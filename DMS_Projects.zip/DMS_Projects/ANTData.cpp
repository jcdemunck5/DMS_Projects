/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*     Reading files from ANT equipment, code adapted from   M. Grigutsch.          */
/*                                                                                  */
/*     NOTE:                                                                        */
/*                                                                                  */
/*                                                                                  */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    12-02-09   Creation
  JdM    01-10-10   Eliminate compiler arnings by explicit type converesions
  JdM    27-01-12   Bug fix: OpenAsRaw3(). creation of new r3-object
                    Added GetMarkerArray()
  JdM    26-11-12   GetRawData(). Fill data array with zeroes when data outside file range are requested.
  JdM    05-08-14   OpenAsRaw3(). Avoid use of sscanf() to read in channel info, as this method fails on LINUX
  JdM    12-12-14   Added recognition of 64 bits variant of ANT data format (CntType==CNT_RAW64)
                    Bug Fix: SortTrig() continue if test==0
                    Bug Fix: GetMarkerArray(). Last event of each new marker was skipped.
*/

#include <math.h>     
#include <string.h>

#include "ANTData.h"
#include "MarkerArray.h"
#include "Marker.h"
#include "AnalyzeLine.h"

static const bool IntelData = true;

/* used to test the binary headers */
#define CHUNKHEADER_SIZE     8
#define CHUNK64HEADER_SIZE  12
#define PARENTHEADER_SIZE   12
#define PARENT64HEADER_SIZE 16

#define RAW3_EPOCH_SIZE(length, chanc) ((length + 2) * (chanc) * 4)


#define RAW3_COPY      0  /* no residuals, original 16-bit values stored */                                             
#define RAW3_TIME      1  /* 16 bit residuals from first deviation       */
#define RAW3_TIME2     2  /* 16 bit residuals from second deviation      */
#define RAW3_CHAN      3  /* 16 bit residuals from difference of first deviation */
                          /* and first dev. of neighbor channel   */

#define RAW3_COPY_32   8  /* the same for 32 bit sample data */
#define RAW3_TIME_32   9
#define RAW3_TIME2_32 10
#define RAW3_CHAN_32  11

int dehuffman16(unsigned char *in, int n, int *method, int *out);
int dehuffman32(unsigned char *in, int n, int *method, int *out);
int dehuffman(unsigned char *in, int n, int *method, int *out);
int decompchan(URaw *raw, int *last, int *cur, int n, char *in);
int decompepoch_mux(URaw *raw, char *in, int length, int *out);


#define TAG_EEP20 "EEP V2.0"
#define TAG_NS30  "Version 3.0"

UString UANTData::Properties = UString();

void URaw::SetAllMembersDefault()
{
    chanc = 0;
    chanv = NULL;
    for(int k=0; k<RAW3_METHODC; k++)
    {
        rc[k].method    = 0;
        rc[k].nbits     = 0;
        rc[k].nexcbits  = 0;
        rc[k].length    = 0;
        memset(rc[k].hst, 0, 33*sizeof(int));
        rc[k].res       = NULL;
    }
    length = 0;
    last   = NULL;
    cur    = NULL;
    error  = U_OK;
}
void URaw::DeleteAllMembers(ErrorType E)
{
    delete[] chanv;
    delete[] last;
    delete[] cur;
    for(int k=0; k<RAW3_METHODC; k++) delete[] rc[k].res;
    SetAllMembersDefault();
    error = E;
}

URaw::URaw()
{
    SetAllMembersDefault();
}
URaw::URaw(const URaw& R3)
{
    SetAllMembersDefault();
    *this = R3;
}

URaw::URaw(int cc, const short *cv, uint64_t le)
{
    SetAllMembersDefault();
    
    if(cc<=0 || cv==NULL || le<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: URaw::URaw(). Invalid (NULL) arguments, cc=%d, length=%d .\n", cc, int(le));
        return;
    }

    chanc  = short(cc);
    chanv  = new short[chanc];
    length = le;
    last   = new int[length];
    cur    = new int[length];

    if(chanv==NULL || last==NULL || cur==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: URaw::URaw(). Memory allocation. \n");
        return;
    }
    for(int k=0; k<RAW3_METHODC; k++)
    {
        rc[k].length = le;
        rc[k].res    = new int[le];
        if(rc[k].res==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: URaw::URaw(). Memory allocation, k=%d. \n", k);
            return;
        }
        for(int j=0; j<le; j++) rc[k].res[j] = 0;
    }
    for(int j=0; j<le   ; j++) last[j]  = cur[j] = 0;
    for(int i=0; i<chanc; i++) chanv[i] = cv[i];
}
URaw::~URaw()
{
    DeleteAllMembers(U_OK);
}

URaw& URaw::operator=(const URaw& R3)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: URaw::operator=(). this == NULL. \n");
        static URaw R; R.error = U_ERROR;
        return R;
    }
    if(&R3==NULL)
    {
        CI.AddToLog("ERROR: URaw::operator=(). Invalid NULL argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&R3) return *this;

    DeleteAllMembers(U_OK);
    chanc = R3.chanc;
    if(R3.chanv)
    {
        chanv = new short[chanc];
        if(chanv) for(int i=0; i<chanc; i++) chanv[i] = R3.chanv[i];
    }
    length = R3.length;
    if(R3.last)
    {
        last = new int[length];
        if(last) for(int l=0; l<length; l++) last[l] = R3.last[l];
    }
    if(R3.cur)
    {
        cur = new int[length];
        if(cur) for(int l=0; l<length; l++) cur[l] = R3.cur[l];
    }
    if((R3.chanv && chanv==NULL) || (R3.last && last==NULL) || (R3.cur && cur==NULL) )
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: URaw::operator=(). Memory allocation. \n");
        return *this;
    }
    for(int k=0; k<RAW3_METHODC; k++)
    {
        rc[k].method    = R3.rc[k].method;
        rc[k].nbits     = R3.rc[k].nbits;
        rc[k].nexcbits  = R3.rc[k].nexcbits;
        rc[k].length    = R3.rc[k].length;
        memcpy(rc[k].hst, R3.rc[k].hst, 33*sizeof(int));
        if(R3.rc[k].res)
        {
            rc[k].res = new int[rc[k].length];
            if(rc[k].res==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: URaw::operator=(). Memory allocation, k=%d. \n", k);
                return *this;
            }
            for(int l=0; l<length; l++) rc[k].res[l] = R3.rc[k].res[l];
        }
    }
    error = R3.error;    
    return *this;
}

void UANTTrigger::SetAllMembersDefault()
{
    c      = 0;
    cmax   = 0;
    v      = NULL;
    error  = U_OK;
}
void UANTTrigger::DeleteAllMembers(ErrorType E)
{
    delete[] v;
    SetAllMembersDefault();
    error = E;
}
UANTTrigger::UANTTrigger()
{
    SetAllMembersDefault();
}
UANTTrigger::UANTTrigger(const UANTTrigger& AT)
{
    SetAllMembersDefault();
    *this = AT;
}

UANTTrigger::UANTTrigger(int Ntrig, bool mode32, FILE* fp)
{
    SetAllMembersDefault();
    if(Ntrig==0) return;
    if(Ntrig<0 || fp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UANTTrigger::UANTTrigger(). Invalid (NULL) arguments, Ntrig = %d .\n", Ntrig);
        return;
    }
    c      = cmax = Ntrig;
    v      = new trgentry_t[cmax];
    if(v==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UANTTrigger::UANTTrigger(). Memory allocation. Ntrig = %d .\n", Ntrig);
        return;
    }
    for(int k=0; k<cmax; k++) 
    {
        v[k].sample = 0;
        memset(v[k].code, 0, TRG_CODE_LENGTH+2);

        if(mode32)   v[k].sample = ReadBinaryUInt(IntelData, fp);
        else         v[k].sample = ReadBinaryUInt64(IntelData, fp);
        fread(v[k].code, TRG_CODE_LENGTH, 1, fp);
    }
    if(SortTriggers()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UANTTrigger::UANTTrigger(). Sorting triggers.\n");
        return;
    }
}
UANTTrigger::~UANTTrigger()
{
    DeleteAllMembers(U_OK);
}

UANTTrigger& UANTTrigger::operator=(const UANTTrigger& AT)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UANTTrigger::operator=(). this == NULL. \n");
        static UANTTrigger Def; Def.error = U_ERROR;
        return Def;
    }
    if(&AT==NULL)
    {
        CI.AddToLog("ERROR: UANTTrigger::operator=(). Invalid NULL argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&AT) return *this;

    DeleteAllMembers(U_OK);
    c      = AT.c;
    cmax   = AT.cmax;
    if(AT.v)
    {
        v = new trgentry_t[cmax];
        if(v==NULL)
        {
            CI.AddToLog("ERROR: UANTTrigger::operator=(). Memory allocation (cmax = %d). \n", cmax);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int k=0; k<cmax; k++) v[k] = AT.v[k];
    }
    error = AT.error;    
    return *this;
}

static int SortTrig(const void *elem1, const void *elem2)
{    
    const trgentry_t* T1 = (trgentry_t*)elem1;
    const trgentry_t* T2 = (trgentry_t*)elem2;

    if(T1==NULL || T2==NULL) return 1;
    int test = stricmp(T1->code, T2->code);
    if(test) return test;
    if(T1->sample < T2->sample) return -1;
    if(T1->sample > T2->sample) return  1;
    return 0;
}

ErrorType UANTTrigger::SortTriggers(void) const
{
    if(this==NULL || error!=U_OK || cmax<0) return U_ERROR;
    if(cmax==0) return U_OK;

    qsort(v, cmax, sizeof(trgentry_t), SortTrig);
    return U_OK;
}

void UChunk::SetAllMembersDefault()
{
    error  = U_OK;
    id     = 0;
    start  = 0;
    size   = 0;
}
UChunk::UChunk(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UChunk::UChunk(const UChunk& C)
{
    SetAllMembersDefault();
    *this = C;
}
UChunk::UChunk(FILE* fp)
{
    SetAllMembersDefault();
    if(fp==NULL)
    {
        error = U_ERROR;
        return;
    }
    start = ftell(fp);
    id    = GetID(fp);
    size  = ReadBinaryUInt(IntelData, fp);
}
UChunk::~UChunk()
{
}
UChunk& UChunk::operator=(const UChunk& C)
{
    if(&C==NULL || this==NULL)
    {
        static UChunk Def; Def.error = U_ERROR;
        return Def;
    }
    if(&C==this) return *this;

    error  = C.error;
    id     = C.id;
    start  = C.start;
    size   = C.size;
    return *this;
}

unsigned int UChunk::GetID(FILE *fp)
{
    if(fp==NULL) return 0;

    char id[4];  
    fread(id, 4, 1, fp);
    return FOURCC(id[0], id[1], id[2], id[3]);
}
void UChunk64::SetAllMembersDefault()
{
    error  = U_OK;
    id     = 0;
    start  = 0;
    size   = 0;
}
UChunk64::UChunk64(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UChunk64::UChunk64(const UChunk64& C)
{
    SetAllMembersDefault();
    *this = C;
}
UChunk64::UChunk64(FILE* fp)
{
    SetAllMembersDefault();
    if(fp==NULL)
    {
        error = U_ERROR;
        return;
    }
    start = ftell(fp);
    id    = GetID(fp);
    size  = ReadBinaryUInt64(IntelData, fp);
}
UChunk64::~UChunk64()
{
}
UChunk64& UChunk64::operator=(const UChunk64& C)
{
    if(&C==NULL || this==NULL)
    {
        static UChunk64 Def; Def.error = U_ERROR;
        return Def;
    }
    if(&C==this) return *this;

    error  = C.error;
    id     = C.id;
    start  = C.start;
    size   = C.size;
    return *this;
}

unsigned int UChunk64::GetID(FILE *fp)
{
    if(fp==NULL) return 0;

    char id[4];  
    fread(id, 4, 1, fp);
    return FOURCC(id[0], id[1], id[2], id[3]);
}


void UANTData::SetAllMembersDefault(void)
{
    Properties        = UString();
    error             = U_OK;            
    mode              = CNT_UNKNOWN;
    
    period            = 0.;
    chanc             = 0; 
    chanv             = NULL;
    samplec           = 0;
    averagedtriggersc = 1;   
    totaltriggersc    = 1;        
    memset(conditionlabel, 0, sizeof(conditionlabel));
  
    chanseq           = NULL;
    epochc            = 0;
    epochl            = 0;
    epochv            = NULL;             
    epvbuf            = 0;
  
    bufepoch          = -2;  
    writeflag         = '\0';
    writepos          = 0;
    readpos           = 0;
    buf               = NULL;                
    cbuf              = NULL;
  
    hist              = UString();
  
    ns_cnttype        = '\0'; 
    ns_evtc           = 0;
    ns_evtpos         = 0;
    ns_evttype        = 0;
    ns_evtlen         = 0;
}

void UANTData::DeleteAllMembers(ErrorType E)
{
    delete[] chanv;
    delete[] chanseq;
    delete[] epochv;
    delete[] buf; 
    delete[] cbuf; 

    SetAllMembersDefault();
    error = E;
}

UANTData::UANTData() 
{
    SetAllMembersDefault();
}
UANTData::UANTData(const UANTData& ADAT)
{
    SetAllMembersDefault();
    *this = ADAT;
}
UANTData::UANTData(const char* FileName)
{
    SetAllMembersDefault();
    if(FileName==NULL)
    {
        CI.AddToLog("ERROR: UANTData::UANTData(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    ANTFname    = UFileName(FileName);
    FILE* fpANT = fopen(ANTFname, "rb");
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::UANTData(). File does not exist or cannot be opened (%s). \n", FileName);
        DeleteAllMembers(U_ERROR);
        return;
    }
    

    char filetag[32];
    char avrtag[4] = { 0x26, 0x00, 0x10, 0x00 };
    
/* read first "magic" bytes to determine filetype */
    if(fseek(fpANT, 0, SEEK_SET)          || 
       fread(filetag, 16, 1, fpANT) < 1   || 
       fseek(fpANT, 0, SEEK_SET)) 
    {
        CI.AddToLog("ERROR: UANTData::UANTData(). File does not exist or cannot be opened (%s). \n", FileName);
        DeleteAllMembers(U_ERROR);
        return;
    }
    else 
    {
        if(!strncmp("RIFF", filetag, 4) && !strncmp("CNT ", &filetag[8], 4)) mode = CNT_RAW3;
        else if(!strncmp("RF64", filetag, 4)                               ) mode = CNT_RAW64;
        else if(!strncmp(TAG_EEP20, filetag, strlen(TAG_EEP20)))             mode = CNT_EEP20;
        else if(!strncmp(TAG_NS30, filetag, strlen(TAG_NS30)))               mode = CNT_NS30;
        else if(!memcmp(avrtag, filetag, 4))                                 mode = CNT_AVR;
        else                                                                 mode = CNT_UNKNOWN;
    }
    
    if(mode==CNT_RAW3)
    {
        if(OpenAsRaw3(fpANT)!=U_OK)
        {
            CI.AddToLog("ERROR: UANTData::UANTData(). Reading raw data. \n");
            DeleteAllMembers(U_ERROR);
        }
    }
    else if(mode==CNT_RAW64)
    {
        if(OpenAsRaw64(fpANT)!=U_OK)
        {
            CI.AddToLog("ERROR: UANTData::UANTData(). Reading raw data (64 bits format). \n");
            DeleteAllMembers(U_ERROR);
        }
    }
    else
    {
        CI.AddToLog("ERROR: UANTData::UANTData(). Unsuppored data type (mode = %d). \n", mode);
        DeleteAllMembers(U_ERROR);
    }
}
UANTData::~UANTData() 
{
    DeleteAllMembers(U_OK);
}
UANTData& UANTData::operator=(const UANTData& ADAT)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UANTData::operator=(). this == NULL. \n");
        static UANTData Def; Def.error = U_ERROR;
        return Def;
    }
    if(&ADAT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::operator=(). Invalid NULL argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&ADAT) return *this;

    DeleteAllMembers(U_OK);

    mode              = ADAT.mode;                  
    ANTFname          = ADAT.ANTFname;
  
    period            = ADAT.period;                
    chanc             = ADAT.chanc;
    samplec           = ADAT.samplec;
    averagedtriggersc = ADAT.averagedtriggersc;
    totaltriggersc    = ADAT.totaltriggersc;
    memcpy(conditionlabel, ADAT.conditionlabel, sizeof(conditionlabel));
    trg               = ADAT.trg;
    r3                = ADAT.r3;  

    data              = ADAT.data;
    data64            = ADAT.data64;

    epochc            = ADAT.epochc;
    epochl            = ADAT.epochl;
    epvbuf            = ADAT.epvbuf;              
  
    bufepoch          = ADAT.bufepoch;            
    writeflag         = ADAT.writeflag;
    writepos          = ADAT.writepos;
    readpos           = ADAT.readpos;
    hist              = ADAT.hist;

    ns_cnttype        = ADAT.ns_cnttype; 
    ns_evtc           = ADAT.ns_evtc;
    ns_evtpos         = ADAT.ns_evtpos;        
    ns_evttype        = ADAT.ns_evttype;
    ns_evtlen         = ADAT.ns_evtlen;

    if(ADAT.chanv)
    {
        chanv = new EEGChanInfo[chanc];
        if(chanv) for(int i=0; i<chanc; i++) chanv[i] = ADAT.chanv[i];
    }
    if(ADAT.chanseq)
    {
        chanseq = new short[chanc];
        if(chanseq) for(int i=0; i<chanc; i++) chanseq[i] = ADAT.chanseq[i];

    }
    if(ADAT.epochv)
    {
        epochv = new uint64_t[epochc];
        if(epochv)  for(int k=0; k<epochc; k++) epochv[k] = ADAT.epochv[k];
    }
    if(ADAT.buf)
    {
        buf = new int[epochl * chanc];
        if(buf) for(int ki=0; ki<epochl * chanc; ki++) buf[ki] = ADAT.buf[ki];
    }
    if(ADAT.cbuf)
    {
        uint64_t Nbuf = RAW3_EPOCH_SIZE(epochl, chanc);
        cbuf          = new char[Nbuf];
        if(cbuf) for(int k=0; k<Nbuf; k++) cbuf[k] = ADAT.cbuf[k];
    }
    if((ADAT.chanv && chanv==NULL)   || (ADAT.chanseq && chanseq==NULL) ||
       (ADAT.epochv && epochv==NULL) || (ADAT.buf && buf==NULL) || (ADAT.cbuf && cbuf==NULL))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UANTData::operator=(). Memory allocation. \n");
        return *this;
    }  
    error             = ADAT.error;    
    return *this;
}

const UString& UANTData::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UANTData-object\n");
        return Properties;
    }
    Properties =  UString();
    Properties += UString(chanc            , "NChan           = %d \n"); 
    Properties += UString(epochc           , "NTrial          = %d \n"); 
    Properties += UString(int(epochl)      , "NSampTrial      = %d \n"); 
    Properties += UString(samplec          , "NTotalSamp      = %d \n");
    Properties += UString(period           , "Period          = %f \n"); 
    Properties += UString(conditionlabel   , "Condition       = %s \n");
    Properties += UString(averagedtriggersc, "NAveraged       = %d \n");
    Properties += UString(totaltriggersc   , "NTotalTriggers  = %d \n");
    
    Properties += UString("History \n{\n") + hist + UString("\n}\n");
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

bool UANTData::IsFormat32bits(void) const 
{
    if(this==NULL || error!=U_OK) return true;
    return mode!=CNT_RAW64;
}

UMarkerArray* UANTData::GetMarkerArray(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetMarkerArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(period<=0.)
    {
        CI.AddToLog("ERROR: UANTData::GetMarkerArray(). Invalid period (=%f). \n", period);
        return NULL;
    }
    if(epochl<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetMarkerArray(). Invalid epoch length (=%d) .\n", int(epochl));
        return NULL;
    }
    if(trg.cmax<=0) return NULL;

    UMarkerArray* Mar = new UMarkerArray(0, int(epochl), 0, 1./period);
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        delete Mar;
        CI.AddToLog("ERROR: UANTData::GetMarkerArray(). Creating UMarkerArray .\n");
        return NULL;
    }

    const char* Name = trg.v[0].code;
    UMarker M(Name, 0, int(epochl), 100, "Internal ANT trigger", 0, true);
    for(int j=0; j<trg.cmax; j++)
    {
        const char* NameTest = trg.v[j].code;
        if(stricmp(Name, NameTest)) // new marker
        {
            Mar->AddMarker(&M);
            Name = NameTest;
            M    = UMarker(Name, 0, int(epochl), 100, "Internal ANT trigger", 0, true);
        }
        uint64_t samp = trg.v[j].sample;
        M.AddEvent(UEvent(int(samp/epochl), int(samp%epochl)));
    }
    Mar->AddMarker(&M);
    if(Mar->GetnMarkers()<=0)
    {
        delete Mar; Mar=NULL;
    }
    return Mar;
}
double UANTData::GetSamplingRate(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetSamplingRate(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(period<=0.)
    {
        CI.AddToLog("ERROR: UANTData::GetSamplingRate(). Invalid period (=%f). \n", period);
        return 0.;
    }
    return 1./period;
}
int UANTData::GetNChan(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetNChan(). Object NULL or erroneous. \n");
        return 0;
    }
    if(chanc<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetNChan(). Invalid nchan (=%d). \n", chanc);
        return 0;
    }
    return chanc;
}
int UANTData::GetNTrial(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetNTrial(). Object NULL or erroneous. \n");
        return 0;
    }
    if(epochc<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetNTrial(). Invalid epochc (=%d). \n", epochc);
        return 0;
    }
    return epochc;
}
int UANTData::GetNSampTrial(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetNSampTrial(). Object NULL or erroneous. \n");
        return 0;
    }
    if(epochl<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetNTrial(). Invalid epochl (=%d). \n", int(epochl));
        return 0;
    }
    return int(epochl);
}

EEGChanInfo UANTData::GetChannelInfo(int ichan) const
{
    static EEGChanInfo Def;
    Def.iscale = 0.F;
    Def.rscale = 0.F;
    strncpy(Def.lab  , "ERROR"  , sizeof(Def.lab));
    strncpy(Def.runit, "UNKNOWN", sizeof(Def.lab));

    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetChannelInfo(). Object NULL or erroneous. \n");
        return Def;
    }
    if(chanv==NULL)
    {
        CI.AddToLog("ERROR: UANTData::GetChannelInfo(). chanv not set. \n");
        return Def;
    }
    if(ichan<0 || ichan>=chanc)
    {
        CI.AddToLog("ERROR: UANTData::GetChannelInfo(). channel out of range (ichan=%d). \n", ichan);
        return Def;
    }
    return chanv[ichan];
}

UChunk UANTData::ReadChunk(FILE* fpANT, unsigned int ID, const UChunk& parent, bool TestStartList)
{    
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk(). Object NULL or erroneous. \n");
        return UChunk(U_ERROR);;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk(). Invalid NULL file argument. \n");
        return UChunk(U_ERROR);
    }
    if(mode!=CNT_RAW3)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk(). File has wrong mode (=%d). \n", mode);
        return UChunk(U_ERROR);
    }
    if(&parent==NULL || parent.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk(). Erroneous parent. \n");
        return UChunk(U_ERROR);
    }

    uint32_t nextchunk = 0;
    uint32_t skipsize  = 0;
  
 /* go to parent data area */
    fseek(fpANT, parent.GetStart() + PARENTHEADER_SIZE, SEEK_SET);
  
 /* loop true the childs on this level, no recursion into tree! */
    do 
    {
        if(fseek(fpANT, nextchunk, SEEK_CUR))
        {
            CI.AddToLog("ERROR: UANTData::ReadChunk(). Putting file pointer. \n");
            return UChunk(U_ERROR); 
        }
        UChunk C = UChunk(fpANT);
        if(C.GetError()!=U_OK) 
        {
            CI.AddToLog("ERROR: UANTData::ReadChunk(). Reading next chunck. \n");
            return UChunk(U_ERROR); 
        }
        if(TestStartList && C.GetID()==FOURCC_LIST)
        {
            if(UChunk::GetID(fpANT)==ID) return C;
        }
        else
        {
            if(C.GetID()==ID) return C;
        }
        skipsize += C.GetSize() + CHUNKHEADER_SIZE + (C.GetSize() & 0x01);
        nextchunk = C.GetSize() + (C.GetSize() & 0x01);
    } 
    while(skipsize < parent.GetSize());

    return UChunk(U_ERROR);
}

UChunk64 UANTData::ReadChunk64(FILE* fpANT, unsigned int ID, const UChunk64& parent, bool TestStartList)
{    
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk64(). Object NULL or erroneous. \n");
        return UChunk64(U_ERROR);
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk64(). Invalid NULL file argument. \n");
        return UChunk64(U_ERROR);
    }
    if(mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk64(). File has wrong mode (=%d). \n", mode);
        return UChunk64(U_ERROR);
    }
    if(&parent==NULL || parent.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadChunk64(). Erroneous parent. \n");
        return UChunk64(U_ERROR);
    }

    uint64_t nextchunk = 0;
    uint64_t skipsize  = 0;
  
 /* go to parent data area */
    fseek(fpANT, parent.GetStart() + PARENT64HEADER_SIZE, SEEK_SET);
  
 /* loop true the childs on this level, no recursion into tree! */
    do 
    {
        if(fseek(fpANT, nextchunk, SEEK_CUR))
        {
            CI.AddToLog("ERROR: UANTData::ReadChunk64(). Putting file pointer. \n");
            return UChunk64(U_ERROR); 
        }
        UChunk64 C = UChunk64(fpANT);
        if(C.GetError()!=U_OK) 
        {
            CI.AddToLog("ERROR: UANTData::ReadChunk64(). Reading next chunck. \n");
            return UChunk64(U_ERROR); 
        }
        if(TestStartList && C.GetID()==FOURCC_LIST)
        {
            if(UChunk64::GetID(fpANT)==ID) return C;
        }
        else
        {
            if(C.GetID()==ID) return C;
        }
        skipsize += C.GetSize() + CHUNK64HEADER_SIZE + (C.GetSize() & 0x01);
        nextchunk = C.GetSize() + (C.GetSize() & 0x01);
    } 
    while(skipsize < parent.GetSize());

    return UChunk64(U_ERROR);
}

ErrorType UANTData::OpenAsRaw3(FILE* fpANT)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Inalid NULL FILE* argument. \n");
        return U_ERROR;
    }    
    if(mode!=CNT_RAW3)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). File has wrong mode (=%d). \n", mode);
        return U_ERROR;
    }    
    rewind(fpANT);
    UChunk cnt                = UChunk(fpANT);
    unsigned int IDcnt = UChunk::GetID(fpANT);
    UChunk eeph               = ReadChunk(fpANT, FOURCC_eeph, cnt, false);

    if(cnt.GetError()!=U_OK || IDcnt!= FOURCC_CNT || eeph.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Reading first chunks (). \n");
        return U_ERROR;
    }

/* Read header */
    uint32_t offset = ftell(fpANT);
    char   line[128];
    while(GetLine(line,sizeof(line),fpANT))
    {
        if(ftell(fpANT)>(uint32_t)(offset+eeph.GetSize())) break;

        if(line[0]=='[')
        {        
            if(strstr(line, "[Sampling Rate]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                double rate = AA.GetNextDouble(0.);
                if(rate<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Invalid sampling rate line = %100s. \n", line);
                    return U_ERROR;
                }
                period = 1./rate;
                continue;
            }
            if(strstr(line, "[Samples]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Invalid sample count line = %100s. \n", line);
                    return U_ERROR;
                }
                samplec = test;
                continue;
            }
            if(strstr(line, "[Channels]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Invalid channel count line = %100s. \n", line);
                    return U_ERROR;
                }
                chanc = test;
                continue;
            }
            if(strstr(line, "[Number of averaged Triggers]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                    CI.AddToLog("WARNING: UANTData::OpenAsRaw3(). Number of averages. line = %100s. \n", line);
                else
                    averagedtriggersc = test;
                continue;
            }
            if(strstr(line, "[Total Number of Triggers]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                    CI.AddToLog("WARNING: UANTData::OpenAsRaw3(). Total number of triggers. line = %100s. \n", line);
                else
                    totaltriggersc = test;
                continue;
            }
            if(strstr(line, "[Condition Label]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                strncpy(conditionlabel,line,sizeof(conditionlabel)-1);
                continue;
            }
            if(strstr(line, "[Basic Channel Data]")) 
            {
                if(chanc<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Reading channel info, nchanc = %d . \n", chanc);
                    return U_ERROR;
                }
                chanv = new EEGChanInfo[chanc];
                if(chanv==NULL)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Memory allocation. nchanc = %d . \n", chanc);
                    return U_ERROR;
                }
                int i = 0;
                while(i<chanc)
                {
                    if(GetLine(line,sizeof(line),fpANT)==NULL) break;
                    if(*line == ';') continue;
                    UAnalyzeLine AA(line, sizeof(line));
                    strcpy(chanv[i].lab, AA.GetNextString(sizeof(chanv[i].lab), "DefLab"));
                    chanv[i].iscale = AA.GetNextDouble(0.);
                    chanv[i].rscale = AA.GetNextDouble(0.);
                    strcpy(chanv[i].runit, AA.GetNextString(sizeof(chanv[i].runit), "AU"));
                    const char* Mu  = strstr(line, chanv[i].runit);
                    if(Mu && *(Mu-1)==-75)
                    {
                        memset(chanv[i].runit, 0, sizeof(chanv[i].runit));
                        size_t NB = MIN(sizeof(chanv[i].runit)-1, strlen(chanv[i].runit)+2);
                        strncpy(chanv[i].runit, Mu-1, NB);
                    }
                    i++;
                }
                continue;
            }
            if(strstr(line, "[History]"))
            {
                hist = UString();
                while(GetLine(line,sizeof(line),fpANT))
                {
                    if(!strcmp(line, "EOH")) break;
                    hist += UString(line) + UString("\n");
                }
                continue;
            }
        }
    }
    if(period<=0. || chanc==0 || chanv==NULL || samplec == 0)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Not all data members present in file.  \n");
        return U_ERROR;
    }
    UChunk raw3 = ReadChunk(fpANT, FOURCC_raw3, cnt , true);
    UChunk chan = ReadChunk(fpANT, FOURCC_chan, raw3, false);
    if(raw3.GetError()!=U_OK || chan.GetError()!=U_OK || chan.GetSize()!=(unsigned int)(2*chanc))
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Reading raw3 or chan .\n");
        return U_ERROR;
    }
    chanseq = new short[chanc];
    if(chanseq==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Memory allocation (chanc = %d) .\n", chanc);
        return U_ERROR;
    }
    for(int i=0; i<chanc; i++) 
        chanseq[i] = ReadBinaryShort(IntelData, fpANT);
  
/* epoch table */
    UChunk ep = ReadChunk(fpANT, FOURCC_ep, raw3 , false);
    if(ep.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Reading ep chunck. \n");
        return U_ERROR;
    }
    epochl = ReadBinaryInt(IntelData, fpANT);
    epochc = ep.GetSize() / 4 - 1;
    if(epochc<=0 || epochl <=0) 
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Invalid epoch length (%d) or epoch count (%d). \n", int(epochl), epochc);
        return U_ERROR;
    }
    epochv = new uint64_t[epochc];
    if(epochv==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Memory allocation (epochc = %d). \n", epochc);
        return U_ERROR;
    }
    for(int k=0; k<epochc; k++) epochv[k] = ReadBinaryInt(IntelData, fpANT);
  
/* trigger table */
    UChunk evt = ReadChunk(fpANT, FOURCC_evt, cnt, false);
    if(evt.GetError()!=U_OK)
    {
        CI.AddToLog("WARNING: UANTData::OpenAsRaw3(). No triggers in file %s. \n", (const char*)ANTFname);        
    }
    else
    {
        trg = UANTTrigger(evt.GetSize() / 12, true, fpANT);
        if(trg.GetError()!=U_OK)
        {
            trg = UANTTrigger();
            CI.AddToLog("WARNING: UANTData::OpenAsRaw3(). Reading triggers. \n");
        }
    }

/* compression buffer setup */
    r3   = URaw(chanc, chanseq, epochl);
    buf  = new int[epochl * chanc];
    cbuf = new char[RAW3_EPOCH_SIZE(epochl, chanc)];
    if(r3.GetError()!= U_OK || buf==NULL || cbuf==NULL) 
    {
        delete[] cbuf; cbuf = NULL;
        delete[] buf;  buf  = NULL;

        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Memory allocation for compression buffers (epochl=%d, chanc=%d). \n", int(epochl), chanc);
        return U_ERROR;
    }
  
/* open data area and fill first buffer */
    data = ReadChunk(fpANT, FOURCC_data, raw3,false);
    if(data.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw3(). Reading data element. \n");
        return U_ERROR;
    }
    return ReadEpoch(fpANT, 0);
}

ErrorType UANTData::OpenAsRaw64(FILE* fpANT)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Inalid NULL FILE* argument. \n");
        return U_ERROR;
    }    
    if(mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). File has wrong mode (=%d). \n", mode);
        return U_ERROR;
    }    
    rewind(fpANT);
    UChunk64 cnt              = UChunk64(fpANT);
    unsigned int IDcnt        = UChunk64::GetID(fpANT);
    UChunk64 eeph             = ReadChunk64(fpANT, FOURCC_eeph, cnt, false);

    if(cnt.GetError()!=U_OK || IDcnt!= FOURCC_CNT || eeph.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Reading first chunks (). \n");
        return U_ERROR;
    }

/* Read header */
    uint64_t offset = ftell(fpANT);
    char   line[128];
    while(GetLine(line,sizeof(line),fpANT))
    {
        if(ftell(fpANT)>(uint64_t)(offset+eeph.GetSize())) break;

        if(line[0]=='[')
        {        
            if(strstr(line, "[Sampling Rate]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                double rate = AA.GetNextDouble(0.);
                if(rate<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Invalid sampling rate line = %100s. \n", line);
                    return U_ERROR;
                }
                period = 1./rate;
                continue;
            }
            if(strstr(line, "[Samples]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Invalid sample count line = %100s. \n", line);
                    return U_ERROR;
                }
                samplec = test;
                continue;
            }
            if(strstr(line, "[Channels]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Invalid channel count line = %100s. \n", line);
                    return U_ERROR;
                }
                chanc = test;
                continue;
            }
            if(strstr(line, "[Number of averaged Triggers]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                    CI.AddToLog("WARNING: UANTData::OpenAsRaw64(). Number of averages. line = %100s. \n", line);
                else
                    averagedtriggersc = test;
                continue;
            }
            if(strstr(line, "[Total Number of Triggers]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                UAnalyzeLine AA(line);
                int test = AA.GetNextInt(0);
                if(test<=0)
                    CI.AddToLog("WARNING: UANTData::OpenAsRaw64(). Total number of triggers. line = %100s. \n", line);
                else
                    totaltriggersc = test;
                continue;
            }
            if(strstr(line, "[Condition Label]")) 
            {
                GetLine(line,sizeof(line),fpANT);
                strncpy(conditionlabel,line,sizeof(conditionlabel)-1);
                continue;
            }
            if(strstr(line, "[Basic Channel Data]")) 
            {
                if(chanc<=0)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Reading channel info, nchanc = %d . \n", chanc);
                    return U_ERROR;
                }
                chanv = new EEGChanInfo[chanc];
                if(chanv==NULL)
                {
                    CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Memory allocation. nchanc = %d . \n", chanc);
                    return U_ERROR;
                }
                int i = 0;
                while(i<chanc)
                {
                    if(GetLine(line,sizeof(line),fpANT)==NULL) break;
                    if(*line == ';') continue;
                    UAnalyzeLine AA(line, sizeof(line));
                    strcpy(chanv[i].lab, AA.GetNextString(sizeof(chanv[i].lab), "DefLab"));
                    chanv[i].iscale = AA.GetNextDouble(0.);
                    chanv[i].rscale = AA.GetNextDouble(0.);
                    strcpy(chanv[i].runit, AA.GetNextString(sizeof(chanv[i].runit), "AU"));
                    const char* Mu  = strstr(line, chanv[i].runit);
                    if(Mu && *(Mu-1)==-75)
                    {
                        memset(chanv[i].runit, 0, sizeof(chanv[i].runit));
                        size_t NB = MIN(sizeof(chanv[i].runit)-1, strlen(chanv[i].runit)+2);
                        strncpy(chanv[i].runit, Mu-1, NB);
                    }
                    i++;
                }
                continue;
            }
            if(strstr(line, "[History]"))
            {
                hist = UString();
                while(GetLine(line,sizeof(line),fpANT))
                {
                    if(!strcmp(line, "EOH")) break;
                    hist += UString(line) + UString("\n");
                }
                continue;
            }
        }
    }
    if(period<=0. || chanc==0 || chanv==NULL || samplec == 0)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Not all data members present in file.  \n");
        return U_ERROR;
    }
    UChunk64 raw3 = ReadChunk64(fpANT, FOURCC_raw3, cnt , true);
    UChunk64 chan = ReadChunk64(fpANT, FOURCC_chan, raw3, false);
    if(raw3.GetError()!=U_OK || chan.GetError()!=U_OK || chan.GetSize()!=(unsigned int)(2*chanc))
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Reading raw3 or chan .\n");
        return U_ERROR;
    }
    chanseq = new short[chanc];
    if(chanseq==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Memory allocation (chanc = %d) .\n", chanc);
        return U_ERROR;
    }
    for(int i=0; i<chanc; i++) 
        chanseq[i] = ReadBinaryShort(IntelData, fpANT);
  
/* epoch table */
    UChunk64 ep = ReadChunk64(fpANT, FOURCC_ep, raw3 , false);
    if(ep.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Reading ep chunck. \n");
        return U_ERROR;
    }
    epochl = ReadBinaryUInt64(IntelData, fpANT);
    epochc = int(ep.GetSize() / 8 - 1);
    if(epochc<=0 || epochl <=0) 
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Invalid epoch length (%d) or epoch count (%d). \n", int(epochl), epochc);
        return U_ERROR;
    }
    epochv = new uint64_t[epochc];
    if(epochv==NULL)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Memory allocation (epochc = %d). \n", epochc);
        return U_ERROR;
    }
    for(int k=0; k<epochc; k++) epochv[k] = ReadBinaryUInt64(IntelData, fpANT);
  
/* trigger table */
    UChunk64 evt = ReadChunk64(fpANT, FOURCC_evt, cnt, false);
    if(evt.GetError()!=U_OK)
    {
        CI.AddToLog("WARNING: UANTData::OpenAsRaw64(). No triggers in file %s. \n", (const char*)ANTFname);        
    }
    else
    {
        trg = UANTTrigger(int(evt.GetSize() / 12), false, fpANT);
        if(trg.GetError()!=U_OK)
        {
            trg = UANTTrigger();
            CI.AddToLog("WARNING: UANTData::OpenAsRaw64(). Reading triggers. \n");
        }
    }

/* compression buffer setup */
    r3   = URaw(chanc, chanseq, epochl);
    buf  = new int[epochl * chanc];
    cbuf = new char[RAW3_EPOCH_SIZE(epochl, chanc)];
    if(r3.GetError()!= U_OK || buf==NULL || cbuf==NULL) 
    {
        delete[] cbuf; cbuf = NULL;
        delete[] buf;  buf  = NULL;

        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Memory allocation for compression buffers (epochl=%d, chanc=%d). \n", int(epochl), chanc);
        return U_ERROR;
    }
  
/* open data area and fill first buffer */
    data64 = ReadChunk64(fpANT, FOURCC_data, raw3,false);
    if(data64.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::OpenAsRaw64(). Reading data element. \n");
        return U_ERROR;
    }
    return ReadEpoch(fpANT, 0);
}

ErrorType UANTData::ReadEpoch(FILE* fpANT, int iep)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Inalid NULL FILE* argument. \n");
        return U_ERROR;
    }    
    if(mode!=CNT_RAW3 && mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). File has wrong mode (=%d). \n", mode);
        return U_ERROR;
    }    
    if(epochv==NULL || cbuf==NULL || buf==NULL)
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Object not properly initialized. \n");
        return U_ERROR;
    }    
    if(iep<0 || iep>=epochc)
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Epoch number out of range (iep %d). \n", iep);
        return U_ERROR;
    }
    uint64_t   insize    = 0;
    uint64_t   insamples = 0;
  
/* how much bytes to read ? */
    if(iep == epochc - 1) 
    {
        insize    = data.GetSize() - epochv[iep];
        insamples = samplec        - iep*epochl;
    }
    else 
    {
        insize    = epochv[iep + 1] - epochv[iep];
        insamples = epochl;
    }
    if(mode==CNT_RAW3) fseek(fpANT, data  .GetStart() + CHUNKHEADER_SIZE   + epochv[iep], SEEK_SET);
    else               fseek(fpANT, data64.GetStart() + CHUNK64HEADER_SIZE + epochv[iep], SEEK_SET);
          
    if(fread(cbuf, 1, insize, fpANT) != (uint64_t)(insize))
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Reading error, insize = %d . \n", int(insize));
        return U_ERROR;
    }
    bufepoch = iep;
    readpos  = 0;
    int got  = decompepoch_mux(&r3, cbuf, insamples, buf);

    if(got != insize) 
    {
        CI.AddToLog("ERROR: UANTData::ReadEpoch(). Checksum error:got %d expected %d filepos %x epoch %d\n", got, int(insize), int(epochv[iep]), iep);
        return U_ERROR;
    }
    return U_OK;
}

double* UANTData::GetRawData(int SampFrom, int NSamp, int* ChanSel, int NSel)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(mode!=CNT_RAW3 && mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). File has wrong mode (=%d). \n", mode);
        return NULL;
    }    
    if(epochv==NULL || cbuf==NULL || buf==NULL || chanv==NULL)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Object not properly initialized. \n");
        return NULL;
    }   
    if(chanc<=0 || samplec<=0 || epochl<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Object not properly initialized (chanc=%d, samplec=%d, epochl=%d). \n", chanc, samplec, int(epochl));
        return NULL;
    }
    int NLeadingZeroes = (SampFrom      <0       ) ?  -SampFrom : 0;
    int NEndingZeroes  = (SampFrom+NSamp>=samplec) ?   SampFrom+NSamp-samplec : 0;

    if(SampFrom>=samplec || NSamp<=0)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Arguments out of range (SampFrom=%d, NSamp=%d). \n", SampFrom, NSamp);
        return NULL;
    }

    if(ChanSel==NULL || NSel<=0 || NSel>chanc)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Channel selection parameters NULL or invalid (NSel = %d). \n", NSel);
        return NULL;
    }
    for(int i=0; i<NSel; i++)
        if(ChanSel[i]<0 || ChanSel[i]>=chanc) 
        {
            CI.AddToLog("ERROR: UANTData::GetRawData(). Channel selection number %d out of range (%d). \n", i, ChanSel[i]);
            return NULL;
        }

    FILE*   fpANT  = fopen(ANTFname, "rb");
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::GetRawData(). Cannot open file: %s \n", (const char*)ANTFname);
        return NULL;
    }
    int*    rbuf   = new int[(RAW3_EPOCH_SIZE(chanc,1))/4];
    double* RawDat = new double[NSel*NSamp]; 
    for(int ij=0; ij<NSel*NSamp; ij++) RawDat[ij] = 0.;

    if(rbuf==NULL || RawDat==NULL)
    {
        fclose(fpANT);
        delete[] rbuf;
        delete[] RawDat;
        CI.AddToLog("ERROR: UANTData::GetRawData(). Memory allocation (chanc=%d, NSaamp=%d). \n", chanc, NSamp);
        return NULL;
    }
  
    if(SetFileOffset(fpANT, SampFrom+NLeadingZeroes)!=U_OK)
    {
        fclose(fpANT);
        delete[] rbuf;
        delete[] RawDat;
        CI.AddToLog("ERROR: UANTData::GetRawData(). Setting file pointer. \n");
        return NULL;
    }
    for(int j=NLeadingZeroes; j<NSamp-NEndingZeroes; j++)
    {
        if(ReadSamples(fpANT, rbuf, 1) != U_OK)
        {
            fclose(fpANT);
            delete[] rbuf;
            delete[] RawDat;
            CI.AddToLog("ERROR: UANTData::GetRawData(). Reading data. \n");
            return NULL;
        }
        for(int i=0; i<NSel; i++)
        {
            int    ichan      = ChanSel[i];
            double Fact       = chanv[ichan].iscale * chanv[ichan].rscale;
            RawDat[i*NSamp+j] = Fact * rbuf[ichan];
        }
    }
    fclose(fpANT);
    delete[] rbuf;
    return RawDat;
}

ErrorType UANTData::SetFileOffset(FILE* fpANT, int sample)  /// cntseek()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::SetFileOffset(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::SetFileOffset(). Inalid NULL FILE* argument. \n");
        return U_ERROR;
    }    
    if(mode!=CNT_RAW3 && mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::SetFileOffset(). File has wrong mode (=%d). \n", mode);
        return U_ERROR;
    }    
    if(epochl<=0)
    {
        CI.AddToLog("ERROR: UANTData::SetFileOffset(). Epoch length wrong (%d).\n", int(epochl));
        return U_ERROR;
    }
    if(sample<0 || sample>=samplec)
    {
        CI.AddToLog("ERROR: UANTData::SetFileOffset(). Argument out of range (sample=%d, samplec=%d) .\n", sample, samplec);
        return U_ERROR;
    }

    ErrorType E = U_OK;
    if(sample/epochl != bufepoch) E =  ReadEpoch(fpANT, int(sample / epochl));
    readpos = sample % epochl;

    return E;
}

ErrorType UANTData::ReadSamples(FILE* fpANT, int *muxbuf, int Nsamp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UANTData::ReadSamples(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpANT==NULL)
    {
        CI.AddToLog("ERROR: UANTData::ReadSamples(). Inalid NULL FILE* argument. \n");
        return U_ERROR;
    }    
    if(mode!=CNT_RAW3 && mode!=CNT_RAW64)
    {
        CI.AddToLog("ERROR: UANTData::ReadSamples(). File has wrong mode (=%d). \n", mode);
        return U_ERROR;
    }    
    if(buf==NULL || chanc<=0)
    {
        CI.AddToLog("ERROR: UANTData::ReadSamples(). Object not properly initialized. \n");
        return U_ERROR;
    }   
    if(muxbuf==NULL || Nsamp<=0)
    {
        CI.AddToLog("ERROR: UANTData::ReadSamples(). Invalid (NULL) argument, Nsamp = %d .\n", Nsamp);
        return U_ERROR;
    }
    int iraw = chanc+2;


    for(int j = 0; j<Nsamp; j++) /* 1 sample per channel + 4 bytes control to 0 */
    {        
        for(int i=0; i<chanc; i++) muxbuf[j*iraw+i] = buf[readpos*chanc+i];
        muxbuf[j * iraw + chanc    ] = 0;
        muxbuf[j * iraw + chanc + 1] = 0;
        
        readpos++;
        if(readpos==epochl) /* can we read a next buffer ? */
        {
            if(bufepoch<epochc-1) 
            {
                if(ReadEpoch(fpANT, bufepoch + 1)!=U_OK) 
                {
                    CI.AddToLog("ERROR: UANTData::ReadSamples(). Reading buffer (%d) .\n", bufepoch+1);
                    return U_ERROR;
                }
            }
            else /* or increment counters only (needed for cntseekrel) */
            {
                readpos = 0;
                bufepoch++;
            }
        }
    }
    return U_OK;
}

int dehuffman16(unsigned char *in, int n, int *method, int *out)
{
  int  nin = 0, nout = 0;
  int  nbit, nbit_1, nexcbit, nexcbit_1, check_exc;
  int  bitin;
  int excval;
  /*int i,j; */ 
  
  int hibytein;
  unsigned int iwork;
  int swork;
  
  static int negmask[33] = {
    0xffffffff, 0xfffffffe, 0xfffffffc, 0xfffffff8,
    0xfffffff0, 0xffffffe0, 0xffffffc0, 0xffffff80,
    0xffffff00, 0xfffffe00, 0xfffffc00, 0xfffff800,
    0xfffff000, 0xffffe000, 0xffffc000, 0xffff8000,
    0xffff0000, 0xfffe0000, 0xfffc0000, 0xfff80000,
    0xfff00000, 0xffe00000, 0xffc00000, 0xff800000,
    0xff000000, 0xfe000000, 0xfc000000, 0xf8000000,
    0xf0000000, 0xe0000000, 0xc0000000, 0x80000000,
    0x00000000
  };
  
  static int posmask[33] = {
    0x00000000, 0x00000001, 0x00000003, 0x00000007,
    0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f,
    0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff,
    0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff,
    0x0000ffff, 0x0001ffff, 0x0003ffff, 0x0007ffff,
    0x000fffff, 0x001fffff, 0x003fffff, 0x007fffff,
    0x00ffffff, 0x01ffffff, 0x03ffffff, 0x07ffffff,
    0x0fffffff, 0x1fffffff, 0x3fffffff, 0x7fffffff,
    0xffffffff
  };

  static int setbit[16] = {
    0x0001, 0x0002, 0x0004, 0x0008,
    0x0010, 0x0020, 0x0040, 0x0080,
    0x0100, 0x0200, 0x0400, 0x0800,
    0x1000, 0x2000, 0x4000, 0x8000
  };
     
  *method = (in[0] >> 4) & 0x0f;

  if (*method != RAW3_COPY) {
    nbit = in[0] & 0x0f;
    /* using 4-bit coding nbit=16 is coded as zero */
    if (nbit == 0) {
      nbit = 16;
      #ifdef RAW3_CHECK
      fprintf(stdout,"\nWarning: critical compression method encountered "
                     "(method %d, 16 bit)\n", *method);
      ERR_FLAG_16 = 1;           
      #endif
    }             
    nbit_1 = nbit - 1;
    nexcbit = (in[1] >> 4) & 0x0f;
    /* using 4-bit coding nexcbit=16 is coded as zero */   
    if (nexcbit == 0) nexcbit = 16;
    /* for test only
    printf("\nnbit: %d, nexcbit: %d, method: %d\n",nbit,nexcbit,*method);
    */ 
    nexcbit_1 = nexcbit - 1;
    excval = -(1 << (nbit_1));
    check_exc = (nbit != nexcbit);

    out[0] =   ((int) in[1] & 0x0f) << 12
             | (int) in[2] << 4
             | (((int) in[3] >> 4) & 0x0f);
    if (out[0] & 0x8000)  out[0] |= 0xffff0000;

    bitin = 28;
    nout = 1;
    
    /* we need to read 2 or 3 bytes from input to get all input value bits */
    if (nbit < 9) {
      while (nout < n) {
    /* index of first byte in inbytes containing bits of current value */
    hibytein = bitin >> 3;

    /* max 2 inbytes are needed here for all the bits */
    iwork = (in[hibytein] << 8) + in[hibytein + 1];
    swork = iwork >> (((hibytein + 2) << 3) - bitin - nbit);

    /* handle the sign in the work buffer */
    if (swork & setbit[nbit_1]) {
          swork |= negmask[nbit];
    }
    else {
          swork &= posmask[nbit];
    }

    bitin += nbit;

    /* exception ? - forget what we got and read again */
    if (swork == excval && check_exc) {
      /* index of first byte containing bits of current exc. value */
      hibytein = bitin >> 3;

      /* max 3 inbytes are needed for all the exc. bits */
      iwork = (in[hibytein] << 16) + (in[hibytein + 1] << 8) + in[hibytein + 2];
          swork = iwork >> (((hibytein + 3) << 3) - bitin - nexcbit);
      /* handle the sign in the work buffer */
      if (swork & setbit[nexcbit_1]) {
            swork |= negmask[nexcbit];
      }
      else {
            swork &= posmask[nexcbit];
      }
      bitin += nexcbit;
    }

    out[nout++] = swork;
      }
    }
    
    else {
      while (nout < n) {
    /* index of first byte in inbytes containing bits of current value */
    hibytein = bitin >> 3;

    /* max 3 inbytes are needed for all the bits */
    iwork = (in[hibytein] << 16) + (in[hibytein + 1] << 8) + in[hibytein + 2];
    swork = iwork >> (((hibytein + 3) << 3) - bitin - nbit);

    /* handle the sign in the work buffer */
    if (swork & setbit[nbit_1]) {
          swork |= negmask[nbit];
    }
    else {
          swork &= posmask[nbit];
    }

    bitin += nbit;

    /* exception ? - forget what we got and read again */
    if (swork == excval && nbit != nexcbit) {
      /* index of first byte containing bits of current exc. value */
      hibytein = bitin >> 3;

      /* max 3 inbytes are needed for all the bits */
      iwork = (in[hibytein] << 16) + (in[hibytein + 1] << 8) + in[hibytein + 2];
          swork = iwork >> (((hibytein + 3) << 3) - bitin - nexcbit);
      /* handle the sign in the work buffer */
      if (swork & setbit[nexcbit_1]) {
            swork |= negmask[nexcbit];
      }
      else {
            swork &= posmask[nexcbit];
      }
      bitin += nexcbit;
    }

    out[nout++] = swork;
      }
    }
    nin = bitin >> 3;
    if (bitin & 0x07) nin++;
  }
  /* RAW3_COPY mode */
  else {
    #ifdef RAW3_CHECK
    fprintf(stdout,"\nWarning: critical compression method encountered "
                   "(method 0 RAW3_COPY)\n");   
    ERR_FLAG_0 = 1; 
    #endif              
    nin = 1;
    for (nout = 0; nout < n; nout++) {
      out[nout] = (((int) in[nin]) << 8) | in[nin + 1];
      /* read s16 instead of u16 */
      if(out[nout] > 32767) out[nout] -= 65536;
      nin += 2;
    }
  }  
  return nin;
}

int dehuffman32(unsigned char *in, int n, int *method, int *out)
{
  int nin = 0, nout = 0;
  int  nbit, nbit_1, nexcbit, nexcbit_1, check_exc;
  int  bitin, bitout;
  char inval; int outval, excval;
  /* int i; */
  
  static unsigned char setinbit[8] = {
    0x01, 0x02, 0x04, 0x08,
    0x10, 0x20, 0x40, 0x80
  };

  static unsigned int setoutbit[32] = {
    0x00000001, 0x00000002, 0x00000004, 0x00000008,
    0x00000010, 0x00000020, 0x00000040, 0x00000080,
    0x00000100, 0x00000200, 0x00000400, 0x00000800,
    0x00001000, 0x00002000, 0x00004000, 0x00008000,
    0x00010000, 0x00020000, 0x00040000, 0x00080000,
    0x00100000, 0x00200000, 0x00400000, 0x00800000,
    0x01000000, 0x02000000, 0x04000000, 0x08000000,
    0x10000000, 0x20000000, 0x40000000, 0x80000000
  };
  
  static unsigned int negmask[33] = {
    0xffffffff, 0xfffffffe, 0xfffffffc, 0xfffffff8,
    0xfffffff0, 0xffffffe0, 0xffffffc0, 0xffffff80,
    0xffffff00, 0xfffffe00, 0xfffffc00, 0xfffff800,
    0xfffff000, 0xffffe000, 0xffffc000, 0xffff8000,
    0xffff0000, 0xfffe0000, 0xfffc0000, 0xfff80000,
    0xfff00000, 0xffe00000, 0xffc00000, 0xff800000,
    0xff000000, 0xfe000000, 0xfc000000, 0xf8000000,
    0xf0000000, 0xe0000000, 0xc0000000, 0x80000000,
    0x00000000
  };
  
  *method = (in[0] >> 4) & 0x0f;
  
  if (*method != RAW3_COPY_32) {
    nbit = ((in[0] << 2) & 0x3c) | ((in[1] >> 6) & 0x03);
    nbit_1 = nbit - 1;
    nexcbit = in[1] & 0x3f;
    /* if (nexcbit == 0) nexcbit = 64; */
    nexcbit_1 = nexcbit - 1;

    out[0] =   ((int) in[2] << 24)
             | ((int) in[3] << 16)
             | ((int) in[4] <<  8)
             | ((int) in[5]);
    
    nin = 6;
    bitin = 7;
    inval = in[nin];
    nout = 1;
    bitout = nbit_1;
    outval = 0;
    excval = -(1 << (nbit_1));
    check_exc = (nbit != nexcbit);

    while (nout < n) {

      /* transfer bitwise from in to out */
      if (inval & setinbit[bitin]) {
        outval |= setoutbit[bitout];
        /* handle the sign in out according to sign bit in in */
        if (bitout == nbit_1) {
          outval |= negmask[nbit];
        }
      }

      bitin--;
      if (bitin < 0) {
        nin++;
        bitin = 7;
        inval = in[nin];
      }

      bitout--;

      /* is a residual complete ? */
      if (bitout < 0) {

        /* its an exception ? - forget this and read the large value which follows */
        if (outval == excval && check_exc) {
          outval = 0;
          for (bitout = nexcbit_1; bitout >= 0; bitout--) {
            if (inval & setinbit[bitin]) {
              outval |= setoutbit[bitout];
              if (bitout == nexcbit_1) {
                outval |= negmask[nexcbit];
              }
            }
            bitin--;
            if (bitin < 0) {
              nin++;
              bitin = 7;
              inval = in[nin];
            }
          }
        }

        /* now we really have the value, store it and set up for the next one */
        out[nout++] = outval;
        outval = 0;
        bitout = nbit - 1;
      }
    }
    /* count last incomplete input byte */
    if (bitin != 7) nin++;
  }

  /* RAW3_COPY_32 */
  else {
    nin = 1;
    for (nout = 0; nout < n; nout++) {
      out[nout] =   ((int) in[nin]   << 24) 
                  | ((int) in[nin+1] << 16) 
                  | ((int) in[nin+2] <<  8) 
                  | ((int) in[nin+3]      );
      nin += 4;
    }
  }

  return nin;
}

int dehuffman(unsigned char *in, int n, int *method, int *out)
{
/* method bit 3 indicates 16 or 32 bit compression */
    if(in[0] & (unsigned char) 0x80) 
    {
        return dehuffman32(in, n, method, out);
    }
    else 
    {
        return dehuffman16(in, n, method, out);
    }
}

int decompchan(URaw *raw, int *last, int *cur, int n, char *in)
{
    int method, sample, sample_1, sample_2;
    int length;
    int *res = raw->rc[0].res;
  
  /* restore the residuals */

    length = dehuffman((unsigned char *) in, n, &method, res);
  
  /* build the values using residuals and method */

    switch(method & 0x07) 
    {
    case RAW3_TIME:
        cur[0] = res[0];
        sample_1 = 0;
        for(sample = 1; sample < n; sample++) 
        {
            cur[sample] = cur[sample_1] + res[sample];
            sample_1++;
        }      
        break;
     
    case RAW3_TIME2:
        cur[0] = res[0];
        cur[1] = cur[0] + res[1];
        sample_2 = 0;
        sample_1 = 1;
        for(sample = 2; sample < n; sample++) 
        {
            cur[sample] = 2 * cur[sample_1] - cur[sample_2] + res[sample];
            sample_1++;
            sample_2++;
        }      
        break;

    case RAW3_CHAN:
        cur[0]   = res[0];
        sample_1 = 0;
        for(sample = 1; sample < n; sample++) 
        {
            cur[sample] = cur[sample_1] + last[sample] - last[sample_1] + res[sample];
            sample_1++;
        }     
        break;
    
    case RAW3_COPY:
        memcpy(cur, res, n * sizeof(int));
        break;
      
    default:
        CI.AddToLog("ERROR: decompchan() raw3: unknown compression method!\n");
        break;
    }    
    return length;
}

int decompepoch_mux(URaw *raw, char *in, int length, int *out)
{
    int chan;
    int sample;
    int *tmp, *chanbase, *last, *cur;
    int samplepos;
    int insize = 0;
  
    cur  = raw->cur;
    last = raw->last;
    memset(last, 0, length * sizeof(int));
  
    for(chan = 0; chan < raw->chanc; chan++) 
    {
    
/* uncompress */
        insize += decompchan(raw, last, cur, length, &in[insize]);
/* mangle into MUX buffer */
    
        chanbase  = &out[raw->chanv[chan]];
        samplepos = 0;
        for(sample = 0; sample < length; sample++) 
        {
            chanbase[samplepos] = cur[sample];
            samplepos += raw->chanc;
        }
    
/* prepare for reading next channel */
        tmp = cur; cur = last; last = tmp;
    }  
    return insize;
}

