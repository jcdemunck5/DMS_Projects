#ifndef ANTDATA_H
#define ANTDATA_H

#include "FileName.h"
#include "String.h"

#include <time.h>

typedef struct 
{
  int       method;
  int       nbits;
  int       nexcbits;
  uint64_t  length;
  int       hst[33];
  int       *res;
} raw3res_t;

#define RAW3_METHODC 3

class DLL_IO URaw
{
public:
    URaw();
    URaw(int cc, const short *cv, uint64_t le);
    URaw(const URaw& R3);
    ~URaw();
    URaw&      operator=(const URaw& R3);

    ErrorType   GetError(void) const {if(this) return error; return U_ERROR;}

    short       chanc;              /* channel sequence */
    short       *chanv;
  
    raw3res_t   rc[RAW3_METHODC];    /* some working buffers */
    uint64_t    length;
    int         *last;
    int         *cur;

protected:
    void        DeleteAllMembers(ErrorType E);
    void        SetAllMembersDefault();

private:
    ErrorType   error;
};

#define TRG_CODE_LENGTH 8

typedef struct 
{
    uint64_t   sample;
    char       code[TRG_CODE_LENGTH + 2]; /* waste one byte to avoid odd length */
} trgentry_t;

class DLL_IO UANTTrigger
{
public:
    friend class UANTData;
    
    UANTTrigger();
    UANTTrigger(int Ntrig, bool mode32, FILE* fp);
    UANTTrigger(const UANTTrigger& AT);
    ~UANTTrigger();
    UANTTrigger&    operator=(const UANTTrigger& AT);

    ErrorType       GetError(void) const {if(this) return error; return U_ERROR;}
    ErrorType       SortTriggers(void) const;

protected:
    void            DeleteAllMembers(ErrorType E);
    void            SetAllMembersDefault();

private:
    int             c;
    trgentry_t      *v;
    int             cmax;
    ErrorType       error;
};


/* 
  export the RIFF chunk id's to applications which have to
  or want to handle them apart from the library
*/
#define FOURCC(a,b,c,d) (  ((unsigned int) a)       | ((unsigned int) b <<  8) | \
                           ((unsigned int) c) << 16 | ((unsigned int) d << 24)     )


/* the standard FOURCC tags and formats known by the library*/
#define FOURCC_RIFF FOURCC('R', 'I', 'F', 'F')
#define FOURCC_RF64 FOURCC('R', 'F', '6', '4')
#define FOURCC_LIST FOURCC('L', 'I', 'S', 'T')
#define FOURCC_CNT  FOURCC('C', 'N', 'T', ' ')
#define FOURCC_nsh  FOURCC('n', 's', 'h', ' ')
#define FOURCC_raw3 FOURCC('r', 'a', 'w', '3')
#define FOURCC_chan FOURCC('c', 'h', 'a', 'n')
#define FOURCC_data FOURCC('d', 'a', 't', 'a')
#define FOURCC_ep   FOURCC('e', 'p', ' ', ' ')
#define FOURCC_eeph FOURCC('e', 'e', 'p', 'h')
#define FOURCC_evt  FOURCC('e', 'v', 't', ' ')
#define FOURCC_refh FOURCC('r', 'e', 'f', 'h')
#define FOURCC_info FOURCC('i', 'n', 'f', 'o')
#define FOURCC_stdd FOURCC('s', 't', 'd', 'd')


/* channel specific informations */
typedef struct 
{
    char   lab[16];   /* electrode label                             */
    double iscale;    /* "internal" scaling gain * calibration       */
    double rscale;    /* "real world" scaling (value of 1 bit if iscale = 1.0) */
    char   runit[16]; /* unit String (uV, fT...)                     */
} EEGChanInfo;


class DLL_IO UChunk
{
public:
    UChunk(ErrorType E=U_OK);
    UChunk(const UChunk& C);
    UChunk(FILE* fp);
    ~UChunk();
    UChunk&             operator=(const UChunk& C);
    
    ErrorType           GetError() const  {if(this) return error; return U_ERROR;}
    uint32_t            GetID() const     {if(this) return id; return 0;}
    uint32_t            GetStart() const  {if(this) return start; return 0;}
    uint32_t            GetSize() const   {if(this) return size; return 0;}
    
    static unsigned int GetID(FILE *fp);
protected:
    void                SetAllMembersDefault();

private:
    ErrorType           error;
    uint32_t            id;
    uint32_t            start;
    uint32_t            size;
};

class DLL_IO UChunk64
{
public:
    UChunk64(ErrorType E=U_OK);
    UChunk64(const UChunk64& C);
    UChunk64(FILE* fp);
    ~UChunk64();
    UChunk64&             operator=(const UChunk64& C);
    
    ErrorType           GetError() const  {if(this) return error; return U_ERROR;}
    uint64_t            GetID() const     {if(this) return id; return 0;}
    uint64_t            GetStart() const  {if(this) return start; return 0;}
    uint64_t            GetSize() const   {if(this) return size; return 0;}

    static unsigned int GetID(FILE *fp);
protected:
    void                SetAllMembersDefault();

private:
    ErrorType           error;
    uint64_t            id;
    uint64_t            start;
    uint64_t            size;
};

enum CntType
{
    CNT_UNKNOWN,
    CNT_NS30,
    CNT_EEP20,
    CNT_RAW3,
    CNT_RAW64,
    CNT_AVR
}; 

class UMarkerArray;
class DLL_IO UANTData
{
public:
    UANTData();
    UANTData(const char* FileName);
    UANTData(const UANTData& ADAT);
    ~UANTData();
    UANTData&        operator=(const UANTData& ADAT);

    ErrorType        GetError() const {if(this) return error; return U_ERROR;}
    const UString&   GetProperties(UString Comment) const;

    double           GetSamplingRate(void) const;
    int              GetNChan(void) const;
    int              GetNTrial(void) const;
    int              GetNSampTrial(void) const;
    EEGChanInfo      GetChannelInfo(int ichan) const;
    double*          GetRawData(int SampFrom, int NSamp, int* ChanSel, int NSel);
    UMarkerArray*    GetMarkerArray(void) const;
    bool             IsFormat32bits(void)const;

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    static UString   Properties;
    ErrorType        error;            // General error flag

    CntType          mode;                  /* cnt type */    
    UFileName        ANTFname;
  
    double           period;                /* time axis scaling             */
    short            chanc;                 /* number of electrodes          */
    EEGChanInfo      *chanv;                /* electrode info table          */
    int              samplec;               /* number of samples             */
    int              averagedtriggersc;     /* number of averaged triggers of average data                     */
    int              totaltriggersc;        /* total number of triggers of average data (including rejections) */
    char             conditionlabel[25];    /* condition label: used trigger value or condition description    */
  
    UANTTrigger      trg;
    URaw             r3;
  
    UChunk           data;
    UChunk64         data64;
  
    short            *chanseq;              /* compressed channel sequence */
    int              epochc;                /* number of epochs in file */
    uint64_t         epochl;                /* epoch length in samples */
    uint64_t         *epochv;               /* relative file position of epochs */
    int              epvbuf;                /* file position buffer */
  
    int              bufepoch;              /* number of epoch in buffer      */
    char             writeflag;             /* access mode flag               */
    int              writepos;              /* working buffer write pointer   */
    int              readpos;               /*    "           read     "      */
    int              *buf;                  /* working buffer (1 epoch)       */
    char             *cbuf;                 /* compression buffer             */
  
    UString          hist;
  
    char             ns_cnttype; 
    int              ns_evtc;
    int              ns_evtpos;
    char             ns_evttype;
    int              ns_evtlen;

    ErrorType        OpenAsRaw3(FILE *fpANT);
    ErrorType        OpenAsRaw64(FILE *fpANT);
    UChunk           ReadChunk(FILE *fpANT, unsigned int ID, const UChunk& parent, bool TestStartList);
    UChunk64         ReadChunk64(FILE *fpANT, unsigned int ID, const UChunk64& parent, bool TestStartList);

    ErrorType        ReadEpoch(FILE *fpANT, int iep);
    ErrorType        SetFileOffset(FILE *fpANT, int sample);
    ErrorType        ReadSamples(FILE *fpANT, int *muxbuf, int Nsamp);
};

#endif  // ANTDATA_H
