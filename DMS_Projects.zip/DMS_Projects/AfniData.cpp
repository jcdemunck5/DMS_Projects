/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read scans in Afni format (.HEAD, .BRIK)                           */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                   */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    01-02-01   Creation
  JdM    05-02-01   Bug fix in setting the correct orientation
JdM/IB   03-04-01   GetField(): Add options to scale the pixels
                    Bug Fix in GetField(). Putting image upside down
JdM/IB   05-04-01   Implement compatibility with saggital and axial scans
  IB     06-04-01   Bug Fix in GetField(), in case of axial scans.
  JdM    12-12-01   Bug Fix in byte swapping in case original data is INTEL byte order
  JdM    12-02-02   Apply coordinate shift present in afni header.
  JdM    19-02-02   Extensively tested and verified coordinate shift and orientation
                    for the case of Sonata scans. For Vision results might be wrong.
  JdM    04-03-02   Extensively tested and verified coordinate shift and orientation
                    for the case of Vision scans.
  JdM    06-03-02   Further simplifications of the code.
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    21-01-03   Added pixel scaling
  JdM    02-09-03   Reading Brik types in case of multiple briks
  JdM    03-03-04   Added GetTime(), returning default sampling time times brik-number (3.0 s)
  JdM    23-01-06   Switched off MS C++ language extensions.
  JdM    04-01-07   Adapted include file to new directory structure
  JdM    10-11-07   Bug Fix. UFileName constructor: min(Ntype,MAXNBRIK) added min
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    01-03-18   GetProperties(). Use const char* argument
*/

#include<string.h>
#include<stdlib.h>

#include"AfniData.h"
#include"AnalyzeLine.h"
#include"PatTree.h"

/* Inititalize static const parameters. */
const int UAfniData::MAXPROPERTIES = 1000;
#define MAXLINE 2000


static const double DefaultRepTime = 3.0; // s

UAfniData::UAfniData(UFileName FileName)
{
    error          = U_ERROR;
    Properties     = NULL;

    History        = NULL;
    DateTime       = NULL;
    dimensions[0]  = dimensions[1]  = dimensions[2]  = 0;
    PixelSize[0]   = PixelSize[1]   = PixelSize[2]   = 0.;

    Orient[0] = Orient[1] = Orient[2]=-1;

    for(int k=0; k<MAXNBRIK; k++)
    {
        BT[k]         = U_UNKNOWN;
        PixelScale[k] = 1.;
    }
    NBrik        = 0;
    Labels       = NULL;
    IntelData    = false;

    DataType  DatTyp = U_DAT_UNKNOWN;
    int       Scene  = -1;
    memset(DataDescriptor, 0, sizeof(DataDescriptor));

    HEADFileName = FileName; HEADFileName.ReplaceExtension(".HEAD");
    BRIKFileName = FileName; BRIKFileName.ReplaceExtension(".BRIK");
    Properties   = new char[MAXPROPERTIES];
    if(!Properties)
    {
        delete[] Properties;   Properties   = NULL;
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Memory allocation.\n");
        return;
    }

    FILE* fp = fopen(HEADFileName, "rt",true);
    if(fp==NULL)
    {
        delete[] Properties;   Properties   = NULL;
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Cannot open header file %s.\n",HEADFileName.GetFullFileName());
        return;
    }

    char line[MAXLINE];
    while(GetLine(line,MAXLINE,fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine()==true) continue;
        if(AA.IsIdentifierIs("name")==false) continue;

        const char* str = AA.GetNextString(20);

        if(!strcmp(str, "DATASET_RANK"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in DATASET_RANK section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
////            int Three = AA.GetNextInt();
            NBrik     = AA.GetNextInt();
            if(NBrik>MAXNBRIK)
                CI.AddToLog("WARNING: UAfniData::UAfniData(). The number of briks (%d) is larger than %d \n",NBrik, MAXNBRIK);

            continue;
        }

        if(!strcmp(str, "TYPESTRING"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==true)
            {
                int nbytes = AA.GetNextInt();
                nbytes     = MIN(nbytes, MAXLINE);

                char TypeString[MAXLINE];
                memset(TypeString, 0, nbytes);
                GetLine(TypeString,nbytes,fp);
                TypeString[nbytes]=0;
                if(!strcmp(TypeString+nbytes-5,"_ANAT")) DatTyp = U_DAT_ANAT;
                if(!strcmp(TypeString+nbytes-5,"_FUNC")) DatTyp = U_DAT_FUNC;
            }
            else
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in TYPESTRING section.\n");
                return;
            }
            continue;
        }

        if(!strcmp(str, "SCENE_DATA"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in SCENE_DATA section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
////            int dum1 = AA.GetNextInt();
            Scene = AA.GetNextInt();
////            int dum2 = AA.GetNextInt(); // 0, 1, 2, or 4, acc. to TYPESTRING
            continue;
        }

        if(!strcmp(str, "HISTORY_NOTE"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==true)
            {
                int nbytes = AA.GetNextInt();
                nbytes     = MIN(nbytes, MAXLINE);
                History    = new char[nbytes+1];
                if(History)
                {
                    memset(History, 0, nbytes+1);
                    GetLine(History,nbytes,fp);
                }
                else
                {
                    CI.AddToLog("ERROR: UAfniData::UAfniData(). Memory allocation error. nbytes = %d .\n",nbytes);
                    return;
                }
            }
            else
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in HISTORY_NOTE section.\n");
                return;
            }
            continue;
        }

        if(!strcmp(str, "IDCODE_DATE"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==true)
            {
                int nbytes = AA.GetNextInt();
                nbytes     = MIN(nbytes, MAXLINE);
                DateTime   = new char[nbytes+1];
                if(DateTime)
                {
                    memset(DateTime, 0, nbytes+1);
                    GetLine(DateTime, nbytes, fp);
                }
                else
                {
                    CI.AddToLog("ERROR: UAfniData::UAfniData(). Memory allocation error. nbytes = %d .\n",nbytes);
                    return;
                }
            }
            else
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in IDCODE_DATE section.\n");
                return;
            }
            continue;
        }

        if(!strcmp(str, "BRICK_LABS"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==true)
            {
                int nbytes = AA.GetNextInt();
                nbytes     = MIN(nbytes, MAXLINE);
                Labels     = new char[nbytes];
                if(Labels)
                {
                    memset(Labels, 0, nbytes);
                    GetLine(Labels, nbytes,fp);
                }
                else
                {
                    CI.AddToLog("ERROR: UAfniData::UAfniData(). Memory allocation error. nbytes = %d .\n",nbytes);
                    return;
                }
            }
            else
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in BRICK_LABS section.\n");
                return;
            }
            continue;
        }

        if(!strcmp(str, "ORIENT_SPECIFIC"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in ORIENT_SPECIFIC section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            Orient[2] = AA.GetNextInt();
            Orient[0] = AA.GetNextInt();
            Orient[1] = AA.GetNextInt();
            continue;
        }

        if(!strcmp(str, "DATASET_DIMENSIONS"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in DATASET_DIMENSIONS section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            dimensions[2] = AA.GetNextInt();
            dimensions[0] = AA.GetNextInt();
            dimensions[1] = AA.GetNextInt();
            continue;
        }

        if(!strcmp(str, "ORIGIN"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in ORIGIN section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            FirstPoint.Setz( AA.GetNextDouble()/10 );
            FirstPoint.Setx( AA.GetNextDouble()/10 );
            FirstPoint.Sety( AA.GetNextDouble()/10 );
            continue;
        }

        if(!strcmp(str, "DELTA"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in DELTA section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            PixelSize[2] = AA.GetNextDouble()/10;
            PixelSize[0] = AA.GetNextDouble()/10;
            PixelSize[1] = AA.GetNextDouble()/10;
            continue;
        }

        if(!strcmp(str, "BRICK_TYPES"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in BRICK_TYPES section.\n");
                return;
            }
            int Ntype = AA.GetNextInt();
            {
                GetLine(line,MAXLINE,fp);
                UAnalyzeLine AA(line);
                for(int k=0; k<MIN(Ntype,MAXNBRIK); k++)
                {
                    int BrikTypeInt = AA.GetNextInt();
                    switch(BrikTypeInt)
                    {
                    case 0: BT[k] = U_BYTE;    break;
                    case 1: BT[k] = U_SHORT;   break;
                    case 2: BT[k] = U_INT;     break;
                    case 3: BT[k] = U_FLOAT;   break;
                    case 4: BT[k] = U_DOUBLE;  break;
                    case 5: BT[k] = U_COMPLEX; break;
                    default:
                        CI.AddToLog("ERROR: UAfniData::UAfniData(). Unknown type: %d  .\n",BrikTypeInt);
                        return;
                    }
                    if(!((k+1)%5) && k+1<Ntype)
                    {
                        GetLine(line,MAXLINE,fp);
                        AA = UAnalyzeLine(line);
                    }
                }
            }
            continue;
        }

        if(!strcmp(str, "BRICK_FLOAT_FACS"))
        {
            GetLine(line,MAXLINE,fp);
            AA = UAnalyzeLine(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in BRICK_FLOAT_FACS section.\n");
                return;
            }
            int Nscale = AA.GetNextInt();
            {
                GetLine(line,MAXLINE,fp);
                UAnalyzeLine AA(line);
                for(int k=0; k<MIN(Nscale,MAXNBRIK); k++)
                {
                    double factor = AA.GetNextDouble();
                    if(factor>0) PixelScale[k] = factor;
                    else         PixelScale[k] = 1.;
                }
            }
            continue;
        }

        if(!strcmp(str, "BYTEORDER_STRING"))
        {
            GetLine(line,MAXLINE,fp);
            UAnalyzeLine AA(line);
            if(AA.IsIdentifierIs("count")==false)
            {
                CI.AddToLog("ERROR: UAfniData::UAfniData(). 'count = ' expected in BYTEORDER_STRING section.\n");
                return;
            }
            GetLine(line,MAXLINE,fp);
            AA              = UAnalyzeLine(line);
            const char* str = AA.GetNextString(20);
            if(!strncmp(str+1,"MSB_FIRST",sizeof("MSB_FIRST")-1))
            {
                IntelData = false;
            }
            else
            {
                IntelData = true;
            }
            continue;
        }
    }
    fclose(fp);

/* Cheque parameters */
    SetDataDescriptor(Scene, DatTyp);
    if(!dimensions[0] || !dimensions[1] || !dimensions[2])
    {
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Illegal image dimensions: (%d,%d,%d)  .\n",dimensions[0],dimensions[1],dimensions[2]);
        return;
    }
    if(PixelSize[0]==0. || PixelSize[1]==0. || PixelSize[2]==0.)
    {
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Illegal pixel size: (%f,%f,%f)  .\n",PixelSize[0],PixelSize[1],PixelSize[2]);
        return;
    }
    if(NBrik<=0 || NBrik>=MAXNBRIK)
    {
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Illegal number of briks : %d  .\n",NBrik);
        return;
    }
    for(int k=0; k<NBrik; k++)
        if(BT[k]!=U_BYTE && BT[k]!=U_SHORT && BT[k]!=U_INT)
        {
            CI.AddToLog("ERROR: UAfniData::UAfniData(). Data format in brik %d not (yet) supported: %d  .\n",k,BT[k]);
            return;
        }

    if(Orient[0]<0 || Orient[1]<0 || Orient[2]<0)
    {
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Orientation parameters out of range: %d, %d %d. \n",Orient[0],Orient[1],Orient[2]);
        return;
    }

    Orientation = GetOrientation(Orient);
    if(Orientation == U_ORI_UNKNOWN)
    {
        CI.AddToLog("ERROR: UAfniData::UAfniData(). Scan orientation not yet implemented. %d %d %d \n", Orient[0],Orient[1],Orient[2]);
        return;
    }

         if(Orient[0]==3 && Orient[1]==4 && Orient[2]==0) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Axial (3,4,0). \n");
    else if(Orient[0]==3 && Orient[1]==5 && Orient[2]==0) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Axial (3,5,0).\n");
    else if(Orient[0]==5 && Orient[1]==2 && Orient[2]==0) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Coronal (5,2,0).\n");
    else if(Orient[0]==5 && Orient[1]==3 && Orient[2]==0) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Coronal (5,3,0). \n");
    else if(Orient[0]==5 && Orient[1]==0 && Orient[2]==3) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Sagital (5,0,3). \n");
    else if(Orient[0]==5 && Orient[1]==1 && Orient[2]==3) CI.AddToLog("Note: UAfniData::UAfniData(). Orientation is Sagital (5,1,3). \n");
    else
        CI.AddToLog("WARNING: UAfniData::UAfniData(). Orientation (%d,%d,%d). NOT TESTED. \n",Orient[0],Orient[1],Orient[2]);

    error = U_OK;
}

UAfniData::~UAfniData()
{
    delete[] Properties;

    delete[] History;
    delete[] DateTime;
    delete[] Labels;
}


UField* UAfniData::GetField(int iBrik, bool WordOn, int pixmin, int pixmax, UField::DatConvertType DatCon)
{
    if(iBrik<0 || iBrik>=NBrik)
    {
        CI.AddToLog("ERROR: UAfniData::GetField(). Requested brik number out of range: %d\n",iBrik);
        return NULL;
    }

    int nx = dimensions[0];
    int ny = dimensions[1];
    int nz = dimensions[2];

    UVector3 MinF = FirstPoint;
    UVector3 MaxF = MinF       + UVector3(PixelSize[0]*(nx-1), PixelSize[1]*(ny-1), PixelSize[2]*(nz-1));


    UField *F = NULL;
    switch(BT[iBrik])
    {
    case U_BYTE:
        F = new UField(MinF, MaxF, dimensions, UField::U_BYTE);
        break;
    case U_SHORT:
        F = new UField(MinF, MaxF, dimensions, UField::U_SHORT);
        break;
    case U_INT:
        F = new UField(MinF, MaxF, dimensions, UField::U_INTEGER);
        break;
        default: break;
    }
    if(F==NULL || F->GetError()!=U_OK)
    {
        delete F;
        CI.AddToLog("ERROR: UAfniData::GetField(). Cannot create requested field.\n");
        return NULL;
    }

    FILE* fp = fopen(BRIKFileName,"rb",true);
    if(fp==NULL)
    {
        delete F;
        CI.AddToLog("ERROR: UAfniData::GetField(). Cannot open Brik file : %s .\n",BRIKFileName.GetFullFileName());
        return NULL;
    }

    int offset = 0;
    for(int k=0; k<iBrik; k++)
    {
        switch(BT[k])
        {
        case U_BYTE:  offset += 1; break;
        case U_SHORT: offset += 2; break;
        case U_INT:   offset += 4; break;
        default:                   break;
        }
    }
    offset *= nx*ny*nz;
    fseek(fp, offset, SEEK_SET);

    int Size   = 0;
    void* data = NULL;
    switch(BT[iBrik])
    {
    case U_BYTE:   Size = 1; data = F->GetBdata(); break;
    case U_SHORT:  Size = 2; data = F->GetSdata(); break;
    case U_INT:    Size = 4; data = F->GetIdata(); break;
    default:                                       break;
    }
    if(Size==0 || data==NULL)
    {
        delete F;
        CI.AddToLog("ERROR: UAfniData::GetField(). Invalid data type in Brik %d.\n",iBrik);
        return NULL;
    }

    int Dx   = 1 ;
    int Minx = 0 ;
    int Dy   = 1 ;
    int Miny = 0 ;
    int Dz   = 1 ;
    int Minz = 0 ;


    switch(Orientation)
    {
    case U_ORI_AXIAL:  // Tested : 3,4,0 and 3,5,0
        if(Orient[1]==4)
        {
            F->MirrorCoordinates(false, true , true );
            F->ReverseCoords    (false, false, false);
//            F->ShiftCoords(-UVector3(0.,0.,0.));
        }
        if(Orient[1]==5)
        {
            F->MirrorCoordinates(false, true , false);
            F->ReverseCoords    (false, false, true );
//            F->ShiftCoords(-UVector3(0., 0., PixelSize[2]));
        }
        break;
    case U_ORI_CORONAL:  // Tested : 5,2,0 and 5,3,0
        if(Orient[1]==2)
        {
            F->MirrorCoordinates(true , true , false);
            F->ReverseCoords    (false, false, true );
//            F->ShiftCoords(-UVector3(0., 0., PixelSize[2]));
        }
        if(Orient[1]==3)
        {
            F->MirrorCoordinates(true , true , true );
            F->ReverseCoords    (false, false, false);
//            F->ShiftCoords(-UVector3(0.,0.,0.));
        }
        break;
    case U_ORI_SAGITAL:  // Tested : 5,0,3 and 5,1,3
        if(Orient[1]==0)
        {
            F->MirrorCoordinates(true , true , true );
            F->ReverseCoords    (false, true , false);
//            F->ShiftCoords(-UVector3(0., PixelSize[1], 0.));
        }
        if(Orient[1]==1)
        {
            F->MirrorCoordinates(true , true , false);
            F->ReverseCoords    (false, true , true );
//            F->ShiftCoords(-UVector3(0., PixelSize[1], PixelSize[2]));
        }
        break;
    default:
        delete F;
        fclose(fp);
        CI.AddToLog("ERROR: UAfniData::GetField(). Unknown scan orientation (%d). \n",Orientation);
        return NULL;
    }
    for(int y=Miny; -1<y && y<ny; y+=Dy)
        for(int x=Minx; -1<x && x<nx; x+=Dx)
            for(int z=Minz; -1<z && z<nz; z+=Dz)
                fread(((char*)data)+(nx*(ny*z+y)+x)*Size, Size, 1, fp);

    fclose(fp);

    if(BT[iBrik]==U_SHORT) SwapArray((short*)data, nx*ny*nz, IntelData);
    if(BT[iBrik]==U_INT  ) SwapArray(  (int*)data, nx*ny*nz, IntelData);


    if(WordOn==false)
        F->ConvertDataToByte(DatCon, pixmin, pixmax);

    return F;
}

const char*  UAfniData::GetBrikLabel(int iBrik) const
{
    static char DefaultLab[20];
    memset(DefaultLab,0,sizeof(DefaultLab));
    if(Labels)
    {
        int ilab = 0;
        int ichr = 0;
        for(unsigned int k=0; k<strlen(Labels)-1;k++)
        {
            if(Labels[k]=='~')
            {
                ilab++;
                continue;
            }
            if(iBrik==ilab)
            {
                if(Labels[k]=='\'' || Labels[k]=='�') continue;
                if(Labels[k]==' ')  DefaultLab[ichr] = '_';
                else                DefaultLab[ichr] = Labels[k];
                ichr++;
                if(ichr>=sizeof(DefaultLab)) return DefaultLab;
            }
            if(iBrik<ilab) break;
        }
        if(ichr) return DefaultLab;
    }
    sprintf(DefaultLab,"BrikNo%d",iBrik);
    return DefaultLab;
}

double UAfniData::GetPixelScale(int iBrik) const
{
    if(iBrik<0 || iBrik>=NBrik)
    {
        CI.AddToLog("ERROR: UAfniData::GetPixelScale(). Argument out of range: iBrik=%d\n", iBrik);
        return 0.;
    }
    return PixelScale[iBrik];
}

double UAfniData::GetTime(int iBrik) const
{
    if(iBrik<0 || iBrik>=NBrik)
    {
        CI.AddToLog("ERROR: UAfniData::GetTime(). Argument out of range: iBrik=%d\n", iBrik);
        return MIN(MAX(iBrik, 0), NBrik-1) * DefaultRepTime;
    }
    return iBrik * DefaultRepTime;
}

UEuler UAfniData::GetEuler(void)  const
{
    return UPatTree::GetToWld(Orientation);
}

void UAfniData::SetDataDescriptor(int Scene,  DataType DatTyp)
{
    memset(DataDescriptor, 0, sizeof(DataDescriptor));
    strcpy(DataDescriptor, "Unknown");
    if(DatTyp==U_DAT_FUNC)
    {
        switch(Scene)
        {
        case  0: strcpy(DataDescriptor, "l value"); break;
        case  1: strcpy(DataDescriptor, "obsolete"); break;
        case  2: strcpy(DataDescriptor, "fico: correlation"); break;
        case  3: strcpy(DataDescriptor, "fitt: t-statistic"); break;
        case  4: strcpy(DataDescriptor, "fift: F-statistic"); break;
        case  5: strcpy(DataDescriptor, "fizt: z-score"); break;
        case  6: strcpy(DataDescriptor, "fict: Chi squared"); break;
        case  7: strcpy(DataDescriptor, "fibt: Beta stat"); break;
        case  8: strcpy(DataDescriptor, "fibn: Binomial"); break;
        case  9: strcpy(DataDescriptor, "figt: Gamma"); break;
        case 10: strcpy(DataDescriptor, "fipt: Poisson"); break;
        case 11: strcpy(DataDescriptor, "fbuc: bucket"); break;
        }
    }
    else if(DatTyp==U_DAT_ANAT)
    {
        switch(Scene)
        {
        case  0: strcpy(DataDescriptor, "SPGR"); break;
        case  1: strcpy(DataDescriptor, "FSE"); break;
        case  2: strcpy(DataDescriptor, "EPI"); break;
        case  3: strcpy(DataDescriptor, "MRAN"); break;
        case  4: strcpy(DataDescriptor, "CT"); break;
        case  5: strcpy(DataDescriptor, "SPECT"); break;
        case  6: strcpy(DataDescriptor, "PET"); break;
        case  7: strcpy(DataDescriptor, "MRA"); break;
        case  8: strcpy(DataDescriptor, "BMAP"); break;
        case  9: strcpy(DataDescriptor, "DIFF"); break;
        case 10: strcpy(DataDescriptor, "OMRI"); break;
        case 11: strcpy(DataDescriptor, "BUCK"); break;
        }
    }
}

const char* UAfniData::GetProperties(const char* Comment) const
{
    char Begin[8]  = {0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,7);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties,0,MAXPROPERTIES);

    int nc = 0;
    if(error!=U_OK)
    {
        if(Comment) nc+=sprintf(Properties,"%s",Begin);
        nc+=sprintf(Properties+nc," ERROR in UAfniData-object");
        return Properties;
    }
    if(History)  nc += sprintf(Properties+nc,"%sHistory = %s%c",Begin,History,End);
    if(DateTime) nc += sprintf(Properties+nc,"%sDateTime = %s%c",Begin,DateTime,End);

    switch(Orientation)
    {
    case U_ORI_AXIAL:   nc += sprintf(Properties+nc,"%s Orientation = Axial %c",Begin,End); break;
    case U_ORI_CORONAL: nc += sprintf(Properties+nc,"%s Orientation = Coronal %c",Begin,End); break;
    case U_ORI_SAGITAL: nc += sprintf(Properties+nc,"%s Orientation = Sagital %c",Begin,End); break;
    default:            nc += sprintf(Properties+nc,"%s Orientation = UNKNOWN %c",Begin,End); break;
    }

    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: UAfniData::GetProperties(). Array overflow: nc=%d .\n",nc);

    return Properties;
}

OrientType UAfniData::GetOrientation(const int* ori) const
/*
    Determine the scan oriantation, based on the paramters Ori[]
 */
{
    if(ori==NULL) return U_ORI_UNKNOWN;

    int maindir = ori[1]/2;
    switch(maindir)
    {
    case 0:
        if(ori[0]/2 == 2 && ori[2]/2 == 1) return U_ORI_SAGITAL;
        return U_ORI_UNKNOWN;

    case 1:
        if(ori[0]/2 == 2 && ori[2]/2 == 0) return U_ORI_CORONAL;
        return U_ORI_UNKNOWN;

    case 2:
        if(ori[0]/2 == 1 && ori[2]/2 == 0) return U_ORI_AXIAL;
        return U_ORI_UNKNOWN;
    }
    return U_ORI_UNKNOWN;
}

/****** Old Tested Code:

    int Dx   = 1 ;
    int Minx = 0 ;
    int Dy   = 1 ;
    int Miny = 0 ;
    int Dz   = 1 ;
    int Minz = 0 ;
    if(Orient[0]==3 && Orient[1]==4 && Orient[2]==0) // Axial (Sonata)
    {
        Dx   =  1 ;
        Minx =  0 ;
        Dy   = -1 ;
        Miny =  ny-1 ;
        Dz   =  1 ;
        Minz =  0 ;
    }
    else if(Orient[0]==5 && Orient[1]==2 && Orient[2]==0) // Coronal (Sonata)1
    {
        Dx   = 1 ;
        Minx = 0 ;
        Dy   = 1 ;
        Miny = 0 ;
        Dz   = 1 ;
        Minz = 0 ;
    }
    else if(Orient[0]==5 && Orient[1]==3 && Orient[2]==0) // Coronal (Sonata)2
    {
        Dx   = 1 ;
        Minx = 0 ;
        Dy   = -1 ;
        Miny = ny-1 ;
        Dz   = 1 ;
        Minz = 0 ;
    }
    else if(Orient[0]==3 && Orient[1]==5 && Orient[2]==0) // Axial (Vision)
    {
        Dx   =  1 ;
        Minx =  0 ;
        Dy   =  1 ;
        Miny =  0 ;
        Dz   =  1 ;
        Minz =  0 ;
    }
    else if(Orient[0]==5 && Orient[1]==0 && Orient[2]==3) // Sagital (Vision)
    {
        Dx   = 1 ;
        Minx = 0 ;
        Dy   = 1 ;
        Miny = 0 ;
        Dz   = 1 ;
        Minz = 0 ;
    }

*****/
