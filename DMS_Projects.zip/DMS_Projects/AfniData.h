#ifndef _AFNIDATA_INCLUDED
#define _AFNIDATA_INCLUDED
/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Field.h"
#include "FileName.h"

#define MAXNBRIK 2000

class DLL_IO UAfniData
{
public:
    UAfniData(UFileName FileName);
    ~UAfniData();  

    ErrorType          GetError(void)  const {return error;}

    UField*            GetField(int iBrik, bool WordOn, int pixmin, int pixmax, UField::DatConvertType DatCon);
    const char*        GetBrikLabel(int iBrik) const;
    double             GetPixelScale(int iBrik) const;
    double             GetTime(int iBrik) const;
    UEuler             GetEuler(void)  const;
    OrientType         GetOrientation(void) const {return Orientation;}

    const char*        GetProperties(const char* Comment) const;
    int                GetNBrik(void) const {return NBrik;}
    int                GetNscans(void) const {return GetNBrik();}
    const char* const  GetScanDescriptor(int iscan) const {return GetBrikLabel(iscan);}
    const char* const  GetDataDescriptor() const {return DataDescriptor;}
    const char* const  GetHeaderFileName(void) const {return HEADFileName.GetFullFileName();}

private:
    ErrorType          error;       // General error flag
    static const int   MAXPROPERTIES;
    char*              Properties;
    enum BrikType{U_UNKNOWN, U_BYTE, U_SHORT, U_INT, U_FLOAT, U_DOUBLE, U_COMPLEX};
    enum DataType{U_DAT_UNKNOWN, U_DAT_ANAT, U_DAT_FUNC};

    BrikType           BT[MAXNBRIK];
    double             PixelScale[MAXNBRIK];
    UFileName          HEADFileName;
    UFileName          BRIKFileName;

    char*              History;
    char*              DateTime;
    int                dimensions[3];
    double             PixelSize[3];
    int                NBrik;
    char*              Labels;
    bool               IntelData;
    int                Orient[3];
    UVector3           FirstPoint;
    OrientType         Orientation;
    OrientType         GetOrientation(const int* ori) const;
    char               DataDescriptor[32];
    void               SetDataDescriptor(int Scene,  DataType DatTyp);
};

#endif //_AFNIDATA_INCLUDED
