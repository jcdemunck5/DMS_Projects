/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read scans in Analyze format                                       */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
 
  Who    When       What
  JdM    21-02-00   Creation
  JdM    04-03-00   Bug fix: scan orientation (read x in reverse order)
  JdM    03-04-00   Bug fix: scan z-coordinate reversed
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    28-01-01   Several bug-fixes, for the case of short and int data
  JdM    05-02-01   Add the option to apply an axial rotation. This has to be applied for old scans.
  JdM    19-03-01   Compatibility with UFileName() object
  JdM    18-07-01   Added WriteAnalyze()
  JdM    02-10-01   Make UEuler rotation and scan pixel order compatible with UPatTree::GetToWld()
  JdM    12-12-01   Use global SwapArray() instead of (old) UField::SwapArr()
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    20-03-03   Read header part in constructor
  JdM    13-04-04   Treat the case that data are not byte swapped
  JdM    18-04-04   Read header elemene by element, to avoid byte alignment problems
  JdM    10-07-04   Bug fix: Once again, reverse x-direction (for axial scans this corresponds to AP)
                    Remove Rotation parameter, swap both z-dir and z-coords
                    Added DT_FLOAT and DT_DOUBLE, tested orientation by comp. to MRIcro
  JdM    20-09-04   Allow for multiple sub-scans
  JdM    28-02-05   Allow for multiple numbered file names.
  JdM    23-01-06   Switched off MS C++ language extensions.
  JdM    11-08-06   UAnalyzeData(), GetField(). Generalized the algorithm to find numbered files (allow missing zeroes in numbered file name).
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    10-04-09   Avoid use of non-standard strnicmp()
  JdM    15-09-09   Read nifty files. Use UString in GetProperties()
  JdM    08-04-10   Recognize other scan orientations
  JdM    03-08-10   Added GetScanOrientation(). Read Coronal scans correctly (apart from possible LR-flip)
                    Sagital scans still not tested.        
  JdM    11-08-10   UFileName constuctor: skip test of negative numbers
  JdM    05-06-11   BUG FIX: GetField(). Force consistent pixel size (constent with writing and nominal value)
  JdM    18-09-13   Bug Fix. Read Sagital scans correctly (apart from possible LR-flip)
  JdM    13-10-13   Major Update. Thouroughly implement distiction between Nifty and Analyze formats
  JdM    14-10-13   Made WriteAnalyze() static
  JdM    15-10-13   Split off UNiftiData
*/

#include<string.h>
#include<stdlib.h>

#include"AnalyzeData.h"
#include"PatTree.h"

/* Acceptable values for hdr.dime.datatype */
#define DT_UNKNOWN              0
#define DT_BINARY               1
#define DT_UNSIGNED_CHAR        2
#define DT_SIGNED_SHORT         4
#define DT_SIGNED_INT           8
#define DT_FLOAT               16
#define DT_COMPLEX             32
#define DT_DOUBLE              64
#define DT_RGB                128


/* Inititalize static const parameters. */
UString UAnalyzeData::Properties = UString();

UAnalyzeData::UAnalyzeData(UFileName FileName)
{
    NumFiles       =   0;
    FirstFileNum   =  -1;
    NDigit         =   0;

    error          = U_ERROR;       // General error flag
    IntelByteOrder = false;

    HeaderFileName = UFileName(FileName);       HeaderFileName.ReplaceExtension(".hdr");
    ImageFileName  = UFileName(FileName);       ImageFileName .ReplaceExtension(".img");
    
/* Read header*/
    if(HeaderFileName.DoesFileExist()==false)
    {
        CI.AddToLog("ERROR: UAnalyzeData::UAnalyzeData(). Header file does not exist: %s.\n", HeaderFileName.GetFullFileName());
        return;
    }
    FILE*  fp = fopen(HeaderFileName,"rb",true);
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UAnalyzeData::UAnalyzeData(). Header file cannot be opened: %s.\n", HeaderFileName.GetFullFileName());
        return;
    }
    

    fread(&HeadKey.sizeof_hdr,        4, 1, fp);
    fread(&HeadKey.data_type,        10, 1, fp);
    fread(&HeadKey.db_name,          18, 1, fp);
    fread(&HeadKey.extents,           4, 1, fp);
    fread(&HeadKey.session_error,     2, 1, fp);
    fread(&HeadKey.regular,           1, 1, fp);
    fread(&HeadKey.hkey_un0,          1, 1, fp);

    if(HeadKey.sizeof_hdr<0 || HeadKey.sizeof_hdr>2000) IntelByteOrder = false;
    else                                                IntelByteOrder = true;

    fread(&HeadDimAna.dim,         2, 8, fp);
    fread(&HeadDimAna.vox_units,   1, 4, fp);
    fread(&HeadDimAna.cal_units,   1, 8, fp);
    fread(&HeadDimAna.unused1,     2, 1, fp);
    fread(&HeadDimAna.datatype,    2, 1, fp);
    fread(&HeadDimAna.bitpix,      2, 1, fp);
    fread(&HeadDimAna.dim_un0,     2, 1, fp);
    fread(&HeadDimAna.pixdim,      4, 8, fp);
    fread(&HeadDimAna.vox_offset,  4, 1, fp);
    fread(&HeadDimAna.funused1,    4, 1, fp);
    fread(&HeadDimAna.funused2,    4, 1, fp);
    fread(&HeadDimAna.funused3,    4, 1, fp);
    fread(&HeadDimAna.cal_max,     4, 1, fp);
    fread(&HeadDimAna.cal_min,     4, 1, fp);
    fread(&HeadDimAna.compressed,  4, 1, fp);
    fread(&HeadDimAna.verified,    4, 1, fp);
    fread(&HeadDimAna.glmax,       4, 1, fp);
    fread(&HeadDimAna.glmin,       4, 1, fp);

    fread(&HeadAna.descrip,       80, 1, fp);
    fread(&HeadAna.aux_file,      24, 1, fp);
    fread(&HeadAna.orient,         1, 1, fp);
    fread(&HeadAna.originator,    10, 1, fp);
    fread(&HeadAna.generated,     10, 1, fp);
    fread(&HeadAna.scannum,       10, 1, fp);
    fread(&HeadAna.patient_id,    10, 1, fp);
    fread(&HeadAna.exp_date  ,    10, 1, fp);
    fread(&HeadAna.exp_time  ,    10, 1, fp);
    fread(&HeadAna.hist_un0  ,     3, 1, fp);
    fread(&HeadAna.views,          4, 1, fp);
    fread(&HeadAna.vols_added,     4, 1, fp);
    fread(&HeadAna.start_field,    4, 1, fp);
    fread(&HeadAna.field_skip,     4, 1, fp);
    fread(&HeadAna.omax,           4, 1, fp);
    fread(&HeadAna.omin,           4, 1, fp);
    fread(&HeadAna.smax,           4, 1, fp);
    fread(&HeadAna.smin,           4, 1, fp);
    fclose(fp);

    SwapHeader(&HeadKey, &HeadDimAna, &HeadAna, IntelByteOrder);

    error = U_OK;
    int test = HeaderFileName.GetNumberBeforeExtension(-1);
    if(test<0 || HeadDimAna.dim[4]>1) return;


/* Read numbered files */
    NDigit       = HeaderFileName.GetNDigitBeforeExtension();
    NumFiles     = 1;
    int start    = test;
    FirstFileNum = test;
    while(test>0)   // Look Backwards
    {
        UFileName Ftest = HeaderFileName;
        test--;
        if(Ftest.ReplaceNumberBeforeExtension(test,-1)!=U_OK)
        {
            error          =  U_OK;
            NumFiles       =  0;
            FirstFileNum   = -1;
            return;
        }
        if(DoesFileExist(Ftest)==true) 
        {
            NumFiles++;
            FirstFileNum = test;
        }
        else
        {
            Ftest = HeaderFileName;
            if(Ftest.ReplaceNumberBeforeExtension(test,0)!=U_OK)
            {
                error          =  U_OK;
                NumFiles       =  0;
                FirstFileNum   = -1;
                return;
            }
            if(DoesFileExist(Ftest)==true) 
            {
                NumFiles++;
                FirstFileNum = test;
                NDigit       = 0;
            }
            else
            {
                break;            
            }                
            break;            
        }
    }
    for(test=start+1;;NumFiles++, test++)
    {
        UFileName Ftest = HeaderFileName;
        if(Ftest.ReplaceNumberBeforeExtension(test,-1)!=U_OK)
        {
            error          =  U_OK;
            NumFiles       =  0;
            FirstFileNum   = -1;
            return;
        }
        if(DoesFileExist(Ftest)==true) continue;
        
        Ftest = HeaderFileName;
        if(Ftest.ReplaceNumberBeforeExtension(test,0)!=U_OK)
        {
            error          =  U_OK;
            NumFiles       =  0;
            FirstFileNum   = -1;
            NDigit         = 0;
            return;
        }
        if(DoesFileExist(Ftest)==false) break;
    }
}

UAnalyzeData::~UAnalyzeData()
{
}

int UAnalyzeData::GetNscan(void) const
{
    if(NumFiles>0 && FirstFileNum>=0) return NumFiles;

    if(HeadDimAna.dim[4]<=0 ) return 1;
    return HeadDimAna.dim[4];
}

double UAnalyzeData::GetSampleTime(void) const
{
    if(NumFiles>0 && FirstFileNum>=0) return 3.0;

    if(HeadDimAna.pixdim[4]>0.)  return HeadDimAna.pixdim[4];
    return 3.51;
}

UDateTime UAnalyzeData::GetScanDate(void) const
{
    char DatString[12];
    memset(DatString, 0, sizeof(DatString));
    memcpy(DatString, HeadAna.exp_date, 10);
    return UDateTime(DatString);
}

UField* UAnalyzeData::GetField(int iscan)   const
{
    if(iscan<0 || iscan>=GetNscan())
    {
        CI.AddToLog("ERROR: UAnalyzeData::GetField(). Sub scan out of range: iscan = %d, Nscan = %d.\n", iscan, GetNscan());
        return NULL;
    }

    UFileName FScan   = ImageFileName;
    int       ioffset = iscan;
    if(NumFiles>0 && FirstFileNum>=0) 
    {
        if(FScan.ReplaceNumberBeforeExtension(FirstFileNum+iscan, NDigit)!=U_OK)
        {
            CI.AddToLog("ERROR: UAnalyzeData::GetField(). Creating appropriate data file name: ImageFileName = %s , iscan = %d   .\n", (const char*)ImageFileName, iscan);
            return NULL;
        }
        if(DoesFileExist(FScan)==false)
        {
            CI.AddToLog("ERROR: UAnalyzeData::GetField(). Connot find file (%s  , iscan=%d).\n", (const char*)ImageFileName, iscan);
            return NULL;
        }
        ioffset = 0;
    }

/* Convert Header into Field parameters*/
    UField::DataType DT = UField::U_BYTE;
    int     Size        = 1;
    double Dunit        = 1.;
    int    dims[3]      = {0,0,0};

    switch(HeadDimAna.datatype)
    {
    case DT_BINARY:
    case DT_UNSIGNED_CHAR: DT = UField::U_BYTE;    Size = 1; break;
    case DT_SIGNED_SHORT:  DT = UField::U_SHORT;   Size = 2; break;
    case DT_SIGNED_INT:    DT = UField::U_INTEGER; Size = 4; break;
    case DT_FLOAT:         DT = UField::U_FLOAT;   Size = 4; break;
    case DT_DOUBLE:        DT = UField::U_DOUBLE;  Size = 8; break;
    default:
        CI.AddToLog("ERROR: UAnalyzeData::GetField(). Unsupported data format:%d.\n", HeadDimAna.datatype);
        return NULL;
    }
    if(IsStringCompatible(HeadDimAna.vox_units,"mm", false)==true)
    {
        Dunit = .1;
    }
    else if(IsStringCompatible(HeadDimAna.vox_units,"cm", false)==true)
    {
        Dunit = 1.;
    }
    else if(IsStringCompatible(HeadDimAna.vox_units,"dm", false)==true)
    {
        Dunit = 10.;
    }
    else if(IsStringCompatible(HeadDimAna.vox_units,"m", false)==true)
    {
        Dunit = 100.;
    }
    else
    {
        CI.AddToLog("WARNING: UAnalyzeData::GetField(). Unsupported length unit: %s. Assume mm.\n", HeadDimAna.vox_units);
        Dunit = .1;
    }
    int nx = dims[0] = HeadDimAna.dim[2];
    int ny = dims[1] = HeadDimAna.dim[3];
    int nz = dims[2] = HeadDimAna.dim[1];

    if(GetScanOrientation()==U_ORI_CORONAL)  // Only tested with HeadDimension.dim[1]==HeadDimension.dim[2]
    {
        nx = dims[0] = HeadDimAna.dim[1]; 
        ny = dims[1] = HeadDimAna.dim[2];
        nz = dims[2] = HeadDimAna.dim[3];
    }
    if(GetScanOrientation()==U_ORI_SAGITAL) // NOT tested
    {
        nx = dims[0] = HeadDimAna.dim[2];
        ny = dims[1] = HeadDimAna.dim[3];
        nz = dims[2] = HeadDimAna.dim[1];
    }
    UVector3 Minx =        UVector3(-HeadDimAna.pixdim[2]* nx/2 , -HeadDimAna.pixdim[3]* ny/2 ,  HeadDimAna.pixdim[1]* nz/2 );
    UVector3 Maxx = Minx + UVector3( HeadDimAna.pixdim[2]*(nx-1),  HeadDimAna.pixdim[3]*(ny-1), -HeadDimAna.pixdim[1]*(nz-1));


    UField*  fld  = new UField(Minx*Dunit, Maxx*Dunit, dims, DT);

    if(fld==NULL || fld->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UAnalyzeData::GetField(). Memory allocation for data allocation: size=%d, (nx,ny,nz) = (%d,%d,%d)\n",Size, nx,ny,nz);
        return NULL;
    }

/* Read the data:*/
    FILE* fp = fopen(FScan,"rb",true);
    if(fp==NULL) return NULL;

    int offset = ioffset*Size*nx*ny*nz + int(HeadDimAna.vox_offset);
    fseek(fp, offset, SEEK_SET);

/***
0 transverse unflipped
1 coronal unflipped
2 sagittal unflipped
3 transverse flipped
4 coronal flipped
5 sagittal flipped

X increases from Left to Right 
Y increases from Posterior to Anterior 
Z increases from Inferior to Superior         
***/

    switch(GetScanOrientation())
    {
    case U_ORI_AXIAL:
        {
            switch(DT)
            {
            case UField::U_BYTE:
                {
                    unsigned char* data = fld->GetBdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=nz-1;z>=0;z--)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);
                }
                break;

            case UField::U_SHORT:
                {
                    short* data = fld->GetSdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=nz-1;z>=0;z--)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_INTEGER:
                {
                    int* data = fld->GetIdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=nz-1;z>=0;z--)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_FLOAT:
                {
                    float* data = fld->GetFdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=nz-1;z>=0;z--)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_DOUBLE:
                {
                    double* data = fld->GetDdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=nz-1;z>=0;z--)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;
            }
        }
        break;
    case U_ORI_CORONAL:
        {
            switch(DT)
            {
            case UField::U_BYTE:
                {
                    unsigned char* data = fld->GetBdata();
                    for(int z=nz-1;z>=0;z--)
                        for(int x=nx-1; x>=0;x--)    
                            for(int y=ny-1; y>=0; y--)  
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);
                }
                break;

            case UField::U_SHORT:
                {
                    short* data = fld->GetSdata();
                    for(int z=nz-1;z>=0;z--)
                        for(int x=nx-1; x>=0;x--)    
                            for(int y=ny-1; y>=0; y--)  
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_INTEGER:
                {
                    int* data = fld->GetIdata();
                    for(int z=nz-1;z>=0;z--)
                        for(int x=nx-1; x>=0;x--)    
                            for(int y=ny-1; y>=0; y--)  
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_FLOAT:
                {
                    float* data = fld->GetFdata();
                    for(int z=nz-1;z>=0;z--)
                        for(int x=nx-1; x>=0;x--)    
                            for(int y=ny-1; y>=0; y--)  
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_DOUBLE:
                {
                    double* data = fld->GetDdata();
                    for(int z=nz-1;z>=0;z--)
                        for(int x=nx-1; x>=0;x--)    
                            for(int y=ny-1; y>=0; y--)  
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;
            }
        }
        break;
    case U_ORI_SAGITAL:
        {    
            switch(DT)
            {
            case UField::U_BYTE:
                {
                    unsigned char* data = fld->GetBdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=0;z<nz;z++)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);
                }
                break;

            case UField::U_SHORT:
                {
                    short* data = fld->GetSdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=0;z<nz;z++)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_INTEGER:
                {
                    int* data = fld->GetIdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=0;z<nz;z++)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_FLOAT:
                {
                    float* data = fld->GetFdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=0;z<nz;z++)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;

            case UField::U_DOUBLE:
                {
                    double* data = fld->GetDdata();
                    for(int y=ny-1; y>=0; y--)  
                        for(int x=nx-1; x>=0;x--)    
                            for(int z=0;z<nz;z++)
                                fread(data+nx*(ny*z+y)+x, Size, 1, fp);

                    SwapArray(data, nx*ny*nz, IntelByteOrder);
                }
                break;
            }
        }
        break;
    default:
        {
            fclose(fp);
            CI.AddToLog("ERROR: UAnalyzeData::GetField(). Unknown orientation parameter: %d\n",HeadAna.orient);
            delete fld;
            return NULL;
        }
    }
    fclose(fp);

    UString Prop = GetProperties("// ");
    fld ->SetFileComments(Prop);
    return fld;
}

UEuler UAnalyzeData::GetEuler(void)  const
{
    return UPatTree::GetToWld(GetScanOrientation());
}
OrientType UAnalyzeData::GetScanOrientation(void) const
{
    if(HeadAna.orient>=3 && HeadAna.orient<5)
        CI.AddToLog("WARNING: UAnalyzeData::GetScanOrientation(). Analyze flag indicates that scan may be mirrored.\n");
/*********    
    if(HeadAna.orient!=0 && HeadAna.orient!=3)
        CI.AddToLog("WARNING: UAnalyzeData::GetScanOrientation(). Scan is forced AXIAL. \n");
    return U_ORI_AXIAL;
/*********/
/*********/
    switch(HeadAna.orient)
    {
    case 0:
    case 3: return U_ORI_AXIAL;
    case 1:
    case 4: return U_ORI_CORONAL;
    case 2:
    case 5: return U_ORI_SAGITAL;
    }
    CI.AddToLog("WARNING: UAnalyzeData::GetScanOrientation(). Invalid Analyze flag, HeadAna.orient=%d .\n", HeadAna.orient);
    return U_ORI_UNKNOWN;
/**********/
}

const UString& UAnalyzeData::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UAnalyzeData-object\n");
        return Properties;
    }
    Properties =  UString();

    Properties += UString((const char*)HeaderFileName, "HeaderFile     = %s   \n");
    Properties += UString((const char*)ImageFileName , "ImageFile      = %s   \n");
    Properties += UString(NumFiles                   , "NumFiles       = %d   \n");
    Properties += UString(HeadAna.descrip            , "Description    = %s   \n");
    Properties += UString(HeadAna.patient_id         , "PatientID      = %s   \n");
    Properties += UString(HeadAna.exp_date           , "Date           = %s   \n");
    Properties += UString(HeadAna.exp_time           , "Time           = %s   \n");
    Properties += UString(BoolAsText(IntelByteOrder) , "IntelByteOrder = %s   \n");
    
    if(Comment.IsNULL() || Comment.IsEmpty())       Properties.ReplaceAll('\n', ';');  
    else                                            Properties.InsertAtEachLine(Comment);

    return Properties;
}


ErrorType UAnalyzeData::SwapHeader(Ana_Header_Key* HK, Ana_Image_Dim* ID, Ana_Data_History*  HeadAna, bool IntelByteOrder)
{
    if(HK==NULL || ID==NULL || HeadAna==NULL) return U_ERROR;

    HK->sizeof_hdr       = SwapVal(HK->sizeof_hdr   , IntelByteOrder);
    HK->extents          = SwapVal(HK->extents      , IntelByteOrder);
    HK->session_error    = SwapVal(HK->session_error, IntelByteOrder);

    ID->dim[0]           = SwapVal(ID->dim[0]       , IntelByteOrder);
    ID->dim[1]           = SwapVal(ID->dim[1]       , IntelByteOrder);
    ID->dim[2]           = SwapVal(ID->dim[2]       , IntelByteOrder);
    ID->dim[3]           = SwapVal(ID->dim[3]       , IntelByteOrder);
    ID->dim[4]           = SwapVal(ID->dim[4]       , IntelByteOrder);
    ID->dim[5]           = SwapVal(ID->dim[5]       , IntelByteOrder);
    ID->dim[6]           = SwapVal(ID->dim[6]       , IntelByteOrder);
    ID->dim[7]           = SwapVal(ID->dim[7]       , IntelByteOrder);
    ID->datatype         = SwapVal(ID->datatype     , IntelByteOrder);
    ID->bitpix           = SwapVal(ID->bitpix       , IntelByteOrder);
    ID->pixdim[0]        = SwapVal(ID->pixdim[0]    , IntelByteOrder);
    ID->pixdim[1]        = SwapVal(ID->pixdim[1]    , IntelByteOrder);
    ID->pixdim[2]        = SwapVal(ID->pixdim[2]    , IntelByteOrder);
    ID->pixdim[3]        = SwapVal(ID->pixdim[3]    , IntelByteOrder);
    ID->pixdim[4]        = SwapVal(ID->pixdim[4]    , IntelByteOrder);
    ID->pixdim[5]        = SwapVal(ID->pixdim[5]    , IntelByteOrder);
    ID->pixdim[6]        = SwapVal(ID->pixdim[6]    , IntelByteOrder);
    ID->pixdim[7]        = SwapVal(ID->pixdim[7]    , IntelByteOrder);
    ID->vox_offset       = SwapVal(ID->vox_offset   , IntelByteOrder);
    ID->cal_max          = SwapVal(ID->cal_max      , IntelByteOrder);
    ID->cal_min          = SwapVal(ID->cal_min      , IntelByteOrder);
    ID->compressed       = SwapVal(ID->compressed   , IntelByteOrder);
    ID->verified         = SwapVal(ID->verified     , IntelByteOrder);
    ID->glmax            = SwapVal(ID->glmax        , IntelByteOrder);
    ID->glmin            = SwapVal(ID->glmin        , IntelByteOrder);

    HeadAna->views       = SwapVal(HeadAna->views        , IntelByteOrder);
    HeadAna->vols_added  = SwapVal(HeadAna->vols_added   , IntelByteOrder);
    HeadAna->start_field = SwapVal(HeadAna->start_field  , IntelByteOrder);
    HeadAna->field_skip  = SwapVal(HeadAna->field_skip   , IntelByteOrder);
    HeadAna->omin        = SwapVal(HeadAna->omin         , IntelByteOrder);
    HeadAna->omax        = SwapVal(HeadAna->omax         , IntelByteOrder);
    HeadAna->smin        = SwapVal(HeadAna->smin         , IntelByteOrder);
    HeadAna->smax        = SwapVal(HeadAna->smax         , IntelByteOrder);

    char *Line = (char*)HeadAna;
    for(int k=0; k<168; k++)
    {
        if(k==104) continue;
        char c = Line[k];
        if(c<=32 ||c==44 ||(57<c&&c<=64) || c==91 || c==93 || 122<c) Line[k] = ' ';
        if(k==79 || k==103 || k==114 || k==124 || k==134 || k==144/** || k==154 || k==164**/) Line[k]=0;
    }
    return U_OK;
}


ErrorType UAnalyzeData::WriteAnalyze(UFileName FileName, const UField* F, const char* patname, const char* patid)
{
    if(F==NULL || F->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UAnalyzeData::WriteAnalyze(). Erroneous UField input. \n");
        return U_ERROR;
    }
    if(F->GetFType()!=UField::U_UNIFORM || F->Getndim()!=3 || F->GetNspace()!=3)
    {
        CI.AddToLog("ERROR: UAnalyzeData::WriteAnalyze(). UField of wrong type: %s\n",F->GetProperties(""));
        return U_ERROR;
    }

    Ana_Header_Key     HKey;
    Ana_Image_Dim      HDim;
    Ana_Data_History   HAna;

/*hk*/
    HKey.sizeof_hdr       = HEADER_SIZE_ANA;
    memset(HKey.data_type,' ',10);
    memset(HKey.db_name,' ',18);
    if(patname)  strncpy(HKey.db_name, patname, 17);
    HKey.extents          = 0;
    HKey.session_error    = 0;
    HKey.regular          = 'r';
    HKey.hkey_un0         = 0;
    
/*hist*/
    strncpy(HAna.descrip,"Created by UAnalyzeData::WriteAnalyze()",80);
    memset(HAna.aux_file,' ',24);
    HAna.orient           = 0;
    memset(HAna.originator,' ',10);
    memset(HAna.generated ,' ',10);
    memset(HAna.scannum   ,' ',10);
    memset(HAna.patient_id,' ',10);
    if(patid)  strncpy(HAna.patient_id, patid, 9);
    strncpy(HAna.exp_date,"01013000",10);
    strncpy(HAna.exp_time,"0:00:00",10);
    memset(HAna.hist_un0,0,3);
    HAna.views             = 0;
    HAna.vols_added        = 0;
    HAna.start_field       = 0;
    HAna.field_skip        = 0;
    HAna.omax              = 0;
    HAna.omin              = 0;
    HAna.smax              = 0;
    HAna.smin              = 0;

/*dime*/
    for(int k=0;k<8; k++) HDim.dim[k] = 0;

    HDim.dim[0] = 4;
    HDim.dim[1] = short(F->GetDimensions(2));
    HDim.dim[2] = short(F->GetDimensions(0));
    HDim.dim[3] = short(F->GetDimensions(1));
    HDim.dim[4] = 1;

    strncpy(HDim.vox_units,"cm",4);
    strncpy(HDim.cal_units,"AU",8);
    HDim.unused1   = 0;
    
    switch(F->GetDType())
    {
    case UField::U_BYTE:
        strcpy(HKey.data_type,"BINARY");
        HDim.datatype  = DT_UNSIGNED_CHAR;
        HDim.bitpix    = 8;
        break;
    case UField::U_SHORT:
        strcpy(HKey.data_type,"SHORT");
        HDim.datatype  = DT_SIGNED_SHORT;
        HDim.bitpix    = 16;
        break;
    case UField::U_INTEGER:
        strcpy(HKey.data_type,"INT");
        HDim.datatype  = DT_SIGNED_INT;
        HDim.bitpix    = 32;
        break;
    default:
        CI.AddToLog("ERROR: UAnalyzeData::WriteAnalyze(). Erroneous data type : %d \n",F->GetDType());
        return U_ERROR;
    }
    HDim.dim_un0   = 0;
    for(int k=0;k<8; k++) HDim.pixdim[k] = 0;
    HDim.pixdim[1] = float(F->GetPixelSize(2));
    HDim.pixdim[2] = float(F->GetPixelSize(0));
    HDim.pixdim[3] = float(F->GetPixelSize(1));

    HDim.vox_offset = 0;  
    HDim.funused1   = 0;  
    HDim.funused2   = 0;  
    HDim.funused3   = 0;  
    HDim.cal_max    = 0;  
    HDim.cal_min    = 0;  
    HDim.compressed = 0;  
    HDim.verified   = 0;  
    F->GetMinMaxData(&HDim.glmin, &HDim.glmax);
    
    bool ByteOrder = false;
    SwapHeader(&HKey, &HDim, &HAna, ByteOrder);

/* Write header*/
    FileName.ReplaceExtension(".hdr");
    FILE*fp = fopen(FileName,"wb",true);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnalyzeData::WriteAnalyze(). Cannot create file : %s \n",FileName.GetFullFileName());
        return U_ERROR;
    }
    fwrite(&HKey.sizeof_hdr,      4, 1, fp);
    fwrite(&HKey.data_type,      10, 1, fp);
    fwrite(&HKey.db_name,        18, 1, fp);
    fwrite(&HKey.extents,         4, 1, fp);
    fwrite(&HKey.session_error,   2, 1, fp);
    fwrite(&HKey.regular,         1, 1, fp);
    fwrite(&HKey.hkey_un0,        1, 1, fp);

    fwrite(&HDim.dim,             2, 8, fp);
    fwrite(&HDim.vox_units,       1, 4, fp);
    fwrite(&HDim.cal_units,       1, 8, fp);
    fwrite(&HDim.unused1,         2, 1, fp);
    fwrite(&HDim.datatype,        2, 1, fp);
    fwrite(&HDim.bitpix,          2, 1, fp);
    fwrite(&HDim.dim_un0,         2, 1, fp);
    fwrite(&HDim.pixdim,          4, 8, fp);
    fwrite(&HDim.vox_offset,      4, 1, fp);
    fwrite(&HDim.funused1,        4, 1, fp);
    fwrite(&HDim.funused2,        4, 1, fp);
    fwrite(&HDim.funused3,        4, 1, fp);
    fwrite(&HDim.cal_max,         4, 1, fp);
    fwrite(&HDim.cal_min,         4, 1, fp);
    fwrite(&HDim.compressed,      4, 1, fp);
    fwrite(&HDim.verified,        4, 1, fp);
    fwrite(&HDim.glmax,           4, 1, fp);
    fwrite(&HDim.glmin,           4, 1, fp);

    fwrite(&HAna.descrip,        80, 1, fp);
    fwrite(&HAna.aux_file,       24, 1, fp);
    fwrite(&HAna.orient,          1, 1, fp);
    fwrite(&HAna.originator,     10, 1, fp);
    fwrite(&HAna.generated,      10, 1, fp);
    fwrite(&HAna.scannum,        10, 1, fp);
    fwrite(&HAna.patient_id,     10, 1, fp);
    fwrite(&HAna.exp_date  ,     10, 1, fp);
    fwrite(&HAna.exp_time  ,     10, 1, fp);
    fwrite(&HAna.hist_un0  ,      3, 1, fp);
    fwrite(&HAna.views,           4, 1, fp);
    fwrite(&HAna.vols_added,      4, 1, fp);
    fwrite(&HAna.start_field,     4, 1, fp);
    fwrite(&HAna.field_skip,      4, 1, fp);
    fwrite(&HAna.omax,            4, 1, fp);
    fwrite(&HAna.omin,            4, 1, fp);
    fwrite(&HAna.smax,            4, 1, fp);
    fwrite(&HAna.smin,            4, 1, fp);
    fclose(fp);

/* Write image*/
    FileName.ReplaceExtension(".img");
    fp = fopen(FileName,"wb",true);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnalyzeData::WriteAnalyze(). Cannot create file : %s \n",FileName.GetFullFileName());
        return U_ERROR;
    }

    int nz = F->GetDimensions(2);
    int nx = F->GetDimensions(0);
    int ny = F->GetDimensions(1);

    switch(F->GetDType()) 
    {
    case UField::U_BYTE:
        {
            for(int y=ny-1; y>=0; y--)  
                for(int x=0; x<nx;x++)    
                    for(int z=nz-1;z>=0;z--)
                        fwrite(F->GetBdata()+nx*(ny*z+y)+x, 1, 1, fp);
            break;
        }
    case UField::U_SHORT:
        {
            short* data = F->GetSdata();
            SwapArray(data, nx*ny*nz, false);
    
            for(int y=ny-1; y>=0; y--)  
                for(int x=0; x<nx;x++)    
                    for(int z=nz-1;z>=0;z--)
                        fwrite(data+nx*(ny*z+y)+x, 1, 2, fp);

            SwapArray(data, nx*ny*nz, false);
        }
        break;
     
    case UField::U_INTEGER:
        {
            int* data = F->GetIdata();
            SwapArray(data, nx*ny*nz, false);
            for(int y=ny-1; y>=0; y--)  
                for(int x=0; x<nx;x++)    
                    for(int z=nz-1;z>=0;z--)
                        fwrite(data+nx*(ny*z+y)+x, 1, 4, fp);

            SwapArray(data, nx*ny*nz, false);
        }
        break;
    }
    fclose(fp);
    
    return U_OK;
}
