#ifndef _ANALYZEDATA_INCLUDED
#define _ANALYZEDATA_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Field.h"
#include "FileName.h"
#include "DateTime.h"
#include "String.h"

#define HEADER_SIZE_ANA       348

struct Ana_Header_Key       /* header_key */
{                           /* off + size */
    int    sizeof_hdr;      /* 0 + 4      */
    char   data_type[10];   /* 4 + 10     */
    char   db_name[18];     /* 14 + 18    */
    int    extents;         /* 32 + 4     */
    short  session_error;   /* 36 + 2     */
    char   regular;         /* 38 + 1     */
    char   hkey_un0;        /* 39 + 1     */
};                          /* total=40   */

struct Ana_Image_Dim      /*  image_dimension (Analyze) */
{                           /* off + size */
    short dim[8];           /*   0 + 16     */
    char  vox_units[4];     /*  16 +  4     */
    char  cal_units[8];     /*  20 +  4     */
    short unused1;          /*  24 +  2     */
    short datatype;         /*  30 +  2     */
    short bitpix;           /*  32 +  2     */
    short dim_un0;          /*  34 +  2     */
    float pixdim[8];        /*  36 + 32     */
    float vox_offset;       /*  68 +  4     */
    float funused1;         /*  72 +  4     */
    float funused2;         /*  76 +  4     */
    float funused3;         /*  80 +  4     */
    float cal_max;          /*  84 +  4     */
    float cal_min;          /*  88 +  4     */
    int   compressed;       /*  92 +  4     */
    int   verified;         /*  96 +  4     */
    int   glmax;            /* 100 +  4     */
    int   glmin;            /* 104 +  4     */
};          

struct Ana_Data_History     /*      data_history (Analyze) */
{                              /* off + size  */
    char descrip[80];          /*   0 + 80    */
    char aux_file[24];         /*  80 + 24    */
    char orient;               /* 104 +  1    */
    char originator[10];       /* 105 + 10    */
    char generated[10];        /* 115 + 10    */
    char scannum[10];          /* 125 + 10    */
    char patient_id[10];       /* 135 + 10    */
    char exp_date[10];         /* 145 + 10    */
    char exp_time[10];         /* 155 + 10    */
    char hist_un0[3];          /* 165 +  3    */
    int  views;                /* 168 +  4    */
    int  vols_added;           /* 172 +  4    */
    int  start_field;          /* 176 +  4    */
    int  field_skip;           /* 180 +  4    */
    int  omax,omin;            /* 184 +  8    */
    int  smax,smin;            /* 192 +  8    */
};                             /* total=200   */


class UFileName;
class UField;

class DLL_IO UAnalyzeData
{
public:
    UAnalyzeData(UFileName FileName);
    ~UAnalyzeData();  

    ErrorType          GetError(void)  const {return error;}

    UField*            GetField(int iscan =0) const;
    UEuler             GetEuler(void) const;
    OrientType         GetScanOrientation(void) const;
    const UString&     GetProperties(UString Comment) const;

    const char*        GetSubject(void) const {return HeadKey.db_name;}
    const char*        GetSubjectID(void) const {return HeadAna.patient_id;}
    UDateTime          GetScanDate(void) const;
    const char*        GetHeaderFileName(void) const {return HeaderFileName.GetFullFileName();}
    int                GetNscan(void) const;
    double             GetSampleTime(void) const;

    static ErrorType   WriteAnalyze(UFileName FileName, const UField* F, const char* patname, const char* patid);
    static ErrorType   SwapHeader(Ana_Header_Key* HK, Ana_Image_Dim* ID, Ana_Data_History*  HeadAna, bool IntelByteOrder);

private:
    ErrorType          error;       // General error flag
    static UString     Properties;
    Ana_Header_Key     HeadKey;
    Ana_Image_Dim      HeadDimAna;
    Ana_Data_History   HeadAna;

    UFileName          HeaderFileName;
    UFileName          ImageFileName;
    bool               IntelByteOrder;
    int                NumFiles;      // >0 in case there are subsequently numbered files
    int                FirstFileNum;  // Number of first file (must be non-negative)
    int                NDigit;        // (0 when variying)
};

#endif //_ANALYZEDATA_INCLUDED


