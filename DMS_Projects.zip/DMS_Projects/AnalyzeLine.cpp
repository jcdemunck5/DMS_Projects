/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Module for retrieving items printed on a line of an ASCII-file.              */
/*     The basic assumption is that the items are separated by "Separator Symbols"  */
/*     (see IsSeparator()). Furthermore, there are special comment signs like       */
/*     ##, %%, CC and // which are assumed to imply that the Line[] doens not       */
/*     contain any relevant items (see IsComment())                                 */
/*     Finally, if // is present in the middle of the Line[], all following         */
/*     characters are considered as comment.                                        */
/*                                                                                  */
/*     The idea is to read a line from the file using the function GetLine()        */
/*     in the C-module GetLine.c, instantiate an UAnalyzeLine-object with a         */
/*     pointer to the retrieved line, and subsequently call the functions           */
/*     IsComment(), GetNextInt(), GetNextDouble(), etc.                             */
/*                                                                                  */
/*     EXAMPLE:                                                                     */
/*       char line[100];                                                            */
/*       FILE* fp=fopen(FileName,"rt");                                             */
/*       memset(line, 0, sizeof(line));                                             */
/*       while(GetLine(line, sizeof(line), fp))                                     */
/*       {                                                                          */
/*            UAnalyzeLine AA(line, sizeof(line));                                  */
/*            if(AA.IsComment() == false)                                           */
/*            {                                                                     */
/*                double x = AA.GetNextDouble();                                    */
/*                double y = AA.GetNextDouble();                                    */
/*                double z = AA.GetNextDouble();                                    */
/*                if(AA.GetError()!=U_OK)                                           */
/*                {                                                                 */
/*                    fclose(fp);                                                   */
/*                    return U_ERROR;                                               */
/*                }                                                                 */
/*                Do something with x, y, z                                         */
/*            }                                                                     */
/*        }                                                                         */
/*                                                                                  */
/*     RELATED OBJECTS:                                                             */ 
/*     The object UAnalyzeLineExt() is an extended version of UAnalyzeLine(), with  */
/*     more advanced behaviour.                                                     */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    16-10-98   creation.
  JdM    05-03-98   changed functionality of IsComment()
  JdM    19-12-98   BUG FIX: Set error=U_OK in GetNextDouble(). Added more comment.
  JdM    22-12-98   BUG FIX: Definition of separator: in range 90-96
JdM/AdJ  19-02-99   Renamed MAXSTRING into MAXLINESTRING
  JdM    19-03-99   Added IsIdentifierIs() and GetNextFileName()
  JdM    23-03-99   Added UNIX compatibility in getting filenames
JdM/AdJ  15-04-99   Made IsSeparator() virtual
  JdM    06-06-99   Allow dot in filenames
  JdM    04-08-99   IsEndOfLine(), allow one more character
  JdM    17-08-99   Added GetCollumn_d()
  JdM    30-09-99   Improved tests in GetNextInt(), GetNextFloat() and GetNextDouble() for correct input from Line[]
  JdM    18-01-00   Added StringInComment()
  DvT    19-01-00   Bug fixes in StringInComment()
  JdM    23-03-00   Added IsStartList() and IsEndList()
                    Redefine IsSeparator()
  JdM    30-04-00   Added ToUpper()
  JdM    01-05-00   Added IsIdentifierIsInLine()
                    New Test in GetNextDouble() and GetNextFloat()
  AdJ    15-05-00   Bug Fix: IsGoodDouble(), test for '+' or '-' sign in exponent
JdM/SG   22-05-00   Added IsEmptyLine()
  JdM    26-06-00   Added IsIdentifier()
                    Made many char pointers const
  JdM    04-09-00   Added operator=() and GetCollumn() and MoveToCollumn()
  JdM    24-12-00   Added parameter to GetCollumn()
  JdM    18-04-01   Added IsIdentifierInLine()
  JdM    15-08-01   Added GetNString()   
  JdM    14-11-01   Added IsCommentLine()
  JdM    15-04-02   Added GetCollumn_i()
  JdM    11-07-03   Added GetIdentifierInt()
  JdM    06-02-04   Added MoveToChar() and MoveToBegin() and ConvertChar()
                    IsComment(). Lines starting with "# " are considered as comment
  JdM    15-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-01-05   Added copy constructor
  JdM    26-02-05   GetNextFileName(). Allow any character when file name is between quotes
  JdM    10-05-05   Bug Fix: GetNextFileName(). When file name does not start with quote, do NOT skip first character
  JdM    27-05-05   Added GetNCollumn()
  JdM    10-04-06   Added SkipComments()
  JdM    03-01-08   Added argument on IsCommentLine()
  JdM    10-03-08   GetNextString() and GetNextFileName(). Made default value const char* iso char*
  JdM    08-09-08   GetCollumn(): Added parameter
  JdM    19-09-08   GetCollumn(): Added parameter
  JdM    12-06-11   Added (default) parameter to ConvertChar()
  JdM    28-09-11   Added GetNextBool()
  JdM    01-12-12   IsComment(). Added "#\n" as comment
  JdM    17-11-13   Bug Fix: IsComment(). Treat case of single character left in line
                    Bug Fix: IsEndList(). Treat case of single character left in line
 */

#include <stdlib.h>
#include <string.h>
#include "AnalyzeLine.h"


UAnalyzeLine::UAnalyzeLine(const char *line, int maxch)
/*
    Initialize the object by giving a string (line[]), with maxch characters.
    If(maxch<0), the maximum amount of characters analyzed is determined by the
    string length.
 */
{
    error   = U_OK;
    Line    = line;
    Pointer = line;
    Maxchar = maxch;
    if(line==NULL) 
        error = U_ERROR;
    else
        if(Maxchar<0) 
            Maxchar = strlen(line);
}

UAnalyzeLine::UAnalyzeLine(const UAnalyzeLine& AA)
{
    error   = U_ERROR;
    Line    = NULL;
    Pointer = NULL;
    Maxchar = 0;
    if(&AA==NULL)
    {
        CI.AddToLog("ERROR: UAnalyzeLine::UAnalyzeLine(). Invalid NULL address argument. \n");
        return;
    }
    *this = AA;
}

UAnalyzeLine& UAnalyzeLine::operator=(const UAnalyzeLine& AA)
{
    error   = AA.error;
    Line    = AA.Line;
    Pointer = AA.Pointer;
    Maxchar = AA.Maxchar;

    return *this;
}

char UAnalyzeLine::ToUpper(char c) const
{
    if('a'<=c && c<='z') return c+'A'-'a';
    return c;
}

bool UAnalyzeLine::IsIs(char c)  const
/*
     Return true iff c is the '='-sign
 */
{
    if(c == '=') return true;
    return false;
}

bool UAnalyzeLine::IsQuote(char c) const
{
    if(IsQuote1(c)==true || IsQuote2(c)==true) return true;
    return false;
}

bool UAnalyzeLine::IsQuote1(char c) const
{
    if(c=='\'') return true; //??
    return false;
}

bool UAnalyzeLine::IsQuote2(char c) const
{
    if(c=='"') return true;
    return false;
}

bool UAnalyzeLine::IsBracketOpen(char c) const
{
    if(c == '{') return true;
    return false;
}

bool UAnalyzeLine::IsBracketClose(char c) const
{
    if(c == '}') return true;
    return false;
}

bool UAnalyzeLine::IsFileChar(char c) const
/*
     return true iif c is a character that is allowed in the filename (not exlusive)
 */
{
    if( ('a'<=c&&c<='z') || ('A'<=c&&c<='Z') || ('0'<=c&&c<='9') ||
        (c=='~') ||
        (c=='@') ||
        (c=='#') ||
        (c=='$') ||
        (c=='%') ||
        (c=='^') ||
        (c=='&') ||
        (c=='-') ||
        (c=='_') ||
        (c=='.') ||
        (c==':') || (c=='/') || (c=='\\')   ) return true;
    return false;
}

bool UAnalyzeLine::IsNumber(char c) const
{
    if( '0'<=c&&c<='9') return true;
    return false;
}

bool UAnalyzeLine::IsDoubleChar(char c) const
{
    if(IsNumber(c)==true || 
        c=='+' || c=='-' || c=='.' || c==',' ||
        c=='E' || c=='e' || c=='D' || c=='d') return true;
    return false;
}

bool UAnalyzeLine::IsGoodDouble(const char* Pnt) const
{
    int       Ndec = 0;
    const char* P  = Pnt;
    if(*P=='+' || *P=='-') P++;
    if(*P=='.') 
    {
        P++; Ndec++;
    }
    while(IsNumber(*P)==true) P++;

    if(P==Pnt)              return false;
    if(*P=='.' && Ndec==1)  return false;
    if(*P=='.') 
    {
        P++; Ndec++;
    }
    while(IsNumber(*P)==true) P++;
    if(*P=='E' || *P=='e' || *P=='D' || *P=='d')
    {
        P++;
        if(*P=='+'||*P=='-') P++;
        if(IsNumber(*P)==false) return false;
    }
    return true;
}

bool UAnalyzeLine::IsSeparator(char c) const
/*
      When analyzing Line[], it is assumed that the relevant items are separated by
      socalled "separator" character (e.g. SPACE, TAB, o, etc).

      return true iff c is such a separator character.

 */
{
    if(c<=' ' ||c==',' || c==';' || c=='|' || 127<=c) return true;
    
    return false;
}

bool UAnalyzeLine::IsBeginItem(void) const
/*
    return true if the Pointer refers to a non-separator, whereas Poniter-1 refers
    to separator. In this case Pointer refers to the beginning of a relevant item 
    in the Line[].
 */
{
    if(Pointer==Line && IsSeparator(*Pointer)==false) return true;

    if(IsSeparator(*(Pointer-1))==true && IsSeparator(*Pointer)==false) return true;
    else                                                               return false;
}

bool UAnalyzeLine::IsEndItem(void) const
/*
    return true if the Pointer refers to a separator, whereas Poniter-1 refers
    to non-separator. In this case Pointer refers to the end of a relevant item 
    in the Line[].
 */
{
    if(IsSeparator(*(Pointer-1))==false && IsSeparator(*Pointer)==true) return true;
    else                                                               return false;
}

bool UAnalyzeLine::IsEndOfLine(void)
/*
     return true if there are no more relevant items on Line[] beyond Pointer.
     This is the case is if Pointer is too large, or if Pointer refers to comments that 
     are to be ignored.
 */
{
    if(Pointer>=Line+Maxchar-1) 
    {
        error = U_ERROR;
        return true;
    }
    if(IsComment(true)==true)
    {
        error = U_ERROR;
        return true;
    }
    return false;
}

bool UAnalyzeLine::IsComment(bool StartFromPointer) const
/*
    Determine whether the member Line[], or the rest of it (starting from Pointer) represents
    a comment line. A comment line starts with "//", "%%", "##", "# ", or "CC". All part of Line[],
    following "//" is considered as comment.
 */
{
    const char* start=Line;
    if(StartFromPointer==true)  start = Pointer;

    if(start+2>Line+Maxchar) return *start == '#';

    if(                 !strncmp(start,"//" ,2)  || 
        (start==Line && !strncmp(start,"%%" ,2)) || 
        (start==Line && !strncmp(start,"##" ,2)) || 
        (start==Line && !strncmp(start,"# " ,2)) || 
        (start==Line && !strncmp(start,"#\n",2)) || 
        (start==Line && !strncmp(start,"CC" ,2))    ) return true;
    else
        return false;
}

ErrorType UAnalyzeLine::SkipComments(void)
{
    if(Pointer==NULL)          return U_ERROR;
    if(Pointer+2>Line+Maxchar) return U_ERROR;

    while(IsSeparator(*Pointer)==true && Pointer<Line+Maxchar-1) 
    {
        Pointer++;
        Line++;
        Maxchar--;
    }
    if(IsComment(true))
    {
        Pointer+=2;
        Line   +=2;
        Maxchar-=2;
        return SkipComments();
    }
    return U_OK;
}

bool UAnalyzeLine::IsCommentLine(const char* CommentString, bool IgnoreLeadingSeparators)
/*
    return true iff Line starts with CommentString[]
 */
{
    if(CommentString)
    {
        int   Clen        = strlen(CommentString);
        const char* start = Line;
        if(IgnoreLeadingSeparators)
        {
            if(Maxchar-Clen<=0) return false;

            for(int k=0; k<Maxchar-Clen; k++) 
            {
                if(IsSeparator(*start)==true) start++;
                else                          break;
            }
        }
        return !strncmp(start, CommentString, Clen);
    }
    if(IgnoreLeadingSeparators)
    {
        int Maxc = Pointer-Line;
        for(int k=0; k<Maxc; k++) 
        {
            if(IsSeparator(*Pointer)==true) Pointer++;
            else                            break;
        }
    }
    return IsComment(true); // true -> start from Pointer i.s.o. Line
}

bool UAnalyzeLine::IsEmptyLine() const
{
    for(int k=0;k<Maxchar;k++)
        if(IsSeparator(Line[k])==false) 
            return false;

    return true;
}

int UAnalyzeLine::GetNextInt(int def)
/*
     Return the next integer in the Line[]. 
     On error, return the default def, and set the error flag on U_ERROR. This flag can be obtained
     by calling GetError().
     After reading the integer, the Pointer is increased accordingly.
 */
{
    error      = U_ERROR;
    int result = def;        // default 
    if(IsEndOfLine()==true) return result;

    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return result;
            Pointer++;
        }
    }
    if(IsEndOfLine()==true) return result;
    
    result = atoi(Pointer);

    const char* OldPointer = Pointer;

    while(Pointer<Line+Maxchar-1 && IsEndItem()==false && IsComment(true)==false) Pointer++;

/* All characters after OldPointer must be numbers*/
    if(*OldPointer == '-' || *OldPointer == '+') OldPointer++;
    for(const char *P=OldPointer; P<Pointer; P++) 
        if(IsNumber(*P)==false && IsSeparator(*P)==false) return def;

    error  = U_OK;
    return result;
}

bool UAnalyzeLine::GetNextBool(bool def)
{
    const char* S      = GetNextString(6, NULL);
    if(S==NULL) return def;

    int LenS = strlen(S);
    if(LenS==1)
    {
        if(S[0]=='t' || S[0]=='T') return true;
        if(S[0]=='f' || S[0]=='F') return false;
        return def;
    }
    if(LenS==4)
    {
        if(IsStringCompatible(S, "true", false)==true) return true;
        return def;
    }
    if(LenS==5)
    {
        if(IsStringCompatible(S, "false", false)==true) return false;
        return def;
    }
    return def;
}


int UAnalyzeLine::GetIdentifierInt(const char* Identifier, bool IgnoreCase, int def)
/*
     Proceed the pointer to the first appearance of the string Identifier[] and return the
     integer immediately following that indentifier (without separators). When the identifier
     does not occur, or when there is no valid integer, return def.
   
     On error, return the default def, and set the error flag on U_ERROR. This flag can be obtained
     by calling GetError().
     After reading the integer, the Pointer is increased accordingly.
 */
{
    if(Identifier==NULL) return -1;

    const char* OldPointer = Pointer;
    Pointer                = Line;
    unsigned int NbID      = strlen(Identifier);

    while(1)
    {
        bool IsID = true;
        for(unsigned int n=0; n<NbID; n++)
        {
            if(IsEndOfLine()==true || IsComment()) 
            {
                Pointer = OldPointer;
                return def;
            }
            if(IgnoreCase==false)
            {
                if(Pointer[n] != Identifier[n]) 
                {
                    IsID = false;
                    break;
                }
            }
            else
            {
                if(ToUpper(Pointer[n]) != ToUpper(Identifier[n])) 
                {
                    IsID = false;
                    break;
                }
            }
        }
        if(IsID==true) 
        {
            Pointer += NbID;
            break;
        }
        Pointer++;
    }

/* Determine int*/
    int result = atoi(Pointer);
    
/* All characters after Pointer must be numbers*/
    if(*Pointer == '-' || *Pointer == '+') Pointer++;
    for(const char *P=Pointer; ; P++) 
        if(IsNumber(*P)==true) Pointer++;
        else break;

    error  = U_OK;
    return result;
}

float UAnalyzeLine::GetNextFloat(float def)
/*
     Return the next float in the Line[]. 
     On error, return the default def, and set the error flag on U_ERROR. This flag can be obtained
     by calling GetError().
     After reading the float, the Pointer is increased accordingly.

 */
{
    error        = U_ERROR;
    float result = def;     // default 
    if(IsEndOfLine()==true) return result;

    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return result;
            Pointer++;
        }
    }
    if(IsEndOfLine()==true) return result;
    
    result = (float) atof(Pointer);

    const char* OldPointer = Pointer;
    while(Pointer<Line+Maxchar-1 && IsEndItem()==false && IsComment(true)==false) Pointer++;

/* All characters after OldPointer must be characters allowed in a printed float*/
    if(IsGoodFloat(OldPointer)==false) return def;

    error  = U_OK;
    return result;
}

double UAnalyzeLine::GetNextDouble(double def)
/*
     Return the next double in the Line[]. 
     On error, return the default def, and set the error flag on U_ERROR. This flag can be obtained
     by calling GetError().
     After reading the double, the Pointer is increased accordingly.

 */
{
    error         = U_ERROR;
    double result = def;    // default 
    if(IsEndOfLine()==true) return result;

    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return result;
            Pointer++;
        }
    }
    if(IsEndOfLine()==true) return result;
    
    result = (double) atof(Pointer);

    const char* OldPointer = Pointer;
    while(Pointer<Line+Maxchar-1 && IsEndItem()==false && IsComment(true)==false) Pointer++;

/* All characters after OldPointer must be characters allowed in a printed float*/
    if(IsGoodDouble(OldPointer)==false) return def;

    error  = U_OK;
    return result;
}

int UAnalyzeLine::GetNString(void) 
/*
     Return the number of strings on the line, counting from the current pointer.
     At the end, the pointer is unchanged.
 */
{
    const char* OldPointer = Pointer;

    int NS=0;
    while(GetNextString(1, NULL) && error==U_OK) NS++;

    Pointer = OldPointer;
    error   = U_OK;
    return NS;
}

const char* UAnalyzeLine::GetNextString(int maxstring, const char *def)
/*
     Return a pointer to a copy of the next string in the Line[]. This copy contains at maximum MAXLINESTRING 
     or maxstring  characters plus an ending zero. 

     On error, return the default def, and set the error flag on U_ERROR. This flag can be obtained
     by calling GetError().
     After reading the string, the Pointer is increased until the first EndItem after the stringaccordingly, but to at most maxstring characters.
     
     Note:
     The resulting string pointer has to be processed in the calling function, before the next call to
     GetNextString(), otherwise the contents of the pointer will be spoiled.

 */
{
    error              = U_ERROR;
    const char* result = def; // default 

    if(IsEndOfLine()==true) return result;

    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return result;
            Pointer++;
        }
    }
    if(IsEndOfLine()==true) return result;
    
    static char String[MAXLINESTRING +1];
    memset(String, 0, MAXLINESTRING+1);
    if(MAXLINESTRING <maxstring) maxstring = MAXLINESTRING ;


    error  = U_OK;
    int nc = 0;
    while(Pointer<Line+Maxchar && IsEndItem()==false) 
    {
        if(nc<maxstring-1)
        {
            String[nc++] = *Pointer;
        }
        Pointer++;
    }
    return String;
}

bool UAnalyzeLine::IsIdentifierInLine(const char* Identifier, bool IgnoreCase)
/*
     Test whether the identifier Identifier[], is anywhere in the Line[]. 
     Do not update the Pointer when the Identifier[] is not in the Line
 */
{
    const char* OldPointer = Pointer;
    Pointer    = Line;
    bool  End  = false;
    bool  IsID = false;

    while(End==false && IsID==false)
    {
        IsID = IsIdentifier(Identifier, IgnoreCase);
        if(IsID==true) break;
        
        if(IsSeparator(*Pointer)==true)
        {
            while(IsBeginItem()==false) //Move the pointer until the next begin of an item
            {
                End = IsEndOfLine();
                if(End==true) break;
                Pointer++;
            }
        }
        else
        {        
            while(IsEndItem()==false) //Move the pointer until the next end of an item
            {
                End = IsEndOfLine();
                if(End==true) break;
                Pointer++;
            }
        }
        End = IsEndOfLine();
    }

    if(IsID==false) Pointer = OldPointer;
    return IsID;
}

bool UAnalyzeLine::IsIdentifierIsInLine(const char* Identifier, bool IgnoreCase)
/*
     Test whether the identifier Identifier[], followed by '=' is anywhere in the
     Line[]. Do not update the Pointer when the Identifier[] (followed by '=')
     is not in the Line
 */
{
    const char* OldPointer = Pointer;
    Pointer    = Line;
    bool  End  = false;
    bool  IsID = false;

    while(End==false && IsID==false)
    {
        IsID = IsIdentifierIs(Identifier, IgnoreCase);
        if(IsID==true) break;
        
        if(IsSeparator(*Pointer)==true)
        {
            while(IsBeginItem()==false) //Move the pointer until the next begin of an item
            {
                End = IsEndOfLine();
                if(End==true) break;
                Pointer++;
            }
        }
        else
        {        
            while(IsEndItem()==false) //Move the pointer until the next end of an item
            {
                End = IsEndOfLine();
                if(End==true) break;
                Pointer++;
            }
        }
        End = IsEndOfLine();
    }

    if(IsID==false) Pointer = OldPointer;
    return IsID;
}

bool UAnalyzeLine::IsIdentifier(const char* Identifier, bool IgnoreCase)
/*
     return true if the next string following the current pointer is Identifier[].
     In that case, update the internal pointer.

     return false if the above condition does not hold. Do not update the internal pointer
     (except for separator symbols). 

     if(IgnoreCase==true) the indentifier is case insensitive
 */
{
    if(IsEndOfLine()==true) return false;

/* Move the pointer until the next start of an item.*/
    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return false;
            Pointer++;
        }
    }

/* Test Identifier[] */
    unsigned int n=0;
    for(            ; n<strlen(Identifier); n++)
    {
        if(IsEndOfLine()==true || IsComment()) return false;
        if(IgnoreCase==false)
        {
            if(Pointer[n] != Identifier[n]) return false;
        }
        else
        {
            if(ToUpper(Pointer[n]) != ToUpper(Identifier[n])) return false;
        }
    }
    
/* Increase Pointer and return string*/
    Pointer += n+1;
    return true;
}

bool UAnalyzeLine::IsIdentifierIs(const char* Identifier, bool IgnoreCase)
/*
     return true if the next string following the current pointer is Identifier[],
     followed by optional separators and the '='-sign. In that case, update the
     internal pointer.

     return false if the above condition does not hold. Do not update the internal pointer
     (except for separator symbols). 

     if(IgnoreCase==true) the indentifier is case insensitive

     Note: This function can be used to read a (commented) ASCII-file, where each line is formatted
     as IDENTIFIER = VALUE
 */
{
    if(IsEndOfLine()==true) return false;

/* Move the pointer until the next start of an item.*/
    if(IsSeparator(*Pointer)==true)
    {
        while(IsBeginItem()==false)
        {
            if(IsEndOfLine()==true) return false;
            Pointer++;
        }
    }

/* Test Identifier[] */
    unsigned int n=0;
    for(            ; n<strlen(Identifier); n++)
    {
        if(IsEndOfLine()==true || IsComment()) return false;
        if(IgnoreCase==false)
        {
            if(Pointer[n] != Identifier[n]) return false;
        }
        else
        {
            if(ToUpper(Pointer[n]) != ToUpper(Identifier[n])) return false;
        }
    }

/* Test '='-sign */
    while(Pointer+n<Line+Maxchar)
    {
        if(IsEndOfLine()==true || IsComment()) return false;
        if(IsIs(Pointer[n])==true) break;
        if(IsSeparator(Pointer[n])==false) return false;
        n++;
    }
    if(IsIs(Pointer[n])==false) return false;
    
/* Increase Pointer and return string*/
    Pointer += n+1;
    return true;
}

const char* UAnalyzeLine::GetNextFileName(int maxstring, const char *def)
/*
   If the filename is between quotes, allow any character in file name
   else, allow only characters of type IsFileChar().
 */
{
    error              = U_ERROR;
    const char* result = def; // default 
    if(IsEndOfLine()==true) return result;

    while(IsSeparator(*Pointer)==true)
    {
        if(IsQuote(*Pointer)) break;
        if(IsEndOfLine()==true) return result;
        Pointer++;
    }
    bool UseQuotes = false;
    if(IsQuote(*Pointer)) {UseQuotes=true; Pointer++;}
    if(IsEndOfLine()==true || (UseQuotes==false && IsFileChar(*Pointer)==false)) return result;
    
    static char String[MAXLINESTRING+1];
    memset(String, 0, MAXLINESTRING+1);
    if(MAXLINESTRING<maxstring) maxstring = MAXLINESTRING;

    error  = U_OK;
    int nc = 0;
    while(Pointer<Line+Maxchar && (UseQuotes==true || (UseQuotes==false && IsFileChar(*Pointer)==true))) 
    {
        if(UseQuotes==true  && IsQuote(*Pointer)) return String;

        if(nc<maxstring)
        {
#ifdef WIN32
            if(*Pointer == '/') String[nc++] = '\\';
            else                String[nc++] = *Pointer;
#else
            if(*Pointer == '\\') String[nc++] = '/';
            else                 String[nc++] = *Pointer;
#endif            
        }
        Pointer++;
    }
    if(UseQuotes==true)
        CI.AddToLog("WARNING: UAnalyzeLine::GetNextFileName(). Ending quote is missing: %s \n", Line);

    return String;
}

ErrorType UAnalyzeLine::MoveToCollumn(int icol)
{
    if(icol<0) return U_ERROR;

    int ic  = 0;
    Pointer = Line;
    while(ic<=icol)
    {
        if(IsEndOfLine()==true) return U_ERROR;

        if(IsBeginItem()==true)
        {
            if(ic==icol) return U_OK;
            ic++;
        }
        Pointer++;
    }
    return U_ERROR;
}

ErrorType UAnalyzeLine::MoveToChar(char c)
{
    const char* OldPointer = Pointer;
    while(*Pointer != c)
    {
        if(IsEndOfLine()==true)
        {
            Pointer = OldPointer;
            return U_ERROR;
        }
        Pointer++;
    }
    Pointer++;
    return U_OK;
}

ErrorType UAnalyzeLine::MoveToBegin()
{
    Pointer = Line;
    return U_OK;
}

ErrorType UAnalyzeLine::ConvertChar(char*line, char cin, char cout, int MaxTimes)
/*
    Convert each occurance of cin in line[] into cout
 */
{
    if(line    ==NULL) return U_ERROR;
    if(MaxTimes==0   ) return U_OK;
    int NR = 0;
    for(unsigned int k=0; k<strlen(line); k++)
    {
        if(line[k]!=cin) continue;
        line[k] = cout;
        NR++;
        if(MaxTimes>0 && NR>=MaxTimes) return U_OK;
    }
    return U_OK;
}

int UAnalyzeLine::GetCollumn(const char* ColName, const char* SkipName1, const char* SkipName2, const char* SkipName3) 
/*
    Return the number of the collumn where the string ColName appears the first time.
    if(SkipName) in numbering the collumns, skip the occurence of a collumn named SkipName[]

    Return -1 if the string does not appear at all.
 */
{
    if(ColName==NULL) return -1;

    int          ic  = 0;
    const char* OldP = Pointer;
    Pointer = Line;
    while(1)
    {
        if(IsEndOfLine()==true) {Pointer=OldP; return -1;}

        if(IsBeginItem()==true)
        {
            if(SkipName1 && IsIdentifier(SkipName1)==true) continue;
            if(SkipName2 && IsIdentifier(SkipName2)==true) continue;
            if(SkipName3 && IsIdentifier(SkipName3)==true) continue;
            if(IsIdentifier(ColName)==true) 
            {
                Pointer=OldP; 
                return ic;
            }
            ic++;
        }
        Pointer++;
    }
    Pointer=OldP; 
    return -1;
}

int UAnalyzeLine::GetNCollumn()
/*
    Return the number of collumns.
    
    The function starts looking from the beginning of the line.
 */
{
    int         ic         = 0;
    const char* OldPointer = Pointer;
    Pointer = Line;
    while(IsEndOfLine()==false)
    {
        if(IsBeginItem()==true) ic++;
        Pointer++;
    }
    Pointer = OldPointer;
    return ic;
}

double UAnalyzeLine::GetCollumn_d(int icol, double DefVal)
/*
    Get the icol-th item on the line and convert it to double.
    A string or a non-existent item is converted to 0, but the error flag is set,
    
    The function starts looking from the beginning of the line.
 */
{
    error   = U_OK;

    int ic  = 0;
    Pointer = Line;
    while(ic<=icol)
    {
        if(IsEndOfLine()==true) return DefVal;

        if(IsBeginItem()==true)
        {
            if(ic==icol) return GetNextDouble(DefVal);
            ic++;
        }
        Pointer++;
    }
    return DefVal;
}

int UAnalyzeLine::GetCollumn_i(int icol, int DefVal)
/*
    Get the icol-th item on the line and convert it to int.
    A string or a non-existent item is converted to 0, but the error flag is set,
    
    The function starts looking from the beginning of the line.
 */
{
    error   = U_OK;

    int ic  = 0;
    Pointer = Line;
    while(ic<=icol)
    {
        if(IsEndOfLine()==true) return DefVal;

        if(IsBeginItem()==true)
        {
            if(ic==icol) return GetNextInt(DefVal);
            ic++;
        }
        Pointer++;
    }
    return DefVal;
}

bool UAnalyzeLine::StringInComment(const char* String)
/*
     return true iff the String[] is contained in the comments part of Line[].
     if Line[] does not contain comments at all, return false.

     This function does not change the Pointer;
 */
{
    const char* OldPointer = Pointer;
    
    for(Pointer = Line; Pointer <Line+Maxchar-1; Pointer++)
        if(IsComment(true)==true)
        {
            Pointer = OldPointer;
            if(strstr(Pointer,String)) return true;
            else                       return false;
        }

    Pointer = OldPointer;
    return false;
}

bool UAnalyzeLine::IsStartList(const char* ListName, bool IgnoreCase)
/*
    return true iff Line[] contains (before comment signs) optional separators, followed by 
    the string ListName[], followed by optional separators, followed by '=' followed by optional
    separators, followed by '{'
 */
{
    if(IsIdentifierIs(ListName, IgnoreCase)==false) return false;

    while(IsEndOfLine()==false && IsSeparator(*Pointer)==true) Pointer++;
    if(IsEndOfLine()==true) return false;

    if(IsBracketOpen(*Pointer)==true) 
    {
        Pointer++;
        return true;
    }
    return false;
}

bool UAnalyzeLine::IsEndList(void)
/*
    return true iff Line[] contains (before comment signs) optional separators, followed by '}'
 */
{
    while(IsEndOfLine()==false && IsSeparator(*Pointer)==true) Pointer++;
    if(IsBracketClose(*Pointer)==true) return true;

    if(IsEndOfLine()==true) return false;

    if(IsBracketClose(*Pointer)==true) 
    {
        Pointer++;
        return true;
    }
    return false;
}