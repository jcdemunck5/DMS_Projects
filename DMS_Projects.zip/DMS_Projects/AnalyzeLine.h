#ifndef _ANALYZELINE_INCLUDED
#define _ANALYZELINE_INCLUDED

#include "BasicInclude.h"

#define MAXLINESTRING 256

class DLL_IO UAnalyzeLine
{
public:
    UAnalyzeLine(const char *line=NULL, int maxch=-1);
    UAnalyzeLine(const UAnalyzeLine& AA);
    UAnalyzeLine& operator=(const UAnalyzeLine& AA);

    ErrorType         GetError(void) const {return error;}

    int               GetNcharRead(void) const {return int(Pointer-Line);}
    virtual bool      IsSeparator(char c) const;
    bool              IsComment(bool StartFromPointer=false) const;
    bool              IsCommentLine(const char* CommentString=NULL, bool IgnoreLeadingSeparators=false);
    bool              IsEmptyLine() const;
    ErrorType         SkipComments(void);

    int               GetNextInt(int def=0);
    int               GetIdentifierInt(const char* Identifier, bool IgnoreCase=false, int def=0);
    float             GetNextFloat(float def=0);
    double            GetNextDouble(double def=0);
    bool              GetNextBool(bool def=false);
    const char*       GetNextString(int maxstring, const char *def=NULL);
    const char*       GetNextFileName(int maxstring, const char *def=NULL);
    int               GetNString(void);
    int               GetNCollumn(void);
    int               GetCollumn(const char* ColName, const char* SkipName1=NULL, const char* SkipName2=NULL, const char* SkipName3=NULL);
    double            GetCollumn_d(int icol, double DefVal);
    int               GetCollumn_i(int icol, int DefVal);
    bool              IsIdentifier(const char* Identifier, bool IgnoreCase=false);
    bool              IsIdentifierInLine(const char* Identifier, bool IgnoreCase=false);
    bool              IsIdentifierIs(const char* Identifier, bool IgnoreCase=false);
    bool              IsIdentifierIsInLine(const char* Identifier, bool IgnoreCase=false);
    bool              StringInComment(const char* String);
    bool              IsStartList(const char*ListName, bool IgnoreCase=false);
    bool              IsEndList(void);
    const char*       GetPointer(void) const {return Pointer;}
    ErrorType         MoveToCollumn(int icol);
    ErrorType         MoveToChar(char c);
    ErrorType         MoveToBegin();
    static ErrorType  ConvertChar(char*line, char cin, char cout, int MaxTimes=-1);

protected:
    ErrorType         error;         // General error flag
    const char       *Pointer;       // Pointer to that part of the line that is currently to be analyzed

private:
    const char       *Line;          // Line to be analyzed
    int               Maxchar;       // Maximum number of characters of Line[] to be analyzed

    bool              IsBeginItem(void) const;
    bool              IsEndItem(void) const;
    bool              IsEndOfLine(void);
    bool              IsIs(char c) const;
    bool              IsQuote(char c) const;
    bool              IsQuote1(char c) const;
    bool              IsQuote2(char c) const;
    bool              IsFileChar(char c) const;
    bool              IsNumber(char c) const;
    bool              IsDoubleChar(char c) const;
    bool              IsGoodDouble(const char* Pnt) const;
    bool              IsGoodFloat(const char* Pnt) const  {return IsGoodDouble(Pnt);}
    bool              IsBracketOpen(char c) const;
    bool              IsBracketClose(char c) const;
    char              ToUpper(char c) const;
};

#endif//_ANALYZELINE_INCLUDED
