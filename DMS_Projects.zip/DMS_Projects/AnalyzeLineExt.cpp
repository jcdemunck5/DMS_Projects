/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for reading "Extended" Datastructures, or objects consisting of    */
/*     more than one int, double or float, from a line.                          */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    19-12-98	creation
  Jdm    21-12-98   BUG FIX: GetNextDipole(), reading symmetric dipoles
AdJ/Jdm  19-01-99   Added GetNextVector3(), and used it in GetNextDipole()
AdJ/Jdm  15-04-99   Added virtual IsSeparator()
  JdM    29-01-00   compatibility with the Borland compiler (system includes first)
  JdM    23-03-00   Added GetNextVector3List()
                    Redefine IsSeparator()
  JdM    28-06-00   Move UAnalyzeLineExt::GetNextDipole() to dipole.cpp
  JdM    04-09-00   Added operator=() and GetDipole()
  JdM    16-01-01   Move GetDipole() to Dipole.cpp
  JdM    04-01-05   Added copy constructor
*/

#include<string.h>
#include"AnalyzeLineExt.h"

UAnalyzeLineExt::UAnalyzeLineExt(const char *line, int maxch) :
    UAnalyzeLine(line, maxch)
{
}

UAnalyzeLineExt::UAnalyzeLineExt(const UAnalyzeLineExt& AA) :
    UAnalyzeLine((UAnalyzeLine)AA)
{
}

UAnalyzeLineExt& UAnalyzeLineExt::operator=(const UAnalyzeLineExt& AA)
/* 
  Assignment operator
*/
{
    UAnalyzeLine::operator=((UAnalyzeLine) AA);
    return *this;
}


bool UAnalyzeLineExt::IsSeparator(char c) const
/*
      When analyzing Line[], it is assumed that the relevant items are separated by
      socalled "separator" character (e.g. SPACE, TAB, o, etc).

      return true iff c is such a separator character.

      Note: this version of IsSeparator also defines '(' and ')' as separators
 */
{
    if(c<=' '||c=='('||c==')'||c==','||c==';'||c=='|'||127<=c) return true;
    
    return false;
}


UVector3 UAnalyzeLineExt::GetNextVector3(void)
{
    UVector3 x;
    x.Setx(GetNextDouble());
    x.Sety(GetNextDouble());
    x.Setz(GetNextDouble());

    return x;
}


#define MAXLINE 256
UVector3* GetNextVector3List(FILE* fp, const char* ListName, int* Nvect)
/*
    Read a list of UVector3-objects from an opened (ASCII) file.
    Reading starts from the given file pointer fp.
    A line containing 'ListName[] = {' is expected. Then the first UVector3 object
    is to be stored on the next line and each subsequent UVector3 is on a separate line.
    The UVector3-list should be closed with the '}' symbol, placed on a separate line.
    Pure comment lines are skipped.

    On error, a message is printed to the log-file, NULL is returned and the file pointer
    is set to the old one.

    On succes, a pointer to a new array is returned, *Nvect will contain the number of 
    Vector3-objects in the list.
 */
{
    if(fp==NULL) return NULL;

    long oldPointer = ftell(fp);
    
/* Seek the List named ListName[] and count the number of UVector3-elements*/
    *Nvect = 0;
    long startList = -1;
    char line[MAXLINE];
    bool EndFound = false;
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLineExt AA(line, MAXLINE);
        if(AA.IsComment() == true)  continue;
        if(AA.IsStartList(ListName)==true)
        {
            startList = ftell(fp);
            while(GetLine(line, MAXLINE, fp))
            {
                UAnalyzeLineExt AA(line, MAXLINE);
                if(AA.IsComment() == true)  continue;
                if(AA.IsEndList() == true) 
                {
                    EndFound=true;
                    break;
                }
                (*Nvect)++;
            }
        }
    }
    if(startList==-1)
    {
        CI.AddToLog("WARNING: GetNextVector3List(). List Identifier '%s' not found.\n",ListName);
        fseek(fp, oldPointer, SEEK_SET);            
        return NULL;
    }
    if(*Nvect==0)
    {
        CI.AddToLog("WARNING: GetNextVector3List(). List with Identifier '%s' does not contain data.\n",ListName);
        fseek(fp, oldPointer, SEEK_SET);            
        return NULL;
    }
    if(EndFound==false)
    {
        CI.AddToLog("WARNING: GetNextVector3List(). End of list with Identifier '%s' not found.\n",ListName);
        fseek(fp, oldPointer, SEEK_SET);            
        return NULL;
    }

    UVector3* Vector3Array = new UVector3[*Nvect];
    if(Vector3Array==NULL)
    {
        CI.AddToLog("ERROR: GetNextVector3List(). Memory allocation.\n");
        fseek(fp, oldPointer, SEEK_SET);            
        return NULL;
    }

/* Goto start and read the data.*/
    int ivect = 0;
    fseek(fp, startList, SEEK_SET);
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLineExt AA(line, MAXLINE);

        if(AA.IsComment() == true) continue;
        if(AA.IsEndList() == true) break;
        Vector3Array[ivect++] = AA.GetNextVector3();
    }
    return Vector3Array;
}