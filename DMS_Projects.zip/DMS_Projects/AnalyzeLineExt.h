#ifndef _ANALYZELINEEXT_INCLUDED
#define _ANALYZELINEEXT_INCLUDED

#include "AnalyzeLine.h"
#include "Dipole.h"


class DLL_IO UAnalyzeLineExt: public UAnalyzeLine
{
public:
    UAnalyzeLineExt(const char *line=NULL, int maxch=-1);
    UAnalyzeLineExt(const UAnalyzeLineExt& AA);
    UAnalyzeLineExt& operator=(const UAnalyzeLineExt& AA);

    UDipole   GetDipole(int icol);
    UDipole   GetNextDipole(void);
    UVector3  GetNextVector3(void);

private:
    bool      IsIs(char c);
    bool      IsSeparator(char c) const;
};


UVector3*     GetNextVector3List(FILE* fp, const char* ListName, int* Nvect);
bool          AreLabelsEqual(const USensor& S1, const USensor& S2);


#endif// _ANALYZELINEEXT_INCLUDED
