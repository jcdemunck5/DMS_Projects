/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*  The purpose of this object is to write commands in the ConQuest Viewer          */
/*  format, to annotate points, plot vectors, and color points                      */
/*                                                                                  */
/*  To create an annotated XXX.structure directory of which the annotations can be  */
/*  visualized with the ConQuest Viewer, create a U_IRREGULAR UField, with U_BYTE   */
/*  data, having a veclen of at least UAnnotateConQuest::MAXPLOTBUFFER. Then, for   */
/*  each point of that UField, get the pointer to the unsigned char data            */
/*  corresponding to that point:                                                    */
/*                                                                                  */
/*   (UField::GetBdata()+ipoint*UAnnotateConQuest::MAXPLOTBUFFER)                   */
/*                                                                                  */
/*  and pass this pointer to the annotation fuctions of UAnnotateConQuest() that you*/ 
/*  wish to use.                                                                    */
/*                                                                                  */
/*   Plot format:                                                                   */
/*    Cxxx    : set Color (rgb) default black                                       */
/*    Bxxx    : set Background color (for annotations only) (rgb) default white     */
/*    Wx      : set line Width (x 0.1 mm), default 1                                */
/*    Yx      ; set sYmbol size (x 0.1 mm), default 20                              */
/*    P       : draw Point (solid circle)                                           */
/*    MXX     : Move cursor relative in 2D (x, y in 0.1 mm)                         */
/*    DXX     : Draw relative in 2D (x, y in 0.1 mm)                                */
/*    VXXX    : move projected 3D Vector (x, y, z in 0.1 mm) in viewing plane       */
/*    JXXX    : draw proJected 3D vector (x, y, z in 0.1 mm) in viewing plane       */
/*    Ttext0  : draw annotation Text (does not move cursor) (0 stands for NULL-byte)*/
/*    Sx      : draw various Symbols (x=symbol .^v+-|*O or > pointed arrowhead)     */
/*    >       : conditional draw following if before screen (useful with arrowhead) */
/*    <       : conditional draw following if behind screen                         */
/*    default : draw annotation text                                                */
/*                                                                                  */
/*                                                                                  */
/*  Jan C. de Munck                                                                 */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    13-03-01   creation 
  JdM    26-04-02   created by renaming DipoleMoveList.cpp (illogical name)
*/


#include <string.h>
#include <stdlib.h>
#include "AnnotateConQuest.h"
#include "Euler.h"

/* Inititalize static const parameters. */
const int UAnnotateConQuest::MAXPLOTBUFFER = 128;

UAnnotateConQuest::UAnnotateConQuest()
{
}

UAnnotateConQuest::~UAnnotateConQuest()
{
}

int UAnnotateConQuest::PlotVector(char* PlotString, UVector3 Dir, UColor rgb) const
{
    if(PlotString==NULL) return 0;
    memset(PlotString, 0, MAXPLOTBUFFER);

    int nc = 0;
    nc += SetColor     (PlotString+nc, rgb);
    nc += SetSymbolSize(PlotString+nc, .3);   
    nc += SetSymbol    (PlotString+nc, -1);
    nc += SetLineWidth (PlotString+nc, .2);
    nc += DrawProjected(PlotString+nc, Dir.Getx(),  Dir.Gety(), Dir.Getz());

    PlotString[nc  ] = '>';
    PlotString[nc+1] = 'S';
    PlotString[nc+2] = '>';
    PlotString[nc+3] = '<';

    return nc;
}

int UAnnotateConQuest::PlotVector(char* PlotString, UVector2 Dir, UColor rgb) const
{
    if(PlotString==NULL) return 0;
    memset(PlotString, 0, MAXPLOTBUFFER);

    PlotString[ 0] = 'C';
    PlotString[ 1] =  rgb.GetR();
    PlotString[ 2] =  rgb.GetG();
    PlotString[ 3] =  rgb.GetB();
    PlotString[ 4] = 'J';
    PlotString[ 5] = DoubleToChar(Dir.Getx()*127);
    PlotString[ 6] = DoubleToChar(Dir.Gety()*127);
    PlotString[ 7] = '>';
    PlotString[ 8] = 'S';
    PlotString[ 9] = '>';
    PlotString[10] = '<';
    PlotString[11] = 'S';
    PlotString[12] = '.';

    return 13;
}

int UAnnotateConQuest::PlotDot(char* PlotString, UColor rgb) const
{
    if(PlotString==NULL) return 0;
    memset(PlotString, 0, MAXPLOTBUFFER);

    int nc = 0;
    nc += SetColor     (PlotString+nc, rgb);
    nc += SetSymbolSize(PlotString+nc, .3);   
    nc += SetSymbol    (PlotString+nc, -1);

    return nc;
}

int UAnnotateConQuest::PlotConfInterval(char* PlotString, const UEuler* xfm, UVector3 Delta, UColor rgb) const
{
    if(PlotString==NULL) return 0;
    memset(PlotString, 0, MAXPLOTBUFFER);

    int nc = 0;
    nc += SetColor     (PlotString+nc, rgb);
    nc += SetSymbolSize(PlotString+nc, .3);   
    nc += SetSymbol    (PlotString+nc, -1);
    nc += SetLineWidth (PlotString+nc, .2);
    
    UVector3 x = xfm->xfm(UVector3(Delta.Getx(), 0., 0.), true);
    nc += DrawProjected(PlotString+nc, x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc, x);
    
    x = xfm->xfm(UVector3(0., Delta.Gety(), 0.), true);
    nc += DrawProjected(PlotString+nc, x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc, x);

    x = xfm->xfm(UVector3(0., 0., Delta.Getz()), true);
    nc += DrawProjected(PlotString+nc, x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc,-x);
    nc += DrawProjected(PlotString+nc, x);
    
    if(nc>=MAXPLOTBUFFER-1)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::PlotConfInterval(). PlotString overflow: nc=%d\n",nc);
        PlotString[MAXPLOTBUFFER-1] = 0;
    }
    return nc;
}

int UAnnotateConQuest::PlotConfInterval(char* PlotString, UVector2 Delta, UColor rgb) const
{
    if(PlotString==NULL) return 0;
    memset(PlotString, 0, MAXPLOTBUFFER);

    PlotString[ 0] = 'Y';
    PlotString[ 1] = 10;
    PlotString[ 2] = 'C';
    PlotString[ 3] =  rgb.GetR();
    PlotString[ 4] =  rgb.GetG();
    PlotString[ 5] =  rgb.GetB();
    PlotString[ 6] = 'S';
    PlotString[ 7] = '0';
    PlotString[ 8] = 'W';
    PlotString[ 9] = 3;
    PlotString[10] = 'V';
    PlotString[11] = DoubleToChar(-Delta.Getx()*100.);
    PlotString[12] = 0;
    PlotString[13] = 'J';
    PlotString[14] = DoubleToChar( Delta.Getx()*100.);
    PlotString[15] = 0;

    PlotString[16] = 'V';
    PlotString[17] = 0;
    PlotString[18] = DoubleToChar(-Delta.Gety()*100.);
    PlotString[19] = 'J';
    PlotString[20] = 0;
    PlotString[21] = DoubleToChar( Delta.Gety()*100.);

    return 22;
}

int UAnnotateConQuest::AddAnnotation(char* PlotString, const char* Text, int Maxchar)
{
    if(PlotString==NULL) return 0;
    if(Text==NULL)       return 0;
    if(Maxchar>=0 && Maxchar<6) return 0;
        
    size_t maxbyte = strlen(Text) + 2;
    if(Maxchar>=0) maxbyte = Maxchar;

    memset(PlotString, 0, Maxchar);
    int nc   = SetBackGroundColor(PlotString, UColor(0,0,0));
    maxbyte -= nc;

    PlotString[nc] = 'T';
    strncpy(PlotString+nc+1, Text, maxbyte);
    return int(maxbyte);
}

int UAnnotateConQuest::AddAnnotation(char* PlotString, double Number, const char* format, int Maxchar)
{
    if(PlotString==NULL) return 0;

    int  nc = 0;
    char string[20];
    if(format)
    {
        nc += sprintf(string, format, Number);
    }
    else
    {
        nc += sprintf(string, "%f", Number);
    }
    if(nc>=sizeof(string)) 
    {
        CI.AddToLog("ERROR: UAnnotateConQuest::AddAnnotation(). Illegal format string : %s .\n",format);
        return 0;
    }
    if(nc+2>Maxchar)
    {
        CI.AddToLog("ERROR: UAnnotateConQuest::AddAnnotation(). To few characters: nc = %d Maxchar = %d.\n",nc,Maxchar);
        return 0;
    }
    return AddAnnotation(PlotString, string, Maxchar);
}

signed char UAnnotateConQuest::DoubleToChar(double Value) const
{
    if(Value>= 126.5) return (signed char) 127;
    if(Value<=-126.5) return (signed char)-127;

    return (signed char) floor(Value+.5);
}

int UAnnotateConQuest::MoveProjected(char* PlotString, double x, double y, double z) const
{
    PlotString[0] = 'V';
    PlotString[1] = DoubleToChar(100*x);
    PlotString[2] = DoubleToChar(100*y);
    PlotString[3] = DoubleToChar(100*z);
    return 4;
}

int UAnnotateConQuest::DrawProjected(char* PlotString, double x, double y, double z) const
{
    PlotString[0] = 'J';
    PlotString[1] = DoubleToChar(100*x);
    PlotString[2] = DoubleToChar(100*y);
    PlotString[3] = DoubleToChar(100*z);
    return 4;
}

int UAnnotateConQuest::MoveProjected(char* PlotString, UVector3 x) const
{
    return MoveProjected(PlotString, x.Getx(), x.Gety(), x.Getz());
}

int UAnnotateConQuest::DrawProjected(char* PlotString, UVector3 x) const
{
    return DrawProjected(PlotString, x.Getx(), x.Gety(), x.Getz());
}

int UAnnotateConQuest::SetColor(char* PlotString, UColor rgb) const
{
    PlotString[0] = 'C';
    PlotString[1] = rgb.GetR();
    PlotString[2] = rgb.GetG();
    PlotString[3] = rgb.GetB();
    return 4;
}

int UAnnotateConQuest::SetBackGroundColor(char* PlotString, UColor rgb) const
{
    PlotString[0] = 'B';
    PlotString[1] = rgb.GetR();
    PlotString[2] = rgb.GetG();
    PlotString[3] = rgb.GetB();
    return 4;
}

int UAnnotateConQuest::SetLineWidth(char* PlotString, double Width_cm) const
{
    PlotString[0] = 'Y';
    PlotString[1] =  DoubleToChar(100*fabs(Width_cm));
    return 2;
}

int UAnnotateConQuest::SetSymbolSize(char* PlotString, double Size_cm) const
{
    PlotString[0] = 'Y';
    PlotString[1] =  DoubleToChar(100*fabs(Size_cm));
    return 2;
}

int UAnnotateConQuest::SetSymbol(char* PlotString, char isymbol) const
{
    if(isymbol=='^' ||
       isymbol=='v' ||
       isymbol=='+' ||
       isymbol=='-' ||
       isymbol=='|' ||
       isymbol=='*' ||
       isymbol=='O' ||
       isymbol=='>' )
    {
        PlotString[0] = 'S';
        PlotString[1] =  isymbol;
        return 2;
    }
    PlotString[0] = 'P';
    return 1;
}
