#ifndef _ANNOTATECONQUEST_INCLUDED
#define _ANNOTATECONQUEST_INCLUDED

#include "Color.h"
#include "MatVec.h"

class UEuler;

class DLL_IO UAnnotateConQuest
{
public:
    enum ProjType {U_NOP,       //  No projection (3D-dipole)
                   U_PX,        //  Project dipole in x-plane
                   U_PY,        //  Project dipole in y-plane
                   U_PZ};       //  Project dipole in z-plane
    
    enum PlotType {U_DOT,       //  Plot dipole as dot
                   U_DOT_TIME,  //  Plot dipole as dot, with absolute time as annotation
                   U_VECTOR,    //  Plot dipole as vector
                   U_CONFINT};  //  Plot dipole confidence interval (only works in derived class)

    static const int MAXPLOTBUFFER;

    UAnnotateConQuest();
    virtual ~UAnnotateConQuest();

    int         PlotVector(char* PlotString, UVector3 Dir, UColor rgb) const;
    int         PlotVector(char* PlotString, UVector2 Dir, UColor rgb) const;
    int         PlotDot(char* PlotString, UColor rgb) const;
    int         PlotConfInterval(char* PlotString, const UEuler* xfm, UVector3 Delta, UColor rgb) const;
    int         PlotConfInterval(char* PlotString, UVector2 Delta, UColor rgb) const;
    int         AddAnnotation(char* PlotString, const char* Text, int Maxchar);
    int         AddAnnotation(char* PlotString, double Number, const char* format, int Maxchar);

private:
    signed char DoubleToChar(double Value) const;
    int         MoveProjected(char* PlotString, double x, double y, double z) const;
    int         DrawProjected(char* PlotString, double x, double y, double z) const;
    int         MoveProjected(char* PlotString, UVector3 x) const;
    int         DrawProjected(char* PlotString, UVector3 x) const;
    int         SetBackGroundColor(char* PlotString, UColor rgb) const;
    int         SetColor(char* PlotString, UColor rgb) const;
    int         SetLineWidth(char* PlotString, double Width_cm) const;
    int         SetSymbolSize(char* PlotString, double Size_cm) const;
    int         SetSymbol(char* PlotString, char isymbol) const;
};

#endif // _ANNOTATECONQUEST_INCLUDED
