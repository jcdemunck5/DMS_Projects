/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    27-11-05   creation, copied from QScanXFMView3D.cpp
  JdM    11-02-06   Added ChangePointRef()
  JdM    12-02-06   bug fix: GetPointRef(): case index<0
  JdM    04-04-06   Bug Fix: TransformCenter(). swap UEuler(-Center) and XFMtoREF;
  JdM    17-08-06   Bug fix: UAnnotatedPointList::UAnnotatedPointList(). Test and skip prsence of indentifier "XYZFile1.0"
  JdM    17-10-06   Added GetAnnotationIndex(). 
                    SavePoints(). Safe points in XFM coordinates i.s.o. Reference coordinates.
                    Added SavePointsRef(). Safes points in reference coordinates.
                    Added GetPointsText(). GetProperties(): removed list of points.
  JdM    05-11-06   Added ReadAsPolhemusFile() and ReadAsPointFile() and applied this in constructor. 
  JdM    08-01-07   ReadAsPolhemusFile(): Added timestamp algorithm
                    Added GetMedianPoint()
  JdM    31-01-07   Added GetPointXfm() and GetCurrentPointXfm()
  JdM    24-02-07   Added HasNLRPoints() 
  JdM    06-03-07   Added RemoveCurrentPoint()
  JdM    17-03-07   ReadAsFindCoilsFile(): test "nas","lef" and "rig" labels and convert to "Nasion", "Left" and "Right"
  JdM    10-05-07   Added UField-constructor
  JdM    03-01-08   Added IsCTFDipFile() and ReadAsCTFDipFile()
  JdM    06-01-08   Added GetPLAsFieldRef()
  JdM    02-08-08   Added and used ReadAsCTFSensors() in constructor
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    19-09-08   ReadAsCTFDipFile():  Read residual error.
                    UAnnotatedPoint:     Added value array and selection bool
                    UAnnotatedPointList: Selection functions, based of multiple values (eg time and res error in case of CTF dipole files)
  JdM    23-04-09   GetPointsText(): Added arguments.
KS/JdM   05-05-09   Bug Fix: GetPointsText(). Only value of first point was printed.
                    Reading VarNames[] and values from .xyz files
  JdM    01-12-09   Added DoesAnnotationExist()
                    BUG FIX: RemoveCurrentPoint(). Removing the wrong point! (current i.s.0. ip)
  JdM    25-12-09   Added ForceInBox()
  JdM    26-12-09   Added SetNewXfmCoords()
  JdM    30-12-09   Added SortAnnotation() and GetPointListRef()
  JdM    18-02-10   Added ReadAsFiffFile()
  JdM    04-03-10   Added SortValues()
  JdM    13-06-10   Added ReadAsFiffDipFile()
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    21-08-10   Added GetValue()
  JdM    22-08-10   Added AddPointRef()
  JdM    24-08-10   Made IsPolhemusFile(),IsFindCoilsFile(), IsCTFDipFile() static
  JdM    26-08-10   ReadAsFiffDipFile(). Keep dipoles in NLR_FIFF coordinates.
  JdM    31-10-10   Added GetDistanceTable()
                    Added SetAnnotation()
  JdM    13-03-11   ReplacePointRef() and RemovePoint()
  JdM    28-09-11   Made GetProperties() virtual
  JdM    09-01-13   Added SetVarNames()
  JdM    29-01-14   UAnnotatedPointList(). Added more gemeral UFileName constroctor and used it in the existing one.
  JdM    22-02-14   Added DeleteDoublePoints()
  JdM    18-01-14   UAnnotatedPointList(). UFileName constroctor, added reading of .asc file
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    06-08-15   Added iVarUNK_BAD_OK data member to keep track of special ivar component that can be used for "Unkown", "BAD" and "OK"
                    Added UAnnotatedPointList::SetValue() and UAnnotatedPointList::AddVar()
  JdM    24-10-15   Added WriteVTK()
  JdM    20-07-18   HasNLRPoints(). Changed definition of Left and Right marker. Added this info to properties.
  JdM    08-09-18   Added GetNLRAsPointListRef().
  JdM    11-09-18   Added UnselectNLR() and GetIndexSelected()
*/

#include <string.h>

#include "AnnotatedPointList.h"
#include "AnalyzeLineExt.h"
#include "SortSemiSort.h"
#include "Sensor.h"
#include "Surface.h"
#include "Field.h"
#include "MEEGDataCTF.h"
#include "MEEGDataFIFF.h"

UString UAnnotatedPointList::Properties = UString();

void UAnnotatedPoint::SetAllMembersDefault(void)
{
    p          = UVector3();
    Annotation = UString();
    Value[0]   = 0.;
    Value[1]   = 0.;
    Value[2]   = 0.;
    Selected   = true;
}

UAnnotatedPoint::UAnnotatedPoint()
{
    SetAllMembersDefault();
}
UAnnotatedPoint::UAnnotatedPoint(const UAnnotatedPoint& x)
{
    SetAllMembersDefault();
    *this = x;
}

UAnnotatedPoint::UAnnotatedPoint(UVector3 x, UString Annot, double V0, double V1, double V2)
{
    SetAllMembersDefault();

    p          = x;
    Annotation = Annot;
    Value[0]   = V0;
    Value[1]   = V1;
    Value[2]   = V2;
}

UAnnotatedPoint& UAnnotatedPoint::operator=(const UAnnotatedPoint& x)
{
    if(this==&x) return *this;
    if(this==NULL)
    {
        static UAnnotatedPoint Def;
        return Def;
    }

    SetAllMembersDefault();

    p          = x.p;
    Annotation = x.Annotation;
    for(int k=0; k<MAXDOUBVAR; k++) Value[k] = x.Value[k];
    Selected   = x.Selected;
    return *this;
}

ErrorType UAnnotatedPoint::SetAnnotation(UString Annot)
{
    Annotation = Annot;
    return Annotation.GetError();
}
double UAnnotatedPoint::GetValue(int ival) const
{
    if(ival<0 || ival>=MAXDOUBVAR) return 0;
    return Value[ival];
}
ErrorType UAnnotatedPoint::SetValue(int ival, double Val)
{
    if(ival<0 || ival>=MAXDOUBVAR) return U_ERROR;
    Value[ival] = Val;
    return U_OK;
}
ErrorType UAnnotatedPoint::SelectInRange(int ival, double MinVal, double MaxVal)
{
    if(ival<0 || ival>=MAXDOUBVAR) return U_ERROR;
    if(MaxVal<MinVal)              return U_ERROR;
    
    if(MinVal<=Value[ival] && Value[ival]<=MaxVal) Selected = true;
    else                                           Selected = false;
    return U_OK;
}
ErrorType UAnnotatedPoint::SelectInRange(int NVal, const double* MinVal, const double* MaxVal)
{
    if(NVal   <0    || NVal   >MAXDOUBVAR) return U_ERROR;
    if(MinVal==NULL || MaxVal==NULL      ) return U_ERROR;

    Selected = true;
    for(int k=0; k<NVal; k++)
        if(Value[k]<MinVal[k] || MaxVal[k]<Value[k]) 
        {
            Selected = false;
            break;
        }

    return U_OK;
}

void UAnnotatedPointList::SetAllMembersDefault(void)
{
    error            = U_OK;
    Name             = UString();
    Properties       = UString();
    plistXFM         = NULL;
    Npoints          = 0;
    NpointsAllocated = 0;
    current          = 0;
    NDoubVar         = 0;
    for(int k=0; k<MAXDOUBVAR; k++) VarName[k] = UString();
    iVarUNK_BAD_OK   = -1;
    XFMtoREF         = ULinTran();
}

void UAnnotatedPointList::DeleteAllMembers(ErrorType E)
{
    delete[] plistXFM;
    SetAllMembersDefault();
    error   = E;
}

UAnnotatedPointList::UAnnotatedPointList()
{
    SetAllMembersDefault();
    Name = UString("NoName");
}

UAnnotatedPointList::UAnnotatedPointList(UString PLName)
{
    SetAllMembersDefault();
    Name = PLName;
}

UAnnotatedPointList::UAnnotatedPointList(const UField* PList)
{
    SetAllMembersDefault();
    if(PList==NULL || PList->GetError()!=U_OK)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). NULL or erroneous UField* argument.\n");
        return;
    }
    if(PList->GetNspace()!=3)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). UField argument of wrong type (%s).\n", PList->GetProperties(""));
        return;
    }
    Name       = "PointList";
    int   Np   = PList->GetNpoints();
    int   Vl   = PList->GetVeclen();

    NDoubVar   = MIN(MAXDOUBVAR, Vl);
    double Var[MAXDOUBVAR];
    for(int k=0; k<MAXDOUBVAR; k++) 
    {
        Var[k]     = 0.;
        VarName[k] = UString(k, "Comp_%d");
    }

    for(int n=0; n<Np; n++)       
    {
        UString Annot = UString(n, " Index=%d");
        
        switch(PList->GetDType())
        {
        case UField::U_BYTE:
            {
                const unsigned char* MinMax = PList->GetBdata();
                if(MinMax==NULL) break;
                Annot += UString((int)MinMax[n*Vl]," Intens = %d");
                for(int k=0; k<NDoubVar; k++)  Var[k] = MinMax[n*Vl+k];
                break;
            }
        case UField::U_SHORT:
            {
                const short* MinMax = PList->GetSdata();
                if(MinMax==NULL) break;
                Annot += UString((int)MinMax[n*Vl]," Intens = %d");
                for(int k=0; k<NDoubVar; k++)  Var[k] = MinMax[n*Vl+k];
                break;
            }
        case UField::U_INTEGER:
            {
                const int* MinMax = PList->GetIdata();
                if(MinMax==NULL) break;
                Annot += UString((int)MinMax[n*Vl]," Intens = %d");
                for(int k=0; k<NDoubVar; k++)  Var[k] = MinMax[n*Vl+k];
                break;
            }
        case UField::U_FLOAT:
            {
                const float* MinMax = PList->GetFdata();
                if(MinMax==NULL) break;
                Annot += UString((double)MinMax[n*Vl]," Intens = %g");
                for(int k=0; k<NDoubVar; k++)  Var[k] = MinMax[n*Vl+k];
                break;
            }
        case UField::U_DOUBLE:
            {
                const double* MinMax = PList->GetDdata();
                if(MinMax==NULL) break;
                Annot += UString((double)MinMax[n*Vl]," Intens = %g");
                for(int k=0; k<NDoubVar; k++)  Var[k] = MinMax[n*Vl+k];
                break;
            }
        }

        UVector3 Pnt = PList->GetPoint(n);
        if(AddPoint(Pnt, Annot, Var)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). Adding Point %d .\n", n);
            return;
        }
    }
    UpdateVarUNK_BAD_OK();
}

UAnnotatedPointList::UAnnotatedPointList(UFileName FNameXFM, ULinTran X2R)
{
    SetAllMembersDefault();
    if(FNameXFM.DoesFileExist()==false)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). File does not exist: Filename = %s  \n",(const char*)FNameXFM);
        return;
    }

    bool CenterPoints = false;
    if(IsStringCompatible(FNameXFM.GetExtension(), "fiff", false) ||
       IsStringCompatible(FNameXFM.GetExtension(), "fif" , false))
    {
        if(ReadAsFiffFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as FIFF file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(IsStringCompatible(FNameXFM.GetExtension(), "bdip", false)==true)
    {
        if(ReadAsFiffDipFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as FIFF dipole file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(FNameXFM.HasExtension("res4")==true || FNameXFM.HasExtension("meg4")==true)
    {
        if(ReadAsCTFSensors(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as sensors from CTF file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(IsCTFDipFile(FNameXFM)==true)
    {
        if(ReadAsCTFDipFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as CTFDip file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(FNameXFM.HasExtension("asc")==true)
    {
        FILE* fp = fopen(FNameXFM, "rt", false);

        char line[1000];
        int ip = 0;
        while(GetLine(line, sizeof(line), fp))
        {
            ip++;
            if(ip%100) continue;
            UAnalyzeLine AA(line, sizeof(line));
            if(AA.IsEmptyLine()==true) continue;
            if(AA.IsComment()==true)   continue;

            double  x     = AA.GetNextDouble()/10; // Convert frm [mm] to [cm]
            double  y     = AA.GetNextDouble()/10;
            double  z     = AA.GetNextDouble()/10;
        
            UString Sname(ip, "P_%d");
            if(this->AddPoint(UVector3(x,y,z), Sname)!=U_OK)
            {
                fclose(fp);
                SetAllMembersDefault();
                error = U_ERROR;
                CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). Adding point from .asc file. \n");
                return;
            }
        }
        CenterPoints = true;
        fclose(fp);
    }
    else if(IsFindCoilsFile(FNameXFM)==true)
    {
        if(ReadAsFindCoilsFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as FindCoils file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(IsPolhemusFile(FNameXFM)==true)
    {
        if(ReadAsPolhemusFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as Polhemus file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(FNameXFM.HasExtension("elc", false)==true)
    {
        if(ReadAsElcFile(FNameXFM)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). FileName cannot be read as .elc file. File = %s  \n",(const char*)FNameXFM);
            return;
        }
    }
    else if(FNameXFM.HasExtension("xyz", false)==true)
    {
        FILE* fp = fopen(FNameXFM, "rt", false);

        char line[256];
        memset(line, 0, sizeof(line));
        GetLine(line, sizeof(line), fp);
        if(strncmp(line, "XYZFile1.0", 10))
        {
            fclose(fp);
            error = U_ERROR;
            CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). File of wrong type. First characters  = %s  (should be XYZFile1.0) \n",line);
            return;
        }

        while(GetLine(line, sizeof(line), fp))
        {
            UAnalyzeLine AA(line, sizeof(line));
            if(AA.IsEmptyLine()==true) continue;
            if(AA.IsComment()==true)
            {
                unsigned int MAXSTRING = sizeof(line)-4; 
                UAnalyzeLine AA(line+2, MAXSTRING);
                if(AA.IsIdentifierIsInLine("NValues", true)==true)
                    NDoubVar = AA.GetNextInt(0);
                if(NDoubVar>0 && AA.IsIdentifierIsInLine("Value0", true)==true)
                    VarName[0] = UString(AA.GetNextString(MAXSTRING, "DefComp0"));
                if(NDoubVar>1 && AA.IsIdentifierIsInLine("Value1", true)==true)
                    VarName[1] = UString(AA.GetNextString(MAXSTRING, "DefComp1"));
                if(NDoubVar>2 && AA.IsIdentifierIsInLine("Value2", true)==true)
                    VarName[2] = UString(AA.GetNextString(MAXSTRING, "DefComp2"));
                continue;
            }
            UString Sname = UString(AA.GetNextString(sizeof(line)-24));
            double  x     = AA.GetNextDouble();
            double  y     = AA.GetNextDouble();
            double  z     = AA.GetNextDouble();
        
            if(this->AddPoint(UVector3(x,y,z), Sname)!=U_OK)
            {
                fclose(fp);
                SetAllMembersDefault();
                error = U_ERROR;
                CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). Adding point. \n");
                return;
            }
            for(int iv=0; iv<NDoubVar; iv++)
            {
                double Val = AA.GetNextDouble(0.);
                plistXFM[Npoints-1].SetValue(iv, Val);
            }
        }
        fclose(fp);
    }
    else
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). File is not FindCoils or Polhemus File. FileName should have extension .xyz . File = %s  \n",(const char*)FNameXFM);
        return;
    }
    Name     = UString(FNameXFM.GetBaseName());    
    XFMtoREF = X2R;

    if(CenterPoints==true) CenterXFM();
    UpdateVarUNK_BAD_OK();
}

UAnnotatedPointList::UAnnotatedPointList(UFileName FNameXFM, UVector3 N, UVector3 L, UVector3 R)
{
    SetAllMembersDefault();
    if(FNameXFM.DoesFileExist()==false)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList::UAnnotatedPointList(). File does not exist: Filename = %s  \n",(const char*)FNameXFM);
        return;
    }

    UEuler X2R;
    if(IsStringCompatible(FNameXFM.GetExtension(), "fiff", false) ||
       IsStringCompatible(FNameXFM.GetExtension(), "fif" , false) ||
       IsStringCompatible(FNameXFM.GetExtension(), "bdip", false))
    {
        X2R.SetNLR_FIFF(N, L, R); X2R.Invert();
    }
    else
    {
        X2R.SetNLR_CTF (N, L, R); X2R.Invert();
    }
    *this = UAnnotatedPointList(FNameXFM, ULinTran(X2R));
}

UAnnotatedPointList::UAnnotatedPointList(const UAnnotatedPointList& PL)
{
    SetAllMembersDefault();
    *this = PL;
}

UAnnotatedPointList::~UAnnotatedPointList()
{
    DeleteAllMembers(U_OK);
}

UAnnotatedPointList& UAnnotatedPointList::operator=(const UAnnotatedPointList &PL)
{
    if(this==&PL) return *this;
    if(this==NULL)
    {
        static UAnnotatedPointList P; P.error = U_ERROR;
        CI.AddToLog("ERROR: UAnnotatedPointList& operator=(). this==NULL \n");
        return P;
    }
    if(&PL==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList& operator=(). Invalid NULL argument. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    
    error            = U_OK;
    Name             = PL.Name;
    plistXFM         = new UAnnotatedPoint[PL.NpointsAllocated];
    if(plistXFM==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UAnnotatedPointList& operator=(). Memory allocation, NpointsAllocated=%d   . \n", NpointsAllocated);
        return *this;
    }
    for(int n=0;n<PL.Npoints; n++) plistXFM[n] = PL.plistXFM[n];

    Npoints          = PL.Npoints;
    NpointsAllocated = PL.NpointsAllocated;
    current          = PL.current;
    XFMtoREF         = PL.XFMtoREF;
 
    NDoubVar         = PL.NDoubVar;
    iVarUNK_BAD_OK   = PL.iVarUNK_BAD_OK;
    for(int k=0; k<MAXDOUBVAR; k++) VarName[k] = PL.VarName[k];

    return *this;
}

ErrorType UAnnotatedPointList::UpdateVarUNK_BAD_OK()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Npoints==0) return U_OK;
    if(Npoints<0 || plistXFM==NULL) return U_ERROR;

    iVarUNK_BAD_OK = -1;
    for(int iv=0; iv<NDoubVar; iv++)
    {
        bool GoodBADcomp = true;
        for(int n=0; n<Npoints; n++)
        {
            if(plistXFM[n].GetValue(iv)==-1. || plistXFM[n].GetValue(iv)==0. || plistXFM[n].GetValue(iv)==1.) continue;
            
            GoodBADcomp = false;
            break;
        }
        if(GoodBADcomp)
        {
            iVarUNK_BAD_OK = iv;
            break;
        }
    }
    if(iVarUNK_BAD_OK>0)
    {
        VarName[iVarUNK_BAD_OK] = "GoodBAD";
        for(int n=0; n<Npoints; n++)
        {
            if(plistXFM[n].GetValue(iVarUNK_BAD_OK)==-1.) plistXFM[n].SetAnnotation("Unknown");
            if(plistXFM[n].GetValue(iVarUNK_BAD_OK)== 0.) plistXFM[n].SetAnnotation("BAD");
            if(plistXFM[n].GetValue(iVarUNK_BAD_OK)== 1.) plistXFM[n].SetAnnotation("OK");
            break;
        }
    }
    return U_OK;
}

const UString& UAnnotatedPointList::GetProperties(UString Comment) const
{    
    Properties = UString();
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UAnnotatedPointList-object or object NULL");
        return Properties;
    }
    bool HasNLR = HasNLRPoints(NULL, NULL, NULL);
    Properties  = UString(" Name          = ") + Name + UString(" \n")
                + UString(Npoints             ," Npoints          = %d    \n")
                + UString(NpointsAllocated    ," NpointsAllocated = %d    \n")
                + UString(GetNPointsSelected()," NpointsSelected  = %d    \n")
                + UString(current             ," CurrentPoint     = %d    \n")
                + UString(BoolAsText(HasNLR)  ," HasNLRmarkers    = %s    \n")
                + UString(" \n")
                + UString(" XFMtoREF matrix: \n")
                + UString(XFMtoREF.PrintMatrix());

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

const UString& UAnnotatedPointList::GetPointsText(bool ConvertRef, bool AllPoints, bool Values) const
{
    Properties = UString();
    if(plistXFM==NULL) 
    {
        Properties += UString(" plistXFM        = NULL \n");
    }
    else
    {
        if(AllPoints) Properties += UString("// All points (selected and non-select). \n");
        else          Properties += UString("// Selected points. \n");
        if(Values)
        {
            Properties += UString(NDoubVar, "//   NValues = %d \n");
            for(int n=0; n<NDoubVar; n++)
            {
                Properties += UString(n, "//   Value%d = ");
                Properties += VarName[n].GetFirstLine();
                Properties += UString(" \n");
            }
        }
        ULinTran Transform;
        if(ConvertRef==true)
        {
            Properties += UString("// Points in reference coordinates: \n");
            Transform   = XFMtoREF;
        }
        else
        {
            Properties += UString("// Points in xfm coordinates: \n");
        }
        Properties += UString("// Annotation \tX  \tY  \tZ");
        for(int k=0; k<NDoubVar; k++) Properties += UString(k,"\tVal%d "); 
        Properties += UString("\n");

        for(int n=0; n<Npoints; n++)
        {
            if(NOT(AllPoints) && NOT(IsPointSelected(n))) continue;

            UVector3 P  = Transform.xfm( plistXFM[n].GetPoint() );
            UString  A  = plistXFM[n].GetAnnotation().GetFirstLine();
            A.ReplaceAll(' ','_');

            Properties += A + UString("\t")+UString(P.Getx(),"%9.4f \t")+UString(P.Gety(),"%9.4f \t")+UString(P.Getz(),"%9.4f \t");
            if(Values)
                for(int m=0; m<NDoubVar; m++)
                    Properties += UString(plistXFM[n].GetValue(m), "%9.4f \t");
            if(AllPoints) 
            {
                if(IsPointSelected(n)) Properties += UString("Selected \t");
                else                   Properties += UString("Skipped  \t");
            }
            Properties += UString("\n");
        }
    }
    return Properties;
}

ErrorType UAnnotatedPointList::WriteVTK(UFileName FileName, double Rad) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::WriteVTK(). Obect NULL or erroneous .\n");
        return U_ERROR;
    }
    if(Rad<=0) Rad = 1.;

    int NSel = GetNPointsSelected();
    if(NSel<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::WriteVTK(). No points selected. \n");
        return U_ERROR;
    }

    UPointList* PL = GetPointListRef();
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UAnnotatedPointList::WriteVTK(). Conversion to UPointList .\n");
        return U_ERROR;
    }

    double* Data0 = (NDoubVar<1) ? NULL : new double[NSel]; 
    double* Data1 = (NDoubVar<2) ? NULL : new double[NSel]; 
    double* Data2 = (NDoubVar<3) ? NULL : new double[NSel]; 
    
    for(int index=0, isel=0; index<Npoints; index++)
    {
        if(plistXFM[index].IsSelected()==false) continue;
        if(Data0) Data0[isel] = plistXFM[index].GetValue(0);
        if(Data1) Data1[isel] = plistXFM[index].GetValue(1);
        if(Data2) Data2[isel] = plistXFM[index].GetValue(2);
        isel++;
    }
    ErrorType E = PL->WriteVTK(FileName, UEuler(), Rad, Data0, Data1, Data2);
    delete[] Data0;    delete[] Data1;    delete[] Data1;
    delete PL;
    if(E!=U_OK)
        CI.AddToLog("ERROR: UAnnotatedPointList::WriteVTK(). Writing UPointList as vtk file.\n");
    return E;
}

ErrorType UAnnotatedPointList::SavePoints(const UFileName& PointFile) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::SavePoints(). Obect NULL or erroneous .\n");
        return U_ERROR;
    }
    if(&PointFile==NULL)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::SavePoints(). Erroneous NULL address in argument .\n");
        return U_ERROR;
    }
    FILE* fp = fopen(PointFile, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::SavePoints(). Creating file %s .\n",(const char*)PointFile);
        return U_ERROR;
    }

    bool ConvertRef = false;
    bool AllPoints  = false;
    bool Values     = true;

    fprintf(fp, "XYZFile1.0\n");
    fprintf(fp, "%s",CI.GetProperties("// "));
    fprintf(fp, "// \n");
    fprintf(fp, "%s", (const char*)this->GetProperties("// "));
    fprintf(fp, "// \n");    
    fprintf(fp, "%s", (const char*)this->GetPointsText(ConvertRef, AllPoints, Values));
    fclose(fp);
    return U_OK;
}

ErrorType UAnnotatedPointList::SavePointsRef(const UFileName& PointFile) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SavePointsRef(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(&PointFile==NULL)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::SavePointsRef(). Erroneous NULL address in argument .\n");
        return U_ERROR;
    }
    FILE* fp = fopen(PointFile, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR UAnnotatedPointList::SavePointsRef(). Creating file %s .\n",(const char*)PointFile);
        return U_ERROR;
    }
    bool ConvertRef = true;
    bool AllPoints  = false;
    bool Values     = true;

    fprintf(fp, "XYZFile1.0\n");
    fprintf(fp, "%s",CI.GetProperties("// "));
    fprintf(fp, "// \n");
    fprintf(fp, "%s", (const char*)this->GetProperties("// "));
    fprintf(fp, "// \n");
    fprintf(fp, "%s", (const char*)this->GetPointsText(ConvertRef, AllPoints, Values));
    fclose(fp);
    return U_OK;
}

ErrorType UAnnotatedPointList::SetNewXfmCoords(UEuler NewXfm2Ref)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetNewXfmCoords(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL && Npoints==0) 
    {
        XFMtoREF = NewXfm2Ref;
        return U_OK;
    }
    if(plistXFM==NULL || Npoints<0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetNewXfmCoords(). Object NULL not properly set. \n");
        return U_ERROR;
    }
    UEuler NewRef2Xfm = NewXfm2Ref.GetInverse();
    for(int n=0; n<Npoints; n++)
    {
        UVector3 pRef = GetPointRef(n);
        plistXFM[n].SetPoint(NewRef2Xfm.xfm(pRef));
    }
    XFMtoREF = NewXfm2Ref;
    
    return U_OK;
}

ErrorType UAnnotatedPointList::Transform(ULinTran Xfm)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::Transform(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    XFMtoREF = Xfm*XFMtoREF;
    return U_OK;
}

UVector3 UAnnotatedPointList::GetCenter(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetCenter(). Object NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetCenter(). plistXFM==NULL \n");
        return UVector3();
    }
    UVector3 Center;
    for(int n=0; n<Npoints; n++)  Center += plistXFM[n].GetPoint();
    return Center/Npoints;
}
ErrorType UAnnotatedPointList::CenterXFM()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::CenterXFM(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::CenterXFM(). plistXFM==NULL \n");
        return U_ERROR;
    }
    UVector3 Center = GetCenter();
    for(int n=0; n<Npoints; n++)  plistXFM[n].SetPoint( plistXFM[n].GetPoint()-Center );

    return U_OK;
}

ErrorType UAnnotatedPointList::ForceInBox(UVector3 BminRef, UVector3 BmaxRef)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ForceInBox(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL) return U_ERROR;

    for(int index=0; index<Npoints; index++)
        plistXFM[index].SetSelected(IsInBox(BminRef, BmaxRef, plistXFM[index].GetPoint()));

    NextPointRef();
    PrevPointRef();
    return U_OK;
}

ErrorType UAnnotatedPointList::TransformCenter(double Sx, double Sy, double Sz)
/*
   Scale all points with respect to the center.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::TransformCenter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL) return U_ERROR;

    UVector3 Center = GetCenter();

    XFMtoREF = UEuler(Center)*   ULinTran(UEuler(), Sx, Sy, Sz) *UEuler(-Center) * XFMtoREF;
    return U_OK;
}

ErrorType UAnnotatedPointList::TransformCenter(UEuler eul)
/*
   Rotate all points with respect to the center using eul (without translating).
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::TransformCenter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL) return U_ERROR;

    UVector3 Center = GetCenter();

    XFMtoREF = UEuler(Center)*   eul    *UEuler(-Center) * XFMtoREF;
    return U_OK;
}

bool UAnnotatedPointList::DoesAnnotationExist(UString Annotation) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::DoesAnnotationExist(). Object NULL or erroneous. \n");
        return false;
    }
    if(plistXFM==NULL) return false;

    for(int n=0; n<Npoints; n++)
        if(Annotation == plistXFM[n].GetAnnotation()) return true;
    return false;
}
int UAnnotatedPointList::GetAnnotationIndex(UString Annotation) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetAnnotationIndex(). Object NULL or erroneous. \n");
        return -1;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetAnnotationIndex(). Empty list. \n");
        return -1;
    }
    for(int n=0; n<Npoints; n++)
        if(Annotation == plistXFM[n].GetAnnotation()) return n;

    CI.AddToLog("ERROR: UAnnotatedPointList::GetAnnotationIndex(). Point not in list (%s). \n", (const char*)Annotation);
    return -1;
}

ErrorType UAnnotatedPointList::SetVarNames(UString VN1, UString VN2, UString VN3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    int NV = 0;
    if(VN1.IsEmpty()==false) VarName[NV++] = VN1;
    if(VN2.IsEmpty()==false) VarName[NV++] = VN2;
    if(VN3.IsEmpty()==false) VarName[NV++] = VN3;
    NDoubVar = NV;
    return U_OK;
}
UString UAnnotatedPointList::GetVarName(int ivar) const
{
    if(this==NULL)               return UString("NONAME");
    if(ivar<0||ivar>=MAXDOUBVAR) return UString("NONAME");
    return VarName[ivar];
}
double UAnnotatedPointList::GetMinRange(int ivar) const
{
    if(this==NULL ||plistXFM==NULL || Npoints<=0) return 0.;
    if(ivar<0||ivar>=MAXDOUBVAR)                  return 0.;
    
    double Min = plistXFM[0].GetValue(ivar);
    for(int n=1; n<Npoints; n++)
    {
        double Val = plistXFM[n].GetValue(ivar);
        if(Val<Min) Min = Val;
    }
    return Min;
}
double UAnnotatedPointList::GetMaxRange(int ivar) const
{
    if(this==NULL ||plistXFM==NULL || Npoints<=0) return 0.;
    if(ivar<0||ivar>=MAXDOUBVAR)                  return 0.;
    
    double Max = plistXFM[0].GetValue(ivar);
    for(int n=1; n<Npoints; n++)
    {
        double Val = plistXFM[n].GetValue(ivar);
        if(Val>Max) Max = Val;
    }
    return Max;
}

bool UAnnotatedPointList::IsPointSelected(int index) const
{
    if(this==NULL || plistXFM==NULL || index<0 || index>=Npoints) return false;

    return plistXFM[index].IsSelected();
}
int UAnnotatedPointList::GetIndexSelected(int indsel) const
{
    if(this==NULL || plistXFM==NULL) return -1;

    for(int n=0,k=0; n<Npoints; n++)
    {
        if(plistXFM[n].IsSelected()==false) continue;
        if(k==indsel) return n;
        k++;
    }
    return -1;
}

int UAnnotatedPointList::GetNPointsSelected(void) const
{
    if(this==NULL || plistXFM==NULL) return 0;

    int NSel = 0;
    for(int index=0; index<Npoints; index++) if(plistXFM[index].IsSelected()) NSel++;
    return NSel;
}

ErrorType UAnnotatedPointList::SelectInRange(int ival, double MinVal, double MaxVal)
{
    if(this==NULL || plistXFM==NULL || ival<0 || ival>=NDoubVar) return U_ERROR;

    for(int index=0; index<Npoints; index++)
        plistXFM[index].SelectInRange(ival, MinVal, MaxVal);

    NextPointRef();
    PrevPointRef();
    return U_OK;
}
ErrorType UAnnotatedPointList::SelectInRange(int NVal, const double* MinVal, const double* MaxVal)
{
    if(NVal   <0    || NVal   >MAXDOUBVAR) return U_ERROR;
    if(MinVal==NULL || MaxVal==NULL      ) return U_ERROR;

    for(int index=0; index<Npoints; index++)
        plistXFM[index].SelectInRange(NVal, MinVal, MaxVal);

    NextPointRef();
    PrevPointRef();
    return U_OK;
}
ErrorType UAnnotatedPointList::AddVar(UString NewVarName, double DefValues, bool GoodBAD)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::AddVar(). Object NULL or erroneously set. \n");
        return U_ERROR;
    }

    if(NDoubVar+1>MAXDOUBVAR)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::AddVar(). Maximum number of variables already reached (NDoubVar=%d). \n", NDoubVar);
        return U_ERROR;
    }
    if(GoodBAD && NOT(DefValues==-1. || DefValues==0. || DefValues==1.))
    {
        CI.AddToLog("WARNING: UAnnotatedPointList::AddVar(). For GoodBAD annotation value (%f) should be -1., 0. or 1.. \n", DefValues);
        GoodBAD = false;
    }
    VarName[NDoubVar++] = NewVarName;

    if(plistXFM)
    {
        for(int n=0; n<Npoints; n++) plistXFM[n].SetValue(NDoubVar-1, DefValues);

        if(iVarUNK_BAD_OK<0 && GoodBAD)
        {
            iVarUNK_BAD_OK = NDoubVar-1;
            UString Annot  = (DefValues<0.) ? "Unknown" : ( (DefValues>0.) ? "Good" : "BAD");
            for(int n=0; n<Npoints; n++) plistXFM[n].SetAnnotation(Annot);
        }
    }
    return U_OK;
}

double UAnnotatedPointList::GetValue(int index, int ivar) const
{
    if(this==NULL || error!=U_OK || plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetValue(). Object NULL or erroneously set. \n");
        return 0.;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetValue(). index out of range (index = %d)  .\n", index);
        return 0.;
    }
    if(ivar<0 || ivar>=NDoubVar)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetValue(). ivar parameter out of range: ivar = %d .\n", ivar);
        return 0.;
    }
    return plistXFM[index].GetValue(ivar);
}
ErrorType UAnnotatedPointList::SetValue(int index, int ivar, double val)
{
    if(this==NULL || error!=U_OK || plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetValue(). Object NULL or erroneously set. \n");
        return U_ERROR;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetValue(). index out of range (index = %d)  .\n", index);
        return U_ERROR;
    }
    if(ivar<0 || ivar>=NDoubVar)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetValue(). ivar parameter out of range: ivar = %d .\n", ivar);
        return U_ERROR;
    }
    if(ivar==iVarUNK_BAD_OK)
    {
        if(val!=-1. && val!=0. && val!=1.) iVarUNK_BAD_OK = -1;
    }
    return plistXFM[index].SetValue(ivar, val);
}

UAnnotatedPoint UAnnotatedPointList::GetPoint(int index) const
{
    if(this==NULL || error!=U_OK || plistXFM==NULL || index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPoint(). index out of range (index = %d)  or object wrongly set.\n", index);
        return UAnnotatedPoint();
    }
    return plistXFM[index];
}

int UAnnotatedPointList::DeleteDoublePoints(double Thresh)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::DeleteDoublePoints(). Object NULL or erroneous. \n");
        return -1;
    }
    if(Npoints<=0)  return 0;
    
    if(plistXFM==NULL) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::DeleteDoublePoints(). plistXFM==NULL \n");
        return -1;
    }

    int    NRem    = 0;
    double Thresh2 = (Thresh<0.) ? 0. : Thresh*Thresh;
    for(int n=Npoints-1; n>=0; n--)
    {
        UVector3 Pref = GetPointRef(n);
        for(int nt=n-1; nt>=0; nt--)
        {
            UVector3 Ptest = GetPointRef(nt);
            if((Pref-Ptest).GetNorm2()>Thresh2) continue;
            RemovePoint(nt);
            NRem++;
            n--;
        }
    }
    return NRem;
}

ErrorType UAnnotatedPointList::RemoveCurrentPoint(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::RemoveCurrentPoint(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Npoints<=0)  return U_OK;
    
    if(plistXFM==NULL) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::RemoveCurrentPoint(). plistXFM==NULL \n");
        return U_ERROR;
    }
    return RemovePoint(current);
}
ErrorType UAnnotatedPointList::RemovePoint(int index)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::RemovePoint(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::RemovePoint(). plistXFM==NULL \n");
        return U_ERROR;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::RemovePoint(). index=%d \n", index);
        return U_ERROR;
    }
    for(int ip=index; ip<Npoints-1; ip++)
        plistXFM[ip] = plistXFM[ip+1];
    Npoints--;
    if(current>=Npoints) current--;

    return U_OK;
}

ErrorType UAnnotatedPointList::ReplacePointRef(int index, UVector3 Pref, UString Annot, const double* Var)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReplacePointRef(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReplacePointRef(). index (%d) out of range .\n", index);
        return U_ERROR;
    }

    UVector3 Pxfm = XFMtoREF.xfmInv(Pref);
    if(Var && NDoubVar>0)
    {
        if(NDoubVar==1)      plistXFM[index] = UAnnotatedPoint(Pxfm, Annot, Var[0]);
        else if(NDoubVar==2) plistXFM[index] = UAnnotatedPoint(Pxfm, Annot, Var[0], Var[1]);
        else                 plistXFM[index] = UAnnotatedPoint(Pxfm, Annot, Var[0], Var[1], Var[2]);
    }
    else
        plistXFM[index] = UAnnotatedPoint(Pxfm, Annot);

    if(iVarUNK_BAD_OK>=0 && iVarUNK_BAD_OK<NDoubVar)
    {
        if(Var[iVarUNK_BAD_OK]!=-1. && Var[iVarUNK_BAD_OK]!=0. && Var[iVarUNK_BAD_OK]!=1.) iVarUNK_BAD_OK = -1;
    }

    return U_OK;
}

ErrorType UAnnotatedPointList::AddPointRef(UVector3 Pref, UString Annot, const double* Var)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::AddPointRef(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    return AddPoint(XFMtoREF.xfmInv(Pref), Annot, Var);
}

ErrorType UAnnotatedPointList::AddPoint(UVector3 x, UString Annot, const double* Var)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::AddPoint(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Npoints>NpointsAllocated-1) // Allocate new memory for points
    {
        int NewAlloc = 2*NpointsAllocated+10;
        if(NewAlloc<100)   NewAlloc = 100;
        if(NewAlloc>10000) NewAlloc = NpointsAllocated+10000; 
        UAnnotatedPoint*   plistNew = new UAnnotatedPoint[NewAlloc];
        if(plistNew==NULL)
        {
            CI.AddToLog("ERROR: UAnnotatedPointList::AddPoint(). Memory allocation. NpointsAllocated = %d, NewAlloc = %d  .\n", NpointsAllocated, NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<Npoints; n++) plistNew[n] = plistXFM[n];
        delete[] plistXFM; plistXFM = plistNew;
        NpointsAllocated      = NewAlloc;
    }
    if(Var && NDoubVar>0)
    {
        if(NDoubVar==1)      plistXFM[Npoints++] = UAnnotatedPoint(x, Annot, Var[0]);
        else if(NDoubVar==2) plistXFM[Npoints++] = UAnnotatedPoint(x, Annot, Var[0], Var[1]);
        else                 plistXFM[Npoints++] = UAnnotatedPoint(x, Annot, Var[0], Var[1], Var[2]);

        if(iVarUNK_BAD_OK>=0 && iVarUNK_BAD_OK<NDoubVar)
        {
            if(Var[iVarUNK_BAD_OK]!=-1. && Var[iVarUNK_BAD_OK]!=0. && Var[iVarUNK_BAD_OK]!=1.) iVarUNK_BAD_OK = -1;
        }
    }
    else
        plistXFM[Npoints++] = UAnnotatedPoint(x, Annot);

    return U_OK;
}

ErrorType UAnnotatedPointList::ChangePointRef(UVector3 Pref, int index)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ChangePointRef(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ChangePointRef(). Point list not set. \n");
        return U_ERROR;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ChangePointRef(). index out of range: idex = %d .\n", index);
        return U_ERROR;
    }
    plistXFM[index].SetPoint( XFMtoREF.xfmInv(Pref) );
    return U_OK;
}
UVector3 UAnnotatedPointList::GetCurrentPointXfm() const
{
    return GetPointXfm(-1);
}
UVector3 UAnnotatedPointList::GetCurrentPointRef() const
{
    return GetPointRef(-1);
}

UVector3 UAnnotatedPointList::GetPointXfm(int index) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointXfm(). Object NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointXfm(). Point list not set. \n");
        return UVector3();
    }
    if(index<0)  index = current;    
    if(index<0 ||index>=Npoints) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointXfm(). index out of range: index = %d. \n", index);
        return UVector3();
    }
    return plistXFM[index].GetPoint();    
}

UPointList* UAnnotatedPointList::GetNLRAsPointListRef(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetNLRAsPointListRef(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetNLRAsPointListRef(). Point list not set. \n");
        return NULL;
    }
    UVector3 NRef;
    UVector3 LRef;
    UVector3 RRef;
    if(HasNLRPoints(&NRef, &LRef, &RRef)==false)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetNLRAsPointListRef(). Nasion, Left or Right ear marker not present. \n");
        return NULL;
    }
    UPointList* PL = new UPointList();
    if(PL==NULL||PL->GetError()!=U_OK||PL->AddPoint(NRef)!=U_OK||PL->AddPoint(LRef)!=U_OK||PL->AddPoint(RRef)!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UAnnotatedPointList::GetNLRAsPointListRef(). Crearint UPointList from Nasion, Left or Right ear marker. \n");
        return NULL;
    }
    return PL;
}
bool UAnnotatedPointList::HasNLRPoints(UVector3* NasRef, UVector3* LefRef, UVector3* RigRef) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::HasNLRPoints(). Object NULL or erroneous. \n");
        return false;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::HasNLRPoints(). Point list not set. \n");
        return false;
    }
    bool Nas = false; UVector3 NRef;
    bool Lef = false; UVector3 LRef;
    bool Rig = false; UVector3 RRef;

    for(int i=0; i<Npoints; i++)
    {
        if(Nas==false && IsStringCompatible(plistXFM[i].GetAnnotation(),"Nasion",false)==true)
        {
            Nas  = true;
            NRef = GetPointRef(i);
            continue;
        }
        if(Lef==false && (IsStringCompatible(plistXFM[i].GetAnnotation(),"Left"    ,false)==true || 
                          IsStringCompatible(plistXFM[i].GetAnnotation(),"LeftEar*",false)==true))
        {
            Lef  = true;
            LRef = GetPointRef(i);
            continue;
        }
        if(Rig==false && (IsStringCompatible(plistXFM[i].GetAnnotation(),"Right"    ,false)==true || 
                          IsStringCompatible(plistXFM[i].GetAnnotation(),"RightEar*",false)==true))
        {
            Rig  = true;
            RRef = GetPointRef(i);
            continue;
        }
    }
    if(Nas&&Lef&&Rig)
    {
        if(NasRef) *NasRef = NRef;
        if(LefRef) *LefRef = LRef;
        if(RigRef) *RigRef = RRef;
        return true;
    }
    return false;
}
ErrorType UAnnotatedPointList::UnselectNLR(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::UnselectNLR(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::UnselectNLR(). Point list not set. \n");
        return U_ERROR;
    }
    for(int i=0; i<Npoints; i++)
    {
        if(IsStringCompatible(plistXFM[i].GetAnnotation(),"Nasion",false)==true)
        {
            plistXFM[i].SetSelected(false);
            continue;
        }
        if(IsStringCompatible(plistXFM[i].GetAnnotation(),"Left"    ,false)==true || 
           IsStringCompatible(plistXFM[i].GetAnnotation(),"LeftEar*",false)==true)
        {
            plistXFM[i].SetSelected(false);
            continue;
        }
        if(IsStringCompatible(plistXFM[i].GetAnnotation(),"Right"    ,false)==true || 
           IsStringCompatible(plistXFM[i].GetAnnotation(),"RightEar*",false)==true)
        {
            plistXFM[i].SetSelected(false);
            continue;
        }
    }
    return U_OK;
}

UVector3 UAnnotatedPointList::GetPointRef(int index) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointRef(). this==NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointRef(). Point list not set. \n");
        return UVector3();
    }
    if(index<0)  index = current;    
    if(index<0 ||index>=Npoints) 
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointRef(). index out of range: index = %d. \n", index);
        return UVector3();
    }
    return XFMtoREF.xfm( plistXFM[index].GetPoint() );    
}

UVector3 UAnnotatedPointList::FirstPointRef(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::FirstPointRef(). this==NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::FirstPointRef(). Point list not set. \n");
        return UVector3();
    }
    if(GetNPointsSelected()<=0)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::FirstPointRef(). No points selected. \n");
        return UVector3();
    }
    current = 0;
    for(int k=0; k<Npoints; k++, current++)
        if(IsPointSelected(current)==true) break;

    return XFMtoREF.xfm( plistXFM[current].GetPoint() );    
}

UVector3 UAnnotatedPointList::PrevPointRef(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::PrevPointRef(). this==NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::PrevPointRef(). Point list not set. \n");
        return UVector3();
    }
    if(GetNPointsSelected()<=0)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::PrevPointRef(). No points selected. \n");
        return UVector3();
    }
    for(int k=0; k<Npoints; k++)
    {
        current--;
        if(current<0) current+=Npoints;
        if(IsPointSelected(current)==true) break;
    }
    return XFMtoREF.xfm( plistXFM[current].GetPoint() );    
}

UVector3 UAnnotatedPointList::NextPointRef(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::NextPointRef(). this==NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::NextPointRef(). Point list not set. \n");
        return UVector3();
    }
    if(GetNPointsSelected()<=0)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::NextPointRef(). No points selected. \n");
        return UVector3();
    }
    for(int k=0; k<Npoints; k++)
    {
        current++;
        if(current>=Npoints) current-=Npoints;
        if(IsPointSelected(current)==true) break;
    }
    return XFMtoREF.xfm( plistXFM[current].GetPoint() );    
}

UVector3 UAnnotatedPointList::LastPointRef(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::LastPointRef(). this==NULL or erroneous. \n");
        return UVector3();
    }
    if(plistXFM==NULL)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::LastPointRef(). Point list not set. \n");
        return UVector3();
    }
    if(GetNPointsSelected()<=0)
    {
        current = 0;
        CI.AddToLog("ERROR: UAnnotatedPointList::LastPointRef(). No points selected. \n");
        return UVector3();
    }
    current = Npoints-1;
    for(int k=0; k<Npoints; k++, current--)
        if(IsPointSelected(current)==true) break;

    return XFMtoREF.xfm( plistXFM[current].GetPoint() );    
}

UString UAnnotatedPointList::GetAnnotation(int index) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetAnnotation(). this==NULL or erroneous. \n");
        return "ERROR";
    }
    if(plistXFM==NULL || index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetAnnotation(). Point list not set, or index out of range (index = %d, Npoints = %d)\n", index, Npoints);
        return "No point";
    }
    return plistXFM[index].GetAnnotation();
}

UString UAnnotatedPointList::GetCurrentAnnotation(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetCurrentAnnotation(). this==NULL or erroneous. \n");
        return "ERROR";
    }
    if(plistXFM==NULL || current<0 || current>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetCurrentAnnotation(). Point list not set. \n");
        return "No point";
    }
    return plistXFM[current].GetAnnotation();
}

ErrorType UAnnotatedPointList::SetAnnotation(int index, UString Annot)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetAnnotation(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetAnnotation(). Point list not set. \n");
        return U_ERROR;
    }
    if(index<0 || index>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetAnnotation(). Index (=%d) out of range.\n ", index);
        return U_ERROR;
    }
    return plistXFM[index].SetAnnotation(Annot);
}
ErrorType UAnnotatedPointList::SetCurrentAnnotation(UString Annot)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetCurrentAnnotation(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL || current<0 || current>=Npoints)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SetCurrentAnnotation(). Point list not set. \n");
        return U_ERROR;
    }
    return plistXFM[current].SetAnnotation(Annot);
}

static int SortAnnot(const void *elem1, const void *elem2)
{    
    if(elem1==NULL || elem2==NULL) return 0;
    UString     A1 = ((UAnnotatedPoint*)elem1)->GetAnnotation();
    UString     A2 = ((UAnnotatedPoint*)elem2)->GetAnnotation();

    if(A1.IsNULL() || A2.IsNULL()) return 0;
    return strcmp((const char*)A1, (const char*)A2);
}

ErrorType UAnnotatedPointList::SortAnnotation(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortAnnotation(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortAnnotation(). Point list not set. \n");
        return U_ERROR;
    }
    int NSel = GetNPointsSelected();
    if(NSel<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortAnnotation(). No points selected. \n");
        return U_ERROR;
    }
    UAnnotatedPoint* PSel = new UAnnotatedPoint[Npoints];
    if(PSel==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortAnnotation(). Memmory allocation (Npoints=%d). \n", Npoints);
        return U_ERROR;
    }
    for(int n=0,ns=0,nns=0; n<Npoints; n++)
    {
        if(plistXFM[n].IsSelected()==true) {PSel[ns      ] = plistXFM[n]; ns++; }
        else                               {PSel[NSel+nns] = plistXFM[n]; nns++;}
    }
    qsort(PSel, NSel, sizeof(UAnnotatedPoint), SortAnnot);
    delete[] plistXFM; plistXFM = PSel;

    return U_OK;
}

ErrorType UAnnotatedPointList::SortValues(int ival, bool UseFabs, bool HighFirst)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortValues(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortValues(). Point list not set. \n");
        return U_ERROR;
    }
    if(ival<0 || ival>=NDoubVar)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortValues(). argument out of range (ival = %d). \n", ival);
        return U_ERROR;
    }
    double*          Values = new double[Npoints];
    UAnnotatedPoint* PSort  = new UAnnotatedPoint[Npoints];
    if(Values==NULL || PSort==NULL)
    {
        delete[] Values;
        delete[] PSort;
        CI.AddToLog("ERROR: UAnnotatedPointList::SortValues(). Memory allocation (Npoints = %d) .\n", Npoints);
        return U_ERROR;
    }
    for(int k=0; k<Npoints; k++)
        Values[k] = plistXFM[k].GetValue(ival);

    int* Index = GetOrderIndexArray(Values, Npoints, UseFabs, HighFirst);
    if(Index==NULL)
    {
        delete[] Index;
        delete[] Values;
        delete[] PSort;
        CI.AddToLog("ERROR: UAnnotatedPointList::SortValues(). Getting order indices .\n", Npoints);
        return U_ERROR;
    }

    for(int n=0; n<Npoints; n++) PSort[n] = plistXFM[Index[n]];
    delete[] plistXFM; plistXFM = PSort;

    return U_OK;
}

UField* UAnnotatedPointList::GetPLAsFieldRef(bool SortAnnot) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Point list not set. \n");
        return NULL;
    }
    if(SortAnnot)
    {
        UAnnotatedPointList ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK || ThisCopy.SortAnnotation()!=U_OK)
        {
            CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Copying or sorting this. \n");
            return NULL;
        }
        return ThisCopy.GetPLAsFieldRef(false);
    }

    int NSel = GetNPointsSelected();
    if(NSel<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). No points selected. \n");
        return NULL;
    }
    UVector3* PArrRef = new UVector3[NSel];
    if(PArrRef==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Memory allocation: Npoints = %d. \n", Npoints);
        return NULL;
    }

    for(int n=0, ns=0; n<Npoints; n++) 
    {
        if(IsPointSelected(n)==false) continue;
        PArrRef[ns++] = GetPointRef(n);
    }
    UField* PL = new UField(PArrRef, NSel);
    delete[] PArrRef;

    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Creating UField-object. \n");
        return NULL;
    }
    return PL;
}
UPointList* UAnnotatedPointList::GetPointListRef(bool SortAnnot) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointListRef(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointListRef(). Point list not set. \n");
        return NULL;
    }
    if(SortAnnot)
    {
        UAnnotatedPointList ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK || ThisCopy.SortAnnotation()!=U_OK)
        {
            CI.AddToLog("ERROR: UAnnotatedPointList::GetPLAsFieldRef(). Copying or sorting this. \n");
            return NULL;
        }
        return ThisCopy.GetPointListRef(false);
    }

    int NSel = GetNPointsSelected();
    if(NSel<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointListRef(). No points selected. \n");
        return NULL;
    }
    UVector3* PArrRef = new UVector3[NSel];
    if(PArrRef==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointListRef(). Memory allocation: Npoints = %d. \n", Npoints);
        return NULL;
    }

    for(int n=0, ns=0; n<Npoints; n++) 
    {
        if(IsPointSelected(n)==false) continue;
        PArrRef[ns++] = GetPointRef(n);
    }
    
    UPointList* PL = new UPointList(PArrRef, Npoints); 
    delete[] PArrRef;
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UAnnotatedPointList::GetPointListRef(). Creating UPointList-object. \n");
        return NULL;
    }
    return PL;
}
USurface* UAnnotatedPointList::GetSurfaceRef(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetSurfaceRef(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(plistXFM==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetSurfaceRef(). Point list not set. \n");
        return NULL;
    }
    int NSel = GetNPointsSelected();
    if(NSel<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetSurfaceRef(). No points selected. \n");
        return NULL;
    }
    UVector3* PArrRef = new UVector3[NSel];
    if(PArrRef==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::GetSurfaceRef(). Memory allocation: Npoints = %d. \n", Npoints);
        return NULL;
    }

    for(int n=0, ns=0; n<Npoints; n++) 
    {
        if(IsPointSelected(n)==false) continue;
        PArrRef[ns++] = GetPointRef(n);
    }
    
    USurface* S = new USurface(PArrRef, Npoints, (const int*)NULL, 0, (const char*)Name); 
    delete[] PArrRef;
    if(S==NULL || S->GetError()!=U_OK)
    {
        delete S;
        CI.AddToLog("ERROR: UAnnotatedPointList::GetSurfaceRef(). Creating USurface-object. \n");
        return NULL;
    }
    return S;
}

bool UAnnotatedPointList::IsPolhemusFile(UFileName FName) // static
{
    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::IsPolhemusFile(). File cannot be opened: %s \n", (const char*)FName);
        return false;
    }

    char line[256];
    memset(line, 0, sizeof(line));

    int LineNo = 1;
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsEmptyLine()==true) continue;
        
        if(LineNo%2)
        {
            if(AA.GetNextInt(-1)!=1) 
            {
                fclose(fp);
                return false;
            }
        }
        else
        {
            if(AA.GetNextInt(-1)!=2) 
            {
                fclose(fp);
                return false;
            }
        }
        LineNo++;
    }
    fclose(fp);
    return true;
}

#define MAXPBUF 100
ErrorType UAnnotatedPointList::ReadAsPolhemusFile(UFileName FName)
{
/*
      1=stylus
      2=referentie

      eerst nlr    ca. 10 per punt
      dan   punten (hs)
      dan   nlr
 */
    if(IsPolhemusFile(FName)==false)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsPolhemusFile(). File is not a polhemus file (%s). \n", (const char*)FName);
        return U_ERROR;
    }

    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsPolhemusFile(). File cannot be opened: %s \n", (const char*)FName);
        return U_ERROR;
    }

    int      LineNo = 1;
    bool TimeStamp1 = false;
    bool TimeStamp2 = false;
    char line[256];
    memset(line, 0, sizeof(line));
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsEmptyLine()==true) continue;
        
        if(LineNo==1)
        {
            const char* Test = AA.GetNextString(20,NULL);
                        Test = AA.GetNextString(20,NULL);
            if(Test==NULL) 
            {
                fclose(fp);
                return U_ERROR;
            }
            TimeStamp1 = (Test[1]=='x');
        }
        else if(LineNo==2)
        {
            const char* Test = AA.GetNextString(20,NULL);
                        Test = AA.GetNextString(20,NULL);
            if(Test==NULL) 
            {
                fclose(fp);
                return U_ERROR;
            }
            TimeStamp2 = (Test[1]=='x');
        }
        else break;
        LineNo++;
    }
    rewind(fp);

    double TX1=0.,TY1=0.,TZ1=0.;
    double RX1=0.,RY1=0.,RZ1=0.;   
    double TX2=0.,TY2=0.,TZ2=0.;
    double RX2=0.,RY2=0.,RZ2=0.;
             LineNo = 1;
    int      RefPnt = 0; // N, L and R
    int      irefpnt= 0;
    UVector3 PArray[MAXPBUF];
    int      TimeOld = 0;
    int      TimeNew = 0;
    UVector3 NLR[3];
    UEuler   ToNLR;

    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsEmptyLine()==true) continue;
        
        if(LineNo%2)
        {
            if(AA.GetNextInt(-1)!=1) 
            {
                fclose(fp);
                return U_ERROR;
            }
            if(TimeStamp1) 
            {
                TimeOld = TimeNew;
                const char* TimeStr = AA.GetNextString(20,NULL);
                sscanf(TimeStr,"%x",&TimeNew);
            }
            TX1 = AA.GetNextDouble(0.);
            TY1 = AA.GetNextDouble(0.);
            TZ1 = AA.GetNextDouble(0.);
            RX1 = AA.GetNextDouble(0.);
            RY1 = AA.GetNextDouble(0.);
            RZ1 = AA.GetNextDouble(0.);
        }
        else
        {
            if(AA.GetNextInt(-1)!=2) 
            {
                fclose(fp);
                return U_ERROR;
            }
            if(TimeStamp2) AA.GetNextString(20,NULL);
            TX2 = AA.GetNextDouble(0.);
            TY2 = AA.GetNextDouble(0.);
            TZ2 = AA.GetNextDouble(0.);
            RX2 = AA.GetNextDouble(0.);
            RY2 = AA.GetNextDouble(0.);
            RZ2 = AA.GetNextDouble(0.);

            UVector3 Psty(TX1, TY1, TZ1);
            UVector3 Pref(TX2, TY2, TZ2);
            UEuler   Eref(0.,0.,0.,PI*RX2/180,PI*RY2/180,PI*RZ2/180); 

            UVector3 P = Eref.xfmInv(Psty-Pref, true);

            if(TimeStamp1)
            {
                if(TimeNew>TimeOld+2000 && LineNo>2)
                {
                    if(RefPnt<3) 
                    {
                        NLR[RefPnt] = GetMedianPoint(PArray, irefpnt);
                        switch(RefPnt)
                        {
                        case 0: CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). Nasion: Npoints = %d \n", irefpnt); break;
                        case 1: CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). Left  : Npoints = %d \n", irefpnt); break;
                        case 2: CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). Right : Npoints = %d \n", irefpnt); break;
                        }
                        if(RefPnt==2)
                        {
                            ToNLR   = UEuler(NLR[0],NLR[1],NLR[2]);
                            this->AddPoint(ToNLR.xfm(NLR[0]), UString("Nasion"));
                            this->AddPoint(ToNLR.xfm(NLR[1]), UString("Left"  ));
                            this->AddPoint(ToNLR.xfm(NLR[2]), UString("Right" ));

                            double T01 = (NLR[1]-NLR[0]).GetNorm();
                            double T12 = (NLR[2]-NLR[1]).GetNorm();
                            double T20 = (NLR[0]-NLR[2]).GetNorm();
                            CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). NL = %f [cm]\n",T01);
                            CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). LR = %f [cm]\n",T12);
                            CI.AddToLog("Note: UAnnotatedPointList::ReadAsPolhemusFile(). RN = %f [cm]\n",T20);
                        }
                        irefpnt = 0;
                        RefPnt++;
                    }
                }
                if(RefPnt<3)
                {
                    if(irefpnt<MAXPBUF) PArray[irefpnt++] = P;
                }
                else
                {
                    this->AddPoint(ToNLR.xfm(P), UString(irefpnt++,"P%d"));
                }
            }
            else
            {
                if(LineNo==2) NLR[0]=P;
                else if(LineNo==4) NLR[1]=P;
                else if(LineNo==6) 
                {
                    NLR[2] = P;
                    ToNLR  = UEuler(NLR[0],NLR[1],NLR[2]);

                    this->AddPoint(ToNLR.xfm(NLR[0]), UString("Nasion"));
                    this->AddPoint(ToNLR.xfm(NLR[1]), UString("Left"));
                    this->AddPoint(ToNLR.xfm(NLR[2]), UString("Right"));
                }
                else
                {
                    this->AddPoint(ToNLR.xfm(P), UString(LineNo/2-3,"Point_%d"));
                }
            }
        }
        LineNo++;
    }
    fclose(fp);

    return U_OK;
}
#undef MAXPBUF

bool UAnnotatedPointList::IsFindCoilsFile(UFileName FName) // static
{
    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::IsFindCoilsFile(). File cannot be opened: %s \n", (const char*)FName);
        return false;
    }

    char line[256];
    memset(line, 0, sizeof(line));
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsEmptyLine()==true) continue;
        if(AA.IsCommentLine()==false) break;

        if(AA.StringInComment("Programme = FindCoils")==false) break;
        
        fclose(fp);
        return true;
    }
    fclose(fp);
    return false;
}
ErrorType UAnnotatedPointList::ReadAsFindCoilsFile(UFileName FName)
{
    if(IsFindCoilsFile(FName)==false)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFindCoilsFile(). File is not a polhemus file (%s). \n", (const char*)FName);
        return U_ERROR;
    }

    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFindCoilsFile(). File cannot be opened: %s \n", (const char*)FName);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    int ip = 0;
    char line[300];
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLineExt AA(line, sizeof(line));
        if(AA.IsComment()              == true) continue;
        
        ErrorType E      = U_OK;
        UString Lab1(AA.GetNextString(32));
        if(AA.GetError()!=U_OK) E = U_ERROR;
        UString Lab2(AA.GetNextString(32));
        if(AA.GetError()!=U_OK) E = U_ERROR;
        UVector3 P = AA.GetNextVector3();
        if(AA.GetError()!=U_OK) E = U_ERROR;

        UString Point(ip, "Point_%d");
        if(AA.StringInComment("ERROR"  ) == true)            Point = UString(ip, "ErrorPoint_%d");
        else if(AA.StringInComment("WARNING") == true)       Point = UString(ip, "WarningPoint_%d");
        else if(IsStringBeginning(Lab1, "nas", false)==true) Point = UString("Nasion");
        else if(IsStringBeginning(Lab1, "lef", false)==true) Point = UString("Left");
        else if(IsStringBeginning(Lab1, "rig", false)==true) Point = UString("Right");

        if(E!=U_OK || this->AddPoint(P, Point)!=U_OK)
        {
            CI.AddToLog("ERROR : UAnnotatedPointList::ReadAsFindCoilsFile(). reading/writing point from line:%s\n", line);
            fclose(fp); 
            return U_ERROR;
        }
        ip++;
    }
    fclose(fp);
    return U_OK;
}

ErrorType UAnnotatedPointList::ReadAsElcFile(UFileName FName)
{
    if(FName.HasExtension("elc", false)==false)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsElcFile(). File is not a .elc file (%s). \n", (const char*)FName);
        return U_ERROR;
    }

    FILE* fp = fopen(FName, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsElcFile(). File cannot be opened: %s \n", (const char*)FName);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    char line[250];
    int  Npoints   = 0;
    bool DistInMM  = true;
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsComment() || AA.IsEmptyLine()) continue;
        if(AA.IsIdentifierIsInLine("NumberPositions",true)==true)
        {
            Npoints = AA.GetNextInt(-1);
            GetLine(line, sizeof(line), fp);
            if(AA.IsIdentifierInLine("UnitPosition") && 
               AA.IsIdentifierInLine("mm")) DistInMM = true;
            break;
        }
    }
    if(Npoints<=0)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsElcFile(). Too few electrodes: %s .\n", line);
        return U_ERROR;
    }
    UAnalyzeLine AA(line, sizeof(line));
    while(AA.IsIdentifierInLine("Positions")==false &&
          GetLine(line, sizeof(line), fp)) AA = UAnalyzeLine(line, sizeof(line));

    for(int i=0; i<Npoints; i++)
    {
        if(!GetLine(line, sizeof(line), fp))
        {
            fclose(fp);
            CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsElcFile(). Not all electrodes found (last = %d).\n", i);
            return U_ERROR;
        }
        for(int k=0; k<sizeof(line); k++) if(line[k]==':') line[k]=' ';
        bool CC = (line[0]=='C') && (line[1]=='C');
        UAnalyzeLine AA = CC ? UAnalyzeLine(line+2, sizeof(line)-2) : UAnalyzeLine(line, sizeof(line));
        if(AA.IsComment() || AA.IsEmptyLine()) 
        {
            i--;
            continue;
        }
        UString Name(AA.GetNextString(sizeof(line)-10, NULL));
        if(CC) Name.Prepend("CC");
        double x = AA.GetNextDouble(0.);
        double y = AA.GetNextDouble(0.);
        double z = AA.GetNextDouble(0.);
        if(x==0. && y==0. && z==0.)
        {
            fclose(fp);
            CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsElcFile(). Invalid electrode postion, (i = %d).\n", i);
            return U_ERROR;
        }
        UVector3 P = DistInMM ? UVector3(x/10, y/10, z/10) : UVector3(x   , y   , z   );

        if(this->AddPoint(P, Name)!=U_OK)
        {
            CI.AddToLog("ERROR : UAnnotatedPointList::ReadAsElcFile(). reading/writing point from line:%s\n", line);
            fclose(fp); 
            return U_ERROR;
        }
    }
    fclose(fp);
    return U_OK;
}

ErrorType UAnnotatedPointList::ReadAsFiffDipFile(UFileName FName)
{
    static const bool IntelData = false;

    FILE* fp   = fopen(FName, "rb");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFiffFile(). File cannot be opened. \n");
        return U_ERROR;
    }
    int Nbytes = GetFileSize(fp);
    if(Nbytes<=0 || Nbytes%196)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFiffFile(). File is not a Fif dipole file (%s). \n", (const char*)FName);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    int   Ndip = Nbytes/196;    
    NDoubVar   = 3;
    VarName[0] = "Amplitude";
    VarName[1] = "G.O.F.";
    VarName[2] = "ConfVol";
    
    for(int k=0; k<Ndip; k++)
    {
        FIFFDipType FDip;
        FDip.dipole          = ReadBinaryInt  (IntelData, fp);
        FDip.begin           = ReadBinaryFloat(IntelData, fp);
        FDip.end             = ReadBinaryFloat(IntelData, fp);
        FDip.r0[0]           = ReadBinaryFloat(IntelData, fp);
        FDip.r0[1]           = ReadBinaryFloat(IntelData, fp);
        FDip.r0[2]           = ReadBinaryFloat(IntelData, fp);
        FDip.rd[0]           = ReadBinaryFloat(IntelData, fp);
        FDip.rd[1]           = ReadBinaryFloat(IntelData, fp);
        FDip.rd[2]           = ReadBinaryFloat(IntelData, fp);
        FDip.Q[0]            = ReadBinaryFloat(IntelData, fp);
        FDip.Q[1]            = ReadBinaryFloat(IntelData, fp);
        FDip.Q[2]            = ReadBinaryFloat(IntelData, fp);
        FDip.goodness        = ReadBinaryFloat(IntelData, fp);
        FDip.errors_computed = ReadBinaryInt  (IntelData, fp);
        FDip.noise_level     = ReadBinaryFloat(IntelData, fp);
        for(int k1=0; k1<5; k1++) FDip.single_errors[k1] = ReadBinaryFloat(IntelData, fp);
        for(int k1=0; k1<5; k1++) 
            for(int k2=0; k2<5; k2++) FDip.error_matrix[k1][k2] = ReadBinaryFloat(IntelData, fp);
        FDip.conf_vol        = ReadBinaryFloat(IntelData, fp);
        FDip.khi2            = ReadBinaryFloat(IntelData, fp);
        FDip.prob            = ReadBinaryFloat(IntelData, fp);
        FDip.noise_est       = ReadBinaryFloat(IntelData, fp);
        
        UVector3 DipPos      = 100*UVector3(FDip.rd);
        UString  Name        = UString(FDip.dipole, "FiffDipole_%d");
        double   Var[3]      = {1.e9*sqrt(FDip.Q[0]*FDip.Q[0]+FDip.Q[1]*FDip.Q[1]+FDip.Q[2]*FDip.Q[2]), FDip.goodness, 1.e6*FDip.conf_vol};
        AddPoint(DipPos, Name, Var);
    }

    fclose(fp);
    return U_OK;
}
ErrorType UAnnotatedPointList::ReadAsFiffFile(UFileName FName)
{
    UMEEGDataFIFF Dat(FName, false, true, false);
    if(Dat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFiffFile(). File is not a Fif data file (%s). \n", (const char*)FName);
        return U_ERROR;
    }
    bool       NLRinc = false;
    int        Np     = 0;    
    UVector3*  p      = Dat.GetPolhemusPoints(&Np, &NLRinc);
    if(p==NULL || Np<=0)
    {
        delete[] p;
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsFiffFile(). No Oplhemus points detected. \n");
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    for(int n=0; n<Np; n++)
    {
        if(NLRinc==true && n==0) {AddPoint(p[n], "Nasion");  continue;}
        if(NLRinc==true && n==1) {AddPoint(p[n], "Left");    continue;}
        if(NLRinc==true && n==2) {AddPoint(p[n], "Right");   continue;}
        
        UString Lab(n, "Pol_%d");
        AddPoint(p[n], Lab);
    }
    delete[] p;
    return U_OK;
}
ErrorType UAnnotatedPointList::ReadAsCTFSensors(UFileName FName)
{
    UMEEGDataCTF Dat(FName);
    if(Dat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFSensors(). File is not a CTF data file (%s). \n", (const char*)FName);
        return U_ERROR;
    }
    const UGrid* G = Dat.GetGridMEG();
    if(G==NULL)  G = Dat.GetGridEEG();
    if(G==NULL || G->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFSensors(). CTF data file has nog MEG or EEG sensors (%s).\n", (const char*)FName);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    for(int i=0; i<G->GetNpoints(); i++)
        AddPoint(G->GetSensor(i).Getx(), G->GetSensor(i).GetName());

    return U_OK;
}
ErrorType UAnnotatedPointList::ReadAsCTFDipFile(UFileName FName)
{
    DeleteAllMembers(U_OK);
    if(IsCTFDipFile(FName)==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFDipFile(). File is not a CTF dipole file (%s). \n", (const char*)FName);
        return U_ERROR;
    }

    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFDipFile(). File cannot be opened: %s \n", (const char*)FName);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);    
    
    double Var[2]     = {0.,0.};    
    bool   IgnoreCase = true;
    char   line[1000];
    memset(line, 0, sizeof(line));
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsIdentifier("Fit_Results", IgnoreCase))
        {
            GetLine(line, sizeof(line), fp);
            UAnalyzeLine AA(line, sizeof(line));
            if(AA.IsIdentifier("{", IgnoreCase)==false)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFDipFile(). File is not a CTF dipole file (%s) (wrong '{'). \n", (const char*)FName);
                fclose(fp);
                return U_ERROR;
            }

            char lineHead[sizeof(line)]; 
            while(GetLine(line, sizeof(line), fp))
            {                
                UAnalyzeLine AA(line, sizeof(line));
                if(AA.IsEmptyLine()==true) continue;
                if(AA.IsCommentLine("//",true)==true) 
                {
                    memcpy(lineHead, line, sizeof(line));
                    continue;
                }
                UAnalyzeLine AAHead(lineHead, sizeof(line)); AAHead.SkipComments();

                int Col_x = 1 + AAHead.GetCollumn("xp", "(s)", "(cm)", "(nAm)");
                int Col_y = 1 + AAHead.GetCollumn("yp", "(s)", "(cm)", "(nAm)");
                int Col_z = 1 + AAHead.GetCollumn("zp", "(s)", "(cm)", "(nAm)");
                int Col_t = 1 + AAHead.GetCollumn("Latency", "(s)", "(cm)", "(nAm)");
                int Col_e = 1 + AAHead.GetCollumn("Error", "(s)", "(cm)", "(nAm)");
                if(Col_e<=0)
                    Col_e = 1 + AAHead.GetCollumn("Err", "(s)", "(cm)", "(nAm)");
                
                if(Col_x<=0 || Col_y<=0 || Col_z<=0)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UAnnotatedPointList::ReadAsCTFDipFile(). Cannot find collumns 'xp', 'yp' or 'zp' in line '%s' .\n", lineHead);
                    fclose(fp);
                    return U_ERROR;
                }
                if(Col_t>=1) 
                {
                    NDoubVar = 1; VarName[0] = UString("time [ms]");
                    if(Col_e>=1) {NDoubVar = 2; VarName[1] = UString("Error [%]");}
                }
                int ip = 0;
                while(1)
                {
                    double x = AA.GetCollumn_d(Col_x, 0.);
                    double y = AA.GetCollumn_d(Col_y, 0.);
                    double z = AA.GetCollumn_d(Col_z, 0.);
                    double t = -1.; if(Col_t>0) t = AA.GetCollumn_d(Col_t, -1.)*1000.;
                    double e = -1.; if(Col_e>0) e = AA.GetCollumn_d(Col_e, -1.);

                    UString Annot(ip,"dipno %d");
                    if(t>=0.         )  Annot  = UString(t, "t=%f ms");
                    if(t>=0. && e>=0.)  Annot += UString(e, "E=%f %%");
                    else if(e>=0.    )  Annot  = UString(e, "E=%f %%");
                    
                    if(NDoubVar>=1) Var[0] = t;
                    if(NDoubVar==2) Var[1] = e;

                    if(AddPoint(UVector3(x,y,z), Annot, Var)!=U_OK)
                    {
                        DeleteAllMembers(U_ERROR);
                        CI.AddToLog("ERROR : UAnnotatedPointList::ReadAsCTFDipFile(). Adding point from line:%s\n", line);
                        fclose(fp); 
                        return U_ERROR;
                    }
                    ip++;

                    bool EndList = false;
                    while(1)
                    {
                        if(!GetLine(line, sizeof(line), fp))      {EndList=true; break;}
                        AA = UAnalyzeLine(line, sizeof(line));                    
                        if(AA.IsIdentifier("}", IgnoreCase)==true){EndList=true; break;}

                        if(AA.IsEmptyLine()==false && AA.IsCommentLine("//",true)==false) break;
                    }
                    if(EndList==true) break;
                }
            }
        }
    }        
    fclose(fp);
    Name = UString(FName.GetBaseName());
    return U_OK;
}
bool UAnnotatedPointList::IsCTFDipFile(UFileName FName) // static
{
    if(FName.HasExtension("DIP")==false &&
       FName.HasExtension("dip")==false) return false;

    FILE* fp = fopen(FName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::IsCTFDipFile(). File cannot be opened: %s \n", (const char*)FName);
        return false;
    }

    bool IgnoreCase = true;
    char line[1000];
    memset(line, 0, sizeof(line));
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsIdentifier("Fit_Results", IgnoreCase))
        {
            GetLine(line, sizeof(line), fp);
            UAnalyzeLine AA(line, sizeof(line));
            if(AA.IsIdentifier("{", IgnoreCase))
            {
                fclose(fp);
                return true;
            }
        }
    }        
    fclose(fp);
    return false;
}

ErrorType UAnnotatedPointList::SortPoints(int ivar, bool Fabs, bool HighFirst)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(plistXFM==NULL || Npoints<=0)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). Object not properly set or empty (Npoints=%d). \n", Npoints);
        return U_ERROR;
    }
    if(ivar<0 || ivar>=NDoubVar)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). ivar (=%d) out of range; NDoubvar=%d .\n", ivar, NDoubVar);
        return U_ERROR;
    }
    double* Var = new double[Npoints];
    if(Var==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). Memory allocation: Npoint=%d .\n", Npoints);
        return U_ERROR;
    }
    for(int n=0; n<Npoints; n++)
        Var[n] = plistXFM[n].GetValue(ivar);

    int* Index = GetOrderIndexArray(Var, Npoints, Fabs, HighFirst);
    delete[] Var;
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). Sorting values. \n");
        return U_ERROR;
    }
    UAnnotatedPoint* plistnew = new UAnnotatedPoint[NpointsAllocated];
    if(plistnew==NULL)
    {
        delete[] Index;
        CI.AddToLog("ERROR: UAnnotatedPointList::SortPoints(). Memory allocation, NpointsAllocated=%d  . \n", NpointsAllocated);
        return U_ERROR;
    }
    for(int ip=0; ip<Npoints; ip++)
        plistnew[ip] = plistXFM[Index[ip]];
    current = Index[current];

    delete[] plistXFM; plistXFM = plistnew;

    delete[] Index;
    return U_OK;
}

static int SortX(const void *elem1, const void *elem2)
{
    if(((UVector3*)elem1)->Getx() < ((UVector3*)elem2)->Getx()) return -1; 
    if(((UVector3*)elem1)->Getx() > ((UVector3*)elem2)->Getx()) return  1;
    return 0;
}
static int SortY(const void *elem1, const void *elem2)
{
    if(((UVector3*)elem1)->Gety() < ((UVector3*)elem2)->Gety()) return -1; 
    if(((UVector3*)elem1)->Gety() > ((UVector3*)elem2)->Gety()) return  1;
    return 0;
}
static int SortZ(const void *elem1, const void *elem2)
{
    if(((UVector3*)elem1)->Getz() < ((UVector3*)elem2)->Getz()) return -1; 
    if(((UVector3*)elem1)->Getz() > ((UVector3*)elem2)->Getz()) return  1;
    return 0;
}

UVector3 GetMedianPoint(const UVector3* Parray, int Npoints)
{
    qsort((void*)Parray, Npoints, sizeof(Parray[0]), SortX);
    double X = Parray[Npoints/2].Getx();

    qsort((void*)Parray, Npoints, sizeof(Parray[0]), SortY);
    double Y = Parray[Npoints/2].Gety();

    qsort((void*)Parray, Npoints, sizeof(Parray[0]), SortZ);
    double Z = Parray[Npoints/2].Getz();

    return UVector3(X, Y, Z);
}

double* GetDistanceTable(const UAnnotatedPointList& PL1, const UAnnotatedPointList& PL2)
{
    if(&PL1==NULL || PL1.GetError()!=U_OK || PL1.GetNPoints()<=0)
    {
        CI.AddToLog("ERROR: GetDistanceTable(). PL1-argument is NULL, erroneous or empty.\n");
        return NULL;
    }
    if(&PL2==NULL || PL2.GetError()!=U_OK || PL2.GetNPoints()<=0)
    {
        CI.AddToLog("ERROR: GetDistanceTable(). PL2-argument is NULL, erroneous or empty.\n");
        return NULL;
    }
    int     NP1  = PL1.GetNPoints();
    int     NP2  = PL2.GetNPoints();

    double* Dtab = new double[NP1*NP2];
    if(Dtab==NULL)
    {
        CI.AddToLog("ERROR: GetDistanceTable(). Memory allocation: NP1 = %d, NP2 = %d \n", NP1, NP2);
        return NULL;
    }

    for(int i1=0; i1<NP1; i1++)
    {
        UVector3 R1 = PL1.GetPointRef(i1);
        for(int i2=0; i2<NP2; i2++)
        {
            UVector3 R2 = PL2.GetPointRef(i2);
            Dtab[i1*NP2+i2] = (R1-R2).GetNorm();
        }
    }
    return Dtab;
}
