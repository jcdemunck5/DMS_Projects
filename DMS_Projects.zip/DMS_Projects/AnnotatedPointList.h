#ifndef _ANNOTATEDPOINTLISTINCLUDED
#define _ANNOTATEDPOINTLISTINCLUDED

#include "MatVec.h"
#include "String.h"
#include "FileName.h"
#include "Euler.h"
#include "LinTran.h"

typedef struct 
{
    int     dipole;             /* Which dipole in a multi-dipole set */
    float   begin;              /* Fitting time range */
    float   end;                /* Fitting time range */
    float   r0[3];              /* Sphere model origin */
    float   rd[3];              /* Dipole location */
    float   Q[3];               /* Dipole amplitude */
    float   goodness;           /* Goodness-of-fit */
    int     errors_computed;    /* Have we computed the errors */
    float   noise_level;        /* Noise level used for error computations */
    float   single_errors[5];   /* Single parameter error limits */
    float   error_matrix[5][5]; /* This fully describes the conf. ellipsoid */
    float   conf_vol;           /* The xyz confidence volume */
    float   khi2;               /* The khi^2 value */
    float   prob;               /* Probability to exceed khi^2 by chance */
    float   noise_est;          /* Total noise estimate */
} FIFFDipType;

#define MAXDOUBVAR 3

class DLL_IO UAnnotatedPoint
{
public:
    UAnnotatedPoint();
    UAnnotatedPoint(const UAnnotatedPoint& x);
    UAnnotatedPoint(UVector3 x, UString Annot, double V0=0., double V1=0., double V2=0.);
    UAnnotatedPoint& operator=(const UAnnotatedPoint& x);

    UVector3         GetPoint(void) const             {return p;}
    ErrorType        SetPoint(UVector3 x)             {p=x; return U_OK;}
    UString          GetAnnotation(void) const        {return Annotation;}
    ErrorType        SetAnnotation(UString Annot);
    ErrorType        SetAnnotation(const char* Annot) {return SetAnnotation(UString(Annot));}

    double           GetValue(int ival) const;
    ErrorType        SetValue(int ival, double Val);
    bool             IsSelected(void) const          {return Selected;}
    ErrorType        SetSelected(bool Sel)           {if(this) {Selected = Sel; return U_OK;} return U_ERROR;}
    ErrorType        SelectInRange(int ival, double MinVal, double MaxVal);
    ErrorType        SelectInRange(int NVal, const double* MinVal, const double* MaxVal);

protected:
    void             SetAllMembersDefault(void);

private:
    UVector3         p;
    UString          Annotation;
    double           Value[MAXDOUBVAR];
    bool             Selected;
};

class UPointList;
class USurface;
class UField;
class DLL_IO UAnnotatedPointList
{
public:
    UAnnotatedPointList();
    UAnnotatedPointList(const UAnnotatedPointList& PL);
    UAnnotatedPointList(UString PLName);
    UAnnotatedPointList(UFileName FName, UVector3 N, UVector3 L, UVector3 R);
    UAnnotatedPointList(UFileName FNameXFM, ULinTran X2R);

    UAnnotatedPointList(const UField* PList);

    virtual ~UAnnotatedPointList();
    virtual UAnnotatedPointList& operator=(const UAnnotatedPointList &PL);

    ErrorType               GetError() const {return error;}
    virtual const UString&  GetProperties(UString Comment) const;
    const UString&          GetPointsText(bool ConvertRef, bool AllPoints, bool Values) const;

    ULinTran                GetXfmToRef(void) const   {return XFMtoREF;}
    void                    SetXfmToRef(UEuler   Xfm) {XFMtoREF = Xfm; }
    void                    SetXfmToRef(ULinTran Xfm) {XFMtoREF = Xfm; }
    ErrorType               SetNewXfmCoords(UEuler NewXfm2Ref);

    int                     GetNPoints(void) const    {return Npoints;}
    void                    SetName(UString PLName)   {Name = PLName;}
    UString                 GetName(void) const       {return Name;}
    UVector3                GetCenter(void);
    ErrorType               Transform(ULinTran Xfm);
    ErrorType               TransformCenter(double Sx, double Sy, double Sz);
    ErrorType               TransformCenter(UEuler eul);
    ErrorType               CenterXFM();
    ErrorType               ForceInBox(UVector3 BminRef, UVector3 BmaxRef);

    int                     GetNDoubVar(void) const    {return NDoubVar;}
    ErrorType               AddVar(UString NewVarName, double DefValues, bool GoodBAD);
    UString                 GetVarName(int ivar) const;
    ErrorType               SetVarNames(UString VN1, UString VN2, UString VN3);
    int                     GetiVarUNK_BAD_OK(void) const {if(this) return iVarUNK_BAD_OK; return -1;}
    double                  GetMinRange(int ivar) const;
    double                  GetMaxRange(int ivar) const;
    double                  GetValue(int index, int ivar) const;
    ErrorType               SetValue(int index, int ivar, double val);
    bool                    IsPointSelected(int index) const;
    int                     GetIndexSelected(int indsel) const;
    int                     GetNPointsSelected(void) const;
    ErrorType               SelectInRange(int ival, double MinVal, double MaxVal);
    ErrorType               SelectInRange(int NVal, const double* MinVal, const double* MaxVal);
    ErrorType               UnselectNLR(void);

    UAnnotatedPoint         GetPoint(int index) const;
    int                     GetAnnotationIndex(UString Annotation) const;
    bool                    DoesAnnotationExist(UString Annotation) const;
    ErrorType               AddPoint(UVector3 x, UString Annot, const double* Var=NULL);
    ErrorType               AddPointRef(UVector3 Pref, UString Annot, const double* Var=NULL);
    ErrorType               ReplacePointRef(int index, UVector3 Pref, UString Annot, const double* Var=NULL);
    ErrorType               ChangePointRef(UVector3 Pref, int index);
    void                    CleanList(void) {Npoints = 0; XFMtoREF = UEuler(); current = 0; NDoubVar = 0;}

    UVector3                GetPointXfm(int index) const;
    UVector3                GetPointRef(int index) const;
    UVector3                FirstPointRef(void);
    UVector3                PrevPointRef(void);
    UVector3                NextPointRef(void);
    UVector3                LastPointRef(void);
    int                     DeleteDoublePoints(double Thresh);
    ErrorType               RemovePoint(int index);
    ErrorType               RemoveCurrentPoint(void);
    UString                 GetAnnotation(int index) const;
    ErrorType               SetAnnotation(int index, UString Annot);
    UString                 GetCurrentAnnotation(void) const;
    ErrorType               SetCurrentAnnotation(UString Annot);
    int                     GetCurrentIndex(void) const {return current;}
    UVector3                GetCurrentPointXfm(void) const;
    UVector3                GetCurrentPointRef(void) const;

    ErrorType               SortAnnotation(void);
    ErrorType               SortValues(int ival, bool UseFabs, bool HighFirst);
    UField*                 GetPLAsFieldRef(bool SortAnnot=false) const;
    UPointList*             GetPointListRef(bool SortAnnot=false) const;
    USurface*               GetSurfaceRef(void) const;

    ErrorType               SavePoints(const UFileName& PointFile) const;
    ErrorType               SavePointsRef(const UFileName& PointFile) const;
    ErrorType               WriteVTK(UFileName FileName, double Rad) const;
    bool                    HasNLRPoints(UVector3* NasRef, UVector3* LefRef, UVector3* RigRef) const;
    UPointList*             GetNLRAsPointListRef(void) const;
    ErrorType               SortPoints(int ivar, bool Fabs, bool HighFirst);

    static bool             IsPolhemusFile(UFileName FName);
    static bool             IsFindCoilsFile(UFileName FName);
    static bool             IsCTFDipFile(UFileName FName);

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);
    UAnnotatedPoint         *plistXFM;

private:
    ErrorType               error;
    static UString          Properties;

    UString                 Name;
    ULinTran                XFMtoREF;
    int                     Npoints;
    int                     NpointsAllocated;
    int                     current;
    int                     NDoubVar;
    int                     iVarUNK_BAD_OK;       // Variable that indicates Unknown, BAD or OK with variable values -1, 0, +1. 
    UString                 VarName[MAXDOUBVAR];

    ErrorType               ReadAsElcFile(UFileName FName);
    ErrorType               ReadAsPolhemusFile(UFileName FName);
    ErrorType               ReadAsFindCoilsFile(UFileName FName);
    ErrorType               ReadAsFiffFile(UFileName FName);
    ErrorType               ReadAsFiffDipFile(UFileName FName);
    ErrorType               ReadAsCTFDipFile(UFileName FName);
    ErrorType               ReadAsCTFSensors(UFileName FName);

    ErrorType               UpdateVarUNK_BAD_OK();
};

UVector3  GetMedianPoint(const UVector3* Parray, int Np);
double*   GetDistanceTable(const UAnnotatedPointList& PL1, const UAnnotatedPointList& PL2);

#endif // _ANNOTATEDPOINTLISTINCLUDED
