#ifndef ARRAY_H
#define ARRAY_H

#include "BasicInclude.h"


template <class Type> class UArray
{
public:
    UArray();
    UArray(int N);
    UArray(const UArray<Type>& A);
    ~UArray();

    UArray&         operator=(const UArray& A);
    Type&           operator[](int i);
    const Type&     operator[](int i) const;

    ErrorType       GetError() const;
    int             GetNelem() const;
    ErrorType       Resize(int N);

    ErrorType       AddElem(const Type& T);
    ErrorType       ReAllocateMemory(void);

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;
    Type            *Elem;
    int             NelemAlloc;
    int             Nelem;
};


template <class Type>
void UArray<Type>::SetAllMembersDefault(void)
{
    error      = U_OK;
    Elem       = NULL;
    Nelem      = 0;
    NelemAlloc = 0;
}

template <class Type>
void UArray<Type>::DeleteAllMembers(ErrorType E)
{
    delete[] Elem;
    SetAllMembersDefault();
    error = E;
}

template <class Type>
UArray<Type>::UArray<Type>()
{
    SetAllMembersDefault();
}

template <class Type>
UArray<Type>::UArray<Type>(int N)
{
    SetAllMembersDefault();
    error = Resize(N);
}
template <class Type>
UArray<Type>::UArray<Type>(const UArray<Type>& A)
{
    SetAllMembersDefault();
    *this = A;
}

template <class Type>
UArray<Type>::~UArray<Type>()
{
    DeleteAllMembers(U_OK);
}



template <class Type>
UArray<Type>& UArray<Type>::operator=(const UArray<Type>& A)
{
    if(this==NULL)
    {
        static UArray<Type> A; A.error=U_ERROR;
        CI.AddToLog("ERROR: UArray<Type>::operator=(). this==NULL. \n");
        return A;
    }
    if(&A==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UArray<Type>::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&A) return *this;

    DeleteAllMembers(U_OK);

    Nelem      = A.Nelem;
    NelemAlloc = A.NelemAlloc;

    if(A.Elem)
    {
        Elem = new Type[A.NelemAlloc];
        if(Elem==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UArray<Type>::operator=(). Memory allocation. A.NelemAlloc = %d .\n", A.NelemAlloc);
            return *this;
        }
        for(int n=0; n<A.NelemAlloc; n++) Elem[n] = A.Elem[n];
    }
    return *this;
}

template <class Type>
Type& UArray<Type>::operator[](int n)
{
    if(this==NULL || error!=U_OK || Elem==NULL)
    {
        static Type T;
        CI.AddToLog("ERROR: UArray<Type>::operator[]. Object NULL or erroneous or not properly set. \n");
        return T;
    }
    if(n<0 || n>=Nelem)
    {
        static Type T;
        CI.AddToLog("ERROR: UArray<Type>::operator[]. Argument out of range (n=%d, Nelem=%d) .\n", n, Nelem);
        return T;
    }
    return Elem[n];
}

template <class Type>
const Type& UArray<Type>::operator[](int n) const
{
    if(this==NULL || error!=U_OK || Elem==NULL)
    {
        static Type T;
        CI.AddToLog("ERROR: UArray<Type>::operator[]. Object NULL or erroneous or not properly set. \n");
        return T;
    }
    if(n<0 || n>=Nelem)
    {
        static Type T;
        CI.AddToLog("ERROR: UArray<Type>::operator[]. Argument out of range (n=%d, Nelem=%d) .\n", n, Nelem);
        return T;
    }
    return Elem[n];
}

template <class Type>
ErrorType UArray<Type>::GetError() const
{
    if(this) return error;
    return U_ERROR;
}

template <class Type>
int UArray<Type>::GetNelem() const
{
    if(this && error==U_OK) return Nelem;
    return 0;
}

template <class Type>
ErrorType UArray<Type>::Resize(int N)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UArray<Type>::Resize(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(N<0)
    {
        CI.AddToLog("ERROR: UArray<Type>::Resize(). Argument out of range (N=%d). \n", N);
        return U_ERROR;
    }
    if(N<=NelemAlloc)
    {
        Nelem = N;
        return U_OK;
    }

    int NewAlloc = 2*N/3+2;
    if(NewAlloc<100)   NewAlloc = 100;
    Type* ElemNew = new Type[NewAlloc];
    if(ElemNew==NULL)
    {
        CI.AddToLog("ERROR: UArray<Type>::Resize(). Memory allocation (NewAlloc = %d ). \n", NewAlloc);
        return U_ERROR;
    }
    for(int n=0; n<Nelem; n++) ElemNew[n] = Elem[n];

    delete[] Elem; Elem = ElemNew;
    Nelem      = N;
    NelemAlloc = NewAlloc;

    return U_OK;
}

template <class Type>
ErrorType UArray<Type>::AddElem(const Type& T)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UArray<Type>::AddElem(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NelemAlloc<=Nelem+1)
    {
        if(Resize(Nelem+1)!=U_OK)
        {
            CI.AddToLog("ERROR: UArray<Type>::AddElem(). Resizing array. \n");
            return U_ERROR;
        }
    }
    Elem[Nelem++] = T;
}

template <class Type>
ErrorType UArray<Type>::ReAllocateMemory(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UArray<Type>::ReAllocateMemory(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NelemAlloc==Nelem) return U_OK;

    Type NewElem* = new Type[Nelem];
    if(NewElem==NULL)
    {
        CI.AddToLog("WARNING: UArray<Type>::ReAllocateMemory(). Re-allocating memory, NelemAlloc = %d, Nelem = %d  .\n", NelemAlloc, Nelem);
        return U_ERROR;
    }

    for(int n=0; n<Nelem; n++) NewElem[n] = Elem[n];
    delete[] Elem;    Elem = NewElem;
    NelemAllc = Nelem;

    return U_OK;
}

#endif // ARRAY_H

