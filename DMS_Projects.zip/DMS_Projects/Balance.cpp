/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for balancing CTF MEG data, or forward models of MEG data.         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    17-08-01   Creation, splitting off from ReadCTFData.cpp
  JdM    07-02-03   Added positivity test on ncoef in constructor from resource
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    14-04-05   Added MEGLabel, name of channel for which co-efficients are valid
                    Added parameter on non-default constructor and changed meaning of channel parameter
  JdM    22-04-05   Compute offset parameter by comparing labels (instead of adding a fixed offset per channel type)
  JdM    22-02-06   IsMEGLabel(). Test this==NULL
  JdM    04-03-06   Added Balance() function that uses ReReferenceType i.s.o. UCTFData::ReReferenceType
  JdM    29-01-08   Balance(). return U_OK in case of ReRef==U_REF_RAW
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    20-06-15   Added WriteBinary() and FILE* constructor
*/

#include <string.h>
#include "Balance.h"
#include "Sensor.h"
#include "MEEGDataCTF.h"

const char*  UBalance::HEADERBEGIN = "Balance1.0";
const char*  UBalance::HEADEREND   = "BalanceEnd";

void UBalance::SetAllMembersDefault(void)
{
    error          = U_OK;
    DataGradOrder  = 0;    
    nTable         = 0;    
    Ncoeff         = NULL; 
    Coeff          = NULL; 
    Ref            = NULL; 
    MEGLabel       = NULL;
}
void UBalance::DeleteAllMembers(ErrorType E)
{
    delete[] Ncoeff;
    for(int k=0; k<nTable; k++)
    {
        if(Coeff) delete[]  Coeff[k];
        if(Ref)   delete[]  Ref[k];
    }
    delete[] Coeff;
    delete[] Ref;
    delete[] MEGLabel;

    SetAllMembersDefault();
    error = E;
}

UBalance::UBalance()
{
    SetAllMembersDefault();
}
UBalance::UBalance(const UBalance& Bal)
{
    SetAllMembersDefault();
    *this = Bal;
}

UBalance::UBalance(int iMEG, int iType, const resource* rez)
{
    SetAllMembersDefault();
    
    if(rez==NULL || iMEG<0 || iMEG>rez->genres.gSetUp.no_channels)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::UBalance(). Invalid input parameters, iMEG=%d\n",iMEG);
        return;
    }

/* Determine to which channel ichan iMEG corresponds: */
    int ichan = -1;
    for(int k=0, kk=0; k<rez->genres.gSetUp.no_channels; k++)
    {
        if(rez->senres[k].sensorTypeIndex!=iType) continue;
        if(kk==iMEG)
        {
            ichan = k;
            break;
        }
        kk++;
    }
    if(ichan<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::UBalance(). MEG channel not found: iMEG=%d\n",iMEG);
        return;
    }

    if(rez->senres[ichan].properGain==0.)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::UBalance(). Invalid Propergain for channel %d \n",ichan);
        return;
    }
    double CofactorChan = 1./rez->senres[ichan].properGain;
    double CofactorRef  = 0.;

    DataGradOrder = rez->senres[ichan].grad_order_no;
    switch(rez->senres[ichan].sensorTypeIndex)
    {
    case SENTYPE_MAGR:
    case SENTYPE_GRAR:
        nTable = 1;
        break;

    case SENTYPE_MEGGR:
        nTable = 5;
        break;
    default:
        error  = U_OK;
        nTable = 0;
        return;
    }
    Ncoeff   = new int[nTable];
    Coeff    = new double*[nTable];
    Ref      = new int*[nTable];
    MEGLabel = new char[USensor::MAXLABELSIZE];
    if(Ncoeff==NULL || Coeff==NULL || Ref==NULL||MEGLabel==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::UBalance(). Memory allocation error. \n");
        return;
    }

    for(int it=0; it<nTable; it++)
    {
        Ncoeff[it] = 0;
        Coeff[it]  = NULL;
        Ref[it]    = NULL;
    }
    int offset = -1;
    for(int k=0; k<rez->numcoef; k++)
    {
        if(strcmp(rez->scrr[k].sensorName, rez->chanNames[ichan])) continue;
        offset = k;
        break;
    }
    if(offset<0 || offset+nTable>rez->numcoef)
    {
        DeleteAllMembers(U_ERROR);
        static bool FirstMessage = true;
        if(FirstMessage==true)
        {
            CI.AddToLog("WARNING: UBalance::UBalance(). Computing SensorCoefResRec offset. Number of coefficients in resources file = %d .\n", rez->numcoef);
            FirstMessage = false;
        }
        return;
    }
    memset(MEGLabel, 0, USensor::MAXLABELSIZE);
    int it;
    for(it=0; it<nTable; it++)
    {
        int tab = -1;
        if(it==0) memcpy(MEGLabel, UMEEGDataCTF::TruncateResourceLabel(rez->scrr[offset+0].sensorName), USensor::MAXLABELSIZE-1);
        else if(strcmp(MEGLabel, UMEEGDataCTF::TruncateResourceLabel(rez->scrr[offset+it].sensorName)))
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBalance::UBalance(). MEG label not constant: first = %s, then %s \n", MEGLabel, UMEEGDataCTF::TruncateResourceLabel(rez->scrr[offset+it].sensorName));
            return;
        }
        switch(rez->scrr[offset+it].coefType)
        {
        case G1BR: tab = TAB_G1BR; break;
        case G2BR: tab = TAB_G2BR; break;
        case G3BR: tab = TAB_G3BR; break;
        case G2OI: tab = TAB_G2OI; break;
        case G3OI: tab = TAB_G3OI; break;
        default:   tab = 0;
        }
        int ncoef  = rez->scrr[offset+it].coefRec.num_of_coefs;
        Ncoeff[tab] = ncoef;

        Coeff[tab]  = NULL;
        Ref[tab]    = NULL;
        if(ncoef>=0)
        {
            Coeff[tab]  = new double[ncoef];
            Ref[tab]    = new int[ncoef];
        }
        if(Coeff[tab]==NULL || Ref[tab]==NULL || tab>=nTable)
        {
            if(tab>=nTable) CI.AddToLog("ERROR: UBalance::UBalance(). Unknown coeffient type: %d. \n", (int)rez->scrr[offset+it].coefType);
            else            CI.AddToLog("ERROR: UBalance::UBalance(). Memory allocation error; allocating tables, ncoef = %d,\n", ncoef);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int k=0; k<ncoef; k++)
        {
            if(Coeff[tab]==NULL || Ref[tab]==NULL) continue;

            Coeff[tab][k]    = rez->scrr[offset+it].coefRec.coefs_list[k];
            const char* rlab = rez->scrr[offset+it].coefRec.sensor_list[k];
            int ref = -1;
            for(int i=0, iref=0; i<rez->genres.gSetUp.no_channels; i++)
            {
                if(rez->senres[i].sensorTypeIndex!=SENTYPE_MAGR &&
                   rez->senres[i].sensorTypeIndex!=SENTYPE_GRAR) continue;
                if(!strcmp(rez->chanNames[i], rlab))
                {
                    ref         = iref;
                    CofactorRef = rez->senres[i].properGain;
                    break;
                }
                iref++;
            }
            if(ref<0 || CofactorRef==0.)
            {
                rez->scrr[offset+it].coefRec.num_of_coefs = 0;
                static bool FirstMessage = true;
                if(FirstMessage==true)
                {
                    if(ref<0)           CI.AddToLog("WARNING: UBalance::UBalance(). Al least one unresolved reference : %s .\n", rlab);
                    if(CofactorRef==0.) CI.AddToLog("WARNING: UBalance::UBalance(). Invalif properGain for reference : %s .\n", rlab);
                    FirstMessage = false;
                }
                DeleteAllMembers(U_ERROR);
                return;
            }
            else
            {
                Ref[tab][k]    = ref;
                Coeff[tab][k] *= (CofactorRef*CofactorChan);
            }
        }
    }
}

UBalance::UBalance(FILE* fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::UBalance(). Invalid NULL pointer. \n");
        return;
    }
    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBalance::UBalance(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }
    DataGradOrder = ::ReadBinaryInt(DefaultIntelData, fpIn);
    nTable        = ::ReadBinaryInt(DefaultIntelData, fpIn);
    if(DataGradOrder<0 || DataGradOrder>100 || nTable<0)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBalance::UBalance(). Invalid parameters read: DataGradOrder=%d, nTable=%d . \n", DataGradOrder, nTable);
        return;
    }
    if(nTable>0)
    {
        MEGLabel = new char   [USensor::MAXLABELSIZE];
        Ncoeff   = new int    [nTable];
        Coeff    = new double*[nTable];
        Ref      = new int*   [nTable];

        if(Coeff) for(int it=0; it<nTable; it++) Coeff[it] = NULL;
        if(Ref  ) for(int it=0; it<nTable; it++) Ref  [it] = NULL;

        if(MEGLabel==NULL || Ncoeff==NULL || Coeff==NULL || Ref==NULL)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UBalance::UBalance(). Memory allocation error. \n");
            return;
        }
        if(::ReadBinaryCharArray(MEGLabel, USensor::MAXLABELSIZE, DefaultIntelData, fpIn)!=U_OK ||
           ::ReadBinaryIntArray (Ncoeff  , nTable               , DefaultIntelData, fpIn)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UBalance::UBalance(). Reading label or Ncoeff. \n");
            return;
        }

        for(int it=0; it<nTable; it++)
        {
            int ncoef = Ncoeff[it];
            if(ncoef>0) Coeff[it] = new double[ncoef];
            if(ncoef>0) Ref[it]   = new int   [ncoef];

            if(Coeff[it]==NULL || Ref[it]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                fseek(fpIn, ioffOld, SEEK_SET);
                CI.AddToLog("ERROR: UBalance::UBalance(). Memory allocation, it=%d, ncoef=%d. \n", it, ncoef);
                return;
            }
            if(::ReadBinaryDoubleArray(Coeff[it], ncoef , DefaultIntelData, fpIn)!=U_OK ||
               ::ReadBinaryIntArray (Ref[it]  , ncoef , DefaultIntelData, fpIn)!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                fseek(fpIn, ioffOld, SEEK_SET);
                CI.AddToLog("ERROR: UBalance::UBalance(). Reading table at it =%d. \n",it);
                return;
            }
        }
    }
    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBalance::UBalance(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }
}
ErrorType UBalance::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }
    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(DataGradOrder, DefaultIntelData, fpOut);
    ::WriteBinary(nTable       , DefaultIntelData, fpOut);
    if(nTable>0)
    {
        if(MEGLabel==NULL || Ncoeff==NULL || Coeff==NULL || Ref==NULL)
        {
            CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). Invalid NULL pointer(s). \n");
            return U_ERROR;
        }
        ::WriteBinary(MEGLabel, USensor::MAXLABELSIZE, DefaultIntelData, fpOut);
        ::WriteBinary(Ncoeff  , nTable               , DefaultIntelData, fpOut);

        for(int it=0; it<nTable; it++)
        {
            if(Coeff[it]==NULL || Ref[it]==NULL)
            {
                CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). Invalid NULL pointer(s), it =%d. \n", it);
                return U_ERROR;
            }
            ::WriteBinary(Coeff[it], Ncoeff[it], DefaultIntelData, fpOut);
            ::WriteBinary(Ref[it]  , Ncoeff[it], DefaultIntelData, fpOut);
        }
    }
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UBalance::~UBalance()
{
    DeleteAllMembers(U_OK);
}

UBalance& UBalance::operator=(const UBalance &Bal)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UBalance::operator=(). this == NULL. \n");
        static UBalance B; B.error = U_ERROR;
        return B;
    }
    if(&Bal==NULL)
    {
        CI.AddToLog("ERROR: UBalance::operator=(). Invalid NULL argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&Bal) return *this;

    DeleteAllMembers(U_OK);

    if(Bal.nTable==0)
    {
        error          = Bal.error;
        DataGradOrder  = Bal.DataGradOrder;    
        nTable         = Bal.nTable;    
        return *this;
    }
    MEGLabel = new char[USensor::MAXLABELSIZE];
    Ncoeff   = new int[Bal.nTable];
    Coeff    = new double*[Bal.nTable];
    Ref      = new int*[Bal.nTable];

    if(MEGLabel==NULL || Ncoeff==NULL || Coeff==NULL || Ref==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBalance::operator=(). Memory allocation error. \n");
        return *this;
    }
    memcpy(MEGLabel, Bal.MEGLabel, USensor::MAXLABELSIZE);

    for(int it=0; it<Bal.nTable; it++)
    {
        int ncoef  = Bal.Ncoeff[it];
        Ncoeff[it] = ncoef;
        Coeff[it]  = new double[ncoef];
        Ref[it]    = new int[ncoef];
        if(Coeff[it]==NULL || Ref[it]==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBalance::operator=(). Memory allocation error; allocating tables, ncoef = %d,\n", ncoef);
            return *this;
        }
        for(int k=0; k<ncoef; k++)
        {
            Coeff[it][k]   = Bal.Coeff[it][k];
            Ref[it][k]     = Bal.Ref[it][k];
        }
    }
    error          = Bal.error;
    DataGradOrder  = Bal.DataGradOrder;    
    nTable         = Bal.nTable;    
    return *this;
}

ErrorType  UBalance::Balance(double* MEGdata, const double* REFdata, int nsamp, ReReferenceType ReRef) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBalance::Balance(). Object NULL or erroneous.\n");        
        return U_ERROR;
    }
    if(DataGradOrder<0 || DataGradOrder>3) 
    {
        CI.AddToLog("WARNING: UBalance::Balance(). Invalid data gradient order: %d .\n", DataGradOrder);        
        return U_OK;
    }
    if(MEGdata==NULL || REFdata==NULL)
    {
        CI.AddToLog("ERROR: UBalance::Balance(). Invalid NULL pointers as argument.\n");        
        return U_ERROR;
    }
    if(ReRef==U_REF_RAW) return U_OK;

    int           it       = 0;
    int           k        = 0;
    double*       pMEGdata = NULL;
    const double* pREFdata = NULL;

    switch(ReRef)
    {
    case U_REF_UNBALANCED:
        switch(DataGradOrder)
        {
        case 0: return U_OK;
        case 1: it = TAB_G1BR; break;
        case 2: it = TAB_G2BR; break;
        case 3: it = TAB_G3BR; break;
        }

        for(k=0; k<Ncoeff[it]; k++)
        {
            pMEGdata   =  MEGdata;
            pREFdata   =  REFdata + Ref[it][k] * nsamp;
            double Cof =  Coeff[it][k];

            for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                *pMEGdata  += *pREFdata * Cof;
        }
        break;


    case U_REF_FIRST:
        switch(DataGradOrder)
        {
        case 0:
            break;

        case 1:
            return U_OK;

        case 2:
        case 3:
            if(DataGradOrder==2) it = TAB_G2BR;
            if(DataGradOrder==3) it = TAB_G3BR;
           
            for(k=0; k<Ncoeff[it]; k++)
            {
                pMEGdata   =  MEGdata;
                pREFdata   =  REFdata + Ref[it][k] * nsamp;
                double Cof =  Coeff[it][k];

                for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                    *pMEGdata  += *pREFdata * Cof;
            }
            break;
        }

        it = TAB_G1BR;
        for(k=0; k<Ncoeff[it]; k++)
        {
            pMEGdata   =  MEGdata;
            pREFdata   =  REFdata + Ref[it][k] * nsamp;
            double Cof = -Coeff[it][k];

            for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                *pMEGdata  += *pREFdata * Cof;
        }
        break;

    case U_REF_SECOND:
        switch(DataGradOrder)
        {
        case 0:
            break;

        case 2:
            return U_OK;
        case 1:
        case 3:
            if(DataGradOrder==1) it = TAB_G1BR;
            if(DataGradOrder==3) it = TAB_G3BR;
           
            for(k=0; k<Ncoeff[it]; k++)
            {
                pMEGdata   =  MEGdata;
                pREFdata   =  REFdata + Ref[it][k] * nsamp;
                double Cof =  Coeff[it][k];

                for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                    *pMEGdata  += *pREFdata * Cof;
            }
            break;
        }

        it = TAB_G2BR;
        for(k=0; k<Ncoeff[it]; k++)
        {
            pMEGdata   =  MEGdata;
            pREFdata   =  REFdata + Ref[it][k] * nsamp;
            double Cof = -Coeff[it][k];

            for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                *pMEGdata  += *pREFdata * Cof;
        }
        break;

    case U_REF_THIRD:
        switch(DataGradOrder)
        {
        case 0:
            break;

        case 1:
        case 2:
            if(DataGradOrder==1) it = TAB_G1BR;
            if(DataGradOrder==2) it = TAB_G2BR;
           
            for(k=0; k<Ncoeff[it]; k++)
            {
                pMEGdata   =  MEGdata;
                pREFdata   =  REFdata + Ref[it][k] * nsamp;
                double Cof =  Coeff[it][k];

                for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                    *pMEGdata  += *pREFdata * Cof;
            }
            break;

        case 3:
            return U_OK;
        }

        it = TAB_G3BR;
        for(k=0; k<Ncoeff[it]; k++)
        {
            pMEGdata   =  MEGdata;
            pREFdata   =  REFdata + Ref[it][k] * nsamp;
            double Cof = -Coeff[it][k];

            for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                *pMEGdata  += *pREFdata * Cof;
        }
        break;

    case U_REF_SECONDFORWARD:
    case U_REF_THIRDFORWARD:

        if(ReRef==U_REF_SECONDFORWARD) it = TAB_G2OI;
        if(ReRef==U_REF_THIRDFORWARD)  it = TAB_G3OI;
        for(k=0; k<Ncoeff[it]; k++)
        {
            pMEGdata   =  MEGdata;
            pREFdata   =  REFdata + Ref[it][k] * nsamp;
            double Cof =  Coeff[it][k];

            for(int j=0; j<nsamp; j++, pMEGdata++, pREFdata++)
                *pMEGdata  -= *pREFdata * Cof;
        }
        break;

    default:
        CI.AddToLog("WARNING: UBalance::Balance(). Erroneous balancing parameter: ReRef = %d. \n",ReRef);        
        return U_ERROR;
    }
    return U_OK;
}

bool UBalance::IsMEGLabel(const char* TestLab) const
{
    if(this==NULL) 
    {
        CI.AddToLog("ERROR: UBalance::IsMEGLabel(). this==NULL.\n");        
        return false;
    }
    if(MEGLabel==NULL || TestLab==NULL) return false;
    if(strcmp(MEGLabel, TestLab)) return false;
    return true;
}
