#ifndef _CTFBALANCING_INCLUDED
#define _CTFBALANCING_INCLUDED

#include "MEEGDataBase.h"
#include "MegDefs.h"

class UBalance
{
public:
    UBalance();
    UBalance(FILE* fpIn);
    UBalance(const UBalance& Bal);
    UBalance(int ichan, int iType, const resource* rez);
    ~UBalance();
    UBalance& operator=(const UBalance &Bal);

    int                    GetDataGradOrder(void) const {return DataGradOrder;}
    ErrorType              GetError(void) const {return error;}
    ErrorType              Balance(double* MEGdata, const double* REFdata, int nsamp, ReReferenceType ReRef) const;
    bool                   IsMEGLabel(const char* TestLab) const;

    ErrorType              WriteBinary(FILE* fpOut) const;
protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static const char*     HEADERBEGIN;
    static const char*     HEADEREND;
    ErrorType              error;            // General errorflag
    int                    DataGradOrder;    // Gradient order in which data was recorded
    int                    nTable;           // The number of tables defined
    int*                   Ncoeff;           // The number of coefficients for each table
    double**               Coeff;            // Arrays of coefficients for each table
    int**                  Ref;              // The reference channel numbers for each table, ordered
                                             // in the order appearing in the file, starting from 0
    char*                  MEGLabel;         // Label of MEG channel for which balancing is valid
};


#endif// _CTFBALANCING_INCLUDED
