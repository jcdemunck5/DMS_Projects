/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     General simple general purpose functions                                     */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    07-08-99   creation.
  JdM    01-10-99   Added NOT()
  JdM    16-11-99   Bug Fix in: DoesFileExist() Test for NULL pointer
  JdM    29-01-00   compatibility with the Borland compiler (system includes first)
  JdM    15-05-00   Added CanFileBeCreated()
  JdM    29-06-00   Added declaration of UConsoleInterface CI
  JdM    29-06-00   DoesFileExist(). Test for empty string, before opening
  JdM    16-05-01   Added ToLowerCase() and ToUpperCase() and IsStringCompatible()
                    bug fixes: IsStringCompatible(), account for wild cards at the begin or end
  JdM    12-12-01   Renamed INTEL_byte_ORDER() into INTEL_PROCESSOR()
                    Added SwapArray()
  JdM    07-01-02   Added BoolAsText()
  JdM    27-03-02   Added DoesStringContainWildCard()
  JdM    29-05-02   Bug fixes in IsStringCompatible()
  JdM    26-06-02   Added IsStringEnding()
  JdM    31-08-02   Bug Fix: ToUpperCase()
  JdM    01-09-02   Add GetLine(), Making the file GetLine.c obsolete
                    Add GetNLines()
  JdM    05-03-03   BoolAsText(). Changed names of TRUE and FALSE strings
  JdM    28-10-03   Added GetNamesFromString()
  JdM    26-12-03   Added UpScalePosValue() and UpScaleDownValue()
  JdM    18-02-04   Added SwapVal()
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    11-06-05   Added GetNiceScaleParameters()
  JdM    13-06-05   Added GetNiceRangeParameters()
  JdM    11-07-05   Bug Fix: GetNiceRangeParameters(), increase loop by 1, on each pass of the loop
  JdM    08-05-06   Added IsStringBeginning()
  JdM    24-05-06   Added new version of SwapVal()
  JdM    28-08-06   GetNiceRangeParameters(). Minor change of algorithm
  JdM    23-11-06   Test for #define PUBLIC_SOURCES to avoid inclusion of FFTW-sources
  JdM    05-01-07   Swapped order of CI and FFTW to prevent creation of "test.log" file when FFTW wisdom cannot be read
  JdM    16-02-07   Added WriteBinary(), ReadBinaryBool(), ReadBinaryShort(),...,ReadBinaryDouble().
  JdM    17-03-07   IsStringBeginning() and IsStringEnding(): Add CaseSens param
  JdM    09-05-07   Added GetMedianIndex() (twice) and GetMedian() (twice)
  JdM    19-06-07   Added DoesStringContainLetters() and DoesStringContainNumbers()
  JdM    27-06-07   Added GetUpperQuantile() (twice) and GetUpperQuantileIndex() (twice)
  JdM    28-10-07   Added ReadBinaryCharArray() to ReadBinaryDoubleArray() and WriteBinary() for arrays
  JdM    24-11-07   Added NormalizeArray()
  JdM    19-04-08   UpScalePosValue(), DownScalePosValue(): Included factors 1.01 and 0.99 in argument.
  JdM    24-04-08   GetLine(): guarantee that last character of returned string is 0
  JdM    15-05-08   Added CopyFile()
  JdM    17-05-08   Added GetDataOrder()
  JdM    21-05-08   Bug fix: CopyFile(). Closing input and ouput files.
  JdM    27-09-08   Added GetNiceUpStep() and GetNiceDownStep()
  JdM    09-10-08   Added IsTiffFile() and QuarterQuantiles()
  JdM    14-10-08   Bug fix: GetNiceUpStep(), GetNiceDownStep(). case Val==0
  JdM    15-02-08   Bug Fix: ReadBinaryShort(),...,ReadBinaryDouble(): return swapped value
  JdM    27-03-09   Added IsBitMapFile()
  JdM    06-04-09   Added GetOrderIndexArray()
  JdM    10-04-09   Added CaseSense argument to IsStringCompatible()
  JdM    03-10-09   Added InterpolateType, and conversion functions
  JdM    15-12-09   Added GetFactorial()
  JdM    18-03-10   Added GetCumulativeBinomial() and GetBinomial()
  JdM    22-03-10   bug fix: GetFactorial(), declared Nmes as int
  JdM    30-04-10   Added GetEquivalenceClass()
  JdM    30-05-10   Added GetNearPrime() and new prime table (from 1 to 10000)
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    13-08-10   Added GetEquivalenceClass() with ClassIndex argument
  JdM    29-08-10   Added GetAverage(), GetMin() and GetMax()
  JdM    30-08-10   Added SortArray()
  JdM    04-10-10   Added GetCorrelation()
  JdM    27-10-10   Bug fix: GetInterpolateTypeText() return-statements missing.
  JdM    15-01-11   Added new ReadBinaryCharArray(), ReadBinaryUCharArray(),...,ReadBinaryDoubleArray()
  JdM    04-03-11   Added float version of GetMin() and GetMax()
  JdM    11-05-11   Added SearchIndex()
  JdM    08-06-11   Added NormalizeArrayFrobenius()
  JdM    07-08-11   GetNiceRangeParameters(). Added optinal parameter NInterval
  JdM    24-10-11   Added (three overloaded versions of) SemiSortArray()
  JdM    18-11-11   Added GetMedianAbs(). GetUpperQuantileIndex() added abs-parameter
  JdM    21-11-11   Bug Fix: GetUpperQuantileIndex() int version. Old code recursively called itself leading to stack overflows
  JdM    15-12-13   Added GetFrobeniusNorm()
  JdM    25-12-13   GetSumSquare() and GetImprod()
  JdM    13-03-14   Added GetNSmaller(), GetNSmallerEqual(), GetNLarger() and GetNLargerEqual()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    26-08-14   Added SIGN()
  JdM    05-10-14   Added FitLine() and GetSum()
  JdM    01-11-14   Added integer version of SearchIndex()
                    GetEquivalenceClass(). Allow NPair==0
  JdM    27-02-15   Bug fix: GetLine(). Set last char ==0, if it happened to be �\n�
  JdM    04-03-15   Bug fix: GetLine(). Keep �\n� to maintain compatibility with UAnalyzeLine()
  JdM    08-03-15   Added ReadBinaryChar(), ReadBinaryUChar(), ReadBinaryUShort() and ReadBinaryInt64()
  JdM    21-03-15   Added GetWindowProfile() and Bessel0() (from ULinearFilter::bessi0())
  JdM    14-04-15   GetEquivalenceClass(). if(Nelem<=0 || NPair<0) set NClass equal to 0.
  JdM    25-04-15   Moved SemiSortArray(), SortDouble(),...,GetUpperQuantileIndex() to new file SortSemiSort.cpp
  JdM    13-06-15   Added HasIDAtOffset()
 JdM/MV  01-12-15   BUG FIX. WriteBinary(const char*,) In old code char array was writen as integers.
                    Added WriteBinary(char,...) and WriteBinary(unsined char,...)
  JdM    07-05-17   Added GetLogGamma(), GetLogFactorial() and GetBinomialCoefficient()
  JdM    24-05-18   NormalizeArrayFrobenius() and GetFrobeniusNorm(). Added float version
 */

#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include"BasicInclude.h"
#include"LinearFilter.h"


#ifndef PUBLIC_SOURCES
UFFTWPlan         FFTW;
UDebug            AUTODEBUG;
#endif
UConsoleInterface CI;


const char*  GetInterpolateTypeText(InterpolateType INT)
{
    switch(INT)
    {
    case U_INTERPOL_CON     : return "PiecewiseConstant";
    case U_INTERPOL_LIN     : return "PiecewiseLinear";
    case U_INTERPOL_FFT     : return "FastFourierTransform";
    case U_INTERPOL_UNKNOWN : return "Unknown";
    }
    return "UnknownInterpolationType";
}
InterpolateType GetInterpolateType(int itype)
{
    switch(itype)
    {
    case  0: return U_INTERPOL_CON;
    case  1: return U_INTERPOL_LIN;
    case  2: return U_INTERPOL_FFT;
    case  3: return U_INTERPOL_UNKNOWN;
    }
    CI.AddToLog("ERROR: GetInterpolateType(). invalid index (itype=%d)  .\n", itype);
    return U_INTERPOL_UNKNOWN;
}
InterpolateType GetInterpolateType(const char* typestring)
{
    if(typestring==NULL) return U_INTERPOL_UNKNOWN;
    for(int i=0; i<4; i++)
    {
        InterpolateType INT = GetInterpolateType(i);
        if(IsStringCompatible(GetInterpolateTypeText(INT), typestring, false) ) return INT;
    }
    return U_INTERPOL_UNKNOWN;
}
double* GetWindowProfile(WindowType Win, int Nsamp, double AlfaBeta)
{
    if(Nsamp<=1)
    {
        CI.AddToLog("ERROR: GetWindowProfile(). Invalid number of samples: %d  .\n", Nsamp);
        return NULL;
    }
    if(Win==U_WIN_HAMMING)
    {
        if(AlfaBeta>=1.)
        {
            CI.AddToLog("ERROR: GetWindowProfile(). AlfaBeta parameter (%f)  .\n", AlfaBeta);
            return NULL;
        }
        AlfaBeta = Win==U_WIN_HAMMING ? ULinearFilter::GetAlfa() : ULinearFilter::GetBeta();
    }

    double* Window =new double[Nsamp];
    if(Window==NULL)
    {
        CI.AddToLog("ERROR: GetWindowProfile(). Memory allocation, Nsamp = %d  .\n", Nsamp);
        return NULL;
    }

    double M      = Nsamp/2.;
    double help   = Win==U_WIN_TRIANGULAR ? double(Nsamp/2) : Bessel0(AlfaBeta);

    switch(Win)
    {
    case U_WIN_BLOCK     : for(int n=0; n<Nsamp; n++)  Window[n] = 1.;                                                                 break;
    case U_WIN_HAMMING   : for(int n=0; n<Nsamp; n++)  Window[n] = AlfaBeta + (1-AlfaBeta)*cos((PI2*(n-M))/Nsamp);                     break;
    case U_WIN_KAISER    : for(int n=0; n<Nsamp; n++)  Window[n] = Bessel0(AlfaBeta*sqrt(MIN(1.,MAX(0.,1.-(n-M)*(n-M)/(M*M)))))/help;  break;
    case U_WIN_TRIANGULAR: for(int n=0; n<Nsamp; n++)  Window[n] = n<=Nsamp/2 ? (n+1)/help : Window[Nsamp-1-n];                         break;
    default:
        delete[] Window;
        CI.AddToLog("ERROR: GetWindowProfile(). Unsupported window type: %d  .\n", int(Win));
        return NULL;
    }
    return Window;
}

bool  NOT(bool b)
{
    if(b==true) return false;
    else        return true;
}

/****
bool operator||(bool b1, bool b2)
{
    if(b1==false && b2==false) return false;
    return true;
}

bool operator&&(bool b1, bool b2)
{
    if(b1==false || b2==false) return false;
    return true;
}
****/

bool INTEL_PROCESSOR(void)
/*
     Returns true on an INTEL-compatible processor and false on a MOTEROLA
     compatible processor.
 */
{
    int i=1;
    if(!(int)(*(char*)(&i))) return false; // Big Endian
    else                     return true;  // Little Endian
}

short SwapVal(short Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    short Sval = Val;
    char* ch   = (char*)(&Sval);
    char dum   = ch[1];
    ch[1]      = ch[0];
    ch[0]      = dum;
    return Sval;
}

int SwapVal(int Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    int  Ival  = Val;
    char* ch   = (char*)(&Ival);
    char dum   = ch[3];
    ch[3]      = ch[0];
    ch[0]      = dum;
    dum        = ch[2];
    ch[2]      = ch[1];
    ch[1]      = dum;
    return Ival;
}
uint32_t SwapVal(uint32_t Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    uint32_t  Ival  = Val;
    char* ch   = (char*)(&Ival);
    char dum   = ch[3];
    ch[3]      = ch[0];
    ch[0]      = dum;
    dum        = ch[2];
    ch[2]      = ch[1];
    ch[1]      = dum;
    return Ival;
}
int64_t SwapVal(int64_t Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    int64_t  Ival  = Val;
    char* ch   = (char*)(&Ival);

    char dum    = ch[7];
    ch[7]       = ch[0];
    ch[0]       = dum;

    dum         = ch[6];
    ch[6]       = ch[1];
    ch[1]       = dum;

    dum         = ch[5];
    ch[5]       = ch[2];
    ch[2]       = dum;

    dum         = ch[4];
    ch[4]       = ch[3];
    ch[3]       = dum;

    return Ival;
}

uint64_t SwapVal(uint64_t Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    uint64_t  Ival  = Val;
    char* ch   = (char*)(&Ival);

    char dum    = ch[7];
    ch[7]       = ch[0];
    ch[0]       = dum;

    dum         = ch[6];
    ch[6]       = ch[1];
    ch[1]       = dum;

    dum         = ch[5];
    ch[5]       = ch[2];
    ch[2]       = dum;

    dum         = ch[4];
    ch[4]       = ch[3];
    ch[3]       = dum;

    return Ival;
}

float SwapVal(float Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    float Fval = Val;
    char* ch   = (char*)(&Fval);
    char dum   = ch[3];
    ch[3]      = ch[0];
    ch[0]      = dum;
    dum        = ch[2];
    ch[2]      = ch[1];
    ch[1]      = dum;
    return Fval;
}

double SwapVal(double Val, bool IntelData)
/*
    Return a swapped version of Val, if its data type (given by IntelData) in not compatible with the active processor
 */
{
    if(INTEL_PROCESSOR()==IntelData) return Val;

    double Dval = Val;
    char* ch    = (char*)(&Dval);
    char dum    = ch[7];
    ch[7]       = ch[0];
    ch[0]       = dum;

    dum         = ch[6];
    ch[6]       = ch[1];
    ch[1]       = dum;

    dum         = ch[5];
    ch[5]       = ch[2];
    ch[2]       = dum;

    dum         = ch[4];
    ch[4]       = ch[3];
    ch[3]       = dum;
    return Dval;
}

void SwapArray(short  *array, int npoints, bool IntelData)
/*
    Swaps the short data array, if the data is incompatible with the active processor
    else, simply return
 */
{
    if(INTEL_PROCESSOR()==IntelData) return;
    if(array==NULL) return;

    for(int i=0; i<npoints; i++)
    {
        char *ch = (char*) (array+i);
        char dum = ch[1];
        ch[1]    = ch[0];
        ch[0]    = dum;
    }
}

void SwapArray(int *array, int npoints, bool IntelData)
/*
    Swaps the int data array, if the data is incompatible with the active processor
    else, simply return
 */
{
    if(INTEL_PROCESSOR()==IntelData) return;
    if(array==NULL) return;

    for(int i=0; i<npoints; i++)
    {
        char *ch = (char*) (array+i);
        char dum = ch[3];
        ch[3]    = ch[0];
        ch[0]    = dum;
        dum      = ch[2];
        ch[2]    = ch[1];
        ch[1]    = dum;
    }
}

void SwapArray(float  *array, int npoints, bool IntelData)
/*
    Swaps the float data array, if the data is incompatible with the active processor
    else, simply return
 */
{
    if(INTEL_PROCESSOR()==IntelData) return;
    if(array==NULL) return;

    for(int i=0; i<npoints; i++)
    {
        char *ch = (char*) (array+i);
        char dum = ch[3];
        ch[3]    = ch[0];
        ch[0]    = dum;
        dum      = ch[2];
        ch[2]    = ch[1];
        ch[1]    = dum;
    }
}

void  SwapArray(double *array, int npoints, bool IntelData)
/*
    Swaps the double data array, if the data is incompatible with the active processor
    else, simply return
 */
{
    if(INTEL_PROCESSOR()==IntelData) return;
    if(array==NULL) return;

    for(int i=0; i<npoints; i++)
    {
        char *ch = (char*) (array+i);
        char dum = ch[7];
        ch[7]    = ch[0];
        ch[0]    = dum;

        dum      = ch[6];
        ch[6]    = ch[1];
        ch[1]    = dum;

        dum      = ch[5];
        ch[5]    = ch[2];
        ch[2]    = dum;

        dum      = ch[4];
        ch[4]    = ch[3];
        ch[3]    = dum;
    }
}

bool DoesFileExist(const char *FileName)
/*
     Returns true iff FileName[] exists and can be opened.
 */
{
    if(FileName==NULL) return false;
    if(FileName[0]==0) return false;

    FILE* fp = fopen(FileName,"rb");
    if(!fp) return false;
    fclose(fp);
    return true;
}

bool CanFileBeCreated(const char *FileName)
/*
     Returns true iff FileName[] can be created. This is a useful test at the
     begining of a long lasting program.
 */
{
    if(FileName==NULL) return false;

    FILE* fp = fopen(FileName,"wb");
    if(!fp) return false;
    fclose(fp);
    return true;
}

uint32_t GetFileSize(FILE *fp)
/*
    Returns the size of the opened file, with file pointer fp, in bytes.
 */
{
    if(fp==NULL) return 0;

    uint32_t ioffOld = ftell(fp);
    fseek(fp, 0, SEEK_END);
    uint32_t size = ftell(fp);
    fseek(fp, ioffOld, SEEK_SET);
    return size;
}

bool HasIDAtOffset(FILE* fp, const char* ID, int Offset)
{
    if(fp==NULL || ID==NULL) 
    {
        CI.AddToLog("ERROR: HasIDAtOffset(). Invalid NULL pointers.\n");
        return false;
    }
    uint32_t ioffOld = ftell(fp);
    if(Offset>=0) fseek(fp, Offset, SEEK_SET);

    size_t   NB   = strlen(ID);
    for(int n=0; n<NB; n++) 
    {
        char c = 0; fread(&c,1,1,fp);
        if(c!=ID[n]) 
        {
            fseek(fp, ioffOld, SEEK_SET);
            return false;
        }
    }
    return true;
}

bool IsBitMapFile(FILE* fp)
{
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: IsBitMapFile(). Invalid NULL argument. \n");
        return false;
    }

    unsigned int ioff = ftell(fp);
    rewind(fp);
    char B = 0; fread(&B, 1, 1, fp);
    char M = 0; fread(&M, 1, 1, fp);
    bool BitMapFile = (B=='B'&& M=='M')  ||  (B=='M'&& M=='B');
    fseek(fp, ioff, SEEK_SET);

    return BitMapFile;
}

bool IsTiffFile(FILE* fp)
{
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: IsTiffFile(). Invalid NULL argument. \n");
        return false;
    }
    unsigned int ioff = ftell(fp);
    rewind(fp);

    bool TiffFile  = true;
    bool IntelData = true;
    short temp = ReadBinaryShort(IntelData, fp);
    if(temp==0x4949 || temp==0x4d4d) TiffFile = true;
    else                             TiffFile = false;

    if(TiffFile==true)
    {
        temp = ReadBinaryShort(IntelData, fp);
        if(temp!=42 && temp!=42*256) TiffFile = false;
    }
    fseek(fp, ioff, SEEK_SET);

    return TiffFile;
}
ErrorType WriteBinary(unsigned char Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    fwrite(&Val, 1, 1, fp);
    return U_OK;
}
ErrorType WriteBinary(char Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    fwrite(&Val, 1, 1, fp);
    return U_OK;
}
ErrorType WriteBinary(bool Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = ((!Val)==false);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(short Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(int Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(uint32_t Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(uint64_t Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(float Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(double Val, bool IntelData, FILE* fp)
{
    if(fp==NULL) return U_ERROR;
    Val = SwapVal(Val, IntelData);
    fwrite(&Val, 1, sizeof(Val), fp);
    return U_OK;
}
ErrorType WriteBinary(const char* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL || Npoints<=0 || fp==NULL) return U_ERROR;

    fwrite(array, 1, Npoints, fp);
    return U_OK;
}
ErrorType WriteBinary(const short* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL || Npoints<=0 || fp==NULL) return U_ERROR;

    if(INTEL_PROCESSOR()==IntelData)
    {
        fwrite(array, sizeof(array[0]), Npoints, fp);
    }
    else
    {
        for(int k=0; k<Npoints; k++) WriteBinary(array[k], IntelData, fp);
    }
    return U_OK;
}
ErrorType WriteBinary(const int* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL || Npoints<=0 || fp==NULL) return U_ERROR;

    if(INTEL_PROCESSOR()==IntelData)
    {
        fwrite(array, sizeof(array[0]), Npoints, fp);
    }
    else
    {
        for(int k=0; k<Npoints; k++) WriteBinary(array[k], IntelData, fp);
    }
    return U_OK;
}
ErrorType WriteBinary(const float* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL || Npoints<=0 || fp==NULL) return U_ERROR;

    if(INTEL_PROCESSOR()==IntelData)
    {
        fwrite(array, sizeof(array[0]), Npoints, fp);
    }
    else
    {
        for(int k=0; k<Npoints; k++) WriteBinary(array[k], IntelData, fp);
    }
    return U_OK;
}
ErrorType WriteBinary(const double* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL || Npoints<=0 || fp==NULL) return U_ERROR;

    if(INTEL_PROCESSOR()==IntelData)
    {
        fwrite(array, sizeof(array[0]), Npoints, fp);
    }
    else
    {
        for(int k=0; k<Npoints; k++) WriteBinary(array[k], IntelData, fp);
    }
    return U_OK;
}
bool ReadBinaryBool(bool IntelData, FILE* fp)
{
    if(fp==NULL) return false;
    char B[sizeof(bool)];
    fread(B, 1, sizeof(bool), fp);
    for(int k=0; k<sizeof(bool); k++) if(B[k]) return true;
    return false;
}

char ReadBinaryChar(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    char Val = 0; fread(&Val, 1, sizeof(Val), fp); return Val;
}
unsigned char ReadBinaryUChar(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    unsigned char Val = 0; fread(&Val, 1, sizeof(Val), fp); return Val;
}
short ReadBinaryShort(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    short Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
unsigned short ReadBinaryUShort(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    unsigned short Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
int ReadBinaryInt(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    int Val = 0; fread(&Val, 1, sizeof(Val), fp);   return SwapVal(Val, IntelData);
}
uint32_t ReadBinaryUInt(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    uint32_t Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
int64_t ReadBinaryInt64(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    int64_t Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
uint64_t ReadBinaryUInt64(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    uint64_t Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
float ReadBinaryFloat(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0;
    float Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}
double ReadBinaryDouble(bool IntelData, FILE* fp)
{
    if(fp==NULL) return 0.;
    double Val = 0; fread(&Val, 1, sizeof(Val), fp); return SwapVal(Val, IntelData);
}

ErrorType ReadBinaryCharArray(char* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). fp==NULL\n");
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    return U_OK;
}
char* ReadBinaryCharArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). fp==NULL\n");
        return NULL;
    }
    char* array = new char[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryCharArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    return array;
}
ErrorType ReadBinaryUCharArray(unsigned char* array, int Npoints, bool IntelData, FILE* fp)
{
    return ReadBinaryCharArray((char*) array, Npoints, IntelData, fp);
}
unsigned char* ReadBinaryUCharArray (int Npoints, bool IntelData, FILE* fp)
{
    return (unsigned char*) ReadBinaryCharArray(Npoints, IntelData, fp);
}
ErrorType ReadBinaryBoolArray(bool* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). fp==NULL\n");
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    return U_OK;
}
bool* ReadBinaryBoolArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). fp==NULL\n");
        return NULL;
    }
    bool* array = new bool[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryBoolArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    return array;
}
ErrorType ReadBinaryShortArray(short* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). fp==NULL\n");
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    SwapArray(array, Npoints, IntelData);
    return U_OK;
}

short* ReadBinaryShortArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). fp==NULL\n");
        return NULL;
    }
    short* array = new short[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryShortArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    SwapArray(array, Npoints, IntelData);
    return array;
}
ErrorType ReadBinaryIntArray(int* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). fp==NULL\n");
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    SwapArray(array, Npoints, IntelData);
    return U_OK;
}
int* ReadBinaryIntArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). fp==NULL\n");
        return NULL;
    }
    int* array = new int[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryIntArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    SwapArray(array, Npoints, IntelData);
    return array;
}
ErrorType ReadBinaryFloatArray(float* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). fp==NULL\n");
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    SwapArray(array, Npoints, IntelData);
    return U_OK;
}
float* ReadBinaryFloatArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). fp==NULL\n");
        return NULL;
    }
    float* array = new float[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryFloatArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    SwapArray(array, Npoints, IntelData);
    return array;
}
ErrorType ReadBinaryDoubleArray(double* array, int Npoints, bool IntelData, FILE* fp)
{
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Data pointer NULL. \n");
        return U_ERROR;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). fp==NULL\n");
        return U_ERROR;
    }
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Npoints==%d\n", Npoints);
        return U_ERROR;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Only first %d points are read.\n", int(Nread));
        return U_ERROR;
    }
    SwapArray(array, Npoints, IntelData);
    return U_OK;
}
double* ReadBinaryDoubleArray(int Npoints, bool IntelData, FILE* fp)
{
    if(Npoints<=0)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Npoints==%d\n", Npoints);
        return NULL;
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). fp==NULL\n");
        return NULL;
    }
    double* array = new double[Npoints];
    if(array==NULL)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Memory allocation, Npoints = %d  .\n", Npoints);
        return NULL;
    }
    size_t Nread = fread(array, sizeof(array[0]), Npoints, fp);
    if(Nread<(unsigned int)Npoints)
    {
        CI.AddToLog("ERROR: ReadBinaryDoubleArray(). Only first %d points are read.\n", int(Nread));
        delete[] array;
        return NULL;
    }
    SwapArray(array, Npoints, IntelData);
    return array;
}

char* GetLine(char *string, int nchar, FILE *fp)
/*
    Get a string from an opened file, with at most nchar characters. When there are
    more characters on the line than nchar, increase the file pointer to the end of line.
 */
{
    if(string==NULL || fp==NULL) return NULL;

    int n=0;
    int c=0;

    memset(string,0,nchar);
    while( (c=fgetc(fp))!=EOF)
    {
        if(n<nchar-1) string[n++] = char(c);                // Guarantee that last char is 0
        if(c=='\n')  
        {
            if(string[n-1]=='\n') string[n]=0;              // Guarantee that last char is 0 (but keep \n)
            return string;
        }
    }
    if(n==0) return NULL;
    return string;
}

int GetNLines(FILE *fp)
/*
    Return the number of lines from the open file associated with fp.
 */
{
    if(fp==NULL) return 0;

    unsigned int ioff = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char string[10];
    int N=0;
    while(GetLine(string, sizeof(string), fp)) N++;

    fseek(fp, ioff, SEEK_SET);

    return N;
}
ErrorType CopyFile(const char *FileIn, const char *FileOut)
{
    if(FileIn==NULL)
    {
        CI.AddToLog("ERROR: CopyFile(). Input file name NULL. \n");
        return U_ERROR;
    }
    if(DoesFileExist(FileIn)==false)
    {
        CI.AddToLog("ERROR: CopyFile(). Input file does not exist (%s). \n", FileIn);
        return U_ERROR;
    }
    if(FileOut==NULL)
    {
        CI.AddToLog("ERROR: CopyFile(). Output file name NULL. \n");
        return U_ERROR;
    }
    if(CanFileBeCreated(FileOut)==false)
    {
        CI.AddToLog("ERROR: CopyFile(). Output file cannot be created (%s). \n", FileOut);
        return U_ERROR;
    }

    FILE* fpIn   = fopen(FileIn, "rb");
    FILE* fpOut  = fopen(FileOut, "wb");
    if(fpIn==NULL || fpOut==NULL)
    {
        if(fpIn ) fclose(fpIn);
        if(fpOut) fclose(fpOut);
        CI.AddToLog("ERROR: CopyFile(). Opening files (%s or %s). \n", FileIn, FileOut);
        return U_ERROR;
    }
    int Nbytes = GetFileSize(fpIn);
    int BSize  = MIN(Nbytes, 100000);
    char*        Buffer = new char[1+BSize];
    if(Buffer==NULL)
    {
        fclose(fpIn );
        fclose(fpOut);
        CI.AddToLog("ERROR: CopyFile(). Allocating buffer memory (BSize = %d). \n", BSize);
        return U_ERROR;
    }
    int Remainder = Nbytes;
    while(Remainder>0)
    {
        int NCopy = MIN(Remainder, BSize);
        fread (Buffer,1, NCopy, fpIn);
        fwrite(Buffer,1, NCopy, fpOut);
        Remainder -= NCopy;
    }
    fclose(fpIn );
    fclose(fpOut);
    return U_OK;
}


const char* BoolAsText(bool boolean)
{
    static char __TRUE[6]  = "TRUE";
    static char __FALSE[6] = "FALSE";
    if(boolean==true) return __TRUE;
    else              return __FALSE;
}

int UpperPower2(int n)
/*
    Return the smallest power of 2, larger than n.
 */
{
    int nsa2 =1;
    while(nsa2<n) nsa2 *= 2;
    return nsa2;
}

int LowerPower2(int n)
/*
    Return the largest power of 2, smaller than n.
 */
{
    return UpperPower2(n)/2;
}

double GetNiceUpStep(double DMin, double DMax, double Val)
{
    if(DMax<=DMin)
    {
        if(DMin==DMax)  CI.AddToLog("ERROR: GetNiceUpStep(). DMin = %f, DMax = %f .\n", DMin, DMax);
        return DMax;
    }
    if(Val < DMin) return DMin;
    if(DMax<=Val ) return DMax;

    double  H = exp(log(10.)*ceil(log(DMax-DMin)/log(10.)));
    double  S = 1.;
    if(H>2*(DMax-DMin)) S=H/20.;
    else                S=H/10.;

    if(Val==0)  Val = MIN((Val+0.001*(DMax-DMin)), DMax);
    double Nice = S*ceil(1.000000001*Val/S);
    return MAX(DMin, MIN(DMax, Nice));
}
double GetNiceDownStep(double DMin, double DMax, double Val)
{
    if(DMax<=DMin)
    {
        if(DMin==DMax)  CI.AddToLog("ERROR: GetNiceDownStep(). DMin = %f, DMax = %f .\n", DMin, DMax);
        return DMax;
    }
    if(Val <=DMin) return DMin;
    if(DMax< Val ) return DMax;

    double  H = exp(log(10.)*ceil(log(DMax-DMin)/log(10.)));
    double  S = 1.;
    if(H>2*(DMax-DMin)) S=H/20.;
    else                S=H/10.;

    if(Val==0)  Val = MAX((Val-0.001*(DMax-DMin)), DMin);
    double Nice = S*floor(0.99999999*Val/S);
    if(Nice==Val) Nice-=S;
    return MAX(DMin, MIN(DMax, Nice));
}

ErrorType GetNiceScaleParameters(double DMin, double DMax, double* Offset, double*Step)
{
    if(Offset==NULL || Step==NULL) return U_ERROR;
    if(DMax<=DMin)
    {
        CI.AddToLog("ERROR: GetNiceScaleParameters(). DMin = %f, DMax = %f .\n", DMin, DMax);
        return U_ERROR;
    }


    double H     = 1.;
    double off   = 1.;
    double ste   = 1.;

    if(fabs(DMax)>fabs(DMin)/2)
    {
        H = exp(log(10.)*ceil(log(fabs(DMax))/log(10.)));
        if(DMax<0) H=-H;

        if(H/5>DMax)      { off=H/5.; ste=H/20.;}
        else if(H/2>DMax) { off=H/2.; ste=H/20.;}
        else              { off=H   ; ste=H/10.;}

        *Step       = ste;
        if(H==0)  H = 1.;
        *Offset     = H;
        double Test = H;
        int    loop = 0;
        while(Test>DMin && loop<1000)
        {
            Test -= H;
            if(fabs(Test)<*Offset) *Offset = Test;
            loop++;
        }
    }
    else
    {
        H = exp(log(10.)*ceil(log(fabs(DMin))/log(10.)));
        if(DMin<0) H=-H;

        if(H  <DMin)      { off=H   ; ste=H/10.;}
        else if(H/2<DMin) { off=H/2.; ste=H/20.;}
        else              { off=H/5.; ste=H/20.;}

        *Step       = ste;
        if(H==0)  H = 1.;
        *Offset     = H;
        double Test = H;
        int    loop = 0;
        while(Test<DMax && loop<1000)
        {
            Test += H;
            if(fabs(Test)<*Offset) *Offset = Test;
            loop++;
        }
    }
    return U_OK;
}
ErrorType GetNiceRangeParameters(double DMin, double DMax, double* DMinNice, double*DMaxNice, int* NInterval)
{
    if(DMinNice==NULL || DMaxNice==NULL) return U_ERROR;
    if(DMax<=DMin)
    {
        CI.AddToLog("ERROR: GetNiceRangeParameters(). DMin = %f, DMax = %f .\n", DMin, DMax);
        return U_ERROR;
    }
    double Offset=0.;
    double Step  =1.;
    if(GetNiceScaleParameters(DMin, DMax, &Offset, &Step)!=U_OK) return U_ERROR;

    double dmiNice = DMin;
    double dmaNice = DMax;
    if(NInterval) *NInterval = 0;
    if(Offset>DMin)
    {
        dmiNice = Offset;
        int loop  = 0;
        while(dmiNice>DMin)
        {
            if(loop>=1000) return U_ERROR;
            dmiNice-=Step;
            loop++;
        }
        if(NInterval) *NInterval += loop;
    }
    else
        dmiNice = Offset;

    int loop=0;
    dmaNice = dmiNice + Step;
    while(dmaNice<DMax)
    {
        if(loop>=1000) return U_ERROR;
        dmaNice+=Step;
        loop++;
    }
    *DMinNice = dmiNice;
    *DMaxNice = dmaNice;
    if(NInterval) *NInterval += (loop+1);

    return U_OK;
}

double UpScalePosValue(double PosVal)
{
    if(PosVal<=0)
    {
        CI.AddToLog("ERROR: UpScalePosValue(). Argument (%f) not positive. \n", PosVal);
        return 0.;
    }
    double H = exp(log(10.)*ceil(log(1.01*PosVal)/log(10.)));

    if(H/5>PosVal)       return H/5.;
    else if(H/2>PosVal)  return H/2.;
    else if(H  >PosVal)  return H   ;

    return H*2 ;
}

double DownScalePosValue(double PosVal)
{
    if(PosVal<=0)
    {
        CI.AddToLog("ERROR: DownScalePosValue(). Argument (%f) not positive. \n", PosVal);
        return 0.;
    }
    double H = exp(log(10.)*ceil(log(0.99*PosVal)/log(10.)));

    if(H/2<PosVal)       return H/ 2;
    else if(H/5<PosVal)  return H/ 5;
    else if(H/10<PosVal) return H/10;

    return H/20;
}

char* GetTime(void)
/*
    return time and date in the form of an ASCII-string.
 */
{
    time_t long_time;
    time( &long_time );
    struct tm *newtime = localtime( &long_time );
    return asctime( newtime );
}

char ToLowerCase(char c)
{
    if('A'<=c && c<='Z') return c+'a'-'A';
    return c;
}
char ToUpperCase(char c)
{
    if('a'<=c && c<='z') return c-'a'+'A';
    return c;
}
bool IsBlankChar(char c)
{
    if(c<=' ' ||c==',' || c==';' || c=='|' || 127<=c) return true;
    return false;
}
int SetBlankNull(char* Line, int N)
{
    if(Line==NULL) return -1;
    int Nset = 0;
    for(int n=0; n<N; n++)
        if(IsBlankChar(Line[n]))
        {
            Line[n] = 0;
            Nset++;
        }
    return Nset;
}


bool DoesStringContainWildCard(const char* String)
/*
    Return false iff String==NULL or iff String[] does at least contain one '*'
 */
{
    if(String==NULL) return false;

    for(unsigned int k=0; k<strlen(String); k++)
        if(String[k]=='*') return true;

    return false;
}

bool IsStringEnding(const char* String, const char* End, bool CaseSens)
/*
     Return true iff String is ending with End[]
 */
{
    if(String==NULL || End==NULL) return true;

    size_t Ns = strlen(String);
    size_t Ne = strlen(End);
    if(Ne>Ns) return false;

    if(CaseSens==true)
    {
        for(size_t ks=Ns, ke=Ne; ks>=0 && ke>=0; ks--, ke--)
            if(String[ks] != End[ke]) return false;
        return true;
    }

    char* LowerString = new char[Ns+1];
    if(LowerString==NULL) return false;
    char* LowerEnd    = new char[Ne+1];
    if(LowerEnd ==NULL)
    {
        delete[] LowerString;
        delete[] LowerEnd;
        return false;
    }

    memset(LowerString, 0, Ns+1);
    for(unsigned int k=0; k<Ns; k++)
        LowerString[k] = ToLowerCase(String[k]);

    memset(LowerEnd, 0, Ne+1);
    for(unsigned int k=0; k<Ne; k++)
        LowerEnd[k] = ToLowerCase(End[k]);

    bool StringEnds = IsStringEnding(LowerString, LowerEnd, true);

    delete[] LowerString;
    delete[] LowerEnd;
    return StringEnds;
}
bool DoesStringContainLetters(const char* String)
{
    if(String==NULL) return false;

    size_t Ns = strlen(String);
    for(unsigned int k=0; k<Ns; k++)
    {
        if('a'<=String[k] && String[k]<='z') return true;
        if('A'<=String[k] && String[k]<='Z') return true;
    }
    return false;
}
bool DoesStringContainNumbers(const char* String)
{
    if(String==NULL) return false;

    size_t Ns = strlen(String);
    for(int k=0; k<Ns; k++)
    {
        if('0'<=String[k] && String[k]<='9') return true;
    }
    return false;
}

bool IsStringBeginning(const char* String, const char* Begin, bool CaseSens)
/*
     Return true iff String is beginning with Begin[]
 */
{

    size_t Ns = strlen(String);
    size_t Nb = strlen(Begin);
    if(Nb>Ns) return false;

    if(CaseSens==true)
    {
        for(unsigned int k=0; k<Nb; k++) if(String[k] != Begin[k]) return false;
        return true;
    }

    char* LowerString = new char[Ns+1];
    if(LowerString==NULL) return false;
    char* LowerBegin  = new char[Nb+1];
    if(LowerBegin ==NULL)
    {
        delete[] LowerString;
        delete[] LowerBegin;
        return false;
    }

    memset(LowerString, 0, Ns+1);
    for(unsigned int k=0; k<Ns; k++)
        LowerString[k] = ToLowerCase(String[k]);

    memset(LowerBegin, 0, Nb+1);
    for(unsigned int k=0; k<Nb; k++)
        LowerBegin[k] = ToLowerCase(Begin[k]);

    bool StringBegins = IsStringBeginning(LowerString, LowerBegin, true);

    delete[] LowerString;
    delete[] LowerBegin;
    return StringBegins;
}

bool IsStringCompatible(const char* String, const char* Descr, bool CaseSense)
/*
     Return true iff String is compatible with the string description Descr[]
 */
{
    if(String==NULL || Descr==NULL) return true;

/* Make a copy of String[] in lower case*/
    char* LowerString = new char[strlen(String)+1];
    if(LowerString==NULL) return false;
    memset(LowerString, 0, strlen(String)+1);
    for(unsigned int k=0; k<strlen(String); k++)
        if(CaseSense) LowerString[k] =             String[k] ;
        else          LowerString[k] = ToLowerCase(String[k]);

/* Make a copy of the test string in lower case, separated by zeroes, i.s.o. wild cards*/
    size_t nbytes = strlen(Descr)+1;
    char* substrings = new char[nbytes];
    if(!substrings)
    {
        delete[] LowerString;
        return false;
    }
    int Nwild = 0;
    memset(substrings, 0, nbytes);
    unsigned int k=0;
    for(            ; k<strlen(Descr); k++)
        if(Descr[k]!='*')
        {
            if(CaseSense) substrings[k] =             Descr[k] ;
            else          substrings[k] = ToLowerCase(Descr[k]);
        }
        else
            Nwild++;

/* Test if all substrings are present*/
    char* pLowerString    = LowerString;
    char* psub            = substrings;
    int   iwild           = 0;
    while(iwild<=Nwild)
    {
        if(!strlen(psub))
        {
            iwild++;
            psub++;
            continue;
        }
        char* subInString = strstr(pLowerString, psub);
        if(subInString==NULL)
        {
            delete[] LowerString;
            delete[] substrings;
            return false;
        }
        if(iwild==0 && Descr[0]!='*')
        {
            if(subInString!=pLowerString) // if Descr[] does not start with wild card, first
            {                             // occurence of Descr must be at beginning of String
                delete[] LowerString;
                delete[] substrings;
                return false;
            }
        }
        if(iwild==Nwild && Descr[strlen(Descr)-1]!='*')
        {
            if(strcmp(subInString+strlen(subInString)-strlen(psub), psub))
            {                           // if Descr[] does not end with wild card, last
                delete[] LowerString;   // occurence of Descr must coincide with end of String
                delete[] substrings;
                return false;
            }
        }
        pLowerString  = subInString+strlen(psub);
        psub         += strlen(psub);
    }
    delete[] LowerString;
    delete[] substrings;
    return true;
}

ErrorType GetNamesFromString(const char* NameString, int MaxStringSize, int *NStrings, char*** Names)
{
    if(NameString==NULL || NStrings==NULL || Names==NULL)
    {
        CI.AddToLog("ERROR: GetNamesFromString(). Invalid NULL pointer. ");
        return U_ERROR;
    }

    int nbytes = int(strlen(NameString));
    if(MaxStringSize<=0) MaxStringSize = nbytes+1;
    int kstart = 0;
    while(kstart<nbytes && (NameString[kstart]==',' || NameString[kstart]==';')) kstart++;

    int  nNam      = 0;
    bool LabelChar = true;
    for(int k=kstart; k<=nbytes; k++)
    {
        if(NameString[k]==',' || NameString[k]==';' || NameString[k]=='\0')
        {
            if(LabelChar==true) nNam++;
            LabelChar = false;
        }
        else
            LabelChar = true;
    }

/* No Names?*/
    *NStrings = nNam;
    if(nNam==0)
    {
        *Names = NULL;
        return U_OK;
    }

    *Names = new char*[nNam+1];
    if(*Names==NULL) return U_ERROR;

    for(int i=0; i<nNam+1; i++)
    {
        (*Names)[i]  = new char[MaxStringSize];
        if((*Names)[i])
            memset((*Names)[i],0,MaxStringSize);
    }

    int ic    = 0;
    int i     = 0;
    LabelChar = true;
    for(int k=kstart; k<=nbytes; k++)
    {
        if(NameString[k]==',' || NameString[k]==';' || NameString[k]=='\0')
        {
            if(LabelChar==true)
            {
                i++;
                ic = 0;
            }
            LabelChar = false;
        }
        else
        {
            LabelChar = true;
            if(ic<MaxStringSize-1)
            {
                (*Names)[i][ic] = NameString[k];
                ic++;
            }
        }
    }
    return U_OK;
}

ErrorType NormalizeArray(double* Array, int N)
{
    if(Array==NULL || N<=0) return U_ERROR;

    double MaxDat = fabs(Array[0]);
    for(int n=1; n<N; n++)
    {
        double Test = fabs(Array[n]);
        if(Test<=MaxDat) continue;
        MaxDat = Test;
    }
    if(MaxDat<=0) return U_OK;
    for(int n=0; n<N; n++) Array[n] /= MaxDat;
    return U_OK;
}
ErrorType NormalizeArrayFrobenius(double* DArray, int N)
{
    if(DArray==NULL || N<=0) return U_ERROR;

    double Norm = GetFrobeniusNorm(DArray, N);
    if(Norm<=0) return U_OK;

    for(int n=0; n<N; n++) DArray[n] /= Norm;
    return U_OK;
}
double GetFrobeniusNorm(const double* DArray, int N)
{
    if(DArray==NULL || N<=0) return 0.;

    double Norm = 0;
    for(int n=0; n<N; n++) Norm += DArray[n] * DArray[n];
    Norm = sqrt(fabs(Norm));
    return Norm;
}
ErrorType NormalizeArrayFrobenius(float* FArray, int N)
{
    if(FArray==NULL || N<=0) return U_ERROR;

    double Norm = GetFrobeniusNorm(FArray, N);
    if(Norm<=0) return U_OK;

    for(int n=0; n<N; n++) FArray[n] /= Norm;
    return U_OK;
}
double GetFrobeniusNorm(const float* FArray, int N)
{
    if(FArray==NULL || N<=0) return 0.;

    double Norm = 0;
    for(int n=0; n<N; n++) Norm += FArray[n] * FArray[n];
    Norm = sqrt(fabs(Norm));
    return Norm;
}
double GetSumSquare(const double* DArray, int N)
{
    if(DArray==NULL || N<=0) return 0.;

    double SumSq = 0;
    for(int n=0; n<N; n++) SumSq += DArray[n] * DArray[n];
    return SumSq;
}
double GetSum(const double* DArray, int N)
{
    if(DArray==NULL || N<=0) return 0.;

    double Sum = 0;
    for(int n=0; n<N; n++) Sum += DArray[n];
    return Sum;
}

double GetImprod(const double* DArray1, const double* DArray2, int N)
{
    if(DArray1==NULL || DArray2==NULL || N<=0) return 0.;

    double Improd = 0;
    for(int n=0; n<N; n++) Improd += DArray1[n] * DArray2[n];
    return Improd;
}
float GetMin(const float* Farray, int N)
{
    if(Farray==NULL || N<=0)
    {
        CI.AddToLog("ERROR: GetMin(). Invalid NULL pointer. N= %d\n", N);
        return 0.F;
    }
    float MinVal = Farray[0];
    for(int n=0; n<N; n++) if(Farray[n]<MinVal) MinVal = Farray[n];
    return MinVal;
}
float GetMax(const float* Farray, int N)
{
    if(Farray==NULL || N<=0)
    {
        CI.AddToLog("ERROR: GetMax(). Invalid NULL pointer. N= %d\n", N);
        return 0;
    }
    float MaxVal = Farray[0];
    for(int n=0; n<N; n++) if(Farray[n]>MaxVal) MaxVal = Farray[n];
    return MaxVal;
}
double GetMin(const double* Darray, int N)
{
    if(Darray==NULL || N<=0)
    {
        CI.AddToLog("ERROR: GetMin(). Invalid NULL pointer. N= %d\n", N);
        return 0;
    }
    double MinVal = Darray[0];
    for(int n=0; n<N; n++) if(Darray[n]<MinVal) MinVal = Darray[n];
    return MinVal;
}
double GetMax(const double* Darray, int N)
{
    if(Darray==NULL || N<=0)
    {
        CI.AddToLog("ERROR: GetMax(). Invalid NULL pointer. N= %d\n", N);
        return 0;
    }
    double MaxVal = Darray[0];
    for(int n=0; n<N; n++) if(Darray[n]>MaxVal) MaxVal = Darray[n];
    return MaxVal;
}
double GetAverage(const double* Darray, int N)
{
    if(Darray==NULL || N<=0)
    {
        CI.AddToLog("ERROR: GetAverage(). Invalid NULL pointer. N= %d\n", N);
        return 0;
    }
    double Aver = 0;
    for(int n=0; n<N; n++) Aver += Darray[n];
    if(N>0)                Aver /= N;
    return Aver;
}
double GetCorrelation(const double* Darray1, const double* Darray2, int N)
{
    if(Darray1==NULL || Darray2==NULL)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Invalid NULL pointer(s). \n");
        return 0;
    }
    if(N<=0)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Invalid N (=%d)  .\n", N);
        return 0;
    }
    double D11 = 0.;
    double D22 = 0.;
    double D12 = 0.;
    for(int n=0; n<N; n++)
    {
        D11 += Darray1[n]*Darray1[n];
        D22 += Darray2[n]*Darray2[n];
        D12 += Darray1[n]*Darray2[n];
    }
    if(D11<=0. || D22<=0.)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Vanishing variances, D11 = %f, D22 = %f .\n", D11, D22);
        return 0;
    }
    return D12/sqrt(D11*D22);
}
double GetCorrelation(const float* Farray1, const float* Farray2, int N)
{
    if(Farray1==NULL || Farray2==NULL)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Invalid NULL pointer(s). \n");
        return 0;
    }
    if(N<=0)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Invalid N (=%d)  .\n", N);
        return 0;
    }
    double D11 = 0.;
    double D22 = 0.;
    double D12 = 0.;
    for(int n=0; n<N; n++)
    {
        D11 += Farray1[n]*Farray1[n];
        D22 += Farray2[n]*Farray2[n];
        D12 += Farray1[n]*Farray2[n];
    }
    if(D11<=0. || D22<=0.)
    {
        CI.AddToLog("ERROR: GetCorrelation(). Vanishing variances, D11 = %f, D22 = %f .\n", D11, D22);
        return 0;
    }
    return D12/sqrt(D11*D22);
}
ErrorType FitLine(const double* DarrayY, const double* DarrayX, int N, double* Offset, double* Slope) // Tested with UGLM() 9-10-14
{
    if(DarrayY==NULL || DarrayY==NULL)
    {
        CI.AddToLog("ERROR: FitLine(). Invalid NULL pointer(s). \n");
        return U_ERROR;
    }
    if(N<=0)
    {
        CI.AddToLog("ERROR: FitLine(). Invalid N (=%d)  .\n", N);
        return U_ERROR;
    }
    double Amat[4] = {0.,0.,0.,0.};
    Amat[0] = GetSumSquare(DarrayX, N);
    Amat[1] = GetSum      (DarrayX, N);
    Amat[2] = Amat[1];
    Amat[3] = N;
    double Det     = Amat[0]*Amat[3] - Amat[1]*Amat[2];
    if(Det<=0.)
    {
        CI.AddToLog("ERROR: FitLine(). Determinant <=0 (Det=%f) \n", Det);
        return U_ERROR;
    }
    double Bvec[2] = {GetImprod(DarrayY, DarrayX, N), GetSum(DarrayY, N)};
    double Para[2] = {Amat[3]*Bvec[0]-Amat[1]*Bvec[1], -Amat[2]*Bvec[0]+Amat[0]*Bvec[1]};
    if(Offset) *Offset = Para[1]/Det;
    if(Slope ) *Slope  = Para[0]/Det;

    return U_OK;
}
double GetBinomial(int Ntot, int Nsuc, double p)
{
    if(Ntot<=1 || Nsuc<0 || Ntot<Nsuc)
    {
        CI.AddToLog("ERROR: GetBinomial(). Argument(s) out of range (Ntot = %d, Nsuc=%d). \n", Ntot, Nsuc);
        return 0.;
    }
    if(Ntot>=MAXFACTORIAL)
    {
        CI.AddToLog("ERROR: GetBinomial(). Ntot = %d out of range for this implementation. \n", Ntot);
        return 0.;
    }
    if(p<0 || p>1)
    {
        CI.AddToLog("ERROR: GetBinomial(). Invalid p (=%f) .\n", p);
        return 0.;
    }
    if(p==0.) return 0.;
    if(p==1.) return 1.;
    double Numer = GetFactorial(Ntot);
    double Denom = GetFactorial(Nsuc)*GetFactorial(Ntot-Nsuc);
    if(Denom<=0)
    {
        CI.AddToLog("ERROR: GetBinomial(). Invalid demominator: (Ntot = %d, Nsuc=%d). \n", Ntot, Nsuc);
        return 0.;
    }
    double P1 = pow(p   ,      Nsuc);
    double P2 = pow(1.-p, Ntot-Nsuc);

    return Numer*P1*P2/Denom;
}

double GetCumulativeBinomial(int Ntot, int Nsuc, double p)
{
    if(Ntot<=1 || Nsuc<0 || Ntot<Nsuc)
    {
        CI.AddToLog("ERROR: GetCumulativeBinomial(). Argument(s) out of range (Ntot = %d, Nsuc=%d). \n", Ntot, Nsuc);
        return 0.;
    }
    if(Ntot>=MAXFACTORIAL)
    {
        CI.AddToLog("ERROR: GetCumulativeBinomial(). Ntot = %d out of range for this implementation. \n", Ntot);
        return 0.;
    }
    if(p<0 || p>1)
    {
        CI.AddToLog("ERROR: GetCumulativeBinomial(). Invalid p (=%f) .\n", p);
        return 0.;
    }
    if(p==0.) return 0.;
    if(p==1.) return 1.;

    double pCum = 0.;
    for(int is=Ntot; is>=Nsuc; is--) pCum += GetBinomial(Ntot, is, p);

    return pCum;
}

double GetFactorial(int n)
{
static const int MAXMESS = 20;
static       int Nmes    = 0;
    if(n<0)
    {
        if(Nmes<MAXMESS) {Nmes++; CI.AddToLog("ERROR: GetFactorial(). Argument out of range (%d). \n", n);}
        return 0;
    }
static double Fact[MAXFACTORIAL];
static bool   FactSet = false;
    if(FactSet==false)
    {
        Fact[0] = 1.;
        Fact[1] = 1.;
        for(int k=2; k<MAXFACTORIAL; k++) Fact[k] = Fact[k-1]*k;
        FactSet = true;
    }
    if(n>=MAXFACTORIAL)
    {
        if(Nmes<MAXMESS) {Nmes++; CI.AddToLog("ERROR: GetFactorial(). Argument out of range (%d). \n", n);}
        return Fact[MAXFACTORIAL-1];
    }
    return Fact[n];
}
double GetLogGamma(double xx)
/* 
This routine returns ln[Gamma(xx)], where Gamma(xx) 
is Gamma-function. This routine is adapted from Numerical (gammln)
Recipes, Chapter 6.1.
*/
{
    double x,y,tmp,ser;
    static double cof[6]={76.18009172947146, -86.50532032941677,
                          24.01409824083091, -1.231739572450155,
                          0.1208650973866179e-2,-0.5395239384953e-5};
    int j;

    y    = x = xx;
    tmp  = x+5.5;
    tmp -= (x+0.5)*log(tmp);
    ser  =1.000000000190015;
    for (j=0;j<=5;j++) ser += cof[j]/++y;
    return -tmp+log(2.5066282746310005*ser/x);
}
double GetLogFactorial(int n)
{
static double LogFact[MAXLOGFACTORIAL];
static bool   LogFactSet = false;
static const int MAXMESS = 20;
static       int Nmes    = 0;
    if(n<0)
    {
        if(Nmes<MAXMESS) {Nmes++; CI.AddToLog("ERROR: GetLogFactorial(). Argument out of range (%d). \n", n);}
        return 0;
    }
    if(LogFactSet==false)
    {
        for(int i=0;i<MAXLOGFACTORIAL;i++) LogFact[i] = GetLogGamma(i+1.);
        LogFactSet = true;
    }
    if (n < MAXLOGFACTORIAL) return LogFact[n];
    return GetLogGamma(n+1.);
}
double GetBinomialCoefficient(int n, int k)
{
    if(n<0 || k<0 || k>n) 
    {
        CI.AddToLog("ERROR: GetBinomialCoefficient(). Paramaeter(s) out of range (n=%d, k=%d) \n", n,k);
        return 0.;
    }
    if(n<MAXFACTORIAL) return floor(0.5+GetFactorial(n)/(GetFactorial(k)*GetFactorial(n-k)));
    return floor(0.5+exp(GetLogFactorial(n)-GetLogFactorial(k)-GetLogFactorial(n-k)));
}
double Bessel0(double x) 
{
    double Bess = 0.;

    double ax = ax=fabs(x);
    if(ax < 3.75) 
    {
        double y  =x/3.75;
        y *=y;
        Bess=1.0+y*(3.5156229+y*(3.0899424+y*(1.2067492 +y*(0.2659732+y*(0.360768e-1+y*0.45813e-2)))));
    } 
    else 
    {
        double y=3.75/ax;
        Bess=(exp(ax)/sqrt(ax))*(0.39894228+y*(0.1328592e-1+y*(0.225319e-2+y*(-0.157565e-2+y*(0.916281e-2+y*(-0.2057706e-1+y*(0.2635537e-1+y*(-0.1647633e-1+y*0.392377e-2))))))));
    }
    return Bess;
}

#define NPRIME 1229
static const int PRIME[NPRIME]  =
{  2,   3,   5,   7,  11,  13,  17,  19,  23,  29,
  31,  37,  41,  43,  47,  53,  59,  61,  67,  71,
  73,  79,  83,  89,  97, 101, 103, 107, 109, 113,
 127, 131, 137, 139, 149, 151, 157, 163, 167, 173,
 179, 181, 191, 193, 197, 199, 211, 223, 227, 229,
 233, 239, 241, 251, 257, 263, 269, 271, 277, 281,
 283, 293, 307, 311, 313, 317, 331, 337, 347, 349,
 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
 419, 421, 431, 433, 439, 443, 449, 457, 461, 463,
 467, 479, 487, 491, 499, 503, 509, 521, 523, 541,
 547, 557, 563, 569, 571, 577, 587, 593, 599, 601,
 607, 613, 617, 619, 631, 641, 643, 647, 653, 659,
 661, 673, 677, 683, 691, 701, 709, 719, 727, 733,
 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
 811, 821, 823, 827, 829, 839, 853, 857, 859, 863,
 877, 881, 883, 887, 907, 911, 919, 929, 937, 941,
 947, 953, 967, 971, 977, 983, 991, 997,1009,1013,
1019,1021,1031,1033,1039,1049,1051,1061,1063,1069,
1087,1091,1093,1097,1103,1109,1117,1123,1129,1151,
1153,1163,1171,1181,1187,1193,1201,1213,1217,1223,
1229,1231,1237,1249,1259,1277,1279,1283,1289,1291,
1297,1301,1303,1307,1319,1321,1327,1361,1367,1373,
1381,1399,1409,1423,1427,1429,1433,1439,1447,1451,
1453,1459,1471,1481,1483,1487,1489,1493,1499,1511,
1523,1531,1543,1549,1553,1559,1567,1571,1579,1583,
1597,1601,1607,1609,1613,1619,1621,1627,1637,1657,
1663,1667,1669,1693,1697,1699,1709,1721,1723,1733,
1741,1747,1753,1759,1777,1783,1787,1789,1801,1811,
1823,1831,1847,1861,1867,1871,1873,1877,1879,1889,
1901,1907,1913,1931,1933,1949,1951,1973,1979,1987,
1993,1997,1999,2003,2011,2017,2027,2029,2039,2053,
2063,2069,2081,2083,2087,2089,2099,2111,2113,2129,
2131,2137,2141,2143,2153,2161,2179,2203,2207,2213,
2221,2237,2239,2243,2251,2267,2269,2273,2281,2287,
2293,2297,2309,2311,2333,2339,2341,2347,2351,2357,
2371,2377,2381,2383,2389,2393,2399,2411,2417,2423,
2437,2441,2447,2459,2467,2473,2477,2503,2521,2531,
2539,2543,2549,2551,2557,2579,2591,2593,2609,2617,
2621,2633,2647,2657,2659,2663,2671,2677,2683,2687,
2689,2693,2699,2707,2711,2713,2719,2729,2731,2741,
2749,2753,2767,2777,2789,2791,2797,2801,2803,2819,
2833,2837,2843,2851,2857,2861,2879,2887,2897,2903,
2909,2917,2927,2939,2953,2957,2963,2969,2971,2999,
3001,3011,3019,3023,3037,3041,3049,3061,3067,3079,
3083,3089,3109,3119,3121,3137,3163,3167,3169,3181,
3187,3191,3203,3209,3217,3221,3229,3251,3253,3257,
3259,3271,3299,3301,3307,3313,3319,3323,3329,3331,
3343,3347,3359,3361,3371,3373,3389,3391,3407,3413,
3433,3449,3457,3461,3463,3467,3469,3491,3499,3511,
3517,3527,3529,3533,3539,3541,3547,3557,3559,3571,
3581,3583,3593,3607,3613,3617,3623,3631,3637,3643,
3659,3671,3673,3677,3691,3697,3701,3709,3719,3727,
3733,3739,3761,3767,3769,3779,3793,3797,3803,3821,
3823,3833,3847,3851,3853,3863,3877,3881,3889,3907,
3911,3917,3919,3923,3929,3931,3943,3947,3967,3989,
4001,4003,4007,4013,4019,4021,4027,4049,4051,4057,
4073,4079,4091,4093,4099,4111,4127,4129,4133,4139,
4153,4157,4159,4177,4201,4211,4217,4219,4229,4231,
4241,4243,4253,4259,4261,4271,4273,4283,4289,4297,
4327,4337,4339,4349,4357,4363,4373,4391,4397,4409,
4421,4423,4441,4447,4451,4457,4463,4481,4483,4493,
4507,4513,4517,4519,4523,4547,4549,4561,4567,4583,
4591,4597,4603,4621,4637,4639,4643,4649,4651,4657,
4663,4673,4679,4691,4703,4721,4723,4729,4733,4751,
4759,4783,4787,4789,4793,4799,4801,4813,4817,4831,
4861,4871,4877,4889,4903,4909,4919,4931,4933,4937,
4943,4951,4957,4967,4969,4973,4987,4993,4999,5003,
5009,5011,5021,5023,5039,5051,5059,5077,5081,5087,
5099,5101,5107,5113,5119,5147,5153,5167,5171,5179,
5189,5197,5209,5227,5231,5233,5237,5261,5273,5279,
5281,5297,5303,5309,5323,5333,5347,5351,5381,5387,
5393,5399,5407,5413,5417,5419,5431,5437,5441,5443,
5449,5471,5477,5479,5483,5501,5503,5507,5519,5521,
5527,5531,5557,5563,5569,5573,5581,5591,5623,5639,
5641,5647,5651,5653,5657,5659,5669,5683,5689,5693,
5701,5711,5717,5737,5741,5743,5749,5779,5783,5791,
5801,5807,5813,5821,5827,5839,5843,5849,5851,5857,
5861,5867,5869,5879,5881,5897,5903,5923,5927,5939,
5953,5981,5987,6007,6011,6029,6037,6043,6047,6053,
6067,6073,6079,6089,6091,6101,6113,6121,6131,6133,
6143,6151,6163,6173,6197,6199,6203,6211,6217,6221,
6229,6247,6257,6263,6269,6271,6277,6287,6299,6301,
6311,6317,6323,6329,6337,6343,6353,6359,6361,6367,
6373,6379,6389,6397,6421,6427,6449,6451,6469,6473,
6481,6491,6521,6529,6547,6551,6553,6563,6569,6571,
6577,6581,6599,6607,6619,6637,6653,6659,6661,6673,
6679,6689,6691,6701,6703,6709,6719,6733,6737,6761,
6763,6779,6781,6791,6793,6803,6823,6827,6829,6833,
6841,6857,6863,6869,6871,6883,6899,6907,6911,6917,
6947,6949,6959,6961,6967,6971,6977,6983,6991,6997,
7001,7013,7019,7027,7039,7043,7057,7069,7079,7103,
7109,7121,7127,7129,7151,7159,7177,7187,7193,7207,
7211,7213,7219,7229,7237,7243,7247,7253,7283,7297,
7307,7309,7321,7331,7333,7349,7351,7369,7393,7411,
7417,7433,7451,7457,7459,7477,7481,7487,7489,7499,
7507,7517,7523,7529,7537,7541,7547,7549,7559,7561,
7573,7577,7583,7589,7591,7603,7607,7621,7639,7643,
7649,7669,7673,7681,7687,7691,7699,7703,7717,7723,
7727,7741,7753,7757,7759,7789,7793,7817,7823,7829,
7841,7853,7867,7873,7877,7879,7883,7901,7907,7919,
7927,7933,7937,7949,7951,7963,7993,8009,8011,8017,
8039,8053,8059,8069,8081,8087,8089,8093,8101,8111,
8117,8123,8147,8161,8167,8171,8179,8191,8209,8219,
8221,8231,8233,8237,8243,8263,8269,8273,8287,8291,
8293,8297,8311,8317,8329,8353,8363,8369,8377,8387,
8389,8419,8423,8429,8431,8443,8447,8461,8467,8501,
8513,8521,8527,8537,8539,8543,8563,8573,8581,8597,
8599,8609,8623,8627,8629,8641,8647,8663,8669,8677,
8681,8689,8693,8699,8707,8713,8719,8731,8737,8741,
8747,8753,8761,8779,8783,8803,8807,8819,8821,8831,
8837,8839,8849,8861,8863,8867,8887,8893,8923,8929,
8933,8941,8951,8963,8969,8971,8999,9001,9007,9011,
9013,9029,9041,9043,9049,9059,9067,9091,9103,9109,
9127,9133,9137,9151,9157,9161,9173,9181,9187,9199,
9203,9209,9221,9227,9239,9241,9257,9277,9281,9283,
9293,9311,9319,9323,9337,9341,9343,9349,9371,9377,
9391,9397,9403,9413,9419,9421,9431,9433,9437,9439,
9461,9463,9467,9473,9479,9491,9497,9511,9521,9533,
9539,9547,9551,9587,9601,9613,9619,9623,9629,9631,
9643,9649,9661,9677,9679,9689,9697,9719,9721,9733,
9739,9743,9749,9767,9769,9781,9787,9791,9803,9811,
9817,9829,9833,9839,9851,9857,9859,9871,9883,9887,
9901,9907,9923,9929,9931,9941,9949,9967,9973
};



int SmallPrimes(int N)
/*
   Return the smallest integer larger or equal to N which is a product of small primes.
 */
{
    const int NPused = 4; //10

    if(N<=0)
    {
        CI.AddToLog("ERROR: SmallPrimes(). Invalid argument, N=%d .\n",N);
        return 0;
    }
    if(N==1) return 1;

    int Nice = N;
    while(1)
    {
        int Ntest = Nice;
        while(Ntest>1)
        {
            int k = 0;
            for(     ; k<NPused; k++)
                if( !(Ntest%PRIME[k]) )
                {
                    Ntest/=PRIME[k];
                    break;
                }
            if(Ntest==1) return Nice;
            if(k==NPused)
            {
                Nice++;
                break;
            }
        }
    }
}

int GetNearPrime(int N)
{
    if(N<0)
    {
        CI.AddToLog("ERROR: GetNearPrime(). Argument (%d) out of range.\n", N);
        return 0;
    }
    if(N<1) return 2;
    for(int k=0; k<NPRIME; k++)
    {
        if(PRIME[k]<=N && N<PRIME[k+1]) return PRIME[k];
    }
    CI.AddToLog("WARNING: GetNearPrime(). Argument (%d) exceeds tabulated oprimes.\n", N);
    return PRIME[NPRIME-1];
}
#undef NPRIME

