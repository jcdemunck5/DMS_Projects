/************************************************************************************/
/*                                                                                  */
/*     General include file containing required defintions, etc for almost all      */
/*     U-objects. This include-file is implicitly included when the include-file    */
/*     of one U-object is included.                                                 */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    16-10-98   creation.
  JdM    28-12-98   added comments
  JdM    13-01-99   BUG: swapped the output of BOOL INTEL_byte_ORDER(void)
  JdM    13-03-99   Added figure()
  JdM    12-04-99   Added DoesFileExist()
  Jdm    14-04-99   Added compatibility with MSFC
  Jdm    27-05-99   Define stricmp() as strcmp() in the case of HPUX
  JdM    27-06-99   Added UpperPower2() and LowerPower2()
  JdM    07-08-99   Remove (obsolete) C-compatibility
  JdM    31-08-99   #define WIN32_MEAN_AND_LEAN
  JdM    31-09-99   compatibility with the inclusion of "windows.h" (_WINDEF_)
  JdM    29-01-00   compatibility with the Borland compiler (__WIN32__)
                    and skip 'typedef' in enums)
  JdM    09-05-01   defined VC_EXTRALEAN
  JdM    02-01-02   use standard bool instead of enum BOOL
  JdM    29-08-02   #define bool in case of sparc
  JdM    16-06-10   Converted Qt3 functions to Qt2 #ifndef QT3
  JdM    01-01-14   Added SQR()
  JdM    13-12-14   Added uint32_t, uint64_t types, ReadBinaryUInt64(), new SwapVal(), new WriteBinary()
*/

#ifndef _BASICINCLUDE_INCLUDED  // Prevent including this include-file twice.
#define _BASICINCLUDE_INCLUDED

#ifdef __WIN32__ // Borland compiler
    #ifndef WIN32
    #define WIN32
    #endif
#endif


#include"DLLio.h"
#include"PMTTypeDefines.h"

#ifndef WIN32 
#define stricmp(a,b)     strcmp((a),(b))
#define strnicmp(a,b,c)  strncmp((a),(b),(c))
#endif

#ifdef MSVC9
#define stricmp(a,b)     _stricmp((a),(b))
#define strnicmp(a,b,c)  _strnicmp((a),(b),(c))
#endif
#ifdef MSVC10 
#ifndef stricmp
#define stricmp(a,b)         _stricmp((a),(b))
#endif
#ifndef strnicmp
#define strnicmp(a,b,c)      _strnicmp((a),(b),(c))
#endif
#endif

#ifdef MSVC_2017
#ifndef stricmp
#define stricmp(a,b)         _stricmp((a),(b))
#endif
#ifndef strnicmp
#define strnicmp(a,b,c)      _strnicmp((a),(b),(c))
#endif
#endif // MSVC_2017

#include<stdio.h>
#include"ConsoleInterface.h"
#include"FFTWPlan.h"
#include"Debug.h"


enum InterpolateType
{
    U_INTERPOL_CON,
    U_INTERPOL_LIN,
    U_INTERPOL_FFT,
    U_INTERPOL_UNKNOWN
};
PMT_CCP         DLL_IO GetInterpolateTypeText(InterpolateType INT);
InterpolateType DLL_IO GetInterpolateType(int itype);
InterpolateType DLL_IO GetInterpolateType(const char* typestring);

enum WindowType     // Window applied to account for the FIR-filters
{
    U_WIN_BLOCK,         // No windowing
    U_WIN_HAMMING,       // Hamming window
    U_WIN_KAISER,        // Kaiser window
    U_WIN_TRIANGULAR     // Triangular window
};
PMT_DP   GetWindowProfile(WindowType Win, int Nsamp, double AlfaBeta);

#ifndef QT3
#define paletteBackgroundColor()     backgroundColor()
#define setPaletteBackgroundColor(a) setBackgroundColor(a)
#endif


#ifndef MIN
    #define MIN(a,b) ( (a)<(b)?(a):(b) )
#endif
#ifndef MAX
    #define MAX(a,b) ( (a)>(b)?(a):(b) )
#endif
#ifndef SQR
    #define SQR(a) ( (a)*(a) )
#endif
#ifndef SIGN
    #define SIGN(a) ((a)>0 ? 1 : ((a)<0 ? -1 : 0) )
#endif


const double PI               =  3.141592653589793;
const double PI2              =  6.2831853071795865;
const double PI4              = 12.566370614359172;
const bool   DefaultIntelData = true;


extern "C"
{
    int   DLL_IO figure(double mesh_size, double x_par, double y_par, double z_par, int fig, double **xyz, int *npoints);
    int   DLL_IO TriangulateSphere(double *xyz, int npoints, int **TriList, int *ntri, double MaxEdge);
    int   DLL_IO GetNeighborList(double *xyz, int npoints, int **neigh, int *Nneigh, int* bound, double MaxEdge);
    int   DLL_IO jacobi_d(double *a, int n, double *d, double *v, int *nrot);
    int   DLL_IO daxisb_c(double *amat, double *x, const double *b, int n, int ndim, double *det);
    int   DLL_IO dsymin_c(double *amat, int n, int ndim, double *det);
    int   DLL_IO dmatin_c(double *a, long int n, long int ndim, double *det);
    int   DLL_IO svdcmp_d(double *u, int m, int n, double *lamda, double *v);

    PMT_CCP DLL_IO GetLibGenDate(void);
    PMT_CCP DLL_IO GetLibScaDate(void);
}

/* Data:*/
extern  UConsoleInterface DLL_IO CI;
extern  UFFTWPlan         DLL_IO FFTW;
extern  UDebug            DLL_IO AUTODEBUG;


#define MAXFACTORIAL       100
#define MAXLOGFACTORIAL   2000

ErrorType      DLL_IO SolveL2Norm(const double* Amat, double* Xvec,  const double* Bvec,  int M, int N, double TruncLevel=-1);
ErrorType      DLL_IO SolveL1Norm(const double* Amat, double* Xvec,  const double* Bvec,  int M, int N, double* L1Min=NULL, int* Ierr=NULL, int* Rank=NULL, int* Niter=NULL);
ErrorType      DLL_IO SolveL2L1Norm(const double* Amat, double* Xvec,  const double* Bvec,  int M, int N, double Lamda, double Alfa, int* NNonZero);

bool           DLL_IO INTEL_PROCESSOR(void);
void           DLL_IO SwapArray(short  *array, int Npoints, bool IntelData);
void           DLL_IO SwapArray(int    *array, int Npoints, bool IntelData);
void           DLL_IO SwapArray(float  *array, int Npoints, bool IntelData);
void           DLL_IO SwapArray(double *array, int Npoints, bool IntelData);

short          DLL_IO SwapVal(short Val, bool IntelData);
int            DLL_IO SwapVal(int Val, bool IntelData);
uint32_t       DLL_IO SwapVal(uint32_t Val, bool IntelData);
int64_t        DLL_IO SwapVal(int64_t Val, bool IntelData);
uint64_t       DLL_IO SwapVal(uint64_t Val, bool IntelData);
float          DLL_IO SwapVal(float Val, bool IntelData);
double         DLL_IO SwapVal(double Val, bool IntelData);

ErrorType      DLL_IO WriteBinary(unsigned char Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(char Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(bool Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(short Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(int   Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(uint32_t Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(uint64_t Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(float Val, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(double Val, bool IntelData, FILE* fp);

ErrorType      DLL_IO WriteBinary(const char* array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(const short* array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(const int* array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(const float* array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO WriteBinary(const double* array, int Npoints, bool IntelData, FILE* fp);

bool           DLL_IO ReadBinaryBool  (bool IntelData, FILE* fp);
PMT_C          DLL_IO ReadBinaryChar  (bool IntelData, FILE* fp);
PMT_UC         DLL_IO ReadBinaryUChar (bool IntelData, FILE* fp);
PMT_S          DLL_IO ReadBinaryShort (bool IntelData, FILE* fp);
PMT_US         DLL_IO ReadBinaryUShort(bool IntelData, FILE* fp);
int            DLL_IO ReadBinaryInt   (bool IntelData, FILE* fp);
uint32_t       DLL_IO ReadBinaryUInt  (bool IntelData, FILE* fp);
int64_t        DLL_IO ReadBinaryInt64 (bool IntelData, FILE* fp);
uint64_t       DLL_IO ReadBinaryUInt64(bool IntelData, FILE* fp);
float          DLL_IO ReadBinaryFloat (bool IntelData, FILE* fp);
double         DLL_IO ReadBinaryDouble(bool IntelData, FILE* fp);
PMT_CP         DLL_IO ReadBinaryCharArray  (int Npoints, bool IntelData, FILE* fp);
PMT_UCP        DLL_IO ReadBinaryUCharArray (int Npoints, bool IntelData, FILE* fp);
PMT_BP         DLL_IO ReadBinaryBoolArray  (int Npoints, bool IntelData, FILE* fp);
PMT_SP         DLL_IO ReadBinaryShortArray (int Npoints, bool IntelData, FILE* fp);
PMT_IP         DLL_IO ReadBinaryIntArray   (int Npoints, bool IntelData, FILE* fp);
PMT_FP         DLL_IO ReadBinaryFloatArray (int Npoints, bool IntelData, FILE* fp);
PMT_DP         DLL_IO ReadBinaryDoubleArray(int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryCharArray  (char*          array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryUCharArray (unsigned char* array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryBoolArray  (bool*          array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryShortArray (short*         array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryIntArray   (int*           array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryFloatArray (float*         array, int Npoints, bool IntelData, FILE* fp);
ErrorType      DLL_IO ReadBinaryDoubleArray(double*        array, int Npoints, bool IntelData, FILE* fp);

bool           DLL_IO DoesFileExist(const char *FileName);
bool           DLL_IO CanFileBeCreated(const char *FileName);
uint32_t       DLL_IO GetFileSize(FILE *fp);
bool           DLL_IO HasIDAtOffset(FILE* fp, const char* ID, int Offset);
PMT_CP         DLL_IO GetLine(char *string, int nchar, FILE *fp);
int            DLL_IO GetNLines(FILE *fp);
ErrorType      DLL_IO CopyFile(const char *FileIn, const char *FileOut);
bool           DLL_IO IsTiffFile(FILE* fp);
bool           DLL_IO IsBitMapFile(FILE* fp);

int            DLL_IO UpperPower2(int n);
int            DLL_IO LowerPower2(int n);
double         DLL_IO UpScalePosValue(double PosVal);
double         DLL_IO DownScalePosValue(double PosVal);
double         DLL_IO GetNiceUpStep(double DMin, double DMax, double Val);
double         DLL_IO GetNiceDownStep(double DMin, double DMax, double Val);
ErrorType      DLL_IO GetNiceScaleParameters(double DMin, double DMax, double* Offset, double*Step);
ErrorType      DLL_IO GetNiceRangeParameters(double DMin, double DMax, double* DminNice, double*DmaxNice, int* NInterval=NULL);

PMT_CP         DLL_IO GetTime(void);

char           DLL_IO ToLowerCase(char c);
char           DLL_IO ToUpperCase(char c);
bool           DLL_IO IsBlankChar(char c);
int            DLL_IO SetBlankNull(char* Line, int N);
bool           DLL_IO IsStringEnding(const char* String, const char* End, bool CaseSens=true);
bool           DLL_IO IsStringBeginning(const char* String, const char* Begin, bool CaseSens=true);
bool           DLL_IO IsStringCompatible(const char* String, const char* Descr, bool CaseSense);
bool           DLL_IO DoesStringContainWildCard(const char* String);
bool           DLL_IO DoesStringContainLetters(const char* String);
bool           DLL_IO DoesStringContainNumbers(const char* String);
PMT_CCP        DLL_IO BoolAsText(bool boolean);
ErrorType      DLL_IO GetNamesFromString(const char* NameString, int MaxStringSize, int *NName, char*** Names);

bool           DLL_IO NOT(bool b);
////bool  operator||(bool b1, bool b2);
////bool  operator&&(bool b1, bool b2);

ErrorType      DLL_IO NormalizeArray(double* DArray, int N);
ErrorType      DLL_IO NormalizeArrayFrobenius(double* DArray, int N);
ErrorType      DLL_IO NormalizeArrayFrobenius(float* FArray, int N);
double         DLL_IO GetFrobeniusNorm(const double* DArray, int N);
double         DLL_IO GetFrobeniusNorm(const float* FArray, int N);
double         DLL_IO GetSumSquare(const double* DArray, int N);
double         DLL_IO GetSum(const double* DArray, int N);
double         DLL_IO GetImprod(const double* DArray1, const double* DArray2, int N);
double         DLL_IO GetCorrelation(const double* Darray1, const double* Darray2, int N);
double         DLL_IO GetCorrelation(const float* Farray1, const float* Farray2, int N);
ErrorType      DLL_IO FitLine(const double* DarrayY, const double* DarrayX, int N, double* Offset, double* Slope);

double         DLL_IO GetMin(const double* Darray, int N);
double         DLL_IO GetMax(const double* Darray, int N);
float          DLL_IO GetMin(const float* Farray, int N);
float          DLL_IO GetMax(const float* Farray, int N);
double         DLL_IO GetAverage(const double* Darray, int N);

double         DLL_IO Bessel0(double x);               // Zeroeth order Bessel function
double         DLL_IO GetFactorial(int n);
double         DLL_IO GetLogGamma(double xx);
double         DLL_IO GetLogFactorial(int n);          // Uses table, has int argument 
double         DLL_IO GetBinomialCoefficient(int n, int k);
double         DLL_IO GetBinomial(int Ntot, int Nsuc, double p);
double         DLL_IO GetCumulativeBinomial(int Ntot, int Nsuc, double p);

int            DLL_IO SmallPrimes(int N);
int            DLL_IO GetNearPrime(int N);

#endif //_BASICINCLUDE_INCLUDED

