/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*     The goal of the object is to compute MEG or EEG sources based on BeamFormers.*/
/*     The contrast is provided by the "difference" in spatial covariance during    */
/*     Rest an Activation.                                                          */
/*                                                                                  */
/*     NOTE:                                                                        */
/*                                                                                  */
/*                                                                                  */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    11-10-07   Creation
  JdM    27-06-08   Added LogEigen parameter to GetSAMField().
  JdM    28-06-08   Bug Fix GetSAMField(): Invert-parameters in EDecBeamAct and EDecBeamRest were reversed
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    18-11-09   GetSAMField(). Added regularization parameter.
  JdM    13-02-10   GetSAMField(). Added channel selection parameters
  JdM    09-03-10   GetSAMField(). Added parameter to select use of LeadField table
*/

#include <math.h>     
#include <string.h>

#include "BeamFormer.h"
#include "EigenDecomp.h"
#include "EMfield.h"
#include "Field.h"
#include "SensorCorrelate.h"
#include "Dipole.h"

UString UBeamFormer::Properties = UString();


void UBeamFormer::SetAllMembersDefault(void)
{
    error       = U_OK;
    EMF         = NULL;    
    NPointsTab  = 0;
    NSens       = 0;
    LFtable     = NULL;
}
void UBeamFormer::DeleteAllMembers(ErrorType E)
{
    delete EMF;
    if(NPointsTab>0 && LFtable)
        for(int k=0; k<NPointsTab; k++) delete[] LFtable[k];
    delete[] LFtable;
    SetAllMembersDefault();
    error = E;
}


// Public functions
UBeamFormer::UBeamFormer() 
{
    SetAllMembersDefault();
}

UBeamFormer::UBeamFormer(const UEMfield* EM)
{
    SetAllMembersDefault();

    if(EM==NULL || EM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::UBeamFormer(). Erroneous UEMfield-argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    EMF = new UEMfield(*EM);
    if(EMF==NULL || EMF->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::UBeamFormer(). Copying UEMfield-argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
}
 
UBeamFormer::UBeamFormer(const UBeamFormer &Beam)
{
    SetAllMembersDefault();
    *this = Beam;
}

UBeamFormer::~UBeamFormer()
{
    DeleteAllMembers(U_OK);
}

UBeamFormer& UBeamFormer::operator=(const UBeamFormer &Beam)
{
    if(this==NULL || &Beam==NULL)
    {
        if(this==NULL) 
        {
            CI.AddToLog("ERROR: UBeamFormer::operator=(). this==NULL . \n");
            static UBeamFormer B; B.error = U_ERROR;
            return B;
        }
        else
        {
            CI.AddToLog("ERROR: UBeamFormer::operator=(). Invalid NULL Address argument. \n");
            DeleteAllMembers(U_ERROR);
        }
        return *this;
    }
    if(this==&Beam) return *this;

    DeleteAllMembers(U_OK);

    if(Beam.EMF)
    {
        EMF = new UEMfield(*(Beam.EMF));
        if(EMF==NULL || EMF->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UBeamFormer::UBeamFormer(). Copying UEMfield-argument. \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }

    NSens       = Beam.NSens;
    NPointsTab  = Beam.NPointsTab;

    if(Beam.LFtable)
    {
        LFtable = new double*[Beam.NPointsTab];
        if(LFtable)
        {
            for(int k=0; k<Beam.NPointsTab; k++) LFtable[k] = NULL;
            for(int k=0; k<Beam.NPointsTab; k++) 
            {
                if(Beam.LFtable[k]==NULL) continue;
                Beam.LFtable[k] = new double[3*Beam.NSens];
                if(Beam.LFtable[k]==NULL)
                {
                    for(int k=0; k<Beam.NPointsTab; k++) delete[] LFtable[k];
                    delete[] LFtable; LFtable = NULL;
                    break;
                }
                for(int i=0; i<3*Beam.NSens; i++) LFtable[k][i] = Beam.LFtable[k][i];
            }
        }
        if(LFtable==NULL)
        {
            CI.AddToLog("ERROR: UBeamFormer::UBeamFormer(). Copying Lead field tables (Npoints = %d, Nsens = %d). \n", Beam.NPointsTab, Beam.NSens);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    return *this;
}

ErrorType UBeamFormer::SetEMField(const UEMfield* EM)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::SetEMField(). Object NULL or Erroneous. \n");
        return U_ERROR;
    }
    if(EM==NULL)
    {
        delete EMF; EMF = NULL;
        return U_OK;
    }        
    if(EM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::SetEMField(). Erroneous UEMfield-argument. \n");
        return U_ERROR;
    }
    delete EMF;
    EMF = new UEMfield(*EM);
    if(EMF==NULL || EMF->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::SetEMField(). Copying UEMfield-argument. \n");
        delete EMF; EMF = NULL;
        return U_ERROR;
    }
    return U_OK;
}

UField* UBeamFormer::GetSAMField(const UField* SearchGrid, const USensorCorrelate* CovarAct, const USensorCorrelate* CovarRest, bool LogEigen, double RegParameter, const int* Select, int NSelect, bool UseLFTables)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(EMF==NULL || EMF->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). EMF object NULL or erroneous. \n");
        return NULL;
    }
    if(SearchGrid==NULL || SearchGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). SearchGrid argument is NULL or erroneous. \n");
        return NULL;
    }
    if(SearchGrid->Getndim()!=3 || SearchGrid->GetNspace()!=3 || SearchGrid->GetVeclen()!=1)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). SearchGrid argument is not 3D or has illegal veclen (%s). \n", SearchGrid->GetProperties(""));
        return NULL;
    }
    if(CovarAct==NULL  || CovarAct->GetError()!=U_OK  || CovarAct->GetGrid()==NULL)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Covariance of active state NULL or erronous. \n");
        return NULL;
    }
    if(CovarRest==NULL || CovarRest->GetError()!=U_OK || CovarRest->GetGrid()==NULL)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Covariance of rest state NULL or erronous. \n");
        return NULL;
    }
    if(*(CovarAct->GetGrid())!=*(CovarRest->GetGrid()))
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Sensor grids of active and rest state are different. \n");
        return NULL;
    }

    if(CovarAct->GetCorrelationType()!=U_CORREL_CROSSSPEC && 
       CovarAct->GetCorrelationType()!=U_CORREL_SPATCOVAR)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Correlation type of active state must be either cross-spectrum or spatial covariance. \n");
        return NULL;
    }
    if(CovarAct->GetCorrelationType()!=CovarRest->GetCorrelationType())
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Correlation types of active and rest state are different. \n");
        return NULL;
    }
    if(CovarAct->GetDataType()!=U_DAT_MEG && 
       CovarAct->GetDataType()!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Data type of active state must be either MEG or EEG (not %s). \n", UMEEGDataBase::GetDataTypeText(CovarAct->GetDataType()));
        return NULL;
    }
    if(CovarAct->GetDataType()!=CovarRest->GetDataType())
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Data types of active and rest state are different. \n");
        return NULL;
    }
    if(RegParameter<0)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Regularization parameter out of range (RegParameter = %f).\n", RegParameter);
        return NULL;
    }
    int  Nsens  = CovarAct->GetGrid()->GetNpoints();
    if(Select)
    {
        if(NSelect<=0)
        {
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Selection parameter out of range (NSelect = %d) .\n", NSelect);
            return NULL;
        }
        for(int is=0; is<NSelect; is++)
            if(Select[is]<0 || Select[is]>=Nsens)
            {
                CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Selected channel (is=%d) out of range (=%d). \n", is, Select[is]);
                return NULL;
            }
    }
    bool Invert = true;
    UEigenDecomp EDecAct (Nsens, CovarAct ->GetRealPart(), CovarAct ->GetImagPart(), Invert, RegParameter, Select, NSelect);
    UEigenDecomp EDecRest(Nsens, CovarRest->GetRealPart(), CovarRest->GetImagPart(), Invert, RegParameter, Select, NSelect);
    if(EDecAct.GetError()!=U_OK || EDecRest.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Creating eigen value decompositions from covariance structures. \n");
        return NULL;
    }

/* Update Lead field tables ?*/
    bool FillLFTables      = false;
    if(UseLFTables)
    {
        bool OldTablesValid = true;
        if(SearchGrid->GetNpoints()!=NPointsTab) OldTablesValid=false;

        if( CovarAct->GetDataType()==U_DAT_MEG && 
           (EMF->GetGridMEG()==NULL || EMF->GetGridMEG()->GetNpoints()!=NSens)) OldTablesValid=false;
        if( CovarAct->GetDataType()==U_DAT_EEG && 
           (EMF->GetGridEEG()==NULL || EMF->GetGridEEG()->GetNpoints()!=NSens)) OldTablesValid=false;
        
        if(OldTablesValid==false)
        {
            if(NPointsTab>0 && LFtable)
                for(int k=0; k<NPointsTab; k++) delete[] LFtable[k];
            delete[] LFtable;

            NPointsTab = SearchGrid->GetNpoints();
            LFtable    = new double*[NPointsTab];
            if(LFtable==NULL)
            {
                UseLFTables = false;
                NPointsTab  = 0;
                NSens       = 0;
                CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Creating Lead field tables (NPointsTab=%d).\n", NPointsTab);
            }
            else
            {
                for(int k=0; k<NPointsTab; k++) LFtable[k] = NULL;
                FillLFTables = true;
            }
        }
        else 
            FillLFTables = false; // Assume existing ones are still good for use
   }        
        
    
/* Update grids of UEmfield-object*/
    bool FewRightHandSides = false;
    bool ManySigmas        = false;
    if(Select)
    {
        UGrid* Grid = CovarAct->GetGrid()->GetSubGrid(Select, NSelect);
        if(Grid==NULL || Grid->GetError()!=U_OK)
        {
            delete Grid;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Getting sub-grid. \n");
            return NULL;
        }
        if( (CovarAct->GetDataType()==U_DAT_MEG && EMF->SetGrid(Grid, NULL, FewRightHandSides, ManySigmas)!=U_OK ) ||
            (CovarAct->GetDataType()==U_DAT_EEG && EMF->SetGrid(NULL, Grid, FewRightHandSides, ManySigmas)!=U_OK ))
        {
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Setting MEG or EEG grids of EMF-object. \n");
            return NULL;
        }
        delete Grid;
    }
    else
    {
        if( (CovarAct->GetDataType()==U_DAT_MEG && EMF->SetGrid(CovarAct->GetGrid(), NULL, FewRightHandSides, ManySigmas)!=U_OK ) ||
            (CovarAct->GetDataType()==U_DAT_EEG && EMF->SetGrid(NULL, CovarAct->GetGrid(), FewRightHandSides, ManySigmas)!=U_OK ))
        {
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Setting MEG or EEG grids of EMF-object. \n");
            return NULL;
        }
    }
    if(UseLFTables)
    {
        if(CovarAct->GetDataType()==U_DAT_MEG) NSens = EMF->GetGridMEG()->GetNpoints(); 
        if(CovarAct->GetDataType()==U_DAT_EEG) NSens = EMF->GetGridEEG()->GetNpoints(); 
    }

    UField* SAMField = new UField(*SearchGrid);
    if(SAMField==NULL || SAMField->GetError()!=U_OK)
    {
        delete SAMField;
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Creating output field. \n");
        return NULL;
    }
    if(SAMField->ConvertData(UField::U_DOUBLE, 1)!=U_OK || SAMField->SetDataDouble(0.)!=U_OK)
    {
        delete SAMField;
        CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Initializing output field. \n");
        return NULL;
    }

    UEMfield::FieldType FType = UEMfield::U_UNKNOWN;
    if(CovarAct->GetDataType()==U_DAT_MEG) FType = UEMfield::U_MEG;
    if(CovarAct->GetDataType()==U_DAT_EEG) FType = UEMfield::U_EEG;

    for(int n=0; n<SearchGrid->GetNpoints(); n++)
    {
        switch(SearchGrid->GetDType())
        {
        case UField::U_BYTE    : if(SearchGrid->GetBdata()[n]<=0) continue; break;
        case UField::U_SHORT   : if(SearchGrid->GetSdata()[n]<=0) continue; break;
        case UField::U_INTEGER : if(SearchGrid->GetIdata()[n]<=0) continue; break;
        case UField::U_FLOAT   : if(SearchGrid->GetFdata()[n]<=0) continue; break;
        case UField::U_DOUBLE  : if(SearchGrid->GetDdata()[n]<=0) continue; break;
        default:    
            delete SAMField;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Search grid of wrong data type. \n");
            return NULL;
        }
        UVector3 P      = SAMField->GetPoint(n);
        UDipole  Dip    = UDipole(P, UVector3(0.,0.,1));
        double*  LField = NULL;
        if(NOT(UseLFTables) || FillLFTables)
        {
            LField      = EMF->GetEMfield(&Dip, D_OriPos10, FType);
            if(FillLFTables)  LFtable[n] = LField;
        }
        else
            LField = LFtable[n];
        if(LField==NULL)
        {
            delete SAMField;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Getting leadfield at point %s. \n", P.GetProperties());
            return NULL;
        }

        double* LCL_ActR  = NULL;
        double* LCL_ActI  = NULL;
        double* LCL_RestR = NULL;
        double* LCL_RestI = NULL;
        if(EDecAct .Compute_MatT_A_Mat(LField, NULL, 3, &LCL_ActR , &LCL_ActI )!=U_OK  ||
           EDecRest.Compute_MatT_A_Mat(LField, NULL, 3, &LCL_RestR, &LCL_RestI)!=U_OK)
        {
            delete[] LCL_ActR;
            delete[] LCL_ActI;
            delete[] LCL_RestR;
            delete[] LCL_RestI;
            delete[] LField;
            delete SAMField;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Computing L*Cinv*LT at point %d. \n", n);
            return NULL;
        }
        if(NOT(UseLFTables)) delete[] LField;

/* The dipole moment covariance matrix is (LT * (Cinv) L )inv */
        UEigenDecomp EDecBeamAct (3, LCL_ActR , LCL_ActI , true );  // Middle 
        UEigenDecomp EDecBeamRest(3, LCL_RestR, LCL_RestI, false);  // Flank
        delete[] LCL_ActR;
        delete[] LCL_ActI;
        delete[] LCL_RestR;
        delete[] LCL_RestI;

        if(EDecBeamAct.GetError()!=U_OK || EDecBeamRest.GetError()!=U_OK)
        {
            delete SAMField;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Creating eigen value decompositions from L*Cinv*LT at point %d. \n", n);
            return NULL;
        }
        if(EDecBeamAct.GetEigenValue(1)<=0 || EDecBeamRest.GetEigenValue(1)<=0)
        {
            delete SAMField;
            CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Zero eigen values at point %d. \n", n);
            return NULL;
        }
        if(FType==UEMfield::U_EEG)
        {
            if(EDecBeamAct.GetEigenValue(2)<=0 || EDecBeamRest.GetEigenValue(2)<=0)
            {
                delete SAMField;
                CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). EEG: Zero eigen values at point %d. \n", n);
                return NULL;
            }
        }
        if(LogEigen==true)
        {
            UEigenDecomp EDecRatio = UEigenDecomp::ComputeSandwitch(EDecBeamAct, EDecBeamRest);
            if(EDecRatio.GetError()!=U_OK)
            {
                delete SAMField;
                CI.AddToLog("ERROR: UBeamFormer::GetSAMField(). Computing beamformer ratio at point %d. \n", n);
                return NULL;
            }
            SAMField->GetDdata()[n] = log( EDecRatio.GetEigenValue(0) );
        }
        else
        {
            double VarAct  = 1./EDecBeamAct .GetEigenValue(0) + 1./EDecBeamAct .GetEigenValue(1);
            double VarRest = 1./EDecBeamRest.GetEigenValue(0) + 1./EDecBeamRest.GetEigenValue(1);
            if(FType==UEMfield::U_EEG)
            {
                VarAct  += 1./EDecBeamAct .GetEigenValue(2);
                VarRest += 1./EDecBeamRest.GetEigenValue(2);
            }
            SAMField->GetDdata()[n] = (VarAct-VarRest)/VarRest;
        }
    } 
    UString Prop;
    if(LogEigen==true) Prop += UString("BeamFormer = Log(Ratio.Eigen(0))\n");
    else               Prop += UString("BeamFormer = Ratio.Eigen(0)\n");
    Prop += UString("Active:   \n") + CovarAct ->GetProperties(" ") + EDecAct .GetProperties("   ")
          + UString("\n\nRest: \n") + CovarRest->GetProperties(" ") + EDecRest.GetProperties("   ");
    SAMField->AddFileComments(Prop);
    return SAMField;
}
