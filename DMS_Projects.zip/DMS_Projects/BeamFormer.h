#ifndef _BEAMFORMER_INCLUDED
#define _BEAMFORMER_INCLUDED


#include "String.h"


class USensorCorrelate;
class UField;
class UEMfield;
class UGrid;

class DLL_IO UBeamFormer 
{
public:
    UBeamFormer();
    UBeamFormer(const UEMfield* EM);
    UBeamFormer(const UBeamFormer &Beam);    
    virtual ~UBeamFormer();
    UBeamFormer& operator=(const UBeamFormer &Beam);

    ErrorType        GetError(void) const {if(this) return error; return U_ERROR;}
    ErrorType        SetEMField(const UEMfield* EM);
    UField*          GetSAMField(const UField* SearchGrid, const USensorCorrelate* CovarAct, const USensorCorrelate* CovarRest, bool LogEigen, double RegParameter, const int* Select, int NSelect, bool UseTable);

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    static UString   Properties;
    ErrorType        error;            // General error flag

    UEMfield*        EMF;
    int              NPointsTab;
    int              NSens;
    double**         LFtable;    // Lead field for selected points, NULL for non-selected points
};
#endif // _BEAMFORMER_INCLUDED
