/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for computing the magnetic field/potentials using the BEM          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    20-04-99   creation  
  Jdm    07-06-99   Added the possibility to compute bfields and potentials with 
                    smoothed B-vector elements.
  JdM    13-06-99   Computation of partial derivatives
JdM/DvT  16-06-99   BUG fix in call to Sout->GetTriangle()
  JdM    13-08-99   BUG FIX: sign in derivatives w.r.t. position
  GdV    06-07-99   Some corrections due to compilation with GNU-compiler
  JdM    27-08-99   Adapted definition of BFSmatrix[] and the function GetBfield(). 
                    New version should be much faster.
  JdM    21-02-00   Make a few public functions const.
 JdM/SG  10-10-00   BUG FIX: GetPotential(). Use SetBvec() to set the right hand side
                    Added GetPotentialEIT() function for EIT
                    GetPotential(): do not delete pointer returned from SetBvec()
  JdM    13-10-00   Added SetSigma(). Removed obsolete functions and variables.
                    Add more messages to log file
  JdM    17-10-00   Added new constructor for realistic models
  JdM    19-10-00   GetPotentialEIT(). Compute potential using LU, instead of EPSmatrix
  JdM    24-10-00   Bug Fix: GetPotentialEIT(), test NULL pointers
  JdM    30-10-00   GetPotential(). Optimized for the computation of only a few right hand 
                    sides (set last parameter, FewRightHandSides in SetGrid true)
  JdM    31-10-00   Use pre-computed Tweight[] in the linear potential approximation
 JdM/SG  09-11-00   Major update: optimizing for many sigmas
                    Put Sherman Morison Update formula in separate function.
 SG/JdM  21-11-00   A few bug fixes in the use of the Sherman Morison Update Formula
  JdM    29-11-00   Bug fix in SetSigma()
 JdM/SG  01-12-00   Added reference parameter to GetPotentialEIT()
 SG/JdM  19-12-00   BUG FIX releasing memory in SetSigma() (mu[])    
  JdM    20-04-01   Added ReplaceSurface()
 SG/JdM  19-06-01   BUG FIX: GetPotentialEIT() Substracting the reference potential
 JdM/SG  22-06-01   Added LocalRefine() (again?) to make sure existing tables are invalidated
  JdM    17-08-01   Added MEG reference gradiometer/magnetometer grid GridREF
  JdM    21-09-01   ComputeBo(): implemented D_OriPos11
  JdM    17-11-01   GetBfield() and GetPotential(): Compatibility with (semi) symmetric dipoles
  JdM    17-11-01   Added GetRfield() and mechanism to compute fields at reference sensors
  JdM    25-11-01   Bug fix GetRfield().
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
 SG/JdM  05-06-03   Bug Fix: SetSigma() update the EPSmatrix
  JdM    14-07-04   SetGrid() and SetGridREF(): Test whether grids are still valid
  JdM    24-09-04   bug fix dd 14-07-04: SetGridREF(). Test if RFSmatrix==NULL
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    27-02-05   Made several pointers const, according to changes in USurface()
  JdM    21-03-05   Added SetAllMembersDefault(), DeleteAllMembers(), operator=(),
                    default constructor and copy constructor
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    18-03-10   Remove all CI.TimeReset() and CI.TimeFlag()
  JdM    02-02-14   GetPotentialEIT(). Added a few more tests. Skip injection electrodes oin reference.
                    Set potential at injection electrodes equal to 0.
  JdM    07-06-14   GetNestedSurface(). Made returned pointer const
  JdM    24-11-14   GetPotential(), GetPotentialEIT(), case U_POTINTER_LINEAR: Add offs to triangle index, replace Field[i] += by Field[i] =
  JdM    22-02-15   Removed option of curved triangles (UBemMatrix3::SurfInterPolType)
  JdM    13-06-15   Added WriteBinary() and FILE* constructor to UBemField
  JdM    05-07-15   GetPotentialEIT(). Added UseMonoLayer parameter (restricted version)
  JdM    18-08-15   GetPotential(). Added UseMonoLayer parameter, which now also valid for dipoles
  JdM    23-08-15   Made UsemonoLayer data member of UBemMatrix, instead of parameter of ComputePotential() and ComputePotentialEIT()
  JdM    30-08-15   Major update of code. Used UMatrix objects where possible, to increase readability
  JdM    17-09-15   Made UseMonolayer compatible with U_POTINTER_LINEAR for case of EIT. 
  JdM    18-09-15   Added GAMmatrix data member
  JdM    21-03-16   Major update of code. Used UMatrix objects also in Sigma updating algorithm. Added various data members (OptimizeManySigma). 
                    Renamed ShermanMorrisonUpdate() as WoodburyUpdate().
  JdM    16-04-16   Bug fixed and tested updates from 21-03-16. Allow OptimizeManySigma combined with UseMonoLayer
  JdM    27-12-16   Bug Fixed and tested SetSigma(), for all settings combinations (including UseMonoLayer).
  JdM    01-01-17   GetPotential(): Made suitable for combi UseMonoLayer && PInter==U_POTINTER_LINEAR
  JdM    04-01-17   SetSigma(), case OptimizeManySigma && GetMonoLayer(): use different deflation scaling to obtain stable results.
  JdM    29-01-17   SetSigma(), case OptimizeManySigma && GetMonoLayer(): use conductivity dependent deflation scaling to obtain stable results.
  JdM    30-01-17   SetSigma(), case NOT(OptimizeManySigma): use "reconstructed" system matrix
  JdM    26-03-18   Added GetPotentialEIT(), for unipolar stimulation
  JdM    15-04-18   UpdateEEGindices(). Launch WARNING if electrodes faurther than 1 cm from surface (instead of Note:)
  JdM    01-06-18   Added another constructor, where BEM settings of UHeadModel argument are overwritten.
  JdM    13-07-18   Added ResetMatrices()
 */

#include <math.h>
#include <string.h>
#include <stdio.h>

#include "BemField.h"
#include "BemIntegral.h"

const char*  UBemField::HEADERBEGIN = "BemField1.2";
const char*  UBemField::HEADEREND   = "BemFieldEnd";

static const double SIGMA_DEF_SKIN  = 1.;
static const double SIGMA_DEF_SKULL = 2.;
static const double SIGMA_DEF_BRAIN = 3.;

const double UBemField::DefaultSigmas[6] = {0., SIGMA_DEF_SKIN , SIGMA_DEF_SKULL, 
                                SIGMA_DEF_SKIN, SIGMA_DEF_SKULL, SIGMA_DEF_BRAIN}; // outer surf 0, surf 1, surf 2, inner surf 0, surf 1, surf 2.


void UBemField::SetAllMembersDefault(void)
{
    error             = U_OK;
    GridREF           = NULL;
    GridMEG           = NULL;
    GridEEG           = NULL;
    RFSmatrix         = UMatrix();
    BFSmatrix         = UMatrix();
    EPSmatrix         = UMatrix();
    GAMmatrix         = UMatrix();
    LU                = ULUdecompose();
    Tweight           = UMatrix();
    IndexTri          = NULL;
    IndexPot          = NULL;
    IndexLin          = NULL;

    OptimizeManySigma = false;
    Ymat              = UMatrix();
    BLU               = ULUdecompose();
}

void UBemField::DeleteAllMembers(ErrorType E)
{
    delete   GridREF;
    delete   GridMEG;
    delete   GridEEG;
    delete[] IndexTri;
    delete[] IndexPot;
    delete[] IndexLin;

    SetAllMembersDefault();
    error   = E;
}

UBemField::UBemField() : UBemMatrix3()
{
    SetAllMembersDefault();
}

UBemField::UBemField(const UHeadModel* Hmod) : UBemMatrix3(Hmod)
{
    SetAllMembersDefault();
    error     = UBemMatrix3::GetError();
    if(error!=U_OK)
        CI.AddToLog("ERROR: UBemField::UBemField(). Initializing base class. \n");
}
UBemField::UBemField(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer): 
    UBemMatrix3(Hmod, PInt, Smo, UseMonoLayer)
{
    SetAllMembersDefault();
    error     = UBemMatrix3::GetError();
    if(error!=U_OK)
        CI.AddToLog("ERROR: UBemField::UBemField(). Initializing base class. \n");
}
UBemField::UBemField(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer) : 
    UBemMatrix3(C, PInt, Smo, UseMonoLayer)
{
    SetAllMembersDefault();
    error     = UBemMatrix3::GetError();
    if(error!=U_OK)
        CI.AddToLog("ERROR: UBemField::UBemField(). Initializing base class. \n");
}

UBemField::UBemField(const UBemField &B) 
{
    SetAllMembersDefault();
    *this = B;
}
UBemField::UBemField(FILE* fpIn) : UBemMatrix3(fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::UBemField(). Invalid NULL pointer. \n");
        return;
    }
    if(UConductor3::GetError()!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::UBemField(). Creating UConductor3 base class. \n");
        return;
    }

    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemField::UBemField(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }
    ErrorType E      = U_OK;
    int       IITEM  = 0;
    bool BoolGridREF = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolGridREF)
    {
        GridREF = new UGrid(fpIn);
        if(GridREF==NULL || GridREF->GetError()!=U_OK) E= U_ERROR;
        if(E==U_OK) IITEM++;
    }
    bool BoolGridMEG = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolGridMEG)
    {
        GridMEG = new UGrid(fpIn);
        if(GridMEG==NULL || GridMEG->GetError()!=U_OK) E= U_ERROR;
        if(E==U_OK) IITEM++;
    }
    bool BoolGridEEG = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolGridEEG)
    {
        GridMEG = new UGrid(fpIn);
        if(GridEEG==NULL || GridEEG->GetError()!=U_OK) E= U_ERROR;
        if(E==U_OK) IITEM++;
    }

    int Neeg = (GridEEG==NULL || GridEEG->GetNpoints()<=0) ? 0 : GridEEG->GetNpoints();
    bool BoolTindex = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolTindex)
    {
        if(Neeg<=0 || (IndexTri=new int[  Neeg])==NULL)  E= U_ERROR;
        else E = ::ReadBinaryIntArray(IndexTri,   Neeg, DefaultIntelData, fpIn);
        if(E==U_OK) IITEM++;
    }
    bool BoolPindex = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolPindex)
    {
        if(Neeg<=0 || (IndexPot=new int[  Neeg])==NULL)  E= U_ERROR;
        else E = ::ReadBinaryIntArray(IndexPot,   Neeg, DefaultIntelData, fpIn);
        if(E==U_OK) IITEM++;
    }
    bool BoolLindex = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(E==U_OK && BoolLindex)
    {
        if(Neeg<=0 || (IndexLin=new int[3*Neeg])==NULL)  E= U_ERROR;
        else E = ::ReadBinaryIntArray(IndexLin, 3*Neeg, DefaultIntelData, fpIn);
        if(E==U_OK) IITEM++;
    }

    if(E==U_OK) {Tweight   = UMatrix(fpIn);       E=Tweight  .GetError(); if(E==U_OK) IITEM++;}
    if(E==U_OK) {RFSmatrix = UMatrix(fpIn);       E=RFSmatrix.GetError(); if(E==U_OK) IITEM++;}
    if(E==U_OK) {BFSmatrix = UMatrix(fpIn);       E=BFSmatrix.GetError(); if(E==U_OK) IITEM++;}
    if(E==U_OK) {EPSmatrix = UMatrix(fpIn);       E=EPSmatrix.GetError(); if(E==U_OK) IITEM++;}
    if(E==U_OK) {GAMmatrix = UMatrix(fpIn);       E=GAMmatrix.GetError(); if(E==U_OK) IITEM++;}
    if(E==U_OK) {LU        = ULUdecompose(fpIn);  E=LU       .GetError(); if(E==U_OK) IITEM++;}

    OptimizeManySigma = ::ReadBinaryBool(DefaultIntelData, fpIn);
    if(OptimizeManySigma)
    {
        if(E==U_OK) {BLU       = ULUdecompose(fpIn);  E=BLU     .GetError(); if(E==U_OK) IITEM++;}
        if(E==U_OK) {Ymat      = UMatrix(fpIn);       E=Ymat    .GetError(); if(E==U_OK) IITEM++;}
    }
    if(E!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemField::UBemField(). Reading one of the data members. There were %d items read in correctly. \n", IITEM);
        return;
    }
    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemField::UBemField(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }
    
    if(UpdateEEGindices()!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemField::UBemField(). Updating electrode indices. \n", HEADEREND);
        return;
    }
}

ErrorType UBemField::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }
    if(UBemMatrix3::WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing base class. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(bool(GridREF!=NULL), DefaultIntelData, fpOut);
    if(GridREF && GridREF->WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing MEG reference sensors. \n");
        return U_ERROR;
    }
    ::WriteBinary(bool(GridMEG!=NULL), DefaultIntelData, fpOut);
    if(GridMEG && GridMEG->WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing MEG sensors. \n");
        return U_ERROR;
    }
    ::WriteBinary(bool(GridEEG!=NULL), DefaultIntelData, fpOut);
    if(GridEEG && GridEEG->WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing EEG sensors. \n");
        return U_ERROR;
    }

    ::WriteBinary(bool(IndexTri!=NULL), DefaultIntelData, fpOut);
    if(IndexTri) ::WriteBinary(IndexTri,   GridEEG->GetNpoints(), DefaultIntelData, fpOut);
    ::WriteBinary(bool(IndexPot!=NULL), DefaultIntelData, fpOut);
    if(IndexPot) ::WriteBinary(IndexPot,   GridEEG->GetNpoints(), DefaultIntelData, fpOut);
    ::WriteBinary(bool(IndexLin!=NULL), DefaultIntelData, fpOut);
    if(IndexLin) ::WriteBinary(IndexLin, 3*GridEEG->GetNpoints(), DefaultIntelData, fpOut);

    if( Tweight  .WriteBinary(fpOut)!=U_OK ||
        RFSmatrix.WriteBinary(fpOut)!=U_OK ||
        BFSmatrix.WriteBinary(fpOut)!=U_OK ||
        EPSmatrix.WriteBinary(fpOut)!=U_OK ||
        GAMmatrix.WriteBinary(fpOut)!=U_OK ||
        LU       .WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing one of the matrices or LU decompositions. \n");
        return U_ERROR;
    }
    ::WriteBinary(OptimizeManySigma, DefaultIntelData, fpOut);

    if(OptimizeManySigma)
    {
        if(BLU     .WriteBinary(fpOut)!=U_OK ||
           Ymat    .WriteBinary(fpOut)!=U_OK)
        {
            CI.AddToLog("ERROR: UBemField::WriteBinary(). Writing one of the OptimizeManySigma-matrices or its LU decompositions. \n");
        }
    }

    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}
UBemField::~UBemField()
{
    DeleteAllMembers(U_OK);
}

UBemField& UBemField::operator=(const UBemField &B)
{
    if(this==NULL || &B==NULL)
    {
        if(this==NULL)
        {
            CI.AddToLog("ERROR: UBemField::operator=(). this==NULL. \n");
            static UBemField B; B.error=U_ERROR;
            return B;
        }
        else
        {
            CI.AddToLog("ERROR: UBemField::operator=(). Invalid NULL Address argument. \n");
            DeleteAllMembers(U_ERROR);
            UBemMatrix3::DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    if(this==&B) return *this;

    UBemMatrix3::operator=((UBemMatrix3) B);
    if(UBemMatrix3::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    if(B.GridREF) GridREF = new UGrid(*B.GridREF);
    if(B.GridMEG) GridMEG = new UGrid(*B.GridMEG);
    if(B.GridEEG) GridEEG = new UGrid(*B.GridEEG);

    Tweight           = B.Tweight;
    RFSmatrix         = B.RFSmatrix;
    BFSmatrix         = B.RFSmatrix;
    EPSmatrix         = B.RFSmatrix;
    GAMmatrix         = B.GAMmatrix;
    OptimizeManySigma = B.OptimizeManySigma;
    LU                = B.LU;
    Ymat              = B.Ymat;
    BLU               = B.BLU;

    if(B.IndexTri && B.GridEEG && B.GridEEG->GetNpoints()>0)    
    {
        IndexTri = new int[B.GridEEG->GetNpoints()];
        if(IndexTri) for(int k=0; k<B.GridEEG->GetNpoints(); k++) IndexTri[k] = B.IndexTri[k];
    }
    if(B.IndexPot && B.GridEEG && B.GridEEG->GetNpoints()>0)    
    {
        IndexPot = new int[B.GridEEG->GetNpoints()];
        if(IndexPot) for(int k=0; k<B.GridEEG->GetNpoints(); k++) IndexPot[k] = B.IndexPot[k];
    }
    if(B.IndexLin && B.GridEEG && B.GridEEG->GetNpoints()>0)    
    {
        IndexLin = new int[3*B.GridEEG->GetNpoints()];
        if(IndexLin) for(int k=0; k<3*B.GridEEG->GetNpoints(); k++) IndexLin[k] = B.IndexLin[k];
    }

    if( (B.GridREF   && (GridREF  ==NULL || GridREF->GetError()!=U_OK)) ||
        (B.GridMEG   && (GridMEG  ==NULL || GridMEG->GetError()!=U_OK)) ||
        (B.GridEEG   && (GridEEG  ==NULL || GridEEG->GetError()!=U_OK)) ||
        (B.IndexTri  &&  IndexTri ==NULL)                               ||
        (B.IndexPot  &&  IndexPot ==NULL)                               ||
        (B.IndexLin  &&  IndexLin ==NULL)                               ||
        Tweight.GetError()  != U_OK||
        RFSmatrix.GetError()!=U_OK || BFSmatrix.GetError()!=U_OK || EPSmatrix.GetError()!=U_OK || GAMmatrix.GetError()!=U_OK ||
        LU.GetError()!=U_OK        || BLU.GetError()!=U_OK       || Ymat.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UBemMatrix3::DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::operator=(). Copying members, Npot = %d  . \n", GetNpot());
        return *this;
    }
    return *this;
}
ErrorType UBemField::ResetMatrices(void)
{
    if(this==NULL) return U_ERROR;
    RFSmatrix         = UMatrix();
    BFSmatrix         = UMatrix();
    EPSmatrix         = UMatrix();
    GAMmatrix         = UMatrix();
    LU                = ULUdecompose();
    Tweight           = UMatrix();
    Ymat              = UMatrix();
    BLU               = ULUdecompose();
    return U_OK;
}

ErrorType UBemField::SetSigma(const double *Sigma)
{
    if(GridEEG==NULL)
    {
        CI.AddToLog("ERROR: UBemField::SetSigma(). EEG has not yet been set.\n");
        return U_ERROR;
    }

    double SigOld[3] = {UConductor3::GetConductivity(0),UConductor3::GetConductivity(1),UConductor3::GetConductivity(2)};
    if(UConductor3::SetSigma(Sigma)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::SetSigma(). Error in setting Sigma of base class.\n");
        return U_ERROR;
    }

    int N0  = UBemMatrix3::GetNpot(0);  // Outer
    int N1  = UBemMatrix3::GetNpot(1);
    int N2  = UBemMatrix3::GetNpot(2);  // Inner
    int N12 = N1+N2+1;

    if(OptimizeManySigma)  // Prepare for the Woodburry formula
    {
        if(fabs(Sigma[0]-DefaultSigmas[3]) + fabs(Sigma[1]-DefaultSigmas[4]) + fabs(Sigma[2]-DefaultSigmas[5])<1.e-12)
        {
            BLU  = ULUdecompose();
            return U_OK;
        }
        if(Ymat.GetNrow()!=Npot && Ymat.GetNcol()!=N12)
        {
            ErrorType E = U_OK;
            Ymat = UMatrix(DNULL, Npot, N12);
            if(GetPotInterPol()==U_POTINTER_LINEAR && GetSmoothElemA()==U_SMOOTH_SMOOTH)
            {
                if(E==U_OK) E = Ymat.SetBlock(N0   ,0 ,GetImprodHOne(true, 1)*GetSurface(1)->GetOverlapMatrix(true));
                if(E==U_OK) E = Ymat.SetBlock(N0+N1,N1,GetImprodHOne(true, 2)*GetSurface(2)->GetOverlapMatrix(true));
            }
            else
            {
                if(E==U_OK) E = Ymat.SetUnitVectors(N0, N0+N1+N2-1, true);
            }
            double  Const = GetMonoLayer() ? Sigma[1]/(Sigma[0]+Sigma[2]) : 1./(N0+N1+N2);
            if(E==U_OK) E = Ymat.SetCol(N12-1, Const);

            if(E!=U_OK || Ymat.GetError()!=U_OK)
            {
                Ymat = UMatrix();
                BLU  = ULUdecompose();
                CI.AddToLog("ERROR: UBemField::SetSigma(). Creating intermediate matrix YMat.\n");
                return U_ERROR;
            }

            LU.ComputeAxIsB(&Ymat, false);
            UMatrix Lam0(DefaultSigmas[0]-DefaultSigmas[3], N0, DefaultSigmas[1]-DefaultSigmas[4], N1, DefaultSigmas[2]-DefaultSigmas[5], N2);
            Ymat  = Lam0*Ymat;
        }

        UMatrix Diag1(Sigma[0]/(Sigma[0]-Sigma[1]) - DefaultSigmas[3]/(DefaultSigmas[3]-DefaultSigmas[4]), N1); // Middle        
        UMatrix Diag2(Sigma[1]/(Sigma[1]-Sigma[2]) - DefaultSigmas[4]/(DefaultSigmas[4]-DefaultSigmas[5]), N2); // Inner

        UMatrix E(DNULL, N0+N1+N2, 1); E.SetData(1.);
        UMatrix D(1./(        -Sigma[0]) - 1./(                -DefaultSigmas[3]), N0,
                  1./(Sigma[0]-Sigma[1]) - 1./(DefaultSigmas[3]-DefaultSigmas[4]), N1,
                  1./(Sigma[1]-Sigma[2]) - 1./(DefaultSigmas[4]-DefaultSigmas[5]), N2);

        UMatrix Bmat(DNULL, N12, N12);
        Bmat.SetBlock( 0   ,  0, Diag1*Ymat.GetBlock(N0   , 0, N1, N12));
        Bmat.SetBlock(N1   ,  0, Diag2*Ymat.GetBlock(N0+N1, 0, N2, N12));
        Bmat.SetBlock(N1+N2,  0, GetMatMul(D*E, true, Ymat, false));

        Bmat += UMatrix(N12);

        BLU = ULUdecompose(Bmat);
        if(BLU.GetError()!=U_OK)
        {
            Ymat = UMatrix();
            BLU  = ULUdecompose();
            CI.AddToLog("ERROR: UBemField::SetSigma(). Creating N12*N12 LU decomposition, N12 = %d.\n", N12);
            return U_ERROR;
        }
    }
    else
    {
        if(LU.GetError()==U_OK && LU.GetN()==Npot)
        {
            UMatrix Lratio(Sigma[0]/SigOld[0], N0, (Sigma[1]-Sigma[0])/(SigOld[1]-SigOld[0]), N1, (Sigma[2]-Sigma[1])/(SigOld[2]-SigOld[1]), N2);
            
            UMatrix Amat = LU.GetMatrix();
            if(GetPotInterPol()==U_POTINTER_LINEAR && GetSmoothElemA()==U_SMOOTH_SMOOTH)
            {
                Amat.SubtractBlock(N0   , N0   , GetImprodHOne(true, 1)*GetSurface(1)->GetOverlapMatrix(true)*SigOld[0]);
                Amat.SubtractBlock(N0+N1, N0+N1, GetImprodHOne(true, 2)*GetSurface(2)->GetOverlapMatrix(true)*SigOld[1]);
            }
            else
            {
                Amat -= UMatrix(0., N0,  SigOld[0], N1,  SigOld[1], N2);
            }
            Amat-=(1./Npot);
            Amat = Amat*Lratio;

            if(GetPotInterPol()==U_POTINTER_LINEAR && GetSmoothElemA()==U_SMOOTH_SMOOTH)
            {
                Amat.AddBlock(N0   , N0   , GetImprodHOne(true, 1)*GetSurface(1)->GetOverlapMatrix(true)*Sigma[0]);
                Amat.AddBlock(N0+N1, N0+N1, GetImprodHOne(true, 2)*GetSurface(2)->GetOverlapMatrix(true)*Sigma[1]);
                Amat.AdaptDiagonalToConstantEigenvector();
            }
            else
            {
                Amat += UMatrix(0., N0,  Sigma[0] , N1,  Sigma[1] , N2);;
            }
            Amat+=(1./Npot);
            
            double* pLU = LU.GetLUArray();
            double* pAm = Amat.Data;
            for(int k=0; k<Npot*Npot; k++, pLU++, pAm++) *pLU = *pAm;
        }
        else
        {
/* Set and invert system matrix*/
            LU = ULUdecompose(Npot);
            if(UBemMatrix3::SetAmat(LU.GetLUArray(), true, NULL)!=U_OK) 
            {
                CI.AddToLog("ERROR: UBemField::SetSigma(). Error in setting system matrix.\n");
                LU = ULUdecompose();
                return U_ERROR;
            }
///////
//    double* U       = new double[Npot*Npot];
//    double* Lamda   = new double[Npot];
//    double* V       = new double[Npot*Npot];
//    for(int k=0;k<Npot*Npot;k++) U[k]=LU.GetMatrix()[k]-1./Npot;
//
//    svdcmp_d(U, Npot, Npot, Lamda, V);
//    FILE* fp=fopen("C:/Users/IBM/Desktop/Temp/U.txt","wt");
//    for(int k=0; k<Npot; k++) fprintf(fp, "%f \n",U[k*Npot+Npot-1]);
//    fclose(fp);
//    fp=fopen("C:/Users/IBM/Desktop/Temp/V.txt","wt");
//    for(int k=0; k<Npot; k++) fprintf(fp, "%f \n",V[k*Npot+Npot-1]);
//    fclose(fp);
//    fp=fopen("C:/Users/IBM/Desktop/Temp/VT.txt","wt");
//    for(int k=0; k<Npot; k++) fprintf(fp, "%f \n",V[(Npot-1)*Npot+k]);
//    fclose(fp);
///////
        }
/* Update LU decomposition */    
        if(LU.ComputeLUDecomposition()!=U_OK)
        {
            CI.AddToLog("ERROR: UBemField::SetSigma(). Error in LU-decomposition of system matrix.\n");
            LU = ULUdecompose();
            return U_ERROR;
        }

        if(NOT(EPSmatrix.IsEmpty()) && ComputeEPSmatrix()!=U_OK)  // Update the EPS matrix, when required (EPSmatrix!=0)
        {
            CI.AddToLog("ERROR: UBemField::SetSigma(). Updating EPS matrix.\n");
            LU = ULUdecompose();
            return U_ERROR;
        }
    }
    return U_OK;
}
ErrorType UBemField::WoodBuryUpdate(UMatrix* Psi) const
/*
    Apply Woodburry formula on the potentials Psi, computed from the deflated
    system matrix with unit conductivity differences.
*/
{
    double Sigma[3] = {UConductor3::GetConductivity(0), UConductor3::GetConductivity(1), UConductor3::GetConductivity(2)};
    if(fabs(Sigma[0]-DefaultSigmas[3]) + fabs(Sigma[1]-DefaultSigmas[4]) + fabs(Sigma[2]-DefaultSigmas[5])<1.e-12)
    {
        return U_OK;
    }
    if(BLU.IsEmpty() || Ymat.IsEmpty())  
    {
        CI.AddToLog("ERROR: UBemfield::WoodBuryUpdate(). BLU or Ymat not set.\n");
        return U_ERROR;
    }
    if(Psi==NULL && Psi->GetError() || Npot != Psi->GetNrow() || Psi->Data==NULL)
    {
        CI.AddToLog("ERROR: UBemfield::WoodBuryUpdate(). NULL or erroneous matrix argument.\n");
        return U_ERROR;
    }

    int    N0       = UBemMatrix3::GetNpot(0);  // Outer
    int    N1       = UBemMatrix3::GetNpot(1);
    int    N2       = UBemMatrix3::GetNpot(2);  // Inner
    int    N12      = N1+N2+1;

    UMatrix Lam0(DefaultSigmas[0]-DefaultSigmas[3], N0, DefaultSigmas[1]-DefaultSigmas[4], N1, DefaultSigmas[2]-DefaultSigmas[5], N2); // Outer, Middle, Inner
    UMatrix Lam(            1./(        -Sigma[0]), N0,            1./(Sigma[0]-Sigma[1]), N1,            1./(Sigma[1]-Sigma[2]), N2);

    UMatrix Diag1(Sigma[0]/(Sigma[0]-Sigma[1]) - DefaultSigmas[3]/(DefaultSigmas[3]-DefaultSigmas[4]), N1); // Middle
    UMatrix Diag2(Sigma[1]/(Sigma[1]-Sigma[2]) - DefaultSigmas[4]/(DefaultSigmas[4]-DefaultSigmas[5]), N2); // Inner

    UMatrix E(DNULL, N0+N1+N2, 1); E.SetData(1.);
    UMatrix D(1./(        -Sigma[0]) - 1./(                -DefaultSigmas[3]), N0,
              1./(Sigma[0]-Sigma[1]) - 1./(DefaultSigmas[3]-DefaultSigmas[4]), N1,
              1./(Sigma[1]-Sigma[2]) - 1./(DefaultSigmas[4]-DefaultSigmas[5]), N2);

    if(UBemMatrix3::GetMonoLayer()==true)
    {
        *Psi       = Lam* *Psi;
        UMatrix ZZ = GetMatMul(Ymat, true, *Psi, false);

        BLU.ComputeAxIsB(&ZZ, true);
        
        E.SetData(ZZ[N1+N2]);
        UMatrix PP(DNULL, Npot, 1);
        PP.SetBlock(N0   ,0, Diag1*ZZ.GetBlock( 0,0,N1,1));
        PP.SetBlock(N0+N1,0, Diag2*ZZ.GetBlock(N1,0,N2,1));
        PP   += D*E;

        *Psi  = Lam0*(*Psi - PP); 
    }
    else
    {
        *Psi  = Lam0* *Psi;

        UMatrix Zweight(DNULL, N12, 1);
        Zweight.SetBlock( 0   ,  0, Diag1*Psi->GetBlock(N0   , 0, N1, 1));
        Zweight.SetBlock(N1   ,  0, Diag2*Psi->GetBlock(N0+N1, 0, N2, 1));
        Zweight.SetBlock(N1+N2,  0, GetMatMul(D*E, true, *Psi, false));

        BLU.ComputeAxIsB(&Zweight, false);  // Solve Bmat * Zweight = SigmaPsi

        *Psi  = Lam*(*Psi - Ymat*Zweight);
    }
    if(Psi->GetError()!=U_OK) return U_ERROR;
    return U_OK;
}

ErrorType UBemField::ReplaceSurface(int iSurface, const USurface &S)
{
    if(UBemMatrix3::ReplaceSurface(iSurface, S)!=U_OK) return U_ERROR;

    RFSmatrix = UMatrix();
    BFSmatrix = UMatrix();
    EPSmatrix = UMatrix();
    GAMmatrix = UMatrix();
    LU        = ULUdecompose();
    
    Ymat      = UMatrix();
    BLU       = ULUdecompose();
    return UpdateEEGindices();
}

ErrorType UBemField::ReplaceSurface(int iSurface, const UConductor3 &r)
{
    if(UBemMatrix3::ReplaceSurface(iSurface, r)!=U_OK) return U_ERROR;

    RFSmatrix = UMatrix();
    BFSmatrix = UMatrix();
    EPSmatrix = UMatrix();
    GAMmatrix = UMatrix();
    LU        = ULUdecompose();
    
    Ymat      = UMatrix();
    BLU       = ULUdecompose();
    return UpdateEEGindices();
}

ErrorType UBemField::LocalRefine(double MaxDistance, UVector3* Pts, int Npts)
{
    if(UBemMatrix3::LocalRefine(MaxDistance, Pts, Npts)!=U_OK) return U_ERROR;

    RFSmatrix = UMatrix();
    BFSmatrix = UMatrix();
    EPSmatrix = UMatrix();
    GAMmatrix = UMatrix();
    LU        = ULUdecompose();
    
    Ymat      = UMatrix();
    BLU       = ULUdecompose();
    return UpdateEEGindices();
}

ErrorType UBemField::SetGridREF(const UGrid* GrREF)
{
    if(GrREF==NULL) // Reset Refernce grid parameters
    {
        delete   GridREF;   GridREF   = NULL;
        RFSmatrix = UMatrix();
        return U_OK;
    }
    if(GrREF->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::SetGridREF(). Erroneous UGrid() argument. \n");
        return U_ERROR;
    }

/* Old reference still valid ?*/
    if(NOT(RFSmatrix.IsEmpty()) && GridREF!=NULL && *GrREF == *GridREF) return U_OK;

/* Set and invert system matrix*/
    LU = ULUdecompose(Npot);
    if(UBemMatrix3::SetAmat(LU.GetLUArray(), true, NULL)!=U_OK) 
    {
        LU = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGridREF(). Error in setting system matrix.\n");
        return U_ERROR;
    }
    if(LU.ComputeLUDecomposition()!=U_OK)
    {
        LU = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGridREF(). Error in LU-decomposing system matrix.\n");
        return U_ERROR;
    }

/* Set Reference Grid*/
    delete GridREF; 
    GridREF = new UGrid(*GrREF);
    if(GridREF==NULL || GridREF->GetError()!=U_OK)
    {
        delete   GridREF;   GridREF   = NULL;
        RFSmatrix = UMatrix();
        LU        = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGridREF(). Error in copying reference grid.\n");
        return U_ERROR;
    }

/* Compute Reference Field System Matrix*/
    if(ComputeRFSmatrix()!=U_OK) 
    {
        delete   GridREF;   GridREF   = NULL;
        RFSmatrix = UMatrix();
        LU        = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGridREF(). Computing RSFmatrix.\n");
        return U_ERROR;
    }

/* LU object is not required anymore */
    LU = ULUdecompose();
    return U_OK;
}

ErrorType UBemField::SetGrid(const UGrid* GrMEG, const UGrid* GrEEG, bool FewRightHandSides, bool ManySigmas)
/*
    Make a local copy of the MEG grid and the EEG grid on which the magnetic fields/
    electric potentials are computed. For that purpose, initialize the magnetic field 
    system matrix BFSmatrix[] and the electric potential system matrix EPSmatrix[].

    After the SetGrid() has been called succesfully (return U_OK), the magnetic field/
    electric potential caused by a dipolar source can be computed by GetBfield(),
    GetPotential().

    if(ManySigmas==true) prepare the object such that it is appropriate for EIT:
                         allocate memory for Zmat and BLU, and compute the system matrix
                         (and LU) with unit cond. differences.                                 
                         In all other cases Zmat and BLU are set to NULL.
                         This option can only be used when FewRightHandSides==true

    Notes:
    If(GrMEG==NULL) magnetic field computations are disabled
    If(GrEEG==NULL) electric field computations are disabled
 */
{
/* Test arguments*/
    if(GrMEG==NULL && GrEEG==NULL)  
    {
        CI.AddToLog("ERROR: UBemField::SetGrid(). Neither EEG nor MEG grid is given.\n");
        return U_ERROR;
    }    
    if(/**** (GrMEG && FewRightHandSides==true) || ***/ (GrMEG && ManySigmas==true) )
    {
        CI.AddToLog("ERROR: UBemField::SetGrid(). The few right hand sides option and the many sigmas option only work with EEG, not MEG.\n");
        return U_ERROR;
    }
    if(UBemMatrix3::GetMonoLayer()==true)
    {
        if(FewRightHandSides==false)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many right hand sides option (and optimizing computations by computing complete inverse of system matrix) cannot (yet) be combined with the monolayer approach.\n");
            return U_ERROR;
        }
        if(GrMEG)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). Monolayer approch not (yet) compatible with magnetitic field computations.\n");
            return U_ERROR;
        }
    }
/* Old grid still valid ?*/
    bool OldMEGValid = false; 
    if( ( GridMEG &&  GrMEG && *GrMEG == *GridMEG)  ||
        (!GridMEG && !GrMEG))
        OldMEGValid = true;
    bool OldEEGValid = false; 
    if( ( GridEEG &&  GrEEG && *GrEEG == *GridEEG)  ||
        (!GridEEG && !GrEEG))
        if( (ManySigmas==true  &&  (BLU.IsEmpty()==false&&Ymat.IsEmpty()==false)) ||
            (ManySigmas==false && !(BLU.IsEmpty()==false&&Ymat.IsEmpty()==false)) )
                OldEEGValid = true;

    if(OldMEGValid && OldEEGValid) return U_OK;

    if(ManySigmas==true)
    {
        if(FewRightHandSides==false)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many sigmas option only work when the few right hand sides option is on. \n");
            return U_ERROR;
        }
        if(GetNsurfaces()!=3)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many sigmas option only work with three surfaces. Nsurface = %d\n",GetNsurfaces());
            return U_ERROR;
        }
        if(GetOuterSurf()!=0)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many sigmas option only work when the outer surface is the first one (not %d). Try to change head model file.\n",GetOuterSurf());
            return U_ERROR;
        }
        if(GetInnerSurf()!=2)
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many sigmas option only work when the inner surface is the last one (not %d). Try to change head model file.\n",GetInnerSurf());
            return U_ERROR;
        }
        if(GetSurface(2)->GetParent() != 1   ||
           GetSurface(1)->GetParent() != 0 )
        {
            CI.AddToLog("ERROR: UBemField::SetGrid(). The many sigmas option only work when all surfaces are nested. This is wrong: %s\n", UConductor3::GetProperties((const char*)NULL));
            return U_ERROR;
        }
    }
    OptimizeManySigma = ManySigmas;
    Ymat              = UMatrix();
    BLU               = ULUdecompose();

/* Set and invert system matrix*/
    LU                = ULUdecompose(Npot);
    ErrorType E       = ManySigmas ? UBemMatrix3::SetAmat(LU.GetLUArray(), true, DefaultSigmas) : UBemMatrix3::SetAmat(LU.GetLUArray(), true, NULL);
    if(LU.GetError()!=U_OK || LU.GetLUArray()==NULL || E!=U_OK) 
    {
        LU = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGrid(). Error in setting system matrix.\n");
        return U_ERROR;
    }
    if(LU.ComputeLUDecomposition()!=U_OK)
    {
        LU = ULUdecompose();
        CI.AddToLog("ERROR: UBemField::SetGrid(). Error in LU-decomposing system matrix.\n");
        return U_ERROR;
    }

/* Set MEG Grid*/
    if(GrMEG)
    {
        delete GridMEG; GridMEG = new UGrid(*GrMEG);
        if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
        {
            delete   GridMEG;   GridMEG   = NULL;
            BFSmatrix = UMatrix();
            LU        = ULUdecompose();
            CI.AddToLog("ERROR: UBemField::SetGrid(). Error in copying MEG grid.\n");
            return U_ERROR;
        }

/* Compute Bfield System Matrix*/
        if(ComputeBFSmatrix()!=U_OK) 
        {
            delete   GridMEG;   GridMEG   = NULL;
            BFSmatrix = UMatrix();
            LU        = ULUdecompose();
            CI.AddToLog("ERROR: UBemField::SetGrid(). Computing BSFmatrix.\n");
            return U_ERROR;
        }

/* Invalidate previous balancing information*/
        delete   GridREF;   GridREF   = NULL; RFSmatrix = UMatrix();
    }

/* Set EEG Grid*/
    if(GrEEG)
    {
        delete   GridEEG;  GridEEG = new UGrid(*GrEEG);
        if(GridEEG==NULL || GridEEG->GetError()!=U_OK || UpdateEEGindices()!=U_OK) 
        {
            delete   GridEEG;   GridEEG  = NULL;
            delete[] IndexTri;  IndexTri = NULL;
            delete[] IndexPot;  IndexPot = NULL;
            delete[] IndexLin;  IndexLin = NULL;
            CI.AddToLog("ERROR: UBemField::SetGrid(). Memory allocation, setting EEG grid, or setting EEG indices.\n");
            return U_ERROR;        
        }
        if(UBemMatrix3::GetMonoLayer()==true)
        {
            int nEEG = GridEEG->GetNpoints();
            if(GetPotInterPol()==U_POTINTER_CONSTANT) GAMmatrix = UBemMatrix3::GetGammaMat(IndexTri,   nEEG);
            else                                      GAMmatrix = UBemMatrix3::GetGammaMat(IndexLin, 3*nEEG); 
        }
        if(FewRightHandSides==true)
        {
            EPSmatrix = UMatrix();
            if(ManySigmas==true)  // Prepare for the Woodburry formula
            {
                Ymat = UMatrix();
                BLU  = ULUdecompose();
                
                double Sigma[3] = {UConductor3::GetConductivity(0), UConductor3::GetConductivity(1), UConductor3::GetConductivity(2)};

                if(SetSigma(Sigma)!=U_OK)
                {
                    CI.AddToLog("ERROR: UBemField::SetGrid(). Setting sigmas. ManySigmas==true.\n");
                    return U_ERROR;
                }
            }
            return U_OK;  // Keep LU
        }        
        else /* Compute Electric Potential System Matrix*/
        {
            if(ComputeEPSmatrix()!=U_OK) 
            {
                delete   GridEEG;   GridEEG   = NULL;
                delete[] IndexTri;  IndexTri  = NULL;
                delete[] IndexPot;  IndexPot  = NULL;
                delete[] IndexLin;  IndexLin  = NULL;
                EPSmatrix = UMatrix();
                LU        = ULUdecompose();
                CI.AddToLog("ERROR: UBemField::SetGrid(). Computing EPSmatrix.\n");
                return U_ERROR;
            }
        }
    }
    if(FewRightHandSides==true) return U_OK;

/* LU object is not required anymore */
    LU = ULUdecompose();
    return U_OK;
}

UMatrix UBemField::GetRfield(const UDipole *Dipole, DerivType deriv) const
/*
    Return a new allocated array, containing the magnetic field on the
    Reference grid (set by SetGrid()) caused by a dipole *Dipole, embedded
    in a volume conductor described in *this::UConductor3
 */
{
    if(Dipole==NULL) 
    {
        CI.AddToLog("ERROR: UBemField::GetRfield(). NULL argument.\n");
        return UMatrix(U_ERROR);
    }
    if(GridREF==NULL || RFSmatrix.IsEmpty() || GridREF->GetNpoints()!=RFSmatrix.GetNrow()) 
    {
        CI.AddToLog("ERROR: UBemField::GetRfield(). Reference grid or RFSmatrix not properly set.\n");
        return UMatrix(U_ERROR);
    }
    if(UBemMatrix3::GetMonoLayer()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetRfield(). Magnetic field computations can not (yet) be combined with the BEM monolayer approach.\n");
        return UMatrix(U_ERROR);
    }

    int Ncomp = GetNcomp(deriv, Dipole->GetDipoleType());
    int nREF  = GridREF->GetNpoints();

    UMatrix       Field(DNULL, nREF, Ncomp);
    UMatrix       Psi = UBemMatrix3::GetBvec(*Dipole, deriv, -1.);

    if(Field.GetError()!=U_OK || Field.IsEmpty()==true || Psi.GetError()!=U_OK || Psi.IsEmpty()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetRfield(). Memory allocation.\n");
        return UMatrix(U_ERROR);
    }

/* Compoute the infinite medium magnetic field*/
    UVector3   xd   = Dipole->Getx();
    UVector3   dd   = Dipole->Getd();
    UDipole DipoleC = UDipole(xd, dd, UDipole::Current);

    double* fld = Field.Data;
    for(int ii=0; ii<nREF;ii++) 
        ComputeBo(DipoleC, GridREF->GetSensor(ii), deriv, fld+ii*Ncomp); 

/* Add symmetric counter parts*/
    if(Dipole->GetDipoleType()==UDipole::Symmetric)
    {
        UVector3   xd   = Dipole->Getx(); xd.MirrorY();
        UVector3   dd   = Dipole->Getd(); dd.MirrorY();      
        UDipole DipoleM = UDipole(xd, dd, UDipole::Current);
        double fldM[9];

        for(int ii=0; ii<nREF;ii++) 
        {
            ComputeBo(DipoleC, GridREF->GetSensor(ii), deriv, fld+ii*Ncomp); 
            ComputeBo(DipoleM, GridREF->GetSensor(ii), deriv, fldM); 

            switch(deriv)
            {
            case D_OriPos00:
                fld[  ii  ] += fldM[0];
                break;

            case D_OriPos10:
            case D_OriPos01:
                fld[3*ii  ] += fldM[0];
                fld[3*ii+1] -= fldM[1];
                fld[3*ii+2] += fldM[2];
                break;

            case D_OriPos11:
                fld[9*ii  ] += fldM[0];
                fld[9*ii+1] -= fldM[1];
                fld[9*ii+2] += fldM[2];
                fld[9*ii+3] -= fldM[3];
                fld[9*ii+4] += fldM[4];
                fld[9*ii+5] -= fldM[5];
                fld[9*ii+6] += fldM[6];
                fld[9*ii+7] -= fldM[7];
                fld[9*ii+8] += fldM[8];
                break;
            default:
                CI.AddToLog("ERROR: UBemField::GetRfield(). Combination not implemented: Dtype = %d, deriv = %d .\n",Dipole->GetDipoleType(), deriv);
                return UMatrix(U_ERROR);
            }
        }
    }
    if(Dipole->GetDipoleType()==UDipole::SymmetricPos)
    {
        UVector3     xd = Dipole->Getx();    xd.MirrorY();
        UVector3     dd = Dipole->GetdSym();        
        UDipole DipoleM = UDipole(xd, dd, UDipole::Current);
        double fldM[9];

        for(int ii=0; ii<nREF;ii++) 
        {
            ComputeBo(DipoleC, GridREF->GetSensor(ii), deriv, fld+ii*Ncomp); 
            ComputeBo(DipoleM, GridREF->GetSensor(ii), deriv, fldM); 

            switch(deriv)
            {
            case D_OriPos00:
                fld[  ii  ] += fldM[0];
                break;

            case D_OriPos10:
                fld[6*ii+3] = fldM[0];
                fld[6*ii+4] = fldM[1];
                fld[6*ii+5] = fldM[2];
                break;

            case D_OriPos01:
                fld[3*ii  ] += fldM[0];
                fld[3*ii+1] -= fldM[1];
                fld[3*ii+2] += fldM[2];
                break;

            case D_OriPos11:
                fld[18*ii+ 9] = fldM[0];
                fld[18*ii+10] =-fldM[1];
                fld[18*ii+11] = fldM[2];
                fld[18*ii+12] = fldM[3];
                fld[18*ii+13] =-fldM[4];
                fld[18*ii+14] = fldM[5];
                fld[18*ii+15] = fldM[6];
                fld[18*ii+16] =-fldM[7];
                fld[18*ii+17] = fldM[8];
                break;

            default:
                CI.AddToLog("ERROR: UBemField::GetRfield(). Combination not implemented: Dtype = %d, deriv = %d .\n",Dipole->GetDipoleType(), deriv);
                return UMatrix(U_ERROR);
            }
        }
    }

/* Add the transformed potential.*/
    Field += RFSmatrix * Psi;
    
    return Field;
}

UMatrix UBemField::GetBfield(const UDipole *Dipole, DerivType deriv) const
/*
    Return a new allocated array, containing the magnetic field on the
    MEG grid (set by SetGrid()) caused by a dipole *Dipole, embedded
    in a volume conductor described in *this::UConductor3
 */
{
    if(Dipole==NULL) 
    {
        CI.AddToLog("ERROR: UBemField::GetBfield(). NULL argument.\n");
        return UMatrix(U_ERROR);
    }
    if(GridMEG==NULL || BFSmatrix.IsEmpty() || GridMEG->GetNpoints()!=BFSmatrix.GetNrow()) 
    {
        CI.AddToLog("ERROR: UBemField::GetBfield(). Reference grid or BFSmatrix not properly set.\n");
        return UMatrix(U_ERROR);
    }
    if(UBemMatrix3::GetMonoLayer()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetBfield(). Magnetic field computations can not (yet) be combined with the BEM monolayer approach.\n");
        return UMatrix(U_ERROR);
    }

    int Ncomp = GetNcomp(deriv, Dipole->GetDipoleType());
    int nMEG  = GridMEG->GetNpoints();

    UMatrix       Field(nMEG, Ncomp);
    UMatrix       Psi = UBemMatrix3::GetBvec(*Dipole, deriv, -1.);

    if(Field.GetError()!=U_OK || Field.IsEmpty()==true || Psi.GetError()!=U_OK || Psi.IsEmpty()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetBfield(). Memory allocation.\n");
        return UMatrix(U_ERROR);
    }

/* Compoute the infinite medium magnetic field*/
    UVector3   xd   = Dipole->Getx();
    UVector3   dd   = Dipole->Getd();
    UDipole DipoleC = UDipole(xd, dd, UDipole::Current);

    double* fld = Field.Data;
    for(int ii=0; ii<nMEG;ii++) 
        ComputeBo(DipoleC, GridMEG->GetSensor(ii), deriv, fld+ii*Ncomp); 

/* Add symmetric counter parts*/
    if(Dipole->GetDipoleType()==UDipole::Symmetric)
    {
        UVector3   xd   = Dipole->Getx(); xd.MirrorY();
        UVector3   dd   = Dipole->Getd(); dd.MirrorY();      
        UDipole DipoleM = UDipole(xd, dd, UDipole::Current);
        double fldM[9];

        for(int ii=0; ii<nMEG;ii++) 
        {
            ComputeBo(DipoleC, GridMEG->GetSensor(ii), deriv, fld+ii*Ncomp); 
            ComputeBo(DipoleM, GridMEG->GetSensor(ii), deriv, fldM); 

            switch(deriv)
            {
            case D_OriPos00:
                fld[  ii  ] += fldM[0];
                break;

            case D_OriPos10:
            case D_OriPos01:
                fld[3*ii  ] += fldM[0];
                fld[3*ii+1] -= fldM[1];
                fld[3*ii+2] += fldM[2];
                break;

            case D_OriPos11:
                fld[9*ii  ] += fldM[0];
                fld[9*ii+1] -= fldM[1];
                fld[9*ii+2] += fldM[2];
                fld[9*ii+3] -= fldM[3];
                fld[9*ii+4] += fldM[4];
                fld[9*ii+5] -= fldM[5];
                fld[9*ii+6] += fldM[6];
                fld[9*ii+7] -= fldM[7];
                fld[9*ii+8] += fldM[8];
                break;
            default:
                CI.AddToLog("ERROR: UBemField::GetBfield(). Combination not implemented: Dtype = %d, deriv = %d .\n",Dipole->GetDipoleType(), deriv);
                return UMatrix(U_ERROR);
            }
        }
    }
    if(Dipole->GetDipoleType()==UDipole::SymmetricPos)
    {
        UVector3     xd = Dipole->Getx();    xd.MirrorY();
        UVector3     dd = Dipole->GetdSym();        
        UDipole DipoleM = UDipole(xd, dd, UDipole::Current);
        double fldM[9];

        for(int ii=0; ii<nMEG;ii++) 
        {
            ComputeBo(DipoleC, GridMEG->GetSensor(ii), deriv, fld+ii*Ncomp); 
            ComputeBo(DipoleM, GridMEG->GetSensor(ii), deriv, fldM); 

            switch(deriv)
            {
            case D_OriPos00:
                fld[  ii  ] += fldM[0];
                break;

            case D_OriPos10:
                fld[6*ii+3] = fldM[0];
                fld[6*ii+4] = fldM[1];
                fld[6*ii+5] = fldM[2];
                break;

            case D_OriPos01:
                fld[3*ii  ] += fldM[0];
                fld[3*ii+1] -= fldM[1];
                fld[3*ii+2] += fldM[2];
                break;

            case D_OriPos11:
                fld[18*ii+ 9] = fldM[0];
                fld[18*ii+10] =-fldM[1];
                fld[18*ii+11] = fldM[2];
                fld[18*ii+12] = fldM[3];
                fld[18*ii+13] =-fldM[4];
                fld[18*ii+14] = fldM[5];
                fld[18*ii+15] = fldM[6];
                fld[18*ii+16] =-fldM[7];
                fld[18*ii+17] = fldM[8];
                break;

            default:
                CI.AddToLog("ERROR: UBemField::GetBfield(). Combination not implemented: Dtype = %d, deriv = %d .\n",Dipole->GetDipoleType(), deriv);
                return UMatrix(U_ERROR);
            }
        }
    }

/* Add the transformed potential.*/
    Field += BFSmatrix * Psi;
    
    return Field;
}

UMatrix UBemField::GetPotentialEIT(double Current)
/*
    Return an UMatrix containing the electric potential on the
    EEG grid (set by SetGrid()) caused a unipolar current at the z-axis.
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(GridEEG==NULL || LU.IsEmpty() || LU.GetError()!=U_OK || IndexTri==NULL || IndexPot==NULL || IndexLin==NULL || Tweight.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). GridEEG and/or LU and/or IndexTri/Tweight not set.\n");
        return UMatrix(U_ERROR);
    }
    int nEEG = GridEEG->GetNpoints();
    if(nEEG <= 3)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Electrode grid has too few points (%d).\n", nEEG);
        return UMatrix(U_ERROR);
    }
    if(UBemMatrix3::GetMonoLayer() == true && GAMmatrix.IsEmpty()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Gamma matrix not set.\n");
        return UMatrix(U_ERROR);
    }
    UVector3 Ez    = GridEEG->GetSensorClosestToAxis(2, true)->Getx();
    UMatrix  Psi   = UBemMatrix3::GetBvec(Current, Ez);
    if(Psi.GetError()!= U_OK || Psi.IsEmpty())
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Memory allocation or setting right hand side.\n");
        return UMatrix(U_ERROR);
    }

    ErrorType E = U_OK;
    if(OptimizeManySigma)
    {
        if(UBemMatrix3::GetMonoLayer()==true)
        {
            if(E==U_OK) E = WoodBuryUpdate(&Psi);
            if(E==U_OK) E = LU.ComputeAxIsB(&Psi, true);
        }
        else
        {
            if(E==U_OK) E = LU.ComputeAxIsB(&Psi, false);
            if(E==U_OK) E = WoodBuryUpdate(&Psi);
        }
    }
    else
    {
        E = LU.ComputeAxIsB(&Psi, UBemMatrix3::GetMonoLayer());
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Solving system or applying WoodBury formula.\n");
        return UMatrix(U_ERROR);
    }

    UMatrix  Field;
    switch (GetPotInterPol())
    {
    case U_POTINTER_CONSTANT:   /* Compute the corresponding row from AmatInverse*/
        if(UBemMatrix3::GetMonoLayer())  Field = GAMmatrix * Psi;
        else                             Field = Psi.GetRowSelection(IndexPot, nEEG);
        break;

    case U_POTINTER_LINEAR:
        if(UBemMatrix3::GetMonoLayer())  Field = GetWeightedField(GAMmatrix * Psi);
        else                             Field = GetWeightedField(Psi.GetRowSelection(IndexLin, 3 * nEEG));
        break;
    }

    int isz = 0;
    GridEEG->GetSensorClosestToAxis(2, false, &isz);
    Field  -= Field[isz];

    return Field;
}


UMatrix UBemField::GetPotentialEIT(double Current, int el1, int el2, int elref) 
/*
    Return an UMatrix containing the electric potential on the
    EEG grid (set by SetGrid()) caused a current Current, injected and
    extracted to/from electrodes el1, el2.    

    If the index elref is inside the range (0, nEEG-1) compute the potential w.r.t. the electrode elref
    Else                                               use average reference (skip injection electrodes oin reference)
    Set potential at injection electrodes equal to 0.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(GridEEG==NULL || LU.IsEmpty() || LU.GetError()!=U_OK || IndexTri==NULL || IndexPot==NULL || IndexLin==NULL || Tweight.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). GridEEG and/or LU and/or IndexTri/Tweight not set.\n");
        return UMatrix(U_ERROR);
    }
    int nEEG  = GridEEG->GetNpoints();
    if(nEEG<=3)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Electrode grid has too few points (%d).\n", nEEG);
        return UMatrix(U_ERROR);
    }
    if(el1<0 || el1>=nEEG ||
       el2<0 || el2>=nEEG)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Electrode indices out of range (%d,%d).\n",el1,el2);
        return UMatrix(U_ERROR);
    }
    if(el1==el2 || el1==elref || el2==elref)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Electrodes overlap (el1, el2, elref) = (%d, %d, %d).\n", el1, el2, elref);
        return UMatrix(U_ERROR);
    }
    if(UBemMatrix3::GetMonoLayer()==true && GAMmatrix.IsEmpty()==true)
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Gamma matrix not set.\n");
        return UMatrix(U_ERROR);
    }

    UMatrix  Psi = UBemMatrix3::GetBvec(Current, GridEEG->GetPosition(el1), GridEEG->GetPosition(el2));
    if(Psi.GetError()!=U_OK || Psi.IsEmpty())
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Memory allocation or setting right had side.\n");
        return UMatrix(U_ERROR);
    }

    ErrorType E = U_OK;
    if(OptimizeManySigma)
    {
        if(UBemMatrix3::GetMonoLayer()==true)
        {
            if(E==U_OK) E = WoodBuryUpdate(&Psi);
            if(E==U_OK) E = LU.ComputeAxIsB(&Psi, true);
        }
        else
        {
            if(E==U_OK) E = LU.ComputeAxIsB(&Psi, false);
            if(E==U_OK) E = WoodBuryUpdate(&Psi);
        }
    }
    else
    {
        E = LU.ComputeAxIsB(&Psi, UBemMatrix3::GetMonoLayer());
    }
    if(E!=U_OK) 
    {
        CI.AddToLog("ERROR: UBemField::GetPotentialEIT(). Solving system or applying WoodBury formula.\n");
        return UMatrix(U_ERROR);
    }        

    UMatrix  Field;
    switch(GetPotInterPol())
    {
    case U_POTINTER_CONSTANT:   /* Compute the corresponding row from AmatInverse*/        
        if(UBemMatrix3::GetMonoLayer())  Field = GAMmatrix * Psi;
        else                             Field = Psi.GetRowSelection(IndexPot, nEEG);
        break;

    case U_POTINTER_LINEAR:
        if(UBemMatrix3::GetMonoLayer())  Field = GetWeightedField( GAMmatrix * Psi);
        else                             Field = GetWeightedField(Psi.GetRowSelection(IndexLin, 3*nEEG));
        break;
    }    

/*  Compute the potential w.r.t. reference */
    if(elref<0 || nEEG<=elref)  Field.DeMeanCols(el1, el2);
    else                        Field -= Field[elref];
    Field.SetElement(el1, 0, 0.);
    Field.SetElement(el2, 0, 0.);
    return Field;
}

UMatrix UBemField::GetPotential(const UDipole* Dipole, DerivType der) 
/*
    Return a new allocated array, containing the electric potential on the
    EEG grid (set by SetGrid()) caused by a dipole *Dipole, embedded
    in a volume conductor described in *this::UConductor3
 */
{
    if(GridEEG==NULL || (EPSmatrix.IsEmpty() && LU.IsEmpty())) 
    {
        CI.AddToLog("ERROR: UBemField::GetPotential. GridEEG and/or EPSmatrix and/or LU not set.\n");
        return UMatrix(U_ERROR);
    }
    if(Dipole==NULL) 
    {
        CI.AddToLog("ERROR: UBemField::GetPotential(). NULL argument. \n");
        return UMatrix(U_ERROR);
    }

    double DipCond = -1.;
    if(UBemMatrix3::GetMonoLayer())
    {
        if(NOT(EPSmatrix.IsEmpty()))
        {
            CI.AddToLog("ERROR: UBemField::GetPotential(). Using monolayer approach is not (yet) compatible with ��many RHS�� optimization on.\n");
            return UMatrix(U_ERROR);
        }
        if(OptimizeManySigma)
        {
            CI.AddToLog("ERROR: UBemField::GetPotential(). Using monolayer approach is not (yet) compatible with Sherman Morrison update formula.\n");
            return UMatrix(U_ERROR);
        }
        if(GAMmatrix.IsEmpty()==true)
        {
            CI.AddToLog("ERROR: UBemField::GetPotential(). Gamma matrix not set.\n");
            return UMatrix(U_ERROR);
        }
        DipCond = UConductor3::GetConductivity(Dipole->Getx());
    }

    int     Ncomp = GetNcomp(der, Dipole->GetDipoleType());
    int     nEEG  = GridEEG->GetNpoints();
    UMatrix Field;
    if(NOT(EPSmatrix.IsEmpty())) // many right hand sides
    {
        UMatrix Psi   = UBemMatrix3::GetBvec(*Dipole, der, DipCond);
        Field         = EPSmatrix*Psi;
    }
    else // a few right hand sides
    {
        if(LU.IsEmpty() || IndexTri==NULL || Tweight.GetError()!=U_OK || Tweight.IsEmpty())
        {
            CI.AddToLog("ERROR: UBemField::GetPotential(). LU decomposition not set, or IndexTri / Tweight not set.\n");
            return UMatrix(U_ERROR);
        }
        UMatrix  Psi = UBemMatrix3::GetBvec(*Dipole, der, DipCond);

        ErrorType E = U_OK;
        if(OptimizeManySigma)
        {
            if(UBemMatrix3::GetMonoLayer()==true)
            {
                if(E==U_OK) E = WoodBuryUpdate(&Psi);
                if(E==U_OK) E = LU.ComputeAxIsB(&Psi, true);
            }
            else
            {
                if(E==U_OK) E = LU.ComputeAxIsB(&Psi, false);
                if(E==U_OK) E = WoodBuryUpdate(&Psi);
            }
        }
        else
        {
            E = LU.ComputeAxIsB(&Psi, UBemMatrix3::GetMonoLayer());
        }
        if(E!=U_OK) 
        {
            CI.AddToLog("ERROR: UBemField::GetPotential(). Solving system or applying WoodBury formula.\n");
            return UMatrix(U_ERROR);
        }        

        switch(GetPotInterPol())
        {
        case U_POTINTER_CONSTANT:   /* Compute the corresponding row from AmatInverse*/        
            if(UBemMatrix3::GetMonoLayer())         Field = GAMmatrix*Psi;
            else                                    Field = Psi.GetRowSelection(IndexPot, nEEG);
            break;

        case U_POTINTER_LINEAR:
            UMatrix PsiSel = Psi.GetRowSelection(IndexLin, 3*nEEG);
            for(int n=0; n<Ncomp; n++)
                Field.MergeCols(GetWeightedField(PsiSel.GetCollumn(n)));
            break;
        }
    }
/*  Compute the average reference */
    Field.DeMeanCols();
    return Field;
}

ErrorType UBemField::ComputeBo(const UDipole& Dipole, const USensor& S, DerivType der, double* Field) const
/*
    Compute the magnetic field on sensor *Sens, caused by a current dipole
    *Dipole, embedded in an infinite medium of uniform conductivity.
    The computed field components are stored in Field[].
    This function only works with single current dipoles (UDipole::Current). Other
    dipole types should be handled by the calling function.
 */
{
    if(Dipole.GetDipoleType()!=UDipole::Current)
    {
        CI.AddToLog("ERROR: UBemField::ComputeBo(). Invalid Dipole argument. \n");
        return U_ERROR;
    }
    int ncoil = 1;
    if(S.GetStype()==USensor::U_SEN_GRAD) ncoil = 2;

    int Ncomp = GetNcomp(der, UDipole::Current);
    for(int k=0; k<Ncomp; k++) Field[k] = 0;

    for(int icoil=0; icoil<ncoil; icoil++)
    {
        UVector3 m = Dipole.Getd();
        UVector3 x = S.Getx()-Dipole.Getx();
        UVector3 n = S.Getn();
        if(icoil==1)
        {
            x =  S.Getc()-Dipole.Getx();
            n = -S.Getn();
        }
        double   r    = x.GetNorm();
        double   fact = 1./(r*r*r);
        
        switch(der)
        {
        case D_OriPos00: 
            Field[0]  +=  ( m & (x^n) )*fact;
            break;

        case D_OriPos10:                        // Tested against D_OriPos00 14-06-99
            {
                UVector3 xn  =  x^n;
                Field[0]    +=  xn.Getx()*fact;
                Field[1]    +=  xn.Gety()*fact;
                Field[2]    +=  xn.Getz()*fact;
            }
            break;
        
        case D_OriPos01:                         // Tested against D_OriPos00 13-08-99
            {
                UVector3 nm  =  m^n;
                Field[0]    +=  nm.Getx()*fact;
                Field[1]    +=  nm.Gety()*fact;
                Field[2]    +=  nm.Getz()*fact;
                fact        *= -3*(x&nm)/(r*r);
                Field[0]    +=   x.Getx()*fact;
                Field[1]    +=   x.Gety()*fact;
                Field[2]    +=   x.Getz()*fact;
            }
            break;

        case D_OriPos11:                         // Tested 21-09-2001
            {                
                Field[1]    -= n.Getz()*fact;
                Field[2]    += n.Gety()*fact;
                Field[3]    += n.Getz()*fact;
                Field[5]    -= n.Getx()*fact;
                Field[6]    -= n.Gety()*fact;
                Field[7]    += n.Getx()*fact;

                UVector3 nx  =  (n^x) *(-3*fact/(r*r));
                Field[0]    +=   x.Getx()*nx.Getx();
                Field[1]    +=   x.Gety()*nx.Getx();
                Field[2]    +=   x.Getz()*nx.Getx();
                Field[3]    +=   x.Getx()*nx.Gety();
                Field[4]    +=   x.Gety()*nx.Gety();
                Field[5]    +=   x.Getz()*nx.Gety();
                Field[6]    +=   x.Getx()*nx.Getz();
                Field[7]    +=   x.Gety()*nx.Getz();
                Field[8]    +=   x.Getz()*nx.Getz();
            }
            break;

        case D_OriPos02: // Not yet implemented
        case D_OriPos20: // Results identically zero
            break;
        }
    }
    return U_OK;
}

ErrorType UBemField::ComputeRFSmatrix(void)
{
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::ComputeRFSmatrix(). MEG Grid not properly set. \n");
        return U_ERROR;
    }
    return ComputeBRFSmatrix(true);
}
ErrorType UBemField::ComputeBFSmatrix(void)
{
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::ComputeBFSmatrix(). MEG Grid not properly set. \n");
        return U_ERROR;
    }
    return ComputeBRFSmatrix(false);
}
ErrorType UBemField::ComputeBRFSmatrix(bool MEGREF)
{
    UGrid    GMgr = MEGREF ? *GridREF  : *GridMEG; 
    UMatrix& GMat = MEGREF ? RFSmatrix : BFSmatrix;

    if(GMgr.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::ComputeBRFSmatrix(). REF/MEG Grid not properly set or copied. \n");
        return U_ERROR;
    }

    int Nsen  = GMgr.GetNpoints();
    int Npot  = GetNpot();

    GMat = UMatrix(DNULL, Nsen, Npot);
    if(GMat.GetError()!=U_OK || GMat.IsEmpty()) 
    {
        GMat = UMatrix();
        CI.AddToLog("ERROR: UBemField::ComputeBFSmatrix(). Creating empty matrix.\n");
        return U_ERROR;
    }

    UBEMIntegral BI;
    int Nsurfaces = GetNsurfaces();

    switch(GetPotInterPol())
    {
    case U_POTINTER_CONSTANT:
/* On each triangle, one integral has to be computed */
        
        for(int j2=0;j2<Nsurfaces;j2++)                 /* Loop over all triangles */
        {
            const UNestedSurface*   g2 = GetNestedSurface(j2);
            const UVector3*         p2 = g2->GetPoints();
            const int*        TriList2 = g2->GetTriList(); 
            double               delta = g2->GetOuterCond() - g2->GetInnerCond();
            for(int n=0,n3=0;n<GetNestedSurface(j2)->GetNtri();n++,n3+=3)
            {
                int i0 = TriList2[n3  ];
                int i1 = TriList2[n3+1];
                int i2 = TriList2[n3+2];

                for(int j1=0;j1<Nsen;j1++)         /*Loop over all gradiometers */
                {                
                    USensor S = GMgr.GetSensor(j1);
                    int ncoil = (S.GetStype()==USensor::U_SEN_GRAD) ? 2 : 1;
    
                    for(int icoil=0; icoil<ncoil; icoil++)
                    {
                        UVector3 yview = icoil==0 ? S.Getn() : -S.Getn();
                        UVector3 yori  = icoil==0 ? S.Getx() :  S.Getc();
                        UVector3 y0    = p2[i0] - yview;
                        UVector3 y1    = p2[i1] - yview;
                        UVector3 y2    = p2[i2] - yview;

                        GMat.Data[j1*Npot + joffset[j2]+n] += delta* (yori&BI.ComputeBconst(y0, y1, y2));
                    }
                }
            }
        }            
        break;

    case U_POTINTER_LINEAR:
/* On each triangle, three integrals have to be computed */
        for(int j2=0;j2<Nsurfaces;j2++)                 /* Loop over all triangles */
        {
            const UNestedSurface*  g2 = GetNestedSurface(j2);
            const UVector3*        p2 = g2->GetPoints();
            const int*       TriList2 = g2->GetTriList(); 
            double              delta = g2->GetOuterCond() - g2->GetInnerCond();
            for(int n=0,n3=0;n<GetNestedSurface(j2)->GetNtri();n++,n3+=3)
            {
                int i0 = TriList2[n3  ];
                int i1 = TriList2[n3+1];
                int i2 = TriList2[n3+2];

                for(int j1=0;j1<Nsen;j1++)         /*Loop over all gradiometers */
                {                
                    USensor S = GMgr.GetSensor(j1);
                    int ncoil = (S.GetStype()==USensor::U_SEN_GRAD) ? 2 : 1;
    
                    for(int icoil=0; icoil<ncoil; icoil++)
                    {
                        UVector3 yview = icoil==0 ? S.Getn() : -S.Getn();
                        UVector3 yori  = icoil==0 ? S.Getx() :  S.Getc();

/* subtract view point yview from all three triangle corners. */                           
                        UVector3 Om0, Om1, Om2;
                        UVector3 y0    = p2[i0] - yview;
                        UVector3 y1    = p2[i1] - yview;
                        UVector3 y2    = p2[i2] - yview;
                        BI.ComputeBlinear(y0,y1,y2,&Om0,&Om1,&Om2);

                        GMat.Data[j1*Npot + joffset[j2]+i0] += delta*(yori&Om0);
                        GMat.Data[j1*Npot + joffset[j2]+i1] += delta*(yori&Om1);
                        GMat.Data[j1*Npot + joffset[j2]+i2] += delta*(yori&Om2);
                    }
                }
            }
        }
        break;
    }

    for(int i=0; i<Nsen; i++)  LU.ComputeATxIsB(GMat.Data+i*Npot);

    return U_OK;
}
ErrorType UBemField::ComputeEPSmatrix(void)
{
    if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::ComputeEPSmatrix(). EEG-Grid not properly set. \n");
        return U_ERROR;
    }

    int nEEG = GridEEG->GetNpoints();
    int Npot = GetNpot();

    EPSmatrix    = UMatrix(DNULL, nEEG, Npot);
    UMatrix  Psi = UMatrix(DNULL, Npot, 1);
    if(EPSmatrix.GetError()!=U_OK || EPSmatrix.IsEmpty() || Psi.GetError()!=U_OK || Psi.IsEmpty()) 
    {
        EPSmatrix = UMatrix();
        CI.AddToLog("ERROR: UBemField::ComputeEPSmatrix(). Memory allocation.\n");
        return U_ERROR;
    }

    switch(GetPotInterPol())
    {
    case U_POTINTER_CONSTANT:
/* Compute the corresponding row from AmatInverse*/        
        for(int k=0; k<Npot; k++)
        {
            Psi.SetData(0.);
            Psi.SetElement(k, 0, 1.);
            LU.ComputeAxIsB(&Psi, false);
            EPSmatrix.SetData(0, k, Psi.GetRowSelection(IndexPot, nEEG));
        }    
        break;

    case U_POTINTER_LINEAR:
        for(int k=0; k<Npot; k++)
        {
            Psi.SetData(0.);
            Psi.SetElement(k, 0, 1.);
            LU.ComputeAxIsB(&Psi, false);
            EPSmatrix.SetData(0, k, GetWeightedField(Psi.GetRowSelection(IndexLin, 3*nEEG)));
        }
        break;
    }
    return U_OK;
}

ErrorType UBemField::UpdateEEGindices(void)
{
    if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemField::UpdateEEGindices(). EEG grid not (properly) set.\n");
        return U_ERROR;
    }
    int   sout                 = GetOuterSurf();
    const UNestedSurface* Sout = GetNestedSurface(sout);
    if(Sout==NULL || Sout->GetError()!=U_OK || Sout->GetTriList()==NULL)
    {
        CI.AddToLog("ERROR: UBemField::UpdateEEGindices(). Getting outer surface (NULL or erroneous).\n");
        return U_ERROR;
    }
    const int* TriList = Sout->GetTriList();
    int        nEEG    = GridEEG->GetNpoints();

    delete[] IndexTri; IndexTri = new int[  nEEG];
    delete[] IndexPot; IndexPot = new int[  nEEG];
    delete[] IndexLin; IndexLin = new int[3*nEEG];
    Tweight = UMatrix(DNULL, nEEG, 3);
    if(IndexTri==NULL || IndexPot==NULL || IndexLin==NULL || Tweight.GetError()!=U_OK || Tweight.Data==NULL) 
    {
        delete[] IndexTri;    IndexTri  = NULL;
        delete[] IndexPot;    IndexPot  = NULL;
        delete[] IndexLin;    IndexLin  = NULL;
        CI.AddToLog("ERROR: UBemField::UpdateEEGindices(). Memory allocation, nEEG = %d.\n", nEEG);
        return U_ERROR;        
    }

/* For each sensor, compute the closesed surface triangle index  IndexTri and weights. */
    double         ElcDistAver = 0;
    double         ElcDistMax  = 0;
    int            imax        = 0;
    for(int i=0; i<nEEG; i++)
    {
        UVector3  Xel   = GridEEG->GetPosition(i);

        double testDist = -1;
        IndexTri[i]       = Sout->GetClosestTriangleStand(Xel, &testDist, false);
        IndexPot[i]       = joffset[sout] + IndexTri[i];
        IndexLin[3*i  ]   = joffset[sout] + TriList[3*IndexTri[i]  ];
        IndexLin[3*i+1]   = joffset[sout] + TriList[3*IndexTri[i]+1];
        IndexLin[3*i+2]   = joffset[sout] + TriList[3*IndexTri[i]+2];

        if(testDist>=0)                  ElcDistAver += testDist;
        if(testDist>ElcDistMax) {imax = i; ElcDistMax = testDist;}
        UBEMIntegral BI;

        const UVector3 *y0 = NULL;
        const UVector3 *y1 = NULL;
        const UVector3 *y2 = NULL;

        Sout->GetTriangle(IndexTri[i], &y0, &y1, &y2);
        BI.Project(Xel, y0, y1, y2, Tweight.Data+3*i, Tweight.Data+3*i+1, Tweight.Data+3*i+2);
    }
    ElcDistAver /= nEEG;

    if(ElcDistAver>1.) CI.AddToLog("WARNING: UBemField::UpdateEEGindices(). Average Distance of electrodes to outersurface %f \n",ElcDistAver);
    if(ElcDistMax >1.) CI.AddToLog("WARNING: UBemField::UpdateEEGindices(). Max Distance of electrode to outersurface %f  (%s).\n",ElcDistMax, GridEEG->GetName(imax));

    return U_OK;
}

UMatrix UBemField::GetWeightedField(UMatrix PsiSel) const
{
    UMatrix Field(DNULL, PsiSel.Nrow/3, 1);

    double* pF = Field  .Data;
    double* pW = Tweight.Data;
    double* pP = PsiSel .Data;

    for(int i=0; i<Field.Nrow; i++, pW+=3, pP+=3) *pF++ = pW[0]*pP[0] + pW[1]*pP[1] + pW[2]*pP[2];

    return Field;
}

/////
////        double NewSig[3] = {Sigma[0],Sigma[1],Sigma[2]};
////        UMatrix A (DNULL, Npot, Npot);     SetAmat(A .Data, true, NULL);
////        UMatrix A0(DNULL, Npot, Npot);     SetAmat(A0.Data, true, DefaultSigmas);
////
////        UMatrix Lin (1./(         -NewSig[0]), N0,  // Outer
////                     1./(NewSig[0]-NewSig[1]), N1, 
////                     1./(NewSig[1]-NewSig[2]), N2); // Inner
////        UMatrix L0in(1./(DefaultSigmas[0]-DefaultSigmas[3]), N0,  // Outer
////                     1./(DefaultSigmas[1]-DefaultSigmas[4]), N1, 
////                     1./(DefaultSigmas[2]-DefaultSigmas[5]), N2); // Inner
////        UMatrix Lam  = UMatrix(0.,N0,NewSig[0]       ,N1,NewSig[1]       ,N2); // to do Lin Smoo
////        UMatrix Lam0 = UMatrix(0.,N0,DefaultSigmas[3],N1,DefaultSigmas[4],N2); 
////        UMatrix NN (DNULL, Npot, Npot);
////        UMatrix NN0(DNULL, Npot, Npot);
////        if(GetPotInterPol()==U_POTINTER_LINEAR && GetSmoothElemA()==U_SMOOTH_SMOOTH)
////        {
////
////            NN.SetBlock( 0   , 0   ,GetSurface(0)->GetOverlapMatrix(true));
////            NN.SetBlock(N0   ,N0   ,GetSurface(1)->GetOverlapMatrix(true));
////            NN.SetBlock(N0+N1,N0+N1,GetSurface(2)->GetOverlapMatrix(true));
////            NN0 = NN;
////            NN  = UMatrix(0.5*(                 NewSig[0])       , N0,0.5*(       NewSig[0]+NewSig[1]       ), N1, 0.5*(       NewSig[1]+NewSig[2]       ), N2) * NN;
////            NN0 = UMatrix(0.5*(DefaultSigmas[0]+DefaultSigmas[3]), N0,0.5*(DefaultSigmas[1]+DefaultSigmas[4]), N1, 0.5*(DefaultSigmas[2]+DefaultSigmas[5]), N2) * NN0;
////        }
////
////        UMatrix EE(DNULL, Npot, Npot); EE.SetData(1./Npot);
////        UMatrix DD   = GetImprodHOne();
////        UMatrix M    = ((A  - EE)- (DD*Lam  + NN  ))*Lin ;
////        UMatrix M0   = ((A0 - EE)- (DD*Lam0 + NN0 ))*L0in;
////
////        for(int i=0,ij=0; i<M.Nrow; i++)
////            for(int j=0; j<M.Ncol; j++,ij++)
////            {
////                if(M[ij]==0. && M0[ij]==0.) continue;
////                if(fabs(M[ij]-M0[ij])<1.e-12) continue;
////                CI.AddToLog("%d %d %f %f\n", i,j, M[ij], M0[ij]);
////            }
////
////        double Mtest = GetFrobNormDifference(M, M0);
////        CI.AddToLog("Mtest = %f \n", Mtest);
/////////
