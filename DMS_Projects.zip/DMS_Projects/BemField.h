#ifndef _BEMFIELD_INCLUDED
#define _BEMFIELD_INCLUDED

#include "Grid.h"
#include "LUdecompose.h"
#include "BemMatrix3.h"
#include "Matrix.h"

/*
  Update history
  
  Who    When       What
  JdM    25-08-99   Remove a few obsolete functions
  GdV    26-08-99   Unix Compatibility: include files directories
JdM/SG   10-10-00   Added GetPotentialEIT() function for EIT
  JdM    17-08-01   Made desctructor virtual
  JdM    30-12-06   Adapted include file to new directory structure
*/

class DLL_IO UBemField : public UBemMatrix3
{
public:
    UBemField();
    UBemField(FILE* fpIn);
    UBemField(const UHeadModel* Hmod);
    UBemField(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer);
    UBemField(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer);
    UBemField(const UBemField &B);
    virtual ~UBemField();

    UBemField&             operator=(const UBemField &B);
    ErrorType              GetError() const {if(this) return error; return U_ERROR;}
   
    UMatrix                GetRfield(const UDipole *Dipole, DerivType der=D_OriPos00) const;
    UMatrix                GetBfield(const UDipole *Dipole, DerivType der=D_OriPos00) const;
    UMatrix                GetPotential(const UDipole *Dipole, DerivType der);
    UMatrix                GetPotentialEIT(double Current);
    UMatrix                GetPotentialEIT(double Current, int el1, int el2, int elref);
    ErrorType              SetSigma(const double *Sigma);

    ErrorType              ReplaceSurface(int iSurface, const USurface &S);
    ErrorType              ReplaceSurface(int iSurface, const UConductor3 &r);
    ErrorType              LocalRefine(double MaxDistance, UVector3* Pts, int Npts);

    const UGrid*           GetGridMEG(void) const {if(this) return GridMEG; return NULL;}
    const UGrid*           GetGridEEG(void) const {if(this) return GridEEG; return NULL;}
    const UGrid*           GetGridREF(void) const {if(this) return GridREF; return NULL;}

    ErrorType              ResetMatrices(void);
    static const char*     GetFileHeader(void) {return UBemMatrix3::GetFileHeader();}
    ErrorType              WriteBinary(FILE* fpOut) const;

protected:
    UGrid*                 GridREF;   // A copy of the Reference MEG grid
    UGrid*                 GridMEG;   // A copy of the MEG grid, on which the magnetic field are computed
    UGrid*                 GridEEG;   // A copy of the EEG grid, on which the electric potentials are computed

    ErrorType              SetGridREF(const UGrid* GrREF);
    ErrorType              SetGrid(const UGrid* GrMEG, const UGrid* GrEEG, bool FewRightHandSides, bool ManySigmas);

    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static const char*     HEADERBEGIN;
    static const char*     HEADEREND;

    ErrorType              error;     // General error flag
    UMatrix                RFSmatrix; // Matrix used to compute the reference magnetic fields from the potentials, Npot*GridREF->GetNpoints()
    UMatrix                BFSmatrix; // Matrix used to compute the magnetic fields from the potentials          , Npot*GridMEG->GetNpoints()
    UMatrix                EPSmatrix; // Matrix used to compute the electric potentials on GridEEG               , Npot*GridEEG->GetNpoints()
    UMatrix                GAMmatrix; // Matrix used in the monolayer approach
    ULUdecompose           LU;        // LU decomposed version of the system matrix                              , Npot
    UMatrix                Tweight;   // nEEG x 3 Matrix containing the weights to be applied in the linear potential interpolation
    int*                   IndexTri;  // List containing references to outer surface triangle, for each electrode
    int*                   IndexPot;  // List containing references to vector elements of the unknowns, for each electrode, for the pliecewise constant case
    int*                   IndexLin;  // List containing references to vector elements of the unknowns, for each electrode, for the pliecewise linear case
    
    bool                   OptimizeManySigma; // When true, all following matrices are filled and used (SetGrid() and WoodBuryUpdate())
    static const double    DefaultSigmas[6];
    UMatrix                Ymat;              // Array used in the WoodBury formula (fast sigma update)          , NPOT*BLU->GetN()
    ULUdecompose           BLU;               // LU decomposition of a matrix required in the Sherman Morrison formula (fast sigma update)
    ErrorType              WoodBuryUpdate(UMatrix* Psi) const;

    ErrorType              ComputeBRFSmatrix(bool MEGREF);
    ErrorType              ComputeRFSmatrix(void);
    ErrorType              ComputeBFSmatrix(void);
    ErrorType              ComputeEPSmatrix(void);

    ErrorType              ComputeBo(const UDipole& Dipole, const USensor& S, DerivType der, double* Field) const;
    ErrorType              UpdateEEGindices(void);
    UMatrix                GetWeightedField(UMatrix PsiSel) const;
};

#endif // _BEMFIELD_INCLUDED
