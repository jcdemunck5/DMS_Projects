/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for computing analytical integrals used in the 3D BEM.             */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    22-04-99   creation, derived from splitting Surface.cpp
  Jdm    05-05-99   BUG FIX ComputeGamma() use det i.s.o. fabs(det) (Error in formula)
  JdM    05-05-99   Tested ComputeBlinear(), against numerical integration.
  JdM    16-05-00   Added ComputeVolume()
  JdM    10-10-00   BUG FIX: ComputeDistance(). Test whether projected point is inside triangle
  JdM    30-10-00   BUG FIX: Project(). minus sign in computation of xp.
  JdM    01-11-00   Made severeral functions and poiters const
  JdM    26-09-01   Added another Project()
  JdM    27-09-01   Added LineThroughTriangle() and  HalfLineThroughTriangle()
  JdM    03-02-14   BUG FIX: ComputeDistance(). There was a sign error in the computation of the distance of x to the triangle edges 
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    13-10-14   Added (tested) GetGammaSing(). Used it in ComputeGamma()
  JdM    10-05-15   Added GetMinimumBoundingCircle()
  JdM    14-09-15   Added (and tested) ComputeLinearSolid(), ComputeLinearGamma() and GetLineIntegralR()
*/

#include "BemIntegral.h"

bool UBEMIntegral::IsAcuteTriangle(const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const
{
    if(y0==NULL || y1==NULL || y2==NULL) return false;
    
    double I00 = (*y0) & (*y0);
    double I01 = (*y0) & (*y1);
    double I02 = (*y0) & (*y2);
    double I11 = (*y1) & (*y1);
    double I12 = (*y1) & (*y2);
    double I22 = (*y2) & (*y2);

    if(I01+I12 >= I11+I02) return false;
    if(I12+I02 >= I22+I01) return false;
    if(I02+I01 >= I00+I12) return false;
    return true;
}


UVector3 UBEMIntegral::GetMinimumBoundingCircle(const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* Radius) const
{
    if(y0==NULL || y1==NULL || y2==NULL)
    {
        CI.AddToLog("ERROR: UBEMIntegral::GetMinimumBoundingCircle(). Invalid NULL pointer argument(s).\n");
        return UVector3();
    }
    UVector3    A = (*y1 - *y0);
    UVector3    B = (*y2 - *y0);
    UVector3   AB = A ^ B;
    
    double   NA2   = A.GetNorm2();
    double   NB2   = B.GetNorm2();
    double   NC2   = (*y1-*y2).GetNorm2();
    double   NAB2  = AB.GetNorm2();

    bool     Accu  = IsAcuteTriangle(y0, y1, y2);
    if(NAB2>0. && Accu)
    {
        UVector3  Cent = ((B*NA2 - A*NB2) ^ AB) / (2*NAB2) + *y0;
        double    Rad2 = (Cent-*y0).GetNorm2();
        if(Radius) *Radius = sqrt(Rad2);
        return Cent;
    }

    double   MaxL2 = MAX(MAX(NA2, NB2), NC2);
    if(NA2==MaxL2)
    {
        if(Radius) *Radius = sqrt(NA2) * 0.5;
        return (*y0+*y1)*0.5;
    }
    if(NB2==MaxL2)
    {
        if(Radius) *Radius = sqrt(NB2) * 0.5;
        return (*y2+*y0)*0.5;
    }
    if(Radius) *Radius = sqrt(NC2) * 0.5;
    return (*y1+*y2)*0.5;
}

double UBEMIntegral::ComputeDistance(UVector3 x, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const
/*
   Calculate the Distance between the point x and the triangle (*y0, *y1, *y2)
 */
{
    if(y0==NULL || y1==NULL || y2==NULL)
    {
        CI.AddToLog("ERROR: UBEMIntegral::ComputeDistance(). Invalid NULL pointer argument(s).\n");
        return -1.;
    }
    double   w0 = 0.;
    double   w1 = 0.;
    double   w2 = 0.;
    UVector3 xp = Project(x, y0, y1, y2, &w0, &w1, &w2);

    if(w0>=0. && w1>=0. && w2>=0.) return (xp-x).GetNorm(); // xp inside triangle

/* Test whether closest point lies on one of the edges */
    double mu0 = (*y1-x)&(*y1-*y2) / (*y1-*y2).GetNorm2();
    double mu1 = (*y2-x)&(*y2-*y0) / (*y2-*y0).GetNorm2();
    double mu2 = (*y0-x)&(*y0-*y1) / (*y0-*y1).GetNorm2();

    if(0.<=mu0 && mu0 <=1.) return (*y1-x + mu0*(*y2-*y1)).GetNorm();
    if(0.<=mu1 && mu1 <=1.) return (*y2-x + mu1*(*y0-*y2)).GetNorm();
    if(0.<=mu2 && mu2 <=1.) return (*y0-x + mu2*(*y1-*y0)).GetNorm();

/* Take the shortest distance to one of the corners*/
   double d0 = (*y0 - x).GetNorm();
   double d1 = (*y1 - x).GetNorm();
   double d2 = (*y2 - x).GetNorm();

   return MIN(d0,MIN(d1,d2));
}

double UBEMIntegral::LinInterpol(UVector3 x, double v0, double v1, double v2, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const
{
    double w0;
    double w1;
    double w2;
    Project(x, y0, y1, y2, &w0, &w1, &w2);

    return w0*v0 + w1*v1 + w2*v2;
}


UVector3 UBEMIntegral::Project(UVector3 x, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* w0, double* w1,double* w2) const
/*
     Project the vector x perpendicularly into the triangle (*y0, *y1, *y2) and compute
     the relative weights (*w0, *w1, *w2).
     Return the projected vector.
 */
{
    UVector3 n   = (*y1-*y0)^(*y2-*y0);
    double   lam = (x-*y0)&n/(n&n);
    UVector3 xp  =-lam*n + x;         // Projection of x into the triangular plane

/* Determine the location of xp w.r,t. trianle*/
    double det  = (*y0^*y1) & *y2;
    if(fabs(det)<1.e-20) det = 1;
    if(w0) *w0 = ( (*y1^*y2) &  xp )/det;
    if(w1) *w1 = ( (*y2^*y0) &  xp )/det;
    if(w2) *w2 = ( (*y0^*y1) &  xp )/det;

    return xp;
}

UVector3 UBEMIntegral::Project(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* w0, double* w1,double* w2) const
/*
     Project the vector x in the direction m into the triangle (*y0, *y1, *y2) and compute
     the relative weights (*w0, *w1, *w2).
     Return the projected vector.
 */
{
    UVector3 n   = (*y1-*y0)^(*y2-*y0);
    double   mn  = m&n;
    UVector3 xp  = x;
    if(fabs(mn)>1.e-10)
    {
        double  lam = ((x-*y0)&n)/mn;
        xp          =-lam*m + x;         // Projection of x into the triangular plane
    }

/* Determine the location of xp w.r,t. trianle*/
    double det  = (*y0^*y1) & *y2;
    if(fabs(det)<1.e-20) det = 1;
    if(w0) *w0 = ( (*y1^*y2) &  xp )/det;
    if(w1) *w1 = ( (*y2^*y0) &  xp )/det;
    if(w2) *w2 = ( (*y0^*y1) &  xp )/det;

    return xp;
}

bool UBEMIntegral::LineThroughTriangle(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const
/*
    Return true iff the line x + lamda *m passes through the triangle (*y0, *y1, *y2)
 */
{
    bool LEFT0 = true; if(GetDeterminant(*y1-x, *y2-x, m)>=0) LEFT0 = false;
    bool LEFT1 = true; if(GetDeterminant(*y2-x, *y0-x, m)>=0) LEFT1 = false;
    bool LEFT2 = true; if(GetDeterminant(*y0-x, *y1-x, m)>=0) LEFT2 = false;

    if(LEFT0==false && LEFT1==false && LEFT2==false) return true;
    if(LEFT0==true  && LEFT1==true  && LEFT2==true ) return true;
    return false;
}

bool UBEMIntegral::HalfLineThroughTriangle(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const
/*
    Return true iff the line x + lamda *m passes through the triangle (*y0, *y1, *y2)
    with lamda >= 0
 */
{
    bool LEFT0 = true; if(GetDeterminant(*y1-x, *y2-x, m)>=0) LEFT0 = false;
    bool LEFT1 = true; if(GetDeterminant(*y2-x, *y0-x, m)>=0) LEFT1 = false;
    bool LEFT2 = true; if(GetDeterminant(*y0-x, *y1-x, m)>=0) LEFT2 = false;

    double det = GetDeterminant(*y0-x, *y1-x, *y2-x);

    if(det>0 && LEFT0==false && LEFT1==false && LEFT2==false) return true;
    if(det<0 && LEFT0==true  && LEFT1==true  && LEFT2==true ) return true;
    return false;
}


double UBEMIntegral::ComputeArea(UVector3 y0, UVector3 y1, UVector3 y2) const
/*
    Calculates the area of triangle (y0, y1, y2)
 */
{
    return .5*((y0-y1)^(y1-y2)).GetNorm();
}

double UBEMIntegral::ComputeVolume(UVector3 y0, UVector3 y1, UVector3 y2, UVector3 y3) const
/*
    Returns the (signed) volume of tetraeder (y0, y1, y2, y3)
 */
{
    return GetDeterminant(y1-y0, y2-y0, y3-y0)/3.;
}

double UBEMIntegral::ComputeSolid(UVector3 y0, UVector3 y1, UVector3 y2) const
/*
    Calculates solid angle viewed from origin.
 */
{

    double det = (y0^y1)&y2;

    double r0  = y0.GetNorm();
    double r1  = y1.GetNorm();
    double r2  = y2.GetNorm();
    double a0  = y1&y2;
    double a1  = y2&y0;
    double a2  = y0&y1;

    return 2*atan2(det, r0*r1*r2 + r0*a0 + r1*a1 + r2*a2);
}

void UBEMIntegral::ComputeLinear(UVector3 y0, UVector3 y1, UVector3 y2, double *om0, double *om1, double *om2) const
/*
     Compute "the" three integrals over the triangle
     with corners y0, y1 and y2.
 */
{
    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double det  = z2&y2;
    double aaa2 = z.GetNorm2();

    double rr0 = y0.GetNorm2();
    double rr1 = y1.GetNorm2();
    double rr2 = y2.GetNorm2();

    double r0  = sqrt( rr0 );
    double r1  = sqrt( rr1 );
    double r2  = sqrt( rr2 );

    double r01 = (y0-y1).GetNorm();
    double r12 = (y1-y2).GetNorm();
    double r20 = (y2-y0).GetNorm();

    double a01 = y0&y1;
    double a12 = y1&y2;
    double a20 = y2&y0;

    double a0  = r20*r20;
    double a1  =-a12 + rr2 + a01 - a20;
    double a2  =-a12 + a01 + a20 - rr0;
    double a3  = rr1 - a12 - a01 + a20;

    double d0, d1;
    double g01,g12,g20;

    d0  = 1.+(rr1-a01)/(r01*r1);
    d1  = 1.+(a01-rr0)/(r01*r0);
    if(d1>.01)
        g01 = log( r1*d0 / (r0*d1) ) / r01;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g01 = log( r0*d1 / (r1*d0) ) / r01;
    }
    d0  = 1.+(rr2-a12)/(r12*r2);
    d1  = 1.+(a12-rr1)/(r12*r1);
    if(d1>.01)
        g12 = log( r2*d0 / (r1*d1) ) / r12;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g12 = log( r1*d1 / (r2*d0) ) / r12;
    }

    d0  = 1.+(rr0-a20)/(r20*r0);
    d1  = 1.+(a20-rr2)/(r20*r2);
    if(d1>.01)
        g20 = log( r0*d0 / (r2*d1) ) / r20;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g20 = log( r2*d1 / (r0*d0) ) / r20;
    }

    *om0 = det*( g20-g01 );
    *om1 = det*( g01-g12 );
    double ddd = r0*r1*r2 + r0*a12 + r1*a20 + r2*a01;
    double oom = 2*atan2(det,ddd);
    double h1  = z1&z;
    double h2  = z2&z;

    *om2 = ( a2* *om0 + a3* *om1 + oom*h2)/aaa2;
    *om1 = ( a0* *om0 + a1* *om1 + oom*h1)/aaa2;
    *om0 = oom - *om1 -*om2;
}

ErrorType UBEMIntegral::ComputeLinearSolid(const UVector3& y0, const UVector3& y1, const UVector3& y2, double *om0, double *om1, double *om2) const
{
    if(y0==UVector3() || y1==UVector3() || y2==UVector3()) return U_ERROR;
    if(y0==y1         || y1==y2         || y2==y0        ) return U_ERROR;

    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double det  = z2&y2;
    double aaa2 = z.GetNorm2();
    double deta = det/aaa2;
    double L0   = UBEMIntegral::GetLineIntegralR(y0, y1, true);
    double L1   = UBEMIntegral::GetLineIntegralR(y1, y2, true);
    double L2   = UBEMIntegral::GetLineIntegralR(y2, y0, true);

    UVector3 V  = (y1-y0)*L0 + (y2-y1)*L1 + (y0-y2)*L2;
    double  oma = ComputeSolid(y0,y1,y2)/aaa2;

    *om0  = ( (y2-y1)&V )*deta + (z & z0) *oma;
    *om1  = ( (y0-y2)&V )*deta + (z & z1) *oma;
    *om2  = ( (y1-y0)&V )*deta + (z & z2) *oma;

    return U_OK;
}
ErrorType UBEMIntegral::ComputeLinearGamma(const UVector3& y0, const UVector3& y1, const UVector3& y2, double *om0, double *om1, double *om2) const
{
    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double det  = z2&y2;
    double aaa2 = z.GetNorm2();
    double aaa  = sqrt(aaa2);
    double L0   = UBEMIntegral::GetLineIntegralR(y0, y1, false);
    double L1   = UBEMIntegral::GetLineIntegralR(y1, y2, false);
    double L2   = UBEMIntegral::GetLineIntegralR(y2, y0, false);

    UVector3 V  = (y1-y0)*L0 + (y2-y1)*L1 + (y0-y2)*L2;
    double  oma = ComputeGamma(y0,y1,y2)/aaa2;

    *om0  = ( -(y2-y1)&V )/aaa + (z & z0) *oma;
    *om1  = ( -(y0-y2)&V )/aaa + (z & z1) *oma;
    *om2  = ( -(y1-y0)&V )/aaa + (z & z2) *oma;

    return U_OK;
}

UVector3 UBEMIntegral::ComputeBconst(UVector3 y0, UVector3 y1, UVector3 y2) const
/*
     Compute the magnetic field integral, for the constant potential approximation.
 */
{
    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double rr0 = y0.GetNorm2();
    double rr1 = y1.GetNorm2();
    double rr2 = y2.GetNorm2();

    double r0  = sqrt( rr0 );
    double r1  = sqrt( rr1 );
    double r2  = sqrt( rr2 );

    double r01 = (y0-y1).GetNorm();
    double r12 = (y1-y2).GetNorm();
    double r20 = (y2-y0).GetNorm();

    double a01 = y0&y1;
    double a12 = y1&y2;
    double a20 = y2&y0;

    double g01=0,g12=0,g20=0;

    double d0  = 1.+(rr1-a01)/(r01*r1);
    double d1  = 1.+(a01-rr0)/(r01*r0);
    if(d1>.01)
        g01 = log( r1*d0 / (r0*d1) ) / r01;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g01 = log( r0*d1 / (r1*d0) ) / r01;
    }
    d0  = 1.+(rr2-a12)/(r12*r2);
    d1  = 1.+(a12-rr1)/(r12*r1);
    if(d1>.01)
        g12 = log( r2*d0 / (r1*d1) ) / r12;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g12 = log( r1*d1 / (r2*d0) ) / r12;
    }

    d0  = 1.+(rr0-a20)/(r20*r0);
    d1  = 1.+(a20-rr2)/(r20*r2);
    if(d1>.01)
        g20 = log( r0*d0 / (r2*d1) ) / r20;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g20 = log( r2*d1 / (r0*d0) ) / r20;
    }

    return g01*(y1-y0) + g12*(y2-y1) + g20*(y0-y2);
}

void UBEMIntegral::ComputeBlinear(UVector3 y0, UVector3 y1, UVector3 y2, UVector3 *Om0, UVector3 *Om1, UVector3 *Om2) const
{
    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double det  = z2&y2;
    double aaa2 = z.GetNorm2();

    double rr0 = y0.GetNorm2();
    double rr1 = y1.GetNorm2();
    double rr2 = y2.GetNorm2();

    double r0  = sqrt( rr0 );
    double r1  = sqrt( rr1 );
    double r2  = sqrt( rr2 );

    double r01 = (y0-y1).GetNorm();
    double r12 = (y1-y2).GetNorm();
    double r20 = (y2-y0).GetNorm();

    double a01 = y0&y1;
    double a12 = y1&y2;
    double a20 = y2&y0;

    double a0  = r20*r20;
    double a1  =-a12 + rr2 + a01 - a20;
    double a2  =-a12 + a01 + a20 - rr0;
    double a3  = rr1 - a12 - a01 + a20;

    double d0, d1;
    double g01,g12,g20;

    d0  = 1.+(rr1-a01)/(r01*r1);
    d1  = 1.+(a01-rr0)/(r01*r0);
    if(d1>.01)
        g01 = log( r1*d0 / (r0*d1) ) / r01;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g01 = log( r0*d1 / (r1*d0) ) / r01;
    }
    d0  = 1.+(rr2-a12)/(r12*r2);
    d1  = 1.+(a12-rr1)/(r12*r1);
    if(d1>.01)
        g12 = log( r2*d0 / (r1*d1) ) / r12;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g12 = log( r1*d1 / (r2*d0) ) / r12;
    }

    d0  = 1.+(rr0-a20)/(r20*r0);
    d1  = 1.+(a20-rr2)/(r20*r2);
    if(d1>.01)
        g20 = log( r0*d0 / (r2*d1) ) / r20;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g20 = log( r2*d1 / (r0*d0) ) / r20;
    }

    double G01 = (r1 - r0 - (a01-rr0)*g01) /(r01*r01);
    double G12 = (r2 - r1 - (a12-rr1)*g12) /(r12*r12);
    double G20 = (r0 - r2 - (a20-rr2)*g20) /(r20*r20);

    double gamma = ComputeGamma(y0, y1, y2);
    double fact  = gamma/(det*sqrt(aaa2));


    *Om0 = G20*(y0-y2) + (g01-G01)*(y1-y0) + fact*(z0^z);
    *Om1 = G01*(y1-y0) + (g12-G12)*(y2-y1) + fact*(z1^z);
    *Om2 = G12*(y2-y1) + (g20-G20)*(y0-y2) + fact*(z2^z);
}

double UBEMIntegral::GetGammaSing(UVector3 x1, UVector3 x2) const
{
    UVector3 x21 = x2-x1;
    double   N12 = x21.GetNorm();
    double   N1  =  x1.GetNorm();
    double   N2  =  x2.GetNorm();
    double   R   = log( ((x2&x21) + N2*N12) / ((x1&x21) + N1*N12));
    double   C   = (x2 ^ x1).GetNorm();
    return C*R/N12;
}

double UBEMIntegral::ComputeGamma(UVector3 y0, UVector3 y1, UVector3 y2) const
/*
     Tested with numerical integration on 28-04-1999.
 */
{
    if(y0==UVector3()) return GetGammaSing(y1, y2);
    if(y1==UVector3()) return GetGammaSing(y2, y0);
    if(y2==UVector3()) return GetGammaSing(y0, y1);

    UVector3 z0 = y1^y2;
    UVector3 z1 = y2^y0;
    UVector3 z2 = y0^y1;
    UVector3 z  = z0 + z1 + z2;

    double det  = z2&y2;
    double aaa2 = z.GetNorm2();

    double rr0 = y0.GetNorm2();
    double rr1 = y1.GetNorm2();
    double rr2 = y2.GetNorm2();

    double r0  = sqrt( rr0 );
    double r1  = sqrt( rr1 );
    double r2  = sqrt( rr2 );

    double r01 = (y0-y1).GetNorm();
    double r12 = (y1-y2).GetNorm();
    double r20 = (y2-y0).GetNorm();

    double a01 = y0&y1;
    double a12 = y1&y2;
    double a20 = y2&y0;

    double a0  = r20*r20;
    double a1  =-a12 + rr2 + a01 - a20;
    double a2  =-a12 + a01 + a20 - rr0;
    double a3  = rr1 - a12 - a01 + a20;

    double d0, d1;
    double g01,g12,g20;

    d0  = 1.+(rr1-a01)/(r01*r1);
    d1  = 1.+(a01-rr0)/(r01*r0);
    if(d1>.01)
        g01 = log( r1*d0 / (r0*d1) ) / r01;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g01 = log( r0*d1 / (r1*d0) ) / r01;
    }
    d0  = 1.+(rr2-a12)/(r12*r2);
    d1  = 1.+(a12-rr1)/(r12*r1);
    if(d1>.01)
        g12 = log( r2*d0 / (r1*d1) ) / r12;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g12 = log( r1*d1 / (r2*d0) ) / r12;
    }

    d0  = 1.+(rr0-a20)/(r20*r0);
    d1  = 1.+(a20-rr2)/(r20*r2);
    if(d1>.01)
        g20 = log( r0*d0 / (r2*d1) ) / r20;
    else
    {
        d0 = 2.-d0;
        d1 = 2.-d1;
        g20 = log( r2*d1 / (r0*d0) ) / r20;
    }

    double gamma = -det*ComputeSolid(y0, y1, y2);
    gamma       += (z&z2)*g01 + (z&z0)*g12 + (z&z1)*g20;

    return gamma/sqrt(aaa2);
}

double UBEMIntegral::GetLineIntegralR(const UVector3& y0, const UVector3& y1, bool InvertR) const
{
    if(y0==UVector3() || y1==UVector3())
    {
        CI.AddToLog("ERROR: GetLineIntegralR(). Begin or end point is zero. \n");
        return 0.;
    }
    if(y0==y1)
    {
        CI.AddToLog("ERROR: GetLineIntegralR(). Begin and end points coincide. \n");
        return 0.;
    }
    double rr0 = y0.GetNorm2();
    double rr1 = y1.GetNorm2();

    double r0  = sqrt( rr0 );
    double r1  = sqrt( rr1 );

    double r01 = (y0-y1).GetNorm();
    double a01 = y0&y1;

    double d0  = 1.+(rr1-a01)/(r01*r1);
    double d1  = 1.+(a01-rr0)/(r01*r0);

    double Integ = 0;
    if(d1>.01)
        Integ = log( r1*d0 / (r0*d1) ) / r01;
    else
    {
        d0    = 2.-d0;
        d1    = 2.-d1;
        Integ = log( r0*d1 / (r1*d0) ) / r01;
    }
    if(InvertR) return Integ;

    double   r012 = 2*r01*r01;
    UVector3 z    = y0^y1;

    Integ      *= z.GetNorm2()/r012;
    Integ      += ((rr1-a01)*r1 - (a01-rr0)*r0)/r012;
    return Integ;
}

