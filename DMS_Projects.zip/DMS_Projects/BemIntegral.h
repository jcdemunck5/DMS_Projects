#ifndef _BEMINTEGRAL_INCLUDED
#define _BEMINTEGRAL_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include"MatVec.h"

class DLL_IO UBEMIntegral
{
public:
    bool        IsAcuteTriangle(const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const;
    UVector3    GetMinimumBoundingCircle(const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* Radius) const;
    double      ComputeDistance(UVector3 x, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const;
    UVector3    Project(UVector3 x, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* w0 = NULL, double* w1 = NULL, double* w2=NULL) const;
    UVector3    Project(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2, double* w0=NULL, double* w1=NULL, double* w2=NULL) const;
    bool        LineThroughTriangle(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const;
    bool        HalfLineThroughTriangle(UVector3 x, UVector3 m, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const;

    double      LinInterpol(UVector3 x, double v0, double v1, double v2, const UVector3 *y0, const UVector3 *y1, const UVector3 *y2) const;
    double      ComputeArea(UVector3 y0, UVector3 y1, UVector3 y2) const;
    double      ComputeVolume(UVector3 y0, UVector3 y1, UVector3 y2, UVector3 y3) const;
    double      ComputeSolid(UVector3 y0, UVector3 y1, UVector3 y2) const;
    void        ComputeLinear(UVector3 y0, UVector3 y1, UVector3 y2, double *om0, double *om1, double *om2) const;
    ErrorType   ComputeLinearSolid(const UVector3& y0, const UVector3& y1, const UVector3& y2, double *om0, double *om1, double *om2) const;
    ErrorType   ComputeLinearGamma(const UVector3& y0, const UVector3& y1, const UVector3& y2, double *om0, double *om1, double *om2) const;
    UVector3    ComputeBconst(UVector3 y0, UVector3 y1, UVector3 y2) const;
    void        ComputeBlinear(UVector3 y0, UVector3 y1, UVector3 y2, UVector3 *Om0, UVector3 *Om1, UVector3 *Om2) const;
    double      ComputeGamma(UVector3 y0, UVector3 y1, UVector3 y2) const;
    double      GetGammaSing(UVector3 x1, UVector3 x2) const;

    double      GetLineIntegralR(const UVector3& y0, const UVector3& y1, bool InvertR=true) const;
};
#endif// _BEMINTEGRAL_INCLUDED
