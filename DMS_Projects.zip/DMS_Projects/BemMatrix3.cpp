/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for computing setting the matrix elements corresponding		     */
/*     to the volume conductor model. C++ version, derived from 2D-version       */
/*     BemMatrix.cpp and from c-sources of R. van Gent                           */
/*                                                                               */
/*     Note: after the constructor, first call SetAmatLU(), then (a loop of      */
/*     calls to) GetBvec() and UBemField::GetPotential() or                      */
/*     UBemField::GetPotentialEIT()                                              */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
Update history

Who    When       What
Jdm    30-09-98   Creation
Jdm    17-10-98   Updated dependence of include files
Jdm    05-11-98   Separated computation parameters for Amat and Bvec
JdM    21-04-99   Improved some of the comments
JdM    22-04-99   Updates according to new definitions of UIntBVec() and UBEMIntegral()    
JdM    24-04-99   Bug fix: Use GetTotalPoints() i.s.o, GetPoints() to get surface points of curved surfaces.
JdM    08-06-99   The potential interpolation mode should be the same for Amat and Bvec and is given by PInter
JdM    10-06-99   Set surface interpolation and smoothing of Bvec by separate functions;
JdM    13-06-99   Computation of partial derivatives
JdM    29-07-99   Added matrix element smoothing
JdM    04-08-99   Some bug-fixes in matrix element smoothing
JdM    05-08-99   Bug fix in computing derivatives of smoothed Bvec[]
JdM    08-08-99   Use CI-object to write errors to .log-file
JdM    13-08-99   BUG FIX: sign in derivatives w.r.t. position
JdM    20-08-99   BUG FIX: Do not get head-model-type in Constructor, when no headmodel is present
GdV    06-07-99   Some corrections due to compilation with GNU-compiler
JdM    27-08-99   SetBvec() now returns NULL instead of ErrorType
JdM    29-08-99   Export timer information to log-file
JdM    17-01-00   More error messages.
JdM    20-01-00   BUG fix? in adding surfaces to conductor in NLR coordinates. TESTED!!
JdM    17-02-00   Take BEM computation parameters from new version UHeadModel.
JdM    21-02-00   Make a few public functions const. Allocate Bvec[] only once.
JdM    19-05-00   Include Surface interpolation index, for curved surfaces.
JdM    19-05-00   Bug Fix in constructor, for case Hmod==NULL.
JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
JdM/SG  10-10-00   Added SetBvec() function for EIT
JdM    13-10-00   Make the EIT right hand side compatible with curved triangles and smoothing
Remove a few obsolete functions and variables. 
JdM/SG  17-10-00   BUG Fix in case of EIT: devide Bvec by 4*PI to get agreement with analytical formulas
JdM    19-10-00   Move LU- object pointer  to UBemField()
JdM    01-11-00   Rename SetAmatLU() to SetAmat(). Compute LU decomposition in calling function.
JdM/SG  17-10-00   Added parameter to SetAmat()
JdM    16-11-00   Update Getproperties() (consistent with UConductor3::GetProperties())
JdM/SG  04-12-00   BUG fix in constructor. Apply transformation to NLR system only once, i.s.o. for each surface
JdM    20-04-01   Added ReplaceSurface()
JdM/SG  22-06-01   Added LocalRefine() (again?) to make sure joffset and Npot are updated
JdM    28-06-01   Bug fix: GetPoints(). Compute the correct gravity point in case of U_POTINTER_CONSTANT
JdM    20-09-01   Implemented mixed derivatives: D_OriPos11
JdM    17-11-01   Made SetBvec() compatible with (semi) symmetric dipoles
JdM    13-06-02   Allow for non-sagital MR scans. Make use of ScanToWld information inside the updated UHeadModel object.
JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
JdM    27-02-05   Made several pointers const, according to changes in USurface()
JdM    07-03-05   Added SetAllMembersDefault(), DeleteAllMembers(). Use UString for GetProperties()
JdM    28-03-05   DerivType: made it external type
JdM    30-12-06   Adapted include file to new directory structure
JdM    05-11-07   Bug Fix: operator=(). Copying Bvec[] and joffset[]
JdM    21-11-07   Renamed  PotInterPol, SurfInterPol and SmoothElem to PotInterPolType, SurfInterPolType and BEMSmoothType
and made them globally, dedfined in Dipole.h
JdM    27-06-08   Bug Fix: operator=(). Copying joffset[] (allocate copy Nsurfaces+1 elements)
JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
JdM    07-06-14   GetNestedSurface(). Made returned pointer const
JdM/JD   02-10-14   SetAmat(). Minor (bug) fix in computing deflation (A += A + term)
JdM    07-10-14   SetBvec(). Use different interface to GetClosestTriangle()
JdM    14-10-14   BUG FIX: SetBvec(double, UVector3, UVector3). Case U_SMOOTH_SMOOTH. Subtract injected from extracted current (instead of adding)
SetBvec(). Avoid shrinking of current injection pattern to smaller triangle (thanks to updated ComputeGamma()).
JdM    15-10-14   SetAmat(). Split off dependency of conductivities
JdM    19-11-14   Renamed GetPoints() by GetPointsCopy().
JdM    19-11-14   UIntBVec() and UIntAmat(). Added default constructor
JdM    20-11-14   UIntBVec() and UIntAmat(). Added operator=(), copy constructor and DeleteAllMembers()
JdM    23-11-14   SetAmat(), SetBevec(). Use GetSmoothNorm() to scale matrix elements in case of SmoothA and SmoothB == U_SMOOTH_SMOOTH
JdM    15-02-15   Re-organized smoothing. Added UIntBVec::IntegrateGammaConst(), UIntBVec::IntegrateDipConst(), UIntBVec::IntegrateGammaLinear(), UIntBVec::IntegrateDipLinear()
UIntAmat::IntegrateOmegConst() and UIntAmat::IntegrateOmegLinear()
JdM    17-02-15   BUG FIX. SetAmat(). (case U_POTINTER_LINEAR, U_SMOOTH_SMOOTH). Set neighboring matrix elements equal to zero.
BUG FIX. SetBvec() (current injection, case U_POTINTER_LINEAR, U_SMOOTH_SMOOTH). Add up all contributions to Bvec[].
JdM    22-02-15   Removed option of curved triangles SInterA and SInterB
JdM    21-05-15   MAJOR change: (obsolete) UPatTree::World2MR() and UPatTree::MR2World() were removed. Before MR2World was applied 
in the UHeadModel construcor to all surfaces to compensate UPatTree::World2MR(), applied in the previous USurface costructor.
With the new code, Nested surfaces are directly extracted from UHeadModel, in NLR coords.
JdM    25-05-15   Added WriteBinary() and FILE* constructor to UBemMatrix3
JdM    05-07-15   SetBvec(). Added UseMonoLayer parameter (restricted version, EIT only)
JdM    10-08-15   Removed (obsolete) GetSmoothNorm()
JdM    18-08-15   SetBvec(). Added UseMonoLayer parameter, which now also valid for dipoles
JdM    23-08-15   Made UsemonoLayer data member, instead of parameter of UBemField::ComputePotential() and UBemField::ComputePotentialEIT()
JdM    30-08-15   Major update of code. Used UMatrix objects where possible, to increase readability.
JdM    17-09-15   Made UseMonolayer compatible with U_POTINTER_LINEAR for case of EIT. 
JdM    15-03-16   SetAmat(). Changed last bool argument into const double array DefaultSigmas[]
JdM    26-12-16   Added GetImprodHOne()
Bug Fix SetAmat(). case of PInter==U_POTINTER_LINEAR && SmoothA==U_SMOOTH_SMOOTH: use += Elem
JdM    31-12-16   Bug Fix GetBvec(double, UVector3, UVector3). case UseMonoLayer, PInter==U_POTINTER_LINEAR, forgot to multiply with Current
SetAmat(), SetBvec() and GetGammaMat(). Normalize matrix elements with GetImprodHOne(). 
JdM    01-01-17   SetRHSSingleDip(), SetBvec(): Made suitable for combi UseMonoLayer && PInter==U_POTINTER_LINEAR
JdM    15-01-17   BUG FIX. SetRHSSingleDip(). In case of UseMonoLayer, normalize N
JdM    03-02-17   Added (default) parameter to GetImprodHOne()
JdM    26-03-18   Added GetBvec() for unipolar stimulation.
JdM    01-06-18   Added another constructor, where BEM settings of UHeadModel argument are overwritten.
JdM    02-06-18   Added ResampleSurfaces()
*/

#include<string.h>
#include "BemMatrix3.h"
#include "BemIntegral.h"
#include "HeadModel.h"
#include "MatrixSparse.h"
#include "MatrixSymmetric.h"

/* Inititalize static const parameters. */
UString      UBemMatrix3::Properties = UString();
const char*  UBemMatrix3::HEADERBEGIN = "BemMatrix1.0";
const char*  UBemMatrix3::HEADEREND   = "BemMatrixEnd";

#define SMOOTH_ORDER  4
#define MAXCOMP      36

void UBemMatrix3::SetAllMembersDefault(void)
{
    error        = U_OK;
    Npot         = 0;
    joffset      = NULL;

    PInter       = U_POTINTER_CONSTANT;
    SmoothA      = U_SMOOTH_DEFAULT;
    SmoothB      = U_SMOOTH_DEFAULT;
    UseMonoLayer = false;
}

void UBemMatrix3::DeleteAllMembers(ErrorType E)
{
    delete[] joffset;
    SetAllMembersDefault();
    error   = E;
}

UBemMatrix3::UBemMatrix3() 
{
    SetAllMembersDefault();
}

UBemMatrix3::UBemMatrix3(const UHeadModel* Hmod) : UConductor3()
{     
    SetAllMembersDefault();
    if(Hmod==NULL) return;
    if(Hmod->GetError()!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). UHeadModel argument erroneous.\n");
        return;
    }
    if(Hmod->GetCondModelType()!=U_CONDMOD_BEM) return;

    for(int j=0; j<Hmod->GetNshell(); j++)
    {
        UNestedSurface* SN = Hmod->GetNestedSurfaceNLR(j);
        if(SN==NULL ||SN->GetError()!=U_OK)
        {
            delete SN;
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot create nested surface no %d from UHeadModel argument.\n",j);
            return;
        }
        if(AddSurface(*SN)!=U_OK)
        {
            delete SN;
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot Add surface %d to conductor (=%s) .\n",j, SN->GetName());
            return;
        }
        delete SN;
    }
    if(UConductor3::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot set realistic model .\n");
        return;
    }
    PotInterPolType  PInt = Hmod->GetPotentalInterpolation();
    BEMSmoothType    Smo  = Hmod->GetMatrixSmoothing();

    if(Smo!=U_SMOOTH_RAW && Smo!=U_SMOOTH_SMOOTH) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Wrong smmothing argument (%d).\n", int(Smo));
        return;
    }

    PInter  = PInt;
    SmoothA = Smo;
    SmoothB = Smo;

    if(UpdateMatSize()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Memory allocation. \n");
        return;
    }
    if(UConductor3::TopologySet==false && UConductor3::SetTopology()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Setting topology of realistic model. \n");
        return;
    }
}
UBemMatrix3::UBemMatrix3(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool MonoLayer) : UConductor3()
{     
    SetAllMembersDefault();

    if(Hmod==NULL || Hmod->GetError()!=U_OK || Hmod->GetCondModelType()!=U_CONDMOD_BEM)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). UHeadModel argument NULL or erroneous (or not of BEM type).\n");
        return;
    }

    for(int j=0; j<Hmod->GetNshell(); j++)
    {
        UNestedSurface* SN = Hmod->GetNestedSurfaceNLR(j);
        if(SN==NULL ||SN->GetError()!=U_OK)
        {
            delete SN;
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot create nested surface no %d from UHeadModel argument.\n",j);
            return;
        }
        if(AddSurface(*SN)!=U_OK)
        {
            delete SN;
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot Add surface %d to conductor (=%s) .\n",j, SN->GetName());
            return;
        }
        delete SN;
    }
    if(UConductor3::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Cannot set realistic model .\n");
        return;
    }
    if(Smo!=U_SMOOTH_RAW && Smo!=U_SMOOTH_SMOOTH) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Wrong smmothing argument (%d).\n", int(Smo));
        return;
    }
    if(MonoLayer && Smo!=U_SMOOTH_SMOOTH)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Galerking smoothing required for MonoLayer approach. \n"); 
        return;
    }
    PInter       = PInt;
    SmoothA      = Smo;
    SmoothB      = Smo;
    UseMonoLayer = MonoLayer;

    if(UpdateMatSize()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Memory allocation. \n");
        return;
    }
    if(UConductor3::TopologySet==false && UConductor3::SetTopology()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Setting topology of realistic model. \n");
        return;
    }
}

UBemMatrix3::UBemMatrix3(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool MonoLayer) :
    UConductor3(C)
{
    SetAllMembersDefault();

    if(UConductor3::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Setting UConducor3 base class. \n");
        return;
    }
    if(Smo!=U_SMOOTH_RAW && Smo!=U_SMOOTH_SMOOTH) 
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Wrong smoothing argument (%d).\n", int(Smo));
        return;
    }
    if(MonoLayer && Smo!=U_SMOOTH_SMOOTH)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Galerking smoothing required for MonoLayer approach. \n"); 
        return;
    }

    PInter       = PInt;
    SmoothA      = Smo;
    SmoothB      = Smo;
    UseMonoLayer = MonoLayer;

    if(UpdateMatSize()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Memory allocation. \n");
        return;
    }
    if(UConductor3::TopologySet==false) 
        if(UConductor3::SetTopology()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Setting topology of realistic model. \n");
            return;
        }
}
UBemMatrix3::UBemMatrix3(FILE* fpIn) : UConductor3(fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Invalid NULL pointer. \n");
        return;
    }
    if(UConductor3::GetError()!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Creating UConductor3 base class. \n");
        return;
    }

    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }

    PInter      = GetPotInterPolType(::ReadBinaryInt (DefaultIntelData, fpIn));
    SmoothA     = GetBEMSmoothType  (::ReadBinaryInt (DefaultIntelData, fpIn));
    SmoothB     = GetBEMSmoothType  (::ReadBinaryInt (DefaultIntelData, fpIn));

    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }
    if(UpdateMatSize()!=U_OK)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Memory allocation, fp constructor. \n");
        return;
    }
    if(UConductor3::TopologySet==false) 
        if(UConductor3::SetTopology()!=U_OK)
        {
            UConductor3::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UBemMatrix3::UBemMatrix3(). Setting topology of realistic model, fp constructor. \n");
            return;
        }
}
ErrorType UBemMatrix3::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }
    if(UConductor3::WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::WriteBinary(). Writing base class. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(GetPotInterPolInt(PInter), DefaultIntelData, fpOut);
    ::WriteBinary(GetBEMSmoothInt (SmoothA), DefaultIntelData, fpOut);
    ::WriteBinary(GetBEMSmoothInt (SmoothB), DefaultIntelData, fpOut);

    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UBemMatrix3::UBemMatrix3(const UBemMatrix3 &B3)
{
    SetAllMembersDefault();
    *this = B3;
}

UBemMatrix3::~UBemMatrix3()
{
    DeleteAllMembers(U_OK);
}

UBemMatrix3& UBemMatrix3::operator=(const UBemMatrix3 &B3)
{
    if(this==NULL || &B3==NULL)
    {
        if(this==NULL)
        {
            static UBemMatrix3 B; B.error = U_ERROR;
            CI.AddToLog("ERROR: UBemMatrix3::operator=(). this==NULL. \n");
            return B;
        }
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::operator=(). this==NULL. \n");
        return *this;
    }
    if(this==&B3) return *this;

    UConductor3::operator=((UConductor3) B3);
    if(UConductor3::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    PInter       = B3.PInter;
    SmoothA      = B3.SmoothA;
    SmoothB      = B3.SmoothB;
    UseMonoLayer = B3.UseMonoLayer;
    Npot         = B3.Npot;
    if(B3.joffset)  joffset = new int[Nsurfaces+1];

    if( joffset==NULL && B3.joffset!=NULL)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::operator=(). Memory allocation, Npot = %d. \n", Npot);
        return *this;
    }
    if(joffset) for(int j=0; j<Nsurfaces+1 ; j++) joffset[j] = B3.joffset[j];
    return *this;
}

ErrorType UBemMatrix3::ResampleSurfaces(int NtotalPoints, double* Frac, int Ns)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(NtotalPoints<20)
    {
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Argument out of range (NtotalPoints=%d). \n", NtotalPoints);
        return U_ERROR;
    }
    if(Frac==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Erroneous NULL argument. \n");
        return U_ERROR;
    }
    if(Ns!=Nsurfaces)
    {
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Argument Ns (%d) not equal to Nsurfaces (%d). \n", Ns, Nsurfaces);
        return U_ERROR;
    }
    double Ftot=0.;
    for(int k=0; k<Ns; k++)
    {
        if(int(Frac[k]*NtotalPoints)<10)
        {
            CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Fraction[%d] too small (%f). Fewer than 10 points remain. \n", k, Frac[k]);
            return U_ERROR;
        }
        Ftot += Frac[k];
    }
    if(fabs(Ftot-1.)>=1.e-5)
    {
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Fractions do not add up to one (%12.8f). \n", Ftot);
        return U_ERROR;
    }
    for(int k=0; k<Ns; k++)
    {
        int NP = int(Frac[k]*NtotalPoints);
        if(pSurface[k]->Resample(NP,0,k+1)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            UConductor3::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Resampling surface %d to %d points. \n", k, NP);
            return U_ERROR;
        }
    }
    if(UpdateMatSize()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Updating matrix size. \n");
        return U_ERROR;
    }
    if(UConductor3::SetTopology()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UConductor3::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::ResampleSurfaces(). Setting topology of realistic model. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UBemMatrix3::ReplaceSurface(int iSurface, const USurface &S)
{
    if(this==NULL || error!=U_OK)                      return U_ERROR;
    if(UConductor3::ReplaceSurface(iSurface, S)!=U_OK) return U_ERROR;
    if(UpdateMatSize()!= U_OK)                         return U_ERROR;
    return U_OK;
}

ErrorType UBemMatrix3::ReplaceSurface(int iSurface, const UConductor3 &r)
{
    if(this==NULL || error!=U_OK)                      return U_ERROR;
    if(UConductor3::ReplaceSurface(iSurface, r)!=U_OK) return U_ERROR;
    if(UpdateMatSize()!= U_OK)                         return U_ERROR;
    return U_OK;
}

ErrorType UBemMatrix3::LocalRefine(double MaxDistance, UVector3* Pts, int Npts)
{
    if(this==NULL || error!=U_OK)                      return U_ERROR;
    if(UConductor3::LocalRefine(MaxDistance, Pts, Npts)!=U_OK) return U_ERROR;
    if(UpdateMatSize()!= U_OK)                                 return U_ERROR;
    return U_OK;
}

ErrorType UBemMatrix3::SetPotInterPol(PotInterPolType PInt) 
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetPotInterPol(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    PInter = PInt; 
    return UpdateMatSize();
}
bool UBemMatrix3::GetMonoLayer(void) const
{
    if(this==NULL || error!=U_OK) return false;
    return UseMonoLayer;
}

UMatrix UBemMatrix3::GetImprodHOne(bool InvertMat, int jsurf) const
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(jsurf>=Nsurfaces)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne().Parameter out of range (jsurf = %d).\n", jsurf);
        return UMatrix(U_ERROR);
    }
    if(joffset==NULL || Npot<=0 || pSurface==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne(). Object improperly set.\n");
        return UMatrix(U_ERROR);
    }
    if(SmoothA!=U_SMOOTH_RAW && SmoothA!=U_SMOOTH_SMOOTH)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne(). Invalid smoothing (%d).\n", int(SmoothA));
        return UMatrix(U_ERROR);
    }
    if(PInter!=U_POTINTER_CONSTANT && PInter!=U_POTINTER_LINEAR)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne(). Invalid interpolation (%d).\n", int(PInter));
        return UMatrix(U_ERROR);
    }

    int NP = GetNpot(jsurf);
    if(SmoothA==U_SMOOTH_RAW)   return UMatrix(1.,NP);

    UMatrix Improd(DNULL, NP);
    if(Improd.GetError()!=U_OK || Improd.Data==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne(). Creating output matrix.\n");
        return UMatrix(U_ERROR);
    }

    for(int n=0; n<NP; n++) Improd.Data[n] = 0.;

    int Jstart = jsurf<0 ? 0         : jsurf;
    int Jend   = jsurf<0 ? Nsurfaces : jsurf+1;

    for(int j=Jstart; j<Jend; j++)
    {
        int Ntri = pSurface[j]->GetNtri();
        int Joff = jsurf<0 ? joffset[j] : 0;
        for(int i=0; i<Ntri;i++)
        {
            double AT = pSurface[j]->GetArea(i);
            if(PInter==U_POTINTER_CONSTANT) 
            {
                Improd.Data[Joff+i] += AT;
            }
            else
            {
                const int* Itri  = pSurface[j]->GetTriIndices(i);
                int        n0    = Joff+Itri[0];
                int        n1    = Joff+Itri[1];
                int        n2    = Joff+Itri[2];
                Improd.Data[n0] += AT/3;
                Improd.Data[n1] += AT/3;
                Improd.Data[n2] += AT/3;
            }
        }
    }
    if(InvertMat) 
    {
        for(int n=0; n<NP; n++) 
        {
            if(Improd.Data[n]>0.) Improd.Data[n] = 1./Improd.Data[n];
            else                  {CI.AddToLog("ERROR: UBemMatrix3::GetImprodHOne(). Invalid matrix elem (%d).\n", n); return UMatrix(U_ERROR);}
        }
    }
    return Improd;
}

UMatrix UBemMatrix3::GetGammaMat(const int* SelectRows, int NIndex)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(SelectRows==NULL || NIndex<=0) return UMatrix(U_ERROR);

    int jout               = GetOuterSurf();
    UNestedSurface Sout(*GetNestedSurface(jout));
    UMatrix ImpOneInv      = GetImprodHOne(true);
    if(Sout.GetError()!=U_OK || ImpOneInv.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetGammaMat(). Getting outer surface or getting improducts. \n");
        return UMatrix(U_ERROR);
    }

    int   Nsurfaces     = GetNsurfaces();
    const UVector3*  p1 = Sout.GetPoints();
    const int* TriList1 = Sout.GetTriList(); 

    UMatrix GAMmatrix(DNULL, PInter==U_POTINTER_CONSTANT? NIndex : Sout.GetNpoints(), Npot);
    if(GAMmatrix.GetError()!=U_OK || GAMmatrix.Data==NULL) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetGammaMat(). Computing Gamma matrix.\n");
        return UMatrix(U_ERROR);
    }

    for(int j2=0;j2<Nsurfaces;j2++)                 /* Loop over all triangles ("source points") */
    {
        const UNestedSurface*   g2 = GetNestedSurface(j2);
        const UVector3*         p2 = g2->GetPoints();
        const int*        TriList2 = g2->GetTriList(); 
        for(int n=0,n3=0;n<GetNestedSurface(j2)->GetNtri();n++,n3+=3)
        {
            int i0 = TriList2[n3  ];
            int i1 = TriList2[n3+1];
            int i2 = TriList2[n3+2];

            UIntAmat Inum = UIntAmat(p2[i0], p2[i1], p2[i2], SMOOTH_ORDER);
            if(PInter==U_POTINTER_CONSTANT)
            {
                for(int i=0;i<NIndex;i++)             /*Loop over all selected electrodes */
                {
                    int              m3 = 3*SelectRows[i];
                    UVector3         y0 = p1[TriList1[m3+0]];
                    UVector3         y1 = p1[TriList1[m3+1]];
                    UVector3         y2 = p1[TriList1[m3+2]];

                    GAMmatrix.Data[i*Npot + joffset[j2]+n] = Inum.IntegrateGammaConst(y0,y1,y2);
                }
            }
            else
            {
                int Nout = Sout.GetNtri();
                for(int m=0, m3=0;m<Nout;m++, m3+=3) /*Loop over all outer points ("sensor points") */
                {
                    int              k0 = TriList1[m3+0];
                    int              k1 = TriList1[m3+1];
                    int              k2 = TriList1[m3+2];
                    const double*   gam = Inum.IntegrateGammaLinear(p1[k0],p1[k1],p1[k2]);

                    GAMmatrix.Data[k0*Npot + joffset[j2]+i0] += gam[0];
                    GAMmatrix.Data[k1*Npot + joffset[j2]+i0] += gam[1];
                    GAMmatrix.Data[k2*Npot + joffset[j2]+i0] += gam[2];
                    GAMmatrix.Data[k0*Npot + joffset[j2]+i1] += gam[3];
                    GAMmatrix.Data[k1*Npot + joffset[j2]+i1] += gam[4];
                    GAMmatrix.Data[k2*Npot + joffset[j2]+i1] += gam[5];
                    GAMmatrix.Data[k0*Npot + joffset[j2]+i2] += gam[6];
                    GAMmatrix.Data[k1*Npot + joffset[j2]+i2] += gam[7];
                    GAMmatrix.Data[k2*Npot + joffset[j2]+i2] += gam[8];
                }
            }
        }
    }
    GAMmatrix = GAMmatrix*ImpOneInv;

    if(PInter==U_POTINTER_CONSTANT)
    {
        for(int i=0;i<NIndex;i++)         /*Loop over all elctrodes */
        {
            int    m3   = 3*SelectRows[i];
            double Area = ::GetArea(p1[TriList1[m3+0]], p1[TriList1[m3+1]], p1[TriList1[m3+2]]) * PI4;;
            for(int n=0; n<Npot; n++) GAMmatrix.Data[i*Npot + n] /= Area;
        }
    }
    else
    {
        UMatrixSparse Hmat = Sout.GetSparseOverlapMatrix();
        if(Hmat.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetGammaMat(). Creating overlap matrix.\n");
            return UMatrix(U_ERROR);
        }
        UMatrixSymmetric SSS(Hmat);
        GAMmatrix = SSS.GetAxIsB(GAMmatrix);
        GAMmatrix = GAMmatrix.GetRowSelection(SelectRows, NIndex)*(1./PI4);
    }
    return GAMmatrix;
}
UMatrix UBemMatrix3::GetBvec(double Current, UVector3 x)
{
    if(this==NULL || error!=U_OK)  UMatrix(U_ERROR);

    UMatrix Bvec(DNULL, Npot, 1);
    if(Bvec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Creating output matrix. \n"); 
        return UMatrix(U_ERROR);
    }

    int jout = GetOuterSurf();
    UNestedSurface Sout(*GetNestedSurface(jout));
    if(jout<0 || Sout.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting outer surface. \n"); 
        return UMatrix(U_ERROR);
    }

    double DistMin = -1;
    int    itx     =  Sout.GetClosestTriangle(x, &DistMin, false); // Unsigned distance
    int    ipx     =  Sout.GetClosestPoint(x, &DistMin, false);    // Unsigned distance
    if(itx<0 ||ipx<0 || DistMin<0.)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting closest triangle. \n"); 
        return UMatrix(U_ERROR);
    }
    double AA0x    = Sout.GetArea(itx);
    double AA0rest = Sout.GetArea() - AA0x;
    double AA1x    = Sout.GetVertexArea(ipx);
    double AA1rest = Sout.GetArea() - AA1x;
    if (AA0x <= 0 || AA1x <= 0. || AA0rest <= 0. || AA1rest <= 0.)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Electrode area(s) out of range. \n");
        return UMatrix(U_ERROR);
    }
    double CurDens0x    =  Current / AA0x;
    double CurDens0rest = -Current / AA0rest;
    double CurDens1x    =  Current / AA1x;
    double CurDens1rest = -Current / AA1rest;

    int Nout = GetNpot(jout);
    if(UseMonoLayer)  // Bvec = Current density times H (= integral h_itx * h_it
    {
        if(PInter==U_POTINTER_CONSTANT)
        {
            for(int it=0; it<Nout; it++) Bvec.Data[joffset[jout]+it] = -Current*AA0x/AA0rest;
            Bvec.Data[joffset[jout]+itx] =  Current; 
        }
        else
        {
            UMatrix RHS = Sout.GetOverlapCollumn(ipx)*(CurDens1x-CurDens1rest) + GetImprodHOne(false,jout)*UMatrix(CurDens1rest,GetNpot(jout),1);
            Bvec.SetData(joffset[jout], 0, RHS);
        }
        return Bvec;
    }

    UMatrix ImpOneInv      = GetImprodHOne(true);
    const UVector3* pOut   = Sout.GetPoints();
    const int*      TriOut = Sout.GetTriList();
    if(pOut==NULL || TriOut==NULL || ImpOneInv.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting points from outer surface or getting improducts. \n");
        return UMatrix(U_ERROR);
    }

    UVector3 p0 = pOut[TriOut[3*itx  ]];
    UVector3 p1 = pOut[TriOut[3*itx+1]];
    UVector3 p2 = pOut[TriOut[3*itx+2]];

    if(SmoothB==U_SMOOTH_RAW)       
    {
        UVector3* pView  = GetPointsCopy(-1);
        if(pView==NULL) return UMatrix(U_ERROR);

        double CurDensxPI4    =  CurDens0x    / PI4;
        double CurDensrestPI4 = -CurDens0rest / PI4;
        UBEMIntegral BI;

        for(int n=0; n<Npot; n++) Bvec.Data[n] = CurDensxPI4* BI.ComputeGamma(p0-pView[n], p1-pView[n], p2-pView[n]);
        for(int n=0; n<Npot; n++)
        {
            double TermOuter = 0;
            for(int it=0; it<Sout.GetNtri(); it++) 
            {
                if(it==itx) continue;
                UVector3 q0   = pOut[TriOut[3*it  ]]-pView[n];
                UVector3 q1   = pOut[TriOut[3*it+1]]-pView[n];
                UVector3 q2   = pOut[TriOut[3*it+2]]-pView[n];
                TermOuter    += BI.ComputeGamma(q0, q1, q2);
            }
            Bvec.Data[n] +=  CurDensrestPI4 * TermOuter;
        }
        delete[] pView;
        return ImpOneInv*Bvec;
    }

    /* Smoothing, double layer*/
    for(int j=0,n=0; j<Nsurfaces; j++)
    {
        UNestedSurface* g = pSurface[j];
        const UVector3* p = g->GetPoints();

        const int *TriList = g->GetTriList();
        for(int k=0; k<g->GetNtri(); k++,n++)  /*Loop over all outer points ("sensor points") */
        {
            int k0 = TriList[3*k  ];
            int k1 = TriList[3*k+1];
            int k2 = TriList[3*k+2];

            UIntAmat Inum  =  UIntAmat(p[k0], p[k1], p[k2], SMOOTH_ORDER);
            if(PInter==U_POTINTER_CONSTANT)
            {            
                Bvec.Data[n]   =  0;
                for(int it=0; it<Sout.GetNtri(); it++)
                {
                    if(it==itx) continue;
                    UVector3 y0   = pOut[TriOut[3*it  ]];
                    UVector3 y1   = pOut[TriOut[3*it+1]];
                    UVector3 y2   = pOut[TriOut[3*it+2]];

                    Bvec.Data[n] += Inum.IntegrateGammaConst(y0,y1,y2);
                }
                Bvec.Data[n] *= (CurDens0rest/PI4);
                Bvec.Data[n] += (CurDens0x   /PI4) * Inum.IntegrateGammaConst(p0, p1,  p2);
            }
            else
            {
                double CurDensxPI4    = (CurDens1x - CurDens1rest) / PI4;
                double CurDensrestPI4 =              CurDens1rest  / PI4;

                int n0 = joffset[j] + k0;
                int n1 = joffset[j] + k1;
                int n2 = joffset[j] + k2;
                for(int it=0, it3=0; it<Sout.GetNtri(); it++, it3+= 3) /* Loop over injection points */
                {
                    int              i0 = TriOut[it3 + 0];
                    int              i1 = TriOut[it3 + 1];
                    int              i2 = TriOut[it3 + 2];
                    /////
                    //                    UIntAmat Inum  =  UIntAmat(pOut[i0], pOut[i1], pOut[i2], SMOOTH_ORDER);
                    //                    const double*   gam = Inum.IntegrateGammaLinear(p[k0], p[k1], p[k2]);
                    const double*   gam = Inum.IntegrateGammaLinear(pOut[i0], pOut[i1], pOut[i2]);
                    ////                    const double gam[9] = {0.,0.,0., 0.,0.,0., 0.,0.,0.};
                    /////
                    Bvec.Data[n0] += (gam[0] + gam[3] + gam[6]) * CurDensrestPI4;
                    Bvec.Data[n1] += (gam[1] + gam[4] + gam[7]) * CurDensrestPI4;
                    Bvec.Data[n2] += (gam[2] + gam[5] + gam[8]) * CurDensrestPI4;

                    if(i0 == ipx) { Bvec.Data[n0] += gam[0] * CurDensxPI4; Bvec.Data[n1] += gam[1] * CurDensxPI4; Bvec.Data[n2] += gam[2] * CurDensxPI4; }
                    if(i1 == ipx) { Bvec.Data[n0] += gam[3] * CurDensxPI4; Bvec.Data[n1] += gam[4] * CurDensxPI4; Bvec.Data[n2] += gam[5] * CurDensxPI4; }
                    if(i2 == ipx) { Bvec.Data[n0] += gam[6] * CurDensxPI4; Bvec.Data[n1] += gam[7] * CurDensxPI4; Bvec.Data[n2] += gam[8] * CurDensxPI4; }
                }
            }
        }
    }
    return ImpOneInv*Bvec;
}

UMatrix UBemMatrix3::GetBvec(double Current, UVector3 x1, UVector3 x2) 
/*
Set the right hand side for the case of EIT
*/
{
    if(this==NULL || error!=U_OK)  UMatrix(U_ERROR);

    UMatrix Bvec(DNULL, Npot, 1);
    if(Bvec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Creating output matrix. \n"); 
        return UMatrix(U_ERROR);
    }

    int jout = GetOuterSurf();
    UNestedSurface Sout(*GetNestedSurface(jout));
    if(Sout.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting outer surface. \n"); 
        return UMatrix(U_ERROR);
    }

    double DistMin = -1;
    int    it1     =  Sout.GetClosestTriangle(x1, &DistMin, false); // Unsigned distance
    int    it2     =  Sout.GetClosestTriangle(x2, &DistMin, false);
    if(it1<0 || it2<0 || DistMin<0.)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting closest triangle(s). \n"); 
        return UMatrix(U_ERROR);
    }

    if(UseMonoLayer)
    {
        if(PInter==U_POTINTER_CONSTANT)
        {
            Bvec.Data[joffset[jout]+it1] =  Current;
            Bvec.Data[joffset[jout]+it2] = -Current;
        }
        else
        {
            double DistMin = -1;
            int    ip1     =  Sout.GetClosestPoint(x1, &DistMin, false); // Unsigned distance
            int    ip2     =  Sout.GetClosestPoint(x2, &DistMin, false);

            int    NN1     = 0;
            int    NN2     = 0;
            int*   Neig1   = Sout.GetVertexAdjacentTriangles(ip1, &NN1);
            int*   Neig2   = Sout.GetVertexAdjacentTriangles(ip2, &NN2);

            if(Neig1==NULL || Neig2==NULL)
            {
                delete[] Neig1; delete[] Neig2;
                CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting neighbors of x1 and/or x2. \n"); 
                return UMatrix(U_ERROR);
            }
            double A1 = 0; for(int nn=0; nn<NN1; nn++) A1 += Sout.GetArea(Neig1[nn])/3;
            double A2 = 0; for(int nn=0; nn<NN2; nn++) A2 += Sout.GetArea(Neig2[nn])/3;
            delete[] Neig1; delete[] Neig2;
            if(A1>0) A1 = Current/A1;
            if(A2>0) A2 = Current/A2;
            UMatrix RHS = Sout.GetOverlapCollumn(ip1)*A1 - Sout.GetOverlapCollumn(ip2)*A2;
            Bvec.SetData(joffset[jout], 0, RHS);
        }
        return Bvec;
    }

    UMatrix ImpOneInv      = GetImprodHOne(true);
    const UVector3* pOut   = Sout.GetPoints();
    const int*      TriOut = Sout.GetTriList();
    if(pOut==NULL || TriOut==NULL || ImpOneInv.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting points from outer surface or getting improducts. \n");
        return UMatrix(U_ERROR);
    }

    UVector3 p10 = pOut[TriOut[3*it1  ]];
    UVector3 p11 = pOut[TriOut[3*it1+1]];
    UVector3 p12 = pOut[TriOut[3*it1+2]];
    UVector3 p20 = pOut[TriOut[3*it2  ]];
    UVector3 p21 = pOut[TriOut[3*it2+1]];
    UVector3 p22 = pOut[TriOut[3*it2+2]];

    UBEMIntegral BI;
    double Area1 = BI.ComputeArea(p10, p11, p12)*PI4;
    double Area2 = BI.ComputeArea(p20, p21, p22)*PI4;

    if(SmoothB==U_SMOOTH_RAW)       
    {
        UVector3* pView  = GetPointsCopy(-1);
        if(pView==NULL) return UMatrix(U_ERROR);

        for(int n=0; n<Npot; n++)  
        {
            double G1    = BI.ComputeGamma(p10-pView[n], p11-pView[n],  p12-pView[n]);
            double G2    = BI.ComputeGamma(p20-pView[n], p21-pView[n],  p22-pView[n]);
            Bvec.Data[n] = Current * (G1/Area1 - G2/Area2);                 // Convert current to to current density
        }
        delete[] pView;
        return ImpOneInv*Bvec;
    }

    /* Smoothing*/
    UIntBVec     Inum(p10, p11, p12, p20, p21, p22, SMOOTH_ORDER);

    double *Bv = Bvec.Data;
    switch(PInter)
    {
    case U_POTINTER_CONSTANT:
    for(int j=0; j<Nsurfaces; j++)
    {
        UNestedSurface* g = pSurface[j];
        const UVector3* p = g->GetPoints();

        const int *TriList = g->GetTriList();
        for(int k=0; k<g->GetNtri(); k++) 
        {
            int k0 = TriList[3*k  ];
            int k1 = TriList[3*k+1];
            int k2 = TriList[3*k+2];

            const double *Integ = Inum.IntegrateGammaConst(p[k0], p[k1], p[k2]);

            *Bv++ = Current*(Integ[0]/Area1 - Integ[1]/Area2); // Convert current to to current density
        }
    }
    break;

    case U_POTINTER_LINEAR:
    Bv = Bvec.Data;
    for(int j=0; j<Nsurfaces; j++)
    {
        UNestedSurface*     g = pSurface[j];
        const UVector3*     p = g->GetPoints();

        const int    *TriList = g->GetTriList();
        for(int k=0; k<g->GetNtri(); k++) 
        {
            int k0 = TriList[3*k  ];
            int k1 = TriList[3*k+1];
            int k2 = TriList[3*k+2];

            const double* Integ = Inum.IntegrateGammaLinear(p[k0], p[k1], p[k2]);
            Bv[joffset[j]+k0] += Current*(Integ[0]/Area1 - Integ[3]/Area2); // Convert current to to current density
            Bv[joffset[j]+k1] += Current*(Integ[1]/Area1 - Integ[4]/Area2);
            Bv[joffset[j]+k2] += Current*(Integ[2]/Area1 - Integ[5]/Area2);
        }
    }
    break;
    }
    return ImpOneInv*Bvec;
}

UMatrix UBemMatrix3::GetBvec(const UDipole& dip, DerivType deriv, double DipCond) const
/*   
Compute the right hand side of the system matrix in case of a dipole source,
which is the potential due to a dipole in an infinite medium.
The "realistic model potential" can subsequently obtained by calling
UBemField::GetPotential() (assuming that SetAmat() was called before the call to GetBvec()).
*/
{
    if(this==NULL || error!=U_OK)  return UMatrix(U_ERROR);

    if(dip.GetDipoleType()==UDipole::Magnetic) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Programming error. Magnetic dipoles need no realistic models.\n");
        return UMatrix(U_ERROR);
    }
    UMatrix ImpOneInv;
    if(UseMonoLayer)
    {
        if(SmoothA!=U_SMOOTH_SMOOTH || SmoothB!=U_SMOOTH_SMOOTH)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Galerking smoothing required for MonoLayer approach. \n"); 
            return UMatrix(U_ERROR);
        }
        bool CondFound = false;
        for(int j=0; j<Nsurfaces; j++)
        {
            if(pSurface[j]->GetInnerCond()!=DipCond) continue;
            CondFound = true; 
            break;
        }
        if(CondFound==false)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Compartment with conductivity %f not found in MonoLayer approach. \n", DipCond); 
            return UMatrix(U_ERROR);
        }
    }
    else
    {
        ImpOneInv = GetImprodHOne(true);
        if(ImpOneInv.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Getting improducts. \n");
            return UMatrix(U_ERROR);
        }
    }

    int Ncomp = GetNcomp(deriv, dip);
    UMatrix Bvec(DNULL, Npot, Ncomp);
    if(Bvec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Creating output matrix. \n"); 
        return UMatrix(U_ERROR);
    }

    UVector3  xd = dip.Getx();
    UVector3  dd = dip.Getd();
    UDipole dipC = UDipole(xd, dd, UDipole::Current);

    /* Compute right hand side for single dipole */
    if(SetRHSSingleDip(dipC, deriv, Bvec.Data, DipCond)!=U_OK)
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Setting single dipole right hand side. \n");
        return UMatrix(U_ERROR);
    }
    if(dip.GetDipoleType()==UDipole::Current) 
    {
        if(UseMonoLayer) return Bvec;
        else             return ImpOneInv*Bvec;
    }

    /* Add symmetric part */
    UMatrix     BvecM(DNULL, Npot, Ncomp);

    if(dip.GetDipoleType()==UDipole::Symmetric)
    {
        dd.MirrorY(); 
        xd.MirrorY();
        UDipole dipM = UDipole(xd, dd, UDipole::Current);
        if(SetRHSSingleDip(dipM, deriv, BvecM.Data, DipCond)!=U_OK)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Setting symmetric counter part of current dipole. \n");
            return UMatrix(U_ERROR);
        }

        switch(deriv)
        {
        case D_OriPos00:
        for(int i=0; i<Npot; i++) Bvec.Data[i] += BvecM.Data[i];
        break;

        case D_OriPos10:
        case D_OriPos01:
        for(int i=0; i<Npot; i++)   
        {
            Bvec.Data[3*i  ] += BvecM.Data[3*i  ] ;
            Bvec.Data[3*i+1] -= BvecM.Data[3*i+1] ;
            Bvec.Data[3*i+2] += BvecM.Data[3*i+2] ;
        }
        break;

        case D_OriPos11:
        for(int i=0; i<Npot; i++)   
        {
            Bvec.Data[9*i  ] += BvecM.Data[9*i  ];
            Bvec.Data[9*i+1] -= BvecM.Data[9*i+1];
            Bvec.Data[9*i+2] += BvecM.Data[9*i+2];

            Bvec.Data[9*i+3] -= BvecM.Data[9*i+3];
            Bvec.Data[9*i+4] += BvecM.Data[9*i+4];
            Bvec.Data[9*i+5] -= BvecM.Data[9*i+5];

            Bvec.Data[9*i+6] += BvecM.Data[9*i+6];
            Bvec.Data[9*i+7] -= BvecM.Data[9*i+7];
            Bvec.Data[9*i+8] += BvecM.Data[9*i+8];
        }
        break;

        default:
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Combination not implemented: Dtype = %d, deriv = %d .\n",dip.GetDipoleType(), deriv);
        return UMatrix(U_ERROR);
        }
        if(UseMonoLayer) return Bvec;
        else             return ImpOneInv*Bvec;
    }

    if(dip.GetDipoleType()==UDipole::SymmetricPos)
    {
        dd = dip.GetdSym();
        xd.MirrorY();
        UDipole dipM = UDipole(xd, dd, UDipole::Current);        
        if(SetRHSSingleDip(dipM, deriv, BvecM.Data, DipCond)!=U_OK)
        {
            CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Setting semi-symmetric counter part of current dipole. \n");
            return UMatrix(U_ERROR);
        }

        switch(deriv)
        {
        case D_OriPos00:
        for(int i=0; i<Npot; i++) Bvec.Data[i] += BvecM.Data[i];
        break;

        case D_OriPos10:
        for(int i=Npot-1; i>=0; i--)   
        {
            Bvec.Data[6*i  ] = Bvec .Data[3*i  ] ;
            Bvec.Data[6*i+1] = Bvec .Data[3*i+1] ;
            Bvec.Data[6*i+2] = Bvec .Data[3*i+2] ;
            Bvec.Data[6*i+3] = BvecM.Data[3*i  ] ;
            Bvec.Data[6*i+4] = BvecM.Data[3*i+1] ;
            Bvec.Data[6*i+5] = BvecM.Data[3*i+2] ;
        }
        break;

        case D_OriPos01:
        for(int i=0; i<Npot; i++)   
        {
            Bvec.Data[3*i  ] += BvecM.Data[3*i  ] ;
            Bvec.Data[3*i+1] -= BvecM.Data[3*i+1] ;
            Bvec.Data[3*i+2] += BvecM.Data[3*i+2] ;
        }
        break;

        case D_OriPos11:
        for(int i=Npot-1; i>=0; i--)   
        {
            Bvec.Data[18*i   ] = Bvec .Data[9*i  ] ;
            Bvec.Data[18*i+ 1] = Bvec .Data[9*i+1] ;
            Bvec.Data[18*i+ 2] = Bvec .Data[9*i+2] ;
            Bvec.Data[18*i+ 3] = Bvec .Data[9*i+3] ;
            Bvec.Data[18*i+ 4] = Bvec .Data[9*i+4] ;
            Bvec.Data[18*i+ 5] = Bvec .Data[9*i+5] ;
            Bvec.Data[18*i+ 6] = Bvec .Data[9*i+6] ;
            Bvec.Data[18*i+ 7] = Bvec .Data[9*i+7] ;
            Bvec.Data[18*i+ 8] = Bvec .Data[9*i+8] ;
            Bvec.Data[18*i+ 9] = BvecM.Data[9*i  ] ;
            Bvec.Data[18*i+10] =-BvecM.Data[9*i+1] ;
            Bvec.Data[18*i+11] = BvecM.Data[9*i+2] ;
            Bvec.Data[18*i+12] = BvecM.Data[9*i+3] ;
            Bvec.Data[18*i+13] =-BvecM.Data[9*i+4] ;
            Bvec.Data[18*i+14] = BvecM.Data[9*i+5] ;
            Bvec.Data[18*i+15] = BvecM.Data[9*i+6] ;
            Bvec.Data[18*i+16] =-BvecM.Data[9*i+7] ;
            Bvec.Data[18*i+17] = BvecM.Data[9*i+8] ;
        }
        break;

        default:
        CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Combination not implemented: Dtype = %d, deriv = %d .\n",dip.GetDipoleType(), deriv);
        return UMatrix(U_ERROR);
        }
        if(UseMonoLayer) return Bvec;
        else             return ImpOneInv*Bvec;
    }
    CI.AddToLog("ERROR: UBemMatrix3::GetBvec(). Combination not implemented: Dtype = %d, deriv = %d .\n",dip.GetDipoleType(), deriv);
    return UMatrix(U_ERROR);
}

ErrorType  UBemMatrix3::SetRHSSingleDip(const UDipole& dip, DerivType der, double* RHS, double DipCond) const
/*   
Compute the right hand side RHS[] of the system matrix for the single (Current) dipole 
case. In case of (semi) symmetric dipoles, SetRHSSingleDip() should be called two 
times and the results should be properly combined.
*/
{
    if(this==NULL || error!=U_OK)  return U_ERROR;

    if(dip.GetDipoleType()==UDipole::Magnetic) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetRHSSingleDip(). Magnetic dipoles need no realistic models.\n");
        return U_ERROR;
    }
    if(dip.GetDipoleType()!=UDipole::Current) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetRHSSingleDip(). This function should only be called with single dipole.\n");
        return U_ERROR;
    }   
    if(RHS==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetRHSSingleDip(). NULL argument.\n");
        return U_ERROR;
    }
    if(UseMonoLayer && DipCond<=0.)
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetRHSSingleDip(). Invalid conductivity for MonoLayer approach: DipCond = %f  \n", DipCond); 
        return U_ERROR;
    }

    int Ncomp = GetNcomp(der, UDipole::Current);
    for(int i=0; i<Ncomp*Npot; i++) RHS[i] = 0.;

    if(SmoothB==U_SMOOTH_RAW)       
    {
        UVector3* p  = GetPointsCopy(-1);
        if(p==NULL) 
        {
            CI.AddToLog("ERROR: UBemMatrix3::SetRHSSingleDip(). Getting discretization points.\n");
            return U_ERROR;
        }

        UVector3 xdip = dip.Getx();
        UVector3 ddip = dip.Getd();
        double*  Bv   = RHS;
        for(int n=0; n<Npot; n++)  
        {
            UVector3 xx    = p[n]-xdip;
            double   r     = xx.GetNorm();
            double   fact  = 1./(r*r*r*PI4);

            switch(der)
            {
            case D_OriPos00: 
            *Bv++ = ( ddip&xx ) * fact;
            break;

            case D_OriPos10:
            *Bv++  = xx.Getx()*fact;
            *Bv++  = xx.Gety()*fact;
            *Bv++  = xx.Getz()*fact;
            break;

            case D_OriPos01:
            {
                UVector3 emf = ddip*fact;
                fact   *= -3.*(ddip&xx)/(r*r);
                emf    += xx *fact;
                *Bv++  = -emf.Getx();
                *Bv++  = -emf.Gety();
                *Bv++  = -emf.Getz();
            }
            break;

            case D_OriPos11: 
            {
                double fac2  = -3*fact/(r*r);
                *Bv++  = -xx.Getx()*xx.Getx()*fac2 - fact;
                *Bv++  = -xx.Gety()*xx.Getx()*fac2;
                *Bv++  = -xx.Getz()*xx.Getx()*fac2;
                *Bv++  = -xx.Getx()*xx.Gety()*fac2;
                *Bv++  = -xx.Gety()*xx.Gety()*fac2 - fact;
                *Bv++  = -xx.Getz()*xx.Gety()*fac2;
                *Bv++  = -xx.Getx()*xx.Getz()*fac2;
                *Bv++  = -xx.Gety()*xx.Getz()*fac2;
                *Bv++  = -xx.Getz()*xx.Getz()*fac2 - fact;
            }
            break;

            case D_OriPos02: // Not yet implemented
            case D_OriPos20: // Results identically zero
            {
                for(int k=0; k<Ncomp; k++) *Bv++ = 0.;
            }
            }
        }
        delete[] p;
        return U_OK;
    }

    UIntBVec     Inum(dip, der, UseMonoLayer, SMOOTH_ORDER);

    double *Bv = RHS;
    switch(PInter)
    {
    case U_POTINTER_CONSTANT:
    for(int j=0; j<Nsurfaces; j++)
    {
        UNestedSurface*  g     = pSurface[j];
        const UVector3*  p     = g->GetPoints();
        double           Delta = g->GetOuterCond() - g->GetInnerCond();

        const int *TriList = g->GetTriList();
        for(int k=0; k<g->GetNtri(); k++) 
        {
            int     k0 = TriList[3*k  ];
            int     k1 = TriList[3*k+1];
            int     k2 = TriList[3*k+2];
            const double *Integ = NULL;
            if(UseMonoLayer)
            {
                UVector3 N = ( (p[k1]-p[k0])^(p[k2]-p[k0]) ); N.Normalize(); N*=(Delta/DipCond);  // Implicitly multiply normal with triangle area
                Integ      = Inum.IntegrateDipConst(p[k0], p[k1], p[k2], N);
            }
            else
                Integ      = Inum.IntegrateDipConst(p[k0], p[k1], p[k2]);

            for(int nk=0; nk<Ncomp; nk++) *Bv++ = Integ[nk];
        }
    }
    break;

    case U_POTINTER_LINEAR:
    for(int j=0; j<Nsurfaces; j++)
    {
        UNestedSurface*      g = pSurface[j];
        const UVector3*      p = g->GetPoints();
        double           Delta = g->GetOuterCond() - g->GetInnerCond();

        const int    *TriList = g->GetTriList();
        for(int k=0; k<g->GetNtri(); k++) 
        {
            int k0 = TriList[3*k  ];
            int k1 = TriList[3*k+1];
            int k2 = TriList[3*k+2];

            const double *Integ = NULL;
            if(UseMonoLayer)
            {
                UVector3 N = ( (p[k1]-p[k0])^(p[k2]-p[k0]) ); N.Normalize(); N*= (Delta/DipCond);  // Implicitly multiply normal with triangle area
                Integ      = Inum.IntegrateDipLinear(p[k0], p[k1], p[k2], N);
            }
            else
                Integ      = Inum.IntegrateDipLinear(p[k0], p[k1], p[k2]);

            for(int nk=0; nk<Ncomp; nk++)
            {
                RHS[Ncomp*(joffset[j]+k0)+nk] += Integ[3*nk+0];
                RHS[Ncomp*(joffset[j]+k1)+nk] += Integ[3*nk+1];
                RHS[Ncomp*(joffset[j]+k2)+nk] += Integ[3*nk+2];
            }
        }
    }
    break;
    }
    return U_OK;
}

ErrorType UBemMatrix3::SetAmat(double* Amat, bool NoOutput, const double* DefaultSigmas) const
/*
Compute the BEM matrix, for a conductor consisting of a set of nested surfaces. The 
conductivities and geometries of the conductor are present in UConductor3, which
is a base class of UBemMatrix3.

The computed matrix can be used for EIT and for EEG modelling. 
PInter  determines the way the potentials are interpolated over each triangle

if(DefaultSigmas) Replace actual conductivities by those stored in DefaultSigmas[]

Notes:
-It is assumed that the surfaces are non-intersecting and that the
inner and outer conductivities are attributed in a consistent way.

return   U_OK    on OK
U_ERROR on ERROR
*/
{
    if(this==NULL || error!=U_OK)  return U_ERROR;

    if(Amat==NULL)
    {
        CI.AddToLog("ERROR: UBemMatrix3::SetAmat(). NULL argument. \n");
        return U_ERROR;
    }
    if(NoOutput==false) 
    {
        CI.AddToLog("UBemMatrix3::SetAmat()\n Npoints: \n");
        CI.AddToLog("%d",joffset[1]-joffset[0]);
        for(int is=1; is<Nsurfaces; is++)
            CI.AddToLog(" + %d",joffset[is+1]-joffset[is]);
        CI.AddToLog(" = %d \n",joffset[Nsurfaces]);
        CI.TimeReset("Build system matrix \n");
    }

    UBEMIntegral Iana;

    /* Initialize matrix */
    for(int m=0;m<Npot*Npot;m++) Amat[m] = 0.;

    switch(PInter)
    {
    case U_POTINTER_CONSTANT:
    /* On each triangle, one integral has to be computed */

    for(int j2=0;j2<Nsurfaces;j2++)                 /* First loop over all viewed triangles */
    {
        const UNestedSurface* g2 = pSurface[j2];
        const UVector3*       p2 = g2->GetPoints();
        const int*      TriList2 = g2->GetTriList(); 
        for(int n=0, n3=0;n<pSurface[j2]->GetNtri();n++,n3+=3)
        {
            int i0 = TriList2[n3  ];
            int i1 = TriList2[n3+1];
            int i2 = TriList2[n3+2];

            UIntAmat Inum = (SmoothA==U_SMOOTH_RAW) ? UIntAmat() : UIntAmat(p2[i0], p2[i1], p2[i2], SMOOTH_ORDER);

            for(int j1=0;j1<Nsurfaces;j1++)         /* Second loop over all view points */
            {
                const UNestedSurface*  g1 = pSurface[j1];
                const UVector3*        p1 = g1->GetPoints();
                const int*       TriList1 = g1->GetTriList(); 
                for(int m=0, m3=0;m<pSurface[j1]->GetNtri();m++,m3+=3)
                {
                    if(j2==j1 && m==n) continue;   /* diagonals are computed separately. */            

                    int k0 = TriList1[m3  ];
                    int k1 = TriList1[m3+1];
                    int k2 = TriList1[m3+2];

                    /* Compute the (smoothed) solid angle */
                    double om=0;
                    if(SmoothA==U_SMOOTH_RAW) // U_POTINTER_CONSTANT,  SmoothA==U_SMOOTH_RAW
                    {
                        UVector3 yview = (p1[k0]+p1[k1]+p1[k2])/3.;
                        UVector3 y0    = p2[i0] - yview;
                        UVector3 y1    = p2[i1] - yview;
                        UVector3 y2    = p2[i2] - yview;
                        om             = Iana.ComputeSolid(y0, y1, y2);
                    }
                    else              // U_POTINTER_CONSTANT,  SmoothA!=U_SMOOTH_RAW
                    {
                        om             = Inum.IntegrateOmegConst(p1[k0], p1[k1], p1[k2]);
                    }
                    Amat[(joffset[j1]+m)*Npot + joffset[j2]+n] += om;
                }
            }
        }
    }
    break;

    case U_POTINTER_LINEAR:

    if(SmoothA==U_SMOOTH_RAW)// U_POTINTER_LINEAR,  SmoothA==U_SMOOTH_RAW
    {
        /* On each triangle, three integrals have to be computed */
        for(int j2=0;j2<Nsurfaces;j2++)                 /* Loop over all viewed triangles */
        {
            const UNestedSurface*  g2 = pSurface[j2];
            const UVector3*        p2 = g2->GetPoints();
            const int*       TriList2 = g2->GetTriList(); 

            for(int n=0, n3=0;n<pSurface[j2]->GetNtri();n++,n3+=3)
            {
                int i0 = TriList2[n3  ];
                int i1 = TriList2[n3+1];
                int i2 = TriList2[n3+2];

                for(int j1=0;j1<Nsurfaces;j1++)         /* Loop over all (view) points */
                {                
                    const UNestedSurface* g1 = pSurface[j1];
                    const UVector3*       p1 = g1->GetPoints();
                    for(int m=0;m<pSurface[j1]->GetNpoints();m++)
                    {
                        if(j2==j1)                     /* diagonals are computed separately. */
                        {
                            if(i0==m) continue;
                            if(i1==m) continue;
                            if(i2==m) continue;
                        }

                        /* subtract view point p1[m] from all three triangle corners. */                           
                        double om0 = 0, om1=0, om2=0;
                        UVector3 y0    = p2[i0] - p1[m];
                        UVector3 y1    = p2[i1] - p1[m];
                        UVector3 y2    = p2[i2] - p1[m];
                        Iana.ComputeLinear(y0,y1,y2,&om0,&om1,&om2);

                        Amat[(joffset[j1]+m)*Npot + joffset[j2]+i0] += om0;
                        Amat[(joffset[j1]+m)*Npot + joffset[j2]+i1] += om1;
                        Amat[(joffset[j1]+m)*Npot + joffset[j2]+i2] += om2;
                    }
                }
            }
        }            
    }
    else // U_POTINTER_LINEAR,  SmoothA!=U_SMOOTH_RAW
    {
        /* For each combination of two triangles, compute nine integrals*/

        for(int j2=0;j2<Nsurfaces;j2++)                 /* First loop over all viewed triangles */
        {
            const UNestedSurface* g2 = pSurface[j2];
            const UVector3*       p2 = g2->GetPoints();
            const int*      TriList2 = g2->GetTriList(); 

            for(int n=0,n3=0;n<pSurface[j2]->GetNtri();n++,n3+=3)
            {
                int i0 = TriList2[n3  ];
                int i1 = TriList2[n3+1];
                int i2 = TriList2[n3+2];

                UIntAmat Inum(p2[i0], p2[i1], p2[i2], SMOOTH_ORDER);

                for(int j1=0;j1<Nsurfaces;j1++)         /* Second loop over all view points */
                {                
                    const UNestedSurface*  g1 = pSurface[j1];
                    const UVector3*        p1 = g1->GetPoints();
                    const int*       TriList1 = g1->GetTriList(); 
                    for(int m=0, m3=0;m<pSurface[j1]->GetNtri();m++,m3+=3)
                    {
                        if(j2==j1 && m==n) /* diagonals are computed separately, but in this case there are non-vanishing neighboring matrix elements. */
                        {
                            double delta =  DefaultSigmas ? (DefaultSigmas[j2]  -  DefaultSigmas[Nsurfaces+j2]) : (g2->GetOuterCond() - g2->GetInnerCond());
                            double sum   =  DefaultSigmas ? (DefaultSigmas[j2]  +  DefaultSigmas[Nsurfaces+j2]) : (g2->GetOuterCond() + g2->GetInnerCond());
                            double Area  =  GetArea(p2[i0], p2[i1], p2[i2]);
                            double Elem  =  sum * PI4 * Area/(24.*delta);  //checked 24., and PI4 and sign (positive)

                            Amat[(joffset[j2]+i0)*Npot + joffset[j2]+i1] += Elem;
                            Amat[(joffset[j2]+i1)*Npot + joffset[j2]+i0] += Elem;
                            Amat[(joffset[j2]+i1)*Npot + joffset[j2]+i2] += Elem;
                            Amat[(joffset[j2]+i2)*Npot + joffset[j2]+i1] += Elem;
                            Amat[(joffset[j2]+i2)*Npot + joffset[j2]+i0] += Elem;
                            Amat[(joffset[j2]+i0)*Npot + joffset[j2]+i2] += Elem;
                        }
                        else
                        {
                            int k0 = TriList1[m3  ];
                            int k1 = TriList1[m3+1];
                            int k2 = TriList1[m3+2];

                            const double* om    = Inum.IntegrateOmegLinear(p1[k0], p1[k1], p1[k2]);

                            Amat[(joffset[j1]+k0)*Npot + joffset[j2]+i0] += om[0];
                            Amat[(joffset[j1]+k1)*Npot + joffset[j2]+i0] += om[1];
                            Amat[(joffset[j1]+k2)*Npot + joffset[j2]+i0] += om[2];
                            Amat[(joffset[j1]+k0)*Npot + joffset[j2]+i1] += om[3];
                            Amat[(joffset[j1]+k1)*Npot + joffset[j2]+i1] += om[4];
                            Amat[(joffset[j1]+k2)*Npot + joffset[j2]+i1] += om[5];
                            Amat[(joffset[j1]+k0)*Npot + joffset[j2]+i2] += om[6];
                            Amat[(joffset[j1]+k1)*Npot + joffset[j2]+i2] += om[7];
                            Amat[(joffset[j1]+k2)*Npot + joffset[j2]+i2] += om[8];
                        }
                    }
                }
            }
        }
    }
    break;
    }
    for(int m=0;m<Npot*Npot;m++) Amat[m] /= PI4;

    /* Multiply with SIGMA diagonal matrix */
    for(int j2=0;j2<Nsurfaces;j2++)                 /* First loop over all triangles */
    {
        const UNestedSurface* g2 = pSurface[j2];
        double             delta = DefaultSigmas ? (DefaultSigmas[j2]-DefaultSigmas[Nsurfaces+j2]) : (g2->GetOuterCond() - g2->GetInnerCond());
        for(int n=0;n<GetNpot(j2);n++)
        {
            for(int j1=0;j1<Nsurfaces;j1++)         /* Second loop over all view points */
            {                
                for(int m=0;m<GetNpot(j1);m++) Amat[(joffset[j1]+m)*Npot + joffset[j2]+n] *= delta;
            }
        }
    }

    /* Diagonal elements: */
    for(int m=0;m<Npot;m++)
    {
        double sum = 0.;
        for(int n=0;n<Npot;n++) {if(n!=m) sum += Amat[m*Npot+n];}
        Amat[m*Npot+m] = -sum;
    }

    if(SmoothA==U_SMOOTH_SMOOTH) // Otherwise you get identity matrix
    {
        UMatrix ImpOneInv = GetImprodHOne(true);
        for(int m=0;m<Npot;m++)
            for(int n=0;n<Npot;n++) Amat[m*Npot+n] *= ImpOneInv.Data[m];
    }
    /***
    for(int m=0;m<Npot;m++)
    {
    double test0=0;
    for(int n=joffset[0];n<joffset[1];n++) {test0 += Amat[m*Npot+n];}

    double test1=0;
    for(int n=joffset[1];n<joffset[2];n++) {test1 += Amat[m*Npot+n];}

    double test2=0;
    for(int n=joffset[2];n<joffset[3];n++) {test2 += Amat[m*Npot+n];}

    if(DefaultSigmas) 
    {
    if(joffset[1]<=m && m<joffset[2]) test1 -= DefaultSigmas[4];
    if(joffset[2]<=m && m<joffset[3]) test2 -= DefaultSigmas[5];
    test0 /= ( DefaultSigmas[0] - DefaultSigmas[Nsurfaces+0] );
    test1 /= ( DefaultSigmas[1] - DefaultSigmas[Nsurfaces+1] );
    test2 /= ( DefaultSigmas[2] - DefaultSigmas[Nsurfaces+2] );

    double Test = 66;
    }
    else 
    {
    if(joffset[1]<=m && m<joffset[2]) test1 -= pSurface[1]->GetInnerCond();
    if(joffset[2]<=m && m<joffset[3]) test2 -= pSurface[2]->GetInnerCond();
    test0 /= ( pSurface[0]->GetOuterCond() - pSurface[0]->GetInnerCond() );
    test1 /= ( pSurface[1]->GetOuterCond() - pSurface[1]->GetInnerCond() );
    test2 /= ( pSurface[2]->GetOuterCond() - pSurface[2]->GetInnerCond() );

    double Test = 66;
    }
    }
    /***/
    if(NoOutput==false) CI.TimeFlag("Build system matrix \n");

    /* Deflation:*/
    double deflat = 1./Npot;
    for(int m=0;m<Npot*Npot;m++) Amat[m] += deflat;

    return error;
}
int UBemMatrix3::GetNpot(int jsurf) const
{
    if(this==NULL || error!=U_OK)  return 0;

    if(jsurf<0) return Npot;
    return joffset[jsurf+1]-joffset[jsurf];
}

UVector3* UBemMatrix3::GetPointsCopy(int jsurf) const 
/*
Return a pointer to a new array of points, corresponding to the
points defining surface jsurf.
If(jsurf<0) return a pointer to all points.

Return NULL on any error;
*/
{
    if(this==NULL || error!=U_OK)  return NULL;

    if(jsurf>=Nsurfaces) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetPointsCopy(). Argument out of range (%d)\n",jsurf); 
        return NULL;
    }

    int      np     = GetNpot(jsurf);
    UVector3 *Pcopy = new UVector3[np];
    if(Pcopy==NULL) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::GetPointsCopy(). Memory allocation, np=%d\n",np); 
        return NULL;
    }
    int jstart = 0;
    int jend   = Nsurfaces;
    if(jsurf>=0)
    {
        jstart = jsurf;
        jend   = jsurf+1;
    }

    int n=0;
    for(int j=jstart; j<jend; j++)
    {
        UNestedSurface* g = pSurface[j];
        const UVector3* p = g->GetPoints();
        if(p==NULL) return NULL;

        if(PInter==U_POTINTER_LINEAR) 
        {
            for(int k=0; k<g->GetNpoints(); k++) Pcopy[n++] = p[k];
        }
        else if(PInter==U_POTINTER_CONSTANT) 
        {
            const int *TriList = g->GetTriList();
            for(int k=0; k<g->GetNtri(); k++) 
            {
                int k0 = TriList[3*k  ];
                int k1 = TriList[3*k+1];
                int k2 = TriList[3*k+2];
                Pcopy[n++]  = (p[k0]+p[k1]+p[k2])/3.;
            }
        }
    }
    return Pcopy;
}

ErrorType UBemMatrix3::UpdateMatSize(void)
/*
Update the alloctated memory required for the system matrices.
Update the "start addresses" of the surfaces joffset[].
The contents of these matrices is deleted.
*/
{
    if(this==NULL || error!=U_OK)  return U_ERROR;

    delete[] joffset;
    joffset = new int[Nsurfaces+1];
    if(joffset==NULL) 
    {
        CI.AddToLog("ERROR: UBemMatrix3::UpdateMatSize(). Memory allocation, Nsurfaces=%d\n",Nsurfaces);
        return U_ERROR;
    }
    int np = joffset[0] = 0;    
    for(int j=0;j<Nsurfaces;j++)
    {
        if(PInter==U_POTINTER_LINEAR)        np += pSurface[j]->GetNpoints();
        else if(PInter==U_POTINTER_CONSTANT) np += pSurface[j]->GetNtri();
        joffset[j+1] = np;
    }
    Npot = np;                 
    return U_OK;
}

const UString& UBemMatrix3::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UBemMatrix3-object");
        return Properties;
    }
    Properties   = UString();
    Properties  += UString(" The Conductor: \n") + UConductor3::GetProperties("   ");
    Properties  += UString(" The BEM parameters: \n");
    Properties  += UString(Npot," MatrixSize = %d (squared) \n");

    /* The matrix elements AmatLU:*/    
    Properties += UString(GetPotInterTypeText(PInter)     ,  " MatrixPotentialInterpolation = %s  \n");
    Properties += UString(GetBEMSmoothTypeText(SmoothA)   ,  " MatrixSmoothing              = %s  \n");

    /* The right hand side vector Bvec:*/
    Properties += UString(GetBEMSmoothTypeText(SmoothB)   ,  " VectorSmoothing              = %s  \n");

    if(Comment.IsNULL() || Comment.IsEmpty())     Properties.ReplaceAll('\n', ';');  
    else                                          Properties.InsertAtEachLine(Comment);

    return Properties;
}

int UBemMatrix3::GetNcomp(DerivType deriv, UDipole::DipoleType DT) 
/* 
return the total number of independent partial derivatives,
depending on derivative parameters and the dipole type.
*/
{
    switch(deriv)
    {
    case D_OriPos00: return 1;
    case D_OriPos01: return 3;

    case D_OriPos10:
    if(DT==UDipole::SymmetricPos) return 6;
    else                          return 3;

    case D_OriPos11:
    if(DT==UDipole::SymmetricPos) return 18;
    else                          return  9;

    case D_OriPos02: return 9;

    case D_OriPos20:
    if(DT==UDipole::SymmetricPos) return 36;
    else                          return  9;
    }
    return 0;
}

int UBemMatrix3::GetNcomp(DerivType deriv, const UDipole& dip)
{
    return GetNcomp(deriv, dip.GetDipoleType());
}

void UBemMatrix3::UIntBVec::SetAllMembersDefault()
{
    BType        = U_DIPOLE;
    UseMonoLayer = false;
    NSigma       = UVector3();
    deriv        = D_OriPos00;
    for(int k=0; k<36; k++) Integ[k] = 0.;
    xdip         = UVector3();
    ddip         = UVector3();
    p10=p11=p12  = UVector3();
    p20=p21=p22  = UVector3();
}
void UBemMatrix3::UIntBVec::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UBemMatrix3::UIntBVec::UIntBVec() : UIntegTri()
{
    SetAllMembersDefault();
}
UBemMatrix3::UIntBVec::UIntBVec(const UIntBVec& BV)
{
    SetAllMembersDefault();
    *this = BV;
}
UBemMatrix3::UIntBVec::UIntBVec(const UVector3& f0, const UVector3& f1, const UVector3& f2,
                                const UVector3& s0, const UVector3& s1, const UVector3& s2, int Order) :
    UIntegTri(Order, 2)
{
    SetAllMembersDefault();

    p10   = f0;
    p11   = f1;
    p12   = f2;
    p20   = s0;
    p21   = s1;
    p22   = s2;
    deriv = D_OriPos00;
    BType = U_EIT;
}
UBemMatrix3::UIntBVec::UIntBVec(const UDipole& dip, DerivType der, bool MonoLayer, int Order) :  
    UIntegTri(Order, GetNcomp(der, UDipole::Current))
{
    SetAllMembersDefault();

    xdip         = dip.Getx();
    ddip         = dip.Getd();
    UseMonoLayer = MonoLayer; 
    deriv        = der;
    BType        = U_DIPOLE;
}
UBemMatrix3::UIntBVec::~UIntBVec()
{
    DeleteAllMembers(U_OK);
}
UBemMatrix3::UIntBVec& UBemMatrix3::UIntBVec::operator=(const UIntBVec &BV)
{
    if(this==NULL || &BV==NULL)
    {
        if(this==NULL)
        {
            static UIntBVec DUM; DUM.error = U_ERROR;
            CI.AddToLog("ERROR: UBemMatrix3::UIntBVec::operator=(). this==NULL. \n");
            return DUM;
        }
        DeleteAllMembers(U_ERROR);
        UIntegTri::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UIntBVec::operator=(). this==NULL. \n");
        return *this;
    }
    if(this==&BV) return *this;

    UIntegTri::operator=((UIntegTri) BV);
    if(UIntegTri::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UIntegTri::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UIntBVec::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    BType        = BV.U_DIPOLE;
    UseMonoLayer = BV.UseMonoLayer;
    NSigma       = BV.NSigma;
    deriv        = BV.deriv;
    for(int k=0; k<36; k++) Integ[k] = BV.Integ[k];
    xdip         = BV.xdip;
    ddip         = BV.ddip;
    p10          = BV.p10;
    p11          = BV.p11;
    p12          = BV.p12;
    p20          = BV.p20;
    p21          = BV.p21;
    p22          = BV.p22;

    return *this;
}

//UVector3 UBemMatrix3::UIntBVec::IntegrandVector3(UVector3 x)
//{
//    if(BType==U_DIPOLE)
//    {
//        double r3 = x.GetNorm2();
//        r3       *= sqrt(r3);
//        return x/r3;
//    }
//    return UVector3();
//}

const double* UBemMatrix3::UIntBVec::IntegrateGammaConst(const UVector3& c0, const UVector3& c1, const UVector3& c2) 
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType = U_EIT;

    return IntegrateScalars();
}
const double* UBemMatrix3::UIntBVec::IntegrateGammaLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2) 
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType = U_EIT;

    return IntegrateLinear();
}
const double* UBemMatrix3::UIntBVec::IntegrateDipConst(const UVector3& c0, const UVector3& c1, const UVector3& c2) 
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType = U_DIPOLE;

    return IntegrateScalars();
}
const double* UBemMatrix3::UIntBVec::IntegrateDipConst(const UVector3& c0, const UVector3& c1, const UVector3& c2, const UVector3& NormDipCond)
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType  = U_DIPOLE;
    NSigma = NormDipCond;
    return IntegrateScalars();
}

const double* UBemMatrix3::UIntBVec::IntegrateDipLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2) 
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType = U_DIPOLE;

    return IntegrateLinear();
}
const double* UBemMatrix3::UIntBVec::IntegrateDipLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2, const UVector3& NormDipCond) 
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;
    BType = U_DIPOLE;
    NSigma = NormDipCond;

    return IntegrateLinear();
}

const double* UBemMatrix3::UIntBVec::IntegrandScalars(const UVector3& x)
{
    if(BType==U_DIPOLE)
    {
        UVector3 xx    = x-xdip;
        double   r     = xx.GetNorm();
        double   r2    = r*r;
        double   fact  = 1./(r2*r*PI4);

        if(UseMonoLayer)
        {
            switch(deriv)
            {
            case D_OriPos00: 
            Integ[0]  =  ( (ddip&NSigma) - 3.*(ddip&xx)*(NSigma&xx)/r2 ) * fact;
            break;

            case D_OriPos10:
            {
                UVector3 DD = NSigma + xx* (-3.*(NSigma&xx)/r2) ;
                Integ[0]    = DD.Getx()*fact;
                Integ[1]    = DD.Gety()*fact;
                Integ[2]    = DD.Getz()*fact;
            }
            break;

            case D_OriPos01:
            {
                fact       *= 3/r2;
                double H0   = NSigma&xx    ;
                double H1   = xx    &ddip  ;
                double H2   = ddip  &NSigma;

                UVector3 DD = ddip*(H0*fact) + NSigma*(H1*fact) + xx*( (H2 - 5*H0*H1/r2)*fact );
                Integ[0]    = DD.Getx();
                Integ[1]    = DD.Gety();
                Integ[2]    = DD.Getz();
            }
            break;

            case D_OriPos11:  // Not yet implemented
            {
                for(int k=0; k<36; k++) Integ[k] = 0.;
            }
            break;

            case D_OriPos02: // Not yet implemented
            {
                for(int k=0; k<36; k++) Integ[k] = 0.;
            }
            case D_OriPos20: // Results identically zero
            {
                for(int k=0; k<36; k++) Integ[k] = 0.;
            }
            }
            return Integ;   
        }
        else
        {
            switch(deriv)
            {
            case D_OriPos00: 
            Integ[0] = ( ddip&xx ) * fact;
            break;

            case D_OriPos10:
            Integ[0] = xx.Getx()*fact;
            Integ[1] = xx.Gety()*fact;
            Integ[2] = xx.Getz()*fact;
            break;

            case D_OriPos01:
            {
                UVector3 emf = ddip*fact;
                fact     *= -3.*(ddip&xx)/(r*r);
                emf      += xx *fact;
                Integ[0]  = -emf.Getx();
                Integ[1]  = -emf.Gety();
                Integ[2]  = -emf.Getz();
            }
            break;

            case D_OriPos11: 
            {
                double fac2  = -3*fact/(r*r);
                Integ[0]  = -xx.Getx()*xx.Getx()*fac2 - fact;
                Integ[1]  = -xx.Gety()*xx.Getx()*fac2;
                Integ[2]  = -xx.Getz()*xx.Getx()*fac2;
                Integ[3]  = -xx.Getx()*xx.Gety()*fac2;
                Integ[4]  = -xx.Gety()*xx.Gety()*fac2 - fact;
                Integ[5]  = -xx.Getz()*xx.Gety()*fac2;
                Integ[6]  = -xx.Getx()*xx.Getz()*fac2;
                Integ[7]  = -xx.Gety()*xx.Getz()*fac2;
                Integ[8]  = -xx.Getz()*xx.Getz()*fac2 - fact;
            }
            break;

            case D_OriPos02: // Not yet implemented
            {
                for(int k=0; k<36; k++) Integ[k] = 0.;
            }
            case D_OriPos20: // Results identically zero
            {
                for(int k=0; k<36; k++) Integ[k] = 0.;
            }
            }
            return Integ;   
        }
    }
    else if(BType==U_EIT)
    {
        UBEMIntegral BI;
        Integ[0] = BI.ComputeGamma(p10-x, p11-x,  p12-x);
        Integ[1] = BI.ComputeGamma(p20-x, p21-x,  p22-x);
        return Integ;
    }
    CI.AddToLog("ERROR: UBemMatrix3::UIntBVec::IntegrandScalars(). Inconsistent use of object.\n");
    return NULL;
}

void UBemMatrix3::UIntAmat::SetAllMembersDefault(void)
{
    CompOmeg = true;
    p0 = p1 = p2 = UVector3();
    Integ[0] = Integ[1] = Integ[2] = 0.;
}
void UBemMatrix3::UIntAmat::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UBemMatrix3::UIntAmat::UIntAmat() :  UIntegTri()
{
    SetAllMembersDefault();
}
UBemMatrix3::UIntAmat::UIntAmat(const UIntAmat& AM)
{
    SetAllMembersDefault();
    *this = AM;
}
UBemMatrix3::UIntAmat::UIntAmat(UVector3 x0, UVector3 x1, UVector3 x2, int Order) :  UIntegTri(Order, 3)
{
    SetAllMembersDefault();

    p0 = x0;
    p1 = x1;
    p2 = x2;
}
UBemMatrix3::UIntAmat::~UIntAmat()
{
    DeleteAllMembers(U_OK);
}
UBemMatrix3::UIntAmat& UBemMatrix3::UIntAmat::operator=(const UIntAmat &AM)
{
    if(this==NULL || &AM==NULL)
    {
        if(this==NULL)
        {
            static UIntAmat DUM; DUM.error = U_ERROR;
            CI.AddToLog("ERROR: UBemMatrix3::UIntAmat::operator=(). this==NULL. \n");
            return DUM;
        }
        DeleteAllMembers(U_ERROR);
        UIntegTri::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UIntAmat::operator=(). this==NULL. \n");
        return *this;
    }
    if(this==&AM) return *this;

    UIntegTri::operator=((UIntegTri) AM);
    if(UIntegTri::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UIntegTri::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemMatrix3::UIntAmat::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    CompOmeg = AM.CompOmeg;
    p0       = AM.p0;
    p1       = AM.p1;
    p2       = AM.p2;

    Integ[0] = AM.Integ[0];
    Integ[1] = AM.Integ[1];
    Integ[2] = AM.Integ[2];
    return *this;
}

double UBemMatrix3::UIntAmat::IntegrateOmegConst(const UVector3& c0, const UVector3& c1, const UVector3& c2)
{
    if(SetCorners(c0, c1, c2)!=U_OK) return 0.;

    CompOmeg = true;
    return IntegrateScalar();
}

double UBemMatrix3::UIntAmat::IntegrateGammaConst(const UVector3& c0, const UVector3& c1, const UVector3& c2)
{
    if(SetCorners(c0, c1, c2)!=U_OK) return 0.;

    CompOmeg = false;
    return IntegrateScalar();
}

const double* UBemMatrix3::UIntAmat::IntegrateOmegLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2)
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;

    CompOmeg = true;
    return IntegrateLinear();
}

const double* UBemMatrix3::UIntAmat::IntegrateGammaLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2)
{
    if(SetCorners(c0, c1, c2)!=U_OK) return NULL;

    CompOmeg = false;
    return IntegrateLinear();
}

double UBemMatrix3::UIntAmat::IntegrandScalar(const UVector3& x)
{
    UBEMIntegral Iana;
    if(CompOmeg==true) return Iana.ComputeSolid(p0-x, p1-x, p2-x);
    return                    Iana.ComputeGamma(p0-x, p1-x, p2-x);
}

const double* UBemMatrix3::UIntAmat::IntegrandScalars(const UVector3& x)
{
    UBEMIntegral Iana;
    if(CompOmeg==true) Iana.ComputeLinear     (p0-x, p1-x, p2-x, Integ, Integ+1, Integ+2);
    else               Iana.ComputeLinearGamma(p0-x, p1-x, p2-x, Integ, Integ+1, Integ+2);

    return Integ;
}
