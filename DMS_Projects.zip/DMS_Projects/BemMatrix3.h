#ifndef _BEMMATRIX_INCLUDED
#define _BEMMATRIX_INCLUDED

/*
  Update history
  
  Who    When       What
  Jdm    30-09-98   Creation
  JdM    21-04-99   Shifted some parameters from private to protected
  JdM    25-08-99   Use explicit public declaration for privately inhereted functions
  JdM    10-10-00   SetBvec() now return const double* i.s.o. double*
  JdM    13-10-00   Made inheritance from UConductor3 public
  JdM    17-08-01   Made desctructor virtual
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Dipole.h"
#include "Matrix.h"
#include "IntegrateTriangle.h"
#include "Conductor3.h"


enum DerivType
{
    D_OriPos00,
    D_OriPos10,
    D_OriPos01,
    D_OriPos20,
    D_OriPos11,
    D_OriPos02
};

class DLL_IO UBemMatrix3 :  public UConductor3
{
public:
    UBemMatrix3();
    UBemMatrix3(FILE* fpIn);
    UBemMatrix3(const UHeadModel* Hmod);
    UBemMatrix3(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool MonoLayer);
    UBemMatrix3(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool MonoLayer); 
    UBemMatrix3(const UBemMatrix3 &B3);    
    virtual ~UBemMatrix3();
    UBemMatrix3& operator=(const UBemMatrix3 &B3);

    ErrorType              GetError(void) const    {if(this) return error; return U_ERROR;}

    PotInterPolType        GetPotInterPol(void) const {if(this) return PInter;  return U_POTINTER_UNKNOWN;}
    BEMSmoothType          GetSmoothElemA(void) const {if(this) return SmoothA; return U_SMOOTH_UNKNOWN;}
    BEMSmoothType          GetSmoothElemB(void) const {if(this) return SmoothB; return U_SMOOTH_UNKNOWN;}

    const UNestedSurface*  GetNestedSurface(int j) const {if(j<0 || j>=Nsurfaces) return NULL; return pSurface[j]; }
    const UNestedSurface*  GetNestedSurface(const char* SurfName) const {return GetNestedSurface(GetSurfIndex(SurfName));}

    ErrorType              ReplaceSurface(int iSurface, const USurface &S);
    ErrorType              ReplaceSurface(int iSurface, const UConductor3 &r);
    ErrorType              ResampleSurfaces(int NtotalPoints, double* Frac, int Ns);

    const UString&         GetProperties(UString Comment) const;
    ErrorType              LocalRefine(double MaxDistance, UVector3* Pts, int Npts);

    static int             GetNcomp(DerivType deriv, UDipole::DipoleType DT);
    static int             GetNcomp(DerivType deriv, const UDipole& dip);
    int                    GetNpot(int jsurf=-1) const;

    static const char*     GetFileHeader(void) {return UConductor3::GetFileHeader();}
    ErrorType              WriteBinary(FILE* fpOut) const;

protected:
    ErrorType              SetPotInterPol(PotInterPolType PInt);
    bool                   GetMonoLayer(void) const;
    ErrorType              SetAmat(double* Amat, bool NoOutput=true, const double* DefaultSigmas=NULL) const;

    UMatrix                GetGammaMat(const int* SelectRows, int NIndex);
    UMatrix                GetBvec(double Current, UVector3 x);
    UMatrix                GetBvec(double Current, UVector3 x1, UVector3 x2);
    UMatrix                GetBvec(const UDipole& dip, DerivType der, double DipoleConduct) const;
    UMatrix                GetImprodHOne(bool InvertMat, int jsurf=-1) const;

    UVector3*              GetPointsCopy(int jsurf=-1) const;

    int                    *joffset;    // Start Adresses of the potentials corresponding to each surface
    int                    Npot;        // Total number of unknown potential (depends on PInter)

    ErrorType              UpdateMatSize(void);
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:  
    static const char*     HEADERBEGIN;
    static const char*     HEADEREND;
    ErrorType              error;       // General error flag
    static UString         Properties;

    PotInterPolType        PInter;      // Potential interpolation       (for the matrix Amat and the vector Bvec)
    BEMSmoothType          SmoothA;     // Smoothing of matrix elements  (for the matrix Amat)
    BEMSmoothType          SmoothB;     // Smoothing of matrix elements  (for the vector Bvec)
    bool                   UseMonoLayer;// if(true) use monolayer variant else use traditional double layer BEM variant

    ErrorType              SetRHSSingleDip(const UDipole& dip, DerivType der, double* RHS, double DipoleConduct) const;

/* Triangle integration class for Right Hand Side*/
    class UIntBVec :  public UIntegTri
    {
    public:
        UIntBVec();
        UIntBVec(const UIntBVec& BV);
        UIntBVec(const UDipole& dip, DerivType der, bool UseMonoLayer, int Order=5);
        UIntBVec(const UVector3& f0, const UVector3& f1, const UVector3& f2,
                 const UVector3& s0, const UVector3& s1, const UVector3& s2, int Order=5);

        virtual     ~UIntBVec();
        UIntBVec&   operator=(const UIntBVec &BV);

        const double*     IntegrateGammaConst(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateGammaLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateDipConst(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateDipConst(const UVector3& c0, const UVector3& c1, const UVector3& c2, const UVector3& NormDipCond); // UseMonoLayer
        const double*     IntegrateDipLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateDipLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2, const UVector3& NormDipCond); // UseMonoLayer 

    protected:
        void              SetAllMembersDefault(void);
        void              DeleteAllMembers(ErrorType E);
        const double*     IntegrandScalars(const UVector3& x);

    private:
        enum BVecType           // Dipole or EIT
        {
            U_DIPOLE,
            U_EIT
        };
        BVecType    BType;          // Determines whether dipole fields or EIT fields should be integrated
        bool        UseMonoLayer;   // If true: compute dipole potential using mono layer approach
        UVector3    NSigma;         // Triangle normal, multiplied with DeltaSigma and divided by conductivity at compartment where dipole is located
        DerivType   deriv;          // The type of partial derivatives that are currently to be computed
        double      Integ[36];      // Array to store the partial derivatives of the integrand
        UVector3    xdip;           // Dipole position 
        UVector3    ddip;           // Dipole moments 
        UVector3    p10,p11,p12;    // First or only injection electrode
        UVector3    p20,p21,p22;    // Second injection electrode
    };    

/* Triangle integration class for System Matrix*/
    class UIntAmat :  public UIntegTri
    {
    public:
        UIntAmat();
        UIntAmat(UVector3 x0, UVector3 x1, UVector3 x2, int Order=5);
        UIntAmat(const UIntAmat& AM);
        virtual           ~UIntAmat();
        UIntAmat&         operator=(const UIntAmat &AM);

        double            IntegrateOmegConst(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateOmegLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2);

        double            IntegrateGammaConst(const UVector3& c0, const UVector3& c1, const UVector3& c2);
        const double*     IntegrateGammaLinear(const UVector3& c0, const UVector3& c1, const UVector3& c2);

    protected:
        void              SetAllMembersDefault(void);
        void              DeleteAllMembers(ErrorType E);

        double            IntegrandScalar(const UVector3& x) ;
        const double*     IntegrandScalars(const UVector3& x);

    private:
        bool              CompOmeg;   // if(CompOmeg==true) Compute Omega else Compute Gamma
        UVector3          p0, p1, p2; // "observed" triangle
        double            Integ[3];   // Array to store the three integrands, in the linear case 
    };
};

#endif // _BEMMATRIX_INCLUDED
