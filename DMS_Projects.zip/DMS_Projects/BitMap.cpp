/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for manipulating and converting 2D data as bitmap (bmp) format.    */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    20-01-01   creation
  JdM    11-02-02   Added parameter to SaveAsCpp()
  JdM    23-03-02   Add color scale constructor
                    Big fix in grey scale
  JdM    11-06-02   Added MixImage()
  JdM    14-06-02   Color scale constructor: invert meaning of reverse parameter
  JdM    22-07-02   Added SetPalletteFirst() and SetPalletteLast()
  JdM    25-10-02   Added another colorscale
  JdM    26-11-02   Added GetColor() and made color bar construct valid for horizontal color scales
  JdM    15-12-02   'bug fix' In the color palletette constructor, use ReversePallette() iff reverse==true
  JdM    04-05-03   Added new pallette types of 256 colors: U_PAL_256A, U_PAL_256B and U_PAL_256C
  JdM    21-05-03   Added new constructor
  JdM    23-05-03   Added ReOrderPallette()
  JdM    05-07-03   Added SaveAsBinaryCpp()
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    14-10-04   Added parameters to colorscale bar constructor
  JdM    22-10-04   Replaced three color tables by for MatLab based tables
  JdM    25-10-04   Add parameter to SetImage()
  JdM    31-12-05   Added parameter to color scale constructor.
                    Added ConvertWhiteToGrey()
  JdM    01-02-08   Added U_PAL_COLD
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    09-11-09   Added U_PAL_TRUE
  JdM    21-08-10   Added static GetColor()
  JdM    17-07-11   Put PalType out of UBitMap and renamed to PaletteType
  JdM    18-07-11   Added bool MaxToBack to one of the color bar constructors
  JdM    26-08-11   Initiate extrax in File-constructor.
                    Bug Fix: SaveAsCpp(): Account for empty dummy pixels
  JdM    11-10-11   Added U_PALETTE_GENERAL
  JdM    28-10-11   Moved CTABOFFSET and HDRSIZE to header and renamed to BM_CTABOFFSET and BM_HDRSIZE8B
  JdM    10-05-12   Added GetPaletteType()
  JdM    06-05-13   Put unsigned char casts in brackets: (unsigned char)(k)
  JdM    03-06-13   Added ConvertMonochrome()
  JdM    15-11-13   Added U_PALETTE_RED, U_PALETTE_GREEN and U_PALETTE_BLUE
  JdM    26-11-13   UBitMap::UBitMap(). Added Asym parameter
                    Replaced U_PALETTE_COPPER by U_PALETTE_HOTCOLD 
  JdM    09-02-14   Bug Fix: UBitMap::UBitMap(). Avoid deviding by zero in case of anti-symmetric scale.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    08-11-14   Added ErrorType constructor. Added Copy constructor
  JdM    18-11-14   Replaced BITMAPFILEHEADER by PMT_BITMAPFILEHEADER, BITMAPINFOHEADER by PMT_BITMAPINFOHEADER and RGBQUAD by PMT_RGBQUAD
*/

#include <math.h>
#include <string.h>
#include "BitMap.h"


/**** Convert monochrome cursor bitmap to UBitMap;
    unsigned char BMdat[32*32];
    for(int i=31,k=0; i>=0; i--)
    {
        for(int j=0; j<32; j++,k++)
        {
            BMdat[k] = (DrawCursorBmp[i*4+(j>>3)] & (1<<(j&7)) ) ? 0 : 255; 
        }
    }
    UBitMap BitM(32, 32, BMdat); 
    BitM.SaveFile(UFileName("C:\\PMT_Projects\\Qt4Projects\\Q4_ui\\Icons\\Bmp\\DrawCursorBmp.bmp"));
****/


static unsigned char jet[3*64] = {
  0,  0,143,    0,  0,159,    0,  0,175,    0,  0,191,    0,  0,207,    0,  0,223,    0,  0,239,    0,  0,255,
  0, 16,255,    0, 32,255,    0, 48,255,    0, 64,255,    0, 80,255,    0, 96,255,    0,112,255,    0,128,255,
  0,143,255,    0,159,255,    0,175,255,    0,191,255,    0,207,255,    0,223,255,    0,239,255,    0,255,255,
 16,255,239,   32,255,223,   48,255,207,   64,255,191,   80,255,175,   96,255,159,  112,255,143,  128,255,128,
143,255,112,  159,255, 96,  175,255, 80,  191,255, 64,  207,255, 48,  223,255, 32,  239,255, 16,  255,255,  0,
255,239,  0,  255,223,  0,  255,207,  0,  255,191,  0,  255,175,  0,  255,159,  0,  255,143,  0,  255,128,  0,
255,112,  0,  255, 96,  0,  255, 80,  0,  255, 64,  0,  255, 48,  0,  255, 32,  0,  255, 16,  0,  255,  0,  0,
239,  0,  0,  223,  0,  0,  207,  0,  0,  191,  0,  0,  175,  0,  0,  159,  0,  0,  143,  0,  0,  128,  0,  0 };

static unsigned char bone[3*64] = {
  0,  0,  1,    4,  4,  6,    7,  7, 11,   11, 11, 16,   14, 14, 21,   18, 18, 26,   21, 21, 31,   25, 25, 35,
 28, 28, 40,   32, 32, 45,   35, 35, 50,   39, 39, 55,   43, 43, 60,   46, 46, 65,   50, 50, 70,   53, 53, 74,
 57, 57, 79,   60, 60, 84,   64, 64, 89,   67, 67, 94,   71, 71, 99,   74, 74,104,   78, 78,108,   81, 81,113,
 85, 86,117,   89, 91,120,   92, 96,124,   96,101,128,   99,106,131,  103,111,135,  106,116,138,  110,120,142,
113,125,145,  117,130,149,  120,135,152,  124,140,156,  128,145,159,  131,150,163,  135,155,166,  138,159,170,
142,164,174,  145,169,177,  149,174,181,  152,179,184,  156,184,188,  159,189,191,  163,193,195,  166,198,198,
172,202,202,  178,205,205,  183,209,209,  189,212,212,  194,216,216,  200,220,220,  205,223,223,  211,227,227,
216,230,230,  222,234,234,  227,237,237,  233,241,241,  238,244,244,  244,248,248,  249,251,251,  255,255,255 };

static unsigned char hot[3*64] = {
 11,  0,  0,   21,  0,  0,   32,  0,  0,   43,  0,  0,   53,  0,  0,   64,  0,  0,   74,  0,  0,   85,  0,  0,
 96,  0,  0,  106,  0,  0,  117,  0,  0,  128,  0,  0,  138,  0,  0,  149,  0,  0,  159,  0,  0,  170,  0,  0,
181,  0,  0,  191,  0,  0,  202,  0,  0,  212,  0,  0,  223,  0,  0,  234,  0,  0,  244,  0,  0,  255,  0,  0,
255, 11,  0,  255, 21,  0,  255, 32,  0,  255, 43,  0,  255, 53,  0,  255, 64,  0,  255, 74,  0,  255, 85,  0,
255, 96,  0,  255,106,  0,  255,117,  0,  255,128,  0,  255,138,  0,  255,149,  0,  255,159,  0,  255,170,  0,
255,181,  0,  255,191,  0,  255,202,  0,  255,212,  0,  255,223,  0,  255,234,  0,  255,244,  0,  255,255,  0,
255,255, 16,  255,255, 32,  255,255, 48,  255,255, 64,  255,255, 80,  255,255, 96,  255,255,112,  255,255,128,
255,255,143,  255,255,159,  255,255,175,  255,255,191,  255,255,207,  255,255,223,  255,255,239,  255,255,255 };

static unsigned char blue[3*64] = {
  0,  0, 11,    0,  0, 21,    0,  0, 32,    0,  0, 43,    0,  0, 53,    0,  0, 64,    0,  0, 74,    0,  0, 85,
  0,  0, 96,    0,  0,106,    0,  0,117,    0,  0,128,    0,  0,138,    0,  0,149,    0,  0,159,    0,  0,170,
  0,  0,181,    0,  0,191,    0,  0,202,    0,  0,212,    0,  0,223,    0,  0,234,    0,  0,244,    0,  0,255,
  0, 11,255,    0, 21,255,    0, 32,255,    0, 43,255,    0, 53,255,    0, 64,255,    0, 74,255,    0, 85,255,
  0, 96,255,    0,106,255,    0,117,255,    0,128,255,    0,138,255,    0,149,255,    0,159,255,    0,170,255,
  0,181,255,    0,191,255,    0,202,255,    0,212,255,    0,223,255,    0,234,255,    0,244,255,    0,255,255,
 16,255,255,   32,255,255,   48,255,255,   64,255,255,   80,255,255,   96,255,255,  112,255,255,  128,255,255,
143,255,255,  159,255,255,  175,255,255,  191,255,255,  207,255,255,  223,255,255,  239,255,255,  255,255,255 };


PaletteType GetPaletteType(int itype)
{
    switch(itype)
    {
    case U_PALETTE_TRUE   : return U_PALETTE_TRUE   ;
    case U_PALETTE_GREY   : return U_PALETTE_GREY   ;
    case U_PALETTE_RED    : return U_PALETTE_RED    ;
    case U_PALETTE_GREEN  : return U_PALETTE_GREEN  ;
    case U_PALETTE_BLUE   : return U_PALETTE_BLUE   ;
    case U_PALETTE_0      : return U_PALETTE_0      ;
    case U_PALETTE_1      : return U_PALETTE_1      ;
    case U_PALETTE_2      : return U_PALETTE_2      ;
    case U_PALETTE_3      : return U_PALETTE_3      ;
    case U_PALETTE_4      : return U_PALETTE_4      ;
    case U_PALETTE_JET    : return U_PALETTE_JET    ;
    case U_PALETTE_BONE   : return U_PALETTE_BONE   ;
    case U_PALETTE_HOT    : return U_PALETTE_HOT    ;
    case U_PALETTE_COLD   : return U_PALETTE_COLD   ;
    case U_PALETTE_HOTCOLD: return U_PALETTE_HOTCOLD;
    case U_PALETTE_GENERAL: return U_PALETTE_GENERAL;
    case U_PALETTE_POSNEG : return U_PALETTE_POSNEG ;
    }
    CI.AddToLog("ERROR: GetPaletteType(). invalid index (itype=%d)  .\n", itype);
    return U_PALETTE_GREY;
}

void UBitMap::SetAllMembersDefault(void)
{
    fhdr.bfType    = BM_SIGNATURE;   // "BM"
    fhdr.bfSize    = BM_HDRSIZE8B;
    fhdr.bfRes1    = 0;
    fhdr.bfRes2    = 0;
    fhdr.bfOffBits = BM_HDRSIZE8B;

    ihdr.biSize         = 40;
    ihdr.biWidth        = 0;
    ihdr.biHeight       = 0;
    ihdr.biPlanes       = 1;
    ihdr.biBitCount     = 8;
    ihdr.biCompression  = 0;
    ihdr.biSizeImage    = 0;
    ihdr.biXPelsPerMeter= 0;
    ihdr.biYPelsPerMeter= 0;
    ihdr.biClrUsed      = 0;
    ihdr.biClrImportant = 0;

    for(int k=0; k<256; k++)  // Set default gray scale color table
    {
        ctab[k].blue     = (unsigned char)(k);
        ctab[k].green    = (unsigned char)(k);
        ctab[k].red      = (unsigned char)(k);
        ctab[k].reserved = 0;
    }
    extrax    = 0;
    BitMapArr = NULL;
    error     = U_OK;
}
void UBitMap::DeleteAllMembers(ErrorType E)
{
    delete[] BitMapArr;
    SetAllMembersDefault();
    error = E;
}

UBitMap::UBitMap()
{
    SetAllMembersDefault();
}
UBitMap::UBitMap(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UBitMap::UBitMap(const UBitMap& BM)
{
    SetAllMembersDefault();
    *this = BM;
}

UBitMap::UBitMap(int dimx, int dimy)
{
    SetAllMembersDefault();
    if(dimx<=0 || dimy<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). dimx and/or dimy out of range (%d,%d) \n",dimx,dimy);
        return;
    }
    if(dimx%4) extrax = 4-dimx%4;
    fhdr.bfSize    = BM_HDRSIZE8B + (dimx+extrax)*dimy;
    ihdr.biWidth   = dimx;
    ihdr.biHeight  = dimy;

    BitMapArr = new unsigned char[fhdr.bfSize];
    if(BitMapArr==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Memory allocation error. dimx=%d, dimy=%d  .\n",dimx,dimy);
        return;
    }

/* Fill header info */
    SetBitMapHeader();

/* Set color table*/
    SetColorTable();
}

UBitMap::UBitMap(int dimx, int dimy, const unsigned char* data)
{
    SetAllMembersDefault();
    if(dimx<=0 || dimy<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). dimx and/or dimy out of range (%d,%d) \n",dimx,dimy);
        return;
    }
    if(data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Invalid NULL pointer argument.\n");
        return;
    }
    if(dimx%4) extrax = 4-dimx%4;
    fhdr.bfSize    = BM_HDRSIZE8B + (dimx+extrax)*dimy;
    ihdr.biWidth   = dimx;
    ihdr.biHeight  = dimy;

    BitMapArr = new unsigned char[fhdr.bfSize];
    if(BitMapArr==NULL || SetImage(data)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Memory allocation error. dimx=%d, dimy=%d, setting image.\n",dimx,dimy);
        return;
    }

/* Fill header info */
    SetBitMapHeader();

/* Set color table*/
    SetColorTable();
}

UBitMap::UBitMap(int dimx, int dimy, bool vertical, bool reverse, PaletteType PL, int imin, int imax, bool WhiteAsGray, bool MaxToBack, bool Asym)
{
    SetAllMembersDefault();
    if(PL==U_PALETTE_NUMPALTYPE)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). PL out of range, PL = %d .\n", PL);
        return;
    }
    if(dimx<=1 || dimy<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Dimensions out of range: dimx = %d, dimy = %d .\n", dimx, dimy);
        return;
    }
    *this = UBitMap(dimx, dimy);
    if(error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Copying empty bitmap. dimx=%d, dimy=%d  .\n", dimx, dimy);
        return;
    }
    int             NK   = vertical ? dimy : dimx;
    unsigned char*  tab  = new unsigned char[NK];
    if(tab==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Memory allocation, NK=%d  .\n",NK);
        return;
    }
    
    int  kmin = (imin<0 || imax<=imin || imin>=NK) ? 0    : imin;
    int  kmax = (imax<0 || imax<=imin || imax>=NK) ? NK-1 : imax;

    for(int n=0; n<NK; n++)
    {
        unsigned char k = 0;
        if(Asym)
        {
            if(n<kmin)        {if(kmin>1)    k =       ((n-0     )*127  )/(kmin-1);    else k =   0;}
            else if(n<=kmax)                 k = MaxToBack ? 0 : 255;
            else              {if(kmax<NK-1) k = 127 + ((n-kmax+1)*127  )/(NK-1-kmax); else k = 255;}
        }
        else
        {
            if(n<kmin)        k = 0;
            else if(n<kmax)   k = ((n-kmin)*255+128)/(kmax-kmin);
            else              k = MaxToBack ? 0 : 255;
        }
        tab[n] = k;
    }

    if(vertical==true)
    {
        unsigned char* pBMA   = BitMapArr+BM_HDRSIZE8B;
        for(int y=0; y<NK; y++)
        {
            for(int x=0; x<dimx;   x++) *pBMA++ = tab[y];
            for(int x=0; x<extrax; x++) *pBMA++ = 0;
        }
    }
    else
    {
        for(int x=0; x<NK+extrax; x++)
        {
            unsigned char* pBMA   = BitMapArr+BM_HDRSIZE8B+x;
            for(int y=0; y<dimy;   y++, pBMA+=NK+extrax) *pBMA = tab[x];
        }
    }
    delete[] tab;
    SetPallette(PL);
    if(reverse) ReversePallette();

    if(WhiteAsGray==true)
    {
        if(PL!=U_PALETTE_GREY && PL!=U_PALETTE_POSNEG) ConvertWhiteToGrey();
    }
}

UBitMap::UBitMap(UFileName F)
{
    SetAllMembersDefault();
    if(DoesFileExist(F)==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). File does not exist: %s .\n",F.GetFullFileName());
        return;
    }
    unsigned int Nbytes = F.GetFileSize();

    BitMapArr = new unsigned char[Nbytes];
    if(BitMapArr==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBitMap::UBitMap(). Memory allocation error. File size = %d .\n",(int)Nbytes);
        return;
    }

    FILE* fp = fopen(F,"rb",false);
    fread(BitMapArr, 1, Nbytes, fp);
    fclose(fp);

    unsigned char* pBitMap = BitMapArr;

/* Fil header info */
    memcpy(&(fhdr.bfType),    pBitMap,  2); pBitMap+=2;
    memcpy(&(fhdr.bfSize),    pBitMap,  4); pBitMap+=4;
    memcpy(&(fhdr.bfRes1),    pBitMap,  2); pBitMap+=2;
    memcpy(&(fhdr.bfRes2),    pBitMap,  2); pBitMap+=2;
    memcpy(&(fhdr.bfOffBits), pBitMap,  4); pBitMap+=4;

    memcpy(&(ihdr.biSize),         pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biWidth),        pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biHeight),       pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biPlanes),       pBitMap, 2); pBitMap+=2;
    memcpy(&(ihdr.biBitCount),     pBitMap, 2); pBitMap+=2;
    memcpy(&(ihdr.biCompression),  pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biSizeImage),    pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biXPelsPerMeter),pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biYPelsPerMeter),pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biClrUsed),      pBitMap, 4); pBitMap+=4;
    memcpy(&(ihdr.biClrImportant), pBitMap, 4); pBitMap+=4;

    unsigned char* pctab   = (unsigned char*) &ctab;
    if(ihdr.biClrUsed)
    {
        for(int k=0; k<4*ihdr.biClrUsed; k++)  *pctab++ = *pBitMap++ ;
    }
    else
    {
        for(int k=0; k<64; k++)  *pctab++ = *pBitMap++ ;
    }

    extrax = 0; if(ihdr.biWidth%4) extrax = 4-ihdr.biWidth%4;;
}

UBitMap::~UBitMap()
{
    DeleteAllMembers(U_OK);
}

UBitMap& UBitMap::operator=(const UBitMap& BM)
{
    if(this==NULL)
    {
        static UBitMap B; B.error = U_ERROR;
        CI.AddToLog("ERROR: UBitMap::operator=(). this==NULL. \n");
        return B;
    }
    if(&BM==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::operator=(). NULL address argument. \n");
        return *this;
    }
    if(this==&BM) return *this;

    if(BM.BitMapArr)
    {
        if(fhdr.bfSize != BM.fhdr.bfSize)
        {
            delete[] BitMapArr;
            BitMapArr  = new unsigned char[BM.fhdr.bfSize];
            if(BitMapArr==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UBitMap::operator=(). Memory allocation. Nbytes = %d .\n",BM.fhdr.bfSize);
                return *this;
            }
        }
        memcpy(BitMapArr, BM.BitMapArr, BM.fhdr.bfSize);
    }
    else
    {
        delete[] BitMapArr;
        BitMapArr = NULL;
    }
    memcpy(&fhdr, &BM.fhdr, sizeof(fhdr));
    memcpy(&ihdr, &BM.ihdr, sizeof(ihdr));
    memcpy(&ctab, &BM.ctab, sizeof(ctab));
    extrax = BM.extrax;
    error  = BM.error;

    return *this;
}

PaletteType UBitMap::ConvertToPalType(int index)
{
    switch(index)
    {
    case  0: return U_PALETTE_TRUE;
    case  1: return U_PALETTE_GREY;
    case  2: return U_PALETTE_RED;
    case  3: return U_PALETTE_GREEN;
    case  4: return U_PALETTE_BLUE;
    case  5: return U_PALETTE_0;
    case  6: return U_PALETTE_1;
    case  7: return U_PALETTE_2;
    case  8: return U_PALETTE_3;
    case  9: return U_PALETTE_4;
    case 10: return U_PALETTE_JET;
    case 11: return U_PALETTE_BONE;
    case 12: return U_PALETTE_HOT;
    case 13: return U_PALETTE_COLD;
    case 14: return U_PALETTE_HOTCOLD;
    case 15: return U_PALETTE_GENERAL;
    case 16: return U_PALETTE_POSNEG;
    }

    CI.AddToLog("ERROR: UBitMap::ConvertToPalType(). Argument out of range: index = %d \n", index);
    return U_PALETTE_GREY;
}

ErrorType UBitMap::ReOrderPallette(void)
{
    PMT_RGBQUAD ctabNew[256];
    for(int k=0; k<256; k++) ctabNew[k].reserved = 255;

    ctabNew[0].red      = ctab[0].red;
    ctabNew[0].green    = ctab[0].green;
    ctabNew[0].blue     = ctab[0].blue;
    ctabNew[0].reserved = 0;
    for(int k1=1; k1<256; k1++)
    {
        double dmin = 100000;
        int    kmin = -1;
        for(int k2=0; k2<256; k2++)
        {
            if(ctabNew[k2].reserved==0) continue;

            double dist = UBitMap::GetDistance2(ctabNew[k1-1], ctab[k2]);
            if(dist<dmin)
            {
                dmin = dist;
                kmin = k2;
            }
        }
        if(kmin<0)
        {
            CI.AddToLog("ERROR: UBitMap::ReOrderPallette(). kmin = %d, k1=%d. \n", kmin,k1);
            kmin = k1;
        }
        ctabNew[k1].red      = ctab[kmin].red;
        ctabNew[k1].green    = ctab[kmin].green;
        ctabNew[k1].blue     = ctab[kmin].blue;
        ctabNew[k1].reserved = 0;
    }
    for(int k=0; k<256; k++)
    {
        ctab[k].red      = ctabNew[k].red;
        ctab[k].green    = ctabNew[k].green;
        ctab[k].blue     = ctabNew[k].blue;
        ctab[k].reserved = ctabNew[k].reserved;
    }
    return U_OK;
}

ErrorType UBitMap::ReversePallette(void)
{
    for(int k=0; k<128; k++)
    {
        unsigned char dum;
        int kk = 256-k-1;

        dum = ctab[k].red;      ctab[k].red      = ctab[kk].red;      ctab[kk].red      = dum;
        dum = ctab[k].green;    ctab[k].green    = ctab[kk].green;    ctab[kk].green    = dum;
        dum = ctab[k].blue;     ctab[k].blue     = ctab[kk].blue;     ctab[kk].blue     = dum;
        dum = ctab[k].reserved; ctab[k].reserved = ctab[kk].reserved; ctab[kk].reserved = dum;
    }
    return SetColorTable();
}

ErrorType UBitMap::SetPallette(const unsigned char* ColTab, int TabSize)
{
    if(ColTab==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SetPallette(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(TabSize<=0 || TabSize>256)
    {
        CI.AddToLog("ERROR: UBitMap::SetPallette(). TabSize out of range (TabSize=%d) .\n", TabSize);
        return U_ERROR;
    }
    for(int k=0; k<256; k++)
    {
        if(k<TabSize)
        {
            ctab[k].red      = ColTab[3*k+2];
            ctab[k].green    = ColTab[3*k+1];
            ctab[k].blue     = ColTab[3*k+0];
        }
        else
        {
            ctab[k].red      = 0;
            ctab[k].green    = 0;
            ctab[k].blue     = 0;
        }
        ctab[k].reserved = 0;
    }
    return SetColorTable();
}

ErrorType UBitMap::SetPallette(PaletteType PL)
{
    PMT_RGBQUAD Pal[17];
    int k=0;
    switch(PL)
    {
    case U_PALETTE_TRUE:
        {
            for(int k=0; k<256; k++)
            {
                ctab[k].red   = ctab[k].green = ctab[k].blue  = 0;
                ctab[k].reserved = 0;
            }
            for(int k=0; k<64; k++)
            {
                for(int i=0; i<4; i++)
                {
                    ctab[4*k+i].red   = 64*( k%4);
                    ctab[4*k+i].green = 64*((k/4)%4);
                    ctab[4*k+i].blue  = 64*((k/16)%4);
                }
            }
        }
        return SetColorTable();

    case U_PALETTE_GREY:
        for(k=0; k<256; k++)
        {
            ctab[k].red   = ctab[k].green = ctab[k].blue  = k;
            ctab[k].reserved = 0;
        }
        return SetColorTable();

    case U_PALETTE_RED:
        for(k=0; k<256; k++)
        {
            ctab[k].red      = k;
            ctab[k].green    = ctab[k].blue  = 0;
            ctab[k].reserved = 0;
        }
        return SetColorTable();

    case U_PALETTE_GREEN:
        for(k=0; k<256; k++)
        {
            ctab[k].green    = k;
            ctab[k].red      = ctab[k].blue  = 0;
            ctab[k].reserved = 0;
        }
        return SetColorTable();

    case U_PALETTE_BLUE:
        for(k=0; k<256; k++)
        {
            ctab[k].blue     = k;
            ctab[k].red      = ctab[k].green = 0;
            ctab[k].reserved = 0;
        }
        return SetColorTable();

    case U_PALETTE_0:
        Pal[ 0].red = 255; Pal[ 0].green = 255; Pal[ 0].blue = 255;
        Pal[ 1].red = 120; Pal[ 1].green = 255; Pal[ 1].blue = 120;
        Pal[ 2].red =   0; Pal[ 2].green = 255; Pal[ 2].blue = 255;
        Pal[ 3].red =   0; Pal[ 3].green = 190; Pal[ 3].blue = 190;
        Pal[ 4].red =   0; Pal[ 4].green =   0; Pal[ 4].blue = 255;
        Pal[ 5].red = 190; Pal[ 5].green =   0; Pal[ 5].blue = 255;
        Pal[ 6].red = 255; Pal[ 6].green =   0; Pal[ 6].blue = 255;
        Pal[ 7].red = 190; Pal[ 7].green =   0; Pal[ 7].blue = 190;
        Pal[ 8].red =   0; Pal[ 8].green =   0; Pal[ 8].blue =   0;
        Pal[ 9].red = 190; Pal[ 9].green =   0; Pal[ 9].blue =   0;
        Pal[10].red = 255; Pal[10].green =   0; Pal[10].blue =   0;
        Pal[11].red = 255; Pal[11].green =  31; Pal[11].blue =   0;
        Pal[12].red = 255; Pal[12].green = 190; Pal[12].blue =   0;
        Pal[13].red = 190; Pal[13].green = 190; Pal[13].blue =   0;
        Pal[14].red = 255; Pal[14].green = 255; Pal[14].blue =   0;
        Pal[15].red = 255; Pal[15].green = 255; Pal[15].blue = 120;
        Pal[16].red = 255; Pal[16].green = 255; Pal[16].blue = 255;
        break;
    case U_PALETTE_1:
        Pal[ 0].red = 128; Pal[ 0].green =   0; Pal[ 0].blue =   0;
        Pal[ 1].red = 190; Pal[ 1].green =   0; Pal[ 1].blue =   0;
        Pal[ 2].red = 255; Pal[ 2].green =   0; Pal[ 2].blue =   0;
        Pal[ 3].red = 255; Pal[ 3].green = 128; Pal[ 3].blue =   0;
        Pal[ 4].red = 255; Pal[ 4].green = 190; Pal[ 4].blue =   0;
        Pal[ 5].red = 255; Pal[ 5].green = 255; Pal[ 5].blue =   0;
        Pal[ 6].red = 255; Pal[ 6].green = 255; Pal[ 6].blue = 128;
        Pal[ 7].red = 255; Pal[ 7].green = 255; Pal[ 7].blue = 190;
        Pal[ 8].red = 255; Pal[ 8].green = 255; Pal[ 8].blue = 255;
        Pal[ 9].red = 190; Pal[ 9].green = 190; Pal[ 9].blue = 255;
        Pal[10].red = 128; Pal[10].green = 128; Pal[10].blue = 255;
        Pal[11].red =   0; Pal[11].green =   0; Pal[11].blue = 255;
        Pal[12].red =   0; Pal[12].green =   0; Pal[12].blue = 202;
        Pal[13].red =   0; Pal[13].green =   0; Pal[13].blue = 190;
        Pal[14].red =   0; Pal[14].green =   0; Pal[14].blue = 161;
        Pal[15].red =   0; Pal[15].green =   0; Pal[15].blue = 128;
        Pal[16].red =   0; Pal[16].green =   0; Pal[16].blue = 100;
        break;
    case U_PALETTE_2:
        Pal[ 0].red = 128; Pal[ 0].green =   0; Pal[ 0].blue =   0;
        Pal[ 1].red = 190; Pal[ 1].green =   0; Pal[ 1].blue =   0;
        Pal[ 2].red = 255; Pal[ 2].green =   0; Pal[ 2].blue =   0;
        Pal[ 3].red = 255; Pal[ 3].green = 128; Pal[ 3].blue =   0;
        Pal[ 4].red = 255; Pal[ 4].green = 190; Pal[ 4].blue =   0;
        Pal[ 5].red = 255; Pal[ 5].green = 255; Pal[ 5].blue =   0;
        Pal[ 6].red = 255; Pal[ 6].green = 255; Pal[ 6].blue = 128;
        Pal[ 7].red = 255; Pal[ 7].green = 255; Pal[ 7].blue = 190;
        Pal[ 8].red = 255; Pal[ 8].green = 255; Pal[ 8].blue = 255;
        Pal[ 9].red =   0; Pal[ 9].green = 215; Pal[ 9].blue =   0;
        Pal[10].red =   0; Pal[10].green = 128; Pal[10].blue =   0;
        Pal[11].red =   0; Pal[11].green = 128; Pal[11].blue = 128;
        Pal[12].red =   0; Pal[12].green =   0; Pal[12].blue = 190;
        Pal[13].red =   0; Pal[13].green =   0; Pal[13].blue = 255;
        Pal[14].red = 190; Pal[14].green =   0; Pal[14].blue = 255;
        Pal[15].red = 128; Pal[15].green =   0; Pal[15].blue = 128;
        Pal[16].red = 100; Pal[16].green =   0; Pal[16].blue = 100;
        break;
    case U_PALETTE_3:
        Pal[ 0].red = 255; Pal[ 0].green = 255; Pal[ 0].blue = 190;
        Pal[ 1].red = 255; Pal[ 1].green = 255; Pal[ 1].blue = 128;
        Pal[ 2].red = 255; Pal[ 2].green = 255; Pal[ 2].blue =   0;
        Pal[ 3].red = 255; Pal[ 3].green = 190; Pal[ 3].blue =   0;
        Pal[ 4].red = 255; Pal[ 4].green = 128; Pal[ 4].blue =   0;
        Pal[ 5].red = 255; Pal[ 5].green =   0; Pal[ 5].blue =   0;
        Pal[ 6].red = 190; Pal[ 6].green =   0; Pal[ 6].blue =   0;
        Pal[ 7].red = 128; Pal[ 7].green =   0; Pal[ 7].blue =   0;
        Pal[ 8].red =   0; Pal[ 8].green =   0; Pal[ 8].blue =   0;
        Pal[ 9].red = 128; Pal[ 9].green =   0; Pal[ 9].blue = 128;
        Pal[10].red = 190; Pal[10].green =   0; Pal[10].blue = 255;
        Pal[11].red =   0; Pal[11].green =   0; Pal[11].blue = 255;
        Pal[12].red =   0; Pal[12].green =   0; Pal[12].blue = 190;
        Pal[13].red =   0; Pal[13].green = 128; Pal[13].blue = 128;
        Pal[14].red =   0; Pal[14].green = 128; Pal[14].blue =   0;
        Pal[15].red =   0; Pal[15].green = 190; Pal[15].blue =   0;
        Pal[16].red =   0; Pal[16].green = 255; Pal[16].blue =   0;
        break;
    case U_PALETTE_4:
        Pal[ 0].red =   0; Pal[ 0].green =   0; Pal[ 0].blue =  64;
        Pal[ 1].red =   0; Pal[ 1].green =   0; Pal[ 1].blue = 128;
        Pal[ 2].red =   0; Pal[ 2].green =   0; Pal[ 2].blue = 190;
        Pal[ 3].red =   0; Pal[ 3].green =   0; Pal[ 3].blue = 255;
        Pal[ 4].red =   0; Pal[ 4].green =  64; Pal[ 4].blue = 190;
        Pal[ 5].red =   0; Pal[ 5].green = 128; Pal[ 5].blue = 128;
        Pal[ 6].red =   0; Pal[ 6].green = 190; Pal[ 6].blue =  64;
        Pal[ 7].red =   0; Pal[ 7].green = 255; Pal[ 7].blue =   0;
        Pal[ 8].red =  64; Pal[ 8].green = 255; Pal[ 8].blue =   0;
        Pal[ 9].red = 128; Pal[ 9].green = 255; Pal[ 9].blue =   0;
        Pal[10].red = 255; Pal[10].green = 255; Pal[10].blue =   0;
        Pal[11].red = 255; Pal[11].green = 163; Pal[11].blue =   0;
        Pal[12].red = 255; Pal[12].green =  81; Pal[12].blue =   0;
        Pal[13].red = 255; Pal[13].green =   0; Pal[13].blue =   0;
        Pal[14].red = 190; Pal[14].green =   0; Pal[14].blue =   0;
        Pal[15].red = 128; Pal[15].green =   0; Pal[15].blue =   0;
        Pal[16].red =  64; Pal[16].green =   0; Pal[16].blue =   0;
        break;
    case U_PALETTE_JET:
        {
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<4; k++)
                {
                    int ic = 4*is+k;
                    ctab[ic].red      = jet[3*is  ];
                    ctab[ic].green    = jet[3*is+1];
                    ctab[ic].blue     = jet[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }
            return SetColorTable();
        }

    case U_PALETTE_BONE:
        {
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<4; k++)
                {
                    int ic = 4*is+k;
                    ctab[ic].red      = bone[3*is  ];
                    ctab[ic].green    = bone[3*is+1];
                    ctab[ic].blue     = bone[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }
            return SetColorTable();
        }

    case U_PALETTE_HOT:
        {
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<4; k++)
                {
                    int ic = 4*is+k;
                    ctab[ic].red      = hot[3*is  ];
                    ctab[ic].green    = hot[3*is+1];
                    ctab[ic].blue     = hot[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }
            return SetColorTable();
        }

    case U_PALETTE_COLD:
        {
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<4; k++)
                {
                    int ic = 4*is+k;
                    ctab[ic].red      = blue[3*is  ];
                    ctab[ic].green    = blue[3*is+1];
                    ctab[ic].blue     = blue[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }
            return SetColorTable();
        }

    case U_PALETTE_HOTCOLD:
        {
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<2; k++)
                {
                    int ic = 127 + (2*is+k);
                    ctab[ic].red      = hot[3*is  ];
                    ctab[ic].green    = hot[3*is+1];
                    ctab[ic].blue     = hot[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }
            for(int is=0; is<64; is++)
            {
                for(int k=0; k<2; k++)
                {
                    int ic = 127 - (2*is+k);
                    ctab[ic].red      = blue[3*is  ];
                    ctab[ic].green    = blue[3*is+1];
                    ctab[ic].blue     = blue[3*is+2];
                    ctab[ic].reserved = 0;
                }
            }

            return SetColorTable();
        }

    case U_PALETTE_GENERAL:
        for(k=0; k<256; k++)
        {
            ctab[k].red   = ctab[k].green = ctab[k].blue  = k;
            ctab[k].reserved = 0;
        }
        return SetColorTable();

    case U_PALETTE_POSNEG:
        {
            for(int ic=0; ic<256; ic++)
            {
                ctab[ic].red      = 255;
                ctab[ic].green    = 255;
                ctab[ic].blue     = 255;
                ctab[ic].reserved = 0;
                if(!((ic+3)%8))
                {
                    if(ic<127)                        ctab[ic].green = ctab[ic].blue = 0;
                    else             ctab[ic].red   = ctab[ic].green                 = 0;
                }
                if(ic==128)          ctab[ic].red   = ctab[ic].green = ctab[ic].blue = 0;
            }
            return SetColorTable();
        }
    default:
        CI.AddToLog("ERROR: UBitMap::SetPallette(). Invalid argument (PL=%d) .\n",PL);
        return U_ERROR;
    }

    int ic = 0;
    for(k=0; k<16; k++)
        for(int i=0; i<16; i++, ic++)
        {
            double alfa = i/16.;
            ctab[ic].red   = (unsigned char)(floor((1.-alfa)*Pal[k].red   + alfa*Pal[k+1].red  +.5));
            ctab[ic].green = (unsigned char)(floor((1.-alfa)*Pal[k].green + alfa*Pal[k+1].green+.5));
            ctab[ic].blue  = (unsigned char)(floor((1.-alfa)*Pal[k].blue  + alfa*Pal[k+1].blue +.5));
            ctab[ic].reserved = 0;
        }

    return SetColorTable();
}

ErrorType UBitMap::SetPalletteFirst(unsigned char R, unsigned char G, unsigned char B)
{
    ctab[0].red      = R;
    ctab[0].green    = G;
    ctab[0].blue     = B;
    ctab[0].reserved = 0;
    return SetColorTable();
}

ErrorType UBitMap::SetPalletteLast(unsigned char R, unsigned char G, unsigned char B)
{
    ctab[255].red      = R;
    ctab[255].green    = G;
    ctab[255].blue     = B;
    ctab[255].reserved = 0;
    return SetColorTable();
}


ErrorType UBitMap::SetImage(const unsigned char* data, int dimx, int dimy, bool Set255To0)
/*
    Set the image, assuming that data[] consists of dimy rows of
    dimx pixels wide each.
    Test whether these numbers are consistent with ihdr.biWidth and ihdr.biHeight,
    respectively.
    If so, use SetImage(data) to copy the image.
    If not, make the object consistent by allocating the appriate amount of
    memory and copy the data then.

    The advantage of this method is that no data are allocated when not stricly necessary.
 */
{
    if(dimx==ihdr.biWidth && dimy==ihdr.biHeight) return SetImage(data, Set255To0);

    if(dimx<=0 || dimy<=0)
    {
        CI.AddToLog("ERROR: UBitMap::SetImage(). dimx and/or dimy out of range (%d,%d) \n",dimx,dimy);
        return U_ERROR;
    }

    extrax = 0;
    if(dimx%4) extrax = 4-dimx%4;
    fhdr.bfSize    = BM_HDRSIZE8B + (dimx+extrax)*dimy;
    ihdr.biWidth   = dimx;
    ihdr.biHeight  = dimy;

    delete[] BitMapArr;
    BitMapArr = new unsigned char[fhdr.bfSize];
    if(BitMapArr==NULL)
    {
        fhdr.bfSize   = BM_HDRSIZE8B;
        ihdr.biWidth  = 0;
        ihdr.biHeight = 0;
        SetBitMapHeader();
        CI.AddToLog("ERROR: UBitMap::SetImage(). Memory allocation error. dimx=%d, dimy=%d  .\n",dimx,dimy);
        return U_ERROR;;
    }
    SetBitMapHeader();
    SetColorTable();

    return SetImage(data, Set255To0);
}

ErrorType UBitMap::SetImage(const unsigned char* data, bool Set255To0)
/*
    Set the image, assuming that data[] consists of ihdr.biHeight rows of
    ihdr.biWidth pixels wide each.
    Furthermore, it is assumed that the number of bytes allocated for the image
    (at BitMapArr) equals BM_HDRSIZE8B + (ihdr.biWidth+extrax)*ihdr.biHeight
 */
{
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SetImage(). Invalid NULL input. \n");
        return U_ERROR;
    }
    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SetImage(). BitMapArr==NULL. \n");
        return U_ERROR;
    }

    const unsigned char  nul[4] = {0,0,0,0};
          unsigned char* pBMA   = BitMapArr+BM_HDRSIZE8B;
    const unsigned char* pdata  = data;
    if(Set255To0==true)
    {
        unsigned char Tab[256];
        for(int k=0; k<256; k++) Tab[k] = (unsigned char)(k); Tab[255] = 0;
        for(int y=0; y<ihdr.biHeight; y++)
        {
            for(int x=0; x<ihdr.biWidth; x++) *pBMA++ = Tab[*pdata++];
            if(extrax) memcpy(pBMA, nul, extrax);  // Add zeroes to obtain a multiple of 4 in witdth
            pBMA  += extrax;
        }
    }
    else
    {
        if(extrax)
        {
            for(int y=0; y<ihdr.biHeight; y++)
            {
                memcpy(pBMA, pdata, ihdr.biWidth);
                pBMA  += ihdr.biWidth;
                memcpy(pBMA, nul, extrax);  // Add zeroes to obtain a multiple of 4 in witdth
                pBMA  += extrax;
                pdata += ihdr.biWidth;
            }
        }
        else
            memcpy(BitMapArr+BM_HDRSIZE8B, data, fhdr.bfSize-BM_HDRSIZE8B);
    }

    return U_OK;
}

ErrorType UBitMap::MixImage(const unsigned char* data, int posx, int posy) const
/*
    Add the image data, contained in data[], to the existing image,
    by replacing the part upper left and lower right to the poosition
    indicated by posx and posy.

    Notes:
    - If(data==NULL) return without copying.
    - it is assumed that the dimensions of data[] and the existing image are equal.
    - If posx and/or posy are out of range, ignore them, dependend on the direction
      of teir out of ranges.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::MixImage(). BitMapArr==NULL. \n");
        return U_ERROR;
    }
    if(data==NULL) return U_ERROR;

    int dimx = ihdr.biWidth;
    if(posx>=dimx) posx = dimx-1;
    if(posx<0    ) posx = 0;

          unsigned char* pBMA   = BitMapArr+BM_HDRSIZE8B;
    const unsigned char* pdata  = data;
    int                  nxr    = dimx-1-posx;
    for(int y=0; y<ihdr.biHeight; y++)
    {
        if(y<posy)
        {
            if(posx) memcpy(pBMA, pdata, posx);
        }
        else
        {
            if(nxr)  memcpy(pBMA+posx, pdata+posx, nxr);
        }
        pBMA  += dimx+extrax;
        pdata += dimx;
    }
    return U_OK;
}

ErrorType UBitMap::ConvertMonochrome(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::ConvertMonochrome(). BitMapArr==NULL. \n");
        return U_ERROR;
    }
    if(ihdr.biBitCount==1) return U_OK;
    if(ihdr.biBitCount!=8) 
    {
        CI.AddToLog("ERROR: UBitMap::ConvertMonochrome(). Function only works with 8 bits pixels. \n");
        return U_ERROR;
    }
    int dimx  = ihdr.biWidth ;
    int dimy  = ihdr.biHeight;
    int nbyte = (dimx+7)/8;

    int newextrax  = (nbyte%4) ? (4-nbyte%4) : 0;
    int NewSize    = BM_HDRSIZE1B + (nbyte+newextrax)*dimy;

    unsigned char* NewBitMapArr = new unsigned char[NewSize];
    if(NewBitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::ConvertMonochrome(). Memory allocation error. dimx=%d, dimy=%d  .\n",dimx,dimy);
        return U_ERROR;
    }

    unsigned char*    data =    BitMapArr+BM_HDRSIZE8B;
    unsigned char* Newdata = NewBitMapArr+BM_HDRSIZE1B;
    for(int i=0; i<dimy; i++)
    {
        for(int j=0, n=0; n<nbyte+newextrax; n++)
        {
            int bit=1;
            int out=0;
            for(int k=0; k<8&&j<dimx; k++, j++, bit<<=1)
            {
                if(data[i*(dimx+extrax)+j]) out|=bit;
            }
            Newdata[i*(nbyte+newextrax)+n] = out;
        }        
    }

    extrax              = newextrax;
    fhdr.bfType         = BM_SIGNATURE;   // "BM"
    fhdr.bfSize         = NewSize;
    fhdr.bfRes1         = 0;
    fhdr.bfRes2         = 0;
    fhdr.bfOffBits      = BM_HDRSIZE1B;

    ihdr.biSize         = 40;
    ihdr.biWidth        = dimx;
    ihdr.biHeight       = dimy;
    ihdr.biPlanes       = 1;
    ihdr.biBitCount     = 1;
    ihdr.biCompression  = 0;
    ihdr.biSizeImage    = (nbyte+newextrax)*dimy;
    ihdr.biXPelsPerMeter= 0;
    ihdr.biYPelsPerMeter= 0;
    ihdr.biClrUsed      = 0;
    ihdr.biClrImportant = 0;
    SetBitMapHeader();
    ctab[0].red         = 255;
    ctab[0].green       = 255;
    ctab[0].blue        = 255;
    ctab[0].reserved    =   0;
    ctab[1].red         =   0;
    ctab[1].green       =   0;
    ctab[1].blue        =   0;
    ctab[1].reserved    =   0;
    SetColorTable();
    delete[] BitMapArr; BitMapArr = NewBitMapArr;

    return U_OK;
}

const unsigned char* UBitMap::GetBitMapImage(void) const
{
    return BitMapArr;
}

int UBitMap::GetBitMapSize(void) const
{
    return fhdr.bfSize;
}

ErrorType UBitMap::SaveFile(UFileName F) const
{
    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveFile(). NULL Image. \n");
        return U_ERROR;
    }
    F.ReplaceExtension(".bmp");

    FILE* fp = fopen(F, "wb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveFile(). Cannot open file %s .\n", F.GetFullFileName());
        return U_ERROR;
    }
    fwrite(BitMapArr, 1, GetBitMapSize(), fp);
    fclose(fp);

    return U_OK;
}

ErrorType UBitMap::SaveAsCpp(UFileName F, bool XPM) const
{
    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveAsCpp(). NULL Image. \n");
        return U_ERROR;
    }
    if(XPM==true)
    {
        if(ihdr.biBitCount!=4)
        {
            CI.AddToLog("ERROR: UBitMap::SaveAsCpp(). Invalid parameter in header: ihdr.biBitCount=%d. \n",ihdr.biBitCount);
            return U_ERROR;
        }
    }
    F.ReplaceExtension(".cpp");

    FILE* fp = fopen(F, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveAsCpp(). Cannot open file %s .\n", F.GetFullFileName());
        return U_ERROR;
    }

    if(XPM==false)
    {
        int nbytes = GetBitMapSize();
        fprintf(fp,"static unsigned char bitmap[] = {  \n ");
        for(int n=0; n<nbytes; n++)
        {
            if(n==nbytes-1)   fprintf(fp,"0x%2.2x};  ",BitMapArr[n]);
            else if((n+1)%20) fprintf(fp,"0x%2.2x,"   ,BitMapArr[n]);
            else              fprintf(fp,"0x%2.2x,\n ",BitMapArr[n]);
        }
    }
    else
    {
        char Table[16];
        memset(Table,'.',sizeof(Table));

        int nLine   = ihdr.biHeight;
        int nPixpl  = ihdr.biWidth;
        for(int ilin=0,k=0; ilin<nLine; ilin++)
        {
            for(int ipix=0; ipix<nPixpl; ipix++, k++)
            {
                int Byte = BitMapArr[fhdr.bfOffBits + k/2];
                int low  = Byte%16;
                int hig  = Byte/16;
                if(ipix%2) {if(low) Table[low] = (unsigned char)('a'+low);}
                else       {if(hig) Table[hig] = (unsigned char)('a'+hig);}
            }
            k+=2*(ihdr.biSizeImage/nLine)-nPixpl;
        }

        int nColUsed=1;
        for(int n=0; n<16; n++) if(Table[n]!='.') nColUsed++;

        UFileName BName = F; BName.RemoveExtension();

        fprintf(fp,"static const char *%s[] = {  \n ", BName.GetBaseName());
        fprintf(fp,"\"%d %d %d %d\",\n ",nPixpl,nLine, nColUsed+1, 1);
        fprintf(fp,"\"# c #000080\",\n ");
        int ic = 0;
        for(int n=0; n<16; n++)
            if(Table[n]!='.')
            {
                fprintf(fp,"\"%c c #%2.2x%2.2x%2.2x\",\n ",Table[n],ctab[ic].red,ctab[ic].green,ctab[ic].blue);
                ic++;
            }

        fprintf(fp,"\". c None\",\n ");

        for(int ilin=0,k=0; ilin<nLine; ilin++)
        {
            fprintf(fp,"\"");
            for(int ipix=0; ipix<nPixpl; ipix++, k++)
            {
                int Byte = BitMapArr[fhdr.bfOffBits + k/2];
                if(ipix%2) fprintf(fp,"%c",Table[Byte%16]);
                else       fprintf(fp,"%c",Table[Byte/16]);
            }
            k+=2*(ihdr.biSizeImage/nLine)-nPixpl;
            if(ilin<nLine-1) fprintf(fp,"\",\n ");
            else             fprintf(fp,"\"");
        }
        fprintf(fp,"};\n");
    }
    fclose(fp);

    return U_OK;
}

ErrorType UBitMap::SaveAsBinaryCpp(UFileName F) const
/*
   This version is meant to create cursors (QCursor -object) by initializing a QBitmap -object.
 */
{
    if(BitMapArr==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveAsBinaryCpp(). NULL Image. \n");
        return U_ERROR;
    }
    F.ReplaceExtension(".cpp");

    FILE* fp = fopen(F, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UBitMap::SaveAsBinaryCpp(). Cannot open file %s .\n", F.GetFullFileName());
        return U_ERROR;
    }
    unsigned char* data = BitMapArr+BM_HDRSIZE8B;
    fprintf(fp,"static unsigned char bitmap[] = {  \n");
    for(int i=0; i<ihdr.biHeight; i++)
    {
        fprintf(fp,"    ");
        for(int j=0; j+7<ihdr.biWidth; )
        {
            int bit=1;
            int out=0;
            for(int k=0; k<8; k++, j++, bit<<=1)
            {
                if(data[i*(ihdr.biWidth+extrax)+j]) out|=bit;
            }
            if(i<ihdr.biHeight-1 || j<ihdr.biWidth-7)
                fprintf(fp,"0x%2.2x,", out);
            else
                fprintf(fp,"0x%2.2x", out);
        }
        fprintf(fp,"\n");
    }
    fprintf(fp,"};\n");
    fclose(fp);

    return U_OK;
}

ErrorType UBitMap::SetBitMapHeader(void)
/*
    Copy the two bitmap header structs to the beginning of the bitmap pointer. (54 bytes)
    Mind the byte header data alignment
 */
{
    if(BitMapArr==NULL) return U_ERROR;

    unsigned char* pBitMap = BitMapArr;
    memcpy(pBitMap, &(fhdr.bfType),    2); pBitMap+=2;
    memcpy(pBitMap, &(fhdr.bfSize),    4); pBitMap+=4;
    memcpy(pBitMap, &(fhdr.bfRes1),    2); pBitMap+=2;
    memcpy(pBitMap, &(fhdr.bfRes2),    2); pBitMap+=2;
    memcpy(pBitMap, &(fhdr.bfOffBits), 4); pBitMap+=4;

    memcpy(pBitMap, &(ihdr.biSize),         4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biWidth),        4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biHeight),       4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biPlanes),       2); pBitMap+=2;
    memcpy(pBitMap, &(ihdr.biBitCount),     2); pBitMap+=2;
    memcpy(pBitMap, &(ihdr.biCompression),  4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biSizeImage),    4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biXPelsPerMeter),4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biYPelsPerMeter),4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biClrUsed),      4); pBitMap+=4;
    memcpy(pBitMap, &(ihdr.biClrImportant), 4); pBitMap+=4;

    return U_OK;
}

ErrorType UBitMap::SetColorTable(void)
{
    if(BitMapArr==NULL || ctab==NULL) return U_ERROR;

    unsigned char* pBitMap = BitMapArr+BM_CTABOFFSET;
    unsigned char* pctab   = (unsigned char*) &ctab;

    if(ihdr.biBitCount==1) for(int k=0; k<       8    ; k++)  *pBitMap++ = *pctab++;
    else                   for(int k=0; k<sizeof(ctab); k++)  *pBitMap++ = *pctab++;
    
    return U_OK;
}

ErrorType UBitMap::ConvertWhiteToGrey(void)
{
    if(BitMapArr==NULL || ctab==NULL) return U_ERROR;
    for(int k=0; k<256; k++)
    {
        if(ctab[k].red   <= 240  ) continue;
        if(ctab[k].green <= 240  ) continue;
        if(ctab[k].blue  <= 240  ) continue;

        ctab[k].red = ctab[k].green = ctab[k].blue = 240;
    }
    return SetColorTable();
}

PMT_RGBQUAD UBitMap::GetColor(unsigned char Value) const
/*
    Return the RGB value of the current color table, corresponding to the value Value
 */
{
    return ctab[Value];
}

PMT_RGBQUAD UBitMap::GetColor(double Fraction, PaletteType PL, bool Reverse)
{
    UBitMap Temp;
    Temp.SetPallette(PL);
    Fraction  = MIN(1. , MAX(0., Fraction));
    int index = int(floor(255 * Fraction));
    index     = MIN(255, MAX(0,  index));
    if(Reverse) index = 255-index;
    return Temp.ctab[index];
}

double UBitMap::GetDistance2(PMT_RGBQUAD c1, PMT_RGBQUAD c2)
{
    return  ((double)c1.red  -c2.red  )*((double)c1.red  -c2.red )  +
            ((double)c1.green-c2.green)*((double)c1.green-c2.green) +
            ((double)c1.blue -c2.blue )*((double)c1.blue -c2.blue);
}
