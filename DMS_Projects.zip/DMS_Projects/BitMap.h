#ifndef _BITMAP_INCLUDED
#define _BITMAP_INCLUDED


#include "FileName.h"

#define BM_HDRSIZE8B   1078  // in case of 256 colors
#define BM_HDRSIZE1B     62  // in case of   2 colors
#define BM_CTABOFFSET    54  // color table offset
#define BM_SIGNATURE  19778  // 'BM'

typedef struct 
{
    short bfType;
    int   bfSize;
    short bfRes1;
    short bfRes2;
    int   bfOffBits;
} PMT_BITMAPFILEHEADER;

typedef struct 
{
    int   biSize;
    int   biWidth;
    int   biHeight;
    short biPlanes;
    short biBitCount;
    int   biCompression;
    int   biSizeImage;
    int   biXPelsPerMeter;
    int   biYPelsPerMeter;
    int   biClrUsed;
    int   biClrImportant;
} PMT_BITMAPINFOHEADER;

typedef struct 
{
    unsigned char blue;
    unsigned char green;
    unsigned char red;
    unsigned char reserved;
} PMT_RGBQUAD;

enum PaletteType
{
    U_PALETTE_TRUE,
    U_PALETTE_GREY,
    U_PALETTE_RED,
    U_PALETTE_GREEN,
    U_PALETTE_BLUE,
    U_PALETTE_0,
    U_PALETTE_1,
    U_PALETTE_2,
    U_PALETTE_3,
    U_PALETTE_4,
    U_PALETTE_JET,
    U_PALETTE_BONE,
    U_PALETTE_HOT,
    U_PALETTE_COLD,
    U_PALETTE_HOTCOLD,
    U_PALETTE_GENERAL,
    U_PALETTE_POSNEG,
    U_PALETTE_NUMPALTYPE
};

PaletteType GetPaletteType(int itype);

class DLL_IO UBitMap 
{
public:
    UBitMap();
    UBitMap(ErrorType E);
    UBitMap(const UBitMap& BM);
    UBitMap(int dimx, int dimy);
    UBitMap(int dimx, int dimy, const unsigned char* data);
    UBitMap(int dimx, int dimy, bool vertical, bool reverse, PaletteType PL, int imin=-1, int imax=-1, bool WhiteAsGray=false, bool MaxToBack=false, bool Asym=false);
    UBitMap(UFileName F);
    ~UBitMap();
    UBitMap&             operator=(const UBitMap& BM);

    ErrorType            GetError(void) const {return error;}
    PMT_RGBQUAD          GetColor(unsigned char Value) const;
    static PMT_RGBQUAD   GetColor(double Fracion, PaletteType PL, bool Reverse);

    ErrorType            MixImage(const unsigned char* data, int posx, int posy) const;
    ErrorType            ConvertMonochrome(void);

    ErrorType            SetImage(const unsigned char* data, int dimx, int dimy, bool Set255To0=false);
    ErrorType            SetImage(const unsigned char* data, bool Set255To0=false);
    const unsigned char* GetBitMapImage() const;
    int                  GetBitMapSize(void) const;

    static PaletteType   ConvertToPalType(int index);
    ErrorType            SetPallette(PaletteType PL);
    ErrorType            SetPallette(const unsigned char* ColTab, int TabSize);
    ErrorType            SetPalletteFirst(unsigned char R, unsigned char G, unsigned char B);
    ErrorType            SetPalletteLast(unsigned char R, unsigned char G, unsigned char B);
    ErrorType            ReversePallette(void);
    ErrorType            ReOrderPallette(void);

    ErrorType            SaveFile(UFileName F) const;
    ErrorType            SaveAsCpp(UFileName F, bool XPM=false) const;
    ErrorType            SaveAsBinaryCpp(UFileName F) const;

    static double        GetDistance2(PMT_RGBQUAD c1, PMT_RGBQUAD c2);

protected:
    void                 SetAllMembersDefault(void);
    void                 DeleteAllMembers(ErrorType E);

private:
    ErrorType            error;
    int                  extrax;
    unsigned char*       BitMapArr;

    PMT_BITMAPFILEHEADER fhdr;
    PMT_BITMAPINFOHEADER ihdr;
    PMT_RGBQUAD          ctab[256];

    void                 InitDefaults(void);
    ErrorType            SetBitMapHeader(void);
    ErrorType            SetColorTable(void);
    ErrorType            ConvertWhiteToGrey(void);
};
#endif // _BITMAP_INCLUDED
