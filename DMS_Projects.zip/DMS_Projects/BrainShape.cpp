/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     This object contains the spherical harmonics coefficients describing`      */
/*     the surface of an object in spherical coordinates, with respect to a       */
/*     coordinate origing, named Origin.                                          */
/*     These coefficients can be created by fitting spherical harmonics functions */
/*     onto an array of 3D points.                                                */
/*                                                                                */
/*     With the object, arbitrary surface points can be computed, of which the    */
/*     spherical coordinates theta and fi are given.                              */
/*                                                                                */
/*     After Dennis van 't Ent                                                    */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    21-10-99   creation, made c++ object from C-functions of D. van 't Ent
  DvtE   14-12-99   added parameter Center (=origin of expansion) to function UBrainShape
  DvtE   14-12-99   added functions GetCoeff() and GetCenter()
  JdM    14-12-99   Use pointer to pass center of gravity to constructor. Test for NULL
 JdM/DvtE 15-12-99   Added new constructor.
  JdM    27-03-00   operator==() : Test whether this==&S
  JdM    29-03-00   Solve system of equations using the Jacobi decomposition
  JdM    30-03-00   Bug Fix: Made the computation of AtA in constructor truly symmetric.
                     Probably, this bug did not influence results, prior to 29-03-00
 DvT/JdM 31-03-00   Change sign of SphereHarm() (-1^m)
  JdM    04-04-00   Added constructor, based on "shape fitting", after D. van 't Ent
  JdM    28-11-00   Added PredictShape()
  JdM    03-03-01   Added new shape type : U_GENERAL
  JdM    24-06-01   Added new constructor
  JdM    25-06-01   Added new constructor, based on UPointList
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    25-10-02   Added GetRadius()
  JdM    17-12-02   Added parameter to some of the constructors, to regulate the truncation of the UJacobi-object
  JdM    15-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    12-12-09   Added copy constructor
  JdM    13-12-09   Inserted weights argument at points constructor
  JdM    15-12-09   Replaced private factrl() by global GetFactorial() (in BasicInclude.cpp)
  JdM    25-12-09   Added UseL1norm argument to several constructors. Used SolveL1Norm() and SolveL2Norm()
  JdM    07-05-10   Renamed USphereHarm as UBrainShape
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include "BrainShape.h"
#include "PointList.h"
#include "ShapeCoeffs.h"


#define EIGEN_THRESHOLD 1.e-8   // Eigen value truncation of inverted matrix, used
                                // in the computation of spherical harmonics coefficients.
/* Inititalize static const parameters. */
const  int UBrainShape::MAXNCOMP = MAX_NCOMP_BRAIN;  // defined in ShapeCoeffs.h

void UBrainShape::SetAllMembersDefault(void)
{
    error  = U_OK;
    Ncoeff = 0;
    coeff  = NULL;
    Origin = UVector3();
}
void UBrainShape::DeleteAllMembers(ErrorType E)
{
    delete[] coeff;
    SetAllMembersDefault();
    error  = E;
}

UBrainShape::UBrainShape()
{
    SetAllMembersDefault();
}
UBrainShape::UBrainShape(const UBrainShape &SH)
{
    SetAllMembersDefault();
    *this = SH;
}

UBrainShape::UBrainShape(int Ncoef, const double* coef, UVector3 Centre)
{
    SetAllMembersDefault();

    if(Ncoef>0)
    {
        Ncoeff = Ncoef;
        coeff  = new double[Ncoeff];
    }
    if(coeff==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(coef)  for(int k=0; k<Ncoeff; k++) coeff[k] = coef[k];
    else      for(int k=0; k<Ncoeff; k++) coeff[k] = 0.;

    Origin = Centre;
}

UBrainShape::UBrainShape(int Npoints, const UVector3* points, const double* W, int Nsph, UVector3* Centre, double TruncThresh, bool UseL1norm)
/*
    Create spherical harmonics coefficients by fitting spherical harmonics to
    a list of 3D points. With these coefficients, new points on the surface can be computed using
    SurfPoint(). The center of the coordinate system Center is computed by
    averaging the given points.

    Npoints   - the number of 3D points
    points[]  - an array of points to be fitted
    W[]       - weights (1/SD) of each point (if W==NULL, all weights are 1.0)
    Nsph      - the largest order of the spherical harmonics. The number of
                coefficients estimated equals (Nsph+1)*(Nsph+1)
    *Center   - the origin relative to which the spherical harmonic expansion is computed
                if this is NULL, take center of gravity as origin
    TruncThresh - truncation parameter for the system of linear equations. If(TruncThresh<0) use default.
 */
{
    SetAllMembersDefault();
    if(Npoints<=0 || points==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape(). Invalid argument(s). \n");
        return;
    }
    if(Centre)
    {
        Origin = *Centre;
    }
    else
    {
        Origin = UVector3();
        for(int n=0; n<Npoints; n++) Origin += points[n];
        if(Npoints) Origin = Origin /(double) Npoints;
    }

    if(Nsph < 0 || Nsph >= MAXFACTORIAL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape() :Bad arguments. Nsph = %d, Npoints = %d\n", Nsph, Npoints);
        return;
    }

    Ncoeff    = (Nsph+1)*(Nsph+1);
    if(Ncoeff>Npoints)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape() :Bad arguments. Ncoeff (= %d) > Npoints (= %d)\n", Ncoeff, Npoints);
        return;
    }
    coeff     = new double[Ncoeff];
    double* A = new double[Npoints*Ncoeff];
    double* r = new double[Npoints];

    if(coeff==NULL || A==NULL || r==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape() :Memory allocation Ncoeff = %d, Npoints = %d\n", Ncoeff, Npoints);
        delete[] A;
        delete[] r;
        return;
    }

// Compute the system matrix A
    for(int i=0; i<Npoints; i++)
    {
        UVector3 p  = points[i] - Origin;
        r[i]        = p.GetNorm();
        double Th   = p.GetTheta();
        double Fi   = p.GetFi();
        double Wei  = 1.0;
        if(W)  Wei  = fabs(W[i]);
        for(int k=0;k<Ncoeff; k++) A[i*Ncoeff+k] = Wei * GetSphereHarm(k, Th, Fi);
        r[i]       *= Wei;
    }

    if(UseL1norm)
    {
        if(SolveL1Norm(A, coeff,  r, Npoints, Ncoeff)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBrainShape::UBrainShape() : Solving system matrix \n");
            return;
        }
    }
    else
    {
        if(TruncThresh<0) TruncThresh = EIGEN_THRESHOLD;
        if(SolveL2Norm(A, coeff,  r, Npoints, Ncoeff, TruncThresh)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBrainShape::UBrainShape() : Solving system matrix \n");
            return;
        }
    }
}

UBrainShape::UBrainShape(UPointList* PL, int Nsph, UVector3* Center)
/*
    Create a UBrainShape object by fitting Nsph spherical harmonics onto the point list *PL, centered
    around *Center. if(Center==NULL) take center of gravity as center.
 */
{
    SetAllMembersDefault();

    if(Center) Origin = *Center;

    if(PL==NULL || PL->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape(). Erroneous UPointList pointer input. \n");
        return;
    }
    const UVector3* p = PL->GetPoints();
    *this = UBrainShape(PL->GetNpoints(), p, NULL, Nsph, Center);
}

UBrainShape::UBrainShape(int Npoints, const UVector3* points, int Ncomp, ShapeType ST, UVector3* Centre, double TruncThresh, bool UseL1norm)
/*
    Construct a UBrainShape-object by fitting a head-, skull- or cortext-shape
    onto a give point list, for a given center of gravity.

    Npoints   - the number of 3D points
    points[]  - an array of points to be fitted
    Ncomp     - The number of sigular values of the shape data-base taken into account
    ST        - Determines the shape that is fitted onto the points.
    *Center   - the origin relative to which the spherical harmonic expansion is computed
                if this is NULL, take center of gravity as origin
    TruncThresh - truncation parameter for the system of linear equations. If(TruncThresh<0) use default.

 */
{
    SetAllMembersDefault();
    if(Npoints<=0 || points==NULL || Ncomp<0 || Ncomp > MAX_NCOMP_BRAIN)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape(). Invalid argument(s). \n");
        return;
    }
    if(Centre)
    {
        Origin = *Centre;
    }
    else
    {
        Origin = UVector3();
        for(int n=0; n<Npoints; n++) Origin += points[n];
        if(Npoints) Origin = Origin /(double) Npoints;
    }

    if(ST==U_GENERAL)
    {
        *this = UBrainShape(Npoints, points, NULL, Ncomp, &Origin, TruncThresh);
        return;
    }
    if(ST!=U_SKIN && ST!=U_SKULL && ST!=U_CORTEX)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape(). Erroneous shape type: %d.\n",ST);
        return;
    }
    Ncoeff         = MAX_NCOEF_BRAIN;
    coeff          = new double[Ncoeff];
    double* LinPar = new double[Ncoeff];
    double* A      = new double[Npoints*Ncomp];
    double* r      = new double[Npoints];

    if(coeff==NULL || A==NULL || r==NULL || LinPar==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape() : Memory allocation \n");
        delete[] A;
        delete[] r;
        delete[] LinPar;
        return;
    }

/* Compute the system matrix A*/
    for(int i=0; i<Npoints; i++)
    {
        UVector3 p  = points[i] - Origin;
        r[i]        = p.GetNorm();
        double Th   = p.GetTheta();
        double Fi   = p.GetFi();

        double sharm[MAX_NCOEF_BRAIN];
        for(int n=0; n<MAX_NCOEF_BRAIN; n++) sharm[n] = GetSphereHarm(n,Th,Fi);

        for(int k=0; k<Ncomp; k++)
        {
            A[i*Ncomp+k] = 0;
            int n=0;
            switch(ST)
            {
            case U_SKIN:
                for(n=0; n<MAX_NCOEF_BRAIN; n++) A[i*Ncomp+k] += SkinCoef[k+n*MAX_NCOMP_BRAIN]*sharm[n];
                break;
            case U_SKULL:
                for(n=0; n<MAX_NCOEF_BRAIN; n++) A[i*Ncomp+k] += SkullCoef[k+n*MAX_NCOMP_BRAIN]*sharm[n];
                break;
            case U_CORTEX:
                for(n=0; n<MAX_NCOEF_BRAIN; n++) A[i*Ncomp+k] += CortexCoef[k+n*MAX_NCOMP_BRAIN]*sharm[n];
                break;
            }
        }
    }

    if(UseL1norm)
    {
        if(SolveL1Norm(A, LinPar,  r, Npoints, Ncomp)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            delete[] LinPar;
            CI.AddToLog("ERROR: UBrainShape::UBrainShape() : Solving system matrix \n");
            return;
        }
    }
    else
    {
        if(TruncThresh<0) TruncThresh = EIGEN_THRESHOLD;
        if(SolveL2Norm(A, LinPar,  r, Npoints, Ncomp, TruncThresh)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            delete[] LinPar;
            CI.AddToLog("ERROR: UBrainShape::UBrainShape() : Solving system matrix \n");
            return;
        }
    }
// Transform the Linear parameters into spherical harmonics coefficients
    Par2Coef(LinPar, Ncomp, ST);

    delete[] LinPar;
}

UBrainShape::UBrainShape(UVector3 Centre, double ScaleRad, ShapeType ST)
/*
   Initialize the coefficients according to the default (average) shape of
   the head, skull or brain, dependent on ST.
 */
{
    SetAllMembersDefault();

    Ncoeff = MAX_NCOEF_BRAIN;
    coeff  = new double[Ncoeff];
    if(coeff==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::UBrainShape(). Memory allocation. Ncoeff = %d  .\n", Ncoeff);
        return;
    }
    Origin = Centre;
    error  = Par2Coef(&ScaleRad, 1, ST);
}

UBrainShape::~UBrainShape()
{
    DeleteAllMembers(U_OK);
}

UBrainShape& UBrainShape::operator=(const UBrainShape &S)
{
    if(this==NULL)
    {
        static UBrainShape H; H.error = U_ERROR;
        CI.AddToLog("ERROR: UBrainShape::operator=(). this==NULL .\n");
        return H;
    }
    if(&S==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBrainShape::operator=(). Argument has NULL address.\n");
        return *this;
    }
    if(this==&S) return *this;

    DeleteAllMembers(U_OK);
    Origin = S.Origin;
    error  = S.error;
    Ncoeff = S.Ncoeff;
    if(S.coeff)
    {
        coeff = new double[Ncoeff];
        if(coeff==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBrainShape::operator=(). Memory allocation.\n");
            return *this;
        }
        for(int k=0; k<Ncoeff; k++) coeff[k] = S.coeff[k];
    }
    return *this;
}

ErrorType UBrainShape::ComputeErrors(int Npoints, const UVector3* points, double *Eps,
                double *Maxerr, int *Maxnode, double *Minerr, int *Minnode) const
/*
    A few error parameters are computed by computing the distances between the Npoints
    points points[] and the surface gerated by the spherical harmonics coefficients
    inside this object.

    Npoints   - the number of 3D points
    points[]  - an array of points to be fitted
    *Eps      - if(Eps) *Eps will contain the average distance between the true points and the
                estimated surface determined by the spherical harmonics
    *Maxerr   - if(Maxerr) *Maxerr will contain the largest distance between the true points
                and the estimated surface.
    *Maxnode  - if(Maxnode) *Maxnode will contain the index of the point with the largest error
    *Minerr   - if(Minerr) *Minerr will contain the smallest distance between the true points
                and the estimated surface.
    *Minnode  - if(Minnode) *Minnode will contain the index of the point with the smallest error

 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UBrainShape::ComputeErrors(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(coeff==NULL)
    {
        CI.AddToLog("ERROR: UBrainShape::ComputeErrors(). coeff==NULL. \n");
        return U_ERROR;
    }
    double MinEr=0., MaxEr =0.;
    int    MinNod=0, MaxNod=0 ;

    double AvEr = 0;
    for(int i=0; i<Npoints; i++)
    {
        UVector3 p  = points[i] - Origin;
        double   r  = p.GetNorm();
        double   Th = p.GetTheta();
        double   Fi = p.GetFi();

        double   Er = r;
        for(int k=0; k<Ncoeff; k++) Er -= coeff[k]*GetSphereHarm(k, Th, Fi);

        Er    = fabs(Er);  // The Error at point i
        AvEr += Er;

        if(i==0) MinEr  = MaxEr  = Er;
        if(Er<MinEr)
        {
            MinEr  = Er;
            MinNod = i;
        }
        if(Er>MaxEr)
        {
            MaxEr  = Er;
            MaxNod = i;
        }
    }
    AvEr   /= Npoints;

/* Copy results when required */
    if(Eps)     *Eps     = AvEr;
    if(Maxerr)  *Maxerr  = MaxEr;
    if(Minerr)  *Minerr  = MinEr;
    if(Maxnode) *Maxnode = MaxNod;
    if(Minnode) *Minnode = MinNod;

    return U_OK;
}


UVector3 UBrainShape::SurfPoint(double theta, double fi, double Roffset) const
{
    double r = Roffset;
    for(int k=0; k<Ncoeff; k++)
        r += coeff[k]*GetSphereHarm(k, theta, fi);
    return Origin + r*UVector3(theta, fi);
}

UVector3  UBrainShape::SurfPoint(UVector3 p) const
/*
    Return the point on the surface, closest to p.
 */
{
    double Theta = (p-Origin).GetTheta();
    double Fi    = (p-Origin).GetFi();
    return SurfPoint(Theta, Fi);
}

double UBrainShape::GetRadius(double theta, double fi)
/*
    Return the radial coordinate corresponding to (theta, fi)
 */
{
    double r = 0;
    for(int k=0; k<Ncoeff; k++)
        r += coeff[k]*GetSphereHarm(k, theta, fi);
    return r;
}

// private functions

double UBrainShape::plgndr(int l, int m, double x) const
/*
    Return associated Legendre polynomial Plm(x). Where m and l are
    integers satisfying 0<= m <=l, x lies in the range -1<= x <=1
    adapted from Numerical Recipes pp 254

    On error, return 0, and print message in log-file

    Dennis van 't Ent
*/
{
    if(m<0 || m>l || fabs(x) >1.0)
    {
        CI.AddToLog("ERROR: UBrainShape::plgndr() Bad arguments cos(th)=%f \n ",x);
        return 0;
    }

    double pmm=1.0;                               //compute Pm,m.
    if(m>0)
    {
        double somx2=sqrt((1.0-x)*(1.0+x));
        double fact =1.0;
        for(int i=1;i<=m;i++)
        {
            pmm *= -fact*somx2;
            fact+= 2.0;
        }
    }
    if(l==m)    return pmm;
                                     
    double pmmp1=x*(2*m+1)*pmm;   //compute Pm+1,m.
    if(l==m+1)  return pmmp1;
    
    double pll = 0;          //compute Pl,m, l>m+1.
    for(int ll=m+2;ll<=l;ll++)
    {
        pll   = (x*(2*ll-1)*pmmp1-(ll+m-1)*pmm)/(ll-m);
        pmm   = pmmp1;
        pmmp1 = pll;
    }
    return pll;
}

double UBrainShape::GetSphereHarm(int k, double Th, double Fi) const
/*
     Return the k-th spherical harmonic evaluated at theta=Th and fi=Fi
 */
{
    int n = int(floor(sqrt(k+.5)));   // Order
    int m = (k-n*n+1)/2;              // Degree

    if(m==0) return plgndr(n,0,cos(Th)); // Associated Legendre function

    double lgndr  = sqrt(2*GetFactorial(n-m)/GetFactorial(n+m))*plgndr(n,m,cos(Th));
    if(m%2) lgndr = -lgndr;

    if((k-n*n)%2) return cos(m*Fi)*lgndr;
    return sin(m*Fi)*lgndr;
}

ErrorType UBrainShape::Par2Coef(const double *LinPar, int Ncomp, ShapeType ST)
 /*
     Convert SVD parameters into spherical harmonics coefficients
 */
{
    if(coeff==NULL) return U_ERROR;

    for(int n=0; n<MIN(Ncoeff,MAX_NCOEF_BRAIN); n++)
    {
        int k=0;
        coeff[n] = 0;
        switch(ST)
        {
        case U_SKIN:
            for(k=0; k<MIN(Ncomp,MAX_NCOMP_BRAIN); k++) coeff[n] += SkinCoef[k+n*MAX_NCOMP_BRAIN]*LinPar[k];
            break;
        case U_SKULL:
            for(k=0; k<MIN(Ncomp,MAX_NCOMP_BRAIN); k++) coeff[n] += SkullCoef[k+n*MAX_NCOMP_BRAIN]*LinPar[k];
            break;
        case U_CORTEX:
            for(k=0; k<MIN(Ncomp,MAX_NCOMP_BRAIN); k++) coeff[n] += CortexCoef[k+n*MAX_NCOMP_BRAIN]*LinPar[k];
            break;
        default:
            CI.AddToLog("ERROR: UBrainShape::Par2Coef(). Erroneous shape type.\n");
        }
    }
    if(Ncoeff>MAX_NCOEF_BRAIN || Ncomp>MAX_NCOMP_BRAIN) return U_ERROR;
    return U_OK;
}

ErrorType UBrainShape::PredictShape(ShapeType PredST) const
/*
    Replace the spherical harmonics coefficients by those of the "best fitting"
    skull or cortex. For that purpose, a linear prediction model is used, of
    which the coefficients are present in the include file.

    Note: In this function it is assumed that the current spherical harmonics coefficients
          represent the skin of a subject.
 */
{
    int i=0;
    const double alpha = 0.05;
    switch(PredST)
    {
    case U_NOSHAPE: return U_OK;
    case U_SKIN:    return U_OK;
    case U_SKULL:
        for(i=0;i<MIN(Ncoeff,MAX_NCOEF_BRAIN);i++)
        {
            if(SkullAlpha[i]<=alpha) coeff[i] = SkullSlope[i]*coeff[i]+SkullOffset[i];
            else                     coeff[i] = SkullMean[i];
        }
        return U_OK;

    case U_CORTEX:
        for(i=0;i<MIN(Ncoeff,MAX_NCOEF_BRAIN);i++)
        {
            if(CortexAlpha[i]<=alpha) coeff[i] = CortexSlope[i]*coeff[i]+CortexOffset[i];
            else                      coeff[i] = CortexMean[i];
        }
        return U_OK;

    default:
        return U_ERROR;
    }
}
