/*
  Update history
  
  Who    When       What
  JdM    14-12-99   Changed GetCentre() into GetOrigin() (more logical name)
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    07-05-10   Renamed USphereHarm as UBrainShape
*/

#ifndef _BRAINSHAPE_INCLUDED
#define _BRAINSHAPE_INCLUDED

#include "MatVec.h"

class UPointList;

class UBrainShape
{
public:
    enum ShapeType
    {
        U_NOSHAPE,
        U_GENERAL,
        U_SKIN,
        U_SKULL,
        U_CORTEX
    };
    UBrainShape();
    UBrainShape(const UBrainShape &SH);
    UBrainShape(int Npoints, const UVector3* points, const double* W, int Nsph, UVector3* Centre = NULL, double TruncThresh=-1, bool UseL1norm = false);
    UBrainShape(int Ncoef, const double* coef, UVector3 Centre = UVector3());
    UBrainShape(int Npoints, const UVector3* points, int Nsingvar, ShapeType ST, UVector3* Center = NULL, double TruncThresh=-1, bool UseL1norm = false);
    UBrainShape(UVector3 Centre, double ScaleRad, ShapeType ST);
    UBrainShape(UPointList* PL, int Nsph, UVector3* Center = NULL);

    virtual ~UBrainShape();
    UBrainShape&        operator=(const UBrainShape &SH);
    
    ErrorType           GetError(void) const {return error;}
    const double*       GetCoeff(void) const {return coeff;}
    UVector3            GetOrigin(void) const {return Origin;}
    UVector3            SurfPoint(double theta, double fi, double Roffset=0.) const;
    UVector3            SurfPoint(UVector3 p) const;
    double              GetRadius(double theta, double fi);

    ErrorType           PredictShape(ShapeType PredST) const;
    ErrorType           ComputeErrors(int Npoints, const UVector3* points, double *Eps=NULL, double *Maxerr=NULL, 
                                      int *Maxnode=NULL, double *Minerr=NULL, int *Minnode=NULL) const;

    const static int    MAXNCOMP; // The maximum number of singular values included in the shape fit algorithm

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;    // General error flag
    int                 Ncoeff;   // The number of spherical harmonics coefficients
    double*             coeff;    // An array containing the spherical harmonics coefficients
    UVector3            Origin;   // The origin w.r.t. which the theta and fi angles are defined

    double              plgndr(int l, int m, double x) const;
    ErrorType           Par2Coef(const double *LinPar, int Ncomp, ShapeType ST);
    double              GetSphereHarm(int k, double Th, double Fi) const;
};

#endif// _BRAINSHAPE_INCLUDED
