/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for checking and setting the filenames of a CTF data set           */
/*     Within the CTF conventions, all data of one recording is stored in a      */
/*     separate directory, with extension "ds". In this directory files have     */
/*     standard names and extensions. By simply giving the name of a data set    */
/*     (with or without extions), this object determines names of the filenames, */
/*     allocates and releases memory for these standard names, and tests whether */
/*     the files (or data set exists).                                           */
/*     Furthermore, this object is capable of reading/writing some of the        */
/*     standard files, like BadChannels and the .hc-file.                        */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*     This object also works under HP-UNIX                                      */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    15-07-98	creation, Update history, Merged HCFile.cpp
  JdM    08-10-98	separated include-files
  JdM    28-12-98	added more detailed comments 
GdV/JdM  06-05-99   Removed "\" to be compatible with GNU compiler

  JdM    23-06-98   creation
  JdM    03-07-98   Minor BUG Fix: Make filename from data setname, if no "\\" occurs in the name
  JdM    15-07-98   Added reading and writing of .hc-files (HCFile.cpp)
  JdM    18-08-98   Added the name of the markerfile (*.mrk), make Badchannel filename in any case
  JdM    11-09-98   Minor modification in MergePathFileName()
  JdM    08-10-98   separated include-files
  JdM    05-11-98   Do not delete DataSetName[] when data-set does not exist
                    Added IsPureFile()
  JdM    13-11-98   Compatibility with UNIX, added U_NOACCES to define the status of a directory
  JdM    16-11-98   Extended MergePathFileName(), made IsPureFileName() private
  JdM    20-12-98   Added more comments.
  JdM    22-02-99   Added default constructor.
  JdM    28-02-99   Separated off the directory manipulation parts. That part is now implemented in
                    the UDirectory-object, which is now a private data member of UCTFDataSet()
  JdM    01-04-99   Added class-filenames and GoodChannel-file
  JdM    06-06-99   Increase the number of characters that are used in Good and Bad labels, and make a const of it.
  JdM    12-06-99   Allow both carriage returns and linefeeds in GoodChannel /BadChannel file 
                    BUG-FIX in operator= : delete[] BadChannels i.s.o. GoodChannels
  JdM    15-04-99   Add MEG Fiducials as private variables.
  JdM    23-04-99   BUG-FIX in creating dataset directory name
  JdM    13-01-00   Merged with HCFile.cpp, which is now obsolete
  FB     10-07-03   Made argument Labels in WriteChannels() const
  JdM    18-01-00   Added GetProperties()
  JdM    27-03-00   operator==() : Test whether this==&d
  JdM    30-03-00   Bug Fix in GetProperties(). Avoid writing beyond array boundaries, for too many Bad Channels
DvT/JdM  16-05-00   Added BackUpMarkerFile()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
                    Added default spatial covariance file name
  JdM    08-08-00   Added default temporal covariance file name
  JdM    25-08-00   Added GetSubDS() added GetError()
  JdM    13-12-00   Error handling of .hc-file
  JdM    23-01-01   Handling void .hc-file
  JdM    19-02-01   Added CopyFiducialsTo(). Also read NLR in dewar coordinates
  JdM    25-09-01   Added DoesHCexist() 
  JdM    28-09-01   Added Possibility to derive good and bad channels from arguments instead from files
  JdM    11-11-01   Added GetChanneldFromString(): allow separators in forced good and bad channel strings
  JdM    22-11-01   Handling void .hc-file: only test first 20 characters
  JdM    15-03-02   New FullOutputFileName()
  JdM    05-06-02   Improved error handling in constructor.
  JdM    04-07-02   Added WriteChannels()
  JdM    30-11-03   Remove standard message that .hc file does not exist (in constructor)
  JdM    17-02-04   Remove WARNING on the truncation of data set name.
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "CTFDataSet.h"
#include "Euler.h"


/* Inititalize static const parameters. */
const int    UCTFDataSet::MAXLABELSIZE    =  8;
const int    UCTFDataSet::MAXPROPERTIES   =  800;

#define BADCHANNAME    "BadChannels"
#define GOODCHANNAME   "GoodChannels"
#define MARKERNAME     "MarkerFile.mrk"
#define CLASSNAME      "ClassFile.cls"
#define SPATCOVARNAME  "CovarXX.cov"
#define TEMPCOVARNAME  "CovarTT.cov"

const char *hcText[9]={
    "standard nasion coil position relative to dewar (cm):",
    "standard left ear coil position relative to dewar (cm):",
    "standard right ear coil position relative to dewar (cm):",
    "measured nasion coil position relative to dewar (cm):",
    "measured left ear coil position relative to dewar (cm):",
    "measured right ear coil position relative to dewar (cm):",
    "measured nasion coil position relative to head (cm):",
    "measured left ear coil position relative to head (cm):",
    "measured right ear coil position relative to head (cm):"
};

const char *hcEmptyText = "Unable to make head coil file.";


void UCTFDataSet::SetAllMembersDefault(void)
{
    error             = U_OK;
    DirDS             = UDirectory();
    FullCTFFileName   = NULL;
    BadChanFileName   = NULL;
    GoodChanFileName  = NULL;
    HCFileName        = NULL;
    MarkerFileName    = NULL;
    ClassFileName     = NULL;
    SpatCovarFileName = NULL;
    TempCovarFileName = NULL;
    BadChannels       = NULL;
    GoodChannels      = NULL;
    nBad              = 0;
    nGood             = 0;
    BadChanFromFile   = true;
    GoodChanFromFile  = true;

    for(int k=0; k<MAX_MEG_FIDUCIALS; k++)
    {
        FiducialsHead[k]  = UVector3();
        FiducialsDewar[k] = UVector3();
    }
    Properties        = NULL;
}
void UCTFDataSet::DeleteAllMembers(ErrorType E) 
{
    delete[] Properties;
    delete[] FullCTFFileName;
    delete[] HCFileName;
    delete[] MarkerFileName;
    delete[] ClassFileName;
    delete[] SpatCovarFileName;
    delete[] TempCovarFileName;
    delete[] BadChanFileName;
    delete[] GoodChanFileName;

    if(nBad) 
    {
        for(int ib=0; ib<nBad+1;ib++) delete[] BadChannels[ib];
        delete[] BadChannels;
    }
    if(nGood) 
    {
        for(int ig=0; ig<nGood+1;ig++) delete[] GoodChannels[ig];
        delete[] GoodChannels;
    }

    SetAllMembersDefault();
    error = E;
}

UCTFDataSet::UCTFDataSet()
{
    SetAllMembersDefault();
    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL) 
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    memset(Properties, 0, MAXPROPERTIES);
}

UCTFDataSet::UCTFDataSet(const UCTFDataSet &d)
{
    SetAllMembersDefault();
    *this = d;
}

UCTFDataSet& UCTFDataSet::operator=(const UCTFDataSet &d)
{
    if(this==NULL)
    {
        static UCTFDataSet D; D.error = U_ERROR;
        CI.AddToLog("ERROR: UCTFDataSet::operator=(). this==NULL .\n");
        return D;
    }
    if(&d==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCTFDataSet::operator=(). Invalid NULL address argument. \n");
        return *this;
    }
    if(this==&d) return *this;

    DeleteAllMembers(U_OK);

    if(d.Properties) Properties = new char[MAXPROPERTIES];
    if(Properties) memset(Properties, 0, MAXPROPERTIES);
    
    for(int k=0; k<MAX_MEG_FIDUCIALS; k++)
    {
        FiducialsHead[k]  = UVector3();
        FiducialsDewar[k] = UVector3();
    }

    if(d.FullCTFFileName)
    {
        size_t nbytes = strlen(d.FullCTFFileName);
        FullCTFFileName = new char[nbytes+1];        
        if(FullCTFFileName) 
        {
            memcpy(FullCTFFileName, d.FullCTFFileName, nbytes);
            FullCTFFileName[nbytes] = 0;
        }
    }
    if(d.HCFileName)
    {
        size_t nbytes = strlen(d.HCFileName);
        HCFileName = new char[nbytes+1];
        if(HCFileName) 
        {
            memcpy(HCFileName, d.HCFileName, nbytes);
            HCFileName[nbytes] = 0;
        }
    }
    if(d.MarkerFileName)
    {
        size_t nbytes = strlen(d.MarkerFileName);
        MarkerFileName = new char[nbytes+1];
        if(MarkerFileName) 
        {
            memcpy(MarkerFileName, d.MarkerFileName, nbytes);
            MarkerFileName[nbytes] = 0;
        }
    }
    if(d.ClassFileName)
    {
        size_t nbytes = strlen(d.ClassFileName);
        ClassFileName = new char[nbytes+1];
        if(ClassFileName) 
        {
            memcpy(ClassFileName, d.ClassFileName, nbytes);
            ClassFileName[nbytes] = 0;
        }
    }
    if(d.SpatCovarFileName)
    {
        size_t nbytes = strlen(d.SpatCovarFileName);
        SpatCovarFileName = new char[nbytes+1];
        if(SpatCovarFileName) 
        {
            memcpy(SpatCovarFileName, d.SpatCovarFileName, nbytes);
            SpatCovarFileName[nbytes] = 0;
        }
    }
    if(d.TempCovarFileName)
    {
        size_t nbytes = strlen(d.TempCovarFileName);
        TempCovarFileName = new char[nbytes+1];
        if(TempCovarFileName) 
        {
            memcpy(TempCovarFileName, d.TempCovarFileName, nbytes);
            TempCovarFileName[nbytes] = 0;
        }
    }
    if(d.BadChanFileName)
    {
        size_t nbytes = strlen(d.BadChanFileName);
        BadChanFileName = new char[nbytes+1];
        if(BadChanFileName) 
        {
            memcpy(BadChanFileName, d.BadChanFileName, nbytes);
            BadChanFileName[nbytes] = 0;
        }
    }
    if(d.GoodChanFileName)
    {
        size_t nbytes = strlen(d.GoodChanFileName);
        GoodChanFileName = new char[nbytes+1];
        if(GoodChanFileName) 
        {
            memcpy(GoodChanFileName, d.GoodChanFileName, nbytes);
            GoodChanFileName[nbytes] = 0;
        }
    }

    if( Properties==NULL                             ||
        (!FullCTFFileName   && d.FullCTFFileName  )  ||
        (!HCFileName        && d.HCFileName       )  ||
        (!MarkerFileName    && d.MarkerFileName   )  ||
        (!ClassFileName     && d.ClassFileName    )  ||
        (!SpatCovarFileName && d.SpatCovarFileName)  ||
        (!TempCovarFileName && d.TempCovarFileName)  ||
        (!BadChanFileName   && d.BadChanFileName  )  ||
        (!GoodChanFileName  && d.GoodChanFileName )  )
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCTFDataSet::operator=(). Memory allocation. \n");
        return *this;
    }
    DirDS             = d.DirDS;
    BadChanFromFile   = d.BadChanFromFile;
    GoodChanFromFile  = d.GoodChanFromFile;

    if(nBad) 
    {
        for(int ib=0; ib<nBad+1;ib++) delete[] BadChannels[ib];
        delete[] BadChannels;
        BadChannels = NULL;
    }
    nBad = d.nBad;
    if(nBad)
    {
        BadChannels = new char*[nBad+1]; 
        if(BadChannels)
        {
            for(int k=0; k<nBad+1; k++)
            {
                BadChannels[k] = new char[MAXLABELSIZE];
                memcpy(BadChannels[k], d.BadChannels[k], MAXLABELSIZE);
            }
        }
        else
            error = U_ERROR;
    }
    if(nGood) 
    {
        for(int ig=0; ig<nGood+1;ig++) delete[] GoodChannels[ig];
        delete[] GoodChannels;
        GoodChannels = NULL;
    }
    nGood = d.nGood;
    if(nGood)
    {
        GoodChannels = new char*[nGood+1];
        if(GoodChannels)
        {
            for(int k=0; k<nGood+1; k++)
            {
                GoodChannels[k] = new char[MAXLABELSIZE];
                memcpy(GoodChannels[k], d.GoodChannels[k], MAXLABELSIZE);
            }
        }
        else
            error = U_ERROR;
    }
    for(int k=0; k<MAX_MEG_FIDUCIALS; k++)
    {
        FiducialsHead[k]  = d.FiducialsHead[k];
        FiducialsDewar[k] = d.FiducialsDewar[k];
    }

    error = d.error;
    return *this;
}


UCTFDataSet::UCTFDataSet(const char *DSet, const char* forceGoodCh, const char* forceBadCh)
/* 
   Set Defaults 
 */
{
    Properties       = new char[MAXPROPERTIES];
    if(Properties) memset(Properties, 0, MAXPROPERTIES);

    FullCTFFileName   = NULL;
    BadChanFileName   = NULL;
    GoodChanFileName  = NULL;
    HCFileName        = NULL;
    MarkerFileName    = NULL;
    ClassFileName     = NULL;
    SpatCovarFileName = NULL;
    TempCovarFileName = NULL;
    BadChannels       = NULL;
    GoodChannels      = NULL;
    nBad              = 0;
    nGood             = 0;
    BadChanFromFile   = true;
    if(forceBadCh)
    {
        BadChanFromFile = false;
        if(GetChanneldFromString(forceBadCh, &nBad, &BadChannels)!=U_OK)
        {
            error = U_ERROR;
            CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Getting bad channels from string: %s\n", forceBadCh);
            return;
        }
    }
    GoodChanFromFile  = true;
    if(forceGoodCh)
    {
        GoodChanFromFile = false;
        if(GetChanneldFromString(forceGoodCh, &nGood, &GoodChannels)!=U_OK)
        {
            error = U_ERROR;
            CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Getting good channels from string: %s\n", forceGoodCh);
            return;
        }
    }

    for(int k=0; k<MAX_MEG_FIDUCIALS; k++)
    {
        FiducialsHead[k]  = UVector3();
        FiducialsDewar[k] = UVector3();
    }

    if(Properties==NULL)  
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Memory allocation in Properties string. \n");
        return;
    }
    if(DSet==NULL)  
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Erroneous NULL argument. \n");
        return;
    }

/* Make Dataset name and determine status*/
    if(strstr(DSet,".ds") == NULL) 
    {
        char* DataSetName =  new char[strlen(DSet)+6];
        if(DataSetName==NULL)
        {
            error = U_ERROR;
            CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Memory allocation in data set name. \n");
            return;
        }
        sprintf(DataSetName,"%s", DSet);
        strncat(DataSetName,".ds",3);
        DataSetName[strlen(DataSetName)+1] = 0;
        DirDS = UDirectory(DataSetName, CNULL);
        delete[] DataSetName;        
    }
    else
    {
        char* DataSetName = new char[strlen(DSet)+2];
        sprintf(DataSetName,"%s", DSet);
        char *substr = strstr(DataSetName,".ds");
        while( strstr(substr+3,".ds") != NULL)  substr = strstr(substr+3,".ds");

        if(substr[3]!=0) substr[3] = 0;        
        DirDS = UDirectory(DataSetName, CNULL);
        delete[] DataSetName;        
    }

    if(DirDS.GetStatus() == UDirectory::U_NOSTAT) 
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UCTFDataSet::UCTFDataSet(). Directory status cannot be determined. (%s)\n", DirDS.GetDirectoryName());
        return;
    }

/* Make Filenames*/    
    UFileName BaseName = DirDS.GetBaseName(); BaseName.RemoveExtension();
    FullCTFFileName    = DirDS.MergeDirFileExt((const char*)BaseName,0,".res4");
    HCFileName         = DirDS.MergeDirFileExt((const char*)BaseName,0,".hc");
    MarkerFileName     = DirDS.MergeDirFileExt(MARKERNAME);
    ClassFileName      = DirDS.MergeDirFileExt(CLASSNAME);
    SpatCovarFileName  = DirDS.MergeDirFileExt(SPATCOVARNAME);
    TempCovarFileName  = DirDS.MergeDirFileExt(TEMPCOVARNAME);
    BadChanFileName    = DirDS.MergeDirFileExt(BADCHANNAME);
    GoodChanFileName   = DirDS.MergeDirFileExt(GOODCHANNAME);    

    if(FullCTFFileName==NULL || HCFileName==NULL || MarkerFileName==NULL || ClassFileName==NULL ||
       SpatCovarFileName==NULL || TempCovarFileName==NULL || BadChanFileName==NULL || GoodChanFileName==NULL)
    {
        DirDS = UDirectory();
        delete[] FullCTFFileName;   FullCTFFileName   = NULL;
        delete[] HCFileName;        HCFileName        = NULL;
        delete[] MarkerFileName;    MarkerFileName    = NULL;
        delete[] ClassFileName;     ClassFileName     = NULL;
        delete[] SpatCovarFileName; SpatCovarFileName = NULL;
        delete[] TempCovarFileName; TempCovarFileName = NULL;
        delete[] BadChanFileName;   BadChanFileName   = NULL;
        delete[] GoodChanFileName;  GoodChanFileName  = NULL;
        error = U_ERROR;
        return;
    }

/* Find Bad Channels*/
    if(BadChanFromFile==true && DirDS.GetStatus()==UDirectory::U_EXIST)
    {
        FILE *fpBad = fopen(BadChanFileName,"rb");
        if(fpBad)
        {
            char ch;
            do
            {
                ch = getc(fpBad);
                if(ch==10) nBad++;
            }
            while(ch != EOF);
            rewind(fpBad);

            if(nBad)
            {
                BadChannels = new char*[nBad+1];
                int iBad  = 0;
                int kchar = 0;
                do
                {
                    if(kchar==0)
                    {
                        BadChannels[iBad] = new char[MAXLABELSIZE];
                        memset(BadChannels[iBad],0,MAXLABELSIZE);
                    }
                    ch = getc(fpBad);
                    if(kchar<MAXLABELSIZE-1 && ch!=EOF && ch!=10 && ch!=13) BadChannels[iBad][kchar] = ch;

                    if(ch==10) 
                    {
                        iBad++;
                        kchar = 0;
                    }
                    else if(ch!=13)
                        kchar++;
                }
                while(ch != EOF);
                BadChannels[nBad] = new char[MAXLABELSIZE];
                memset(BadChannels[nBad],0,MAXLABELSIZE);
            }
            fclose(fpBad);
        }
    }

/* Find Good Channels*/
    if(GoodChanFromFile==true && DirDS.GetStatus()==UDirectory::U_EXIST)
    {
        FILE *fpGood = fopen(GoodChanFileName,"rb");
        if(fpGood)
        {
            char ch;
            do
            {
                ch = getc(fpGood);
                if(ch==10) nGood++;
            }
            while(ch != EOF);
            rewind(fpGood);

            if(nGood)
            {
                GoodChannels = new char*[nGood+1];
                int iGood  = 0;
                int kchar = 0;
                do
                {
                    if(kchar==0)
                    {
                        GoodChannels[iGood] = new char[MAXLABELSIZE];
                        memset(GoodChannels[iGood],0,MAXLABELSIZE);
                    }
                    ch = getc(fpGood);
                    if(kchar<MAXLABELSIZE-1 && ch!=EOF && ch!=10 && ch!=13) GoodChannels[iGood][kchar] = ch;

                    if(ch==10) 
                    {
                        iGood++;
                        kchar = 0;
                    }
                    else if(ch!=13)
                        kchar++;
                }
                while(ch != EOF);
                GoodChannels[nGood] = new char[MAXLABELSIZE];
                memset(GoodChannels[nGood],0,MAXLABELSIZE);
            }
            fclose(fpGood);
        }
    }
    error = U_OK;
    if(DoesFileExist(HCFileName)==true) error = ReadHC();
}

UCTFDataSet::~UCTFDataSet()
{
    DeleteAllMembers(U_OK);
}

UCTFDataSet* UCTFDataSet::GetSubDS(const char *DSet) const
{
    if(DSet==NULL) return NULL;

    char* SubDSName = FullOutputFileName(DSet, 10);
    UCTFDataSet* NewDS = new UCTFDataSet(SubDSName);
    if(NewDS==NULL || NewDS->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCTFDataSet::GetSubDS(). Cannot create subdata set object: %s \n", SubDSName);
        delete[] SubDSName;
        return NULL;
    }
    delete[] SubDSName;
    return NewDS;
}

ErrorType UCTFDataSet::WriteChannels(const char* const* const Labels, int Nlabels, UFileName BaseName) const
/*
    Create a file with the format of BadChannels/GoodChannels, with Nlabels labels named 
    Labels[0],..., Labels[Nlabels-1] inside *this data set directory, with the name BaseName.

    Note1: The BadChannels[] and GoodChannels[] arrays of this object are not updated.
    Note2: In order to activate BaseName, it has to be renamed to BadChannels (or GoodChannels).
 */
{
    if(Labels==NULL || Nlabels<=0)
    {
        CI.AddToLog("ERROR: UCTFDataSet::WriteChannels(). Invalid (NULL) arguments.\n");
        return U_ERROR;
    }
    if(DirDS.GetStatus()!=UDirectory::U_EXIST)
    {
        CI.AddToLog("ERROR: UCTFDataSet::WriteChannels(). Data set does not exist: %s .\n", DirDS.GetDirectoryName());
        return U_ERROR;
    }
    UFileName F(DirDS, BaseName.GetBaseName());
    FILE* fp = fopen(F, "wb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCTFDataSet::WriteChannels(). File cannot be created : %s \n", F.GetFullFileName());
        return U_ERROR;
    }
    for(int k=0; k<Nlabels; k++)
    {
        if(Labels[k]==NULL)
        {
            CI.AddToLog("WARNING: UCTFDataSet::WriteChannels(). Label %d = NULL. Skip label.\n", k);
            continue;
        }
        for(int kk=0; kk<MAXLABELSIZE&&Labels[k][kk]; kk++)
            fprintf(fp,"%c",Labels[k][kk]);
        fprintf(fp,"\n");
    }
    fclose(fp);

    return U_OK;
}


ErrorType UCTFDataSet::BackUpMarkerFile(char* Extension) const
/*
     Make a copy of the existing marker file MarkerFile.mrk, to a new file in the data set directory,
     whose name is MarkerFile + Extension[].
 */
{
    if(Extension==NULL || Extension[0]==0) 
    {
		CI.AddToLog( "ERROR UCTFDataSet::BackUpMarkerFile(): No or NULL extension is given. Back up omitted .\n");
        return U_ERROR;
    }
    if(DoesFileExist(MarkerFileName)==false)
	{
		CI.AddToLog( "WARNING UCTFDataSet::BackUpMarkerFile(). Cannot open %s, back up omitted\n",MarkerFileName);
   		return U_OK;
	}  

// read existing markerfile
    FILE*	fpMark= fopen(MarkerFileName,"rb");
	if(fpMark==NULL)
	{
		CI.AddToLog( "ERROR UCTFDataSet::BackUpMarkerFile(): cannot open %s \n",MarkerFileName);
   		return U_ERROR;
	}  

    long size = GetFileSize(fpMark);
    char* buffer = new char[size];
    if(buffer==NULL)
    {
        fclose(fpMark);
        CI.AddToLog("ERROR: UCTFDataSet::BackUpMarkerFile(). Memory allocation. Size =%d\n",(int)size);
        return U_ERROR;
    }

    fread( buffer, sizeof( char ), size, fpMark );
    fclose(fpMark);

// write contents to backup file
    FILE*      fpBack = NULL;
    UDirectory dum    = UDirectory();
    char *BackupMarkerFileName      = dum.MergeDirFileExt(MarkerFileName,0,Extension);
    if(BackupMarkerFileName) fpBack = fopen(BackupMarkerFileName,"wb");
    delete[] BackupMarkerFileName;

	if(fpBack==NULL)
	{
        delete[] buffer;
		CI.AddToLog( "ERROR UCTFDataSet::BackUpMarkerFile(): cannot open %s \n",BackupMarkerFileName);
   		return U_ERROR;
	} 

    fwrite( buffer, sizeof( char ), size, fpBack );
    fclose(fpBack);

    delete[] buffer;
    return U_OK;
}

ErrorType  UCTFDataSet::CreateDataSet()
{
    return DirDS.CreateDir();
}

char* UCTFDataSet::FullOutputFileName(const char* FileName, int nAddChar) const
{
    return DirDS.MergeDirFileExt(FileName, nAddChar);
}

UFileName UCTFDataSet::FullOutputFileName(UFileName FileName) const
{
    return UFileName(FullOutputFileName(FileName.GetFullFileName()));
}

UVector3  UCTFDataSet::GetFiducials(int ifid) const 
{
    if(ifid<0||ifid>=MAX_MEG_FIDUCIALS) 
    {
        CI.AddToLog("ERROR: UCTFDataSet::GetFiducials(). Fuducial number out of range: %d\n",ifid);
        return UVector3();
    }
    return FiducialsHead[ifid];
}

ErrorType UCTFDataSet::CopyFiducialsTo(const UCTFDataSet* DSout) const
{
    if(DSout==NULL)
    {
        CI.AddToLog("ERROR: UCTFDataSet::CopyFiducialsTo(). NULL argument .\n");
        return U_ERROR;
    }
    UEuler XFM(FiducialsDewar[0], FiducialsDewar[1], FiducialsDewar[2]);
    return DSout->WriteHC(FiducialsHead, XFM.GetInverse());
}


ErrorType UCTFDataSet::WriteHC(const UVector3 *NLRhead, const UEuler &HeadToDewar) const 
/*
     Write a .hc-file.
     The array NLRhead contains the positions of the Nasion, Left Ear, Right Ear w.r.t. the head.
     The euler transform HeadToDewar contains the transform from head to dewar coordinates.
 */
{
    FILE* fp = fopen(HCFileName,"wb");
    if(fp==NULL) return U_ERROR;
    
    UVector3 v;
    fprintf(fp,"%s\n",hcText[0]);
    fprintf(fp,"\tx = 4\n");
    fprintf(fp,"\ty = 0\n");
    fprintf(fp,"\tz = 0\n");
    fprintf(fp,"%s\n",hcText[1]);
    fprintf(fp,"\tx = 0\n");
    fprintf(fp,"\ty = 4\n");
    fprintf(fp,"\tz = 0\n");
    fprintf(fp,"%s\n",hcText[2]);
    fprintf(fp,"\tx = 0\n");
    fprintf(fp,"\ty = -4\n");
    fprintf(fp,"\tz = 0\n");

    fprintf(fp,"%s\n",hcText[3]);
    v = HeadToDewar.xfm(NLRhead[0]);    
    fprintf(fp,"\tx = %f\n",v.Getx());
    fprintf(fp,"\ty = %f\n",v.Gety());
    fprintf(fp,"\tz = %f\n",v.Getz());

    fprintf(fp,"%s\n",hcText[4]);
    v = HeadToDewar.xfm(NLRhead[1]);    
    fprintf(fp,"\tx = %f\n",v.Getx());
    fprintf(fp,"\ty = %f\n",v.Gety());
    fprintf(fp,"\tz = %f\n",v.Getz());

    fprintf(fp,"%s\n",hcText[5]);
    v = HeadToDewar.xfm(NLRhead[2]);    
    fprintf(fp,"\tx = %f\n",v.Getx());
    fprintf(fp,"\ty = %f\n",v.Gety());
    fprintf(fp,"\tz = %f\n",v.Getz());

    fprintf(fp,"%s\n",hcText[6]);
    fprintf(fp,"\tx = %f\n",NLRhead[0].Getx());
    fprintf(fp,"\ty = %f\n",NLRhead[0].Gety());
    fprintf(fp,"\tz = %f\n",NLRhead[0].Getz());

    fprintf(fp,"%s\n",hcText[7]);
    fprintf(fp,"\tx = %f\n",NLRhead[1].Getx());
    fprintf(fp,"\ty = %f\n",NLRhead[1].Gety());
    fprintf(fp,"\tz = %f\n",NLRhead[1].Getz());

    fprintf(fp,"%s\n",hcText[8]);
    fprintf(fp,"\tx = %f\n",NLRhead[2].Getx());
    fprintf(fp,"\ty = %f\n",NLRhead[2].Gety());
    fprintf(fp,"\tz = %f\n",NLRhead[2].Getz());
    fclose(fp);
    return U_OK;
}

bool UCTFDataSet::DoesHCexist(void) const
{
    return DoesFileExist(HCFileName);
}

ErrorType  UCTFDataSet::ReadHC() 
{
/*
     Read a .hc-file.
     On output, the array NLRhead will contain the positions of the Nasion, Left Ear, 
     Right Ear w.r.t. head.
 */

    FILE* fp = NULL;
    if(HCFileName) fp=fopen(HCFileName,"rb");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UCTFDataSet::ReadHC(). Error reading file %s. \n", HCFileName);
        return U_ERROR;
    }
    char line[100];
    int  np=0;
    for(int k=0; k<1000; k++)
    {
        double x=0,y=0,z=0;
        fgets(line,99,fp);
        if(!strncmp(line,hcEmptyText, 20))
        {
            CI.AddToLog("WARNING: UCTFDataSet::ReadHC(). Head coil file is empty: %s. \n", HCFileName);
            return U_OK;
        }
        if(!strncmp(line,hcText[3],strlen(hcText[3])))  // Measured w.r.t. Dewar
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsDewar[0] = UVector3(x,y,z);
            np++;
        }
        if(!strncmp(line,hcText[4],strlen(hcText[4])))
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsDewar[1] = UVector3(x,y,z);
            np++;
        }
        if(!strncmp(line,hcText[5],strlen(hcText[5])))
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsDewar[2] = UVector3(x,y,z);
            np++;
        }

        if(!strncmp(line,hcText[6],strlen(hcText[6])))  // Measured w.r.t. Head
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsHead[0] = UVector3(x,y,z);
            np++;
        }
        if(!strncmp(line,hcText[7],strlen(hcText[7])))
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsHead[1] = UVector3(x,y,z);
            np++;
        }
        if(!strncmp(line,hcText[8],strlen(hcText[8])))
        {
            fgets(line,99,fp);
            x = GetCoordinate(line); 
            fgets(line,99,fp);
            y = GetCoordinate(line); 
            fgets(line,99,fp);
            z = GetCoordinate(line); 
            FiducialsHead[2] = UVector3(x,y,z);
            np++;
        }
        if(np==6) break;
    }
    fclose(fp);
    if(np==6)   return U_OK;
    
    CI.AddToLog("ERROR: UCTFDataSet::ReadHC(). Error reading file %s. np=%d\n", HCFileName,np);
    return U_ERROR;
}

double UCTFDataSet::GetCoordinate(const char *line) const 
{
    int k=0;
    for(   ; k<99; k++) if(line[k]=='=') break;
    return atof(line+k+1);
}

char* UCTFDataSet::GetProperties(char* Comment) const
{
    if(!Properties) return NULL;

    char Begin[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,15);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties, 0, MAXPROPERTIES);

    int nc = 0;

    nc += sprintf(Properties+nc,"%s DataSet     =%s%c",Begin,DirDS.GetDirectoryName(),End);
    if(DoesFileExist(FullCTFFileName)==true) 
        nc += sprintf(Properties+nc,"%s .res4-file does exist. %c",Begin,End);    
    else
        nc += sprintf(Properties+nc,"%s .res4-file does not exist. %c",Begin,End); 
    if(DoesFileExist(HCFileName)==true) 
    {
        nc += sprintf(Properties+nc,"%s .hc-file does exist. %c",Begin,End);    
        if(FiducialsHead[0]==UVector3() && 
           FiducialsHead[1]==UVector3() && 
           FiducialsHead[2]==UVector3())
        {
            nc += sprintf(Properties+nc,"%s .hc-file is void. %c",Begin,End);    
        }
    }
    else
        nc += sprintf(Properties+nc,"%s .hc-file does not exist. %c",Begin,End); 
    if(DoesFileExist(MarkerFileName)==true) 
        nc += sprintf(Properties+nc,"%s Marker file does exist. %c",Begin,End);    
    else
        nc += sprintf(Properties+nc,"%s Marker file does not exist. %c",Begin,End); 
    if(DoesFileExist(ClassFileName)==true) 
        nc += sprintf(Properties+nc,"%s Class file does exist. %c",Begin,End);    
    else
        nc += sprintf(Properties+nc,"%s Class file does not exist. %c",Begin,End); 
    
/* Fiducials*/
    nc += sprintf(Properties+nc,"%s%c",Begin,End); 
    nc += sprintf(Properties+nc,"%s MEG  FUDUCIALS:%c",Begin,End); 
    nc += sprintf(Properties+nc,"%s NASION = %s %c",Begin,FiducialsHead[0].GetProperties(),End); 
    nc += sprintf(Properties+nc,"%s LEFT   = %s %c",Begin,FiducialsHead[1].GetProperties(),End); 
    nc += sprintf(Properties+nc,"%s RIGHT  = %s %c",Begin,FiducialsHead[2].GetProperties(),End); 


/* Print bad and good channels*/
    nc += sprintf(Properties+nc,"%s%c",Begin,End); 
    if(BadChanFromFile==true) nc += sprintf(Properties+nc,"%s Bad Channels (from file): ",Begin); 
    else                      nc += sprintf(Properties+nc,"%s Bad Channels (from arguments): ",Begin); 
    for(int ib=0; ib<nBad; ib++) 
    {
        if(nc+MAXLABELSIZE+25>MAXPROPERTIES)
        {
            nc += sprintf(Properties+nc,"...%c",End);
            return Properties;
        }
        nc += sprintf(Properties+nc,"%s, ",BadChannels[ib]);
    }
    nc += sprintf(Properties+nc,"%c",End);

    if(GoodChanFromFile==true) nc += sprintf(Properties+nc,"%s Good Channels (from file): ",Begin); 
    else                       nc += sprintf(Properties+nc,"%s Good Channels (from arguments): ",Begin);     
    for(int ig=0; ig<nGood; ig++) 
    {
        if(nc+MAXLABELSIZE+15>MAXPROPERTIES)
        {
            nc += sprintf(Properties+nc,"...%c",End);
            return Properties;
        }
        nc += sprintf(Properties+nc,"%s, ",GoodChannels[ig]);
    }
    nc += sprintf(Properties+nc,"%c",End);

    if(nc>MAXPROPERTIES)
        CI.AddToLog("ERROR: UCTFDataSet::GetProperties(). Array overflow: nc=%d .\n",nc);
    return Properties;
}

ErrorType UCTFDataSet::GetChanneldFromString(const char* ChanString, int *Nchan, char*** Channels) const
{
    if(ChanString==NULL || Nchan==NULL || Channels==NULL) return U_ERROR;

    size_t nbytes = strlen(ChanString);
    int    kstart = 0;
    while(kstart<nbytes && (ChanString[kstart]==',' || ChanString[kstart]==';')) kstart++;

    int nKan       = 0;
    bool LabelChar = true;
    int k;
    for(    k=kstart; k<=nbytes; k++)
    {
        if(ChanString[k]==',' || ChanString[k]==';' || ChanString[k]=='\0')
        {
            if(LabelChar==true) nKan++;
            LabelChar = false;
        }
        else
            LabelChar = true;
    }

/* No channels?*/
    *Nchan = nKan;
    if(nKan==0)
    {
        *Channels = NULL;
        return U_OK;
    }


    *Channels = new char*[nKan+1];
    if(*Channels==NULL) return U_ERROR;

    int i;
    for(    i=0; i<nKan+1; i++)
    {
        (*Channels)[i]  = new char[MAXLABELSIZE];
        if((*Channels)[i]) 
            memset((*Channels)[i],0,MAXLABELSIZE);
    }

    int ic    = 0;    
    i         = 0;
    LabelChar = true;
    for(k=kstart; k<=nbytes; k++)
    {
        if(ChanString[k]==',' || ChanString[k]==';' || ChanString[k]=='\0')
        {
            if(LabelChar==true) 
            {
                i++;
                ic = 0;
            }
            LabelChar = false;
        }
        else
        {
            LabelChar = true;
            if(ic<MAXLABELSIZE-1)
            {
                (*Channels)[i][ic] = ChanString[k];
                ic++;
            }
        }
    }
    return U_OK;
}