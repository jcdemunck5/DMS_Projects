#ifndef _CTFDATASET_INCLUDED
#define _CTFDATASET_INCLUDED

#include"Directory.h"
#include"FileName.h"
#include"MatVec.h"

#define MAX_MEG_FIDUCIALS 3

class UEuler;

class DLL_IO UCTFDataSet
{
public:
    UCTFDataSet();
    UCTFDataSet(const UCTFDataSet &d);
    UCTFDataSet(const char *DSet, const char* forceGoodCh=NULL, const char* forceBadCh=NULL);

    ~UCTFDataSet();
    UCTFDataSet& operator=(const UCTFDataSet &d);
    char*     GetProperties(char* Comment=NULL) const;
    ErrorType GetError(void) const {return error;}

    UDirectory          GetDirectory(void)         const {return DirDS;}
    UDirectory::DirStat GetDataSetStatus(void)     const {return DirDS.GetStatus(); }
    const char*         GetDataSetName(void)       const {return DirDS.GetDirectoryName();}
    char*               GetCTFFileName(void)       const {return FullCTFFileName;}
    const char*         GetBADFileName(void)       const {return BadChanFileName;}
    const char*         GetGOODFileName(void)      const {return GoodChanFileName;}
    const char*         GetMarkerFileName(void)    const {return MarkerFileName;}
    const char*         GetClassFileName(void)     const {return ClassFileName;}
    const char*         GetSpatCovarFileName(void) const {return SpatCovarFileName;}
    const char*         GetTempCovarFileName(void) const {return TempCovarFileName;}
    UCTFDataSet*        GetSubDS(const char *DSet) const;

    ErrorType           WriteChannels(const char* const* const Labels, int Nlabels, UFileName BaseName) const;
    ErrorType           BackUpMarkerFile(char* Extension=NULL) const;

    ErrorType           CreateDataSet(void);
    const char* const*  GetBadChannels(int *nB=NULL)  const {if(nB) *nB=nBad; return BadChannels;}
    const char* const*  GetGoodChannels(int *nG=NULL) const {if(nG) *nG=nGood; return GoodChannels;}

    UVector3            GetFiducials(int ifid) const;
    ErrorType           CopyFiducialsTo(const UCTFDataSet* DSout) const;
    ErrorType           WriteHC(const UVector3 *NLRhead, const UEuler &HeadToDewar) const;
    bool                DoesHCexist(void) const;

    char*               FullOutputFileName(const char* FileName, int nAddChar=0) const;
    UFileName           FullOutputFileName(UFileName FileName) const;

    static const int    MAXLABELSIZE;  // The maxumum number of characters used to in BadChannels and GoodChannels

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static const int    MAXPROPERTIES; // The maxumum number of characters used in Properties[]-string

    char*               Properties;
    ErrorType           error;
    UDirectory          DirDS;
    char                *FullCTFFileName;
    char                *BadChanFileName;
    char                *GoodChanFileName;
    char                *HCFileName;
    char                *MarkerFileName;
    char                *ClassFileName;
    char                *SpatCovarFileName;
    char                *TempCovarFileName;
    bool                BadChanFromFile;
    char                **BadChannels;
    int                 nBad;
    bool                GoodChanFromFile;
    char                **GoodChannels;
    int                 nGood;
    double              GetCoordinate(const char *line) const;
    UVector3            FiducialsDewar[MAX_MEG_FIDUCIALS];
    UVector3            FiducialsHead[MAX_MEG_FIDUCIALS];

    ErrorType           ReadHC(void);    
    ErrorType           GetChanneldFromString(const char* ChanString, int *Nchan, char*** Channels) const;
};
#endif// _CTFDATASET_INCLUDED
