/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read scans in CTF MRI data format                                  */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    09-08-06   Creation
  JdM    15-08-06   Bug Fix: GetScan(). Left-Right, conversion to cm.
  JdM    30-12-06   Adapted include file to new directory structure

*/

#include<string.h>
#include<stdlib.h>

#include"CTFMRIData.h"
#include "Scan.h"

/* Inititalize static const parameters. */


UCTFMRIData::UCTFMRIData(UFileName FileName)
{
    memset(Header.VersionIdentifier, 0, 32);
    Header.imageSize               = 256;
    Header.size                    =   0;
    Header.clippingRange           = 100;
    Header.imageSwap               =   0;
    Header.pixelSag                =   1.; 
    Header.pixelCor                =   1.; 
    Header.pixelAxi                =   1.; 
    Header.HeadModel.NasionSag     = 0;
    Header.HeadModel.NasionCor     = 0;
    Header.HeadModel.NasionAxi     = 0;
    Header.HeadModel.LeftSag       = 0;
    Header.HeadModel.LeftCor       = 0;
    Header.HeadModel.LeftAxi       = 0;
    Header.HeadModel.RightSag      = 0;
    Header.HeadModel.RightCor      = 0;
    Header.HeadModel.RightAxi      = 0;
    Header.HeadModel.SpherePosX    = 0.;
    Header.HeadModel.SpherePosY    = 0.;
    Header.HeadModel.SpherePosZ    = 0.;
    Header.HeadModel.SphereRad     = 0.;
    Header.HeadModel.SphereRad     = 0.;
    Header.ImageInfo.modality      = 4;
    memset(Header.ImageInfo.Manufacturer, 0, 64);
    memset(Header.ImageInfo.Institution, 0, 64);
    memset(Header.ImageInfo.patID,    0, 32);
    memset(Header.ImageInfo.DateTime, 0, 32);
    memset(Header.ImageInfo.ScanType, 0, 32);
    memset(Header.ImageInfo.Contrast, 0, 32);
    memset(Header.ImageInfo.Nucleus,  0, 32);
    Header.ImageInfo.Frequency     = 0.;
    Header.ImageInfo.FieldStrength = 0.;
    Header.ImageInfo.EchoTime      = 0.;
    Header.ImageInfo.RepTime       = 0.;
    Header.ImageInfo.InvTime       = 0.;
    Header.ImageInfo.FlipAngle     = 0.;
    Header.ImageInfo.NoExitations  = 1;
    Header.ImageInfo.NoAcqui       = 1;
    memset(Header.ImageInfo.Comment,  0, 256);
    memset(Header.ImageInfo.Dummy,    0, 64);
    Header.headOrigSag             =   0.;
    Header.headOrigCor             =   0.;
    Header.headOrigAxi             =   0.;
    Header.rotCor                  =   0.;
    Header.rotSag                  =   0.;
    Header.rotAxi                  =   0.;
    Header.orthoFlag               =   1;
    Header.interFlag               =   1;
    Header.OriginalSlice           =   1.0;
    for(int k=0; k<16; k+=1) Header.Tranform[k] = 0.;
    for(int k=0; k<16; k+=4) Header.Tranform[k] = 1.;
    memset(Header.Unused, 0, 202);

    FILE* fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCTFMRIData::UCTFMRIData(). Cannot open file %s. \n", FileName.GetFullFileName());
        return;
    }
    char Identity[22];
	fread(Identity,1,22,fp);
	if(memcmp(Identity,"CTF_MRI_FORMAT VER 2.2",22))
	{
        fclose(fp);
        CI.AddToLog("ERROR: UCTFMRIData::UCTFMRIData(). Wrong fiele identifier (first characters: %s).\n", Identity);
        return;
	}
    rewind(fp);

    char dum[20];
    fread(&Header.VersionIdentifier      , 32, 1,fp);
    fread(&Header.imageSize              ,  2, 1,fp);    Header.imageSize               = SwapVal(Header.imageSize               , false);
    fread(&Header.size                   ,  2, 1,fp);    Header.size                    = SwapVal(Header.size                    , false);
    fread(&Header.clippingRange          ,  2, 1,fp);    Header.clippingRange           = SwapVal(Header.clippingRange           , false);
    fread(&Header.imageSwap              ,  2, 1,fp);    Header.imageSwap               = SwapVal(Header.imageSwap               , false);
    fread(&Header.pixelSag               ,  4, 1,fp);    Header.pixelSag                = SwapVal(Header.pixelSag                , false);
    fread(&Header.pixelCor               ,  4, 1,fp);    Header.pixelCor                = SwapVal(Header.pixelCor                , false);
    fread(&Header.pixelAxi               ,  4, 1,fp);    Header.pixelAxi                = SwapVal(Header.pixelAxi                , false);
    fread(&Header.HeadModel.NasionSag    ,  2, 1,fp);    Header.HeadModel.NasionSag     = SwapVal(Header.HeadModel.NasionSag     , false);
    fread(&Header.HeadModel.NasionCor    ,  2, 1,fp);    Header.HeadModel.NasionCor     = SwapVal(Header.HeadModel.NasionCor     , false);
    fread(&Header.HeadModel.NasionAxi    ,  2, 1,fp);    Header.HeadModel.NasionAxi     = SwapVal(Header.HeadModel.NasionAxi     , false);
    fread(&Header.HeadModel.LeftSag      ,  2, 1,fp);    Header.HeadModel.LeftSag       = SwapVal(Header.HeadModel.LeftSag       , false);
    fread(&Header.HeadModel.LeftCor      ,  2, 1,fp);    Header.HeadModel.LeftCor       = SwapVal(Header.HeadModel.LeftCor       , false);
    fread(&Header.HeadModel.LeftAxi      ,  2, 1,fp);    Header.HeadModel.LeftAxi       = SwapVal(Header.HeadModel.LeftAxi       , false);
    fread(&Header.HeadModel.RightSag     ,  2, 1,fp);    Header.HeadModel.RightSag      = SwapVal(Header.HeadModel.RightSag      , false);
    fread(&Header.HeadModel.RightCor     ,  2, 1,fp);    Header.HeadModel.RightCor      = SwapVal(Header.HeadModel.RightCor      , false);
    fread(&Header.HeadModel.RightAxi     ,  2, 1,fp);    Header.HeadModel.RightAxi      = SwapVal(Header.HeadModel.RightAxi      , false);
    fread(dum, 2, 1,fp);
    fread(&Header.HeadModel.SpherePosX   ,  4, 1,fp);    Header.HeadModel.SpherePosX    = SwapVal(Header.HeadModel.SpherePosX    , false);
    fread(&Header.HeadModel.SpherePosY   ,  4, 1,fp);    Header.HeadModel.SpherePosY    = SwapVal(Header.HeadModel.SpherePosY    , false);
    fread(&Header.HeadModel.SpherePosZ   ,  4, 1,fp);    Header.HeadModel.SpherePosZ    = SwapVal(Header.HeadModel.SpherePosZ    , false);
    fread(&Header.HeadModel.SphereRad    ,  4, 1,fp);    Header.HeadModel.SphereRad     = SwapVal(Header.HeadModel.SphereRad     , false);
    fread(&Header.ImageInfo.modality     ,  2, 1,fp);    Header.ImageInfo.modality      = SwapVal(Header.ImageInfo.modality      , false);
    fread(&Header.ImageInfo.Manufacturer , 64, 1,fp);
    fread(&Header.ImageInfo.Institution  , 64, 1,fp);
    fread(&Header.ImageInfo.patID        , 32, 1,fp);
    fread(&Header.ImageInfo.DateTime     , 32, 1,fp);
    fread(&Header.ImageInfo.ScanType     , 32, 1,fp);
    fread(&Header.ImageInfo.Contrast     , 32, 1,fp);
    fread(&Header.ImageInfo.Nucleus      , 32, 1,fp);
    fread(dum, 2, 1,fp);
    fread(&Header.ImageInfo.Frequency    ,  4, 1,fp);   Header.ImageInfo.Frequency     = SwapVal(Header.ImageInfo.Frequency     , false);
    fread(&Header.ImageInfo.FieldStrength,  4, 1,fp);   Header.ImageInfo.FieldStrength = SwapVal(Header.ImageInfo.FieldStrength , false);
    fread(&Header.ImageInfo.EchoTime     ,  4, 1,fp);   Header.ImageInfo.EchoTime      = SwapVal(Header.ImageInfo.EchoTime      , false);
    fread(&Header.ImageInfo.RepTime      ,  4, 1,fp);   Header.ImageInfo.RepTime       = SwapVal(Header.ImageInfo.RepTime       , false);
    fread(&Header.ImageInfo.InvTime      ,  4, 1,fp);   Header.ImageInfo.InvTime       = SwapVal(Header.ImageInfo.InvTime       , false);
    fread(&Header.ImageInfo.FlipAngle    ,  4, 1,fp);   Header.ImageInfo.FlipAngle     = SwapVal(Header.ImageInfo.FlipAngle     , false);
    fread(&Header.ImageInfo.NoExitations ,  2, 1,fp);   Header.ImageInfo.NoExitations  = SwapVal(Header.ImageInfo.NoExitations  , false);
    fread(&Header.ImageInfo.NoAcqui      ,  2, 1,fp);   Header.ImageInfo.NoAcqui       = SwapVal(Header.ImageInfo.NoAcqui       , false);
    fread(&Header.ImageInfo.Comment      ,256, 1,fp);
    fread(&Header.ImageInfo.Dummy        , 64, 1,fp);
    fread(&Header.headOrigSag            ,  4, 1,fp);   Header.headOrigSag             = SwapVal(Header.headOrigSag             , false);
    fread(&Header.headOrigCor            ,  4, 1,fp);   Header.headOrigCor             = SwapVal(Header.headOrigCor             , false);
    fread(&Header.headOrigAxi            ,  4, 1,fp);   Header.headOrigAxi             = SwapVal(Header.headOrigAxi             , false);
    fread(&Header.rotCor                 ,  4, 1,fp);   Header.rotCor                  = SwapVal(Header.rotCor                  , false);
    fread(&Header.rotSag                 ,  4, 1,fp);   Header.rotSag                  = SwapVal(Header.rotSag                  , false); 
    fread(&Header.rotAxi                 ,  4, 1,fp);   Header.rotAxi                  = SwapVal(Header.rotAxi                  , false);
    fread(&Header.orthoFlag              ,  2, 1,fp);   Header.orthoFlag               = SwapVal(Header.orthoFlag               , false);
    fread(&Header.interFlag              ,  2, 1,fp);   Header.interFlag               = SwapVal(Header.interFlag               , false);
    fread(&Header.OriginalSlice          ,  2, 1,fp);   Header.OriginalSlice           = SwapVal(Header.OriginalSlice           , false);
    fread(dum, 2, 1,fp);
    fread(&Header.Tranform               ,  4,16,fp);   for(int k=0; k<16; k++) Header.Tranform[k] = SwapVal(Header.Tranform[k] , false);
    fread(&Header.Unused                 ,202, 1,fp);
    fclose(fp);

    CTFMRIFileName = FileName;
    error = U_OK;
}
    
UCTFMRIData::~UCTFMRIData()
{
}

UScan* UCTFMRIData::GetScan(void) const
{
    if(DoesFileExist(CTFMRIFileName)==false)
    {
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). File does not exist: %s. \n", CTFMRIFileName.GetFullFileName());
        return NULL;
    }
    UVector3 Min = -128.*UVector3(0.1*Header.pixelAxi, 0.1*Header.pixelSag, -0.1*Header.pixelCor);
    UVector3 Max =  127.*UVector3(0.1*Header.pixelAxi, 0.1*Header.pixelSag, -0.1*Header.pixelCor);
    int dims[3] = {256, 256, 256};
    UField::DataType DT = UField::U_DOUBLE;
    switch(Header.size)
    {
    case 1:  DT = UField::U_BYTE ; break;
    case 2:  DT = UField::U_SHORT; break;
    default:
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). Invalid data size (%d). \n", Header.size);
        return NULL;
    }
    UField* F = new UField(Min, Max, dims, DT, 0);
    if(F==NULL || F->GetError()!=U_OK)
    {
        delete F;
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). Cannot create UField object. \n");
        return NULL;
    }
    UScan* S = new UScan(*F, true);
    delete F;
    if(S==NULL || S->GetError()!=U_OK || S->SetVeclen(1)!=U_OK)
    {
        delete S;
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). Cannot create UScan object. \n");
        return NULL;
    }
    S->SetOrientation(U_ORI_SAGITAL);

    S->SetScanName("CTF_MRI");
    S->SetDateTime(UDateTime(Header.ImageInfo.DateTime));
    S->SetPatName (Header.ImageInfo.patID);
    S->SetPatID   (Header.ImageInfo.patID);
    switch(Header.ImageInfo.modality)
    {
    case 0: S->SetModality(U_MOD_MR);    break;
    case 1: S->SetModality(U_MOD_CT);    break;
    case 2: S->SetModality(U_MOD_PET);   break;
    case 3: S->SetModality(U_MOD_SPECT); break;
    default:
        S->SetModality(U_MOD_UNKNOWN);
    }
    S->SetOrigFileType(U_FIL_CTFMRI);
    S->SetOrigFileName(CTFMRIFileName);

    FILE* fp = fopen(CTFMRIFileName, "rb", false);
    if(fp==NULL)
    {
        delete S;
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). Cannot open file %s. \n", CTFMRIFileName.GetFullFileName());
        return NULL;
    }
    fseek(fp, 1024, SEEK_SET);  
    
    if(S->GetDType()==UField::U_BYTE)
    {
        unsigned char* dat = S->GetBdata();
        if(dat)
        {
            for(int y=dims[1]-1; y>=0; y--)
                for(int x=0; x<dims[0]; x++)
                    for(int z=0; z<dims[2]; z++)
                       fread(dat+z*dims[0]*dims[1] + y*dims[0] + x,  1, 1, fp);    
        }
    }
    if(S->GetDType()==UField::U_SHORT)
    {
        short* dat = S->GetSdata();
        if(dat)
        {
            for(int y=dims[1]-1; y>=0; y--)
                for(int x=0; x<dims[0]; x++)
                    for(int z=0; z<dims[2]; z++)
                       fread(dat+z*dims[0]*dims[1] + y*dims[0] + x,  2, 1, fp);    

            SwapArray(dat, dims[0]*dims[1]*dims[2], false);
        }
    }
    fclose(fp);
    if(S->GetBdata()==NULL && S->GetSdata()==NULL)
    {
        delete S;
        CI.AddToLog("ERROR: UCTFMRIData::GetScan(). Reading image data. \n");
        return NULL;
    }
    return S;
}
