#ifndef _CTFMRIDATA_INCLUDED
#define _CTFMRIDATA_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "FileName.h"
#include "String.h"

class UPersistTag
{
public:
    
protected:
    void              SetAllMembersDefault(void);
    void              DeleteAllMembers(void);

private:
    enum ValType
    {
        U_PTAG_CUSTOM = 1,
        U_PTAG_PERSIST,
        U_PTAG_BINARY,
        U_PTAG_DOUBLE,
        U_PTAG_INT,
        U_PTAG_SHORT,
        U_PTAG_USHORT,
        U_PTAG_BOOL,
        U_PTAG_STR32,      // 31 char + 0
        U_PTAG_STRING,     // 0-terminated
        U_PTAG_STRINGLIST,
        U_PTAG_STR32LIST,
        U_PTAG_SENSLIST,
        U_PTAG_LONG,
        U_PTAG_ULONG,
        U_PTAG_UINT,
        U_PTAG_CTFBOOL
    };
    int     LabelLen;
    UString Label;
    ValType VType;
    int     VLen;         // Only in case of U_PTAG_BINARY or U_PTAG_STRING

    int     IVal;
    double  DVal;
    UString SVal;
    char*   CVal;
};

typedef struct {
    short       NasionSag;
    short       NasionCor;
    short       NasionAxi;
    short       LeftSag;
    short       LeftCor;
    short       LeftAxi;
    short       RightSag;
    short       RightCor;
    short       RightAxi;
    float       SpherePosX;       // [mm];
    float       SpherePosY;       // [mm];
    float       SpherePosZ;       // [mm];
    float       SphereRad;        // [mm];
} CTF_HMODEL;
typedef struct {
    short       modality;           // 0=MRI, 1=CT, 2=PET, 3=SPECT, 4=Other
    char        Manufacturer[64];
    char        Institution[64];
    char        patID[32];
    char        DateTime[32];
    char        ScanType[32];
    char        Contrast[32];
    char        Nucleus[32];
    float       Frequency;
    float       FieldStrength;
    float       EchoTime;
    float       RepTime;
    float       InvTime;
    float       FlipAngle;
    short       NoExitations;
    short       NoAcqui;
    char        Comment[256];
    char        Dummy[64];
} CTF_IMAGE;

typedef struct {
    char        VersionIdentifier[32];  // CTF_MRI_FORMAT VER 2.2
    short       imageSize;              // 256
    short       size;                   // 1 or 2
    short       clippingRange;
    short       imageSwap;              // 0 = OK, 1 = LR-swapped 
    float       pixelSag;               // mm pix size sagital
    float       pixelCor;               // mm pix size coronal
    float       pixelAxi;               // mm pix size axial
    CTF_HMODEL  HeadModel;
    CTF_IMAGE   ImageInfo;
    float       headOrigSag;
    float       headOrigCor;
    float       headOrigAxi;
    float       rotCor;                 // Rotation in degrees
    float       rotSag;
    float       rotAxi;
    short       orthoFlag;
    short       interFlag;
    float       OriginalSlice;
    float       Tranform[16];
    char        Unused[202];
} CTFMRI2_HDR;
 
class UScan;

class DLL_IO UCTFMRIData
{
public:
    UCTFMRIData(UFileName FileName);
    ~UCTFMRIData();  

    ErrorType           GetError(void)  const {return error;}

    UScan*              GetScan(void) const;
    const char*         GetFileName(void) const {return CTFMRIFileName.GetFullFileName();}

private:
    ErrorType           error;       // General error flag
    UFileName           CTFMRIFileName;
    CTFMRI2_HDR         Header;
};

#endif //_CTFMRIDATA_INCLUDED
