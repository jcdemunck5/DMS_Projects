/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read scans in CTF SAM data format                                  */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    18-02-04   Creation
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    22-03-07   Added SAM version number 2 header. (earlier software version in com with version 2 files gave wrong results)
  JdM    01-03-18   GetProperties(). Return const char*
*/

#include<string.h>
#include<stdlib.h>

#include "CTFSAMData.h"
#include "Euler.h"
#include "Field.h"
#include "FileName.h"

/* Inititalize static const parameters. */
const int UCTFSAMData::MAXPROPERTIES = 500;


UCTFSAMData::UCTFSAMData(UFileName FileName)
{
    Header.Version    = 0;            // file version number
    memset(Header.SetName, 256, 0);
    Header.NumChans   = 0;            // number of channels used by SAM
    Header.NumWeights = 0;            // number of SAM virtual channels (0=static image)
    Header.XStart     = 0.;           // x-start coordinate (m)
    Header.XEnd       = 0.;           // x-end coordinate (m)
    Header.YStart     = 0.;           // y-start coordinate (m)
    Header.YEnd       = 0.;           // y-end coordinate (m)
    Header.ZStart     = 0.;           // z-start coordinate (m)
    Header.ZEnd       = 0.;           // z-end coordinate (m)
    Header.StepSize   = 0.;           // voxel step size (m)
    Header.HPFreq     = 0.;           // highpass frequency (Hz)
    Header.LPFreq     = 0.;           // lowpass frequency (Hz)
    Header.BWFreq     = 0.;           // bandwidth of filters (Hz)
    Header.MeanNoise  = 0.;           // mean primary sensor noise (T)
    memset(Header.MriName, 256, 0);   // MRI image file name
    Header.Nasion[0]  = 0;            // MRI voxel index for nasion
    Header.Nasion[1]  = 0;            // MRI voxel index for nasion
    Header.Nasion[2]  = 0;            // MRI voxel index for nasion
    Header.RightPA[0] = 0;            // MRI voxel index for right pre-auricular
    Header.RightPA[1] = 0;            // MRI voxel index for right pre-auricular
    Header.RightPA[2] = 0;            // MRI voxel index for right pre-auricular
    Header.LeftPA[0]  = 0;            // MRI voxel index for left pre-auricular
    Header.LeftPA[1]  = 0;            // MRI voxel index for left pre-auricular
    Header.LeftPA[2]  = 0;            // MRI voxel index for left pre-auricular
    Header.SAMType    = 0;            // SAM file type
    Header.SAMUnit    = 0;            // SAM units (a bit redundant, but may be useful)

    error          = U_ERROR;         // General error flag
    Properties     = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        CI.AddToLog("ERROR: UCTFSAMData::UCTFSAMData(). Memory allocation error. \n");
        return;
    }
    FILE* fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        delete[] Properties; Properties = NULL;
        CI.AddToLog("ERROR: UCTFSAMData::UCTFSAMData(). Cannot open file %s. \n", FileName.GetFullFileName());
        return;
    }
    char Identity[8];
    fread(Identity,1,8,fp);
    if(memcmp(Identity,"SAMIMAGE",8))
    {
        fclose(fp);
        delete[] Properties; Properties = NULL;
        CI.AddToLog("ERROR: UCTFSAMData::UCTFSAMData(). Wrong fiele identifier (first characters: %s).\n", Identity);
        return;
    }
    char dum[50];

    fread(&Header.Version   ,  4,1,fp); Header.Version    = SwapVal(Header.Version   , false);
    fread(&Header.SetName   ,256,1,fp);
    fread(&Header.NumChans  ,  4,1,fp); Header.NumChans   = SwapVal(Header.NumChans  , false);
    fread(&Header.NumWeights,  4,1,fp); Header.NumWeights = SwapVal(Header.NumWeights, false);
    fread(dum               ,  4,1,fp); 
    fread(&Header.XStart    ,  8,1,fp); Header.XStart     = SwapVal(Header.XStart    , false);
    fread(&Header.XEnd      ,  8,1,fp); Header.XEnd       = SwapVal(Header.XEnd      , false);
    fread(&Header.YStart    ,  8,1,fp); Header.YStart     = SwapVal(Header.YStart    , false);
    fread(&Header.YEnd      ,  8,1,fp); Header.YEnd       = SwapVal(Header.YEnd      , false);
    fread(&Header.ZStart    ,  8,1,fp); Header.ZStart     = SwapVal(Header.ZStart    , false);
    fread(&Header.ZEnd      ,  8,1,fp); Header.ZEnd       = SwapVal(Header.ZEnd      , false);
    fread(&Header.StepSize  ,  8,1,fp); Header.StepSize   = SwapVal(Header.StepSize  , false);
    fread(&Header.HPFreq    ,  8,1,fp); Header.HPFreq     = SwapVal(Header.HPFreq    , false);
    fread(&Header.LPFreq    ,  8,1,fp); Header.LPFreq     = SwapVal(Header.LPFreq    , false);
    fread(&Header.BWFreq    ,  8,1,fp); Header.BWFreq     = SwapVal(Header.BWFreq    , false);
    fread(&Header.MeanNoise ,  8,1,fp); Header.MeanNoise  = SwapVal(Header.MeanNoise , false);
    fread(&Header.MriName   ,256,1,fp);
    fread(&Header.Nasion    ,  4,3,fp); SwapArray(Header.Nasion , 3, false);
    fread(&Header.RightPA   ,  4,3,fp); SwapArray(Header.RightPA, 3, false);
    fread(&Header.LeftPA    ,  4,3,fp); SwapArray(Header.LeftPA,  3, false);
    fread(&Header.SAMType   ,  4,1,fp); Header.SAMType    = SwapVal(Header.SAMType   , false);
    fread(&Header.SAMUnit   ,  4,1,fp); Header.SAMUnit    = SwapVal(Header.SAMUnit   , false);
    fclose(fp);

    if(Header.Version!=1 && Header.Version!=2)
    {
        delete[] Properties; Properties = NULL;
        CI.AddToLog("ERROR: UCTFSAMData::UCTFSAMData(). Wrong version nummer (not 1 or 2) (Header.Version = %d).\n", Header.Version);
        return;
    }
    CTFSAMFileName = FileName;
    error = U_OK;
}
    
UCTFSAMData::~UCTFSAMData()
{
    delete[] Properties; 
}

UField* UCTFSAMData::GetField(void)
{
    FILE* fp = fopen(CTFSAMFileName, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCTFSAMData::GetField(). Cannot open file %s. \n", CTFSAMFileName.GetFullFileName());
        return NULL;
    }
    if(Header.Version==1)    fseek(fp, 672, SEEK_SET);    
    if(Header.Version==2)    fseek(fp, 776, SEEK_SET);    


    double   Voxel = 100.*Header.StepSize;
    UVector3 MinX  = 100.*UVector3(Header.ZStart, Header.XStart, Header.YStart);
    UVector3 MaxX  = 100.*UVector3(Header.ZEnd  , Header.XEnd  , Header.YEnd  );
    UField*  F     = new UField(Voxel, MinX, MaxX, UField::U_DOUBLE);
    if(F==NULL || F->GetError()!=U_OK || F->GetDdata()==NULL)
    {
        fclose(fp);
        delete F;
        CI.AddToLog("ERROR: UCTFSAMData::GetField(). Creating UField() object. \n");
        return NULL;
    }
    
    int dimx = F->GetDimensions(0);
    int dimy = F->GetDimensions(1);
    int dimz = F->GetDimensions(2);

    double* Data = F->GetDdata();
    for(int y=0; y<dimy; y++)
        for(int z=dimz-1; z>=0; z--)
            for(int x=dimx-1; x>=0; x--)
               fread(Data+z*dimx*dimy + y*dimx + x,  8, 1, fp);    

    fclose(fp);
    SwapArray(Data, dimx*dimy*dimz, false);

    return F;
}

const char* UCTFSAMData::GetProperties(char* Comment) const
{
    return "UCTFSAMData::GetProperties(). Not Yet implemented.\n";
}


