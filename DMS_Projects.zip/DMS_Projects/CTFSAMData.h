#ifndef _CTFSAMDATA_INCLUDED
#define _CTFSAMDATA_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "FileName.h"

#define SAM_TYPE_IMAGE      0           // flags file as a SAM static image file
#define SAM_TYPE_WT_ARRAY   1           // flags file as SAM coefficients for regular target array
#define SAM_TYPE_WT_LIST    2           // flags file as SAM coefficients for target list

// define SAM unit types
#define SAM_UNIT_COEFF      0           // SAM coefficients A-m/T
#define SAM_UNIT_MOMENT     1           // SAM source (or noise) strength A-m
#define SAM_UNIT_POWER      2           // SAM source (or noise) power (A-m)^2
#define SAM_UNIT_SPMZ       3           // SAM z-deviate
#define SAM_UNIT_SPMF       4           // SAM F-statistic
#define SAM_UNIT_SPMT       5           // SAM T-statistic
#define SAM_UNIT_SPMP       6           // SAM probability
#define SAM_UNIT_MUSIC      7           // MUSIC metric

// 'SAM_HDR' is to be used for both SAM coefficients & SAM static images
typedef struct {
    int     Version;    // file version number
    char    SetName[256];   // name of parent dataset
    int     NumChans;   // number of channels used by SAM
    int     NumWeights; // number of SAM virtual channels (0=static image)
    double  XStart;     // x-start coordinate (m)
    double  XEnd;       // x-end coordinate (m)
    double  YStart;     // y-start coordinate (m)
    double  YEnd;       // y-end coordinate (m)
    double  ZStart;     // z-start coordinate (m)
    double  ZEnd;       // z-end coordinate (m)
    double  StepSize;   // voxel step size (m)
    double  HPFreq;     // highpass frequency (Hz)
    double  LPFreq;     // lowpass frequency (Hz)
    double  BWFreq;     // bandwidth of filters (Hz)
    double  MeanNoise;  // mean primary sensor noise (T)
    char    MriName[256];   // MRI image file name
    int     Nasion[3];  // MRI voxel index for nasion
    int     RightPA[3]; // MRI voxel index for right pre-auricular
    int     LeftPA[3];  // MRI voxel index for left pre-auricular
    int     SAMType;    // SAM file type
    int     SAMUnit;    // SAM units (a bit redundant, but may be useful)
} SAM_HDR;
 
class UField;

class DLL_IO UCTFSAMData
{
public:
    UCTFSAMData(UFileName FileName);
    ~UCTFSAMData();  

    ErrorType           GetError(void)  const {return error;}

    UField*             GetField(void);
    const char*         GetProperties(char* Comment) const;

    const char*         GetFileName(void) const {return CTFSAMFileName.GetFullFileName();}

private:
    ErrorType           error;       // General error flag
    static const int    MAXPROPERTIES;
    char*               Properties;
    UFileName           CTFSAMFileName;
    SAM_HDR             Header;
};

#endif //_CTFSAMDATA_INCLUDED
