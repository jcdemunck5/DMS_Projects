/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read and write Cart data (CadPlan Image files)                     */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    03-09-01   creation
  JdM    26-09-01   ReadSurfaces(): call RemoveDoublePoints() before triangulation
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    25-11-02   Add non-static versions of GetGeomInfo() and GetPatInfo()
                    Bug fix: ReadSlices(): do not convert data when WordOn==true and pixmin=pixmax =-1
  JdM    23-01-06   Switched off MS C++ language extensions.
  JdM    30-12-06   Adapted include file to new directory structure
*/


#include<string.h>
#include<stdlib.h>

#include"FileName.h"
#include"CartData.h"

/* Inititalize static const parameters. */
const int UCartData::MAXPROPERTIES = 512;


#define RECORD_SIZE  512
#define MAX_SLICES   512
static  int          swap;


UCartData::UCartData(const char* CarFileNames)
{
/* Set defaults*/
    error       = U_ERROR;
    swap        = 1;
    if(INTEL_PROCESSOR()==false) swap = 0;

    OT          = U_ORI_UNKNOWN;
    ScanType    = 0;

    FileNames   = NULL;
    Nfiles      = 0;

    Properties  = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        CI.AddToLog("ERROR : UCartData::UCartData() : Memory allocation\n");
        return;
    }
    sprintf(Properties,"No data Read yet");

    CartDir  = UFileName(CarFileNames).GetDirectory();
    error    = AnalyzeCartFiles(CarFileNames);
}

UCartData::~UCartData()
{
    delete[] Properties;
    delete[] FileNames;
}

UEuler  UCartData::GetScanToWld(void) const
{
    switch(OT)
    {
    case U_ORI_AXIAL:   return UEuler(0.,0.,0.,0.0,-PI/2,PI);
    case U_ORI_CORONAL: return UEuler(0.,0.,0.,-0.5* PI, PI , 0.5* PI);
    case U_ORI_SAGITAL: return UEuler(0.,0.,0.,0.0, 0.0 , -0.5* PI);
    }
    CI.AddToLog("ERROR: UCartData::GetScanToWld(). Unknown orientation. Return default \n");
    return UEuler();
}

USurface** UCartData::ReadSurfaces(int* Nsurf, UVector3 Center) const
{
    if(Nsurf==NULL)
    {
        CI.AddToLog("ERROR: UCartData::ReadSurfaces(). NULL pointer argument. \n");
        return NULL;
    }
    if(Nfiles<=0)
    {
        CI.AddToLog("ERROR: UCartData::ReadSurfaces(). No good files. \n");
        return NULL;
    }

    UDrawing** Dlist = ReadDrawings(Nsurf, Center);
    if(Dlist==NULL)
    {
        CI.AddToLog("ERROR: UCartData::ReadSurfaces(). Reading drawings. \n");
        return NULL;
    }

    USurface** Slist = new USurface*[*Nsurf];
    if(Slist==NULL)
    {
        CI.AddToLog("ERROR: UCartData::ReadSurfaces(). Memory allocation: *Nsurf = %d. \n", *Nsurf);
        return NULL;
    }

    for(int is=0; is<*Nsurf; is++)
    {
        Slist[is] = NULL;
        if(Dlist[is]==NULL || Dlist[is]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UCartData::ReadSurfaces(). Skipping erroneous drawing (%d). \n",is);
            continue;
        }
        const int MAXNPOINT = 2000;
        int Npoints         = Dlist[is]->GetNpoints();
        if(Npoints>MAXNPOINT)
        {
            CI.AddToLog("ERROR: UCartData::ReadSurfaces(). On surface (%d) there are more than %d number of points (%d). Skip this surface. \n",is, MAXNPOINT, Npoints);
            continue;
        }

        Dlist[is]->RemoveDoublePoints(0.0001);
        const UVector3* p = Dlist[is]->GetPoints();
        Slist[is]         = new USurface(p, Dlist[is]->GetNpoints(), (const int*)NULL, 0, Dlist[is]->GetName());
        delete   Dlist[is];
    }
    delete[] Dlist;
    return Slist;
}


UDrawing** UCartData::ReadDrawings(int* Ndraw, UVector3 Center) const
{
    if(Ndraw==NULL)
    {
        CI.AddToLog("ERROR: UCartData::ReadDrawings(). NULL pointer\n");
        return NULL;
    }
    if(Nfiles<=0)
    {
        CI.AddToLog("ERROR: UCartData::ReadDrawings(). No good files. \n");
        return NULL;
    }


    int NpROI[MAX_DRAWING];
    for(int k=0; k<MAX_DRAWING;k++)
        NpROI[k] = 0;

    ContInfo CT;
    GeomInfo GT;
    double   CartCenter[3]; // Center of scan in Cart coordinates
    CartCenter[0] = 0;
    CartCenter[1] = 0;
    CartCenter[2] = 0;

    for(int n=0; n<Nfiles; n++)
    {
        GetGeomInfo(FileNames[n], &GT);
        CartCenter[2] += GT.SlicePos;

        if(GetContInfo(FileNames[n], &CT)==U_OK)
        {
            for(int k=0; k<MAX_DRAWING;k++)
                NpROI[k] += CT.Np[k];
        }
    }
    CartCenter[0]  = GT.Dx*GT.ndimx/2;
    CartCenter[1]  = GT.Dy*GT.ndimy/2;
    CartCenter[2] /= Nfiles;


    *Ndraw = 0;
    for(int k=0; k<MAX_DRAWING;k++)
        if(NpROI[k]>0) (*Ndraw)++;

    if(*Ndraw == 0)
    {
        CI.AddToLog("ERROR: UCartData::ReadDrawings(). No drawings present. \n");
        return NULL;
    }

    UDrawing** Dlist = new UDrawing*[*Ndraw];
    if(Dlist==NULL)
    {
        CI.AddToLog("ERROR: UCartData::ReadDrawings(). Memory allocation: *Ndraw = %d. \n", *Ndraw);
        return NULL;
    }

    int id = 0;
    for(int k=0; k<MAX_DRAWING;k++)
    {
        if(NpROI[k]<=0) continue;

        Dlist[id] = new UDrawing();
        char Name[20];
        sprintf(Name,"Drawing_%2.2d",k);
        Dlist[id]->SetName(Name);

        ContInfo CT;
        for(int n=0; n<Nfiles; n++)
        {
            GetContInfo(FileNames[n], &CT);
            if(CT.Np[k]<=0) continue;

            UVector3* p = new UVector3[CT.Np[k]];
            if(p)
            {
                for(int i=0; i<CT.Np[k]; i++)
                {
                    double xx = CT.xp[k][i]-CartCenter[0];
                    double yy = CT.yp[k][i]-CartCenter[1];
                    double zz = CT.SlicePos-CartCenter[2];
                    p[i] = UVector3(-yy, -zz, -xx) + Center;
                }
            }
            UDrawing D(p, CT.Np[k], NULL);
            delete[] p;

            if(Dlist[id]->Concatenate(&D)!=U_OK)
            {
                CI.AddToLog("ERROR: UCartData::ReadDrawings(). Creation of stacked drawings, File = %d, Drawing = %d \n", n, k);
                break;
            }
        }
        id++;
    }
    return Dlist;
}

UField* UCartData::ReadSlices(bool WordOn, int pixmin, int pixmax, int numslices, int pixdown, int slicedown, bool centerY, bool ReverseSlices)
/*
    Read the slices of scan with number scannum and convert these slices into an UField object,
    of type U_RECTILINEAR.

    if(WordOn) Convert the pixels short, else to byte.
    if data converted to byte, scale pixels between pixmin and pixmax.
    if(numslices>0) convert the first numslices slices.
    if(CenterY) shift slice coordinates such that the origin is in the middle of the scan
    if(ReverseSlices) reverse the sign of the slice coordinates.
 */
{
    if(numslices==0) return NULL;

/* Get general image info, hopefully identical for all slices */
    GeomInfo  GInfo;
    GetGeomInfo( FileNames[0], &GInfo);

    double dx   = GInfo.Dx;
    double dz   = GInfo.Dy;
    int    nx   = GInfo.ndimx;
    int    nz   = GInfo.ndimy;
    int    ny   = Nfiles;

/* Read slice coordinates*/
    double ys[MAX_SLICES];
    double t = 0;

    for(int i=0; i<Nfiles; i++)
    {
        GetGeomInfo(FileNames[i], &GInfo);
        ys[i] = GInfo.SlicePos;

        if(i==0) continue;
        if(i==1)
        {
            t = ys[1] - ys[0];
        }
        else if(t * (ys[i]-ys[i-1]) < 0.0)
        {
            CI.AddToLog("WARNING: UCartData::ReadSlices(). Sign change in slice distance (slice %d)\n", i);
        }
        else if(t * (ys[i]-ys[i-1]) < 1.e-5)
        {
            CI.AddToLog("WARNING: UCartData::ReadSlices(). Almost identical slice coordinates (slice %d)\n", i);
        }
        t = ys[i] - ys[i-1];
    }

/* Center the Y coordinate */
    double ynew[MAX_SLICES];
    double yav = ys[0];
    for(int i=0; i<ny; i++) yav    += ys[i];
    yav /= ny;
    for(int i=0; i<ny; i++) ynew[i] = ys[i] - yav;

/* Create the volume field */
    int pixels  = nx * ny * nz;
    int nxny    = nx * ny;

/* Read each planar slice and add it into the volume in 2-byte units */
    short* data     = new short[pixels];
    char*  scan_buf = new char[sizeof(short)*nx*nz];
    if(!data || !scan_buf)
    {
        CI.AddToLog("ERROR: UCartData::ReadSlices: Memory allocation error in read buffer. Npixels=%d, nx=%d, ny=%d.\n",pixels,nx,nz);
        delete[] data;
        delete[] scan_buf;
        return NULL;
    }

    for(int slice=0; slice<ny; slice++)
    {
        if(GetPixels(FileNames[slice], scan_buf)!=U_OK)
        {
            CI.AddToLog("ERROR: UCartData::ReadSlices: file contains other that byte, short or color information\n");
            delete[] data;
            delete[] scan_buf;
            return NULL;
        }

        char* bp  = scan_buf;
        if(swap==1)
        {
            for(int x=nx-1; x>=0; x--)
            {
                int nxslice = nx*slice + x;
                for(int z=0; z<nz; z++)
                {
                    unsigned char v = *bp++;
                    data[nxslice] = 256 * v + *(unsigned char *)bp++;
                    nxslice += nxny;
                }
            }
        }
        else
        {
            for(int x=nx-1; x>=0; x--)
            {
                int nxslice = nx*slice + x;
                for(int z=0; z<nz; z++)
                {
                    unsigned char v = *bp++;
                    data[nxslice] = v + 256 * *(unsigned char *)bp++;
                    nxslice += nxny;
                }
            }
        }
    }
    delete[] scan_buf;

/* Create the 3D output field */
    int     ddims[3] = {(nx+pixdown-1)/pixdown, (ny+slicedown-1)/slicedown, (nz+pixdown-1)/pixdown};
    double* xcoords  = new double[ddims[0]];
    double* ycoords  = new double[ddims[1]];
    double* zcoords  = new double[ddims[2]];
    if(xcoords==NULL || ycoords==NULL || zcoords==NULL)
    {
        delete[] xcoords;
        delete[] ycoords;
        delete[] zcoords;
        delete[] data;
        CI.AddToLog("ERROR: UCartData::ReadSlices: Could not allocate memory for field coordinates\n");
        return NULL;
    }
/* Fill coordinate arrays */
    double* p;
    int     i=0;
    for(p=xcoords, i=0; i<nx; i+=pixdown)           *p++ =  (i - (nx / 2)) * dx;
    if(centerY ==true)
        for(p=ycoords, i=0; i<ny; i+=slicedown)     *p++ =  ynew[i];
    else
        for(p=ycoords, i=0; i<ny; i+=slicedown)     *p++ =  ys[i];
    if(ReverseSlices==true)
        for(p=ycoords, i=0; i<ny; i+=slicedown,p++) *p   =  -*p;
    for(p=zcoords, i=0; i<nz; i+=pixdown)           *p++ = -(i - (nz / 2)) * dz;

    UField::DataType DT=UField::U_BYTE;
    if(WordOn==true) DT = UField::U_SHORT;
    int veclen = 1;
    UField* Output = new UField(xcoords, ycoords, zcoords, ddims, DT, veclen);
    delete[] xcoords;
    delete[] ycoords;
    delete[] zcoords;
    if(Output==NULL || Output->GetError()!=U_OK)
    {
        delete[] data;
        CI.AddToLog("ERROR: UCartData::ReadSlices: Could not allocate memory for output field.\n");
        return NULL;
    }

/* Move the pixel data from the byte/short/RGB array (data) to the field */

    int    hl = pixmax - pixmin;
    short* sp = data;

    if(pixdown==1 && slicedown==1)     /* no downsizing required */
    {
        if(WordOn==true)
        {
            short* ips = Output->GetSdata();
            memcpy(ips, sp, pixels * sizeof(short));
        }
        else
        {
            unsigned char* bp = Output->GetBdata();
            if(hl == 0)
            {
                for (i=0; i<pixels; i++)
                *bp++ = *sp++ > pixmin ? 255 : 0;
            }
            else if(pixmin==0)
            {
                for(i=0; i<pixels; i++)
                {
                    short v = *sp++;
                    if(v > pixmax) *bp++ = 255;
                    else           *bp++ = v * 255 / pixmax;
                }
            }
            else
            {
                for (i=0; i<pixels; i++)
                {
                    short v = *sp++;
                    if     (v > pixmax)  *bp++ = 255;
                    else if(v < pixmin ) *bp++ = 0;
                    else                 *bp++ = (v-pixmin) * 255 / hl;
                }
            }
        }
    }
    else /* we need to downsize data here, making the loops more elaborate */
    {
        if(WordOn==true)
        {
            short* ips = Output->GetSdata();
            for(int z=0; z<nz; z+=pixdown)
                for(int y=0; y<ny; y+=slicedown)
                {
                    short* sp = data + z*nxny + y*nx;
                    for(int x=0; x<nx; x+=pixdown)
                    *ips++ = sp[x];
                }
        }
        else
        {
            unsigned char* bp = Output->GetBdata();
            if(hl == 0)
            {
                for(int z=0; z<nz; z+=pixdown)
                    for(int y=0; y<ny; y+=slicedown)
                    {
                        short* sp = data + z*nxny + y*nx;
                        for(int x=0; x<nx; x+=pixdown)
                            *bp ++ = sp[x] > pixmin ? 255 : 0;
                    }
            }
            else if(pixmin == 0)
            {
                for(int z=0; z<nz; z+=pixdown)
                    for(int y=0; y<ny; y+=slicedown)
                    {
                        short* sp = data + z*nxny + y*nx;
                        for(int x=0; x<nx; x+=pixdown)
                        {
                            short v = sp[x];
                            if (v > pixmax) *bp++ = 255;
                            else            *bp++ = v * 255 / pixmax;
                        }
                    }
            }
            else
            {
                for(int z=0; z<nz; z+=pixdown)
                    for(int y=0; y<ny; y+=slicedown)
                    {
                        short* sp = data + z*nxny + y*nx;
                        for(int x=0; x<nx; x+=pixdown)
                        {
                            short v = sp[x];
                            if     (v > pixmax)  *bp++ = 255;
                            else if(v < pixmin ) *bp++ = 0;
                            else                 *bp++ = (v-pixmin) * 255 / hl;
                        }
                    }
            }
        }
    }
    delete[]data;
    return Output;
}

const char* UCartData::GetProperties(const char* Comment) const
{
    char Begin[8] = {0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,7);

    char End        = ';';
    if(Comment) End = '\n';

    memset(Properties,0,MAXPROPERTIES);

    PatInfo Pinfo;
    GetPatInfo(FileNames[0], &Pinfo);
    int nc  = sprintf(Properties,   "%s Patient = %s %c",Begin, Pinfo.PatName, End);
    nc     += sprintf(Properties+nc,"%s PatientID = %s %c",Begin, Pinfo.PatNumber, End);
    nc     += sprintf(Properties+nc,"%s Scandate = %s %c",Begin, Pinfo.ScanDate, End);

    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: UCartData::GetProperties(). Array overflow: nc=%d .\n",nc);

    return Properties;
}

ErrorType UCartData::GetGeomInfo(UFileName FileName, GeomInfo* GInfo)
{
    if(GInfo==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetGeomInfo(). NULL argument. \n");
        return U_ERROR;
    }
    FILE *fp=fopen(FileName,"rb",false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UCartData::GetGeomInfo(). File cannot be read : %s. \n", FileName.GetFullFileName());
        return U_ERROR;
    }
    unsigned char buffer[RECORD_SIZE];
    fread(buffer,RECORD_SIZE,1,fp);
    fclose(fp);

    GInfo->Dx          = (double)swap16(buffer+18) /10000.0;
    GInfo->Dy          = (double)swap16(buffer+20) /10000.0;
    GInfo->ndimx       = (int   )swap16(buffer+14);
    GInfo->ndimy       = (int   )swap16(buffer+16);
    GInfo->SlicePos    = (double)swap16(buffer+12) /10.0;
    switch(swap16(buffer+108))
    {
    case 1:  GInfo->OT = U_ORI_AXIAL;   break;
    case 2:  GInfo->OT = U_ORI_CORONAL; break;
    case 3:  GInfo->OT = U_ORI_SAGITAL; break;
    default: GInfo->OT = U_ORI_UNKNOWN;
    }
    GInfo->ST = (int) swap16(buffer+10);

    return U_OK;
}

ErrorType UCartData::GetGeomInfo(GeomInfo* GInfo)
{
    if(FileNames==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetGeomInfo(). FileNames==NULL");
        return U_ERROR;
    }
    return GetGeomInfo(FileNames[0], GInfo);
}

ErrorType  UCartData::GetPatInfo(PatInfo* PInfo)
{
    if(FileNames==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetPatInfo(). FileNames==NULL");
        return U_ERROR;
    }
    return GetPatInfo(FileNames[0], PInfo);
}

ErrorType UCartData::GetPatInfo(UFileName FileName, PatInfo* PInfo)
{
    if(PInfo==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetPatInfo(). NULL argument. \n");
        return U_ERROR;
    }
    FILE *fp=fopen(FileName,"rb",false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UCartData::GetPatInfo(). File cannot be read : %s. \n", FileName.GetFullFileName());
        return U_ERROR;
    }
    unsigned char buffer[RECORD_SIZE];
    fread(buffer,RECORD_SIZE,1,fp);
    fclose(fp);

    memset(PInfo->PatName,   0, sizeof(PInfo->PatName));
    memset(PInfo->PatNumber, 0, sizeof(PInfo->PatNumber));
    memset(PInfo->ScanDate,  0, sizeof(PInfo->ScanDate));
    memcpy(PInfo->PatName  , buffer+260 , sizeof(PInfo->PatName)-1);
    memcpy(PInfo->PatNumber, buffer+244 , sizeof(PInfo->PatNumber)-1);
    memcpy(PInfo->ScanDate , buffer+152 , sizeof(PInfo->ScanDate)-1);

    return U_OK;
}


ErrorType UCartData::GetPixels(UFileName FileName, char* buffer)
/*
     read the pixels from file FileName[] and store the result in buffer[] (which should be allocated
     in the calling function).
 */
{
    if(buffer==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetPixels(). NULL argument. \n");
        return U_ERROR;
    }
    FILE *fp=fopen(FileName,"rb", false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UCartData::GetPixels(). File cannot be read : %s. \n", FileName.GetFullFileName());
        return U_ERROR;
    }
    fread(buffer,RECORD_SIZE,1,fp);

    int ndimx       = (int)swap16(buffer+14);
    int ndimy       = (int)swap16(buffer+16);
    int offset      = (int)swap16(buffer+ 6);

    fseek(fp, offset*RECORD_SIZE, SEEK_SET);
    fread(buffer, sizeof(short), ndimx*ndimy, fp);
    fclose(fp);

    return U_OK;
}

ErrorType UCartData::GetContInfo(UFileName FileName, ContInfo* CT)
{
    if(CT==NULL)
    {
        CI.AddToLog("ERROR: UCartData::GetContInfo(). NULL argument. \n");
        return U_ERROR;
    }
    FILE *fp=fopen(FileName,"rb",false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UCartData::GetContInfo(). File cannot be read : %s. \n", FileName.GetFullFileName());
        return U_ERROR;
    }
    unsigned char buffer[RECORD_SIZE];
    fread(buffer,RECORD_SIZE,1,fp);

    double Dx       = (double)swap16(buffer+18) /10000.0;
    double Dy       = (double)swap16(buffer+20) /10000.0;
    CT->SlicePos    = (double)swap16(buffer+12) /10.0;

    fseek(fp, 2*RECORD_SIZE, SEEK_SET);
    fread(buffer,RECORD_SIZE,1,fp);
    for(int k=0; k<MAX_DRAWING; k++)
    {
        CT->Np[k] = swap16(buffer+2*k);

        if(CT->Np[k]<0 || CT->Np[k]>128)
        {
            CI.AddToLog("WARNING: UCartData::GetContInfo(). Error in file %s. Wrong number of points (%d) in contour %d . \n",  FileName.GetFullFileName(), CT->Np[k], k);
            CT->Np[k] = 0;
        }
    }
    for(int k=0; k<MAX_DRAWING; k++)
    {
        fseek(fp,(3+k)*RECORD_SIZE, SEEK_SET);
        fread(buffer,RECORD_SIZE,1,fp);

        for(int n=0; n<CT->Np[k]; n++)
        {
            CT->xp[k][n] = Dx * swap16(buffer+4*n);
            CT->yp[k][n] = Dy * swap16(buffer+4*n+2);
        }
    }
    fclose(fp);
    return U_OK;
}

static int GeomOrder(const void *elem1, const void *elem2)
{
    const UFileName F1 = *(UFileName*) elem1;
    const UFileName F2 = *(UFileName*) elem2;

    UCartData::GeomInfo G1;
    UCartData::GeomInfo G2;

    UCartData::GetGeomInfo(F1, &G1);
    UCartData::GetGeomInfo(F2, &G2);

    if((int)G1.ST < (int)G2.ST) return -1;
    if((int)G1.ST > (int)G2.ST) return  1;

    if((int)G1.OT < (int)G2.OT) return -1;
    if((int)G1.OT > (int)G2.OT) return  1;

    if(G1.ndimx < G2.ndimx) return -1;
    if(G1.ndimx > G2.ndimx) return  1;

    if(G1.ndimy < G2.ndimy) return -1;
    if(G1.ndimy > G2.ndimy) return  1;

    if(G1.Dx < G2.Dx) return -1;
    if(G1.Dx > G2.Dx) return  1;

    if(G1.Dy < G2.Dy) return -1;
    if(G1.Dy > G2.Dy) return  1;

    if(G1.SlicePos < G2.SlicePos) return -1;
    if(G1.SlicePos > G2.SlicePos) return  1;

    return 0;
}

ErrorType UCartData::AnalyzeCartFiles(const char* FileN)
/*
    Analyze the files in the directory CartDir and determine the
    first and last file of each scan. This is done by analyzing the
    pixel size, file number, z-coordinate, gantry tilt, etc. All these
    data of subsequent files should be consistent in order to belong to
    one scan.

    Export cause of slice inconsistency to log file.
 */
{
    if(CartDir.GetStatus()!=UDirectory::U_EXIST)
    {
        CI.AddToLog("ERROR : UCartData::AnalyzeCartFiles(). Directory %s does not exist\n", CartDir.GetDirectoryName());
        return U_ERROR;
    }

    delete[] FileNames;  FileNames   = NULL;
    Nfiles      = 0;

    UFileName SomeFile(FileN);
    SomeFile.ReplaceExtension("*");
    FileNames = CartDir.GetAllFileNames(SomeFile.GetFullFileName(), &Nfiles);
    if(FileNames==NULL || Nfiles<=0)
    {
        CI.AddToLog("ERROR : UCartData::AnalyzeCartFiles(). Memory allocation\n");
        return U_ERROR;
    }

/* Get all good file names*/
    int Nfgood = 0;
    for(int i=0; i<Nfiles; i++)
    {
        const char* Ext = FileNames[i].GetExtension();
        size_t       nb = strlen(Ext);

        bool GoodFile   = false;
        if(nb==3 &&
          '0'<=Ext[1]&&Ext[1]<='9' &&
          '0'<=Ext[2]&&Ext[2]<='9')    GoodFile = true;

        if(nb==2 &&
          '0'<=Ext[1]&&Ext[1]<='9')    GoodFile = true;

        if(GoodFile==false)
        {
            CI.AddToLog("Note:  UCartData::AnalyzeCartFiles(). Skipping %s (wrong file name). \n", FileNames[i].GetFullFileName());
            continue;
        }

        GeomInfo  GInfo;
        if(GetGeomInfo(FileNames[i], &GInfo)!=U_OK)
        {
            CI.AddToLog("Note:  UCartData::AnalyzeCartFiles(). Cannot read data header from %s .\n", FileNames[i].GetFullFileName());
            continue;
        }

        if(Nfgood==0)
        {
            OT          = GInfo.OT;
            ScanType    = GInfo.ST;
        }
        FileNames[Nfgood] = FileNames[i];
        Nfgood++;
    }
    Nfiles = Nfgood;
    if(Nfiles==0)
    {
        CI.AddToLog("ERROR : UCartData::AnalyzeCartFiles(). No good files found in %s\n", CartDir.GetDirectoryName());
        return U_ERROR;
    }
/* sort file names on geom info*/
    qsort(FileNames, Nfiles, sizeof(UFileName), GeomOrder);

    return U_OK;
}

ErrorType UCartData::swapxy(void* buffer, int size, int nx, int ny) const
{
    char* temp = new char[size*nx*ny];
    if(temp==NULL)
    {
        CI.AddToLog("ERROR: UCartData::swapxy(). Memory allocation, nbytes = %d \n",size*nx*ny);
        return U_ERROR;
    }
    memcpy(temp, buffer, size*nx*ny);

    switch(size)
    {
    case 1:
        {
            char* cp = (char*) buffer;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *cp++ = temp[iy*nx+ix];
            break;
        }
    case 2:
        {
            short* sp     = (short*) buffer;
            short* sptemp = (short*) temp;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *sp++ = sptemp[iy*nx+ix];
            break;
        }
    case 4:
        {
            int* ip     = (int*) buffer;
            int* iptemp = (int*) temp;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *ip++ = iptemp[iy*nx+ix];
            break;
        }
    default:
        {
            char* cp = (char*)buffer;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++)
                    for(int k=0; k<size; k++) *cp++ = temp[(iy*nx+ix)*size+k];
            break;
        }
    }
    delete[] temp;
    return U_OK;
}

short UCartData::swap16(unsigned char *n)
{
    unsigned char sw[2];

    if(swap)
    {
        sw[0] = n[1];
        sw[1] = n[0];
    }
    else
    {
        sw[0] = n[0];
        sw[1] = n[1];
    }
    return *(short*) sw;
}

short UCartData::swap16(char *n)
{
    char sw[2];

    if(swap)
    {
        sw[0] = n[1];
        sw[1] = n[0];
    }
    else
    {
        sw[0] = n[0];
        sw[1] = n[1];
    }
    return *(short*) sw;
}
