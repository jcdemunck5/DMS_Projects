#ifndef _CARTDATA_INCLUDED
#define _CARTDATA_INCLUDED

/*
  Update history

  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Field.h"
#include "Directory.h"
#include "Drawing.h"
#include "Surface.h"

#define MAX_DRAWING    10


class DLL_IO UCartData
{
public:
    struct GeomInfo               // Geometrical information about the scan which should
    {                                     // be present in each Somatom file.
        double     Dx;                    // pixel size in x-direction
        double     Dy;                    // pixel size in y-direction
        int        ndimx;                 // number of pixels in x-direction
        int        ndimy;                 // number of pixels in y-direction
        double     SlicePos;              // slice position
        OrientType OT;                    // scan orientation
        int        ST;                    // scan type
    };
    struct PatInfo                // Patient info
    {                                     // be present in each Cart file.
        char       PatName[40+1];
        char       PatNumber[16+1];
        char       ScanDate[12+1];
    };
    struct ContInfo
    {
        int        Np[MAX_DRAWING];
        double     xp[MAX_DRAWING][256];
        double     yp[MAX_DRAWING][256];
        double     SlicePos;
    };

    UCartData(const char* CarFileNames);
    ~UCartData();

    ErrorType          GetError(void)  const {return error;}
    const char*        GetProperties(const char* Comment) const;

    UDrawing**         ReadDrawings(int* Ndraw, UVector3 Center=UVector3()) const;
    USurface**         ReadSurfaces(int* Nsurf, UVector3 Center=UVector3()) const;
    UField*            ReadSlices(bool WordOn, int pixmin, int pixmax, int numslices, int pixdown, int slicedown, bool centerY, bool ReverseSlices);
    UEuler             GetScanToWld(void) const;

    const char*        GetFirstFileName(void) const {if(FileNames) return FileNames[0].GetFullFileName(); return NULL;}
    ErrorType          GetGeomInfo(GeomInfo* GInfo);
    ErrorType          GetPatInfo(PatInfo* PInfo);

    static ErrorType   GetGeomInfo(UFileName FileName, GeomInfo* GInfo);
    static ErrorType   GetPatInfo(UFileName FileName, PatInfo* PInfo);
    static ErrorType   GetPixels(UFileName FileName, char* buffer);
    static ErrorType   GetContInfo(UFileName FileName, ContInfo* CT);

private:
    ErrorType          error;       // General error flag
    static const int   MAXPROPERTIES;
    char*              Properties;

    UDirectory         CartDir;     // Directory with the Cart files to be examined
    UFileName*         FileNames;   // Image files to be examined
    int                Nfiles;      // Number of files in CartDir

    OrientType         OT;
    int                ScanType;

    ErrorType          AnalyzeCartFiles(const char* FileDesc);
    static short       swap16(unsigned char *n);
    static short       swap16(char *n);
    ErrorType          swapxy(void* buffer, int size, int nx, int ny) const;
};

#endif //_CARTDATA_INCLUDED
