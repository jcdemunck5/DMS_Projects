/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
#include"Chamfer.h"
#include"avscoor_AVL.h"
  
#include"Field.h" 
#include"PointList.h" 
#include"Distribution.h" 

const double UChamfer::DIS2ANG   = 0.1;   // 1 cm ~ .1 Radian (= 5.7 degree)
const double UChamfer::DIS2SCA   = 0.01;  // 1 cm ~ 1% scaling
const double UChamfer::COSTERROR = 1000.;

UChamfer::UChamfer() : Uminimize(UCostminimize())
{
    DistanceXFM = NULL;
    Dots        = NULL;
    Npar        = 0;
}

UChamfer::~UChamfer()
{
    delete DistanceXFM;
    delete Dots;
}

bool UChamfer::IsReadyForMatching(void) const
{
    if(DistanceXFM && DistanceXFM->GetError()==U_OK) return true;
    return false;
}

ErrorType UChamfer::ComputeDistanceXFM(const UField* F)
{
    if(F==NULL || F->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeDistanceXFM(). NULL or erroneous argument. \n");
        return U_ERROR;
    }
    if( F->Getndim()!=3   || 
        F->GetVeclen()!=1 || 
       (F->GetFType()!=UField::U_UNIFORM && F->GetFType()!=UField::U_RECTILINEAR) ||
        F->GetDType()!=UField::U_BYTE
       )
    {
        CI.AddToLog("ERROR: UChamfer::ComputeDistanceXFM(). Input field is of wrong type (%s) .\n", (const char*)F->GetProperties(""));
        return U_ERROR;
    }
    delete DistanceXFM;
    DistanceXFM = new UField(*F);

    ErrorType   E = DistanceXFM->EdgeDetect(true);
    if(E==U_OK) E = DistanceXFM->DistanceXFM();
    
    if(E!=U_OK)
    {
        delete DistanceXFM; DistanceXFM = NULL;
        CI.AddToLog("ERROR: UChamfer::ComputeDistanceXFM(). Thresholding or computing distance transform. \n");
        return U_ERROR;
    }
    return E;
}

ErrorType UChamfer::Match(const UPointList* PL, UEuler* Xfm)
{
    if(PL==NULL || PL->GetError()!=U_OK || Xfm==NULL)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). NULL or erroneous arguments. \n");
        return U_ERROR;
    }
    if(IsReadyForMatching()==false)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Object not ready for matching yet.\n");
        return U_ERROR;
    }
    delete Dots; 
    Dots = PL->GetIrregularField(1);
    if(Dots==NULL || Dots->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Converting UPointList into UField.\n");
        return U_ERROR;
    }

/* Do the iterative search of the transformation w.r.t. the initial guess*/
    if(Dots->xfm(*Xfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Cannot Transform points.\n");
        return U_ERROR;
    }

    Npar          = 6;
    double par[6] = {0.,0.,0.,0.,0.,0.};
    double    StartCost = ComputeCost(par, -1, NULL);
    ErrorType error     = Iterate(par,6,2.);
    double    FinCost   = ComputeCost(par, -1, NULL);

    *Xfm = Par2Euler(par) * *Xfm;

    double RotFac = DIS2ANG*180./PI;
    CI.AddToLog("Note: UChamfer::Match() \n");
    CI.AddToLog("Note: Start cost = %f \n", StartCost);
    CI.AddToLog("Note: Final cost = %f \n", FinCost);
    CI.AddToLog("Note: N iterations = %d \n", GetNoIterations());
    CI.AddToLog("Note: N points  = %d \n", Dots->GetNpoints());
    CI.AddToLog("Note: Translations:  (%f, %f, %f) \n",       par[0],       par[1],       par[2]);
    CI.AddToLog("Note: Rotations:     (%f, %f, %f) \n",RotFac*par[3],RotFac*par[4],RotFac*par[5]);

    return U_OK;
}

double UChamfer::ComputeCost(const UPointList* PL, const UEuler* Xfm)
{
    if(PL==NULL || PL->GetError()!=U_OK || Xfm==NULL)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). NULL or erroneous arguments. \n");
        return COSTERROR;
    }
    if(IsReadyForMatching()==false)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). Object not ready for computing cost.\n");
        return U_ERROR;
    }
    delete Dots; 
    Dots = PL->GetIrregularField(1);
    if(Dots==NULL || Dots->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). Converting UPointList into UField.\n");
        return COSTERROR;
    }
    Npar = 6;
    double par[6];
    if(Euler2Par(*Xfm, par)!=U_OK) return COSTERROR;
    return ComputeCost(par, 0, NULL);
}

ErrorType UChamfer::Match(const UPointList* PL, UEuler* Xfm, double* Sx, double* Sy, double* Sz)
{
    if(PL==NULL || PL->GetError()!=U_OK || Xfm==NULL || Sx==NULL || Sy==NULL || Sz==NULL)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). NULL or erroneous arguments. \n");
        return U_ERROR;
    }
    if(IsReadyForMatching()==false)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Object not ready for matching yet.\n");
        return U_ERROR;
    }
    delete Dots; 
    Dots = PL->GetIrregularField(1);
    if(Dots==NULL || Dots->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Converting UPointList into UField.\n");
        return U_ERROR;
    }

/* Do the iterative search of the transformation w.r.t. the initial guess*/
    if(Dots->xfm(*Xfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::Match(). Cannot Transform points.\n");
        return U_ERROR;
    }

    Npar          = 9;
    double par[9] = {0.,0.,0.,0.,0.,0.,0.,0.,0.};
    double    StartCost = ComputeCost(par, -1, NULL);
    ErrorType error     = Iterate(par,9,2.);
    double    FinCost   = ComputeCost(par, -1, NULL);


    *Xfm  = Par2Euler(par) * *Xfm;
    *Sx  *= 1.+DIS2SCA*par[6];
    *Sy  *= 1.+DIS2SCA*par[7];
    *Sz  *= 1.+DIS2SCA*par[8];

    double RotFac = DIS2ANG*180./PI;
    CI.AddToLog("Note: UChamfer::Match() \n");
    CI.AddToLog("Note: Start cost = %f \n", StartCost);
    CI.AddToLog("Note: Final cost = %f \n", FinCost);
    CI.AddToLog("Note: N iterations = %d \n", GetNoIterations());
    CI.AddToLog("Note: N points  = %d \n", Dots->GetNpoints());
    CI.AddToLog("Note: Translations:  (%f, %f, %f) \n",       par[0],       par[1],       par[2]);
    CI.AddToLog("Note: Rotations:     (%f, %f, %f) \n",RotFac*par[3],RotFac*par[4],RotFac*par[5]);
    CI.AddToLog("Note: Scalings:      (%f, %f, %f) \n",   100*  *Sx ,100.*    *Sy ,100.*    *Sz );

    return U_OK;
}

double UChamfer::ComputeCost(const UPointList* PL, const UEuler* Xfm, const double* Sx, const double* Sy, const double* Sz)
{
    if(PL==NULL || PL->GetError()!=U_OK || Xfm==NULL || Sx==NULL || Sy==NULL || Sz==NULL)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). NULL or erroneous arguments. \n");
        return COSTERROR;
    }
    if(IsReadyForMatching()==false)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). Object not ready for computing cost.\n");
        return U_ERROR;
    }
    delete Dots; 
    Dots = PL->GetIrregularField(1);
    if(Dots==NULL || Dots->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UChamfer::ComputeCost(). Converting UPointList into UField.\n");
        return U_ERROR;
    }

    Npar = 9;
    double par[9];
    if(LinTran2Par(*Xfm, *Sx, *Sy, *Sz, par)!=U_OK) return COSTERROR;
    return ComputeCost(par, 0, NULL);
}

double UChamfer::ComputeCost(double *par, int iter, int *CostEr)
{
    const int  OUTSIDE = 255;
    const int  InterT  =   1; // Linear interpolation
    const bool Logging = false;

    UField* CostField=NULL;
    if(Npar==6)
    {
        UEuler XFM = Par2Euler(par);
        CostField  = DistanceXFM->ResampleField(XFM, Dots, InterT, OUTSIDE, Logging);
    }
    else if(Npar==9)
    {
        ULinTran XFM = Par2LinTran(par);
        CostField    = DistanceXFM->ResampleField(XFM, Dots, InterT, OUTSIDE, Logging);
    }
    if(CostField==NULL || CostField->GetError()!=U_OK)
    {
        delete CostField;
        return COSTERROR;
    }
    
    unsigned char* Data = CostField->GetBdata();

/* Add distances*/
    double Cost = 0;
    int    NpIn = 0;
    for(int k=0; k<CostField->GetNpoints(); k++) 
    {
        if(Data[k]==OUTSIDE) continue;
        
        Cost += Data[k];
        NpIn++;
    }
    if(NpIn)  Cost /= NpIn;
    else      Cost  = COSTERROR;

    if(iter==-1)
    {
        UDistribution Dist(255, 0, 255);
        for(int k=0; k<CostField->GetNpoints(); k++)
            Dist.AddValue((double) Data[k]);
        CI.AddToLog("%s",Dist.GetProperties("Dist "));
////        CI.AddToLog("%s",Dist.GetDistributionText("Dist ", true, false, false));
    }

    delete CostField;

    return Cost;
}

UEuler UChamfer::Par2Euler(const double* par) const
{
    return UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);
}

ULinTran UChamfer::Par2LinTran(const double* par) const
{
    return ULinTran(Par2Euler(par), 1.+DIS2SCA*par[6], 1.+DIS2SCA*par[7], 1.+DIS2SCA*par[8]);
}

ErrorType UChamfer::Euler2Par(UEuler E, double* par) const
{
    if(E.GetParameters(par)!=U_OK) return U_ERROR;
    par[3] /= DIS2ANG;
    par[4] /= DIS2ANG;
    par[5] /= DIS2ANG;
    return U_OK;
}

ErrorType UChamfer::LinTran2Par(UEuler E, double Sx, double Sy, double Sz, double* par) const
{
    if(E.GetParameters(par)!=U_OK) return U_ERROR;
    par[3] /= DIS2ANG;
    par[4] /= DIS2ANG;
    par[5] /= DIS2ANG;
    par[6]  = (Sx-1.)/DIS2SCA;
    par[7]  = (Sy-1.)/DIS2SCA;
    par[8]  = (Sz-1.)/DIS2SCA;
    return U_OK;
}
