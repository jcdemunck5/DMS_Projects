#ifndef _CHAMFER_INCLUDED
#define _CHAMFER_INCLUDED

#include"Minimize.h"
#include"LinTran.h"

class UPointList;
class UField;
class UEuler;

class DLL_IO UChamfer : public Uminimize
{
public:
    UChamfer();
    ~UChamfer();

    bool      IsReadyForMatching(void) const;

    ErrorType     ComputeDistanceXFM(const UField* F);
    const UField* GetDistanceXFM(void) const {return DistanceXFM;}

    ErrorType     Match(const UPointList* PL, UEuler* Xfm);
    ErrorType     Match(const UPointList* PL, UEuler* Xfm, double* Sx, double* Sy, double* Sz);
    double        ComputeCost(const UPointList* PL, const UEuler* Xfm);
    double        ComputeCost(const UPointList* PL, const UEuler* Xfm, const double* Sx, const double* Sy, const double* Sz);

private:
    static const double DIS2ANG;
    static const double DIS2SCA;
    static const double COSTERROR;

    UField*   DistanceXFM;
    UField*   Dots;
    int       Npar;

    double    ComputeCost(double *par, int iter, int *CostEr);
    UEuler    Par2Euler(const double* par) const;
    ULinTran  Par2LinTran(const double* par) const;
    ErrorType Euler2Par(UEuler E, double* par) const;
    ErrorType LinTran2Par(UEuler E, double Sx, double Sy, double Sz, double* par) const;
};


#endif //_CHAMFER_INCLUDED

