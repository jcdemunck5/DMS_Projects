/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for clustering objects.                                            */
/*                                                                               */
/*                                                                               */
/*     Arent de Jongh                                                            */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    25-08-02   creation (derived code of A. de Jongh)
  JdM    14-02-03   Made DisTab[] a float array to reduce memory consumption
  JdM    28-02-03   Made InitClustering() protected
  JdM    05-03-03   Made syntax compatible with GNU compiler (e.g. avoid pure virtual function in constructor)
  JdM    30-10-03   Bug fix: ComputeClusters(). treat the case that Ncluster<=1 separately.
  JdM    25-04-04   Added operator=() and copy constructor
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    16-04-05   Changed lay out of log file output.
  JdM    13-08-05   Added new InitClustering(), avoid pure virtual functions
  JdM    05-04-06   Added GetProperties(). Defined LinkType outside object, and renamed as LinkType
  JdM    14-02-07   operator=(). Avoid copying of DisTab, when arument has NULL DisTab
                    Added WriteBinary() and a FILE* constructor
  JdM    03-05-07   InitClusteringTables(). Delete (obsolete) DisTab[], at the end of the function
  JdM    26-10-07   Made HEADERBEGIN and HEADEREND static const char*
  JdM    11-11-07   Bug Fix: CanClusterBeComputed(). Old version always returned true
  JdM    12-06-08   Added virtual ShowStatus()
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    01-11-10   Remove all data conversion WARNINGS. This might lead to round off differences!
  JdM    14-05-11   Added GetLinkArcArray() and required additional functions
*/

#include <math.h> 
#include <string.h> 
#include "Cluster.h"

UString      UCluster::Properties  = UString();
const char*  UCluster::HEADERBEGIN = "Cluster1.0";
const char*  UCluster::HEADEREND   = "ClusterEnd";



void UCluster::SetAllMembersDefault(void)
{
    Nobjects = 0;
    DisTab   = NULL;
    Link     = NULL;
    Cnumb    = NULL;
    error    = U_OK;
    LMethod  = U_LINK_NOTYPE;
}

void UCluster::DeleteAllMembers(ErrorType E)
{
    delete[] DisTab;
    delete[] Link;
    delete[] Cnumb;
    SetAllMembersDefault();
    error   = E;
}

UCluster::UCluster(LinkType LM)
{
    SetAllMembersDefault();
    LMethod  = LM;
    if(LM!=U_LINK_CENTROID && LM!=U_LINK_WARD) LMethod = U_LINK_NOTYPE;
}

UCluster::UCluster(const UCluster& Clus)
{
    SetAllMembersDefault();
    *this = Clus;
}

UCluster::UCluster(FILE* fpIn)
{
    SetAllMembersDefault();
    if(fpIn==NULL)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UCluster::UCluster(). Invalid NULL pointer. \n");
        return;
    }
    unsigned int ioff   = ftell(fpIn);
    unsigned int NHead  = strlen(HEADERBEGIN);
    char     Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        fseek(fpIn, ioff, SEEK_SET);    
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCluster::UCluster(). Reading first item from file pointer. \n");
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        fseek(fpIn, ioff, SEEK_SET);    
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCluster::UCluster(). Wrong header (%s). \n", Buffer);
        return;
    }

    int dum1 = ::ReadBinaryInt(DefaultIntelData, fpIn);
    LMethod  = U_LINK_NOTYPE;
    switch(dum1)
    {
    case 1: LMethod  = U_LINK_CENTROID; break;
    case 2: LMethod  = U_LINK_WARD    ; break;
    default:
        fseek(fpIn, ioff, SEEK_SET);    
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCluster::UCluster(). Invalid link type (LMethod = %d). \n", dum1);
        return;
    }

    Nobjects = ::ReadBinaryInt(DefaultIntelData, fpIn);
    if(Nobjects<=0)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);    
        CI.AddToLog("ERROR: UCluster::UCluster(). Invalid number of objects  (Nobjects = %d). \n", Nobjects);
        return;
    }
    Link = new ULinkage[Nobjects];
    if(Link==NULL)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);    
        CI.AddToLog("ERROR: UCluster::UCluster(). Memory allocation  (Nobjects = %d). \n", Nobjects);
        return;
    }

    for(int i=0; i<Nobjects; i++)
    {
        Link[i].ind1 = ::ReadBinaryInt   (DefaultIntelData,fpIn);
        Link[i].ind2 = ::ReadBinaryInt   (DefaultIntelData,fpIn);
        Link[i].dist = ::ReadBinaryDouble(DefaultIntelData,fpIn);
    }
    fread(Buffer,1,strlen(HEADEREND),fpIn);
} 

UCluster::~UCluster()
{
    DeleteAllMembers(U_OK);
}

UCluster& UCluster::operator=(const UCluster &Clus)
{
    if(this==NULL)
    {
        static UCluster Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: UCluster::operator=(). this==NULL. \n");
        return Def;
    }
    if(&Clus==NULL)
    {
        CI.AddToLog("ERROR: UCluster::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Clus) return *this;

    if(Clus.Nobjects<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCluster::operator=(). Argument has invalid number of objecs: Clus.Nobjects=%d    . \n", Clus.Nobjects);
        return *this;
    }
    DeleteAllMembers(U_OK);

    Nobjects = Clus.Nobjects;
    LMethod  = Clus.LMethod;

    if(Nobjects<=0) return *this;

    if(Clus.DisTab)
    {
        DisTab   = new float[1  + Nobjects*(Nobjects-1)/2]; 
        if(DisTab==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCluster::operator=(). Memory allocation for distance table. Nobjects = %d  .\n", Nobjects);
            return *this;
        }
        for(int i=0; i<Nobjects*(Nobjects-1)/2; i++) DisTab[i] = Clus.DisTab[i];
    }
    if(Clus.Link)
    {
        Link     = new ULinkage[Nobjects]; 
        if(Link==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCluster::operator=(). Memory allocation for linkage table. Nobjects = %d  .\n", Nobjects);
            return *this;
        }
        for(int i=0; i<Nobjects; i++) Link[i]   = Clus.Link[i];
    }
    if(Clus.Cnumb) 
    {
        Cnumb    = new int[Nobjects];
        if(Cnumb==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCluster::operator=(). Memory allocation for cluster number table. Nobjects = %d  .\n", Nobjects);
            return *this;
        }
        for(int i=0; i<Nobjects; i++) Cnumb[i]  = Clus.Cnumb[i];
    }
    return *this;
}

const UString&  UCluster::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UCluster-object\n");
        return Properties;
    }
    Properties  =  UString();
    Properties +=  UString(Nobjects,"Nobjects          = %d \n");
    switch(LMethod)
    {
    case U_LINK_CENTROID : Properties +=  UString(Nobjects,"LinkMethod      = CENTROID \n"); break;
    case U_LINK_WARD     : Properties +=  UString(Nobjects,"LinkMethod      = WARD     \n"); break;
    default              : Properties +=  UString(Nobjects,"LinkMethod      = UNKNOWN  \n"); break;
    }
    if(DisTab) Properties += UString("TableInitialized = TRUE \n");
    else       Properties += UString("TableInitialized = FALSE\n");
    
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UCluster::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCluster::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Link==NULL || Nobjects<=0)
    {
        CI.AddToLog("ERROR: UCluster::WriteBinary(). Link==NULL or Nobjects invalid (=%d). \n", Nobjects);
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UCluster::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

    unsigned int NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)
    {
        CI.AddToLog("ERROR: UCluster::WriteBinary(). Cannot write Header (%s). \n", HEADERBEGIN);
        return U_ERROR;
    }
    ::WriteBinary((int)LMethod , DefaultIntelData, fpOut);
    ::WriteBinary(     Nobjects, DefaultIntelData, fpOut);

    for(int i=0; i<Nobjects; i++)
    {
        ::WriteBinary(Link[i].ind1, DefaultIntelData, fpOut);
        ::WriteBinary(Link[i].ind2, DefaultIntelData, fpOut);
        ::WriteBinary(Link[i].dist, DefaultIntelData, fpOut);
    }
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}


ErrorType UCluster::InitClustering(LinkType LM, const double* Dist, int Nob)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Object not properly initialyzed. \n");
        return U_ERROR;
    }
    if(LM!=U_LINK_NOTYPE) LMethod=LM;

    if(Dist==NULL || Nob<=0)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Invalid distance table (NULL) or invalid number of objects (Nob=%d). \n", Nob);
        return U_ERROR;
    }

    Nobjects = Nob;
    delete[] DisTab;  DisTab = new float[Nobjects*(Nobjects-1)/2]; // distance array
    if(DisTab==NULL)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Memory allocation. Nobjects = %d  . \n", Nobjects);
        return U_ERROR;
    }

/* Get distances from argument */
    for(int i1=0,i12=0;i1<Nobjects;i1++)
        for(int i2=i1+1;i2<Nobjects;i2++,i12++)
            DisTab[i12] = (float)Dist[i1*Nobjects+i2];

    return this->InitClusteringTables();
}

ErrorType UCluster::InitClustering(LinkType LM) // Use GetDistance2() function of derived class
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Object not properly initialyzed. \n");
        return U_ERROR;
    }
    if(LM!=U_LINK_NOTYPE) LMethod=LM;

    Nobjects = GetNobjects(); // Get number of objects from derived class
    if(Nobjects<=0)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Number of objects out of range, Nobjects = %d  . \n", Nobjects);
        return error;
    }
    delete[] DisTab;  DisTab = new float[Nobjects*(Nobjects-1)/2]; // distance array
    if(DisTab==NULL)
    {
        CI.AddToLog("ERROR: UCluster::InitClustering(). Memory allocation. Nobjects = %d  . \n", Nobjects);
        return U_ERROR;
    }

/* Get distances from derived class */
    int q=0;
    for(int i1=0;i1<Nobjects;i1++)
    {
        for(int i2=i1+1;i2<Nobjects;i2++)
            DisTab[q++] = (float)GetDistance2(i1, i2);
        if(!((i1+1)%20) || i1==Nobjects-1)
        {
            UString Text = UString(i1+1, "Distances %d") + UString(Nobjects," of %d ");
            ShowStatus((const char*) Text, i1, Nobjects);
        }
    }
    return this->InitClusteringTables();
}

ErrorType UCluster::InitClusteringTables(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCluster::InitClusteringTables(). Object not properly initialyzed. \n");
        return U_ERROR;
    }
    if(LMethod!=U_LINK_CENTROID && LMethod!=U_LINK_WARD)
    {
        CI.AddToLog("ERROR: UCluster::InitClusteringTables(). Wrong clustering method: LMethod = %d .\n",LMethod);
        return U_ERROR;
    }
    if(Nobjects<=0)
    {
        CI.AddToLog("ERROR: UCluster::InitClusteringTables(). Number of objects out of range, Nobjects = %d  . \n", Nobjects);
        return U_ERROR;
    }
    if(DisTab==NULL)
    {
        CI.AddToLog("ERROR: UCluster::InitClusteringTables(). Distance table not set. \n");
        return U_ERROR;
    }

    delete[] Link;  Link  = NULL;
    delete[] Cnumb; Cnumb = NULL;

    Link   = new ULinkage[Nobjects];              // output vector
    int* N = new int[2*Nobjects];
    int* R = new int[Nobjects];

    if(Link==NULL || N==NULL || R==NULL)
    {
        delete[] Link;   Link   = NULL;
        delete[] R;
        delete[] N;
        CI.AddToLog("ERROR: UCluster::InitClusteringTable(). Memory allocation. Nobjects = %d  . \n", Nobjects);
        return U_ERROR;
    }
    
    if(LMethod==U_LINK_WARD)
        for(int q=0; q<Nobjects*(Nobjects-1)/2; q++) DisTab[q]/=2;

    for(int i=0;i<Nobjects;i++)
    {
        Link[i].ind1  = 0;
        Link[i].ind2  = 0;
        Link[i].dist  = 0.;
        N[i         ] = 1; 
        N[i+Nobjects] = 0; 
        R[i         ] = i+1;
    }

/* Compute Linkage*/
    int m=Nobjects;// Number of clusters
    for(int s=1;s<=Nobjects-1;s++)
    {
        int   k = 0;
        float v = GetMin(DisTab, m*(m-1)/2, &k); k+=1;
        if(LMethod==U_LINK_CENTROID) v = float(sqrt(v));

        int i=int(floor(((double)m)+0.5 -
                   sqrt(((double)m)*((double)m)-((double)m)
                   +0.25-2.*(((double)k)-1))));                  // i = m - sqrt(m*m-m+2k-2)
        int j=int(floor(0.5 +((double)k)-(((double)i)-1.)*       // j = k -(i-1)*(m-i)/2 + i
              (((double)m)-((double)i)/2.)+((double)i)));

        Link[s-1].ind1 = R[i-1];
        Link[s-1].ind2 = R[j-1];
        Link[s-1].dist = v;
        
        int* I1 = new int[i-1];
        int* I2 = new int[j-i-1];
        int* I3 = new int[m-j];
        int* U  = new int[m-2];
        int* I  = new int[m-2];
        int* J  = new int[m-2];

        if(I1==NULL || I2==NULL || I3==NULL || U==NULL || I==NULL || J==NULL)
        {
            delete[] I1; delete[] I2; delete[] I3;
            delete[]  U; delete[]  I; delete[]  J;

            delete[] Link;   Link   = NULL;
            delete[] R;
            delete[] N;
            CI.AddToLog("ERROR: UCluster::InitClusteringTable(). Memory allocation help arrays. Nobjects = %d  . \n", Nobjects);
            return U_ERROR;
        }

        for(int q=  1;q<i  ;q++)  I1[q-1  ]=q;
        for(int q=i+1;q<j  ;q++)  I2[q-i-1]=q;
        for(int q=j+1;q<m+1;q++)  I3[q-j-1]=q;

        for(int q=1;q<i;q++)
        {
            U[q-1] = I1[q-1];
            I[q-1] = int(floor(0.5 + ((double)I1[q-1])*(((double)m)-
                               (((double)I1[q-1]+((double)1)))
                                /((double)2))-((double)m)+((double)i)));
            J[q-1] = int(floor(0.5 + ((double)I1[q-1])*(((double)m)
                              -(((double)I1[q-1])+1.)/2.)-((double)m)+((double)j)));
        }
        for(int q=i+1;q<j;q++)
        {
            U[q-2] = I2[q-i-1];
            I[q-2] = int(floor(0.5 + ((double)i)*(((double)m)-(((double)i)+1.)/2.)-
                     ((double)m)+((double)I2[q-i-1])));
            J[q-2] = int(floor(0.5 + ((double)I2[q-i-1])*(((double)m)-
                     (((double)I2[q-i-1])+1.)/2.)-((double)m)+((double)j)));
        }
        for(int q=j+1;q<=m;q++)
        {
            U[q-3] = I3[q-j-1];
            I[q-3] = int(floor(0.5 + ((double)i)*(((double)m)-(((double)i)+1.)/2.)-
                     ((double)m)+((double)I3[q-j-1])));
            J[q-3] = int(floor(0.5 + ((double)j)*(((double)m)-(((double)j)+1.)/2.)-
                     ((double)m)+((double)I3[q-j-1])));
        }

        switch(LMethod)
        {
            case(U_LINK_WARD):
                for(int q=1;q<=m-2;q++)
                {
                    DisTab[I[q-1]-1]=float(((((double)N[R[U[q-1]-1]-1])+((double)N[R[i-1]-1]))*((double)DisTab[I[q-1]-1]) +
                              (((double)N[R[U[q-1]-1]-1])+((double)N[R[j-1]-1]))*((double)DisTab[J[q-1]-1])  -
                              ((double)N[R[U[q-1]-1]-1])*v) / 
                              (((double)N[R[i-1]-1]) + ((double)N[R[j-1]-1])+((double)N[R[U[q-1]-1]-1])));
                }
                break;
            case(U_LINK_CENTROID):
                for(int q=1;q<=m-2;q++)
                {
                    double K=(((double)N[R[i-1]-1])+((double)N[R[j-1]-1]));
                    DisTab[I[q-1]-1]=float( (((double)N[R[i-1]-1])*((double)DisTab[I[q-1]-1])+((double)N[R[j-1]-1])*((double)DisTab[J[q-1]-1]) -
                                 (((double)N[R[i-1]-1])*((double)N[R[j-1]-1])*v*v)/ K) / K);
                                
                }
                break;
        }

        int NewM = m-1;
        float* DisTabNew= new float[1+NewM*(NewM-1)/2]; // Assure that at least 1 byte is allocated

        if(DisTabNew==NULL)
        {
            delete[] I1; delete[] I2; delete[] I3;
            delete[]  U; delete[]  I; delete[]  J;

            delete[] Link;   Link   = NULL;
            delete[] R;
            delete[] N;
            CI.AddToLog("ERROR: UCluster::InitClusteringTable(). Memory allocation in DisTabNew-array. NewM = %d  . \n", NewM);
            return U_ERROR;
        }


        DisTab[(int) floor(0.5+((double)i)*(((double)m)-(((double)i)+1.)/2.)-((double)m)+((double)j)-1.)] = -1; //Items to be removed
        for(int q=1;q<=m-2;q++)
        {
            DisTab[J[q-1]-1]=-1;
        }

        int t=1;
        for(int q=1;q<=m*(m-1)/2;q++)
        {
            if( DisTab[q-1] == -1)
            {
            }
            else
            {
                DisTabNew[t-1]=DisTab[q-1];
                t++;
            }
        }
        delete[] DisTab;
        DisTab = DisTabNew;
        m=m-1;
        N[Nobjects+s-1] = N[R[i-1]-1] + N[R[j-1]-1];
        R[i-1]   = Nobjects+s;
        for(int q=j;q<=Nobjects-1;q++)
        {
            R[q-1] = R[q+1-1];
        }
        delete [] I1;
        delete [] I2;
        delete [] I3;
        delete [] U;
        delete [] I;
        delete [] J;

    
        if(!((s+1)%20) || s==Nobjects-1)
        {
            UString Text = UString(s+1, "Linking %d") + UString(Nobjects," of %d ");
            ShowStatus((const char*) Text, s-1, Nobjects);
        }
    }
    delete[] R;
    delete[] N;

    if(LMethod == U_LINK_WARD)
        for(int q=0;q<Nobjects;q++)
            Link[q].dist =sqrt(Link[q].dist);

    delete[] DisTab; DisTab = NULL;  // This table is empty anyhow.
    return U_OK;
}

float UCluster::GetMin(const float* Vec, int Length, int* Index) const
{
    float MinAr = Vec[0];
    int   IndAr = 0;

    for(int i=1;i<Length;i++)
        if(Vec[i]<MinAr)
        {
            MinAr = Vec[i];
            IndAr = i;
        }

    if(Index) *Index = IndAr;
    return MinAr;
}


bool UCluster::CanClusterBeComputed() const
{
    if(this==NULL || Nobjects<=0 || error!=U_OK || Link==NULL) return false;
    return true;
}

const int* UCluster::ComputeClusters(int Ncluster)
/*
    Return const array Cnum[] such that Cnum[i] contains the cluster number of
    object i, for i=0,...,Nobjects-1.
 */
{
    if(this==NULL || Nobjects<=0 || error!=U_OK || Link==NULL)
    {
        CI.AddToLog("ERROR: UCluster::ComputeClusters(). Object not properly initialyzed. \n");
        return NULL;
    }
    if(Ncluster<=0||Ncluster>Nobjects)
    {
        CI.AddToLog("ERROR: UCluster::ComputeClusters(). Requested number of clusters out of range: Ncluster = %d. \n", Ncluster);
        return NULL;
    }

    delete[] Cnumb; Cnumb = new int[Nobjects];
    if(Cnumb == NULL)
    {
        CI.AddToLog("ERROR: UCluster::ComputeClusters(). Memory allocation. \n");
        return NULL;
    }
    for(int i=0;i<Nobjects;i++) Cnumb[i] = 0;
    if(Ncluster<=1) return Cnumb;  // Avoid substraction of 1

    int clsnum=1;
    for(int k=Nobjects-Ncluster+1;k<=Nobjects-1;k++)
    {
        int i=Link[k-1].ind1;
        if(i<=Nobjects)
        {
            Cnumb[i-1]=clsnum;
            clsnum++;
        }
        else
        {
            if(i<2*Nobjects-Ncluster+1)
            {
                ClusterN(clsnum,i-Nobjects);
                clsnum++;
            }
        }
        i=Link[k-1].ind2;
        if(i<=Nobjects)
        {
            Cnumb[i-1]=clsnum;
            clsnum++;
        }
        else
        {
            if(i<(2*Nobjects-Ncluster+1))
            {
                ClusterN(clsnum,i-Nobjects);
                clsnum++;
            }
        }
    }
    for(int i=0;i<Nobjects;i++) Cnumb[i] -= 1;
    return Cnumb;
}

void UCluster::ClusterN(int c, int k)
{
    int i=Link[k-1].ind1;
    if(i<=Nobjects)
    {
        Cnumb[i-1]=c;
    }
    else
    {
        ClusterN(c,i-Nobjects);
    }

    i=Link[k-1].ind2;
    if(i<=Nobjects)
    {
        Cnumb[i-1]=c;
    }
    else
    {
        ClusterN(c,i-Nobjects);
    }
}

ULinkArc* UCluster::GetLinkArcArray(bool DistanceScaled)
{
    if(this==NULL || Nobjects<=2 || error!=U_OK || Link==NULL || Link[Nobjects-2].dist<=0.)
    {
        CI.AddToLog("ERROR: UCluster::GetLinkArcArray(). Object not properly initialyzed. \n");
        return NULL;
    }
    
    ULinkArc* LAA = new ULinkArc[Nobjects];
    if(LAA==NULL)
    {
        CI.AddToLog("ERROR: UCluster::GetLinkArcArray(). Memory allocation (Nobjects = %d).\n", Nobjects);
        return NULL;
    }
    for(int k=0; k<Nobjects-1; k++)
    {
        LAA[k].Xup   = 0.;
        LAA[k].Yup   = 1.;
        LAA[k].Xtop  = 1.;
        LAA[k].Ylo   = 0.;
        LAA[k].Xlo   = 0.;
        LAA[k].IndUp = 0;
        LAA[k].IndLo = 0;
    }
    int*    LOrder = this->GetLinkOrder();
    double* XX     = new double[2*Nobjects];
    double* YY     = new double[2*Nobjects];
    if(LOrder==NULL || XX==NULL || YY==NULL)
    {
        delete[] LOrder;
        delete[] XX;
        delete[] YY;
        delete[] LAA;
        CI.AddToLog("ERROR: UCluster::GetLinkArcArray(). GetLinkOrder. \n");
        return NULL;
    }
    for(int k=0; k<2*Nobjects; k++) YY[k]=XX[k]=1;/////0;
    
    double             DistMax = Nobjects-1;
    if(DistanceScaled) DistMax = Link[Nobjects-2].dist;
    
    for(int k=0,g=Nobjects; k<Nobjects-1; k++,g++)
    {
        int i1=Link[k].ind1-1;
        int i2=Link[k].ind2-1;
        
        if(i1<Nobjects)    XX[i1] = 0;
        if(i1<Nobjects)    YY[i1] = LOrder[i1]/double(Nobjects-1);
        if(i2<Nobjects)    XX[i2] = 0;
        if(i2<Nobjects)    YY[i2] = LOrder[i2]/double(Nobjects-1);
        
        if(DistanceScaled) XX[g] = Link[k].dist / DistMax;
        else               XX[g] = (k+1.)       / DistMax;
        YY[g] = (YY[i1]+YY[i2])/2;
    }

    for(int k=0,g=Nobjects; k<Nobjects-1; k++,g++)
    {
        int i1=Link[k].ind1-1;
        int i2=Link[k].ind2-1;

        LAA[k].Xup   = XX[i1];
        LAA[k].Yup   = YY[i1];
        LAA[k].Xtop  = XX[ g];
        LAA[k].Xlo   = XX[i2];
        LAA[k].Ylo   = YY[i2];
        LAA[k].IndUp = i1;
        LAA[k].IndLo = i2;
    }
    delete[] LOrder;

    delete[] XX;
    delete[] YY;

    return LAA;
}

int* UCluster::GetLinkOrder(void)
{
    if(this==NULL || Nobjects<=0 || error!=U_OK || Link==NULL)
    {
        CI.AddToLog("ERROR: UCluster::GetLinkOrder(). Object not properly initialyzed. \n");
        return NULL;
    }
    
    int* Order = new int[Nobjects];
    if(Order==NULL)
    {
        CI.AddToLog("ERROR: UCluster::GetLinkOrder(). Memory allocation (NObjects=%d).\n", Nobjects);
        return NULL;
    }
    if(ReorderLinkage()!=U_OK)
    {
        CI.AddToLog("ERROR: UCluster::GetLinkOrder(). Ordering linkage.\n");
        delete[] Order;
        return NULL;
    }

    int  pos   = 0;
    UpdateLinkOrder(Order, pos, Nobjects-2);
    return Order;
}

ErrorType UCluster::ReorderLinkage(void)
{
    int dum = 0;
    for(int k=0; k<Nobjects-1; k++)
    {
        int i1=Link[k].ind1-1;
        int i2=Link[k].ind2-1;
        if(i1 < Nobjects && i2 < Nobjects)     
        {       
            if(i1 > i2)
            {
                dum=i1; i1=i2;i2=dum;
            }
        }
        else if(i1 < Nobjects && i2 >= Nobjects)
        {
            dum=i1; i1=i2;i2=dum;
        }
        else if(i1 >= Nobjects && i2 >= Nobjects)
        {
            if(i1 > i2)
            {
                dum=i1; i1=i2;i2=dum;
            }
        }
    }
    return U_OK;
}

void UCluster::UpdateLinkOrder(int* Order, int& pos, int row)
{
    int node = 0;

    node = Link[row].ind1-1;
    if(node >= Nobjects)   UpdateLinkOrder(Order, pos, node - Nobjects);
    if(node <  Nobjects)   Order[node] = pos++;

    node = Link[row].ind2-1;
    if(node >= Nobjects)   UpdateLinkOrder(Order, pos, node - Nobjects);
    if(node <  Nobjects)   Order[node] = pos++;
}
