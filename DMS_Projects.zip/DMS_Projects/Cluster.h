#ifndef _CLUSTER_INCLUDED
#define _CLUSTER_INCLUDED

#include "String.h"

enum LinkType
{
    U_LINK_NOTYPE,
    U_LINK_CENTROID,
    U_LINK_WARD
};


struct ULinkArc
{
    double  Xup;    // Upper line (Xup ,  Yup              ) -> (Xtop, (Yup+Ylo)/2)
    double  Yup;    // Lower line (Xtop, (Xtop, (Yup+Ylo)/2) -> (Xlo ,  Ylo       )
    double  Xtop;   
    double  Ylo;
    double  Xlo;     
    int     IndUp;  // Index upper left
    int     IndLo;  // Index lower left
};

class DLL_IO UCluster
{
public:
    UCluster(LinkType LM=U_LINK_NOTYPE);
    UCluster(const UCluster& Clus); 
    UCluster(FILE* fpIn);
    virtual ~UCluster();
    virtual UCluster& operator=(const UCluster &Clus);

    ErrorType          InitClustering(LinkType LM, const double* Dist, int Nob);
    ErrorType          GetError(void) const {return error;}
    const int*         ComputeClusters(int Ncluster);
    const UString&     GetProperties(UString Comment) const;
    bool               CanClusterBeComputed() const;
    ErrorType          WriteBinary(FILE* fpOut) const;

    ULinkArc*          GetLinkArcArray(bool DistanceScaled);

protected:
    ErrorType          InitClustering(LinkType LM=U_LINK_NOTYPE);
    void               SetAllMembersDefault(void);
    void               DeleteAllMembers(ErrorType E);

private:
    struct ULinkage
    {
        int    ind1;
        int    ind2;
        double dist;
    };

    static UString     Properties;
    static const char* HEADERBEGIN;
    static const char* HEADEREND;

    ErrorType          error;
    int                Nobjects;
    LinkType           LMethod;
    float*             DisTab;  // Distance squared table
    ULinkage*          Link;    // Link array
    int*               Cnumb;   // Cluster number of each object  

    float              GetMin(const float* Vec, int Length, int* Index) const;
    void               ClusterN(int c, int k);
    ErrorType          InitClusteringTables(void);

    ErrorType          ReorderLinkage(void);
    int*               GetLinkOrder(void);
    void               UpdateLinkOrder(int* Order, int& pos, int row);

    virtual void       ShowStatus(const char* Status, int istep, int Nstep) {if(Status==NULL || istep<0 || Nstep<=0) return;}
public:
    virtual double     GetDistance2(int i1, int i2) {if(i1<0 || i2<0) return 0.; return 0.;}
    virtual int        GetNobjects(void) const      {if(this) return Nobjects; return 0;}
};

#endif// _CLUSTER_INCLUDED
