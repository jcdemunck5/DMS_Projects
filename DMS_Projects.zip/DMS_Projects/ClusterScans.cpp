/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Object to group the non-zero points of a UScanList-object.                */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    05-04-06   creation
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    03-05-07   Copy constructor, pass argument to base class
  JdM    11-06-07   Added UFileName constructor
  JdM    26-10-07   Made HEADERBEGIN and HEADEREND static const char*
  JdM    27-05-08   BUG FIX constructor (FILE* fpIn). Use Buffer[100]
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    18-11-09   UClusterScans::UClusterScans(). Test whether SL argument is is UScanList
  JdM    06-01-10   GetAverageTimeFunctions() added argument
*/
 


#include <string.h>
#include "ClusterScans.h"
#include "ScanList.h"
#include "FieldGraph.h"

const char*  UClusterScans::HEADERBEGIN = "ClusterScan1.0";
const char*  UClusterScans::HEADEREND   = "ClusterScanEnd";

UString UClusterScans::Properties = UString();

void UClusterScans::SetAllMembersDefault()
{
    error      = U_OK;
    Properties = UString();

    ScanList   = NULL;
    TemplScan  = NULL;
    NNonZero   = 0;
    ScanPoint  = NULL;
    Icomp      = 0;
    Normalize  = false;
}
void UClusterScans::DeleteAllMembers(ErrorType E)
{
    delete   TemplScan;
    delete[] ScanPoint;
    SetAllMembersDefault();
    error  = E;
}
UClusterScans::UClusterScans()
{
    SetAllMembersDefault();
}
UClusterScans::~UClusterScans()
{
    DeleteAllMembers(U_OK);
}
UClusterScans::UClusterScans(const UClusterScans& CS) : UCluster( (const UCluster&) CS)
{
    SetAllMembersDefault();
    *this = CS;
}
UClusterScans& UClusterScans::operator=(const UClusterScans& CS)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::operator=(). this==NULL  . \n");
        static UClusterScans Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&CS==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::operator=(). Invalid NULL pointer argument \n");
        error = U_ERROR;
        return *this;
    }
    if(this==&CS) return *this;

    SetAllMembersDefault();

    UCluster::operator=(CS);
    if(UCluster::GetError() != U_OK) 
    {
        UCluster::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::operator=(). Copying base class. \n");
        return *this;
    }
    error      = CS.error;
    NNonZero   = CS.NNonZero;
    Icomp      = CS.Icomp;
    Normalize  = CS.Normalize;
    ScanList   = CS.ScanList;

    if(CS.TemplScan)
    {
        TemplScan = new UScan(*CS.TemplScan);
        if(TemplScan==NULL || TemplScan->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            UCluster::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UClusterScans::operator=(). Template Scan. \n");
            return *this;
        }
    }
    if(CS.ScanPoint)
    {
        ScanPoint = new int[NNonZero];
        if(ScanPoint==NULL)
        {
            DeleteAllMembers(U_ERROR);
            UCluster::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UClusterScans::operator=(). ScanPoint index array. \n");
            return *this;
        }
        for(int n=0; n<NNonZero; n++) ScanPoint[n] = CS.ScanPoint[n];
    }
    return *this;       
}

UClusterScans::UClusterScans(FILE* fpIn)
{
    SetAllMembersDefault();
    if(fpIn==NULL)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Invalid NULL pointer. \n");
        return;
    }
    UCluster::operator=(UCluster(fpIn));
    if(UCluster::GetError()!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Creating base class from FILE pointer. \n");
        return;
    }

/* Derived Class */ 
    size_t NHead  = strlen(HEADERBEGIN);
    char Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0 || strncmp(Buffer, HEADERBEGIN, NHead))
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Wrong header (%s) (should be %s). \n", Buffer, HEADERBEGIN);
        return;
    }
    Icomp     = ReadBinaryInt (DefaultIntelData, fpIn);
    Normalize = ReadBinaryBool(DefaultIntelData, fpIn);
    NNonZero  = ReadBinaryInt (DefaultIntelData, fpIn);
    
    if(Icomp<0 || NNonZero<=0)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Invalid parameters (Icomp=%d, NNonZero=%d). \n", Icomp, NNonZero);
        return;
    }
    ScanPoint = new int[NNonZero];
    if(ScanPoint==NULL)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Memory allocation (NNonZero=%d). \n", NNonZero);
        return;
    }
    for(int n=0; n<NNonZero; n++) ScanPoint[n] = ReadBinaryInt(DefaultIntelData, fpIn);
    TemplScan = new UScan(fpIn);
    if(TemplScan==NULL || TemplScan->GetError()!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Reading Template scan. \n");
        return;
    }
    
    char Hend[sizeof(HEADEREND)];
    NHead  = strlen(HEADEREND);
    fread(Hend,1,NHead,fpIn);
}

UClusterScans::UClusterScans(UFileName ClusteredScanFile)
{
    SetAllMembersDefault();

    FILE* fpIn = fopen(ClusteredScanFile, "rb", false);
    if(fpIn==NULL)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Cannot open file (%s). \n", (const char*)ClusteredScanFile);
        return;
    }
    *this = UClusterScans(fpIn);
    fclose(fpIn);
    if(error!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Creating object from file (%s). \n", (const char*)ClusteredScanFile);
        return;
    }
}

UClusterScans::UClusterScans(const UScanList& SL, int icomp, bool norm, LinkType LM)
{
    SetAllMembersDefault();
    if(&SL==NULL || SL.GetError()!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). UScanList argument NULL or erroneous. \n");
        return;
    }
    if(SL.IsScanList()==false)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). SL argument is not UScanList (but base-class). \n");
        return;
    }
    if(LM!=U_LINK_CENTROID && LM!=U_LINK_WARD) 
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Invalid link method (%d). \n", LM);
        return;
    }
    if(icomp<0 || icomp>=SL.GetVeclen())
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Icomp out of range (Icomp=%d). \n", Icomp);
        return;
    }
    Icomp      = icomp;
    Normalize  = norm;
    TemplScan  = new UScan((const UScan&)SL, true);
    if(TemplScan==NULL || TemplScan->GetError()!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Creating template scan . \n");
        return;
    }
    ScanList   = &SL;
    NNonZero   = SL.GetNonZeroes(Icomp, &ScanPoint);
    if(NNonZero<=0 || ScanPoint==NULL)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Getting indices for non-zero points (NNonZero=%d). \n", NNonZero);
        return;
    }
    CI.AddToLog("Note: UClusterScans::UClusterScans(). NNonZero = %d   .\n", NNonZero);
    if(UCluster::InitClustering(LM)!=U_OK)
    {
        UCluster::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UClusterScans::UClusterScans(). Initializing UCluster base class. \n");
        return;
    }
    ScanList = NULL; // Not necessary anymore (??)
}

const UString&  UClusterScans::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UClusterScans-object\n");
        return Properties;
    }
    Properties =  UString();
    Properties += UString(NNonZero, "NNonZero     = %d \n"); 
    if(TemplScan)
        Properties += UString(TemplScan->GetScanName(),"Template     = %s\n");
    else
        Properties += UString("Template     = Not Set \n");
    Properties += UString(BoolAsText(Normalize),"Normalize    = %s \n");
    Properties += UString(Icomp, "Icomp         = %d \n");
    Properties += UString("  \n");
    Properties += UString("BaseClass:  \n");
    Properties += UCluster::GetProperties(Comment+UString("  "));

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UClusterScans::WriteToFile(UFileName Fout) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(Fout, "wb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). Cannot open FILE: %s. \n", Fout);
        return U_ERROR;
    }
    if(WriteBinary(fp)!=U_OK)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). WritingBinary data  . \n");
        return U_ERROR;
    }
    fclose(fp);
    return U_OK;    
}

ErrorType UClusterScans::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NNonZero<=0 || ScanPoint==NULL || TemplScan==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). Object not properly initialized (NNonZero=%d). \n", NNonZero);
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

/* Base Class */ 
    if(UCluster::WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). Cannot write UCluster Base Class. \n");
        return U_ERROR;
    }

/* Derived Class */ 
    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)
    {
        CI.AddToLog("ERROR: UClusterScans::WriteToFile(). Cannot write Header (%s). \n", HEADERBEGIN);
        return U_ERROR;
    }

    ::WriteBinary(Icomp    , DefaultIntelData, fpOut);
    ::WriteBinary(Normalize, DefaultIntelData, fpOut);
    ::WriteBinary(NNonZero , DefaultIntelData, fpOut);
    for(int n=0; n<NNonZero; n++) ::WriteBinary(ScanPoint[n], DefaultIntelData, fpOut);
    TemplScan->WriteBinary(fpOut);
    
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UScan* UClusterScans::GetClusterScan(int NCluster) 
{
    if(this==NULL || error!=U_OK) return NULL;
    
    if(NNonZero<=0 || ScanPoint==NULL || TemplScan==NULL || TemplScan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). Object not properly initialized. \n");
        return NULL;
    }
    if(NCluster<=0 || NCluster>NNonZero)
    {
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). NCluster out of range (=%d). \n", NCluster);
        return NULL;
    }
    const int* ClusterIndex = UCluster::ComputeClusters(NCluster);
    if(ClusterIndex==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). Computing cluster indices. \n");
        return NULL;
    }

    UScan* ScanClust = new UScan(*TemplScan);
    if(ScanClust==NULL || ScanClust->GetError()!=U_OK)
    {
        delete ScanClust;
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). Copying template. \n");
        return NULL;
    }
    int  Npoints     = ScanClust->GetNpoints();
    int* ClusterData = new int[Npoints];
    if(ClusterData==NULL)
    {
        delete[] ClusterData;
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). Memory allocation, Npoints = %d. \n", Npoints);
        return NULL;
    }

/* Set cluster data */    
    for(int k=0; k<Npoints;  k++) ClusterData[k] = -1; // Background
    for(int n=0; n<NNonZero; n++) ClusterData[ScanPoint[n]] = ClusterIndex[n];

/* Copy to scan */    
    if(ScanClust->SetData(ClusterData, 1)!=U_OK)
    {
        delete   ScanClust;
        delete[] ClusterData;
        CI.AddToLog("ERROR: UClusterScans::GetClusterScan(). Copying data to output. \n");
        return NULL;
    }
    delete[] ClusterData;

    ScanClust->SetScanName(UString(NCluster, "Cluster_%d"));
    return ScanClust;
}

UFieldGraph** UClusterScans::GetAverageTimeFunctions(const UScanList& SL, int NCluster, int* NpClust)
{
    if(this==NULL || error!=U_OK) return NULL;
    if(NNonZero<=0 || ScanPoint==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::GetAverageTimeFunctions(). Object not properly initialized. \n");
        return NULL;
    }

    if(&SL==NULL || SL.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::GetAverageTimeFunctions(). UScanList argument NULL or erroneous. \n");
        return NULL;
    }
    if(NCluster<=0 || NCluster>NNonZero)
    {
        CI.AddToLog("ERROR: UClusterScans::GetAverageTimeFunctions(). NCluster out ot range (=%d). \n", NCluster);
        return NULL;
    }
    const int* ClusterIndex = UCluster::ComputeClusters(NCluster);
    if(ClusterIndex==NULL)
    {
        CI.AddToLog("ERROR: UClusterScans::GetAverageTimeFunctions(). Computing cluster indices. \n");
        return NULL;
    }

    UFieldGraph** FGArr = new UFieldGraph*[NCluster];
    int*          Np    = new int[NCluster];
    if(FGArr && Np)
    {
        for(int ic=0; ic<NCluster; ic++) FGArr[ic] = NULL;
        for(int ic=0; ic<NCluster; ic++)
        {
            Np   [ic] = 0;
            FGArr[ic] = SL.GetTimeSeriesFieldGraph(0, -1, false);
            if(FGArr[ic]==NULL || FGArr[ic]->GetError()!=U_OK)
            {
                for(int ic2=0; ic2<NCluster; ic2++) delete FGArr[ic2];
                delete[] FGArr; FGArr=NULL;
                break;
            }
            FGArr[ic]->SetDataDouble(0.);
        }
    }
    if(FGArr==NULL || Np==NULL)
    {
        delete[] FGArr;
        delete[] Np;
        CI.AddToLog("ERROR: UClusterScans::GetAverageTimeFunctions(). Creating default array of UFieldGraph. \n");
        return NULL;
    }
    for(int n=0; n<NNonZero; n++)
    {
        int k         = ScanPoint[n];
        int ic        = ClusterIndex[n];
        *(FGArr[ic]) += *(SL.GetTimeSeriesFieldGraph(k, -1, false));
        Np[ic]++;

        if(Np[ic]==1) FGArr[ic]->SetPoint(SL.GetPoint(k));
    }
    for(int ic=0; ic<NCluster; ic++)
    {
        if(Np[ic] ) (*FGArr[ic]) *= 1./Np[ic];
        if(NpClust)  NpClust[ic] = Np[ic];
        FGArr[ic]->SetLabel(UString(ic,"Clus_%d") + UString(Np[ic],"_%d"));
    }
    delete[] Np;
    return FGArr;
}

double UClusterScans::GetDistance2(int i1, int i2)
{
    if(NNonZero<=0 || ScanPoint==NULL || ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterScans::GetDistance2(). Object not properly initialized. \n");
        return 0.;
    }
    if(i1<0 || i1>=NNonZero ||
       i2<0 || i2>=NNonZero)
    {
        CI.AddToLog("ERROR: UClusterScans::GetDistance2(). Indices out of range: i1=%d and i2=%d  . \n", i1,i2);
        return 0.;
    }

    double* Series1 = ScanList->GetTimeSeries(ScanPoint[i1], Icomp);
    double* Series2 = ScanList->GetTimeSeries(ScanPoint[i2], Icomp);

    if(Series1==NULL || Series2==NULL)
    {
        delete[] Series1;
        delete[] Series2;
        CI.AddToLog("ERROR: UClusterScans::GetDistance2(). Getting time series at points  i1=%d or i2=%d  . \n", i1,i2);
        return 0.;
    }
    int Nscan = ScanList->GetNscan();
    if(Normalize==true)
    {
        double Norm1 = 0;
        for(int j=0; j<Nscan; j++) Norm1 += Series1[j]*Series1[j];
        if(Norm1>0)
        {
            Norm1 = sqrt(Norm1);
            for(int j=0; j<Nscan; j++) Series1[j] /= Norm1;
        }
        double Norm2 = 0;
        for(int j=0; j<Nscan; j++) Norm2 += Series2[j]*Series2[j];
        if(Norm2>0)
        {
            Norm2 = sqrt(Norm2);
            for(int j=0; j<Nscan; j++) Series2[j] /= Norm2;
        }
    }
    
    double Dis = 0.;
    for(int j=0; j<Nscan; j++) Dis += (Series1[j]-Series2[j])*(Series1[j]-Series2[j]);

    delete[] Series1;
    delete[] Series2;
    
    return Dis;
}
int UClusterScans::GetNobjects(void) const
{
    return NNonZero;
}
