#ifndef _CLUSTERSCANS_INCLUDED
#define _CLUSTERSCANS_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Cluster.h"
#include "String.h"
#include "FileName.h"

class UScan;
class UScanList;
class UFieldGraph;
class UBitMap;

class DLL_IO UClusterScans : private UCluster
{
public:
    UClusterScans();
    UClusterScans(UFileName ClusteredScanFile);
    UClusterScans(FILE* fpIn);
    UClusterScans(const UClusterScans& CS);
    UClusterScans(const UScanList& SL, int icomp, bool Norm, LinkType LM=U_LINK_NOTYPE);
    ~UClusterScans();  

    UClusterScans&          operator=(const UClusterScans& CS);

    ErrorType               GetError(void) const {return error;}
    virtual const UString&  GetProperties(UString Comment) const;
    int                     GetIcomp(void) const {return Icomp;}
    bool                    GetNormalize(void) const {return Normalize;}

    const UScan*            GetTemplateScan(void) const {return TemplScan;}
    UScan*                  GetClusterScan(int NCluster);
    UFieldGraph**           GetAverageTimeFunctions(const UScanList& SL, int NCluster, int* NpClust=NULL);
    ErrorType               WriteToFile(UFileName Fout) const;
    ErrorType               WriteBinary(FILE* fpOut) const;

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    static UString          Properties;
    static const char*      HEADERBEGIN;
    static const char*      HEADEREND;
    ErrorType               error;            // General error flag

    UScan*                  TemplScan;        // Template scan, no data
    int                     NNonZero;         // Number of points with non-zero data
    int*                    ScanPoint;        // returns the index of each non-zero data point

/* "Temporary" parameters only used in UClusterScans::GetDistance2() (and in GetProperties()) */
    const UScanList*        ScanList;         // Temporary pointer to UScanList-object
    int                     Icomp;            // Component of ScanList, used to define distances
    bool                    Normalize;

    virtual double          GetDistance2(int i1, int i2);
    virtual int             GetNobjects(void) const;
};

#endif //_CLUSTERSCANS_INCLUDED


