/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for keeping track of all coding parameters in a dipole fit on      */
/*     coded data. Derived from UDipoleManager                                   */
/*                                                                               */
/*                                                                               */
/*     Fetsje Bijma                                                              */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  FB     14-11-02   creation
  FB     07-03-03   Added members BoolCodeMat, BoolDerCodmat and CodeType U_SIMULATIONCODE,
                    and reorganized function SetCodeParameters()
  JdM    10-03-05   Disable language extensions (for-loops) for compatability with Linux C++
  FB     22-03-05   Disable language extensions (for-loops) for compatability with Linux C++
  FB     28-04-05   Added SetCoupleDesign() for setting Coupled Design with boolean array
  JdM    20-11-07   Changed order of include files for OpenWatcom compatibility (system includes first)
  JdM    20-05-11   Use UString for GetProperties()
  AMW    23-11-12   Assure compatibility with gcc4.7: PrintCodeMat(). Use .GetString() to convert UString to const char*
*/

#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "CodeManager.h"

/* Inititalize static const parameters. */
UString      UCodeManager::Properties           = UString();

UCodeManager::UCodeManager() : UDipoleManager()
{
    CdT            = U_NOCODING;
    nCodes         = 0;
    nCodePars      = 0;
    nBasicSTF      = 0;

    CodePars       = NULL;
    nTrialsPerCode = NULL;
    CodeMat        = NULL;
    DerCodMat      = NULL;
    BoolCodeMat    = NULL;
    BoolDerCodMat  = NULL;
    CodeNames      = NULL;
    IsDipInCode    = NULL;
    IsSTFInCode    = NULL;
    Properties     = UString();
    error          = UDipoleManager::GetError();
}

UCodeManager::UCodeManager(const UDipoleFix* DipoleArray, int Ndipoles, const double* const* pWDerivField, int Nsensors):
              UDipoleManager(DipoleArray, Ndipoles, pWDerivField, Nsensors)
{
    CdT            = U_NOCODING;
    nCodes         = 0;
    nCodePars      = 0;
    nBasicSTF      = 0;

    CodePars       = NULL;
    nTrialsPerCode = NULL;
    CodeMat        = NULL;
    DerCodMat      = NULL;
    BoolCodeMat    = NULL;
    BoolDerCodMat  = NULL;
    CodeNames      = NULL;
    IsDipInCode    = NULL;
    IsSTFInCode    = NULL;
    Properties     = UString();
    error          = UDipoleManager::GetError();
}

UCodeManager::UCodeManager(const UDipole* DipoleArray, int Ndipoles, bool AllRotating, const double* const* pWDerivField, int Nsensors):
    UDipoleManager(DipoleArray, Ndipoles, AllRotating, pWDerivField, Nsensors)
{
    CdT            = U_NOCODING;
    nCodes         = 0;
    nCodePars      = 0;
    nBasicSTF      = 0;

    CodePars       = NULL;
    nTrialsPerCode = NULL;
    CodeMat        = NULL;
    DerCodMat      = NULL;
    BoolCodeMat    = NULL;
    BoolDerCodMat  = NULL;
    CodeNames      = NULL;
    IsDipInCode    = NULL;
    IsSTFInCode    = NULL;
    Properties     = UString();
    error          = UDipoleManager::GetError();
}

UCodeManager::UCodeManager(const UDipoleManager& DM) : UDipoleManager()
{
    CdT            = U_NOCODING;
    nCodes         = 0;
    nCodePars      = 0;
    nBasicSTF      = 0;

    CodePars       = NULL;
    nTrialsPerCode = NULL;
    CodeMat        = NULL;
    DerCodMat      = NULL;
    BoolCodeMat    = NULL;
    BoolDerCodMat  = NULL;
    CodeNames      = NULL;
    IsDipInCode    = NULL;
    IsSTFInCode    = NULL;
    Properties     = UString();

    error          = UDipoleManager::GetError();
    *this          = DM;
}


UCodeManager::~UCodeManager()
{
    DeleteCodeMembers();
}

UCodeManager& UCodeManager::operator=(const UCodeManager& CM)
{
    if(&CM==NULL)
    {
        CI.AddToLog("ERROR: UCodeManager::operator=(). NULL address  . \n");
        return *this;
    }
    if(this==&CM) return *this;

    UDipoleManager::operator=(CM);
    DeleteCodeMembers();

    CdT       = CM.CdT;
    nCodes    = CM.nCodes;
    nCodePars = CM.nCodePars;
    nBasicSTF = CM.nBasicSTF;
    error     = CM.error;

    if(CM.DerCodMat)
    {
        DerCodMat = new double**[nCodes];
        for(int q=0;q<nCodes;q++)
        {
            if(CM.DerCodMat[q])
            {
                DerCodMat[q] = new double*[nCodePars];
                for(int y=0;y<nCodePars;y++)
                    if(CM.DerCodMat[q][y])
                        DerCodMat[q][y] = new double[NSourceTimeFunc*nBasicSTF];
            }
        }
    }

    if(CM.BoolDerCodMat)
    {
        BoolDerCodMat = new bool**[nCodes];
        for(int q=0;q<nCodes;q++)
        {
            if(CM.BoolDerCodMat[q])
            {
                BoolDerCodMat[q] = new bool*[nCodePars];
                for(int y=0;y<nCodePars;y++)
                    if(CM.BoolDerCodMat[q][y])
                        BoolDerCodMat[q][y] = new bool[NSourceTimeFunc*nBasicSTF];
            }
        }
    }

    if(CM.CodeMat)
    {
        CodeMat = new double*[nCodes];
        for(int q=0;q<nCodes;q++)
            if(CM.CodeMat[q])
                CodeMat[q] = new double[NSourceTimeFunc*nBasicSTF];
    }
    if(CM.BoolCodeMat)
    {
        BoolCodeMat = new bool*[nCodes];
        for(int q=0;q<nCodes;q++)
            if(CM.BoolCodeMat[q])
                BoolCodeMat[q] = new bool[NSourceTimeFunc*nBasicSTF];
    }

    if(CM.CodePars)        CodePars       = new double[nCodePars];
    if(CM.nTrialsPerCode)  nTrialsPerCode = new int[nCodes];
    if(CM.CodeNames)       CodeNames      = new UString[nCodes];
    if(CM.IsDipInCode)
    {
        IsDipInCode = new bool*[Ndip];
        for(int p=0; p<Ndip; p++)
            if(CM.IsDipInCode[p])
                IsDipInCode[p] = new bool[nCodes];
    }
    if(CM.IsSTFInCode)
    {
        IsSTFInCode = new bool*[NSourceTimeFunc];
        for(int p=0; p<NSourceTimeFunc; p++)
            if(CM.IsSTFInCode[p])
                IsSTFInCode[p] = new bool[nCodes];
    }
    if( (!DerCodMat      && CM.DerCodMat     ) ||
        (!CodeMat        && CM.CodeMat       ) ||
        (!CodePars       && CM.CodePars      ) ||
        (!nTrialsPerCode && CM.nTrialsPerCode) ||
        (!CodeNames      && CM.CodeNames     ) ||
        (!IsDipInCode    && CM.IsDipInCode   ) ||
        (!IsSTFInCode    && CM.IsSTFInCode   ) ||
        (!Properties     && CM.Properties    ) )
    {
        error = U_ERROR;
        CI.AddToLog("UCodeManager: Operator= Memory Allocation error.");
    }
    else
    {
        int q=0;
        for(   ;q<nCodes;q++)
        {
            nTrialsPerCode[q]=CM.nTrialsPerCode[q];
            CodeNames[q]=CM.CodeNames[q];
            for(int z=0;z<nBasicSTF;z++)
                for(int p=0;p<NSourceTimeFunc;p++)
                {
                    CodeMat[q][p*nBasicSTF+p]=CM.CodeMat[q][p*nBasicSTF+p];
                    BoolCodeMat[q][p*nBasicSTF+p]=CM.BoolCodeMat[q][p*nBasicSTF+p];
                    for(int y=0;y<nCodePars;y++)
                    {
                        DerCodMat[q][y][p*nBasicSTF+p]=CM.DerCodMat[q][y][p*nBasicSTF+p];
                        BoolDerCodMat[q][y][p*nBasicSTF+p]=CM.BoolDerCodMat[q][y][p*nBasicSTF+p];
                    }
                }
        }
        for(int y=0;y<nCodePars;y++)
            CodePars[y]=CM.CodePars[y];
        for(q=0;q<nCodes;q++)
        {
            int p=0;
            for(   ; p<Ndip; p++)
                IsDipInCode[p][q] = CM.IsDipInCode[p][q];
            for(p=0; p<NSourceTimeFunc; p++)
                IsSTFInCode[p][q] = CM.IsSTFInCode[p][q];
        }
    }
    return *this;
}

UCodeManager& UCodeManager::operator=(const UDipoleManager& DM)
{
    if(&DM==NULL)
    {
        CI.AddToLog("ERROR: UCodeManager::operator=(). NULL address  . \n");
        return *this;
    }
    if(this==&DM) return *this;

    UDipoleManager::operator=(DM);
    error = DM.GetError();

    DeleteCodeMembers();

    Properties     = UString();

    CdT            = U_NOCODING;
    nCodes         = 0;
    nCodePars      = 0;
    nBasicSTF      = 0;

    CodePars       = NULL;
    nTrialsPerCode = NULL;
    CodeMat        = NULL;
    DerCodMat      = NULL;
    BoolCodeMat    = NULL;
    BoolDerCodMat  = NULL;
    CodeNames      = NULL;
    IsDipInCode    = NULL;

    return *this;
}

UString& UCodeManager::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = "ERROR: UCodeManager::GetProperties(): MEMORY .\n";
        return Properties;
    }
    Properties = UString("The coding parameters:\n");

    switch(CdT)
    {
    case U_NOCODING:
        Properties += UString(" CodeType = UNKNOWN \n");
        break;
    case U_KBHF:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, two single dipoles, one Basic STF, one InterAction STF \n");
        break;
    case U_KBHFSYMM:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, one semi-symmetric dipole, one Basic STF, one InterAction STF \n");
        break;
    case U_KBHFREST:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, one semi-symmetric dipole, one UniLat STF, one BiLat STF \n");
        break;
    case U_KBHFFREE:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, two single dipoles, one UniLat STF, one BiLat STF \n");
        break;
    case U_KBHFUPGRADE:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, two single dipoles, ContraLat STF and IpsiLat STF \n");
        break;
    case U_KBHFUPGRADEREST:
        Properties += UString(" CodeType = KB visual data High Spatial Frequency, one semi-symmetric dipole, ContraLat STF and IpsiLat STF  \n");
        break;
    case U_KBUNILEFT:
        Properties += UString(" CodeType = KB visual data UniLateral Left, all Spatial Frequencies, two single dipoles, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBUNIRIGHT:
        Properties += UString(" CodeType = KB visual data UniLateral Right, all Spatial Frequencies, two single dipoles, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBUNILEFTREST:
        Properties += UString(" CodeType = KB visual data UniLateral Left, all Spatial Frequencies, two single dipoles, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate \n");
        break;
    case U_KBUNIRIGHTREST:
        Properties += UString(" CodeType = KB visual data UniLateral Right, all Spatial Frequencies, two single dipoles, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLUNILAT:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, UniLeft and UniRight, four single dipoles; HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLUNILATSYMM:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, UniLeft and UniRight, two semi-symmetric dipoles; HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLUNILATSYMMREST:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, UniLeft and UniRight, two semi-symmetric dipoles; HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLCODES:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, All lateralizations, four single dipoles, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLCODESSYMM:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, All lateralizations, two semi-symmetric dipoles, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate \n");
        break;
    case U_KBALLCODESSYMMREST:
        Properties += UString(" CodeType = KB visual data All Spatial Frequencies, All lateralizations, two semi-symmetric dipoles, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate \n");
        break;
    }

    Properties = UString("Base Class:\n");
    Properties += UDipoleManager::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}


ErrorType UCodeManager::SetCodePars(double* CodPars)
{
    if(CodPars==NULL)
    {
        CI.AddToLog("UCodeManager::SetCodePars(). Invalid Argument.\n");
        return U_ERROR;
    }

    delete CodePars;
    CodePars = new double[nCodePars];
    for (int y=0;y<nCodePars;y++)
        CodePars[y]=CodPars[y];

    UpdateCodeMat();
    return U_OK;
}


ErrorType UCodeManager::SetNTrialsPerCode(int* ntrialspercode)
{
    if(ntrialspercode ==NULL)
    {
        CI.AddToLog("UCodeManager::SetNTrialsPerCode(). Invalid Argument.\n");
        return U_ERROR;
    }
    delete nTrialsPerCode;
    nTrialsPerCode = new int[nCodes];
    for (int q=0;q<nCodes;q++)
        nTrialsPerCode[q]=ntrialspercode[q];

    return U_OK;
}

ErrorType UCodeManager::ScaleCodeMatWithTrials(int* nTrialsPerCode)
/*
   Scales the entries of DerCodMat with the sqrt of
   the number of trials for each code.
*/
{
    if(nTrialsPerCode==NULL)
    {
        CI.AddToLog("UCodeManager::ScaleCodeMatWithTrials(). Invalid Argument.\n");
        return U_ERROR;
    }

    for(int q=0;q<nCodes;q++)
        for(int y=0;y<nCodePars;y++)
            for(int p=0;p<NSourceTimeFunc;p++)
                for(int z=0;z<nBasicSTF;z++)
                {
                    DerCodMat[q][y][p*nBasicSTF+z]*=sqrt((double)nTrialsPerCode[q]);
                    if(DerCodMat[q][y][p*nBasicSTF+z]!=0.)
                        BoolDerCodMat[q][y][p*nBasicSTF+z]= true;
                    else
                        BoolDerCodMat[q][y][p*nBasicSTF+z]= false;
                }

    UpdateCodeMat();
    return U_OK;
}


void UCodeManager::UpdateCodeMat(void) const
/* This routine updates CodeMat and BoolCodeMat using the CodePars and DerCodMat array.
*/
{
    for(int q=0;q<nCodes;q++)
        for(int p=0;p<NSourceTimeFunc;p++)
            for(int z=0;z<nBasicSTF;z++)
            {
                CodeMat[q][p*nBasicSTF+z]=0.;
                for(int y=0;y<nCodePars;y++)
                    if(BoolDerCodMat[q][y][p*nBasicSTF+z])
                        CodeMat[q][p*nBasicSTF+z]+=CodePars[y]*DerCodMat[q][y][p*nBasicSTF+z];
                if(CodeMat[q][p*nBasicSTF+z]!=0.)
                    BoolCodeMat[q][p*nBasicSTF+z]=true;
                else
                    BoolCodeMat[q][p*nBasicSTF+z]=false;
            }
    return;
}

void UCodeManager::UpdateIsDipSTFInCode()
/* This routine updates the IsDipInCode and the IsSTFInCode array, according
   to the non zero entries in CodeMat, keeping track of which dipoles and STFs
   are active in each code.
*/
{
    if(IsDipInCode)
        for(int p=0; p<Ndip; p++)
            if(IsDipInCode[p])
                delete[] IsDipInCode[p];
    delete[] IsDipInCode; IsDipInCode = NULL;

    if(IsSTFInCode)
        for(int p=0; p<NSourceTimeFunc; p++)
            if(IsSTFInCode[p])
                delete[] IsSTFInCode[p];
    delete[] IsSTFInCode; IsSTFInCode = NULL;

    if(nCodes==0 || Ndip <=0 || NSourceTimeFunc <=0)
    {
        CI.AddToLog("ERROR: UCodeManager::UpdateIsDipSTFInCode(). Object to properly initialized.\n");
        return; // at return IsDipInCode and IsSTFInCode are NULL pointers
    }

    IsDipInCode = new bool*[Ndip];
    int p=0;
    for(p=0; p<Ndip; p++)
        IsDipInCode[p] = new bool[nCodes];
    IsSTFInCode = new bool*[NSourceTimeFunc];
    for(p=0; p<NSourceTimeFunc; p++)
        IsSTFInCode[p] = new bool[nCodes];

    int STFindex=0;
    for(p=0; p<Ndip; p++)
    {
        int nSTFofDip = GetNfreeSTF(p);
        for(int q=0; q<nCodes; q++)
        {
            bool founddip = false;
            for(int pp=0;pp<nSTFofDip;pp++)
            {
                bool foundstf = false;
                for(int z=0;z<nBasicSTF;z++)
                {
                    if(BoolCodeMat[q][(STFindex+pp)*nBasicSTF+z])
                    {
                        foundstf = true;
                        founddip = true;
                        break;
                    }
                }
                IsSTFInCode[STFindex+pp][q] = foundstf;
            }
            IsDipInCode[p][q]= founddip;
        }
        STFindex += nSTFofDip;
    }
}

void UCodeManager::InvertFreeSTF(int istf)
{
    if(istf<0 || istf>=NSourceTimeFunc)
        return;
    for (int q=0;q<nCodes;q++)
        for (int y=0;y<nCodePars;y++)
            for(int z=0;z<nBasicSTF;z++)
                DerCodMat[q][y][istf*nBasicSTF+z]*=-1;
    UpdateCodeMat();
    return;
}

void UCodeManager::InvertBasicSTF(int istf)
{
    if(istf<0 || istf>=nBasicSTF)
        return;
    for (int q=0;q<nCodes;q++)
        for (int y=0;y<nCodePars;y++)
            for(int p=0;p<NSourceTimeFunc;p++)
                DerCodMat[q][y][p*nBasicSTF+istf]*=-1;
    UpdateCodeMat();
    return;
}

ErrorType UCodeManager::SwapDipCodeMatOnly(void)
/*
This routine swaps entries in CodeMat corresponding to the two dipoles.
The DerCodMat is left unchanged, so the rest of the UCodeManager object is
basically not changed.
This routine should be used WITH CARE, because after this routine DerCodMat
and CodeMat do not correspond.
However is it alright to use this after ComputeDipoles() in order to minimize
the position errors of the fitted dipoles
*/
{
    if(Ndip!=2)
        return U_ERROR;
    else
    {
        UDipoleFix dum;
        dum       = DipArr[0];
        DipArr[0] = DipArr[1];
        DipArr[1] = dum;

        int free0 = GetNfreeSTF(0);
        int free1 = GetNfreeSTF(1);
        if(free0+free1 != NSourceTimeFunc)
            return U_ERROR;

        double* dumm = new double[free0+free1];

        for(int q=0; q<nCodes;q++)
            for(int z=0; z<nBasicSTF; z++)
            {
                int p=0;
                for(p=0;p<free0+free1;p++)
                    dumm[p]=CodeMat[q][p*nBasicSTF+z];
                for(p=0;p<free1;p++)
                    CodeMat[q][p*nBasicSTF+z] = dumm[free1+p];
                for(p=0;p<free0;p++)
                    CodeMat[q][(p+free1)*nBasicSTF+z] = dumm[p];
            }

        delete[] dumm;
        return U_OK;
    }
}

void UCodeManager::DeleteCodeMembers()
{
    if(DerCodMat)
        for(int q=0;q<nCodes;q++)
        {
            if(DerCodMat[q])
                for(int y=0; y<nCodePars;y++)
                    delete[] DerCodMat[q][y];
            delete[] DerCodMat[q];
        }
    delete[] DerCodMat;       DerCodMat =     NULL;
    if(BoolDerCodMat)
        for(int q=0;q<nCodes;q++)
        {
            if(BoolDerCodMat[q])
                for(int y=0; y<nCodePars;y++)
                    delete[] BoolDerCodMat[q][y];
            delete[] BoolDerCodMat[q];
        }
    delete[] BoolDerCodMat;   BoolDerCodMat=  NULL;
    if(CodeMat)
        for(int q=0;q<nCodes;q++)
            delete[] CodeMat[q];
    delete[] CodeMat;         CodeMat=        NULL;
    if(BoolCodeMat)
        for(int q=0;q<nCodes;q++)
            delete[] BoolCodeMat[q];
    delete[] BoolCodeMat;     BoolCodeMat=    NULL;
    delete[] CodeNames;       CodeNames=      NULL;
    if(IsDipInCode)
        for(int p=0; p<Ndip; p++)
            delete[] IsDipInCode[p];
    delete[] IsDipInCode;     IsDipInCode=    NULL;
    if(IsSTFInCode)
        for(int p=0; p<NSourceTimeFunc; p++)
            delete[] IsSTFInCode[p];
    delete[] IsSTFInCode;     IsSTFInCode=    NULL;
    delete[] CodePars;        CodePars=       NULL;
    delete[] nTrialsPerCode;  nTrialsPerCode= NULL;
}

UString UCodeManager::GetCodeName(int q) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCodeManager::GetCodeName() Object NULL or erroneous.\n");
        return UString();
    }
    if(q<0 || q>nCodes)
    {
        CI.AddToLog("ERROR: UCodeManager::GetCodeName() Invalid Argument.\n");
        return UString();
    }
    return CodeNames[q];
}


int UCodeManager::GetNCodesInDipole(int p) const
/*
   Returns the number of codes which have dipole as active dipole
*/
{
    int N=0;
    for (int q=0;q<nCodes;q++)
        if(IsDipInCode[p][q])
            N++;

    return N;
}

int UCodeManager::GetNDipolesInCode(int q) const
/*
   Returns the number of dipoles active in code q
*/
{
    int N=0;
    for (int p=0;p<Ndip;p++)
        if(IsDipInCode[p][q])
            N++;

    return N;
}


ErrorType UCodeManager::GetCodeInDipIndex(int p, int* index) const
/*
   On return index contains all code indices q of codes which have dipole p as active dipole
*/
{
    int actcod=0;
    for(int q=0; q<nCodes; q++)
        if(IsDipInCode[p][q])
        {
            index[actcod]=q;
            actcod++;
        }
    if(actcod!=GetNCodesInDipole(p))
        return U_ERROR;
    return U_OK;
}

ErrorType UCodeManager::GetDipInCodeIndex(int q, int* index) const
/*
   On return index contains the indices p of all active dipoles in code q
*/
{
    int actdip=0;
    for(int p=0; p<Ndip; p++)
        if(IsDipInCode[p][q])
        {
            index[actdip]=p;
            actdip++;
        }
    if(actdip!=GetNDipolesInCode(q))
        return U_ERROR;
    return U_OK;
}

ErrorType UCodeManager::ComputeCodeOutput(int q, int& nDipInCode, int* DipInCodeIndex, double* BasicSTF, double* CodeSTF, int nSamples) const
/*
   On return:
   nDipInCode equals the number of active dipoles in code q
   DipInCodeIndex contains the indices of the active dipoles in code q
   CodeSTF contains the STFs used in code q (sample as fast index)
   CodeSTF should be allocated before
*/
{
    if(q<0 || q>=nCodes || DipInCodeIndex == NULL || BasicSTF==NULL || CodeSTF==NULL || nSamples <=0)
    {
        CI.AddToLog("ERROR: UCodeManager::ComputeCodeOutput : Invalid Argument.\n");
        return U_ERROR;
    }

    int nActDip      = 0;
    int STFindex     = 0;
    int CodeSTFindex = 0;
    for (int p=0;p<Ndip;p++)
    {
        if(IsDipInCode[p][q])
        {
            DipInCodeIndex[nActDip]=p;
            nActDip++;
            for(int z=0;z<this->GetNfreeSTF(p);z++)
            {
                if(IsSTFInCode[STFindex][q]==true)
                {
                    for(int j=0;j<nSamples;j++)
                    {
                        CodeSTF[CodeSTFindex*nSamples+j]=0;
                        for(int z=0;z<nBasicSTF;z++)
                            if(BoolCodeMat[q][STFindex*nBasicSTF+z])
                                CodeSTF[CodeSTFindex*nSamples+j]+=CodeMat[q][STFindex*nBasicSTF+z]*BasicSTF[z*nSamples+j]/sqrt((double)nTrialsPerCode[q]);
                    }
                }
                else
                    for(int j=0;j<nSamples;j++)
                        CodeSTF[CodeSTFindex*nSamples+j]=0;
                CodeSTFindex++;
                STFindex++;
            }
        }
        else
            STFindex+=GetNfreeSTF(p);
    }
    nDipInCode = nActDip;
    return U_OK;
}


double UCodeManager::GetCodeNormalizer() const
{
    double sign    = 0.;
    int    biggpar = 0;
    for(int y=0;y<nCodePars;y++)
    {
        if(fabs(CodePars[y])>0)
            sign += CodePars[y]/fabs(CodePars[y]);
        if(fabs(CodePars[y])>fabs(CodePars[biggpar]))
            biggpar = y;
    }
    if(sign!=0)
        sign/=fabs(sign); // now sign is +1 or -1, indicating to most frequent sign in CodePars
    else
        sign =1.;

    if(fabs(CodePars[biggpar])==0)
        return 0.;
    else
        return CodePars[biggpar]*sign;
}


void UCodeManager::PrintCodeMat(UFileName FileNameOut,int q,bool Norm) const
{
    FILE* fpOut = NULL;
    fpOut = fopen(FileNameOut,"at", true);
    bool error = false;

    if(Norm==true)
    {
        double norm = GetCodeNormalizer();
        if(fabs(norm) == 0.)
            error=true; // print unnormalized codemat
        else
        {
            fprintf(fpOut,"CodeMatrix %d for Code %s (normalized by %f)\n",q,CodeNames[q].GetString(),norm);
            for(int p=0;p<NSourceTimeFunc;p++)
            {
                for(int z=0;z<nBasicSTF;z++)
                    fprintf(fpOut,"%f\t",CodeMat[q][p*nBasicSTF+z]/(norm*sqrt((double)nTrialsPerCode[q])));
                fprintf(fpOut,"\n");
            }
            fprintf(fpOut,"\n");
        }
    }
    if(Norm==false||error)
    {
        fprintf(fpOut,"CodeMatrix %d for Code %s (unnormalized)\n",q,CodeNames[q].GetString());
        for(int p=0;p<NSourceTimeFunc;p++)
        {
            for(int z=0;z<nBasicSTF;z++)
                fprintf(fpOut,"%f\t",CodeMat[q][p*nBasicSTF+z]/sqrt((double)nTrialsPerCode[q]));
            fprintf(fpOut,"\n");
        }
        fprintf(fpOut,"\n");
    }
    fclose(fpOut);
    return;
}


void UCodeManager::PrintCodePars(UFileName FileNameOut,bool Norm) const
{
    FILE* fpOut = NULL;
    fpOut = fopen(FileNameOut,"at", true);
    bool error = false;

    if(Norm==true)
    {
        double norm = GetCodeNormalizer();
        if(fabs(norm) == 0.)
            error=true; // print unnormalized codemat
        else
        {
            fprintf(fpOut,"CodePars (normalized by %f): \n",norm);
            for(int y=0;y<nCodePars;y++)
                fprintf(fpOut,"%f\t",CodePars[y]/norm);
            fprintf(fpOut,"\n\n");
        }
    }
    if(Norm==false||error)
    {
        fprintf(fpOut,"CodePars(unnormalized): \n");
        for(int y=0;y<nCodePars;y++)
            fprintf(fpOut,"%f\t",CodePars[y]);
        fprintf(fpOut,"\n\n");
    }
    fclose(fpOut);
    return;
}


ErrorType UCodeManager::SetCodeParameters(CodeType CodT)
// Set the Code parameters to one of the predefined codings
/*
CodT = U_KBHF:
           KB High Spatial Frequency data,

           The first source corresponds to: UniLeft, (Right Hemisphere Source)

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3
                        0 0                        0 0
           CodeMat[1] = 0 0     DerCodeMat[1][1] = 0 0 DerCodeMat[1][y]=0 for y=0,2,3
                        b 0                        1 0
           CodeMat[2] = a c     DerCodeMat[2][0] = 1 0 DerCodeMat[2][1] = 0 0 DerCodeMat[2][2] = 0 1 DerCodeMat[2][3] = 0 0
                        b d                        0 0                    1 0                    0 0                    0 1
           CodePars   = [a,b,c,d]
CodT = U_KBHFREST:
           KB High Spatial Frequency data,

           One semi-symmetric source, UniLat STF and BiLat STF

           CodeMat[0] = 0 0     DerCodeMat[0][0] = 0 0 DerCodeMat[0][y]=0 for y=1,2,3
                        a 0                        1 0
           CodeMat[1] = b 0     DerCodeMat[1][1] = 1 0 DerCodeMat[1][y]=0 for y=0,2,3
                        0 0                        0 0
           CodeMat[2] = 0 d     DerCodeMat[2][2] = 0 0 DerCodeMat[2][3] = 0 1
                        0 c                        0 1                    0 0
           CodePars   = [a,b,c,d]
CodT = U_KBHFFREE:
           KB High Spatial Frequency data

           two single sources, UniLat STF and BiLat STF

           CodeMat[0] = 0 0     DerCodeMat[0][0] = 0 0 DerCodeMat[0][y]=0 for y=1,2,3
                        a 0                        1 0
           CodeMat[1] = b 0     DerCodeMat[1][1] = 1 0 DerCodeMat[1][y]=0 for y=0,2,3
                        0 0                        0 0
           CodeMat[2] = 0 d     DerCodeMat[2][2] = 0 0 DerCodeMat[2][3] = 0 1
                        0 c                        0 1                    0 0
           CodePars   = [a,b,c,d]
CodT = U_KBHFUPGRADE:
           KB High Spatial Frequency data

           two single sources Left and Right, ContraLateral STF and Ipsilateral STF

           CodeMat[0] = 0 b     DerCodeMat[0][0] = 0 0 DerCodeMat[0][1] = 0 1 DerCodeMat[0][y]=0 for y=2,3,4,5
                        a 0                        1 0                    0 0
           CodeMat[1] = c 0     DerCodeMat[1][2] = 1 0 DerCodeMat[1][3] = 0 0 DerCodeMat[0][y]=0 for y=0,1,4,5
                        0 d                        0 0                    0 1
           CodeMat[2] = e 0     DerCodeMat[2][4] = 1 0 DerCodeMat[2][5] = 0 0 DerCodeMat[0][y]=0 for y=0,1,2,3
                        f 0                        0 0                    1 0
           CodePars   = [a,b,c,d,e,f] (nCodePars=6)
CodT = U_KBHFUPGRADE:
           KB High Spatial Frequency data

           two single sources Left and Right, ContraLateral STF and Ipsilateral STF

           CodeMat[0] = 0 b     DerCodeMat[0][0] = 0 0 DerCodeMat[0][1] = 0 1 DerCodeMat[0][y]=0 for y=2,3,4,5
                        a 0                        1 0                    0 0
           CodeMat[1] = c 0     DerCodeMat[1][2] = 1 0 DerCodeMat[1][3] = 0 0 DerCodeMat[0][y]=0 for y=0,1,4,5
                        0 d                        0 0                    0 1
           CodeMat[2] = e 0     DerCodeMat[2][4] = 1 0 DerCodeMat[2][5] = 0 0 DerCodeMat[0][y]=0 for y=0,1,2,3
                        f 0                        0 0                    1 0
           CodePars   = [a,b,c,d,e,f] (nCodePars=6)
CodT = U_KBHFUPGRADEREST:
           KB High Spatial Frequency data

           one semi-symmetric source Left and Right, ContraLateral STF and Ipsilateral STF

           CodeMat[0] = 0 b     DerCodeMat[0][0] = 0 0 DerCodeMat[0][1] = 0 1 DerCodeMat[0][y]=0 for y=2,3,4,5
                        a 0                        1 0                    0 0
           CodeMat[1] = c 0     DerCodeMat[1][2] = 1 0 DerCodeMat[1][3] = 0 0 DerCodeMat[0][y]=0 for y=0,1,4,5
                        0 d                        0 0                    0 1
           CodeMat[2] = e 0     DerCodeMat[2][4] = 1 0 DerCodeMat[2][5] = 0 0 DerCodeMat[0][y]=0 for y=0,1,2,3
                        f 0                        0 0                    1 0
           CodePars   = [a,b,c,d,e,f] (nCodePars=6)
CodT = U_KBUNILEFT:
           KB Unilateral Left Stimulation, all Spatial Frequencies: HSF, LSF, MSF
           (two sources in Right Hemisphere Source)

           The first source is the striate source (in HSF, MSF and a minor contribution in LSF)

           The second source is the extrastriate source (in MSF and LSF)

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3,4
           HSF          0 0                        0 0

           CodeMat[1] = b 0     DerCodeMat[1][1] = 1 0 DerCodeMat[1][2] = 0 0 DerCodeMat[1][y]=0 for y=0,3,4
           LSF          0 c                        0 0                    0 1

           CodeMat[2] = d 0     DerCodeMat[2][3] = 1 0 DerCodeMat[2][4] = 0 0 DerCodeMat[1][y]=0 for y=0,1,2
           MSF          0 e                        0 0                    0 1

           CodePars   = [a,b,c,d,e]  a, b<c, d>e  (a is the biggest?)
                    y = [0,1,2,3,4]
CodT = U_KBUNIRIGHT:
           KB Unilateral Right Stimulation, all Spatial Frequencies: HSF, LSF, MSF
           (two sources in Left Hemisphere Source)

           The first source is the striate source (in HSF, MSF and a minor contribution in LSF)

           The second source is the extrastriate source (in MSF and LSF)

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3,4
           HSF          0 0                        0 0

           CodeMat[1] = b 0     DerCodeMat[1][1] = 1 0 DerCodeMat[1][2] = 0 0 DerCodeMat[1][y]=0 for y=0,3,4
           LSF          0 c                        0 0                    0 1

           CodeMat[2] = d 0     DerCodeMat[2][3] = 1 0 DerCodeMat[2][4] = 0 0 DerCodeMat[1][y]=0 for y=0,1,2
           MSF          0 e                        0 0                    0 1

           CodePars   = [a,b,c,d,e]  a, b<c, d>e  (a is the biggest?)
                    y = [0,1,2,3,4]
CodT = U_KBUNILEFTREST:
           KB Unilateral Left Stimulation, all Spatial Frequencies: HSF, LSF, MSF
           (two sources in Right Hemisphere Source)

           The first source is the striate source (in HSF and MSF)

           The second source is the extrastriate source (in MSF and LSF)

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3,4
           HSF          0 0                        0 0

           CodeMat[1] = 0 0     DerCodeMat[1][1] = 0 0 DerCodeMat[1][y]=0 for y=0,2,3
           LSF          0 b                        0 1

           CodeMat[2] = c 0     DerCodeMat[2][2] = 1 0 DerCodeMat[2][3] = 0 0 DerCodeMat[2][y]=0 for y=0,1
           MSF          0 d                        0 0                    0 1

           CodePars   = [a,b,c,d]  where d>e
                    y = [0,1,2,3]
CodT = U_KBUNIRIGHTREST:
           KB Unilateral Right Stimulation, all Spatial Frequencies: HSF, LSF, MSF
           (two sources in Left Hemisphere)

           The first source is the striate source (in HSF and MSF)

           The second source is the extrastriate source (in MSF and LSF)

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3,4
           HSF          0 0                        0 0

           CodeMat[1] = 0 0     DerCodeMat[1][1] = 0 0 DerCodeMat[1][y]=0 for y=0,2,3
           LSF          0 b                        0 1

           CodeMat[2] = c 0     DerCodeMat[2][2] = 1 0 DerCodeMat[2][3] = 0 0 DerCodeMat[2][y]=0 for y=0,1
           MSF          0 d                        0 0                    0 1

           CodePars   = [a,b,c,d]  where d>e
                    y = [0,1,2,3]
CodT = U_KBALLCODES:
           KB visual data, all Spatial Frequencies, all lateralizations,

           The sources: RightStriate, LeftStriate, RightExtraStriate, LeftExtraStriate

           CodeMat[0] = a 0 0 0  CodeMat[1] = b 0 0 0  CodeMat[2] = d 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 c 0               0 0 e 0
                        0 0 0 0               0 0 0 0               0 0 0 0

           CodeMat[3] = 0 0 0 0  CodeMat[4] = 0 0 0 0  CodeMat[5] = 0 0 0 0
                        f 0 0 0               g 0 0 0               u 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 h 0               0 0 j 0

           CodeMat[6] = a k 0 0  CodeMat[7] = b l 0 0  CodeMat[8] = d n 0 0
                        f p 0 0               g q 0 0               u s 0 0
                        0 0 0 0               0 0 c m               0 0 e o
                        0 0 0 0               0 0 h r               0 0 j t

           CodePars   = [a,b,c,d,e,f,g,h,u,j, k, l, m, n, o, p, q, r, t, s]
           CodePars   = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
CodT = U_KBALLUNILAT:
           KB visual data, All UniLateral data, all Spatial Frequencies

           The first source corresponds to: LeftHemi, the second to Right Hemi

           CodeMat[0] = 0 0  CodeMat[1] = 0 0  CodeMat[2] = 0 0
                        a 0               b 0               d 0
                        0 0               0 0               0 0
                        0 0               0 c               0 e

           CodeMat[3] = f 0  CodeMat[4] = g 0  CodeMat[5] = u 0
                        0 0               0 0               0 0
                        0 0               0 h               0 j
                        0 0               0 0               0 0
           CodePars   = [a,b,c,d,e,f,g,h,u,j]
           CodePars   = [0,1,2,3,4,5,6,7,8,9]
CodT = U_KBALLCODESSYMM:
           KB visual data, all Spatial Frequencies, all lateralizations, two semi-symmetric dipoles

           The STFs: StriateLeft, StriateRight, ExtraStriateLeft, ExtraStriateRight

           CodeMat[0] = 0 0 0 0  CodeMat[1] = 0 0 0 0  CodeMat[2] = 0 0 0 0
                        a 0 0 0               b 0 0 0               d 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 c 0               0 0 e 0

           CodeMat[3] = f 0 0 0  CodeMat[4] = g 0 0 0  CodeMat[5] = u 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 h 0               0 0 j 0
                        0 0 0 0               0 0 0 0               0 0 0 0

           CodeMat[6] = f p 0 0  CodeMat[7] = g q 0 0  CodeMat[8] = u s 0 0
                        a k 0 0               b l 0 0               d n 0 0
                        0 0 0 0               0 0 h r               0 0 j t
                        0 0 0 0               0 0 c m               0 0 e o

           CodePars   = [a,b,c,d,e,f,g,h,u,j, k, l, m, n, o, p, q, r, t, s]
           CodePars   = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
CodT = U_KBHFSYMM:
           KB High Spatial Frequency data,

           One semi-symmetric source: BasicSTF and InterAction STF

           CodeMat[0] = 0 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][y]=0 for y=1,2,3
                        a 0                        0 0
           CodeMat[1] = b 0     DerCodeMat[1][1] = 0 0 DerCodeMat[1][y]=0 for y=0,2,3
                        0 0                        1 0
           CodeMat[2] = b d     DerCodeMat[2][0] = 1 0 DerCodeMat[2][1] = 0 0 DerCodeMat[2][2] = 0 1 DerCodeMat[2][3] = 0 0
                        a c                        0 0                    1 0                    0 0                    0 1
           CodePars   = [a,b,c,d]
CodT = U_KBALLCODESSYMMREST:
           KB visual data, all Spatial Frequencies, all lateralizations, two semi-symmetric dipoles

           The STFs: StriateLeft, StriateRight, ExtraStriateLeft, ExtraStriateRight

           CodeMat[0] = 0 0 0 0  CodeMat[1] = 0 0 0 0  CodeMat[2] = 0 0 0 0
                        a 0 0 0               0 0 0 0               c 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 b 0               0 0 d 0

           CodeMat[3] = e 0 0 0  CodeMat[4] = 0 0 0 0  CodeMat[5] = g 0 0 0
                        0 0 0 0               0 0 0 0               0 0 0 0
                        0 0 0 0               0 0 f 0               0 0 h 0
                        0 0 0 0               0 0 0 0               0 0 0 0

           CodeMat[6] = e u 0 0  CodeMat[7] = 0 0 0 0  CodeMat[8] = g m 0 0
                        a j 0 0               0 0 0 0               c n 0 0
                        0 0 0 0               0 0 f k               0 0 h o
                        0 0 0 0               0 0 b l               0 0 d p

           CodePars   = [a,b,c,d,e,f,g,h,u,j, k, l, m, n, o, p]
           CodePars   = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
CodT = U_KBALLUNILATSYMM:
           KB visual data, All UniLateral data, all Spatial Frequencies, two semi symmetric dipoles

           The first source corresponds to: LeftHemi, the second to Right Hemi

           CodeMat[0] = 0 0  CodeMat[1] = 0 0  CodeMat[2] = 0 0
                        a 0               b 0               d 0
                        0 0               0 0               0 0
                        0 0               0 c               0 e

           CodeMat[3] = f 0  CodeMat[4] = g 0  CodeMat[5] = u 0
                        0 0               0 0               0 0
                        0 0               0 h               0 j
                        0 0               0 0               0 0

           CodePars   = [a,b,c,d,e,f,g,h,u,j]
           CodePars   = [0,1,2,3,4,5,6,7,8,9]
CodT = U_KBALLUNILATSYMMREST:
           KB visual data, All UniLateral data, all Spatial Frequencies, two semi symmetric dipoles

           The first source corresponds to: LeftHemi, the second to Right Hemi

           CodeMat[0] = 0 0  CodeMat[1] = 0 0  CodeMat[2] = 0 0
                        a 0               0 0               c 0
                        0 0               0 0               0 0
                        0 0               0 b               0 d

           CodeMat[3] = e 0  CodeMat[4] = 0 0  CodeMat[5] = g 0
                        0 0               0 0               0 0
                        0 0               0 f               0 h
                        0 0               0 0               0 0

           CodePars   = [a,b,c,d,e,f,g,h]
           CodePars   = [0,1,2,3,4,5,6,7]
CodT = U_SIMULATIONCODE:
           Simulated Coded MEG data, 3 codes

           two single sources (LH and RH); two Basic STFs: UniLat STF and BiLat STF
           codes: UniLeft, UniRight, Bilat

           CodeMat[0] = 0 0     DerCodeMat[0][0] = 0 0 DerCodeMat[0][y]=0 for y=1,2,3
                        a 0                        1 0
           CodeMat[1] = b 0     DerCodeMat[1][1] = 1 0 DerCodeMat[1][y]=0 for y=0,2,3
                        0 0                        0 0
           CodeMat[2] = 0 d     DerCodeMat[2][2] = 0 0 DerCodeMat[2][3] = 0 1
                        0 c                        0 1                    0 0
           CodePars   = [a,b,c,d]
CodT = U_SIMULATIONCODE2:
           Simulated Coded MEG data, 5 codes

           two single sources (striate and extrastriate); two Basic STFs: StriateSTF and ExtraStriateSTF


           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][1] = 0 0
                        0 b                        0 0                    0 1
           CodeMat[1] = c 0     DerCodeMat[1][2] = 1 0 DerCodeMat[1][3] = 0 0
                        0 d                        0 0                    0 1
           CodeMat[2] = e 0     DerCodeMat[2][4] = 1 0 DerCodeMat[2][5] = 0 0
                        0 f                        0 0                    0 1
           CodeMat[3] = g 0     DerCodeMat[3][6] = 1 0 DerCodeMat[3][7] = 0 0
                        0 h                        0 0                    0 1
           CodeMat[4] = i 0     DerCodeMat[4][8] = 1 0 DerCodeMat[3][7] = 0 0
                        0 j                        0 0                    0 1
           CodePars   = [a,b,c,d,e,f,g,h,i,j]
                         0,1,2,3,4,5,6,7,8,9
CodT = U_BIJMAPROTOCOL:
           FB Visual Data, 5 codes

           two single sources (both extrastriate); two Basic STFs
           Codes: Check Size 6', 12', 25', 36', 48'

           CodeMat[0] = a 0     DerCodeMat[0][0] = 1 0 DerCodeMat[0][1] = 0 0
                        0 b                        0 0                    0 1
           CodeMat[1] = c 0     DerCodeMat[1][2] = 1 0 DerCodeMat[1][3] = 0 0
                        0 d                        0 0                    0 1
           CodeMat[2] = e 0     DerCodeMat[2][4] = 1 0 DerCodeMat[2][5] = 0 0
                        0 f                        0 0                    0 1
           CodeMat[3] = g 0     DerCodeMat[3][6] = 1 0 DerCodeMat[3][7] = 0 0
                        0 h                        0 0                    0 1
           CodeMat[4] = i 0     DerCodeMat[4][8] = 1 0 DerCodeMat[3][7] = 0 0
                        0 j                        0 0                    0 1
           CodePars   = [a,b,c,d,e,f,g,h,i,j]
                         0,1,2,3,4,5,6,7,8,9
CodT = U_AUDModulated:
           RS Visual data, 4 codes,

           one semi-symmetric source Left and Right, 8 STF's

           CodeMat[0] = a 0 0 0 0 0 0 0
                        0 b 0 0 0 0 0 0

           CodeMat[1] = 0 0 c 0 0 0 0 0
                        0 0 0 d 0 0 0 0

           CodeMat[2] = 0 0 0 0 e 0 0 0
                        0 0 0 0 0 f 0 0

           CodeMat[3] = 0 0 0 0 0 0 g 0
                        0 0 0 0 0 0 0 h
           CodePars   = [a,b,c,d,e,f,g,h] (nCodePars=8)

*/
{
    DeleteCodeMembers();
    CdT = CodT;

/* Setting nCodes nCodePars nDipoles and nBasicSTF for each code*/
    switch(CodT)
    {
    case U_KBHF:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(2)!=U_OK) // RightSource, LeftSource
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // UniSTF, additional interaction BiSTF
            break;
        }
    case U_KBHFREST:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(1)!=U_OK) // one semi-symmetric source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // UniSTF, BiSTF
            break;
        }

    case U_KBHFFREE:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(2)!=U_OK) // two single sources
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // UniSTF, BiSTF
            break;
        }

    case U_KBHFUPGRADE:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 6;          // a, b, c, d, e, f
            if(SetNdipoles(2)!=U_OK) // two single sources, first Left, then Right
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // ContraSTF, IpsiSTF
            break;
        }

    case U_KBHFUPGRADEREST:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 6;          // a, b, c, d, e, f
            if(SetNdipoles(1)!=U_OK) // one semi-symmetric source, first Left, then Right
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParameters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // ContraSTF, IpsiSTF
            break;
        }

    case U_KBUNILEFT:
        {
            nCodes     = 3;          // HSF, LSF, MSF
            nCodePars  = 5;          // a, b, c, d, e
            if(SetNdipoles(2)!=U_OK) // Striate and ExtraStriate Source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_KBUNIRIGHT:
        {
            nCodes     = 3;          // HSF, LSF, MSF
            nCodePars  = 5;          // a, b, c, d, e
            if(SetNdipoles(2)!=U_OK) // Striate and ExtraStriate Source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_KBUNILEFTREST:
        {
            nCodes     = 3;          // HSF, LSF, MSF
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(2)!=U_OK) // Striate and ExtraStriate Source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_KBUNIRIGHTREST:
        {
            nCodes     = 3;          // HSF, LSF, MSF
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(2)!=U_OK) // Striate and ExtraStriate Source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_KBALLCODES:
        {
            nCodes     = 9;          // (Left, Right, Bi) x (HF, LF, MF)
            nCodePars  = 20;         // a to t
            if(SetNdipoles(4)!=U_OK) // RightStriate, LeftStriate, RightExtraStriate, LeftExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 4;          // StriateBasis, StriateInterAct, ExtraStriateBasis, ExtraStriateInterAct
            break;
        }

    case U_KBALLUNILAT:
        {
            nCodes     = 6;          // (Left, Right) x (HF, LF, MF)
            nCodePars  = 10;         // a to j
            if(SetNdipoles(4)!=U_OK) // RightStriate, LeftStriate, RightExtraStriate, LeftExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // Striate, ExtraStriate
            break;
        }

    case U_KBALLCODESSYMM:
        {
            nCodes    = 9;           // (Left, Right, Bi) x (HF, LF, MF)
            nCodePars = 20;          // a to t
            if(SetNdipoles(2)!=U_OK) // SymmetricStriate, SymmetricExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF = 4;           // StriateBasis, StriateInterAct, ExtraStriateBasis, ExtraStriateInterAct
            break;
        }

    case U_KBHFSYMM:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(1)!=U_OK) // one Semi-Symmetric Source
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // UniSTF, additional interaction BiSTF
            break;
        }

    case U_KBALLCODESSYMMREST:
        {
            nCodes    = 9;           // (Left, Right, Bi) x (HF, LF, MF)
            nCodePars = 16;          // a to p
            if(SetNdipoles(2)!=U_OK) // SymmetricStriate, SymmetricExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF = 4;           // StriateBasis, StriateInterAct, ExtraStriateBasis, ExtraStriateInterAct
            break;
        }

    case U_KBALLUNILATSYMM:
        {
            nCodes     = 6;          // (Left, Right) x (HF, LF, MF)
            nCodePars  = 10;         // a to j
            if(SetNdipoles(2)!=U_OK) // StriateSYMM, ExtraStriateSYMM
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // Striate, ExtraStriate
            break;
        }


    case U_KBALLUNILATSYMMREST:
        {
            nCodes     = 6;         // (Left, Right) x (HF, LF, MF)
            nCodePars  = 8;         // a to h
            if(SetNdipoles(2)!=U_OK) // StriateSYMM, ExtraStriateSYMM
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;          // Striate, ExtraStriate
            break;
        }

    case U_SIMULATIONCODE:
        {
            nCodes     = 3;          // UniLeft, UniRight, Bi
            nCodePars  = 4;          // a, b, c, d
            if(SetNdipoles(2)!=U_OK) // two single sources, Left first, Right second
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // UniSTF, BiSTF
            break;
        }

    case U_SIMULATIONCODE2:
        {
            nCodes     = 5;          //
            nCodePars  = 10;         // a, b, c, d, e, f, g, h, i, j
            if(SetNdipoles(2)!=U_OK) // two single sources, Striate and ExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_BIJMAPROTOCOL:
        {
            nCodes     = 4;          //
            nCodePars  = 8;          // a, b, c, d, e, f, g, h,
            if(SetNdipoles(2)!=U_OK) // two single sources, Striate and ExtraStriate
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 2;         // StriateSTF, ExtraStriateSTF
            break;
        }

    case U_AUDModulated:
        {
            nCodes     = 4;          //
            nCodePars  = 8;          // a, b, c, d, e, f, g, h,
            if(SetNdipoles(1)!=U_OK) // one semi-symmetric source, Left and Right auditive cortex
            {
                CI.AddToLog("ERROR: UCodeManager::SetCodeParamters : Error in setting number of dipoles. \n");
                return U_ERROR;
            }
            nBasicSTF  = 8;         // STF left + STF right for each code
            break;
        }
    default:
        {
            CdT = U_NOCODING;

            CI.AddToLog("ERROR: UCodeManager::SetCodeParameters(): default not yet implemented.\n");
            return U_ERROR;
        }
    }

/* Allocating memory and setting all entries of the matrices to zero or false */
    DerCodMat     = new double**[nCodes];
    BoolDerCodMat = new bool**[nCodes];
    int q=0;
    for(q=0;q<nCodes;q++)
    {
        DerCodMat[q]     = new double*[nCodePars];
        BoolDerCodMat[q] = new bool*[nCodePars];
        for(int y=0;y<nCodePars;y++)
        {
            DerCodMat[q][y]     = new double[NSourceTimeFunc*nBasicSTF];
            BoolDerCodMat[q][y] = new bool[NSourceTimeFunc*nBasicSTF];
        }
    }
    CodeMat     = new double*[nCodes];
    BoolCodeMat = new bool*[nCodes];
    for(q=0;q<nCodes;q++)
    {
        CodeMat[q]     = new double[NSourceTimeFunc*nBasicSTF];
        BoolCodeMat[q] = new bool[NSourceTimeFunc*nBasicSTF];
    }
    CodePars       = new double [nCodePars];
    nTrialsPerCode = new int    [nCodes];
    CodeNames      = new UString[nCodes];
    IsDipInCode    = new bool*  [Ndip];
    int p=0;
    for(p=0; p<Ndip; p++)
        IsDipInCode[p] = new bool[nCodes];
    IsSTFInCode = new bool*[NSourceTimeFunc];
    for(p=0; p<NSourceTimeFunc; p++)
        IsSTFInCode[p] = new bool[nCodes];
    if(   !DerCodMat   || !BoolDerCodMat || !CodeMat
       || !BoolCodeMat || !CodePars      || !nTrialsPerCode
       || !CodeNames   || !IsDipInCode   || !IsSTFInCode)
        return U_ERROR;

    for(q=0;q<nCodes;q++)
        for(int y=0;y<nCodePars;y++)
            for(int p=0;p<NSourceTimeFunc;p++)
                for(int z=0;z<nBasicSTF;z++)
                {
                    DerCodMat[q][y][p*nBasicSTF+z]    =0;
                    BoolDerCodMat[q][y][p*nBasicSTF+z]=false;
                }

    for(q=0;q<nCodes;q++)
        for(int p=0;p<NSourceTimeFunc;p++)
            for(int z=0;z<nBasicSTF;z++)
            {
                CodeMat[q][p*nBasicSTF+z]    =0;
                BoolCodeMat[q][p*nBasicSTF+z]=false;
            }

/* Initializing DerCodMat and CodeMat*/
    switch(CodT)
    {
    case U_KBHF:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+0] = 1.;

            DerCodMat[2][0][0*nBasicSTF+0] = 1.;
            DerCodMat[2][1][1*nBasicSTF+0] = 1.;
            DerCodMat[2][2][0*nBasicSTF+1] = 1.;
            DerCodMat[2][3][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("4r");
            CodeNames[2] = UString("4b");

            break;
        }
    case U_KBHFREST:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;

            DerCodMat[2][2][1*nBasicSTF+1] = 1.;
            DerCodMat[2][3][0*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("4r");
            CodeNames[2] = UString("4b");
            break;
        }

    case U_KBHFFREE:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;

            DerCodMat[2][2][1*nBasicSTF+1] = 1.;
            DerCodMat[2][3][0*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("4r");
            CodeNames[2] = UString("4b");
            break;
        }

    case U_KBHFUPGRADE:
    case U_KBHFUPGRADEREST:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;
            DerCodMat[0][1][0*nBasicSTF+1] = 1.;

            DerCodMat[1][2][0*nBasicSTF+0] = 1.;
            DerCodMat[1][3][1*nBasicSTF+1] = 1.;

            DerCodMat[2][4][0*nBasicSTF+0] = 1.;
            DerCodMat[2][5][1*nBasicSTF+0] = 1.;

            CodeNames[0] = UString("CDM4l");
            CodeNames[1] = UString("CDM4r");
            CodeNames[2] = UString("CDM4b");

            break;
        }

    case U_KBUNILEFT:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;
            DerCodMat[1][2][1*nBasicSTF+1] = 1.;

            DerCodMat[2][3][0*nBasicSTF+0] = 1.;
            DerCodMat[2][4][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            break;
        }

    case U_KBUNIRIGHT:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;
            DerCodMat[1][2][1*nBasicSTF+1] = 1.;

            DerCodMat[2][3][0*nBasicSTF+0] = 1.;
            DerCodMat[2][4][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4r");
            CodeNames[1] = UString("1r");
            CodeNames[2] = UString("2r");
            break;
        }

    case U_KBUNILEFTREST:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+1] = 1.;

            DerCodMat[2][2][0*nBasicSTF+0] = 1.;
            DerCodMat[2][3][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            break;
        }

    case U_KBUNIRIGHTREST:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+1] = 1.;

            DerCodMat[2][2][0*nBasicSTF+0] = 1.;
            DerCodMat[2][3][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4r");
            CodeNames[1] = UString("1r");
            CodeNames[2] = UString("2r");
            break;
        }

    case U_KBALLCODES:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;
            DerCodMat[1][2][2*nBasicSTF+2] = 1.;

            DerCodMat[2][3][0*nBasicSTF+0] = 1.;
            DerCodMat[2][4][2*nBasicSTF+2] = 1.;

            DerCodMat[3][5][1*nBasicSTF+0] = 1.;

            DerCodMat[4][6][1*nBasicSTF+0] = 1.;
            DerCodMat[4][7][3*nBasicSTF+2] = 1.;

            DerCodMat[5][8][1*nBasicSTF+0] = 1.;
            DerCodMat[5][9][3*nBasicSTF+2] = 1.;

            DerCodMat[6][0 ][0*nBasicSTF+0] = 1.;
            DerCodMat[6][10][0*nBasicSTF+1] = 1.;
            DerCodMat[6][5 ][1*nBasicSTF+0] = 1.;
            DerCodMat[6][15][1*nBasicSTF+1] = 1.;

            DerCodMat[7][1 ][0*nBasicSTF+0] = 1.;
            DerCodMat[7][11][0*nBasicSTF+1] = 1.;
            DerCodMat[7][6 ][1*nBasicSTF+0] = 1.;
            DerCodMat[7][16][1*nBasicSTF+1] = 1.;
            DerCodMat[7][2 ][2*nBasicSTF+2] = 1.;
            DerCodMat[7][12][2*nBasicSTF+3] = 1.;
            DerCodMat[7][7 ][3*nBasicSTF+2] = 1.;
            DerCodMat[7][17][3*nBasicSTF+3] = 1.;

            DerCodMat[8][3 ][0*nBasicSTF+0] = 1.;
            DerCodMat[8][13][0*nBasicSTF+1] = 1.;
            DerCodMat[8][8 ][1*nBasicSTF+0] = 1.;
            DerCodMat[8][18][1*nBasicSTF+1] = 1.;
            DerCodMat[8][4 ][2*nBasicSTF+2] = 1.;
            DerCodMat[8][14][2*nBasicSTF+3] = 1.;
            DerCodMat[8][9 ][3*nBasicSTF+2] = 1.;
            DerCodMat[8][19][3*nBasicSTF+3] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            CodeNames[6] = UString("4b");
            CodeNames[7] = UString("1b");
            CodeNames[8] = UString("2b");
            break;
        }

    case U_KBALLUNILAT:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+0] = 1.;
            DerCodMat[1][2][3*nBasicSTF+1] = 1.;

            DerCodMat[2][3][1*nBasicSTF+0] = 1.;
            DerCodMat[2][4][3*nBasicSTF+1] = 1.;

            DerCodMat[3][5][0*nBasicSTF+0] = 1.;

            DerCodMat[4][6][0*nBasicSTF+0] = 1.;
            DerCodMat[4][7][2*nBasicSTF+1] = 1.;

            DerCodMat[5][8][0*nBasicSTF+0] = 1.;
            DerCodMat[5][9][2*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            break;
        }

    case U_KBALLCODESSYMM:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+0] = 1.;
            DerCodMat[1][2][3*nBasicSTF+2] = 1.;

            DerCodMat[2][3][1*nBasicSTF+0] = 1.;
            DerCodMat[2][4][3*nBasicSTF+2] = 1.;

            DerCodMat[3][5][0*nBasicSTF+0] = 1.;

            DerCodMat[4][6][0*nBasicSTF+0] = 1.;
            DerCodMat[4][7][2*nBasicSTF+2] = 1.;

            DerCodMat[5][8][0*nBasicSTF+0] = 1.;
            DerCodMat[5][9][2*nBasicSTF+2] = 1.;

            DerCodMat[6][0 ][1*nBasicSTF+0] = 1.;
            DerCodMat[6][10][1*nBasicSTF+1] = 1.;
            DerCodMat[6][5 ][0*nBasicSTF+0] = 1.;
            DerCodMat[6][15][0*nBasicSTF+1] = 1.;

            DerCodMat[7][1 ][1*nBasicSTF+0] = 1.;
            DerCodMat[7][11][1*nBasicSTF+1] = 1.;
            DerCodMat[7][6 ][0*nBasicSTF+0] = 1.;
            DerCodMat[7][16][0*nBasicSTF+1] = 1.;
            DerCodMat[7][2 ][3*nBasicSTF+2] = 1.;
            DerCodMat[7][12][3*nBasicSTF+3] = 1.;
            DerCodMat[7][7 ][2*nBasicSTF+2] = 1.;
            DerCodMat[7][17][2*nBasicSTF+3] = 1.;

            DerCodMat[8][3 ][1*nBasicSTF+0] = 1.;
            DerCodMat[8][13][1*nBasicSTF+1] = 1.;
            DerCodMat[8][8 ][0*nBasicSTF+0] = 1.;
            DerCodMat[8][18][0*nBasicSTF+1] = 1.;
            DerCodMat[8][4 ][3*nBasicSTF+2] = 1.;
            DerCodMat[8][14][3*nBasicSTF+3] = 1.;
            DerCodMat[8][9 ][2*nBasicSTF+2] = 1.;
            DerCodMat[8][19][2*nBasicSTF+3] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            CodeNames[6] = UString("4b");
            CodeNames[7] = UString("1b");
            CodeNames[8] = UString("2b");
            break;
        }

    case U_KBHFSYMM:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;

            DerCodMat[2][0][1*nBasicSTF+0] = 1.;
            DerCodMat[2][1][0*nBasicSTF+0] = 1.;
            DerCodMat[2][2][1*nBasicSTF+1] = 1.;
            DerCodMat[2][3][0*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("4r");
            CodeNames[2] = UString("4b");
            break;
        }

    case U_KBALLCODESSYMMREST:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][3*nBasicSTF+2] = 1.;

            DerCodMat[2][2][1*nBasicSTF+0] = 1.;
            DerCodMat[2][3][3*nBasicSTF+2] = 1.;

            DerCodMat[3][4][0*nBasicSTF+0] = 1.;

            DerCodMat[4][5][2*nBasicSTF+2] = 1.;

            DerCodMat[5][6][0*nBasicSTF+0] = 1.;
            DerCodMat[5][7][2*nBasicSTF+2] = 1.;

            DerCodMat[6][0][1*nBasicSTF+0] = 1.;
            DerCodMat[6][4][0*nBasicSTF+0] = 1.;
            DerCodMat[6][8][0*nBasicSTF+1] = 1.;
            DerCodMat[6][9][1*nBasicSTF+1] = 1.;

            DerCodMat[7][1 ][3*nBasicSTF+2] = 1.;
            DerCodMat[7][5 ][2*nBasicSTF+2] = 1.;
            DerCodMat[7][10][2*nBasicSTF+3] = 1.;
            DerCodMat[7][11][3*nBasicSTF+3] = 1.;

            DerCodMat[8][2 ][1*nBasicSTF+0] = 1.;
            DerCodMat[8][3 ][3*nBasicSTF+2] = 1.;
            DerCodMat[8][6 ][0*nBasicSTF+0] = 1.;
            DerCodMat[8][7 ][2*nBasicSTF+2] = 1.;
            DerCodMat[8][12][0*nBasicSTF+1] = 1.;
            DerCodMat[8][13][1*nBasicSTF+1] = 1.;
            DerCodMat[8][14][2*nBasicSTF+3] = 1.;
            DerCodMat[8][15][3*nBasicSTF+3] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            CodeNames[6] = UString("4b");
            CodeNames[7] = UString("1b");
            CodeNames[8] = UString("2b");
            break;
        }

    case U_KBALLUNILATSYMM:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][1*nBasicSTF+0] = 1.;
            DerCodMat[1][2][3*nBasicSTF+1] = 1.;

            DerCodMat[2][3][1*nBasicSTF+0] = 1.;
            DerCodMat[2][4][3*nBasicSTF+1] = 1.;

            DerCodMat[3][5][0*nBasicSTF+0] = 1.;

            DerCodMat[4][6][0*nBasicSTF+0] = 1.;
            DerCodMat[4][7][2*nBasicSTF+1] = 1.;

            DerCodMat[5][8][0*nBasicSTF+0] = 1.;
            DerCodMat[5][9][2*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            break;
        }


    case U_KBALLUNILATSYMMREST:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][3*nBasicSTF+1] = 1.;

            DerCodMat[2][2][1*nBasicSTF+0] = 1.;
            DerCodMat[2][3][3*nBasicSTF+1] = 1.;

            DerCodMat[3][4][0*nBasicSTF+0] = 1.;

            DerCodMat[4][5][2*nBasicSTF+1] = 1.;

            DerCodMat[5][6][0*nBasicSTF+0] = 1.;
            DerCodMat[5][7][2*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("4l");
            CodeNames[1] = UString("1l");
            CodeNames[2] = UString("2l");
            CodeNames[3] = UString("4r");
            CodeNames[4] = UString("1r");
            CodeNames[5] = UString("2r");
            break;
        }

    case U_SIMULATIONCODE:
        {
            DerCodMat[0][0][1*nBasicSTF+0] = 1.;

            DerCodMat[1][1][0*nBasicSTF+0] = 1.;

            DerCodMat[2][2][1*nBasicSTF+1] = 1.;
            DerCodMat[2][3][0*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("1 dip Left");
            CodeNames[1] = UString("1 dip Right");
            CodeNames[2] = UString("2 dip BiLat");
            break;
        }

    case U_SIMULATIONCODE2:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;
            DerCodMat[0][1][1*nBasicSTF+1] = 1.;

            DerCodMat[1][2][0*nBasicSTF+0] = 1.;
            DerCodMat[1][3][1*nBasicSTF+1] = 1.;

            DerCodMat[2][4][0*nBasicSTF+0] = 1.;
            DerCodMat[2][5][1*nBasicSTF+1] = 1.;

            DerCodMat[3][6][0*nBasicSTF+0] = 1.;
            DerCodMat[3][7][1*nBasicSTF+1] = 1.;

            DerCodMat[4][8][0*nBasicSTF+0] = 1.;
            DerCodMat[4][9][1*nBasicSTF+1] = 1.;

            CodeNames[0] = UString("Striate1");
            CodeNames[1] = UString("Striate3/4");
            CodeNames[2] = UString("Striate1/2");
            CodeNames[3] = UString("Striate1/4");
            CodeNames[4] = UString("ExtraStriate");
            break;
        }

    case U_BIJMAPROTOCOL:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;
            DerCodMat[0][1][1*nBasicSTF+1] = 1.;

            DerCodMat[1][2][0*nBasicSTF+0] = 1.;
            DerCodMat[1][3][1*nBasicSTF+1] = 1.;

            DerCodMat[2][4][0*nBasicSTF+0] = 1.;
            DerCodMat[2][5][1*nBasicSTF+1] = 1.;

            DerCodMat[3][6][0*nBasicSTF+0] = 1.;
            DerCodMat[3][7][1*nBasicSTF+1] = 1.;

         //   DerCodMat[4][8][0*nBasicSTF+0] = 1.;
         //   DerCodMat[4][9][1*nBasicSTF+1] = 1.;

           // CodeNames[0] = UString("DE-VISLL06_20030417_01");
            CodeNames[0] = UString("DE-VISLL12_20030417_02");
            CodeNames[1] = UString("DE-VISLL24_20030417_03");
            CodeNames[2] = UString("DE-VISLL36_20030417_04");
            CodeNames[3] = UString("DE-VISLL48_20030417_05");
            break;
        }

    case U_AUDModulated:
        {
            DerCodMat[0][0][0*nBasicSTF+0] = 1.;
            DerCodMat[0][1][1*nBasicSTF+1] = 1.;

            DerCodMat[1][2][0*nBasicSTF+2] = 1.;
            DerCodMat[1][3][1*nBasicSTF+3] = 1.;

            DerCodMat[2][4][0*nBasicSTF+4] = 1.;
            DerCodMat[2][5][1*nBasicSTF+5] = 1.;

            DerCodMat[3][6][0*nBasicSTF+6] = 1.;
            DerCodMat[3][7][1*nBasicSTF+7] = 1.;
/*
            CodeNames[0] = UString("de_1400_36_fga");
            CodeNames[1] = UString("de_1400_40_fga");
            CodeNames[2] = UString("de_1400_44_fga");
            CodeNames[3] = UString("de_1400_48_fga");
*/
            CodeNames[0] = UString("de_1400_76_fga");
            CodeNames[1] = UString("de_1400_80_fga");
            CodeNames[2] = UString("de_1400_84_fga");
            CodeNames[3] = UString("de_1400_88_fga");

            break;
        }

    default:
        {
            CI.AddToLog("ERROR: UCodeManager::SetCodeParameters(): default not yet implemented.\n");
            return U_ERROR;
        }
    }

    for(int y=0;y<nCodePars;y++) CodePars[y]=1.;

/* Filling the boolean array BoolDerCodMat */
    for(q=0;q<nCodes;q++)
        for(int y=0;y<nCodePars;y++)
            for(int p=0;p<NSourceTimeFunc;p++)
                for(int z=0;z<nBasicSTF;z++)
                {
                    if(DerCodMat[q][y][p*nBasicSTF+z]!=0)
                        BoolDerCodMat[q][y][p*nBasicSTF+z]=true;
                }

/* Updating CodeMat and  the boolean array BoolCodeMat and IsDipSTFInCode */
    UpdateCodeMat();
    UpdateIsDipSTFInCode();
    return U_OK;
}

ErrorType UCodeManager::SetCoupleDesign(bool** CoupleMat, char** MarNames, int nCondition, int nBasSTF, UDipoleEdit* DipEd, int nDip)
{
    if(!CoupleMat || !MarNames || nCondition < 1 || nBasSTF < 1 || !DipEd|| nDip <1 )
    {
        CI.AddToLog("ERROR: UCodeManager::SetCoupleDesign(). Invalid parameter.\n");
        return U_ERROR;
    }

    nCodes = nCondition;

/* Set the number of dipoles */
/* Check all dipoles in DipEd are of the same dipole type */

/* !!!!!!! In case different dipole types are allowed, this routine has to be adapted !!!!!!*/

    int iDip=0;
    for(iDip=0;iDip<nDip;iDip++)
    {
        if(DipEd[iDip].GetDipoleType() != DipEd[0].GetDipoleType())
            break;
    }
    if(iDip<nDip)
    {
        CI.AddToLog("ERROR: UCodeManager::SetCoupleDesign(). Different dipoles not implemented (yet).\n");
        return U_ERROR;
    }
    if(SetNdipoles(nDip)!=U_OK)
    {
        CI.AddToLog("ERROR: UCodeManager::SetCoupleDesign : Error in setting number of dipoles. \n");
        return U_ERROR;
    }


/* Determine nCodePars = the number of "true" entries in CoupleMat */
    nBasicSTF  = nBasSTF;
    nCodePars=0;

    for(int iCond=0;iCond<nCondition;iCond++)
        for(int i=0;i<NSourceTimeFunc*nBasicSTF;i++)
            if(CoupleMat[iCond][i] == true)
                nCodePars++;

/* Allocating memory for all private member arrays */
    CodeMat        = new double* [nCodes   ];
    DerCodMat      = new double**[nCodes   ];
    BoolCodeMat    = new bool*   [nCodes   ];
    BoolDerCodMat  = new bool**  [nCodes   ];
    CodeNames      = new UString [nCodes   ];
    nTrialsPerCode = new int     [nCodes   ];
    CodePars       = new double  [nCodePars];
    IsDipInCode    = new bool*[Ndip];
    IsSTFInCode    = new bool*[NSourceTimeFunc];
    if(!CodeMat       || !DerCodMat   || !BoolCodeMat    ||
       !BoolDerCodMat || !CodeNames   || !nTrialsPerCode ||
       !CodePars      || !IsDipInCode || !IsSTFInCode)
    {
        CI.AddToLog("ERROR: UCodeManager::SetCoupleDesign(). Memory Allocation.\n");
        return U_ERROR;
    }

    int q=0;
    int p=0;
    for(q=0;q<nCodes;q++)
    {
        CodeMat[q]       = new double[NSourceTimeFunc*nBasicSTF];
        BoolCodeMat[q]   = new bool[  NSourceTimeFunc*nBasicSTF];
        DerCodMat[q]     = new double*[nCodePars];
        BoolDerCodMat[q] = new bool*[  nCodePars];
        for(int y=0;y<nCodePars;y++)
        {
            DerCodMat[q][y]     = new double[NSourceTimeFunc*nBasicSTF];
            BoolDerCodMat[q][y] = new bool[NSourceTimeFunc*nBasicSTF];
        }
    }
    for(p=0; p<Ndip; p++)
        IsDipInCode[p] = new bool[nCodes];
    for(p=0; p<NSourceTimeFunc; p++)
        IsSTFInCode[p] = new bool[nCodes];

/* Filling the arrays with their default values */
    for(q=0;q<nCodes;q++)
    {
        nTrialsPerCode[q] = 0;
        for(int pz=0;pz<NSourceTimeFunc*nBasicSTF;pz++)
        {
            CodeMat[q][pz]     = 0;
            BoolCodeMat[q][pz] = false;
            for(int y=0;y<nCodePars;y++)
            {
                 DerCodMat[q][y][pz]     = 0;
                 BoolDerCodMat[q][y][pz] = false;
            }
        }
    }

/* Filling the arrays DerCodMat and BoolDerCodMat, based on the input CoupledMat[][] */
    int iCodPar =0;
    for(int iCond=0;iCond<nCondition;iCond++)
        for(int pz=0;pz<NSourceTimeFunc*nBasicSTF;pz++)
        {
            if(CoupleMat[iCond][pz] == true)
            {
                DerCodMat[iCond][iCodPar][pz]     = 1.;
                BoolDerCodMat[iCond][iCodPar][pz] = true;
                iCodPar++;
            }
        }

    for(int y=0;y<nCodePars;y++) CodePars[y]=1.;

/* Filling the array CodeNames with the names of the markers from MarNames */
    for(int p=0;p<nCodes;p++)
        CodeNames[p]= MarNames[p];

/* Updating the arrays CodeMat, BoolCodeMat, IsDipInCode and IsSTFInCode */
    UpdateCodeMat();
    UpdateIsDipSTFInCode();
    return U_OK;
}
