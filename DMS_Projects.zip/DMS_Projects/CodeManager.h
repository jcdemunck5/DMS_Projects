#ifndef _CODEMANAGER_INCLUDED
#define _CODEMANAGER_INCLUDED

#define MAXCODEDIP  6
#define MAXCODES    15
#define MAXCODEPARS 25
#define MAXCODEMOMS 18 // 3 x MAXCODEDIP
#define MAXBASICSTF 20

#include "Euler.h"
#include "FileName.h"
#include "MarkerArray.h"
#include "DipoleManager.h"
#include "DipoleEditList.h"

class UCodeManager : public UDipoleManager
{
public: 
    enum CodeType {U_KBHF,               // KB visual data High Spatial Frequency, two single dipoles, Basic STF and InterAction STF
                   U_KBHFREST,           // KB visual data High Spatial Frequency, one semi-symmetric dipole, UniLat STF and BiLat STF
                   U_KBHFUPGRADE,        // KB visual data High Spatial Frequency, two single dipoles, ContraLat STF and IpsiLat STF
                   U_KBHFUPGRADEREST,    // KB visual data High Spatial Frequency, one semi-symmetric dipole, ContraLat STF and IpsiLat STF 
                   U_KBHFFREE,           // KB visual data High Spatial Frequency, two single dipoles, UniLat STF and BiLat STF
                   U_KBHFSYMM,           // KB visual data High Spatial Frequency, one semi-symmetric dipole, Basic STF and InterAction STF
                   U_KBUNILEFT,          // KB visual data UniLateral Left,  all Spatial Frequencies, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate
                   U_KBUNIRIGHT,         // KB visual data UniLateral Right, all Spatial Frequencies, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate
                   U_KBUNILEFTREST,      // KB visual data UniLateral Left,  all Spatial Frequencies, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate
                   U_KBUNIRIGHTREST,     // KB visual data UniLateral Right, all Spatial Frequencies, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate
                   U_KBALLUNILAT,        // KB visual data All Spatial Frequencies, UniLeft and UniRight, four single dipoles; HSF: Striate only, MSF, LSF: both Striate and ExtraStriate
                   U_KBALLUNILATSYMM,    // KB visual data All Spatial Frequencies, UniLeft and UniRight, two semi-symmetric dipoles; HSF: Striate only, MSF, LSF: both Striate and ExtraStriate
                   U_KBALLUNILATSYMMREST,// KB visual data All Spatial Frequencies, UniLeft and UniRight, two semi-symmetric dipoles; HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate
                   U_KBALLCODES,         // KB visual data All Spatial Frequencies, All lateralizations, four single dipoles
                   U_KBALLCODESSYMM,     // KB visual data All Spatial Frequencies, All lateralizations, two semi-symmetric dipoles, HSF: Striate only, MSF, LSF: both Striate and ExtraStriate
                   U_KBALLCODESSYMMREST, // KB visual data All Spatial Frequencies, All lateralizations, two semi-symmetric dipoles, HSF: Striate only, LSF: ExtraStriate only, MSF: both Striate and ExtraStriate
                   U_SIMULATIONCODE,     // Simulation data: Two single dipoles, Two STFs 3 codes
                   U_SIMULATIONCODE2,    // Simulation data: Two visual dipoles (striate and extrastriate), two STFs, 5 codes
                   U_BIJMAPROTOCOL,      // FB visual data: Two visual dipoles (both extrastriate), two STFs, 5 codes
                   U_AUDModulated,       // RS auditive data: Two auditive dipoles, semi-symmetric, one STF per code, 4 codes
                   U_NOCODING};          // No Coding, one code matrix, set to identity

    UCodeManager();               // Default constructor
    UCodeManager(const UDipoleFix* DipoleArray, int Ndipoles, const double* const* pWDerivField, int Nsensors);
    UCodeManager(const UDipole* DipoleArray, int Ndipoles, bool AllRotating, const double* const* pWDerivField, int Nsensors);
    UCodeManager(const UDipoleManager& DM); 

    ~UCodeManager();

    UCodeManager& operator=(const UCodeManager& CM); 
    UCodeManager& operator=(const UDipoleManager& DM); 

    UString&       GetProperties(UString Comment) const;
    ErrorType      GetError(void) const {if(UDipoleManager::GetError()!=U_OK) return U_ERROR; return error;}

    int            GetNCodes()    const     {return nCodes;}
    int            GetNCodePars() const     {return nCodePars;}
    int            GetNBasicSTF() const     {return nBasicSTF;}
    int            GetNFreeSTF()  const     {return NSourceTimeFunc;}
    int            GetNTrialsCode(int q)     const  {return nTrialsPerCode[q];}
    const UString* GetCodeNames(int* NCode)  const  {return CodeNames; if(NCode) *NCode = nCodes;} 
    UString        GetCodeName(int q)        const;
    double*        GetCodePars()             const {return CodePars;}
    const double* const* const GetCodeMat()       const {return CodeMat;}
    const bool*   const* const GetBoolCodeMat()   const {return BoolCodeMat;}
    double***                  GetDerCodMat()     const {return DerCodMat;}
    bool***                    GetBoolDerCodMat() const {return BoolDerCodMat;}

    ErrorType      SetCodeParameters(CodeType CdT);  // Sets the coding parameters to a predefined coding
    ErrorType      SetCodePars(double* CodPars);     // Sets CodePars-array equal to values in CodPars
    ErrorType      SetCoupleDesign(bool** CoupleMat, char** MarNames, int nCondition, int nBasicSTF, UDipoleEdit* DipEd, int nDipoles);
                                                
    ErrorType      SetNTrialsPerCode(int* nTrialsPerCode);      // Deletes and builds nTrialsPerCode anew
    ErrorType      ScaleCodeMatWithTrials(int* nTrialsPerCode); // Scales the DerCodeMat with nTrialsPerCode

    void           UpdateCodeMat() const;                       // Updates CodeMat by multiplying DerCodMat with CodePars
    void           UpdateIsDipSTFInCode();                      // Deletes and creates new IsDipInCode and IsSTFInCode 
 
    void           InvertFreeSTF(int istf);  // inverts row istf of DerCodeMat for all codes and updates CodeMat
    void           InvertBasicSTF(int istf); // inverts column istf of DerCodeMat for all codes and updates CodeMat
 
    int            GetNDipolesInCode(int q) const;
    int            GetNCodesInDipole(int p) const;
    ErrorType      GetDipInCodeIndex(int q, int* index) const;  
    ErrorType      GetCodeInDipIndex(int p, int* index) const;  
    ErrorType      ComputeCodeOutput(int q, int& nDipInCode, int* DipInCodeIndex, double* BasicSTF, double* CodeSTF, int nSamp) const;
    void           PrintCodeMat(UFileName FileNameOut, int q,bool Norm=false) const;
    void           PrintCodePars(UFileName FileNameOut, bool Norm=false) const; 

    ErrorType      SwapDipCodeMatOnly(void); // Only if Ndip = 2. Swaps the corresponing rows in CodeMat only, not in DerCodeMat.  

private:  
    static UString Properties;       // General flag containing properties in text format
    ErrorType      error;               // General error flag 

    CodeType       CdT;           // The active code type
    int            nCodes;        // Number of conditions (protocols)
    int            nCodePars;     // Number of parameters in complete code matrix
    int            nBasicSTF;     // Number of basic source time functions   
 
    double*        CodePars;      // Coding parameters
    int*           nTrialsPerCode;// Number of trials per Code
    double**       CodeMat;       // Coding matrix. CodeMat[q] is coding matrix for code q
    double***      DerCodMat;     // Partial derivatives of cod mat.DerCodMat[q][y] is derivative of codmat q w.r.t. codepar y
    bool**         BoolCodeMat;   // Boolean array, keeping track of nonzero entries in CodeMat : true means nonzero
    bool***        BoolDerCodMat; // Boolean array, keeping track of nonzero entries in DerCodMat : true means nonzero

    bool**         IsDipInCode;   // Boolean array keeping track of which dipoles are used in which code
    bool**         IsSTFInCode;   // Boolean array keeping track of which STFs are used in which code
    UString*       CodeNames;     // Array with name of each code (is markername of the code) 

    bool           IsDipUsedInCode(int code, int dip);
    double         GetCodeNormalizer() const;
    void           DeleteCodeMembers(); // Deletes all CodeMembers    
};


#endif // _CODEMANAGER_INCLUDED
