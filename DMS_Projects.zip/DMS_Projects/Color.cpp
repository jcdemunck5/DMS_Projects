/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Color Object                                                              */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Arent de Jongh                                                            */
/*********************************************************************************/
/*
  Update history
  
  Who    When         What
  AdJ    20-06-2000   big revision of test object
  GdV    09-05-2001   small change(s) for Unix compatibility

*/

#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include "Color.h"

UColor::UColor(const char* ClName)
{
    if(!stricmp(ClName, "black"    )) {r=0  ;g=0  ;b=0;  return;}
    if(!stricmp(ClName, "red"      )) {r=255;g=0  ;b=0;  return;}
    if(!stricmp(ClName, "green"    )) {r=0  ;g=255;b=0;  return;}
    if(!stricmp(ClName, "blue"     )) {r=0  ;g=0  ;b=255;return;}
    if(!stricmp(ClName, "white"    )) {r=255;g=255;b=255;return;}
    if(!stricmp(ClName, "lightblue")) {r=0  ;g=255;b=255;return;}
    if(!stricmp(ClName, "darkgray" )) {r=128;g=128;b=128;return;}
    if(!stricmp(ClName, "darkpink" )) {r=255;g=0  ;b=255;return;}
    if(!stricmp(ClName, "darkgreen")) {r=0  ;g=128;b=0;  return;}
    if(!stricmp(ClName, "lightgray")) {r=192;g=192;b=192;return;}
    if(!stricmp(ClName, "brown"    )) {r=128;g=0  ;b=0;  return;}
    if(!stricmp(ClName, "darkblue" )) {r=0  ;g=0  ;b=128;return;}
    if(!stricmp(ClName, "olive"    )) {r=128;g=128;b=0;  return;}
    if(!stricmp(ClName, "purple"   )) {r=128;g=0  ;b=128;return;}
    if(!stricmp(ClName, "yellow"   )) {r=255;g=255;b=0;  return;}

    CI.AddToLog("ERROR UColor::UColor(). ClName not recognised, color set to black\n");
    r=0;g=0;b=0;
}

UColor::UColor(const UColor& Cl)
{
    r = Cl.r;
    g = Cl.g;
    b = Cl.b;
}

UColor::UColor(UColor cl1, UColor cl2, double factor)
{
    if( (factor > 1.0) || (factor < 0.0) )
    {   CI.AddToLog("ERROR UColor::UColor(). factor out of range, color set to black. factor=%f\n",factor);
        r=0;g=0;b=0;
        return;
    }
    r = (unsigned char)(factor * cl1.GetR() + (1.-factor) * cl2.GetR()); 
    g = (unsigned char)(factor * cl1.GetG() + (1.-factor) * cl2.GetG()); 
    b = (unsigned char)(factor * cl1.GetB() + (1.-factor) * cl2.GetB()); 
}

UColor UColor::operator=(const UColor& Cl)
{
    r = Cl.r;
    g = Cl.g;
    b = Cl.b;
    return *this;
}
