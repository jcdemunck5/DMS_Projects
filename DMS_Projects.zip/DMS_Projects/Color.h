#ifndef _COLOR_INCLUDED
#define _COLOR_INCLUDED

#include"BasicInclude.h"

class DLL_IO UColor
{
public: 
    UColor() {r=g=b=0;};
    UColor(int rr, int gg, int bb) {r=(unsigned char)(rr);g=(unsigned char)(gg);b=(unsigned char)(bb);};
    UColor(const char* ClName);
    UColor(const UColor& cl1);
    UColor(UColor cl1, UColor cl2, double factor);

    UColor operator=(const UColor& Cl);

    virtual ~UColor() {};

    unsigned char GetR() const {return r;};
    unsigned char GetG() const {return g;};
    unsigned char GetB() const {return b;};

private:
    unsigned char r,g,b;
};

#endif

