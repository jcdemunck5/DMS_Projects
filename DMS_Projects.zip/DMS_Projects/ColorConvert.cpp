/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for converting color images to index images, using Median Cut      */
/*     Color Quantization.                                                       */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    15-01-12   Creation
*/

#include"ColorConvert.h"
#include"MedianCut.h"
#include"Field.h"

void UColorConvert::SetAllMembersDefault(void)
{
    error     = U_OK;
    CRoot     = NULL;
    TabSize   = 0;
    ColTable  = NULL;
}
void UColorConvert::DeleteAllMembers(ErrorType E)
{
    delete   CRoot;
    delete[] ColTable;
    SetAllMembersDefault();
    error     = E;
}

UColorConvert::UColorConvert()
{
    SetAllMembersDefault();
}
UColorConvert::UColorConvert(unsigned char* ColorImage, int NPoints, int NColChan, int TableSize)
{
    SetAllMembersDefault();
    if(ColorImage==NULL || NPoints<=0 || NColChan<=0 || TableSize<=0 || TableSize>256)
    {
        CI.AddToLog("ERROR: UColorConvert::UColorConvert(). Invalid (NULL) argument(s). NPoints = %d, NColChan = %d, TableSize = %d \n", NPoints, NColChan, TableSize);
        DeleteAllMembers(U_ERROR);
        return;
    }
    TabSize = TableSize;
    CRoot   = GetMedianCut(ColorImage, NColChan, NPoints, TabSize, &ColTable);
    if(CRoot==NULL || ColTable==NULL)
    {
        CI.AddToLog("ERROR: UColorConvert::UColorConvert(). Computing color table using Median Cut Color Quantization - algoritm. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }    
}
UColorConvert::UColorConvert(const UColorConvert& CC)
{
    SetAllMembersDefault();
    *this = CC;
}
UColorConvert::~UColorConvert()
{
    DeleteAllMembers(U_OK);
}

UColorConvert& UColorConvert::operator=(const UColorConvert& CC)
{
    if(this==NULL)
    {
        static UColorConvert Dum; Dum.error = U_ERROR;
        return Dum;
    }
    if(&CC==NULL)
    {
        CI.AddToLog("ERROR: UColorConvert::operator=(). Invalid NULL address in argument.\n");
        return *this;
    }
    if(this==&CC) return *this;

    DeleteAllMembers(U_OK);
    error   = CC.error;

    if(CC.CRoot)
    {
        CRoot = new UBlockByte(CC.CRoot);
        if(CRoot==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UColorConvert::operator=(). Copying CRoot member.\n");
            return *this;
        }
    }
    TabSize   = CC.TabSize;
    int Vec   = CC.GetNColChan();
    if(TabSize*Vec>0)
    {
        ColTable  = new unsigned char[TabSize*Vec];
        if(ColTable==NULL)
        {
            CI.AddToLog("ERROR: UColorConvert::operator=(). Memory allocation: TabSize=%d, Vec=%d.\n", TabSize, Vec);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int ki=0; ki<TabSize*Vec; ki++) ColTable[ki] = CC.ColTable[ki];
    }
    else
    {
        TabSize = 0;
    }
    return *this;
}

int UColorConvert::GetNColChan(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UColorConvert::GetNColChan(). Object NULL or erroneous.\n");
        return 0;
    }
    if(CRoot==NULL) return 0;
    return CRoot->GetVeclen();
}

const unsigned char*  UColorConvert::GetColTable(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UColorConvert::GetColTable(). Object NULL or erroneous.\n");
        return NULL;
    }
    return ColTable;
}
ErrorType UColorConvert::ComputeIndexImage(const unsigned char* ColorImage, int NPoints, int NColChan, unsigned char* IndexImage) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UColorConvert::ComputeIndexImage(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(ColorImage==NULL)
    {
        CI.AddToLog("ERROR: UColorConvert::ComputeIndexImage(). Invalid NULL argument for input color image.\n");
        return U_ERROR;
    }
    int Veclen = GetNColChan();
    if(NPoints<=0 || NColChan !=Veclen)
    {
        CI.AddToLog("ERROR: UColorConvert::ComputeIndexImage(). Invalid NPoints (=%d) or NColChan (=%d) argument; Veclen = %d .\n", NPoints, NColChan, Veclen);
        return U_ERROR;
    }
    if(IndexImage==NULL)
    {
        CI.AddToLog("ERROR: UColorConvert::ComputeIndexImage(). Invalid NULL pointer for output image.\n");
        return U_ERROR;
    }

    for(int i=0; i<NPoints; i++) 
        IndexImage[i] = CRoot->FindIndex(ColorImage+i*Veclen);

    return U_OK;
}

ErrorType UColorConvert::ConvertField(UField* ColField) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(ColField==NULL || ColField->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). UField argument NULL or erroneous.\n");
        return U_ERROR;
    }
    int NP = ColField->GetNpoints();
    int VL = GetNColChan();
    if(ColField->GetDType()!=UField::U_BYTE || ColField->GetBdata()==NULL ||
       ColField->GetVeclen()!=VL            || NP<=0)
    {
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). UField argument NULL of wrong type (%s) .\n", (const char*)ColField->GetProperties(""));
        return U_ERROR;
    }
    unsigned char* CIndex = new unsigned char[NP];
    if(CIndex==NULL)
    {
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). Memory allocation: NP = %d .\n", NP);
        return U_ERROR;
    }
    for(int i=0; i<NP; i++) CIndex[i] = 0;
    
    if(ComputeIndexImage(ColField->GetBdata(), NP, VL, CIndex)!=U_OK)
    {
        delete[] CIndex;
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). Converting image.\n");
        return U_ERROR;
    }
    if(ColField->SetData(CIndex, 1)!=U_OK)
    {
        delete[] CIndex;
        CI.AddToLog("ERROR: UColorConvert::ConvertField(). Setting converted data.\n");
        return U_ERROR;
    }
    delete[] CIndex;
    return U_OK;
}