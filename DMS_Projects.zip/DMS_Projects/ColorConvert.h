#ifndef _COLORCONVERT_INCLUDED
#define _COLORCONVERT_INCLUDED

#include"BasicInclude.h"

class UBlockByte;
class UField;
class DLL_IO UColorConvert
{
public:
    UColorConvert();
    UColorConvert(unsigned char* ColorImage, int NPoints, int NCol, int TableSize);
    UColorConvert(const UColorConvert& CC);
    ~UColorConvert();
    UColorConvert&        operator=(const UColorConvert& CC);
    
    int                   GetError(void) const   {if(this) return error; return U_ERROR;}
    int                   GetNColChan(void) const;
    int                   GetTabSize(void) const {if(this) return TabSize; return 0;}
    const unsigned char*  GetColTable(void) const;
    ErrorType             ComputeIndexImage(const unsigned char* ColorImage, int NPoints, int NCol, unsigned char* IndexImage) const;
    ErrorType             ConvertField(UField* ColField) const;
    
protected:
    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    ErrorType             error;
    UBlockByte*           CRoot;
    int                   TabSize;
    unsigned char*        ColTable;
};

#endif // _COLORCONVERT_INCLUDED

