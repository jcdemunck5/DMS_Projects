/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a 3D conductor, C++ version.                       */
/*     The conductor consists of a set of nested surfaces. Of each of these      */
/*     surfaces, the inner conductivity can be set directly, the outer           */
/*     conductivities can be set by determining the "topology" of the surfaces,  */
/*     using SetTopology().                                                      */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    30-09-98   creation 
  Jdm    17-10-98   Updated dependence of include files
  JdM    24-04-99   Added GetProperties() 
  JdM    07-06-99   Added Transform()
  JdM    16-06-99   Added FitSphere()
  JdM    27-03-00   operator==() : Test whether this==&d
  JdM    19-05-00   Added GetInnerSurf()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    25-10-00   Bug Fix: AddSurface: Take curvature information into account using copy constructors
  JdM    13-11-00   Added LocalRefine()
  JdM    16-11-00   Split GetProperties() and SetTopology()
  JdM    19-11-00   Added SetSigma() and renamed SetConductivity() into SetInnerConductivity()
  JdM    22-12-00   Added FitConcentricSpheres()
  JdM    12-04-00   Added new ReplaceSurface()
JdM/SG   01-05-01   Bug Fix: LocalRefine(). Update Npoints.
  JdM    10-05-01   Added Crop() and GetNpoints()
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    27-02-05   Added GetFirstChild() and Are ConductivitiesOK()
                    Added SetAllMembersDefault(), DeleteAllMembers(). Use UString for GetProperties()
  JdM    27-12-06   Bug fix: operator=() copying nested surfaces.
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    02-11-07   GetSurface(): return const *
  JdM    11-11-07   Remove one of the GetSurface() functions and made the other const
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    25-12-09   Added UseL1norm argument to various sphere fitting functions
  JdM    03-03-10   GetSurfIndex(). Test this==NULL and avoid MAXSURFNAME
  JdM    15-01-12   bug fix DeleteAllMembers(). Set error=E, iso error = U_ERROR
  JdM    04-02-14   Added GetSigma()
  JdM    25-05-15   Added WriteBinary() and FILE* constructor to UConductor3
  JdM    24-06-15   Added ProjectConcentricSpheres()
  JdM    25-06-15   Added RemoveSharpestTriangles()
  JdM    20-08-15   Added GetConductivity(UVector3)
  JdM    01-06-18   Added SwapSurfaces()
  JdM    03-06-18   Removed (obsolete) Npoints member, and GetNpoints() function. Keep Npoints in binary data format
  JdM    01-06-18   Made SwapSurfaces() protected
  */
 
#include <string.h>
#include "GridFit.h"
#include "Conductor3.h"

/* Inititalize static (const) parameters. */
UString      UConductor3::Properties  = UString();
const char*  UConductor3::HEADERBEGIN = "Conductor1.0";
const char*  UConductor3::HEADEREND   = "ConductorEnd";
const int    UConductor3::CAULIFLOWER = -1;

#define MAXSURFACE 10

void UConductor3::SetAllMembersDefault(void)
{
    Properties  =  UString();
    TopologySet =  false;
    error       =  U_OK;
    Nsurfaces   =  0;
    OuterSurf   = -1; // Undermined
    pSurface    =  NULL;
}

void UConductor3::DeleteAllMembers(ErrorType E)
{
    if(pSurface)
        for(int ic=0;ic<MAXSURFACE;ic++)  delete pSurface[ic];
    delete[] pSurface;
    SetAllMembersDefault();
    error = E;
}

UConductor3::UConductor3()
{
    SetAllMembersDefault();

    pSurface   = new UNestedSurface*[MAXSURFACE];
    if(pSurface==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int ic=0;ic<MAXSURFACE;ic++)  
    {
        pSurface[ic] = new UNestedSurface();
        if(pSurface[ic]==NULL || pSurface[ic]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConductor3::UConductor3(). Initializing surface %d .\n", ic);
            return;
        }
    }
}

UConductor3::UConductor3(const UConductor3 &C)
{
    SetAllMembersDefault();
    *this = C;
}

UConductor3::UConductor3(FILE* fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConductor3::UConductor3(). Invalid NULL pointer. \n");
        return;
    }
    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UConductor3::UConductor3(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }
    int NpointsDum  =::ReadBinaryInt (DefaultIntelData, fpIn);
    Nsurfaces       =::ReadBinaryInt (DefaultIntelData, fpIn);
    OuterSurf       =::ReadBinaryInt (DefaultIntelData, fpIn);
    TopologySet     =::ReadBinaryBool(DefaultIntelData, fpIn);

    if(Nsurfaces<0 || Nsurfaces>=MAXSURFACE)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UConductor3::UConductor3(). Nsurfaces (%d) out of range. \n", Nsurfaces);
        return;
    }
    pSurface = new UNestedSurface*[MAXSURFACE];
    if(pSurface==NULL)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UConductor3::UConductor3(). Memory allocation, MAXSURFACE = %d . \n", MAXSURFACE);
        return;
    }
    for(int is=0; is<MAXSURFACE; is++) pSurface[is] = NULL;
    for(int is=0; is<Nsurfaces; is++) 
    {
        pSurface[is] = new UNestedSurface(fpIn);
        if(pSurface[is]==NULL || pSurface[is]->GetError()!=U_OK)
        {
            for(int iis=0; iis<Nsurfaces; iis++) {delete pSurface[iis]; pSurface[iis] = NULL;}

            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UConductor3::UConductor3(). Reading surface  %d (of %d). \n", is, Nsurfaces);
            return;
        }
    }
    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        UConductor3::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UConductor3::UConductor3(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }
}
ErrorType UConductor3::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    int NpointsDum = 0;
    ::WriteBinary(NpointsDum , DefaultIntelData, fpOut);
    ::WriteBinary(Nsurfaces  , DefaultIntelData, fpOut);
    ::WriteBinary(OuterSurf  , DefaultIntelData, fpOut);
    ::WriteBinary(TopologySet, DefaultIntelData, fpOut);
    if(Nsurfaces>0 && pSurface)
    {
        for(int is=0; is<Nsurfaces; is++)
        {
            if(pSurface[is]==NULL || pSurface[is]->WriteBinary(fpOut)!=U_OK)
            {
                CI.AddToLog("ERROR: UConductor3::WriteBinary(). Writing surface %d. \n", is);
                return U_ERROR;
            }
        }
    }
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UConductor3::~UConductor3() 
{
    DeleteAllMembers(U_OK);
}

UConductor3& UConductor3::operator=(const UConductor3 &r)
{
    if(this==NULL)
    {
        static UConductor3 C; C.error = U_ERROR;
        CI.AddToLog("ERROR: UConductor3::operator=(). this==NULL . \n");
        return C;
    }
    if(&r==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConductor3::operator=(). Invalid NULL Address argument. \n");
        return *this;
    }
    if(this==&r) return *this;

    DeleteAllMembers(U_OK);
    pSurface    = new UNestedSurface*[MAXSURFACE];
    if(pSurface==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConductor3::operator=(). Memory allocation, MAXSURFACE = %d. \n", MAXSURFACE);
        return *this;
    }
    for(int ic=0;ic<MAXSURFACE;ic++)  
    {
        pSurface[ic] = new UNestedSurface();
        if(pSurface[ic]==NULL || pSurface[ic]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConductor3::operator=(). Initializing surface %d .\n", ic);
            return *this;
        }
    }
/* Start copying. */
    TopologySet =  r.TopologySet;
    error       =  r.error;
    OuterSurf   =  r.OuterSurf;
    Nsurfaces   =  r.Nsurfaces;

    for(int i=0;i<r.Nsurfaces;i++)
    {
        delete pSurface[i];
        pSurface[i] = new UNestedSurface(*(r.pSurface[i]));
        if(pSurface[i]==NULL || pSurface[i]->GetError() != U_OK) 
        {
            CI.AddToLog("ERROR: UConductor3::operator=(). Copying surface %d .\n", i);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }  
    return *this;
}

bool UConductor3::operator==(const UConductor3 &r) const
/*
    Return true iff both conductors are "equal", i.e. iff
    they have the same contour names and the same topology.
 */
{
    if(OuterSurf != r.OuterSurf) return false;
    if(Nsurfaces != r.Nsurfaces) return false;
    
    for(int ic=0;ic<Nsurfaces;ic++)
    {
        const UNestedSurface*  gr=r.GetSurface(ic);
        if(strncmp(GetSurface(ic)->GetName(),gr->GetName(),32)) return false;
        if(GetSurface(ic)->GetParent()!=gr->GetParent()) return false;
        if(GetSurface(ic)->GetNchild()!=gr->GetNchild()) return false;
        for(int k=0;k<GetSurface(ic)->GetNchild();k++)
            if(GetSurface(ic)->GetNextChild(k)!=gr->GetNextChild(k)) return false;
    }
    return true;
}

int UConductor3::GetSurfIndex(const char* SurfName) const
/*
     Return the index of the surface carrying the name SurfName[]. If that
     surface does not exist, return -1;
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::GetSurfIndex(). Object NULL or erroneous.\n");
        return -1;
    }
    if(pSurface==NULL || Nsurfaces<0)
    {
        CI.AddToLog("ERROR: UConductor3::GetSurfIndex(). Surfaces not (properly) set (Nsurfaces = %d ).\n", Nsurfaces);
        return -1;
    }
    if(SurfName==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::GetSurfIndex(). Invalid NULL argument. \n");
        return -1;
    }
    for(int is=0; is<Nsurfaces; is++)
        if(IsStringCompatible(pSurface[is]->GetName(), SurfName, true )==true) return is;

    for(int is=0; is<Nsurfaces; is++)
        if(IsStringCompatible(pSurface[is]->GetName(), SurfName, false)==true) return is;
    return -1;
}

int UConductor3::GetFirstChild(int iSurface)
{
    if(iSurface<0 || iSurface>=Nsurfaces) 
    {
        CI.AddToLog("ERROR: UConductor3::GetFirstChild(). Argument out of range: iSurface = %d \n", iSurface);
        return -1;
    }
    if(pSurface[iSurface]==NULL || pSurface[iSurface]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::GetFirstChild(). Surface not (properly) set: iSurface = %d \n", iSurface);
        return -1;
    }
    SetTopology();
    return pSurface[iSurface]->GetNextChild(0);
}

ErrorType UConductor3::Transform(UEuler eul)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    for(int is=0; is<Nsurfaces; is++)
        if(Transform(eul, is)!=U_OK) return U_ERROR;

    return U_OK;
}
ErrorType UConductor3::Transform(UEuler eul, int isurf)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(isurf<0 || isurf>=Nsurfaces)
    {
        CI.AddToLog("ERROR: UConductor3::Transform(). Parameter out of range: isurf = %d .\n", isurf);
        return U_ERROR;
    }
    if(pSurface[isurf]==NULL || pSurface[isurf]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::Transform(). Surface %d is NULL or erroneous.\n", isurf);
        return U_ERROR;
    }
    return pSurface[isurf]->Transform(eul);
}
ErrorType UConductor3::SwapSurfaces(int is1, int is2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(pSurface==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::SwapSurfaces(). Surface array not set.\n");
        return U_ERROR;
    }

    if(is1<0 || is1>=Nsurfaces || is2<0 || is2>=Nsurfaces)
    {
        CI.AddToLog("ERROR: UConductor3::SwapSurfaces(). Parameter(s) out of range: is1 = %d, is2=%d.\n", is1, is2);
        return U_ERROR;
    }
    if(is1==is2) return U_OK;

    UNestedSurface* pDum = pSurface[is1];
    pSurface[is1]        = pSurface[is2];
    pSurface[is2]        = pDum;

    return SetTopology();
}

ErrorType UConductor3::AddSurface(const UNestedSurface* gamma)
{
    if(gamma==NULL) return U_ERROR;

    TopologySet = false;
    
    delete pSurface[Nsurfaces];
    pSurface[Nsurfaces]  = new UNestedSurface(*gamma);

    if(pSurface[Nsurfaces]==NULL || pSurface[Nsurfaces]->GetError()!=U_OK)
    {
        delete pSurface[Nsurfaces]; pSurface[Nsurfaces] = NULL;
        CI.AddToLog("ERROR: UConductor3::AddSurface().\n");
        return U_ERROR;
    }
    Nsurfaces++;
    return U_OK;
}

ErrorType UConductor3::AddSurface(UVector3* plist, int np, int* tril, int ntr, double cond, const char *gname)	  
{
    TopologySet = false;

/* Set Countour*/	
    UNestedSurface SurfaceTmp(plist, np, tril, ntr, cond, gname);
    if(SurfaceTmp.GetError()!=U_OK)  return U_ERROR;
    
/* Copy yje contour and update the total number of contours in the conductor*/
    delete pSurface[Nsurfaces];
    *pSurface[Nsurfaces++]  = SurfaceTmp;

    return SetTopology();
}

ErrorType UConductor3::ReplaceSurface(int iSurface,const USurface &S)
{
    if(iSurface<0 || iSurface>=Nsurfaces) 
    {
        CI.AddToLog("ERROR: UConductor3::ReplaceSurface(). iSurface index out of range: %d   .\n",iSurface);
        return U_ERROR;
    }
    TopologySet = false;
    OuterSurf   = -1; // Undetermined

    *pSurface[iSurface]  = S;

    return SetTopology();
}

ErrorType UConductor3::ReplaceSurface(int iSurface, const UConductor3 &r)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(iSurface<0 || iSurface>=Nsurfaces) 
    {
        CI.AddToLog("ERROR: UConductor3::ReplaceSurface(). iSurface index out of range: %d   .\n",iSurface);
        return U_ERROR;
    }
    if(&r==NULL || r.GetError()!=U_OK) return U_ERROR;
    if(iSurface<0 || iSurface>=r.GetNsurfaces()) 
    {
        CI.AddToLog("ERROR: UConductor3::ReplaceSurface(). iSurface index out of range: %d   .\n",iSurface);
        return U_ERROR;
    }
    UNestedSurface* S = new UNestedSurface(*r.GetSurface(iSurface) );
    if(S==NULL || S->GetError()!=U_OK)
    {
        delete S;
        CI.AddToLog("ERROR: UConductor3::ReplaceSurface(). Copying iSurface %d from argument \n", iSurface);
        return U_ERROR;
    }

    TopologySet = false;
    OuterSurf   = -1; // Undetermined
    
    delete pSurface[iSurface];  pSurface[iSurface]  = S;

    return SetTopology();
}

double* UConductor3::GetSigma(void) const
{
    if(this==NULL || error!=U_OK) return NULL;

    if(Nsurfaces<=0 || pSurface==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::GetSigma(). Surfaces not set (Nsurfaces=%d). \n", Nsurfaces);
        return NULL;
    }
    double* Sigma = new double[Nsurfaces];
    if(Sigma==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::GetSigma(). Memory allocation (Nsurfaces=%d). \n", Nsurfaces);
        return NULL;
    }

    for(int is=0; is<Nsurfaces; is++) Sigma[is] = 0.;

    for(int is=0; is<Nsurfaces; is++)
    {
        if(pSurface[is]==NULL || pSurface[is]->GetError()!=U_OK) continue;
        Sigma[is] = pSurface[is]->GetInnerCond();
    }
    for(int is=0; is<Nsurfaces; is++)
    {
        if(Sigma[is]>0.) continue;
        delete[] Sigma;
        CI.AddToLog("ERROR: UConductor3::GetSigma(). Erroneous conductivity (is=%d). \n", is);
        return NULL;
    }
    return Sigma;
}

ErrorType UConductor3::SetSigma(const double* Sigma)
/*
    Set the conductivities of all inner and outer surfaces of the conductor.
    Set the topology if necessary.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Sigma==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::SetSigma(). NULL argument.\n");
        return U_ERROR;
    }
    if(TopologySet==false)
    {
        if(SetTopology()!=U_OK)
        {
            CI.AddToLog("ERROR: UConductor3::SetSigma(). Setting topology.\n");
            return U_ERROR;
        }
    }
    TopologySet=true;
    
    for(int is=0; is<Nsurfaces; is++) 
        pSurface[is]->SetInnerCond(Sigma[is]);

    for(int is=0; is<Nsurfaces; is++) 
    {    
        if((pSurface[is])->GetParent() == CAULIFLOWER) 
            (pSurface[is])->SetOuterCond(0.);
        else
            (pSurface[is])->SetOuterCond( (pSurface[(pSurface[is])->GetParent()])->GetInnerCond() );
    }
    return U_OK;
}

ErrorType UConductor3::SetInnerConductivity(int iSurface, double cond)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    TopologySet = false;

    if(cond<0.) return U_ERROR;
    if(iSurface<0 || iSurface>=Nsurfaces) return U_ERROR;
    pSurface[iSurface]->SetInnerCond(cond);
    return U_OK;
}
double UConductor3::GetConductivity(int iSurface) const 
{
    if(this==NULL || error!=U_OK) return -1.;
    if(iSurface<0 || iSurface>=Nsurfaces)
    {
        CI.AddToLog("ERROR: UConductor3::GetConductivity(). Parameter out of range, iSurface=%d \n", iSurface);
        return -1.;
    }
    return pSurface[iSurface]->GetInnerCond();
}
double UConductor3::GetConductivity(UVector3 x)
{
    if(this==NULL || error!=U_OK) return -1.;

    if(TopologySet==false && SetTopology()!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::GetConductivity(). Setting topology. \n");
        return -1.;
    }
    UNestedSurface* Sout = pSurface[GetOuterSurf()];
    if(Sout->IsInSurface(x)==false) return Sout->GetOuterCond();

    UNestedSurface* S = Sout;
    for(int idum=0; idum<Nsurfaces; idum++)
    {
        bool InChild = false;
        for(int k=0; k<S->GetNchild(); k++)
        {
            UNestedSurface* Sch = pSurface[S->GetNextChild(k-1)];
            if(Sch->IsInSurface(x))
            {
                InChild = true;
                S=Sch;
                break;
            }
        }
        if(NOT(InChild)) return S->GetInnerCond();
    }
    CI.AddToLog("ERROR: UConductor3::GetConductivity(). Search algorithm failed. \n");
    return -1;
}


const UNestedSurface*  UConductor3::GetSurface(int iSurface) const
{
    if(this==NULL || error!=U_OK)       return NULL;
    if(iSurface<0||iSurface>=Nsurfaces) return NULL;
    if(pSurface==NULL)                  return NULL;
    return pSurface[iSurface];
}

bool UConductor3::AreConductivitiesOK(void) const
{
    for(int is=0; is<Nsurfaces; is++)
    {
        if(pSurface[is]==NULL || pSurface[is]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UConductor3::AreConductivitiesOK(). Surface %d not (properly) set.\n", is);
            return false;
        }
        if(pSurface[is]->GetInnerCond() <= 0.)
        {
            CI.AddToLog("ERROR: UConductor3::AreConductivitiesOK(). Invalid conductivities at surface %s, Inner=%14.9f  .\n", pSurface[is]->GetName(), pSurface[is]->GetInnerCond() );
            return false;
        }
        if( pSurface[is]->GetOuterCond() <  0.      || 
           (pSurface[is]->GetOuterCond() <= 0. && pSurface[is]->GetParent()!=CAULIFLOWER))
        {
            CI.AddToLog("ERROR: UConductor3::AreConductivitiesOK(). Invalid conductivities at surface %s, Outer=%14.9f   .\n", pSurface[is]->GetName(), pSurface[is]->GetOuterCond());
            return false;
        }
        if(pSurface[is]->GetInnerCond() == pSurface[is]->GetOuterCond())
        {
            CI.AddToLog("ERROR: UConductor3::AreConductivitiesOK(). Inner and outer conductivities of shell %s are equal: %f  .\n", pSurface[is]->GetName(), pSurface[is]->GetOuterCond());
            return false;
        }
    }
    return true;
}

int UConductor3::GetOuterSurf(void)
{
    if(OuterSurf==-1) SetTopology();
    return OuterSurf;
}

int UConductor3::GetInnerSurf(void)
/*
     Return the index of the 'first' USurface() that does not contain other surfaces
 */
{
    SetTopology();

    int inner = -1;
    for(int is=0; is<Nsurfaces; is++)
        if(pSurface[is]->GetNchild()<=0) 
        {
            if(inner==-1) inner=is;
            else CI.AddToLog("WARNING: UConductor3::GetInnerSurf(). Ambiguous inner surfaces:%s\n",pSurface[is]->GetName());
        }

    return inner;
}

UVector3 UConductor3::FitSphere(int isurf, double* Radius, double* Error, bool UseL1norm) const
/*
     Fit a sphere to surface isurf and return the best fitting sphere position.
     if(Radius) return the best fitting radius in *Radius
     if(Error)  return the fit-error [cm] in *Error
 */
{
    if(isurf<0 || isurf>=Nsurfaces)
    {
        if(Radius) *Radius = -1.;
        if(Error)  *Error  = -1.;
        return UVector3();
    }
    return pSurface[isurf]->FitSphere(Radius, Error, UseL1norm);
}

ErrorType UConductor3::Crop(UVector3 Minco, UVector3 Maxco)
/*
    Crop each of the surfaces constituting the conductor. Reset the topology.
 */
{
    TopologySet = false;

    for(int is =0; is<Nsurfaces; is++)
        if(pSurface[is]->Crop(Minco, Maxco)!=U_OK)
        {
            CI.AddToLog("ERROR UConductor3::Crop(). Cropping surface %d .\n",is);
            return U_ERROR;
        }

    return SetTopology();
}

ErrorType UConductor3::LocalRefine(double MaxDistance, UGrid* Grid)
/* 
    Locally refine the meshes in the neighborhood of the points of *Grid.
    See USurface::LocalRefine() for details.
 */
{
    for(int is=0; is<Nsurfaces; is++)
    {
        if(pSurface[is]->LocalRefine(MaxDistance, Grid)!=U_OK) 
        {
            CI.AddToLog("ERROR: UConductor3::LocalRefine(). Surface = %d \n",is);
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UConductor3::LocalRefine(double MaxDistance, UVector3* Pts, int Npts)
/* 
    Locally refine the meshes in the neighborhood of any of the Npoints points Pts[].
    See USurface::LocalRefine() for details.
 */
{
    for(int is=0; is<Nsurfaces; is++)
    {
        if(pSurface[is]->LocalRefine(MaxDistance, Pts, Npts)!=U_OK) 
        {
            CI.AddToLog("ERROR: UConductor3::LocalRefine(). Surface = %d \n",is);
            return U_ERROR;
        }
    }
    return U_OK;
}

const UString& UConductor3::GetProperties(UString Comment) const
/*
     Print the topology properties and conductivities into the Properties string.
     return a pointer to that string.
 */
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UConductor3-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(" UConductor3 properties:  \n");
    if(TopologySet==false) Properties += UString(" Note: Topology not set. \n");
    Properties += UString(Nsurfaces, " Nsurfaces = %d . \n");

    for(int ic=0;ic<Nsurfaces;ic++)
    {
        if(pSurface[ic]==NULL || pSurface[ic]->GetError()!=U_OK)
        {
            Properties += UString(ic, " Erroneous surface %d \n");
            continue;
        }
        if(pSurface[ic]->GetParent()==CAULIFLOWER)
            Properties += UString((pSurface[ic])->GetName()) + UString(" enclosed by UNIVERSE \n");
        else
            Properties += UString((pSurface[ic])->GetName()) + UString(" enclosed by ") + UString((pSurface[(pSurface[ic])->GetParent()])->GetName()) + UString(" \n"); 

        UString PS(pSurface[ic]->GetProperties(" "));
        PS.InsertAtEachLine("   ");
        Properties += PS;
    }
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UConductor3::SetTopology()
/*
    Cheque whether the conductor is consistent, 
    set the topology parameters (parents and children) and
    set the outer conductivity of each contour. 
 */
{
    const int EMPTY = -123;  /* used to indicate that a descendent has not yet been set*/
    
    int   descend[MAXSURFACE*MAXSURFACE];
    for(int i=0;i<Nsurfaces*Nsurfaces;i++) descend[i]= EMPTY;

    for(int ic1=0;ic1<Nsurfaces;ic1++)
    {
        for(int ic2=ic1+1;ic2<Nsurfaces;ic2++)
        {

/* Test if all points of contour ic1 are on the same side of contour ic2 */
            bool Inside = true;
            if(pSurface[ic2]->AllInsideOrAllOutside(pSurface[ic1], &Inside)==false)
            {
                CI.AddToLog("ERROR: UConductor3::SetTopology(). %s and %s are crossing\n",(pSurface[ic1])->GetName(), (pSurface[ic2])->GetName());
                return U_ERROR;
            }
            if(Inside==true) 
                descend[ic1+ic2*Nsurfaces] = ic1;            // ic1 inside ic2 
            else 
                if((pSurface[ic1])->IsInSurface( ((UPointList*)(pSurface[ic2]))->GetPoint(0))) 
                    descend[ic2+ic1*Nsurfaces] = ic2;        // ic2 inside ic1 
        }
   }

/* Determine the generation of each contour */
    int   gener[MAXSURFACE],children[MAXSURFACE];

    for(int i=0;i<Nsurfaces;i++) gener[i]=0;
    for(int i=0;i<Nsurfaces*Nsurfaces;i++) if(descend[i]!=EMPTY) gener[descend[i]]++;

/* Determine the surface which has no parent */
    OuterSurf = -1;
    for(int ic1=0;ic1<Nsurfaces;ic1++)     
        if(gener[ic1]==0)
        {
            if(OuterSurf!=-1)
            {
                CI.AddToLog("ERROR: UConductor3::SetTopology(). Both %s border to infinity %s \n", (pSurface[OuterSurf])->GetName(), (pSurface[ic1])->GetName());
                return U_ERROR;
            }
            else
            {
                (pSurface[ic1])->SetParent(CAULIFLOWER);
                OuterSurf = ic1;
            }
        }

    if(OuterSurf==-1)
    {
        CI.AddToLog("ERROR: UConductor3::SetTopology(). There is no surface bordering to infinity.\n");	
        return U_ERROR;
    }

/* Set the default number of children*/
    for(int ic1=0;ic1<Nsurfaces;ic1++) (pSurface[ic1])->SetNchild(0);

/* Determine the rest of the parent structure */
    for(int gen=0;gen<Nsurfaces-1;gen++)     // Loop over all generations 
    {
        for(int ic2=0;ic2<Nsurfaces;ic2++)
        {
            if(gener[ic2]==gen)         // Contour ic2 has the right generation 
            {
                int nch = 0;
                for(int ic1=0;ic1<Nsurfaces;ic1++)
                {
                    int i = descend[ic1+ic2*Nsurfaces];
                    if(i==ic1 && gener[i]==gen+1) // Contour ic1 is a direct descendant of ic2 
                    {
                        (pSurface[ic1])->SetParent(ic2);
                        children[nch] = ic1;
                        nch++;
                    }
                }
                if((pSurface[ic2])->SetNchild(nch,children)!=U_OK)
                {
                    CI.AddToLog(Properties,"ERROR: UConductor3::SetTopology(). Memory allocation. \n");
                    return U_ERROR;
                }
            }
        }
    }

/* Store the outside conductivities. The universe is treated separately. 
   The outer conductivity of other contours are equal to the inner conductivity of 
   their parents.
*/ 
    for(int ic1=0;ic1<Nsurfaces;ic1++)
    {
        if((pSurface[ic1])->GetParent() == CAULIFLOWER) 
            (pSurface[ic1])->SetOuterCond(0.);
        else
            (pSurface[ic1])->SetOuterCond( (pSurface[(pSurface[ic1])->GetParent()])->GetInnerCond() );
    }
    TopologySet = true;

    return U_OK;
}

ErrorType UConductor3::RemoveSharpestTriangles(double FracRemove)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::RemoveSharpestTriangles(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nsurfaces<=0 || Nsurfaces>MAXSURFACE)
    {
        CI.AddToLog("ERROR: UConductor3::RemoveSharpestTriangles(). Nsurfaces (=%d) out of range. \n",Nsurfaces);
        return U_ERROR;
    }
    if(FracRemove<0. || FracRemove>=1.)
    {
        CI.AddToLog("ERROR: UConductor3::RemoveSharpestTriangles(). Fraction parameter out of range (%f). \n",FracRemove);
        return U_ERROR;
    }
    for(int k=0; k<Nsurfaces; k++)
    {
        if(pSurface[k]->RemoveSharpestTriangles(FracRemove)<0)
        {
            CI.AddToLog("ERROR: UConductor3::RemoveSharpestTriangles(). Processing surface %d. \n", k);
            return U_ERROR;
        }
    }
    return U_OK;
}
ErrorType UConductor3::ProjectConcentricSpheres(bool UseL1norm)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::ProjectConcentricSpheres(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nsurfaces<=0 || Nsurfaces>MAXSURFACE)
    {
        CI.AddToLog("ERROR: UConductor3::ProjectConcentricSpheres(). Nsurfaces (=%d) out of range. \n",Nsurfaces);
        return U_ERROR;
    }

    double Radii[MAXSURFACE];
    for(int k=0; k<MAXSURFACE; k++) Radii[k] = 0.;

    double   Error  = 0.;
    UVector3 Center = FitConcentricSpheres(Radii, &Error, UseL1norm);
    if(Error<0.)
    {
        CI.AddToLog("ERROR: UConductor3::ProjectConcentricSpheres(). Fitting spheres. \n");
        return U_ERROR;
    }
    for(int k=0; k<Nsurfaces; k++)
    {
        if(pSurface[k]->ProjectSphere(Center, Radii[k])!=U_OK)
        {
            CI.AddToLog("ERROR: UConductor3::ProjectConcentricSpheres(). Projecting surface %d onto sphere with radius %f. \n", k, Radii[k]);
            return U_ERROR;
        }
    }
    return U_OK;
}

UVector3 UConductor3::FitConcentricSpheres(double* Radii, double* Error, bool UseL1norm) const 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConductor3::FitConcentricSpheres(). Object NULL or erroneous. \n");
        if(Error) *Error = -1;
        return UVector3();
    }
    if(Nsurfaces<=0)
    {
        CI.AddToLog("ERROR: UConductor3::FitConcentricSpheres(). Nsurfaces (=%d) out of range. \n",Nsurfaces);
        if(Error) *Error = -1;
        return UVector3();
    }
    if(Radii==NULL || Error==NULL)
    {
        CI.AddToLog("ERROR: UConductor3::FitConcentricSpheres(). NULL arguments. \n");
        if(Error) *Error = -1;
        return UVector3();
    }

/* Compute starting values*/
    double par[MAXSURFACE+4];
    for(int n=0; n<MAXSURFACE+4; n++) par[n] = 0.;

    for(int n=0; n<Nsurfaces; n++)
    {
        UVector3 C = FitSphere(n, par+3+n, NULL, UseL1norm);
        par[0] += C.Getx();
        par[1] += C.Gety();
        par[2] += C.Getz();
    }
    par[0] /= Nsurfaces;
    par[1] /= Nsurfaces;
    par[2] /= Nsurfaces;
    
    UFitSpheres FS(pSurface, Nsurfaces, UseL1norm);
    if(FS.Iterate(par, 3+Nsurfaces, 6.) != U_OK) 
    {
        CI.AddToLog("ERROR: UConductor3::FitConcentricSpheres(). Fitting spheres to surfaces. \n");
        if(Error)  *Error = -1.;
        return UVector3();
    }

/* Copy result to output */
    for(int n=0; n<Nsurfaces; n++) Radii[n] = par[3+n];
    if(Error)  *Error  = FS.ComputeCost(par,-1);

    return UVector3(par);
}
UConductor3::UFitSpheres::UFitSpheres(const UNestedSurface *const*pSurface, int Nsurf, bool UseL1norm) : 
    Uminimize(UCostminimize()) 
{ 
    L1norm = UseL1norm;
    SurfAr = pSurface; 
    Ns     = Nsurf;
}

double UConductor3::UFitSpheres::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    double cost = 0;
    int    Np   = 0;
    if(L1norm)
    {
        for(int n=0; n<Ns; n++)
        {
            Np += SurfAr[n]->GetNpoints();

            for(int i=0; i<SurfAr[n]->GetNpoints(); i++)
            {
                UVector3 x  = ((UPointList*)SurfAr[n])->GetPoint(i)-UVector3(par);            
                cost       += fabs(x.GetNorm()-par[3+n]);
            }
        }
        if(Np) cost/=Np;
    }
    else
    {
        for(int n=0; n<Ns; n++)
        {
            Np += SurfAr[n]->GetNpoints();

            for(int i=0; i<SurfAr[n]->GetNpoints(); i++)
            {
                UVector3 x  = ((UPointList*)SurfAr[n])->GetPoint(i)-UVector3(par);            
                cost       += (x.GetNorm()-par[3+n])*(x.GetNorm()-par[3+n]);
            }
        }
        if(Np) cost/=Np;
        cost = sqrt(fabs(cost));
    }
    return cost;
}