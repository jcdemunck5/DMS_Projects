#ifndef _CONDUCTOR3_INCLUDED
#define _CONDUCTOR3_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "NestedSurface.h"
#include "String.h"

class DLL_IO UConductor3
{
public:
    UConductor3();
    UConductor3(FILE* fpIn);
    UConductor3(const UConductor3 &q );
    virtual ~UConductor3();
    
    UConductor3& operator=(const UConductor3 &r);
    bool operator==(const UConductor3 &r) const;
    bool operator!=(const UConductor3 &r) const {if(operator==(r)==false) return true; else return false;}

    ErrorType             GetError() const           {return error;}
    const UString&        GetProperties(UString Comment) const;

    int                   GetNsurfaces(void)const    {return Nsurfaces;}
    int                   GetSurfIndex(const char* SurfName) const;

    ErrorType             AddSurface(UVector3 *p, int np, int* trlist, int ntr, double cond=1., const char* name=NULL);
    ErrorType             AddSurface(const UNestedSurface* gamma);
    ErrorType             AddSurface(const UNestedSurface& gamma) {return AddSurface(&gamma);}
    ErrorType             ReplaceSurface(int iSurface, const USurface &S);
    ErrorType             ReplaceSurface(int iSurface, const UConductor3 &r);
    int                   GetFirstChild(int iSurface);

    bool                  AreConductivitiesOK(void) const;
    ErrorType             SetInnerConductivity(int iSurface, double cond);
    double                GetConductivity(int iSurface) const;
    double                GetConductivity(UVector3 x);

    const UNestedSurface* GetSurface(int iSurface) const;
    int                   GetOuterSurf(void);
    int                   GetInnerSurf(void);

    UVector3              FitSphere(int isurf, double* Radius=NULL, double* Error=NULL, bool UseL1norm=true) const;
    UVector3              FitConcentricSpheres(double* Radii, double* Error, bool UseL1norm) const;
    ErrorType             ProjectConcentricSpheres(bool UseL1norm);
    ErrorType             RemoveSharpestTriangles(double FracRemove);
    ErrorType             Crop(UVector3 Minco, UVector3 Maxco);

    ErrorType             Transform(UEuler eul);
    ErrorType             Transform(UEuler eul, int isurf);
    ErrorType             LocalRefine(double MaxDistance, UGrid* Grid);
    ErrorType             LocalRefine(double MaxDistance, UVector3* Pts, int Npts);

    static const char*    GetFileHeader(void) {return HEADERBEGIN;}
    ErrorType             WriteBinary(FILE* fpOut) const;

    ErrorType             SetTopology(void);
protected:
    int                   Nsurfaces;    // Number of Nested Surfaces in the conductor
    UNestedSurface        **pSurface;   // Array of Surface pointers
    int                   OuterSurf;    // Index of the outermost surface
    bool                  TopologySet;  // This is true iff the current outer conductivities, childs 
                                        //  and parent correspond to the current surface topology

    ErrorType             SetSigma(const double* Sigma);
    double*               GetSigma(void) const;
    ErrorType             SwapSurfaces(int is1, int is2);

    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    static const char*    HEADERBEGIN;
    static const char*    HEADEREND;
    ErrorType             error;        // General error
    static UString        Properties;
    static const int      CAULIFLOWER;  // parent of contour bounding to infinity 

    class UFitSpheres : public Uminimize   // Object used to fit a sphere
    {
    public:
        UFitSpheres(const UNestedSurface *const *pSurface, int Nsurf, bool UseL1norm);
        double ComputeCost(double *par, int iter, int *status) 
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);    
    private:
        bool  L1norm;
        const UNestedSurface *const *SurfAr;
        int   Ns;
    };
};

#endif// _CONDUCTOR3_INCLUDED
