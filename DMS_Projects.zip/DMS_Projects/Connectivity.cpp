/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for connecting objects                                             */
/*                and mapping connectivity stats                                 */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Alle Meije Wink                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  AMW    02-12-10   Creation
  JdM    10-02-11   Lay out update, including deletion of pointers where possible.
                    ComputeMapping(). Remove obsolete argument
  JdM    04-09-15   Changed MatrixExplicit into MatrixCompExplicit and changed enum names, to avoid conflicts 
*/

#include <math.h>
#include <string.h>
#include "Connectivity.h"

UString      UConnectivity::Properties  = UString();

void UConnectivity::SetAllMembersDefault(void)
{
    Nobjects = 0;
    ConnMat  = NULL;
    Cmap     = NULL;
    error    = U_OK;
    SType    = U_SIM_NOTYPE;
    MType    = U_MAP_NOTYPE;
    MExpl    = U_MATCOMP_IMPLICIT;
}

void UConnectivity::DeleteAllMembers(ErrorType E)
{
    delete[] ConnMat;
    delete[] Cmap;
    SetAllMembersDefault();
    error = E;
}

UConnectivity::UConnectivity(SimilarityType ST, MappingType MT, MatrixCompExplicit ME)
{
    SetAllMembersDefault();

    if(ST!=U_SIM_MUTINF   && ST!=U_SIM_CORR)     SType  = U_SIM_NOTYPE;
    else                                         SType  = ST;

    if(MT!=U_MAP_EIGCENT  && MT!=U_MAP_DEGCENT)  MType  = U_MAP_NOTYPE;
    else                                         MType  = MT;

    if(ME!=U_MATCOMP_EXPLICIT && ME!=U_MATCOMP_IMPLICIT) MExpl = U_MATCOMP_UNKNOWN;
    else                                         MExpl = ME;
}

// copy
UConnectivity::UConnectivity(const UConnectivity& Conn)
{
    SetAllMembersDefault();
    *this = Conn; // uses operator= defined below
}

///////////////////////////////////////////////////////
// destructors

UConnectivity::~UConnectivity()
{
    DeleteAllMembers(U_OK);
}

///////////////////////////////////////////////////////
// operators

UConnectivity& UConnectivity::operator=(const UConnectivity& Conn)
{
// null pointer to current object -> not properly initialised
    if(this==NULL)
    {
        static UConnectivity Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: UConnectivity::operator=(). this==NULL. \n");
        return Def;
    }
// null pointer of copied object -> not properly initialised
    if(&Conn==NULL)
    {
        CI.AddToLog("ERROR: UConnectivity::operator=(). Argument has NULL address. \n");
        return *this;
    }

// if copied object and current object are the same, just return the address
    if(this==&Conn) return *this;

// check if any elements can be compared (i.e. exist and are nonzero)
    if(Conn.Nobjects < 0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivity::operator=(). Argument has invalid number of objecs: Conn.Nobjects=%d    . \n", Conn.Nobjects);
        return *this;
    }

// clean current object
    DeleteAllMembers(U_OK);

// copy number of nonzero elements and similarity measure
    Nobjects = Conn.Nobjects;
    SType    = Conn.SType;
    MType    = Conn.MType;
    MExpl    = Conn.MExpl;

// stop here if no comparable elements exist
    if(Nobjects <= 0)  return *this;

// if connectivity matrix of copied object exists -> copy to current object
    if(Conn.ConnMat)
    {
        ConnMat   = new float[1  + Nobjects*(Nobjects-1)/2]; // allocate block the size of required upper triangular matrix
        if(ConnMat==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConnectivity::operator=(). Memory allocation for Connectivity Matrix. Nobjects = %d  .\n", Nobjects);
            return *this;
        }
        for(int i = 0; i < Nobjects*(Nobjects-1) / 2; i++) ConnMat[i] = Conn.ConnMat[i];
    } // if Conn.ConnMat

    if(Conn.Cmap)
    {
        Cmap    = new float[Nobjects]; // allocate mappings for all nonzero elements
        if(Cmap == NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConnectivity::operator=(). Memory allocation for Statistic Mapping. Nobjects = %d  .\n", Nobjects);
            return *this;
        }

        for(int i = 0; i < Nobjects; i++) Cmap[i]  = Conn.Cmap[i];
    }
    return *this;
}

///////////////////////////////////////////////////////

ErrorType UConnectivity::ComputeMatrix(SimilarityType ST) // Use GetSimilarity() function of derived class
{
// null pointer to current object -> not properly initialised
    if(this == NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMatrix(). Object not properly initialyzed. \n");
        return U_ERROR;
    }

    if(ST!=U_SIM_NOTYPE)       SType = ST;

// check number of objects that can be compared
    Nobjects = GetNobjects(); // Get number of objects from derived class

    if(Nobjects<=0)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMatrix(). Number of objects out of range, Nobjects = %d  . \n", Nobjects);
        return error;
    }

    delete[] ConnMat;

// allocate required memory
    ConnMat = new float[1+Nobjects*(Nobjects-1)/2]; // Similarity array

    if(ConnMat == NULL)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMatrix(). Memory allocation. Nobjects = %d  . \n", Nobjects);
        return U_ERROR;
    }

    const bool usegetts = false;

    if(usegetts == true)
    {
        // Get Similarities from derived class
        long int q = 0;
        for(int i1 = 0; i1 < Nobjects; i1++)
        {
            if (!(q % 1000))  CI.AddToLog("%d of %d\n", (int)q, (int)Nobjects*(Nobjects - 1) / 2);

            for(int i2 = i1 + 1; i2 < Nobjects; i2++)
                ConnMat[q++] = (float)GetSimilarity(i1, i2);
        } // for i1
    }
    else
    {
        if(MakeConnectivityMatrix() != U_OK)
        {
            CI.AddToLog("ERROR: UConnectivity::ComputeMatrix(). Computation of matrix from scan data. \n", Nobjects);
            return U_ERROR;
        }
    }
    return U_OK;
}

///////////////////////////////////////////////////////

ErrorType UConnectivity::ComputeMapping(void)
{
// null pointer to current object -> not properly initialised
    if(this == NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMapping(). Object not properly initialyzed\n");
        return U_ERROR;
    }

    if(MExpl == U_MATCOMP_EXPLICIT && ConnMat == NULL)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMapping(). ConnMat needed for explicit matrix usage\n");
        return U_ERROR;
    }

// check number of objects that can be compared
    Nobjects = GetNobjects(); // Get number of objects from derived class

// null pointer to current object -> not properly initialised
    if(Nobjects <= 0)
    {
        CI.AddToLog("ERROR: UConnectivity::ComputeMapping(). No objects in scans!\n");
        return U_ERROR;
    }

    delete[] Cmap; // array that holds the mappings
    Cmap     = new float[Nobjects];
    float* w = new float[Nobjects];

    if(Cmap == NULL || w == NULL)
    {
        delete[] w;
        delete[] Cmap; Cmap = NULL;
        CI.AddToLog("ERROR: UConnectivity::ComputeMapping(). Memory allocation. \n");
        return U_ERROR;
    }

// see http://en.wikipedia.org/wiki/Power_iteration
//
// for (n=0; n<Nmax; n++) {               line 1
//  w=A*v;                                line 2
//  v=w/norm(w);                          line 3
// }

// initialise mappings with a straight line
    for(int i = 0; i < Nobjects; i++) Cmap[i] = w[i] = 1 / float(Nobjects);

    const int   Nmax  = 10;
    for(int n = 0; n < Nmax; n++) // line 1
    {
        CI.AddToLog("Note: UConnectivity::ComputeMapping(). Explicit: %d,\titeration %d,\tCmap[100]=%f\n", MExpl, n, Cmap[100]);

        switch(MExpl)
        {
        case U_MATCOMP_EXPLICIT:
            for(int i = 0; i < Nobjects; i++) // line 2
            {
                int counter = i, step = Nobjects - 2;             // step: distance between 2 points in the same column on row 1 and 2
                w[i] = 0;                                         // w[i] is going to contain A(:,:)*v_i(:)

                for(int j = 0; j < i; j++, counter += (step--))   // column i above diagonal
                    w[i] += Cmap[j] * ConnMat[counter-1];         //

                for(int j = i + 1; j < Nobjects; j++)             // row i right of diagonal
                    w[i] += Cmap[j] * ConnMat[counter++];         //

            }   // for i
            break;

        case U_MATCOMP_IMPLICIT:

            // line 2
            //
            // assume data Y[NxT] has mean 0 and variance 1
            //   then A[NxN]*v[Nx1] can be computed as Y[NxT]*(Y'[TxN]*v[Nx1])
            //   which requires much less storage (but A will not be available)
            //

            if (GetMaskedCovMatrixProduct(w) != U_OK)
            {
                CI.AddToLog("ERROR: UConnectivity::GetMaskedCovMatrixProduct(). \n");
                return U_ERROR;
            }
            break;

        } // switch
        
        float wnorm = 0.; // line 3
        float cnorm = 0.;

        for(int i = 0; i<Nobjects; i++)     wnorm  += w[i]*w[i];
    // normlisation of estimated vector by L2 norm gives node centrality,
    // see http://www.sciencedirect.com/science/article/pii/S0378873300000319
    // makes comparison between networks more objective
        if(wnorm>0.F) {
            wnorm=sqrtf(wnorm)*sqrtf(0.5);
          for(int i = 0; i<Nobjects; i++) w[i] /= wnorm;
        }   
        for(int i = 0; i<Nobjects; i++)     cnorm  += fabsf(w[i] - Cmap[i]);
        for(int i = 0; i<Nobjects; i++)     Cmap[i] = w[i];

        if (cnorm < 0.000001)  break;
    }   // for n
    delete[] w;
    return U_OK;
} // ComputeMapping

///////////////////////////////////////////////////////

const UString&  UConnectivity::GetProperties(UString Comment) const
{
    if(this==NULL || error != U_OK)
    {
        Properties = UString(" ERROR in UConnectivity-object\n");
        return Properties;
    }

    Properties  =  UString();
    Properties +=  UString(Nobjects, "Nobjects          = %d \n");

    switch(SType)
    {
        case U_SIM_MUTINF :  Properties += UString("SimMeasure        = MutualInformation \n"); break;
        case U_SIM_CORR   :  Properties += UString("SimMeasure        = Correlation \n");        break;
        default           :  Properties += UString("SimMeasure        = Unknown  \n");           break;
    }

    switch(MType)
    {
        case U_MAP_EIGCENT : Properties += UString("MapMeasure        = EigenvectorCentrality \n"); break;
        case U_MAP_DEGCENT : Properties += UString("MapMeasure        = DegreeCentrality \n");      break;
        default            : Properties += UString("MapMeasure        = Unknown \n");                break;
    }

    if(ConnMat)              Properties += UString("MatrixInitialised = TRUE \n");
    else                     Properties += UString("MatrixInitialised = FALSE\n");

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

bool UConnectivity::CanConnectivityBeComputed() const
{
    if(this == NULL || Nobjects <= 0 || error != U_OK)
        return false;

    return true;
}
