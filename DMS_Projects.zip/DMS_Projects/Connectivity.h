#ifndef _CONNECTIVITY_INCLUDED
#define _CONNECTIVITY_INCLUDED

#include "String.h"

/*********************************************************************************/
/*     Module for connecting objects                                             */
/*                and mapping connectivity stats                                 */
/*     Alle Meije Wink                                                           */
/*********************************************************************************/

/*
  Update history

  Who    When       What
  AMW    02-12-10   Creation
*/

///////////////////////////////////////////////////
// similarity measures for the connectivity matrix
enum SimilarityType 
{
    U_SIM_NOTYPE,
    U_SIM_MUTINF,
    U_SIM_CORR,
};

///////////////////////////////////////////////////
// connectivity measures for mapping
enum MappingType 
{
    U_MAP_NOTYPE,
    U_MAP_DEGCENT,
    U_MAP_EIGCENT,
};

///////////////////////////////////////////////////
// explicit matrix computation (memory intensive!) or not
enum MatrixCompExplicit 
{
    U_MATCOMP_UNKNOWN,
    U_MATCOMP_EXPLICIT,
    U_MATCOMP_IMPLICIT,
};

///////////////////////////////////////////////////////
// definition of class: properties and member functions
class DLL_IO UConnectivity 
{
public:
    UConnectivity(SimilarityType ST=U_SIM_NOTYPE, MappingType MT=U_MAP_NOTYPE, MatrixCompExplicit=U_MATCOMP_UNKNOWN);
    UConnectivity(const UConnectivity& Conn);

    virtual ~UConnectivity();

    virtual UConnectivity& operator=(const UConnectivity &Conn);

    const UString&     GetProperties(UString Comment) const;
    ErrorType          GetError(void) const                   {if(this) return error; return U_ERROR;}

protected:
    void               SetAllMembersDefault(void);
    void               DeleteAllMembers(ErrorType E);

    ErrorType          ComputeMatrix(SimilarityType ST=U_SIM_NOTYPE);
    ErrorType          ComputeMapping(void);
    bool               CanConnectivityBeComputed() const;

    SimilarityType     SType;
    MappingType        MType;
    MatrixCompExplicit MExpl;

    float*             Cmap;     // Mappable connectivity stat - such as Eigenvector Centrality
    float*             ConnMat;  // Connectivity matrix

private:
    static UString     Properties;
    ErrorType          error;
    int                Nobjects;

    virtual float      GetSimilarity(int i1, int i2)          {if(i1<0||i2<0) return 0.F; return 0.F;}
    virtual int        GetNobjects(void) const                {return 0;    }
    virtual ErrorType  GetMaskedCovMatrixProduct(float *map)  {if(map==NULL)  return U_ERROR; return U_OK;}
    virtual ErrorType  MakeConnectivityMatrix(void)           {return U_OK; }
};
#endif // _CONNECTIVITY_INCLUDED
