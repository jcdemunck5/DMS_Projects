/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for connecting 4D scans (e.g. MRI time series)                     */
/*                and mapping connectivity stats                                 */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Alle Meije Wink                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  AMW    02-12-10   Creation
  JdM    10-02-11   Lay out update, including deletion of pointers where possible.
                    Removed (obsolete) TemplScan. Made ScanList a deep copy of external UScalList.
                    GetMaskedCovMatrixProduct(), MakeConnectivityMatrix(). Consistently deal with Icomp. Do not assume float data in ScanList.
                    GetMapping(): Remove obsolete argument.
*/

#include <string.h>
#include "ConnectivityScans.h"
#include "ScanList.h"
#include "FieldGraph.h"

// initialise for every object
UString UConnectivityScans::Properties = UString();

void UConnectivityScans::SetAllMembersDefault()
{
    error      = U_OK;
    Properties = UString();
    ScanList   = NULL;
    NNonZero   = 0;
    ScanPoint  = NULL;
    Normalise  = false;
}
void UConnectivityScans::DeleteAllMembers(ErrorType E)
{
    delete[] ScanPoint;
    delete   ScanList;
    SetAllMembersDefault();
    error  = E;
}

UConnectivityScans::UConnectivityScans()   // default
{
    SetAllMembersDefault();
}

UConnectivityScans::UConnectivityScans(const UConnectivityScans& CS) : UConnectivity( (const UConnectivity&) CS)   // copy
{
    SetAllMembersDefault();
    *this = CS;
}

UConnectivityScans::UConnectivityScans(const UScanList& SL, int icomp, bool norm, SimilarityType ST, MatrixCompExplicit ME)   // initialised
{
    SetAllMembersDefault();
    if(&SL==NULL || SL.GetError()!=U_OK)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). UScanList argument NULL or erroneous. \n");
        return;
    }
    if(SL.IsScanList()==false)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). SL argument is not UScanList (but base-class). \n");
        return;
    }
    if(ST!=U_SIM_MUTINF && ST!=U_SIM_CORR)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Invalid similarity measure (%d). \n", ST);
        return;
    }
    if(ME!=U_MATCOMP_EXPLICIT && ME!=U_MATCOMP_IMPLICIT)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Invalid matrix storage (%d). \n", ST);
        return;
    }
    if(icomp<0 || icomp>=SL.GetVeclen())
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Icomp out of range (icomp=%d). \n", icomp);
        return;
    }
    Normalise  = norm;
    ScanList   = SL.GetComponent(icomp);
    if(ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Copying ScanList argument.\n");
        return;
    }
    NNonZero   = ScanList->GetNonZeroes(0, &ScanPoint);
    if(NNonZero<=0 || ScanPoint==NULL)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Getting indices for non-zero points (NNonZero=%d). \n", NNonZero);
        return;
    }
    CI.AddToLog("Note: UConnectivityScans::UConnectivityScans(). NNonZero = %d   .\n", NNonZero);
    SType = ST;
    MExpl = ME;
    if(MExpl==U_MATCOMP_EXPLICIT)
        if(UConnectivity::ComputeMatrix(SType)!=U_OK)
        {
            UConnectivity::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConnectivityScans::UConnectivityScans(). Initialising UConnectivity base class. \n");
            return;
        }
}

///////////////////////////////////////////////////////
// destructor

UConnectivityScans::~UConnectivityScans()
{
    DeleteAllMembers(U_OK);
}

///////////////////////////////////////////////////////
// operators

UConnectivityScans& UConnectivityScans::operator=(const UConnectivityScans& CS)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UConnectivityScans::operator=(). this==NULL  . \n");
        static UConnectivityScans Default; Default.error = U_ERROR;
        return Default;
    }
    if(&CS==NULL)
    {
        CI.AddToLog("ERROR: UConnectivityScans::operator=(). Invalid NULL pointer argument \n");
        error = U_ERROR;
        return *this;
    }
    if(this==&CS) return *this;
    SetAllMembersDefault();
    UConnectivity::operator=(CS);
    if(UConnectivity::GetError() != U_OK)
    {
        UConnectivity::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConnectivityScans::operator=(). Copying base class. \n");
        return *this;
    }

    error      = CS.error;
    NNonZero   = CS.NNonZero;
    Normalise  = CS.Normalise;
    if(CS.ScanList)
    {
        ScanList = new UScanList(*CS.ScanList);
        if(ScanList==NULL || ScanList->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            UConnectivity::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConnectivityScans::operator=(). Copying ScanList. \n");
            return *this;
        }
    }
    if(CS.ScanPoint)
    {
        ScanPoint = new int[NNonZero];
        if(ScanPoint==NULL)
        {
            DeleteAllMembers(U_ERROR);
            UConnectivity::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConnectivityScans::operator=(). ScanPoint index array. \n");
            return *this;
        }
        for(int n=0; n<NNonZero; n++) ScanPoint[n] = CS.ScanPoint[n];
    }
    return *this;
}

///////////////////////////////////////////////////////
// member functions

const UString&  UConnectivityScans::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UConnectivityScans-object\n");
        return Properties;
    }
    Properties =  UString();
    Properties += UString(NNonZero, "NNonZero     = %d \n");
    if(ScanList)
        Properties += UString(ScanList->GetScanName(), "ScanList     = %s\n");
    else
        Properties += UString(                         "ScanList     = Not Set \n");
    Properties += UString(BoolAsText(Normalise),       "Normalise    = %s \n");
    Properties += UString("  \n");
    Properties += UString("BaseClass:  \n");
    Properties += UConnectivity::GetProperties(Comment+UString("  "));

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

UScan* UConnectivityScans::GetMapping(void)
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMapping(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(NNonZero<=0 || ScanPoint==NULL || ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMapping(). Object not properly initialised. \n");
        return NULL;
    }
    if (UConnectivity::ComputeMapping()!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMapping(). Computing Connectivity indices. \n");
        return NULL;
    }
    
    UScan* ScanConn = new UScan(*(const UScan*)ScanList, true);
    if(ScanConn==NULL || ScanConn->GetError()!=U_OK || 
       ScanConn->ConvertData(UField::U_FLOAT)!=U_OK ||
       ScanConn->SetVeclen(1)!=U_OK || ScanConn->GetFdata()==NULL)
    {
        delete ScanConn;
        CI.AddToLog("ERROR: UConnectivityScans::GetMapping(). Copying or converting template. \n");
        return NULL;
    }

    float* ConnectivityData = ScanConn->GetFdata();
    int    Npoints          = ScanConn->GetNpoints();

// Set Connectivity data (which has size #nonnegative) and copy to image (which has size #points)
    for(int k=0; k<Npoints;  k++) ConnectivityData[k]            = 0.F; // Background
    for(int n=0; n<NNonZero; n++) ConnectivityData[ScanPoint[n]] = Cmap[n];

    ScanConn->SetScanName(UString(MType, "Connectivity_%d"));
    return ScanConn;
}

ErrorType UConnectivityScans::MakeConnectivityMatrix(void) 
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UConnectivityScans::MakeConnectivityMatrix(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    int Nscan    = ScanList->GetNscan();
    int Nobjects = GetNobjects();

    if(Nscan<=0 || Nobjects<=0 || ScanPoint==NULL || ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::MakeConnectivityMatrix(). Object not properly initialised. \n");
        return U_ERROR;
    }

    double ScaleNormalise = 1000.;
    if(ScanList->RemoveAverage(Normalise, ScaleNormalise)!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::MakeConnectivityMatrix(). Pre-processing ScanList. \n");
        return U_ERROR;
    }

// store the image data for each scan
    void** data = new void*[Nscan];
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UConnectivityScans::MakeConnectivityMatrix(). Memory allocation, Nscan = %d \n", Nscan);
        return U_ERROR;
    }
    ErrorType E = U_OK;
    for(int t=0; t<Nscan; t++) 
    {
        const UScan* tscan = ScanList->GetScan(t);
        if(tscan==NULL || tscan->GetError()!=U_OK) {E=U_ERROR; break;}
        
        switch(tscan->GetDType())
        {
        case UField::U_BYTE:    if(tscan->GetBdata()) data[t] = (unsigned char*) tscan->GetBdata(); else E=U_ERROR; break;
        case UField::U_SHORT:   if(tscan->GetSdata()) data[t] = (short        *) tscan->GetSdata(); else E=U_ERROR; break;
        case UField::U_INTEGER: if(tscan->GetIdata()) data[t] = (int          *) tscan->GetIdata(); else E=U_ERROR; break;
        case UField::U_FLOAT:   if(tscan->GetFdata()) data[t] = (float        *) tscan->GetFdata(); else E=U_ERROR; break;
        case UField::U_DOUBLE:  if(tscan->GetDdata()) data[t] = (double       *) tscan->GetDdata(); else E=U_ERROR; break;
        }
        if(E!=U_OK) break;
    }
    if(E!=U_OK)
    {
        delete[] data;
        CI.AddToLog("ERROR: UConnectivityScans::MakeConnectivityMatrix(). Invalid scans in ScanList. \n");
        return U_ERROR;
    }

// now build The Matrix
    long int q=0;
    for(int i=0; i<Nobjects; i++) 
    {
        int i1=ScanPoint[i];
        fprintf(stderr,"percentage done: %d\r",100*q/(Nobjects*(Nobjects-1)/2));
        for(int j=i+1; j<Nobjects; j++) 
        {
            int    i2  = ScanPoint[j];
            double tmp = 0.;
            for(int t=0; t<Nscan; t++) 
            {
                void* dat=data[t]; 
                switch(ScanList->GetDType())
                {
                case UField::U_BYTE:    tmp+=(((unsigned char*)dat)[i1])*(((unsigned char*)dat)[i2]); break;
                case UField::U_SHORT:   tmp+=(((short        *)dat)[i1])*(((short        *)dat)[i2]); break;
                case UField::U_INTEGER: tmp+=(((int          *)dat)[i1])*(((int          *)dat)[i2]); break;
                case UField::U_FLOAT:   tmp+=(((float        *)dat)[i1])*(((float        *)dat)[i2]); break;
                case UField::U_DOUBLE:  tmp+=(((double       *)dat)[i1])*(((double       *)dat)[i2]); break;
                }
            }
            ConnMat[q++] = float(tmp);
        } // for i2
    } // for i1
    delete[] data;

// make sure we're all positive about this
    float minq = GetMin(ConnMat, q);
    float maxq = GetMax(ConnMat, q);

    CI.AddToLog("Note: UConnectivityScans::MakeConnectivityMatrix(). min. / max. value in ConnMat: %f / %f\n",double(minq),double(maxq));
    if(minq<0) for (int i=0; i<q;i++) ConnMat[i]++;

    return U_OK;
}

float UConnectivityScans::GetSimilarity(int i1, int i2)
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetSimilarity(). Object NULL or erroneous. \n");
        return 0.F;
    }
    int Nscan = ScanList->GetNscan();

    if(Nscan==0 || NNonZero<=0 || ScanPoint==NULL || ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetSimilarity(). Object not properly initialised. \n");
        return 0.F;
    }

    if(i1<0 || i1>=NNonZero ||
       i2<0 || i2>=NNonZero)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetSimilarity(). Indices out of range: i1=%d and i2=%d  . \n", i1,i2);
        return 0.F;
    }

    double* Series1 = ScanList->GetTimeSeries(ScanPoint[i1], 0);
    double* Series2 = ScanList->GetTimeSeries(ScanPoint[i2], 0);

    if(Series1==NULL || Series2==NULL)
    {
        delete[] Series1;
        delete[] Series2;
        CI.AddToLog("ERROR: UConnectivityScans::GetSimilarity(). Getting time series at points  i1=%d or i2=%d  . \n", i1,i2);
        return 0.;
    }

//subtract mean
    double Norm1 = 0;
    for(int j=0; j<Nscan; j++) Norm1 += Series1[j];
    Norm1 /= Nscan;
    for(int j=0; j<Nscan; j++) Series1[j] -= Norm1;

    double Norm2 = 0;
    for(int j=0; j<Nscan; j++) Norm2 += Series2[j];
    Norm2 /= Nscan;
    for(int j=0; j<Nscan; j++) Series2[j] -= Norm2;

// compute covariance
    double Corr = 0.;
    for(int j=0; j<Nscan; j++) Corr += (Series2[j]*Series1[j]);

// normalise compute correlation
    if(Normalise==true)
    {
        double Norm1 = 0;
        for(int j=0; j<Nscan; j++) Norm1 += Series1[j]*Series1[j];
        if(Norm1>0)
        {
            Norm1 = sqrt(Norm1);
            Corr /= Norm1;
        }
        double Norm2 = 0;
        for(int j=0; j<Nscan; j++) Norm2 += Series2[j]*Series2[j];
        if(Norm2>0)
        {
            Norm2 = sqrt(Norm2);
            Corr /= Norm2;
        }
        
        Corr+=1;  // add 1 to not go negative (??? Not if Normalise==FALSE???)
    }

    delete[] Series1;
    delete[] Series2;

    return float(Corr);
}

int UConnectivityScans::GetNobjects(void) const
{
    if(this==NULL || error!=U_OK) return 0;
    return NNonZero;
}

ErrorType UConnectivityScans::GetMaskedCovMatrixProduct(float* map)
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct(). Object NULL or erroneous. \n");
        return U_ERROR;
    }

    int   Nscan = ScanList->GetNscan();

    if(NNonZero<=0 || Nscan<=0 || ScanPoint==NULL || ScanList==NULL || ScanList->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct(). Object not properly initialised. \n");
        return U_ERROR;
    }

    if(map==NULL)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct(). Invalid NULL argument. \n");
        return U_ERROR;
    }

// time signals in data Y[NxT] are assumed to have mean 0 and variance 1
//
// then for A=cov(Y), A[NxN]             * v[Nx1] corresponds to
//                    Y[NxT] * ( Y'[TXN] * v[Nx1] )
//                    Y[NxT] *    Z[Tx1] !!!
//
// Y is the ScanList, v is the map Z is the half-product tvec

    double* tvec = new double[Nscan];
    if(tvec==NULL)
    {
        CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct(). Memory allocation, Nscan = %d \n");
        return U_ERROR;
    }

    double mapsum = 0.;

// first compute Y'[TxN] v[N*1]
    for(int t=0; t<Nscan; t++)
    {
        tvec[t]            = 0;
        const UScan* tscan = ScanList->GetScan(t);

        if(tscan==NULL || tscan->GetError()!=U_OK)
        {
            delete[] tvec;
            CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct() problem with GetScan(). Getting image at t=%d.\n",t);
            return U_ERROR;
        } // if tscan
        
        switch(tscan->GetDType())
        {
        case UField::U_BYTE:
            {
                unsigned char* bdata=tscan->GetBdata();
                if(bdata)
                    for(int n=0; n<NNonZero; n++) 
                    {
                        mapsum  += map[n];
                        tvec[t] += map[n]* bdata[ScanPoint[n]];
                    }
            }
            break;
        case UField::U_SHORT:
            {
                short* sdata=tscan->GetSdata();
                if(sdata)
                    for(int n=0; n<NNonZero; n++) 
                    {
                        mapsum  += map[n];
                        tvec[t] += map[n]* sdata[ScanPoint[n]];
                    }
            }
            break;
        case UField::U_INTEGER:
            {
                int* idata=tscan->GetIdata();
                if(idata)
                    for(int n=0; n<NNonZero; n++) 
                    {
                        mapsum  += map[n];
                        tvec[t] += map[n]* idata[ScanPoint[n]];
                    }
            }
            break;
        case UField::U_FLOAT:
            {
                float* fdata=tscan->GetFdata();
                if(fdata)
                    for(int n=0; n<NNonZero; n++) 
                    {
                        mapsum  += map[n];
                        tvec[t] += map[n]* fdata[ScanPoint[n]];
                    }
            }
            break;
        case UField::U_DOUBLE:
            {
                double* ddata=tscan->GetDdata();
                if(ddata)
                    for(int n=0; n<NNonZero; n++) 
                    {
                        mapsum  += map[n];
                        tvec[t] += map[n]* ddata[ScanPoint[n]];
                    }
            }
            break;
        }

    } // for t

    // now compute Y[NxT] Z[Tx1]
    for(int n=0; n<NNonZero; n++)
    {
        double* tdata = ScanList->GetTimeSeries(ScanPoint[n], 0);
        if(tdata==NULL)
        {
            delete[] tvec;
            CI.AddToLog("ERROR: UConnectivityScans::GetMaskedCovMatrixProduct() problem with GetTimeSeries(). Time series at point %d.\n",ScanPoint[n]);
            return U_ERROR;
        } // if tscan

        map[n] = 0.F;
        for(int t=0; t<Nscan; t++) map[n] += float(tvec[t]*tdata[t]);
        delete[] tdata;

// add sum of current map (vector) to each coefficient of the new map
        map[n] += float(mapsum);
    } // for n

    delete[] tvec;
    return U_OK;
}