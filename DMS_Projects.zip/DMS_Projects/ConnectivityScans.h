#ifndef _CONNECTIVITYSCANS_INCLUDED
#define _CONNECTIVITYSCANS_INCLUDED

/*********************************************************************************/
/*     Module for connecting 4D scans (e.g. MRI time series)                     */
/*                and mapping connectivity stats                                 */
/*     Alle Meije Wink                                                           */
/*********************************************************************************/

/*
  Update history

  Who   When        What
  AMW   16/12/2010  Creation
*/

#include "Connectivity.h"
#include "String.h"
#include "FileName.h"

class UScan;
class UScanList;
class UFieldGraph;
class UBitMap;

class DLL_IO UConnectivityScans : private UConnectivity 
{
public:
    UConnectivityScans(); // default
    UConnectivityScans(const UConnectivityScans& CS); // copy
    UConnectivityScans(const UScanList& SL, int icomp, bool Norm, SimilarityType ST=U_SIM_NOTYPE, MatrixCompExplicit=U_MATCOMP_UNKNOWN); // initialised

    ~UConnectivityScans(); // ensures proper deletion
    UConnectivityScans& operator=(const UConnectivityScans& CS); // assignment

    virtual const UString&  GetProperties(UString Comment) const; // list properties
    ErrorType               GetError(void) const        {if(this) return error;     return U_ERROR;}
    bool                    GetNormalise(void) const    {if(this) return Normalise; return false;  }

    UScan*                  GetMapping(void); // return the mapping

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    virtual float           GetSimilarity(int i1, int i2);
    virtual int             GetNobjects(void) const;
    virtual ErrorType       GetMaskedCovMatrixProduct(float *map);
    virtual ErrorType       MakeConnectivityMatrix(void);

    static UString          Properties;
    ErrorType               error;            // General error flag

    int                     NNonZero;         // Number of points with non-zero data
    int*                    ScanPoint;        // returns the index of each non-zero data point

/* "Temporary" parameters only used in UConnectivityScans::GetSimilarity() (and in GetProperties()) */
    UScanList*              ScanList;         // Copy of UScanList-object of wich connectivity is derived
    bool                    Normalise;
};
#endif //_CONNECTIVITYSCANS_INCLUDED
