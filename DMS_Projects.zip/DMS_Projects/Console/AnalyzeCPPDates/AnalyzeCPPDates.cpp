/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to analyze update histories of cpp files.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    12-06-11   creation
  JdM    24-07-11   Bug Fix GetUpdateRecords(). Open file with "rb" instead of "rb", to stay compatible with ftell()
  JdM    21-11-14   Increased MAXRECORDS from 2000 to 20000
  JdM    03-03-18   Changed output format.
*/ 
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../String.h"
#include "../../AnalyzeLine.h"

#define VERSION "1.04"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

enum{
    OP_DIRIN,OP_FILOUT,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

typedef struct
{
    UString FileName;
    UString Initial;
    int     Day;
    int     Month;
    int     Year;
    UString UpdateText;
} UpdateRecord;

#define       MAXRECORDS 20000
UpdateRecord* GetUpdateRecords(UFileName Fnam, int* Nrec);


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme reads files with .cpp extension, analyzes update history \n"
                         "and stores them in a given text file. \n";

    Help[OP_DIRIN    ] = "Directory with .cpp files.";
    Help[OP_FILOUT   ] = "Output text file.";
    Option[OP_DIRIN  ] = UOption("Input",Help[OP_DIRIN], UOption::DATASETNAME);
    Option[OP_FILOUT ] = UOption("Updates.txt",Help[OP_FILOUT], UOption::FILENAME);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.ResetLogFile();
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UDirectory Dir(Option[OP_DIRIN].GetFileName());
    UFileName  Fout(Option[OP_FILOUT].GetFileName());

    int        NFiles = 0;
    UFileName* Filar  = Dir.GetAllFileNames("*.cpp", &NFiles);
    if(Filar==NULL || NFiles<=0)
    {
        CI.AddToLog("ERROR: There are no files of the given specifications: %s .\n",Dir);
        CI.PressReturnExit();
    }
    int NTotRec = 0;
    for (int ifile = 0; ifile < NFiles; ifile++)  NTotRec += Filar[ifile].GetNLines();
    
    FILE* fpout = fopen(Fout, "wt");
    fprintf(fpout,"%s", CI.GetProperties("//  "));
    fprintf(fpout, "//   NFiles    = %d \n", NFiles);
    fprintf(fpout, "//   NLines    = %d \n", NTotRec);
    fprintf(fpout, "// \n");
    fprintf(fpout, "// File \tNline \tWho \tDay \tMonth \tYear \tUpdate \n");

    for(int ifile=0; ifile<NFiles; ifile++)
    {
        int           Nrec = 0;
        UpdateRecord* UR   = GetUpdateRecords(Filar[ifile], &Nrec);
        if(UR==NULL) continue;

        int NLine = Filar[ifile].GetNLines();
        for(int ir=0; ir<Nrec; ir++)
        {
            fprintf(fpout, "%s \t", (const char*) UR[ir].FileName);
            fprintf(fpout, "%d \t", NLine);
            fprintf(fpout, "%s \t", (const char*) UR[ir].Initial );
            fprintf(fpout, "%d \t",               UR[ir].Day     );
            fprintf(fpout, "%d \t",               UR[ir].Month   );
            fprintf(fpout, "%d \t",               UR[ir].Year);
            fprintf(fpout, "%s \n", (const char*) UR[ir].UpdateText);
        }

        delete[] UR;
    }
    delete[] Filar;
    fclose(fpout);

    return 0;
}

UpdateRecord* GetUpdateRecords(UFileName Fnam, int* Nrec)
{
    if(Nrec==0) return NULL;

    FILE* fp = fopen(Fnam, "rb", false);
    if(fp==NULL) return 0;

    *Nrec            = 0;
    UpdateRecord* UR = new UpdateRecord[MAXRECORDS];

    bool Start = false;
    char line[200];
    while(::GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine()) continue;
        if(Start==false)
        {
            Start = AA.IsIdentifierInLine("Who", true);      continue;
        }
        if(Start==true)
        {
            UString S(line);
            if(S.IsContaining("*/",true)) break;
        }
        UpdateRecord Record;
        Record.FileName = UString(Fnam.GetBaseName());
        Record.Initial  = UString(AA.GetNextString(10));
        UAnalyzeLine::ConvertChar(line,'-',' ', 2);
        Record.Day      = AA.GetNextInt(-1); if(Record.Day  ==-1 && *(AA.GetPointer()-2)=='?') Record.Day   = 1;
        Record.Month    = AA.GetNextInt(-1); if(Record.Month==-1 && *(AA.GetPointer()-2)=='?') Record.Month = 1;
        Record.Year     = AA.GetNextInt(-1);
        if(Record.Day<=0 || Record.Day>31 || Record.Month<=0 || Record.Month>12 || Record.Year<0)
        {
            fclose(fp);
            delete[] UR; *Nrec = 0;
            CI.AddToLog("ERROR: UpdateRecord* GetUpdateRecords(). Reading Date in file %s\n          line = %s \n", (const char*)Fnam, line);
            return NULL;
        }

        if(Record.Year<30)       Record.Year += 2000;
        else if(Record.Year<=99) Record.Year += 1900;
        Record.UpdateText = UString(AA.GetPointer());
        Record.UpdateText.ReplaceAll('\r', ' ');
        Record.UpdateText.ReplaceAll('\n', ' ');
        UR[*Nrec] =Record; (*Nrec)++;
        if(*Nrec>=MAXRECORDS-2)
        {
            fclose(fp);
            delete[] UR; *Nrec = 0;
            CI.AddToLog("Too many records in file %s \n", (const char*)Fnam);
            return NULL;
        }
        
        int          NCread = AA.GetNcharRead();
        while(1)
        {
            unsigned int point  = ftell(fp);
            if(::GetLine(line, sizeof(line), fp)==NULL) break;
            bool SameDate = true;
            for(int k=0; k<NCread; k++) if(line[k]!=' ') {SameDate=false; break;}
            if(SameDate==true)
            {
                Record.UpdateText = UString(line+NCread);
                Record.UpdateText.ReplaceAll('\r', ' ');
                Record.UpdateText.ReplaceAll('\n', ' ');
                UR[*Nrec] =Record; (*Nrec)++;
                if(*Nrec>=MAXRECORDS-5)
                {
                    fclose(fp);
                    delete[] UR; *Nrec = 0;
                    CI.AddToLog("Too many records in file %s \n", (const char*)Fnam);
                    return NULL;
                }
            }
            else
            {
                fseek(fp, point, SEEK_SET);
                break;
            }
        }        
    }
    fclose(fp);
    return UR;
}
