/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to analyze update histories of cpp files.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    02-04-17   creation
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../String.h"
#include "../../MEEGDataCTF.h"
#include "../../MarkerArray.h"

#define VERSION "1.01"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

enum{
    OP_DIRIN,OP_FILOUT,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

typedef struct
{
    UString     Directory;
    UString     DSName;
    UString     PatName;
    int         Day;
    int         Month;
    int         Year;
    int         NMEG;
    int         NEEG;
    int         NECG;
    int         NMarker;
    int         NTrial;
    int         NSampTrial;
    int         NAver;
    UString     SEFMarker;
    double      SampRate;
    double      Duration;
} MEEGData;


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme reads files with .res4 extension, analyzes their settings \n"
                         "and stores these in a given text file. \n";

    Help[OP_DIRIN    ] = "Directory with .res4 files.";
    Help[OP_FILOUT   ] = "Output text file.";
    Option[OP_DIRIN  ] = UOption("Input",Help[OP_DIRIN], UOption::DATASETNAME);
    Option[OP_FILOUT ] = UOption("Output",Help[OP_FILOUT], UOption::FILENAME);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.ResetLogFile();
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UDirectory Dir(Option[OP_DIRIN].GetFileName());
    UFileName  Fout(Option[OP_FILOUT].GetFileName());

    int        NFiles = 0;
    UFileName* Filar  = Dir.GetAllFileNames("*.res4", &NFiles);
    if(Filar==NULL || NFiles<=0)
    {
        CI.AddToLog("ERROR: There are no files of the given specifications: %s .\n",Dir);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NFiles);

    FILE* fpout = fopen(Fout, "wt");
    fprintf(fpout,"%s", CI.GetProperties("//  "));
    fprintf(fpout,"//   NFiles    = %d \n", NFiles);
    fprintf(fpout,"// \n");
    fprintf(fpout,"// \n");
    fprintf(fpout,"Directory \tDSName \tPatName \tDay \tMonth \tYear \tNMEG \tNEEG \tNECG \tNMarker \tNTrial \tNSamp \tNAver \tSEFmarkers \tSRate \tDuration \n");

    for(int ifile=0; ifile<NFiles; ifile++)
    {
        UFileName    FI(Filar[ifile]);

        if(IsStringCompatible((const char*)FI, "*hz.res4" ,false)==true) continue;
        if(IsStringCompatible((const char*)FI, "*hz2.res4",false)==true) continue;

        UMEEGDataCTF CTF(FI);
        if(CTF.GetError()!=U_OK) continue;

        MEEGData MDat;
        UDateTime Date        = CTF.GetDateTime();
        const UMarkerArray* M = CTF.GetMarkerArray();

        MDat.Directory  = UString(FI.GetDirectory().GetDirectoryName());
        MDat.DSName     = UString(FI.GetBaseName());
        MDat.PatName    = UString(CTF.GetPatName());
        MDat.Year       = Date.GetYear();
        MDat.Month      = Date.GetMonth();
        MDat.Day        = Date.GetDay();
        MDat.NMEG       = CTF.GetNmeg();
        MDat.NEEG       = CTF.GetNeeg();
        MDat.NECG       = CTF.GetNkan(U_DAT_EKG);
        MDat.NMarker    = M?CTF.GetMarkerArray()->GetnMarkers():0;
        MDat.NTrial     = CTF.GetNtrial();
        MDat.NSampTrial = CTF.GetNsampTrial();

        MDat.NAver      = CTF.GetNaver();
        MDat.SEFMarker  = "No";
        if(M)
        {
            for(int n=0, k=0; n<MDat.NMarker; n++)
            {
                if(M->IsNameEquivalent(n, "*SEF*")==false) continue;
                if(k==0) MDat.SEFMarker  = UString(M->GetMarkerName(n));
                else     MDat.SEFMarker += UString(",")+UString(M->GetMarkerName(n));
                k++;
            }
        }
        MDat.SampRate   = CTF.GetSampleRate();
        MDat.Duration   = CTF.GetSampleTime_s() * CTF.GetNsampTotal();

        fprintf(fpout,"%s \t%s \t%s \t%d \t%d \t%d \t%d \t%d \t%d \t%d \t%d \t%d \t%d \t%s \t%f \t%f \n", (const char*)MDat.Directory,(const char*)MDat.DSName,(const char*)MDat.PatName,MDat.Day, MDat.Month, MDat.Year, MDat.NMEG, MDat.NEEG, MDat.NECG, MDat.NMarker, MDat.NTrial, MDat.NSampTrial,MDat.NAver,(const char*)MDat.SEFMarker, MDat.SampRate, MDat.Duration);
    }
    delete[] Filar;
    fclose(fpout);

    return 0;
}
