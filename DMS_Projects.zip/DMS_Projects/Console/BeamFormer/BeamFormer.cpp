/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to generate Beamformer scans.                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    03-03-10   creation
  JdM    09-03-10   Use lead field tables
  JdM    16-03-10   Use separate window offsets for active and rest windows.
  JdM    22-03-11   Bug Fix. Writing "match_scan_to_wld.xdr" of beamformer scan
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  */


#include "../SetUpMEEGDataEpochs.h"
#include "../../MEEGDataEpochsExt.h"
#include "../../SensorCorrelate.h"
#include "../../MarkerArray.h"
#include "../../Marker.h"
#include "../../HeadModel.h"
#include "../../Scan.h"
#include "../../Option.h"

#define VERSION "1.2 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUmc, Amsterdam"


enum
{
    OP_DIRIN,OP_HMFILE,OP_GOODCH,OP_BADCH,
    OP_FBANDS,OP_MREST,OP_MACTIVE,OP_WINREST,OP_WINACTIVE,OP_MEGSENS,OP_RESOL,OP_REGUL,OP_LOG,OP_WRIPAT,OP_OUTNAME,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

#define  MAXBAND 5

USensorCorrelate* CovarActi[MAXBAND]  = {NULL, NULL, NULL, NULL, NULL};
USensorCorrelate* CovarRest[MAXBAND]  = {NULL, NULL, NULL, NULL, NULL};

const char* BandName[MAXBAND] = {"Delta","Theta","Alpha","Beta","Gamma"};

ErrorType ComputeWindow(double T1r, double T2r, double T1a, double T2a, double Stime, int* s1r, int *s2r, int* s1a, int *s2a);

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme computes beamformer scans for MEG data in CTF data format.\n";


    Help[OP_DIRIN    ] = "DataSet name of the MEG data to be analyzed. This name may contain wild cards (*) to analyze multiple data sets.";
    Help[OP_HMFILE   ] = "The name of the file containing the volume conductor model. The same head model file will be used for all data sets selected with the wild card.";
    Help[OP_OUTNAME  ] = "Extra string in output  beamformer scan file (.xdr) that may be used to refer to specific contrast.";
    Help[OP_GOODCH   ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH    ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_FBANDS   ] = "You set (multiple) frequency bands: 1: 1-4 Hz (Delta), 2: 4-8 Hz (Theta), 3: 8-12 Hz (Alpha), 4: 12-20 Hz (Beta), 5: 20-40 Hz (Gamma). Set -FB3F5 to compute beamformers for both alpha, beta and gamma bands.";
    Help[OP_MREST    ] = "Marker name of events of rest onset. The precise windows are determined by the offset parameters.";
    Help[OP_MACTIVE  ] = "Marker name of events of active onset. The precise windows are determined by the offset parameters.";
    Help[OP_WINREST  ] = "Offset timings in seconds for rest window. First parameter gives the time shift applied on each event marker to find the window onset, second paramer gives the end of the window with respect to event markers. Note that precise timings can be adapted to avoid unhandy number of samples (large primes).";
    Help[OP_WINACTIVE] = "Offset timings in seconds for active window. First parameter gives the time shift applied on each event marker to find the window onset, second paramer gives the end of the window with respect to event markers. Note that precise timings can be adapted to avoid unhandy number of samples (large primes). Note that active time window aand rest time window should be of equal length in order to assure identical frequency resolution.";
    Help[OP_MEGSENS  ] = "Which MEG sensor types are taken? 1=Magnetometers, 2=Gradiometers, 3=both.";
    Help[OP_RESOL    ] = "Beamformer scanning resoltion [cm].";
    Help[OP_REGUL    ] = "Regularization parameter.";
    Help[OP_LOG      ] = "Log-weighting?";
    Help[OP_WRIPAT   ] = "Export beamformer scan to patient tree.";

    Option[OP_DIRIN    ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_HMFILE   ] = UOption("HeadModel",Help[OP_HMFILE],UOption::FILENAME);
    Option[OP_OUTNAME  ] = UOption("Out","ContrastName",Help[OP_OUTNAME],"");
    Option[OP_GOODCH   ] = UOption("Gch","GoodCh",Help[OP_GOODCH],NULL);
    Option[OP_BADCH    ] = UOption("Bch","BadCh",Help[OP_BADCH],NULL);
    Option[OP_FBANDS   ] = UOption("FB" ,"Fbands",Help[OP_FBANDS],1,5,3,5);
    Option[OP_MREST    ] = UOption("MR" ,"MarkRest",Help[OP_MREST],NULL);
    Option[OP_MACTIVE  ] = UOption("MA" ,"MarkActiv",Help[OP_MACTIVE],NULL);
    Option[OP_WINREST  ] = UOption("WiR","WindowRest",Help[OP_WINREST],-100.,100.,1.,9.);
    Option[OP_WINACTIVE] = UOption("WiA","WindowActive",Help[OP_WINACTIVE],-100.,100.,1.,9.);
    Option[OP_MEGSENS  ] = UOption("MEG","MEG-sens",Help[OP_MEGSENS],1,3,2);
    Option[OP_RESOL    ] = UOption("Res","Resolution",Help[OP_RESOL],0.01,10.,0.3);
    Option[OP_REGUL    ] = UOption("Lam","Lamda",Help[OP_REGUL],0.,100.,0.01);
    Option[OP_LOG      ] = UOption("Log","LogWeights",Help[OP_LOG]);
    Option[OP_WRIPAT   ] = UOption("Pat","WritePat",Help[OP_WRIPAT]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    const char* GoodChan = NULL; if(Option[OP_GOODCH].GetValueSet()==true)  GoodChan = Option[OP_GOODCH].GetString();
    const char* BadChan  = NULL; if(Option[OP_BADCH ].GetValueSet()==true)  BadChan  = Option[OP_BADCH ].GetString();
    const char* HeadModelFile = Option[OP_HMFILE].GetFileName();
    UHeadModel HM(HeadModelFile);
    if(HM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating head model object from file %s .\n",HeadModelFile);
        CI.PressReturnExit();
    }

/*Select data and Set Epochs*/
    const char* DataSets  = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(DataSets, NULL, false);
    const char* DirName   = Dirin.GetDirectoryName();

    const char* MrestName = Option[OP_MREST  ].GetString();
    const char* MactiName = Option[OP_MACTIVE].GetString();
    if(MrestName==NULL || MactiName==NULL)
    {
        CI.AddToLog("ERROR: Invalid marker names.\n");
        CI.PressReturnExit();
    }
    int ibandMin = Option[OP_FBANDS  ].GetValue1()-1;
    int ibandMax = Option[OP_FBANDS  ].GetValue2()-1;
    if(ibandMin>ibandMax) {int dum = ibandMin; ibandMin = ibandMax; ibandMax = dum;}
    int NBand    = ibandMax - ibandMin + 1;

    int        NDirs = 0;
    UFileName* Filar  = Dirin.GetAllSubdirNames(DataSets, &NDirs);
    if(Filar==NULL || NDirs<=0)
    {
        CI.AddToLog("ERROR: There are no files of the give specifications: %s .\n",DataSets);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NDirs);


    bool   MAGonly  = false; if(Option[OP_MEGSENS ].GetValue()==1) MAGonly = true;
    bool   GRAonly  = false; if(Option[OP_MEGSENS ].GetValue()==2) GRAonly = true;
    double Resel    = Option[OP_RESOL  ].GetDubVal1();
    double Lamda    = Option[OP_REGUL  ].GetDubVal1();
    bool   LogW     = Option[OP_LOG    ].GetBOOL();
    bool   WritePat = Option[OP_WRIPAT ].GetBOOL();
    if(WritePat && HM.GetCondModelType()!=U_CONDMOD_BEM)
    {
        CI.AddToLog("WARNING: Exporting beam former scan to patient tree only works with BEM models.\n");
        WritePat = false;
    }
    UPatTree PatOut;
    if(WritePat)
    {
        PatOut = UPatTree(HM.GetTriFileName(0)).Parent().Parent();
        if(PatOut.GetBranchType()!=UPatTree::U_PATIENT)
        {
            PatOut = UPatTree(PatOut.Parent());
            if(PatOut.GetBranchType()!=UPatTree::U_PATIENT)
            {
                PatOut = UPatTree(PatOut.Parent());
                if(PatOut.GetBranchType()!=UPatTree::U_PATIENT)
                {
                    CI.AddToLog("WARNING: Cannot fing output patient tree directory. \n");
                    WritePat = false;
                }
             }
        }
    }


    int    NDS      = 0;
    for(int idir=0; idir<NDirs; idir++)
    {
        const char* DataSetName = Filar[idir].GetFullFileName();

        if(IsStringEnding(DataSetName, "hz.ds")==true ||
           IsStringEnding(DataSetName, "hz2.ds")==true)  continue;

        UMEEGDataEpochsExt EpDat(DataSetName, GoodChan, BadChan);
        if(EpDat.GetError()!=U_OK                               ||
           EpDat.GetData() ==NULL                               ||
           EpDat.GetData()->GetError()!=U_OK                    ||
           EpDat.GetData()->GetDataFormatType()!=U_DATFORM_CTF  ||
           EpDat.GetData()->GetNChan(U_DAT_MEG)<=10)
        {
            CI.AddToLog("ERROR: Cannnot create data-object, or data does not contain CTF MEG sensors. Skip %s .\n", DataSetName);
            continue;
        }
        if(EpDat.GetData()->CanBeBalanced()==true)
            EpDat.SetRereference(U_REF_THIRDFORWARD, U_REF_AVERAGE);
        else
            EpDat.SetRereference(U_REF_RAW         , U_REF_AVERAGE);

        const UMarkerArray* M = EpDat.GetData()->GetMarkerArray();
        if(M==NULL || M->GetError()!=U_OK || M->GetMarker(MrestName)==NULL || M->GetMarker(MactiName)==NULL)
        {
            CI.AddToLog("ERROR: Data set does not contain rest and/or acctive markers. Skip %s .\n", DataSetName);
            continue;
        }
        const UMarker* Mrest = M->GetMarker(MrestName);
        if(Mrest==NULL || Mrest->GetError()!=U_OK || Mrest->GetnEvents()<=0)
        {
            CI.AddToLog("ERROR: Rest marker does not contain events. Skip %s .\n", DataSetName);
            continue;
        }
        const UMarker* Macti = M->GetMarker(MactiName);
        if(Macti==NULL || Macti->GetError()!=U_OK || Macti->GetnEvents()<=0)
        {
            CI.AddToLog("ERROR: Active marker does not contain events. Skip %s .\n", DataSetName);
            continue;
        }
        double T1r = Option[OP_WINREST].GetDubVal1(); double T1a = Option[OP_WINACTIVE].GetDubVal1();
        double T2r = Option[OP_WINREST].GetDubVal2(); double T2a = Option[OP_WINACTIVE].GetDubVal2();
        int    s1r =  0; int s1a = 0;
        int    s2r = -1; int s2a = 0;
        if(ComputeWindow(T1r,T2r,T1a,T2a,EpDat.GetSampleTime_s(), &s1r, &s2r, &s1a, &s2a)!=U_OK)
        {
            CI.AddToLog("ERROR: Computing time window. Skip %s .\n", DataSetName);
            continue;
        }
        UFreqBand FB(U_FBAND_FIVE, EpDat.GetSampleRate(), s2r-s1r+1);

        if(EpDat.SetEpochsMarker(s1r, s2r, Mrest)!=U_OK || EpDat.GetNEpoch()<=0)
        {
            CI.AddToLog("ERROR: Setting rest epochs. Skip %s .\n", DataSetName);
            continue;
        }
        if(EpDat.SetEpochsMarker(s1a, s2a, Macti)!=U_OK || EpDat.GetNEpoch()<=0)
        {
            CI.AddToLog("ERROR: Setting active epochs. Skip %s .\n", DataSetName);
            continue;
        }

        bool      Overlap      = false;
        bool      SubAve       = false;
        DataType  DType        = U_DAT_MEG;
        int       NBandDum     = 0;
        USensorCorrelate** pSC = NULL;

/* rest cross spectra */
        EpDat.SetEpochsMarker(s1r, s2r, Mrest);
        UString Prop = UString(EpDat.GetData()->GetDataFileName(), " DataFileName  = %s \n") +
                       UString(MrestName                         , " Marker        = %s \n") +
                       UString(s1r                               , " BeginOffset   = %d \n") +
                       UString(s2r                               , " EndOffset     = %d \n");

        pSC = EpDat.GetCrossSpectra(0., 1., 1., U_FBAND_FIVE, -1, Overlap, SubAve, &NBandDum, DType);
        if(pSC==NULL || NBandDum!=MAXBAND)
        {
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarRest[ib]; CovarRest[ib]=NULL;}
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarActi[ib]; CovarActi[ib]=NULL;}
            CI.AddToLog("ERROR: Computing crossspectra for rest epochs. Skip %s .\n", DataSetName);
            continue;
        }
        UFileName Frest = UDirectory(DataSetName) + UFileName("Covar_.cor"); Frest.InsertBeforeExtension(MrestName); Frest.InsertBeforeExtension("_");
        for(int ib=0; ib<MAXBAND; ib++)
        {
            UFileName Fout = Frest; Fout.InsertBeforeExtension(BandName[ib]);
            if(Option[OP_OUTNAME].GetValueSet()==true) Fout.InsertBeforeExtension(Option[OP_OUTNAME].GetString());

            delete CovarRest[ib];  CovarRest[ib] = pSC[ib];
            CovarRest[ib]->SetCreation(Prop);
            CovarRest[ib]->WriteToFile(Fout);
        }
        delete[] pSC;

/* active  cross spectra */
        EpDat.SetEpochsMarker(s1a, s2a, Macti);
        Prop = UString(EpDat.GetData()->GetDataFileName(), " DataFileName  = %s \n") +
               UString(MactiName                         , " Marker        = %s \n") +
               UString(s1a                               , " BeginOffset   = %d \n") +
               UString(s2a                               , " EndOffset     = %d \n");

        pSC = EpDat.GetCrossSpectra(0., 1., 1., U_FBAND_FIVE, -1, Overlap, SubAve, &NBandDum, DType);
        if(pSC==NULL || NBandDum!=MAXBAND)
        {
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarRest[ib]; CovarRest[ib]=NULL;}
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarActi[ib]; CovarActi[ib]=NULL;}
            CI.AddToLog("ERROR: Computing crossspectra for active epochs. Skip %s .\n", DataSetName);
            continue;
        }
        UFileName Facti = UDirectory(DataSetName) + UFileName("Covar_.cor"); Facti.InsertBeforeExtension(MactiName); Facti.InsertBeforeExtension("_");
        for(int ib=0; ib<MAXBAND; ib++)
        {
            UFileName Fout = Facti; Fout.InsertBeforeExtension(BandName[ib]);
            if(Option[OP_OUTNAME].GetValueSet()==true) Fout.InsertBeforeExtension(Option[OP_OUTNAME].GetString());
            delete CovarActi[ib];  CovarActi[ib] = pSC[ib];
            CovarActi[ib]->SetCreation(Prop);
            CovarActi[ib]->WriteToFile(Fout);
        }
        delete[] pSC;

        if(EpDat.InitBeamFormerScan(&HM, Resel)!=U_OK)
        {
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarRest[ib]; CovarRest[ib]=NULL;}
            for(int ib=0; ib<MAXBAND; ib++) {delete CovarActi[ib]; CovarActi[ib]=NULL;}
            CI.AddToLog("ERROR: Initializing beamformer object. Skip %s .\n", DataSetName);
            continue;
        }

        bool      UseLFtable = true;
        ErrorType E          = U_OK;
        for(int ib=ibandMin; ib<=ibandMax; ib++)
        {
            CI.TimeReset(BandName[ib]);

            UString Prop = UString(EpDat.GetData()->GetDataFileName(), " DataFileName  = %s \n") +
                           UString(MrestName                         , " MarkerRest    = %s \n") +
                           UString(s1r                               , " BeginOffset   = %d \n") +
                           UString(s2r                               , " EndOffset     = %d \n") +
                           UString(MactiName                         , " MarkerActive  = %s \n") +
                           UString(s1a                               , " BeginOffset   = %d \n") +
                           UString(s2a                               , " EndOffset     = %d \n");

            UEuler  Ref2NLR = HM.GetRef2NLR();
            UEuler  Ref2Wld = HM.GetMRtoWld();
            UScan*  Sbeam   = EpDat.ComputeBeamFormerScan(CovarActi[ib], CovarRest[ib], LogW, Lamda, MAGonly, GRAonly, UseLFtable, Ref2Wld * Ref2NLR.GetInverse());
            if(Sbeam==NULL || Sbeam->GetError()!=U_OK)
            {
                delete Sbeam;
                CI.AddToLog("ERROR: Computing beamformer object, band = %s .\n", BandName[ib]);
                continue;
            }
            Sbeam->AddFileComments(Prop);

            UFileName Fbeam = UDirectory(DataSetName) + UFileName("Beam_.xdr");
            Fbeam.InsertBeforeExtension(MrestName);
            Fbeam.InsertBeforeExtension("_");
            Fbeam.InsertBeforeExtension(MactiName);
            Fbeam.InsertBeforeExtension(BandName[ib]);
            if(Option[OP_OUTNAME].GetValueSet()==true) 
            {
                Fbeam.InsertBeforeExtension("_");
                Fbeam.InsertBeforeExtension(Option[OP_OUTNAME].GetString());
            }
            Sbeam->SetScanName(Fbeam.GetBaseName());
            Sbeam->WriteXDR(Fbeam);

            if(WritePat)
            {
                UFileName  FName   = UFileName(Filar[idir]);
                FName.ReplaceExtension(".scan");
                UString    Name    = UString("_") + UString(BandName[ib]);
                if(Option[OP_OUTNAME].GetValueSet()==true) Name += UString("_") + Option[OP_OUTNAME].GetString();
                Name += UString("_") + UString(FName.GetBaseName());
                UDirectory BeamDir = PatOut.Child((const char*)Name);
                if(BeamDir.CreateDir()==U_OK)
                {
                    UEuler     ToWld   = UPatTree::GetToWld(U_ORI_AXIAL);
                    UEuler     NLR2Wld = Sbeam->GetMatchScanToWld();
                    Sbeam ->WriteXDR( BeamDir + UFileName("scan.xdr") );
                    NLR2Wld.WriteXDR( BeamDir + UFileName("match_scan_to_wld.xdr") );
                    ToWld  .WriteXDR( BeamDir + UFileName("scan_to_wld.xdr") );
                }
            }

            delete Sbeam;

            CI.TimeFlag(BandName[ib]);
        }
        for(int ib=0; ib<MAXBAND; ib++) {delete CovarRest[ib]; CovarRest[ib]=NULL;}
        for(int ib=0; ib<MAXBAND; ib++) {delete CovarActi[ib]; CovarActi[ib]=NULL;}
        if(E==U_OK) NDS++;
    }

    CI.AddToLog("Note: %d files analyzed sucessfully! .\n", NDS);
    return 0;
}

ErrorType ComputeWindow(double T1r, double T2r, double T1a, double T2a, double Stime, int* s1r, int *s2r, int* s1a, int *s2a)
{
    if(s1r==NULL || s2r==NULL) return U_ERROR;
    if(s1a==NULL || s2a==NULL) return U_ERROR;

    if(T1r>=T2r)
    {
        CI.AddToLog("ComputeWindow(). Invalid window (%f - %f)  (rest).\n", T1r, T2r);
        return U_ERROR;
    }
    if(T1a>=T2a)
    {
        CI.AddToLog("ComputeWindow(). Invalid window (%f - %f) (active).\n", T1a, T2a);
        return U_ERROR;
    }
    if(T2r-T1r != T2a-T1a)
    {
        CI.AddToLog("ComputeWindow(). Rest and active window are not of same duration (%f and %f).\n", T2r-T1r, T2a-T1a);
        return U_ERROR;
    }

    if(Stime<=0)
    {
        CI.AddToLog("ComputeWindow(). Invalid sample time (%f) .\n", Stime);
        return U_ERROR;
    }
    int Nsamp = int((T2r-T1r)/Stime);
    if(Nsamp<=0)
    {
        CI.AddToLog("ComputeWindow(). Invalid window (%f - %f) .\n", T1r, T2r);
        return U_ERROR;
    }
    Nsamp = SmallPrimes(Nsamp);
    *s1r  = int(floor(T1r/Stime));  *s2r = *s1r + Nsamp-1;
    *s1a  = int(floor(T1a/Stime));  *s2a = *s1a + Nsamp-1;

    return U_OK;
}

