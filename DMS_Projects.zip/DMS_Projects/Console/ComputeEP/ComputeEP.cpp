/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to estimate evoked potentials/evoked fields.                      */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    09-03-15   creation, derived from MainCovEstim.cpp
  JdM    12-06-15   Split off part for general UMEEGDataEpoch settings, using newly created class USetUpMEEGDataEpochs
  JdM    12-08-15   Added option to set bitmap range output and export global field power.
  JdM    16-02-16   BUG Fix (Win32 Version). Add SetEp = USetUpMEEGDataEpochs() in main() to initialize staic data.
  JdM    22-03-16   Merge existing markers with new one
  JdM    12-02-17   Bug Fix. WriteAveragedCTFData(). Added break statements in computation of temporal pre-processing.
                    Added option to compute spatial/temporal covariance.
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  JdM    29-06-18   Changed interface to USetUpMEEGDataEpochs
*/


#include "../SetUpMEEGDataEpochs.h"
#include "../../Directory.h"
#include "../../MEEGDataEpochs.h"
#include "../../Covariance.h"
#include "../../MarkerArray.h"
#include "../../Grid.h"
#include "../../MEEGDataWriteCTF.h"
#include "../../Epochs.h"
#include "../../Field.h"
#include "../../FieldGraph.h"

#define VERSION "1.21"
#define AUTHOR  "Dr. JC de Munck, Dept PMT VUmc, Amsterdam"

const int MaxCovIter = 25;

enum
{
    OP_FILIN=USetUpMEEGDataEpochs::NOPTIONS, OP_DIROUT,
    OP_DATTYP, OP_PRCOUTLIERS, OP_DISOVER, OP_COMPCOVXX, OP_COMPCOVTT, OP_BMPOUT, OP_BMPSCALE, OP_GFPOUT,
    NOPTIONS
};

static const char*   Help  [NOPTIONS];
static UOption       Option[NOPTIONS];
static USetUpMEEGDataEpochs SetEp(Help, Option);

ErrorType WriteAveragedCTFData(UMEEGDataEpochs* TemplateData, DataType DType, UFileName Fout);


int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads in a raw MEG or EEG dat file and computes an evoked potential.\n"
                         "The input data file can be in any format, output is always in CTF format. The \n"
                         "user can specifile the way in which the epoch triggers are created from markers\n"
                         "or using the present trial structure.\n\n";

    Help[OP_FILIN        ] = "Input data file with raw MEG, EEG or ADC data.";
    Help[OP_DIROUT       ] = "The name of the directory wherein the EP will be stored in CTF data format.";
    Help[OP_DATTYP       ] = "Choose the data type that you wish to analyze: 1= pure MEG, 2= pure EEG, 3=ADC;";
    Help[OP_PRCOUTLIERS  ] = "Percentage of outliers (epochs with largest maxima will be removed from averaging procedure).";
    Help[OP_DISOVER      ] = "If this option is set an algorithm is applied to disentangle overlapping responses.";
    Help[OP_COMPCOVXX    ] = "If this option is set, the spatial covariance matrix is computed over epoch to epoch variations. If also the temporal covariance is required, a Kronecker product model is assumed and the flip-flop algorithm is used. \n";
    Help[OP_COMPCOVTT    ] = "If this option is set, the temporal covariance matrix is computed over epoch to epoch variations. If also the spatial covariance is required, a Kronecker product model is assumed and the flip-flop algorithm is used. \n";
    Help[OP_BMPOUT       ] = "If this option in set, averaged maps will be stored as bitmaps. You give the first and last sample of the time range for which these maps will be computed. Here -1 indicates last sample. Note: ever other sample is plotted.";
    Help[OP_BMPSCALE     ] = "If bitmap output option is set, you can set here the min, max range to which the averages are scaled. Here (0.,0.) means auto scaling.";
    Help[OP_GFPOUT       ] = "If this option in set, the (square rooted) global field power will be extracted from the averaged data and stored in a text file.";

    Option[OP_FILIN      ] = UOption("DataFile"         ,Help[OP_FILIN ],UOption::FILENAME);
    Option[OP_DIROUT     ] = UOption("FileOut"          ,Help[OP_DIROUT],UOption::DATASETNAME);
    Option[OP_DATTYP     ] = UOption("DT" ,"DataType"   ,Help[OP_DATTYP]     ,1,3,1);
    Option[OP_PRCOUTLIERS] = UOption("OUT","Outliers"   ,Help[OP_PRCOUTLIERS],0.,100.,5.);
    Option[OP_DISOVER    ] = UOption("Dis","Disentangle",Help[OP_DISOVER]);
    Option[OP_COMPCOVXX  ] = UOption("CXX","CovarX"     ,Help[OP_COMPCOVXX]);
    Option[OP_COMPCOVTT  ] = UOption("CTT","CovarT"     ,Help[OP_COMPCOVTT]);
    Option[OP_BMPOUT     ] = UOption("Bmp","Bitmaps"    ,Help[OP_BMPOUT],-1,200000,0,-1);
    Option[OP_BMPSCALE   ] = UOption("Scl","BitMapScale",Help[OP_BMPSCALE], -1000000.,1000000.,-1.,1.);
    Option[OP_GFPOUT     ] = UOption("GFP","GlobFldPow" ,Help[OP_GFPOUT]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    DataType DType = U_DAT_UNKNOWN;
    switch(Option[OP_DATTYP ].GetValue())
    {
    case 1: DType = U_DAT_MEG; break;
    case 2: DType = U_DAT_EEG; break;
    case 3: DType = U_DAT_ADC; break;
    default:
        CI.AddToLog("ERROR: Wrong data type option.\n");
        CI.PressReturnExit();
    }

/* Set filename and epochs*/
    UFileName Fin = UFileName(Option[OP_FILIN].GetFileName());

    UMEEGDataEpochs DatEpo(Fin);
    if(DatEpo.GetError()!=U_OK || SetEp.ArgumentsToObject(&DatEpo)!=U_OK) 
    {
        CI.AddToLog("ERROR: Setting data file %s .\n", (const char*)Fin);
        CI.PressReturnExit();
    }
    SetEp.ApplySettings(&DatEpo);

    if(DatEpo.GetData()->GetNkan(DType)<=0)
    {
        CI.AddToLog("ERROR: No channels of type %s present in file %s .\n", UMEEGDataBase::GetDataTypeText(DType), (const char*)Fin);
        CI.PressReturnExit();
    }
    if(Option[OP_DISOVER].GetValueSet()==true)
    {
        if(Option[OP_COMPCOVXX].GetValueSet()==true || Option[OP_COMPCOVTT].GetValueSet()==true)
        {
            CI.AddToLog("ERROR: Disentangling epoch overlap cannot be combined with spatial or temporal covariance computation.\n");
            CI.PressReturnExit();
        }
    }

    DatEpo.SetEpochs(0, -1);      // In this application: overrule settings from command line arguments and use original trials for filtering
    UFileName OutputFile(Option[OP_DIROUT].GetFileName());
    if(OutputFile.IsPureFile()==true)
        OutputFile = Fin.GetSiblingFileName(OutputFile);

    if(WriteAveragedCTFData(&DatEpo, DType, OutputFile)!=U_OK)
    {
        CI.AddToLog("ERROR: Computing/saving averages. \n");
        CI.PressReturnExit();
    }

    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}


ErrorType WriteAveragedCTFData(UMEEGDataEpochs* TemplateData, DataType DType, UFileName Fout)
{
    const UMEEGDataBase* DataB      = TemplateData->GetData();

    UMEEGDataWriteCTF CTFout(*DataB); 
    if(CTFout.GetError()!=U_OK || CTFout.SetDataFileName(Fout)!=U_OK)
    {
        CI.AddToLog("ERROR: WriteAveragedCTFData(). Setting UMEEGDataWriteCTF() object. \n");
        CI.PressReturnExit();
    }

    switch(DType)
    {
    case U_DAT_MEG: CTFout.SetGridADC(NULL); CTFout.SetGridEEG(NULL); break;
    case U_DAT_EEG: CTFout.SetGridMEG(NULL); CTFout.SetGridADC(NULL); break;
    case U_DAT_ADC: CTFout.SetGridEEG(NULL); CTFout.SetGridMEG(NULL); break;
    }
    
    int NtrialOut = 1;
    ErrorType   E = U_OK;
    if(E==U_OK) E = CTFout.SetNtrial(NtrialOut);
    CTFout.AddComment(CI.GetProperties("//   "));
    CTFout.AddComment("// Template: ");
    CTFout.AddComment(TemplateData->GetProperties("//   "));
    CTFout.AddComment("// EndTemplate: ");

    double Foutlier   = Option[OP_PRCOUTLIERS].GetDubVal1()/100.;

    int NLeft         = SetEp.GetWinStart();
    int NRight        = SetEp.GetWinEnd();
    int NPreTrigger   = NLeft;
    int NewNsampTrial = NRight+NLeft+1;
    if(E==U_OK)     E = CTFout.SetNsampTrial(NewNsampTrial);
    if(E==U_OK)     E = CTFout.SetPreNTriggerPnts(NPreTrigger);
    if(E==U_OK)
    {
        const UMarker* Mark = SetEp.GetTrigger();
        E = CTFout.SetNaver(Mark->GetnEvents());
    }
    if(E!=U_OK || CTFout.WriteHeader()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteAveragedCTFData(). Writing CTF header file. \n");
        CI.PressReturnExit();
    }
    if(CTFout.GetNmeg()>0 && DType==U_DAT_MEG) CTFout.WriteHC();

    double         Dmin = Option[OP_BMPSCALE].GetDubVal1();
    double         Dmax = Option[OP_BMPSCALE].GetDubVal2();
    const UMarker* Mark = SetEp.GetTrigger();
    ErrorType      E2   = U_OK;
    if(E2==U_OK && CTFout.GetNkan(DType)>0)
    {
        UMultiChan*       MC    = NULL;
        UMatrixSymmetric* CovXX = NULL; UMatrixSymmetric** pCovXX = Option[OP_COMPCOVXX].GetValueSet() ? &CovXX  : NULL;
        UMatrixSymmetric* CovTT = NULL; UMatrixSymmetric** pCovTT = Option[OP_COMPCOVTT].GetValueSet() ? &CovTT  : NULL;

        if(Option[OP_DISOVER].GetBOOL()==true) MC = TemplateData->GetOverlapCorrectedAveragedMultiChan(Mark, NLeft, NRight, DType, -1, Foutlier);
        else                                   MC = TemplateData->GetAveragedFilteredMultiChan(Mark, NLeft, NRight, DType, -1, Foutlier, pCovXX, pCovTT, MaxCovIter);

        if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
        {
            CI.AddToLog("ERROR: WriteAveragedCTFData(). Getting averaged data (type = %d).\n", int(DType));
            E2 = U_ERROR;
        }
        else
        {
            switch(SetEp.GetPrep())
            {
            case U_PREP_OFFSET: E2 = MC->DeMeanRows();         break;
            case U_PREP_TREND : E2 = MC->RemoveLinearTrend();  break;
            }
            E2 = CTFout.WriteTrial(MC->GetData(), DType, 0);

            if(CovXX || CovTT)
            {
                bool    ASCII = false;
                UString Name  = "Covar";
                if(DType==U_DAT_MEG) Name+="_MEG"; else{ if(DType==U_DAT_EEG) Name+="_EEG"; else Name+="_ADC"; }
                UFileName FCovXX(CTFout.GetDataFileName().GetDirectory(),Name+"_XX", "cov");
                UFileName FCovTT(CTFout.GetDataFileName().GetDirectory(),Name+"_TT", "cov");
                if(CovXX) ::WriteXX(CTFout.GetDataFileName().GetSiblingFileName(FCovXX), *CovXX, MC->GetSensorGrid(), NULL, UString(), ASCII);
                if(CovTT) ::WriteTT(CTFout.GetDataFileName().GetSiblingFileName(FCovTT), *CovTT, MC->GetSampTime(), UString(), ASCII);
            }
        }
        delete CovXX;
        delete CovTT;
        if(E2==U_OK && Option[OP_BMPOUT].GetValueSet() && (DType==U_DAT_MEG || DType==U_DAT_EEG))
        {
            if(Dmin>=Dmax)
            {
                Dmax =  MC->GetMaxData(true);
                Dmin = -Dmax;
            }
            int       sampb   = Option[OP_BMPOUT].GetValue1(); if(sampb<0) sampb = MC->GetNcol()-1;
            int       sampe   = Option[OP_BMPOUT].GetValue2(); if(sampe<0) sampe = MC->GetNcol()-1;
            int       dims[2] = {800, 800};
            MC->DeMeanRows(); // Remove temporal offset
            MC->DeMeanCols(); // Rereference to average reference
            UBitMap   BM      = MC->GetMapsAsBitmap(dims, Dmin, Dmax, sampb, sampe, 2, U_PALETTE_4);

            UFileName Fbmp    = UFileName(CTFout.GetDataFileName().GetDirectory().Parent(), TemplateData->GetData()->GetDataFileName().GetBaseName(), "bmp");
            Fbmp.InsertBeforeExtension("_");
            Fbmp.InsertBeforeExtension(SetEp.GetTriggerName());
            BM.SaveFile(Fbmp);
        }
        if(Option[OP_GFPOUT].GetBOOL())
        {
            UFieldGraph* FG_GFP = MC->GetLFPowerAsFieldGraph(false);
            if(FG_GFP && FG_GFP->GetError()==U_OK)
            {
                FG_GFP->SquareRoot();
                FG_GFP->SetLabel(SetEp.GetTriggerName());
                UFileName Fgfp = UFileName(CTFout.GetDataFileName().GetDirectory().Parent(), TemplateData->GetData()->GetDataFileName().GetBaseName(), "txt");
                Fgfp.InsertBeforeExtension("_");
                Fgfp.InsertBeforeExtension(SetEp.GetTriggerName());
                Fgfp.InsertBeforeExtension("_GFP");
                FG_GFP->WriteAsText(Fgfp);
            }
        }
        delete MC;
    }
    if(E2!=U_OK)
    {
        CI.AddToLog("ERROR: WriteAveragedCTFData(). Writing averaged CTF data.\n");
        E2 = U_ERROR;
    }

/* Set marker */
    UMarkerArray MarkAr(0, NewNsampTrial, NPreTrigger, CTFout.GetSampleRate());
    UMarker      M(Mark->GetName(), 0, NewNsampTrial, Mark->GetColorAsInt(), "NULL point of average marker", 1, true);
    M.AddEvent(UEvent(0, NLeft));
    MarkAr.AddMarker(&M);
    CTFout.WriteMarkerArray(&MarkAr, true);
    return U_OK;
}

