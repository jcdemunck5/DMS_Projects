/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to convert and align 3D/4D scans.                                 */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    10-03-08   creation
  Jdm    24-08-08   Added smoothing option, changed order of comptation
  Jdm    25-10-08   Added option to set a general IO-directory
                    Added the option to store motion regressors in separate directories
  JdM    08-06-09   Added the option to use trilinear interpolation instead of FFT for motion correction.
  JdM    01-08-13   Also smooth when no motion correction is applied
  JdM    18-02-16   Added option OP_FLIPFMRI to flip fMRI scans
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../ScanList.h"
#include "../../String.h"
#include "../../AnalyzeLine.h"
#include "../../PatTree.h"
#include "../../MatchVol.h"
#include "../../Costminimize.h"
#include "../../FieldGraph.h"

#define VERSION "1.21"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

static UScan* ReadInputFile(UDirectory Dir, UFileName Input, UFileName** XfmIn, UString** XfmOut, int* Nxfm);
static UScan* ReadScan(UFileName XfmIn, UString XfmOut);

enum{
    OP_FILIN,OP_DIROUT,
    OP_DIRIO,OP_MAXNSCAN,OP_FLIPFMRI,OP_ALIGN,OP_THRESH,OP_GLOBS,OP_MOTCOR,OP_MOTCORTRI,OP_SMOOTH,OP_REGDIR,OP_SEPREG,OP_SORDER,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];



int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme converts raw scan data of several formats to the .Patient directory tree format.\n"
                         "Raw scan files and the names of converted files must be given in a text file with the following format:\n"
                         "   Scanconvert1.0                                      // Required file type identifier\n"
                         "   //\n"
                         "   //\n"
                         "   REFERENCE_IN  = \"c:\\data\\My Subject\\MRI\\2\"           // Use quotes to include spaces in input file names\n"
                         "   REFERENCE_OUT =  MRI                                 // No spaces allowed \n"
                         "   SCAN_IN       = \"c:\\data\\My Subject\\MRI\\3\"    \n"
                         "   SCAN_OUT      =  RestingState                        // No spaces allowed \n"
                         "   SCAN_IN       = \"c:\\data\\My Subject\\MRI\\2\"    \n"
                         "   SCAN_OUT      =  MotorTask                           // No spaces allowed \n"
                         "\n"
                         "\n"
                         "The scans are aligned to the reference scan using volume matching. 4D scans can also be motion corrected.\n";

    Help[OP_FILIN    ] = "You must give the file name with all the scans to be converted. This file should at least contain the raw reference scan when the ScanAlign-option is set.";
    Help[OP_DIROUT   ] = "You must give the output directory. The extension .Patient will be added when not present. Directory will be created when it does not yet exist.";
    Help[OP_DIRIO    ] = "You can give a general input/output directory. This string will be prepended to all the names of files and directories refering to input/output scans. (So it will not influence the file name of the Scanconvert file, exampled above)";
    Help[OP_MAXNSCAN ] = "You can set the maximum number of (sub)scans per scan. The subscans after this maximum will be ignored. This option is useful to avoid memory overflows in huge scans.";
    Help[OP_FLIPFMRI ] = "You can flip Left/Right in case of (axial) fMRI scans.";
    Help[OP_ALIGN    ] = "You can align the scans using volume matching.";
    Help[OP_THRESH   ] = "If you use volume matching, scans are thresholded and converted to bytes. Here you can set the thresholds applied for the reference c.q. transformed scanned.";
    Help[OP_GLOBS    ] = "If you use volume matching, you can use a global search before the iterative search. Then you must specify step size and search range in cm.";
    Help[OP_MOTCOR   ] = "You can apply motion correction for 4D scans. For 3D scans this option is ignored.";
    Help[OP_MOTCORTRI] = "Use trilinear interpolation instead of FFTW interpolation when computing the motion corrected aligned scans. FFTW is more accurate but can produce artefacts when outliers are present in the data.";
    Help[OP_SMOOTH   ] = "You can spatially smooth 4D scans with a Gaussian profile with given standard deviation. For 3D scans this option is ignored.";
    Help[OP_REGDIR   ] = "When motion correction is apllied, the motion correction parameters can be stored in a given regression directory. If this otion is not set, motion parameters will be stored in converted .Patient directory.";
    Help[OP_SEPREG   ] = "If motion correction is applied and motion regressors are saves, you can either save regressors of different scans under different file names (skip this option) or under different sub-directories of the give regression directory (set this option).";
    Help[OP_SORDER   ] = "You can set (overwrite the default) slice order of 4D scans that are processed (3D scans are ignored by this option) (0=Axial, bottom to top, 1=Axial, top to bottom, 2=Coronal front to post, 3=Coronal post to front, 4=Sagital left to right, 5=Sagital right to left, 6=All at once, 7=Unknown)";

    Option[OP_FILIN    ] = UOption("Scans.txt",Help[OP_FILIN], UOption::FILENAME);
    Option[OP_DIROUT   ] = UOption("Output.Patient",Help[OP_DIROUT], UOption::DATASETNAME);
    Option[OP_DIRIO    ] = UOption("Dir","IOdirectory",Help[OP_DIRIO],"d:\\data\\");
    Option[OP_FLIPFMRI ] = UOption("FfM","FlipfMRI", Help[OP_FLIPFMRI]);
    Option[OP_MAXNSCAN ] = UOption("Mss","MaxSubScans", Help[OP_MAXNSCAN], -1, 10000, -1);
    Option[OP_ALIGN    ] = UOption("Aln","Align",Help[OP_ALIGN]);
    Option[OP_THRESH   ] = UOption("Thr","Threshold",Help[OP_THRESH], 0, 32000, 100, 100);
    Option[OP_GLOBS    ] = UOption("GS" ,"StepRange",Help[OP_GLOBS], 0.01, 100.,1.,5.);
    Option[OP_MOTCOR   ] = UOption("Mot","MotionCorrect",Help[OP_MOTCOR]);
    Option[OP_MOTCORTRI] = UOption("Lin","TriLinearInt",Help[OP_MOTCORTRI]);
    Option[OP_SMOOTH   ] = UOption("Smo","Smooth",Help[OP_SMOOTH], 0., 10., 0.25);
    Option[OP_REGDIR   ] = UOption("Reg","RegDirectory",Help[OP_REGDIR],"Regressor");
    Option[OP_SEPREG   ] = UOption("Sep","SeparateDirs",Help[OP_SEPREG]);
    Option[OP_SORDER   ] = UOption("Sor","SliceOrder",Help[OP_SORDER],0,7,7);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    bool FlipfMRI = Option[OP_FLIPFMRI].GetBOOL();
    bool MotCor   = Option[OP_MOTCOR  ].GetBOOL();
    bool RegDir   = Option[OP_REGDIR  ].GetValueSet();
    bool SepDir   = Option[OP_SEPREG  ].GetBOOL();
    
    if(RegDir==true && MotCor==false)
    {
        CI.AddToLog("ERROR: Regressor directory set, but no motion correction computed. \n");
        CI.PressReturnExit(true);
    }
    if(SepDir==true && (RegDir==false||MotCor==false))
    {
        CI.AddToLog("ERROR: You have chosen to put motion regressors in seperate sub-directories, but no regression directory set, or no motion regressors computed. \n");
        CI.PressReturnExit(true);
    }

    UDirectory Dir;
    if(Option[OP_DIRIO].GetValueSet()) Dir = UDirectory(Option[OP_DIRIO].GetString());
    UFileName  Input(Option[OP_FILIN].GetFileName());
    UFileName* XfmIn    = NULL; 
    UString*   XfmOut   = NULL; 
    int        Nxfm     = 0;
    UScan*     RefScan  = ReadInputFile(Dir, Input, &XfmIn, &XfmOut, &Nxfm);

    if(RefScan==NULL || RefScan->GetError()!=U_OK)
    {
        delete[] XfmIn ;
        delete[] XfmOut;
        delete   RefScan; 
        CI.AddToLog("ERROR: Reference scan not present in input file (%s)", (const char*)Input);
        CI.PressReturnExit(true);
    }
    UFileName P = Dir + UFileName(Option[OP_DIROUT].GetFileName()); P.ReplaceExtension(".Patient");    
    UDirectory PatDir((const char*)P);
    if(PatDir.CreateDir()!=U_OK)
    {
        delete[] XfmIn ;
        delete[] XfmOut;
        delete   RefScan; 
        CI.AddToLog("ERROR: Output directory cannot be created (%s)", (const char*)PatDir);
        CI.PressReturnExit(true);
    }
    
    UEuler RefToWld;
    UString    Name  = UString(RefScan->GetScanName()) + UString(".scan");
    UDirectory DScan = PatDir.Child((const char*)Name);
    if(DScan.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Reference output directory cannot be created (%s)", (const char*)DScan);
        CI.PressReturnExit(true);
    }
    RefScan->WriteXDR(DScan + UFileName("scan.xdr"));
    RefToWld = UPatTree::GetToWld(RefScan->GetOrientation());
    RefToWld.WriteXDR(DScan + UFileName("scan_to_wld.xdr"));

    SliceOrderType SliOrd = U_SLI_UNKNOWN;
    bool  ForceSliceOrder = Option[OP_SORDER].GetValueSet();
    if(ForceSliceOrder==true)
    {
        switch(Option[OP_SORDER].GetValue())
        {
        case 0:  SliOrd = U_SLI_TB;        break;
        case 1:  SliOrd = U_SLI_BT;        break;
        case 2:  SliOrd = U_SLI_FP;        break;
        case 3:  SliOrd = U_SLI_PF;        break;
        case 4:  SliOrd = U_SLI_LR;        break;
        case 5:  SliOrd = U_SLI_RL;        break;
        case 6:  SliOrd = U_SLI_ALLATONCE; break;
        default: SliOrd = U_SLI_UNKNOWN;
        }
    }
    for(int is=0; is<Nxfm; is++)
    {
        CI.AddToLog("Processing scan %d of %d \n", is, Nxfm);

        UScan*            S = ReadScan(XfmIn[is], XfmOut[is]);
        if(FlipfMRI && S->IsScanList()==true && S->GetOrientation()==U_ORI_AXIAL && S->GetModality()==U_MOD_fMRI)
        {
            CI.AddToLog("Flipping L & R of scan %d of %d \n", is, Nxfm);
            S->ReverseData(2, false);
        }

        UEuler MatchScanToW = UPatTree::GetToWld(S->GetOrientation());
        UEuler     XfmToWld = UPatTree::GetToWld(S->GetOrientation());
        if(S==NULL || S->GetError()!=U_OK)
        {
            delete S;
            CI.AddToLog("ERROR: Reading Xfm Scan. \n");
            continue;
        }
        if(Option[OP_MAXNSCAN].GetValue()>0 && S->IsScanList()==true)
        {
            int NScanMax = Option[OP_MAXNSCAN].GetValue();
            int NScan    = S->GetNscan();
            if(NScanMax<NScan)
            {
                CI.AddToLog("Note: Ignoring last %d scans. \n", NScan-NScanMax);
                if(((UScanList*)S)->RemoveSubScans(0, NScan-NScanMax)!=U_OK)
                {
                    delete S;
                    CI.AddToLog("ERROR: Removing subscans. \n");
                    continue;
                }
            }
        }
        if(Option[OP_ALIGN].GetBOOL()==true)
        {
            UCostminimize CM;
            CM.SetOptMethod(UCostminimize::U_SIMPLEX_BOOST); 
            CM.SetMaxiter(500);
            CM.SetNormalize(true);
            CM.SetTolerance(-1.e-5);
            CM.SetStartOffset(4.);
            UMatchVol Mat(UMatchVol::U_TRILIN, UMatchVol::U_MUTIN2, 2, CM);
            double TransLim =  4.;
            double RotLim   = 25.;
            int    TreshRef = Option[OP_THRESH].GetValue1();
            int    TreshXfm = Option[OP_THRESH].GetValue2();
            UField R(*RefScan);        R.ConvertDataToByte(TreshRef, 10*TreshRef); 
            UField X(*(S));            X.ConvertDataToByte(TreshXfm, 10*TreshXfm); 
            UEuler XFM(RefToWld.GetInverse()*XfmToWld);

            if(Option[OP_GLOBS].GetValueSet()==true)
            {
                double Step  = Option[OP_GLOBS].GetDubVal1();
                double Range = Option[OP_GLOBS].GetDubVal2();
                if(Mat.MatchComputeGlobalShift(&R, &X, &XFM, Step, Range)!=U_OK)
                {
                    CI.AddToLog("ERROR: Global search: %s to Reference. \n", S->GetScanName());
                    continue;
                }
            }
            if(Mat.MatchCompute(&R, &X, &XFM, TransLim, RotLim, 2000.)!=U_OK)
            {
                CI.AddToLog("ERROR: Matching %s to Reference. \n", S->GetScanName());
                continue;
            }
            MatchScanToW = RefToWld * XFM;
        }
        UDirectory DScan = PatDir.Child((const char*)(UString(S->GetScanName()) + UString(".scan4D")));
        if(S->IsScanList()==false)
                   DScan = PatDir.Child((const char*)(UString(S->GetScanName()) + UString(".scan")));
        
        if(DScan.CreateDir()!=U_OK)
        {
            CI.AddToLog("ERROR: Xfm output directory cannot be created (%s)", (const char*)DScan);
            delete S;
            continue;
        }
        XfmToWld    .WriteXDR(DScan + UFileName("scan_to_wld.xdr"));
        MatchScanToW.WriteXDR(DScan + UFileName("match_scan_to_wld.xdr"));
        if(S->IsScanList()==false) 
        {
            S->WriteXDR(DScan + UFileName("scan.xdr"));
        }
        else
        {                
            UScanList* SL = (UScanList*)S;
            if(ForceSliceOrder==true && SL->SetSliceOrder(SliOrd, true)!=U_OK)
                CI.AddToLog("ERROR: Slice order not consistent with orienation. \n");

            if(MotCor==false)
            {
                if(Option[OP_SMOOTH].GetValueSet()==true)
                {
                    double SD = Option[OP_SMOOTH].GetDubVal1();
                    if(SL->Smooth(SD, SD, SD, 0, 0, 0)!=U_OK)
                    {
                        CI.AddToLog("ERROR: Spatial smoothing. \n");
                    }
                    else
                    {
                        UDirectory DScanSmo = PatDir.Child((const char*)(UString(S->GetScanName()) + UString("_SMO.scan4D")));
                        if(DScanSmo.CreateDir()!=U_OK)
                        {
                            CI.AddToLog("ERROR: Smoothing output directory cannot be created (%s)", (const char*)DScan);
                        }
                        else
                        {
                            SL->WriteXDR_4D(DScanSmo + UFileName("scan4D.xdr"));
                            XfmToWld    .WriteXDR(DScanSmo + UFileName("scan_to_wld.xdr"));
                            MatchScanToW.WriteXDR(DScanSmo + UFileName("match_scan_to_wld.xdr"));
                        }
                    }
                }
                else
                {
                    SL->WriteXDR_4D(DScan + UFileName("scan4D.xdr"));
                }
            }
            else
            {
                UCostminimize::OptimizeType Opt    = UCostminimize::U_SIMPLEX;
                int                         Niter  = 50;
                UMatchVol::CostType         Cst    = UMatchVol::U_RMS;
                UFieldGraph**               pTrans = NULL;
                bool                        UseFFT = NOT(Option[OP_MOTCORTRI].GetBOOL());
                if(SL->AlignResample(Opt, Cst, Niter, &pTrans, UseFFT)!=U_OK)
                {
                    CI.AddToLog("ERROR: Performing motion correction on scan %s. \n", SL->GetScanName());
                }
                else
                {
                    if(pTrans)
                    {                            
                        UDirectory DMot = DScan;
                        if(SepDir==false && Nxfm>1)
                        {
                            for(int k=0; k<6; k++) 
                            {
                                UString L = UString(SL->GetScanName()) + UString("_") + pTrans[k]->GetLabel(); 
                                pTrans[k]->SetLabel(L);
                            }
                        }
                        if(RegDir==true)
                        {
                            DMot = PatDir.Child(Option[OP_REGDIR].GetString(), NULL);
                            if(DMot.CreateDir()!=U_OK)
                            {
                                CI.AddToLog("ERROR: Creating regressor directory: %s \n", (const char*)DMot);
                            }
                            if(SepDir==true&&Nxfm>1)
                            {
                                DMot = DMot.Child(SL->GetScanName());
                                if(DMot.CreateDir()!=U_OK)
                                {
                                    CI.AddToLog("ERROR: Creating regressor directory: %s \n", (const char*)DMot);
                                }
                            }
                        }
                        if(DMot.GetStatus()==UDirectory::U_EXIST)
                        {
                            if(SaveGraphs(pTrans, NULL, 6, false, DMot+UFileName("Motion.xdr"))!=U_OK)
                            {
                                CI.AddToLog("ERROR: Saving motion parameters.\n");
                            }
                        }
                    }
                    SL->WriteXDR_4D(DScan + UFileName("scan4D.xdr"));

                    if(Option[OP_SMOOTH].GetValueSet()==true)
                    {
                        double SD = Option[OP_SMOOTH].GetDubVal1();
                        if(SL->Smooth(SD, SD, SD, 0, 0, 0)!=U_OK)
                        {
                            CI.AddToLog("ERROR: Spatial smoothing. \n");
                        }
                        else
                        {
                            UDirectory DScanSmo = PatDir.Child((const char*)(UString(S->GetScanName()) + UString("_SMO.scan4D")));
                            if(DScanSmo.CreateDir()!=U_OK)
                            {
                                CI.AddToLog("ERROR: Smoothing output directory cannot be created (%s)", (const char*)DScan);
                            }
                            else
                            {
                                SL->WriteXDR_4D(DScanSmo + UFileName("scan4D.xdr"));
                                XfmToWld    .WriteXDR(DScanSmo + UFileName("scan_to_wld.xdr"));
                                MatchScanToW.WriteXDR(DScanSmo + UFileName("match_scan_to_wld.xdr"));
                            }
                        }
                    }
                }
            }
        }
        delete S;
    }
    delete[] XfmIn ;
    delete[] XfmOut;
    delete   RefScan; 
    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}

UScan* ReadInputFile(UDirectory Dir, UFileName Input, UFileName** XfmIn, UString** XfmOut, int* Nxfm)
{
    if(XfmIn==NULL || XfmOut==NULL || Nxfm==NULL)
    {
        CI.AddToLog("ERROR: ReadInputFile(). Invalid NULL pointer.\n");
        return NULL;
    }
    *XfmIn          = NULL;
    *XfmOut         = NULL;
    *Nxfm           = 0;
    FILE*  fp       = fopen(Input, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("WARNING: ReadInputFile(). Opening: %s \n", (const char*)Input);
        Input    = Dir + Input;
        fp       = fopen(Input, "rt", false);
        if(fp==NULL)
        {
            CI.AddToLog("ERROR: ReadInputFile(). Opening: %s \n", (const char*)(Input));
            return NULL;
        }
    }
    int NLines = GetNLines(fp);
    if(NLines<=0)
    {
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). File %s empty.\n", (const char*)Input);
        return NULL;
    }
    *XfmIn  = new UFileName[NLines];
    *XfmOut = new UString  [NLines];
    if(*XfmIn==NULL || *XfmOut==NULL)
    {
        delete[] XfmIn ; *XfmIn  = NULL;
        delete[] XfmOut; *XfmOut = NULL;
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). Memory allocation (NLines=%d).\n", NLines);
        return NULL;
    }

    char TestString[20];
    memset(TestString, 0, sizeof(TestString));
    fread(TestString, sizeof(TestString), 1, fp);
    if(strncmp("Scanconvert1.0", TestString, sizeof("Scanconvert1.0")-1))
    {
        delete[] XfmIn ; *XfmIn  = NULL;
        delete[] XfmOut; *XfmOut = NULL;
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). Invalid file or version: TestString[] = %s (should be %s  (Case SENSITIVE)).\n", TestString, "Scanconvert1.0");
        return NULL;
    }

    UScan* RefScan  = NULL;
    *Nxfm           = 0;
    char line[500];
    rewind(fp);
    while(GetLine(line, sizeof(line),fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsCommentLine()==true || AA.IsEmptyLine()==true) continue;

/* Read reference scan and set new name */        
        if(AA.IsIdentifierIs("REFERENCE_IN", true)==true)
        {
            const char* RefName = AA.GetNextFileName(sizeof(line), NULL);
            while(GetLine(line, sizeof(line), fp))
            {
                UAnalyzeLine AA(line);
                if(AA.IsCommentLine()==true || AA.IsEmptyLine()==true) continue;
                if(AA.IsIdentifierIs("REFERENCE_OUT", true)==false)
                {
                    delete[] *XfmIn ; *XfmIn  = NULL;
                    delete[] *XfmOut; *XfmOut = NULL;
                    delete    RefScan; 
                    fclose(fp);
                    CI.AddToLog("ERROR: ReadInputFile(). KeyWord REFERENCE_OUT not found. \n");
                    return NULL;
                }
                RefScan = ReadScan(Dir+UFileName(RefName), UString(AA.GetNextString(sizeof(line),"RefScan")));
                if(RefScan==NULL || RefScan->GetError()!=U_OK) 
                {
                    delete[] *XfmIn ; *XfmIn  = NULL;
                    delete[] *XfmOut; *XfmOut = NULL;
                    delete    RefScan; 
                    fclose(fp);
                    CI.AddToLog("ERROR: ReadInputFile(). File not found. \n");
                    return NULL;
                }
                break;
            }
            CI.AddToLog("Reference Read successfully! \n");
        }

/* Read transformed scan(s) and set new name(s) */        
        if(AA.IsIdentifierIs("SCAN_IN", true)==true)
        {
            const char* XfmName = AA.GetNextFileName(sizeof(line), NULL);
            (*XfmIn)[*Nxfm]     = Dir+UFileName(XfmName);
            if((*XfmIn)[*Nxfm].DoesFileExist()==false)
            {
                UDirectory Dirin((const char*)(*XfmIn)[*Nxfm]);
                if(Dirin.GetStatus()!=UDirectory::U_EXIST)
                {
                    CI.AddToLog("WARNING: ReadInputFile(). Directory/File does not exist: %s \n", (const char*)(*XfmIn)[*Nxfm]);
                    continue;
                }
            }
            while(GetLine(line, sizeof(line), fp))
            {
                UAnalyzeLine AA(line);
                if(AA.IsCommentLine()==true || AA.IsEmptyLine()==true) continue;
                if(AA.IsIdentifierIs("SCAN_OUT", true)==false)
                {
                    delete[] *XfmIn ; *XfmIn  = NULL;
                    delete[] *XfmOut; *XfmOut = NULL;
                    delete    RefScan; 
                    fclose(fp);
                    CI.AddToLog("ERROR: ReadInputFile(). KeyWord SCAN_OUT not found after SCAN_IN = %s. \n", XfmName);
                    return NULL;
                }
                UString DefName(*Nxfm, "Xfm_%d");
                (*XfmOut)[*Nxfm] = UString(AA.GetNextString(sizeof(line), (const char*)DefName));
                (*Nxfm)++;
                break;
            }
        }        
    }    
    
    fclose(fp);
    return RefScan;
}

UScan* ReadScan(UFileName XfmIn, UString XfmOut)
{
    CI.DisableLogging();
    UScan* S = new UScan(XfmIn); 
    CI.EnableLogging();

    UString Comment = UString(CI.GetProperties("// "))
                    + UString((const char*)XfmIn ,"RawFileIn = %s \n")
                    + UString((const char*)XfmOut,"NewName   = %s \n");

    if(S==NULL || S->GetError()!=U_OK)
    {
        delete S; S=NULL;
        CI.AddToLog("ERROR: ReadScan(). Reading scan %s \n", (const char*)XfmIn);
        return NULL;
    }
    if(S->GetNscan()==1) 
    {
        S->AddFileComments(Comment);
        S->SetScanName((const char*)XfmOut);
        S->CenterCoords(true, true, true);
        return S;
    }
    delete S;

    CI.DisableLogging();
    UScanList* SL = new UScanList(XfmIn);
    CI.EnableLogging();
    if(SL==NULL || SL->GetError()!=U_OK)
    {
        delete SL; SL=NULL;
        CI.AddToLog("ERROR: ReadScan(). Reading scanlist %s \n", (const char*)XfmIn);
        return NULL;
    }
    SL->AddFileComments(Comment);
    SL->SetScanName((const char*)XfmOut);
    SL->ForceUniform(0.05);
    SL->CenterCoords(true, true, true);
    return SL;
}