/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to analyze update histories of cpp files.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    05-10-15   creation
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../Field.h"
#include "../../MedianCut.h"

#define VERSION "1.01"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

enum{
    OP_DIRIN,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

#define TABSIZE 256
#define VECLEN    3


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme reads bmp color files and converts them to indexed .bmp files \n"
                         "that have an optimized 256 color palette. \n";

    Help[OP_DIRIN    ] = "Directory with .bmp files.";
    Option[OP_DIRIN  ] = UOption("Input",Help[OP_DIRIN], UOption::DATASETNAME);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.ResetLogFile();
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UDirectory Dir(Option[OP_DIRIN].GetFileName());
    int        NFiles = 0;
    UFileName* Filar  = Dir.GetAllFileNames("*.bmp", &NFiles);
    if(Filar==NULL || NFiles<=0)
    {
        CI.AddToLog("ERROR: There are no files of the given specifications: %s .\n",Dir);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NFiles);

    for(int n=0; n<NFiles; n++)
    {
        UField Fin(Filar[n]);
        if(Fin.GetError()!=U_OK || Fin.GetBdata()==NULL ||Fin.GetVeclen()!=VECLEN)
        {
            CI.AddToLog("ERROR: File is not a three color bitmap file: %s .\n",(const char*)Filar[n]);
            continue;
        }
        unsigned char* im   = Fin.GetBdata();
        UField*        Fot  = new UField(Fin, true);
        Fot->SetVeclen(1);
        Fot->ConvertDataToByte(0.,1.);
        Fot->SetDataByte(0);
        
        unsigned char* imout   = Fot->GetBdata();
        int            NPoints = Fin.GetNpoints();
        unsigned char* ColTab  = NULL;

        UBlock*        CRoot = GetMedianCut(im, VECLEN, NPoints, TABSIZE, &ColTab);
        for(int i=0; i<NPoints; i++) 
        {
            unsigned char* sp = ColTab + 3*CRoot->FindIndex(im+i*VECLEN);
            imout[i]          = (unsigned char)(0.5 + 0.2989*sp[0]+0.5870*sp[1]+0.1140*sp[2]);
        }
        UFileName F = Filar[n];
        F.InsertBeforeExtension("_256");
        Fot->WriteBitMap(F);
        delete Fot;
        delete[] ColTab;
    }
    delete[] Filar;

    return 0;
}
