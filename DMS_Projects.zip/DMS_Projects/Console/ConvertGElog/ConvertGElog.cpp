/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to convert GE log-files to CTF data sets.         .               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    22-09-09   creation
  Jdm    04-10-12   ConvertLog(). Set empty marker arrays at EpoR and EpoE.
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../CTFDataSet.h"
#include "../../MEEGDataEpochs.h"
#include "../../MEEGDataGELog.h"
#include "../../MEEGDataWriteCTF.h"
#include "../../Marker.h"
#include "../../MarkerArray.h"
#include "../../Grid.h"

#define VERSION    "1.31 "
#define AUTHOR     "Dr. JC de Munck, Dept. PMT, VUMC, Amsterdam"

enum{
    OP_TR,
    OP_NDUMMY,
    OP_NSCAN,
    OP_OUTDIR,
    OP_DIRIN,
    NOPTIONS
};


static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

ErrorType ConvertLog(UDirectory DirIn, UFileName FResp, UFileName FECG, int Ndummy, int Nscan, double TR, UDirectory DirOut);

int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme converts GE physiologically files into CTF dat sets.\n";

    Help[OP_TR     ] = "TR (=length of output trials) in s.";
    Help[OP_NDUMMY ] = "The number of dummy scans preceding the actual protocol.";
    Help[OP_NSCAN  ] = "The number of scans (excluding dummy scans) of the protocol. This will determine the number of trials in the output data set. If you give -1, the number of scans will be determined automatically from the maximum possible number of scans that fit the physiological data.";
    Help[OP_OUTDIR ] = "If this option is set, the string refers to a directory wherein all output files will be placed. If not set, all output files will be placed next to input.";
    Help[OP_DIRIN  ] = "The directory of the files containing the physiological files. The largest two ECG and resp. files will be merged into one CTF data set.";

    Option[OP_TR    ] = UOption("TR" ,"Rep. Time",Help[OP_TR],0.001,100.,2.1);
    Option[OP_NDUMMY] = UOption("Nd" ,"Num. Dummy",Help[OP_NDUMMY],0,1000,3);    
    Option[OP_NSCAN ] = UOption("Ns" ,"Num. Scan",Help[OP_NSCAN],-1,10000,-1);  
    Option[OP_OUTDIR] = UOption("Out","Out",Help[OP_OUTDIR],"");
    Option[OP_DIRIN ] = UOption("Input*",Help[OP_DIRIN], UOption::FILENAME);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    int    Ndummy = Option[OP_NDUMMY].GetValue();
    int    Nscan  = Option[OP_NSCAN ].GetValue();
    double TR     = Option[OP_TR    ].GetDubVal1();

    UDirectory DirOut;
    if(Option[OP_OUTDIR].GetValueSet()==true)
    {
        DirOut = UDirectory(Option[OP_OUTDIR].GetString());
        if(DirOut.CreateDir()!=U_OK)
        {
            CI.AddToLog("Creating output directory.\n");
            CI.PressReturnExit();
        }
    }
/*Select data sets*/   
    const char* DirectIns = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(DirectIns, NULL, false);
    const char* DirName = Dirin.GetDirectoryName();

    int        NDirs    = 0;
    UFileName* DirNamAr = Dirin.GetAllSubdirNames(DirectIns, &NDirs);

    if(DirNamAr==NULL || NDirs<=0)
    {
        delete[] DirNamAr;
        CI.AddToLog("ERROR: There are no files of the give specifications: %s .\n",DirectIns);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d directories to be examined .\n",NDirs);


/*Test whether data selection arguments are compatible */
    int NConvert = 0;
    for(int idir=0; idir<NDirs; idir++)
    {
        UDirectory Dir((const char*)DirNamAr[idir]);
        int        NFile = 0;
        UFileName* Filar = Dir.GetFileNames("*",&NFile);
        if(Filar==NULL || NFile<=0)
        {
            delete[] Filar;
            continue;
        }
        int IndexResp = -1;
        int IndexECG  = -1;
        for(int k=0; k<NFile; k++)
        {
            if(Filar[k].HasAnyExtension()==true) continue;
            UFileName F = Dir + Filar[k];
            if(F.GetFileSize()<10000) continue;

            bool IsResp = F.DoesBaseFileNameStartWith("RespData");
            bool IsECG  = F.DoesBaseFileNameStartWith("EcGData");
            if(IsResp==false && IsECG==false)  continue;

            if(UMEEGDataBase::GetDataFormatType(F)!=U_DATFORM_GELOG) continue;
            if(IsResp) IndexResp = k;
            if(IsECG ) IndexECG  = k;
        }
        if(IndexResp<0 || IndexECG<0)
        {
            CI.AddToLog("WARNING: No physiological files found in dir = %s \n", (const char*)Dir);
            delete[] Filar;
            continue;
        }
        if(ConvertLog(Dir, Dir+Filar[IndexResp], Dir+Filar[IndexECG], Ndummy, Nscan, TR, DirOut)!=U_OK)
            CI.AddToLog("ERROR: Converting .log files in dir = %s \n", (const char*)Dir);
        else 
            NConvert++;

        delete[] Filar;
    }
    CI.AddToLog("Programme converted %d data files succesfully! \n", NConvert);


    delete[] DirNamAr;
    return 0;
}

ErrorType ConvertLog(UDirectory DirIn, UFileName FResp, UFileName FECG, int Ndummy, int Nscan, double TR, UDirectory DirOut)
{
    UMEEGDataEpochs EpoR(FResp);
    UMEEGDataEpochs EpoE(FECG );

    if(EpoR.GetError()!=U_OK || EpoR.GetData()==NULL || EpoR.GetSampleTime_s()<=0.)
    {
        CI.AddToLog("ERROR: ConvertLog(). Reading respiration data (%s).\n", (const char*)FResp);
        return U_ERROR;
    }
    if(EpoE.GetError()!=U_OK || EpoE.GetData()==NULL || EpoE.GetSampleTime_s()<=0.)
    {
        CI.AddToLog("ERROR: ConvertLog(). Reading ecg data (%s).\n", (const char*)FECG);
        return U_ERROR;
    }
    UMarkerArray MarkEmpty;
    EpoR.SetMarkerArray(&MarkEmpty);
    EpoE.SetMarkerArray(&MarkEmpty);

    if(Nscan<0)
    {
        int    NSampTot = EpoE.GetData()->GetNsampTotal();
        double TimeTot  = NSampTot * EpoE.GetSampleTime_s() - Ndummy*TR;
        Nscan           = int(TimeTot/TR);
        if(Nscan<=0)
        {
            CI.AddToLog("ERROR: ConvertLog(). Nscan computed as %d   .\n", Nscan);
            return U_ERROR;
        }
        CI.AddToLog("Note: ConvertLog(). Nscan set to %d   .\n", Nscan);
    }
    UMarker MarkR("Vol", 0, EpoR.GetData()->GetNsampTrial(), 255, "VolResp", 0, true);
    MarkR.AddEvent(int (TR*  Ndummy         /EpoR.GetSampleTime_s() ));
    MarkR.AddEvent(int (TR* (Ndummy+Nscan-1)/EpoR.GetSampleTime_s() ));
    MarkR.AddEquiDistantEvents(0, 1, Nscan-2);
    if(EpoR.AddMarker(&MarkR)!=U_OK || EpoR.SetEpochsMarker(0, int(TR/EpoR.GetSampleTime_s()),"Vol")!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Adding volume marker to resp. data or setting new epochs.\n");
        return U_ERROR;
    }
    UMarker MarkE("Vol", 0, EpoE.GetData()->GetNsampTrial(), 0, "VolECG", 0, true);
    MarkE.AddEvent(int (TR*  Ndummy         /EpoE.GetSampleTime_s() ));
    MarkE.AddEvent(int (TR* (Ndummy+Nscan-1)/EpoE.GetSampleTime_s() ));
    MarkE.AddEquiDistantEvents(0, 1, Nscan-2);
    if(EpoE.AddMarker(&MarkE)!=U_OK || EpoE.SetEpochsMarker(0, int(TR/EpoE.GetSampleTime_s()),"Vol")!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Adding volume marker to ECG data or setting new epochs.\n");
        return U_ERROR;
    }

    if( EpoR.GetSampleTime_s()          != EpoE.GetSampleTime_s()            ||
        EpoR.GetData()->GetNsampTrial() != EpoE.GetData()->GetNsampTrial()   ||
        EpoR.GetNEpoch()                != EpoE.GetNEpoch()                  ||
        EpoR.GetNSampEpoch(0)           != EpoE.GetNSampEpoch(0)             ||
        EpoR.GetData()->GetDateTime()   != EpoE.GetData()->GetDateTime()   )
    {
        CI.AddToLog("ERROR: ConvertLog(). ECG and resp. data not compatible. \n");
        return U_ERROR;
    }


    UCTFDataSet DSOut;
    if(DirOut.GetDirectoryName()==NULL || DirOut.GetDirectoryName()[0]==0)
    {
        UFileName Ftemp((const char*)DirIn); Ftemp.ReplaceExtension(".ds");
        UFileName  FilOut = DirIn.Parent() + UFileName(Ftemp.GetBaseName());
        DSOut             = UCTFDataSet((const char*)FilOut);
    }
    else
    {
        UString S((const char*)DirIn);
        if(S.ReplaceLast('\\', '_')==0) S.ReplaceLast('/', '-');
        if(S.ReplaceLast('\\', '_')==0) S.ReplaceLast('/', '-');
        UFileName F((const char*)S);
        F.ReplaceExtension("ds");
        UFileName  FilOut = DirOut + UFileName(F.GetBaseName());
        DSOut             = UCTFDataSet((const char*)FilOut);
    }
    if(DSOut.CreateDataSet()!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Creating output directory (%s). \n", DSOut.GetDataSetName());
        return U_ERROR;
    }

    UString Comment(CI.GetProperties(" "));
    Comment += UString((const char*)DirIn,  " InputDirectory  = %s  \n");
    Comment += UString((const char*)FResp,  " RespFile        = %s  \n");
    Comment += UString((const char*)FECG ,  " ECGFile         = %s  \n");
    Comment += UString(Ndummy            ,  " NDummyScan      = %d  \n");
    Comment += UString(Nscan             ,  " NScan           = %d  \n");
    Comment += UString(TR                ,  " TR              = %f  \n");

    UGrid   GrADC;
    USensor S1(UVector3(-20.,0.,0.), UVector3(1.,0.,0.), UVector3(-1.,0.,0.), USensor::U_SEN_POINT,"Resp");
    USensor S2(UVector3(-30.,0.,0.), UVector3(1.,0.,0.), UVector3(-1.,0.,0.), USensor::U_SEN_POINT,"ECG");
    if(GrADC.AddSensor(S1)!=U_OK || GrADC.AddSensor(S2)!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Creating sensor grid with ADC channels. \n");
        return U_ERROR;
    }

    UMEEGDataWriteCTF CTFout; 
    CTFout.SetDataFormatType(U_DATFORM_CTF); 
    CTFout.SetDateTimeRef(EpoR.GetData()->GetDateTime());          
    CTFout.SetDataContineous(false);          
    CTFout.SetDataFileName(UFileName(DSOut.GetCTFFileName())); 
    CTFout.SetSampleRate(EpoR.GetSampleRate());           
    CTFout.SetPreNTriggerPnts(0);        
    CTFout.SetNsampTrial(EpoR.GetNSampEpoch(0));         
    CTFout.SetNtrial(EpoR.GetNEpoch());                 
    CTFout.SetNaver(0);               
    CTFout.SetGridREF(NULL);              
    CTFout.SetGridMEG(NULL);              
    CTFout.SetGridEEG(NULL);              
    CTFout.SetGridADC(&GrADC);              
    CTFout.AddComment((const char*)Comment);
 
    if(CTFout.WriteHeader()!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Writing CTF header file. \n");
        return U_ERROR;
    }

/* Convert old to new markers and write marker filename */    
    UMarkerArray Mnew(*EpoR.GetMarkerArray());
    if(Mnew.MergeMarkerArray(EpoE.GetMarkerArray())!=U_OK)
    {
        CI.AddToLog("ERROR: ConvertLog(). Creating creating new UMarkerArray object. \n");
        return U_ERROR;
    }    
    Mnew.RemoveDoubleNames();
    if(Mnew.RedistributeTrials(EpoR.GetEpochs())!=U_OK)
    {
        CI.AddToLog("ERROR: UQMEEGToolCorrectfMRIArt::ComputeSaveCorrectedData(). Redistributing markers over trials. \n");
        return U_ERROR;
    }
    for(int im=0; im<Mnew.GetnMarkers(); im++)
    {
        if(IsStringCompatible(Mnew.GetMarkerName(im), "ECG" , false)) Mnew.SetColor(im, UColor(255,0,0));
        if(IsStringCompatible(Mnew.GetMarkerName(im), "Resp", false)) Mnew.SetColor(im, UColor(0,0,255));
        if(IsStringCompatible(Mnew.GetMarkerName(im), "Vol" , false)) 
        {
            Mnew.SetColor(im, UColor(0,0,0));
            Mnew.DeleteMiddleEvents(im);
            Mnew.AddEquiDistantEvents(im, 0, 1, Nscan-2);
        }
    }

    if(CTFout.WriteMarkerArray(&Mnew, true)!=U_OK)
    {
        CI.AddToLog("ERROR UQMEEGToolCorrectfMRIArt::ComputeSaveCorrectedData(). Error in WriteMarkerFile(). \n");
        return U_ERROR;
    }

    int     NsampTrial = EpoR.GetNSampEpoch(0);
    double* Buffer     = new double[2*NsampTrial];
    if(Buffer==NULL)
    {
        CI.AddToLog("ERROR UQMEEGToolCorrectfMRIArt::ComputeSaveCorrectedData(). Memory allocation (NsampTrial=%d). \n", NsampTrial);
        return U_ERROR;
    }

    for(int it=0; it<CTFout.GetNtrial(); it++)
    {
        double* Rdat = EpoR.GetFilteredData(it, U_DAT_ADC);
        double* Edat = EpoE.GetFilteredData(it, U_DAT_ADC);
        if(Rdat==NULL || Edat==NULL)
        {
            delete[] Rdat;
            delete[] Edat;
            delete[] Buffer;
            CI.AddToLog("ERROR UQMEEGToolCorrectfMRIArt::ComputeSaveCorrectedData(). Reading resp. or ECG data in trial %d \n", it);
            return U_ERROR;
        }
        for(int j=0; j<NsampTrial; j++) Buffer[           j] = Rdat[j]/8.;
        for(int j=0; j<NsampTrial; j++) Buffer[NsampTrial+j] = Edat[j];

        CTFout.WriteTrial(Buffer, U_DAT_ADC, it);
        delete[] Rdat;
        delete[] Edat;
    }

    delete[] Buffer;
    return U_OK;
}

