/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to convert MEG/EEG data into CTF or other data formats.           */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    03-03-10   creation
  JdM    24-07-12   Updated arguments of export functions according to changes dd 11-01-12 and 24-04-12 in MEEGDataEpochsSave.cpp
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include <stdlib.h>

#include "../SetUpMEEGDataEpochs.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../Option.h"
#include "../../MEEGDataEpochs.h"
#include "../../Grid.h"

#define VERSION "1.28 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUMC, Amsterdam"

enum
{
    OP_DIRIN,OP_FILOUT,OP_GOODCH,OP_BADCH,OP_OUTFORM,
    NOPTIONS
};


static const char*     Help[NOPTIONS];
static UOption         Option[NOPTIONS];

#define MAXTRIALLENGTH 100000

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads all MEG/EEG files in the given directory and .\n"
                         "converts them to CTF format.\n";


    Help[OP_DIRIN  ] = "Directory name of input files. This name may contain wild cards, e.g. 'Data\\*.ds' In that case, all data sets compatible with that name will be analyzed (e.g. *SSS.fif).";
    Help[OP_FILOUT ] = "Base name of the output file file";
    Help[OP_GOODCH ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH  ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_OUTFORM] = "Output format (1=CTF, 2=EDF, 3=Text (incl header), 4=ASCII (text without header).";

    Option[OP_DIRIN  ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_FILOUT ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_GOODCH ] = UOption("Gch","GoodCh",Help[OP_GOODCH],NULL);
    Option[OP_BADCH  ] = UOption("Bch","BadCh",Help[OP_BADCH],NULL);
    Option[OP_OUTFORM] = UOption("Out","Format",Help[OP_OUTFORM],1,4,1);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

/* Output formats */
    DataFormatType  DFOut = U_DATFORM_UNKNOWN;
    switch(Option[OP_OUTFORM].GetValue())
    {
    case 1: DFOut = U_DATFORM_CTF;   break;
    case 2: DFOut = U_DATFORM_EDF;   break;
    case 3: DFOut = U_DATFORM_TXT;   break;
    case 4: DFOut = U_DATFORM_ASCII; break;
    }
    if(DFOut==U_DATFORM_UNKNOWN)
    {
        CI.AddToLog("ERROR: Invalid output format (%d). \n", Option[OP_OUTFORM].GetValue());
        CI.PressReturnExit();
    }

/*Select data and Set Epochs*/
    bool IgnoreWildCards = false;
    const char*  Dirs    = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(Dirs, NULL, IgnoreWildCards);
    const char*  DirName = Dirin.GetDirectoryName();  // Base name, before all wild cards

    int        NFiles = 0;
    UFileName* Filar  = Dirin.GetAllFileNames(Dirs, &NFiles);
    if(Filar==NULL || NFiles<=0)
    {
        CI.AddToLog("ERROR: There are no files of the given specifications: %s .\n",Dirs);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NFiles);

    const char* GoodCh = NULL; if(Option[OP_GOODCH].GetValueSet()) GoodCh = Option[OP_GOODCH].GetString();
    const char* BadCh  = NULL; if(Option[OP_BADCH ].GetValueSet()) BadCh  = Option[OP_BADCH ].GetString();

    int NFileConv = 0;
    for(int ifile=0; ifile<NFiles; ifile++)
    {
        UDirectory DirDat = Filar[ifile].GetDirectory();
        const char* DataSetName = DirDat.GetDirectoryName();

        if(IsStringEnding(DataSetName, "hz.ds")==true ||
           IsStringEnding(DataSetName, "hz2.ds")==true)  continue;

        UMEEGDataEpochs EpDat(Filar[ifile], GoodCh, BadCh);
        if(EpDat.GetError()!=U_OK || EpDat.GetData()==NULL || EpDat.GetData()->GetError()!=U_OK)
        {
            CI.AddToLog("WARNING: Skipping erroneous file %s \n", (const char*) Filar[ifile]);
            continue;
        }
        if(EpDat.GetData()->GetDataFormatType()==DFOut)
        {
            CI.AddToLog("WARNING: Skipping file %s because input and output format are identical.\n", (const char*) Filar[ifile]);
            continue;
        }
        const UMEEGDataBase* DatIn    = EpDat.GetData();
        ReReferenceType      MEGreref = U_REF_RAW;
        ReReferenceType      EEGreref = U_REF_RAW;
        if(DatIn->GetDataFormatType()==U_DATFORM_CTF) MEGreref = U_REF_THIRD;

        EpDat.SetRereference(MEGreref, EEGreref);

        if(DatIn->GetNsampTrial()<2 || DatIn->GetNsampTrial()>=MAXTRIALLENGTH)
        {
            int NewNsampTrial = int(3* DatIn->GetSampleRate());
            if(NewNsampTrial<=0) NewNsampTrial = 3000;
            if(NewNsampTrial>=DatIn->GetNsampTrial()*DatIn->GetNtrial())
                NewNsampTrial = DatIn->GetNsampTrial()*DatIn->GetNtrial() -1;

            EpDat.SetEpochs(0, NewNsampTrial, 0, -1);
        }
        else
        {
            EpDat.SetEpochs(-1, -1);
        }

        bool SaveType[U_DAT_NTYPE];
        for(int k=0; k<U_DAT_NTYPE; k++) SaveType[k] = DatIn->GetNChan(UMEEGDataBase::GetDataType(k))>0;

        SaveType[U_DAT_UNKNOWN] = false;
        SaveType[U_DAT_MEGREF ] = false;
        SaveType[U_DAT_EEGREF ] = false;
        SaveType[U_DAT_SSP    ] = false;

        UFileName F = UFileName(Option[OP_FILOUT ].GetFileName());
        UFileName FileOut = Filar[ifile];
        if(DatIn->GetDataFormatType()==U_DATFORM_CTF)
        {
            FileOut = Filar[ifile].GetSiblingFileName(F.GetBaseName());
        }
        else
        {
            if(DFOut==U_DATFORM_CTF)
            {
                FileOut.ReplaceExtension("ds");
            }
            else
            {
                FileOut.InsertBeforeExtension(F.GetBaseName());
            }
        }
        int       iepoch      = -1;
        double    NewSampFreq = 0.;
        bool      InvEEG      = false;
        bool      InvEKG      = false;
        ErrorType E           = U_OK;

        switch(DFOut)
        {
        case U_DATFORM_ASCII:
        case U_DATFORM_TXT:
            {
                bool   WriteHeader    = (DFOut==U_DATFORM_TXT);
                bool   ChanLabels     = (DFOut==U_DATFORM_TXT);
                bool   Transpose      = false;
                bool   FixedFormat    = false;
                bool   SepFiles       = false;
                TimeFormatType FTime= U_TIMEFORM_NOLAB;
                char   Separator      = '\t';
                E = EpDat.WriteTextFile(FileOut, WriteHeader, ChanLabels, Transpose, FixedFormat, SepFiles, FTime, Separator, SaveType, NewSampFreq, iepoch, InvEEG, InvEKG);
            }
        break;

        case U_DATFORM_CTF:
            {
                DataType ConvEKG      = U_DAT_ADC;
                E = EpDat.WriteCTFDataSet(FileOut, SaveType, ConvEKG, NewSampFreq, iepoch, InvEEG, InvEKG);
                if(E==U_OK)
                {
                    UFileName FileXYZ((const char*)FileOut, FileOut.GetBaseName(), NULL);
                    FileXYZ.ReplaceExtension("xyz");
                    EpDat.WriteSensorPositionsXYZ(FileXYZ);
                }
                break;
            }

        case U_DATFORM_EDF:
            {
                E        = EpDat.WriteEDF(FileOut, SaveType, NewSampFreq, iepoch, InvEEG, InvEKG);
                if(E==U_OK)
                {
                    UFileName FileXYZ(FileOut);
                    FileXYZ.ReplaceExtension("xyz");
                    EpDat.WriteSensorPositionsXYZ(FileXYZ);
                }
            }
            break;

        default:
            E = U_ERROR;
        }
        if(E!=U_OK)
            CI.AddToLog("ERROR: Converting data of file %s failed. \n", (const char*) Filar[ifile]);
        else
            NFileConv++;
    }
    CI.AddToLog("Note: %d files converted sucessfully! .\n", NFileConv);
    return 0;
}

