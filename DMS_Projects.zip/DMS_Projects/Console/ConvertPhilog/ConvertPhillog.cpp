/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to compute Philips .log files to CTF format.                      */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    24-08-08   creation
  JdM    24-07-12   Updated arguments of export functions according to changes dd 11-01-12 and 24-04-12 in MEEGDataEpochsSave.cpp
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>

#include "../../Option.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../MEEGDataEpochs.h"
#include "../../MEEGDataPhilipsLog.h"
#include "../../MarkerArray.h"
#include "../../Epochs.h"

#define VERSION "1.22 "
#define AUTHOR  "Dr. JC de Munck, Dep. PMT, VUmc, Amsterdam"


const double TRDEF       = 2.3;
const double SRATEDEF    = 499.993;
#define      STOPMARKER  "0020"

enum ExpType
{
    U_EXP_TOL,
    U_EXP_STROOP,
    U_EXP_FLANKER,
    U_EXP_NEXP
};

typedef struct
{
    ExpType       ET;
    int           NTrial;
    const char*   Name;
    const char*   Description;
} PROTOCOL;


PROTOCOL Prot[U_EXP_NEXP] = {U_EXP_TOL    , 440, "tol"    ,"*tol.log",
                             U_EXP_STROOP , 260, "stroop" ,"*stroop.log",
                             U_EXP_FLANKER, 250, "flanker","*flanker.log"};

enum{
    OP_TR,
    OP_SRATE,
    OP_DIRIN,
    NOPTIONS
};


static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];


int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme converts GE physiologically files into CTF dat sets.\n";

    Help[OP_TR     ]  = "TR (=length of output trials) in s.";
    Help[OP_SRATE  ]  = "The sampling rate of the Philips .log files.";
    Help[OP_DIRIN  ]  = "The directory of the files containing the physiological files from the Philips scanner.";

    Option[OP_TR    ] = UOption("TR" ,"Rep. Time",Help[OP_TR   ],0.001,100.  ,TRDEF);
    Option[OP_SRATE ] = UOption("Sr" ,"Srate"    ,Help[OP_SRATE],0.01 ,10000.,SRATEDEF);
    Option[OP_DIRIN ] = UOption("Dir", Help[OP_DIRIN], UOption::FILENAME);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    UDirectory D(Option[OP_DIRIN ].GetFileName());
    int        NFiles = 0;
    UFileName* F      = D.GetAllFileNames("*.log",&NFiles);
    if(F==NULL || NFiles<=0)
    {
        CI.AddToLog("ERROR: No file(s) found in the give directory (NFiles =%d) \n", NFiles);
        CI.PressReturnExit();
    }
    double TR    = Option[OP_TR   ].GetDubVal1();
    double SRATE = Option[OP_SRATE].GetDubVal1();

    for(int ifil=0; ifil<NFiles; ifil++)
    {
        for(int kexp=0; kexp<U_EXP_NEXP; kexp++)
        {
            if(IsStringCompatible((const char*)F[ifil], Prot[kexp].Description, false)==false) continue;

            UMEEGDataEpochs DatEpo(F[ifil],"v1;v2;resp;gy",NULL);

            if(DatEpo.GetError()!=U_OK                  || DatEpo.GetData()==NULL ||
               DatEpo.GetData()->GetMarkerArray()==NULL || DatEpo.GetData()->GetMarkerArray()->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: Creating UMEEGDataEpochs()-object. \n");
                continue;
            }

            UMarkerArray  M    (*(DatEpo.GetData()->GetMarkerArray()));
            UMarker       Mar20(*(M.GetMarker(STOPMARKER)));
            if(M.GetError()!=U_OK || Mar20.GetError()!=U_OK || Mar20.GetnEvents()<=0)
            {
                CI.AddToLog("ERROR: Stop-marker not found (Name = %s). \n", STOPMARKER);
                continue;
            }
            Mar20.SortEvents();
            int StopSamp  = Mar20.GetAbsSample(Mar20.GetnEvents()-1);

            int LastSamp  = int(StopSamp - TR*SRATE*2                     );
            int FirstSamp = int(LastSamp - TR*SRATE*(Prot[kexp].NTrial-1) );

            UMarker Mnew("Grad", 2, 1, 255, "Gradient, fix srate", 1, true);
            Mnew.SetEvent(0, UEvent(FirstSamp,0));
            Mnew.SetEvent(1, UEvent(LastSamp ,0));

            Mnew.AddEquiDistantEvents(0,1,Prot[kexp].NTrial-2);
            M.AddMarker(&Mnew);
            DatEpo.SetEpochsMarker(0, Mnew.GetMinInterval(), &Mnew);

            for(int k=0; k<M.GetnMarkers(); k++)
                if(IsStringCompatible(M.GetMarker(k)->GetMarkerName(), STOPMARKER, false))
                {
                    M.RemoveMarker(k);
                    k--;
                }

            DatEpo.SetMarkerArray(&M);

            UFileName DS(F[ifil]); DS.ReplaceExtension("ds");
            bool TypAr[U_DAT_NTYPE];
            for(int k=0; k<U_DAT_NTYPE; k++) TypAr[k] = false;
            TypAr[U_DAT_ADC]      = true;
            int       iepoch      = -1;
            double    NewSampFreq = 0.;
            bool      InvEEG      = false;
            bool      InvEKG      = false;

            if(DatEpo.WriteCTFDataSet((const char*)DS,  TypAr, U_DAT_UNKNOWN, NewSampFreq, iepoch, InvEEG, InvEKG)!=U_OK)
            {
                CI.AddToLog("ERROR: Creating CTF data set (%s). \n", DS.GetFullFileName());
                continue;
            }
        }
    }
    return 0;
}
