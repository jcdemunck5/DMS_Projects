/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to convert tiff files to .xdr or .PatTree structure.              */
/*                                                                               */
/*                                                                               */
/*     Zhiqing Zhang(Andy)                                                       */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    02-04-15   creation, converted from Tiff2XDR.cpp
  ZZQ    18-08-14   creation
  ZZQ    18-08-14   succeed to add tifflib to the project, and begin to write
                    the function ReadTiffAsImageData() to read in the tiff files.
  ZZQ    20-08-14   finish ReadTiffAsImageData().
  ZZQ    26-08-13   add function SaveTiffData().
  ZZQ    30-08-13   Gradients3D()
  ZZQ    09-10-13   Mean_Filtering3D()

*/
#include "../../Option.h"

#define VERSION "1.0 "
#define AUTHOR  "Z Zhang and JC de Munck, Dept. PMT VUmc, Amsterdam"

#include"../../FileName.h"
#include"../../Field.h"
#include"../../BitMap.h"
#include"../../PatTree.h"

#include "../../Tiff/tiffio.h"
#include "../../Tiff/tiff.h"



#define Uint16_Max 65535
#define Uint16_Min 0


enum
{
    OP_FILIN,OP_WRIPAT,OP_REF,OP_OUTNAME, OP_PIXXY, OP_PIXZ,
    NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];

void convertBuffer(unsigned char* buffer,int iLengthBuffer, unsigned short* bufferU16); //convert two 8-bit to one 16-bit
UField* ReadTiffAsImageData(UFileName F);


int main(int Nargs, char **Args)
{
    char* Intro  = "This programme computes reads in a (3D) .tif file and converts it to AVS .xdr format or to .\n"
                   ".Patient tree data structure.";


    Help[OP_FILIN    ] = "File name of the input tiff file.";
    Help[OP_WRIPAT   ] = "If this option is set, the output will be stored in .Patient directory with given name.";
    Help[OP_REF      ] = "If this option is set and the output is in the .Patient format, tif file will be treated as reference scan.";
    Help[OP_OUTNAME  ] = "If this option is set, output name will be modified accoring to given string.";
    Help[OP_PIXXY    ] = "Pixel size of output in um.";
    Help[OP_PIXZ     ] = "Slice distance of output in um (z-size of voxels).";

    Option[OP_FILIN    ] = UOption("FileName",Help[OP_FILIN ],UOption::FILENAME);
    Option[OP_WRIPAT   ] = UOption("Pat","WritePat",Help[OP_WRIPAT],"c:\\test.Patient");
    Option[OP_REF      ] = UOption("Ref","Reference",Help[OP_REF]);
    Option[OP_OUTNAME  ] = UOption("Out","OutName",Help[OP_OUTNAME],"");
    Option[OP_PIXXY    ] = UOption("Pxy","PixelSize",Help[OP_PIXXY],0.0000001,1000000.,1.);
    Option[OP_PIXZ     ] = UOption("Pz" ,"SliceThickness",Help[OP_PIXZ],0.0000001,1000000.,1.);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());


    UFileName Fin(Option[OP_FILIN].GetFileName()); 
    if(DoesFileExist(Fin)==false)
    {
        CI.AddToLog("ERROR: File does not exist: %s. \n", (const char*)Fin);
        CI.PressReturnExit();
    }
    UField* Fld = ReadTiffAsImageData(Fin);
    if(Fld==NULL || Fld->GetError()!=U_OK)
    {
        delete Fld;
        CI.AddToLog("ERROR: File cannot be read as UField object: %s. \n", (const char*)Fin);
        CI.PressReturnExit();
    }
    Fld->SetVoxel(Option[OP_PIXXY].GetDubVal1(), Option[OP_PIXXY].GetDubVal1(), Option[OP_PIXZ].GetDubVal1(), true);

    if(Option[OP_WRIPAT].GetValueSet()==false)
    {
        UFileName Fout = Fin;
        if(Option[OP_OUTNAME].GetValueSet()==true) Fout = Fin.GetSiblingFileName(Option[OP_OUTNAME].GetString());
        Fout.SetExtension("xdr");
        if(Fld->WriteXDR(Fout, " Orientation = Sagital \n")!=U_OK)
        {
            delete Fld;
            CI.AddToLog("ERROR: Writing file cannot as .xdr: %s. \n", (const char*)Fin);
            CI.PressReturnExit();
        }
    }
    else
    {
        UDirectory DirOut(Option[OP_WRIPAT].GetString());
        DirOut.SetExtension(".Patient");
        if(DirOut.CreateDir()!=U_OK)
        {
            delete Fld;
            CI.AddToLog("ERROR: Cannot create directory: %s. \n", (const char*)DirOut);
            CI.PressReturnExit();
        }
        UFileName FName = Option[OP_OUTNAME].GetValueSet() ? UFileName(Option[OP_OUTNAME].GetString()) : UFileName(Fin.GetBaseName());
        FName.SetExtension("scan");
        DirOut = DirOut.Child((const char*)FName);
        if(DirOut.CreateDir()!=U_OK)
        {
            delete Fld;
            CI.AddToLog("ERROR: Cannot create directory: %s. \n", (const char*)DirOut);
            CI.PressReturnExit();
        }
        UFileName Fout = DirOut + UFileName("scan.xdr");
        if(Fld->WriteXDR(Fout)!=U_OK)
        {
            delete Fld;
            CI.AddToLog("ERROR: Writing file cannot as .xdr: %s. \n", (const char*)Fin);
            CI.PressReturnExit();
        }
        UEuler XFM = UPatTree::GetToWld(U_ORI_SAGITAL);
        XFM.WriteXDR(Fout.GetSiblingFileName("scan_to_wld.xdr"));
        if(Option[OP_REF].GetBOOL()==false)
            XFM.WriteXDR(Fout.GetSiblingFileName("match_scan_to_wld.xdr"));
    }
    delete Fld;

    return 0;
}


//convert two 8-bit to one 16-bit
void convertBuffer(unsigned char* buffer,int iLengthBuffer, unsigned short* bufferU16)
{
    for (int src = 0, dst = 0; src < iLengthBuffer; dst++)
    {
        int value16 = buffer[src++];
        bufferU16[dst] = (unsigned short)(value16 + (buffer[src++] << 8));
        //m_iMaxIntens = bufferU16[dst] > m_iMaxIntens ? bufferU16[dst] : m_iMaxIntens;
        //m_iMinIntens = bufferU16[dst] < m_iMinIntens ? bufferU16[dst] : m_iMinIntens;
    }
}

UField* ReadTiffAsImageData(UFileName Fin)
{
    TIFF* tiff = TIFFOpen((const char*)Fin, "r");
    if(tiff==NULL)
    {
        return NULL;
    }

    int dimx=0, dimy=0; 
    //get the width and height of the input image
    TIFFGetField(tiff, TIFFTAG_IMAGEWIDTH, &dimx);
    TIFFGetField(tiff, TIFFTAG_IMAGELENGTH, &dimy);
    if(dimx<=0 || dimy<=0)
    {
        return NULL;
    }


    uint16 uBitspersample   = 1;  
    uint16 uSamplesperpixel = 1;  

    TIFFGetField(tiff, TIFFTAG_SAMPLESPERPIXEL, &uSamplesperpixel); 
    TIFFGetField(tiff, TIFFTAG_BITSPERSAMPLE, &uBitspersample);  
    if(uSamplesperpixel != 1)
    {
        return NULL;
    }
    if(uBitspersample != 16)
    {
        return NULL;
    }
    //get the picture length of the tiff image
    TIFFSetDirectory(tiff, 0);

    int dimz = 0;
    do
    {
        dimz++;
    }while(TIFFReadDirectory(tiff));

    if(dimz<=0)
    {
        return NULL;
    }

    int Dims[3] = {dimx, dimy, dimz};

    UField* Fld = NULL;
    if(dimz==1) Fld = new UField(UVector2(), UVector2(dimx-1., dimy-1)        , Dims, UField::U_SHORT, 1);
    else        Fld = new UField(UVector3(), UVector3(dimx-1., dimy-1, dimz-1), Dims, UField::U_SHORT, 1);

    if(Fld==NULL || Fld->GetError()!=U_OK || Fld->GetSdata()==NULL)
    {
        delete Fld;
        return NULL;
    }

    TIFFSetDirectory(tiff, 0);
    int     z                 = 0;
    tdata_t buf               = 0;
    tsize_t scanlineSize      = 0;
    short*  ImLine            = Fld->GetSdata();

    scanlineSize = TIFFScanlineSize(tiff);
    buf          = _TIFFmalloc(scanlineSize);
    if(buf==NULL || scanlineSize!=2*dimx)
    {
        _TIFFfree(buf);
        delete Fld;

        return NULL;
    }
    do
    {
        for (int row = 0; row < dimy; row++)
        {
            TIFFReadScanline(tiff, buf, row);
            convertBuffer((unsigned char*)buf, scanlineSize, (unsigned short*)ImLine);
            //copy data to ImageData
            ImLine += dimx;
        }
        z++;
    }
    while(TIFFReadDirectory(tiff));
    _TIFFfree(buf);
    TIFFClose(tiff);

    return Fld;
}
