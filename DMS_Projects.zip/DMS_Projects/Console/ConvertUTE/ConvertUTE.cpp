/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     Test and repair UTE scans.                                                 */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
Update history

  Who    When       What
  Jdm    17-03-18   creation
  Jdm    17-07-18   Conversion to console application
  JdM    12-09-18   Added log transform as output
*/

#include "../../Option.h"
#include "../../ScanList.h"
#include "../../FileName.h"
#include "../../MatchVol.h"
#include "../../Distribution.h"
#include "../../Drawing.h"

#define VERSION "1.03"
#define AUTHOR  "Dr. JC de Munck, VUmc dept. RNG, Amsterdam"

enum{
    OP_AXIDIR,OP_SLICESTEP,OP_CROPDRAW,OP_DIRIN,OP_FIL1,OP_FIL2,OP_FILOUT,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

UScan GetLogDiff(const UScan* S1, const UScan* S2);

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads in two UTE scans, matches, smoothes and substracts. First scan ans substracted\n"
                         "scans are saved on .Patient format. A delineation of the skin is aded for further processing and\n";
                         "extraction of skin surface using BIAP4D.exe\n";

    Help[OP_DIRIN    ] = "Input directory where UTE scans can be found.";
    Help[OP_FIL1     ] = "Name of first UTE scan.";
    Help[OP_FIL2     ] = "Name of second UTE scan.";
    Help[OP_FILOUT   ] = "Output .Patient directory. If no complete path is given, a .Patient tree is created next to input directory.";
    Help[OP_AXIDIR   ] = "Axial direction of input files. 0=fast direction, 1=middle direction, 2=slow direction. See Biap4D. This option is used to create axial delineations of skin.";
    Help[OP_SLICESTEP] = "Axial delineations of skin are made for an equidistantsubset of slices. Here you can set the period of slices.";
    Help[OP_CROPDRAW ] = "If this option is set, the axial deliations are cropped acoording to the given range.";


    Option[OP_DIRIN    ] = UOption("Input",Help[OP_DIRIN], UOption::FILENAME);
    Option[OP_FIL1     ] = UOption("File1",Help[OP_FIL1 ], UOption::FILENAME);
    Option[OP_FIL2     ] = UOption("File2",Help[OP_FIL2 ], UOption::FILENAME);
    Option[OP_FILOUT   ] = UOption("Output",Help[OP_FILOUT], UOption::FILENAME);
    Option[OP_AXIDIR   ] = UOption("Axi","AxialDir",Help[OP_AXIDIR],0,2,1);
    Option[OP_SLICESTEP] = UOption("Stp","Step",Help[OP_SLICESTEP],1,1000,20);
    Option[OP_CROPDRAW ] = UOption("Crp","Crop",Help[OP_CROPDRAW],-1000.,1000.,-100.,3.);


    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.ResetLogFile();
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    const char* Dirin  = Option[OP_DIRIN    ].GetFileName();
    const char* File1  = Option[OP_FIL1     ].GetFileName();
    const char* File2  = Option[OP_FIL2     ].GetFileName();
    const char* DirPat = Option[OP_FILOUT   ].GetFileName();

    int    dirAxi      = Option[OP_AXIDIR   ].GetValue();
    int    SliceStep   = Option[OP_SLICESTEP].GetValue();
    bool   Crop        = Option[OP_CROPDRAW ].GetValueSet();
    double Ymin        = Option[OP_CROPDRAW ].GetDubVal1();
    double Ymax        = Option[OP_CROPDRAW ].GetDubVal2();

    UDirectory DD(Dirin);
    UFileName FF1  = DD + UFileName(File1);
    UFileName FF2  = DD + UFileName(File2);
    if(FF1.DoesFileExist()==false||FF2.DoesFileExist()==false)
    {
        CI.AddToLog("ERROR: File(s) do not exist: %s and/or %s  .\n", (const char*)FF1, (const char*)FF2);
        CI.PressReturnExit();
    }
    UScanList SL(FF1);
    UScan S1(*SL.GetScan(0));
    
    SL = UScanList(FF2);
    UScan S2(*SL.GetScan(0));
    if(S1.GetError()!=U_OK||S2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Scan(s) Cannot be created from input file(s): %s and/or %s  .\n", (const char*)FF1, (const char*)FF2);
        CI.PressReturnExit();
    }
    UFileName DDtest(DirPat);
    UDirectory DDpat = DDtest.IsPureFile() ? DD.Parent().Sibling(DirPat) : UDirectory(DirPat);
    if(DDpat.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Output .Patient tree cannot be created: %s  .\n", (const char*)DDpat);
        CI.PressReturnExit();
    }

    UMatchVol MM(UMatchVol::U_TRILIN, UMatchVol::U_MUTIN, 3, UCostminimize());
    MM.SetPrintCostToScreen(true);

    UEuler XFM_2to1;
    int      pmin=-1,pmax=-1;
    UField* F1 = new UField(S1); F1->ConvertDataToByte(UField::U_DCONVERT_98PROC, &pmin, &pmax);  pmin=-1; pmax=-1;
    UField* F2 = new UField(S2); F2->ConvertDataToByte(UField::U_DCONVERT_98PROC, &pmin, &pmax);
    MM.MatchCompute(F1, F2, &XFM_2to1);
    CI.AddToLog("Xfm_2_to_1 : \n%s\n",XFM_2to1.PrintMatrix());
    delete F1;
    delete F2;
    UField* F21 = S2.ResampleField(XFM_2to1);
    S2 = UScan(S1, F21);
    delete F21;

    //S1.Smooth(0.05,0.05,0.05,0,0,0);
    //S2.Smooth(0.05,0.05,0.05,0,0,0);

    UField Diff =S1-S2;
    UScan Skull(S2, &Diff);
    Skull.SetLevelSettings(ULevelSettings(-1000, 1000, 0, 300, 50, 100, U_SCALE_LIN, U_PALETTE_RED, false, false));

    S1   .WritePatTreeScan(DDpat.Child("S1.scan"),true);
    Skull.WritePatTreeScan(DDpat.Child("S1-S2.scan"),false);

    Skull = GetLogDiff(&S1, &S2);
    Skull.SetLevelSettings(ULevelSettings(0, 32000, 0, 32000, 4000, 16000, U_SCALE_LIN, U_PALETTE_RED, false, false));
    Skull.WritePatTreeScan(DDpat.Child("LogS1-LogS2.scan"), false);

/* Create and write drawing*/
    UDistribution His(S1, 1);
    int T = int(His.GetFirstMinimum(0));
    CI.AddToLog("Threshold = %d \n",T);
    UDrawing D(&S1, dirAxi, SliceStep, U_LEVEL_LARGER, T, "Skin");
    if(Crop) D.Crop(UVector3(-100.,Ymin,-100.), UVector3(100.,Ymax,100.));
    UEuler ToWld = S1.GetScanToWld();
    D.WriteXDR(DDpat.Child("S1.scan")+UFileName("Skin"), &ToWld);

    return 0;
}

UScan GetLogDiff(const UScan* S1, const UScan* S2)
{
    UField* F1 = S1->GetComponent(0);
    UField* F2 = S2->GetComponent(0);

    if(F1) F1->ConvertData(UField::U_DOUBLE);
    if(F2) F2->ConvertData(UField::U_DOUBLE);
    double* D1  = F1 ? F1->GetDdata()   : NULL;
    double* D2  = F2 ? F2->GetDdata()   : NULL;
    int     NP1 = F1 ? F1->GetNpoints() : NULL;
    int     NP2 = F2 ? F2->GetNpoints() : NULL;

    if(F1==NULL || D1==NULL|| F2==NULL || D2==NULL || NP1!=NP2)
    {
        CI.AddToLog("ERROR: GetLogDiff(). Converting scans to double.\n");
        return UScan();
    }
    
    double Dmin = 0;
    double Dmax = 0;
    for(int n=0; n<NP1; n++, D1++, D2++)
    {
        if(*D1==NULL || *D2==NULL) {*D1=0.; continue;}

        *D1  = log(*D1) - log(*D2);
        Dmin = MIN(Dmin, *D1);
        Dmax = MAX(Dmax, *D1);
    }

    D1  -=NP1;
    for(int n=0; n<NP1; n++, D1++) *D1 = 32000*(*D1-Dmin)/(Dmax-Dmin);
    D1  -=NP1;
    
    UScan Log = *S1;
    Log.SetVeclen(1);
    Log.SetData(D1);
    Log.ConvertData(UField::U_SHORT);
    return Log;
}

