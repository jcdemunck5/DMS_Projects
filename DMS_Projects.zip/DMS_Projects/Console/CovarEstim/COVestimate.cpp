/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for estimating the spatial and temporal covariance matrices from   */
/*     a set of Epochs, using the Maximum Likelyhood estimator                   */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    23-12-99   creation
  JdM    09-06-00   Added new covariance estimation method, based on sample covariance of low power samples
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    25-08-00   Added ExportAverageDS()
  JdM    14-09-00   WriteXX() and WriteTT(). Option to export data in ASCII format
  JdM    05-10-00   Change output of text files a little.
  JdM    06-10-00   Incorporate changes made in UEpochs()-object dd 06-10-00.
                    Added options to analyze other data types than MEG
  JdM    11-10-00   Export spatial EEG covariance in the form of Variance(distance)
                    BUG fix in exporting average EEG
  JdM    17-10-00   USpaceTime::Update(). Substract average from each trial before building Cov. matrix
  JdM    16-02-00   Add special meaning to negative number of iterations. 
                    ExportAverageDS(): Compute "natural" pre-trigger time in exported data set
                    Remove (obsolete) norm from object
                    BUG fixes in computation of SNR and MeanStdDevMean
  JdM    17-02-01   Added ComputeAverage()
  JdM    19-02-01   ExportAverageDS(): Copy .hc file and number of averages
  JdM    14-09-01   EstimateCovariance(): Added option to keep all data in memory.
  JdM    15-09-01   Bug fixes of 14-09-01
 JdM/FB  01-10-01   BUG FIX: ExportAverageDS(). Copy good and bad channels in template of UWriteCTFData()
  JdM    03-07-02   Make use of UMEEGDataEpochs::GetAllFilteredData() when keeping data in memory
                    Add EstimateCovariance() to allow the use of epoch weights.
                    Add GetCovarianceXX() and GetCovarianceTT()
  JdM    09-07-02   WriteTTcovStat(). Added the computation and export of the FFT's of Var and Cov
  JdM    11-07-02   WriteTT() and WriteXX(): insert default file name parameter
                    EstimateCovariance() add parameter.
  JdM    23-07-02   Bug Fix WriteTT(). The changes of 11-07-02 caused the temporal matrix to be written over the spatial matrix
  JdM    11-09-02   Added WriteXXbitmap() and WriteTTbitmap()
                    Remove conditional includes, to allow makefile generation with tmake (Qt)
  FB     10-07-03   Bug Fix Update(). Normalize matrices for EType!=UCOVestimate::U_MAXLIKE: fixed parameter Norm
  FB     21-07-03   Added EstimType::U_LSSUMKP and adapted estimation functions to fit a sum op KP's in LS sense
  FB     03-11-03   Added EstimType::U_MAXLIKECDM and adapted estimation functions to estimate the ML covariances for the CDM model
  FB     08-06-04   Bug Fix in USpaceTime::Update() : UpdateError now equals relative difference in matrix power (squared entries)
  FB     22-06-04   Added StartFromOldCov in EstimateCovariance() and ScaleInitCov()
  FB     02-07-04   Added SampCovPower and CovPowKP[] for computation of matrix power
  JdM    07-02-05   declared some undeclared identifiers (for g++-compatibility)
                    Added WriteXXmap()
  FB/JdM 07-05-06   Bug fix: WriteXXcovDist(). Insert "fopen"
  FB     09-08-06   Update(): adapt normalization: use NormalizeMat() in all cases
                    Bug fix EstimateCovariance(): computation of explained power for not LS cases. Now relative difference is computed.
  JdM/FB 10-08-06   Delete XXnew[] and TTnew[] in ScaleInitCov(). 
  JdM    09-03-07   Bug fix: Compute SampCovPower only in case EType==EstimType::U_SUMKPLS
  JdM    05-03-08   MAJOR update. Adapted sources to new directory structure (PMT_Projects iso MCAProjects_6)
*/ 

#include <string.h>
#include "COVestimate.h"
#include "../../MEEGDataCTF.h"
#include "../../MEEGDataWriteCTF.h"
#include "../../Covariance.h"
#include "../../BitMap.h"
#include "../../Epochs.h"
#include "../../Matrix.h"
#include "../../MapFile.h"
#include "../../Fftw/rfftw/rfftw.h"
#include "../../Distribution.h"
#include "../../Directory.h"
#include "../../CTFDataSet.h"
#include "../../Grid.h"

/* Inititalize static const parameters. */
const int UCOVestimate::MAXPROPERTIES = 500;

UCOVestimate::UCOVestimate(const char* DataSetName, const char* forceGoodCh, const char* forceBadCh) : UMEEGDataEpochs(DataSetName, forceGoodCh, forceBadCh)
{
    error            = UMEEGDataEpochs::GetError();
    EigenThreshold   = 0.;
    ErrorThreshold   = 0.;
    DType            = U_DAT_UNKNOWN;
    EType            = U_MAXLIKE;
    nEpoch           = 0;
    DatAv            = NULL;
    EpWeights        = NULL;
    DatAll           = NULL;
    XX               = NULL;
    TT               = NULL;
    for(int i=0;i<MAXKP;i++)
    {
        XXKP[i]      = NULL;
        TTKP[i]      = NULL;
        CovPowKP[i]  = 0.;
    }
    SampCovPower     = 0.;
    
    Properties       = NULL;
    nT      = nX     = 0;
    Niter            = 0;

    RelPowerThresh   = 0.;   
    AbsPowerThresh   = 0.;   
    nLow             = 0;
    SNR              = 0.;
    MeanStdDevMean   = 0.;
   

    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL) 
    {
        CI.AddToLog("ERROR: UCOVestimate::UCOVestimate(). Memory allocation. \n");
        error = U_ERROR;
    }
}

UCOVestimate::~UCOVestimate()
{
    if(DatAll)
        for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
    delete[] DatAll;
    delete[] DatAv;
    delete[] EpWeights;
    delete[] Properties;    
    delete   XX;
    delete   TT;
    for(int i = 0; i<MAXKP; i++)
    {
        delete XXKP[i];
        delete TTKP[i];
    }
}

ErrorType UCOVestimate::ComputeAverage(DataType DT)
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::ComputeAverage(). Data not set.\n");
        return U_ERROR;
    }
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::ComputeAverage(). Epochs not set.\n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UCOVestimate::ComputeAverage(). Epochs have difference sizes.\n");
        return U_ERROR;
    }
    if(DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UCOVestimate::ComputeAverage(). Unknown data type.\n");
        return U_ERROR;
    }
    DType   = DT;
    nT      = Epochs->GetNsamp(0);
    nX      = Data->GetNkan(DType);
    if(nX<=0 || nT<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::ComputeAverage(). Number of channels (%d) or number of samples (%d) is illegal.\n",nX,nT);
        return U_ERROR;
    }
    nEpoch = Epochs->GetnEpochs();

/* Delete old data, which is possibly present.*/
    if(DatAll)
        for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
    delete[] DatAll;    DatAll    = NULL;
    delete[] DatAv;     DatAv     = NULL;
    delete[] EpWeights; EpWeights = NULL;
    delete   XX;        XX        = NULL;
    delete   TT;        TT        = NULL;

/* Compute average*/    
    DatAv   = GetAveragedData(DType, NULL);

    if(DatAv==NULL)
    {
        delete[] DatAv;   DatAv   = NULL;
        CI.AddToLog("ERROR: ComputeAverage(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
        return U_ERROR;        
    }
    return U_OK;
}

ErrorType UCOVestimate::EstimateLowPowerCov(double PowThresh, DataType DT)
{
    const int    NBIN        = 10000;
    const double MaxPowerMEG = 1000000;

    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Data not (properly) set.\n");
        return U_ERROR;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Epochs not (properly) set.\n");
        return U_ERROR;
    }
    if(Epochs->GetnEpochs()<=1)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Invalid number of Epochs (%d).\n",Epochs->GetnEpochs());
        return U_ERROR;
    }

    if(DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Unknown data type.\n");
        return U_ERROR;
    }
    DType = DT;
    nX    = Data->GetNkan(DType);
    if(nX<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Number of channels for requested data type is illegal: nX=%d.\n",nX);
        return U_ERROR;
    }
    nT        = 0;                     // No temporal covariance is estimated
    nEpoch    = Epochs->GetnEpochs();

/* Delete old data, which is possibly present.*/
    if(DatAll)
        for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
    delete[] DatAll;    DatAll    = NULL;
    delete[] DatAv;     DatAv     = NULL;
    delete[] EpWeights; EpWeights = NULL;
    delete   XX;        XX        = NULL;
    delete   TT;        TT        = NULL;

    DatAv        = new double[nX];            // Average over all samples
    double* Buf  = new double[nX];            // Sample buffer
    double* CovX = new double[nX*nX];         // Sample covariance over all samples
    UDistribution* Dis = GetAverPowerHistogram(NBIN, MaxPowerMEG, DType);

    if( Dis==NULL   || Dis->GetError()!=U_OK ||
        DatAv==NULL || CovX==NULL || Buf==NULL)
    {
        delete   Dis;
        delete[] DatAv;   DatAv   = NULL;
        delete[] CovX;  
        delete[] Buf;
        CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Memory allocation error. nX=%d\n",nX);
        return U_ERROR;        
    }
    Dis->ReDistribute(0.,5*Dis->GetMedian(),256);

    RelPowerThresh  = PowThresh;
    AbsPowerThresh  = PowThresh*Dis->GetMedian()*nX; // Total value in fT2
    delete   Dis;

    EigenThreshold  = 0;
    ErrorThreshold  = 0;
    EType           = U_LOWPOWER;
    Niter           = 0;

// Compute first and ssecond order moment over all sub-threshold powers
    nLow = 0; // Count all subthreshold samples.
    for(int i=0; i<nX;   i++) DatAv[i] = 0.;
    for(int i=0; i<nX*nX;i++) CovX[i]  = 0;

    CI.TimeReset("Compute covariance matrix.\nNote: Trial ");

    for(int k=0; k<nEpoch; k++)
    {
        CI.AddToLog("%d ",k);

        double* Dat = GetFilteredData(k, DType);
        if(Dat==NULL)
        {
            delete[] DatAv;   DatAv   = NULL;
            delete[] CovX;  
            delete[] Buf;
            CI.AddToLog("ERROR: UCOVestimate::EstimateLowPowerCov(). Cannot get data from Epoch %d.\n", k);
            return U_ERROR;
        }

        int nTime = Epochs->GetNsamp(k);
        for(int j=0; j<nTime; j++)
        {
            double Pow = 0.;
            for(int i=0; i<nX; i++) 
            {
                Buf[i]  = Dat[i*nTime+j];                
                Pow    += Buf[i]*Buf[i];
            }
            if(Pow>AbsPowerThresh) continue;

            nLow++;
            for(int i1=0; i1<nX; i1++)
            {
                DatAv[i1] += Buf[i1];
                for(int i2=0; i2<nX; i2++) CovX[i1*nX+i2] += Buf[i1]*Buf[i2];
            }
        }
        delete[] Dat;
    }

    if(nLow)
    {
        for(int i1=0; i1<nX; i1++)
        {
            DatAv[i1] /= nLow;
            for(int i2=0; i2<nX; i2++) 
                CovX[i1*nX+i2] = CovX[i1*nX+i2]/nLow - DatAv[i1]*DatAv[i2];
        }
    }
    CI.TimeFlag("\nCompute covariance matrix.\n");
    CI.AddToLog("Note: nLow = %d\n",nLow);

    XX = new USpaceTime(CovX, nX, false);

    delete[] CovX;  
    delete[] Buf;

    return U_OK;
}

ErrorType UCOVestimate::EstimateCovariance(double MatThresh, double ErrThresh, EstimType ET, int MaxIter, DataType DT, const double* EpochWeights, bool StartFromOldCov)
{
    if(ET!=U_MAXLIKE && ET!=U_LEASTSQUARES)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Wrong covariance estimation type.\n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Data not set.\n");
        return U_ERROR;
    }
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Epochs not set.\n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Epochs have difference sizes.\n");
        return U_ERROR;
    }
    if(DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Unknown data type.\n");
        return U_ERROR;
    }
    if(EpochWeights==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). EpochWeights = NULL.\n");
        return U_ERROR;
    }
    
    DType   = DT;
    nLow    = 0;   // Not a relevant parameter in this estimation method

    if(StartFromOldCov==true)
    {
        if(nT!=Epochs->GetNsamp(0) || nX!=Data->GetNkan(DType))
        {
            CI.AddToLog("ERROR: UCOVestimate::EstimateSpatialCov(). Dimensions of old covariances (nX,nT) = (%d,%d) different from new ones (%d,%d)\n",nX,nT,Epochs->GetNsamp(0),Data->GetNkan(DType));
            return U_ERROR;
        }
    }
    else
    {
        nT      = Epochs->GetNsamp(0);
        nX      = Data->GetNkan(DType);
    }
    if(nX<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateSpatialCov(). Number of channels for requested data type is illegal: nX=%d.\n",nX);
        return U_ERROR;
    }

    if(nX<2 || nT<2)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Too few samples (nT=%d) or too few channels (nX=%d).\n",nT,nX);
        return U_ERROR;
    }
    nEpoch  = Epochs->GetnEpochs();

/* Delete old data, which is possibly present. */
    delete[] EpWeights; EpWeights = NULL;
    delete[] DatAv;     DatAv     = NULL;

    if(StartFromOldCov==false)
    {
        delete XX; XX = new USpaceTime(nX, USpaceTime::U_SPACE);
        delete TT; TT = new USpaceTime(nT, USpaceTime::U_TIME );

    }
    if(XX==NULL || XX->GetError()!=U_OK || 
       TT==NULL || TT->GetError()!=U_OK)
    {
        delete XX; XX = NULL;
        delete TT; TT = NULL;
        CI.AddToLog("ERROR: EstimateCovariance(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
        return U_ERROR;        
    }

    if(DatAll==NULL) // Get new filtered data
    {
        DatAll= UMEEGDataEpochs::GetAllFilteredData(DType);
        if(DatAll==NULL)
        {
            delete XX; XX = NULL;
            delete TT; TT = NULL;
            CI.AddToLog("ERROR: UCOVestimate::EstimateSpatialCov(). Getting filtered data of all epochs in memory at once.\n");
            return U_ERROR;
        }
    }

/* Copy epoch weights */
    DatAv     = new double[nX*nT];
    EpWeights = new double[nEpoch];
    if(EpWeights==NULL || DatAv==NULL)
    {
        delete[] DatAv;     DatAv     = NULL;
        delete[] EpWeights; EpWeights = NULL;
        delete   XX; XX = NULL;
        delete   TT; TT = NULL;
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Allocating memory for epoch weights or average data, nEpoch=%d, nX=%d, nT=%d .\n", nEpoch, nX, nT);
        return U_ERROR;
    }
    double Norm2 = 0;
    for(int k=0; k<nEpoch; k++) Norm2 += EpochWeights[k]*EpochWeights[k];
    if(Norm2>0.) 
        for(int k=0; k<nEpoch; k++) EpWeights[k] = EpochWeights[k]/Norm2;
    else
    {
        delete[] DatAv;     DatAv     = NULL;
        delete[] EpWeights; EpWeights = NULL;
        delete   XX; XX = NULL;
        delete   TT; TT = NULL;
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). All Weights are zero. \n");
        return U_ERROR;
    }

/* Computed (weighted) average */
    for(int ij=0; ij<nX*nT; ij++) DatAv[ij] = 0;
    for(int Iepoch=0; Iepoch<nEpoch; Iepoch++)
        for(int ij=0;ij<nT*nX; ij++) DatAv[ij] += EpWeights[Iepoch]*DatAll[Iepoch][ij];

/* Update covariances iteratively */ 
    RelPowerThresh  = 0.;
    AbsPowerThresh  = 0.;

    EigenThreshold  = MatThresh;
    ErrorThreshold  = ErrThresh;
    EType           = ET;
    Niter           = 0;

    double TestError = 1.e12;
    if(MaxIter<0)  // Update spatial covariance only, assuming that the trials are uncorrelated in time
    {
        XX->Update(false, this);

        CI.AddToLog("Note: Iter=%d nXeig=%d nTeig=%d; ", Niter++, XX->GetNeig(), TT->GetNeig());
        CI.AddToLog("ErrXX=%12.5g and ErrTT=%12.5g\n", XX->GetUpdateError(), TT->GetUpdateError());
    }
    while(TestError>ErrorThreshold && Niter<=MaxIter)
    {
        XX->Update(true, this);
        TT->Update(false, this);  // Last of both updates should not apply normalization, before decomposition

        CI.AddToLog("Note: Iter=%d nXeig=%d nTeig=%d; ", Niter++, XX->GetNeig(), TT->GetNeig());
        CI.AddToLog("ErrXX=%12.5g and ErrTT=%12.5g\n", XX->GetUpdateError(), TT->GetUpdateError());
        TestError = XX->GetUpdateError()+TT->GetUpdateError();
    }

/* Compute some data statistics */
    double Signal = 0.;
    for(int ij=0; ij<nT*nX; ij++) Signal += DatAv[ij]*DatAv[ij];
    double VarX =0;
    for(int i=0; i<nX; i++) VarX += XX->GetElem(i,i);
    double VarT =0;
    for(int j=0; j<nT; j++) VarT += TT->GetElem(j,j);
    SNR             = Signal/(VarX*VarT);    
    MeanStdDevMean  = sqrt( VarX*VarT/(nT*nX*nEpoch+.5) );
    
    return U_OK;
}

ErrorType UCOVestimate::EstimateCovariance(double MatThresh, double ErrThresh, EstimType ET, int MaxIter, DataType DT, bool AllDataInMem, int StartFromOldCov, int iKP)
{
    if(ET!=U_MAXLIKE && ET!=U_LEASTSQUARES && ET!=U_SUMKPLS && ET!=U_MAXLIKECDM)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Wrong covariance estimation type.\n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Data not set.\n");
        return U_ERROR;
    }
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Epochs not set.\n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Epochs have difference sizes.\n");
        return U_ERROR;
    }
    if(DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Unknown data type.\n");
        return U_ERROR;
    }
    if(iKP<0 || iKP>=MAXKP)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Invalid argument for iKP.\n");
        return U_ERROR;
    }
    
    DType   = DT;
    nLow    = 0;   // Not a relevant parameter in this estimation method
    nT      = Epochs->GetNsamp(0);
    nX      = Data->GetNkan(DType);
    if(nX<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Number of channels for requested data type is illegal: nX=%d.\n",nX);
        return U_ERROR;
    }

    if(nX<2 || nT<2)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Too few samples (nT=%d) or too few channels (nX=%d).\n",nT,nX);
        return U_ERROR;
    }
   nEpoch  = Epochs->GetnEpochs();

/* Delete old data, which is possibly present.*/
    if(ET!=U_SUMKPLS)
    {
        if(DatAll)        
            for(int k=0; k<nEpoch; k++) delete[] DatAll[k];    
        delete[] DatAll;    DatAll    = NULL;    
        delete[] DatAv;     DatAv     = NULL;
    }
    else            
    {
        if(DatAll && iKP==0)  
        {      
            for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
            delete[] DatAll; DatAll = NULL;
            delete[] DatAv;  DatAv  = NULL;
        }
    }

    delete[] EpWeights; EpWeights = NULL;

    if(ET!=U_SUMKPLS)
    {
        delete   XX;
        delete   TT;

        XX      = new USpaceTime(nX, USpaceTime::U_SPACE);
        TT      = new USpaceTime(nT, USpaceTime::U_TIME );
        if(XX==NULL || XX->GetError()!=U_OK || 
           TT==NULL || TT->GetError()!=U_OK)
        {
            delete XX;        XX      = NULL;
            delete TT;        TT      = NULL;
            CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
            return U_ERROR;        
        }
    }
    else
    {       
        delete XXKP[iKP];
        delete TTKP[iKP];

        XXKP[iKP] = new USpaceTime(nX, USpaceTime::U_SPACE);
        TTKP[iKP] = new USpaceTime(nT, USpaceTime::U_TIME );
        if (XXKP[iKP]==NULL || XXKP[iKP]->GetError()!=U_OK ||
            TTKP[iKP]==NULL || TTKP[iKP]->GetError()!=U_OK)             
        {
            delete XXKP[iKP];  XXKP[iKP] = NULL;
            delete TTKP[iKP];  TTKP[iKP] = NULL;
            CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
            return U_ERROR;        
        }
    }

    if(StartFromOldCov==1 || StartFromOldCov==2) // Initialize with existing spatial covariance
    {  
        UString XXOldFile = UString(Data->GetDataFileName().GetDirectory().GetDirectoryName())
                          + UString("\\AverageMEG.ds\\CovarXXOLD.cov");
    
        UCovariance* XXOldCov = new UCovariance(XXOldFile, Data->GetGrid(U_DAT_MEG), Data->GetGrid(U_DAT_EEG));
       
        if(ET==UCOVestimate::U_MAXLIKE||ET==UCOVestimate::U_MAXLIKECDM)   
        {
            delete XX;         
            XX = new USpaceTime(XXOldCov->GetCovMat(), nX, true, USpaceTime::U_SPACE);           
        }
        else if(ET!=UCOVestimate::U_SUMKPLS)
        {
            delete XX;            
            XX = new USpaceTime(XXOldCov->GetCovMat(), nX, false, USpaceTime::U_SPACE);
        }
        else
        {
            delete XXKP[iKP];        
            XXKP[iKP] = new USpaceTime(XXOldCov->GetCovMat(), nX, false, USpaceTime::U_SPACE);
        }       
        delete XXOldCov;
    }
        
    if(StartFromOldCov==1 || StartFromOldCov==3) // Initialize wiht existing temporal covariance
    { 
        UString TTOldFile = UString(Data->GetDataFileName().GetDirectory().GetDirectoryName())
                          + UString("\\AverageMEG.ds\\CovarTTOLD.cov");

        UCovariance* TTOldCov = new UCovariance(TTOldFile, nT);        
        
        if(ET==UCOVestimate::U_MAXLIKE||ET==UCOVestimate::U_MAXLIKECDM)   
        {
            delete TT;
            TT = new USpaceTime(TTOldCov->GetCovMat(), nT, true, USpaceTime::U_TIME);
        }
        else if(ET!=UCOVestimate::U_SUMKPLS)
        {
            delete TT;
            TT = new USpaceTime(TTOldCov->GetCovMat(), nT, false, USpaceTime::U_TIME);
        }
        else
        {
            delete TTKP[iKP];
            TTKP[iKP] = new USpaceTime(TTOldCov->GetCovMat(), nT, false, USpaceTime::U_TIME);       
        }
        delete TTOldCov;
    }

    if(StartFromOldCov)
        ScaleInitCov(StartFromOldCov,iKP);
  
    if(AllDataInMem==true && ET==U_MAXLIKECDM)
    {
        CI.AddToLog("WARNING: UCOVestimate::EstimateCovariance(). Memory option not implemented for CDM estimation method.\n");
    }

    if(AllDataInMem==true && ET!=U_MAXLIKECDM)
    {
      /* Get filtered data and compute (weighted) average*/
        if(DatAll==NULL)  DatAll = UMEEGDataEpochs::GetAllFilteredData(DType); 
        if(DatAv ==NULL)  DatAv = new double[nX*nT];
        if(DatAll==NULL || DatAv==NULL)
        {
            if(DatAll)
                for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
            delete[] DatAll; DatAll = NULL;
            delete[] DatAv;  DatAv  = NULL;
            CI.AddToLog("WARNING: UCOVestimate::EstimateCovariance().Insufficient memory for all data in memory option.\n");
        }
        else
        {
            for(int ij=0; ij<nX*nT; ij++) DatAv[ij] = 0;

            CI.AddToLog("Note:  UCOVestimate::EstimateCovariance(). Average %d Epochs. \n",nEpoch);
            for(int Iepoch=0; Iepoch<nEpoch; Iepoch++)
            {
                for(int ij=0;ij<nT*nX; ij++) DatAv[ij] += DatAll[Iepoch][ij];
            }
            for(int ij=0; ij<nX*nT; ij++) DatAv[ij] /= nEpoch;
            CI.AddToLog("\n");
        }
    }

    int      nDataSets    = 0;
    UString* DataSetNames = NULL;

    if (ET!=U_MAXLIKECDM)
    {
        if(DatAv==NULL) DatAv = GetAveragedData(DType, NULL);
    }
    else
    {
        DataSetNames = GetUsedMarkerNames(&nDataSets); 
        DatAv        = new double[nX*nT*nDataSets];        
        for(int q=0;q<nDataSets;q++)
        {         
            double* DatAvSet = GetAveragedData(DType, DataSetNames[q]);
            if(DatAvSet == NULL)
            {
                delete   XXKP[iKP]; XXKP[iKP] = NULL;
                delete   TTKP[iKP]; TTKP[iKP] = NULL;
                delete   XX;        XX        = NULL;           
                delete   TT;        TT        = NULL;
                
                CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
                return U_ERROR;        
            }
            for(int i=0;i<nX*nT;i++)
                DatAv[q*nX*nT+i] = DatAvSet[i];
        }
    }
    
    if(DatAv==NULL)
    {
        if(DatAll)
            for(int k=0; k<nEpoch; k++) delete[] DatAll[k];
        delete[] DatAll;    DatAll    = NULL;
        delete[] DatAv;     DatAv     = NULL;
        delete   XXKP[iKP]; XXKP[iKP] = NULL;
        delete   TTKP[iKP]; TTKP[iKP] = NULL;
        delete   XX;        XX        = NULL;           
        delete   TT;        TT        = NULL;
        
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Memory allocation error. nX=%d and nT=%d\n",nX,nT);
        return U_ERROR;        
    }
    RelPowerThresh  = 0.;
    AbsPowerThresh  = 0.;

    EigenThreshold  = MatThresh;
    ErrorThreshold  = ErrThresh;
    EType           = ET;
    Niter           = 0;

    double TestError = 1.e12;
    if(MaxIter<0 && EType==EstimType::U_SUMKPLS)
    {
        CI.AddToLog("ERROR: UCOVestimate::EstimateCovariance(). Invalid EstimType with computing only spatial correlations.");
        return U_ERROR;        
    }
    if(MaxIter<0)  // Update spatial covariance only, assuming that the trials are uncorrelated in time
    {
        XX->Update(false, this);

        CI.AddToLog("Note: Iter=%d: nXeig=%d; ", Niter++, XX->GetNeig());
        CI.AddToLog("ErrXX=%12.5g\n", XX->GetUpdateError());
    }
    if(EType != EstimType::U_SUMKPLS)
    {
        while(TestError>ErrorThreshold && Niter<=MaxIter)
        {       
            XX->Update(true, this);
            TT->Update(false, this);  // Last of both updates should not apply normalization, before decomposition

            CI.AddToLog("Note: Iter=%d: nXeig=%d and nTeig=%d; ", Niter++, XX->GetNeig(), TT->GetNeig());
            CI.AddToLog("ErrXX=%12.5g and ErrTT=%12.5g\n", XX->GetUpdateError(), TT->GetUpdateError());
            TestError = XX->GetUpdateError()+TT->GetUpdateError();
        }
    }
    else
    {
        while(TestError>ErrorThreshold && Niter<=MaxIter)
        {       
            XXKP[iKP]->Update(true, this, iKP);
            TTKP[iKP]->Update(false, this, iKP);  // Last of both updates should not apply normalization, before decomposition

            CI.AddToLog("Note: iKP = %d. Iter=%d: nXeig=%d and nTeig=%d; ", iKP, Niter++, XXKP[iKP]->GetNeig(), TTKP[iKP]->GetNeig());
            CI.AddToLog("ErrXX=%12.5g and ErrTT=%12.5g\n", XXKP[iKP]->GetUpdateError(), TTKP[iKP]->GetUpdateError());
            TestError = XXKP[iKP]->GetUpdateError()+TTKP[iKP]->GetUpdateError();
        }
    }

/* In case of DatAll compute power in estimated KP (or sum of KP) */ 
    if(DatAll)
    {
      /* Compute Power of Sample Covariance matrix and store in SampCovPower */
      /* In case of SUMKPLS, SampCovPow is computed only once, when iKP==0 */
        if(EType==EstimType::U_SUMKPLS && iKP==0)
        {
            SampCovPower=0.;
            for(int ij=0;ij<nX*nT;ij++)
            {
                double powdiag = 0.;
                double powoff  = 0.;

                for(int k=0;k<nEpoch;k++)
                    powdiag+= (DatAll[k][ij]-DatAv[ij])*(DatAll[k][ij]-DatAv[ij]);
                powdiag *= powdiag;
                SampCovPower += powdiag;

                for(int iijj=ij+1;iijj<nX*nT;iijj++)
                {
                    double sum = 0.;
                    for(int k=0;k<nEpoch;k++)
                        sum += (DatAll[k][ij]-DatAv[ij])*(DatAll[k][iijj]-DatAv[iijj]);
                    SampCovPower += 2*sum*sum;
                }
            }
            SampCovPower /= ((nEpoch-1)*(nEpoch-1));
        } 
        if(EType != EstimType::U_SUMKPLS && EType != EstimType::U_LEASTSQUARES)
        {
          
        /* Compute relative difference between model and sample cov.
           not explained part is: sample cov - KPmodel .
           explained pow (%) = 100 - 100*|sample cov - KPmodel|^2/|sample cov|^2 
                             = 100 - relative difference 
           Be aware that this can be negative, in case the Kronecker product is not fitting 
           the sample cov well, and hence, the relative difference is over 100% in that case. */

            if(SampCovPower>0) 
            {
                UMatrix Xmat=UMatrix(XX->GetMatrix(),nX,nX);
                UMatrix Tmat=UMatrix(TT->GetMatrix(),nT,nT);                
                
                double* ETXE = new double[nT*nT];
                for(int j=0;j<nT;j++)
                {
                    for(int jj=0;jj<=j;jj++)
                    {
                        ETXE[j*nT+jj] =0.;
                        for(int k=0;k<nEpoch;k++)
                            for(int i=0;i<nX;i++)
                                for(int ii=0;ii<nX;ii++)                            
                                    ETXE[j*nT+jj] += (DatAll[k][i*nT+j]-DatAv[i*nT+j])*Xmat.GetElement(i,ii)*(DatAll[k][ii*nT+jj]-DatAv[ii*nT+jj]);
                    }
                }
                for(int j=0;j<nT;j++)
                    for(int jj=j+1;jj<nT;jj++)                  
                        ETXE[j*nT+jj] =ETXE[jj*nT+j];
            
                UMatrix EXEmat = UMatrix(ETXE,nT,nT);
                double pow= 2*(EXEmat*Tmat).GetTrace()/((nEpoch-1)*SampCovPower);
                pow -= (Xmat.GetNorm())*(Tmat.GetNorm())/SampCovPower;
                CovPowKP[0]= 100*pow;
            }
            else
                CovPowKP[0]= 0.;
        }
        if(EType == EstimType::U_LEASTSQUARES)
        { /* The model is orthogonal component, so the explained power is just the quotient */
            UMatrix Xmat=UMatrix(XX->GetMatrix(),nX,nX);
            UMatrix Tmat=UMatrix(TT->GetMatrix(),nT,nT);
            double pow = (Xmat.GetNorm())*(Tmat.GetNorm());
            if(SampCovPower>0) 
                CovPowKP[0]= 100*pow/SampCovPower;
            else
                CovPowKP[0]= 0.;
        }
        if(EType == EstimType::U_SUMKPLS)
        { /* The model consists of orthogonal components, so the explained power is just the quotient */
            UMatrix Xmat=UMatrix(XXKP[iKP]->GetMatrix(),nX,nX);
            UMatrix Tmat=UMatrix(TTKP[iKP]->GetMatrix(),nT,nT);
            double pow = (Xmat.GetNorm())*(Tmat.GetNorm());
            if(SampCovPower>0) 
                CovPowKP[iKP]= 100*pow/SampCovPower;
            else
                CovPowKP[iKP]= 0.;
        }
        CI.AddToLog("NOTE: Relative matrix power in %d-th estimated KP = %7.2f%%\n",iKP,CovPowKP[iKP]);
    }
   
/* Delete memory */
    if(DatAll && EType != EstimType::U_SUMKPLS)
    {
        for(int k=0; k<nEpoch; k++) delete[] DatAll[k];    
        delete[] DatAll; DatAll = NULL;
    }

/* Compute some data statistics*/
    double Signal = 0.;
    if(EType != EstimType::U_MAXLIKECDM)    
        for(int ij=0; ij<nT*nX; ij++) Signal += DatAv[ij]*DatAv[ij];
    else
        for(int ij=0; ij<nT*nX*nDataSets; ij++) Signal += DatAv[ij]*DatAv[ij];

    double VarX =0;
    double VarT =0;
    if(EType != EstimType::U_SUMKPLS)
    {
        for(int i=0; i<nX; i++) VarX += XX->GetElem(i,i);       
        for(int j=0; j<nT; j++) VarT += TT->GetElem(j,j);
    }
    else
    {
        for(int i=0; i<nX; i++) VarX += XXKP[iKP]->GetElem(i,i);        
        for(int j=0; j<nT; j++) VarT += TTKP[iKP]->GetElem(j,j);
    }    
    SNR             = Signal/(VarX*VarT);    
    MeanStdDevMean  = sqrt( VarX*VarT/(nT*nX*nEpoch+.5) );
    
    return U_OK;
}
    
char* UCOVestimate::GetProperties(const char* Comment) const
{
    memset(Properties, 0, MAXPROPERTIES);
    char Begin[8] = {0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,7);

    char End        = ';';
    if(Comment) End = '\n';
    
    int nc = 0;
    switch(EType)
    {
    case U_MAXLIKE:      nc+= sprintf(Properties+nc,"%s Method=MaximumLikelyhood%c",Begin, End);
        break;
    case U_LEASTSQUARES: nc+= sprintf(Properties+nc,"%s Method=LeastSquares%c",Begin, End);
        break;
    case U_LOWPOWER:     nc+= sprintf(Properties+nc,"%s Method=LowPowerSampleCovariance%c",Begin, End);
        break;
    }
    if(EType==U_LOWPOWER)
    {
        nc += sprintf(Properties+nc,"%sRelPowerThreshold = %f%c",Begin,RelPowerThresh, End);
        nc += sprintf(Properties+nc,"%sAbsPowerThreshold = %e%c",Begin,AbsPowerThresh, End);
        nc += sprintf(Properties+nc,"%sNsubThreshold = %d;%c",Begin, nLow, End);
        nc += sprintf(Properties+nc,"%sNspace = %d;%c",Begin, nX, End);
    }
    else
    {
        if(EpWeights)
            nc += sprintf(Properties+nc,"%sUse Epoch weights%c",Begin, End);
        nc += sprintf(Properties+nc,"%sEigenThreshold  = %e%c",Begin, EigenThreshold , End);
        nc += sprintf(Properties+nc,"%sErrorThreshold = %e%c",Begin, ErrorThreshold, End);
        nc += sprintf(Properties+nc,"%sNspace = %d; Ntime = %d%c",Begin, nX, nT, End);
        if(XX && TT)
            nc += sprintf(Properties+nc,"%sNEigen_space = %d; NEigen_time = %d%c",Begin, XX->GetNeig(), TT->GetNeig(), End);
        nc += sprintf(Properties+nc,"%sIterations = %d%c",Begin, Niter, End);
    }
    if(nc>MAXPROPERTIES)
        CI.AddToLog("ERROR: UCOVestimate::GetProperties(). Array overflow: nc=%d .\n",nc);

    return Properties;
}

#define MAXLABELSIZE 50
ErrorType UCOVestimate::WriteXXmap(const char* BaseFileName, const UCTFDataSet* DSet, int iKP) const
{
    if(iKP<0 && XX==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXmap(). XX not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && XXKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXmap(). XXKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXmap(). Data not set. \n");
        return U_ERROR;
    }

    UFileName F;
    if(DSet==NULL) F = Data->GetDataFileName();
    else           F = UFileName(DSet->GetCTFFileName());
    F.GetSiblingFileName(BaseFileName);
    F.ReplaceExtension(".map");
    F.InsertBeforeExtension("_XX");
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    int   Ntime       = nX+1; // Add variance 
    const UGrid* Grid = Data->GetGrid(DType);
    
    UMapFile MF(Grid, Ntime, 1, "Covariance");
    if(MF.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteXXmap(). Creating UMapFile()-object .\n");
        return U_ERROR;
    }
    
    char*   TrLab = new char [1 * MAXLABELSIZE];
    char** pTrLab = new char*[1];
    if(TrLab==NULL || pTrLab==NULL)
    {
        delete[] TrLab;
        delete[] pTrLab;
        CI.AddToLog("ERROR: WriteXXmap(). Memory allocation for trial labels .\n");
        return U_ERROR;
    }
    for(int it=0; it<1; it++)
    {
        pTrLab[it] = TrLab+it*MAXLABELSIZE;
        sprintf(pTrLab[it],"Covar");
        double* Data = new double[nX*Ntime];
        if(Data==NULL)
        {
            delete[] TrLab;
            delete[] pTrLab;
            CI.AddToLog("ERROR: WriteXXmap(). Memory allocation for data in frequency band %d .\n", it);
            return U_ERROR;
        }
        if(iKP<0)
        {
            for(int i=0; i<nX; i++)
            {
                for(int j=0; j<Ntime; j++)
                    if(j<Ntime-1)
                    {
                        Data[i*Ntime+j]  = XX->GetEigenVector(j, false)[i];
                    }
                    else
                    {
                        Data[i*Ntime+j]  = XX->GetElem(i,i)/XX->GetElem(0,0);
                    }
            }
        }
        else
        {
            for(int i=0; i<nX; i++)
            {
                for(int j=0; j<Ntime; j++)
                    if(j<Ntime-1)
                    {
                        Data[i*Ntime+j]  = XXKP[iKP]->GetEigenVector(j, false)[i];
                    }
                    else
                    {
                        Data[i*Ntime+j]  = XXKP[iKP]->GetElem(i,i)/XXKP[iKP]->GetElem(0,0);
                    }
            }
        }

        if(MF.SetData(Data, it, false)!=U_OK)
        {
            delete[] Data;
            delete[] TrLab;
            delete[] pTrLab;
            CI.AddToLog("ERROR: WriteXXmap(). Setting data in frequency band %d .\n", it);
            return U_ERROR;
        }
        delete[] Data;
    }
    MF.SetTrialLabels(pTrLab);
    delete[] TrLab;
    delete[] pTrLab;

    char*   TiLab = new char [Ntime * MAXLABELSIZE];
    char** pTiLab = new char*[Ntime];
    if(TiLab==NULL || pTiLab==NULL)
    {
        delete[] TiLab;
        delete[] pTiLab;
        CI.AddToLog("ERROR: WriteAsMapFile(). Memory allocation for time labels .\n");
        return U_ERROR;
    }
    for(int j=0; j<Ntime; j++)
    {
        pTiLab[j] = TiLab+j*MAXLABELSIZE;
        if(j<Ntime-1) sprintf(pTiLab[j],"Eigen_%d",j);
        else          sprintf(pTiLab[j],"Diagonal");
    }
    MF.SetMapLabels(pTiLab);
    delete[] TiLab;
    delete[] pTiLab;

    return MF.WriteFile(F.GetFullFileName(), "fT2");
}
#undef MAXLABELSIZE


ErrorType UCOVestimate::WriteXXbitmap(const char* BaseFileName, const UCTFDataSet* DSet, int iKP) const
{
    if(iKP<0 && XX==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXbitmap(). XX not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && XXKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXbitmap(). XXKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXbitmap(). Data not set. \n");
        return U_ERROR;
    }

    unsigned char* BinDat = NULL;
    if (iKP<0)
        BinDat = ConvertCovarToUnsignedChar(XX->GetMatrix(), nX);
    else
        BinDat = ConvertCovarToUnsignedChar(XXKP[iKP]->GetMatrix(), nX);
    if(BinDat==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXbitmap(). Converting spatial covariance to unsigned char. \n");
        return U_ERROR;
    }
    
    UFileName F;
    if(DSet==NULL) F = Data->GetDataFileName();
    else           F = UFileName(DSet->GetCTFFileName());
    F.GetSiblingFileName(BaseFileName);
    F.ReplaceExtension(".bmp");
    F.InsertBeforeExtension("_XX");
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    UBitMap B(nX, nX);
    B.SetImage(BinDat);
    delete[] BinDat;

    B.SetPallette(U_PALETTE_3);
    return B.SaveFile(F);
}

ErrorType UCOVestimate::WriteXXcovDist(const char* BaseFileName, const UCTFDataSet* DSet, int iKP) const
{
    if(iKP<0 && XX==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXcovDist(). XX not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && XXKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXcovDist(). XXKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXcovDist(). Data not set. \n");
        return U_ERROR;
    }

#define NBIN  60
    double bin = .4;
    if(DType==U_DAT_EEG) bin = 1.;

    double Cov[NBIN];
    double Std[NBIN];
    int    Nsens[NBIN];

    for(int k=0; k<NBIN; k++) Cov[k] = Std[k] = Nsens[k] = 0;

    const UGrid* gr = Data->GetGrid(DType);
    for(int i1=0; i1<nX; i1++)
    {
        for(int i2=i1; i2<nX; i2++)
        {
            double dist = Distance(gr->GetSensor(i1), gr->GetSensor(i2));
            int    ibin = int(floor(dist/bin));
            if(ibin<0 || ibin>=NBIN) continue;
            Nsens[ibin]++;

            double term = 0;
            if(DType==U_DAT_EEG)
            {
                if(iKP<0)
                    term = XX->GetElem(i1,i1) - 2.*XX->GetElem(i2,i1) + XX->GetElem(i2,i2);
                else
                    term = XXKP[iKP]->GetElem(i1,i1) - 2.*XXKP[iKP]->GetElem(i2,i1) + XXKP[iKP]->GetElem(i2,i2);
            }
            else
            {
                if(iKP<0)
                    term = XX->GetElem(i1,i2);
                else
                    term = XXKP[iKP]->GetElem(i1,i2);
            }
            Cov[ibin]  += term;
            Std[ibin]  += term*term;
        }
    }
    
    for(int k=0; k<NBIN; k++) 
    {
        if(Nsens[k]==0) 
        {
            Cov[k] = Std[k] = 0;
        }
        else
        {
            Cov[k] /= Nsens[k];
            Std[k]  = sqrt( fabs( Std[k]/Nsens[k] - Cov[k]*Cov[k] ) );
        }
    }
    
    UFileName F;
    if(DSet==NULL) F = Data->GetDataFileName();
    else           F = UFileName(DSet->GetCTFFileName());
    F.GetSiblingFileName(BaseFileName);
    F.ReplaceExtension(".txt");
    F.InsertBeforeExtension("_XX");
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    FILE* fp = fopen(F.GetFullFileName(),"wt");

    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXXcovDist(). Cannot open file: %s \n", (const char*)F);
        return U_ERROR;
    }

    fprintf(fp,"// Origin: \n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// Data:\n");
    fprintf(fp,"%s",Data->GetProperties("//  "));
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"// DataType = MEG\n"); break;
    case U_DAT_EEG: fprintf(fp,"// DataType = EEG\n"); break;
    case U_DAT_ADC: fprintf(fp,"// DataType = ADC\n"); break;
    default:fprintf(fp,"// DataType = Unknown\n"); break;
    }
    fprintf(fp,"// \n");
    fprintf(fp,"// Averaged data:\n");
    fprintf(fp,"// Estimated SNR = %f \n",SNR);
    fprintf(fp,"// Estimated mean standard error of the mean = %f ",MeanStdDevMean);
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"fT \n"); break;
    case U_DAT_EEG: fprintf(fp,"uV\n"); break;
    case U_DAT_ADC: fprintf(fp,"V\n"); break;
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// Eigen values: \n");  
    if( (iKP<0 && XX->GetEigen()) || (iKP>=0 && XXKP[iKP]->GetEigen()) )
    {
        if(iKP<0)
            for(int i=0; i<nX; i++) 
                fprintf(fp,"%f  \t",XX->GetEigen(i)); 
        else
            for(int i=0; i<nX; i++) 
                fprintf(fp,"%f  \t",XXKP[iKP]->GetEigen(i)); 
        fprintf(fp,"\n");
    }
    fprintf(fp,"// \n");

    if(EType==UCOVestimate::U_SUMKPLS && CovPowKP[iKP]>0)
        fprintf(fp,"// Relative matrix power of %d-th KP term = %f\n",iKP,CovPowKP[iKP]);
    if(EType!=UCOVestimate::U_SUMKPLS && CovPowKP[0]>0)
        fprintf(fp,"// Matrix power of Kronecker Product relative to sample covariance matrix = %f\n",CovPowKP[0]);

    fprintf(fp,"// \n");
    if(DType==U_DAT_EEG)
    {
        fprintf(fp,"// Spatial variance as a function of distance.\n");
        fprintf(fp,"Dist [cm] \t Var      \t StDev \t Nsens\n");
    }
    else
    {
        fprintf(fp,"// Spatial covariance as a function of distance.\n");
        fprintf(fp,"Dist [cm] \t Cov      \t StDev \t Nsens\n");
    }
    for(int k=0; k<NBIN; k++)
        fprintf(fp,"%f \t %f \t %f \t %d\n",k*bin, Cov[k], Std[k], Nsens[k]);
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// Variance as a function of channel.\n");
    fprintf(fp,"Chan \t Label \t Variance\n");
    if(iKP<0)
        for(int i1=0; i1<nX; i1++)        
            fprintf(fp,"%d \t %s \t %f\n",i1, gr->GetSensor(i1).GetName(), XX->GetElem(i1,i1));
    else
        for(int i1=0; i1<nX; i1++)        
            fprintf(fp,"%d \t %s \t %f\n",i1, gr->GetSensor(i1).GetName(), XXKP[iKP]->GetElem(i1,i1));
        
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");

    fclose(fp);
    return U_OK;
#undef  NBIN
}

ErrorType UCOVestimate::WriteTTbitmap(const char* BaseFileName, const UCTFDataSet* DSet,int iKP) const
{ 
    if(iKP<0 && TT==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTbitmap(). TT not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && TTKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTbitmap(). TTKP[iKP] not computed. \n");
        return U_ERROR;
    }    
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTbitmap(). Data not set. \n");
        return U_ERROR;
    }

    unsigned char* BinDat = NULL;
    if (iKP<0)
        BinDat = ConvertCovarToUnsignedChar(TT->GetMatrix(), nT);
    else
        BinDat = ConvertCovarToUnsignedChar(TTKP[iKP]->GetMatrix(), nT);
    if(BinDat==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTbitmap(). Converting spatial covariance to unsigned char. \n");
        return U_ERROR;
    }

    UFileName F;
    if(DSet==NULL) F = Data->GetDataFileName();
    else           F = UFileName(DSet->GetCTFFileName());
    F.GetSiblingFileName(BaseFileName);
    F.ReplaceExtension(".bmp");
    F.InsertBeforeExtension("_TT");
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    UBitMap B(nT, nT);
    B.SetImage(BinDat);
    delete[] BinDat;

    B.SetPallette(U_PALETTE_3);
    return B.SaveFile(F);
}

ErrorType UCOVestimate::WriteTTcovStat(const char* BaseFileName, const UCTFDataSet* DSet, int iKP) const
{
    if(iKP<0 && TT==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). TT not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && TTKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). TTKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). Data not set. \n");
        return U_ERROR;
    }   

    double  bin  = 1000./Data->GetSampleRate();
    double* Cov  = new double[nT];
    double* Std  = new double[nT];
    double* Var  = new double[nT];
    int*    Ncov = new int[nT];

    if(Cov==NULL || Std==NULL || Var==NULL || Ncov==NULL)
    {
        delete[] Cov;
        delete[] Std;
        delete[] Var;
        delete[] Ncov;
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). Memory allocation.\n");
        return U_ERROR;
    }

    for(int k=0; k<nT; k++) Cov[k] = Std[k] = Var[k] = Ncov[k] = 0;

    if(iKP<0)
        for(int j1=0; j1<nT; j1++)
        {
            for(int j2=0; j2<nT; j2++)
            {
                int    ibin = abs(j2-j1);
                double term = TT->GetElem(j2,j1);
                Cov[ibin]  += term;
                Std[ibin]  += term*term;
                Ncov[ibin]++;
            }
        }
    else
        for(int j1=0; j1<nT; j1++)
        {
            for(int j2=0; j2<nT; j2++)
            {
                int    ibin = abs(j2-j1);
                double term = TTKP[iKP]->GetElem(j2,j1);
                Cov[ibin]  += term;
                Std[ibin]  += term*term;
                Ncov[ibin]++;
            }
        }

    for(int k=0; k<nT; k++) 
    {
        if(iKP<0) 
            Var[k] = TT->GetElem(k,k);
        else
            Var[k] = TTKP[iKP]->GetElem(k,k);

        if(Ncov[k]==0) continue;

        Cov[k] /= Ncov[k];
        Std[k]  = sqrt( fabs( Std[k]/Ncov[k] - Cov[k]*Cov[k] ) );
    }
    
    UFileName F;
    if(DSet==NULL) F = Data->GetDataFileName();
    else           F = UFileName(DSet->GetCTFFileName());
    F.GetSiblingFileName(BaseFileName);
    F.ReplaceExtension(".txt");
    F.InsertBeforeExtension("_TT");
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    FILE* fp = fopen(F,"wt");

    if(fp==NULL)
    {
        delete[] Cov;
        delete[] Std;
        delete[] Var;
        delete[] Ncov;
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). Cannot open file: %s \n", (const char*)F);
        return U_ERROR;
    }

    fprintf(fp,"// Origin: \n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// Data:\n");
    fprintf(fp,"%s",Data->GetProperties("//  "));
    fprintf(fp,"// \n");
    fprintf(fp,"// Averaged data:\n");
    fprintf(fp,"// Estimated SNR = %f \n",SNR);
    fprintf(fp,"// Estimated mean standard error of the mean = %f ",MeanStdDevMean);
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"fT \n"); break;
    case U_DAT_EEG: fprintf(fp,"uV\n"); break;
    case U_DAT_ADC: fprintf(fp,"V\n"); break;
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",GetProperties("//  "));
    fprintf(fp,"// nT    = %d\n", nT);
    if(iKP<0)
    {
        fprintf(fp,"// nTeig = %d\n", TT->GetNeig());
        fprintf(fp,"// Eigen values: \n// ");
        if(TT->GetEigen())
        {
            for(int i=0; i<nT; i++) 
                fprintf(fp,"%f  \t",TT->GetEigen(i)); 
            fprintf(fp,"\n");
        }
    }
    else
    {
        fprintf(fp,"// nTeig = %d\n", TTKP[iKP]->GetNeig());
        fprintf(fp,"// Eigen values: \n// ");
        if(TTKP[iKP]->GetEigen())
        {
            for(int i=0; i<nT; i++) 
                fprintf(fp,"%f  \t",TTKP[iKP]->GetEigen(i)); 
            fprintf(fp,"\n");
        }
    }  
    fprintf(fp,"// \n");
    if(EType==UCOVestimate::U_SUMKPLS && CovPowKP[iKP]>0)
        fprintf(fp,"// Relative matrix power of %d-th KP term = %f\n",iKP,CovPowKP[iKP]);
    if(EType!=UCOVestimate::U_SUMKPLS && CovPowKP[0]>0)
        fprintf(fp,"// Matrix power of Kronecker Product relative to sample covariance matrix = %f\n",CovPowKP[0]);
    fprintf(fp,"// \n");    
    fprintf(fp,"// Temporal covarance and variance as a function of time distance.\n");
    fprintf(fp,"Sample \t Dist [ms] \t Cov      \t StDev{Cov}  \tVariance(t) \n");
    for(int k=0; k<nT; k++)
        fprintf(fp,"%d \t %f \t %f \t %f \t %f \n",k, k*bin, Cov[k], Std[k], Var[k]);
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// f [Hz]  \tFFT(Cov)  \tFFT(Var) \n");

    double* FFTCov = UCOVestimate::FFTpower(Cov, nT);
    double* FFTVar = UCOVestimate::FFTpower(Var, nT);
    if(FFTCov==NULL || FFTVar==NULL)
    {
        CI.AddToLog("WARNING: UCOVestimate::WriteTTcovStat(). Computing FFT's  .\n");
    }
    else
    {
        double DeltaF = Data->GetSampleRate() / nT; 
        for(int k=0; k<(nT+1)/2; k++)
            fprintf(fp," %f \t %f \t %f \n", k*DeltaF, FFTCov[k], FFTVar[k]);
    }
    fclose(fp);

    delete[] FFTCov;
    delete[] FFTVar;
    delete[] Cov;
    delete[] Std;
    delete[] Var;
    delete[] Ncov;
    return U_OK;
}


ErrorType UCOVestimate::WriteXX(const UCTFDataSet* DSet, const char* FName, bool ASCII, int iKP) const
{
    if(iKP<0 && XX==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXX(). XX not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && XXKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXX(). XXKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXX(). Data not set. \n");
        return U_ERROR;
    }

    UFileName F;
    if(FName==NULL) // Automatic name
    {
        if(DSet==NULL) F = Data->GetDataFileName();
        else           F = UFileName(DSet->GetCTFFileName());
        F.GetSiblingFileName(FName);
    }
    else
    {
        if(DSet==NULL) F = Data->GetDataFileName();
        else           F = UFileName(DSet->GetCTFFileName());
        F.GetSiblingFileName("CovarXX.cov");
    }    
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    FILE* fp = NULL;    

    if(ASCII==true)
    {
        F.ReplaceExtension("txt");
        fp = fopen(F.GetFullFileName(),"wt");
    }
    else
        fp = fopen(F.GetFullFileName(),"wb");

    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteXX(). Cannot open file: %s \n", F.GetFullFileName());
        return U_ERROR;
    }
    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    fprintf(fp,"// Data:\n");
    fprintf(fp,"%s",Data->GetProperties("//  "));
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"// DataType = MEG\n"); break;
    case U_DAT_EEG: fprintf(fp,"// DataType = EEG\n"); break;
    case U_DAT_ADC: fprintf(fp,"// DataType = ADC\n"); break;
    default:fprintf(fp,"// DataType = Unknown\n"); break;
    }
    fprintf(fp,"// \n");
    fprintf(fp,"// Averaged data:\n");
    fprintf(fp,"// Estimated SNR = %f \n",SNR);
    fprintf(fp,"// Estimated mean standard error of the mean = %f ",MeanStdDevMean);
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"fT \n"); break;
    case U_DAT_EEG: fprintf(fp,"uV\n"); break;
    case U_DAT_ADC: fprintf(fp,"V\n"); break;
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",GetProperties("//  "));
    fprintf(fp,"// Eigen values: \n// ");
    if( (iKP<0 && XX->GetEigen()) || (iKP>=0 && XXKP[iKP]->GetEigen()) )
    {
        if(iKP<0)
            for(int i=0; i<nX; i++) 
                fprintf(fp,"%f  \t",XX->GetEigen(i)); 
        else
            for(int i=0; i<nX; i++) 
                fprintf(fp,"%f  \t",XXKP[iKP]->GetEigen(i)); 
        fprintf(fp,"\n");
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = SPACE   // SPACE or TIME \n");
    fprintf(fp,"    nX        = %d      // Number of channels \n", nX);
    const UGrid *gr = Data->GetGrid(DType);
    for(int i=0; i<nX; i++) fprintf(fp,"    SENSOR = %s \n",gr->GetSensor(i).GetProperties());
    fprintf(fp,"}\n");
    
    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12); 
        if (iKP<0)        
            fwrite(XX->GetMatrix(),sizeof(double),nX*nX,fp);
        else
            fwrite(XXKP[iKP]->GetMatrix(),sizeof(double),nX*nX,fp);
    }
    else
    {
        fprintf(fp,"Spatial Covariance Matrix: \n");   
        const double* Mat = NULL;
        if (iKP<0)        
            Mat = XX->GetMatrix();
        else
            Mat = XXKP[iKP]->GetMatrix();
        for(int i1=0; i1<nX; i1++)
        {
            for(int i2=0; i2<nX; i2++) fprintf(fp,"\t%g ",Mat[i1*nX+i2]);
            fprintf(fp,"\n");
        }
    }
    fclose(fp);

    return U_OK;
}

ErrorType UCOVestimate::WriteTT(const UCTFDataSet* DSet, const char* FName, bool ASCII,int iKP) const
{
    if(iKP<0 && TT==NULL)       
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). TT not computed. \n");
        return U_ERROR;
    }
    if(iKP>=0 && TTKP[iKP] == NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). TTKP[iKP] not computed. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTTcovStat(). Data not set. \n");
        return U_ERROR;
    }

    UFileName F;
    if(FName==NULL) // Automatic name
    {
        if(DSet==NULL) F = Data->GetDataFileName();
        else           F = UFileName(DSet->GetCTFFileName());
        F.GetSiblingFileName(FName);
    }
    else
    {
        if(DSet==NULL) F = Data->GetDataFileName();
        else           F = UFileName(DSet->GetCTFFileName());
        F.GetSiblingFileName("CovarTT.cov");
    }    
    if(iKP>=0)  F.InsertFileNumber(iKP,2);

    FILE* fp = NULL;    

    if(ASCII==true)
    {
        F.ReplaceExtension("txt");
        fp = fopen(F.GetFullFileName(),"wt");
    }
    else
        fp = fopen(F.GetFullFileName(),"wb");

    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCOVestimate::WriteTT(). Cannot open file: %s \n", (const char*)F);
        return U_ERROR;
    }
    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    fprintf(fp,"// Data:\n");
    fprintf(fp,"%s",Data->GetProperties("//  "));
    fprintf(fp,"// \n");
    fprintf(fp,"// Averaged data:\n");
    fprintf(fp,"// Estimated SNR = %f \n",SNR);
    fprintf(fp,"// Estimated mean standard error of the mean = %f ",MeanStdDevMean);
    switch(DType)
    {
    case U_DAT_MEG: fprintf(fp,"fT \n"); break;
    case U_DAT_EEG: fprintf(fp,"uV\n"); break;
    case U_DAT_ADC: fprintf(fp,"V\n"); break;
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",GetProperties("//  "));
    fprintf(fp,"// Eigen values: \n");
    if(iKP<0)
    {       
        if(TT->GetEigen())
        {
            for(int i=0; i<nT; i++) 
                fprintf(fp,"%f  \t",TT->GetEigen(i)); 
            fprintf(fp,"\n");
        }
    }
    else
    {   
        if(TTKP[iKP]->GetEigen())
        {
            for(int i=0; i<nT; i++) 
                fprintf(fp,"%f  \t",TTKP[iKP]->GetEigen(i)); 
            fprintf(fp,"\n");
        }
    }    
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = TIME    // SPACE or TIME\n");
    fprintf(fp,"    Ntime = %d   // Number of samples \n",nT);
    fprintf(fp,"    Stime = %f   // ms.\n",1000./Data->GetSampleRate());
    fprintf(fp,"}\n"); 

    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12);
        if(iKP<0)
            fwrite(TT->GetMatrix(),sizeof(double),nT*nT,fp);
        else
            fwrite(TTKP[iKP]->GetMatrix(),sizeof(double),nT*nT,fp);
    }
    else
    {
        fprintf(fp,"Temporal Covariance Matrix: \n");  
        const double* Mat = NULL;
        if (iKP<0)        
            Mat = TT->GetMatrix();
        else
            Mat = TTKP[iKP]->GetMatrix();
        for(int j1=0; j1<nT; j1++)
        {
            for(int j2=0; j2<nT; j2++) fprintf(fp,"\t%g ",Mat[j1*nT+j2]);
            fprintf(fp,"\n");
        }
    }
    fclose(fp);
    
    return U_OK;
}

UCovariance* UCOVestimate::GetCovarianceXX(void) const
{
    if(XX==NULL || XX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::GetCovarianceXX(). XX-object not properly set.\n");
        return NULL;
    }

    switch(DType)
    {
    case U_DAT_MEG: return new UCovariance(*XX, Data->GetGridMEG(), NULL);
    case U_DAT_EEG: return new UCovariance(*XX, NULL, Data->GetGridEEG());
    }
    CI.AddToLog("ERROR: UCOVestimate::GetCovarianceXX(). Invalid data type: DType = %d \n", DType);
    return NULL;
}

UCovariance* UCOVestimate::GetCovarianceTT(void) const
{
    if(TT==NULL || TT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::GetCovarianceTT(). TT-object not properly set.\n");
        return NULL;
    }

    double STms = 1;
    if(Data && Data->GetSampleRate()>0) STms = 1000. / Data->GetSampleRate();

    return new UCovariance(*TT, STms);
}

ErrorType UCOVestimate::ExportAverageDS(const UCTFDataSet* DSet) const
{
    if(DatAv==NULL)
    {
        CI.AddToLog("ERROR: ExportAverageDS().No average present in object (NULL).\n");
        return U_ERROR;
    }
    if(DSet==NULL)  
    {
        CI.AddToLog("ERROR: ExportAverageDS(). NULL argument.\n");
        return U_ERROR;
    }

    UMEEGDataCTF      DataIn(Data->GetDataFileName());
    
    ///, Data->GetGoodChannels(), Data->GetBadChannels());
    UMEEGDataWriteCTF DataOut(DataIn);

    ErrorType   E = DataOut.GetError();
    if(E==U_OK) E = DataOut.SetNtrial(1);
    if(E==U_OK) E = DataOut.SetNsampTrial(nT);
    if(E==U_OK) E = DataOut.SetNaver(nEpoch);
    if(E==U_OK) E = DataOut.SetComment(CI.GetProperties("// "));
    if(E==U_OK) E = DataOut.SetPreTriggerTime_s(Data->GetPreTriggerTime_s());
    switch(DType)
    {
    case U_DAT_MEG: 
        if(E==U_OK) E = DataOut.SetGridMEG(DataIn.GetGridMEG()); 
        if(E==U_OK) E = DataOut.SetGridEEG(NULL); 
        if(E==U_OK) E = DataOut.SetGridADC(NULL); 
        break;
    case U_DAT_EEG: 
        if(E==U_OK) E = DataOut.SetGridMEG(NULL); 
        if(E==U_OK) E = DataOut.SetGridEEG(DataIn.GetGridEEG()); 
        if(E==U_OK) E = DataOut.SetGridADC(NULL); 
        break;
    case U_DAT_ADC: 
        if(E==U_OK) E = DataOut.SetGridMEG(NULL); 
        if(E==U_OK) E = DataOut.SetGridEEG(NULL); 
        if(E==U_OK) E = DataOut.SetGridADC(DataIn.GetGridADC()); 
        break;
    }
    if(E==U_OK) E = DataOut.SetDataFileName(DSet->GetCTFFileName());
    if(E==U_OK) E = DataOut.WriteTrial(DatAv, DType, 0);    

///    if(E==U_OK) E = DS->CopyFiducialsTo(DSet);

    return E;
}

unsigned char* UCOVestimate::ConvertCovarToUnsignedChar(const double* Matrix, int nDim) const
{
    if(Matrix==NULL || nDim<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::ConvertCovarToUnsignedChar(). Invalid arguments. nDim=%d . \n", nDim);
        return NULL;
    }
    int Np = nDim*nDim;
    unsigned char* data = new unsigned char[Np];
    if(data==NULL) 
    {
        CI.AddToLog("ERROR: UCOVestimate::ConvertCovarToUnsignedChar(). Memory allocation. Np=%d . \n", Np);
        return NULL;
    }
    double fM = fabs(Matrix[0]);
    for(int k=0; k<Np; k++)
        if(fabs(Matrix[k])>fM) fM = fabs(Matrix[k]);

    double Scale = 127./fM;
    for(int k2=0; k2<nDim; k2++)
        for(int k1=0; k1<nDim; k1++)
        {
            int k   =       k2   *nDim + k1;
            int kk  = (nDim-k2-1)*nDim + k1;
            data[k] = unsigned char (128 + Scale*Matrix[kk] + .5);
        }
    return data;
}


double* UCOVestimate::FFTpower(double* Array, int N) const
/*
   Compute the FFT powers of a given array
*/
{
    if(Array==NULL || N<=0)
    {
        CI.AddToLog("ERROR: UCOVestimate::FFTpower(). Erroneous NULL arguments. \n");
        return NULL;
    }
    double*     Pow   = new double[N];
    rfftw_plan  Pforw = rfftw_create_plan(N, FFTW_REAL_TO_COMPLEX, FFTW_ESTIMATE);
    if(Pow==NULL || Pforw==NULL)
    {
        delete[] Pow;
        if(Pforw) rfftw_destroy_plan(Pforw);
        CI.AddToLog("ERROR: UCOVestimate::FFTpower(). Memory allocation or creating FFT plan. \n");
        return NULL;
    }

/* Compute FFT and powers */
    rfftw_one(Pforw, Array, Pow);

    Pow[0] = Pow[0]*Pow[0];  // The DC-component
    for(int k=1; k<(N+1)/2; k++) 
        Pow[k] = 2* (Pow[k]*Pow[k] + Pow[N-k]*Pow[N-k]);    
    if(N%2==0) Pow[N/2] = Pow[N/2]*Pow[N/2];

    rfftw_destroy_plan(Pforw);
    return Pow;
}

ErrorType UCOVestimate::ScaleInitCov(int StartFromOldCov,int ikp)
{
    if (StartFromOldCov !=1) 
        return U_OK;

    if(EType==UCOVestimate::U_MAXLIKE||EType==UCOVestimate::U_MAXLIKECDM)
    {
        double scale = XX->NormalizeMatrix(); // XX is divided by scale
        TT->MultiplyMatrix(scale);            // TT is multiplied by scale
        const double* XXscale = XX->GetMatrix();
        const double* TTscale = TT->GetMatrix();
        double* XXnew = new double[nX*nX];
        double* TTnew = new double[nT*nT];
        for(int i=0;i<nX*nX;i++) XXnew[i] = XXscale[i];
        for(int i=0;i<nT*nT;i++) TTnew[i] = TTscale[i];
        delete XX; XX= new USpaceTime(XXnew, nX,true, USpaceTime::U_SPACE);
        delete TT; TT= new USpaceTime(TTnew, nT,true, USpaceTime::U_TIME);  
        delete[] XXnew;
        delete[] TTnew;
        return U_OK;
    }
    else if(EType!=UCOVestimate::U_SUMKPLS)
    {
        double scale = XX->NormalizeMatrix(); // XX is divided by scale
        TT->MultiplyMatrix(scale);            // TT is multiplied by scale
        const double* XXscale = XX->GetMatrix();
        const double* TTscale = TT->GetMatrix();
        double* XXnew = new double[nX*nX];
        double* TTnew = new double[nT*nT];
        for(int i=0;i<nX*nX;i++) XXnew[i] = XXscale[i];
        for(int i=0;i<nT*nT;i++) TTnew[i] = TTscale[i];
        delete XX; XX= new USpaceTime(XXnew, nX,false, USpaceTime::U_SPACE);
        delete TT; TT= new USpaceTime(TTnew, nT,false, USpaceTime::U_TIME);
        delete[] XXnew;
        delete[] TTnew;
        return U_OK;
    }
    else
    {
        double scale = XXKP[ikp]->NormalizeMat(); // XXKP[ikp] is divided by scale
        TTKP[ikp]->MultiplyMatrix(scale);          // TTKP[ikp] is multiplied by scale
        if(fabs(scale-1)<1e-12)
            return U_OK;
        const double* XXscale = XXKP[ikp]->GetMatrix();
        const double* TTscale = TTKP[ikp]->GetMatrix();
        double* XXnew = new double[nX*nX];
        double* TTnew = new double[nT*nT];
        for(int i=0;i<nX*nX;i++) XXnew[i] = XXscale[i];
        for(int i=0;i<nT*nT;i++) TTnew[i] = TTscale[i];
        delete XXKP[ikp]; XXKP[ikp]= new USpaceTime(XXnew, nX,false, USpaceTime::U_SPACE);
        delete TTKP[ikp]; TTKP[ikp]= new USpaceTime(TTnew, nT,false, USpaceTime::U_TIME);
        delete[] XXnew;
        delete[] TTnew;
        return U_OK;
    }
}


USpaceTime::USpaceTime(int n, USpaceTime::STType ST) : UJacobi(n)
{
    N           = 0;
    SpaceTime   = U_NOTYPE;
    XT          = NULL;
    XTold       = NULL;
    UpdateError = -1;

    error       = UJacobi::GetError();
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::USpaceTime::USpaceTime(). Error in UJacobi creation, N=%d.\n",n);
        return;
    }
    XT    = new double[n*n];
    XTold = new double[n*n];
    if(XT==NULL||XTold==NULL)
    {
        delete[] XT;    XT    = NULL;
        delete[] XTold; XTold = NULL;
        error = U_ERROR;
        CI.AddToLog("ERROR: UCOVestimate::USpaceTime::USpaceTime(). Memory allocation, N=%d.\n",n);
        return;
    }

    N           = n;
    SpaceTime   = ST;

    for(int k=0; k<N*N; k++)    XTold[k] = XT[k] = 0.;
    for(int k=0; k<N*N; k+=N+1) XTold[k] = XT[k] = 1.;
}

USpaceTime::USpaceTime(const double*Mat, int n, bool Inv) : UJacobi(Mat, n, Inv)
{
    N           = 0;
    SpaceTime   = U_NOTYPE;
    XT          = NULL;
    XTold       = NULL;
    UpdateError = -1;

    error       = UJacobi::GetError();
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::USpaceTime::USpaceTime(). Error in UJacobi creation, N=%d.\n",n);
        return;
    }
    N = n;
}

USpaceTime::USpaceTime(const double* Mat, int n, bool Inv, STType ST) : UJacobi(Mat, n, Inv)
{
    N           = 0;
    SpaceTime   = U_NOTYPE;
    XT          = NULL;
    XTold       = NULL;
    UpdateError = -1;

    error       = UJacobi::GetError();
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UCOVestimate::USpaceTime::USpaceTime(). Error in UJacobi creation, N=%d.\n",n);
        return;
    }
    XT    = new double[n*n];
    XTold = new double[n*n];
    if(XT==NULL||XTold==NULL)
    {
        delete[] XT;    XT    = NULL;
        delete[] XTold; XTold = NULL;
        error = U_ERROR;
        CI.AddToLog("ERROR: UCOVestimate::USpaceTime::USpaceTime(). Memory allocation, N=%d.\n",n);
        return;
    }
    N           = n;
    SpaceTime   = ST;    

    for(int k=0; k<N*N; k++)    XTold[k] = XT[k] = Mat[k];   
}


USpaceTime::~USpaceTime()
{
    delete[] XT;
    delete[] XTold;
}

ErrorType USpaceTime::Update(bool Normalize, UCOVestimate* ML, int iKP)
{
    if(SpaceTime==U_NOTYPE) return U_ERROR;

/* Copy data:*/
    double     EigenThreshold  = ML->EigenThreshold ;
    int        nEpoch          = ML->nEpoch;
    double*    DatAv           = ML->DatAv;
    double*    EpWeights       = ML->EpWeights;

    int        nX              = ML->nX;;
    int        nT              = ML->nT;
    USpaceTime *XX = NULL;
    USpaceTime *TT = NULL;
    if (ML->EType != UCOVestimate::U_SUMKPLS)
    {
        XX = ML->XX;
        TT = ML->TT;
    }
    else
    {
        XX = ML->XXKP[iKP];
        TT = ML->TTKP[iKP];
    }

/* Initialize XT[] */
    for(int n=0; n<N*N; n++) XT[n] = 0;    
     
    int      nDataSets    = 0;
    UString* DataSetNames = NULL;
    if(ML->EType==UCOVestimate::U_MAXLIKECDM) DataSetNames = ML->GetUsedMarkerNames(&nDataSets); 
    int    DataSetIndex = 0;

/* Update matrix by looping over independent trials. */

    for(int k=0; k<nEpoch; k++)
    {
/* Get epochs and substract average*/
        double* Dat = NULL;
        if(!(ML->DatAll)) Dat =  ML->GetFilteredData(k, ML->DType);
        else              Dat = (ML->DatAll)[k];       

        if(ML->EType!=UCOVestimate::U_MAXLIKECDM)
        {
            if(EpWeights) for(int ij=0; ij<nX*nT; ij++) Dat[ij] -= EpWeights[k]*DatAv[ij];
            else          for(int ij=0; ij<nX*nT; ij++) Dat[ij] -= DatAv[ij];
        }
        else
        {
            for(int q=0;q<nDataSets;q++)
            {            
                if(ML->GetEpochs()->IsMarkerIsInDescriptor(k,DataSetNames[q]))
                {
                    DataSetIndex =q;
                    break;
                }
            }
            for(int ij=0; ij<nX*nT; ij++) Dat[ij] -= DatAv[DataSetIndex*nX*nT+ij];
        }
  
        if(SpaceTime==U_SPACE)    TT->AddAJAT(XT, Dat, N);
        else                      XX->AddATJA(XT, Dat, N);
        
        if(!(ML->DatAll)) 
        {
            delete[] Dat;
        }
        else // Restore data for next time
        {
            if(EpWeights) for(int ij=0; ij<nX*nT; ij++) Dat[ij] += EpWeights[k]*DatAv[ij];
            else          for(int ij=0; ij<nX*nT; ij++) Dat[ij] += DatAv[ij];            
        }
    }

    /* In case of higher order KP terms, subtract the correction from lower order terms */
    if(iKP>0 && ML->EType==UCOVestimate::U_SUMKPLS)
    {       
        UMatrix XTmat = UMatrix(XT,N,N);
        for(int n=0;n<iKP;n++)
        {
            UMatrix XT_n;            
            UMatrix Corr;
            if(SpaceTime==U_SPACE) 
                XT_n = UMatrix(ML->XXKP[n]->GetMatrix(), nX, nX);
            else
                XT_n = UMatrix(ML->TTKP[n]->GetMatrix(), nT, nT);
            double powXT_n = XT_n.GetNorm();
            XT_n.MultiplyMA(Corr,XTmat);            
            XT_n.MultiplyBy(Corr.GetTrace()/powXT_n);
            XTmat -= XT_n; // subtract the correction term for lower order KP terms
        }
        const double* NewXT = XTmat.GetMatrix();
        for(int i=0;i<N*N;i++) XT[i]=NewXT[i];
    }

/* Normalize matrices. */
    double Norm = 0.;
    if(ML->EType==UCOVestimate::U_MAXLIKE || ML->EType==UCOVestimate::U_MAXLIKECDM)
    {
        if(SpaceTime==U_SPACE) Norm = 1./(nEpoch*nT);
        else                   Norm = 1./(nEpoch*nX);
    }
    else
    {        
        if(SpaceTime==U_SPACE) 
        {
            for(int k=0; k<nT; k++) 
                Norm += TT->GetEigen(k)*TT->GetEigen(k);
        }
        else
        {
            for(int k=0; k<nX; k++) 
                Norm += XX->GetEigen(k)*XX->GetEigen(k);             
        }
        if(ML->EType != UCOVestimate::U_SUMKPLS) 
            Norm = 1./(Norm*nEpoch);
        else
            Norm = 1./(Norm*(nEpoch-1));
    }
    
    for(int k=0; k<N*N; k++)  
        XT[k] *= Norm;

/* Normalize matrix. */ 
    if(Normalize==true)
        NormalizeMat();     
    
/* Compute UpdateError and update XTold[] */
    double PowXT = 0.;
    UpdateError  = 0.;
    for(int k=0; k<N*N; k++)  
    {
        UpdateError += (XT[k]-XTold[k])*(XT[k]-XTold[k]);
        XTold[k]     =  XT[k];
        PowXT       +=  XT[k]*XT[k];
    }
    /////
    PowXT = sqrt(PowXT);
    //////
    UpdateError /= PowXT; //relative difference in matrix power
    
    ErrorType ErrorSetMatrix = U_ERROR;
    if(ML->EType==UCOVestimate::U_MAXLIKE||ML->EType==UCOVestimate::U_MAXLIKECDM) 
        ErrorSetMatrix = SetMatrix(XT, N, true);
    else 
        ErrorSetMatrix = SetMatrix(XT, N, false);
    
    if(ErrorSetMatrix!=U_OK) CI.AddToLog("%s",GetProperties("// "));

    SetEigenTreshold(EigenThreshold );
    return U_OK;
}

double USpaceTime::NormalizeMatrix(void)
{
    double PowXT     = 0.;
    for(int k=0; k<N; k++) PowXT  +=  XT[k*(N+1)]*XT[k*(N+1)];

    if(PowXT<=0.) return 0.;
        
    PowXT = sqrt(PowXT/N);
    for(int k=0; k<N*N; k++)  XT[k] /= PowXT;
   
    return PowXT;
}

double USpaceTime::NormalizeMat(void)
{
    double PowXT     = 0.;
    for(int k=0; k<N*N; k++) PowXT  +=  XT[k]*XT[k];

    if(PowXT<=0.) return 0.;
        
    PowXT = sqrt(PowXT);
    for(int k=0; k<N*N; k++)  XT[k] /= PowXT;
    return PowXT;
}

ErrorType USpaceTime::MultiplyMatrix(double factor)
{  
    for(int k=0; k<N*N; k++)  
        XT[k] *= factor;
    return U_OK;
}

ErrorType USpaceTime::SetXToldEqualToXT(void)
{
     for(int k=0; k<N*N; k++)  XTold[k] = XT[k];
     return U_OK;
}


const double* USpaceTime::GetMatrix(void) const      
{
    if(SpaceTime==U_NOTYPE) return UJacobi::GetMatrix();
    return XT;
}

ErrorType USpaceTime::SetSTType(STType st)
{
    if (st == U_SPACE || st == U_TIME || st == U_NOTYPE)
    {
        SpaceTime = st;
        return U_OK;
    }
    else
    {
        SpaceTime = U_NOTYPE;
        return U_ERROR;
    }

}

