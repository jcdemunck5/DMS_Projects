#ifndef _MLESTIMATE_INCLUDED
#define _MLESTIMATE_INCLUDED

#include "../../MEEGDataEpochs.h"
#include "../../Jacobi.h"

class UCOVestimate;
class UCovariance;

#define MAXKP 4

class USpaceTime : public UJacobi
{
public:
    enum STType
    {
        U_NOTYPE,
        U_SPACE,
        U_TIME    
    };
    USpaceTime(int n, STType ST);
    USpaceTime(const double*Mat, int n, bool Inv);
    USpaceTime(const double*Mat, int n, bool Inv, STType ST);
    ~USpaceTime();

    ErrorType     SetSTType(STType st); 
    ErrorType     GetError(void) const       {return error;}
    double        GetUpdateError(void) const {return UpdateError;}
    const double* GetMatrix(void) const;
    ErrorType     Update(bool Normalize, UCOVestimate* ML, int iKP=0);
    double        NormalizeMatrix(void);
	double        NormalizeMat(void);
    ErrorType     MultiplyMatrix(double factor);
    ErrorType     SetXToldEqualToXT(void);

private:
    ErrorType     error;
    int           N;
    STType        SpaceTime;
    double*       XT;
    double*       XTold;
    double        UpdateError;
};

class UCTFDataSet;
class UCOVestimate : public UMEEGDataEpochs
{
public:
    enum EstimType
    {
        U_MAXLIKE,      // Kronecker product of space and time, maximum likelihood method
        U_LEASTSQUARES, // Kronecker product of space and time, least squares method
        U_LOWPOWER,     // Average sample matrices over low power samples. Spatial correlations only
        U_SUMKPLS,      // Sum of Kronecker products of space and time, least squares method
        U_MAXLIKECDM    // Kronecker product of space and time, maximum likelihood method, multiple data sets CDM
    };
    friend ErrorType USpaceTime::Update(bool Normalize, UCOVestimate* ML, int iKP);

    UCOVestimate(const char* DataSetName, const char* forceGoodCh=NULL, const char* forceBadCh=NULL);
    ~UCOVestimate();
    char*            GetProperties(const char* Comment=NULL) const;
    
    ErrorType        GetError(void) const {return error;}
    int              GetNiter(void) const {return Niter;}

    ErrorType        ComputeAverage(DataType DT);
    ErrorType        EstimateLowPowerCov(double PowThresh, DataType DT);    
    ErrorType        EstimateCovariance(double MatThresh, double ErrThresh, EstimType ET, int MaxIter, DataType DT, bool AllDataInMem, int StartFromOldCov=0, int iKP = 0);
    ErrorType        EstimateCovariance(double MatThresh, double ErrThresh, EstimType ET, int MaxIter, DataType DT, const double* EpochsWeights, bool StartFromOldCov);

    ErrorType        WriteXXmap(const char* BaseFileName, const UCTFDataSet* DSet=NULL, int iKP=-1) const;
    ErrorType        WriteXXbitmap(const char* BaseFileName, const UCTFDataSet* DSet=NULL, int iKP=-1) const;
    ErrorType        WriteTTbitmap(const char* BaseFileName, const UCTFDataSet* DSet=NULL, int iKP=-1) const;
    ErrorType        WriteXXcovDist(const char* BaseFileName, const UCTFDataSet* DSet=NULL, int iKP=-1) const;
    ErrorType        WriteTTcovStat(const char* BaseFileName, const UCTFDataSet* DSet=NULL, int iKP=-1) const;
    ErrorType        WriteXX(const UCTFDataSet* DSet, const char* FName, bool ASCIIform, int iKP=-1) const;
    ErrorType        WriteTT(const UCTFDataSet* DSet, const char* FName, bool ASCIIform, int iKP=-1) const;
    ErrorType        ExportAverageDS(const UCTFDataSet* DSet) const;

    double* const*   GetAllFilteredData(void) const {return DatAll;}
    UCovariance*     GetCovarianceXX(void) const;
    UCovariance*     GetCovarianceTT(void) const;
	
private:
// General
    ErrorType        error;            // General error parameter
    static const int MAXPROPERTIES;
    char*            Properties;       // String to hold the properties in ASCII format

    int              nEpoch;           // Number of epochs used for covriance estimation (==Epochs->GetnEpochs())
    double*          EpWeights;        // Determine the weighting of each epoch. 
    double*          DatAv;            // Average of the data in all epochs
    DataType         DType;            // Data Type
    EstimType        EType;            // Type of covariance estimation
    int              nX;               // dimensions of the spatial covariance matrix
    int              nT;               // dimensions of the temporal covariance matrix

// Spatio-Temporal Estimation
    double           EigenThreshold;   // Threshold parameter, used to separate small and big eigenvalues
    double           ErrorThreshold;   // Parameter used to test if the number of iterations in the space-time covariance estimations are sufficient
    int              Niter;            // Number of iterations used in the spatio-temporal covariance estimation
    double**         DatAll;           // All (filtered) data
    USpaceTime      *XX;
    USpaceTime      *TT;
    USpaceTime      *XXKP[MAXKP];      // Array of USpaceTime objects for estimating sum of KPs 
    USpaceTime      *TTKP[MAXKP];      //
// Data statistics
    double           SNR;              // estimated Signal to Noise ratio
    double           MeanStdDevMean;   // the mean standard error of the mean
    double           SampCovPower;     // power of the sample covariance matrix
    double           CovPowKP[MAXKP];  // % power of sample cov in each KP term 

// Spatial Estimation
    double           RelPowerThresh;   // All time samples with an average data power larger than RelPowerThresh*Median Power are ignored
    double           AbsPowerThresh;   // All time samples with an average data power larger than RelPowerThresh*Median Power are ignored
    int              nLow;             // Number of time samples with a sub-threshold power

    double*          FFTpower(double* Array, int N) const; // Compute the FFT powers of a give array

    unsigned char*   ConvertCovarToUnsignedChar(const double* Matrix, int nDim) const;

    ErrorType        ScaleInitCov(int StartFromOldCov,int ikp);
};


#endif//_MLESTIMATE_INCLUDED
