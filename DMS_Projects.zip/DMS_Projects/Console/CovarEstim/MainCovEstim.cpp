/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to estimate spatio-temporoal covariance functions.                */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-08-00   creation, added interface to preleminary version.
  JdM    06-10-00   Added option to analyze EEG data i.s.o MEG
  JdM    13-10-00   Make name of averaged ds dependent on data type
  JdM    16-02-01   Copy mechanism to set epochs from FitDipoles
  JdM    17-02-01   Added option to compute (filtered) average only (no covariance)
  JdM    14-06-01   Added option to sub-sample the epochs
                    Added the option to keep all data in memory.
  JdM    15-06-01   Bug fixes of 14-06-01
 JdM/FB  04-07-01   Allow preprocessing without band-pass or SVD filtering
  JdM    17-08-01   Added re-referencing of MEG/EEG data
  JdM    09-10-01   Add the option to remove SEF artifact before filtering
  JdM    08-07-02   Allow removal of powerline noise
  JdM    11-09-02   Export covariances as bitmap.
                    Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    12-09-02   Allow wild cards in data set names
  JdM    09-10-02   Add option to remove complete epochs based on overlapping with markers
 JdM/BvZ 29-10-02   Avoid static enum to be compatible with Lynux
  FB     21-07-03   Added EstimType::U_SUMKPLS and adapted options and estimation to fit a sum op KP's in LS sense
  FB     22-06-04   Added option: StartFromOldCov to initialize the iterative estimation with ready computed covariance 
  FB     09-08-06   Removed ULinearFilter:: for each UPreProType
  JdM    05-03-08   MAJOR update. Adapted sources to new directory structure (PMT_Projects iso MCAProjects_6)
*/

#include <stdlib.h>

#include "COVestimate.h"

#include "../../Option.h"
#include "../../Directory.h"
#include "../../CTFDataSet.h"

#define VERSION "4.0 "
#define AUTHOR  "Dr. JC de Munck, Dept PMT VUmc, Amsterdam"

enum
{
    OP_DIRIN,OP_FILOUT,OP_ASCOUT,
    OP_DATTYP,OP_AVERONLY,OP_METHOD,OP_NKP, OP_STARTCOV,
    OP_STOP,OP_NITER,OP_ALLMEM,OP_POWTRE,
    OP_TRIALS,OP_SAMPLE,OP_MWIDTH,OP_MOFFSET,OP_MRANGE,OP_MNAME,OP_SUBEPOCH,OP_EXTRIAL,OP_EXMNAME,OP_EXMWIDTH,OP_EXMEPOCH,OP_EXOVERL,
    OP_RSEFART,OP_REM50HZ,OP_FBANDP,OP_SVD,OP_PREPRO,OP_PREEPOCH,OP_MEGRREF,OP_EEGRREF,
    NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];

class USetEpochs
{
public:
    USetEpochs();
    ErrorType ArgumentsToObject(UMEEGDataEpochs* Epdat);
};
static USetEpochs SetEp;


static const double WindowSize_s = 1.0;

int main(int Nargs, char **Args)
{       
    char* Intro  = "This programme computes an estimate of the spatial (and temporal) covariance\n"
                   "corresponding to a selection of epochs of a CTF data set. The estimation method\n"
                   "is either the maximum likehood or the ordinary least squares method. In these two\n"
                   "cases it is assumed that the spatio-temporal covariance is a Kronecker product\n"
                   "of a spatial and a temporal covariance matrix. In the third method a spatial covariance\n"
                   "matrix is estimated by making the ad hoc assumption that the noise is reflected in \n"
                   "the low power samples of the data. Over these samples a simple sample covariance matrix\n"
                   "is estimated.\n\n"
                   "In all cases, the spatial and temporal covariance matrices are exported in a standard\n"
                   "format, with standard names, which are recognized by other applications that use these\n"
                   "matrices.\n\n"
                   "The theory underlying this program is described in:\n"
                   "J.C. de Munck, H.M. Huizenga, L.J. Waldorp and R.M. Heethaar, Estimating stationary\n"
                   "dipoles from MEG/EEG data contaminated with spatially and temporally correlated\n"
                   "background noise, IEEE Trans Sign. Proc., 2001, under review.\n"
                   "Please refer to that paper if the use of this program is a substantial part of \n"
                   "your work.\n";

    
    Help[OP_DIRIN   ] = "DataSet name of the MEG data to be analyzed.";
    Help[OP_FILOUT  ] = "Basis filename of the output text file. This text file contains information on the eigenvalues of the matrices and their behavior as a function of sensor distance or time difference.";
    Help[OP_ASCOUT  ] = "You can switch on this option to export the covariance matrices in ASCII format.";

    Help[OP_DATTYP  ] = "Choose the data type that you wish to analyze: 1= pure MEG, 2= pure EEG;";
    Help[OP_AVERONLY] = "You can compute the average of the (filtered) epochs, without computing the spatial or temporal covariance. If you set this option, options regarding the covariances are ignored.";
    Help[OP_METHOD  ] = "Set the method you wish to use to estimate the covariance matrices: 1=iterative maximum likelihood method, 2=iterative least squares, 3=sample covariance on low-power samples, 4= sum of Kronecker Products in LS sense and 5=iterative maximum likelihood method for the CDM model.";    
    Help[OP_NKP     ] = "Set the number of Kronecker Products you wish to estimate when a the method is set to a sum of KP's in LS sense.";    
    Help[OP_STARTCOV] = "You can initialize the iterative estimation using an existing covariance. This covariances should be located in the AverageMEG.ds directory, names CovarXXOLD.cov and CovarTTOLD.cov. 0= no initialization, 1=initialize both X and T, 2= initialize X only, 3= initialize T only";    
    Help[OP_STOP    ] = "The iterative estimation methods will stop when the relative difference between two succesive iteratrions is smaller than a give number.";
    Help[OP_NITER   ] = "The iterative estimation methods will stop when more than a give number of iterations are performed. Note: a negative number of iterations indicates that only the spatial correlations are updated, assuming that the data are uncorrelted in time.";
    Help[OP_ALLMEM  ] = "You can reduce computation time by reading first all (filtered) data into memory. Then, during iterative covariance estimation procedures, the data is readily available. If you do not have the required amount of memory, a WARNING is given and the data will be read and filtered each time when needed. This option can not be used in combination with estimation method 5 (CDM)";
    Help[OP_POWTRE  ] = "The sample covariance estimation method will only include time samples with a power lower than a given factor times the average data power over the selected epochs.";
    
    Option[OP_DIRIN   ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_FILOUT  ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_ASCOUT  ] = UOption("ASC","ASCIIformat",Help[OP_ASCOUT]);

    Option[OP_DATTYP  ] = UOption("DT"  ,"DataType"     ,Help[OP_DATTYP]  ,1,2,1);
    Option[OP_AVERONLY] = UOption("Ave" ,"AverageOnly"  ,Help[OP_AVERONLY]);
    Option[OP_METHOD  ] = UOption("m"   ,"Estim. Meth." ,Help[OP_METHOD]  ,1,5,1);
    Option[OP_NKP     ] = UOption("nKP" ,"Number of KP" ,Help[OP_NKP]     ,1,MAXKP,2);
    Option[OP_STARTCOV] = UOption("Stc" ,"Start Cov"    ,Help[OP_STARTCOV],0,3,0);
    Option[OP_STOP    ] = UOption("Stp" ,"StoppingPar"  ,Help[OP_STOP]    ,0.,1000.,1.e-10);    
    Option[OP_NITER   ] = UOption("Nit" ,"Num.Iter."    ,Help[OP_NITER]  ,-1,1000,100);  
    Option[OP_ALLMEM  ] = UOption("Mem" ,"AllDataMem"   ,Help[OP_ALLMEM]);
    Option[OP_POWTRE  ] = UOption("PTF" ,"PowerThresh"  ,Help[OP_POWTRE] ,-1.,100.,1.);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

/*Select data sets*/   
    const char* DataSets = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(DataSets, NULL, false);
    const char* DirName = Dirin.GetDirectoryName();

    int           NDirs    = 0;
    UFileName*    DirNamAr = Dirin.GetAllSubdirNames(DataSets, &NDirs);
    CI.AddToLog("Note: There are %d files to be examined .\n",NDirs);

    int NgoodDir = 0;
    for(int idir =0; idir<NDirs; idir++)
    {
        const char* DataSetName = DirNamAr[idir].GetFullFileName();

        if(IsStringEnding(DataSetName, "hz.ds")==true ||      
           IsStringEnding(DataSetName, "hz2.ds")==true)        
        {
            CI.AddToLog("Note: Skipping data set %s .\n",DataSetName);
            continue;
        }

/* Set epochs*/
        UCOVestimate COV(DataSetName);
        if(COV.GetError()!=U_OK || SetEp.ArgumentsToObject(&COV)!=U_OK) 
        {
            CI.AddToLog("ERROR: Skipping data set %s .\n", DataSetName);
            continue;
        }
            
        UCOVestimate::EstimType EsType;
        switch(Option[OP_METHOD].GetValue())
        {
        case 1:  EsType = UCOVestimate::U_MAXLIKE;      break;
        case 2:  EsType = UCOVestimate::U_LEASTSQUARES; break;
        case 3:  EsType = UCOVestimate::U_LOWPOWER;     break;
        case 4:  EsType = UCOVestimate::U_SUMKPLS;      break;
        case 5:  EsType = UCOVestimate::U_MAXLIKECDM;   break;
        default:
            CI.AddToLog("ERROR: Illegal covar estimation type.\n");
            CI.PressReturnExit();
        }
		int nKP=1;
		if (EsType==UCOVestimate::U_SUMKPLS)		
			nKP=Option[OP_NKP].GetValue();			
		
        int StartFromOldCov = Option[OP_STARTCOV].GetValue();

        char* AverageDSname=NULL;
        DataType DT = U_DAT_UNKNOWN;
        switch(Option[OP_DATTYP ].GetValue())
        {
        case 1: DT = U_DAT_MEG; AverageDSname = "AverageMEG.ds"; break;
        case 2: DT = U_DAT_EEG; AverageDSname = "AverageEEG.ds"; break;
        default:
            CI.AddToLog("ERROR: Wrong data type option.\n");
            CI.PressReturnExit();
        }

        const char* BaseName = Option[OP_FILOUT].GetFileName();

        ErrorType E     = U_ERROR;
        bool      ASCII = Option[OP_ASCOUT].GetBOOL();
        if(Option[OP_AVERONLY].GetBOOL()==true)
        {
            E = COV.ComputeAverage(DT);

            UCTFDataSet* NewDS = new UCTFDataSet(COV.GetData()->GetDataFileName().GetDirectory().Child(AverageDSname));

            if(NewDS==NULL || NewDS->GetError()!=U_OK || NewDS->CreateDataSet()!=U_OK)
            {
                CI.AddToLog("ERROR: Cannot Create output DataSet Directory: \n");
                E = U_ERROR;
            }
            if(E==U_OK) E = COV.ExportAverageDS(NewDS);
            delete NewDS;
        }
        else
        {
            if(EsType==UCOVestimate::U_LOWPOWER)
            {
                double MaxPowFac  = Option[OP_POWTRE ].GetDubVal1();
                E=COV.EstimateLowPowerCov(MaxPowFac, DT);
                if(E==U_OK) E = COV.WriteXX(NULL, NULL, ASCII);
                if(E==U_OK) E = COV.WriteXXcovDist(BaseName);
                if(E==U_OK) E = COV.WriteXXbitmap(BaseName);
            }
            else if(EsType==UCOVestimate::U_SUMKPLS)
            {
                double StopCrit     = Option[OP_STOP].GetDubVal1();
                int    Niter        = Option[OP_NITER].GetValue();
                bool   AllDataInMem = Option[OP_ALLMEM].GetBOOL();
                
                UCTFDataSet* NewDS = new UCTFDataSet(COV.GetData()->GetDataFileName().GetDirectory().Child(AverageDSname));
				if(NewDS==NULL || NewDS->GetError()!=U_OK || NewDS->CreateDataSet()!=U_OK)
                {
                    CI.AddToLog("ERROR: Cannot Create output DataSet Directory: \n");
                    E = U_ERROR;
                }

				for(int iKP=0;iKP<nKP;iKP++)
				{
                    if(iKP==0) // start from old covariance only for the first KP term
                        E = COV.EstimateCovariance(0., StopCrit, EsType, Niter, DT, AllDataInMem, StartFromOldCov, iKP);
                    else					
                        E = COV.EstimateCovariance(0., StopCrit, EsType, Niter, DT, AllDataInMem, 0, iKP);
                
					if(E==U_OK) E = COV.WriteXX(NewDS, NULL, ASCII,iKP);
					if(E==U_OK) E = COV.WriteXXcovDist(BaseName, NewDS,iKP);
					if(E==U_OK) E = COV.WriteXXbitmap(BaseName, NewDS,iKP);
                    if(E==U_OK) E = COV.WriteXXmap(BaseName, NewDS);
					if(E==U_OK) E = COV.WriteTT(NewDS, NULL, ASCII,iKP);
					if(E==U_OK) E = COV.WriteTTcovStat(BaseName,NewDS,iKP);
					if(E==U_OK) E = COV.WriteTTbitmap(BaseName,NewDS,iKP);					
				}
				if(E==U_OK) E = COV.ExportAverageDS(NewDS);
				if(E==U_OK) E = COV.ExportAverageDS(NewDS);
                delete NewDS;
            }
            else 
            {
                double StopCrit     = Option[OP_STOP].GetDubVal1();
                int    Niter        = Option[OP_NITER].GetValue();
                bool   AllDataInMem = Option[OP_ALLMEM].GetBOOL();
                E = COV.EstimateCovariance(0., StopCrit, EsType, Niter, DT, AllDataInMem,StartFromOldCov);

                UCTFDataSet* NewDS = new UCTFDataSet(COV.GetData()->GetDataFileName().GetDirectory().Child(AverageDSname));
                if(NewDS==NULL || NewDS->GetError()!=U_OK || NewDS->CreateDataSet()!=U_OK)
                {
                    CI.AddToLog("ERROR: Cannot Create output DataSet Directory: \n");
                    E = U_ERROR;
                }
                if(E==U_OK) E = COV.WriteXX(NewDS, NULL, ASCII);
                if(E==U_OK) E = COV.WriteXXcovDist(BaseName, NewDS);
                if(E==U_OK) E = COV.WriteXXbitmap(BaseName, NewDS);
                if(E==U_OK) E = COV.WriteXXmap(BaseName, NewDS);

                if(Niter>=0)
                {
                    if(E==U_OK) E = COV.WriteTT(NewDS, NULL, ASCII);
                    if(E==U_OK) E = COV.WriteTTcovStat(BaseName,NewDS);
                    if(E==U_OK) E = COV.WriteTTbitmap(BaseName,NewDS);
                }
                if(EsType!=UCOVestimate::U_MAXLIKECDM && E==U_OK) 
                    E = COV.ExportAverageDS(NewDS);
                delete NewDS;
            }
        }
        if(E==U_OK) 
        {
            CI.AddToLog("Data set processed succesfully. \n");
        }
        else
        {
            CI.AddToLog("Error in covariance estimation or exporting files\n");
        }
        NgoodDir++;
    }
    CI.AddToLog("There are %d data sets succesfully processed. \n", NgoodDir);
    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}

USetEpochs::USetEpochs()
{
/* Setting the epochs */
    Help[OP_TRIALS  ]   = "Trial Range: Only the data between first and last given trial is processed. -1 refers to last trial.";
    Help[OP_SAMPLE  ]   = "Sample Range: Only the data between first and last given sample is processed. -1 refers to last sample. Given samples are considered as absolute, i.e. not corrected for pr-trigger time.";
    Help[OP_MWIDTH  ]   = "Use markers from marker file, with certain half width i (in samples). If both the option and the -s option is set, -s is ignored.";
    Help[OP_MOFFSET ]   = "If the -mo option ist, the epochs are determined by shifting markers from the markerfiles with a certain name, over a fixed number of samples. The first number is used to set the beginning of each epoch and the second marker is used to set the last sample of each epoch.";
    Help[OP_MRANGE  ]   = "If the -mr option is set, begin and end markers are taken from the marker file, in order to set time segments to be analyzed. Begin and end markers are markers starting with the string 'BEGIN' and 'END' (or 'EIND'), respectively. The -mr option can not be set simultaneously with the -mh option. If both the -mr option and the -s option is set, the -s option is ignored.";
    Help[OP_MNAME   ]   = "If the epochs are derived from a marker with halfwidth or from begin/end marker pairs, you can here select a marker with a certain name. If the name is not set, all markers (pairs) are taken.";
    Help[OP_SUBEPOCH]   = "You can take every n-th epoch exclusively, starting with the m-th epoch (m<n). Here n it the first and m the second number to be given. For example, the numbers 0 amd 2 will skip all odd epochs and taking the even ones.";
    Help[OP_EXTRIAL ]   = "With this option you can exclude trials from the analysis, whose class name (defined in ClassFile.cls) is compatible the given string. This string may contain one or more wild cards. ";    
    Help[OP_EXMNAME ]   = "You can exclude time samples from the analysis, around markers with a certain name. Here you can set the marker name. If this option is set all samples within a certain range about the events corresponding to this marker are skipped.";
    Help[OP_EXMWIDTH]   = "When you have set the option to skip time samples with a certain name, you can set here how many samples on both side of each even will be disregarded.";
    Help[OP_EXMEPOCH]   = "Instead of removing time samples coinciding with a certain marker name, you can remove complete epochs that have an overlap with a certain marker. The advantage is that the number of samples per epoch stays the same";
    Help[OP_EXOVERL ]   = "If this option is set, overlapping epochs (e.g. caused by a too large -mr time) are excluded from the analysis.";

    Option[OP_TRIALS  ] = UOption("Tr" ,"Trials",Help[OP_TRIALS],-1,128,0,-1);
    Option[OP_SAMPLE  ] = UOption("s"  ,"Samples",Help[OP_SAMPLE],-1,32000,0,-1);
    Option[OP_MWIDTH  ] = UOption("mw" ,"Marker wi.",Help[OP_MWIDTH],1,500,1);
    Option[OP_MOFFSET ] = UOption("mo" ,"MarkerOffset",Help[OP_MOFFSET],-100000,100000,0,0);
    Option[OP_MRANGE  ] = UOption("mr" ,"Marker range",Help[OP_MRANGE]);
    Option[OP_MNAME   ] = UOption("Nam","Marker Name",Help[OP_MNAME],NULL);
    Option[OP_SUBEPOCH] = UOption("Rep","ReduceEpochs",Help[OP_SUBEPOCH],0,100,1,0);
    Option[OP_EXTRIAL ] = UOption("Ext","ExcludeTrls",Help[OP_EXTRIAL],"ClassName");
    Option[OP_EXMNAME ] = UOption("ExM","ExcludeMark.",Help[OP_EXMNAME ],NULL);
    Option[OP_EXMWIDTH] = UOption("Exw","Exclude wi.",Help[OP_EXMWIDTH],1,5000,1);
    Option[OP_EXMEPOCH] = UOption("ExE","Exclude ep",Help[OP_EXMEPOCH]);
    Option[OP_EXOVERL ] = UOption("EXO","Excl. Overl.",Help[OP_EXOVERL]);

/* Filtering parameters*/
    Help[OP_RSEFART ]   = "You can remove the SEF artifact from the selected epochs and pre-processing windows by linear interpolation. However, this only works for those epoch selection methods in which the stimulus onset can be determined, making certain assumptions.";
    Help[OP_REM50HZ ]   = "You can remove the 50 Hz. power line noise.";
    Help[OP_FBANDP  ]   = "Band-pass filter the data, before selecting the epochs. You can do so by giving here the minimum and maximum frequency in Hz. A negative value means: ignore. So, e.g. -Bpf-1Bpf10. means: pass all data between zero and 10. Hz, and -Bpf10.Bpf-1 means: pass all data between 10 Hz and the highest present frequency. If the option -Bpf is omitted at all, no filtering is applied.";
    Help[OP_SVD     ]   = "Apply the SVD-filter and set the number of SVD components that are taken from the data. If this option is set, the band-pass filter and the minimum time window parameters are ignored. If -SVD is not set at all, no SVD filters will be applied.";    
    Help[OP_PREPRO  ]   = "Before filtering the data using the band-pass or SVD option, you can substract the offset and/or remove the trend from the data. This pre-processing can be applied upon the selected time epochs themselves, or upon time epochs related to these epochs (pre-processing epochs).  0=No preprocessing, 1=offset removal using the selected epochs, 2=offset and trend removal using the selected epochs, 3=offset removal using preprocessing epochs, 4=trend removal using preprocessing epochs. 5=offset removal using pre-stimulus interval. 6=trendremoval using pre-stimulus interval. Note1: This preprocessing is applied in each selected epoch and on each channel individually, before band-pass c.q. SVD filtering.";
    Help[OP_PREEPOCH]   = "You can set the pre-processing epochs by giving the number of samples that the first samples of each analysis epoch have to be shifted to obtain the begin and end sample of the pre-processing window. When the given shift of the end sample is smaller than the shift of the begin samples, the pre-trigger windows are used.";
    Help[OP_MEGRREF ]   = "You can transform the MEG data to another reference: -1: Keep the data as is, 0: Make MEG data unbalanced, 1: Compute MEG data w.r.t. first gradient, 2: Compute MEG data w.r.t. second gradient, 3: Compute MEG data w.r.t. third gradient .";
    Help[OP_EEGRREF ]   = "You can transform the EEG data to average reference: -1: Keep the data as is, 0: Compute EEG data withrespect to average reference.";

    Option[OP_RSEFART ] = UOption("RSA","RemStimArt",Help[OP_RSEFART]);
    Option[OP_REM50HZ ] = UOption("RPL","RemPowLin",Help[OP_REM50HZ]);
    Option[OP_FBANDP  ] = UOption("Bpf","BandPass",Help[OP_FBANDP],-1.,10000.,1.,30.);
    Option[OP_SVD     ] = UOption("SVD","SVD-filter",Help[OP_SVD],0,100,2);
    Option[OP_PREPRO  ] = UOption("Pre","Pre-process",Help[OP_PREPRO],0,6,0);
    Option[OP_PREEPOCH] = UOption("PPe","PPepochs",Help[OP_PREEPOCH],-1000,1000,0,0);
    Option[OP_MEGRREF ] = UOption("Mrr","MEGreref",Help[OP_MEGRREF],-1,3,-1);
    Option[OP_EEGRREF ] = UOption("Err","EEGreref",Help[OP_EEGRREF],-1,0, 0);
}

ErrorType USetEpochs::ArgumentsToObject(UMEEGDataEpochs *EpDat)
{
    if(EpDat->GetError()!=U_OK)  
    {
        CI.AddToLog("\nErrors in File names\n");
        return U_ERROR;
    }
    bool EpSam = Option[OP_SAMPLE ].GetValueSet();
    bool EpWid = Option[OP_MWIDTH ].GetValueSet();
    bool EpRan = Option[OP_MRANGE ].GetValueSet();
    bool EpOff = Option[OP_MOFFSET].GetValueSet();
    if(EpWid==false && EpRan==false && EpOff==false) EpSam = true;

    if( (EpSam==true && (EpWid==true || EpRan==true || EpOff==true)) ||
        (EpWid==true && (EpRan==true || EpOff==true || EpSam==true)) ||
        (EpRan==true && (EpOff==true || EpSam==true || EpWid==true)) ||
        (EpOff==true && (EpSam==true || EpWid==true || EpRan==true)) )
    {
        CI.AddToLog("ERROR: Epochs definition set ambiguiously. \n");
        CI.AddToLog("       Either use the same samples from each trial (-%s),\n",Option[OP_SAMPLE].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs symmetrically around these markers (-%s),\n",Option[OP_MWIDTH].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs shifted w.r,t. these markers (-%s),\n",Option[OP_MOFFSET].GetIdentifier());
        CI.AddToLog("       or use the CTF begin and end-markers to select epochs (-%s).\n",Option[OP_MRANGE].GetIdentifier());
        CI.PressReturnExit();
    }

    if(Option[OP_MNAME].GetValueSet()==true   &&
       EpRan==false  &&
       EpWid==false  &&
       EpOff==false)
    {
        CI.AddToLog("WARNING: Marker name (=%s) set, without setting -mr, -mh or -mo\n",Option[OP_MNAME ].GetString());
    }

/* Select the epochs */
    const char* MarkerName = Option[OP_MNAME ].GetString();
    if(EpRan==true)     // use "range markers"
    {        
        if(EpDat->SetEpochsMarker(MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MRANGE].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpWid==true) // halfwidt set
    {
        int halfwidth = Option[OP_MWIDTH].GetValue();
        if(EpDat->SetEpochsMarker(halfwidth, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MWIDTH].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpOff==true)
    {
        int boff = Option[OP_MOFFSET].GetValue1();
        int eoff = Option[OP_MOFFSET].GetValue2();

        if(EpDat->SetEpochsMarker(boff, eoff, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MOFFSET].GetIdentifier());
            return U_ERROR;
        }
    }
    else // DEFAULT: fixed sample range from all trials
    {
        int startsample = Option[OP_SAMPLE].GetValue1();
        int endsample   = Option[OP_SAMPLE].GetValue2();
        if(EpDat->SetEpochs(startsample, endsample)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_SAMPLE].GetIdentifier());
            return U_ERROR;
        }
    }

    if(EpDat->GetError()!=U_OK)
    {
        CI.AddToLog("Errors in setting epochs.\n");
        return U_ERROR;
    }
    
/* Exclude epochs:*/
    if(Option[OP_SUBEPOCH].GetValueSet()==true)
    {
        int Ntake  = Option[OP_SUBEPOCH].GetValue1();
        int Nphase = Option[OP_SUBEPOCH].GetValue2();
        if(EpDat->SubsampleEpochs(Ntake, Nphase)!=U_OK)
        {
            CI.AddToLog("ERROR in sub-sampling epochs. Ntake = %d and Nphase = %d.\n",Ntake,Nphase);
            return U_ERROR;
        }
    }
    int starttrial = Option[OP_TRIALS].GetValue1();
    int endtrial   = Option[OP_TRIALS].GetValue2();
    
    if(EpDat->ExcludeTrials(starttrial, endtrial) !=U_OK)
    {
        CI.AddToLog("Errors excluding trials.\n");
        return U_ERROR;
    }
    if(Option[OP_EXTRIAL].GetValueSet()==true)
    {
        const char* TrialName = Option[OP_EXTRIAL].GetString();
        if(EpDat->ExcludeTrialClass(TrialName)!=U_OK)
        {
            CI.AddToLog("ERROR in processing Excluding trials named %s\n",TrialName);
            return U_ERROR;
        }
    }
    if(Option[OP_EXMNAME ].GetValueSet()==true)
    {
        const char* MarkerName = Option[OP_EXMNAME ].GetString();
        int         width      = Option[OP_EXMWIDTH].GetValue();
        if(Option[OP_EXMEPOCH].GetBOOL()==true)
        {
            if(EpDat->ExcludeEpochs(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d epochs,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
        else
        {
            if(EpDat->ExcludeSamples(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d samples,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
    }
    if(Option[OP_EXOVERL].GetBOOL()==true)  
    {
        if(EpDat->ExcludeOverlapping()!=U_OK)
        {
            CI.AddToLog("ERROR in excluding overlapping epochs.\n");
            return U_ERROR;
        }
    }

/* Set the filter parameters:*/
    UPreProType Prep = U_PREP_NO;
    bool PreProEp     = false;
    bool ForcePreStim = false;
    switch(Option[OP_PREPRO].GetValue())
    {
    case 0: Prep     = U_PREP_NO; 
            PreProEp = Option[OP_PREEPOCH].GetValueSet();
            break;
    case 1: Prep = U_PREP_OFFSET;    PreProEp = false; break;
    case 2: Prep = U_PREP_TREND;     PreProEp = false; break;
    case 3: Prep = U_PREP_OFFSET;    PreProEp = true;  break;
    case 4: Prep = U_PREP_TREND;     PreProEp = true;  break;
    case 5: Prep = U_PREP_OFFSET;    PreProEp = true;  ForcePreStim = true; break;
    case 6: Prep = U_PREP_TREND;     PreProEp = true;  ForcePreStim = true; break;
    default:
        CI.AddToLog("ERROR: Invalid pre-processing parameter: %d .\n",Option[OP_PREPRO].GetValue());
        return U_ERROR;
    }

    if(PreProEp==true && (Option[OP_PREEPOCH].GetValueSet()==true || ForcePreStim==true))
    {
        int BeginOffset = Option[OP_PREEPOCH].GetValue1();
        int EndOffset   = Option[OP_PREEPOCH].GetValue2();
        if(ForcePreStim==true && Option[OP_PREEPOCH].GetValueSet()==true && BeginOffset<=EndOffset)
        {
            CI.AddToLog("ERROR: Forcing pre-stimulus interval is in conflict with the given pre-processing parameters.\n");
            return U_ERROR;
        }
        else if(ForcePreStim==true)
        {
            BeginOffset =  0;
            EndOffset   = -1;
        }
        if(EpDat->SetPreProcessingEpochs(BeginOffset, EndOffset)!=U_OK)
        {
            CI.AddToLog("ERROR in setting pre-processing epochs.\n");
            return U_ERROR;
        }        
    }
    else if(PreProEp==true)
    {
        CI.AddToLog("ERROR: You have chosen to use pre-processing windows without selecting them.\n");
        return U_ERROR;
    }
    
    if(EpDat->SetSEFCorrection(Option[OP_RSEFART ].GetBOOL(), NULL)!=U_OK)
    {
        CI.AddToLog("ERROR: Setting the remove stimulus artifact option.\n");
        return U_ERROR;
    }
    bool   PowerLine = Option[OP_REM50HZ].GetBOOL();
    double PLWitdth  = 2.;

    if(Option[OP_SVD].GetValueSet()==true)
    {
        int Ncomp = Option[OP_SVD ].GetValue();
        EpDat->SetFilter(Ncomp, Prep, PowerLine, PLWitdth, 1.);          
    }
    else if(Option[OP_FBANDP].GetValueSet()==true)
    {
        double Fmin = Option[OP_FBANDP ].GetDubVal1();
        double Fmax = Option[OP_FBANDP ].GetDubVal2();
        EpDat->SetFilter(Fmin, Fmax, Prep, PowerLine, PLWitdth, false, 1.);    
    }
    else
        EpDat->SetFilter(Prep, PowerLine, PLWitdth, false, 1.);  

    ReReferenceType MEGreref = U_REF_RAW;
    switch(Option[OP_MEGRREF ].GetValue())
    {
    case -1: MEGreref = U_REF_RAW;         break;
    case  0: MEGreref = U_REF_UNBALANCED;  break;
    case  1: MEGreref = U_REF_FIRST;       break;
    case  2: MEGreref = U_REF_SECOND;      break;
    case  3: MEGreref = U_REF_THIRD;       break;
    default: CI.AddToLog("ERROR: Invalid MEG re-referencing parameter: %d \n", Option[OP_MEGRREF ].GetValue()); 
        return U_ERROR;
    }
    ReReferenceType EEGreref = U_REF_AVERAGE;
    switch(Option[OP_EEGRREF ].GetValue())
    {
    case -1: EEGreref = U_REF_RAW;         break;
    case  0: EEGreref = U_REF_AVERAGE;     break;
    default: CI.AddToLog("ERROR: Invalid EEG re-referencing parameter: %d \n", Option[OP_EEGRREF ].GetValue()); 
        return U_ERROR;
    }
    return EpDat->SetRereference(MEGreref, EEGreref);
}
