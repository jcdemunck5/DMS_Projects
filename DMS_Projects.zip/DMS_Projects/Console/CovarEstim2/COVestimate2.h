#ifndef _MLESTIMATE2_INCLUDED
#define _MLESTIMATE2_INCLUDED

#include "../../MEEGDataEpochs.h"
#include "../../Jacobi.h"
#include "../../String.h"

class UCOVestimate;
class UCovariance;

#define MAXKP 4

class USpaceTime : public UJacobi
{
public:
    enum STType
    {
        U_NOTYPE,
        U_SPACE,
        U_TIME    
    };
    USpaceTime(int n, STType ST);
    USpaceTime(const double*Mat, int n, bool Inv);
    USpaceTime(const double*Mat, int n, bool Inv, STType ST);
    ~USpaceTime();

    ErrorType           SetSTType(STType st); 
    ErrorType           GetError(void) const       {return error;}
    double              GetUpdateError(void) const {return UpdateError;}
    const double*       GetMatrix(void) const;
    ErrorType           Update(bool Normalize, UCOVestimate* ML, int iKP=0);
    double              NormalizeMatrix(void);
	double              NormalizeMat(void);
    ErrorType           MultiplyMatrix(double factor);
    ErrorType           SetXToldEqualToXT(void);

protected:   
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;
    int                 N;
    STType              SpaceTime;
    double*             XT;
    double*             XTold;
    double              UpdateError;
};

class UMultiChan;
class UCTFDataSet;
class UCOVestimate : public UMEEGDataEpochs
{
public:
    friend ErrorType USpaceTime::Update(bool Normalize, UCOVestimate* ML, int iKP);

    UCOVestimate(const char* DataSetName, const char* forceGoodCh=NULL, const char* forceBadCh=NULL);
    ~UCOVestimate();
    const UString&           GetProperties(UString Comment) const;
    ErrorType                GetError(void) const {return error;}

    int                      GetNiter(void) const {return Niter;}

    ErrorType                EstimateLowPowerCov(double PowThresh, DataType DT);    
    ErrorType                EstimateCovariance(double MatThresh, double ErrThresh, int MaxIter, DataType DT, bool AllDataInMem, int StartFromOldCov=0, int NKP = 1);

    const UMultiChan* const* GetAllFilteredData(void) const {return DatAll;}
    UCovariance*             GetCovarianceXX(int iKP) const;
    UCovariance*             GetCovarianceTT(int iKP) const;

protected:
    void                     SetAllMembersDefault(void);
    void                     DeleteAllMembers(ErrorType E);

private:
// General
    ErrorType                error;            // General error parameter
    static UString           Properties;

    int                      nEpoch;           // Number of epochs used for covriance estimation (==Epochs->GetnEpochs())
    UMultiChan*              DatAv;            // Average of the data in all epochs
    DataType                 DType;            // Data Type

// Spatio-Temporal Estimation
    double                   EigenThreshold;   // Threshold parameter, used to separate small and big eigenvalues
    double                   ErrorThreshold;   // Parameter used to test if the number of iterations in the space-time covariance estimations are sufficient
    int                      Niter;            // Number of iterations used in the spatio-temporal covariance estimation
    UMultiChan**             DatAll;           // All (filtered) data
    UMultiChan**             DatAllPW;         // All (filtered, pre-whitened) data
    USpaceTime              *XX;
    USpaceTime              *TT;
    USpaceTime              *XXKP[MAXKP];      // Array of USpaceTime objects for estimating sum of KPs 
    USpaceTime              *TTKP[MAXKP];      //
};


#endif//_MLESTIMATE2_INCLUDED
