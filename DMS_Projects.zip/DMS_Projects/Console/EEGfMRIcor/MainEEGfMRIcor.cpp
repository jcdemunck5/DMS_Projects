/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to remove gradient and pulse artefacts from                       */
/*     co-registered EEG/fMRI data.                                              */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history 
    
  Who    When       What
  JdM    30-09-16   creation, derived from QMEEGToolCorrectfMRIArt.cpp
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  */


#include "../../Option.h"

#include "../../MEEGDataEpochs.h"
#include "../../EEGfMRItool.h"

#define VERSION "1.04 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUmc, Amsterdam"

int     GetNString(const char* InputString, char Sep);
UString GetIString(const char* InputString, char Sep, int i);

enum
{
    OP_FILIN,
    OP_DIROUT,
    OP_CHANSEL,
    OP_GOODCH,
    OP_BADCH,
    OP_CORRECT_EEG,
    OP_CORRECT_ADC,
    OP_CORRECT_EKG,
    OP_CORRECT_VOL,
    OP_VOLMARKER,
    OP_VOLMARKERSKIP,
    OP_SKIPPED_RAW,
    OP_VOLSUBSIZE,
    OP_PARTIONFILE,
    OP_NOLOWPASS,
    OP_DOWNSAMPFREQ,
    OP_MERGELOGFILE,
    OP_MERGEVOLMARKER,
    OP_MERGENDUMMY,
    OP_CORRECT_SLI,
    OP_NSLICE,
    OP_TIMETOSLICE,
    OP_SLICETIME,
    OP_TIMEINTERPOL,
    OP_NOTIMESHIFT,
    OP_RFWIN,
    OP_CORRECT_REF,
    OP_REFLAYER_SVD,
    OP_REFLAYER_BAND,
    OP_CORRECT_BCG,
    OP_BCGMARKERS,
    OP_BCGWIN,
    OP_BCGOVERLAP,
    OP_BCGOUTLIER,
    OP_BCGADAPTAMP,
    NOPTIONS
};

static const char*   Help  [NOPTIONS];
static       UOption Option[NOPTIONS];


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme removes aretefacts from EEG data resulting from simultaneous fMRI scanning.\n"
                         "You are adviced to use BIAP1D in order to inspect your data and set all markers appropriately.\n"
                         "This program accepts several EEG data formats as input. The output will be written in CTF data format.\n"
                         "The underlying theory applied in this software is described in:\n"
                         "\n"
                         "De Munck JC, Houdt PJ, Van Wegen E, SI Gon�alves and Ossenblok PPW, (2013), Novel artefact \n"
                         "removal algorithms for co-registered EEG/fMRI based on selective averaging and subtraction, \n"
                         "NeuroImage, 64 (2013) 407�415.\n"
                         "\n"
                         "Please refer to that paper if the use of this program is a substantial part of your work.\n"
                         "\n";

    Help[OP_FILIN         ] = "Name of input file (including path).";
    Help[OP_DIROUT        ] = "Name of output CTF data file.";
    Help[OP_CHANSEL       ] = "If this option is set, take the default channels selection based on the DATAFILE.skptxt file.";
    Help[OP_GOODCH        ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels and *.skptxt files will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH         ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels and *.skptxt files will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_CORRECT_EEG   ] = "Set this option to correct EEG channels.";
    Help[OP_CORRECT_ADC   ] = "Set this option to correct ADC channels.";
    Help[OP_CORRECT_EKG   ] = "Set this option to correct ECG channels. For BCG artefact correction this option is ignored.";
    Help[OP_CORRECT_VOL   ] = "Set this option apply gradient correction on each recorded fMRI volume.";
    Help[OP_VOLMARKER     ] = "Give the name of the volume marker.";
    Help[OP_VOLMARKERSKIP ] = "Give the name of the marker refering to (BAD) volumes to be skipped.";
    Help[OP_SKIPPED_RAW   ] = "Set this option to leave BAD volumes as raw (otherwise the data at these volumes are set to zero).";
    Help[OP_VOLSUBSIZE    ] = "You can split the computation of volume templates into subgroups of subsequent volumes. To use this option, give the number of volumes in each subgroup.";
    Help[OP_PARTIONFILE   ] = "Alternatively, you can split the volumes into subgroups by means of a partition file (created by BIAP1D). To use this option, give the name of the partion file.";
    Help[OP_NOLOWPASS     ] = "By default, a low pass filter is applied, with one third of the sampling frequency. To switch off this filter, set this option.";
    Help[OP_DOWNSAMPFREQ  ] = "You can down sample the sampling frequency to a given frequancy. This can safely be done after gradient correction.";
    Help[OP_MERGELOGFILE  ] = "You can merge the channels of another (ECG, Pulse, Respiration) file that was recorded simulaneously with the EEG and fMRI. To use that option, give the file name of these data.";
    Help[OP_MERGEVOLMARKER] = "Give the name of the volume marker in the coregistered (ECG, Pulse, Respiration) file.";
    Help[OP_MERGENDUMMY   ] = "Give the number of (dummy) events of the volume marker of the (ECG, Pulse, Respiration) file that need to be skipped in order the get a good sychronization with the EEG data file.";
    Help[OP_CORRECT_SLI   ] = "Set this option to apply a template correction corresponding to each slice.";
    Help[OP_NSLICE        ] = "Give the number of slices per volume in the fMRI data.";
    Help[OP_TIMETOSLICE   ] = "Give the time [s] between the volume marker and the first slice.";
    Help[OP_SLICETIME     ] = "Give the duration [s] of each slice.";
    Help[OP_TIMEINTERPOL  ] = "Give the time interpolation method (0: roundoff, 1: linear, 2: FFT.";
    Help[OP_NOTIMESHIFT   ] = "Set this option to skip sub-sample time shift correction. This should be set in case of partion file.";
    Help[OP_RFWIN         ] = "Give this option to remove RF pulse artefacts by linearly interpolating the data over fixed windoes preceeding each slice recording. Here you give the begin and end sample of that window [samples]. Note: Slice time parameters and number of slices should be set.";
    Help[OP_CORRECT_REF   ] = "If the EEG cap was furnished with a layer reference channels, not attched to the skin, you can use these reference signals to clean the normal EEG channels.";
    Help[OP_REFLAYER_SVD  ] = "If you choose to use the reference channels, you can here give the number of SVD components of the signals projected out of the EEG.";
    Help[OP_REFLAYER_BAND ] = "If you choose to use the reference channels, you can here give the range of a band-pass filer, applied to both EEG and reference signals, before applying SVD. An invalid range implies that bandpass filtering is skipped.";
    Help[OP_CORRECT_BCG   ] = "Give this option to correct for BCG artefacts.";
    Help[OP_BCGMARKERS    ] = "Give a comma sepatated string with all ECG markers you want to use for BCG correction, e.g.: ECG_1,ECG_2,ECG_3_1.";
    Help[OP_BCGWIN        ] = "Give the time window used for BCG correction by giving the begin and and samples.";
    Help[OP_BCGOVERLAP    ] = "Set this option to account for overlapping BCG artefacts.";
    Help[OP_BCGOUTLIER    ] = "Specify the fraction of outliers applied when determining the template BCG artefacts.";
    Help[OP_BCGADAPTAMP   ] = "Give this option to allow for BCG artefacts that vary in amplitude.";

    Option[OP_FILIN         ] = UOption(      "InputFile"    ,Help[OP_FILIN         ], UOption::FILENAME);
    Option[OP_DIROUT        ] = UOption(      "OutputFile"   ,Help[OP_DIROUT        ], UOption::DATASETNAME);
    Option[OP_CHANSEL       ] = UOption("Skp","SkipChan"     ,Help[OP_CHANSEL       ]);
    Option[OP_GOODCH        ] = UOption("Gch","GoodCh"       ,Help[OP_GOODCH        ],NULL);
    Option[OP_BADCH         ] = UOption("Bch","BadCh"        ,Help[OP_BADCH         ],NULL);
    Option[OP_CORRECT_EEG   ] = UOption("E"  ,"CorrectEEG"   ,Help[OP_CORRECT_EEG   ]);
    Option[OP_CORRECT_ADC   ] = UOption("A"  ,"CorrectADC"   ,Help[OP_CORRECT_ADC   ]);
    Option[OP_CORRECT_EKG   ] = UOption("C"  ,"CorrectECG"   ,Help[OP_CORRECT_EKG   ]);
    Option[OP_CORRECT_VOL   ] = UOption("Vol","VolCorrection",Help[OP_CORRECT_VOL   ]);
    Option[OP_VOLMARKER     ] = UOption("VoM","VolMarker"    ,Help[OP_VOLMARKER     ], "Vol");
    Option[OP_VOLMARKERSKIP ] = UOption("VoB","VolBAD"       ,Help[OP_VOLMARKERSKIP ], "VolBAD");
    Option[OP_SKIPPED_RAW   ] = UOption("BaR","SetBADRaw"    ,Help[OP_SKIPPED_RAW   ]);
    Option[OP_VOLSUBSIZE    ] = UOption("Grp","GroupSize"    ,Help[OP_VOLSUBSIZE    ], 2, 1000000, 100);
    Option[OP_PARTIONFILE   ] = UOption("Prt","PartFile"     ,Help[OP_PARTIONFILE   ],"Vol.Part");
    Option[OP_NOLOWPASS     ] = UOption("NoL","NoLowPass"    ,Help[OP_NOLOWPASS     ]);
    Option[OP_DOWNSAMPFREQ  ] = UOption("Frq","DownSamp"     ,Help[OP_DOWNSAMPFREQ  ], 1., 10000., 250.);
    Option[OP_MERGELOGFILE  ] = UOption("MLo","MergLog"      ,Help[OP_MERGELOGFILE  ], "Phys.log");
    Option[OP_MERGEVOLMARKER] = UOption("MVo","TR_Marker"    ,Help[OP_MERGEVOLMARKER], "TR");
    Option[OP_MERGENDUMMY   ] = UOption("MDu","NDummy"       ,Help[OP_MERGENDUMMY   ], 0, 1000, 2);
    Option[OP_CORRECT_SLI   ] = UOption("Sli","SliCorrection",Help[OP_CORRECT_SLI   ]);
    Option[OP_NSLICE        ] = UOption("NSl","NumSlice"     ,Help[OP_NSLICE        ], 1, 500, 30);
    Option[OP_TIMETOSLICE   ] = UOption("TtS","TimeToSlice"  ,Help[OP_TIMETOSLICE   ], 0., 100., 0.);
    Option[OP_SLICETIME     ] = UOption("SlT","SliceTime"    ,Help[OP_SLICETIME     ], 1.e-10, 500.,0.1);
    Option[OP_TIMEINTERPOL  ] = UOption("Int","Interpol"     ,Help[OP_TIMEINTERPOL  ], 0, 2, 2);
    Option[OP_NOTIMESHIFT   ] = UOption("NTS","NoTimeShift"  ,Help[OP_NOTIMESHIFT   ]);
    Option[OP_RFWIN         ] = UOption("RF" ,"RFCorrection" ,Help[OP_RFWIN         ], -10000, 10000, -100, 100);
    Option[OP_CORRECT_REF   ] = UOption("RLa","RefLayer"     ,Help[OP_CORRECT_REF   ]);
    Option[OP_REFLAYER_SVD  ] = UOption("RSV","RefLayerSVD"  ,Help[OP_REFLAYER_SVD  ], 1, 100, 6);
    Option[OP_REFLAYER_BAND ] = UOption("RBp","RefLayerBandP",Help[OP_REFLAYER_BAND ], -1., 10000., 0.,100.);
    Option[OP_CORRECT_BCG   ] = UOption("BCG","BCGCorrection",Help[OP_CORRECT_BCG   ]);
    Option[OP_BCGMARKERS    ] = UOption("MMa","BCGMarkers"   ,Help[OP_BCGMARKERS    ], "EKG1,EKG2,EGG3");
    Option[OP_BCGWIN        ] = UOption("BWi","BCGWindow"    ,Help[OP_BCGWIN        ], -10000, 10000, -1000, 999);
    Option[OP_BCGOVERLAP    ] = UOption("Ove","BCGOverlap"   ,Help[OP_BCGOVERLAP    ]);
    Option[OP_BCGOUTLIER    ] = UOption("Bot","BCGOulier"    ,Help[OP_BCGOUTLIER    ], 0., 1., 0.05);
    Option[OP_BCGADAPTAMP   ] = UOption("Bam","BCGAplitude"  ,Help[OP_BCGADAPTAMP   ]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

#ifdef WIN32 
    FFTW.SetWisdomDir("C:\\TempQt");
#else
    FFTW.SetWisdomDir("~/TempQt");
#endif

    UFileName   Fin            = UFileName(Option[OP_FILIN].GetFileName());
    bool        AutoRemoveChan = Option[OP_CHANSEL ].GetValueSet();
    const char* GoodChan       = Option[OP_GOODCH  ].GetValueSet() ? Option[OP_GOODCH].GetString() : NULL;
    const char* BadChan        = Option[OP_BADCH   ].GetValueSet() ? Option[OP_BADCH ].GetString() : NULL;
    if( (GoodChan || BadChan) && AutoRemoveChan)
        CI.AddToLog("WARNING: *.skptxt file will be ignored, because good/bad channel option is also set.\n");

    UMEEGDataEpochs DatEpo(Fin);
    if(DatEpo.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: Setting data file %s .\n", (const char*)Fin);
        CI.PressReturnExit();
    }
    if(GoodChan || BadChan)
    {
        if(DatEpo.SelectChannels(GoodChan, BadChan)!=U_OK)
        {
            CI.AddToLog("ERROR: Removing given channels. \n");
            CI.PressReturnExit();
        }
    }
    else if(AutoRemoveChan)
    {
        if(DatEpo.RemoveChannelsFromSkipFile()!=U_OK)
        {
            CI.AddToLog("ERROR: Removing channels from default .skptxt file. \n");
            CI.PressReturnExit();
        }
    }

    UEEGfMRITool ETool;

    ErrorType   E = U_OK;
    if(E==U_OK) E = ETool.SetTemplateData(&DatEpo);
    if(E==U_OK) E = ETool.SetOutputDataFile(Option[OP_DIROUT].GetFileName());
    if(E==U_OK) E = ETool.SetVolumeMarker(UString(Option[OP_VOLMARKER].GetString()));

    UString VolSkip = Option[OP_VOLMARKERSKIP].GetValueSet() ? UString(Option[OP_VOLMARKERSKIP].GetString()) : UString();
    if(E==U_OK) E = ETool.SetCorrectVolumes(Option[OP_CORRECT_VOL].GetValueSet(), VolSkip, NOT(Option[OP_SKIPPED_RAW].GetBOOL()));
    if(E==U_OK) E = ETool.ApplySubGroups(Option[OP_VOLSUBSIZE].GetValueSet(), Option[OP_VOLSUBSIZE].GetValue());
    if(E==U_OK) E = ETool.ApplyPartionFile(Option[OP_PARTIONFILE].GetValueSet(), UFileName(Option[OP_PARTIONFILE].GetString()));
    if(E==U_OK) E = ETool.SetPostProcess(Option[OP_DOWNSAMPFREQ].GetValueSet(), Option[OP_DOWNSAMPFREQ].GetDubVal1(), NOT(Option[OP_NOLOWPASS].GetBOOL()));
    if(E==U_OK) E = ETool.CorrectDataTypes(Option[OP_CORRECT_EEG].GetBOOL(), DatEpo.GetData()->GetNADC()>0&&Option[OP_CORRECT_ADC].GetBOOL(), Option[OP_CORRECT_EKG].GetBOOL());

    TimeShiftType Inter =  Option[OP_TIMEINTERPOL].GetValue()==0 ? U_TIMESHIFT_SAMPLE : \
                          (Option[OP_TIMEINTERPOL].GetValue()==1 ? U_TIMESHIFT_LINEAR : U_TIMESHIFT_FFT);
    if(E==U_OK) E = ETool.SetCorrectSlices(Option[OP_CORRECT_SLI].GetBOOL(), Option[OP_NSLICE].GetValue(), Option[OP_TIMETOSLICE].GetDubVal1(), Option[OP_SLICETIME].GetDubVal1(), Inter, Option[OP_NOTIMESHIFT].GetBOOL());

    if(E==U_OK) E = ETool.SetCorrectRFPulse(Option[OP_RFWIN].GetValueSet(), Option[OP_RFWIN].GetValue1(), Option[OP_RFWIN].GetValue1());
    if(E==U_OK) E = ETool.SetCorrectRefLayer(Option[OP_CORRECT_REF].GetBOOL(), Option[OP_REFLAYER_SVD].GetValue(), Option[OP_REFLAYER_BAND].GetDubVal1(), Option[OP_REFLAYER_BAND].GetDubVal2());

    if(Option[OP_CORRECT_BCG].GetValueSet())
    {
        int NEKG = GetNString(Option[OP_BCGMARKERS].GetString(), ',');
        if(E==U_OK) E = ETool.SetCorrectBCG(Option[OP_CORRECT_BCG].GetValueSet(), NEKG, Option[OP_BCGWIN].GetValue1(), Option[OP_BCGWIN].GetValue2(), Option[OP_BCGOUTLIER].GetDubVal1(), Option[OP_BCGOVERLAP].GetBOOL(), Option[OP_BCGADAPTAMP].GetBOOL(), false);
    
        for(int k=0; k<NEKG; k++)
            if(E==U_OK ) E = ETool.SetEKGMarker(GetIString(Option[OP_BCGMARKERS].GetString(), ',', k));
    }
    if(E==U_OK) E = ETool.OutputBCGArtefacts(false, false);

    if(E==U_OK) E = ETool.SetMergeLogFile(Option[OP_MERGELOGFILE].GetValueSet(), UFileName(Option[OP_MERGELOGFILE].GetString()), UString(Option[OP_MERGEVOLMARKER].GetString()), Option[OP_MERGENDUMMY].GetValue());

    CI.AddToLog("%s", ETool.GetProperties(" "));
    if(E==U_OK) E = ETool.ComputeSaveCorrectedData();


    if(E!=U_OK)
    {
        CI.AddToLog("Error in parameter settings or computations.\n");
        CI.PressReturnExit();
    }
    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}

int     GetNString(const char* InputString, char Sep)
{
    if(InputString==NULL) return 0;
    int Len = strlen(InputString);

    int NS = 1;
    for(int n=0; n<Len; n++) if(InputString[n]==Sep) NS++;

    return NS;
}
UString GetIString(const char* InputString, char Sep, int i)
{
    if(InputString==NULL) return UString();
    if(i          < 0   ) return UString();

    int Len    = strlen(InputString);
    int From   = 0;
    int To     = Len;

    for(int n=0, ikey=1; n<Len; n++) 
        if(InputString[n]==Sep) 
        {
            if(ikey==i  ) From = n+1;
            if(ikey==i+1) To   = n;
            ikey++;
        }
    UString S(InputString+From);
    S.Truncate(To-From);
    return S;
}

