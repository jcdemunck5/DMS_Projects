/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     Preprocess EIT data.                                                       */
/*     Read voltages at active electrodes ("EIT.txt").                            */
/*     Read injection channels and BAD channels ("EIT_Config.txt").               */
/*                                                                                */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
Update history

 Who    When       What
 JdM    31-05-18   creation
 JdM    10-06-18   Output injection/extraction electrodes, NVolt
 JdM    08-07-18   Made command line version
 JdM    09-07-18   Create one single output file. 
 JdM    13-07-18   Remove (obsolete) "Opt" option.
 JdM    17-07-18   Remove (obsolete) call to system("pause")
 JdM    11-09-18   ConvertOpposing(). Automatically detect opposing electrode pairs
 JdM    28-09-18   Added option to force a concentric sphere model.
 */

#include<string.h>

#include "../EIT_Subjects.h"

#include "../../Option.h"
#include "../../StringTable.h"
#include "../../MarkerArray.h"
#include "../../GridFit.h"
#include "../../HeadModel.h"
#include "../../EMfield.h"
#include "../../SortSemiSort.h"
#include "../../MapFile.h"

#define VERSION "1.06"
#define AUTHOR  "Dr. JC de Munck, VUmc dept. RNG, Amsterdam"


enum
{
    OP_DIRIN, OP_FILEOUT,OP_KEEPLOG,
    OP_ELCFILE, OP_BEMFILE, OP_BEMNPOINTS, OP_BEMINTER, OP_BEMMONO, OP_SPHERES, OP_AVERREF, OP_OPPINJECT,
    NOPTIONS
};

#define  NSIGSTEP     100
#define  NSKBRRAT       3
const double RatMin          =    0.5; // Skin Skull sigma ratio
const double RatMax          =  120. ;
const double SkinBrainRat[NSKBRRAT] =  {0.4,1.0,2.5}; // Skin Brain sigma ratio

const double BrainRad        = 0.87;
const double SkullRad        = 0.95;
static bool AverReference    = false;
static bool ConvOpposElec    = false;
static int NtotalPoints      = 3000;
static PotInterPolType PInt  = U_POTINTER_LINEAR;
static BEMSmoothType   Smo   = U_SMOOTH_SMOOTH;
static bool UseMonoLayer     = false;

static const char*   Help  [NOPTIONS];
static UOption       Option[NOPTIONS];

UString GetProperties(UString Comment);
ElecType* GetEltypes(UFileName F, int* Ntrial, int** iref, int** inj, int** ext, bool** BadTrial);
ErrorType ConvertOpposing(ElecType* El, UMatrix* Rmat, const UGrid* GrEEG, int* Ntrial, int* iref, int* inj, int* ext, bool* BadTrial, UDirectory MapDir);

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme computes skin, skull and brain conductivities on the basis of potential measurements due to current injections.\n"
        "It uses two files as input: (EIT.txt and EIT_EIT_Config.txt), which are created by the command line rogramme EIT_Preprop. \n"
        "An optimized version of boundary element method (BEM) is used, which uses the Sherman Morison formula for matrix inversion. BEM \n"
        "parameters are read from a file specified by the user, and some options of this program can be used to overwrite the BEM configuration \n"
        "file. "
        "The output of this file consists of two files, one containing the fit error as function of the skull/skin conductivity ratio and\n"
        "and the other contains the conductivities of skin, skul and brain for three possible assumptions of the skin/brain conductivity ratio.\n\n";

    Help[OP_DIRIN       ] = "Input directory containing the files to be analyzed: EIT.txt and EIT_EIT_Config.txt.";
    Help[OP_FILEOUT     ] = "Output filename. If no path is included, the file is stored in the input directory.";
    Help[OP_KEEPLOG     ] = "If this option is set, the old .log file is not deleted but new results are appended on existing .log file";
    Help[OP_ELCFILE     ] = "Electrode file. If no path is included, the file is read from the in the input directory.";
    Help[OP_BEMFILE     ] = "Head model file, (e.g. created by BIAP4D) containing skin, skull and brain surfaces, as well some other necessary parameters. Some of these will be overwritten by the other options of this programme.";
    Help[OP_BEMNPOINTS  ] = "Total number of points (unknowns) used for BEM computations. -1 indicates that the surfaces are taken as is. When the number of points is set, the number of points on each surface is optimized: 50% of the points to the skin, 30% to the skull and 20 % to the brain. In this way most point are located at largest spatial gradients.";
    Help[OP_BEMINTER    ] = "BEM interpolation mode: 0=piecewise constant, 1=piecewise linear.";
    Help[OP_BEMMONO     ] = "If this option is set, the mono-layer configuration is used. Otherwise the standard double layer approach is taken.";
    Help[OP_SPHERES     ] = "Ignore BEM parameters and force concentric sphere model, fitted to electrode positions.";
    Help[OP_AVERREF     ] = "If this option is set, voltage data is converted to average reference before fitting the data. Otherwise, the reference electrode is take according to the input file";
    Help[OP_OPPINJECT   ] = "If this option is set, different current injection trials are combined in order to create opposing current injections.";

    Option[OP_DIRIN       ] = UOption("DataDir"          ,Help[OP_DIRIN ], UOption::DATASETNAME);
    Option[OP_FILEOUT     ] = UOption("FileOut"          ,Help[OP_FILEOUT ], UOption::FILENAME);
    Option[OP_KEEPLOG     ] = UOption("KL", "KeepLog"    ,Help[OP_KEEPLOG]);
    Option[OP_ELCFILE     ] = UOption("Elc","ElecFile"   ,Help[OP_ELCFILE],"");
    Option[OP_BEMFILE     ] = UOption("HM" ,"HeadModel"  ,Help[OP_BEMFILE],"");
    Option[OP_BEMNPOINTS  ] = UOption("NP" ,"NPoints"    ,Help[OP_BEMNPOINTS], -1,100000, NtotalPoints);
    Option[OP_BEMINTER    ] = UOption("Int","Interpol"   ,Help[OP_BEMINTER],0,1,1);
    Option[OP_BEMMONO     ] = UOption("Mon","MonoLayer"  ,Help[OP_BEMMONO]);
    Option[OP_SPHERES     ] = UOption("Sph","Spheres"    ,Help[OP_SPHERES]);
    Option[OP_AVERREF     ] = UOption("Ave","AverRef"    ,Help[OP_AVERREF]);
    Option[OP_OPPINJECT   ] = UOption("Opp","OppInject"  ,Help[OP_OPPINJECT]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);
    if(NOT( Option[OP_KEEPLOG].GetBOOL())) {CI.ResetLogFile(); CI.TranslateArgs(Option, NOPTIONS, Intro);}
    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UDirectory DDin(Option[OP_DIRIN].GetFileName());
    UFileName FileVolt = DDin + UFileName(ResistorName);
    UFileName FileConf = DDin + UFileName(ConfigName);
    if(FileVolt.DoesFileExist()==false||FileConf.DoesFileExist()==false)
    {
        CI.AddToLog("ERROR: Data file(s) do not exist %s and/or %s .\n", (const char*)FileVolt, (const char*)FileConf);
        CI.PressReturnExit();
    }
    UStringTable ST_Res(FileVolt,'\t',UString("//"));
    ST_Res.DeleteCollumn(0);
    UMatrix Rmat = ST_Res.GetTableAsMatrix();
    if(ST_Res.GetError()!=U_OK||Rmat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Reading voltages from file: %s .\n", (const char*)FileVolt);
        CI.PressReturnExit();
    }

    UFileName FileElc(Option[OP_ELCFILE].GetString());
    if(FileElc.IsPureFile()) FileElc = DDin+FileElc;
    UFileName FileHM(Option[OP_BEMFILE].GetString());
    if(FileHM.IsPureFile()) FileHM = DDin+FileHM;
    
    bool ForceSphereModel = Option[OP_SPHERES].GetBOOL();
    if(FileElc.DoesFileExist()==false||(ForceSphereModel==false && FileHM.DoesFileExist()==false))
    {
        CI.AddToLog("ERROR: File(s) do not exist %s and/or %s .\n", (const char*)FileElc, (const char*)FileHM);
        CI.PressReturnExit();
    }
    UGridFit      GEEG(FileElc);
    if(GEEG.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Reading elecrodes from file %s .\n", (const char*)FileElc);
        CI.PressReturnExit();
    }
    if(GEEG.SelectSensors(ST_Res.GetHeader(), ST_Res.GetNcol())!=U_OK)  // Here after sensors are sorted according to header
    {
        CI.AddToLog("ERROR: Selecting sensors .\n");
        CI.PressReturnExit();
    }
    UVector3 Spos;
    double   Hrad = 0.;
    if(GEEG.FitSphere(Spos, &Hrad)<0.||Hrad<=1.)
    {
        CI.AddToLog("ERROR: Fitting sphere to EEG sensors, Rad = %f .\n", Hrad);
        CI.PressReturnExit();
    }

    UHeadModel HM = ForceSphereModel ? UHeadModel(1., 0.1, SkullRad, BrainRad, Spos, Hrad) : UHeadModel(FileHM);
    if(HM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Reading BEM model from file %s .\n", (const char*)FileHM);
        CI.PressReturnExit();
    }
    ConvOpposElec   = Option[OP_OPPINJECT   ].GetBOOL();

    UFileName FileCond(Option[OP_FILEOUT].GetFileName());
    if(FileCond.IsPureFile()==true) FileCond = DDin + FileCond;
    if(ConvOpposElec) FileCond.InsertBeforeExtension("_Opp");
    FILE*     fpCon = fopen(FileCond,"wt");
    if(fpCon==NULL)
    {
        CI.AddToLog("ERROR: Output file cannot be created: %s .\n", (const char*)FileCond);
        CI.PressReturnExit();
    }
    fprintf(fpCon,"%s",CI.GetProperties("//  "));

    fprintf(fpCon,"Skin/Brain=%f \t\t\t\t\t",SkinBrainRat[0]);
    fprintf(fpCon,"Skin/Brain=%f \t\t\t\t\t",SkinBrainRat[1]);
    fprintf(fpCon,"Skin/Brain=%f \t\t\t\t\n",SkinBrainRat[2]);
    fprintf(fpCon, "SigSkin \tSigSkull \tSigBrain \tRatio \tError [%%]\t");
    fprintf(fpCon, "SigSkin \tSigSkull \tSigBrain \tRatio \tError [%%]\t");
    fprintf(fpCon, "SigSkin \tSigSkull \tSigBrain \tRatio \tError [%%]\n");
    fclose(fpCon);

    AverReference    = Option[OP_AVERREF     ].GetBOOL();
    NtotalPoints     = Option[OP_BEMNPOINTS  ].GetValueSet() ? Option[OP_BEMNPOINTS  ].GetValue() : -1;
    PInt             = Option[OP_BEMINTER    ].GetValue()==1 ? U_POTINTER_LINEAR : U_POTINTER_CONSTANT;
    UseMonoLayer     = Option[OP_BEMMONO     ].GetBOOL();

    int   Ntrial = 0;
    int*  iref   = NULL;
    int*  inj    = NULL;
    int*  ext    = NULL;
    bool* BadT   = NULL;
    ElecType* Elmat = GetEltypes(FileConf, &Ntrial, &iref, &inj, &ext, &BadT);
    if(Elmat==NULL)
    {
        CI.AddToLog("ERROR: Reading electrode configuration from file: %s .\n", (const char*)FileConf);
        CI.PressReturnExit();
    }

    if(ConvOpposElec && ConvertOpposing(Elmat, &Rmat, &GEEG, &Ntrial, iref, inj, ext, BadT, FileCond.GetDirectory())!=U_OK)
    {
        CI.AddToLog("ERROR: Combining trials to opposing electrode configration.\n");
        CI.PressReturnExit();
    }
    UEMfield   EMF = ForceSphereModel ? UEMfield(&HM) : UEMfield(&HM,PInt,Smo,UseMonoLayer);
    if(NOT(ForceSphereModel) && EMF.GetOuterSurf()!=0) EMF.SwapSurfaces(0,2);

    double Frac[3] = {0.5, 0.3,0.2};
    if(NOT(ForceSphereModel) && NtotalPoints>=0) 
    {
        if(EMF.ResampleSurfaces(PInt==U_POTINTER_LINEAR?NtotalPoints:NtotalPoints/2, Frac, 3)!=U_OK)
        {
            CI.AddToLog("ERROR: Resampling surfaces.\n");
            CI.PressReturnExit();
        }
    }
    bool FewRHS  = true;
    bool ManySig = true;
    EMF.SetGrid(NULL, &GEEG, FewRHS, ManySig);

    UMatrix Result(DNULL, NSIGSTEP, 5*NSKBRRAT); // (SigSkin, SigSkull, SigBrain, Ratio, Error) * NSKBRRAT

    for(int sbr=0; sbr<NSKBRRAT; sbr++)
    {
        bool RowSel[NSIGSTEP];
        for(int k=0; k<NSIGSTEP; k++)
        {
            double SigSkin  = 1;
            double LogRat   = log(RatMin) + (log(RatMax/RatMin))*k/double(NSIGSTEP-1);
            double Rat      = exp(LogRat);
            double Sigma[5] = {SigSkin, SigSkin/Rat, SigSkin/SkinBrainRat[sbr], 0., 0.};
            EMF.SetSigma(Sigma);

            RowSel[k]    = Rat>2.;
            double SumRR = 0;
            double SumPR = 0;
            double SumPP = 0;
            for(int it=0, itel=0; it<Rmat.GetNrow(); it++)
            {
                if(BadT[it]) {itel+=Rmat.GetNcol(); continue;}
                UMatrix Psi = EMF.GetEfieldAsMatrix(1., inj[it], ext[it], iref[it]);

                double RefDat = 0.;
                double RefMod = 0.;
                if(AverReference)
                {
                    int NVolt = 0;
                    for(int el=0; el< Rmat.GetNcol(); el++, itel++)
                    {
                        if(Elmat[itel]!=U_ELECTYPE_VOLT) continue;
                        RefDat += Rmat[itel];
                        RefMod += Psi[el];
                        NVolt++;
                    }
                    itel    -= Rmat.GetNcol();
                    RefDat  /= NVolt;
                    RefMod  /= NVolt;
                }
                
                for(int el=0; el< Rmat.GetNcol(); el++, itel++)
                {
                    if(Elmat[itel]!=U_ELECTYPE_VOLT) continue;
                    SumRR += ( Rmat[itel]-RefDat)*( Rmat[itel]-RefDat);
                    SumPR += ( Psi[el]   -RefMod)*( Rmat[itel]-RefDat);
                    SumPP += ( Psi[el]   -RefMod)*( Psi[el]   -RefMod);
                }
            }
            SigSkin  = SumPP/SumPR;
            Sigma[0] = SigSkin;
            Sigma[1] = SigSkin/Rat;
            Sigma[2] = SigSkin/SkinBrainRat[sbr];
            Sigma[3] = Rat;                        // Skin/Skull ratio
            Sigma[4] = 1. - SumPR/(SigSkin*SumRR); // Residual error
            Result.SetBlock(k, sbr*5, UMatrix(Sigma, 1, 5));
            CI.AddToLog("%d, ", k);
        }
        int kmin = -1;
        Result.GetColMin(sbr*5+4, false, RowSel, &kmin);

        fpCon = fopen(FileCond,"at");
        for(int kk=0; kk<5;kk++) fprintf(fpCon, "%f \t",Result.GetElement(kmin, sbr*5+kk));
        if(sbr==NSKBRRAT-1) fprintf(fpCon,"\n");
        fclose(fpCon);
    }
    CI.AddToLog("\n");

    UString Properties = GetProperties("// ");

    fpCon = fopen(FileCond,"at");
    fprintf(fpCon,"\n\nCurves: \n");
    for(int i=0; i<Result.GetNrow(); i++)
    {
        for(int j=0; j<Result.GetNcol()-1; j++) fprintf(fpCon, "%f \t", Result.GetElement(i,j));
        fprintf(fpCon, "%f \n", Result.GetElement(i,Result.GetNcol()-1));
    }
    fclose(fpCon);

    fpCon = fopen(FileCond,"at");
    fprintf(fpCon,"\n\nProperties: \n");
    fprintf(fpCon, "%s", CI.GetProperties("//  "));
    fprintf(fpCon," \n");
    fprintf(fpCon,"// Trial: \tNVolt \tNBAD \tInjections: \tRef \n");
    for(int it=0,itel=0; it<Ntrial; it++)
    {
        if(BadT[it]) 
        {
            fprintf(fpCon,"// %d \tBAD trial.\n",it);
            itel += Rmat.GetNcol();
            continue;
        }
        int NVolt = 0; for(int el=0; el<Rmat.GetNcol(); el++, itel++) if(Elmat[itel]==U_ELECTYPE_VOLT) NVolt++;
        fprintf(fpCon,"// %d: \t%d \t", it, NVolt);

        itel -= Rmat.GetNcol();
        int NBAD = 0; for(int el=0; el<Rmat.GetNcol(); el++, itel++) if(Elmat[itel]==U_ELECTYPE_BAD) NBAD++;
        fprintf(fpCon,"%d \t", NBAD);

        const UString* H = ST_Res.GetHeader();
        fprintf(fpCon,"%s-%s  \t%s \n",(const char*)H[inj[it]], (const char*)H[ext[it]], (const char*)H[iref[it]]);
    }
    fprintf(fpCon," \n");

    UString Pr = GetProperties("//  ");
    fprintf(fpCon, "%s", (const char*)Pr);
    fprintf(fpCon," \n");
    fprintf(fpCon,EMF.GetProperties("//  "));
    fclose(fpCon);

    delete[] Elmat;
    delete[] iref;
    delete[] inj;
    delete[] ext;
    delete[] BadT;
    return 0;
}

UString GetProperties(UString Comment)
{
    UString Properties =  UString();

    Properties += UString(GetPotInterTypeText(PInt)  ,"BEM_INTERPOLATE     = %s \n");
    Properties += UString(GetBEMSmoothTypeText(Smo)  ,"BEM_SMOOTH          = %s \n");
    Properties += UString(BoolAsText(UseMonoLayer)   ,"BEM_MONOLAYER       = %s \n");
    Properties += UString(NtotalPoints               ,"BME_NPOINTS_TOTAL   = %d \n");
    Properties += UString(BoolAsText(AverReference)  ,"AverageReference    = %s \n");
    Properties += UString(BoolAsText(ConvOpposElec)  ,"ConvOpposElectrodes = %s \n");
    Properties += UString(SkinBrainRat[0]            ,"SkinBrainRatio[0]   = %f \n");
    Properties += UString(SkinBrainRat[1]            ,"SkinBrainRatio[1]   = %f \n");
    Properties += UString(SkinBrainRat[2]            ,"SkinBrainRatio[2]   = %f \n");

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);
    return Properties;
}

ElecType* GetEltypes(UFileName F, int* Ntrial, int** iref, int** inj, int** ext, bool** BadTrial)
{
    UStringTable ST(F,'\t',UString("//"));
    ST.DeleteCollumn(0);

    int NR       = ST.GetNrow();
    int NC       = ST.GetNcol();

    *Ntrial      = NR;
    *iref        = new int[NR];
    *inj         = new int[NR];
    *ext         = new int[NR];
    *BadTrial    = new bool[NR];
    ElecType* ET = new ElecType[NR*NC];

    for(int ir=0, k=0; ir<NR; ir++) (*iref)[ir] = (*inj)[ir] = (*ext)[ir] = -1;
    for(int ir=0, k=0; ir<NR; ir++) (*BadTrial)[ir] = false;
    for(int ir=0, k=0; ir<NR; ir++)
    { 
        for(int ic=0; ic<NC; ic++, k++)
        {
            ET[k]     = U_ELECTYPE_NELEC;
            UString S = ST.GetElem(ir, ic);

            if(S.IsEqual(ETName[U_ELECTYPE_VOLT],false,true)) ET[k] = U_ELECTYPE_VOLT;
            else if(S.IsEqual(ETName[U_ELECTYPE_REF ],false,true)) ET[k] = U_ELECTYPE_REF ;
            else if(S.IsEqual(ETName[U_ELECTYPE_INJ ],false,true)) ET[k] = U_ELECTYPE_INJ ;
            else if(S.IsEqual(ETName[U_ELECTYPE_EXT ],false,true)) ET[k] = U_ELECTYPE_EXT ;
            else if(S.IsEqual(ETName[U_ELECTYPE_BAD ],false,true)) ET[k] = U_ELECTYPE_BAD ;
        }
        for(int ic=0; ic<NC; ic++)
        {
            if(ET[ir*NC+ic]==U_ELECTYPE_REF)
            {
                if((*iref)[ir]<0) (*iref)[ir] = ic;
                else
                {
                    CI.AddToLog("ERROR: More than one reference electrode detected. Ignore %s \n", (const char*) ST.GetHeader()[ic]);
                    (*BadTrial)[ir] = true;
                }
            }
            if(ET[ir*NC+ic]==U_ELECTYPE_INJ)
            {
                if((*inj)[ir]< 0) (*inj)[ir] = ic;
                else
                {
                    CI.AddToLog("ERROR: More than one injection electrodes detected. Ignore %s \n", (const char*) ST.GetHeader()[ic]);
                    (*BadTrial)[ir] = true;
                }
            }
            if(ET[ir*NC+ic]==U_ELECTYPE_EXT)
            {
                if((*ext)[ir]< 0) (*ext)[ir] = ic;
                else
                {
                    CI.AddToLog("ERROR: More than one extraction electrodes detected. Ignore %s \n", (const char*) ST.GetHeader()[ic]);
                    (*BadTrial)[ir] = true;
                }
            }
        }
    }
    for(int ir=0; ir<NR; ir++)
    {
        if((*iref)[ir]<0)  {CI.AddToLog("ERROR: No reference electrode detected in trial %d \n", ir); (*BadTrial)[ir] = true;}
        if((*inj )[ir]<0)  {CI.AddToLog("ERROR: No injection electrode detected in trial %d \n", ir); (*BadTrial)[ir] = true;}
        if((*ext )[ir]<0)  {CI.AddToLog("ERROR: No extraction electrode detected in trial %d \n", ir);(*BadTrial)[ir] = true;}
    }
    return ET;
}

ErrorType ConvertOpposing(ElecType* ElNew, UMatrix* RmatNew, const UGrid* GrEEG, int* Ntrial, int* irefNew, int* injNew, int* extNew, bool* BadTrialNew, UDirectory MapDir)
{
    if(RmatNew==NULL || ElNew==NULL || GrEEG==NULL || irefNew==NULL || injNew==NULL || extNew==NULL || BadTrialNew==NULL || GrEEG->GetNpoints()!=RmatNew->GetNcol() || RmatNew->GetNrow()!=*Ntrial)
    {
        CI.AddToLog("ERROR: ConvertOpposing(). Inconsisent (NULL) input.\n");
        return U_ERROR;
    }
    int    NR      = RmatNew->GetNrow();
    int    NC      = RmatNew->GetNcol();

    ElecType*    El = new ElecType[NR*NC];
    UMatrix    Rmat = UMatrix(*RmatNew);
    int*       iref = new int[NR];
    int*        inj = new int[NR];
    int*        ext = new int[NR];
    bool*  BadTrial = new bool[NR];
    int*      pairs = new int[2*NR];
    UString* MapLab = new UString[NR];
    if(pairs==NULL||El==NULL||iref==NULL||inj==NULL||ext==NULL||BadTrialNew==NULL)
    {
        delete[] pairs; delete[] El; delete[] iref; delete[] inj; delete[] ext; delete[] BadTrialNew;
        CI.AddToLog("ERROR: ConvertOpposing(). Memory allocation.\n");
        return U_ERROR;
    }
    for(int k=0; k<NR*NC; k++) El  [k]     = ElNew  [k];
    for(int k=0; k<   NR; k++) iref[k]     = irefNew[k];
    for(int k=0; k<   NR; k++) inj [k]     = injNew [k];
    for(int k=0; k<   NR; k++) ext [k]     = extNew [k];
    for(int k=0; k<   NR; k++) BadTrial[k] = BadTrialNew[k];

/* Make pairs over array of injections or extractions, dependent on which are most */
    int    Ninj    = GetNDifferentInts(inj, *Ntrial);
    int    Next    = GetNDifferentInts(ext, *Ntrial);
    int    Nmax    = Ninj>Next ? Ninj  : Next;
    int*   ivar    = Ninj>Next ? inj   :  ext;
    int    NPair   = 0;

    for(int k1=0; k1<Nmax; k1++)
    {
        int    k1p  = k1;
        double dist = 0;
        for(int k2=0; k2<Nmax; k2++) // each pair consists of electrodes with largest mutual distance
        {
            double test = GrEEG->GetDistance(ivar[k1], ivar[k2]);
            if(test<=dist) continue;
            dist = test;
            k1p  = k2;
        }
        pairs[2*NPair  ] = ivar[k1 ];
        pairs[2*NPair+1] = ivar[k1p];
        NPair++;
    }

    for(int k=0; k<NR; k++) BadTrialNew[k] = true;
    int NTrialNew = 0;
    for(int ip=0; ip<NPair; ip++)  // Combine trial k1, k2 to create pair ip
    {
        int k1=-1; for(int k=0; k<*Ntrial; k++) if(pairs[2*ip  ]==ivar[k]) {k1 = k; break;}
        int k2=-1; for(int k=0; k<*Ntrial; k++) if(pairs[2*ip+1]==ivar[k]) {k2 = k; break;}
        if(k1<0 || k2<0) continue;
        if(iref[k1]!=iref[k2]) continue;

        if(BadTrial[k1]) continue;
        if(BadTrial[k2]) continue;

        bool II = (ivar[k1]==inj[k1] && ivar[k2]==inj[k2]);
        bool EI = (ivar[k1]==ext[k1] && ivar[k2]==inj[k2]);
        bool IE = (ivar[k1]==inj[k1] && ivar[k2]==ext[k2]);
        bool EE = (ivar[k1]==ext[k1] && ivar[k2]==ext[k2]);

        int ioldinex =-1;
        if(II && ext[k1]!=ext[k2]) continue; else ioldinex = ext[k1];
        if(EI && inj[k1]!=ext[k2]) continue; else ioldinex = inj[k1];
        if(IE && ext[k1]!=inj[k2]) continue; else ioldinex = ext[k1];
        if(EE && inj[k1]!=inj[k2]) continue; else ioldinex = inj[k1];

        int newext = (EI || EE) ? ext[k1] : inj[k1];
        int newinj = (EI || II) ? inj[k2] : ext[k2];

/* Copy local variable to output */
        for(int ii=0; ii<NC; ii++)
        {
            if(ii==newext)                                                       {ElNew[NTrialNew*NC+ii]=U_ELECTYPE_EXT; extNew[NTrialNew] =ii;}
            else if(ii==newinj)                                                  {ElNew[NTrialNew*NC+ii]=U_ELECTYPE_INJ; injNew[NTrialNew] =ii;}
            else if(El[k1*NC+ii]==U_ELECTYPE_BAD || El[k2*NC+ii]==U_ELECTYPE_BAD) ElNew[NTrialNew*NC+ii]=U_ELECTYPE_BAD;
            else if(ii==ioldinex)                                                 ElNew[NTrialNew*NC+ii]=U_ELECTYPE_BAD;
            else                                                                  ElNew[NTrialNew*NC+ii]=U_ELECTYPE_VOLT;
        }

        if(EE)       RmatNew->SetRow(NTrialNew,  Rmat.GetRow(k1)-Rmat.GetRow(k2)); //  (e1-i1) - (e2-i2) =  e1 -e2
        else if(EI)  RmatNew->SetRow(NTrialNew,  Rmat.GetRow(k1)+Rmat.GetRow(k2)); //  (e1-i1) + (e2-i2)  = e1 -i2
        else if(IE)  RmatNew->SetRow(NTrialNew, -Rmat.GetRow(k1)-Rmat.GetRow(k2)); // -(e1-i1) - (e2-i2)  =-i1 -e2
        else if(II)  RmatNew->SetRow(NTrialNew, -Rmat.GetRow(k1)+Rmat.GetRow(k2)); // -(e1-i1) + (e2-i2)  =-i1 -i2
        irefNew[NTrialNew]     = iref[k1];
        BadTrialNew[NTrialNew] = false;

        CI.AddToLog("New pair: %s -%s \n",GrEEG->GetName(extNew[NTrialNew]), GrEEG->GetName(injNew[NTrialNew]));
        if(MapLab) MapLab[NTrialNew] = UString(GrEEG->GetName(extNew[NTrialNew])) + UString(" - ") + UString(GrEEG->GetName(injNew[NTrialNew]));
        NTrialNew++;
    }
    *Ntrial = NTrialNew;
    delete[] pairs; delete[] El; delete[] iref; delete[] inj; delete[] ext; delete[] BadTrial;

    UMapFile M(GrEEG,NTrialNew, "OpposingInject");
    M.SetMapLabels(MapLab);
    Rmat = *RmatNew;
    Rmat.Transpose();
    M.SetData(Rmat.GetMatrixArray());
    M.WriteFile(MapDir+UFileName("EIT_Opp.map"),"uV");
    delete[] MapLab;
    if(*Ntrial<=0)
    {
        CI.AddToLog("ERROR: ConvertOpposing(). No opposing pairs found: Ntrial = %d\n", *Ntrial);
        return U_ERROR;
    }
    return U_OK;
}

 