#ifndef EITSUBJECTS_H
#define EITSUBJECTS_H

#define NSUBJECT   9
#define NINJECT    8
#define NEXTRACT   1

const char* LabelInject [NINJECT ] = {"Fpz","F7" ,"F8" ,"T8" ,"P7" ,"P8" ,"Oz","T7"};  // Set of possible injection electrodes
const char* LabelExtract[NEXTRACT] = {"Cz"};                                           // Set of possible extraction electrodes (1 if 1 switch box is used)

const char* LabelRef               = "Fz";

#define NOPPAIR 4
const char* LabelPAIR [NOPPAIR][2] = {{"Fpz","Oz"},{"T8" ,"T7"}, {"F7" ,"P8"} ,{"P7" ,"F8"}};  // Opposing pairs


const char* Subjects[NSUBJECT] = {  "M02","M03","M04","M05","M06","M07","M08", "M09","M10"};
const char* EEGFile [NSUBJECT] = {  "M02_20150216_1203.cnt","M03_20150218_1322.cnt",\
                                    "M04_20150217_1039.cnt","M05_20150216_1441.cnt",\
                                    "M06_20150216_1027.cnt","M07_20150217_1501.cnt",\
                                    "M08_20150218_1535.cnt","M09_20150217_1731.cnt",\
                                    "M10_20150213_1445.cnt"};
const char* ElcFile [NSUBJECT] = {  "M02_4D-EEG_pilot_Juhani_2-16-2015_12-20_PM.elc",\
                                    "M03_4D-EEG_pilot_Juhani_2-18-2015_2-00_PM.elc",\
                                    "M04_4D-EEG_pilot_Juhani_2-17-2015_11-19_AM.elc",\
                                    "M05_4D-EEG_pilot_Juhani_2-16-2015_3-05_PM.elc",\
                                    "M06_4D-EEG_pilot_Juhani_2-16-2015_10-11_AM.elc",\
                                    "M07_4D-EEG_pilot_Juhani_2-17-2015_2-53_PM.elc",\
                                    "M08_4D-EEG_pilot_Juhani_2-18-2015_4-19_PM.elc",\
                                    "M09_4D-EEG_pilot_Juhani_2-17-2015_6-01_PM.elc",\
                                    "M10_4D-EEG_pilot_Juhani_2-13-2015_3-17_PM.elc"};

enum ElecType
{
    U_ELECTYPE_VOLT,
    U_ELECTYPE_REF,
    U_ELECTYPE_INJ,
    U_ELECTYPE_EXT,
    U_ELECTYPE_BAD,
    U_ELECTYPE_NELEC
};
const char* ETName[]     = {"Volt", "Ref", "Inj", "Ext", "BAD"};

const char* ResistorName = "EIT.txt";
const char* ConfigName   = "EIT_Config.txt";


#endif ///EITSUBJECTS_H
