/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     Preprocess EIT data.                                                       */
/*     Compute voltages at active electrodes ("EIT.txt").                         */
/*     Detect inject channels and BAD channels ("EIT_Config.txt").                */
/*                                                                                */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
Update history
 Who    When       What
 Jdm    30-05-18   creation
 Jdm    10-06-18   Test minimum electrode distance
 Jdm    14-06-18   Made command line version
 Jdm    18-07-18   Added corration and Gog/BAD information to MapFile
 JdM    29-08-18   Truncate MapFile output values
 JdM    06-09-18   Bug Fix. Computing correlations for .map file: do not skip channels when normalizing ADC channel
 */



#include<string.h>


#include "../EIT_Subjects.h"

#include "../SetUpMEEGDataEpochs.h"
#include "../../MEEGDataEpochs.h"
#include "../../MarkerArray.h"
#include "../../Grid.h"
#include "../../MapFile.h"


#define VERSION "1.06"
#define AUTHOR  "Dr. JC de Munck, VUmc dept. PMT, Amsterdam"


enum
{
    OP_FILIN=USetUpMEEGDataEpochs::NOPTIONS, OP_KEEPLOG,
    OP_EXTSET, OP_INJSET, OP_FORCEINEXT, OP_REFCHAN, OP_ADCIN, OP_MAXRESIST, OP_INJCORR, OP_INJTHRESH, OP_MINELCDIST, 
    NOPTIONS
};




/* Default values general part: */
static double       Fmin              =  1.;
static double       Fmax              = 40.;
static const char*  MarkerSwitch      = "SwitchMulti";
static const char*  LabelRef          = "";
static double       TimeStart         = 2.; // s
static double       TimeStop          = 8.; // s


const double ADCtouA                  = 0.01;      // 100 Ohm

/* Default values specific EIT part: */
static const char*  ADCinject            = "HRdistA";
static double       MaxResistorThreshold = 400;       // Used to detect "BAD" channels
static double       CorrelationThrehold  = 0.75;      // Used to detect "BAD" channels
static double       InjectionThreshold   = 0.0001;    // Used to detect "zero" injection channels
static double       MinElectDistance     = 1.0;       // Minimally required electrode distance for non-duplicated electrode digtization
static bool         ForceInjExt          = false;

static double Rmax = 0.;
static double MinMax(double x) {return MAX(MIN(x,Rmax),-Rmax);}
static double Trunc(double x)  {if(fabs(x)<=1.) return x; return 0.;}

static const char*   Help  [NOPTIONS];
static UOption       Option[NOPTIONS];
static USetUpMEEGDataEpochs SetEp;
static UMEEGDataEpochs DatEpo;
static UString GetProperties(UString Comment);


int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads and pre-processes an EEG data files that contains EIT data.\n"
        "EEG electrode positions are checked and EEG signals are correlated to the injected current signal (one of the ADC channels). \n"
        "Consistency is chequed, outliers are detected and voltages are converted to impedances. Results are stored in text files \n"
        "(EIT.txt and EIT_EIT_Config.txt) for later analysis and computation of skull conductivity.\n\n";

    SetEp = USetUpMEEGDataEpochs(Help, Option);
    Option[USetUpMEEGDataEpochs::OP_FBANDP ].SetDefaultDubValRange(Fmin, Fmax);
    Option[USetUpMEEGDataEpochs::OP_TRIALS ].SetDisabled();
    Option[USetUpMEEGDataEpochs::OP_SAMPLE ].SetDisabled();
    Option[USetUpMEEGDataEpochs::OP_MNAME  ].SetDefaultString("Switch");
    Option[USetUpMEEGDataEpochs::OP_MOFFSET].SetDefaultDubValRange(int(TimeStart*1024.), int(TimeStop*1024.));
    Option[USetUpMEEGDataEpochs::OP_RSEFART].SetDisabled();
    Option[USetUpMEEGDataEpochs::OP_SVD    ].SetDisabled();
    Option[USetUpMEEGDataEpochs::OP_MEGRREF].SetDisabled();
    Option[USetUpMEEGDataEpochs::OP_EEGRREF].SetDisabled();


    Help[OP_FILIN       ] = "Input data file with EEG data generated by current injections.";
    Help[OP_KEEPLOG     ] = "If this option is set, the old .log file is not deleted but new results are appended on existing .log file";
    Help[OP_EXTSET      ] = "Set of electrode labels, separated by comma's, where current was injected (switch box 1). This could be a single electrode in case no switch box was used. These names are used to help the detection of the configuration used in each trial.";
    Help[OP_INJSET      ] = "Set of electrode labels, separated by comma's, where current was extracted (switch box 2). This could be a single electrode in case no switch box was used. These names are used to help the detection of the configuration used in each trial.";
    Help[OP_FORCEINEXT  ] = "By default, injection/extraction electrodes are automatically detected from the data using a voltage treshold. However, this test may fail if a fixed electrode is used and the corresponding channels is not connected to ground. If you set this option, for fixed injection/extraction electrodes (not connected through switch box) the amplitude test is skipped and the given electrode is forced to be injectio, cq extraction electrode.";
    Help[OP_REFCHAN     ] = "Label of reference electrode for volage measurements. Data is converted to this refeerence after detecting injection and extraction electrodes.";
    Help[OP_ADCIN       ] = "Name of the ADC channel that records the injected current pattern.";
    Help[OP_MAXRESIST   ] = "Parameter to detect BAD channels. If the computed resistance (impedance) is larger than the given threshold it is marked as BAD.This test is applied separately for each trial. -1 indicates that this test is skipped.";
    Help[OP_INJCORR     ] = "Parameter to detect BAD channels. If the correlation between injected current and a channel is smaller that the give threshold that channel is marked as BAD.";
    Help[OP_INJTHRESH   ] = "Parameter to detect injection/extraction electrodes. If the amplitude of the (raw) signal is lower than the given threshold and the label fits in the list of possible injections/extractions the electrode is marked as injection/extraction. The parameter should be set such that there is only one extraction and one injection per trial.";
    Help[OP_MINELCDIST  ] = "Parameter to detect duplicated cated electrode positions. If two electrodes are closer than the given threshold, computations stop. For negative values this test is skipped.";

    Option[OP_FILIN     ] = UOption("DataFile"       ,Help[OP_FILIN ],UOption::FILENAME);
    Option[OP_KEEPLOG   ] = UOption("KL", "KeepLog"  ,Help[OP_KEEPLOG]);
    Option[OP_EXTSET    ] = UOption("ExS","Extract"  ,Help[OP_EXTSET],"");
    Option[OP_INJSET    ] = UOption("InS","Inject"   ,Help[OP_INJSET],"");
    Option[OP_FORCEINEXT] = UOption("For","ForceInEx",Help[OP_FORCEINEXT]);
    Option[OP_REFCHAN   ] = UOption("Ref","Reference"  ,Help[OP_REFCHAN],"");

    Option[OP_ADCIN     ] = UOption("ADC","ADCchan"  ,Help[OP_ADCIN], ADCinject);
    Option[OP_MAXRESIST ] = UOption("MxR","MaxResist",Help[OP_MAXRESIST], -1.,1000000., MaxResistorThreshold);
    Option[OP_INJCORR   ] = UOption("MnC","MinCorr"  ,Help[OP_INJCORR], -1.,1., CorrelationThrehold);
    Option[OP_INJTHRESH ] = UOption("NUL","NULLchan" ,Help[OP_INJTHRESH], -1.,1., InjectionThreshold);
    Option[OP_MINELCDIST] = UOption("Dis","ElcDist"  ,Help[OP_MINELCDIST], -1.,100., MinElectDistance);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);
    if(NOT( Option[OP_KEEPLOG].GetBOOL())) {CI.ResetLogFile(); CI.TranslateArgs(Option, NOPTIONS, Intro);}
    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    ADCinject            = Option[OP_ADCIN     ].GetString();
    MaxResistorThreshold = Option[OP_MAXRESIST ].GetDubVal1();
    CorrelationThrehold  = Option[OP_INJCORR   ].GetDubVal1();
    InjectionThreshold   = Option[OP_INJTHRESH ].GetDubVal1();
    MinElectDistance     = Option[OP_MINELCDIST].GetDubVal1();
    ForceInjExt          = Option[OP_FORCEINEXT].GetBOOL();
    Rmax                 = MaxResistorThreshold;

/* Set filename and epochs, and delete old output files*/
    UFileName Fin      = UFileName(Option[OP_FILIN].GetFileName());
    UFileName FoutEIT  = Fin.GetSiblingFileName(ResistorName);
    if(FoutEIT.DoesFileExist()) FoutEIT.RemoveFile();
    FoutEIT.ReplaceBaseName(ConfigName);
    if(FoutEIT.DoesFileExist()) FoutEIT.RemoveFile();

    DatEpo  = UMEEGDataEpochs(Fin);
    if(DatEpo.GetError()!=U_OK || SetEp.ArgumentsToObject(&DatEpo)!=U_OK) 
    {
        CI.AddToLog("ERROR: Setting data file %s .\n", (const char*)Fin);
        CI.PressReturnExit();
    }
    if(SetEp.ApplySettings(&DatEpo)!=U_OK)
    {
        CI.AddToLog("ERROR: Applying settings to file %s .\n", (const char*)Fin);
        CI.PressReturnExit();
    }
    int   ichanADC = DatEpo.GetData()->GetChanAndType(ADCinject, NULL);
    if(ichanADC<0)
    {
        CI.AddToLog("ERROR: ADC channel not found: %s .\n", ADCinject);
        CI.PressReturnExit();
    }
    DataType DTEEG    = U_DAT_UNKNOWN;
             LabelRef = Option[OP_REFCHAN].GetString();
    int      ichanREF = DatEpo.GetData()->GetChanAndType(LabelRef, &DTEEG);
    if(ichanREF<0 || DTEEG!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: Reference channel not found in EEG data: %s .\n", LabelRef);
        CI.PressReturnExit();
    }

    const UGrid* GEEG    = DatEpo.GetData()->GetGridEEG();
    int istest1 =-1, istest2=-1;
    if(MinElectDistance>0 && GEEG->GetMinDistance(&istest1, &istest2)<MinElectDistance)
    {
        UString N1 = istest1<=0 ? UString("Not Found1") : UString(GEEG->GetName(istest1));
        UString N2 = istest2<=0 ? UString("Not Found2") : UString(GEEG->GetName(istest2));
        CI.AddToLog("ERROR: Electrodes (almost) coincide: %s - %s \n", (const char*)N1, (const char*)N2);
        CI.PressReturnExit();
    }
    char** LabelsIn = NULL; int NInjectMAX = 0;
    GetNamesFromString(Option[OP_INJSET].GetString(), 0, &NInjectMAX , &LabelsIn);
    char** LabelsEx = NULL; int NExtractMAX = 0;
    GetNamesFromString(Option[OP_EXTSET].GetString(), 0, &NExtractMAX, &LabelsEx);

    if(NInjectMAX<=0||NExtractMAX<=0)
    {
        if(NInjectMAX <=0) CI.AddToLog("ERROR: No injection labels set: %s \n" , Option[OP_INJSET].GetString());
        if(NExtractMAX<=0) CI.AddToLog("ERROR: No extraction labels set: %s \n", Option[OP_EXTSET].GetString());
        CI.PressReturnExit();
    }
    int      ichanInj    = (ForceInjExt && NInjectMAX ==1) ? DatEpo.GetData()->GetChanAndType(LabelsIn[0], &DTEEG) : -1;
    int      ichanExt    = (ForceInjExt && NExtractMAX==1) ? DatEpo.GetData()->GetChanAndType(LabelsEx[0], &DTEEG) : -1;
    int      Ntrial      = DatEpo.GetNEpoch();
    int      NEEG        = DatEpo.GetData()->GetNeeg();
    UMapFile MapRes(GEEG, 3, Ntrial, "Resistor");
    UString* TrialLabels = new UString[Ntrial];

    int*    NBad         = new int[Ntrial];
    bool*   Inj          = new bool[Ntrial*NEEG];
    bool*   Ext          = new bool[Ntrial*NEEG];
    bool*   BAD          = new bool[Ntrial*NEEG]; 
    double* Resist       = new double[Ntrial*NEEG];

    for(int iep=0; iep<Ntrial     ; iep++) NBad[iep]  = 0;
    for(int ki=0 ; ki <Ntrial*NEEG; ki++ ) Inj[ki]    = Ext[ki] = BAD[ki] = false;
    for(int ki=0 ; ki <Ntrial*NEEG; ki++ ) Resist[ki] = 0.;

/* Take raw data to detect injection/extraction and BAD channels. */
    DatEpo.SetRereference(U_REF_RAW, U_REF_RAW);
    for(int iep=0; iep<Ntrial; iep++)
    {
        UMultiChan* MCE = DatEpo.GetFilteredMultiChan(iep, U_DAT_EEG);
        UMultiChan* MCA = DatEpo.GetFilteredMultiChan(iep, U_DAT_ADC, ichanADC); 

        UMatrix    W    = UMatrix(U_WIN_HAMMING, MCE->GetNcol()); W.ApplySquareRoot();
        UMatrix    MCEW = (*MCE)* W;
        UMatrix    MCAW = (*MCA)*(W*ADCtouA);
        delete MCE; delete MCA;

        UMatrix IP       = GetMatMul(MCEW, false, MCAW, true)/MCAW.GetFrobNorm2();  // Ohm

        int     Ninject  = 0; 
        int     Nextract = 0;
        bool*   Inull    = IP.GetSubThresholdElements(InjectionThreshold, true);

        for(int i=0,ki=iep*NEEG; i<NEEG; i++,ki++)
        {
            if(i==ichanInj) {Ninject++  ; Inj[ki] =true; continue;}
            if(i==ichanExt) {Nextract++ ; Ext[ki] =true; continue;}

            if(NOT(Inull[i]))
            {
                if(fabs(IP[i])>MaxResistorThreshold) {BAD[ki] = true; NBad[iep]++;}
                continue;
            }
            if(i==ichanREF) continue;

            const char* Name = GEEG->GetName(i);
            for(int kk=0;kk<NInjectMAX ; kk++) if(!stricmp(Name,LabelsIn[kk])) {Ninject++ ; Inj[ki] =true; break;}
            for(int kk=0;kk<NExtractMAX; kk++) if(!stricmp(Name,LabelsEx[kk])) {Nextract++; Ext[ki] =true; break;}

            if(NOT(Inj[ki])&&NOT(Ext[ki])) {BAD[ki] = true; NBad[iep]++;}  // Low signal channels that are no reference, and have no injection/extraction labels
        }
        if(Ninject !=1)  CI.AddToLog("WARNING: Data file %s, trial %d, %d injection electrodes detected \n" , (const char*)Fin, iep, Ninject);
        if(Nextract!=1)  CI.AddToLog("WARNING: Data file %s, trial %d, %d extraction electrodes detected \n", (const char*)Fin, iep, Nextract);

        CI.AddToLog("Switch %d \tInj/Ext: \t", iep);
        for(int i=0; i<NEEG; i++) if(Inj[iep*NEEG+i]) {TrialLabels[iep] += UString(GEEG->GetName(i)); break;} 
        TrialLabels[iep] += UString(" - ");
        for(int i=0; i<NEEG; i++) if(Ext[iep*NEEG+i]) {TrialLabels[iep] += UString(GEEG->GetName(i)); break;}
        CI.AddToLog("%s \n", TrialLabels[iep]);

        delete[] Inull;
    }

    for(int iep=0; iep<Ntrial; iep++)
    {
        UMultiChan* MCE = DatEpo.GetFilteredMultiChan(iep, U_DAT_EEG);        
        UMultiChan* MCA = DatEpo.GetFilteredMultiChan(iep, U_DAT_ADC, ichanADC); 

        UMatrix    W    = UMatrix(U_WIN_HAMMING, MCE->GetNcol()); W.ApplySquareRoot();
        UMatrix    MCEW = (*MCE)* W;
        UMatrix    MCAW = (*MCA)*(W*ADCtouA);
        delete MCE; delete MCA;

        int row1 = -1; for(int i=0; i<NEEG; i++) if(Inj[iep*NEEG+i]) {row1=i; break;} // RE-reference to given channel
        int row2 = -1; for(int i=0; i<NEEG; i++) if(Ext[iep*NEEG+i]) {row2=i; break;}
        MCEW.SubstractRow(ichanREF, row1, row2);

        UMatrix IP    = GetMatMul(MCEW, false, MCAW, true)/MCAW.GetFrobNorm2();  // Ohm

        MCAW.NormalizeRows();
        MCEW.NormalizeRows(ichanREF, row1, row2);
        UMatrix CC      = GetMatMul(MCEW, false, MCAW, true);

        for(int i=0, ik=iep*NEEG; i<NEEG; i++, ik++)
        {
            if(i==ichanREF || Inj[ik] || Ext[ik] ) continue;
            Resist[ik] = IP[i];
            if(BAD[ik]) continue;
            if(fabs(CC[i])>CorrelationThrehold) continue;
            BAD[ik] = true; NBad[iep]++;
        }
        CI.AddToLog("BAD:  ");
        for(int i=0,ik=iep*NEEG; i<NEEG; i++,ik++) if(BAD[ik]) CI.AddToLog("\t%s ", GEEG->GetName(i));
        CI.AddToLog("\n");

/* Adapt values for .map file output*/
        for(int i=0, ik=iep*NEEG; i<NEEG; i++, ik++) if(i==ichanREF || Inj[ik] || Ext[ik]) {IP.SetElement(i,0,0.); CC.SetElement(i,0,0.);}
        IP.ApplyFunction(MinMax);
        CC.ApplyFunction(Trunc );
        UMatrix GoodBAD = CC;
        for(int i=0, ik=iep*NEEG; i<NEEG; i++, ik++) GoodBAD.SetElement(i,0, BAD[ik] ? -1 : ( (i==ichanREF || Inj[ik] || Ext[ik]) ? 0. : 1));

        UMatrix ResCor(DNULL, NEEG, 3);
        ResCor.SetBlock(0,0, IP);
        ResCor.SetBlock(0,1, CC);
        ResCor.SetBlock(0,2, GoodBAD);
        MapRes.SetData(ResCor.GetMatrixArray(), iep);
    }

    UString Properties  = GetProperties("// ") + UString("// \n") + SetEp.GetProperties("//   ");
    FoutEIT             = Fin.GetSiblingFileName(ResistorName);
    FILE* fpEIT         = fopen(FoutEIT, "wt");
    fprintf(fpEIT,"%s\n",CI.GetProperties("// "));
    fprintf(fpEIT,"%s\n",(const char*)Properties);
    fprintf(fpEIT,"// \n");
    fprintf(fpEIT, "Ohm\t");
    for(int i=0; i<GEEG->GetNpoints(); i++) fprintf(fpEIT, "%s\t", GEEG->GetName(i)); 
    fprintf(fpEIT, "\n");

    for(int iep=0; iep<Ntrial; iep++)
    {
        fprintf(fpEIT, "%d\t",iep);
        for(int i=0,ik=iep*NEEG; i<NEEG; i++, ik++) fprintf(fpEIT, "%16.12f \t", Resist[ik]); 
        fprintf(fpEIT, "\n");
    }
    fclose(fpEIT);

    FoutEIT.ReplaceBaseName(ConfigName);
    FILE* fpCon = fopen(FoutEIT, "wt");
    fprintf(fpCon,"%s\n",CI.GetProperties("// "));
    fprintf(fpCon,"%s\n",(const char*)Properties);
    fprintf(fpCon,"// \n");
    fprintf(fpCon, "Trial\t");
    for(int i=0; i<GEEG->GetNpoints(); i++) fprintf(fpCon, "%s\t", GEEG->GetName(i)); 
    fprintf(fpCon, "\n");

    for(int iep=0; iep<Ntrial; iep++)
    {
        fprintf(fpCon, "%d\t",iep);
        for(int i=0, ki=iep*NEEG; i<NEEG; i++,ki++) 
            fprintf(fpCon, "%s \t", i==ichanREF ? ETName[U_ELECTYPE_REF]:(Inj[ki]?ETName[U_ELECTYPE_INJ]:(Ext[ki]?ETName[U_ELECTYPE_EXT]:(BAD[ki]?ETName[U_ELECTYPE_BAD]:ETName[U_ELECTYPE_VOLT])))); 
        fprintf(fpCon, "\n");
    }

    fprintf(fpCon, "//  Trial \tNBAD \tInject/Extract \n");
    for(int iep=0; iep<Ntrial; iep++)
        fprintf(fpCon, "// %d \t%d \t%s \n",iep, NBad[iep], (const char*)TrialLabels[iep]);
    fclose(fpCon);

    delete[] NBad;
    delete[] Inj;
    delete[] Ext;
    delete[] BAD;

    for(int k=0; k<NInjectMAX ; k++) delete[] LabelsIn[k]; delete[] LabelsIn;
    for(int k=0; k<NExtractMAX; k++) delete[] LabelsEx[k]; delete[] LabelsEx;

    UString MapLab[3] = {UString("Impedance [Ohm]"), UString("Correlation [a.u.]"), UString("Good/BAD")};
    MapRes.SetMapLabels(MapLab);
    MapRes.SetTrialLabels(TrialLabels);

    UFileName    FoutMap = FoutEIT; FoutMap.SetExtension("map");
    MapRes.WriteFile(FoutMap,"Ohm");

    delete[] TrialLabels;
    return 0;
}

UString GetProperties(UString Comment)
{
    UString Properties =  UString();

    Fmin           =  Option[USetUpMEEGDataEpochs::OP_FBANDP ].GetDubVal1();
    Fmax           =  Option[USetUpMEEGDataEpochs::OP_FBANDP ].GetDubVal2();
    MarkerSwitch   =  SetEp.GetTriggerName();
    if(Option[USetUpMEEGDataEpochs::OP_MWIDTH ].GetValueSet())
    {
        TimeStart  = -Option[USetUpMEEGDataEpochs::OP_MWIDTH].GetValue()*DatEpo.GetSampleTime_s(); 
        TimeStop   =  Option[USetUpMEEGDataEpochs::OP_MWIDTH].GetValue()*DatEpo.GetSampleTime_s();
    }
    else
    {
        TimeStart  =  Option[USetUpMEEGDataEpochs::OP_MOFFSET].GetValue1()*DatEpo.GetSampleTime_s(); 
        TimeStop   =  Option[USetUpMEEGDataEpochs::OP_MOFFSET].GetValue2()*DatEpo.GetSampleTime_s();
    }
    const char* InjSet = Option[OP_INJSET].GetString();
    const char* ExtSet = Option[OP_EXTSET].GetString();

    Properties += UString(Fmin                    ,"Fmin                = %f \n"); 
    Properties += UString(Fmax                    ,"Fmax                = %f \n"); 
    Properties += UString(MarkerSwitch            ,"SwitchMarker        = %s \n"); 
    Properties += UString(TimeStart               ,"TimeStart           = %f \n"); 
    Properties += UString(TimeStop                ,"TimeStop            = %f \n"); 
    Properties += UString(LabelRef                ,"RefLabel            = %s \n"); 
    Properties += UString(InjSet                  ,"InjectionSet        = %s \n"); 
    Properties += UString(ExtSet                  ,"ExtractionSet       = %s \n"); 
    Properties += UString(BoolAsText(ForceInjExt) ,"ForceInjExt         = %s \n");
    Properties += UString(ADCinject               ,"ADCLabel            = %s \n"); 
    Properties += UString(InjectionThreshold      ,"ADCconversion       = %f \n"); 
    Properties += UString(CorrelationThrehold     ,"CorrelationThrehold = %f \n"); 
    Properties += UString(MinElectDistance        ,"MinElectDistance    = %f \n"); 

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);
    return Properties;
}


 