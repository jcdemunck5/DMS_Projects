#ifndef EITSUBJECTS_H
#define EITSUBJECTS_H

enum ElecType
{
    U_ELECTYPE_VOLT,
    U_ELECTYPE_REF,
    U_ELECTYPE_INJ,
    U_ELECTYPE_EXT,
    U_ELECTYPE_BAD,
    U_ELECTYPE_NELEC
};
const char* ETName[]     = {"Volt", "Ref", "Inj", "Ext", "BAD"};

const char* ResistorName = "EIT.txt";
const char* ConfigName   = "EIT_Config.txt";


#endif ///EITSUBJECTS_H
