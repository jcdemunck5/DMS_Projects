/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to computes connectivity matrix for all in-mask voxels,           */
/*     given a 4D fMRI data set.                                                 */
/*      (mask is determined as the nonzero voxel locations in volume 0)          */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  AMW    11-11-10   creation
  JdM    29-05-12   General update, use command line arguments mechanism
  JdM    11-06-12   GetMotionRegressors(): Avoid nested loops over k.
*/ 


#include <string.h>

#include "../../Option.h"
#include "../../ScanList.h"
#include "../../Projector.h"
#include "../../ConnectivityScans.h"
#include "../../FieldGraph.h"
#include "../../AnalyzeLine.h"
#include "../../Projector.h"
#include "../../Directory.h"


#define VERSION "1.01"
#define AUTHOR  "AM Wink/JC de Munck"

enum
{
    OP_METHOD,
    OP_MOTPARS,
    OP_FILIN,OP_FILOUT,
    NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];

UFieldGraph** GetMotionRegressors(const char* FileName, int* NMotReg);


int main(int Nargs, char** Args) 
{
    char* Intro  = "This programme computes reads in a 4D fMRI scan and computes the voxelwise\n"
                   "eigvalue centrality (ECM). To facilitate a fast computation of that quantity,\n"
                   "the connectivity is here defined as the distance between the normalized time \n"
                   "series. The output (eigenvector) is exported in the same fileformat as the input.\n"
                   "The theory underlying this program is described in:\n"
                   "Wink AM, De Munck JC, Van der Werf Y, Van den Heuvel O and Barkhof F, (2012), \n"
                   "Fast eigenvector centrality mapping of voxelwise connectivity matrices in functional \n"
                   "MRI: implementation, validation and interpretation. Brain Connectivity, under review. \n"
                   "Please refer to that paper if the use of this program is a substantial part of \n"
                   "your work.\n";

    
    Help[OP_FILIN   ] = "File name of the dynamic (fMRI) data to be analyzed.";
    Help[OP_FILOUT  ] = "Basis filename of the output nifti file containing the eigenvecor corresponding to the largest eigenvalue. If this filename does not contain a path, it will be placed in the same directory as the input file.";
    Help[OP_MOTPARS ] = "You can give the file name containing the motion parameters. If this option is set, motion regressors will be projected out before compting ECM.";
    Help[OP_METHOD  ] = "Choose the algithm by which ECM is to be computed: 1=implicit (fast iterative power iteration), 2=explicit (first computing full connectivity matrix).";

    Option[OP_FILIN   ] = UOption("FileIn" ,Help[OP_FILIN ],UOption::FILENAME);
    Option[OP_FILOUT  ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_MOTPARS ] = UOption("Mot", "MotionFile", Help[OP_MOTPARS], "prefiltered_func_data_mcf.par");
    Option[OP_METHOD  ] = UOption("A","Algorithm" ,Help[OP_METHOD]  ,1,2,1);


    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    MatrixExplicit implexpl=U_MAT_IMPLICIT;
    if(Option[OP_METHOD  ].GetValue()==2) implexpl=U_MAT_EXPLICIT;

    UFileName     Fin     = UFileName(Option[OP_FILIN].GetFileName());
    if(Fin.DoesFileExist()==false)
    {
        CI.AddToLog("ERROR: File does not exist: %s .\n", (const char*)Fin);
        CI.PressReturnExit(true);
        return -1;
    }

/* Create outputfile*/
    UFileName Fout(Option[OP_FILOUT].GetFileName());
    if(Fout.IsPureFile()) Fout =  Fin.GetSiblingFileName(Option[OP_FILOUT].GetFileName());
    Fout.SetExtension("nii");
    if(Fout.GetDirectory().GetStatus()!=UDirectory::U_EXIST)
    {
        CI.AddToLog("ERROR: Directory of output file does not exist: %s .\n", (const char*)Fout);
        CI.PressReturnExit(true);
        return -1;
    }
    
/* Create motion regressors if requested */
    int           NMotReg = 0;
    UFieldGraph** FG_Mot  = NULL;
    if(Option[OP_MOTPARS ].GetValueSet()==true)
    {
        UFileName FMotPar = Fin.GetSiblingFileName(Option[OP_MOTPARS].GetString());
        FG_Mot = GetMotionRegressors((const char*)FMotPar, &NMotReg);
        if(FG_Mot==NULL || NMotReg<=0)
        {
            CI.AddToLog("ERROR: Getting motion regressors: %s .\n", Option[OP_MOTPARS].GetString());
            CI.PressReturnExit(true);
        }
    }


/* Load the filename into a UScanlist */
    UScanList SL(Fin);
    if(SL.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: File not recognized as dynamic scan: %s .\n", (const char*)Fin);
        CI.PressReturnExit(true);
        return -1;
    }

/* convert (back) to short int
   set mean time series to 0 and normalise variance ("false" would not normalise variance), and scale by factor 1024
   convert (back) to float and divide by factor 1024
 */ 
    if(FG_Mot==NULL)
    {
        SL.ConvertData(UField::U_SHORT);
        SL.RemoveAverage(true,1024.);
        SL.ConvertData(UField::U_FLOAT,1./1024.);
    }
    else
    {
        UProjector Proj((const UField**)FG_Mot, NMotReg, NULL, "Nuisance");
        if(Proj.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Creating Nuisance projector.\n");
            CI.PressReturnExit(true);
            return -1;
        }
        Proj.SetComplement(true);
        for(int k=0; k<NMotReg; k++) delete FG_Mot[k]; delete[] FG_Mot;
        
        if(SL.Project(&Proj)!=U_OK)
        {
            CI.AddToLog("ERROR: Applying Nuisance projector.\n");
            CI.PressReturnExit(true);
            return -1;
        }
        SL.NormalizeTimeSeries();
        SL.ConvertData(UField::U_FLOAT);
    }

/* initialise connectivity object based on selected similarity measure and implicit/explicit matrix computation */
    CI.TimeReset("Connectivity");
    bool           Normalise   = true;
    int            ComponentNo = 0;
    SimilarityType SimT        = U_SIM_CORR;
    UConnectivityScans CS(SL, ComponentNo, Normalise, SimT, implexpl);
    CI.TimeFlag("Connectivity");

/* obtain mapping based on centrality type (degree/eigenvector/...) */
    UScan* Eig = CS.GetMapping();

/* write result to file */
    Eig->SaveAs(U_FIL_NIFTI, Fout, "", "",false);
    delete Eig;

    return 0;
}

UFieldGraph** GetMotionRegressors(const char* FileName, int* NMotReg)
{
    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: GetMotionRegressors(). File does not exist: %s \n", FileName);
        return NULL;
    }
    if(NMotReg==NULL)
    {
        CI.AddToLog("ERROR: GetMotionRegressors(). Invalid NULL argument. \n");
        return NULL;
    }
    *NMotReg = 0;
    FILE* fp = fopen(FileName, "rt");
    
    char line[300];
    if(GetLine(line, sizeof(line), fp)==NULL)
    {
        fclose(fp);
        CI.AddToLog("ERROR: GetMotionRegressors(). Getting fist line from motion file. \n");
        return NULL;
    }
    UAnalyzeLine AA(line);
    int NReg = 1 + AA.GetNCollumn();
    if(NReg<=1 || NReg>=25)
    {
        fclose(fp);
        CI.AddToLog("ERROR: GetMotionRegressors(). Invalid number of collumns (%d) in first line: %s. \n", NReg, line);
        return NULL;
    }
    int NPoints = GetNLines(fp);
    if(NPoints<=0 || NPoints>=10000)
    {
        fclose(fp);
        CI.AddToLog("ERROR: GetMotionRegressors(). Invalid number of rows (%d) in file: %s. \n", NPoints, FileName);
        return NULL;
    }
    UFieldGraph** FGarr = new UFieldGraph*[NReg];
    if(FGarr)
    {
        for(int k=0; k<NReg; k++) FGarr[k] = NULL;
        for(int k=0; k<NReg; k++)
        {
            FGarr[k] = new UFieldGraph(float(0), float(NPoints-1), NPoints, UField::U_DOUBLE);
            if(FGarr[k]==NULL||FGarr[k]->GetError()!=U_OK)
            {
                for(int kk=0; kk<NReg; kk++) delete FGarr[kk];
                delete[] FGarr; FGarr = NULL;
                break;
            }
            FGarr[k]->SetDataDouble(0);
            if(k==0)
            {
                UString Name(k,"Const");
                FGarr[k]->SetLabel(Name);
            }
            else
            {
                UString Name(k,"Col_%d");
                FGarr[k]->SetLabel(Name);
            }
        }
    }
    if(FGarr==NULL)
    {
        fclose(fp);
        CI.AddToLog("ERROR: GetMotionRegressors(). Creation of empty regressors (NPoints=%d). \n", NPoints);
        return NULL;
    }
    rewind(fp);
    for(int n=0; n<NPoints; n++)
    {
        if(GetLine(line, sizeof(line), fp)==NULL)
        {
            for(int k=0; k<NReg; k++) delete FGarr[k]; delete[] FGarr;
            fclose(fp);
            CI.AddToLog("ERROR: GetMotionRegressors(). Getting line %d from motion file. \n", n);
            return NULL;
        }
        UAnalyzeLine AA(line);
        for(int k=0; k<NReg; k++) 
        {
            if(k==0)
            {
                FGarr[k]->GetDdata()[n] = 1.;
            }
            else
            {
                double Val = AA.GetNextDouble(-12345.);
                if(Val==-12345.)
                {
                    for(int kk=0; kk<NReg; kk++) delete FGarr[kk]; delete[] FGarr;
                    fclose(fp);
                    CI.AddToLog("ERROR: GetMotionRegressors(). Getting value from line %d, collum %d from motion file. \n", n, k);
                    return NULL;
                }
                FGarr[k]->GetDdata()[n] = Val;
            }
        }
    }
    fclose(fp);
    *NMotReg = NReg;
    return FGarr;
}
