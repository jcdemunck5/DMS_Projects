/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to localize magnetic coils.                                       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    16-11-98   creation
  JdM    17-12-98   Print version and author
  JdM    11-02-99   Added time range-option
  JdM    31-03-99   Added the option to export intermediate results in the CTF helmemet coordinate system
  Jdm    20-04-99   Export Introduction text to .bat-file
  Jdm    06-05-99   Define epochs using markers
  JdM    07-08-99   Use global UConsoleInterface()-object CI
  JdM    05-10-99   Use U_BESTOFALL as initial dipole search guess
  JdM    14-12-99   Added option to set the number of grid points for the initial guess
  JdM    21-12-99   Added option to set the size of the global search region
  JdM    22-12-99   Extend option added on 21-12-99.
  JdM    19-05-00   Added option to detect small distances between fourth coil measurements
  JdM    24-05-00   Added option to export cost functions
  JdM    25-05-00   Added option to set the front-back coordinate shift (in addition to the z-coordinate).
  JdM    21-09-00   Use new default for tip-length (=-2.77)
  JdM    17-08-01   Added re-referencing of MEG data
  JdM    09-07-02   Added new global search region
  JdM    09-07-02   Added the options to force good or bad channels
  JdM    17-09-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    29-07-13   Complete update source code to make it compile after 10 years of general updates
*/
#include <stdlib.h>

#include "../../Option.h"
#include "../../CTFDataSet.h"
#include "FitCoils.h"


#define VERSION "5.5" 
#define AUTHOR  "Dr. JC de Munck, VUmc Dept. FMT, Amsterdam"


int main(int Nargs, char **Args)
{       
    char* Intro  = "This programme localizes electrode positions, measured with the four-coil\n"
                   "method. With this method, three coils are fixed onto the head at the nasion,\n"
                   "left and right pre-aucular points. The electrodes are pointed to with the\n" 
                   "fourth coil, which has a tip with known lenght. Each coil is energized with\n"
                   "a sinusoidal current, which is stored in the ADC-channels of the CTF-data.\n"
                   "This program localizes the four coils, corrects for the tip-length and stores\n"
                   "the results in text-file. \n\n"
                   "The theory underlying this program is described in:\n"
                   "J.C. De Munck, J.P.A. Verbunt, D. Van 't Ent and B.W. van Dijk, The Use of an\n"
                   "MEG device as 3-D digitizer and motion detection system, Phys. Med. Biol, 46:2041-2052 (2001)\n"
                   "Please refer to that paper if the use of this program is a substantial part of your work.\n";

 
    enum{OP_DIRIN,OP_FILOUT,OP_GOODCH,OP_BADCH,OP_MEGRREF,OP_ADFORWM,OP_TRIALS,OP_MNAME,OP_TRANGE,OP_CCALIB,OP_MINMET,OP_STRTGR,OP_STRTTP,OP_STARTZX,OP_TIPLEN,OP_BADTR,OP_COORD,OP_NEAR,OP_EXGTAB,NOPTIONS};
    
    char* Help[NOPTIONS];
    
    Help[OP_DIRIN  ] = "DataSet name of the MEG data to be analyzed. The .res4-file must contain the four ADC-channels with the current time functions fed to the four coils.";
    Help[OP_FILOUT ] = "Basis filename of the output xyz file. If no drive or path is given, the file is created in the DataSet directory of the ADC data.";
    Help[OP_GOODCH ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH  ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";    
    Help[OP_MEGRREF] = "You can transform the MEG data to another reference: -1: Keep the data as is, 0: Make MEG data unbalanced, 1: Compute MEG data w.r.t. first gradient, 2: Compute MEG data w.r.t. second gradient, 3: Compute MEG data w.r.t. third gradient .";    
    Help[OP_ADFORWM] = "By default, the forward model does not account for the references. By setting this option, you can adapt the forward model such as to account for second or third order gradiometer effects. ";
    Help[OP_TRIALS ] = "Trial Range: Only the data between first and last given trial is processed. -1 refers to last trial.";
    Help[OP_MNAME  ] = "Epochs derived from each marker with the given name, during the time given with RNG. If no marker name is given, but only 'Nam', all markers are used. Note1: The -Nam option cannot be given simultaneously with the -Tr option. Note2: The Epochs resulting from -Nam and -RGN may overlap and they may also cross trial boundaries. No testing is done.";
    Help[OP_TRANGE ] = "Give the time range in ms. Time samples outside this range are ignored in all trials (or markers). In combination with the -Tr option, negative a value refers to the last sample of a trial. In combination with marker names, negative values denote samples located before the marker.";
    Help[OP_CCALIB ] = "Coil callibration type: 0=all coils different, 1=force same callibration in different trials.";
    Help[OP_MINMET ] = "Minimization method: 0=Simplex, 1=Simplex Boost, 2=Powell, 3=Marquardt, 4=Marquardt New Version";
    Help[OP_STRTGR ] = "If the starting values are determined by global search, you can set here the number of grid points.";
    Help[OP_STRTTP ] = "Set global search region type. 0: The global search space consists of a sphere with a radius of 25 cm., centered about (0.,0.,-20) (Nasion-Ear coordinates). 1: The global seartch region is a sphere with a radius of 10 cm. and is centered at (0.,0.,0.), 2: The global search region consists of 3 small spheres (5. cm. radius), at approximately the Nasion, Left and Right Ear, 3: Three rectangular blocks which are chosen such that all coil positions found historically are enclosed. 4: Four small spheres of radius 2 cm. centered at the corners of a large square (meant for coil callibration purposes). ";
    Help[OP_STARTZX] = "Set global search region Z-coordinate (= MINUS distance below the dewar) and X-coordinate (Front=PLUS, Back=MINUS) in cm.";
    Help[OP_TIPLEN ] = "Give the tip-lenght in cm.";
    Help[OP_BADTR  ] = "Give the threshold used to detect Bad Channels in %%. The lower this threshold, the more channelks are marked as BAD.";
    Help[OP_COORD  ] = "If this option is set, the full results of all coils are set in coordinates w.r.t. the CTF helmet (instead of the CTF nasion/ear system). The final results of the fourth coil are always given with respect to the nasion-ear system, as it is computed with this programme.";
    Help[OP_NEAR   ] = "You can detect whether there are fourth points in different trials that have, withing a given range threshold, idential coordinates. This option is e.g. useful when the trial when the trials represent electrode coordinates and you want to detect whether some electrodes are touched twice. Here you can give the range in cm. If you give a negative value, or you not give the option at all, the range test is skipped.";
    Help[OP_EXGTAB ] = "You can export the (scaled) minimum function for each fitted coil in the form of a ConQuest Patient Tree scan. The name of the patient tree is 'GlobMin.Patient' and is a sub-directory of the working directory. With the ConQuest Viewer you can (online) monitor the behavior of each fitted coil. Setting this option will slow dowm the computations a little, but may provide insight into your data.";
 
    UOption Option[NOPTIONS];
    Option[OP_DIRIN  ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_FILOUT ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_GOODCH ] = UOption("Gch","GoodCh",Help[OP_GOODCH],NULL);
    Option[OP_BADCH  ] = UOption("Bch","BadCh",Help[OP_BADCH],NULL);
    Option[OP_MEGRREF] = UOption("Mrr","MEGreref",Help[OP_MEGRREF],-1,3,-1);
    Option[OP_ADFORWM] = UOption("AFM","AdForwMod",Help[OP_ADFORWM]);
    Option[OP_TRIALS ] = UOption("Tr" ,"Trials",Help[OP_TRIALS],-1,1000,0,-1);
    Option[OP_MNAME  ] = UOption("Nam","Marker Name",Help[OP_MNAME],NULL);    
    Option[OP_TRANGE ] = UOption("RNG","Range ms.",Help[OP_TRANGE],-1.e6,1.e6,0.,-1.);   
    Option[OP_CCALIB ] = UOption("cc","Coil Calib.",Help[OP_CCALIB],0,1,0);
    Option[OP_MINMET ] = UOption("m","Min. Meth.",Help[OP_MINMET],0,4,4);
    Option[OP_STRTGR ] = UOption("bNp","Ngrid Pnts.",Help[OP_STRTGR],2,1000000,1200);
    Option[OP_STRTTP ] = UOption("bGS","GlobalS.Reg.",Help[OP_STRTTP],0,4,0);
    Option[OP_STARTZX] = UOption("bZX","ZX-start",Help[OP_STARTZX],-100.,50.,-20.,0.);
    Option[OP_TIPLEN ] = UOption("tl","Tip length",Help[OP_TIPLEN],-5.,5.,-2.77);
    Option[OP_BADTR  ] = UOption("BAD","Bad Thresh.",Help[OP_BADTR],0.,100.,10.);
    Option[OP_COORD  ] = UOption("HLM","HelmetCoord",Help[OP_COORD]);
    Option[OP_NEAR   ] = UOption("Dis","DetectDist",Help[OP_NEAR],-1.,4.,-1.);
    Option[OP_EXGTAB ] = UOption("EMT","ExportMinTb",Help[OP_EXGTAB]);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

/* Translate options into useful variables*/ 
    const char* DSName  = Option[OP_DIRIN ].GetFileName();

    UCostminimize costPoint;
    costPoint.SetNormalize(false);
    costPoint.SetTolerance(1.e-15);
    costPoint.SetStartOffset(3.);
    costPoint.SetLogFile();
    switch(Option[OP_MINMET].GetValue())
    {
    case 0:  costPoint.SetOptMethod(UCostminimize::U_SIMPLEX);       break;
    case 1:  costPoint.SetOptMethod(UCostminimize::U_SIMPLEX_BOOST); break;
    case 2:  costPoint.SetOptMethod(UCostminimize::U_POWELL);        break;
    case 3:  costPoint.SetOptMethod(UCostminimize::U_MARQUARDT);     break;
    case 4:  costPoint.SetOptMethod(UCostminimize::U_MARQUARDT2);    break;
    default: costPoint.SetOptMethod(UCostminimize::U_NOMETHOD);      break;
    }

    const char* GoodChan = NULL; if(Option[OP_GOODCH].GetValueSet()==true) GoodChan = Option[OP_GOODCH].GetString();
    const char* BadChan  = NULL; if(Option[OP_BADCH].GetValueSet()==true)  BadChan  = Option[OP_BADCH].GetString();

    UFitCoils Fit(Option[OP_DIRIN ].GetFileName(), GoodChan, BadChan, costPoint);
    if(Fit.GetError()!=U_OK)
    {
        CI.AddToLog("Errors in File names\n");
        CI.PressReturnExit();
    }

/* Determine the epochs on which the dipoles are fitted */     
    if(Option[OP_TRIALS].GetValueSet()==true && 
       Option[OP_MNAME ].GetValueSet()==true)
    {
        CI.AddToLog("Error: Epochs can only be set by either trial numbers or marker names\n");
        CI.PressReturnExit();
    }
    if(Option[OP_MNAME ].GetValueSet()==true)
    {
        double STime     = 1000.*Fit.GetSampleTime_s();
        int    starttime = int(Option[OP_TRANGE].GetDubVal1()/STime);
        int    endtime   = int(Option[OP_TRANGE].GetDubVal2()/STime);
        const char* Name = Option[OP_MNAME ].GetString();
        Fit.SetEpochsMarker(starttime, endtime, Name);        
    }
    else
    {
        double STime      = 1000.*Fit.GetSampleTime_s();
        int    starttrial = Option[OP_TRIALS].GetValue1();
        int    endtrial   = Option[OP_TRIALS].GetValue2();
        int    starttime  = int(Option[OP_TRANGE].GetDubVal1()/STime);
        int    endtime    = int(Option[OP_TRANGE].GetDubVal2()/STime);
        Fit.SetEpochs(starttime, endtime);
        Fit.ExcludeTrials(starttrial, endtrial);
    }
    
    if(Fit.GetError()!=U_OK)
    {
        CI.AddToLog("Errors in setting Epoch\n");
        CI.PressReturnExit();
    }

    ReReferenceType MEGreref = U_REF_RAW;
    switch(Option[OP_MEGRREF ].GetValue())
    {
    case -1: MEGreref = U_REF_RAW;         break;
    case  0: MEGreref = U_REF_UNBALANCED;  break;
    case  1: MEGreref = U_REF_FIRST;       break;
    case  2: MEGreref = U_REF_SECOND;      break;
    case  3: MEGreref = U_REF_THIRD;       break;
    default: CI.AddToLog("ERROR: Invalid MEG re-referencing parameter: %d \n", Option[OP_MEGRREF ].GetValue()); 
        CI.PressReturnExit();
    }
    ReReferenceType EEGreref = U_REF_AVERAGE;
    if(Fit.SetRereference(MEGreref, EEGreref)!=U_OK)
    {
        CI.AddToLog("Errors in setting the re-referencing parameters \n");
        CI.PressReturnExit();
    }

/* Translate a few parameters and start dipole fitting. */
    double BadThreshold = Option[OP_BADTR].GetDubVal1();
    CalibType  CoilCallibration = U_VARYING;
    if(Option[OP_CCALIB].GetValue()==1) CoilCallibration = U_ITERATIVE;

    UStartDipole::RegionType GlobalSRegion = UStartDipole::U_LARGESPHERE;
    switch(Option[OP_STRTTP].GetValue())
    {
    case 0: GlobalSRegion = UStartDipole::U_LARGESPHERE;      break;
    case 1: GlobalSRegion = UStartDipole::U_SPHERE;           break;
    case 2: GlobalSRegion = UStartDipole::U_THREESPHERES;     break;
    case 3: GlobalSRegion = UStartDipole::U_THREEBLOCKS;      break;
    case 4: GlobalSRegion = UStartDipole::U_FOURSMALLSPHERES; break;
    default:
        CI.AddToLog("ERROR: Illegal parameter Global serarch Region parameter: %d\n", Option[OP_STRTTP].GetValue());
        CI.PressReturnExit();
    }
    int  Npts = Option[OP_STRTGR].GetValue();

    UVector3 Start(Option[OP_STARTZX].GetDubVal2(),0.,Option[OP_STARTZX].GetDubVal1());
    bool     ExportGlobTable = Option[OP_EXGTAB].GetBOOL();
    bool     AdFordMod       = Option[OP_ADFORWM].GetBOOL();
    if(Fit.ComputeCoils(Start, AdFordMod, UStartDipole::U_BESTOFALL, BadThreshold, CoilCallibration, NULL, Npts, GlobalSRegion, ExportGlobTable)==U_ERROR)
    {
        CI.AddToLog("Errors in Dipole Fitting\n");
        CI.PressReturnExit();
    }

/*Export results */
    double       TipLength      = Option[OP_TIPLEN].GetDubVal1();
    const char*  OutputFileName = Option[OP_FILOUT].GetFileName();
    bool         HelmetCoords   = Option[OP_COORD ].GetBOOL();
    double       DetectDistance = Option[OP_NEAR  ].GetDubVal1();

    if(Fit.ExportResults(OutputFileName, TipLength, HelmetCoords, DetectDistance)==U_ERROR)
    {
        CI.AddToLog("Errors in exporting results\n");
        CI.PressReturnExit();
    }
    CI.AddToLog("Programme finished succesfully...\n");
}   