/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to fit (moving) dipoles onto a CTF data set.                      */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history 
    
  Who    When       What
  GdV    20-09-98   creation
  JdM    23-09-98   merge with previous versions.
  JdM    01-10-98   separated include-files
  Jdm    13-11-98   compatibility with HP CC Compiler; Use UOption()-object to read 
                    command-line options.
  Jdm    23-11-98   Implemented markers with half-width
Jdm/AdJ  23-12-98   Added option to store output in one file.
  JdM    16-03-99   Translate the program argument in enums within main() i.s.o. UFitDipoles()
  JdM    04-04-99   Added the option to exclude trials from the analysis
  JdM    08-04-99   Added the option to filter the data, before fitting dipoles
  JdM    18-04-99   Added the option export a selected channel
  Jdm    20-04-99   Export Introduction text to .bat-file
  JdM    07-08-99   Use global UConsoleInterface()-object CI
  JdM    29-08-99   Add option to choose cost function.
  JdM    11-10-99   Add option to set the maximum number of iterations
  JdM    16-10-99   Allow the use of GLS estimates using theoretically computed covariance matrix
  JdM    19-10-99   Allow pre-processing of the epochs (offset and trend-removal)
  JdM    15-12-99   Add option to skip data point when the initial guess error is
                    larger than some threshold.
  JdM    18-01-00   Add option to switch between (pure) MEG and EEG data.
  JdM    31-01-00   Add option to set the stopping criterion for the non-linear optimizations
  JdM    07-02-00   Add option to set the output format
  JdM    14-02-00   Set default stopping parameter to 10e-3
  JdM    24-05-00   Added option to export cost functions
  JdM    05-06-00   Added option to set a penalty factor, in order to force the dipoles in the domain
  JdM    28-06-00   Added option to read experimentally determined spatial covariance from  file (with default file name).
  JdM    28-08-00   Added option to determined inititial guess by interpolation of global search estimate
  JdM    04-09-00   Added option to choose between deleting or appending to existing files
  JdM    15-11-00   Bug fix in the treatment of out of range values of band pass filter parameters
  JdM    17-12-00   Added options -mo and EXO (similar to NewSpectrum). Use static objects to process groups of related options
  JdM    01-02-01   Added options -Atr to set eigenvalue threshold of the linear component system matrix
  JdM    30-03-01   Added option -Ave to force averaged (filtered) epochs.
  JdM    14-09-01   Added option to sub-sample the epochs
  JdM    05-07-01   Allow pre-processing without other filter types
  JdM    14-07-01   Allow dipole fitting based on simultaneous MEG and EEG
  JdM    17-08-01   Added re-referencing of MEG data
  JdM    24-08-01   Added the option to correct forward MEG model for gradient order of data
  JdM    09-10-01   Add the option to remove SEF artifact before filtering
  JdM    08-11-01   Add the option to export dipole parameters in many digits
  JdM    15-02-02   Add the option to compute common spatio-temporal component over epochs
 GdV/JdM 25-03-02   static enum not allowed in HP Unix
  JdM    08-07-02   Allow removal of powerline noise
  JdM    11-09-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    17-09-02   Allow multiple overriding good and bad channels (again, since 11-11-01 ???)
  JdM    09-10-02   Add option to remove complete epochs based on overlapping with markers
  JdM    22-08-03   By default, use new dipole strength units (see Emfield.cpp). Add option for backward compatibility.
  JdM    31-10-03   Replaced -AFM option by -DFM option, with the opposite behavior.
  JdM    27-09-05   Set default FFT-dir as "C:\\TempQt"
  JdM    21-02-06   UPreProType are now defined globally in stead of enums of ULinearFilter
  JdM    05-03-08   MAJOR update. Adapted sources to new directory structure (PMT_Projects iso MCAProjects_6)
  JdM    12-06-15   MAJOR update. Renumber versions: from 15.01 to 1.01
                    Split off part for general UMEEGDataEpoch settings, using newly created class USetUpMEEGDataEpochs
  JdM    30-09-16   Allow theoretical random dipole model in combination with EEG (in addition to MEG and MEG/EEG)
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  */

#include "../SetUpMEEGDataEpochs.h"

#include "../../MEEGDataEpochs.h"
#include "../../Option.h"
#include "../../FitDipoles.h"

#define VERSION "1.04 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUmc, Amsterdam"

enum
{
    OP_DIRIN=USetUpMEEGDataEpochs::NOPTIONS,OP_HMFILE,OP_FILOUT,
    OP_OUTAPP,OP_OUTFORM,OP_MANYDIG,OP_OLDUNIT,OP_EXPCHAN,
    OP_DATTYP,OP_DIPTYP,OP_CONFLIM,
    OP_COST,OP_DEFORWM,OP_AMATTHR,OP_START,OP_STRTGR,OP_STRTTRE,OP_POWTRE,
    OP_STOP,OP_NITER,OP_MINMET,OP_PENALTY,
    NOPTIONS
};

static const char*   Help  [NOPTIONS];
static       UOption Option[NOPTIONS];
static USetUpMEEGDataEpochs SetEp;

class USetCost
{
public:
    USetCost();
    ErrorType ArgumentsToObject(UCostminimize* Cost);
};
static USetCost SetCost;


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme computes the optimal dipole sources corresponding to a CTF\n"
                         "data set. On each selected time sample, a single, symmetric or semi-symmetric\n"
                         "dipole is fitted. The time samples can be selected by either specifying the\n" 
                         "range, or they can be taken from the marker-file.\n"
                         "The output is stored in a text file (with extension .txt), which can be\n"
                         "imported in programmes such as EXCEL.\n\n"
                         "The theory underlying this program is described in:\n"
                         "J.C. de Munck, A. de Jongh, B.W. Van Dijk The localization of spontaneous \n"
                         "brain activity: An efficient way to analyze large data sets, IEEE Trans \n"
                         "Biomed Eng, BME-48(11): 1221-1228 (2001). \n"
                         "and\n"
                         "A. de Jongh, J.C. de Munck, J.C. Baayen, E.J. Jonkman, R.M. Heethaar, B.W. van \n"
                         "Dijk, The localization of spontaneous brain activity: first results in patients\n"
                         "with cerebral tumors, Clin. Neurophysiol, 112: 378-385 (2001).\n"
                         "Please refer to that paper if the use of this program is a substantial part of \n"
                         "your work.\n";

        
    Help[OP_DIRIN    ] = "DataSet name of the MEG data to be analyzed.";
    Help[OP_HMFILE   ] = "The name of the file containing the volume conductor model. If no path is given, it is assumed that the file is located in the CTF dataset. If this file does not exist, by default a sphere is taken that fits as well as possible to the MEG helmet. Also, that file will be created and it will contain the default settings.";
    Help[OP_FILOUT   ] = "Basis filename of the output text file. Dipoles corresponding to subsequent samples are stored in one file. Files are numbered automatically and the extension .txt is added.";
    Help[OP_OUTAPP   ] = "When the given output file exists, you can choose between 0: do not compute, nor export results, 1: delete existing file, overwrite contents with new results, 2: append new results to existing file.";
    Help[OP_OUTFORM  ] = "With this option you can specify the format of the output text file. You can store all dipoles in one file or create separate (numbered) files for each epoch. If you do so, the comments between epochs are skipped. You can omit or include dipoles with super threshold errors. You can export the time in sample number or in milli-seconds (in both cases the time is with respect to the first sample in the file and pre-trigger time is ignored). Set the following number to: 0=one file, export all dipoles, time in samples; 1=one file, export all dipoles, time in ms; 2=one file, export low error dipoles only, time in samples; 3=one file, export low error dipoles only, time in ms; 4=separate files, export all dipoles, time in samples; 5=separate files, export all dipoles, time in ms; 6=separate files, export low error dipoles only, time in samples; 7=separate files, export low error dipoles only, time in ms.";
    Help[OP_MANYDIG  ] = "With this option you can export the dipole parameters in more than the normal number of digits. This option is important in special applications where you use the results of FitDipoles as intermediate results.";
    Help[OP_OLDUNIT  ] = "By default this program assumes distances in cm, conductitivities in Ohm-1*cm-1 and dipole strengths in nAm*cm. To force dipole strengths to the old (undefined) units, you can set this option for backward comaptibility. ";
    Help[OP_EXPCHAN  ] = "You can select one channel (by giving its name) which is printed as a column in the output file.";    
    Help[OP_DATTYP   ] = "Choose the data type that you wish to analyze: 1= pure MEG, 2= pure EEG 3= MEG and EEG (when present in data file);";
    Help[OP_DIPTYP   ] = "Dipole Type: 0=Single dipole, 1= Symmetric dipole, 2=Semi-symmetric dipole.";
    Help[OP_CONFLIM  ] = "You can compute and export the 95% confidence intervals for all dipole position parameters. The computation is hased on the assumption that the (unscaled) covariance matrix of the background noise is given. The noise level (scaling of the covariance matrix) is computed using the residuals. When the option is not set, confidence limits will not be computed.";
    
    Option[OP_DIRIN  ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_HMFILE ] = UOption("HeadModel",Help[OP_HMFILE],UOption::FILENAME);
    Option[OP_FILOUT ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_OUTAPP ] = UOption("App","Append"     ,Help[OP_OUTAPP ],0,2,1);
    Option[OP_OUTFORM] = UOption("OF" ,"OutputForm" ,Help[OP_OUTFORM],0,7,1);
    Option[OP_MANYDIG] = UOption("Mdg","ManyDigits" ,Help[OP_MANYDIG]);
    Option[OP_OLDUNIT] = UOption("OU","OldUnits"    ,Help[OP_OLDUNIT]);
    Option[OP_EXPCHAN] = UOption("Chn","Channel"    ,Help[OP_EXPCHAN],NULL);
    Option[OP_DATTYP ] = UOption("DT" ,"DataType"   ,Help[OP_DATTYP ],1,3,1);
    Option[OP_DIPTYP ] = UOption("d"  ,"DipType"    ,Help[OP_DIPTYP ],0,2,0);
    Option[OP_CONFLIM] = UOption("Con","95p ConfLim",Help[OP_CONFLIM]);
    
    Help[OP_COST     ] = "Set cost function: 0=absolute value, 1=sum of squares, 2=GLS with theoretical covariance function, 3=Spatial covariance read from experimentally determined file (CovarXX.cov, present in CTF data set). Note 1: it is not recommended to minimize absolute values using Marquardt-like methods. Note 2: You can not apply semi-symmetric dipole models in combination with abolute value of differences (yet).";
    Help[OP_DEFORWM  ] = "By default, the forward model accounts for the references. By setting this option, you can switch off this default, and ignore the gradients. This option is meant for backwards compatibility of the output dipole file. ";
    Help[OP_AMATTHR  ] = "When the (semi-)symmetric dipole model is chosen, the system matrix used to compute the dipole components may become instable when the dipoles approach the mid-saggital plane. In that case two (almost) opposite dipoles may be estimated, with an unrealistically large amplitude. To avoid matrix instability, you can set an eigen-value truncation parameter. When this parameter is negative, the time samples at which the instability problem appears are marked with an artificially large residual error, so that these dipoles can be easily skipped when the dipoles are plotted.";
    Help[OP_START    ] = "Starting Values:  0=Start at origin, 1=First dipole at origin, subsequent dipoles take results from previous fit, 2=Use min and max in the data, 3=Global search, 4=Global search or previous, take best of both. (With this option about 10 to 30 % of time is saved by computing the previous cost only when the initial guess and power threshold test are passed) 5=Best of all.";
    Help[OP_STRTGR   ] = "If the starting values are determined by global search, you can set here the number of grid points. For symmetric dipoles, half this number is used. For other starting conditions, this parameter is ignored.";
    Help[OP_STRTTRE  ] = "If the optimal starting value yields a residual error which is large, subsequent iterations will probably not reduce the error below a satisfying low level and will therefore be needless. In these cases you can skip the non-linear iterations by setting an Starting Value Error Threshold, in %%. Only iff the error obtained with the optimal starting values are below this threshold, non-linear search will follow. A negative value (or omitting the option at all) denotes: skip the threshold test, and perform non-linear search on all selected time samples.";
    Help[OP_POWTRE   ] = "To speed up the search for good fitting dipoles, you can skip data samples with a low power. Experience learned that most good fitting dipoles coincide with high data powers. Here you give the power threshold as a factor, which is multiplied with the median of the data power of the selected time samples. When the option is omitted at all (or set to -1.), dipoles will be fitted to all selected data samples.";
        
    Option[OP_COST   ] = UOption("C"  ,"Cost type",Help[OP_COST],0,3,1);
    Option[OP_DEFORWM] = UOption("DFM","DefForwMod",Help[OP_DEFORWM]);   
    Option[OP_AMATTHR] = UOption("Atr","MatrixTrunc",Help[OP_AMATTHR],-1.,1.,.001);
    Option[OP_START  ] = UOption("b"  ,"Start Val.",Help[OP_START],0,5,5);    
    Option[OP_STRTGR ] = UOption("bNp","Ngrid Pnts.",Help[OP_STRTGR],1,1000000,600);
    Option[OP_STRTTRE] = UOption("bmx","MaxErrTr",Help[OP_STRTTRE],-1.,100.,30.);
    Option[OP_POWTRE ] = UOption("PTF","PowerThresh",Help[OP_POWTRE],-1.,100.,-1.);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    for(int k=0; k<USetUpMEEGDataEpochs::NOPTIONS; k++)   Option[k] = SetEp.Option[k];
    CI.TranslateArgs(Option, NOPTIONS, Intro);
    for(int k=0; k<USetUpMEEGDataEpochs::NOPTIONS; k++)   SetEp.Option[k] = Option[k];

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

#ifdef WIN32 
    FFTW.SetWisdomDir("C:\\TempQt");
#else
    FFTW.SetWisdomDir("~/TempQt");
#endif

    UDipole::DipoleType DType;    
    switch(Option[OP_DIPTYP].GetValue())
    {
    case 0:  DType = UDipole::Current;      break;
    case 1:  DType = UDipole::Symmetric;    break;
    case 2:  DType = UDipole::SymmetricPos; break;
    default:
        CI.AddToLog("ERROR: Illegal dipole type.\n");
        CI.PressReturnExit();
    }

    UCostminimize cost;
    if(SetCost.ArgumentsToObject(&cost)!=U_OK)
        CI.PressReturnExit();

    UFitDipoles::OutputFormat OF;
    switch(Option[OP_OUTFORM].GetValue())
    {
    case 0: OF = UFitDipoles::U_OF_ALL_SAMP;  break;
    case 1: OF = UFitDipoles::U_OF_ALL_MS;    break;
    case 2: OF = UFitDipoles::U_OF_SKIP_SAMP; break;
    case 3: OF = UFitDipoles::U_OF_SKIP_MS;   break;
    case 4: OF = UFitDipoles::U_SF_ALL_SAMP;  break;
    case 5: OF = UFitDipoles::U_SF_ALL_MS;    break;
    case 6: OF = UFitDipoles::U_SF_SKIP_SAMP; break;
    case 7: OF = UFitDipoles::U_SF_SKIP_MS;   break;
    default: 
        CI.AddToLog("ERROR: Illegal output format.\n");
        CI.PressReturnExit();
    }
    bool ManyDigits = Option[OP_MANYDIG].GetBOOL();

    UFitDipoles::OutputType OT;
    switch(Option[OP_OUTAPP ].GetValue())
    {
    case 0: OT = UFitDipoles::U_SKIP;   break;
    case 1: OT = UFitDipoles::U_DELETE; break;
    case 2: OT = UFitDipoles::U_APPEND; break;
    default: 
        CI.AddToLog("ERROR: Illegal output type.\n");
        CI.PressReturnExit();
    }

/* Set the epochs, based on the command line options set*/
/* Set filename and epochs*/
    UFileName Fin = UFileName(Option[OP_DIRIN].GetFileName());

    UMEEGDataEpochs DatEpo(Fin);
    if(DatEpo.GetError()!=U_OK || SetEp.ArgumentsToObject(&DatEpo)!=U_OK) 
    {
        CI.AddToLog("ERROR: Setting data file %s .\n", (const char*)Fin);
        CI.PressReturnExit();
    }
    SetEp.ApplySettings(&DatEpo);

    UFitDipoles Fit(DatEpo, Option[OP_FILOUT].GetFileName(), cost, OF, OT, DType);

    const char* HeadModelFile = Option[OP_HMFILE].GetFileName();
    const char* ChanName      = Option[OP_EXPCHAN].GetString();
    int Npts = Option[OP_STRTGR].GetValue();

    UStartDipole::StartType SType;
    switch(Option[OP_START ].GetValue())
    {
    case 0:  SType = UStartDipole::U_ALLFIRST;        break;
    case 1:  SType = UStartDipole::U_PREVIOUS;        break;
    case 2:  SType = UStartDipole::U_MINMAX;          break;
    case 3:  SType = UStartDipole::U_GLOBAL;          break;
    case 4:  SType = UStartDipole::U_GLOBAL_OR_PREV;  break;
    case 5:  SType = UStartDipole::U_BESTOFALL;       break;
    default: 
        CI.AddToLog("ERROR: Illegal starting value.\n");
        CI.PressReturnExit();
    }

    UFitDipoles::CostType CT = UFitDipoles::U_SQUARE;
    switch(Option[OP_COST].GetValue())
    {
    case 0:
        if(Option[OP_DIPTYP].GetValue()==2)
        {
            CI.AddToLog("ERROR: You cannot combine semi-symmetric dipoles with abs() cost function.\n");
            CI.PressReturnExit();
        }
        if(Option[OP_DATTYP].GetValue()==2 || Option[OP_DATTYP].GetValue()==3)
        {
            CI.AddToLog("ERROR: You cannot combine EEG data with abs() cost function.\n");
            CI.PressReturnExit();
        }
        CT = UFitDipoles::U_ABS;  
        break;

    case 1:
        CT = UFitDipoles::U_SQUARE;  
        break;

    case 2:
        CT = UFitDipoles::U_THECOV; 
        break;

    case 3:
        CT = UFitDipoles::U_FILECOV;  
        break;
    }

    double MaxStartError = -1;
    if(Option[OP_STRTTRE].GetValueSet()==true) MaxStartError = Option[OP_STRTTRE].GetDubVal1();

    UFitDipoles::FitDataType FDT = UFitDipoles::U_MEG_ONLY;
    switch(Option[OP_DATTYP ].GetValue())
    {
    case 1: FDT = UFitDipoles::U_MEG_ONLY;    break;
    case 2: FDT = UFitDipoles::U_EEG_ONLY;    break;
    case 3: FDT = UFitDipoles::U_MEG_AND_EEG; break;
    default:
        CI.AddToLog("ERROR: Wrong data type option.\n");
        CI.PressReturnExit();
    }

    double MinPowFac  = Option[OP_POWTRE ].GetDubVal1();
    if(MinPowFac>0 && CT != UFitDipoles::U_SQUARE)
    {
        CI.AddToLog("ERROR: Setting a data threshold cannot (yet) be combined with other cost function that the sum of squares.\n");
        CI.PressReturnExit();
    }
    bool     ConfidenceLimits = Option[OP_CONFLIM].GetBOOL();
    bool     DefFordMod       = Option[OP_DEFORWM].GetBOOL();
    bool     UseOldUnits      = Option[OP_OLDUNIT].GetBOOL();
    double   AmatThreshold    = Option[OP_AMATTHR].GetDubVal1();
    if(Fit.FitMovingDipoles(UFileName(HeadModelFile), ChanName, SType, Npts, CT, NOT(DefFordMod), UseOldUnits, MaxStartError, FDT, MinPowFac, ConfidenceLimits, AmatThreshold, ManyDigits)!=U_OK)
    {
        CI.AddToLog("Error in dipole fitting\n");
        CI.PressReturnExit();        
    }
    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}


USetCost::USetCost()
{

/* General parameters*/
    Help[OP_STOP    ]  = "The non-linear minimization procedure will stop when the maximum of all partitial derivatives are smaller the the value given here. The smaler this parameter, the better minimum you get, but the more iterations are needed.";
    Help[OP_NITER   ]  = "The maximum number of iterations used to fit each dipole. The non-linear optimization will stop after the given number of iterations, even when the stopping criterion is not satisfied. By setting this number to zero, you can scan the dipole file for good-fitting dipoles at the starting positions.";    
    Help[OP_MINMET  ]  = "Minimization method: 0=Simplex, 1=Simplex Boost, 2=Powell, 3=Marquardt, 4=Marquardt Version 2";
    Help[OP_PENALTY ]  = "When during the iterations the dipole moves outside the region on interest (typically the innermost compartment of the volume conductor model), the formulas used in the forward problem become invalid. You can deal with this problem by increasing the cost function artificially with a penalty function, which increases with the distance to the valid domain. Here you can set the penalty function factor. For a zero value, no penalty is applied. The use of a penalty function is recommended for EEG and/or realistic models.";

    Option[OP_STOP   ] = UOption("Stp","StoppingPar",Help[OP_STOP],0.,1.,1.e-3);    
    Option[OP_NITER  ] = UOption("Nit","Num.Iter.",Help[OP_NITER],0,10000,1000);  
    Option[OP_MINMET ] = UOption("m"  ,"Min. Meth.",Help[OP_MINMET],0,4,4);
    Option[OP_PENALTY] = UOption("Pen","Penalty",Help[OP_PENALTY],0.,10.,0.);
}

ErrorType USetCost::ArgumentsToObject(UCostminimize* Cost)
{
    Cost->SetMaxiter(Option[OP_NITER].GetValue());
    if(Option[OP_COST].GetValue()!=0) 
        Cost->SetTolerance( Option[OP_STOP].GetDubVal1());
    else
        Cost->SetTolerance(-Option[OP_STOP].GetDubVal1());
    Cost->SetStartOffset(4);
    Cost->SetLogFile();

    switch(Option[OP_MINMET].GetValue())
    {
    case 0:  Cost->SetOptMethod(UCostminimize::U_SIMPLEX);       break;
    case 1:  Cost->SetOptMethod(UCostminimize::U_SIMPLEX_BOOST); break;
    case 2:  Cost->SetOptMethod(UCostminimize::U_POWELL);        break;
    case 3:  Cost->SetOptMethod(UCostminimize::U_MARQUARDT);     break;
    case 4:  Cost->SetOptMethod(UCostminimize::U_MARQUARDT2);    break;
    default: 
        CI.AddToLog("ERROR: Illegal minimization method: %d\n",Option[OP_MINMET].GetValue());
        return U_ERROR;
    }
    Cost->SetPenaltyFactor(Option[OP_PENALTY].GetDubVal1());
    return U_OK;
}
