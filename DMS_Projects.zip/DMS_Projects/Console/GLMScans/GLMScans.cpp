/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to perform GLM analysis on scans in .Patient tree.                */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    06-08-13   creation
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../String.h"
#include "../../PatTree.h"
#include "../../ConsoleInterFace.h"
#include "../../Filename.h"
#include "../../Directory.h"
#include "../../ScanList.h"
#include "../../FieldGraph.h"
#include "../../Gaussian.h"
#include "../../Analyzeline.h"
#include "../../GLMArray.h"


#if defined(WIN32) && defined(_DEBUG)
     #define _CRTDBG_MAP_ALLOC
     #include <stdlib.h>
     #include <crtdbg.h>
     #define DEBUG_NEW new( _NORMAL_BLOCK, __FILE__, __LINE__ )
     #define new DEBUG_NEW
#endif


#define VERSION "1.02"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"


#define MAX_REG_REFERENCE    200
#define MAX_REG_CONFOUNDER   200

UFieldGraph* RegRef[MAX_REG_REFERENCE ];
UFieldGraph* RegCon[MAX_REG_CONFOUNDER];
UFieldGraph* Selector                   = NULL;


static ErrorType ReadInputFile(UFileName FileIn, UPatTree* PatDir, UScanList** pSL, UFileName* pBaseName, int* NRegRef, int* NRegCon);


enum{OP_FILIN, OP_THRESH, NOPTIONS};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];



int main(int Nargs, char **Args)
{       
#if defined(_MSC_VER) && defined(_DEBUG)
    _CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif



    const char* Intro  = "This programme performs a GLM analysis on a 4D data set present in the .Patient tree data format.\n"
                         "Regressors and input scan are speficied in a format given below:\n"
                         "ScanGLM1.0                                      // Required file type identifier\n"
                         " //\n"
                         " //\n"
                         "PATIENTDIR     = \"C:My Data\\MrA.Patient\"          // Use quotes to include spaces in input file names\n"
                         "SCAN_4D        = fMRI_Smooth                         // Subdir containing the 4D scan in xdr format. .scan4D-Extension can be omitted. No spaces allowed \n"
                         "CORRSCAN       = AlphaBand                           // Basis Subdir name containing the output correlation. .scan-Extension can be omitted. No spaces allowed \n"
                         "REGDIR         = \"C:My Data\\MrA.Regressors\"       // Directory containing the regressors in .xdr or in .1D format \n"
                         "SELECTOR       = GoodScans.xdr                       // Optional indicator ''regressor'' in which bad scans are marked with 0. These scans are omitted from the GLM analysis \n"
                         "NREFERENCE     = 10                                  // Number of regressors of interest \n"
                         "NCONFOUNDER    = 20                                  // Number of regressors of no interest (these are projected out) \n"
                         "REFERENCES     = {                                   // '{'-sign is required\n"
                         "                    Ref1.xdr                         // File names containing the regressors of interest. No spaces allowed.\n"
                         "                    Ref2.xdr                         // The number of file names should match the given number of references.\n"
                         "                    Ref3.1D \n"
                         "                    ...\n"
                         "                    Ref10.1D \n"
                         "                 }                                   // Closing '}'-sign is required\n"
                         "CONFOUNDERS    = {                                   // '{'-sign is required\n"
                         "                    Rot_x.xdr                        // File names containing the regressors of no-interest. No spaces allowed.\n"
                         "                    Rot_y.xdr                        // The number of file names should match the given number of confounders.\n"
                         "                    Rot_z.xdr \n"
                         "                    ...\n"
                         "                    HBI_S6.xdr \n"
                         "                 }                                   // Closing '}'-sign is required\n"
                         "\n";

    Help[OP_FILIN    ] = "You must give the file name containg all regressors and the .Patient tree input/output scans.";
    Help[OP_THRESH   ] = "You can give an fMRI threshold for gross segmentation of the brain. Only voxels in the first scan that exceed this threshold are analyzed.";

    Option[OP_FILIN    ] = UOption("ScanGLM.txt",Help[OP_FILIN], UOption::FILENAME);
    Option[OP_THRESH   ] = UOption("Thr","Threshold",Help[OP_THRESH], 0., 32000., 100.);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);
    CI.ResetLogFile();

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    for(int k=0; k<MAX_REG_REFERENCE ; k++)RegRef[k] = NULL;
    for(int k=0; k<MAX_REG_CONFOUNDER; k++)RegCon[k] = NULL;
    Selector = NULL;

    UPatTree  PatTree;
    UFileName BaseName;
    UScanList *SL    = NULL;
    int       NRef   = NULL;
    int       NCon   = NULL;
    UFileName FileIn(Option[OP_FILIN].GetFileName());

    if(ReadInputFile(FileIn, &PatTree, &SL, &BaseName, &NRef, &NCon)!=U_OK)
    {
        CI.AddToLog("ERROR: Invalid input file. \n");
        CI.PressReturnExit(true);
    }


    UGLMArray GLMA(RegRef, NRef, RegCon, NCon, Selector, NULL);
    if(GLMA.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating GLM-object. \n");
        CI.PressReturnExit(true);
    }

    UScan*     ScanCorrVec  = NULL; 
    UScanList* ScanArrAlfa  = NULL;
    UScan*     ScanVarData  = NULL; 
    bool       ComputeSD    = true;
    bool       IsIndpvalues = true;
    double     NoiseThresh  = Option[OP_THRESH].GetDubVal1();

    if(SL->Correlate4D(&GLMA, &ScanCorrVec, &ScanArrAlfa, &ScanVarData, ComputeSD, IsIndpvalues, NoiseThresh)!=U_OK)
    {
        CI.AddToLog("ERROR: Computing GLM analysis. \n");
        CI.PressReturnExit(true);
    }

    UEuler MatchToWld(SL->GetOrigFileName().GetSiblingFileName("match_scan_to_wld.xdr"));
    UEuler      ToWld(SL->GetOrigFileName().GetSiblingFileName("scan_to_wld.xdr"));

    UFileName  CorFil = BaseName; CorFil.SetExtension(".scan"); CorFil.InsertBeforeExtension("_CorpFDR");
    UDirectory CorDir = PatTree.Child(CorFil.GetBaseName()); 
    if(CorDir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating output directory for correlation scan (%s). \n", (const char*)CorDir);
    }
    else
    {
        ScanCorrVec->WriteXDR(UDirectory(CorDir) + UFileName("scan.xdr"), NULL, NULL);
        MatchToWld  .WriteXDR(UDirectory(CorDir) + UFileName("match_scan_to_wld.xdr"));
        ToWld       .WriteXDR(UDirectory(CorDir) + UFileName("scan_to_wld.xdr"));
    }

    UFileName  VarFil = BaseName; VarFil.SetExtension(".scan"); VarFil.InsertBeforeExtension("_Var");
    UDirectory VarDir = PatTree.Child(VarFil.GetBaseName()); 
    if(VarDir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating output directory for variance scan (%s). \n", (const char*)VarDir);
    }
    else
    {
        ScanVarData->WriteXDR(UDirectory(VarDir) + UFileName("scan.xdr"), NULL, NULL);
        MatchToWld  .WriteXDR(UDirectory(VarDir) + UFileName("match_scan_to_wld.xdr"));
        ToWld       .WriteXDR(UDirectory(VarDir) + UFileName("scan_to_wld.xdr"));
    }

    UFileName  HRFFil = BaseName; HRFFil.SetExtension(".scan4D"); HRFFil.InsertBeforeExtension("_HRF");
    UDirectory HRFDir = PatTree.Child(HRFFil.GetBaseName()); 
    if(HRFDir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating output directory for HRF scan (%s). \n", (const char*)HRFDir);
    }
    else
    {
        ScanArrAlfa->WriteXDR_4D(UDirectory(HRFDir) + UFileName("scan4d.xdr"));
        MatchToWld  .WriteXDR   (UDirectory(HRFDir) + UFileName("match_scan_to_wld.xdr"));
        ToWld       .WriteXDR   (UDirectory(HRFDir) + UFileName("scan_to_wld.xdr"));
    }

    delete ScanCorrVec; 
    delete ScanArrAlfa;
    delete ScanVarData;


    delete SL;
    for(int k=0; k<MAX_REG_REFERENCE ; k++) delete RegRef[k];
    for(int k=0; k<MAX_REG_CONFOUNDER; k++) delete RegCon[k];
    delete Selector;

    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}

ErrorType ReadInputFile(UFileName FileIn, UPatTree* PatDir, UScanList** pSL, UFileName* pBaseName, int* NRegRef, int* NRegCon)
{
    if(PatDir==NULL || pSL==NULL || pBaseName==NULL || NRegRef==NULL || NRegCon==NULL)
    {
        CI.AddToLog("ERROR: ReadInputFile(). Invalid NULL pointer(s).\n");
        return U_ERROR;
    }
    *PatDir         = UPatTree();
    *pSL            = NULL;
    *pBaseName      = UFileName();
    *NRegRef        = 0;
    *NRegCon        = 0;

    for(int k=0; k<MAX_REG_REFERENCE ; k++) {delete RegRef[k]; RegRef[k]=NULL;}
    for(int k=0; k<MAX_REG_CONFOUNDER; k++) {delete RegCon[k]; RegCon[k]=NULL;}
    delete Selector; Selector = NULL;

    FILE*  fp       = fopen(FileIn, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: ReadInputFile(). Opening: %s \n", (const char*)FileIn);
        return U_ERROR;
    }
    int NLines = GetNLines(fp);
    if(NLines<=0)
    {
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). File %s empty.\n", (const char*)FileIn);
        return U_ERROR;
    }

    char TestString[20];
    memset(TestString, 0, sizeof(TestString));
    fread(TestString, sizeof(TestString), 1, fp);
    if(strncmp("ScanGLM1.0", TestString, sizeof("ScanGLM1.0")-1))
    {
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). Invalid file or version: TestString[] = %s (should be %s  (Case SENSITIVE)).\n", TestString, "ScanGLM1.0");
        return U_ERROR;
    }

    UFileName  ScanNameIn;
    UFileName  SelectName;
    UDirectory RegDir;
    char line[500];
    rewind(fp);
    while(GetLine(line, sizeof(line),fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsCommentLine()==true || AA.IsEmptyLine()==true) continue;

        if(AA.IsIdentifierIs("PATIENTDIR", true)==true)
        {
            const char* PatName = AA.GetNextFileName(sizeof(line), NULL);
            *PatDir = UPatTree(PatName);
            if(PatDir->GetError()!=U_OK || PatDir->GetStatus()!=UDirectory::U_EXIST)
            {
                fclose(fp);
                CI.AddToLog("ERROR: ReadInputFile(). Input .Patient tree does not exist, or erroneous: %s .\n", PatName);
                return U_ERROR;
            }
            continue;
        }
        if(AA.IsIdentifierIs("SCAN_4D", true)==true)
        {
            const char* SName = AA.GetNextFileName(sizeof(line), NULL);
            ScanNameIn = UFileName(SName);
            continue;
        }
        if(AA.IsIdentifierIs("CORRSCAN", true)==true)
        {
            const char* SName = AA.GetNextFileName(sizeof(line), NULL);
            *pBaseName = UFileName(SName);
            continue;
        }
        if(AA.IsIdentifierIs("REGDIR", true)==true)
        {
            const char* RegName = AA.GetNextFileName(sizeof(line), NULL);
            RegDir = UDirectory(RegName);
            if(RegDir.GetStatus()!=UDirectory::U_EXIST)
            {
                fclose(fp);
                CI.AddToLog("ERROR: ReadInputFile(). Input regressor directory does not exist, or erroneous: %s .\n", RegName);
                return U_ERROR;
            }
            continue;
        }
        if(AA.IsIdentifierIs("SELECTOR", true)==true)
        {
            const char* SName = AA.GetNextFileName(sizeof(line), NULL);
            SelectName = UFileName(SName);
            continue;
        }
        if(AA.IsIdentifierIs("NREFERENCE", true)==true)
        {
            *NRegRef = AA.GetNextInt(-1);
            if(*NRegRef<=0 || *NRegRef >MAX_REG_REFERENCE)
            {
                fclose(fp);
                CI.AddToLog("ERROR: ReadInputFile(). Input parameter NREFERENCE out of range (%d) .\n", *NRegRef);
                return U_ERROR;
            }
            continue;
        }
        if(AA.IsIdentifierIs("NCONFOUNDER", true)==true)
        {
            *NRegCon = AA.GetNextInt(-1);
            if(*NRegCon<=0 || *NRegCon >MAX_REG_CONFOUNDER)
            {
                fclose(fp);
                CI.AddToLog("ERROR: ReadInputFile(). Input parameter NCONFOUNDER out of range (%d) .\n", *NRegCon);
                return U_ERROR;
            }
            continue;
        }
    }
    rewind(fp);

    ScanNameIn.SetExtension(".scan4D");
    UDirectory ScanDirIn( (const char*)(*PatDir + ScanNameIn));
    *pSL = new UScanList(ScanDirIn + UFileName("scan4d.xdr"));
    if( (*pSL)==NULL || (*pSL)->GetError()!=U_OK)
    {
        delete *pSL;
        fclose(fp);
        CI.AddToLog("ERROR: ReadInputFile(). Creating input dynamic scan from input parameters.\n");
        return U_ERROR;
    }

/* Create regressors */
    if(SelectName.IsEmpty()==false)
    {
        Selector = new UFieldGraph(RegDir + SelectName);
        if(Selector==NULL || Selector->GetError()!=U_OK)
        {
            delete *pSL;
            fclose(fp);
            CI.AddToLog("ERROR: ReadInputFile(). Creating selector from file name: %s .\n", (const char*)(RegDir + SelectName));
            return U_ERROR;
        }
    }

    int NRegFound = 0;
    int NConFound = 0;
    while(GetLine(line, sizeof(line),fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsStartList("REFERENCES")==true)
        {
            while(NRegFound<*NRegRef && GetLine(line, sizeof(line),fp))
            {
                UAnalyzeLine AA(line);
                if(AA.IsEmptyLine() || AA.IsCommentLine()) continue;
                UFileName    F  = RegDir + UFileName((AA.GetNextString(sizeof(line))));
                UFieldGraph* FG = new UFieldGraph(F);
                if(FG==NULL || FG->GetError()!=U_OK)
                {
                    delete FG; delete *pSL;
                    fclose(fp);
                    CI.AddToLog("ERROR: ReadInputFile(). Creating reference regressor %d.\n", NRegFound);
                    return U_ERROR;
                }
                RegRef[NRegFound++] = FG;
            }
        }

        if(AA.IsStartList("CONFOUNDERS")==true)
        {
            while(NConFound<*NRegCon && GetLine(line, sizeof(line),fp))
            {
                UAnalyzeLine AA(line);
                if(AA.IsEmptyLine() || AA.IsCommentLine()) continue;
                UFileName    F  = RegDir + UFileName((AA.GetNextString(sizeof(line))));
                UFieldGraph* FG = new UFieldGraph(F);
                if(FG==NULL || FG->GetError()!=U_OK)
                {
                    delete FG; delete *pSL;
                    fclose(fp);
                    CI.AddToLog("ERROR: ReadInputFile(). Creating reference regressor %d.\n", NConFound);
                    return U_ERROR;
                }
                RegCon[NConFound++] = FG;
            }
        }
    }
    fclose(fp);

    return U_OK;
}
