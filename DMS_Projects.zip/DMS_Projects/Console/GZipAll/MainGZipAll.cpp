/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to call gzip32.exe recursively                    .               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    08-06-06   creation
  Jdm    13-04-11   Allow compressing as well as decompressing.
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  JdM    21-04-18   Improved compatibility with wild cards
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../String.h"

#define VERSION            "1.2 "
#define AUTHOR             "Dr. JC de Munck, Dept. PMT, VUMC, Amsterdam"

enum{
    OP_COMP,
    OP_DIRIN,
    NOPTIONS
};


static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme call gzip32.exe recursively.\n";

    Help[OP_COMP   ] = "Set this option to compress instead of decompress.";
    Help[OP_DIRIN  ] = "You must give the data sets of which you want to unzip.";
    Option[OP_COMP ] = UOption("Zip","Compress", Help[OP_COMP   ]);
    Option[OP_DIRIN] = UOption("Input*.ds",Help[OP_DIRIN], UOption::DATASETNAME);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());


/*Select data sets*/   
    const char* DataSets = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(DataSets, CNULL);
    char* WC = Dirin.SplitOffWildcards();

    int               NDirs    = 0;
    UFileName*        DirNamAr = Dirin.GetAllSubdirNames(WC?WC:"*", &NDirs);
    delete[] WC;

    if(DirNamAr==NULL || NDirs<=0)
    {
        delete[] DirNamAr;
        CI.AddToLog("ERROR: There are no files of the give specifications: %s .\n",DataSets);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NDirs);


/*Test whether data selection arguments are compatible */
    for(int idir=0; idir<NDirs; idir++)
    {
        const char* DataSetName = DirNamAr[idir].GetFullFileName();
        UString Command;
        if(Option[OP_COMP ].GetValueSet()==true)
        {
            Command = UString(DataSetName, "gzip32.exe -v1 %s\\*");
        }
        else
        {
            Command = UString(DataSetName, "gzip32.exe -d -n %s\\*");
        }
        CI.AddToLog("Executing: %s \n",(const char*)Command);
        system((const char*)Command);
    }
    CI.AddToLog("Programme ended succesfully\n");

    return 0;
}

