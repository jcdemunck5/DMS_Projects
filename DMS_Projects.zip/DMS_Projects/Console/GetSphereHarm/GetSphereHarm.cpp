/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to compute spherical harmonics coefficients of outside of head    */
/*     using discretized points as input.                                        */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    10-02-13   creation
*/
#include<stdlib.h>

#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../PointList.h"

#define VERSION "1.01"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

const UEuler Fiff2CTF   = UEuler(UVector3(0.,0.,1.),-PI/2);


enum{
    OP_FILEIN,OP_FILEOUT,OP_LENUNIT,OP_ZTHRESH,OP_SHAPE,OP_COST,OP_L2LAM,OP_FIXCEN,OP_NCOMP,NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];


int main(int Nargs, char **Args)
{       
    char* Intro  = "This reads a set of digitized head points from disk and fits a standard deformable head \n"
                   "through it. It outputs a file containing the spherical harmonics coefficients and the \n"
                   "the fitted origin. \n";

    Help[OP_FILEIN  ] = "The input file containing the the digitized head. This can be in FIF format or ,pts text format (FIF coordinates).";
    Help[OP_FILEOUT ] = "The ouput (text) file containing the spherical harmonics coefficients and origin (in CTF coordinate system).";
    Help[OP_LENUNIT ] = "The length unit of a .pts file can be mm, cm or m. In this program all units are in cm. Here you can give the lenght unit used in the .pts input file (LU1= mm, LU2 = cm, LU3= m).";
    Help[OP_ZTHRESH ] = "You can select points that are included in the fit procedure, based on height above (positive Z) or below (negative Z) the nasion-ear plane. Here you give Z in cm. If this option is not set, all points are included.";
    Help[OP_SHAPE   ] = "You can either fit arbitrary shapes (-S1) or fit predefined head shapes (-S2).";
    Help[OP_COST    ] = "You can use either L1 or L2 norm in the cost function. L1 is less sensitive for outliers, -Cst1 uses L1, -Cst2 uses L2 minimization.";
    Help[OP_L2LAM   ] = "In case of L2 cost function, you can apply a smoothing parameter. Of omitted, a default is used.";
    Help[OP_FIXCEN  ] = "You can fix the center of the head at the standard position (-1.,0.,5.) (CTF-coords).";
    Help[OP_NCOMP   ] = "You can fix the number of components used for the spherical harmonics expansion. In case of arbitrary shapes this number is the maximum degree, in case of head shapes the given number reflects the number of reduced coefficients.";

    Option[OP_FILEIN  ] = UOption("FileIn.pts",Help[OP_FILEIN], UOption::FILENAME);
    Option[OP_FILEOUT ] = UOption("FileIn.txt",Help[OP_FILEOUT], UOption::FILENAME);
    Option[OP_LENUNIT ] = UOption("LU","LengthUnit",Help[OP_LENUNIT],1,3,2);
    Option[OP_ZTHRESH ] = UOption("Z","Zthresh",Help[OP_ZTHRESH],-20.,20.,0.);
    Option[OP_SHAPE   ] = UOption("S","Shape",Help[OP_COST],1,2,2);
    Option[OP_COST    ] = UOption("Cst","CostType",Help[OP_COST],1,2,2);
    Option[OP_L2LAM   ] = UOption("Lam","Smoothing",Help[OP_L2LAM],0.,1.,1.e-6);
    Option[OP_FIXCEN  ] = UOption("Fix","FixCenter",Help[OP_FIXCEN]);
    Option[OP_NCOMP   ] = UOption("Nc","NComp",Help[OP_NCOMP],1,8,6);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UFileName Fin(Option[OP_FILEIN ].GetFileName());
    UFileName Fot(Option[OP_FILEOUT].GetFileName());
    Fot.SetExtension("txt");
    if(Fot.IsPureFile())  
    {
        UDirectory Dirin = Fin.GetDirectory();
        Fot = Dirin + Fot;
    }
    UPointList PL(Fin);
    if(PL.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: File does not exist, or file type not supported: %s \n", (const char*)Fin);
        CI.PressReturnExit();
    }
    PL.Transform(Fiff2CTF);
    switch(Option[OP_LENUNIT].GetValue())
    {
    case 1: PL.Multiply(0.1);   break;
    case 2:                     break;
    case 3: PL.Multiply(100.);  break;
    }
    if(Option[OP_ZTHRESH].GetValueSet()==true)
    {
        double Z = Option[OP_ZTHRESH].GetDubVal1();
        PL.Crop(UVector3(-1000.,-1000.,Z), UVector3(1000.,1000.,1000.));
    }


    int           Ncomp      = Option[OP_NCOMP   ].GetValue();
    double        FitError   = 0.;
    ShapeAnatType FitST      = Option[OP_SHAPE].GetValue()==1? U_ANAT_GENERAL : U_ANAT_SKIN;
    double        LamdaTrunc =  Option[OP_L2LAM   ].GetDubVal1();
    bool          UseL1Norm  = (Option[OP_COST    ].GetValue()==1);

    UVector3      Center;
    if(Option[OP_FIXCEN  ].GetBOOL()==false)
    {
        double        Mesh       = 1.;
        UCostminimize Cpar;
        Cpar.SetMaxiter(1000);
        Cpar.SetOptMethod(UCostminimize::U_SIMPLEX_BOOST);
        Cpar.SetStartOffset(3.);


        UPointList *PTemp = PL.GetShapeFit(Mesh, Ncomp, &Center, &FitError, FitST, Cpar, LamdaTrunc, UseL1Norm);
        if(PTemp==NULL || PTemp->GetError()!=U_OK)
        {
            delete PTemp;
            CI.AddToLog("ERROR: Fitting head shape. \n");
            CI.PressReturnExit();
        }
        delete PTemp;
    }
    else
    {
        Center = UVector3(-1.,0.,5.);
    }
    UParamShape PSS(PL.GetNpoints(), PL.GetPoints(), Ncomp, FitST, &Center, LamdaTrunc, UseL1Norm);
    int           NCoeff = PSS.GetNCoeff();
    const double* coef   = PSS.GetCoeff();

    FILE*   fp = fopen(Fot, "wt");
    fprintf(fp, "%s", CI.GetProperties("// "));
    fprintf(fp, "FitError = %f  \n", FitError);
    fprintf(fp, "NPoints   = %d  \n", PL.GetNpoints());
    fprintf(fp, "Xpos     = %f  // [cm], CTF-coords\n", Center.Getx());
    fprintf(fp, "Ypos     = %f  \n", Center.Gety());
    fprintf(fp, "Zpos     = %f  \n", Center.Getz());
    fprintf(fp, "NCoeff   = %d  \n", NCoeff);
    for(int n=0; n<NCoeff; n++)
        fprintf(fp, "%f \n", coef[n]);

    fclose(fp);


    return 0;
}

