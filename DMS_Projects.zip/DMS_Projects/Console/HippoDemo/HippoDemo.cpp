/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to analyze update histories of cpp files.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    04-12-16   creation
  JdM    05-12-16   GetDrawings(). Changed error messages on error.
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  JdM    10-06-18   Enable input in form of .DWI/.dwp combi
  */
#include<stdlib.h>
 
#include "../../Option.h"
#include "../../FileName.h"
#include "../../Directory.h"
#include "../../Surface.h"
#include "../../Drawing.h"
#include "../../Manifold.h"

#define VERSION "1.12"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

enum{
    OP_FILIN,OP_FILOUT,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];


#define MAXCONTOURS 40
UDrawing* Contours[MAXCONTOURS];
ErrorType GetDrawings(const UPointList& S, int dir, int* NCross);

UEuler GetToWld(UFileName F);



int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme reads in paralel 3D-contours, converts it to a closed surface and exports it to a vtk file. \n";

    Help[OP_FILIN    ] = "Input file with paralel contours in .vtk format. Slices should be in z-plane.";
    Help[OP_FILOUT   ] = "Output .vtk file.";
    Option[OP_FILIN  ] = UOption("Input",Help[OP_FILIN], UOption::FILENAME);
    Option[OP_FILOUT ] = UOption("Output",Help[OP_FILOUT], UOption::FILENAME);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.ResetLogFile();
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    UFileName  Fin(Option[OP_FILIN].GetFileName());
    UFileName  Fout(Option[OP_FILOUT].GetFileName());
    if(Fout.IsPureFile()==true)
        Fout = Fin.GetSiblingFileName(Option[OP_FILOUT].GetFileName());
    Fout.SetExtension(".vtk");

    if(DoesFileExist(Fin)!=true)
    {
        CI.AddToLog("ERROR: Files does not exist: %s \n", (const char*)Fin);
        CI.PressReturnExit(true);
        return -1;
    }

    UPointList Pin;
    if(Fin.HasExtension("vtk",false))
    {
        USurface Sin(Fin);
        if(Sin.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Reading .vtk file: %s \n", (const char*)Fin);
            CI.PressReturnExit(true);
            return -1;
        }
        Pin = (UPointList) Sin;
    }
    else if(Fin.HasExtension("DWI",false) || Fin.HasExtension("dwp",false))
    {
        UDrawing Din(Fin);
        if(Din.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Reading xdr drawing file: %s \n", (const char*)Fin);
            CI.PressReturnExit(true);
            return -1;
        }
        Pin       = (UPointList) Din;
        UEuler TW = GetToWld(Fin);
        Pin.Transform(TW.GetInverse());
    }
    int dir   = 1;   //// Sagital
    //int dir   = 0; //// Axial
    int NCont = 0;
    if(GetDrawings(Pin, dir, &NCont) !=U_OK)
    {
        CI.AddToLog("ERROR: Creating contours from input file: %s \n", (const char*)Fin);
        CI.PressReturnExit(true);
        return -1;
    }

    int  NPcontInter = 100;
    int  NSublayer   = 5;
    int  order       = 2;
    bool AddCap      = true;
    UManifold M((const UDrawing**)Contours, NCont, NPcontInter, NSublayer, order, AddCap, U_PENALTY_NO, 0.001);
    for(int k=0; k<MAXCONTOURS; k++) {delete Contours[k]; Contours[k]=NULL;}

    if(M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating manifold from contours. \n");
        CI.PressReturnExit(true);
        return -1;
    }

    USurface* Sout = M.GetSurface("Sout", true);
    if(Sout==NULL || Sout->GetError()!=U_OK)
    {
        delete Sout;
        CI.AddToLog("ERROR: Extracting surface from manifold. \n");
        CI.PressReturnExit(true);
        return -1;
    }
    bool BINARY = false;
    if(Sout->WriteVTK(Fout, ULinTran(), BINARY)!=U_OK)
    {
        delete Sout;
        CI.AddToLog("ERROR: Writing to .vtk file: %s. \n", (const char*)Fout);
        CI.PressReturnExit(true);
        return -1;
    }
    delete Sout;
    return 0;
}

ErrorType GetDrawings(const UPointList& PL, int dir, int* NCross)
{
    for(int k=0; k<MAXCONTOURS; k++) Contours[k] = NULL;

    *NCross = 0;
    UVector3 po;
    for(int n=0, ic=0; n<PL.GetNpoints();  n++)
    {
        UVector3 p = PL.GetPoint(n);

        if(n!=0 && fabs(p[dir]-po[dir])>0.001) ic++;
        *NCross= ic+1;
        if(ic>=MAXCONTOURS)
        {
            for(int k=0; k<MAXCONTOURS; k++) {delete Contours[k]; Contours[k]=NULL;}
            CI.AddToLog("ERROR: GetDrawings(). Too many contours: NCross = %d, n=%d \n", *NCross, n);
            *NCross = 0;
            return U_ERROR;
        }

        if(Contours[ic]==NULL)  Contours[ic] = new UDrawing();

        Contours[ic]->AddPoint(p, Contours[ic]->GetNpoints()>0);
        po = p;
    }
    return U_OK;
}

UEuler GetToWld(UFileName F)
{
    UDirectory D = F.GetDirectory();
    if(D.HasExtension("Patient", false)==false)
    {
        D = D.Parent();
        if(D.HasExtension("Patient", false)==false)
        {
            D = D.Parent();
            if(D.HasExtension("Patient", false)==false)
            {
                return UEuler();
            }
        }
    }
    int        ND  = 0;
    UFileName* Far = D.GetSubdirNames("*.scan", &ND, true);
    if(ND<=0||Far==NULL)
    {
        delete[] Far;
        return UEuler();
    }
    for(int n=0; n<ND; n++)
    {
        UFileName M = UDirectory(Far[n])+"match_scan_to_wld.xdr";
        UFileName W = UDirectory(Far[n])+"scan_to_wld.xdr";
        if(DoesFileExist(M)==false && DoesFileExist(W))  // Reference scan directory
        {
            delete[] Far;
            return UEuler(W);
        }
    }
    return UEuler();
}
