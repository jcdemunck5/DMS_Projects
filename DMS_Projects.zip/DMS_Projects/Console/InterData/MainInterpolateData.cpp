/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to interpolate CTF-data from one data set onto another.           */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    16-07-98   creation
  Jdm    24-08-98   lay out
  Jdm    26-08-98   made TranslateArgs() and Usage() static
  Jdm    15-11-98   Use UOptions-object.
  Jdm    13-01-99   Option to export Stimulus channel.
  Jdm    18-01-99   Option to export ADC channel(s).
  Jdm    19-01-99   Make Radius a double, i.s.o. an integer variable
  JdM    12-02-99   Option to export the EEG data
  Jdm    20-04-99   Export Introduction text to .bat-file
  JdM    07-08-99   Use global UConsoleInterface()-object CI
  JdM    25-09-01   Major revision. Combine functionality of BestGrid with InterpolateData.
                    Use Wild cards to select data sets to be interpolated.
                    Use UMEEGDataEpochs object to get data from raw data files.                      
  JdM    30-10-01   Added the option to export .hc file
  JdM    30-10-01   Added the option to export CTF markers (Concatenated case).
                    Put the right time-offset into the output data sets.
  JdM    19-05-02   Use AddComment() i.s.o. SetComment() to set the redescription of the output file.
                    The reason of this change is to keep the information about the EEG sensors
  JdM    30-05-02   Add the option to choose EEG re-referencing
  JdM    06-06-02   Allow all exported markers to have the same name "Zero"
  JdM    18-06-02   Bug fix in setting zero markers
  JdM    26-06-02   Automatically skip hz-files
  JdM    08-07-02   Allow removal of powerline noise and SEF artefacts
  JdM    26-08-02   Add option to set default best grid
  JdM    09-10-02   Add option to remove complete epochs based on overlapping with markers
  JdM    07-02-03   CanbeConcatenated() Treat different MEG references as warning, for concatenation when options require so.
                    CreateZeroMarkers() Relax the demand that PreTriggerPts is equal over all data sets
  JdM    12-02-03   Add option to export .map file of concatenated data set
  JdM    02-07-04   Program works also when no MEG is present. It will select/concatenate EEG or ADC data.
  JdM    14-03-05   Disable MS-language extensions, correct for loops
  JdM    22-02-06   UPreProType not a member of ULinearFilter anymore
  JdM    24-08-06   Used UInterpolateSensors() instead of old UInterpolate() (just renaming of class)
  GdV    11-10-06   main() returns int instead of void
  JdM    05-03-08   MAJOR update. Adapted sources to new directory structure (PMT_Projects iso MCAProjects_6)
  JdM    26-06-08   Added option OP_GOODCH and OP_BADCH. Updated USetEpochs according to PowerSpectrum.cpp
  JdM    04-06-12   Small updates to comply with new interface
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include<stdlib.h>

#include "../../Option.h"
#include "../../FileName.h"
#include "../../MEEGDataEpochs.h"
#include "../../MEEGDataCTF.h"
#include "../../MEEGDataWriteCTF.h"
#include "../../InterpolateSensors.h"
#include "../../GridFit.h"
#include "../../Directory.h"
#include "../../Epochs.h"
#include "../../MarkerArray.h"


#define VERSION "6.03"
#define AUTHOR  "Dr. JC de Munck, Dept. PMT, VUmc, Amsterdam"

#define MAXTRIALLABEL 100

static UGridFit*     GetBestGrid(UMEEGDataEpochs** EpDatAr, int Nsets, UEuler* BestEuler, UEuler* Dewar2Best, double* ResError, const UGrid* DefaultGrid);
static bool          CanbeConcatenated(UMEEGDataEpochs** EpDatAr, int Nsets, bool *ExportEEG, bool *ExportADC);
static UMarkerArray* CreateZeroMarkers(const UMEEGDataEpochs* const* EpdatAr, int Nset, const char* Name);

enum{
    OP_DIRIN,OP_OUTNAM,OP_GOODCH,OP_BADCH,
    OP_DEFBEST,OP_RADIUS,OP_EPS,OP_ADC,OP_EEG,OP_COPYHC,OP_CONCAT,OP_SAVEMAP,OP_INSMARK,
    OP_TRIALS,OP_SAMPLE,OP_MWIDTH,OP_MOFFSET,OP_MRANGE,OP_MNAME,OP_SUBEPOCH,OP_EXTRIAL,OP_EXMNAME,OP_EXMWIDTH,OP_EXMEPOCH,OP_EXOVERL,
    OP_RSEFART,OP_REM50HZ,OP_FBANDP,OP_SVD,OP_PREPRO,OP_PREEPOCH,OP_MEGRREF,OP_EEGRREF,
    NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

class USetEpochs
{
public:
    USetEpochs();
    ErrorType ArgumentsToObject(UMEEGDataEpochs* Epdat);
};
static USetEpochs SetEp;


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme extrapolates the MEG data sets measured with different sensor positions\n"
                         "onto new data sets that all have the same (average) sensor positions. The goal of these\n"
                         "extrapolations is to be able to average, merge and compare different data sets.\n";
                         "The extrapolation algorithm is based on the computation of minimum norm dipole distributions,\n"
                         "computed for the data to be interpolated. Then using these sources, the magnetitic field is\n"
                         "computed onto the other grid. The interpolated data is stored new data sets, which contain the\n"
                         "the computed.res4-file, .meg4-file and .hc-file.\n\n"           
                         "Notes:\n"
                         "1.) The data sets to be interpolated are to be given using wild cards. Erroneous data sets are skipped.\n"
                         "2.) The extrapolated data sets have default names (extensions of the input names).\n"
                         "3.) When selections of data are given (e.g. using different markers) these data are \n"
                         "    are stored in different trials. \n"
                         "Restrictions:\n"
                         "The minimum norm dipoles are computed on a spherical shell with a certain\n"
                         "radius (default 7.0 cm). If the recording grid and the interpolation grid are\n"
                         "too far apart (more than 2. cm and/or more than 30 degrees), the method will\n"
                         "fail.\n\n"
                         "The theory underlying this program is described in:\n"
                         "J.C. De Munck, J.P.A. Verbunt, D. Van 't Ent and B.W. van Dijk, The Use of an\n"
                         "MEG device as 3-D digitizer and motion detection system, Phys. Med. Biol, 46:2041-2052 (2001)\n"
                         "Please refer to that paper if the use of this program is a substantial part of your work.\n";


    Help[OP_DIRIN  ] = "You must give the data sets of which you want to align the MEG data in the form of a data set name containing wild cards. For example, you would give E:\\CTFData\\*EE\\*BNT\\ds, and all data set matching this string will be aligned. NB: Linux users, do not forget to start the filename string with './' to indicate the current directory.";
    Help[OP_OUTNAM ] = "The ouput data sets, obtained bu extrapolating the inputs will have default names, consisting of the input names with a given string added to it. Here you can give the string added to the names of the output data sets.";
    Help[OP_GOODCH ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH  ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";    
    Help[OP_DEFBEST] = "You can align the data set(s) to a fixed gived data set, i.e. without performing an optimal fit. When you wish to do so, you can give here the data set you wish to use as default grid. When this option is omitted, the optimal grid is computed.";
    Help[OP_RADIUS ] = "The radius of the sphere on which the dipole interpolation sources are projected [cm].";
    Help[OP_EPS    ] = "The matrix used to compute the interpolating dipoles is very instable (depending on the radius of the spherical shell). To smooth the inverse solution you can set a threshold parameter that is used to NULL the smallest eigenvalues.";
    Help[OP_ADC    ] = "If this option is set, the ADC channel(s) of input DataSets (if present) are copied to the output data sets.";
    Help[OP_EEG    ] = "If this option is set, the EEG channel(s) of input DataSets (if present) are copied to the output data sets.";
    Help[OP_COPYHC ] = "If this option is set, the .hc file with the head coils is copied (after transformation) to the new data set directory. In case of concatened output data set, the first .hc file will be transformed to the output coordinate system, implicitly assuming that the shapes of the Nasion-Ear triangles are equal over input data sets.";
    Help[OP_CONCAT ] = "You can concatenate all epochs of the selected data sets in one new data set. In this new data sets all epochs of all selected data sets are exported as trials. It will be tested beforehand whether a concatenation is possible, by considering the sample frequencies, etc. If you wish to concatenate all data in one new data set, you must give here the data set of the concatenated data.";
    Help[OP_SAVEMAP] = "When you conatenated all epochs, it is possible to export a copy of the data set in the form a .map-file. This .map file can be viewed with Maptool (JPA Verbut, Matlab) or with QShowMap.";
    Help[OP_INSMARK] = "When you decide to concatenate selected epochs, you can insert CTF markers. These markers are positioned at the zero-point of the written trials. 0: Do not create markers, 1: Create markers named 'Zero', 2: Create markers carrying the name of the corresponding data set.";

    Option[OP_DIRIN  ] = UOption("Input*.ds",Help[OP_DIRIN], UOption::DATASETNAME);
    Option[OP_OUTNAM ] = UOption("Nex","NameExten",Help[OP_OUTNAM],"_int");
    Option[OP_GOODCH ] = UOption("Gch","GoodCh",Help[OP_GOODCH],NULL);
    Option[OP_BADCH  ] = UOption("Bch","BadCh",Help[OP_BADCH],NULL);
    Option[OP_DEFBEST] = UOption("Grd","Def. Grid",Help[OP_DEFBEST],"");
    Option[OP_RADIUS ] = UOption("r","Radius",Help[OP_RADIUS],3.,10.,8.);
    Option[OP_EPS    ] = UOption("eps","EigenThres",Help[OP_EPS],0.,1.,1.e-10);
    Option[OP_ADC    ] = UOption("ADC","ADC Ch",Help[OP_ADC]);
    Option[OP_EEG    ] = UOption("EEG","EEG Ch",Help[OP_EEG]);
    Option[OP_COPYHC ] = UOption("Chc","Copy hc",Help[OP_COPYHC]);
    Option[OP_CONCAT ] = UOption("Cat","ConcatNam",Help[OP_CONCAT],"");
    Option[OP_SAVEMAP] = UOption("Map","MapFile",Help[OP_SAVEMAP],"");
    Option[OP_INSMARK] = UOption("Mrk","InsertMarkers",Help[OP_INSMARK],0,2,0);
           
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    if(Option[OP_INSMARK].GetValue()!=0 && Option[OP_CONCAT].GetValueSet()==false)
    {
        CI.AddToLog("ERROR: You can only export CTF markers in case of concatenated data sets.\n");
        CI.PressReturnExit();
    }

/*Select data sets*/   
    const char*       DataSets = Option[OP_DIRIN].GetFileName();
    UDirectory        Dirin(DataSets, NULL, false);
    const char*       DirName  = Dirin.GetDirectoryName();

    int               NDirs    = 0;
    UFileName*        DirNamAr = Dirin.GetAllSubdirNames(DataSets, &NDirs);
    UMEEGDataEpochs** EpdatAr  = new UMEEGDataEpochs*[NDirs];
    if(EpdatAr)
        for(int idir=0; idir<NDirs; idir++) EpdatAr[idir] = NULL;

    if(DirNamAr==NULL || EpdatAr==NULL || NDirs<=0)
    {
        CI.AddToLog("ERROR: There are no files of the give specifications: %s .\n",DataSets);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NDirs);

    const char* GoodChan = NULL; if(Option[OP_GOODCH].GetValueSet()==true) GoodChan = Option[OP_GOODCH].GetString();
    const char* BadChan  = NULL; if(Option[OP_BADCH ].GetValueSet()==true)  BadChan = Option[OP_BADCH ].GetString();

/*Test whether data selection arguments are compatible */
    int ngood  = 0;
    int ntotEp = 0;  // The total number of all epochs over all data sets
    for(int idir=0; idir<NDirs; idir++)
    {
        const char* DataSetName = DirNamAr[idir].GetFullFileName();

        if(IsStringEnding(DataSetName, "hz.ds")==true ||
           IsStringEnding(DataSetName, "hz2.ds")==true)
        {
            CI.AddToLog("Note: Skipping data set %s .\n",DataSetName);
            continue;
        }

        EpdatAr[ngood] = new UMEEGDataEpochs(UDirectory(DataSetName));
        if(SetEp.ArgumentsToObject(EpdatAr[ngood])!=U_OK) 
        {
            CI.AddToLog("Note: Skipping data set %s .\n",DataSetName);
            delete EpdatAr[ngood];
            continue;
        }
        if(EpdatAr[ngood]->ForceEqualSize(false, 0.)!=U_OK)
        {
            CI.AddToLog("Note: Skipping data set %s . Error in making all epochs of equal size. \n",DataSetName);
            delete EpdatAr[ngood];
            continue;
        }
        if(GoodChan==NULL && BadChan==NULL)
        {
            if(EpdatAr[ngood]->RemoveChannels(EpdatAr[ngood]->GetData()->GetBadChannels())!=U_OK)
            {
                CI.AddToLog("Note: Skipping data set %s . Removing BAD channels. \n",DataSetName);
                delete EpdatAr[ngood];
                continue;
            }
        }
        else
        {
            if(EpdatAr[ngood]->SelectChannels(GoodChan, BadChan)!=U_OK)
            {
                CI.AddToLog("Note: Skipping data set %s . Error in selecing good/bad channels. \n",DataSetName);
                delete EpdatAr[ngood];
                continue;
            }
        }
        ntotEp+=EpdatAr[ngood]->GetNEpoch();
        ngood++;
    }
    delete[] DirNamAr;
    NDirs = ngood;

/* Get Best Grid of remaining data sets*/
    UEuler    BEuler;
    UEuler    Dewar2Best;
    double    ResError = 0;
    UGrid* DefaultGrid = NULL;
    if(Option[OP_DEFBEST].GetValueSet()==true)
    {
        UMEEGDataCTF DefDat(Option[OP_DEFBEST].GetString());
        DefaultGrid = new UGrid(*DefDat.GetGridMEG());
        if(DefaultGrid==NULL || DefaultGrid->GetError()!=U_OK)
        {
            for(int idir=0; idir<NDirs; idir++) delete EpdatAr[idir];
            delete[] EpdatAr;
            CI.AddToLog("ERROR: Getting default grid from given data set: %s .\n", DefDat.GetDataFileName());
            CI.PressReturnExit();
        }
    }
    UGridFit* BGrid = NULL;
    if(EpdatAr[0]->GetData()->GetGridMEG()!=NULL)
    {
        BGrid = GetBestGrid(EpdatAr, NDirs, &BEuler, &Dewar2Best, &ResError, DefaultGrid);
        delete[] DefaultGrid;
        if(BGrid==NULL || BGrid->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Computing best grid.  \n");
            CI.PressReturnExit();
        }
        CI.AddToLog("Note: ResidualError = %f \n", ResError);
        CI.AddToLog("Note: BestEulerXFM: \n");
        CI.AddToLog("%s", BEuler.GetProperties("Note:"));
        for(int is=0; is<NDirs; is++)
        {
            CI.AddToLog("// %s \n", (const char*) EpdatAr[is]->GetData()->GetDataFileName());

            UEuler Error = Dewar2Best*EpdatAr[is]->GetData()->GetDewar2NLR().Invert();
            CI.AddToLog("// %s \n",Error.PrintParameters());
            CI.AddToLog("// TranslationError = %f //[cm]  \n",Error.TotalTrans());
            CI.AddToLog("// RotationError    = %f //[deg] \n",Error.TotalRot(false));        
        }
    }
    else
    {
        CI.AddToLog("WARNING: No MEG data present in first data set. Skip MEG.\n");
    }


/* Concatenate data?*/
    bool ExportEEG     = Option[OP_EEG ].GetBOOL();
    bool ExportADC     = Option[OP_ADC ].GetBOOL();
    bool CopyHC        = Option[OP_COPYHC].GetBOOL();
    bool ConCatData    = false;
    const char*   ConCatDSName = NULL;
    UMarkerArray* CTFMark      = NULL;
    if(Option[OP_CONCAT].GetValueSet()==true)
    {
        ConCatData = true;
        if(CanbeConcatenated(EpdatAr, NDirs, &ExportEEG, &ExportADC)==false)
        {
            CI.AddToLog("ERROR: Not all data sets can be concatenated, because of inconsistencies. \n");
            CI.PressReturnExit();
        }
        ConCatDSName = Option[OP_CONCAT].GetString();
        if(ConCatDSName==NULL || ConCatDSName[0]==0)
        {
            CI.AddToLog("ERROR: Invalid name was given for the concatenated data set. \n");
            CI.PressReturnExit();
        }
        if(Option[OP_INSMARK].GetValue()!=0)
        {
            if(Option[OP_INSMARK].GetValue()==1)
                CTFMark = CreateZeroMarkers(EpdatAr, NDirs, "Zero");
            else if(Option[OP_INSMARK].GetValue()==2)
                CTFMark = CreateZeroMarkers(EpdatAr, NDirs, NULL);
            else
                CI.AddToLog("WARNING: Invalid marker option (%d). \n",Option[OP_INSMARK].GetValue());

            if(CTFMark==NULL)
                CI.AddToLog("WARNING: Creating time zero markers. \n");
        }
    }

/* Export .map file?*/
    UMEEGDataEpochs* MapData=NULL;
    char**       TrialLabels = NULL;
    if(Option[OP_SAVEMAP].GetValueSet()==true)
    {
        if(Option[OP_CONCAT].GetValueSet()==false)
            CI.AddToLog("WARNING: Exporting data as ,map file only works for concatenated data sets. \n");
        else if(Option[OP_ADC].GetValueSet()==true ||
                 Option[OP_EEG].GetValueSet()==true )
            CI.AddToLog("WARNING: Map-file will only contain MEG data (no ADC nor EEG). \n");
        else
        {
            TrialLabels = new char*[ntotEp];
            if(TrialLabels)
            {
                for(int k=0; k<ntotEp; k++) 
                {
                    TrialLabels[k] = new char[MAXTRIALLABEL];
                    if(TrialLabels[k]==NULL)
                    {
                        for(int kk=0; kk<k; kk++) delete[] TrialLabels[kk];
                        delete[] TrialLabels; TrialLabels=NULL;
                        break;
                    }
                    memset(TrialLabels[k], 0, MAXTRIALLABEL);
                }
            }
            if(TrialLabels==NULL)
                CI.AddToLog("ERROR: Memory allocation for .map file trial labels.\n");
        }
    }

/* Interpolate the data*/
    double Radius  = Option[OP_RADIUS].GetDubVal1();
    double Epsilon = Option[OP_EPS   ].GetDubVal1();
    UInterpolateSensors Inter; 

    UMEEGDataWriteCTF DatNew;
    for(int is=0, itrial=0; is<NDirs; is++)
    {
/* Create interpolation matrix*/
        if(BGrid)
        {
            const UGrid* Gr = EpdatAr[is]->GetData()->GetGridMEG();
            Inter = UInterpolateSensors(Gr, BGrid, Radius, Epsilon);
            if(Inter.GetError()!=U_OK)
            {
                CI.AddToLog("ERROR. Computing interpolation matrix in data set %s.\n",EpdatAr[is]->GetData()->GetDataFileName());
                CI.PressReturnExit();
            }
        }

/* Create new data set*/
        UFileName   Forig;
        if(ConCatData==true) 
        {
            Forig  = UFileName(ConCatDSName, "Orig.txt");
            if(is==0)
            {
                DatNew = UMEEGDataWriteCTF(*(EpdatAr[is]->GetData()));
                if(DatNew.SetDataFileName(ConCatDSName)!=U_OK)
                {
                    CI.AddToLog("ERROR. Creating ouput data set %s.\n",ConCatDSName);
                    CI.PressReturnExit();
                }

                UString Comment = UString(CI.GetProperties   ("//  "), "%s")
                                + UString("// Interpolation Constants:  \n") 
                                + UString(Inter.GetProperties("//  "), "%s") 
                                + UString(Inter.GetSphere().GetProperties(), "//   Sphere Position=%s      \n")
                                + UString(ResError                         , "//   Residual Error %f [cm]  \n");
                DatNew.AddComment(Comment);

/* Convert resource. Export EEG/ADC/Stim, iff these data are present in the input file */
                DatNew.SetNtrial(ntotEp);
                DatNew.SetNsampTrial(EpdatAr[is]->GetNSampEpoch(0));
                DatNew.SetPreTriggerTime_s(EpdatAr[is]->GetPreTriggerTime_s());
                
                DatNew.SetGridREF(NULL);
                if(BGrid) DatNew.SetGridMEG((const UGrid*)BGrid);
                else      DatNew.SetGridMEG(NULL);

                if(ExportEEG)  DatNew.SetGridEEG(EpdatAr[is]->GetData()->GetGridEEG());
                else           DatNew.SetGridEEG(NULL);
                if(ExportADC)  DatNew.SetGridADC(EpdatAr[is]->GetData()->GetGridADC());
                else           DatNew.SetGridADC(NULL);

                if(DatNew.WriteHeader() != U_OK)
                {
                    CI.AddToLog("ERROR :Writing the output file: %s\n",DatNew.GetDataFileName());
                    CI.PressReturnExit();
                }
                if(CTFMark && CTFMark->WriteMarkersCTF(DatNew.GetDataFileName().GetSiblingFileName("MarkerFile.mrk"))!=U_OK)
                    CI.AddToLog("WARNING: Errors in exporting marker file. \n");
                
                if(Option[OP_SAVEMAP].GetValueSet()==true && TrialLabels)
                {
                    MapData = new UMEEGDataEpochs(DatNew.GetDataFileName());
                    if(MapData==NULL || MapData->GetError()!=U_OK)
                    {
                        delete MapData; MapData = NULL;
                        CI.AddToLog("ERROR: Unable to create UMEEGDataEpochs()-object for the export of .map-file. \n");
                    }
                    else
                        MapData->SetEpochs(0, -1); // All samples, all trials, no filtering
                }
/* Add comments in origin file*/
                FILE* fp=fopen(Forig, "wt", false);
                if(fp)
                {
                    fprintf(fp,"// General: \n");
                    fprintf(fp,"%s", CI.GetProperties("//  "));
                    fprintf(fp,"//  \n");
                    fprintf(fp,"// Epoch origins: \n");
                    fprintf(fp,"//  \n");
                }
                fclose(fp);
            }
        }
        else
        {
            UFileName NewDSname(EpdatAr[is]->GetData()->GetDataFileName());
            NewDSname.InsertBeforeExtension(Option[OP_OUTNAM].GetString());
            DatNew = UMEEGDataWriteCTF(*(EpdatAr[is]->GetData()));
            if(DatNew.SetDataFileName(NewDSname)!=U_OK)
            {
                CI.AddToLog("ERROR. Creating ouput data set %s.\n",NewDSname);
                CI.PressReturnExit();
            }
/* Set comments */
            UEuler Error = Dewar2Best*EpdatAr[is]->GetData()->GetDewar2NLR().Invert();
            double trans = Error.TotalTrans();
            double rot   = Error.TotalRot(false);
            UString Comment = UString(CI.GetProperties   ("//  "), "%s")
                            + UString("// Interpolation Constants:  \n")  
                            + UString(Inter.GetProperties("//  "), "%s") 
                            + UString(trans       , "//   Shift         = %7.2f       \n")
                            + UString(rot         , "//   Rotation      = %7.2f       \n")
                            + UString(ResError    , "//   ResidualError = %f // [cm]  \n");
            DatNew.AddComment(Comment);

/* Convert resource. Export EEG/ADC/Stim, iff these data are present in the input file */
            DatNew.SetNtrial(ntotEp);
            DatNew.SetNsampTrial(EpdatAr[is]->GetNSampEpoch(0));
            DatNew.SetPreTriggerTime_s(EpdatAr[is]->GetPreTriggerTime_s());
                
            DatNew.SetGridREF(NULL);
            if(BGrid) DatNew.SetGridMEG((const UGrid*)BGrid);
            else      DatNew.SetGridMEG(NULL);
            if(Option[OP_EEG ].GetBOOL())  DatNew.SetGridEEG(EpdatAr[is]->GetData()->GetGridEEG());
            else                           DatNew.SetGridEEG(NULL);
            if(Option[OP_ADC ].GetBOOL())  DatNew.SetGridADC(EpdatAr[is]->GetData()->GetGridADC());
            else                           DatNew.SetGridADC(NULL);

            if(DatNew.WriteHeader() != U_OK)
            {
                CI.AddToLog("ERROR UInterpolateData :Writing the output file: %s\n",DatNew.GetDataFileName());
                CI.PressReturnExit();
            }
        }


/* Interpolated data and export as trials */
        int     nsamp = EpdatAr[is]->GetNSampEpoch(0);
        for(int k=0; k<EpdatAr[is]->GetNEpoch(); k++, itrial++)
        {
            if(ConCatData==true) // Add data to Orig file
            {
                FILE* fp=fopen(Forig, "at", false);
                if(fp)
                {
                    fprintf(fp, "%d \t",itrial);
                    const UEpochs* Ep = EpdatAr[is]->GetEpochs();
                    if(Ep && Ep->GetDescriptor(k))
                    {
                        fprintf(fp, "%s", Ep->GetDescriptor(k));
                    }
                    else if(Ep)
                    {
                        fprintf(fp, "%s \t", EpdatAr[is]->GetData()->GetDataFileName().GetBaseName());
                        fprintf(fp, "%d:%d \t %d:%d", Ep->GetBegin(k).trial, Ep->GetBegin(k).sample, 
                                                      Ep->GetEnd  (k).trial, Ep->GetEnd  (k).sample);
                    }
                    else
                    {
                        fprintf(fp, "Unknown");
                    }
                    fprintf(fp, "\n");
                }
                fclose(fp);
                if(Option[OP_SAVEMAP].GetValueSet()==true && TrialLabels)
                {
                    UFileName F(EpdatAr[is]->GetData()->GetDataFileName());
                    int nc = 0;
                    if(EpdatAr[is]->GetNEpoch()==1)
                        nc+=sprintf(TrialLabels[is]+nc, "%s",F.GetBaseName());
                    else
                        nc+=sprintf(TrialLabels[is]+nc, "%s %d",F.GetBaseName(),k);
                }
            }
            CI.AddToLog("%d ", itrial);

            UMultiChan* MCmeg = NULL;
            if(BGrid)
            {

                UMultiChan* MCin = EpdatAr[is]->GetFilteredMultiChan(k, U_DAT_MEG);
                if(MCin==NULL)
                {
                    CI.AddToLog("ERROR UInterpolateData : Getting MEG epoch %d .\n", k);
                    CI.PressReturnExit();
                }
                MCmeg = Inter.GetInterpolatedMultiChan(MCin);
                delete MCin;
                if(MCmeg==NULL || MCmeg->GetError()!=U_OK)
                {
                    delete MCmeg;
                    CI.AddToLog("ERROR UInterpolateData : Computing interpolated MEG in epoch %d .\n", k);
                    CI.PressReturnExit();
                }
            }
            UMultiChan* MCadc = NULL;
            UMultiChan* MCeeg = NULL;
            if(ExportADC ==true) MCadc = EpdatAr[is]->GetFilteredMultiChan(k, U_DAT_ADC);
            if(ExportEEG ==true) MCeeg = EpdatAr[is]->GetFilteredMultiChan(k, U_DAT_EEG);
            
            int iwrite = k;
            if(ConCatData==true)  iwrite = itrial;
            if(MCmeg&&MCmeg->GetData()) DatNew.WriteTrial(MCmeg->GetData(), U_DAT_MEG, iwrite);
            if(MCeeg&&MCeeg->GetData()) DatNew.WriteTrial(MCeeg->GetData(), U_DAT_EEG, iwrite);
            if(MCadc&&MCadc->GetData()) DatNew.WriteTrial(MCadc->GetData(), U_DAT_ADC, iwrite);

            delete MCmeg;
            delete MCeeg;
            delete MCadc;

            CI.AddToLog("\n");
        }

/* Convert .hc-file*/
/****
        if(CopyHC==true && (ConCatData==false||is==0) && EpdatAr[is]->GetDataSet()->DoesHCexist()==true)
        {
            UVector3 NLRhead[3];
            NLRhead[0] = EpdatAr[is]->GetDataSet()->GetFiducials(0);
            NLRhead[1] = EpdatAr[is]->GetDataSet()->GetFiducials(1);
            NLRhead[2] = EpdatAr[is]->GetDataSet()->GetFiducials(2);
            UEuler  Head2Dewar = Dewar2Best.Inverse();
            NewDS.WriteHC(NLRhead, Head2Dewar);
        }
 *****/
    }   
    delete BGrid;

    for(int idir=0; idir<NDirs; idir++) delete EpdatAr[idir];
    delete[] EpdatAr;


    if(MapData)
    {
        MapData->WriteMapFile(U_DAT_MEG, Option[OP_SAVEMAP].GetString(), TrialLabels, 0., -1, false);
    }
    delete MapData;
    if(TrialLabels)
    {
        for(int k=0; k<ntotEp; k++) delete[] TrialLabels[k];
        delete[] TrialLabels;
    }
    CI.AddToLog("Programme ended succesfully\n");
}


USetEpochs::USetEpochs()
{
/* Setting the epochs */
    Help[OP_TRIALS  ]   = "Trial Range: Only the data between first and last given trial is processed. -1 refers to last trial.";
    Help[OP_SAMPLE  ]   = "Sample Range: Only the data between first and last given sample is processed. -1 refers to last sample. Given samples are considered as absolute, i.e. not corrected for pr-trigger time.";
    Help[OP_MWIDTH  ]   = "Use markers from marker file, with certain half width i (in samples). If both the option and the -s option is set, -s is ignored.";
    Help[OP_MOFFSET ]   = "If the -mo option ist, the epochs are determined by shifting markers from the markerfiles with a certain name, over a fixed number of samples. The first number is used to set the beginning of each epoch and the second marker is used to set the last sample of each epoch.";
    Help[OP_MRANGE  ]   = "If the -mr option is set, begin and end markers are taken from the marker file, in order to set time segments to be analyzed. Begin and end markers are markers starting with the string 'BEGIN' and 'END' (or 'EIND'), respectively. The -mr option can not be set simultaneously with the -mh option. If both the -mr option and the -s option is set, the -s option is ignored.";
    Help[OP_MNAME   ]   = "If the epochs are derived from a marker with halfwidth or from begin/end marker pairs, you can here select a marker with a certain name. If the name is not set, all markers (pairs) are taken.";
    Help[OP_SUBEPOCH]   = "You can take every n-th epoch exclusively, starting with the m-th epoch (m<n). Here n it the first and m the second number to be given. For example, the numbers 0 amd 2 will skip all odd epochs and taking the even ones.";
    Help[OP_EXTRIAL ]   = "With this option you can exclude trials from the analysis, whose class name (defined in ClassFile.cls) is compatible the given string. This string may contain one or more wild cards. ";    
    Help[OP_EXMNAME ]   = "You can exclude time samples from the analysis, around markers with a certain name. Here you can set the marker name. If this option is set all samples within a certain range about the events corresponding to this marker are skipped.";
    Help[OP_EXMWIDTH]   = "When you have set the option to skip time samples with a certain name, you can set here how many samples on both side of each even will be disregarded.";
    Help[OP_EXMEPOCH]   = "Instead of removing time samples coinciding with a certain marker name, you can remove complete epochs that have an overlap with a certain marker. The advantage is that the number of samples per epoch stays the same";
    Help[OP_EXOVERL ]   = "If this option is set, overlapping epochs (e.g. caused by a too large -mr time) are excluded from the analysis.";

    Option[OP_TRIALS  ] = UOption("Tr" ,"Trials",Help[OP_TRIALS],-1,128,0,-1);
    Option[OP_SAMPLE  ] = UOption("s"  ,"Samples",Help[OP_SAMPLE],-1,32000,0,-1);
    Option[OP_MWIDTH  ] = UOption("mw" ,"Marker wi.",Help[OP_MWIDTH],1,500,1);
    Option[OP_MOFFSET ] = UOption("mo" ,"MarkerOffset",Help[OP_MOFFSET],-100000,100000,0,0);
    Option[OP_MRANGE  ] = UOption("mr" ,"Marker range",Help[OP_MRANGE]);
    Option[OP_MNAME   ] = UOption("Nam","Marker Name",Help[OP_MNAME],NULL);
    Option[OP_SUBEPOCH] = UOption("Rep","ReduceEpochs",Help[OP_SUBEPOCH],0,100,1,0);
    Option[OP_EXTRIAL ] = UOption("Ext","ExcludeTrls",Help[OP_EXTRIAL],"ClassName");
    Option[OP_EXMNAME ] = UOption("ExM","ExcludeMark.",Help[OP_EXMNAME ],NULL);
    Option[OP_EXMWIDTH] = UOption("Exw","Exclude wi.",Help[OP_EXMWIDTH],0,50000,0);
    Option[OP_EXMEPOCH] = UOption("ExE","Exclude ep",Help[OP_EXMEPOCH]);
    Option[OP_EXOVERL ] = UOption("EXO","Excl. Overl.",Help[OP_EXOVERL]);

/* Filtering parameters*/
    Help[OP_RSEFART ]   = "You can remove the SEF artifact from the selected epochs and pre-processing windows by linear interpolation. However, this only works for those epoch selection methods in which the stimulus onset can be determined, making certain assumptions.";
    Help[OP_REM50HZ ]   = "You can remove the 50 Hz. power line noise.";
    Help[OP_FBANDP  ]   = "Band-pass filter the data, before selecting the epochs. You can do so by giving here the minimum and maximum frequency in Hz. A negative value means: ignore. So, e.g. -Bpf-1Bpf10. means: pass all data between zero and 10. Hz, and -Bpf10.Bpf-1 means: pass all data between 10 Hz and the highest present frequency. If the option -Bpf is omitted at all, no filtering is applied.";
    Help[OP_SVD     ]   = "Apply the SVD-filter and set the number of SVD components that are taken from the data. If this option is set, the band-pass filter and the minimum time window parameters are ignored. If -SVD is not set at all, no SVD filters will be applied.";    
    Help[OP_PREPRO  ]   = "Before filtering the data using the band-pass or SVD option, you can substract the offset and/or remove the trend from the data. This pre-processing can be applied upon the selected time epochs themselves, or upon time epochs related to these epochs (pre-processing epochs).  0=No preprocessing, 1=offset removal using the selected epochs, 2=offset and trend removal using the selected epochs, 3=offset removal using preprocessing epochs, 4=trend removal using preprocessing epochs. 5=offset removal using pre-stimulus interval. 6=trendremoval using pre-stimulus interval. Note1: This preprocessing is applied in each selected epoch and on each channel individually, before band-pass c.q. SVD filtering.";
    Help[OP_PREEPOCH]   = "You can set the pre-processing epochs by giving the number of samples that the first samples of each analysis epoch have to be shifted to obtain the begin and end sample of the pre-processing window. When the given shift of the end sample is smaller than the shift of the begin samples, the pre-trigger windows are used.";
    Help[OP_MEGRREF ]   = "You can transform the MEG data to another reference: -1: Keep the data as is, 0: Make MEG data unbalanced, 1: Compute MEG data w.r.t. first gradient, 2: Compute MEG data w.r.t. second gradient, 3: Compute MEG data w.r.t. third gradient .";
    Help[OP_EEGRREF ]   = "You can transform the EEG data to average reference: -1: Keep the data as is, 0: Compute EEG data withrespect to average reference.";

    Option[OP_RSEFART ] = UOption("RSA","RemStimArt",Help[OP_RSEFART]);
    Option[OP_REM50HZ ] = UOption("RPL","RemPowLin",Help[OP_REM50HZ]);
    Option[OP_FBANDP  ] = UOption("Bpf","BandPass",Help[OP_FBANDP],-1.,10000.,1.,30.);
    Option[OP_SVD     ] = UOption("SVD","SVD-filter",Help[OP_SVD],0,100,2);
    Option[OP_PREPRO  ] = UOption("Pre","Pre-process",Help[OP_PREPRO],0,6,0);
    Option[OP_PREEPOCH] = UOption("PPe","PPepochs",Help[OP_PREEPOCH],-1000,1000,0,0);
    Option[OP_MEGRREF ] = UOption("Mrr","MEGreref",Help[OP_MEGRREF],-1,3,-1);
    Option[OP_EEGRREF ] = UOption("Err","EEGreref",Help[OP_EEGRREF],-1,0, 0);
}

ErrorType USetEpochs::ArgumentsToObject(UMEEGDataEpochs *EpDat)
{
    if(EpDat->GetError()!=U_OK)  
    {
        CI.AddToLog("\nErrors in File names\n");
        return U_ERROR;
    }
    bool EpSam = Option[OP_SAMPLE ].GetValueSet();
    bool EpWid = Option[OP_MWIDTH ].GetValueSet();
    bool EpRan = Option[OP_MRANGE ].GetValueSet();
    bool EpOff = Option[OP_MOFFSET].GetValueSet();
    if(EpWid==false && EpRan==false && EpOff==false) EpSam = true;

    if( (EpSam==true && (EpWid==true || EpRan==true || EpOff==true)) ||
        (EpWid==true && (EpRan==true || EpOff==true || EpSam==true)) ||
        (EpRan==true && (EpOff==true || EpSam==true || EpWid==true)) ||
        (EpOff==true && (EpSam==true || EpWid==true || EpRan==true)) )
    {
        CI.AddToLog("ERROR: Epochs definition set ambiguiously. \n");
        CI.AddToLog("       Either use the same samples from each trial (-%s),\n",Option[OP_SAMPLE].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs symmetrically around these markers (-%s),\n",Option[OP_MWIDTH].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs shifted w.r,t. these markers (-%s),\n",Option[OP_MOFFSET].GetIdentifier());
        CI.AddToLog("       or use the CTF begin and end-markers to select epochs (-%s).\n",Option[OP_MRANGE].GetIdentifier());
        CI.PressReturnExit();
    }

    if(Option[OP_MNAME].GetValueSet()==true   &&
       EpRan==false  &&
       EpWid==false  &&
       EpOff==false)
    {
        CI.AddToLog("WARNING: Marker name (=%s) set, without setting -mr, -mh or -mo\n",Option[OP_MNAME ].GetString());
    }

/* Select the epochs */
    const char* MarkerName = Option[OP_MNAME ].GetString();
    if(EpRan==true)     // use "range markers"
    {        
        if(EpDat->SetEpochsMarker(MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MRANGE].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpWid==true) // halfwidt set
    {
        int halfwidth = Option[OP_MWIDTH].GetValue();
        if(EpDat->SetEpochsMarker(halfwidth, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MWIDTH].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpOff==true)
    {
        int boff = Option[OP_MOFFSET].GetValue1();
        int eoff = Option[OP_MOFFSET].GetValue2();

        if(EpDat->SetEpochsMarker(boff, eoff, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MOFFSET].GetIdentifier());
            return U_ERROR;
        }
    }
    else // DEFAULT: fixed sample range from all trials
    {
        int startsample = Option[OP_SAMPLE].GetValue1();
        int endsample   = Option[OP_SAMPLE].GetValue2();
        if(EpDat->SetEpochs(startsample, endsample)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_SAMPLE].GetIdentifier());
            return U_ERROR;
        }
    }

    if(EpDat->GetError()!=U_OK)
    {
        CI.AddToLog("Errors in setting epochs.\n");
        return U_ERROR;
    }
    
/* Exclude epochs:*/
    if(Option[OP_SUBEPOCH].GetValueSet()==true)
    {
        int Ntake  = Option[OP_SUBEPOCH].GetValue1();
        int Nphase = Option[OP_SUBEPOCH].GetValue2();
        if(EpDat->SubsampleEpochs(Ntake, Nphase)!=U_OK)
        {
            CI.AddToLog("ERROR in sub-sampling epochs. Ntake = %d and Nphase = %d.\n",Ntake,Nphase);
            return U_ERROR;
        }
    }
    int starttrial = Option[OP_TRIALS].GetValue1();
    int endtrial   = Option[OP_TRIALS].GetValue2();
    
    if(EpDat->ExcludeTrials(starttrial, endtrial) !=U_OK)
    {
        CI.AddToLog("Errors excluding trials.\n");
        return U_ERROR;
    }
    if(Option[OP_EXTRIAL].GetValueSet()==true)
    {
        const char* TrialName = Option[OP_EXTRIAL].GetString();
        if(EpDat->ExcludeTrialClass(TrialName)!=U_OK)
        {
            CI.AddToLog("ERROR in processing Excluding trials named %s\n",TrialName);
            return U_ERROR;
        }
    }
    if(Option[OP_EXMNAME ].GetValueSet()==true)
    {
        const char* MarkerName = Option[OP_EXMNAME ].GetString();
        int         width      = Option[OP_EXMWIDTH].GetValue();
        if(Option[OP_EXMEPOCH].GetBOOL()==true)
        {
            if(EpDat->ExcludeEpochs(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d epochs,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
        else
        {
            if(EpDat->ExcludeSamples(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d samples,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
    }
    if(Option[OP_EXOVERL].GetBOOL()==true)  
    {
        if(EpDat->ExcludeOverlapping()!=U_OK)
        {
            CI.AddToLog("ERROR in excluding overlapping epochs.\n");
            return U_ERROR;
        }
    }

/* Set the filter parameters:*/
    UPreProType Prep = U_PREP_NO;
    bool PreProEp     = false;
    bool ForcePreStim = false;
    switch(Option[OP_PREPRO].GetValue())
    {
    case 0: Prep     = U_PREP_NO; 
            PreProEp = Option[OP_PREEPOCH].GetValueSet();
            break;
    case 1: Prep = U_PREP_OFFSET;    PreProEp = false; break;
    case 2: Prep = U_PREP_TREND;     PreProEp = false; break;
    case 3: Prep = U_PREP_OFFSET;    PreProEp = true;  break;
    case 4: Prep = U_PREP_TREND;     PreProEp = true;  break;
    case 5: Prep = U_PREP_OFFSET;    PreProEp = true;  ForcePreStim = true; break;
    case 6: Prep = U_PREP_TREND;     PreProEp = true;  ForcePreStim = true; break;
    default:
        CI.AddToLog("ERROR: Invalid pre-processing parameter: %d .\n",Option[OP_PREPRO].GetValue());
        return U_ERROR;
    }

    if(PreProEp==true && (Option[OP_PREEPOCH].GetValueSet()==true || ForcePreStim==true))
    {
        int BeginOffset = Option[OP_PREEPOCH].GetValue1();
        int EndOffset   = Option[OP_PREEPOCH].GetValue2();
        if(ForcePreStim==true && Option[OP_PREEPOCH].GetValueSet()==true && BeginOffset<=EndOffset)
        {
            CI.AddToLog("ERROR: Forcing pre-stimulus interval is in conflict with the given pre-processing parameters.\n");
            return U_ERROR;
        }
        else if(ForcePreStim==true)
        {
            BeginOffset =  0;
            EndOffset   = -1;
        }
        if(EpDat->SetPreProcessingEpochs(BeginOffset, EndOffset)!=U_OK)
        {
            CI.AddToLog("ERROR in setting pre-processing epochs.\n");
            return U_ERROR;
        }        
    }
    else if(PreProEp==true)
    {
        CI.AddToLog("ERROR: You have chosen to use pre-processing windows without selecting them.\n");
        return U_ERROR;
    }
    
    if(EpDat->SetSEFCorrection(Option[OP_RSEFART ].GetBOOL(), NULL, -2, 6)!=U_OK) //// Correct????
    {
        CI.AddToLog("ERROR: Setting the remove stimulus artifact option.\n");
        return U_ERROR;
    }
    bool      PowerLine = Option[OP_REM50HZ].GetBOOL();
    double    PLWitdth  = 2.;
    UPowerLineType PWL  = PowerLine ? U_POWERLINE_50 : U_POWERLINE_NO;

    if(Option[OP_SVD].GetValueSet()==true)
    {
        int            Ncomp = Option[OP_SVD ].GetValue();
        EpDat->SetFilter(Ncomp, Prep, PWL, PLWitdth,1.);
    }
    else if(Option[OP_FBANDP].GetValueSet()==true)
    {
        double Fmin = Option[OP_FBANDP ].GetDubVal1();
        double Fmax = Option[OP_FBANDP ].GetDubVal2();
        EpDat->SetFilter(Fmin, Fmax, Prep, PWL, PLWitdth, false, 1.);    
    }
    else
        EpDat->SetFilter(Prep, PWL, PLWitdth, false, 1.);  

    ReReferenceType MEGreref = U_REF_RAW;
    switch(Option[OP_MEGRREF ].GetValue())
    {
    case -1: MEGreref = U_REF_RAW;         break;
    case  0: MEGreref = U_REF_UNBALANCED;  break;
    case  1: MEGreref = U_REF_FIRST;       break;
    case  2: MEGreref = U_REF_SECOND;      break;
    case  3: MEGreref = U_REF_THIRD;       break;
    default: CI.AddToLog("ERROR: Invalid MEG re-referencing parameter: %d \n", Option[OP_MEGRREF ].GetValue()); 
        return U_ERROR;
    }
    ReReferenceType EEGreref = U_REF_AVERAGE;
    switch(Option[OP_EEGRREF ].GetValue())
    {
    case -1: EEGreref = U_REF_RAW;         break;
    case  0: EEGreref = U_REF_AVERAGE;     break;
    default: CI.AddToLog("ERROR: Invalid EEG re-referencing parameter: %d \n", Option[OP_EEGRREF ].GetValue()); 
        return U_ERROR;
    }
    return EpDat->SetRereference(MEGreref, EEGreref);
}

UGridFit* GetBestGrid(UMEEGDataEpochs** EpDatAr, int Nsets, UEuler* BestEuler, UEuler* Dewar2Best, double* ResError, const UGrid* DefaultGrid)
{

    if(EpDatAr==NULL || Nsets<=0 || BestEuler==NULL || Dewar2Best==NULL)
    {
        CI.AddToLog("ERROR: GetBestGrid(). Erroneous arguments. Nsets = %d \n", Nsets);
        return NULL;
    }

    if(EpDatAr[0]->GetData()->GetGridMEG()==NULL)
    {
        CI.AddToLog("ERROR: GetBestGrid(). No MEG grid in first data file. \n");
        return NULL;
    }

    UGridFit* BGrid = new UGridFit(*(EpDatAr[0]->GetData()->GetGridMEG()));
    if(BGrid==NULL || BGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetBestGrid(). Copying first MEG grid. \n");
        return NULL;
    }

/* Fill Euler array*/
    UEuler  Head2Dewar = (EpDatAr[0]->GetData()->GetDewar2NLR()).Invert(); 
    UEuler* EulerArray = new UEuler[Nsets];
    if(EulerArray==NULL)
    {
        CI.AddToLog("ERROR: GetBestGrid(). Memory alocation in Euler array. Nsets = %d .\n", Nsets);
        delete BGrid;
        return NULL;
    }
    for(int is=1; is<Nsets;is++)
    {
        UEuler D2W     = EpDatAr[is]->GetData()->GetDewar2NLR();
        EulerArray[is] = D2W*Head2Dewar;
    }

    double residual;
    *BestEuler = BGrid->FitGridEuler(EulerArray, Nsets, &residual, DefaultGrid);
    if(residual<0)
    {
        CI.AddToLog("ERROR: GetBestGrid(). Fitting Euler transform. \n");
        delete BGrid;
        return NULL;
    }
    if(ResError) *ResError = residual;

    *Dewar2Best = (*BestEuler) * EpDatAr[0]->GetData()->GetDewar2NLR();

    BGrid->Transform(*BestEuler);

    return BGrid;
}

bool CanbeConcatenated(UMEEGDataEpochs** EpDatAr, int Nsets, bool *ExportEEG, bool *ExportADC)
{
    if(EpDatAr==NULL || Nsets<=0 || ExportEEG==NULL || ExportADC==NULL)
    {
        CI.AddToLog("ERROR: CanbeConcatenated(). Erroneous arguments. Nsets = %d \n", Nsets);
        return false;
    }

    int    nsamp = EpDatAr[0]->GetNSampEpoch(0);
    double srate = EpDatAr[0]->GetData()->GetSampleRate();
    int    nEEG  = EpDatAr[0]->GetData()->GetNeeg();
    int    nADC  = EpDatAr[0]->GetData()->GetNADC();
    bool   STIM  = EpDatAr[0]->GetData()->GetStim();
    ReReferenceType RefMEG = EpDatAr[0]->GetMEGReref();
    ReReferenceType RefEEG = EpDatAr[0]->GetEEGReref();

    bool CanbeCat = true;
    for(int is=1; is<Nsets; is++)
    {
        if(nsamp!=EpDatAr[is]->GetNSampEpoch(0))
        {
            CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate MEG data because nsamp in dataset 0 and dataset %d are different: %d and %d .\n", is, nsamp, EpDatAr[is]->GetNSampEpoch(0));
            CanbeCat = false;
            break;
        }
        if(srate!=EpDatAr[is]->GetData()->GetSampleRate())
        {
            CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate MEG data because sample rate in dataset 0 and dataset %d are different: %f and %f .\n", is, srate, EpDatAr[is]->GetData()->GetSampleRate());
            CanbeCat = false;
            break;
        }
        if(RefMEG != EpDatAr[is]->GetMEGReref())
        {
            CI.AddToLog("Note: CanbeConcatenated(). Concatenated data have different MEG references. In dataset 0 and  %d references are: %d and %d .\n", is, RefMEG, EpDatAr[is]->GetMEGReref());
        }
        if(*ExportEEG == true && nEEG!=EpDatAr[is]->GetData()->GetNeeg())
        {
            CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate EEG data because nEEG in dataset 0 and dataset %d are different: %d and %d .\n", is, nEEG, EpDatAr[is]->GetData()->GetNeeg());
            *ExportEEG  = false;
        }
        if(*ExportEEG == true && RefEEG != EpDatAr[is]->GetEEGReref())
        {
            CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate EEG data because EEG references in dataset 0 and dataset %d are different: %d and %d .\n", is, RefEEG, EpDatAr[is]->GetEEGReref());
            *ExportEEG  = false;
        }
        if(*ExportADC == true && nADC!=EpDatAr[is]->GetData()->GetNADC())
        {
            CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate ADC data because nADC in dataset 0 and dataset %d are different: %d and %d .\n", is, nADC, EpDatAr[is]->GetData()->GetNADC());
            *ExportADC  = false;
        }
    }

/* Test EEG sensor positions */
    if(CanbeCat==true && *ExportEEG==true)
    {
        for(int i=0; i<nEEG; i++)
        {
            USensor S0 = EpDatAr[0]->GetData()->GetGridEEG()->GetSensor(i);
            for(int is=1; is<Nsets; is++)
            {
                USensor Si = EpDatAr[is]->GetData()->GetGridEEG()->GetSensor(i);
                if( (S0==Si)==false )
                {
                    CI.AddToLog("Note: CanbeConcatenated(). Cannot concatenate EEG because electrode %d in dataset 0 and dataset %d are different:\n",i, is);
                    CI.AddToLog("Note: %s and %s \n", S0.GetProperties(), Si.GetProperties());

                    *ExportEEG  = false;
                    break;
                }
            }
            if(*ExportEEG==false) break;
        }
    }
    if(nEEG <= 0)    *ExportEEG =false;
    if(nADC <= 0)    *ExportADC =false;
    return CanbeCat;    
}

UMarkerArray* CreateZeroMarkers(const UMEEGDataEpochs* const* EpdatAr, int Nset, const char* Name)
{
    if(EpdatAr==NULL || EpdatAr[0]==NULL || Nset<=0)
    {
        CI.AddToLog("ERROR: CreateZeroMarkers(). Invalid NULL argument(s). \n");
        return NULL;
    }

/* Test if the follwing parameters are equal for all data sets:*/ 
    int    nSampTrial = EpdatAr[0]->GetNSampEpoch(0);
    double SRate      = EpdatAr[0]->GetData()->GetSampleRate();

    int NtotSamp = EpdatAr[0]->GetNEpoch();
    for(int k=1; k<Nset; k++)
    {
        if(EpdatAr[k]==NULL)
        {
            CI.AddToLog("ERROR: CreateZeroMarkers(). Invalid NULL UMEEGDataEpochs* in data set %d. \n", k);
            return NULL;
        }
        if(nSampTrial != EpdatAr[0]->GetNSampEpoch(0))
        {
            CI.AddToLog("ERROR: CreateZeroMarkers(). Number of samples per trial in data set 0 (%d) does not match that in data set %d. \n", nSampTrial, k);
            return NULL;
        }
        if(SRate != EpdatAr[k]->GetData()->GetSampleRate())
        {
            CI.AddToLog("ERROR: CreateZeroMarkers(). Sample frequency in data set 0 (%f) does not match that in data set %d. \n", SRate, k);
            return NULL;
        }
        NtotSamp += EpdatAr[k]->GetNEpoch();
    }

    UMarkerArray* ZeroMark = NULL;
    if(Name==NULL || Name[0]==0)
    {
        ZeroMark = new UMarkerArray(Nset, nSampTrial, 0, SRate);
        if(ZeroMark==NULL || ZeroMark->GetError()!=U_OK)
        {
            delete ZeroMark;
            CI.AddToLog("ERROR: CreateZeroMarkers(). Creating default marker array. \n");
            return NULL;
        }

        int itrial = 0;
        for(int k=0; k<Nset; k++)
        {
            UFileName F(EpdatAr[k]->GetData()->GetDataFileName());
            F.ReplaceExtension(NULL);
            const char* name = F.GetBaseName();
            int        nsamp = EpdatAr[k]->GetNEpoch();
            UString Comment(k, "DataSet_%d");
            UMarker Mark(name, nsamp, nSampTrial, 0, Comment, 0, true);
            if(Mark.GetError()!=U_OK)
            {
                delete ZeroMark;
                CI.AddToLog("ERROR: CreateZeroMarkers(). Creating marker %d. \n",k);
                return NULL;
            }
            for(int j=0; j<nsamp; j++)
            {
                UEvent E(itrial++, 0);
                Mark.SetEvent(j, E);
            }
            if(ZeroMark->SetMarker(Mark, k)!=U_OK)
            {
                delete ZeroMark;
                CI.AddToLog("ERROR: CreateZeroMarkers(). Copying marker %d. \n",k);
                return NULL;
            }
        }
    }
    else // create one marker with the same name Name[] for all trials
    {
        ZeroMark = new UMarkerArray(1, nSampTrial, 0, SRate);
        if(ZeroMark==NULL || ZeroMark->GetError()!=U_OK)
        {
            delete ZeroMark;
            CI.AddToLog("ERROR: CreateZeroMarkers(). Creating default marker array. \n");
            return NULL;
        }

        int NTotTrial = 0;
        for(int k=0; k<Nset; k++) NTotTrial += EpdatAr[k]->GetNEpoch();

        UMarker Mark(Name, NTotTrial, nSampTrial, 0, CI.GetProgName(), 0, true);
        if(Mark.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: CreateZeroMarkers(). Creating marker named %s. \n",Name);
            delete ZeroMark;
            return NULL;
        }

        int itrial = 0;
        for(int k=0; k<Nset; k++)
        {
            int nsamp = EpdatAr[k]->GetNEpoch();
            for(int j=0; j<nsamp; j++, itrial++)
            {
                UEvent E(itrial, 0);
                Mark.SetEvent(itrial, E);
            }
        }
        if(ZeroMark->SetMarker(Mark, 0)!=U_OK)
        {
            delete ZeroMark;
            CI.AddToLog("ERROR: CreateZeroMarkers(). Copying marker. \n");
            return NULL;
        }
    }
    return ZeroMark;
}
