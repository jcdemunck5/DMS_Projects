/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to concatenate MM data and insert zeroes.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    22-11-05   creation
  JdM    27-06-07   Automated programmme and Added NShift
  JdM    14-12-07   Converted from Test program into command line application
  JdM    23-04-08   Set ReReference() to U_REF_RAW.
  JdM    24-04-08   Bug fix: Determine number of null-trials by rounding off to nearest int
                    FT[k].NNullEpo = int( floor(0.5+(TDelta)/TEpoch));
*/
 
#define VERSION "1.11 "
#define AUTHOR  "Dr. JC de Munck, VUmc dept. PMT, Amsterdam"


#include <string.h>

#include "../../Option.h"
#include "../../MEEGDataEpochs.h"
#include "../../MEEGDataMM.h"
#include "../../MEEGDataWriteCTF.h"
#include "../../MarkerArray.h"
#include "../../Marker.h"
#include "../../Directory.h"
 
#define NEVENTNAM 3
const char* EventNames[NEVENTNAM] = {"_F1","Bit0","Bit1"};


#ifdef WIN32
static enum
#else
enum
#endif
{
    OP_FILEIN,OP_DSDIROUT,OP_NMMFILES,OP_EVENTSHIFT,OP_NBAD,OP_NTRIALOUT,
    NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];


typedef struct
{
    int StartSec;
    int SampFirstEpoch;
    int NEpoch;
    int NNullEpo;
    int IevName;
} FileTiming;

int main(int Nargs, char **Args)
{                   
    char* Intro  = "This programme concatenates a series of MicroMed EEG files and exports \n"
                   "the result in the format of a CTF data set. \n"
                   "Notes:\n"
                   "-Trials are created by assuming the MM files contain an equidistant set of events (Bit0 or Bit1).\n";
                   " Data following these events are put in subsequent trials. \n"
                   "-It is assumed the all MM files exist in the same directory and are consecutively numbered.\n";
                   "-Missing data, determined on the basis of MM header information (start time and number of samples)\n"
                   " is replaced by zero data.\n"
                   "-New files and zeroes are indicated with marker in the output data set.\n";

        
    Help[OP_FILEIN     ] = "Name of the first MM data file to be concatenated and converted.";
    Help[OP_DSDIROUT   ] = "Name of the CTF data set directory to be created and to stored the output data.";
    Help[OP_NMMFILES   ] = "Number of MM files to be concatenated.";
    Help[OP_EVENTSHIFT ] = "All Bit0 or Bit1 events are shifted before making trials, over the number of samples given here. Both positive and negative shifts are allowed.";
    Help[OP_NBAD       ] = "Give the number trials that are marked as BAD at the start of each concatenated MM file (not including the first file). ";
    Help[OP_NTRIALOUT  ] = "Total number of trials in output file (needed to compute number of ending zeroes).";
    
    Option[OP_FILEIN     ] = UOption("FirstMMFile",Help[OP_FILEIN ],UOption::FILENAME);
    Option[OP_DSDIROUT   ] = UOption("OutputDS",Help[OP_DSDIROUT],UOption::DATASETNAME);
    Option[OP_NMMFILES   ] = UOption("NMM"  ,"NFiles",Help[OP_NMMFILES],1,100,2);
    Option[OP_EVENTSHIFT ] = UOption("Sft"  ,"Shift",Help[OP_EVENTSHIFT],-10000,10000,0);
    Option[OP_NBAD       ] = UOption("Nbd"  ,"NBAD",Help[OP_NBAD],1,100,3);
    Option[OP_NTRIALOUT  ] = UOption("Ntr"  ,"Ntrials",Help[OP_NTRIALOUT],1,10000,600);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    const char* FirstMM    = Option[OP_FILEIN     ].GetFileName();
    const char* DSout      = Option[OP_DSDIROUT   ].GetFileName();
    int         NFileIn    = Option[OP_NMMFILES   ].GetValue();
    int         NShift     = Option[OP_EVENTSHIFT ].GetValue();
    int         NEpochOut  = Option[OP_NTRIALOUT  ].GetValue();
    
    if(FirstMM==NULL)
    {
        CI.AddToLog("ERROR: Wrong input file name.\n");
        CI.PressReturnExit();
    }
    UFileName FFirst(FirstMM);
    int FirstNumb = FFirst.GetNumberBeforeExtension(-1);
    int NDigit    = FFirst.GetNDigitBeforeExtension();
    if(FirstNumb<0 || NDigit<=0)
    {
        CI.AddToLog("ERROR: Input file is not a numbered MM file (%s).\n", (const char*)FFirst);
        CI.PressReturnExit();
    }
   
    if(DSout==NULL)
    {
        CI.AddToLog("ERROR: Wrong output data set name.\n");
        CI.PressReturnExit();
    }
    if(NFileIn<=0)
    {
        CI.AddToLog("ERROR: Wrong number of input files (%d).\n", NFileIn);
        CI.PressReturnExit();
    }
    if(NEpochOut<=0)
    {
        CI.AddToLog("ERROR: Wrong number of output trials (%d).\n", NEpochOut);
        CI.PressReturnExit();
    }
    FileTiming* FT     = new FileTiming[NFileIn];
    if(FT==NULL)
    {
        CI.AddToLog("ERROR: Memory allocation (%d).\n", NFileIn);
        CI.PressReturnExit();
    }

    double*     NullEp = NULL;    

    UMEEGDataWriteCTF Output;
    UMarker           OutMarTrial;
    UMarker           OutMarZero;
    UMarker           OutMarBad;
    UMarker           OutMarStart;
    UMarker*          OutMarInputFile = new UMarker[NFileIn];

    double      TEpoch = -1.;
    double      TSamp  = -1.;
    int         NChan  = -1;
    int         NSamp  = -1;
    ErrorType   error  = U_OK;
    for(int k=0; k<NFileIn; k++)
    {
        UFileName File = FFirst;
        File.ReplaceNumberBeforeExtension(FirstNumb+k, NDigit);

        UMEEGDataMM  DatMM(File);
        if(DatMM.GetError()!=U_OK)
        {
            error = U_ERROR;
            break;
        }

        FT[k].IevName  = - 1;
        UMarker Mar;
        for(int iev=0; iev<NEVENTNAM; iev++)
        {
            Mar = UMarker(*DatMM.GetMarkerArray()->GetMarker(EventNames[iev]));
            if(Mar.GetError()==U_OK && !(k>0&&Mar.GetMedianInterval()!=NSamp))  
            {
                FT[k].IevName = iev;
                break;
            }
        }
        if(FT[k].IevName<0)
        {
            CI.AddToLog("ERROR: No markers of the name ");
            for(int iev=0; iev<NEVENTNAM; iev++) CI.AddToLog("%s  , ", EventNames[iev]);
            CI.AddToLog(" \n");
            error = U_ERROR;
            break;
        }        

        DatMM.ConvertDataType(U_DAT_UNKNOWN, U_DAT_EEG);
        if(k==0) 
        {
            NSamp  = Mar.GetMedianInterval();
            NChan  = DatMM.GetNeeg();
            TSamp  = DatMM.GetSampleTime_s();
            TEpoch = NSamp*TSamp;
            NullEp = new double[NChan*NSamp];
            for(int ij=0; ij<NChan*NSamp; ij++) NullEp[ij] = 0.;

            Output = UMEEGDataWriteCTF((const UMEEGDataBase&)DatMM);
            Output.SetDataFileName(UFileName(DSout)); 
            Output.SetPreNTriggerPnts(0);        
            Output.SetNsampTrial(NSamp);         
            Output.SetNtrial(NEpochOut);                 
            OutMarTrial = UMarker("Trial"  , 0, NSamp, 0, "Begin Trial", 0, false);
            OutMarZero  = UMarker("Zeroes"  , 0, NSamp, 0, "Zero Trial"  , 0, false);
            OutMarBad   = UMarker("BAD "  , 0, NSamp, 0, "Bad Trial"  , 0, false);
            OutMarStart = UMarker("NewFile", 0, NSamp, 0, "Begin File" , 0, false); 
            if(OutMarInputFile)
                for(int k=0; k<NFileIn; k++)
                {
                    UString Name(FirstNumb+k,"MM_%4.4d");
                    OutMarInputFile[k] = UMarker((const char*)Name, 0, NSamp, 0, "MM_File" , 0, false);
                }                    
        }
        if(NChan!=DatMM.GetNeeg() || TSamp!=DatMM.GetSampleTime_s())
        {
            CI.AddToLog("ERROR: Invalid Neeg (%d) or Tsamp (%f) \n", DatMM.GetNeeg(), DatMM.GetSampleTime_s());
            error = U_ERROR;
            break;
        }
        if(Mar.GetMaxInterval()-Mar.GetMinInterval()>2)
        {
            CI.AddToLog("ERROR: Events not equidistant in data set %s \n", (const char*)DatMM.GetDataFileName());
            error = U_ERROR;
            break;
        }

        
        int   NTotSamp        = DatMM.GetNtrial() * DatMM.GetNsampTrial();
        FT[k].StartSec        = int(DatMM.GetDateTime().GetTimeOfDayInSec());
        FT[k].SampFirstEpoch  = Mar.GetAbsSample(0);
        FT[k].NEpoch          = 0;
        for(int n=0; n<Mar.GetnEvents(); n++)
            if(Mar.GetAbsSample(n)+NSamp<=NTotSamp) 
                FT[k].NEpoch   = n+1;

        if(k==0 && FT[k].NEpoch<=0)
        {
            CI.AddToLog("ERROR: No good epochs for first data file. \n");
            error = U_ERROR;
            break;
        }
        CI.AddToLog("Note: Tested file %s \n", (const char*)DatMM.GetDataFileName());
    }
    if(error!=U_OK)
    {
        delete[] FT;
        delete[] NullEp;
        CI.PressReturnExit(true);
    }
    int NEpochCount = 0;
    for(int k=0; k<NFileIn; k++)
    {
        if(k<NFileIn-1)
        {
            int kk = k+1;
            while(kk<NFileIn-1)
                if(FT[kk].NEpoch<=0) kk++;
                else                 break;

            double StartEpk = FT[k ].StartSec+FT[k ].SampFirstEpoch*TSamp; 
            double StartEpkk= FT[kk].StartSec+FT[kk].SampFirstEpoch*TSamp; 
            double TDelta   = StartEpkk - (StartEpk + FT[k].NEpoch*TEpoch);
            if(TDelta<0)
            {
                CI.AddToLog("ERROR: Invalid onset times in files %d and %d \n", FirstNumb+k, FirstNumb+kk);
                error = U_ERROR;
                break;
            }
            FT[k].NNullEpo = int( floor(0.5+(TDelta)/TEpoch));  // Test 24-04-08 Round off to nearest int (instead of lower int)
            NEpochCount   += FT[k].NEpoch + FT[k].NNullEpo;

            if(fabs(FT[k].NNullEpo*TEpoch - TDelta)>1.)
            {
                CI.AddToLog("WARNING: Round-off error of time between files larger than 1 s. (File=%d)\n", FirstNumb+k);
            }

            k+= (kk-1-k);
        }
        else
        {
            NEpochCount   += FT[k].NEpoch;
            FT[k].NNullEpo = NEpochOut-NEpochCount;
            if(FT[k].NNullEpo<0)
            {
                CI.AddToLog("ERROR: Invalid total number of epochs (NEpochCount=%d) \n", NEpochCount);
                error = U_ERROR;
                break;
            }
        }
    }

    UString Comment("k \tFile \tStartSec \tFirstSamp \tNEpoch \tNNull \tRoundOff [s]\n");
    for(int k=0; k<NFileIn; k++)
    {
        Comment += UString(k             ,"  %d ") + UString(FirstNumb+k           ,"\t%d ");
        Comment += UString(FT[k].StartSec,"\t%d ") + UString(FT[k].SampFirstEpoch,"\t%d ");
        Comment += UString(FT[k].NEpoch  ,"\t%d ") + UString(FT[k].NNullEpo        ,"\t%d ");
        if(k+1<NFileIn)
        {
            double StartEpk = FT[k  ].StartSec+FT[k  ].SampFirstEpoch*TSamp; 
            double StartEpkk= FT[k+1].StartSec+FT[k+1].SampFirstEpoch*TSamp; 
            double TDelta   = StartEpkk - (StartEpk + FT[k].NEpoch*TEpoch);
            double RoundOff = FT[k].NNullEpo*TEpoch - TDelta;
            Comment += UString(RoundOff  ,"\t%f ");
        }
        Comment += UString("\n");
    }
    CI.AddToLog((const char*)Comment);

    Output.AddComment((const char*)Comment);
    Output.WriteHeader();

    if(error!=U_OK)
    {
        delete[] FT;
        delete[] NullEp;
        CI.PressReturnExit(true);
    }

    int Nwrite = 0;
    for(int k=0; k<NFileIn; k++)
    {
        if(FT[k].NEpoch<=0) continue;

        UFileName File = FFirst;
        File.ReplaceNumberBeforeExtension(FirstNumb+k, NDigit);
        UMEEGDataEpochs Edat(File);
        
        UMarker   Mar(*Edat.GetMarkerArray()->GetMarker(EventNames[FT[k].IevName]));

        Edat.ConvertDataType(U_DAT_UNKNOWN, U_DAT_EEG);
        Edat.SetEpochsMarker(NShift, NSamp-1+NShift, &Mar);
        Edat.SetRereference(U_REF_RAW, U_REF_RAW);

        for(int iep=0 ;iep<Edat.GetNEpoch(); iep++, Nwrite++)
        {
            double* Data = Edat.GetFilteredData(iep, U_DAT_EEG);
            Output.WriteTrial(Data, U_DAT_EEG, Nwrite);
            delete[] Data;

            OutMarTrial.AddEvent(UEvent(Nwrite, 0));
            if(iep==0) OutMarStart.AddEvent(UEvent(Nwrite, 0));
            if(OutMarInputFile)
                OutMarInputFile[k].AddEvent(UEvent(Nwrite, 0));

            CI.AddToLog("%d of %d  \n", iep, Edat.GetNEpoch());
        }
        CI.AddToLog("Number of trials written: %d  \n", Nwrite);
        for(int iep=0 ;iep<FT[k].NNullEpo; iep++, Nwrite++)
        {
            Output.WriteTrial(NullEp, U_DAT_EEG, Nwrite);
            OutMarTrial.AddEvent(UEvent(Nwrite, 0));
            OutMarZero.AddEvent(UEvent(Nwrite, 0));
            OutMarBad.AddEvent(UEvent(Nwrite, 0));
            if(OutMarInputFile)
                OutMarInputFile[k].AddEvent(UEvent(Nwrite, 0));
        }
        for(int iep=0; iep<Option[OP_NBAD].GetValue(); iep++)
            if(Nwrite+iep<NEpochOut)
                OutMarBad.AddEvent(UEvent(Nwrite+iep, 0));

        CI.AddToLog("Number of trial written: %d  (default data)\n", Nwrite);
    }
    
    UMarkerArray Mar(0, NSamp, 0, 1./TSamp);
    Mar.AddMarker(&OutMarTrial);
    Mar.AddMarker(&OutMarStart);
    Mar.AddMarker(&OutMarZero );
    Mar.AddMarker(&OutMarBad  );
    if(OutMarInputFile)
        for(int k=0; k<NFileIn; k++)
                Mar.AddMarker(&OutMarInputFile[k] );

    Output.WriteMarkerArray(&Mar);


    delete[] FT;
    delete[] NullEp;
    delete[] OutMarInputFile;
    
    return 0;
}


