/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to compute (cross) spectra.                                       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    14-02-99   creation
  JdM    04-04-99   Added the option to exclude trials from the analysis
  JdM    15-04-99   Added the option to use named markers
  Jdm    20-04-99   Export Introduction text to .bat-file
  GdV    20-05-99   Adopted to Unix
  JdM    07-08-99   Use global UConsoleInterface()-object CI
  JdM    27-08-99   Added option to export results in CTF data format and to exclude 
                    overlapping (expanded) epochs.
  JdM    13-09-99   Release the constraint that time segments have 2**n samples
  JdM    03-10-00   Add option to export results as Map data 
  JdM    20-10-00   Allow for standard EEG bands, and allow computation of coherence
  JdM    07-11-00   Allow for setting time sample ranges
  JdM    13-02-01   Add an option for pre-processing the data
  JdM    16-05-01   Copy mechanism to set epochs from CovarEstim. Note that there are slight changes in functionality
                    Allow wild cards in CTF dataset name
  JdM    17-08-01   Added re-referencing of MEG/EEG data
  JdM    11-11-01   Allow multiple overriding good and bad channels
  JdM    14-06-02   Apply standard input functions for data pre-processing and filtering.
  JdM    08-07-02   Allow removal of powerline noise and SEF artefacts
  JdM    09-10-02   Add option to remove complete epochs based on overlapping with markers
                    Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    15-01-03   Bug fix: testing the setting of samples ranges (if(EpWid==false && EpRan==false && EpOff==false) EpSub = true;)
  JdM    15-04-03   Coherencies can be exported as .map file
  JdM    23-04-03   Increased sample boundaries
  JdM    03-06-03   Added the option to compute cross coherencies
  JdM    21-02-06   UPreProType are now defined globally in stead of enums of ULinearFilter
  JdM    10-04-08   MAJOR UPDATE. Adapted sources to new directory structure (PMT_Projects iso MCAProjects_6)
  JdM    29-04-08   Bug Fix: Channel section from string on command line
  JdM    08-05-08   Used new function to select channel types and good/bad channels
                    Make summary .map file
  JdM    24-07-12   Made const char* DataSetName a UDirectory object, to avoid ambiguities in UMEEGDataEpochs constructor
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include <stdlib.h>
 
#include "../SetUpMEEGDataEpochs.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../Option.h"
#include "../../MEEGDataEpochs.h"
#include "../../FieldGraph.h"
#include "../../SensorCorrelate.h"
#include "../../MapFile.h"
#include "../../Grid.h"

#define VERSION "1.16 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUMC, Amsterdam"
 
#ifdef WIN32
static enum
#else
enum
#endif
{
    OP_DIRIN,OP_FILOUT,OP_GOODCH,OP_BADCH,OP_OUTMAP,OP_SUMMAR,
    OP_DATTYP,OP_AVERGRP,OP_CTFGRP,OP_CSPECT,OP_FMIN,OP_FMAX,OP_FDELTA,OP_FSTAND,OP_SUBAV,OP_NONOVR,
    OP_TRIALS,OP_SAMPLE,OP_MWIDTH,OP_MOFFSET,OP_MRANGE,OP_MNAME,OP_SUBEPOCH,OP_EXTRIAL,OP_EXMNAME,OP_EXMWIDTH,OP_EXMEPOCH,OP_EXOVERL,
    OP_RSEFART,OP_REM50HZ,OP_FBANDP,OP_SVD,OP_PREPRO,OP_PREEPOCH,OP_MEGRREF,OP_EEGRREF,
    NOPTIONS
};


static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

class USetEpochs
{
public:
    USetEpochs();
    ErrorType ArgumentsToObject(UMEEGDataEpochs* Epdat);
};
static USetEpochs SetEp;

static const double WindowSize_s = 1.0;


int main(int Nargs, char **Args)
{       
    const char* Intro  = "This programme computes the (cross) spectra of a CTF data set.\n"
                         "The computation is based on a subdivision of the data is smaller epochs.\n"
                         "These epochs are Fourier Transformed and the amplitude spectra are computed.\n"
                         "The exported spectra are obtained by averaging the amplitude spectra of the\n"
                         "individual epochs. Herewith the user can decide to let epochs overlap one another\n"
                         "(by creating artificial intermediate epochs) or not.\n"
                         "The epochs may be based on markers, or on a subdivsion of each trial into\n"
                         "smaller parts.\n\n"
                         "The units of the output numbers is fT*fT, uV*uV or V*V. If the frequency bands\n"
                         "complete and not overlapping, the sum of the powers over all bands is equal to\n"
                         "the power in the time domain, averaged over the epochs.\n\n"
                         "The output is stored in a text file (with extension .txt), which can be\n"
                         "imported in programmes such as EXCEL.\n";
     
    
    Help[OP_DIRIN  ] = "DataSet name of the MEG/EEG data to be analyzed. This directory name may contain wild cards, e.g. 'Data\\*.ds' In that case, all data sets compatible with that name will be analyzed.";
    Help[OP_FILOUT ] = "Filename of the output text file";
    Help[OP_GOODCH ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH  ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels file will be ignored. Note that there are no spaces between the different channel names in this sytax.";    
    Help[OP_OUTMAP ] = "You can export the spectra (in addition to .txt-files) also as .map files.";
    Help[OP_SUMMAR ] = "You can export the spectra of different data sets in summary file.";
    
    Help[OP_DATTYP ] = "The data type that you want to analyze. For powerspectra, the first number indicates: 1=MEG, 2=EEG and 3=ADC, and the second number is ignored. For coherences, you can compute cross coherences between different data types. The first and second numbers indicate both data types, similar to the power spectra.";
    Help[OP_AVERGRP] = "Set this option to average power spectra over channel groups.";
    Help[OP_CTFGRP ] = "You can set standard CFT channel groups. (ML*, MR*, etc). This option affects channel groep averaging.";
    Help[OP_CSPECT ] = "You chan choose between spectra, cross spectra and coherence. 0: Power Spectrum on each channel, 1: Cross spectra between all pairs of channels 2: cross-coherence between all pairs of channels.";
    Help[OP_FMIN   ] = "The lowest frequency added in the estimated power spectrum.";
    Help[OP_FMAX   ] = "The highest frequency added in the estimated power spectrum.";
    Help[OP_FDELTA ] = "The widthness of the frequency bands. For -1 the maximum frequency resolution (given the time wondows) is taken.";
    Help[OP_FSTAND ] = "Instead of regular frequncy bands you can use standard EEG bands. 0: Five bands, 0.-4.-8.-12.-20.-40. Hz, 1: Seven bands,  0.-4.-8.-10.-13.-20.-40.-99.";
    Help[OP_SUBAV  ] = "Subtract the average of all epochs.";
    Help[OP_NONOVR ] = "If this option is set, the epochs are non-overlapping, i.e. no intermediate epochs are created. If this option is not set, additional epochs are averaged, containing the first and second halves of each epoch";
    
    Option[OP_DIRIN  ] = UOption("DataDir",Help[OP_DIRIN ],UOption::DATASETNAME);
    Option[OP_FILOUT ] = UOption("FileOut",Help[OP_FILOUT],UOption::FILENAME);
    Option[OP_GOODCH ] = UOption("Gch","GoodCh",Help[OP_GOODCH],NULL);
    Option[OP_BADCH  ] = UOption("Bch","BadCh",Help[OP_BADCH],NULL);
    Option[OP_OUTMAP ] = UOption("Map","Map output",Help[OP_OUTMAP]);
    Option[OP_SUMMAR ] = UOption("Sum","Summary",Help[OP_SUMMAR]);
    
    Option[OP_DATTYP ] = UOption("Dat","DataType",Help[OP_DATTYP ],1,3,1);
    Option[OP_AVERGRP] = UOption("AGr","Aver. Groups",Help[OP_AVERGRP]);
    Option[OP_CTFGRP ] = UOption("CTF","CTF Groups",Help[OP_CTFGRP]);
    Option[OP_CSPECT ] = UOption("Crs","CrossCoher",Help[OP_CSPECT ],0,2,0);
    Option[OP_FMIN   ] = UOption("Fm" ,"Fmin",Help[OP_FMIN], 0.,10000.,   2.);
    Option[OP_FMAX   ] = UOption("FM" ,"Fmax",Help[OP_FMAX], .1,10000.,100.);
    Option[OP_FDELTA ] = UOption("Fd" ,"Fdelta",Help[OP_FDELTA],-2.,1024.,1.);
    Option[OP_FSTAND ] = UOption("FS" ,"Fstand",Help[OP_FSTAND ],0,1,0);
    Option[OP_SUBAV  ] = UOption("Sa" ,"Subtract A.",Help[OP_SUBAV]);
    Option[OP_NONOVR ] = UOption("SEP","Sep. epoch.",Help[OP_NONOVR]);
    
    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

/* Output formats */
    bool MapOut = Option[OP_OUTMAP ].GetBOOL();
    bool Summar = Option[OP_SUMMAR ].GetBOOL();    
    if(Option[OP_CSPECT].GetValue()!=0 && Summar==true)
    {
        CI.AddToLog("ERROR: Summary file option can only be set in combination with power spectrum computations. \n");
        CI.PressReturnExit();
    }
    if(Option[OP_CSPECT].GetValue()!=0 && MapOut==true)
    {
        CI.AddToLog("ERROR: Map file option can only be set in combination with power spectrum computations. \n");
        CI.PressReturnExit();
    }

/* Set frequency bands*/
    if(Option[OP_FSTAND ].GetValueSet() && Option[OP_FDELTA].GetValueSet())
    {
        CI.AddToLog("ERROR: Standard frequency bands cannot be set simultaneously with fixed bandwidth. \n");
        CI.PressReturnExit();
    }
    double Fmin   = Option[OP_FMIN].GetDubVal1();
    double Fmax   = Option[OP_FMAX].GetDubVal1();
    double Fdelta = Option[OP_FDELTA].GetDubVal1();
    FreqBandType  FBT = U_FBAND_EVEN;
    if(Option[OP_FSTAND ].GetValueSet())
    {
        if(     Option[OP_FSTAND ].GetValue()==0) FBT = U_FBAND_FIVE;
        else if(Option[OP_FSTAND ].GetValue()==1) FBT = U_FBAND_SEVEN;
        else
        {
            CI.AddToLog("ERROR: Invalid Standard frequency option (%d). \n", Option[OP_FSTAND ].GetValue());
            CI.PressReturnExit();
        }
    }

    DataType  DT = U_DAT_UNKNOWN;
    switch(Option[OP_DATTYP].GetValue())
    {
    case 1:  DT = U_DAT_MEG; break;
    case 2:  DT = U_DAT_EEG; break;
    case 3:  DT = U_DAT_ADC; break;
    default: CI.AddToLog("ERROR: Invalid data type: DT = %d \n", Option[OP_DATTYP].GetValue1());
             CI.PressReturnExit();
    }
    bool AverChanGrp = Option[OP_AVERGRP].GetBOOL();
    bool CTFGrouping = Option[OP_CTFGRP ].GetBOOL();
    if(Option[OP_CSPECT].GetValue()!=0 && AverChanGrp==true)
    {
        CI.AddToLog("ERROR: Averaging over channel groups can only be set in combination with power spectrum computations. \n");
        CI.PressReturnExit();
    }
    if(CTFGrouping && (DT!=U_DAT_MEG || AverChanGrp==false))
    {
        CI.AddToLog("ERROR: Setting CTF grouping can only be done when chosing MEG data and channel group averaging. \n");
        CI.PressReturnExit();
    }

    const char* GoodChan = NULL; if(Option[OP_GOODCH].GetValueSet()==true) GoodChan = Option[OP_GOODCH].GetString();
    const char* BadChan  = NULL; if(Option[OP_BADCH ].GetValueSet()==true)  BadChan = Option[OP_BADCH ].GetString();

/*Select data and Set Epochs*/   
    const char* DataSets = Option[OP_DIRIN].GetFileName();
    UDirectory Dirin(DataSets, NULL, false);
    const char* DirName = Dirin.GetDirectoryName();

    int        NDirs = 0;
    UFileName* Filar  = Dirin.GetAllSubdirNames(DataSets, &NDirs);
    if(Filar==NULL || NDirs<=0)
    {
        CI.AddToLog("ERROR: There are no files of the give specifications: %s .\n",DataSets);
        CI.PressReturnExit();
    }
    CI.AddToLog("Note: There are %d files to be examined .\n",NDirs);

    int NDS      = 0;
    int MaxNChan = 0;
    for(int idir=0; idir<NDirs; idir++)
    {
        UDirectory DataSetName( Filar[idir].GetFullFileName() );

        if(IsStringEnding(DataSetName, "hz.ds")==true ||      
           IsStringEnding(DataSetName, "hz2.ds")==true)  continue;
        
        UMEEGDataEpochs EpDat(DataSetName);
        if(EpDat.GetError()!=U_OK || EpDat.GetData()==NULL || EpDat.GetData()->GetError()!=U_OK) continue;
        
        EpDat.SelectChannels(DT, GoodChan, BadChan);
        if(CTFGrouping) EpDat.SetCTFSensorGroups();

        int NChan = 0;
        if(AverChanGrp) 
        {
            const UGrid* G = NULL;
            switch(DT)
            {
            case U_DAT_MEG: G = EpDat.GetData()->GetGridMEG(); break;
            case U_DAT_EEG: G = EpDat.GetData()->GetGridEEG(); break;
            case U_DAT_ADC: G = EpDat.GetData()->GetGridADC(); break;
            }
            if(G==NULL || G->GetGroup()==NULL) continue;
            
            NChan = G->GetGroup()->GetNGroup();
        }
        else
        {
            NChan = EpDat.GetData()->GetNChan(DT);
        }
        if(NChan>MaxNChan) MaxNChan = NChan;

        NDS++;
    }
    if(MaxNChan<=0 || NDS<=0)
    {
        CI.AddToLog("ERROR: Memory allocation, Requested data not found (MaxNChan=%d, NDS=%d). \n",MaxNChan,NDS);
        CI.PressReturnExit();
    }
    UFieldGraph** SummarArray = NULL;
    UMapFile      SummarMap;
    if(Summar)
    {
        SummarArray = new UFieldGraph*[NDS*MaxNChan];
        if(SummarArray==NULL)
        {
            CI.AddToLog("ERROR: Memory allocation, Summay file. \n");
            CI.PressReturnExit();
        }
        for(int nn=0;nn<NDS*MaxNChan; nn++) SummarArray[nn] = NULL;
    }


    int Nerror = 0;
    int iDS    = 0;
    for(int idir=0; idir<NDirs; idir++)
    {
        UDirectory DataSetName( Filar[idir].GetFullFileName() );

        if(IsStringEnding(DataSetName, "hz.ds")==true ||      
           IsStringEnding(DataSetName, "hz2.ds")==true)        
        {
            CI.AddToLog("Note: Skipping data set %s .\n",DataSetName);
            continue;
        }

        UMEEGDataEpochs EpDat(DataSetName);
        if(SetEp.ArgumentsToObject(&EpDat)!=U_OK) 
        {
            CI.AddToLog("ERROR in processing data set %s .\n",DataSetName);
            Nerror++;
            continue;
        }
        EpDat.SelectChannels(DT, GoodChan, BadChan);

        if(CTFGrouping) EpDat.SetCTFSensorGroups();

        bool          RMS      = false;
        bool          Overlap  = NOT(Option[OP_NONOVR].GetBOOL());
        bool          SubAve   = Option[OP_SUBAV  ].GetBOOL();

        UFileName Fout = EpDat.GetData()->GetDataFileName().GetSiblingFileName(UFileName(Option[OP_FILOUT].GetFileName()).GetBaseName());
        Fout.ReplaceExtension(".txt");

/* Compute spectra*/
        if(Option[OP_CSPECT].GetValue()==0)  // PowerSpectra
        {
            int           NChan     = 0;
            UMapFile**    pMapMEG   = NULL; 
            UMapFile**    pMapEEG   = NULL;
            UMapFile*     MapMEG    = NULL; 
            UMapFile*     MapEEG    = NULL;
            if(MapOut)
            {
                if(DT==U_DAT_MEG) pMapMEG = &MapMEG;
                if(DT==U_DAT_EEG) pMapEEG = &MapEEG;
            }
            UFieldGraph** SArray   = EpDat.GetSpectra(Fmin, Fmax, Fdelta, FBT, -1, RMS, Overlap, SubAve, &NChan, pMapMEG, pMapEEG, AverChanGrp);

            if(SArray==NULL)
            {
                CI.AddToLog("ERROR: Compting power spectra in data set %s .\n",DataSetName);
                Nerror++;
                continue;
            }
            if(SummarArray)
            {
                UFileName Base(EpDat.GetData()->GetDataFileName().GetBaseName());
                Base.ReplaceExtension(NULL);
                
                for(int n=0; n<NChan; n++) 
                {
                    UString Label = UString((const char*)Base) + UString("_") + SArray[n]->GetLabel();
                    SArray[n]->SetLabel(Label);
                    SummarArray[n*NDS+iDS] = SArray[n];
                }
            }
            else
            {
                if(SaveGraphs(SArray, NULL, NChan, false, Fout)!=U_OK)
                {
                    CI.AddToLog("ERROR: Saving power spectra in data set %s in .txt format.\n",DataSetName);
                    Nerror++;
                }
                for(int n=0; n<NChan; n++) delete SArray[n]; delete[] SArray;
            }
            if(MapMEG) 
            {
                UFileName FMap = Fout;
                FMap.InsertBeforeExtension("_MEG");
                FMap.ReplaceExtension(".map");
                if(MapMEG->WriteFile(FMap, "fT")!=U_OK)
                {
                    CI.AddToLog("ERROR: Saving MEG power spectra in data set %s in .map format.\n",DataSetName);
                    Nerror++;
                }
                if(Summar)                    
                {
                    UFileName Fin = EpDat.GetData()->GetDataFileName();                        
                    Fin.ReplaceExtension(NULL);
                    UString Text = UString(Fin.GetBaseName()) + UString("_");
                    MapMEG->PrependTrialLabels(Text);
                    if(SummarMap.MergeTrials(*MapMEG)!=U_OK) 
                    {
                        CI.AddToLog("ERROR: Merging MEG power to summary map file, (DS = %s).\n",DataSetName);
                        Nerror++;
                    }
                }
                delete MapMEG;
            }
            if(MapEEG)
            {
                UFileName FMap = Fout;
                FMap.InsertBeforeExtension("_EEG");
                FMap.ReplaceExtension(".map");
                if(MapEEG->WriteFile(FMap, "uV")!=U_OK)
                {
                    CI.AddToLog("ERROR: Saving EEG power spectra in data set %s in .map format.\n",DataSetName);
                    Nerror++;
                }
                if(Summar)                    
                {
                    FMap.ReplaceExtension(NULL);
                    UString Text = UString(FMap.GetBaseName()) + UString("_");
                    MapEEG->PrependTrialLabels(Text);
                    if(SummarMap.MergeTrials(*MapEEG)!=U_OK) 
                    {
                        CI.AddToLog("ERROR: Merging EEG power to summary map file, (DS = %s).\n",DataSetName);
                        Nerror++;
                    }
                }
                delete MapEEG;
            }
        }            
        if(Option[OP_CSPECT].GetValue()==1)  // Cross spectra
        {
            int                NBand  = 0;
            USensorCorrelate** SArray = EpDat.GetCrossSpectra(Fmin, Fmax, Fdelta, FBT, -1, Overlap, SubAve, &NBand, DT);

            if(SArray==NULL)
            {
                CI.AddToLog("ERROR: Computing cross spectra in data set %s .\n",DataSetName);
                Nerror++;
                continue;
            }

            UFreqBand UFB(Fmin, Fmax, Fdelta, FBT, EpDat.GetSampleRate(), EpDat.GetNSampEpoch(0));

            ErrorType E = U_OK;
            for(int n=0; n<NBand; n++)
            {
                if(E!=U_OK) continue;

                UString   BandText = UFB.GetBandAsText(n); BandText.ReplaceAll(' ','_');
                UFileName FCross   = Fout;
                FCross.ReplaceExtension(".cov");
                FCross.InsertBeforeExtension(UString("_")+BandText);

                E = SArray[n]->WriteToFile(FCross);
            }
            if(E==U_OK) E = WriteSensorCorrelateAsText(SArray, NBand, Fout, U_CORREL_CROSSSPEC);
            if(E!=U_OK)
            {
                CI.AddToLog("ERROR: Saving cross spectra in data set %s .\n",DataSetName);
                Nerror++;
            }

            for(int n=0; n<NBand; n++) delete SArray[n]; delete[] SArray;
        }
        if(Option[OP_CSPECT].GetValue()==2)  // Cross coherence
        {
            int                NBand  = 0;
            USensorCorrelate** SArray = EpDat.GetCrossSpectra(Fmin, Fmax, Fdelta, FBT, -1, Overlap, SubAve, &NBand, DT);

            if(SArray==NULL)
            {
                CI.AddToLog("ERROR: Compting cross spectra in data set %s .\n",DataSetName);
                Nerror++;
                continue;
            }
            ErrorType E = U_OK;
            if(E==U_OK) E = WriteSensorCorrelateAsText(SArray, NBand, Fout, U_CORREL_COHERENCE);
            if(E!=U_OK)
            {
                CI.AddToLog("ERROR: Saving coherencies in data set %s .\n",DataSetName);
                Nerror++;
            }

            for(int n=0; n<NBand; n++) delete SArray[n]; delete[] SArray;
        }
        CI.AddToLog("\nNote: Data set %d processed succesfully!\n", idir);
        iDS++;
    }
    
    if(Summar)
    {
        UFileName FoutSum(Option[OP_FILOUT].GetFileName());
        FoutSum.ReplaceExtension(".txt");
        if(SaveGraphs(SummarArray, NULL, NDS*MaxNChan, false, FoutSum)!=U_OK)
        {
            CI.AddToLog("ERROR: Saving power spectra in summary file (%s).\n",(const char*)FoutSum);
            Nerror++;
        }
        for(int nn=0;nn<NDS*MaxNChan; nn++) delete SummarArray[nn];
        delete[] SummarArray;
        
        if(MapOut)
        {
            FoutSum.ReplaceExtension(".map");
            if(DT==U_DAT_MEG)
            {
                FoutSum.InsertBeforeExtension("_MEG");
                if(SummarMap.WriteFile(FoutSum, "fT")!=U_OK)
                {
                    CI.AddToLog("ERROR: Saving summary MEG .map file. \n");
                    Nerror++;
                }
            }
            if(DT==U_DAT_EEG)
            {
                FoutSum.InsertBeforeExtension("_EEG");
                if(SummarMap.WriteFile(FoutSum, "uV")!=U_OK)
                {
                    CI.AddToLog("ERROR: Saving summary EEG .map file. \n");
                    Nerror++;
                }
            }
        }
    }    
    
    if(Nerror==0) CI.AddToLog("Programme ended succesfully!!\n");
    else          CI.AddToLog("There were %d erroneous data sets proceesed. Seeg .log file .\n",Nerror);
    return 0;
}


USetEpochs::USetEpochs()
{
/* Setting the epochs */
    Help[OP_TRIALS  ]   = "Trial Range: Only the data between first and last given trial is processed. -1 refers to last trial.";
    Help[OP_SAMPLE  ]   = "Sample Range: Only the data between first and last given sample is processed. -1 refers to last sample. Given samples are considered as absolute, i.e. not corrected for pr-trigger time.";
    Help[OP_MWIDTH  ]   = "Use markers from marker file, with certain half width i (in samples). If both the option and the -s option is set, -s is ignored.";
    Help[OP_MOFFSET ]   = "If the -mo option ist, the epochs are determined by shifting markers from the markerfiles with a certain name, over a fixed number of samples. The first number is used to set the beginning of each epoch and the second marker is used to set the last sample of each epoch.";
    Help[OP_MRANGE  ]   = "If the -mr option is set, begin and end markers are taken from the marker file, in order to set time segments to be analyzed. Begin and end markers are markers starting with the string 'BEGIN' and 'END' (or 'EIND'), respectively. The -mr option can not be set simultaneously with the -mh option. If both the -mr option and the -s option is set, the -s option is ignored.";
    Help[OP_MNAME   ]   = "If the epochs are derived from a marker with halfwidth or from begin/end marker pairs, you can here select a marker with a certain name. If the name is not set, all markers (pairs) are taken.";
    Help[OP_SUBEPOCH]   = "You can take every n-th epoch exclusively, starting with the m-th epoch (m<n). Here n it the first and m the second number to be given. For example, the numbers 0 amd 2 will skip all odd epochs and taking the even ones.";
    Help[OP_EXTRIAL ]   = "With this option you can exclude trials from the analysis, whose class name (defined in ClassFile.cls) is compatible the given string. This string may contain one or more wild cards. ";    
    Help[OP_EXMNAME ]   = "You can exclude time samples from the analysis, around markers with a certain name. Here you can set the marker name. If this option is set all samples within a certain range about the events corresponding to this marker are skipped.";
    Help[OP_EXMWIDTH]   = "When you have set the option to skip time samples with a certain name, you can set here how many samples on both side of each even will be disregarded.";
    Help[OP_EXMEPOCH]   = "Instead of removing time samples coinciding with a certain marker name, you can remove complete epochs that have an overlap with a certain marker. The advantage is that the number of samples per epoch stays the same";
    Help[OP_EXOVERL ]   = "If this option is set, overlapping epochs (e.g. caused by a too large -mr time) are excluded from the analysis.";

    Option[OP_TRIALS  ] = UOption("Tr" ,"Trials",Help[OP_TRIALS],-1,128,0,-1);
    Option[OP_SAMPLE  ] = UOption("s"  ,"Samples",Help[OP_SAMPLE],-1,32000,0,-1);
    Option[OP_MWIDTH  ] = UOption("mw" ,"Marker wi.",Help[OP_MWIDTH],1,500,1);
    Option[OP_MOFFSET ] = UOption("mo" ,"MarkerOffset",Help[OP_MOFFSET],-100000,100000,0,0);
    Option[OP_MRANGE  ] = UOption("mr" ,"Marker range",Help[OP_MRANGE]);
    Option[OP_MNAME   ] = UOption("Nam","Marker Name",Help[OP_MNAME],NULL);
    Option[OP_SUBEPOCH] = UOption("Rep","ReduceEpochs",Help[OP_SUBEPOCH],0,100,1,0);
    Option[OP_EXTRIAL ] = UOption("Ext","ExcludeTrls",Help[OP_EXTRIAL],"ClassName");
    Option[OP_EXMNAME ] = UOption("ExM","ExcludeMark.",Help[OP_EXMNAME ],NULL);
    Option[OP_EXMWIDTH] = UOption("Exw","Exclude wi.",Help[OP_EXMWIDTH],0,50000,0);
    Option[OP_EXMEPOCH] = UOption("ExE","Exclude ep",Help[OP_EXMEPOCH]);
    Option[OP_EXOVERL ] = UOption("EXO","Excl. Overl.",Help[OP_EXOVERL]);

/* Filtering parameters*/
    Help[OP_RSEFART ]   = "You can remove the SEF artifact from the selected epochs and pre-processing windows by linear interpolation. However, this only works for those epoch selection methods in which the stimulus onset can be determined, making certain assumptions.";
    Help[OP_REM50HZ ]   = "You can remove the 50 Hz. power line noise.";
    Help[OP_FBANDP  ]   = "Band-pass filter the data, before selecting the epochs. You can do so by giving here the minimum and maximum frequency in Hz. A negative value means: ignore. So, e.g. -Bpf-1Bpf10. means: pass all data between zero and 10. Hz, and -Bpf10.Bpf-1 means: pass all data between 10 Hz and the highest present frequency. If the option -Bpf is omitted at all, no filtering is applied.";
    Help[OP_SVD     ]   = "Apply the SVD-filter and set the number of SVD components that are taken from the data. If this option is set, the band-pass filter and the minimum time window parameters are ignored. If -SVD is not set at all, no SVD filters will be applied.";    
    Help[OP_PREPRO  ]   = "Before filtering the data using the band-pass or SVD option, you can substract the offset and/or remove the trend from the data. This pre-processing can be applied upon the selected time epochs themselves, or upon time epochs related to these epochs (pre-processing epochs).  0=No preprocessing, 1=offset removal using the selected epochs, 2=offset and trend removal using the selected epochs, 3=offset removal using preprocessing epochs, 4=trend removal using preprocessing epochs. 5=offset removal using pre-stimulus interval. 6=trendremoval using pre-stimulus interval. Note1: This preprocessing is applied in each selected epoch and on each channel individually, before band-pass c.q. SVD filtering.";
    Help[OP_PREEPOCH]   = "You can set the pre-processing epochs by giving the number of samples that the first samples of each analysis epoch have to be shifted to obtain the begin and end sample of the pre-processing window. When the given shift of the end sample is smaller than the shift of the begin samples, the pre-trigger windows are used.";
    Help[OP_MEGRREF ]   = "You can transform the MEG data to another reference: -1: Keep the data as is, 0: Make MEG data unbalanced, 1: Compute MEG data w.r.t. first gradient, 2: Compute MEG data w.r.t. second gradient, 3: Compute MEG data w.r.t. third gradient .";
    Help[OP_EEGRREF ]   = "You can transform the EEG data to average reference: -1: Keep the data as is, 0: Compute EEG data withrespect to average reference.";

    Option[OP_RSEFART ] = UOption("RSA","RemStimArt",Help[OP_RSEFART]);
    Option[OP_REM50HZ ] = UOption("RPL","RemPowLin",Help[OP_REM50HZ]);
    Option[OP_FBANDP  ] = UOption("Bpf","BandPass",Help[OP_FBANDP],-1.,10000.,1.,30.);
    Option[OP_SVD     ] = UOption("SVD","SVD-filter",Help[OP_SVD],0,100,2);
    Option[OP_PREPRO  ] = UOption("Pre","Pre-process",Help[OP_PREPRO],0,6,0);
    Option[OP_PREEPOCH] = UOption("PPe","PPepochs",Help[OP_PREEPOCH],-1000,1000,0,0);
    Option[OP_MEGRREF ] = UOption("Mrr","MEGreref",Help[OP_MEGRREF],-1,3,-1);
    Option[OP_EEGRREF ] = UOption("Err","EEGreref",Help[OP_EEGRREF],-1,0, 0);
}

ErrorType USetEpochs::ArgumentsToObject(UMEEGDataEpochs *EpDat)
{
    if(EpDat->GetError()!=U_OK)  
    {
        CI.AddToLog("\nErrors in File names\n");
        return U_ERROR;
    }
    bool EpSam = Option[OP_SAMPLE ].GetValueSet();
    bool EpWid = Option[OP_MWIDTH ].GetValueSet();
    bool EpRan = Option[OP_MRANGE ].GetValueSet();
    bool EpOff = Option[OP_MOFFSET].GetValueSet();
    if(EpWid==false && EpRan==false && EpOff==false) EpSam = true;

    if( (EpSam==true && (EpWid==true || EpRan==true || EpOff==true)) ||
        (EpWid==true && (EpRan==true || EpOff==true || EpSam==true)) ||
        (EpRan==true && (EpOff==true || EpSam==true || EpWid==true)) ||
        (EpOff==true && (EpSam==true || EpWid==true || EpRan==true)) )
    {
        CI.AddToLog("ERROR: Epochs definition set ambiguiously. \n");
        CI.AddToLog("       Either use the same samples from each trial (-%s),\n",Option[OP_SAMPLE].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs symmetrically around these markers (-%s),\n",Option[OP_MWIDTH].GetIdentifier());
        CI.AddToLog("       or use the CTF event markers to select epochs shifted w.r,t. these markers (-%s),\n",Option[OP_MOFFSET].GetIdentifier());
        CI.AddToLog("       or use the CTF begin and end-markers to select epochs (-%s).\n",Option[OP_MRANGE].GetIdentifier());
        CI.PressReturnExit();
    }

    if(Option[OP_MNAME].GetValueSet()==true   &&
       EpRan==false  &&
       EpWid==false  &&
       EpOff==false)
    {
        CI.AddToLog("WARNING: Marker name (=%s) set, without setting -mr, -mh or -mo\n",Option[OP_MNAME ].GetString());
    }

/* Select the epochs */
    const char* MarkerName = Option[OP_MNAME ].GetString();
    if(EpRan==true)     // use "range markers"
    {        
        if(EpDat->SetEpochsMarker(MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MRANGE].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpWid==true) // halfwidt set
    {
        int halfwidth = Option[OP_MWIDTH].GetValue();
        if(EpDat->SetEpochsMarker(halfwidth, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MWIDTH].GetIdentifier());
            return U_ERROR;
        }
    }
    else if(EpOff==true)
    {
        int boff = Option[OP_MOFFSET].GetValue1();
        int eoff = Option[OP_MOFFSET].GetValue2();

        if(EpDat->SetEpochsMarker(boff, eoff, MarkerName)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_MOFFSET].GetIdentifier());
            return U_ERROR;
        } 
    }
    else // DEFAULT: fixed sample range from all trials
    {
        int startsample = Option[OP_SAMPLE].GetValue1();
        int endsample   = Option[OP_SAMPLE].GetValue2();
        if(EpDat->SetEpochs(startsample, endsample)!=U_OK)
        {
            CI.AddToLog("ERROR: Epochs can not be determined properly using -%s\n", Option[OP_SAMPLE].GetIdentifier());
            return U_ERROR;
        }
    }

    if(EpDat->GetError()!=U_OK)
    {
        CI.AddToLog("Errors in setting epochs.\n");
        return U_ERROR;
    }
    
/* Exclude epochs:*/
    if(Option[OP_SUBEPOCH].GetValueSet()==true)
    {
        int Ntake  = Option[OP_SUBEPOCH].GetValue1();
        int Nphase = Option[OP_SUBEPOCH].GetValue2();
        if(EpDat->SubsampleEpochs(Ntake, Nphase)!=U_OK)
        {
            CI.AddToLog("ERROR in sub-sampling epochs. Ntake = %d and Nphase = %d.\n",Ntake,Nphase);
            return U_ERROR;
        }
    }
    int starttrial = Option[OP_TRIALS].GetValue1();
    int endtrial   = Option[OP_TRIALS].GetValue2();
    
    if(EpDat->ExcludeTrials(starttrial, endtrial) !=U_OK)
    {
        CI.AddToLog("Errors excluding trials.\n");
        return U_ERROR;
    }
    if(Option[OP_EXTRIAL].GetValueSet()==true)
    {
        const char* TrialName = Option[OP_EXTRIAL].GetString();
        if(EpDat->ExcludeTrialClass(TrialName)!=U_OK)
        {
            CI.AddToLog("ERROR in processing Excluding trials named %s\n",TrialName);
            return U_ERROR;
        }
    }
    if(Option[OP_EXMNAME ].GetValueSet()==true)
    {
        const char* MarkerName = Option[OP_EXMNAME ].GetString();
        int         width      = Option[OP_EXMWIDTH].GetValue();
        if(Option[OP_EXMEPOCH].GetBOOL()==true)
        {
            if(EpDat->ExcludeEpochs(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d epochs,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
        else
        {
            if(EpDat->ExcludeSamples(width, MarkerName)!=U_OK)
            {
                CI.AddToLog("ERROR in processing Excluding %d samples,",width);
                CI.AddToLog(" around markers named %s\n", MarkerName);
                return U_ERROR;
            }
        }
    }
    if(Option[OP_EXOVERL].GetBOOL()==true)  
    {
        if(EpDat->ExcludeOverlapping()!=U_OK)
        {
            CI.AddToLog("ERROR in excluding overlapping epochs.\n");
            return U_ERROR;
        }
    }

/* Set the filter parameters:*/
    UPreProType Prep = U_PREP_NO;
    bool PreProEp     = false;
    bool ForcePreStim = false;
    switch(Option[OP_PREPRO].GetValue())
    {
    case 0: Prep     = U_PREP_NO; 
            PreProEp = Option[OP_PREEPOCH].GetValueSet();
            break;
    case 1: Prep = U_PREP_OFFSET;    PreProEp = false; break;
    case 2: Prep = U_PREP_TREND;     PreProEp = false; break;
    case 3: Prep = U_PREP_OFFSET;    PreProEp = true;  break;
    case 4: Prep = U_PREP_TREND;     PreProEp = true;  break;
    case 5: Prep = U_PREP_OFFSET;    PreProEp = true;  ForcePreStim = true; break;
    case 6: Prep = U_PREP_TREND;     PreProEp = true;  ForcePreStim = true; break;
    default:
        CI.AddToLog("ERROR: Invalid pre-processing parameter: %d .\n",Option[OP_PREPRO].GetValue());
        return U_ERROR;
    }

    if(PreProEp==true && (Option[OP_PREEPOCH].GetValueSet()==true || ForcePreStim==true))
    {
        int BeginOffset = Option[OP_PREEPOCH].GetValue1();
        int EndOffset   = Option[OP_PREEPOCH].GetValue2();
        if(ForcePreStim==true && Option[OP_PREEPOCH].GetValueSet()==true && BeginOffset<=EndOffset)
        {
            CI.AddToLog("ERROR: Forcing pre-stimulus interval is in conflict with the given pre-processing parameters.\n");
            return U_ERROR;
        }
        else if(ForcePreStim==true)
        {
            BeginOffset =  0;
            EndOffset   = -1;
        }
        if(EpDat->SetPreProcessingEpochs(BeginOffset, EndOffset)!=U_OK)
        {
            CI.AddToLog("ERROR in setting pre-processing epochs.\n");
            return U_ERROR;
        }        
    }
    else if(PreProEp==true)
    {
        CI.AddToLog("ERROR: You have chosen to use pre-processing windows without selecting them.\n");
        return U_ERROR;
    }
    
    if(EpDat->SetSEFCorrection(Option[OP_RSEFART ].GetBOOL(), NULL)!=U_OK)
    {
        CI.AddToLog("ERROR: Setting the remove stimulus artifact option.\n");
        return U_ERROR;
    }
    bool   PowerLine = Option[OP_REM50HZ].GetBOOL();
    double PLWitdth  = 2.;

    if(Option[OP_SVD].GetValueSet()==true)
    {
        int Ncomp = Option[OP_SVD ].GetValue();
        EpDat->SetFilter(Ncomp, Prep, PowerLine, PLWitdth, 1.);          
    }
    else if(Option[OP_FBANDP].GetValueSet()==true)
    {
        double Fmin = Option[OP_FBANDP ].GetDubVal1();
        double Fmax = Option[OP_FBANDP ].GetDubVal2();
        EpDat->SetFilter(Fmin, Fmax, Prep, PowerLine, PLWitdth, false, 1.);    
    }
    else
        EpDat->SetFilter(Prep, PowerLine, PLWitdth, false, 1.);  

    ReReferenceType MEGreref = U_REF_RAW;
    switch(Option[OP_MEGRREF ].GetValue())
    {
    case -1: MEGreref = U_REF_RAW;         break;
    case  0: MEGreref = U_REF_UNBALANCED;  break;
    case  1: MEGreref = U_REF_FIRST;       break;
    case  2: MEGreref = U_REF_SECOND;      break;
    case  3: MEGreref = U_REF_THIRD;       break;
    default: CI.AddToLog("ERROR: Invalid MEG re-referencing parameter: %d \n", Option[OP_MEGRREF ].GetValue()); 
        return U_ERROR;
    }
    ReReferenceType EEGreref = U_REF_AVERAGE;
    switch(Option[OP_EEGRREF ].GetValue())
    {
    case -1: EEGreref = U_REF_RAW;         break;
    case  0: EEGreref = U_REF_AVERAGE;     break;
    default: CI.AddToLog("ERROR: Invalid EEG re-referencing parameter: %d \n", Option[OP_EEGRREF ].GetValue()); 
        return U_ERROR;
    }
    return EpDat->SetRereference(MEGreref, EEGreref);
}
