/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*     Object to set UMEEGDataEpochs object from commmand line arguments.           */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    12-06-15   creation
  JdM    12-08-15   Distinguish between 50 Hz and 60 Hz powerline removal
  JdM    13-05-17   With OP_CHANSEL option one can now change the directory where SkipFile is to be found.
                    Added option to get the markerfile from different location.
  JdM    03-03-18   Made Help[] const char* to avoid compiler errors
  JdM    14-06-18   Added GetProperties()
  JdM    29-06-18   Changed interface to USetUpMEEGDataEpochs. Remove default constructor.
  */

#include "SetUpMEEGDataEpochs.h"
#include "../MarkerArray.h"
#include "../Grid.h"

/* Inititalize static const parameters. */
UString      USetUpMEEGDataEpochs::Properties   = UString();
const double USetUpMEEGDataEpochs::WindowSize_s = 1.0;

void USetUpMEEGDataEpochs::InitOptions()
{
/* General */
    Help[OP_MARKERDIR ] = "Take the marker file DATAFILE.mrktxt file from a different directory than the default one (next to the data file directory).";
    Help[OP_ELECFILE  ] = "Replace default electrode positions by the ones from a give data file (.elc, .xyz, .lay).";
    Help[OP_CHANSEL   ] = "If this option is set, take the default channels selection based on the DATAFILE.skptxt file. You can also Use -Skp=DirName to pick the channel selection file from another directory than the MEG/EEG data file.";
    Help[OP_GOODCH    ] = "You can exclusively perform computations on a selected set of channels. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as good channels. When using this option, the GoodChannels and *.skptxt files will be ignored. Note that there are no spaces between the different channel names in this sytax.";
    Help[OP_BADCH     ] = "You can exclude a selected set of channels from the computations. Here you can give these channels using a string with a wild card, e.g. MC*;ML* . In this case, all channels whose names are consistent with either MC* or ML* are considered as bad channels. When using this option, the BadChannels and *.skptxt files will be ignored. Note that there are no spaces between the different channel names in this sytax.";

    Option[OP_MARKERDIR] = UOption("MrD","MarkerDir"  ,Help[OP_MARKERDIR]  ,"");
    Option[OP_ELECFILE ] = UOption("Elc","Elc file"   ,Help[OP_ELECFILE]   ,"Pos.elc");
    Option[OP_CHANSEL  ] = UOption("Skp","SkipChan"   ,Help[OP_CHANSEL] , "");
    Option[OP_GOODCH   ] = UOption("Gch","GoodCh"     ,Help[OP_GOODCH]  ,NULL);
    Option[OP_BADCH    ] = UOption("Bch","BadCh"      ,Help[OP_BADCH]   ,NULL);

/* Setting the epochs */
    Help[OP_TRIALS  ]   = "Trial Range: Only the data between first and last given trial is processed. -1 refers to last trial.";
    Help[OP_SAMPLE  ]   = "Sample Range: Only the data between first and last given sample is processed. -1 refers to last sample. Given samples are considered as absolute, i.e. not corrected for pr-trigger time.";
    Help[OP_MWIDTH  ]   = "Use markers from marker file, with certain half width i (in samples). If both the option and the -s option is set, -s is ignored.";
    Help[OP_MOFFSET ]   = "If the -mo option ist, the epochs are determined by shifting markers from the markerfiles with a certain name, over a fixed number of samples. The first number is used to set the beginning of each epoch and the second marker is used to set the last sample of each epoch.";
    Help[OP_MNAME   ]   = "If the epochs are derived from a marker with halfwidth or from begin/end marker pairs, you can here select a marker with a certain name. If the name is not set, all markers (pairs) are taken.";

    Option[OP_TRIALS  ] = UOption("Tr" ,"Trials"       ,Help[OP_TRIALS],-1,1000,0,-1);
    Option[OP_SAMPLE  ] = UOption("s"  ,"Samples"      ,Help[OP_SAMPLE],-1,32000,0,-1);
    Option[OP_MWIDTH  ] = UOption("mw" ,"Marker wi."   ,Help[OP_MWIDTH],1,500,1);
    Option[OP_MOFFSET ] = UOption("mo" ,"MarkerOffset" ,Help[OP_MOFFSET],-100000,100000,0,0);
    Option[OP_MNAME   ] = UOption("Nam","Marker Name"  ,Help[OP_MNAME],NULL);

/* Filtering parameters*/
    Help[OP_RSEFART      ]   = "You can remove the SEF artifact from the selected epochs by linear interpolation. Here you give the time range in samples (with respect to marker or trial) over which linear interpolation is performed.";
    Help[OP_REMPOWERLINE ]   = "You can remove the 50 Hz or 60 Hz power line noise: 0 do not apply powerline removal, 1: remove 50 Hz and 2: remove 60 Hz.";
    Help[OP_REMPOWERWIDTH]   = "Here you can specify the width of the powerline notch band. A width og 0. implies that no noth will be applied.";
    Help[OP_FBANDP       ]   = "Band-pass filter the data, before selecting the epochs. You can do so by giving here the minimum and maximum frequency in Hz. A negative value means: ignore. So, e.g. -Bpf-1Bpf10. means: pass all data between zero and 10. Hz, and -Bpf10.Bpf-1 means: pass all data between 10 Hz and the highest present frequency. If the option -Bpf is omitted at all, no filtering is applied.";
    Help[OP_SVD          ]   = "Apply the SVD-filter and set the number of SVD components that are taken from the data. If this option is set, the band-pass filter and the minimum time window parameters are ignored. If -SVD is not set at all, no SVD filters will be applied.";    
    Help[OP_PREPRO       ]   = "Before filtering the data using the band-pass or SVD option, you can substract the offset and/or remove the trend from the data. This pre-processing will be applied upon the selected time epochs themselves.  0=No preprocessing, 1=offset removal using the selected epochs, 2=offset and trend removal using the selected epochs. Note1: This preprocessing is applied in each selected epoch and on each channel individually, before band-pass c.q. SVD filtering.";
    Help[OP_MEGRREF      ]   = "You can transform the MEG data to another reference: -1: Keep the data as is, 0: Make MEG data unbalanced, 1: Compute MEG data w.r.t. first gradient, 2: Compute MEG data w.r.t. second gradient, 3: Compute MEG data w.r.t. third gradient .";
    Help[OP_EEGRREF      ]   = "You can transform the EEG data to average reference: -1: Keep the data as is, 0: Compute EEG data withrespect to average reference.";

    Option[OP_RSEFART      ] = UOption("RSA","RemStimArt" ,Help[OP_RSEFART],-50,50,0,-1);
    Option[OP_REMPOWERLINE ] = UOption("RPL","RemPowLin"  ,Help[OP_REMPOWERLINE], 0, 2, 0);
    Option[OP_REMPOWERWIDTH] = UOption("RPw","PowLinWidth",Help[OP_REMPOWERWIDTH], 0.,10., 1.);
    Option[OP_FBANDP       ] = UOption("Bpf","BandPass"   ,Help[OP_FBANDP],-1.,10000.,1.,30.);
    Option[OP_SVD          ] = UOption("SVD","SVD-filter" ,Help[OP_SVD],0,100,2);
    Option[OP_PREPRO       ] = UOption("Pre","Pre-process",Help[OP_PREPRO],0,2,0);
    Option[OP_MEGRREF      ] = UOption("Mrr","MEGreref"   ,Help[OP_MEGRREF],-1,3,-1);
    Option[OP_EEGRREF      ] = UOption("Err","EEGreref"   ,Help[OP_EEGRREF],-1,0, 0);
}
void USetUpMEEGDataEpochs::SetAllMembersDefault()
{
    error          = U_OK;

    AutoRemoveChan = false;
    SkipDir        = NULL;
    GoodChan       = NULL;
    BadChan        = NULL;

    ElPosFromFile  = false;
    ElPosFile      = UFileName();

    Trigger        = NULL;
    WinS           =  0;
    WinE           = -1;

    Prep           = U_PREP_NO;
    WinSEPS        =  0;
    WinSEPE        = -1;

    PowerLine      = U_POWERLINE_NO;
    PLWitdth       = 0.;
    Ncomp          = 0;
    Fmin           = 0.;
    Fmax           = 0.;
    MEGreref       = U_REF_RAW;
    EEGreref       = U_REF_RAW;
}
void USetUpMEEGDataEpochs::DeleteAllMembers(ErrorType E)
{
    delete Trigger;
    SetAllMembersDefault();
    error = E;
}
USetUpMEEGDataEpochs::USetUpMEEGDataEpochs()
{
    SetAllMembersDefault();
}
USetUpMEEGDataEpochs::USetUpMEEGDataEpochs(const char** H, UOption* O)
{
    Help   = H;
    Option = O;
    SetAllMembersDefault();
    InitOptions();
}
USetUpMEEGDataEpochs::~USetUpMEEGDataEpochs()
{
    DeleteAllMembers(U_OK);
}

const UString& USetUpMEEGDataEpochs::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in USetUpMEEGDataEpochs-object\n");
        return Properties;
    }

    Properties = UString();

    Properties += UString(BoolAsText(AutoRemoveChan) ,    "AutoRemoveChan     = %s   // Using *.skptxt file\n");
    if(GoodChan) Properties += UString(GoodChan      ,    "GoodChan           = %s   \n");
    else         Properties += UString(GoodChan      ,    "GoodChan           = NotSet \n");
    if(BadChan)  Properties += UString(BadChan       ,    "BadChan            = %s   \n");
    else         Properties += UString(BadChan       ,    "BadChan            = NotSet \n");
    if(SkipDir)  Properties += UString(SkipDir       ,    "SkipChannelsFrom   = %s   \n");
    Properties += UString(BoolAsText(ElPosFromFile)  ,    "ReplaceElecPos     = %s   \n");
    if(ElPosFromFile) Properties += UString(ElPosFile,    "ElecPositions      = %s   \n");

    if(Trigger)
    {
        Properties += UString(Trigger->GetName(),    "MarkerName         = %s   \n");
        Properties += UString(WinS              ,    "SampleFrom         = %d   \n");
        Properties += UString(WinE              ,    "SampleTo           = %d   \n");
    }
    Properties += UString(int(Prep)         ,    "PreProp            = %d   \n");
    if(Prep!=U_PREP_NO)
    {
        Properties += UString(WinSEPS           ,    "PrepSampleFrom     = %d   \n");
        Properties += UString(WinSEPE           ,    "PrepSampleTo       = %d   \n");
    }
    Properties += UString(int(PowerLine)        ,    "PowerLine          = %d   \n");
    if(PowerLine!=U_POWERLINE_NO)
        Properties += UString(PLWitdth          ,    "PowerLineWin       = %f   \n");
    if(Ncomp)
        Properties += UString(Ncomp             ,    "NSVDcomp           = %d   \n");

    Properties += UString(Fmin                  ,    "Fmin               = %f   \n");
    Properties += UString(Fmax                  ,    "Fmax               = %f   \n");
    Properties += UString(int(MEGreref)         ,    "MEGreref           = %d   \n");
    Properties += UString(int(EEGreref)         ,    "EEGreref           = %d   \n");


    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);
    return Properties;
}

ErrorType USetUpMEEGDataEpochs::ArgumentsToObject(UMEEGDataEpochs *EpDat)
{
    DeleteAllMembers(U_OK);

    if(EpDat==NULL || EpDat->GetError()!=U_OK || EpDat->GetData()==NULL || EpDat->GetData()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Argument NULL, erroneous or data not set.\n");
        return U_ERROR;
    }

    TxtMarkerDir   = Option[OP_MARKERDIR].GetValueSet() ? Option[OP_MARKERDIR].GetString() : NULL;
    AutoRemoveChan = Option[OP_CHANSEL  ].GetValueSet();
    SkipDir        = Option[OP_CHANSEL  ].GetString(); if(SkipDir && (SkipDir[0]==0 || SkipDir[0]==' ')) SkipDir=NULL;
    GoodChan       = Option[OP_GOODCH   ].GetValueSet() ? Option[OP_GOODCH].GetString() : NULL;
    BadChan        = Option[OP_BADCH    ].GetValueSet() ? Option[OP_BADCH ].GetString() : NULL;
    if( (GoodChan || BadChan) && AutoRemoveChan)
        CI.AddToLog("WARNING: USetUpMEEGDataEpochs::ArgumentsToObject(). *.skptxt file will be ignored, because good/bad channel option is also set.\n");

    if(TxtMarkerDir)
    {
        UFileName FMarkText = EpDat->GetData()->GetMarkerTextFile(TxtMarkerDir);
        if(FMarkText.DoesFileExist()==false)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). *.mrktxt file does not exist (%s).\n", (const char*)FMarkText);
            return U_ERROR;
        }
        UMarkerArray MText(FMarkText);
        if(MText.GetError()!=U_OK || fabs(MText.GetSampleRate()-EpDat->GetSampleRate())>0.1 || MText.GetnSampTrial()!=EpDat->GetNsampTrial())
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Creating Markers from text file. SampleRate (%f) or NSampTrial (%d)might be incompatible. \n", MText.GetSampleRate(), MText.GetnSampTrial());
            return U_ERROR;
        }
        if(EpDat->ReplaceMarkers(&MText, true)!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Replacing default markers. \n");
            return U_ERROR;
        }
    }

    ElPosFromFile  = Option[OP_ELECFILE].GetValueSet();
    if(ElPosFromFile) 
    {
        ElPosFile     = UFileName(Option[OP_ELECFILE].GetString());
        UFileName Fin = EpDat->GetData()->GetDataFileName(); 
        if(ElPosFile.IsPureFile()==true) ElPosFile = Fin.GetSiblingFileName(ElPosFile.GetBaseName());
    }

    bool EpSam = Option[OP_SAMPLE ].GetValueSet();
    bool EpWid = Option[OP_MWIDTH ].GetValueSet();
    bool EpOff = Option[OP_MOFFSET].GetValueSet();
    if(EpWid==false && EpOff==false) EpSam = true;

    if( (EpSam==true && (EpWid==true || EpOff==true)) ||
        (EpWid==true && (EpOff==true || EpSam==true)) ||
        (EpOff==true && (EpSam==true || EpWid==true)) )
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Epochs definition set ambiguiously. \n");
        CI.AddToLog("       Either use the same samples from each trial (-%s),\n",Option[OP_SAMPLE].GetIdentifier());
        CI.AddToLog("       or use event markers to select epochs symmetrically around these markers (-%s),\n",Option[OP_MWIDTH].GetIdentifier());
        CI.AddToLog("       or use event markers to select epochs shifted w.r,t. these markers (-%s),\n",Option[OP_MOFFSET].GetIdentifier());
        return U_ERROR;
    }

    if(Option[OP_MNAME].GetValueSet()==true && EpWid==false && EpOff==false)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Marker name (=%s) set, without setting -mr, -mh or -mo\n",Option[OP_MNAME ].GetString());
        return U_ERROR;
    }

/* Select the epochs */
    int Ntrial     = EpDat->GetData()->GetNtrial();
    int NsampTrial = EpDat->GetNsampTrial();
    if(EpSam==true)
    {
        Trigger        = new UMarker("Trial", Ntrial, NsampTrial, 200, "trials", 0, true);
        if(Trigger==NULL || Trigger->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Creating marker for trials. \n");
            return U_ERROR;
        }
        for(int k=0; k<Ntrial; k++) Trigger->SetEvent(k, UEvent(k,0));

        WinS = Option[OP_SAMPLE].GetValue1(); if(WinS<0) WinS=NsampTrial-1;
        WinE = Option[OP_SAMPLE].GetValue2(); if(WinE<0) WinE=NsampTrial-1;
    }
    else
    {
        const UMarkerArray* Mar = EpDat->GetMarkerArray();
        if(Mar==NULL || Mar->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). No markers present in give data file. \n");
            return U_ERROR;
        }
        Trigger = new UMarker(*Mar->GetMarker(Option[OP_MNAME ].GetString()));
        if(Trigger==NULL || Trigger->GetError()!=U_OK)
        {
            delete Trigger; Trigger = NULL;
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Copying marker with name %s. \n", Option[OP_MNAME ].GetString());
            return U_ERROR;
        }
        if(EpWid==true) 
        {
            WinS = -Option[OP_MWIDTH].GetValue(); 
            WinE =  Option[OP_MWIDTH].GetValue();
        }
        else if(EpOff==true)
        {
            WinS = Option[OP_MOFFSET].GetValue1();
            WinE = Option[OP_MOFFSET].GetValue2();
        }
    }

    if(WinS>WinE)
    {
        delete Trigger; Trigger = NULL;
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Getting trigger window  (%d, %d). \n", WinS, WinE);
        return U_ERROR;
    }
    
/* Exclude epochs:*/
    int starttrial = Option[OP_TRIALS].GetValue1();
    int endtrial   = Option[OP_TRIALS].GetValue2();
    if(Trigger->SelectEventsAbsSamp(starttrial*NsampTrial, endtrial*NsampTrial)!=U_OK || Trigger->GetnEvents()<=0)
    {
        delete Trigger; Trigger = NULL;
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Excluding triggers from (%d, %d) (trial range). \n", starttrial, endtrial);
        return U_ERROR;
    }

/* Set the filter parameters:*/
    Prep = U_PREP_NO;
    switch(Option[OP_PREPRO].GetValue())
    {
    case 0: Prep = U_PREP_NO    ;  break;
    case 1: Prep = U_PREP_OFFSET;  break;
    case 2: Prep = U_PREP_TREND ;  break;
    default:
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Invalid pre-processing parameter: %d .\n",Option[OP_PREPRO].GetValue());
        return U_ERROR;
    }

    if(Option[OP_RSEFART ].GetValueSet()==true && Option[OP_RSEFART].GetValue1()<Option[OP_RSEFART].GetValue2())
    {
        WinSEPS = Option[OP_RSEFART].GetValue1();
        WinSEPE = Option[OP_RSEFART].GetValue2();
    }
    PowerLine = (Option[OP_REMPOWERLINE].GetValue()==1) ? U_POWERLINE_50 : ((Option[OP_REMPOWERLINE].GetValue()==2) ? U_POWERLINE_60 : U_POWERLINE_NO);
    PLWitdth  = (PowerLine==U_POWERLINE_NO            ) ? 0.             : Option[OP_REMPOWERWIDTH].GetDubVal1();

    if(Option[OP_SVD].GetValueSet()==true)
    {
        Ncomp = Option[OP_SVD ].GetValue();
    }
    else if(Option[OP_FBANDP].GetValueSet()==true)
    {
        Fmin = Option[OP_FBANDP ].GetDubVal1();
        Fmax = Option[OP_FBANDP ].GetDubVal2();
    }

    switch(Option[OP_MEGRREF ].GetValue())
    {
    case -1: MEGreref = U_REF_RAW;         break;
    case  0: MEGreref = U_REF_UNBALANCED;  break;
    case  1: MEGreref = U_REF_FIRST;       break;
    case  2: MEGreref = U_REF_SECOND;      break;
    case  3: MEGreref = U_REF_THIRD;       break;
    default: CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Invalid MEG re-referencing parameter: %d \n", Option[OP_MEGRREF ].GetValue()); 
        return U_ERROR;
    }
    switch(Option[OP_EEGRREF ].GetValue())
    {
    case -1: EEGreref = U_REF_RAW;         break;
    case  0: EEGreref = U_REF_AVERAGE;     break;
    default: CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ArgumentsToObject(). Invalid EEG re-referencing parameter: %d \n", Option[OP_EEGRREF ].GetValue()); 
        return U_ERROR;
    }
    return U_OK;
}

ErrorType USetUpMEEGDataEpochs::ApplySettings(UMEEGDataEpochs* EpDat)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Object NULL or not properly set. \n");
        return U_ERROR;
    }
    
    if(GoodChan || BadChan)
    {
        if(EpDat->SelectChannels(GoodChan, BadChan)!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Removing channels from default .skptxt file. \n");
            return U_ERROR;
        }
    }
    else if(AutoRemoveChan)
    {
        if(EpDat->RemoveChannelsFromSkipFile(SkipDir)!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Removing channels from default .skptxt file. \n");
            return U_ERROR;
        }
    }
    if(ElPosFromFile) 
    {
        UGrid Grid(ElPosFile);
        if(EpDat->ReplaceSensorPositions(&Grid, U_DAT_EEG)!=U_OK)
        {
            CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). replacing EEG sensors from file %s .\n", (const char*)ElPosFile);
            return U_ERROR;
        }
    }

    ErrorType E = U_OK;
    if(Ncomp>0)
    {
        E = EpDat->SetFilter(Ncomp, Prep, PowerLine, PLWitdth, WindowSize_s);
    }
    else if(Fmax>Fmin)
    {
        E = EpDat->SetFilter(Fmin, Fmax, Prep, PowerLine, PLWitdth, false, WindowSize_s);
    }
    else
        E = EpDat->SetFilter(Prep, PowerLine, PLWitdth, false, WindowSize_s);  

    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Error in applying filter settings. \n");
        return U_ERROR;
    }
    if(EpDat->SetRereference(MEGreref, EEGreref)!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Error in applying re-referencing parameters. \n");
        return U_ERROR;
    }

    if(WinSEPS<WinSEPE) E = EpDat->SetSEFCorrection(true , Trigger, WinSEPS, WinSEPE);
    else                E = EpDat->SetSEFCorrection(false, NULL   , WinSEPS, WinSEPE);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Error in applying SEP artefact correction settings. \n");
        return U_ERROR;
    }

    if(EpDat->SetEpochsMarker(WinS, WinE, Trigger)!=U_OK)
    {
        CI.AddToLog("ERROR: USetUpMEEGDataEpochs::ApplySettings(). Setting epochs from reconstructed or selected trigger (%s). \n", Trigger->GetName());
        return U_ERROR;
    }
    return U_OK;
}

