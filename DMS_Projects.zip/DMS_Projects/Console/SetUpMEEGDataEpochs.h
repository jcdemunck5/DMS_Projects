#ifndef _SETUPMEEGDATAEPOCHS
#define _SETUPMEEGDATAEPOCHS

#include "../Option.h"
#include "../MEEGDataEpochs.h"
#include "../LinearFilter.h"


class USetUpMEEGDataEpochs
{
public:
    enum
    {
        OP_MARKERDIR,OP_ELECFILE,OP_CHANSEL,OP_GOODCH,OP_BADCH,
        OP_TRIALS,OP_SAMPLE,OP_MWIDTH,OP_MOFFSET,OP_MNAME,
        OP_RSEFART,OP_REMPOWERLINE,OP_REMPOWERWIDTH,OP_FBANDP,OP_SVD,OP_PREPRO,OP_MEGRREF,OP_EEGRREF,
        NOPTIONS
    };
    USetUpMEEGDataEpochs();
    USetUpMEEGDataEpochs(const char** H, UOption* O);
    ~USetUpMEEGDataEpochs();

    const UString&         GetProperties(UString Comment) const;

    ErrorType              ArgumentsToObject(UMEEGDataEpochs* Epdat);
    ErrorType              ApplySettings(UMEEGDataEpochs* Epdat);
    const UMarker*         GetTrigger(void) const     {return Trigger;}
    const char*            GetTriggerName(void) const {return Trigger->GetName();}
    int                    GetWinStart() const        {return WinS;}
    int                    GetWinEnd() const          {return WinE;}
    UPreProType            GetPrep() const            {return Prep;}

protected:
    void                   InitOptions();
    void                   SetAllMembersDefault();
    void                   DeleteAllMembers(ErrorType E);

private:
    ErrorType              error;
    static UString         Properties;
    static const double    WindowSize_s;

    const char**           Help;
    UOption*               Option;

    const char*            TxtMarkerDir;
    bool                   AutoRemoveChan;
    const char*            SkipDir;
    const char*            GoodChan;
    const char*            BadChan; 

    bool                   ElPosFromFile;
    UFileName              ElPosFile;

    UMarker*               Trigger;
    int                    WinS;
    int                    WinE;

    UPreProType            Prep;
    int                    WinSEPS;
    int                    WinSEPE;

    UPowerLineType         PowerLine;
    double                 PLWitdth;
    int                    Ncomp;
    double                 Fmin;
    double                 Fmax;
    ReReferenceType        MEGreref;
    ReReferenceType        EEGreref;
};
#endif // _SETUPMEEGDATAEPOCHS
