/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to represent binary file as hexadecimal text file.                */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    14-12-14   creation
  JdM    04-04-18   Made Intro and Help[] const char* to avoid compiler errors
  */
#include <stdlib.h>

#include "../../Option.h"
#include "../../FileName.h"

#define VERSION "1.00 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUmc, Amsterdam"


enum
{
    OP_FILIN,OP_NBYTES,NOPTIONS
};

static const char*   Help[NOPTIONS];
static UOption       Option[NOPTIONS];

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme converts the given file to bytes and saves it as text file.\n";


    Help[OP_FILIN    ] = "File name of file to be analyzed. Output file will have extension .hex";
    Help[OP_NBYTES   ] = "Give the number of bytes to be analyzed. -1 will do complete file.";

    Option[OP_FILIN    ] = UOption("FileIn",Help[OP_FILIN],UOption::FILENAME);
    Option[OP_NBYTES   ] = UOption("NB" ,"NBytes",Help[OP_NBYTES],-1,30000000,1000);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    const char* InputFile = Option[OP_FILIN].GetFileName();
    int         NB        = Option[OP_NBYTES].GetValue();

    FILE* fpIn = fopen(InputFile, "rb");
    if(fpIn==NULL)
    {
        CI.AddToLog("ERROR: File does not exist: %s \n", InputFile);
        CI.PressReturnExit(false);
    }
    uint32_t Size   = GetFileSize(fpIn);
    uint32_t NBytes = (NB<0) ? Size : NB;

    UFileName Fout(InputFile);
    if(Fout.HasExtension("hex")) Fout.SetExtension("hex2") ;
    else                         Fout.SetExtension("hex") ;

    FILE* fpOt = fopen(Fout, "wt", false);
    if(fpOt==NULL)
    {
        fclose(fpIn);
        CI.AddToLog("ERROR: File cannot be created : %s \n", (const char*)Fout);
        CI.PressReturnExit(false);
    }

    fprintf(fpOt, "Offset     ");
    for(int k=0; k<16; k++) fprintf(fpOt, "\t%5d", k); 
    fprintf(fpOt, "\n"); 

    unsigned char buffer[16];
    
    int Ndone = 0;
    while(Ndone<NBytes)
    {
        const char ASCII[17] = "0123456789ABCDEF";
        memset(buffer, 0, sizeof(buffer));
        int nb =MIN(16, (NBytes-Ndone));

        fread(buffer, 1, nb, fpIn);
        fprintf(fpOt, "%6d", Ndone);

        for(int k=0; k<16; k++) fprintf(fpOt, "\t%c%c ", ASCII[buffer[k]/16], ASCII[buffer[k]%16]); 
        
        char cbuf[16];
        for(int k=0; k<16; k++) cbuf[k] = (buffer[k]<=' '|| 127<=buffer[k]) ? ' ' : buffer[k];
        fprintf(fpOt, "  \t");
        for(int k=0; k<16; k++) fprintf(fpOt, "%c", cbuf[k]);
        fprintf(fpOt, "\n"); 

        Ndone += 16;
    }


    fclose(fpOt);
    fclose(fpIn);

    return 0;
}
