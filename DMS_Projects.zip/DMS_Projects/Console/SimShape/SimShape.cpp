/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to similate shapes by contours.                                   */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    27-02-17   creation.
  JdM    31-03-17   Allowed .vtk file as input.
  JdM    04-04-17   Bug fix. Change extension for MatLab output
                    Added invert normals option
  JdM    07-04-17   Added option for alignment using moment matching. Autimatically invert normals when volume is negative.
  JdM    18-05-17   Give WARNING on empty slices and skip them.
                    Apply 3D connected components and choose largest when input is scan file.
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
  */


#include "../../Option.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../Scan.h"
#include "../../Surface.h"
#include "../../Drawing.h"
#include "../../Manifold.h"

#define VERSION "1.08"
#define AUTHOR  "Dr. JC de Munck, Dept PMT VUmc, Amsterdam"

UDrawing* GetDrawingSlice(UManifold* M, int islice, int NSlice, int dir);


enum
{
    OP_FILIN, OP_DIROUT,
    OP_LEVEL, OP_DIRECTION, OP_MOMATCH, OP_NCONT, OP_MERGETH, OP_NPCONT, OP_NINTER, OP_ORDER, OP_ADDCAPS, OP_INVNORM, OP_OUTRAW, OP_OUTCONT,OP_MATLAB, 
    NOPTIONS
};

static const char*   Help  [NOPTIONS];
static       UOption Option[NOPTIONS];

#define MAXDRAWING 100

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads a binary scan or a .vtk file. In case of a binary scan it creates a level surface \n"
                         "using the level given as on of the options. In both cases the programme simulates a reconstruction\n"
                         "from that surface, by interpolating a set of cross-sections representing deliniations. The reconstructed \n"
                         "surface is output as vtk file and can be used for visualisation and quantitative comparison with other\n"
                         "surfaces.\n\n";

    Help[OP_FILIN        ] = "Input data file with segmented scan or .vtk file.";
    Help[OP_DIROUT       ] = "The name of the directory wherein reconstructed surfces and other output objects are stored.";
    Help[OP_LEVEL        ] = "Level indicating the boundary of the segmented object (only in case the input file name represents a scan).";
    Help[OP_DIRECTION    ] = "Direction in which the parallel cross sections are made (0: fastest, 1: middle, 2: slowest direction).";
    Help[OP_MOMATCH      ] = "You can force the surfce (input surface or the one extracted from the given scan) to be aligned with the origin and coordinate axes, before making cross sections and reconstructions. If you do so, all outputs will be in the standard directions (x=shortest axis, 1=middle axis, y=longest axis). The 180 ambiguity can be resolved as follows: 0: do not apply alignment, 1: rotate 180 deg over x-axis, 2: rotate 180 deg over y-axis, 3: rotate 180 deg over z-axis, 4: take rotation matrix with smallest possible total rotation angle. \n";
    Help[OP_NCONT        ] = "Number of equidistant cross sections simulated in the given direction. With -1 you indicate that the input file is a scan file with a sparse delineation. In that case every delineated slice will be taken.";
    Help[OP_MERGETH      ] = "When a cross setion with the surface is made, multiple contours can appear. If you set this option, the largest contour is taken and smaller ones are merged, if their distance to the larger one of smaller than the given threshold. When the option is not set, the threshold is ignored and all crossing points are treated as if they belong together.";
    Help[OP_NPCONT       ] = "Number of points on each cross section. Here -1 means that the true number of points on each cross section is taken.";
    Help[OP_NINTER       ] = "Number of intermediate levels used for the mesh points between contours. \n";
    Help[OP_ORDER        ] = "Interpolation order (0: straight lines, 1: Laplacian, 2: Bi-Laplacian, 3: Tri-Laplacian). \n";
    Help[OP_ADDCAPS      ] = "With this option you can add caps to both ends of the object. 0: No caps, >0: curved caps, <0: flat caps, number indicates number of mesh levels. \n";
    Help[OP_INVNORM      ] = "If this option is set, the normals of the reconstructed surface are inverted. This is handy when the input consists of a left handed coord system.";
    Help[OP_OUTRAW       ] = "This option is only meant in case the input file represents a binary scan. If it is set, the raw object of interest (obtained from the marching cube algorithm) is output as .vtk file.";
    Help[OP_OUTCONT      ] = "If this option in set, the simulated contours are output as .vtk file.";
    Help[OP_MATLAB       ] = "If this option is set, the reconstructed surface is stored as text files that can be easily read in with MatLab. \n";

    Option[OP_FILIN      ] = UOption("DataFile"         ,Help[OP_FILIN ],UOption::FILENAME);
    Option[OP_DIROUT     ] = UOption("FileOut"          ,Help[OP_DIROUT],UOption::DATASETNAME);
    Option[OP_LEVEL      ] = UOption("Lev","Level"      ,Help[OP_LEVEL]    , 0,100000, 1);
    Option[OP_DIRECTION  ] = UOption("Dir","Direction"  ,Help[OP_DIRECTION], 0,3     , 0);
    Option[OP_MOMATCH    ] = UOption("Mom","MomentMatch",Help[OP_MOMATCH], 0,4       , 0);
    Option[OP_NCONT      ] = UOption("NC" ,"NCont"      ,Help[OP_NCONT],  -1,100     , 4);
    Option[OP_MERGETH    ] = UOption("Mer","MergeThresh",Help[OP_MERGETH], 0.0,100.  , 0.5);
    Option[OP_NPCONT     ] = UOption("NPC","NPoint"     ,Help[OP_NPCONT], -1,100000  , 100);
    Option[OP_NINTER     ] = UOption("Nin","Ninter"     ,Help[OP_NINTER],   1,100    , 4);
    Option[OP_ORDER      ] = UOption("Ord","Order"      ,Help[OP_ORDER],    0,3      , 2);
    Option[OP_ADDCAPS    ] = UOption("Cap","OutRaw"     ,Help[OP_ADDCAPS],-10,10     , 1);
    Option[OP_INVNORM    ] = UOption("Inv","InvertNorm" ,Help[OP_INVNORM]);
    Option[OP_OUTRAW     ] = UOption("Raw","OutRaw"     ,Help[OP_OUTRAW]);
    Option[OP_OUTCONT    ] = UOption("Dra","OutDraw"    ,Help[OP_OUTCONT]);
    Option[OP_MATLAB     ] = UOption("MaL","MatLab"     ,Help[OP_MATLAB]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

#ifdef WIN32
    FFTW.SetWisdomDir("C:\\TempQt");
#else
    FFTW.SetWisdomDir("~/TempQt");
#endif

/* Set filename and epochs*/
    UFileName  Fin = UFileName(Option[OP_FILIN].GetFileName());
    int        Lev = Option[OP_LEVEL].GetValue();

    bool  VTKinput = Fin.HasExtension("vtk");
    USurface  SurfIn;
    UScan     Sin;
    if(VTKinput)
    {
        if( Option[OP_LEVEL].GetValueSet()==true)
            CI.AddToLog("WARNING: Input is interpreted as .vtk file. Level parameter ignored. \n");
        SurfIn = USurface(Fin);
    }
    else
    {
        Sin = UScan(Fin);
        if(Sin.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Creating scan from data file %s .\n", (const char*)Fin);
            CI.PressReturnExit();
        }
        UField::DataType DType = Sin.GetDType();
        if(DType!=UField::U_BYTE && DType!=UField::U_SHORT && DType!=UField::U_INTEGER) Sin.ConvertData(UField::U_INTEGER);

        if(Option[OP_NCONT].GetValue()>0)
        {
            Sin.Segment(Lev-1, Lev, true, false, true, true, 0);
            Sin.SelectLargestComponent();
            SurfIn = USurface(&Sin, 1, U_LEVEL_EQUAL, "Raw");
        }
    }
    if(Option[OP_MOMATCH].GetValue()!=0)
    {
        UEuler ToAxis = SurfIn.GetXfm2Moments(Option[OP_MOMATCH].GetValue());
        SurfIn.Transform(ToAxis);
    }
    double Vol = SurfIn.GetNpoints()>0 ? SurfIn.GetVolume() : 0.; 
    if(Vol<0.) SurfIn.InvertNormals();

    UManifold ManiIn(SurfIn);
    if(SurfIn.GetError()!=U_OK || ManiIn.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating surface from data file %s at level %d.\n", (const char*)Fin, Lev);
        CI.PressReturnExit();
    }
    UDirectory Dout(Option[OP_DIROUT].GetFileName());
    if(Dout.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: Creating output directory %s .\n", (const char*)Dout);
        CI.PressReturnExit();
    }
    int dir     = Option[OP_DIRECTION].GetValue();
    int NSlice  = Option[OP_NCONT    ].GetValue();
    if(NSlice==-1)
    {
        if(VTKinput)
        {
            CI.AddToLog("ERROR: Sparse delineation is not compatible with .vtk input.\n");
            CI.PressReturnExit();
        }
    }
    else if(NSlice<2)
    {
        CI.AddToLog("ERROR: Invalid number of slices (%d) .\n", NSlice);
        CI.PressReturnExit();
    }
    else if(NSlice>MAXDRAWING) NSlice = MAXDRAWING;

    int Npoints = Option[OP_NPCONT   ].GetValue();
    int Ninter  = Option[OP_NINTER   ].GetValue();
    int order   = Option[OP_ORDER    ].GetValue();
    int Capps   = Option[OP_ADDCAPS  ].GetValue();
    if(0<=Npoints && Npoints<4)
    {
        CI.AddToLog("ERROR: Invalid number of Npoints (%d) .\n", Npoints);
        CI.PressReturnExit();
    }

    UString NameBase(Fin.GetBaseName()); NameBase.ReplaceAll('.','_'); NameBase.Append('_');
    UString NameVTK = NameBase+UString(dir,"dir_%d") + UString(NSlice,"_NSlice_%d") + UString(Npoints,"_Npoints_%d") + UString(Ninter,"_Ninter_%d") + UString(Capps,"_Caps_%d") + UString(order,"_order_%d.vtk");
    UString NameTXT = NameBase+UString(dir,"dir_%d") + UString(NSlice,"_NSlice_%d") + UString(Npoints,"_Npoints_%d") + UString(Ninter,"_Ninter_%d") + UString(Capps,"_Caps_%d") + UString(order,"_order_%d.txt");

    double  Concat  = Option[OP_MERGETH].GetValueSet() ? Option[OP_MERGETH].GetDubVal1() : -1;

    UDrawing* DrawArr[MAXDRAWING];
    UDrawing  Draw;
    if(NSlice<0)
    {
        Draw            = UDrawing(&Sin, dir, Lev, "Sparse");
        UDrawing** Dtmp = Draw.GetComponents(&NSlice);
        for(int k=0; k<MIN(NSlice,MAXDRAWING); k++) DrawArr[k] = Dtmp[k];
        delete[] Dtmp;
    }
    else
    {
        for(int k=0; k<NSlice; k++) 
        {
            DrawArr[k] = GetDrawingSlice(&ManiIn, k, NSlice, dir);
            if(DrawArr[k]==NULL)
            {
                CI.AddToLog("WARNING: Empty cross section %d of %d.\n", k, NSlice);
                continue;
            }
            else if(DrawArr[k] && DrawArr[k]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: Simulating cross section %d of %d.\n", k, NSlice);
                CI.PressReturnExit();
            }
            if(Concat>=0.)
                DrawArr[k]->MergeComponents(Concat);

            Draw.Concatenate(DrawArr[k]);
        }
        int ks  = 0; for(int k=0; k<NSlice-ks; k++) if(DrawArr[k]==NULL) {DrawArr[k]=DrawArr[k+ks]; DrawArr[k+ks]=NULL;k--; ks++;}
        NSlice -= ks;
    }
    if(Option[OP_OUTRAW ].GetBOOL() && NSlice>0)  SurfIn.WriteVTK(Dout+UFileName(UString("RawSurf_")+NameVTK), ULinTran(), UColor());
    if(Option[OP_OUTCONT].GetBOOL())              Draw  .WriteVTK(Dout+UFileName(UString("Drawing_")+NameVTK), ULinTran(), 0.02);

    UManifold Mou((const UDrawing** )DrawArr, NSlice, Npoints, Ninter, order, Capps, U_PENALTY_NO, 0.);
    USurface* Sou = Mou.GetSurface("Surf", true);
    if(Option[OP_MATLAB].GetBOOL())    Sou->WriteMatLab(Dout+UFileName(UString("Reconst_")+NameTXT));
    else                               Sou->WriteVTK   (Dout+UFileName(UString("Reconst_")+NameVTK), ULinTran(), UColor());
    delete Sou;

    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}


UDrawing* GetDrawingSlice(UManifold* M, int islice, int NSlice, int dir)
{
    double LevMin = M->GetMinCoord(dir);
    double LevMax = M->GetMaxCoord(dir);


    double Level = LevMin + 0.01 + islice* (LevMax-LevMin-0.05)/(NSlice-1);

    UDrawing* PLlev = M->GetCrossSectionAsFlatDrawing(dir, Level);

    return PLlev;
}


