/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to compute overlaps of pairs of surfaces.                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-04-17   creation.
  JdM    01-06-17   Overlap three surfaces.
  JdM    03-03-18   Made Intro and Help[] const char* to avoid compiler errors
 */



#include "../../Option.h"
#include "../../Directory.h"
#include "../../FileName.h"
#include "../../AnalyzeLine.h"
#include "../../Surface.h"

#define VERSION "1.11"
#define AUTHOR  "Dr. JC de Munck, Dept PMT VUmc, Amsterdam"



enum
{
    OP_DIRIN, OP_FILIN, 
    OP_NSURF, OP_NPOINTS, OP_LINESEG,
    NOPTIONS
};

static const char*   Help  [NOPTIONS];
static       UOption Option[NOPTIONS];

int main(int Nargs, char **Args)
{
    const char* Intro  = "This programme reads a text file containing pairs of surfaces files (e.g. in vtk-format) on each line. \n"
                         "Then a new text file will be created containing five collumns: the two filenames, volume of first surface, \n"
                         "volume of second surface and overlap index. The overlap is computed as the volume of the cross section, \n"
                         "divided by the volume of the union. These volumes are approximated by either counting the number\n"
                         "the number of points taken from a regular grid that are inside the cross section, or by computing the\n"
                         "the total length of some line segments inside both volumes. You can regulate the accuracy of the overlap by\n"
                         "setting the number of discretization points\n"
                         "\n\n";

    Help[OP_DIRIN        ] = "The name of the directory where all surface files are located.";
    Help[OP_FILIN        ] = "Input data file containing the filenames of the pairs of surfaces you whish to analyze. These file names do not need to have a full directory name.";
    Help[OP_NSURF        ] = "Number of surfaces on each line of the input data file. For more than three surface files, generalized conformity indices are computed.";
    Help[OP_NPOINTS      ] = "Number of discretization points (or line segments).";
    Help[OP_LINESEG      ] = "If this option is set, line segments are used instead of points to compute overlap.";

    Option[OP_DIRIN      ] = UOption("InputDir"         ,Help[OP_DIRIN  ],UOption::DATASETNAME);
    Option[OP_FILIN      ] = UOption("DataFile"         ,Help[OP_FILIN  ],UOption::FILENAME);
    Option[OP_NSURF      ] = UOption("NS" ,"Nsurface"   ,Help[OP_NSURF  ], 2,3,2);
    Option[OP_NPOINTS    ] = UOption("NP" ,"Npoints"    ,Help[OP_NPOINTS], 0,9000000, 50000);
    Option[OP_LINESEG    ] = UOption("Seg","Segments"   ,Help[OP_LINESEG]);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

#ifdef WIN32
    FFTW.SetWisdomDir("C:\\TempQt");
#else
    FFTW.SetWisdomDir("~/TempQt");
#endif

    UDirectory Din = UDirectory(Option[OP_DIRIN].GetFileName());
    UFileName  Fin = UFileName (Option[OP_FILIN].GetFileName());

    if(Fin.IsPureFile()) Fin = Din+Fin;
    UFileName Fout = Fin;
    Fout.InsertBeforeExtension("_Overlap"); Fout.SetExtension("txt");

    int  NSurf  =  Option[OP_NSURF  ].GetValue(); 
    int  NP     =  Option[OP_NPOINTS].GetValue(); 
    bool UseSeg =  Option[OP_LINESEG].GetBOOL(); 

    FILE* fpIn  = fopen(Fin, "rt", false);
    if(fpIn==NULL)
    {
        CI.AddToLog("ERROR: Cannot open file: %s  \n", (const char*)Fin);
        CI.PressReturnExit(false);
    }
    FILE* fpOut  = fopen(Fout, "wt", false);
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: Cannot create file: %s  \n", (const char*)Fout);
        CI.PressReturnExit(false);
        fclose(fpIn);
    }
    fprintf(fpOut,"%s",CI.GetProperties("// "));
    fclose(fpOut);

    CI.AddToLog("There are %d lines \n", ::GetNLines(fpIn));

    int  il = 0;
    char line[1000];
    while(GetLine(line, sizeof(line), fpIn))
    {
        il++;
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine()==true)       continue;
        if(AA.IsCommentLine("//")==true) continue;

        UFileName F1(AA.GetNextFileName(sizeof(line)/2)); if(F1.IsPureFile()) F1 = Din + F1;
        UFileName F2(AA.GetNextFileName(sizeof(line)/2)); if(F2.IsPureFile()) F2 = Din + F2;
        UFileName F3;
        if(NSurf==3) 
        {
            F3 = UFileName(AA.GetNextFileName(sizeof(line)/2)); if(F3.IsPureFile()) F3 = Din + F3;
        }

        USurface S1(F1);
        USurface S2(F2);
        if(S1.GetError()!=U_OK || S2.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Creating surfaces from %s or %s \n", (const char*)F1, (const char*)F2);
            continue;
        }
        double V1 = S1.GetVolume();
        double V2 = S2.GetVolume();

        fpOut  = fopen(Fout, "at", false);
        if(NSurf==2)
        {
            double Ov = UseSeg ? S1.GetConformityExp(&S2, NP) : S1.GetConformity(&S2, NP);
            fprintf(fpOut,"%s \t %s \t%f \t%f \t%f \n",F1.GetBaseName(), F2.GetBaseName(), V1, V2, Ov);
        }
        else
        {
            USurface S3(F3);
            if(S3.GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: Creating surface from %s  \n", (const char*)F3);
                continue;
            }
            double V3 = S3.GetVolume();
            double OV = ::GetConformity(&S1, &S2, &S3, NP);
            fprintf(fpOut,"%s \t %s \t %s \t%f \t%f \t%f \t%f \n",F1.GetBaseName(), F2.GetBaseName(), F3.GetBaseName(), V1, V2, V3, OV);
        }
        fclose(fpOut);

        CI.AddToLog("Line %d processed \n", il);
    }
    fclose(fpIn );
    fclose(fpOut);

    CI.AddToLog("Programme ended succesfully\n");
    return 0;
}

