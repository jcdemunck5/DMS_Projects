/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Program to analyze DICOM files.                                           */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    01-11-15   creation
*/
#include <stdlib.h>

#include "../../Option.h"
#include "../../FileName.h"
#include "../../Scan.h"
#include "../../DICOMFile.h"

#define VERSION "1.00 "
#define AUTHOR  "Dr. JC de Munck, Dept. PMT VUmc, Amsterdam"


enum
{
    OP_FILIN,NOPTIONS
};

static char*   Help[NOPTIONS];
static UOption Option[NOPTIONS];

int main(int Nargs, char **Args)
{
    char* Intro  = "This programme analyzes a given file and exports its DIOM key words.\n";


    Help[OP_FILIN    ] = "File name of DICOM file to be analyzed. Output file will have extension .info";
    Option[OP_FILIN  ] = UOption("FileIn",Help[OP_FILIN],UOption::FILENAME);

    CI = UConsoleInterface(Args, Nargs, VERSION, AUTHOR);
    CI.TranslateArgs(Option, NOPTIONS, Intro);

    for(int k=0; k<NOPTIONS; k++) fprintf(stderr,"%s\n",Option[k].PrintProperties());

    const char* InputFile = Option[OP_FILIN].GetFileName();

    UFileName Fin(InputFile);

    FILE* fpIn = fopen(Fin, "rb");
    if(fpIn==NULL)
    {
        CI.AddToLog("ERROR: File does not exist: %s \n", InputFile);
        CI.PressReturnExit(false);
    }
    fclose(fpIn);
    UDICOMFile DICF((const char*)Fin);
    DICF.Rewind();

    UFileName Fot    = Fin; Fot.SetExtension("info");
    FILE*     fpOut  = fopen(Fot, "wt");
    fprintf(fpOut, "%s", CI.GetProperties(""));
    fprintf(fpOut, "Group \tElement \tlength \tvalue\n");

    while(1)
    {
        ELEMENT*    E = DICF.dicom_element();
        if(E==NULL) break;

        unsigned int offset = DICF.GetOffset();
        DICF.dicom_load(AE);

        char result[128];
        memset(result, 0, sizeof(result));
        int Len = 127;
        int nc  = 0;
        if(E->length<=0 || E->value.AE==NULL) strcpy(result, "Empty");
        else
        {
            for(unsigned int k=0; k<E->vm; k++)
            {
                switch(E->vr)
                {
                case AE: nc += sprintf(result+nc,"%s",(const char*)(E->value.AE[k])); break;
                case AS: nc += sprintf(result+nc,"%s",(const char*)(E->value.AS[k])); break;
                case CS: nc += sprintf(result+nc,"%s",(const char*)(E->value.CS[k])); break;
                case DA: nc += sprintf(result+nc,"%s",(const char*)(E->value.DA[k])); break;
                case LT: nc += sprintf(result+nc,"%s",(const char*)(E->value.LT   )); break;
                case LO: nc += sprintf(result+nc,"%s",(const char*)(E->value.LO[k])); break;
                case OB: nc += sprintf(result+nc,"%s",(const char*)(E->value.OB   )); break;
                case OW: nc += sprintf(result+nc,"%s",(const char*)(E->value.OW   )); break;
                case PN: nc += sprintf(result+nc,"%s",(const char*)(E->value.PN[k])); break;
                case SH: nc += sprintf(result+nc,"%s",(const char*)(E->value.SH[k])); break;
                case ST: nc += sprintf(result+nc,"%s",(const char*)(E->value.ST   )); break;
                case TM: nc += sprintf(result+nc,"%s",(const char*)(E->value.TM[k])); break;
                case UI: nc += sprintf(result+nc,"%s",(const char*)(E->value.UI[k])); break;
                case IS: nc += sprintf(result+nc,"%s",(const char*)(E->value.IS[k])); break;

                case DS: nc += sprintf(result+nc,"%s",(const char*)(E->value.DS[k])); break;
                case UT: nc += sprintf(result+nc,"%s",(const char*)(E->value.UT   )); break;
                case DT: nc += sprintf(result+nc,"%s",(const char*)(E->value.DT[k])); break;
                case UN:
                case SQ: nc += sprintf(result+nc,"%s",(const char*)(E->value.AE[k])); break;
                case AT: nc += sprintf(result+nc, "(%d, %d)",E->value.AT[k].group,E->value.AT[k].element); break;

                case FL: nc += sprintf(result+nc, "%f", E->value.FL[k]);   break;
                case FD: nc += sprintf(result+nc, "%f", E->value.FD[k]);   break;
                case SL: nc += sprintf(result+nc, "%d", E->value.SL[k]);   break;
                case SS: nc += sprintf(result+nc, "%d", E->value.SS[k]);   break;
                case UL: nc += sprintf(result+nc, "%d", E->value.UL[k]);   break;
                case US: nc += sprintf(result+nc, "%d", E->value.US[k]);   break;
                }
                if(E->vr!=AE && E->vr!=AS && E->vr!=CS && E->vr!=DA && E->vr!=DS && E->vr!=DT &&
                    E->vr!=IS && E->vr!=LO && E->vr!=PN && E->vr!=SH && E->vr!=TM && E->vr!=UI) break;
                if(nc>Len) break;
                if(k+1!=E->vm) nc += sprintf(result+nc,"\\");
            }
        }


        fprintf(fpOut, "%d \t%d \t%d \t%s\n", int(E->group), int(E->element), nc, result);
    }
    fclose(fpOut);

    return 0;
}
