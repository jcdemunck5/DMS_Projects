/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL:                                                                   */
/*     Module for regulating the interface between the console and the user.      */
/*                                                                                */
/*     There is one UConsoleInterface()-object, defined in basicinclude.h. There- */
/*     for, it is accessible from all U-objects. This object, called CI, should   */
/*     be initialized in the main programme using the non-default constructor.    */
/*                                                                                */
/*     The main purposes ob the UConsoleInterface()-object are:                   */
/*     -To translate programme arguments into doubles, ints, strings, etc.        */
/*     -To set author and version number                                          */
/*     -To write error messages to .log file                                      */
/*                                                                                */
/*     The best way to learn to use the UOption()-object is to look into the code */
/*     of e.g. FitDipoles, Spectrum, InterData, etc.                              */
/*                                                                                */
/*                                                                                */
/*     NOTE(S):                                                                   */
/*     An important feature of the object is that UOptions of the type FILENAME   */
/*     and DATASETNAME are mandatory, and that they have no defaults.             */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    09-08-99   creation.
  JdM    13-08-99   Added AddArrayToLog()
  JdM    25-08-99   Added ./ in front of UNIX script name.  JdM    29-08-99   Added timer information using TimeReset() and TimeFlag() functions
  JdM    29-08-99   Adaptations for SUN UNIX
  JdM    07-09-99   Added another AddToLog()
  JdM    08-10-99   ArrayToLog() : export in collumn (easier to read with EXCELL)
  JdM    28-10-99   Add EnableKey()
  JdM    28-10-99   Another AddToLog() (combination of string and integers)
  JdM    04-12-99   Added another AddToLog()
  JdM    25-12-99   Added another AddToLog()
  JdM    14-01-00   Added SkipConsoleOutput()
  JdM    29-01-00   compatibility with the Borland compiler (system includes first)
  JdM    09-02-00   TranslateArgs(): Print error messages to CI-object instead of to screen alone
  JdM    14-02-00   New AddToLog()
  JdM    14-04-00   New AddToLog()
  JdM    16-06-00   Test if logfile can be created (skip iff not).
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
                    Insert default names in default contructors (i.s.o. NULL pointers)
                    Create .log file in the same directory as the .bat (or .scr) file
  JdM    07-09-00   Add Transpose -parameter to ArrayToLog()
  JdM    22-09-00   New AddToLog()
  JdM    10-10-00   New AddToLog()
  JdM    06-11-00   Added GetProperties()
  JdM    16-02-01   Added new AddToLog()
  JdM    25-03-01   Added new AddArrayToLog()
  JdM    28-06-01   Added new AddToLog()
  JdM    09-07-01   Recognize SUN sparc compiler
  JdM    26-09-01   Added new AddToLog()
  JdM    03-01-02   Added GetLastLogLines()
  JdM    23-01-02   Added central VERSIONDATE string
  JdM    03-02-02   Added LogOffset parameter to keep trach of the start of a new session
                    This is used in new GetLastLogSession()
  JdM    18-03-02   Added new AddToLog()
  JdM    20-03-02   Added new AddToLog(). Made all AddToLog() const
  JdM    29-05-02   increased MAXPROPERTIES
  JdM    14-10-02   Add new AddArrayToLog()
  JdM    16-10-02   Add new AddArrayToLog()
  JdM    23-10-02   Add the functions EnableLogging() and DisableLogging()
  JdM    22-11-02   Added new AddToLog()
  JdM    29-11-02   Defined compiler version in case of Linux
  JdM    29-11-02   Defined compiler version in case of Linux
JdM/BvZ  29-01-03   #elif does not work under Linux. Avoid this.
  GdV    13-02-03   initialize UConsoleInterface::CompilerVersion for the case of HP-UX
  BvZ    04-03-03   #elif Linux Debug / Release
  BvZ    24-03-03   #elif ETHERNET
  JdM    20-07-03   Added new AddToLog()
  JdM    23-12-03   Added new AddToLog()
  JdM    04-01-04   Added new AddToLog()
  JdM    02-10-04   Added GetDisAbleLogging()
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    28-10-04   Added new AddToLog()
  JdM    27-02-05   Added new AddToLog()
  JdM    17-03-05   CreateBatFile(), added ./ before program name, in case of UNIX
  JdM    29-03-05   Bug fix CreateBatFile(), dd 17-03-04
  JdM    22-04-05   AddArrayToLog(): Single index versions: Renamed Transpose-parameter in  into DataRows
                                     Double index version:  Reversed meaning of "Transpose" parameter
  JdM    07-03-06   Added GetCompilerVersion(), GetVersion(), GetVersionDate()
  Jdm    13-02-10   Bug Fix: GetLastLogSession(). Never return const pointers because calling functions will try to delete them
  JdM    05-05-10   Added ResetLogFile()
  JdM    28-11-10   LogFileName now contains complete path (copied from Args[0])
  JdM    06-03-11   Added DisableConsoleOutput() and EnableConsoleOutput(). Remove SkipConsoleOutput()
  JdM    28-03-12   Added GetLogFileSize()
  JdM    12-06-12   Set ConsoleOut=false when defined BUILD_PMT_DLL
  JdM    03-07-13   Changed default ProgArgs text.
  JdM    02-02-14   Added new AddToLog()
  JdM    04-05-15   Added new AddToLog()
  JdM    14-05-17   Added pArgs[] and ArgsArray[] to store deep copies of program arguments. This will prepare for allowance of spaces in file names.
  JdM    16-10-17   Added new AddToLog()
  JdM    13-07-18   CreateBatFile(). Add pause statement.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>


#include"ConsoleInterface.h"
#include"BasicInclude.h"
#include"Option.h"
 
#ifdef LIMITED_FILETYPES
#define VERSIONDATE "28-09-2018 LIGHT EDITION"
#else
#define VERSIONDATE "28-09-2018" 
#endif 
/* Inititalize static const parameters. */
int          UConsoleInterface::CountDestr    = 0;
const char*  UConsoleInterface::DefProgName   = "Test.exe";
const char*  UConsoleInterface::DefAuthor     = "Nerd";
const char*  UConsoleInterface::DefVersion    = "0.0";
unsigned int UConsoleInterface::MAXPROPERTIES = 2000;
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    #ifdef DEBUG_GNU_WIN
        const char* UConsoleInterface::CompilerVersion = "(GNU Win Debug)";
    #endif
    #ifdef RELEASE_GNU_WIN
        const char* UConsoleInterface::CompilerVersion = "(GNU Win Release)";
    #endif
    #ifdef _DEBUG
        const char* UConsoleInterface::CompilerVersion = "(Debug)";
    #else
        #ifndef DEBUG_GNU_WIN
            #ifndef RELEASE_GNU_WIN
                const char* UConsoleInterface::CompilerVersion = "(Release)";
            #endif
        #endif
    #endif
#else
    #ifdef sparc
        const char* UConsoleInterface::CompilerVersion = "(SUN sparc)";
    #endif
    #ifdef linux
        #ifdef DEBUG
            const char* UConsoleInterface::CompilerVersion = "(Linux Debug)";
        #else
            #ifdef PARALLEL
                #ifdef ETHERNET
                    const char* UConsoleInterface::CompilerVersion = "(Linux Release Ethernet)";
                #else
                    const char* UConsoleInterface::CompilerVersion = "(Linux Release Parallel)";
                #endif
            #else
                const char* UConsoleInterface::CompilerVersion = "(Linux Release)";
            #endif
        #endif
    #endif
    #ifdef hpux
        const char* UConsoleInterface::CompilerVersion = "(HP-UX)";
    #endif
#endif


#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    #define SLASH '\\'
    #define EXTEN ".bat"
#else
    #define SLASH '/'
    #define EXTEN ".scr"
#endif

/*include library and the master and IDproc are external variables*/
#ifdef PARALLEL
#include "mpi.h"
#endif

extern int Master;
extern int IDproc;


UConsoleInterface::UConsoleInterface()
{
    Nargs          = 0;
    NByteArgs      = 0;
    ArgsArray      = NULL;
    pArgs          = NULL;
    ProgName       = DefProgName;
    LogFileName    = new char[sizeof("Test.log")+4];
    if(LogFileName) strcpy(LogFileName,"Test.log");
    Author         = DefAuthor;
    Version        = DefVersion;
    ProgArgs       = NULL;
    Properties     = new char[MAXPROPERTIES];
    KeyEnable      = false;
    ConsoleOut     = true;
#ifdef BUILD_PMT_DLL
    ConsoleOut     = false;
#endif
    DisAbleLogging = false;
    LogOffset      = 0;
#ifdef WIN32
#ifdef _DEBUG
    EnableKey();
#endif
#endif
}

UConsoleInterface::UConsoleInterface(char** Args, int N, const char* Ver, const char* Aut)
{
    KeyEnable      = false;
    ConsoleOut     = true;
#ifdef BUILD_PMT_DLL
    ConsoleOut     = false;
#endif
    DisAbleLogging = false;
#ifdef WIN32
#ifdef _DEBUG
    EnableKey();
#endif
#endif
    if(Args==NULL)
    {
        if(ConsoleOut==true)
            fprintf(stderr, "UConsoleInterface: Programming failure. \n");
        PressReturnExit(false);
    }
    Nargs       = N;
    NByteArgs   = 100; for(int n=0; n<Nargs; n++) NByteArgs += int(strlen(Args[n])) + 3;
    ProgArgs    = new char[NByteArgs];
    ArgsArray   = new char[NByteArgs];
    pArgs       = new char*[Nargs];
    Properties  = new char[MAXPROPERTIES];
    if(ProgArgs==NULL || ArgsArray==NULL || pArgs==NULL || Properties==NULL)
    {
        if(ConsoleOut==true) fprintf(stderr, "UConsoleInterface: Programming failure. Memory Error. \n");
        PressReturnExit(false);
    }
    memset(ProgArgs , 0, NByteArgs);
    memset(ArgsArray, 0, NByteArgs);
    memset(pArgs    , 0, Nargs*sizeof(char*));
    if(Nargs>1)
    {
        int nbyte = 0;
        for(int n=1; n<N-1; n++)  nbyte+=sprintf(ProgArgs+nbyte,"%s ", Args[n]);
        nbyte+=sprintf(ProgArgs+nbyte,"%s", Args[N-1]);
    }
    else
        sprintf(ProgArgs,"No command line arguments");

    for(int n=0, off=0; n<Nargs; n++)
    {
        pArgs[n] = ArgsArray + off;
        strcpy(ArgsArray+off, Args[n]);
        off     += int(strlen(Args[n]))+1;
    }
    Author    = Aut;
    Version   = Ver;

    ProgName  = NULL;
    for(ProgName=Args[0]+strlen(Args[0]);ProgName>=Args[0];ProgName--)
        if(*ProgName==SLASH) break;
    ProgName++;

    size_t nbytes  = 10 + strlen(Args[0]);
    LogFileName    = new char[nbytes];
    if(LogFileName==NULL || DisAbleLogging==true) return;

    memset(LogFileName, 0, nbytes);
    strcpy(LogFileName, Args[0]);
    char* Ext = LogFileName + strlen(LogFileName)-3;
    if(Ext[0]=='e' && Ext[1]=='x' && Ext[2]=='e')
    {
        Ext[0] = 'l'; Ext[1]='o'; Ext[2]='g';
    }
    else if(Ext[-1]=='.')
    {
        strcat(LogFileName, "log");
    }
    else
    {
        strcat(LogFileName, ".log");
    }
    time(&ProgStartT);
    time(&ProgEndT);
    time(&ProcStartT);
    time(&ProcEndT);

    FILE* fp  = fopen(LogFileName,"at");
    LogOffset = GetFileSize(fp);

    if(fp)
    {
        fprintf(fp,"****************************************************************************************\n");
        fprintf(fp,"*    Time         :      %s",GetTime());
        fprintf(fp,"*    Programme    :      %s\n",ProgName);
        fprintf(fp,"*    Version      :      %s: %s, %s\n",Version, VERSIONDATE, CompilerVersion);
        fprintf(fp,"*    Arguments    :      %s\n",ProgArgs);
        fprintf(fp,"*\n*\n");
        fclose(fp);
    }
    else
    {
        fprintf(stderr,"WARNING: UConsoleInterface::UConsoleInterface(). Cannot create logfile :%s\n",LogFileName);
    }
    if(ConsoleOut==true)
        fprintf(stderr,"%s Version: %s: %s\n%s\n\n\n",ProgName,Version,VERSIONDATE,Author);
}

UConsoleInterface& UConsoleInterface::operator=(const UConsoleInterface& ci)
{
    NByteArgs      = ci.NByteArgs;
    Nargs          = ci.Nargs;
    ProgName       = ci.ProgName;
    Author         = ci.Author;
    Version        = ci.Version;
    ProgStartT     = ci.ProgStartT;
    ProgEndT       = ci.ProgEndT;
    ProcStartT     = ci.ProcStartT;
    ProcEndT       = ci.ProcEndT;
    KeyEnable      = ci.KeyEnable;
    ConsoleOut     = ci.ConsoleOut;
    DisAbleLogging = ci.DisAbleLogging;
    LogOffset      = ci.LogOffset;

/* Allocate memory for new logfile name*/
    delete[] LogFileName;
    if(ci.LogFileName)
    {
        size_t  nbytes = strlen(ci.LogFileName)+2;
        LogFileName = new char[nbytes];
        if(LogFileName)
        {
            memset(LogFileName, 0, nbytes);
            sprintf(LogFileName,ci.LogFileName);
        }
    }
    else
        LogFileName = NULL;

    delete[] ProgArgs;
    if(ci.ProgArgs)
    {
        size_t  nbytes = strlen(ci.ProgArgs)+2;
        ProgArgs       = new char[nbytes];
        if(ProgArgs)
        {
            memset(ProgArgs, 0, nbytes);
            sprintf(ProgArgs,ci.ProgArgs);
        }
    }
    else
        ProgArgs = NULL;

    delete[] Properties;
    if(ci.Properties)
    {
        Properties = new char[MAXPROPERTIES];
        if(Properties)
            memcpy(Properties, ci.Properties, MAXPROPERTIES);
    }
    else
        Properties = NULL;
    
    delete[] ArgsArray;
    if(ci.ArgsArray)
    {
        ArgsArray = new char[NByteArgs];
        if(ArgsArray)
            memcpy(ArgsArray, ci.ArgsArray, NByteArgs);
    }
    else
        ArgsArray = NULL;

    delete[] pArgs;
    if(ci.pArgs)
    {
        pArgs = new char*[Nargs];
        if(pArgs) for(int n=0; n<Nargs; n++) pArgs[n] = ci.pArgs[n] + int64_t(ArgsArray -ci.ArgsArray);
    }
    else
        pArgs = NULL;

    return *this;
}

UConsoleInterface::~UConsoleInterface()
{
    CountDestr++;
    if(pArgs==NULL || CountDestr==1) return;

    time(&ProgEndT);

    FILE* fp=fopen(LogFileName,"at");
    if(fp)
    {
        fprintf(fp,"*\n*\n");
        fprintf(fp,"*    Elapsed Time :      %d (s)\n",int(ProgEndT-ProgStartT));
        fprintf(fp,"*    Time         :      %s",GetTime());
        fprintf(fp,"****************************************************************************************\n");
        fclose(fp);
    }
    delete[] LogFileName;
    delete[] ProgArgs;
    delete[] pArgs;
    delete[] ArgsArray;
    delete[] Properties;
}

const char* UConsoleInterface::GetProgName()        const {return ProgName;}
const char* UConsoleInterface::GetAuthor()          const {return Author;}
const char* UConsoleInterface::GetProgArgs()        const {return ProgArgs;}
const char* UConsoleInterface::GetLogFileName()     const {return LogFileName;}
const char* UConsoleInterface::GetCompilerVersion() const {return CompilerVersion;}
const char* UConsoleInterface::GetVersion()         const {return Version;}
const char* UConsoleInterface::GetVersionDate()     const {return VERSIONDATE;}

void UConsoleInterface::DisableConsoleOutput(void)    
{
    ConsoleOut = false;
}
void UConsoleInterface::EnableConsoleOutput(void)     
{
    ConsoleOut = true; 
#ifdef BUILD_PMT_DLL
    ConsoleOut     = false;
#endif
}

ErrorType UConsoleInterface::ResetLogFile(void)
{
    if(this==NULL)           return U_ERROR;
    if(LogFileName==NULL)    return U_ERROR;
    if(DisAbleLogging==true) return U_OK;

    char* LastLog = GetLastLogSession();
    if(LastLog==NULL)        return U_ERROR;

    FILE* fp=fopen(LogFileName,"wb");
    if(fp==NULL)             return U_ERROR;
    fprintf(fp, LastLog);
    fclose(fp);
    delete[] LastLog;
    LogOffset = 0;

    return U_OK;
}
unsigned int UConsoleInterface::GetLogFileSize(void) const
{
    FILE* fp=fopen(LogFileName,"rb");
    if(fp==NULL) return 0;
    unsigned int Size = GetFileSize(fp);
    fclose(fp);
    return Size;
}

void UConsoleInterface::AddToLog(const char* str) const
{
    if(ConsoleOut==true)  fprintf(stderr,"%s",str);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,"%s",str);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,str);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,str);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, const char* str2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr, form, str1, str2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, str2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, const char* str2, const char* str3) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr, form, str1, str2, str3);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, str2, str3);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, const char* str2, const char* str3, const char* str4) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr, form, str1, str2, str3, str4);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, str2, str3, str4);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, doub);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2, int i) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2,i);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2,i);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2, const double doub3) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2,doub3);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2,doub3);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const double doub4) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2,doub3,doub4);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2,doub3,doub4);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const double doub4, const double doub5) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2,doub3,doub4,doub5);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2,doub3,doub4,doub5);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub, const int i) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub,i);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub,i);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub, const int i1, const int i2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub,i1, i2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub,i1, i2);
    fclose(fp);
}
void UConsoleInterface::AddToLog(const char* form, const double doub, const int i1, const int i2, const int i3) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub,i1, i2, i3);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub,i1, i2, i3);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, int i) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, str1, i);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, i);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, int i1, int i2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, str1, i1, i2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, i1, i2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, double doub1, double doub2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, str1, doub1, doub2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, doub1, doub2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2, const int i3) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2,i3);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2,i3);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2, const int i3, const int i4) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2,i3,i4);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2,i3,i4);
    fclose(fp);
}
void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2, const int i3, const int i4, const int i5) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2,i3,i4,i5);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2,i3,i4,i5);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i, const double doub) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i,doub);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i,doub);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i, const double doub1, const double doub2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i,doub1,doub2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i,doub1,doub2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2, const double doub) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2,doub);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2,doub);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i1, const int i2, const double doub1, const double doub2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i1,i2,doub1,doub2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i1,i2,doub1,doub2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const int i, const char* str) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i,str);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i,str);
    fclose(fp);
}
void UConsoleInterface::AddToLog(const char* form, const int i, const char* str1, const char* str2) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,i,str1,str2);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,i,str1,str2);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const int i1) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form,doub1,doub2,doub3,i1);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form,doub1,doub2,doub3,i1);
    fclose(fp);
}

void UConsoleInterface::AddToLog(const char* form, const char* str1, const double doub) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, str1, doub);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, str1, doub);
    fclose(fp);
}
void UConsoleInterface::AddToLog(const char* form, const double doub, const char* str1) const
{
    if(form==NULL) return;
    if(ConsoleOut==true)  fprintf(stderr,form, doub, str1);
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    fprintf(fp,form, doub, str1);
    fclose(fp);
}

void UConsoleInterface::AddArrayToLog(const double* Array, int N1, int N2, bool Transpose)
{
    if(Array==NULL)
    {
        CI.AddToLog("ERROR: UConsoleInterface::AddArrayToLog(). Invalid NULL pointer. \n");
        return;
    }
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(Transpose==true)
    {
        for(int n2=0; n2<N2; n2++)
        {
            for(int n1=0; n1<N1-1; n1++)
                fprintf(fp,"%f\t",Array[n1*N2+n2]);
            fprintf(fp,"%f\n",Array[N1*N2-N2+n2]);
        }
    }
    else // First index refers to collumn
    {
        for(int n1=0; n1<N1; n1++)
        {
            for(int n2=0; n2<N2-1; n2++)
                fprintf(fp,"%f\t",Array[n1*N2+n2]);
            fprintf(fp,"%f\n",Array[(n1+1)*N2-1]);
        }
    }
    fclose(fp);
}

void UConsoleInterface::AddArrayToLog(const int* Array, int N, bool DataRows)
{
    if(Array==NULL)
    {
        CI.AddToLog("ERROR: UConsoleInterface::AddArrayToLog(). Invalid NULL pointer. \n");
        return;
    }
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(DataRows==false)
    {
        for(int n=0; n<N; n++) fprintf(fp,"%d\n",Array[n]);
    }
    else
    {
        for(int n=0; n<N-1; n++) fprintf(fp,"%d\t",Array[n]);
        fprintf(fp,"%d\n",Array[N-1]);
    }

    fclose(fp);
}

void UConsoleInterface::AddArrayToLog(const double* Array, int N, bool DataRows)
{
    if(Array==NULL)
    {
        CI.AddToLog("ERROR: UConsoleInterface::AddArrayToLog(). Invalid NULL pointer. \n");
        return;
    }
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(DataRows==false)
    {
////        for(int n=0; n<N; n++) fprintf(fp,"%g\n",Array[n]);
        for(int n=0; n<N; n++) fprintf(fp,"%7.4f\n",Array[n]);
    }
    else
    {
////        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Array[n]);
        for(int n=0; n<N-1; n++) fprintf(fp,"%7.4f\t",Array[n]);
////        fprintf(fp,"%g\n",Array[N-1]);
        fprintf(fp,"%7.4f\n",Array[N-1]);
    }

    fclose(fp);
}

void UConsoleInterface::AddArrayToLog(const double* Ar1, const double* Ar2, int N, bool DataRows)
{
    if(Ar1==NULL)
    {
        AddArrayToLog(Ar2, N, DataRows);
        return;
    }
    if(Ar2==NULL)
    {
        AddArrayToLog(Ar1, N, DataRows);
        return;
    }
    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(DataRows==false)
    {
        for(int n=0; n<N; n++) fprintf(fp,"%g\t%g\n",Ar1[n],Ar2[n]);
    }
    else
    {
        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Ar1[n]);
        fprintf(fp,"%g\n",Ar1[N-1]);
        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Ar2[n]);
        fprintf(fp,"%g\n",Ar2[N-1]);
    }
    fclose(fp);
}

void UConsoleInterface::AddArrayToLog(const double* Ar1, const double* Ar2, const double* Ar3, int N, bool DataRows)
{
    if(Ar1==NULL)
    {
        AddArrayToLog(Ar2, Ar3, N, DataRows);
        return;
    }
    if(Ar2==NULL)
    {
        AddArrayToLog(Ar1, Ar3, N, DataRows);
        return;
    }
    if(Ar3==NULL)
    {
        AddArrayToLog(Ar1, Ar2, N, DataRows);
        return;
    }

    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(DataRows==false)
    {
        for(int n=0; n<N; n++) fprintf(fp,"%g \t%g \t%g\n",Ar1[n],Ar2[n],Ar3[n]);
    }
    else
    {
        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Ar1[n]);
        fprintf(fp,"%g\n",Ar1[N-1]);
        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Ar2[n]);
        fprintf(fp,"%g\n",Ar2[N-1]);
        for(int n=0; n<N-1; n++) fprintf(fp,"%g\t",Ar3[n]);
        fprintf(fp,"%g\n",Ar3[N-1]);
    }
    fclose(fp);
}

void UConsoleInterface::TimeReset(const char* str)
{
    time(&ProcStartT);
    if(str && ConsoleOut==true) fprintf(stderr,"START %s",str);

    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(str) fprintf(fp,"START %s",str);
    fclose(fp);
}

void UConsoleInterface::TimeFlag(const char* str)
{
    time(&ProcEndT);
    if(str && ConsoleOut==true) fprintf(stderr,"STOP %s",str);
    if(ConsoleOut==true)        fprintf(stderr,"Elapsed Time: %d (s)\n",int(ProcEndT-ProcStartT));

    if(LogFileName==NULL || DisAbleLogging==true) return;

    FILE* fp=fopen(LogFileName,"at");
    if(fp==NULL) return;

    if(str) fprintf(fp,"STOP %s",str);
    fprintf(fp,"Elapsed Time: %d \n",int(ProcEndT-ProcStartT));
    fclose(fp);
}

void UConsoleInterface::TranslateArgs(UOption *Option, int Noption, const char* Intro)
/*
     Interpretate the options given by the user. Return error in any error,

     Option[]  - an array of options set by the programmer.
     Noption   - the total number of the options (including file and dataset names ) set
                 by the programmer.
     Intro[]   - Introduction text, passed to CreateBatFile() (lines separated by returns)

     If no arguments are present, Nargs==1, create a .bat-file.
     If arguments are wrong, print message and terminate program.
*/
{
    if(Nargs-1>Noption)
    {
        CI.AddToLog("ERROR: Too many parameters.\n");
        Usage(Option, Noption, Intro);
        PressReturnExit();
    }


/* Perform consistency test and count the number of File and DataSet names.*/
    int Nfile = 0;
    for(int k1=0; k1<Noption; k1++)
    {
        if(Option[k1].IsDisabled()) continue;
        if(Option[k1].GetType()==UOption::NOTYPE)
        {
            CI.AddToLog("INITIALIZATION ERROR: in option %d (%s).\n",k1,Option[k1].GetName());
            PressReturnExit();
        }
        if(Option[k1].GetType()==UOption::FILENAME ||
           Option[k1].GetType()==UOption::DATASETNAME ) Nfile++;

        if(Option[k1].ChequeDefault()!=U_OK)
        {
            CI.AddToLog("INITIALIZATION ERROR: Default out of range in or Identifier wrongly set. %s\n",Option[k1].GetIdentifier());
            PressReturnExit();
        }
    }

    if(Nargs==1)
    {
        if(ConsoleOut==true)
        {
            if(CreateBatFile(Option, Noption, Intro)==U_OK)
                CI.AddToLog("No arguments given. %s-file with default arguments created.\n",EXTEN);
            else
                CI.AddToLog("No arguments given. %s-file is NOT created, because it exists already.\n",EXTEN);
        }
        PressReturnExit(false);
    }

    if(Nargs-1<Nfile)
    {
        CI.AddToLog("ERROR There must be %d REQUIRED filenames/directories present\n",Nfile);
        PressReturn(-1);

        Usage(Option, Noption, Intro);
        PressReturnExit();
    }

/*Set file names. The last Nfile arguments correspond the the filenams/datasetname
  options in the same order as specified in the options array. */
    for(int k2=Nargs-Nfile, k1=0; k2<Nargs; k2++)
    {
        while(Option[k1].GetType()!=UOption::FILENAME &&
              Option[k1].GetType()!=UOption::DATASETNAME ) k1++;
        Option[k1++].SetOption(pArgs[k2]);
    }

/* Set the rest of the options*/
    ErrorType Error = U_OK;
    bool ArgOK;
    for(int k2=1; k2<Nargs-Nfile; k2++)   // First argument is the name of the calling programme
                                          // Last Nfile arguments are file names
    {
        if(pArgs[k2][0] != '-' && pArgs[k2][0] != '/')
        {
            Error = U_ERROR;
            CI.AddToLog("ERROR in argument %s. First character should be - or /. \n",pArgs[k2]);
        }
        ArgOK = false;
        for(int k1=0; k1<Noption; k1++)
        {
            if(Option[k1].GetType()==UOption::FILENAME ||
               Option[k1].GetType()==UOption::DATASETNAME) continue;
            switch(Option[k1].SetOption(pArgs[k2]+1))
            {
            case UOption::OK:
                ArgOK = true;
                break;
            case UOption::OP_ERROR:
                CI.AddToLog("ERROR in program argument %s.\n",pArgs[k2]);
                Error = U_ERROR;
                break;
            case UOption::WRONG_ID:
                break;
            case UOption::OUTOFRANGE:
                Error = U_ERROR;
                CI.AddToLog("ERROR argument %s out of range.\n",pArgs[k2]);
                break;
            }
            if(ArgOK==true) break;
        }
        if(ArgOK==false)
        {
            Error = U_ERROR;
            CI.AddToLog("ERROR argument %s not recognized. \n",pArgs[k2]);
        }
    }
    if(Error!=U_OK)
    {
        CI.AddToLog("ERROR There are %d filenames missing\n",Nfile-(Nargs-1));
        PressReturn(-1);

        Usage(Option, Noption, Intro);
        PressReturnExit();
    }
}

void UConsoleInterface::Usage(UOption *Option, int Noption, const char* Intro)
/*
    Print the name of the programme and its usage.

    Option[] - An array of options (and compulary filenames) that can (or must) be
               set by the user.
    Noption  - the number of filenames and options that can (must) be processed by the programme.
    Intro[]  - An introductory text describing the programme (line breaks must be set.)
 */
{
    if(ConsoleOut==false) return;

    fprintf(stderr,"General:\n%s \n\n",Intro);
    fprintf(stderr,"Usage:\n%s [options] ",ProgName);
    for(int k1=0; k1<Noption; k1++)
    {
        if(Option[k1].GetType()==UOption::FILENAME    ||
           Option[k1].GetType()==UOption::DATASETNAME)   fprintf(stderr,"%s ",Option[k1].GetName());
    }
    PressReturn(-1);

    for(int loop=0; loop<2; loop++)
    {
        int nline = 0;
        if(loop==0)
        {
            fprintf(stderr,"Options:\nEach option is a string, without spaces or blanks, consisting of \nan identifier and a value. Options can be set in any order.\n");
            nline = 2;
        }
        else
        {
            fprintf(stderr,"\n\nFiles:\nFile names and data set names must be set in the specified order. \nThey cannot be omitted.\nNote: The filenames should be given without quotes.");
            nline = 5;
        }

        for(int k1=0; k1<Noption; k1++)
        {
            if( (loop==0 && (Option[k1].GetType()==UOption::FILENAME    ||
                             Option[k1].GetType()==UOption::DATASETNAME) )
            ||  (loop==1 &&!(Option[k1].GetType()==UOption::FILENAME    ||
                             Option[k1].GetType()==UOption::DATASETNAME) ) ) continue;
            fprintf(stderr,"%s\n",Option[k1].PrintUsage());
            nline++;

            char* Help;
            while( (Help=Option[k1].PrintHelp())!=NULL)
            {
                fprintf(stderr,"%s\n",Help);
                PressReturn(nline++);
            }
            PressReturn(nline);
        }
    }
    PressReturn(-1);
}


bool UConsoleInterface::PressReturn(int nline)
{
    if(ConsoleOut==false) return true;
    if(!((nline+1)%21) || nline<0)
    {
        fprintf(stderr,"\nPress RETURN to continue\n");
        if(KeyEnable==true) while(!getchar());
        return true;
    }
    return false;
}

ErrorType UConsoleInterface::CreateBatFile(UOption *Option, int Noption, const char* Intro)
{
    size_t   nbytes = strlen(ProgName);
    char *BatchFile = new char[nbytes+10];
    if(BatchFile==NULL) return U_ERROR;

    memset(BatchFile, 0, nbytes+10);
    BatchFile[0]        = '.';
    BatchFile[1]        = SLASH;
    for(unsigned int k=0; k<nbytes; k++)
        if(ProgName[k]!='.') BatchFile[k+2] = ProgName[k];
        else                 break;
    strcat(BatchFile,EXTEN);

    if(DoesFileExist(BatchFile)==true)
    {
        delete[] BatchFile;
        return U_ERROR;
    }

    FILE* fp = fopen(BatchFile, "wt");
    char* command = new char[strlen(BatchFile)+16];
    sprintf(command,"chmod 777 %s",BatchFile);
    if(fp==NULL)
    {
        fprintf(stderr,"ERROR: UConsoleInterface::CreateBatFile(). Can not create %s.\n",BatchFile);
        delete[] BatchFile;
        delete[] command;
        return U_ERROR;
    }
    delete[] BatchFile;
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    char Comment[5] = "rem ";
    fprintf(fp,"echo off\n");
#else
    char Comment[3] = "# ";
    fprintf(fp,"unset echo\n");
#endif
    fprintf(fp,"%s This File is automatically created and contains the default arguments.\n",Comment);
    fprintf(fp,"%s \n",Comment);
    fprintf(fp,"%s \n",Comment);
    if(Version)  fprintf(fp,"%s Programme version : %s: %s\n",Comment, Version, VERSIONDATE);
    if(Author )  fprintf(fp,"%s Author            : %s\n",Comment, Author);
    fprintf(fp,"%s \n",Comment);
    fprintf(fp,"%s Introduction:\n%s ",Comment,Comment);
    for(unsigned int n=0; n<strlen(Intro); n++)
    {
        if(Intro[n]=='\n') fprintf(fp,"\n%s ",Comment);
        else               fprintf(fp,"%c",Intro[n]);
    }
    fprintf(fp,"\n");
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    fprintf(fp,"%s \n",Comment);
#else
    fprintf(fp,"./");
    fprintf(fp,"%s \n",Comment);
#endif

/* Print the programe name */
    fprintf(fp,"%s", ProgName);

/* Print the options first */
    for(int k=0; k<Noption; k++)
    {
        if(Option[k].GetType()==UOption::FILENAME ||
           Option[k].GetType()==UOption::DATASETNAME ) continue;
        fprintf(fp," %s",Option[k].PrintDefault());
    }

/* The print the Filenames */
    for(int k=0; k<Noption; k++)
    {
        if(! (Option[k].GetType()==UOption::FILENAME ||
              Option[k].GetType()==UOption::DATASETNAME )) continue;
        fprintf(fp," %s",Option[k].PrintDefault());
    }
    fprintf(fp,"\n");
    fprintf(fp,"%s\n",Comment);
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    fprintf(fp,"pause \n");
#endif
    fprintf(fp,"%s\n",Comment);
    fprintf(fp,"%s\n",Comment);

/*Print the help texts, after comment signs Comment[] */
    for(int k=0; k<Noption; k++)
    {
        if(Option[k].GetType()==UOption::FILENAME ||
           Option[k].GetType()==UOption::DATASETNAME ) continue;

        fprintf(fp,"%s %s\n",Comment, Option[k].PrintUsage());
        char* Help;
        while( (Help=Option[k].PrintHelp())!=NULL) fprintf(fp,"%s %s\n",Comment, Help);
    }

    for(int k=0; k<Noption; k++)
    {
        if(! (Option[k].GetType()==UOption::FILENAME ||
              Option[k].GetType()==UOption::DATASETNAME )) continue;

        fprintf(fp,"%s %s (REQUIRED)\n",Comment, Option[k].PrintUsage());
        char* Help;
        while( (Help=Option[k].PrintHelp())!=NULL) fprintf(fp,"%s %s\n",Comment, Help);
    }
    fclose(fp);
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    system(command);
#endif
    delete[] command;
    return U_OK;
}

void UConsoleInterface::PressReturnExit(bool SeeLogFile)
/*
    Print text and terminate program.
 */
{
    if(SeeLogFile && ConsoleOut==true)
    {
        fprintf(stderr,"Program Ended abnormally.\n");
        fprintf(stderr,"See file %s for details.\n",LogFileName);
    }
    if(ConsoleOut==true) fprintf(stderr,"Press Return to exit\n");
    if(KeyEnable==true) while(!getchar());
    exit(-1);
}

char* UConsoleInterface::GetProperties(const char *Comment) const
{
    char Begin[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,15);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties,0,MAXPROPERTIES);

    unsigned int nc = 0;
    if(ProgName && nc<MAXPROPERTIES-strlen(ProgName)-30)
        nc += sprintf(Properties+nc,"%s Programme = %s%c",Begin,ProgName,End);
    else if(nc<MAXPROPERTIES-30)
        nc += sprintf(Properties+nc,"%s Programme = %s%c",Begin,"Unknown",End);

    if(Version && CompilerVersion && nc<MAXPROPERTIES-strlen(Version)-strlen(CompilerVersion)-sizeof(VERSIONDATE)-40)
        nc += sprintf(Properties+nc,"%s Version   = %s: %s %s%c",Begin,Version,VERSIONDATE,CompilerVersion,End);
    else if(nc<MAXPROPERTIES-30)
        nc += sprintf(Properties+nc,"%s Version   = %s %c",Begin,"Unknown",End);

    if(Author && nc<MAXPROPERTIES-strlen(Author)-30)
        nc += sprintf(Properties+nc,"%s Author    = %s%c",Begin,Author,End);
    else if(nc<MAXPROPERTIES-30)
        nc += sprintf(Properties+nc,"%s Author    = %s%c",Begin,"Unknown",End);

    if(ProgArgs && nc<MAXPROPERTIES-strlen(ProgArgs)-30)
        nc += sprintf(Properties+nc,"%s Arguments = %s%c",Begin,ProgArgs,End);
    else if(nc<MAXPROPERTIES-30)
        nc += sprintf(Properties+nc,"%s Arguments = %s%c",Begin,"None",End);


    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: UConsoleInterface::GetProperties(). Array overflow: nc=%d .\n",(int)nc);

    return Properties;
}

char* UConsoleInterface::GetLastLogLines(int Nlines, int MaxChar)
{
    if(Nlines<=0) return NULL;
    if(MaxChar<80) MaxChar = 80;
    char* Text = new char[Nlines*MaxChar];
    if(Text==NULL)
    {
        CI.AddToLog("ERROR: UConsoleInterface::GetLastLogLines(). Memory allocation. Nlines=%d, MaxChar=%d . \n", Nlines, MaxChar);
        return NULL;
    }
    memset(Text, 0, Nlines*MaxChar);
    if(LogFileName==NULL)
    {
        const char* Etext = "ERROR: UConsoleInterface::GetLastLogLines(). LogFileName==NULL.";
        memcpy(Text,Etext,strlen(Etext));
    }
    else
    {
        FILE* fp=fopen(LogFileName,"rb");
        if(fp==NULL) return Text;

        fseek(fp, 0L, SEEK_END);
        unsigned long int ie = ftell(fp);
        unsigned long int ib = 0;
        if(ie>(unsigned)Nlines*(MaxChar-1)) ib = ie-Nlines*(MaxChar-1);
        fseek(fp, ib, SEEK_SET);

        size_t nc = sprintf(Text,"...");
        while(nc<(unsigned int)(Nlines-1)*MaxChar)
        {
            size_t len = strlen(Text);
            if(!GetLine(Text+nc, MaxChar, fp)) break;

            len = strlen(Text)-len;
            nc += len;
            if(Text[nc-1]!='\n') Text[nc-1]='\n';
        }
        fclose(fp);
    }
    return Text;
}

char* UConsoleInterface::GetLastLogSession()
{
    if(LogFileName==NULL) return NULL;
    FILE* fp=fopen(LogFileName,"rb");
    if(fp==NULL) return NULL;

    fseek(fp, 0, SEEK_END);
    unsigned int NewOffset = ftell(fp);
    unsigned int nbytes    = NewOffset-LogOffset+1;

    char* Text = new char[nbytes];
    if(Text==NULL)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UConsoleInterface::GetLastLogSession(). Memory allocation. nbytes = %d. \n", (int)nbytes);
        return NULL;
    }
    memset(Text, 0, nbytes);
    fseek(fp, LogOffset, SEEK_SET);
    fread(Text, nbytes-1, 1, fp);
    fclose(fp);
    return Text;
}
