/************************************************************************************/
/*                                                                                  */
/*     Include file for the UConsoleInterface-object.                               */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    09-08-99   creation.
  JdM    31-09-99   compatibility with the inclusion of "windows.h" (_WINDEF_)
  JdM    29-01-00   compatibility with the Borland compiler (system includes first
                    and skip 'typedef' in enums)
  JdM    02-01-02   use standard bool instead of enum BOOL
  JdM    29-08-02   #define bool in case of sparc
  JdM    16-10-02   skip #define bool in case of sparc
*/


#ifndef _CONSOLEINTERFACE_INCLUDED
#define _CONSOLEINTERFACE_INCLUDED

#ifdef __WIN32__ // Borland compiler
#ifndef WIN32
#define WIN32
#endif
#endif

#include<time.h>
#include"DLLio.h"
#include"PMTTypeDefines.h"


class UOption;

class DLL_IO UConsoleInterface
{
public:
    UConsoleInterface();
    UConsoleInterface(char** Args, int N, const char* Ver, const char* Aut);
    ~UConsoleInterface();
    UConsoleInterface& operator=(const UConsoleInterface& ci);

    const char*           GetProgName() const;
    const char*           GetAuthor() const;
    const char*           GetProgArgs() const;
    const char*           GetLogFileName() const;
    const char*           GetCompilerVersion() const;
    const char*           GetVersion() const;
    const char*           GetVersionDate() const;

    char*                 GetProperties(const char *Comment) const;
    ErrorType             ResetLogFile(void);
    unsigned int          GetLogFileSize(void) const;    

    void                  TranslateArgs(UOption *Option, int Noption, const char* Intro);
    void                  PressReturnExit(bool SeeLogFile=true);
    void                  EnableKey(void)               {KeyEnable  = true; }
    void                  DisableConsoleOutput(void);
    void                  EnableConsoleOutput(void);
    void                  DisableLogging(void)          {DisAbleLogging = true;}
    void                  EnableLogging(void)           {DisAbleLogging = false;}
    bool                  GetDisableLogging(void) const {return DisAbleLogging;}

    void                  AddToLog(const char* str) const;
    void                  AddToLog(const char* form, const char* str) const;
    void                  AddToLog(const char* form, const char* str1, const char* str2) const;
    void                  AddToLog(const char* form, const char* str1, const char* str2, const char* str3) const;
    void                  AddToLog(const char* form, const char* str1, const char* str2, const char* str3, const char* str4) const;
    void                  AddToLog(const char* form, const char* str1, int i) const;
    void                  AddToLog(const char* form, const char* str1, int i1, int i2) const;
    void                  AddToLog(const char* form, const char* str1, double doub1, double doub2) const;
    void                  AddToLog(const char* form, const int i) const;
    void                  AddToLog(const char* form, const int i1, const int i2) const;
    void                  AddToLog(const char* form, const int i1, const int i2, const int i3) const;
    void                  AddToLog(const char* form, const int i1, const int i2, const int i3, const int i4) const;
    void                  AddToLog(const char* form, const int i1, const int i2, const int i3, const int i4, const int i5) const;
    void                  AddToLog(const char* form, const int i, const double doub) const;
    void                  AddToLog(const char* form, const int i, const double doub1, const double doub2) const;
    void                  AddToLog(const char* form, const int i1, const int i2, const double doub) const;
    void                  AddToLog(const char* form, const int i1, const int i2, const double doub1, const double doub2) const;
    void                  AddToLog(const char* form, const int i, const char* str) const;
    void                  AddToLog(const char* form, const int i, const char* str1, const char* str2) const;
    void                  AddToLog(const char* form, const double doub) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2, const double doub3) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const double doub4) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const double doub4, const double doub5) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2, const double doub3, const int i1) const;
    void                  AddToLog(const char* form, const double doub, const int i) const;
    void                  AddToLog(const char* form, const double doub, const int i1, const int i2) const;
    void                  AddToLog(const char* form, const double doub, const int i1, const int i2, const int i3) const;
    void                  AddToLog(const char* form, const double doub1, const double doub2, int i) const;
    void                  AddToLog(const char* form, const char* str1, const double doub) const;
    void                  AddToLog(const char* form, const double doub, const char* str1) const;

    void                  AddArrayToLog(const int* Array, int N, bool DataRows);
    void                  AddArrayToLog(const double* Array, int N, bool DataRows);
    void                  AddArrayToLog(const double* Ar1, const double* Ar2, int N, bool DataRows);
    void                  AddArrayToLog(const double* Ar1, const double* Ar2, const double* Ar3, int N, bool DataRows);
    void                  AddArrayToLog(const double* Array, int N1, int N2, bool Transpose);

    void                  TimeReset(const char* str=NULL);
    void                  TimeFlag(const char* str=NULL);
    char*                 GetLastLogSession();
    char*                 GetLastLogLines(int Nlines, int MaxChar);

private:
    static int            CountDestr;      // Counts the number of times the desctructor is alled
    static const char*    DefProgName;     // Default name of the program
    static const char*    DefAuthor;       // Default name of the author
    static const char*    DefVersion;      // Default version number string
    static const char*    CompilerVersion; // Version of the compiler used to create the executable
    static unsigned int   MAXPROPERTIES;

    char*                 Properties;
    int                   NByteArgs;
    char*                 ArgsArray;      // All argument strings concatenated with zeroes in between
    char**                pArgs;          // Pointer to program argument strings in ArgArray (The first string refers to the program itself, the rest to the arguments)
    int                   Nargs;          // Number of arguments plus one.
    const char*           ProgName;       // Pointer to program name (excluding path)
    char*                 LogFileName;    // Copy of program .log-file name (derived from ProgName)
    const char*           Author;         // Pointer to Author name
    const char*           Version;        // Pointer to version string

    char*                 ProgArgs;       // All program arguments printed in one string

    time_t                ProgStartT;     // Program start time in s.
    time_t                ProgEndT;       // Program end time in s.
    time_t                ProcStartT;     // Procedure start time in s.
    time_t                ProcEndT;       // Procedure end time in s.
    unsigned int          LogOffset;      // Offset of the log file at the start of a new proram session

    bool                  KeyEnable;      // Enable the input from key board (iff false, skip that input)
    bool                  ConsoleOut;     // Disable writing to stderr.
    bool                  DisAbleLogging; // Temporary disable output to log-file

    bool                  PressReturn(int nline);

    ErrorType             CreateBatFile(UOption *Option, int Noption, const char* Intro);
    void                  Usage(UOption *Option, int Noption, const char* Intro);
};

#endif // _CONSOLEINTERFACE_INCLUDED
