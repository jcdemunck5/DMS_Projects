/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a conversion table.                                 */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    16-06-05   creation
  JdM    07-03-06   Added GetIOArrays()
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
*/

#include <math.h>

#include "ConversionTable.h"


void UConversionTable::SetAllMembersDefault()
{
    error          = U_OK;
    Table          = NULL;
    TableSize      = 0;
    TableSizeAlloc = 0;
    ConversionText = UString();
}

void UConversionTable::DeleteAllMembers(ErrorType E)
{
    delete[] Table;
    SetAllMembersDefault();
    error   = E;
}
UConversionTable::UConversionTable()
{
    SetAllMembersDefault();
}
UConversionTable::UConversionTable(UString Caption)
{
    SetAllMembersDefault();
    ConversionText = Caption;
}
UConversionTable::UConversionTable(const UConversionTable &ConTab)
{
    SetAllMembersDefault();
    *this = ConTab;
}

UConversionTable::~UConversionTable(void)
{
    DeleteAllMembers(U_OK);
}

UConversionTable& UConversionTable::operator=(const UConversionTable &ConTab)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UConversionTable::operator=(). Object = NULL.\n");
        static UConversionTable Tab; Tab.error = U_ERROR;
        return Tab;
    }
    if(&ConTab==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConversionTable::operator=(). Invalid NULL address in argument. \n");
    }
    if(&ConTab==this)  return *this;
        
    DeleteAllMembers(U_OK);

    TableSize      = ConTab.TableSize;
    TableSizeAlloc = ConTab.TableSizeAlloc;
    ConversionText = ConTab.ConversionText;
    
    if(ConTab.Table)
    {
        Table = new IOPair[ConTab.TableSizeAlloc];
        if(Table==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UConversionTable::operator=(). Memory allocation. \n");
            return *this;
        }
        for(int k=0; k<ConTab.TableSize; k++) Table[k] = ConTab.Table[k];
    }
    return *this;
}

ErrorType UConversionTable::AddPair(double Input, double Output, double InTolerance)
{
    if(Table==NULL || InTolerance<=0)
    {
        IOPair IO = {Input, Output};
        return AddPair(IO);
    }
    for(int k=0; k<TableSize; k++)
        if(fabs(Table[k].in-Input)<InTolerance) return U_OK;

    IOPair IO = {Input, Output};
    return AddPair(IO);
}
double UConversionTable::GetOutput(double Input, bool* OutOfRange) const
{
    if(Table==NULL)
    {
        CI.AddToLog("ERROR: UConversionTable::GetOutput(). Table not set.\n");
        if(OutOfRange) *OutOfRange = true;
        return 0.;
    }
    double MinIn = Table[0].in;
    double MaxIn = Table[0].in;
    double MinEr = fabs(Input-Table[0].in);
    int    Index = 0;

    for(int k=1; k<TableSize; k++)
    {
        double Test = fabs(Table[k].in-Input);
        if(Test<MinEr) 
        {
            MinEr = Test;
            Index = k;
        }
        if(Table[k].in<MinIn) MinIn = Table[k].in;
        if(Table[k].in>MaxIn) MaxIn = Table[k].in;
    }
    if(OutOfRange) *OutOfRange = (Input<MinIn || Input>MaxIn);

    return Table[Index].ot;
}

UString UConversionTable::GetOutputText(double Input) const
{
    bool   Range = false;
    double Out   = GetOutput(Input, &Range);
    if(Range==true) return ConversionText + UString("out of range");

    if(fabs(Out)>1.e-5) return ConversionText + UString(Out, "%12.8f");
    return ConversionText + UString(Out, "%12.8g");
}

ErrorType UConversionTable::ReAllocateMemory(void)
{
    if(TableSizeAlloc==TableSize) return U_OK;

    IOPair* TableNew = new IOPair[TableSize];
    if(TableNew==NULL)
    {
        CI.AddToLog("WARNING: UGrid::UConversionTable::ReAllocateMemory(). Re-allocating memory, TableSizeAlloc = %d, TableSize = %d  .\n", TableSizeAlloc, TableSize);
        return U_ERROR;
    }

    for(int n=0; n<TableSize; n++) TableNew[n] = Table[n];
    delete[] Table;    Table  = TableNew;
    TableSizeAlloc = TableSize;

    return U_OK;
}

ErrorType UConversionTable::AddPair(IOPair Pair)
{
    if(TableSizeAlloc-TableSize<1) // Allocate new memory for points
    {
        int NewAlloc = 2*TableSizeAlloc+2;
        if(NewAlloc<100)   NewAlloc = 100;
        if(NewAlloc>10000) NewAlloc = TableSizeAlloc+10000; 
        IOPair* TableNew = new IOPair[NewAlloc];
        if(TableNew==NULL)
        {
            CI.AddToLog("ERROR: UConversionTable::AddPair(). Memory allocation. TableSizeAlloc = %d, NewAlloc = %d  .\n", TableSizeAlloc, NewAlloc);
            return U_ERROR;
        }
        if(Table)
            for(int n=0; n<TableSize; n++) TableNew[n] = Table[n];
        delete[] Table;   
        Table          = TableNew;
        TableSizeAlloc = NewAlloc;
    }
    Table[TableSize++] = Pair;

    return U_OK;
}

ErrorType UConversionTable::PrintToLog(void)
{
    if(error!=U_OK) return U_ERROR;

    if(Table==NULL || TableSize<=0)
    {
        CI.AddToLog("Note: UConversionTable::PrintToLog(). Table is empty. ");
        return U_OK;
    }
    CI.AddToLog("Note: UConversionTable::PrintToLog(). Text = %s  \n", (const char*)ConversionText);
    CI.AddToLog("Note: UConversionTable::PrintToLog(). Size = %d  \n", TableSize);
    CI.AddToLog("Input \t Output \n");

    for(int k=0; k<TableSize; k++)
        CI.AddToLog("%g \t%g \n",Table[k].in,  Table[k].ot);
    return U_OK;
}

ErrorType UConversionTable::GetIOArrays(double** InputArr, double** OutputArr, int* NPair) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UConversionTable::GetIOArrays(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Table==NULL || TableSize<=0)
    {
        CI.AddToLog("ERROR: UConversionTable::GetIOArrays(). Table is empty. \n");
        return U_ERROR;
    }
    if(InputArr==NULL || OutputArr==NULL || NPair==NULL)
    {
        CI.AddToLog("ERROR: UConversionTable::GetIOArrays(). Erroneous NULL arguments. \n");
        return U_ERROR;
    }
    *InputArr  = new double[TableSize];
    *OutputArr = new double[TableSize];
    if(*InputArr==NULL  ||  *OutputArr==NULL)
    {
        delete[] *InputArr;  *InputArr  = NULL;
        delete[] *OutputArr; *OutputArr = NULL;
        CI.AddToLog("ERROR: UConversionTable::GetIOArrays(). Memory allocation, TableSize = %d. \n", TableSize);
        return U_ERROR;
    }
    *NPair = TableSize;
    for(int n=0; n<TableSize; n++)
    {
        (*InputArr )[n] = Table[n].in;
        (*OutputArr)[n] = Table[n].ot;
    }
    return U_OK;
}
