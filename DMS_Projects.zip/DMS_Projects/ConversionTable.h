#ifndef UCONVERSIONTABLE_H
#define UCONVERSIONTABLE_H

#include "String.h"


class DLL_IO UConversionTable
{
public:
    UConversionTable(void);
    UConversionTable(UString Caption);
    UConversionTable(const UConversionTable& ConTab);
    ~UConversionTable(void);
    UConversionTable& operator=(const UConversionTable &ConTab);


    ErrorType        GetError(void) const         {return error;}
    UString          GetConversionText(void) const {return ConversionText;}

    ErrorType        AddPair(double Input, double Output, double InTolerance=0.);
    double           GetOutput(double Input, bool* OutOfRange) const;
    UString          GetOutputText(double Input) const;
    ErrorType        GetIOArrays(double** InputArr, double** OutputArr, int* NPair) const;

    ErrorType        ReAllocateMemory(void);
    ErrorType        PrintToLog(void);

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    typedef struct
    {
        double in;
        double ot;
    } IOPair;
    ErrorType        error;
    IOPair*          Table;
    int              TableSize;
    int              TableSizeAlloc;
    UString          ConversionText;

    ErrorType        AddPair(IOPair Pair);
};


#endif // UCONVERSIONTABLE_H

