/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for computing convulutions between two time functions              */
/*     using the discrete Fourier transform. (Fastest Fourier Transform of the   */
/*     West).                                                                    */
/*     One of the time functions is set with the constructor and a copy is kept  */
/*     as a data member. The algorithm is most efficient when the same data      */
/*     sizes (number of data elements) is kept constant between subsequent calls */ 
/*     to ComputeConv().                                                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    21-06-02   creation (using parts of ULinearFilter)
  JdM    07-07-02   Added AddImpulseResponse(), Reset() and WindowImpulseResponse()
  JdM    08-07-02   Add SetManyFFT() to choose between FFTW_MEASURE and FFTW_ESTIMATE
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
GdV/JdM  28-10-02   Bug Fix: SmallPrimes(): 51 is not prime
  JdM    12-06-03   Use of the new global object FFTW in InitFFT()
  JdM    09-10-03   Bug Fix: Never use rfftw_destroy_plan() and rfftw_create_plan(), but use global object FFTW
                    to avoid multiple deletion of pointers
  JdM    04-07-04   Added SetAllMembersDefault(), DeleteAllMembers() and copy constructor
  JdM    07-07-04   SmallPrimes(): NPused=4 (instead of 5) This is more efficient
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    16-10-04   Bug fix: UConvolve::operator=(). timH[] has NsampH elements, not NFFT
  JdM    25-10-05   InitFFT(). Reduce output to LogFile ("Note: ")
  JdM    02-01-06   bug fix operator=(). Set pointers to NULL, immediately after delete[]
                                       . Copying plan pointers.
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
  JdM    23-05-10   Moved SmallPrimes() to BasicInclude.cpp
*/



#include "Convolve.h"

void UConvolve::SetAllMembersDefault(void)
{
    ManyFFT = true;
    NsampH  = 0;
    Shift   = 0;
    NFFT    = 0;
    Pforw   = NULL;
    Pback   = NULL;
    fftH    = NULL;
    fftD    = NULL;
    timH    = NULL;
    timD    = NULL;
    error   = U_OK;
}

void UConvolve::DeleteAllMembers(ErrorType E)
{
    delete[] fftH;
    delete[] fftD;
    delete[] timH;
    delete[] timD;
    SetAllMembersDefault();
    error  = E;
}

UConvolve::UConvolve()
{
    SetAllMembersDefault();
}

UConvolve::UConvolve(const double* H, int Nsamp)
{
    SetAllMembersDefault();
    if(H==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConvolve::UConvolve(). Invalid NULL pointer. \n");
        return;
    }
    if(Nsamp<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConvolve::UConvolve(). Arguments out of range: (Nsamp=%d) .\n",Nsamp);
        return;
    }

    timH   = new double[Nsamp];
    if(timH==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConvolve::UConvolve(). Memory allocation (Nsamp=%d) .\n",Nsamp);
        return;
    }

/* Copy the impulse response */
    NsampH = Nsamp;
    Shift  = (NsampH+1)/2;
    for(int j=0; j<Nsamp; j++) timH[j] = H[j];
}

UConvolve::UConvolve(const UConvolve& C)
{
    SetAllMembersDefault();
    *this = C;
}

UConvolve::~UConvolve(void)
{
    DeleteAllMembers(U_OK);
}

UConvolve& UConvolve::operator=(const UConvolve& C)
{
    if(this==NULL)
    {
        static UConvolve CC; CC.error = U_ERROR;
        CI.AddToLog("ERROR: UConvolve::operator=(). this == NULL  .\n");
        return CC;
    }
    if(&C==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UConvolve::operator=(). Invalid NULL address argument.\n");
        return *this;
    }
    if(this==&C) return *this;

    DeleteAllMembers(U_OK);
    ManyFFT = C.ManyFFT;
    error   = C.error;  
    NsampH  = C.NsampH;
    Shift   = C.Shift;
    
    NFFT    = C.NFFT;
    Pforw   = C.Pforw;
    Pback   = C.Pback;

/* Copy arrays, when set in argument object*/
    if(C.fftH)
    {
        fftH = new double[C.NFFT];
        if(fftH) for(int j=0; j<C.NFFT; j++) fftH[j] = C.fftH[j];
    }        
    if(C.fftD)
    {
        fftD = new double[C.NFFT];
        if(fftD) for(int j=0; j<C.NFFT; j++) fftD[j] = C.fftD[j];
    }        
    if(C.timH)
    {
        timH = new double[C.NsampH];
        if(timH) for(int j=0; j<C.NsampH; j++) timH[j] = C.timH[j];
    }        
    if(C.timD)
    {
        timD = new double[C.NFFT];
        if(timD) for(int j=0; j<C.NFFT; j++) timD[j] = C.timD[j];
    }
        

/* Test succes*/
    if( (!Pforw&&C.Pforw) ||
        (!Pback&&C.Pback) ||
        (!fftH &&C.fftH ) ||
        (!fftD &&C.fftD ) ||
        (!timH &&C.timH ) ||
        (!timD &&C.timD ) )
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: operator=() ERROR: UConvolve::operator=(). memory allocation.\n");
    }
    return *this;
}

ErrorType UConvolve::SetImpulseResponse(const double* H, int Nsamp)
{
    if(H==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::SetImpulsResponse(). Invalid NULL pointer. \n");
        return U_ERROR;
    }
    if(Nsamp<=0)
    {
        CI.AddToLog("ERROR: UConvolve::SetImpulsResponse(). Arguments out of range: (Nsamp=%d) .\n",Nsamp);
        return U_ERROR;
    }

    delete[] timH;
    timH   = new double[Nsamp];
    if(timH==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::SetImpulsResponse(). Memory allocation (Nsamp=%d) .\n",Nsamp);
        return U_ERROR;
    }

/* Copy the impulse response */
    NsampH = Nsamp;
    Shift  = (NsampH+1)/2;
    for(int j=0; j<Nsamp; j++) timH[j] = H[j];

    if(fftH && timD && NsampH<=NFFT) // Fourier transform the impuls response
    {
        for(int j=0;     j<NsampH; j++) timD[j] = timH[j];
        for(int j=NsampH;j<NFFT;   j++) timD[j] = 0.;
        rfftw_one(Pforw, timD, fftH);
    }
    else  // Invalidate the FFT plans
    {
        NFFT = 0;
        delete[] fftH; fftH = NULL;
        delete[] fftD; fftD = NULL;
        delete[] timD; timD = NULL;        
    }
    return U_OK;
}

ErrorType UConvolve::AddImpulseResponse(const double* H, int Nsamp) 
/*
    If no impulseresponse has been set yet, set the impulse response to H[]
    else replace the existing impulse response with its convolution with H[]
 */
{
    if(H==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::AddImpulsResponse(). Invalid NULL pointer. \n");
        return U_ERROR;
    }
    if(Nsamp<=0)
    {
        CI.AddToLog("ERROR: UConvolve::AddImpulsResponse(). Arguments out of range: (Nsamp=%d) .\n",Nsamp);
        return U_ERROR;
    }
    if(timH==NULL) return SetImpulseResponse(H, Nsamp);

    if(InitFFT(Nsamp)!=U_OK)
    {
        CI.AddToLog("ERROR: UConvolve::AddImpulseResponse(). Initializing the FFT-plan. \n");
        return U_ERROR;
    }

/* Copy Data to buffer and add zeroes. Fourier transform the input*/
    for(int j=0;    j<Nsamp; j++) timD[j] = H[j];
    for(int j=Nsamp;j<NFFT;  j++) timD[j] = 0.;
    rfftw_one(Pforw, timD, fftD); 

/* Complex multiply FFT of impulse response and data*/
    fftD[0] *= fftH[0];
    for(int k=1; k<(NFFT+1)/2; k++)
    {
        double Re    = fftD[k]*fftH[k]      - fftD[NFFT-k]*fftH[NFFT-k];
        double Im    = fftD[k]*fftH[NFFT-k] + fftD[NFFT-k]*fftH[k];
        fftD[k]      = Re;
        fftD[NFFT-k] = Im;
    }
    if(NFFT%2==0) fftD[NFFT/2] *= fftH[NFFT/2];

/* Transform back to time domain and copy result to the new impulse response time function */
    rfftw_one(Pback, fftD, timD);  

    Shift   = (NsampH+1)/2 + (Nsamp+1)/2;
    NsampH += Nsamp-1;
    delete[] timH;
    timH   = new double[NsampH];
    if(timH==NULL)
    {
        DeleteAllMembers(U_ERROR);;
        CI.AddToLog("ERROR: UConvolve::AddImpulseResponse(). Memory allocation: NsampH = %d .\n", NsampH);
        return U_ERROR;
    }

    for(int j=0; j<NsampH; j++) timH[j] = timD[j]/NFFT;

/* Invalidate the FFT plans   */
    NFFT = 0;
    delete[] fftH; fftH = NULL;
    delete[] fftD; fftD = NULL;
    delete[] timD; timD = NULL;        

    return U_OK;
}

    
ErrorType UConvolve::ComputeConv(double* Data, int Nsamp) 
/*
    Compute a filtered version of the array Data[], consisting of Nsamp samples,
    by convoluting Data with the data member timH[].

    Note: The convolution is computed as follows. 

          DataOut[j] = SUMk timH[k] * Data[j-k+Shift]
          
          Points of which the index j-k+Shift is out of range are set to zero.
          In other words, in the beginning of the transformed array the last
          points of timH are use and the end of that array the first points of
          timH are used.
          Initially Shift = (NsampH+1)/2, but when the impulse response is built up 
          from subsequent calls of AddImpulseResponse(), the Shift can be one sample
          more or less, in order to maintain constency with subsequent calls to ComputeConv()
 */
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::ComputeConv(). Erroneous NULL argument. \n");
        return U_ERROR;
    }
    if(InitFFT(Nsamp)!=U_OK)
    {
        CI.AddToLog("ERROR: UConvolve::ComputeConv(). Initializing the FFT-plan. \n");
        return U_ERROR;
    }

/* Copy Data to buffer and add zeroes. Fourier transform the data*/
    for(int j=0;    j<Nsamp; j++) timD[j] = Data[j];
    for(int j=Nsamp;j<NFFT;  j++) timD[j] = 0.;
    rfftw_one(Pforw, timD, fftD);  // fourier transform the data.

/* Complex multiply FFT of impulse response and data*/
    fftD[0] *= fftH[0];
    for(int k=1; k<(NFFT+1)/2; k++)
    {
        double Re    = fftD[k]*fftH[k]      - fftD[NFFT-k]*fftH[NFFT-k];
        double Im    = fftD[k]*fftH[NFFT-k] + fftD[NFFT-k]*fftH[k];
        fftD[k]      = Re;
        fftD[NFFT-k] = Im;
    }
    if(NFFT%2==0) fftD[NFFT/2] *= fftH[NFFT/2];

/* Transform back to time domain and copy result to Data[] array */
    rfftw_one(Pback, fftD, timD);  
    for(int j=0; j<Nsamp; j++) Data[j] = timD[j+Shift]/NFFT; // Skip 'overflow points'

    return U_OK;
}

ErrorType UConvolve::WindowImpulseResponse(const double* Win)
/*
    Multiply the impulse response sample by sample with the windowing function Win[]
    if(fftH) Recompute the fourier transform of timH[]
 */
{
    if(Win==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::WindowImpulseResponse(). Invalid NULL argument.\n");
        return U_ERROR;
    }
    if(timH==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::WindowImpulseResponse(). Impulse response not set (timH==NULL) .\n");
        return U_ERROR;
    }
    for(int j=0; j<NsampH; j++) timH[j] *= Win[j];
    
    if(fftH && timD && NsampH<=NFFT) // Fourier transform the impuls response
    {
        for(int j=0;     j<NsampH; j++) timD[j] = timH[j];
        for(int j=NsampH;j<NFFT;   j++) timD[j] = 0.;
        rfftw_one(Pforw, timD, fftH);
    }
    else  // Invalidate the FFT plans
    {
        NFFT = 0;
        delete[] fftH; fftH = NULL;
        delete[] fftD; fftD = NULL;
        delete[] timD; timD = NULL;        
    }
    return U_OK;
}

ErrorType  UConvolve::InitFFT(int NsampData) 
/*
    Initialize the object in such a way that the convolution between an array
    of NsampH samples and another array of NsampData samples can be done (NFFT is at
    least NsampH+NsampData+1).
    If NFFT has to be increased to deal with Nsamp, compute new FFT plans,
    allocate nevarrays for fftH and for fftD, and comupte the FFT of timH[]
    (which is stored in fftH). 
 */
{
    if(NsampData<=0)
    {
        CI.AddToLog("ERROR: UConvolve::InitFFT(). NsampData = %d .\n",NsampData);
        return U_ERROR;
    }
    if(timH==NULL)
    {
        CI.AddToLog("ERROR: UConvolve::InitFFT(). Impuls response not properly set (timH==NULL).\n");
        return U_ERROR;
    }

    if(NsampH+NsampData+1<=NFFT &&
        fftH && fftD && timH)    return U_OK; // current array (sizes) still valid

    NFFT         = SmallPrimes(NsampH+NsampData+1);
    bool OldPlan = FFTW.DoesRealPlanExist(NFFT, true) | FFTW.DoesRealPlanExist(NFFT, false);
    Pforw        = FFTW.GetRealPlan(NFFT, true,  ManyFFT);
    Pback        = FFTW.GetRealPlan(NFFT, false, ManyFFT);
        
    if(!Pforw || !Pback)
    {
        CI.AddToLog("ERROR: UConvolve::InitFFT(). Creating FFT forward plan with %d samples. \n",NFFT);
        return U_ERROR;
    }
    if(OldPlan==false)
        CI.AddToLog("Note: UConvolve::InitFFT(). NsampH=%d, NsampData=%d and NFFT=%d \n",NsampH, NsampData, NFFT);

    delete[] fftH; fftH = new double[NFFT];
    delete[] fftD; fftD = new double[NFFT];
    delete[] timD; timD = new double[NFFT];

    if(fftH==NULL || fftD==NULL || timH==NULL)
    {
        delete[] fftH; fftH = NULL;
        delete[] fftD; fftD = NULL;
        delete[] timD; timD = NULL;
        CI.AddToLog("ERROR: UConvolve::InitFFT(). Memory allocation. NFFT=%d .\n",NFFT);
        return U_ERROR;
    }

/* Fourier transform the impulse response with added zeroes. Use timD as temporary array.*/
    for(int j=0;     j<NsampH; j++) timD[j] = timH[j];
    for(int j=NsampH;j<NFFT;   j++) timD[j] = 0.;
    rfftw_one(Pforw, timD, fftH);
    
/* Set data arrays to 0.*/
    for(int j=0;j<NFFT; j++) timD[j] = fftD[j] = 0.;
    return U_OK;
}
