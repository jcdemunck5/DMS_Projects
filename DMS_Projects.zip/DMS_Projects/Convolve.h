#ifndef _CONVOLVE_INCLUDED
#define _CONVOLVE_INCLUDED

#include "BasicInclude.h"

class DLL_IO UConvolve
{
public:
    UConvolve();
    UConvolve(const double* H, int Nsamp);
    UConvolve(const UConvolve& C);
    virtual ~UConvolve(void);

    UConvolve&       operator=(const UConvolve& C);

    ErrorType        GetError(void) const {return error;}
    ErrorType        SetManyFFT(bool setMany) {ManyFFT=setMany; return U_OK;}
    
    ErrorType        SetImpulseResponse(const double* H, int Nsamp);
    ErrorType        AddImpulseResponse(const double* H, int Nsamp);
    ErrorType        WindowImpulseResponse(const double* Win);
    ErrorType        ComputeConv(double* Data, int Nsamp);

protected:
    int              NsampH; // Number of samples of first time function (typically impuls response)
    int              NFFT;   // Size of FFT (at least NsampH+Nsamples)
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    ErrorType        error;                        // General error flag

    bool             ManyFFT;// if(ManyFFT==true) use FFTW_MEASURE else use FFTW_ESTIMATE in creating FFT plans
    int              Shift;  // The number of samples that the output of ComputeConv() is shifted (usually (NsampH+1)/2)
    rfftw_plan       Pforw;  // Plans for forward or inverse FFT
    rfftw_plan       Pback;

    double*          fftH;   // The (NFFT-point) Fourier transform of H[]
    double*          fftD;   // The (NFFT-point) Fourier transform of Data[] (= temporary array, allocated once)
    double*          timH;   // A (NsampH-point) array containing the first time function (imp. res.) in the time domain
    double*          timD;   // A temporary (NFFT-point) array containing the data and leading zeroes

    ErrorType        InitFFT(int NsampData);
};

#endif // _CONVOLVE_INCLUDED
