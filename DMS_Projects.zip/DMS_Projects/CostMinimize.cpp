/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for setting the conditions under which a cost function             */
/*     is minimized.                                                             */
/*                                                                               */
/*     USAGE:                                                                    */
/*     The use of this object only makes sense in combination with the UMinimize */
/*     object, for which this object is a base class. UCostMinimize determines   */
/*     the minimization method and parameters, and it takes care that no         */
/*     conflicting parameters are set. Note that some paramers are used in the   */
/*     minimization method, while others are to be used in the evaluation of the */
/*     user-defined cost function.                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*     MAXSTRING is set in globalinit.h, which is to be included in the main     */
/*     function.                                                                 */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    14-12-98   Split Minimize.cpp into Minimize.cpp and CostMinimize.cpp, with one object each file
  JdM    20-12-98   Added more comments
  JdM    19-08-99   Remove CostType -parameter
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    17-12-00   Added PenaltyFactor
  JdM    29-01-02   Added functions to read the object parameters
                    Use allocated memory for the log file string
  JdM    04-07-03   operator=(). Test whether this==&cost.
  JdM    01-03-18   GetParameterString(). Return const char*
*/


#include <string.h>
#include <stdio.h>
#include "CostMinimize.h"

/* Inititalize static const parameters. */
const int    UCostminimize::MAXSTRING = 300;


UCostminimize::UCostminimize()  
{
    Normalize     = true;            
    Penalty       = false; 
    PenaltyFactor = 0.;
    Optimization  = U_SIMPLEX_BOOST; 
    Maxiter       = 5000;            
    Tolerance     = 0.0001;          
    StartOffset   = 200;  
    Hdif          = .001;
    NormalizePar  = true;
    AddToLog      = false;           
    LogFile       = NULL;            
    string        = new char[MAXSTRING];
}   

UCostminimize::UCostminimize(const UCostminimize &cost)
/* 
    The copy constructor.
 */
{
    Normalize     = cost.Normalize;   
    Penalty       = cost.Penalty; 
    PenaltyFactor = cost.PenaltyFactor;
    Optimization  = cost.Optimization;
    Maxiter       = cost.Maxiter;     
    Tolerance     = cost.Tolerance;   
    StartOffset   = cost.StartOffset; 
    Hdif          = cost.Hdif;
    NormalizePar  = cost.NormalizePar;
    AddToLog      = cost.AddToLog;    
    LogFile       = NULL;     
    if(cost.LogFile)
    {
        LogFile = new char[1+strlen(cost.LogFile)];
        if(LogFile) strcpy(LogFile, cost.LogFile);
    }
    string        = new char[MAXSTRING];
    if(string)
        memcpy(string, cost.string, MAXSTRING);
}

UCostminimize::~UCostminimize()
{
    delete[] string; 
    delete[] LogFile;
}

UCostminimize& UCostminimize::operator=(const UCostminimize &cost)
/* 
    The assignment operator.
*/
{
    if(this==&cost) return *this;

    Normalize     = cost.Normalize;   
    Penalty       = cost.Penalty;     
    PenaltyFactor = cost.PenaltyFactor;
    Optimization  = cost.Optimization;
    Maxiter       = cost.Maxiter;     
    Tolerance     = cost.Tolerance;   
    StartOffset   = cost.StartOffset; 
    Hdif          = cost.Hdif;
    NormalizePar  = cost.NormalizePar;
    AddToLog      = cost.AddToLog;    

    delete[] LogFile;
    LogFile       = NULL;     
    if(cost.LogFile)
    {
        LogFile = new char[1+strlen(cost.LogFile)];
        if(LogFile) strcpy(LogFile, cost.LogFile);
    }
    delete[] string;
    string        = new char[MAXSTRING];
    if(string)
        memcpy(string, cost.string, MAXSTRING);

    return *this;
}

void UCostminimize::SetOptMethod(OptimizeType Opt) 
{
    Optimization = Opt;
    if(Optimization == U_MARQUARDT || Optimization == U_MARQUARDT2) 
    {
        Normalize = false;
    }
}

void UCostminimize::SetPenaltyFactor(double PenFac)
{
    if(PenFac<=0) 
    {
        Penalty = false;
        return;
    }
    Penalty       = true;
    PenaltyFactor = PenFac;
}


void UCostminimize::SetLogFile(const char *Lfile)
{
    delete[] LogFile; LogFile = NULL;
    if(Lfile)
    {
        LogFile = new char[1+strlen(Lfile)];
        if(LogFile)  strcpy(LogFile, Lfile);
    }
    if(LogFile) AddToLog = true;
    else        AddToLog = false;
}

const char* UCostminimize::GetParameterString(void)
/* 
    Print out the current parameter settings.
*/
{
    if(string==NULL) 
        return "UCostminimize::GetParameterString(). Memory allocation error";
    
    memset(string,0,MAXSTRING);

    int n=0;
    if(Optimization != U_MARQUARDT && Optimization != U_MARQUARDT2)
    {
        if(Normalize) strncpy(string+n,"normalized, ",MAXSTRING-1-n);
    }
    else
    {
        strncpy(string+n,"Cost: ",MAXSTRING-1-n);
    }
    
    n=strlen(string);
    if(Penalty==true)
    {
        strncpy(string+n,"Penalty On; ",MAXSTRING-1-n);
        n=strlen(string);    
        sprintf(string+n,"Weight = %g; ",PenaltyFactor);
    }
    else
        strncpy(string+n,"Penalty Off; ",MAXSTRING-1-n);
    
    n=strlen(string);    
    switch(Optimization)
    {
    case U_SIMPLEX:
        strncpy(string+n,"Method: Simplex; ",MAXSTRING-1-n);
        break;
    case U_SIMPLEX_BOOST:
        strncpy(string+n,"Method: Simplex Boost; ",MAXSTRING-1-n);
        break;
    case U_POWELL:
        strncpy(string+n,"Method: Powell; ",MAXSTRING-1-n);
        break;
    case U_MARQUARDT:
        if(NormalizePar == true)
            strncpy(string+n,"Method: Marquardt, Norm. Par.; ",MAXSTRING-1-n);
        else
            strncpy(string+n,"Method: Marquardt, Parameters not normalized; ",MAXSTRING-1-n);
        break;
    case U_MARQUARDT2:
        if(NormalizePar == true)
            strncpy(string+n,"Method: Marquardt, ver2, Norm. Par.; ",MAXSTRING-1-n);
        else
            strncpy(string+n,"Method: Marquardt, ver2, Parameters not normalized; ",MAXSTRING-1-n);
        break;
    default:
        strncpy(string+n,"Method: UNKNOWN; ",MAXSTRING-1-n);
        break;
    }

    n  = strlen(string);    
    n += sprintf(string+n,"Maxiter: %d; ",Maxiter); 

    if(Tolerance>0)
        n += sprintf(string+n,"Tolerance: %9.6g (absolute).",Tolerance); 
    else
        n += sprintf(string+n,"Tolerance: %9.6g (relative).",-Tolerance); 


    return string;
}
