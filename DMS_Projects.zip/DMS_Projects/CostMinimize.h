#ifndef _COSTMINIMIZE_INCLUDED
#define _COSTMINIMIZE_INCLUDED

#include "BasicInclude.h"


class DLL_IO UCostminimize
{
public:
    enum OptimizeType
    {   U_NOMETHOD,
        U_SIMPLEX,
        U_SIMPLEX_BOOST,
        U_POWELL,
        U_MARQUARDT,
        U_MARQUARDT2};

    UCostminimize();
    UCostminimize(const UCostminimize &cost);
    virtual ~UCostminimize();

    UCostminimize& operator=(const UCostminimize &cost);

    void          SetOptMethod(OptimizeType Opt);
    void          SetMaxiter(int Mit)          {Maxiter       = Mit;}
    void          SetTolerance(double Tol)     {Tolerance     = Tol;}
    void          SetStartOffset(double SO)    {StartOffset   =  SO;}
    void          SetLogFile(const char *Lfile=NULL);
    void          SetNormalize(bool norm)      {Normalize     = norm;}
    void          SetHdif(double h)            {if(h!=0.) Hdif = h;  }
    void          SetPenaltyFactor(double PenFac);

    const char*   GetParameterString(void);
    OptimizeType  GetOptMethod(void) const     {return Optimization;}
    int           GetMaxiter(void) const       {return Maxiter;}
    double        GetTolerance(void) const     {return Tolerance;}
    double        GetStartOffset(void) const   {return StartOffset;}
    const char*   GetLogFile(void) const       {return LogFile;}
    double        GetPenaltyFactor(void) const {return PenaltyFactor;}

protected:
/* Parameters used in the minimization algorithm itself*/
    OptimizeType  Optimization; // Which optimization type to use? Simplex, Powell, etc.
    int           Maxiter;      // Maximum of cost function evaluations
    double        Tolerance;    // Tolerance level used for stopping iterations
    double        StartOffset;  // Parameter that determines the initial jump
    bool          NormalizePar; // Apply normalization of the variable to be optimized (Marquardt only)
    double        Hdif;         // Stepsize taken in numerical differentiation

/* Parameters used in the computation of the the cost function */
    bool          Normalize;    // Apply some normalization in the definition of the cost function
    bool          Penalty;      // Add penalty parameters that are too close to their out of range value
    double        PenaltyFactor;// Factor influencing the relative weight of the penalty w.r,t. the cost
    bool          AddToLog;     // If true, add iteration information to LogFile[]
    char          *LogFile;     // Name of log-file (NULL if no log is to be written)

private:
/* Other parameters transferred to the minimization algorithm itself*/
    static const int MAXSTRING; // Maximum number of characters printed in the properties of UCostminimize
    char          *string;
};

#endif  // _COSTMINIMIZE_INCLUDED
