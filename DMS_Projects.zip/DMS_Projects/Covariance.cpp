/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL                                                                    */
/*     Module set spatial and temporal covariance matrices.                       */
/*     The functions of the base class, UMatrixSymmetric() can be used to compute */
/*     various quantities involving covariance matrices.                          */
/*                                                                                */
/*     METHODS                                                                    */
/*                                                                                */
/*     USAGE                                                                      */
/*                                                                                */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    15-10-99   creation, derived from UInterpol()
  JdM    06-06-00   Changed implementation of SetEigenThresh()
  JdM    09-06-00   Use UMatrixSymmetric object to manipulate some of the matrices
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    03-08-00   Added constructor for identity matrix
                    Make the UMatrixSymmetric-object a base class from which UCovariance is derived.
  JdM    28-08-00   Added new variant of UCovariance object, using e-curve in time domain
  JdM    05-09-00   Added copy constructor.
  JdM    07-09-00   Use table to compute exponential decay in one of constructors
JdM/SG   16-10-00   BUG FIX: Test whether electrode positions are equal
  JdM    20-11-00   Made some pointers and functions const
  JdM    24-11-00   Added SetNoiseLevel()
  JdM    01-12-00   Added parameter to one of the constructors
  JdM    11-12-00   Added default constructor and operator=()
  FB     31-01-02   Added constructor for temporal cov with Poisson model
  JdM    07-03-02   Added the functions WriteXX() and WriteTT(). For that purpose, also\
                    added the data members GrMEG, GrEEG and SampleTimeMS
  JdM    03-07-02   Added new (generic) covariance types and theirs constructors
  JdM    18-07-02   Added new constructor, which reads a covariance file that may be either spatial or temporal
  FB     07-07-03   Added argument FileName in WriteTT() and WriteXX()
  JdM    02-11-04   Bug fix: operator=(). Setting pointers NULL without deleting
  JdM    04-11-04   "Relaxation" -constructor: Allow Nrelaxtime == 0
  JdM    12-11-04   "Relaxation" -constructor: Allow Nrelaxtime < 0
  JdM    05-01-06   Avoid inclusion of ReadCTFData.h: skip test nDim>=MAXCHANNELS in FileName, UGrid constructor
  JdM    12-03-07   GetProperties(): return const char*
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    06-03-08   Bug fix: UCovariance::UCovariance(): getc() returns int (not char). This effcts EOF test.
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    10-04-09   UCovariance(). Avoid use of non-standard stricmp()
  JdM    22-10-01   GetProperties(). Use UString()
  JdM    22-03-10   bug fix: UCovariance::UCovariance(). Skip test Properties==NULL
  JdM    07-08-12   Add matrix inversion parameter to all constructors. This is passed to the UMatrixSymmetric base class
                    Use UFileName class for CovarFile. Remove (obsolete) parameter nDim
  JdM    23-12-12   Added new covariance types: U_COV_DATA_XX and U_COV_DATA_TT
                    Added another WriteXX() and WriteTT()
  JdM    18-01-15   MAJOR UPDATE: Derived from UMatrixSymmetric instead of from (obsolete) UJacobi. 
                    Keep a few rudimentairy functions for later upating.See .h file. Add NPosEigen and Prew Data members.
                    Added SelectRowCol()
  JdM    28-01-15   Added GetAMAT(),GetATMA(),GetVTMV(),GetA1TMA2(),GetV1TMV2() and AxIsB(). These functions only include NPosEigen positive eigenvalues
  JdM    30-09-16   Random dipole constructor now also works for EEG. Arguments of constructor have changed.
  JdM    22-01-17   Renamed GetPreWhiten(), GetPostWhiten() into GetPreWhitened(), GetPostWhitened()
                    Changed arguments of GetMEGCovar() and GetEEGVar() into const USensor() and made them public
  JdM    23-01-17   Added GetVarDifferenceMat()
  JdM    26-01-17   GetEEGVar(). Do at least 4 iterations. Project EEG elecrodes on outer sphere.
*/

#include <string.h>

#include "Covariance.h"
#include "Projector.h"
#include "CTFDataSet.h"
#include "AnalyzeLineExt.h"
#include "Grid.h"

/* Inititalize static const parameters. */
UString  UCovariance::Properties       = UString();
static const double      HeadR         = 10.;


const char* GetCovTypeText(CovarType CovT)
{
    switch(CovT)
    {
    case U_COV_CONSTANTVARIANCE: return "IdentityMatrix";    
    case U_COV_VARIANCE:         return "NoCrossCorrelationsVaryingVariance";
    case U_COV_RANDIP:           return "RandomDipoleModel";
    case U_COV_ECURVE:           return "e-curve";
    case U_COV_FILE_XX:          return "SpatialFromCovFile";
    case U_COV_FILE_TT:          return "TemporalFromCovFile";
    case U_COV_DATA_XX:          return "SpatialFromDataFile";
    case U_COV_DATA_TT:          return "TemporalFromDataFile";
    case U_COV_GEN_XX:           return "SpatialGeneral";
    case U_COV_GEN_TT:           return "TemporalGeneral";
    }
    return "UnknownCovar";
}

void UCovariance::SetAllMembersDefault(void)
{
    CovT         = U_COV_CONSTANTVARIANCE;
    CovarFile    = UFileName();
    error        = U_ERROR;
    r0           = 0;
    Nrelax       = 0;
    SampleTimeMS = 0.;
    GrMEG        = NULL;
    GrEEG        = NULL;

    NPosEigen    = -1;
    Prew         = UMatrixSymmetric();

    Properties   = UString();
    error        = U_OK;
}
void UCovariance::DeleteAllMembers(ErrorType E)
{
    delete   GrMEG;
    delete   GrEEG;
    SetAllMembersDefault();
    error = E;
}

UCovariance::UCovariance() : UMatrixSymmetric()
{
    SetAllMembersDefault();
}
UCovariance::UCovariance(ErrorType E) : UMatrixSymmetric(E)
{
    SetAllMembersDefault();
    if(E==U_OK) Decompose();
    error = E;
}

UCovariance::UCovariance(int N) : UMatrixSymmetric(N)
{
    SetAllMembersDefault();

    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Base class not properly set.\n");
        return;
    }
    if(N<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Invalid N argument (%d). \n", N);
        return;
    }
    error = Decompose();
}

UCovariance::UCovariance(int N1, int N2, double Var1, double Var2)
{
    SetAllMembersDefault();

    if(N1<0 || N2<0 || N1+N2<=0)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Arguments out of range: N1=%d, N2=%d  \n", N1, N2);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Var1<=0. || Var2<=0.)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Arguments out of range: Var1=%f, Var2=%f  \n", Var1, Var2);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    double* Var = new double[N1+N2];
    if(Var==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Memory allocation: N1=%d, N2=%d  \n", N1, N2);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int n=0; n<N1+N2; n++) Var[n] = n<N1 ? Var1 : Var2;
    
    *this = UCovariance(N1+N2, Var);

    delete[] Var;
    error = Decompose();
}

UCovariance::UCovariance(int N, const double* Variance) : UMatrixSymmetric(Variance, N, N)
{
    SetAllMembersDefault();
    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Setting base class .\n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovT  = U_COV_VARIANCE;
    error = Decompose();
}

UCovariance::UCovariance(const UGrid *gridM, const UGrid *gridE, int Ntime, double stimeMS, CovarType CT) :
    UMatrixSymmetric()
/*
    Create Empty UCovariance object. 
    Matrix elements should later be added using operator+() and 
    scaled using operator*()
 */
{
    SetAllMembersDefault();

    if(CT==U_COV_DATA_TT)
    {
        if(gridM || gridE)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Sensor grids not compatible with data type %d .\n", U_COV_DATA_TT);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(Ntime<=0) // Parameter not used further
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Parameter out of range, Ntime = %d .\n", Ntime);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(stimeMS<=0.)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Parameter out of range, stimeMS = %f .\n", stimeMS);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        SampleTimeMS = stimeMS;
    }
    else if(CT==U_COV_DATA_XX)
    {
        if(gridM && (gridM->GetError()!=U_OK || gridM->GetNpoints()<=0))
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). MEG Sensor grid erroneous, Npoints = %d .\n", gridM->GetNpoints());
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(gridE && (gridE->GetError()!=U_OK || gridE->GetNpoints()<=0))
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). EEG Sensor grid erroneous, Npoints = %d .\n", gridM->GetNpoints());
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(gridM==NULL && gridE==NULL)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Neither MEG nor EEG Sensor grid set.\n");
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(gridM && gridE)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Only one of both, MEG or EEG, Sensor grid must be set.\n");
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    else
    {
        CI.AddToLog("ERROR: Covariance::UCovariance(). Covartype of wrong kind:  CT = %d .\n", U_COV_DATA_TT);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovT = CT;
    if(gridM) 
    {
        GrMEG = new UGrid(*gridM);
        if(GrMEG==NULL || GrMEG->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Copying MEG grid. \n");
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    if(gridE) 
    {
        GrEEG = new UGrid(*gridE);
        if(GrEEG==NULL || GrEEG->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: Covariance::UCovariance(). Copying EEG grid. \n");
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    error = Decompose();
}

UCovariance::UCovariance(const char* FileName, int nTime) : UMatrixSymmetric()
/*
     Read the temporal covariance from the file FileName[] to initialize this object.
     if(nTime<=0) read complete covariance matrix
     else         read upper left corner of covaraince matrix
                  Lauch error when nTime>number of samples in file
 */
{
    SetAllMembersDefault();

    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File does not exist: %s\n", FileName);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovarFile = UFileName(FileName);
    
    char line[200];
    char Item[20] = "";
    FILE* fp = fopen(FileName,"rb");

    fread(line,1,sizeof(line),fp);
    rewind(fp);
    if(strncmp(line,"// Covar",sizeof("// Covar")-1))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File %s is not a Covariance .cov-file. First charachters: %8s\n", FileName, line);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }

    int    nTimeFile  =  0;
    double Stime      = -1;
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;
        
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsIdentifierIs("DataType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("double",Item,false)==false)
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Data type should be double. (DataType = double). NOT %s\n",Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("ByteOrder"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if( ((IsStringCompatible("INTEL"   , Item, false)==true) && INTEL_PROCESSOR()==false) ||
                ((IsStringCompatible("Moterola", Item, false)==true) && INTEL_PROCESSOR()==true ) )
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Wrong byte order: %s\n", Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("CovarType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("TIME",Item,false)==false)
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Covariance type should be temporal covariance. (CovarType = TIME). NOT %s\n",Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("Ntime")) nTimeFile  = AA.GetNextInt();
        if(AA.IsIdentifierIs("Stime")) Stime      = AA.GetNextDouble();
    }
    if(nTimeFile<=0)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Number of time samples out of range or not set: nDim = %d\n", nTimeFile);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Stime<=0.)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). SampleTime out of range, or not set: Stime = %f [ms]\n",Stime);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nTime<=0)
    {
        nTime = nTimeFile;
    }
    else
    {
        if(nTime>nTimeFile)
        {
            fclose(fp);
            CI.AddToLog("ERROR: UCovariance::UCovariance(). Too many samples required (%d). In file =%d\n",nTime, nTimeFile);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }        
    }
    SampleTimeMS    = Stime;

    double*   CovMat = new double[nTime*nTime];

    if(CovMat==NULL)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        delete[] CovMat; 
        fclose(fp);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Memory allocation. \n");
        return;
    }

/* Read the covariance data*/
    rewind(fp);
    int cp1 = getc(fp);
    int cp2 = getc(fp);
    while(cp1!=12 || cp2!=12)
    {
        cp1 = cp2;
        cp2 = getc(fp);
        if(cp2==EOF)
        {
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            delete[] CovMat; 
            fclose(fp);
            CI.AddToLog("ERROR: UCovariance::UCovariance(). Unexpected end of file in cov-file : %s\n",FileName);
            return;
        }
    }
    for(int j1=0; j1<nTime; j1++)
    {
        fread(CovMat+j1*nTime, sizeof(double), nTime, fp);
        double dum;
        for(int j2=nTime; j2<nTimeFile; j2++) fread(&dum, sizeof(double), 1, fp);
    }
    fclose(fp);

/* Create UMatrixSymmetric base object*/
    *(UMatrixSymmetric*)this = UMatrixSymmetric(CovMat, nTime, nTime);
    delete[] CovMat;     
    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Creating base class.\n");
        return;
    }
    CovT  = U_COV_FILE_TT;
    error = Decompose();
}

UCovariance::UCovariance(const UMatrixSymmetric& MS, double STms)
/*
    Use the content of J to create a temporal covariance matrix object with sample time STms in ms
 */
{
    SetAllMembersDefault();

/* Test arguments*/
    if(&MS==NULL || MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Erroneous UMatrixSymmetric argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(STms<=0.)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Invalid sample time ST = %f \n", STms);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

/* copy data*/
    UMatrixSymmetric::operator=(MS);
    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Copying data .\n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    SampleTimeMS = STms;
    CovT         = U_COV_GEN_TT;
    error        = Decompose();
}

UCovariance::UCovariance(const UMatrixSymmetric& MS, const UGrid *gridM, const UGrid *gridE)
/*
    Use the contents of MS to create a spatial covariance matrix object.
 */
{
    SetAllMembersDefault();

/* Test arguments*/
    if(&MS==NULL || MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Erroneous UMatrixSymmetric argument. \n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if( (gridM && gridM->GetError()!=U_OK) || 
        (gridE && gridE->GetError()!=U_OK))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). At least one erroneous UGrid-object argument. \n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    int nDim = 0;
    if(gridM) nDim += gridM->GetNpoints();
    if(gridE) nDim += gridE->GetNpoints();
    if(nDim != MS.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Jacobi object not consistent with grid sizes. \n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nDim==0)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). nDim = 0 \n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

/* copy data*/
    UMatrixSymmetric::operator=(MS);
    if(gridM) GrMEG = new UGrid(*gridM);
    if(gridE) GrEEG = new UGrid(*gridE);
    if(UMatrixSymmetric::GetError()!=U_OK         ||
      (GrMEG && GrMEG->GetError()!=U_OK)          ||
      (GrEEG && GrEEG->GetError()!=U_OK) )
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Copying data .\n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovT  = U_COV_GEN_XX;
    error = Decompose();
}

UCovariance::UCovariance(const char* FileName)
/*
     Read the spatial/temporal covariance from the file FileName[] to initialize this object.

     If the covariance is of the temporal type, read all time samples.
     If the covariance is of the spatial type, read all MEG/EEG sensor covariances.

 */
{
    SetAllMembersDefault();

    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File does not exist: %s\n", FileName);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    
    char line[200];
    char Item[20] = "";
    FILE* fp = fopen(FileName,"rb");

    fread(line,1,sizeof(line),fp);
    rewind(fp);
    if(strncmp(line,"// Covar",sizeof("// Covar")-1))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File %s is not a Covariance .cov-file. First charachters: %8s\n", FileName, line);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }

    int  nDim     = 0;
    bool SpatType = false;
    bool TempType = false;
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;
        
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsIdentifierIs("DataType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("double",Item,false)==false)
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Data type should be double. (DataType = double). NOT %s\n",Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("ByteOrder"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if( ((IsStringCompatible("INTEL"   , Item, false)==true) && INTEL_PROCESSOR()==false) ||
                ((IsStringCompatible("Moterola", Item, false)==true) && INTEL_PROCESSOR()==true ) )
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Wrong byte order: %s\n", Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("CovarType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("SPACE",Item,false))     SpatType = true;
            else if(IsStringCompatible("TIME",Item,false)) TempType = true;
            else
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Invalid CovarType: %s.\n", Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("nX")) nDim = AA.GetNextInt();
    }
    if( (TempType==true  && SpatType==true) ||
        (TempType==false && SpatType==false))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Invalid covariance type.\n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(TempType==true)
    {
        *this = UCovariance(FileName, -1);
        fclose(fp);
        return;
    }

/* Spatial type: read MEG/EEG sensors*/
    UGrid GridMEG(nDim);
    UGrid GridEEG(nDim);
    if(GridMEG.GetError()!=U_OK || GridEEG.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Creating MEG/EEG UGrid objects .\n");
        fclose(fp);
        return;
    }

    int isM = 0;
    int isE = 0;    
    rewind(fp);
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);

        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsIdentifierIs("SENSOR")==false) continue;
    
        USensor S(AA.GetPointer());
        if(S.GetStype()==USensor::U_SEN_MAG || S.GetStype()==USensor::U_SEN_GRAD)
        {
            if(isM<nDim) GridMEG.SetSensor(&S,isM++);
        }
        if(S.GetStype()==USensor::U_SEN_EEG)
        {
            if(isM<nDim) GridEEG.SetSensor(&S,isE++);
        }
    }
    fclose(fp);

    GridMEG.RemoveSensors(isM, nDim-1);
    GridEEG.RemoveSensors(isE, nDim-1);

    UGrid* pGridMEG = &GridMEG; if(GridMEG.GetNpoints()<=0) pGridMEG = NULL;
    UGrid* pGridEEG = &GridEEG; if(GridEEG.GetNpoints()<=0) pGridEEG = NULL;

    *this = UCovariance(FileName, pGridMEG, pGridEEG);
    error = Decompose();
}

UCovariance::UCovariance(const char* FileName, const UGrid *gridM, const UGrid *gridE)
/*
     Read the spatial covariance from the file FileName[] to initialize this object.

     Give and error when sensors in gridM/gridE are not present in the covariance file
     or when they have different positions/orientations.

     if(gridM==NULL) ignore all magnetic sensors.
     if(gridE==NULL) ignore all electric sensors.
 */
{
    SetAllMembersDefault();

    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File does not exist: %s\n", FileName);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovarFile = UFileName(FileName);

    char line[200];
    char Item[20] = "";
    FILE* fp = fopen(FileName,"rb");

    fread(line,1,sizeof(line),fp);
    rewind(fp);
    if(strncmp(line,"// Covar",sizeof("// Covar")-1))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). File %s is not a Covariance .cov-file. First charachters: %8s\n", FileName, line);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    int nDim = 0;
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;
        
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsIdentifierIs("DataType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("double",Item,false)==false)
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Data type should be double. (DataType = double). NOT %s\n",Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("ByteOrder"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if( ((IsStringCompatible("INTEL"   , Item, false)==true) && INTEL_PROCESSOR()==false) ||
                ((IsStringCompatible("Moterola", Item, false)==true) && INTEL_PROCESSOR()==true ) )
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Wrong byte order: %s\n", Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("CovarType"))
        {
            strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
            if(IsStringCompatible("SPACE",Item,false)==false)
            {
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Covariance type should be spatial covariance. (CovarType = SPACE). NOT %s\n",Item);
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsIdentifierIs("nX")) nDim = AA.GetNextInt();
    }
    if(nDim<=0)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Number of channels out of range: nDim = %d\n",nDim);
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }

    rewind(fp);
    UGrid GrCov(nDim);

/* Read the sensor information of the covariance file.*/
    int is = 0;
    
    if(GrCov.GetError()==U_OK)
    {
        while(GetLine(line, sizeof(line), fp)!=NULL)
        {
            UAnalyzeLineExt AA(line);
        
            if(line[0]==12)
            {
                GetLine(line, sizeof(line), fp);
                if(line[0]==12) break;
            }
            if(AA.IsIdentifierIs("SENSOR")==false) continue;
            
            USensor S(AA.GetPointer());
            GrCov.SetSensor(&S,is++);
        }
    }
    
    int* IndexM = NULL;
    int* IndexE = NULL;

    int nMEG    = 0;
    int nEEG    = 0;
    if(gridM) IndexM = new int[nMEG=gridM->GetNpoints()];
    if(gridE) IndexE = new int[nEEG=gridE->GetNpoints()];
    double*   buffer = new double[nDim*nDim];
    double*   CovMat = new double[(nMEG+nEEG)*(nMEG+nEEG)];

    if(GrCov.GetError()!=U_OK   ||
       (gridM && IndexM==NULL)  ||
       (gridE && IndexE==NULL)  ||
        buffer         == NULL  ||
        CovMat         == NULL)
    {
        delete[] IndexM;
        delete[] IndexE;
        delete[] buffer;
        delete[] CovMat; 
        fclose(fp);
        CI.AddToLog("ERROR: UCovariance::UCovariance(). Memory allocation. \n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

    if(gridM)
    {
        GrMEG  = new UGrid(*gridM);
        if(GrMEG==NULL || GrMEG->GetError()!=U_OK)
        {
            delete[] IndexM;
            delete[] IndexE;
            delete[] buffer;
            delete[] CovMat; 
            fclose(fp);
            CI.AddToLog("ERROR: UCovariance::UCovariance(). Copying MEG grid (nMEG = %d ). \n",nMEG);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }

        for(int i=0; i<nMEG; i++)
        {
            IndexM[i] = -1;
            for(int k=0; k<nDim; k++)
            {
                if(GrCov.GetSensor(k) == gridM->GetSensor(i))
                {
                    IndexM[i] = k;
                    break;
                }
            }
            if(IndexM[i]<0)
            {
                delete[] IndexM;
                delete[] IndexE;
                delete[] buffer;
                delete[] CovMat;
                fclose(fp);
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Required MEG sensor %s does not match covariance file. \n",gridM->GetName(i));
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }
    }

    if(gridE)
    {
        GrEEG  = new UGrid(*gridE);
        if(GrEEG==NULL || GrEEG->GetError()!=U_OK)
        {
            delete[] IndexM;
            delete[] IndexE;
            delete[] buffer;
            delete[] CovMat; 
            fclose(fp);
            CI.AddToLog("ERROR: UCovariance::UCovariance(). Copying MEG grid (nEEG = %d ). \n",nEEG);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        
        for(int i=0; i<nEEG; i++)
        {
            IndexE[i] = -1;
            for(int k=0; k<nDim; k++)
            {
                if(GrCov.GetSensor(k) == gridE->GetSensor(i))
                {
                    IndexE[i] = k;
                    break;
                }
            }
            if(IndexE[i]<0)
            {
                delete[] IndexM;
                delete[] IndexE;
                delete[] buffer;
                delete[] CovMat;
                fclose(fp);
                CI.AddToLog("ERROR: UCovariance::UCovariance(). Required EEG sensor %s does not match covariance file. \n",gridE->GetName(i));
                UMatrixSymmetric::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }
    }

/* Read the covariance data*/
    rewind(fp);
    int cp1 = getc(fp);
    int cp2 = getc(fp);
    while(cp1!=12 || cp2!=12)
    {
        cp1 = cp2;
        cp2 = getc(fp);
        if(cp2==EOF)
        {
            delete[] IndexM;
            delete[] IndexE;
            delete[] buffer;
            delete[] CovMat;
            fclose(fp);
            CI.AddToLog("ERROR: UCovariance::UCovariance(). Unexpected end of file in cov-file : %s\n",FileName);
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    fread(buffer, sizeof(double), nDim*nDim, fp);
    fclose(fp);
 
/* Store the covariance data in the object variables*/
    for(int i1=0; i1<nMEG+nEEG; i1++)
    {
        int k1 = 0;
        if(i1<nMEG) k1 = IndexM[i1];
        else        k1 = IndexE[i1-nMEG];

        for(int i2=0; i2<nMEG+nEEG; i2++)
        {
            int k2 = 0;
            if(i2<nMEG) k2 = IndexM[i2];
            else        k2 = IndexE[i2-nMEG];

            CovMat[i1*(nMEG+nEEG)+i2] = buffer[k1*nDim+k2];
        }
    }
    delete[] IndexM;
    delete[] IndexE;
    delete[] buffer;

    nDim       = nMEG + nEEG;

/* Create UMatrixSymmetric base object*/
    *(UMatrixSymmetric*)this = UMatrixSymmetric(CovMat, nDim, nDim);
    delete[] CovMat;     
    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Jacobi decomposition of the covariance matrix.\n");
        return;
    }
    CovT  = U_COV_FILE_XX;
    error = Decompose();
}

UCovariance::UCovariance(const UGrid *gridM, const UGrid *gridE, int iref, double r, UVector3 Spos)    
/*
    Compute the theoretical covariance matrix, for sources on spherical
    surface with radius r0 about the center Spos.

    *gridM - The MEG sensor grid where the sources are located
    *gridE - The EEG sensor grid where the sources are located (Not yet implemented!!!)
    r0     - The radius of the sphere on which the distributed minimum norm 
             source is computed [cm].
    Spos   - Position of the sphere on which the distributed minimum norm 
             source is computed [cm].
 */
{ 
    SetAllMembersDefault();

    if( (gridM && gridM->GetError()!=U_OK) || (gridE && gridE->GetError()!=U_OK) || (gridM==NULL && gridE==NULL))
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance() : Both grids NULL or erroneous. \n");
        return;
    }
    if(gridM && gridM->GetGridType()!=UGrid::U_GRD_MEG) 
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance() : MEG grid contains non MEG sensors. \n");
        return;
    }
    if(gridE && gridE->GetGridType()!=UGrid::U_GRD_EEG)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance() : EEG grid contains non EEG sensors. \n");
        return;
    }

    CovT       = U_COV_RANDIP;
    SpherePos  = Spos;
    r0         = r;

    int nMEG   = gridM ? gridM->GetNpoints() : 0;
    int nEEG   = gridE ? gridE->GetNpoints() : 0;
    for(int i=0; i<nMEG; i++)
    {
        double Dist = (gridM->GetPosition(i) - SpherePos).GetNorm() -r0;
        if(Dist<.5 )
        {
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCovariance::UCovariance():  MEG Sensor %d closer than .5 cm. to sphere surface\n",i);
            return;
        }
    }
    if( HeadR-0.5 < r0)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance():  Dipoles closer than .5 cm. to outer surface\n");
        return;
    }

    GrMEG          = gridM ? new UGrid(*gridM)        : NULL;
    UMatrix CovMEG = gridM ? UMatrix(DNULL,nMEG,nMEG) : UMatrix();
    GrEEG          = gridE ? new UGrid(*gridE)        : NULL;
    UMatrix CovEEG = gridE ? UMatrix(DNULL,nEEG,nEEG) : UMatrix();
    UMatrix VarEEG = gridE ? UMatrix(DNULL,nEEG,nEEG) : UMatrix();

    if((gridM && (GrMEG==NULL ||GrMEG->GetError()!=U_OK || CovMEG.Data==NULL                     )) || 
       (gridE && (GrEEG==NULL ||GrEEG->GetError()!=U_OK || CovEEG.Data==NULL || VarEEG.Data==NULL)))
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Memory allocation Error, or copying grid.\n");
        return;
    }
    for(int i=0;i<nMEG;i++)
    {  
        for(int j=0;j<nMEG;j++)
        {
            if(j>=i) CovMEG.Data[i*nMEG+j] =  GetMEGCovar(gridM->GetSensor(i),gridM->GetSensor(j));
            else     CovMEG.Data[i*nMEG+j] =  CovMEG.Data[j*nMEG+i];
        }
    }
    for(int i=0;i<nEEG;i++)
    {  
        for(int j=0;j<nEEG;j++)
        {
            if(j>=i) VarEEG.Data[i*nEEG+j] =  GetEEGVar(gridE->GetSensor(i),gridE->GetSensor(j));
            else     VarEEG.Data[i*nEEG+j] =  VarEEG.Data[j*nEEG+i];
        }
    }
    if(gridE)
    {
        if(iref<0 || iref>=nEEG)
        {
            UMatrix E(DNULL, nEEG, 1);
            E.SetData(1.);
            UProjector P(E, true, "Const");
            P.SetComplement(true);
            CovEEG = P.GetPAP(-VarEEG)/2;
        }
        else
        {
            for(int i=0;i<nEEG;i++)
            {  
                for(int j=0;j<nEEG;j++)
                {
                   if(j>=i) CovEEG.Data[i*nEEG+j] =  0.5*(VarEEG.Data[j*nEEG+iref]+VarEEG.Data[i*nEEG+iref]-VarEEG.Data[i*nEEG+j]);
                   else     CovEEG.Data[i*nEEG+j] =  CovEEG.Data[j*nEEG+i];
                }
            }
        }
    }
    if(gridM) CovMEG.ForceSymmetricType(1.e-10);
    if(gridE) CovEEG.ForceSymmetricType(1.e-10);

/* Create UMatrixSymmetric base object*/
    *(UMatrixSymmetric*)this = UMatrixSymmetric(DNULL, nMEG+nEEG, nMEG+nEEG);
    if( (gridM&&SetBlock(0,0,CovMEG)!=U_OK) || (gridE&&SetBlock(nMEG,nMEG,CovEEG)!=U_OK))
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Copying covariance matrix.\n");
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    CovT  = U_COV_RANDIP;
    error = Decompose();
}

UCovariance::UCovariance(int N, int Nrelaxtime, double Diag, int HalfPeriod)
/*
    Generate a stationary (Toeplitz) matrix with exponential decay.
 */
{
    SetAllMembersDefault();
    CovT         = U_COV_ECURVE;
    SampleTimeMS = 1.;
    Nrelax       = Nrelaxtime;

    if(N<=0 || Nrelaxtime<0)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameters: N=%d and Nrelaxtime=%d  .\n", N, Nrelaxtime);
        return;
    }
    if(Diag<=1)
        CI.AddToLog("WARNING: UCovariance::UCovariance(): Diagonal negative (%f). Resulting covariance matrix might ne non-positive. \n", Diag);

    if(Nrelaxtime==0)
        CI.AddToLog("WARNING: UCovariance::UCovariance(): Relaxation parameter = %d. Matrix set to identity, with CovType=%d  . \n", Nrelaxtime, CovT);

    double* CovMat  = new double[N*N];
    double* CovFunc = new double[N];
    if(CovMat==NULL || CovFunc==NULL)
    {
        delete[] CovFunc;
        delete[] CovMat;
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Memory allocation Error. N=%d\n",N);
        return;
    }

    if(Nrelaxtime>0) 
    {
        double Tconst = 1./Nrelaxtime;
        for(int j12=0; j12<N; j12++) CovFunc[j12] = exp(-j12*Tconst);

        if(HalfPeriod>0)
        {
            int Period = 2*HalfPeriod;
            for(int j12=0; j12<N; j12++) 
            {
                if( (j12%Period)<HalfPeriod) continue;
                CovFunc[j12] = -CovFunc[j12];
            }
        }
        CovFunc[0] = Diag;

        for(int j1=0; j1<N; j1++)
            for(int j2=0; j2<N; j2++) CovMat[j1*N+j2] = CovFunc[abs(j1-j2)];
    }
    else 
    {
        CovFunc[0] = 1.;
        for(int j12=1; j12<N; j12++) CovFunc[j12] = 0.;
        for(int j1=0; j1<N; j1++)
            for(int j2=0; j2<N; j2++) CovMat[j1*N+j2] = CovFunc[abs(j1-j2)];
    }
    delete[] CovFunc;

/* Create UMatrixSymmetric base object*/
    *(UMatrixSymmetric*)this = UMatrixSymmetric(CovMat, N, N);
    delete[] CovMat;

    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Jacobi-decomposition of the covariance matrix.\n");
        return;
    }
    CovT         = U_COV_ECURVE;
}
ErrorType UCovariance::SelectRowCol(const bool* SelectRowCol)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::SelectRowCol(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(UMatrixSymmetric::SelectRowCol(SelectRowCol)!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::SelectRowCol(). Row/collumn selection of base class.\n");
        return U_ERROR;
    }

    ErrorType E = U_OK;
    if(CovT==U_COV_RANDIP || CovT==U_COV_FILE_XX || U_COV_DATA_XX)
    {
        if(GrMEG && GrEEG)
        {
            int nMEG = GrMEG->GetNpoints();
            if(E==U_OK) E = GrMEG->SelectSensors(SelectRowCol);
            if(E==U_OK) E = GrEEG->SelectSensors(SelectRowCol+nMEG);
        }
        else if(GrMEG) E = GrMEG->SelectSensors(SelectRowCol);
        else if(GrEEG) E = GrEEG->SelectSensors(SelectRowCol);
    
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UCovariance::SelectRowCol(). Selecting sensors.\n");
            return U_ERROR;
        }
        if(GrMEG && GrMEG->GetNpoints()==0) {delete GrMEG; GrMEG=NULL;}
        if(GrEEG && GrEEG->GetNpoints()==0) {delete GrEEG; GrEEG=NULL;}
    }
    return E;
}


static double Integrand1(double,double,double,double,double,double);
static double Integrand2(double,double,double,double,double,double);
static double Integrand3(double,double,double,double,double,double);
static double Integrand4(double,double,double,double,double,double);
static double Conv(double La, double t);
static double Trapzd(double (*func)(double,double,double,double,double,double),double, double, double, double, double, double a, double b, int n);
static double Simpson(double (*func)(double,double,double,double,double,double),double, double, double, double, double, double a, double b);

UCovariance::UCovariance(int nT, double SR, double tShift,double tpp, double linpar[3], double nonlinpar[3])
// This routine computes the theoretical temporal covariance matrix assuming the Poisson model:
// The parameter arrays are linpar = [Om,sig0,sig1] and nonlinpar = [w,La,k].
// tShift denotes the shift of the first timesample of the analysis epoch with respect to
// the begin point of the baseline correction interval. tpp is the length of this
// correction interval. Both tpp and tShift are in ms. 

{
    SetAllMembersDefault();

    CovT        = U_COV_POISSON;

    double w    = nonlinpar[0];
    double La   = nonlinpar[1];
    double k    = nonlinpar[2];
    double Om   = linpar[0];
    double sig0 = linpar[1];
    double sig1 = linpar[2];

    if(nT<=0 || SR<=0 || tpp<0 || w<=6.28*7/1000 || w>=6.28*13/1000 || Om<0 || La<=0 || k<0 || sig0<0 || sig1<0)
    {
        if (nT<=0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter nT: %d\n", nT);
        if (SR<=0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter SR: %d\n", SR);
        if (tpp<0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter tpp: %d\n", tpp);
        if (w<=6.28*7/1000 || w>=6.28*13/1000)
                              CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter w: %d\n", w);
        if (Om<=0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter Om: %d\n", Om);
        if (La<=0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter La: %d\n", La);
        if (k <=0)            CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter k: %d\n", k);
        if (sig0<=0)          CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter sig0: %d\n", sig0);
        if (sig1<0)           CI.AddToLog("ERROR: UCovariance::UCovariance(): Illegal parameter sig1: %d\n", sig1);

        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

    SampleTimeMS    = 1000./SR;

    double* CovMat  = new double[nT*nT];
    if(CovMat==NULL)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UCovariance::UCovariance(): Memory allocation Error. nT=%d\n",nT);
        return;
    }

/* Computing lower diagonal part of CovMat */
    double t  = 0.;
    double dt = 0.;
    for(int jp=0;jp<nT;jp++)                 // loop over rows of CovMat
    {
        for(int jac=jp;jac<nT;jac++)         // loop over columns of CovMat
        {       
            t = jp*1000/SR + tShift;
            dt = (jac-jp)*1000/SR;

            double OmPart  =0.;
            double Sig0Part=0.;
            double Sig1Part=0.;
            double integral1 = Simpson(Integrand1, w, La, tpp, dt, t, 0, tpp);     // part of cov formula for Poisson Process
            double integral2 = Simpson(Integrand2, w, La, tpp, dt, t, -tpp, tpp);  // part of cov formula for Poisson Process
            double integral3 = Simpson(Integrand3, k, 0, tpp, dt, t, 0, tpp);      // part of cov formula for Additional Noise
            double integral4 = Simpson(Integrand4, k, 0, tpp, dt, t, -tpp, tpp);   // part of cov formula for Additional Noise

            OmPart = (0.5*cos(w*dt)*Conv(La,dt)+integral1+integral2);
            Sig0Part = ((exp(-k*fabs(dt)))+integral3+integral4);
            if (dt==0.)              // main diagonal has additional sig1
                Sig1Part = 1;
            else if (dt<2000/SR)     // first subdiagonals have additional 0.5*sig1
                Sig1Part = 0.5;
            else
                Sig1Part = 0.;
         
            CovMat[jp*nT+jac] = Om*OmPart+sig0*Sig0Part+sig1*Sig1Part;
        }
    }

/* Copying off diagonal elements in symmetric matrix CovMat */
    for(int jp=0;jp<nT;jp++) 
    {
        for(int jac=0;jac<jp;jac++)
        {
            CovMat[jp*nT+jac]= CovMat[jac*nT+jp];
        }
    }

    *(UMatrixSymmetric*)this = UMatrixSymmetric(CovMat, nT, nT);
    delete[] CovMat;

    if(UMatrixSymmetric::GetError()!=U_OK)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::UCovariance(): Setting base class data.\n");
        return;
    }
}

UCovariance::UCovariance(const UCovariance &Cov) : UMatrixSymmetric(Cov)
/*
    The copy constructor
 */
{
    SetAllMembersDefault();
    *this = Cov;
}

UCovariance::~UCovariance()
{
    DeleteAllMembers(U_OK);
}

UCovariance& UCovariance::operator=(const UCovariance &Cov)
{
    if(this==NULL)
    {
        static UCovariance Dummy(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::operator=(). this has NULL address. \n");
        return Dummy;
    }
    if(&Cov==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Cov) return *this;

    UMatrixSymmetric::operator=(Cov);
    if(UMatrixSymmetric::GetError() != U_OK)
    {
        UMatrixSymmetric::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCovariance::operator=(). Copying base class. \n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    CovT         = Cov.CovT;
    SpherePos    = Cov.SpherePos;
    r0           = Cov.r0;
    Nrelax       = Cov.Nrelax;
    SampleTimeMS = Cov.SampleTimeMS;
    CovarFile    = Cov.CovarFile;

    if(Cov.GrMEG)
    {
        GrMEG = new UGrid(* (Cov.GrMEG));
        if(GrMEG==NULL || GrMEG->GetError()!=U_OK)
        {
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCovariance::operator=(). Copying MEG grid. \n");
            return *this;
        }
    }
    if(Cov.GrEEG)
    {
        GrEEG = new UGrid(* (Cov.GrEEG));
        if(GrEEG==NULL || GrEEG->GetError()!=U_OK)
        {
            UMatrixSymmetric::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UCovariance::operator=(). Copying EEG grid. \n");
            return *this;
        }
    }

    NPosEigen    = Cov.NPosEigen;
    Prew         = Cov.Prew;

    return *this;
}

ErrorType UCovariance::WriteXX(UFileName Fcov, const char* Comment, bool ASCII) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Object NULL or erroneous. \n");
        return U_ERROR;
    }

    if(UMatrixSymmetric::GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Matrix not set. \n");
        return U_ERROR;
    }

    if(CovT!=U_COV_RANDIP && CovT!=U_COV_DATA_XX && CovT!=U_COV_FILE_XX && CovT!=U_COV_GEN_XX)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Object of the wrong type: CovT=%d .\n", CovT);
        return U_ERROR;
    }
    if(GrMEG==NULL && GrEEG==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). MEG/EEG Grids are not set. \n");
        return U_ERROR;
    }
    FILE* fp = NULL;
    if(ASCII==true)
    {
        Fcov.SetExtension("txt");
        fp = fopen(Fcov,"wt");
    }
    else
    {
        fp = fopen(Fcov, "wb");
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Cannot open file: %s \n", (const char*)Fcov);
        return U_ERROR;
    }
    int nX = 0;
    if(GrMEG) nX += GrMEG->GetNpoints();
    if(GrEEG) nX += GrEEG->GetNpoints();

    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    if(Comment)
    {
        fprintf(fp,"// ");
        for(unsigned int k=0; k<strlen(Comment); k++)
        {
            if(Comment[k]=='\n') 
            {
                fprintf(fp,"\n");
                if(k!=strlen(Comment)-1) fprintf(fp,"// ");
            }
            else
                fprintf(fp,"%c",Comment[k]);
        }
    }
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = SPACE   // SPACE or TIME \n");
    fprintf(fp,"    nX        = %d      // Number of channels \n", nX);
    if(GrMEG)
    {
        int nP = GrMEG->GetNpoints();
        for(int i=0; i<nP; i++) fprintf(fp,"    SENSOR = %s \n",GrMEG->GetSensor(i).GetProperties());
    }
    if(GrEEG)
    {
        int nP = GrEEG->GetNpoints();
        for(int i=0; i<nP; i++) fprintf(fp,"    SENSOR = %s \n",GrEEG->GetSensor(i).GetProperties());
    }
    fprintf(fp,"}\n");
    
    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12);    
        fwrite(GetMatrixArray(),sizeof(double),nX*nX,fp);
    }
    else
    {
        fprintf(fp,"Spatial Covariance Matrix: \n");    
        const double* Mat = GetMatrixArray();
        for(int i1=0; i1<nX; i1++)
        {
            for(int i2=0; i2<nX; i2++) fprintf(fp,"\t%g ",Mat[i1*nX+i2]);
            fprintf(fp,"\n");
        }
    }
    fclose(fp);

    return U_OK;
}
ErrorType UCovariance::WriteXX(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* Filename) const
/*
    Export the covariance matrix, assuming it is of the spatial type, in
    the standard format, using the standard name in the CTFDataSet directory 
    defined in *DSet. If ASCII==true, export the covariance in ASCII format.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DSet==NULL || DSet->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteXX(). Erroneous DSet argument. \n");
        return U_ERROR;
    }

    UFileName Fcov;
    if (Filename) Fcov = UFileName(Filename);
    else          Fcov = UFileName(DSet->GetSpatCovarFileName());

    return WriteXX(Fcov, Comment, ASCII);
}

ErrorType UCovariance::WriteTT(UFileName Fcov, const char* Comment, bool ASCII) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(UMatrixSymmetric::GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Matrix not set. \n");
        return U_ERROR;
    }

    if(CovT!=U_COV_ECURVE && CovT!=U_COV_DATA_TT && CovT!=U_COV_FILE_TT && CovT!=U_COV_POISSON && CovT!=U_COV_GEN_TT)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Object of the wrong type: CovT=%d .\n", CovT);
        return U_ERROR;
    }

    FILE* fp = NULL;
    if(ASCII==true)
    {
        Fcov.SetExtension("txt");
        fp = fopen(Fcov,"wt");
    }
    else
    {
        fp = fopen(Fcov, "wb");
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Cannot open file: %s \n", (const char*)Fcov);
        return U_ERROR;
    }
    
    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    if(Comment)
    {
        fprintf(fp,"// ");
        for(unsigned int k=0; k<strlen(Comment); k++)
        {
            if(Comment[k]=='\n') 
            {
                fprintf(fp,"\n");
                if(k!=strlen(Comment)-1) fprintf(fp,"// ");
            }
            else
                fprintf(fp,"%c",Comment[k]);
        }
    }
    int nDim = UMatrixSymmetric::GetNrow();
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = TIME    // SPACE or TIME\n");
    fprintf(fp,"    Ntime = %d   // Number of samples \n",nDim);
    fprintf(fp,"    Stime = %f   // ms.\n",SampleTimeMS);
    fprintf(fp,"}\n"); 

    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12);
        fwrite(GetMatrixArray(),sizeof(double),nDim*nDim,fp);
    }
    else
    {
        fprintf(fp,"Temporal Covariance Matrix: \n");    
        const double* Mat = GetMatrixArray();
        for(int j1=0; j1<nDim; j1++)
        {
            for(int j2=0; j2<nDim; j2++) fprintf(fp,"\t%g ",Mat[j1*nDim+j2]);
            fprintf(fp,"\n");
        }
    }
    fclose(fp);
    
    return U_OK;
}

ErrorType UCovariance::WriteTT(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* Filename) const
/*
    Export the covariance matrix, assuming it is of the temporal type, in
    the standard format, using the standard name in the CTFDataSet directory 
    defined in *DSet. If ASCII==true, export the covariance in ASCII format.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DSet==NULL || DSet->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::WriteTT(). Erroneous DSet argument. \n");
        return U_ERROR;
    }

    UFileName Fcov;
    if (Filename) Fcov = UFileName(Filename);
    else          Fcov = UFileName(DSet->GetTempCovarFileName());

    return WriteTT(Fcov, Comment, ASCII);
}

const UString& UCovariance::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UCovariance-object\n");
        return Properties;
    }

    Properties  = UString();
    Properties += UString(GetCovTypeText(CovT),"CovarianceType   = %s \n");
    switch(CovT)
    {
    case U_COV_RANDIP: 
        Properties += UString(r0                       ," R0               = %f \n");
        Properties += UString(SpherePos.GetProperties()," SpherePos        = %s \n");
        break;
    case U_COV_ECURVE:
        Properties += UString(Nrelax                   ," NSampRelax       = %d \n");
        break;
    case U_COV_FILE_XX:
    case U_COV_FILE_TT:
        Properties += UString((const char*)CovarFile   ," CovarFile        = %s \n");
        break;
        
    }
    Properties += UString(NPosEigen," NPosEigen        = %d \n");
    Properties += Comment+UString(" Baseclass: \n");
    Properties += UMatrixSymmetric::GetProperties(Comment);

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}


// private funtions:
double UCovariance::GetMEGCovar(const USensor& S1, const USensor& S2)
/*
    Compute the theoretical covariance between the sensor sens1 of grid1 and sensor sens2 of grid2.
 */
{
    double g1,g2,g3,g4;             // Geometrical factors
    double s1,s2,s3,s4;             // Sums of Legendre functions
    double r1,r2;                   // Radial coordinates
    
    UVector3 x1 = S1.Getx() - SpherePos;
    UVector3 n1 = S1.Getn();

    UVector3 x2 = S2.Getx() - SpherePos;
    UVector3 n2 = S2.Getn();
        
    r1    =  x1.GetNorm(); 
    r2    =  x2.GetNorm();
    x1    =  x1/r1;
    x2    =  x2/r2;
 
// Compute the geometrical factors
    UVector3 x1x2 = x1^x2;
    UVector3 n1x1 = n1^x1;
    UVector3 n2x2 = n2^x2;

    g1    = (n1&x1)*(n2&x2);
    g2    =  x1x2&(((n2&x2)*n1x1)-((n1&x1)*n2x2));
    g3    = -n1x1&(x1^(x2^n2x2));
    g4    = -(x1x2&n1x1)*(x1x2&n2x2);

// Compute the Legendre series 
    Legendre( x1&x2, r0*r0/(r1*r2), &s1, &s2, &s3, &s4);
    return 10.e6*(g1*s1+g2*s2+g3*s3+g4*s4)/(r1*r1*r2*r2);
}

#define MAXTER 300 // Maximum number of terms in Legendre series
void UCovariance::Legendre(double cosom, double lam, double *s1, double *s2, double *s3, double *s4)
/*
    Compute the Legendre series necessary in the lead field inner product computations.
 */
{
    int    n,n2,n3;
    double Pn ,Pna, Pnaa;  // Legendre Polynomials, first and second derivative
    double Pn1,Pn1a,Pn1aa; // The same for n-1
    double lamn,h;
    double dis,dis1,dis2,dis3,dislam;

    dis    =  sqrt(1.-2*lam*cosom+lam*lam);
    dis1   =  1./dis;
    dis2   =  dis*dis;
    dis3   =  dis*dis2;
    dislam =  1.-lam*cosom+dis;

    *s1  = -1. + (1.-lam*lam)/dis3;
    *s2  =  lam/dis3;
    *s3  =  lam*(1+dis1)/dislam;
    *s4  =  (lam*lam)*(dislam/dis3 + (1+dis1)*(1+dis1) )/(dislam*dislam);
    lamn  = lam;
    Pn    = cosom; // n=1
    Pn1   = 1.;    // n=0
    Pn1a  = 0.;
    Pn1aa = 0.;

    n2   = 3;
    n3   = 4;
    for(n=1; n<MAXTER && lamn>1.e-6 ;n++,n2+=2,n3+=3) 
    {
        Pna   =  n   *Pn1  + cosom*Pn1a;   //  first derivative
        Pnaa  = (n+1)*Pn1a + cosom*Pn1aa;  // second derivative

        h     = lamn/n2;

        *s1  -= h*Pn;
        *s2  -= h*Pna;
        h    /= n*(n+1);
        *s3  -= n3*h*Pna;
        *s4  -= n3*h*Pnaa;

        lamn *= lam;
        h     = Pn;
        Pn    = (n2*cosom*Pn-n*Pn1)/(n+1);
        Pn1   = h;
        Pn1a  = Pna;
        Pn1aa = Pnaa;
    }
    *s1 /= 4;
    *s2 /= 2;
    *s3 /= 2;
    *s4 /= 2;
}

double UCovariance::GetEEGVar(const USensor& S1, const USensor& S2)
/*
    Compute the theoretical variance between the sensor sens1 of grid1 and sensor sens2 of grid2.
 */
{
    const double KSI   = .0125;
    const double g1    = .87;
    const double g2    = .92;

    UVector3 x1 = S1.Getx() - SpherePos; x1.Normalize(); x1*=HeadR;
    UVector3 x2 = S2.Getx() - SpherePos; x2.Normalize(); x2*=HeadR;
        
    double r1    =  x1.GetNorm(); 
    double r2    =  x2.GetNorm();
    double cosom =  (x1&x2) /(r1*r2);

    double g12   = g1/g2;
    double pg1   = g1 *g1 *g1;
    double pg2   = g2 *g2 *g2;
    double pg12  = g12*g12*g12;
    double r02   = r0*r0/(HeadR*HeadR);
    double pr02  = r02;

    double Pn    = cosom; // n=1
    double Pn1   = 1.;    // n=0
    
    double Var   = 0;
    for(int n=1,n2=3;n<=MAXTER && (pr02>1.e-8||n<4);n++,n2+=2)
    {
        double teller  = KSI*n2*n2*n2/(PI4*HeadR*HeadR*n*(n+1));
        double noemer  = ((n+1)*KSI+n)*(1.+n*KSI/(n+1)) + (1.-KSI)*((n+1)*KSI+n)*(pg1-pg2) - n*(1.-KSI)*(1.-KSI)*pg12;

        double gn = teller/noemer; 

        Var      += gn*gn*pr02*((3*n*n+n)/n2)*(1.-Pn);

        pg1      *= g1 *g1;
        pg2      *= g2 *g2;
        pg12     *= g12*g12;
        pr02     *= r02;

        double h  = Pn;
        Pn        = (n2*cosom*Pn-n*Pn1)/(n+1);
        Pn1       = h;
    }
    return 10.e6*Var;
}

double Conv(double La, double t)
{ 
    if (La<=0.)
    {
        CI.AddToLog("ERROR: UCovariance::UCovariance : Conv(La,t) is called with negative La.\n");
        return 0.;
    }
    else
    {
        if (fabs(t) < La)
            return (La-fabs(t))/La;
        else
            return 0.;
    }
}

double Integrand1(double tac, double w, double La, double tpp, double dt, double t)
{
    return ((-1/tpp)*0.5*(cos(w*(t-tac))*Conv(La,t-tac)
                 +cos(w*(t+dt-tac))*Conv(La,t+dt-tac)));
}

double Integrand2(double u, double w, double La, double tpp, double dt, double t)
{
    return (((tpp-fabs(u))/(tpp*tpp))*0.5*cos(w*u)*Conv(La,u));
}

double Integrand3(double tac, double k, double sig0, double tpp, double dt, double t)
{
    return -(1/tpp)*(exp(-k*fabs(t-tac))+exp(-k*fabs(t+dt-tac)));
}

double Integrand4(double u, double k, double sig0, double tpp, double dt, double t)
{
    return ((tpp-fabs(u))/(tpp*tpp))*exp(-k*fabs(u));
}

static const double EPS  = 1.0e-6;
static const int    JMAX = 20;

double Simpson(double (*func)(double,double,double,double,double,double), double A,double B,double C,double D, double F, double a, double b)
// Returns the integral of the function func from a to b. 
// The parameters EPS can be set to the desired fractional accuracy and JMAX so that
// 2 to the power JMAX-1 is the maximum allowed number of steps. Integration is 
// performed using Simpson's rule.
{
    int j;
    double s,st,ost,os;

    ost = os = -1.0e30;
    for (j=1;j<=JMAX;j++)
    {
        st=Trapzd(func,A,B,C,D,F,a,b,j);
        s=(4.0*st-ost)/3.0;   
        if (fabs(s-os) < EPS*fabs(os))
        {            
            return s;
        }
        if (s == 0.0 && os == 0.0 && j>6)
            return s;
        os=s;
        ost=st;
    }
    //     nrerror("Too many steps in routine qsimp");  --> iets met AddToLog van maken
    return 0.0;           //Never get here. 
}

double Trapzd(double (*FUNC)(double,double, double, double, double, double),double A, double B, double C, double D, double F, double a, double b, int n)
// This routine computes the nth stage of refinement of an extended trapezoidal rule.
// func is input as a pointer to the function to be integrated between limits a and b, also input. 
// When called with n=1, the routine returns the crudest estimate of the integral of
// f(x) over [a,b]. Subsequent calls with n=2,3,... will improve the accuracy by adding
// 2^(n-2) interior points.
{
    double x,tnm,sum,del;
    static double s;
    int it,j;

    if (n==1)
        return (s=0.5*(b-a)*(FUNC(a,A,B,C,D,F)+FUNC(b,A,B,C,D,F)));
    else
    {
        for (it=1,j=1;j<n-1;j++)
            it <<= 1;
        tnm=it;
        del=(b-a)/tnm;            // This is the spacing of the points to be added
        x=a+0.5*del;
        for (sum=0.0,j=1;j<=it;j++,x+=del)
            sum += FUNC(x,A,B,C,D,F);
        s=0.5*(s+(b-a)*sum/tnm);  // This replaces s by its refined value.
        return s;
    }
}


ErrorType WriteXX(UFileName Fcov, const UMatrixSymmetric& CovMat, const UGrid* GrMEG, const UGrid* GrEEG, UString Comment, bool ASCII)
{
    if(&CovMat==NULL || CovMat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteXX(). Object NULL or erroneous. \n");
        return U_ERROR;
    }

    if(GrMEG && GrMEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteXX(). MEG Grid erroneous. \n");
        return U_ERROR;
    }
    if(GrEEG && GrEEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteXX(). EEG Grid erroneous. \n");
        return U_ERROR;
    }
    if(GrMEG==NULL && GrEEG==NULL)
    {
        CI.AddToLog("ERROR: WriteXX(). MEG/EEG Grids are not set. \n");
        return U_ERROR;
    }
    int nX = 0;
    if(GrMEG) nX += GrMEG->GetNpoints();
    if(GrEEG) nX += GrEEG->GetNpoints();
    if(nX!=CovMat.GetNrow() || nX!=CovMat.GetNcol())
    {
        CI.AddToLog("ERROR: WriteXX(). Dimensions inconsistent (Nsensors = %d, Nrow=%d, Ncol=%d \n", nX, CovMat.GetNrow(), CovMat.GetNcol());
        return U_ERROR;
    }

    FILE* fp = NULL;
    if(ASCII==true)
    {
        Fcov.SetExtension("txt");
        fp = fopen(Fcov,"wt");
    }
    else
    {
        fp = fopen(Fcov, "wb");
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: WriteXX(). Cannot create or open file: %s \n", (const char*)Fcov);
        return U_ERROR;
    }

    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    if(Comment.IsNULL()==false && Comment.IsEmpty()==false)
    {
        UString ComCom = Comment;
        ComCom.InsertAtEachLine("//  ");
        fprintf(fp,"// ");
        fprintf(fp,"// COMMENT: \n");
        fprintf(fp,"%s", ComCom.GetString());
        fprintf(fp,"// ");
    }
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = SPACE   // SPACE or TIME \n");
    fprintf(fp,"    nX        = %d      // Number of channels \n", nX);
    if(GrMEG)
    {
        int nP = GrMEG->GetNpoints();
        for(int i=0; i<nP; i++) fprintf(fp,"    SENSOR = %s \n",GrMEG->GetSensor(i).GetProperties());
    }
    if(GrEEG)
    {
        int nP = GrEEG->GetNpoints();
        for(int i=0; i<nP; i++) fprintf(fp,"    SENSOR = %s \n",GrEEG->GetSensor(i).GetProperties());
    }
    fprintf(fp,"}\n");
    
    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12);
        for(int i1=0; i1<nX; i1++)
            for(int i2=0; i2<nX; i2++)
            {
                double Elem = CovMat.GetElement(i1, i2);
                fwrite(&Elem,sizeof(double),1,fp);
            }
    }
    else
    {
        fprintf(fp,"Spatial Covariance Matrix: \n");    
        for(int i1=0; i1<nX; i1++)
        {
            for(int i2=0; i2<nX; i2++)
            {
                double Elem = CovMat.GetElement(i1, i2);
                fprintf(fp,"\t%g ", Elem);
            }
            fprintf(fp,"\n");
        }
    }
    fclose(fp);

    return U_OK;
}
ErrorType WriteTT(UFileName Fcov, const UMatrixSymmetric& CovMat, double STimeMS, UString Comment, bool ASCII)
{
    if(&CovMat==NULL || CovMat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: WriteTT(). Object NULL or erroneous. \n");
        return U_ERROR;
    }

    if(STimeMS<=0.)
    {
        CI.AddToLog("ERROR: WriteTT(). Sample time parameter out of range (STimeMS=%f). \n", STimeMS);
        return U_ERROR;
    }
    int nT = CovMat.GetNrow();

    FILE* fp = NULL;
    if(ASCII==true)
    {
        Fcov.SetExtension("txt");
        fp = fopen(Fcov,"wt");
    }
    else
    {
        fp = fopen(Fcov, "wb");
    }
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: WriteTT(). Cannot create or open file: %s \n", (const char*)Fcov);
        return U_ERROR;
    }

    fprintf(fp,"// Covar1.1\n");
    fprintf(fp,"// General:\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    if(Comment.IsNULL()==false && Comment.IsEmpty()==false)
    {
        UString ComCom = Comment;
        ComCom.InsertAtEachLine("//  ");
        fprintf(fp,"// ");
        fprintf(fp,"// COMMENT: \n");
        fprintf(fp,"%s", ComCom.GetString());
        fprintf(fp,"// ");
    }
    fprintf(fp,"// \n");    
    fprintf(fp,"PARAMETERS \n");
    fprintf(fp,"{\n");
    fprintf(fp,"    DataType  = double  // double or float \n");
    fprintf(fp,"    ByteOrder = INTEL   // INTEL or Moterola \n");
    fprintf(fp,"    CovarType = TIME    // SPACE or TIME\n");
    fprintf(fp,"    Ntime = %d   // Number of samples \n",nT);
    fprintf(fp,"    Stime = %f   // ms.\n",STimeMS);
    fprintf(fp,"}\n"); 
    
    if(ASCII==false)
    {
        fprintf(fp,"%c%c",12,12);
        for(int j1=0; j1<nT; j1++)
            for(int j2=0; j2<nT; j2++)
            {
                double Elem = CovMat.GetElement(j1, j2);
                fwrite(&Elem,sizeof(double),1,fp);
            }
    }
    else
    {
        fprintf(fp,"Temporal Covariance Matrix: \n");    
        for(int j1=0; j1<nT; j1++)
        {
            for(int j2=0; j2<nT; j2++)
            {
                double Elem = CovMat.GetElement(j1, j2);
                fprintf(fp,"\t%g ", Elem);
            }
            fprintf(fp,"\n");
        }
    }
    fclose(fp);

    return U_OK;
}

ErrorType UCovariance::SetNPosEig(double RelAverAbsEigenThresh)
/*
    Sets the number of positive eigenvalues included in computations according to some algorithm define in UMatrixSymmetric.
    The number of negative eigenvalues is always set equal to 0.
    Note: If the UCovariance object is modified using base class functions, the NPosEigen member will be reset to -1 (the default).
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::SetNPosEig(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    int NP = UMatrixSymmetric::GetNPosEig(RelAverAbsEigenThresh);
    if(NP<0)
    {
        CI.AddToLog("ERROR: UCovariance::SetNPosEig(). Getting number of positive eigen values.\n");
        return U_ERROR;
    }
    NPosEigen = NP;
    return U_OK;
}
ErrorType UCovariance::Decompose(void)
{
    if(UMatrixSymmetric::Decompose()!=U_OK)
    {
        CI.AddToLog("ERROR: UCovariance::Decompose(). Decomposition failed. \n");
        return U_ERROR;
    }
    NPosEigen = -1;
    Prew      = UMatrixSymmetric::GetInvertSqrt(NPosEigen);
    if(Prew.GetError()!=U_OK) return U_ERROR;
    return U_OK;
}

UMatrixSymmetric UCovariance::GetVarDifferenceMat(void) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UCovariance::GetVarDifferenceMat(). this is NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    UMatrixSymmetric VarDif(*this);
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<Ncol; j++)
        {
            if(j>=i) VarDif.Data[i*Ncol+j] = Data[i*Ncol+i] + Data[j*Ncol+j] - 2*Data[i*Ncol+j];
            else     VarDif.Data[i*Ncol+j] = VarDif.Data[j*Ncol+i];
        }
    }
    VarDif.ResetDecomp();
    return VarDif;
}

UMatrix UCovariance::GetPreWhitened(const UMatrix& A) const
/*
     return InvSqrt(Lamda) *UMatT * A = PrewT * A
     This corresponds to spatially prewhitening
 */
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UCovariance::GetPreWhitened(). this is NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=A.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetPreWhitened(). Rows (%d) of this and argument (%d) do not match.\n", Nrow, A.GetNrow());
        return UMatrix(U_ERROR);
    }

    bool* SelectTerms = (NPosEigen<0) ? NULL : new bool[Nrow];
    if(SelectTerms==NULL && NPosEigen>=0)
    {
        CI.AddToLog("ERROR: UCovariance::GetPreWhitened(). Memory allocation (Nrow=%d).\n", Nrow);
        return UMatrix(U_ERROR);
    }
    if(SelectTerms) for(int k=0; k<Nrow; k++) SelectTerms[k] = (k<NPosEigen);

    UMatrix Result = GetMatMul(Prew, true, A, false, SelectTerms);
    delete[] SelectTerms;

    return Result;
}
UMatrix UCovariance::GetPostWhitened(const UMatrix& A) const
/*
     return A * UMat*InvSqrt(Lamda)   = A * Prew
     This corresponds to temporally prewhitening
 */
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UCovariance::GetPostWhitened(). this is NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Ncol!=A.GetNcol())
    {
        CI.AddToLog("ERROR: UCovariance::GetPostWhitened(). Rows (%d) of this and argument (%d) do not match.\n", Ncol, A.GetNcol());
        return UMatrix(U_ERROR);
    }

    bool* SelectTerms = (NPosEigen<0) ? NULL : new bool[Ncol];
    if(SelectTerms==NULL && NPosEigen>=0)
    {
        CI.AddToLog("ERROR: UCovariance::GetPostWhitened(). Memory allocation (Ncol=%d).\n", Ncol);
        return UMatrix(U_ERROR);
    }
    if(SelectTerms) for(int k=0; k<Ncol; k++) SelectTerms[k] = (k<NPosEigen);

    UMatrix Result = GetMatMul(A, Prew, SelectTerms);
    delete[] SelectTerms;

    return Result;
}
UMatrix UCovariance::GetAxIsB(const UMatrix& B)
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);
    if(&B  ==NULL || B.GetError()!=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetAxIsB(). Matrix empty.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=B.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetAxIsB(). Numbers of rows do not fit (Nrow=%d) and (B.Nrow=%d)\n", Nrow, B.GetNrow());
        return UMatrix(U_ERROR);
    }
    return UMatrixSymmetric::GetAxIsB(B, NPosEigen, 0);
}
UMatrix UCovariance::GetAMAT(const UMatrix& A,bool InvertM)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetAMAT(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UCovariance::GetAMAT(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(A.GetNcol()!=Nrow)
    {
        CI.AddToLog("ERROR: UCovariance::GetAMAT(). Number of A.Ncol (%d) does not match Nrow (%d)\n", A.GetNcol(), Nrow);
        return UMatrix(U_ERROR);
    }
    return UMatrixSymmetric::GetAMAT(A, InvertM, NPosEigen, 0);
}
UMatrix UCovariance::GetATMA(const UMatrix& A, bool InvertM)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetATMA(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UCovariance::GetATMA(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(Ncol!=A.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetATMA(). Number of Ncol (%d) does not match A.Nrow (%d)\n", Ncol, A.GetNrow());
        return UMatrix(U_ERROR);
    }
    return UMatrixSymmetric::GetATMA(A, InvertM, NPosEigen, 0);
}
double  UCovariance::GetVTMV(const UMatrix& V, bool InvertM)
{
    if(this==NULL || error!=U_OK) 0.;
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetVTMV(). Data not properly set. \n");
        return  0.;
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UCovariance::GetVTMV(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return 0.;
    }
    if(Ncol!=V.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetVTMV(). Number of Ncol (%d) does not match A.Nrow (%d)\n", Ncol, V.GetNrow());
        return 0.;
    }
    if(V.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UCovariance::GetVTMV(). Matrix argument has multiple collumns (%d).\n", V.GetNcol());
        return 0.;
    }
    return UMatrixSymmetric::GetVTMV(V, InvertM, NPosEigen, 0);
}
UMatrix UCovariance::GetA1TMA2(const UMatrix& A1, const UMatrix& A2, bool InvertM)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetA1TMA2(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UCovariance::GetA1TMA2(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(Ncol!=A1.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetA1TMA2(). Number of Ncol (%d) does not match A1.Ncol (%d)\n", Ncol, A1.GetNcol());
        return UMatrix(U_ERROR);
    }
    if(Ncol!=A2.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetA1TMA2(). Number of Ncol (%d) does not match A2.Nrow (%d)\n", Nrow, A2.GetNrow());
        return UMatrix(U_ERROR);
    }
    return UMatrixSymmetric::GetA1TMA2(A1, A2, InvertM, NPosEigen, 0);
}
double  UCovariance::GetV1TMV2(const UMatrix& V1, const UMatrix& V2, bool InvertM)
{
    if(this==NULL || error!=U_OK) 0.;
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UCovariance::GetV1TMV2(). Data not properly set. \n");
        return  0.;
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UCovariance::GetV1TMV2(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return 0.;
    }
    if(Ncol!=V1.GetNrow() || Ncol!=V2.GetNrow())
    {
        CI.AddToLog("ERROR: UCovariance::GetV1TMV2(). Number of Ncol (%d) does not match V1.Nrow (%d) or V2.Nrow (%d) .\n", Ncol, V1.GetNrow(), V2.GetNrow());
        return 0.;
    }
    if(V1.GetNcol()!=1 || V2.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UCovariance::GetV1TMV2(). Matrix argument has multiple collumns (V1.Ncol=%d, V2.Ncol=%d).\n", V1.GetNcol(), V2.GetNcol());
        return 0.;
    }
    return UMatrixSymmetric::GetV1TMV2(V1, V2, InvertM, NPosEigen, 0);
}


// Functions to be replaced by UMatrix versions:
ErrorType UCovariance::MultiplyAWmat(double* A, int Nr) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
////    if(Decompose()!=U_OK) return U_ERROR;

    UMatrix Amat(A, Nr, Ncol);
    UMatrix X = GetMatMul(Amat, false, Prew, false);

    for(int i=0, k=0; i<Nr; i++) 
        for(int j=0; j<Ncol; j++, k++) 
            A[k] = X.GetElement(i,j);
    return U_OK;
}
ErrorType UCovariance::MultiplyWmatTA(double* A, int Nc) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
////    if(Decompose()!=U_OK) return U_ERROR;

    UMatrix Amat(A, Nrow, Nc);
    UMatrix X = GetMatMul(Prew, true, Amat, false);

    for(int i=0, k=0; i<Ncol; i++) 
        for(int j=0; j<Nc; j++, k++) 
            A[k] = X.GetElement(i,j);
    return U_OK;
}
ErrorType UCovariance::MultiplyAWmatT(double* A, int Nr) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
////    if(Decompose()!=U_OK) return U_ERROR;

    UMatrix Amat(A, Nr, Ncol);
    UMatrix X = GetMatMul(Amat, false, Prew, true);

    for(int i=0, k=0; i<Nr; i++) 
        for(int j=0; j<Ncol; j++, k++) 
            A[k] = X.GetElement(i,j);
    return U_OK;
}

