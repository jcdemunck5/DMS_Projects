#ifndef _COVARIANCENEWINCLUDED
#define _COVARIANCENEWINCLUDED

#include "MatrixSymmetric.h"
#include "MatVec.h"
#include "FileName.h"


class UField;
class UGrid;
class USensor;
class UCTFDataSet;

enum CovarType
{
    U_COV_CONSTANTVARIANCE,  // No correlations, all variances equal
    U_COV_VARIANCE,          // No correlations, all variances not equal
    U_COV_RANDIP,            // Spatial covariance, use theoretical random dipole model
    U_COV_ECURVE,            // Temporal covariance, use e-curve
    U_COV_FILE_XX,           // Spatial covariance from covariance file
    U_COV_FILE_TT,           // Temporal covariance from covariance file
    U_COV_DATA_XX,           // Spatial covariance from data file
    U_COV_DATA_TT,           // Temporal covariance from data file
    U_COV_POISSON,           // Temporal covariance by Poisson model
    U_COV_GEN_XX,            // Spatial covariance of unspecified origin
    U_COV_GEN_TT             // Temporal covariance of unspecified origin
};
const char* GetCovTypeText(CovarType CovT);

class DLL_IO UCovariance : public UMatrixSymmetric
{
public:
    UCovariance();
    UCovariance(ErrorType E);
    UCovariance(int N);
    UCovariance(int N1, int N2, double Var1, double Var2);
    UCovariance(int N, const double* Variance);
    UCovariance(const UGrid *gridM, const UGrid *gridE, int Ntime, double stimeMS, CovarType CT);  // Create Empty UCovariance object.
    UCovariance(const UGrid *gridM, const UGrid *gridE, int iref, double r, UVector3 Spos);
    UCovariance(int N, int Nrelaxtime,double Diag, int HalfPeriod=0);
    UCovariance(int nT, double SR, double tShift, double tpp, double linpar[3], double nonlinpar[3]);

    UCovariance(const UMatrixSymmetric& MS, const UGrid *gridM, const UGrid *gridE);
    UCovariance(const UMatrixSymmetric& MS, double STms);

    UCovariance(const char* FileName);
    UCovariance(const char* FileName, int nTime);
    UCovariance(const char* FileName, const UGrid *gridM, const UGrid *gridE);

    UCovariance(const UCovariance &Cov);
    virtual ~UCovariance();

    UCovariance& operator=(const UCovariance &Cov);

    ErrorType               WriteXX(UFileName Fcov, const char* Comment, bool ASCII) const;
    ErrorType               WriteXX(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* FileName= NULL) const;
    ErrorType               WriteTT(UFileName Fcov, const char* Comment, bool ASCII) const;
    ErrorType               WriteTT(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* FileName= NULL) const;

    ErrorType               GetError()  const         {if(this) return error; return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
    const double*           GetCovMatArray() const    {if(this) return UMatrixSymmetric::GetMatrixArray(); return NULL;}

    CovarType               GetCovarType(void) const {if(this) return CovT;  return U_COV_CONSTANTVARIANCE;}
    const UGrid*            GetMEGGrid(void)   const {if(this) return GrMEG; return NULL;}
    const UGrid*            GetEEGGrid(void)   const {if(this) return GrEEG; return NULL;}

    int                     GetNdim()    const {if(this) return UMatrixSymmetric::GetNrow(); return 0;}
    ErrorType               SelectRowCol(const bool* SelectRowCol);
    ErrorType               SetNPosEig(double RelAverAbsEigenThresh);

// These functions call base class with NPos = UCovariance NPosEigen, NNeg = 0
    UMatrix                 GetAxIsB(const UMatrix& B);              // Allow update of decomposition and WMat
    UMatrix                 GetAMAT(const UMatrix& A, bool InvertM); 
    UMatrix                 GetATMA(const UMatrix& A, bool InvertM);
    double                  GetVTMV(const UMatrix& V, bool InvertM);
    UMatrix                 GetA1TMA2(const UMatrix& A1, const UMatrix& A2, bool InvertM);
    double                  GetV1TMV2(const UMatrix& V1, const UMatrix& V2, bool InvertM);

    UMatrix                 GetPreWhitened(const UMatrix& A) const;  // InvSqrt(Lamda) *UMatT * A = PrewT * A 
    UMatrix                 GetPostWhitened(const UMatrix& A) const; // A * UMat*InvSqrt(Lamda)   = A * Prew
    UMatrixSymmetric        GetVarDifferenceMat(void) const;

    double                  GetMEGCovar(const USensor& S1, const USensor& S2);
    double                  GetEEGVar(const USensor& S1, const USensor& S2);

//// Functions to be replaced:                                             These functions are called in:
    ErrorType               MultiplyAWmat(double* A, int Nr) const;        //ULocCodeDip, ULocStatDip   // Post-Whiten
    ErrorType               MultiplyWmatTA(double* A, int Nc) const;       //ULocCodeDip, ULocStatDip   // PreWhiten
    ErrorType               MultiplyAWmatT(double* A, int Nr) const;       //ULocCodeDip, ULocStatDip   // ???
////
protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    static UString          Properties;
    ErrorType               error;
    CovarType               CovT;             // Covariance type

// CovT==U_COV_FILE_XX || CovT==U_COV_FILE_TT
    UFileName               CovarFile;        // Name of the covariance file, from which data originate.

// CovT==U_COV_RANDIP || CovT==U_COV_FILE_XX || U_COV_DATA_XX
    UVector3                SpherePos;        // Position of the best fitting sphere wrt to gradiometer
    UGrid*                  GrMEG;            // MEG Sensor positions in case of U_COV_FILE_XX/U_COV_RANDIP
    UGrid*                  GrEEG;            // EEG Sensor positions in case of U_COV_FILE_XX

// CovT==U_RANDIP
    double                  r0;               // Integration surface radius

// CovT==U_ECURVE || U_DATA_TT || U_FILE_TT || U_POISSON
    double                  SampleTimeMS;     // Sample time in ms.

// CovT==U_ECURVE
    int                     Nrelax;           // Relaxation time in samples

    void                    Legendre(double cosom, double lam, double *s1, double *s2, double *s3, double *s4);

    virtual ErrorType       Decompose(void);    // Decompose in eigenvalues/eigenvectors
    int                     NPosEigen;          // Number of positive eigenvalues included in computations with (inverse) of *this
    UMatrix                 Prew;               // Prew * PrewT = CovInv
};

ErrorType DLL_IO WriteXX(UFileName Fcov, const UMatrixSymmetric& CovMat, const UGrid* GrMEG, const UGrid* GrEEG, UString Comment, bool ASCII);
ErrorType DLL_IO WriteTT(UFileName Fcov, const UMatrixSymmetric& CovMat, double STimeMS, UString Comment, bool ASCII);

#endif //_COVARIANCEMODELINCLUDED
