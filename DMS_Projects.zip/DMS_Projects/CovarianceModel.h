#ifndef _COVARIANCEMODELINCLUDED
#define _COVARIANCEMODELINCLUDED

#include "MatrixSymmetric.h"
#include "MatVec.h"
#include "FileName.h"

class UField;
class UGrid;
class UCTFDataSet;

enum CovarType
{
    U_COV_CONSTANTVARIANCE,  // No correlations, all variances equal
    U_COV_VARIANCE,          // No correlations, all variances not equal
    U_COV_RANDIP,            // Spatial covariance, use theoretical random dipole model
    U_COV_ECURVE,            // Temporal covariance, use e-curve
    U_COV_FILE_XX,           // Spatial covariance from covariance file
    U_COV_FILE_TT,           // Temporal covariance from covariance file
    U_COV_DATA_XX,           // Spatial covariance from data file
    U_COV_DATA_TT,           // Temporal covariance from data file
    U_COV_POISSON,           // Temporal covariance by Poisson model
    U_COV_GEN_XX,            // Spatial covariance of unspecified origin
    U_COV_GEN_TT             // Temporal covariance of unspecified origin
};
const char* GetCovTypeText(CovarType CovT);

class DLL_IO UCovarianceModel : public UMatrixSymmetric
{
public:
    UCovarianceModel();
    UCovarianceModel(ErrorType E);
    UCovarianceModel(int N);
    UCovarianceModel(int N1, int N2, double Var1, double Var2);
    UCovarianceModel(int N, const double* Variance);
    UCovarianceModel(const UGrid *gridM, const UGrid *gridE, int Ntime, double stimeMS, CovarType CT);  // Create Empty UCovarianceModel object.
    UCovarianceModel(const UGrid *gridM, const UGrid *gridE, double r, UVector3 Spos, double DiagFact);
    UCovarianceModel(int N, int Nrelaxtime,double Diag, int HalfPeriod=0);
    UCovarianceModel(int nT, double SR, double tShift, double tpp, double linpar[3], double nonlinpar[3]);

    UCovarianceModel(const UMatrixSymmetric& MS, const UGrid *gridM, const UGrid *gridE);
    UCovarianceModel(const UMatrixSymmetric& MS, double STms);

    UCovarianceModel(const char* FileName);
    UCovarianceModel(const char* FileName, int nTime);
    UCovarianceModel(const char* FileName, const UGrid *gridM, const UGrid *gridE);

    UCovarianceModel(const UCovarianceModel &Cov);
    virtual ~UCovarianceModel();

    UCovarianceModel& operator=(const UCovarianceModel &Cov);

    ErrorType       WriteXX(UFileName Fcov, const char* Comment, bool ASCII) const;
    ErrorType       WriteXX(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* FileName= NULL) const;
    ErrorType       WriteTT(UFileName Fcov, const char* Comment, bool ASCII) const;
    ErrorType       WriteTT(const UCTFDataSet* DSet, const char* Comment, bool ASCII, const char* FileName= NULL) const;


    ErrorType       GetError()  const         {if(this) return error; return U_ERROR;}
    const UString&  GetProperties(UString Comment) const;
    const double*   GetCovMatArray() const    {if(this) return UMatrixSymmetric::GetMatrixArray(); return NULL;}

    CovarType       GetCovarType(void) const {if(this) return CovT;  return U_COV_CONSTANTVARIANCE;}
    const UGrid*    GetMEGGrid(void)   const {if(this) return GrMEG; return NULL;}
    const UGrid*    GetEEGGrid(void)   const {if(this) return GrEEG; return NULL;}

    int             GetNdim()    const {if(this) return UMatrixSymmetric::GetNrow(); return 0;}
//// These functions are only called in ULocMovDip
    ErrorType       ComputeCovinvVec(double* CinvVec, const double* Vec) const;
    ErrorType       ComputeMatTCovinvMat(double* MTCM, const double *Mat, int N) const;
    ErrorType       ComputeMatTCovinvMat(double* MTCM, const double *Mat1, const double *Mat2, int N1, int N2) const;
    ErrorType       ComputeMatTCovinvMat(double* MTCM, const float  *Mat, int N) const; // Used with table of multiple starting values
////

    ErrorType       MultiplyAWmat(double* A, int Nrow) const;
    ErrorType       MultiplyWmatTA(double* A, int Ncol) const;
    ErrorType       MultiplyAWmatT(double* A, int Nrow) const;
    ErrorType       SkipSamples(const UField* Selector, int *NSelected, char** Selection);

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    static UString  Properties;
    ErrorType       error;
    CovarType       CovT;             // Covariance type

// CovT==U_COV_FILE_XX || CovT==U_COV_FILE_TT
    UFileName       CovarFile;        // Name of the covariance file, from which data originate.

// CovT==U_RANDIP || CovT==U_COV_FILE_XX || U_COV_DATA_XX
    UVector3        SpherePos;        // Position of the best fitting sphere wrt to gradiometer
    UGrid*          GrMEG;            // MEG Sensor positions in case of U_COV_FILE_XX/U_COV_RANDIP
    UGrid*          GrEEG;            // EEG Sensor positions in case of U_COV_FILE_XX

// CovT==U_RANDIP
    double          r0;               // Integration surface radius

// CovT==U_ECURVE || U_DATA_TT || U_FILE_TT || U_POISSON
    double          SampleTimeMS;     // Sample time in ms.

// CovT==U_ECURVE
    int             Nrelax;           // Relaxation time in samples

    void            Legendre(double cosom, double lam, double *s1, double *s2, double *s3, double *s4);
    double          MatrixElem(const UGrid *Grid1, int sens1, const UGrid *Grid2, int sens2);
};

#endif //_COVARIANCEMODELINCLUDED
