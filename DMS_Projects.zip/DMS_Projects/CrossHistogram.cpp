/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for creating and maintaining (2D) Cross-histograms. The bins are   */
/*     determined by the geometry of the underlying 2D-1vector-U_UNIFORM int     */
/*     UField class.                                                             */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    07-03-04   creation
  JdM    29-08-08   DeleteAllMembers(), added ErrorType argument
                    Use UString for Title and Properties
*/


#include <string.h>
#include "CrossHistogram.h"

/* Inititalize static const parameters. */

UString UCrossHistogram::Properties  = UString();


void UCrossHistogram::SetAllMembersDefault(void)
{
    error          = U_OK;
    Properties     = UString();
    Title          = UString();
    Ntotal         = 0;
    NinRange       = 0;
    MinRange2      = UVector2();
    MaxRange2      = UVector2();
    MinValue2      = UVector2();    
    MaxValue2      = UVector2();    
    SumInRange2    = UVector2();  
}

void UCrossHistogram::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UCrossHistogram::UCrossHistogram() : UField()
{
    SetAllMembersDefault();
}


UCrossHistogram::UCrossHistogram(UVector2 Min, UVector2 Max, const int *dims) : 
    UField(Min, Max, dims, UField::U_INTEGER, 1)
{
    SetAllMembersDefault();

    if(UField::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UCrossHistogram::UCrossHistogram(). Creating UField-base class. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }

    MinRange2   = UField::GetMinx2();
    MaxRange2   = UField::GetMaxx2();
    error       = ClearCounts();
}
    
UCrossHistogram::UCrossHistogram(const UCrossHistogram& CH) : UField( (UField) CH )
{
    SetAllMembersDefault();
    *this = CH;
}

UCrossHistogram::~UCrossHistogram()
{
    DeleteAllMembers(U_ERROR);
}

UCrossHistogram& UCrossHistogram::operator=(const UCrossHistogram& CH)
{
    if(this==NULL)
    {
        static UCrossHistogram C; C.error = U_ERROR;
        CI.AddToLog("ERROR: UCrossHistogram::operator=(). Argument has NULL address. \n");
        return C;
    }
    if(&CH==NULL)
    {
        CI.AddToLog("ERROR: UCrossHistogram::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&CH) return *this;

    UField::operator=(CH);
    if(UField::GetError() != U_OK) 
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UCrossHistogram::operator=(). Copying base class. \n");
        return *this;
    }

/* Copy derived class */
    DeleteAllMembers(U_OK);

    
    Title       = CH.Title;
    Ntotal      = CH.Ntotal;      
    NinRange    = CH.NinRange;    
    MinRange2   = CH.MinRange2;
    MaxRange2   = CH.MaxRange2;
    MinValue2   = CH.MinValue2;    
    MaxValue2   = CH.MaxValue2;    
    SumInRange2 = CH.SumInRange2;  
    return *this;
}

ErrorType UCrossHistogram::SetTitle(UString T)
{
    Title = T;
    return Title.GetError();
}
ErrorType UCrossHistogram::SetTitle(const char* TitleText)
{
    Title = UString(TitleText);
    return Title.GetError();
}

ErrorType UCrossHistogram::AddValue(double Valx, double Valy)
{
    if(error!=U_OK) return U_ERROR;

    UVector2 Val(Valx, Valy);

    Ntotal++;
    if(Ntotal==1) MinValue2 = MaxValue2 = Val;
    else
    {
        MinValue2 = Min(MinValue2, Val);
        MaxValue2 = Max(MaxValue2, Val);
    }

/* Test for out of range:*/
    if(::IsInBox(MinRange2, MaxRange2, Val)==false) return U_OK;

/* Update statistics*/
    int ibinx = UField::GetPointIndex(0, Valx);
    int ibiny = UField::GetPointIndex(1, Valy);
    Idata[ibiny*dimensions[0]+ibinx]++;

    NinRange++;
    SumInRange2  += Val;

    return U_OK;
}

const UString& UCrossHistogram::GetProperties(UString Comment) const
{
    Properties = UString("CrossHistogram \n") + UField::GetProperties(Comment);

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);
    return Properties;
}

UVector2 UCrossHistogram::GetAverage2(void) const
{
    if(NinRange==0) return UVector2();
    return SumInRange2/double(NinRange);
}

UVector2 UCrossHistogram::GetMedian2(void) const
{
    CI.AddToLog("ERROR: UCrossHistogram::GetMedian2(). Function not implemented. \n");
    return UVector2();
}

ErrorType UCrossHistogram::ClearCounts(void)
{
    MinValue2    = UVector2();
    MaxValue2    = UVector2();
    Ntotal       = 0;
    NinRange     = 0;
    SumInRange2  = UVector2();

    if(Idata==NULL) return U_ERROR;

    for(int k=0; k<UField::GetNpoints(); k++) Idata[k] = 0;
    return U_OK;
}

