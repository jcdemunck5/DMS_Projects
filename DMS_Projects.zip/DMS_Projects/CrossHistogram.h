#ifndef _UCROSSHISTOGRAM_INCLUDED
#define _UCROSSHISTOGRAM_INCLUDED

#include "Field.h"
#include "String.h"


class DLL_IO UCrossHistogram : public UField
{
public:
    UCrossHistogram();
    UCrossHistogram(UVector2 Min, UVector2 Max, const int *dims);
    UCrossHistogram(const UCrossHistogram& CH);

    virtual ~UCrossHistogram();  
    UCrossHistogram& operator=(const UCrossHistogram& CH);

    ErrorType        GetError(void) const {return error;}
    ErrorType        SetTitle(UString T);
    ErrorType        SetTitle(const char* T);
    ErrorType        AddValue(double Valx, double Valy);
    ErrorType        AddValue(UVector2 Val) {return AddValue(Val.Getx(), Val.Gety());}
    const UString&   GetProperties(UString Comment) const;
    UVector2         GetAverage2(void) const;
    UVector2         GetMedian2(void) const;
    UVector2         GetMinValue2(void) const {return MinValue2;}
    UVector2         GetMaxValue2(void) const {return MaxValue2;}
    ErrorType        ClearCounts(void);

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    ErrorType        error;
    static UString   Properties;
    UString          Title;

    int              Ntotal;      // Number of values investigated 
    int              NinRange;    // Number of examined values that are in range
    UVector2         MinRange2;   // The minimum and the maximum between which the distribution is determined
    UVector2         MaxRange2;    
    UVector2         MinValue2;   // Running minimum
    UVector2         MaxValue2;   // Running maximum
    UVector2         SumInRange2; // Running sum of all values in range
};

#endif //_UCROSSHISTOGRAM_INCLUDED
