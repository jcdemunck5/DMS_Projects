/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read and write DICOM files                                         */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck, adapted from Avs_Rdic.cpp by M. van Herk, AvL/NKI           */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    30-09-99   creation, derived Avs_Rdic.cpp (developed by M. van Herk, AvL/NKI)
  JdM    17-12-99   Added (GRP_SLIPOS3,ITM_SLIPOS3) in order to have a third way of getting slice-position
                    Test for changes in scan orientation.
  JdM    04-02-00   Export more info to log-file on the reason to fail to find next slice.
  JdM    06-03-00   Large update with the intention to be able to export edited DICOM-slices
  JdM    07-03-00   Bug fix: ReadSlices() with WordOn==true.
  JdM    22-03-00   Bug fix: ExportDICOMslices(). Swap x and z of each slice.
  JdM    23-03-00   Uptimized update 22-03-00
  JdM    05-04-00   Added GetSeriesID() and change Series ID when writing (insert 'R')
  JdM    03-05-00   Make swapxy() a member function
  JdM    05-05-00   Remove obsolete defines, move other defines from .h to .cpp-file
                    Export more detailed MR scan-info
  JdM    15-05-00   Bug fix in AnalyzeDicomFiles(): split subsequent files with equal slice coordinate into two scans
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    06-07-00   Reorder slices and files on geometrical information, i.s.o. alphabetical order of file names
  JdM    10-07-00   ExportDICOMslices(). Add ".1" to Series, Study and SOP instance UID
  JdM    01-08-00   ReadSlices() pixmin==-1-> take minimum, pixmax==-1 -> take maximum
                    ExportDICOMslices(). Change the way the UID's are adapted
  JdM    03-08-00   ExportDICOMslices(). Also change SOP Class UID and study sequence UID
  JdM    08-08-00   ExportDICOMslices(). Add parameter to edit UID's
  JdM    09-08-00   ChangeUID(), adapt algorithm
  JdM    19-10-00   More error/warning messages in AnalyzeDicomFiles()
  JdM    15-11-00   More error/warning messages in AnalyzeDicomFiles()
  JdM    12-02-01   Bug fix in AnalyzeDicomFiles(). To isolate scans, test also for pixel size and other parameters
  JdM    23-03-01   ReadSlices(). Use UField::ConvertDataToByte() to convert from short to byte
  JdM    30-09-01   ACRNEMA_header(). Small modifcation (||l==8) to read GRP_ACQMAT and ITM_ACQMAT
  JdM    08-10-01   Compatibility with fMRI and Angio scans. Switch from Value Representation mode at VR="AE"
  JdM    10-10-01   ACRNEMA_header(). Dynamically allocate buffer array for DICOM header
  JdM    21-10-01   Export more MR properties. StampUnpack: automatically read slice thickness
  JdM    12-12-01   Use global SwapArray() instead of old UField::SwapArr()
  JdM    18-12-01   Change algorithm ChangeUID().
                    ExportDICOMslices(). Change only 3 UID's and patname and patID
  JdM    03-01-02   Added GetScanDescriptor()
  JdM    04-01-02   GetScanMod() and its applications in e.g. GeomInfo
                    Added GetGeomInfo
  JdM    11-01-02   Added new ExportDICOMslices()
  JdM    12-01-02   IMPORTANT Update AnalyzeDicomFiles(): read all files, from all subdirectories.
                    Added GetRawScan()
                    Made OrientationType and ModalityType global, defined in Field.h
  JdM    17-01-02   Include the relative path of the DICOM file in the sorting of the files
                    ExportDICOMslices() Print old and new UID's in log file
  JdM    11-02-02   Also edit Reference frame UID in (both) ExportDICOMslices(). (0x20,0x52)
  JdM    12-02-02   Added new functions: GetBeginFile(), GetPatName(), GetPatID(), GetScanDate()
                    Added new constructor
  JdM    13-02-02   Also edit Study UID in (both) ExportDICOMslices(). (0x20,0x10)
  JdM    20-02-02   Added GetSliceAsField() and allow the editing of pixel data in ExportDICOMslices()
  JdM    21-02-02   Remove the index[] parameter, reorder all filenames according to their
                    logical appearance.
  JdM    26-02-02   ChangeUID() adapt algorithm such that it also works for a one digit UID
  JdM    01-07-02   Add Nologging parameter to constructors
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    27-11-02   Bug fix: ACRNEMA_header(). Make static data class members, to avoid problems with multiple UDICOMData() objects
  JdM    22-02-03   Bug fix: ExportDICOMslices() and ReadSlices(). Computing filename offset in case scannum!=0
  JdM    23-03-03   Added First Pixel coordinates to GeomInfo.
                    Bug fix: AnalyzeDicomFiles(): Automatically reverse slices based on First Pixel Coordinates of each slice (Coronal)
  JdM    31-03-03   Bug Fix: Reversing slices dd 23-03-03. Order arrays GeomInfo[] and FileNames[] simultaneously
  JdM    02-06-03   AnalyzeDicomFiles(): Automatically reverse slices based on First Pixel Coordinates of each slice (Axial, Sagital and Coronal)
                    GetRawScan(): Shift Center according to geometrical info in DICOM file.
  JdM    03-06-03   ReadSlices(): Use FirstX, FirstY and FirstZ to set slice position, instead of SlicePos
  JdM    13-06-03   Reimplemented GetProperties()
  JdM    21-06-03   Bug fix: AnalyzeDicomFiles(): dd 31-03-03. Ordering of GInfo[], simply use sort()
  JdM    07-09-03   Bug fix: GetScanTime(); 60 seconds per min (no 100).
  JdM    18-04-04   GetRawScan(). Set shifting compatible to AFNI files, for coronal scans
  JdM    24-08-04   Bug fix: AnalyzeDicomFiles(). Reversing slices: addressing last slices in case of iscan>0
  JdM    25-08-04   Bug fix: AnalyzeDicomFiles(). Reversing slices: addressing last slices in case of iscan>0
  JdM    22-09-04   Added image time and sliceorder
                    Add GetRepTime(), detect fMRI data type
  JdM    06-12-04   Bug fix : GetRawScan() In case of U_ORI_CORONAL, reverse slices
  JdM    22-01-06   Dis-abled MS C++ language extensions
  JdM    03-08-00   ExportDICOMslices(). Do not change GRP_STUDY_INSTANCE_UID, nor GRP_STUDY_UID
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    14-05-07   Bug Fix: GetSliceAsField(). Extend in y-direction (use dimy-1, NOT dimy-2)
  JdM    22-08-07   Remove zerou slices in when calling StampUnpack()
  JdM    06-06-08   ExportDICOMSlices(): Added const char* Descriptor argument
  JdM    01-02-09   Changes during exploration of the use of UDICOMFile object in ACRNEMA_header()
  JdM    28-02-09   Bug fix: AnalyzeDicomFiles() setting slice order (switch(.Ori) NOT (switch(.SliceOrder))
  JdM    10-04-09   Bug fixes GetSlicePosition(): compilor errors on MSVC2008 (static int)
  JdM    09-06-10   Added GetFileName()
  JdM    28-10-10   bug fix: UDICOMData::GetPatID() and others: return -1 on error ('return' was missing)
  JdM    17-01-11   Bug Fix: ACRNEMA_header(). Testing string length. In uncorrected not all items were always read, resulting in e.g. erroneous Orientation
  JdM    31-01-11   GetProperties(): Use UString()
  JdM    01-02-11   AnalyzeDicomFiles(). Added heuristics to sort slices
  JdM    13-04-11   ACRNEMA_header(). Omit printing Len -parameter in result[] string.
                    ExportDICOMslices(). Replace maskUID by three parameters: maskUIDref, maskUIDser and maskUIDsop
  JdM    27-07-13   Eliminate compiler warnings regarding unused variables.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    09-09-14   Bug Fix: ReadSlices(). Avoid crash when BytesPerPixel is invalid, by reading the image after testing BytesPerPixel.
  JdM    01-11-15   GetSlicePosition(). Changed algorithm: use (GRP_SCANFIRSTPIX,ITM_SCANFIRSTPIX) and scan orientation
  JdM    02-11-15   Removed (obsolete) lastfilename[], nbytesHeader,  bufferHeader members
                    ACRNEMA_header(): remove static UDICOMFile DICF and made it data member of UDICOMData
                    Added SetAllMembersDefault() and DeleteAllMembers()
                    ReadSlices(). Add constant to data when all pixels have negative grey values
*/

#include<string.h>
#include<stdlib.h>

#include"DICOMData.h"
#include"FileName.h"

/* Inititalize static const parameters. */

UString   UDICOMData::Properties      = UString();
UString   UDICOMData::ScanDescriptor  = UString();
UString   UDICOMData::GeomErrorText[] = {"No Error",
                                         "Error Unknown",
                                         "Error in GantryTilt",
                                         "Error in PixelSize",
                                         "Error in Ndim",
                                         "Error in SliceNumber",
                                         "Error in SlicePosition",
                                         "Error on ScanOrientation"};

#define MAX_SLICES           512
#define MAX_DICOM_HEADER  600000


typedef struct 
{  
    int          GroupNo;
    int          ItemNo;
    char         Name[32];
} DicomRec;
struct DicomHead
{
    bool         Present;
    unsigned int offset;
};

enum DicomType
{
    U_DIC_SLICENUM,
    U_DIC_PIXSIZE,
    U_DIC_FOV,
    U_DIC_SLICEPOS,
    U_DIC_SLICEPOS2,
    U_DIC_SLICETHICK,
    U_DIC_PIXELINFO,
    U_DIC_PIXELINFO_NKI,
    U_DIC_PIXELINFO_XDIM,
    U_DIC_PIXELINFO_YDIM,
    U_DIC_GANTRY_TILT,
    U_DIC_PATIENT_NAME,
    U_DIC_PATIENT_ID,
    U_DIC_PATIENT_DOB,
    U_DIC_PATIENT_SEX,
    U_DIC_SCAN_MODALITY,
    U_DIC_SCAN_DATE,
    U_DIC_SCAN_DATE2,
    U_DIC_SCAN_TIME,
    U_DIC_SCAN_TIME2,
    U_DIC_PATIENT_ORIENTATION,
    U_DIC_SCAN_ORIENTATION,
    U_DIC_POS_FIRST,
    U_DIC_INSTITUTION,
    U_DIC_CONTRAST,
    U_DIC_SERIESDECRIPTION,
    U_DIC_DIAGNOSIS,
    U_DIC_MR_IMAGETYPE,
    U_DIC_MR_SEQUENCE,
    U_DIC_MR_FIELDSTRENGTH,
    U_DIC_MR_REPTIME,
    U_DIC_MR_ECHOTIME,
    U_DIC_MR_INVERSIONTIME,
    U_DIC_MR_FLIPANGLE,
    U_DIC_MR_NUMAVERAGE,
    U_DIC_MR_ACQMATRIX,
    U_DIC_MR_TEMPOSORDER,
    U_DIC_MR_NTEMPORALPOS,
    U_DIC_MR_TEMPORALRESOLUTION,
    U_DIC_UID_REFFRAME_INST,
    U_DIC_UID_SERIES_INST,
    U_DIC_UID_SOP_INST,
    U_DIC_UID_STUDY_INST,
    U_DIC_UID_STUDY,
    U_DIC_NTYPE
};

const DicomRec DicTable[U_DIC_NTYPE] =
{
    0x20  , 0x13  , "Slice Number                   ",
    0x28  , 0x30  , "Pixel Size                     ",
    0x21  , 0x1120, "Field of View                  ",
    0x20  , 0x50  , "Slice Position                 ",
    0x20  , 0x1041, "Slice Position (Philips)       ",
    0x18  , 0x50  , "Slice Thickness                ",
    0x7fe0, 0x10  , "Pixel Info                     ",
    0x7fdf, 0x10  , "Pixel Info (NKI)               ",
    0x28  , 0x10  , "X-dimension                    ",
    0x28  , 0x18  , "Y-dimension                    ",
    0x18  , 0x1120, "Gantry tilt                    ",
    0x10  , 0x10  , "Patient name                   ",
    0x10  , 0x20  , "Patient ID                     ",
    0x10  , 0x30  , "Patient date of Birth          ",
    0x10  , 0x40  , "Patient sex                    ",
    0x8   , 0x60  , "Scan modality                  ",
    0x8   , 0x22  , "Scan date                      ",
    0x8   , 0x22  , "Scan date (reconstruction)     ",
    0x8   , 0x32  , "Scan time                      ",
    0x8   , 0x33  , "Scan time (reconstruction)     ",
    0x18  , 0x5100, "Patient orientation            ",
    0x20  , 0x37  , "Scan orientation               ", // x: to left, y: to back, z: to top
    0x20  , 0x32  , "Upper left first               ", // coordinates 
    0x8   , 0x80  , "Institution                    ",
    0x18  , 0x10  , "Contrast                       ",
    0x8   , 0x103e, "Series description             ",
    0x8   , 0x1080, "Admitting diagnosis            ",
    0x8   , 0x8   , "MR image type                  ",
    0x18  , 0x24  , "MR sequence name               ",
    0x18  , 0x87  , "MR field strength              ",
    0x18  , 0x80  , "MR repetition time             ",
    0x18  , 0x81  , "MR echo time                   ",
    0x18  , 0x82  , "MR inversion time              ",
    0x18  , 0x1314, "MR flip angle                  ",
    0x18  , 0x83  , "MR number averages             ",
    0x18  , 0x1310, "MR acquisition matrix          ",
    0x20  , 0x100 , "MR temporal position order     ",
    0x20  , 0x105 , "MR number of temporal positions",
    0x20  , 0x110 , "Temporal resolution            ",
    0x20  , 0x52  , "UID Refframe instance          ",
    0x20  , 0xe   , "UID Series instance            ", // keep fixed per serie, adapt in ExportDICOMslices()
    0x8   , 0x18  , "UID SOP instance               ", // Image number, adapt in ExportDICOMslices()
    0x20  , 0xd   , "UID Study instance             ", // Pat in, pat out, DO NOT adapt in ExportDICOMslices()
    0x20  , 0x10  , "UID Study                      "
};

#define GRP_SLINUM    32        // These are decimal numbers. Part3.doc contains hexadecimals
#define ITM_SLINUM    19
#define GRP_PIXSIZ    40
#define ITM_PIXSIZ    48
#define GRP_FOV       33
#define ITM_FOV     4384

#define GRP_SLIPOS    32
#define ITM_SLIPOS    80
#define GRP_SLIPOS2   32        /* for philips */
#define ITM_SLIPOS2   4096+65   /* for philips */
#define GRP_SLISPAC    0x18        /* for MR      */
#define ITM_SLISPAC    0x88        /* for MR      */
#define GRP_SLITHIC   24
#define ITM_SLITHIC   80

#define GRP_PIXEL     0x7fe0 // 32736
#define ITM_PIXEL     0x0010 // 16
#define GRP_PIXEL_NKI 0x7fdf
#define ITM_PIXEL_NKI 0x0010

#define GRP_XDIM      40
#define ITM_XDIM      16
#define GRP_YDIM      40
#define ITM_YDIM      17
#define GRP_GTILT     24
#define ITM_GTILT   4384

/* Patient info */
#define GRP_NAME      0x10
#define ITM_NAME      0x10
#define GRP_PATID     0x10
#define ITM_PATID     0x20
#define GRP_BIRTH     16
#define ITM_BIRTH     48
#define GRP_SEX       16
#define ITM_SEX       64

/* scan info */
#define GRP_SCANMO       0x8
#define ITM_SCANMO       0x60  ////96
#define GRP_SCANDATE     0x8
#define ITM_SCANDATE     0x22
#define GRP_SCANTIME     0x8
#define ITM_SCANTIME     0x33 ///0x32
#define GRP_PATORI       0x18    ///24
#define ITM_PATORI       0x5100  ///20736
#define GRP_SCANORI      0x20   ////32     x-axis : to left
#define ITM_SCANORI      0x37   ////55     y-axis : to back
#define GRP_SCANFIRSTPIX 0x20   ////32     z-axis : to top
#define ITM_SCANFIRSTPIX 0x32   ////55

#define GRP_INSTIT       8
#define ITM_INSTIT     128
#define GRP_CONTRAST    24
#define ITM_CONTRAST    16

#define GRP_SERDESCR     8   // 0x8
#define ITM_SERDESCR  4158   // 0x103e
#define GRP_ADM_DIAGN    8
#define ITM_ADM_DIAGN 4224


/* MR scan Info */
#define GRP_IMTYPE       0x8
#define ITM_IMTYPE       0x8
#define GRP_IMTIME       0x8
#define ITM_IMTIME       0x33
#define GRP_IMSEQ        0x18
#define ITM_IMSEQ        0x20
#define GRP_SEQNAM       0x18
#define ITM_SEQNAM       0x24
#define GRP_FIELD        0x18
#define ITM_FIELD        0x87
#define GRP_ECHOTIME     0x18
#define ITM_ECHOTIME     0x81
#define GRP_INVTIME      0x18
#define ITM_INVTIME      0x82
#define GRP_REPTIME      0x18
#define ITM_REPTIME      0x80


#define GRP_FLIPA       24
#define ITM_FLIPA     4884
#define GRP_NUMAV       24
#define ITM_NUMAV      131

#define GRP_ACQMAT       0x18
#define ITM_ACQMAT       0x1310
#define GRP_TEMPPOS      0x20
#define ITM_TEMPPOS      0x100
#define GRP_NUMTEMP      0x20
#define ITM_NUMTEMP      0x105
#define GRP_TEMPRES      0x20
#define ITM_TEMPRES      0x110



/* Various*/
#define GRP_REFFRAME_INSTANCE_UID  0x20
#define ITM_REFFRAME_INSTANCE_UID  0x52

#define GRP_SERIES_INSTANCE_UID    0x20   // gelijk hoeden per serie, aanpassen in ExportDICOMslices()
#define ITM_SERIES_INSTANCE_UID    0xe

#define GRP_SOP_INSTANCE_UID       0x8    // Beeld nummer, aanpassen in ExportDICOMslices()
#define ITM_SOP_INSTANCE_UID       0x18

#define GRP_STUDY_INSTANCE_UID     0x20   // pat in, pat uit, NIET aanpassen in ExportDICOMslices()
#define ITM_STUDY_INSTANCE_UID     0xd

#define GRP_STUDY_UID              0x20
#define ITM_STUDY_UID              0x10


//// See 0029,1020 (or 1010), Siemens private field
//// sGRADSPEC.ucMode                         = 0x1 Bottom to top
//// sGRADSPEC.ucMode                         = 0x2 Top to bottom
//// sGRADSPEC.ucMode                         = 0x4 Interleaved

void UDICOMData::SetAllMembersDefault(void)
{
    error       = U_OK;
    swap        = 1;
    Orientation = U_ORI_UNKNOWN;

    FileNames   = NULL;
    Nfiles      = 0;
    GInfo       = NULL;
    BeginScan   = NULL;
    EndScan     = NULL;
    Nscans      = 0;

    Properties  = UString("No data Read yet");

    DicomDir    = UDirectory();
    DICFile     = UDICOMFile();
}
void UDICOMData::DeleteAllMembers(ErrorType E)
{
    delete[] FileNames;
    delete[] GInfo;
    delete[] BeginScan;
    delete[] EndScan;

    SetAllMembersDefault();
    error = E;
}


UDICOMData::UDICOMData(UFileName F, bool Nologging)
{
    SetAllMembersDefault();

    DicomDir    = F.GetDirectory();
    DICFile     = UDICOMFile();
    error       = AnalyzeDicomFiles(Nologging);
    if(error!=U_OK || Nscans<=0) 
    {
        CI.AddToLog("ERROR: UDICOMData::UDICOMData(). Reading DICOM files %s .\n", (const char*)F);
        DeleteAllMembers(U_ERROR);
    }
}

UDICOMData::UDICOMData(const char* DicDirName, bool Nologging)
{
    SetAllMembersDefault();
    Properties  = UString("No data Read yet");

    DicomDir    = UDirectory(DicDirName, CNULL);
    error       = AnalyzeDicomFiles(Nologging);
    if(error!=U_OK || Nscans<=0) 
    {
        CI.AddToLog("ERROR: UDICOMData::UDICOMData(). Reading DICOM directory %s .\n", DicDirName);
        DeleteAllMembers(U_ERROR);
    }
}


UDICOMData::~UDICOMData()
{
    DeleteAllMembers(U_OK);
}

UDICOMData::GeomInfo UDICOMData::GetGeomInfo(int iscan) const
{
    GeomInfo Result;
    Result.Gtilt        = 0.;
    Result.Dx           = 0.;
    Result.Dy           = 0.;
    Result.ndimx        = 0;
    Result.ndimy        = 0;
    Result.nslices      = 0;
    Result.ndimStamp    = 0;
    Result.SliceNumber  = 0;
    Result.SlicePos     = 0.;
    Result.Ori          = U_ORI_UNKNOWN;
    Result.ScanTilted   = false;
    Result.FirstX       = 0.;
    Result.FirstY       = 0.;
    Result.FirstZ       = 0.;
    Result.Mod          = U_MOD_UNKNOWN;
    Result.GE           = U_ERR_NO;
    Result.FileIndex    =-1;
    Result.RelSubDir[0] = 0;

    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetGeomInfo(). Scannumber out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return Result;
    }
    Result = GInfo[BeginScan[iscan]];
    return Result;
}

UFileName UDICOMData::GetBeginFile(int iscan) const
{
    if(this==NULL || error!=U_OK || FileNames==NULL)
    {
        CI.AddToLog("ERROR: UDICOMData::GetBeginFile(). Object NULL, erroneous or erroneously set .\n");
        return UFileName();
    }
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetBeginFile(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return UFileName();
    }
    return FileNames[BeginScan[iscan]];
}

UFileName UDICOMData::GetFileName(int iscan, int islice) const
{
    if(this==NULL || error!=U_OK || FileNames==NULL)
    {
        CI.AddToLog("ERROR: UDICOMData::GetFileName(). Object NULL, erroneous or erroneously set .\n");
        return UFileName();
    }
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetFileName(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return UFileName();
    }
    if(islice<0 || islice>EndScan[iscan]-BeginScan[iscan])
    {
        CI.AddToLog("ERROR: UDICOMData::GetFileName(). Slice number out of range (iscan=%d, islice=%d) \n",iscan, islice);
        return UFileName();
    }
    return FileNames[BeginScan[iscan]+islice];
}

const char* UDICOMData::GetPatName(int iscan)
{
    if(iscan<0 || iscan>= Nscans) iscan = 0;

    static char PatName[256]; PatName[0] = 0;
    if(GetPatName(FileNames[BeginScan[iscan]], PatName)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetPatName(). Patient name cannot be found. \n");
    }
    return PatName;
}

const char* UDICOMData::GetPatID(int iscan)
{
    if(iscan<0 || iscan>= Nscans) iscan = 0;

    static char PatID[256]; PatID[0] = 0;
    if(GetPatID(FileNames[BeginScan[iscan]], PatID)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetPatID() Patient ID cannot be found. \n");
    }
    return PatID;
}

UDateTime UDICOMData::GetPatDOB(int iscan)
{
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetPatDOB(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return UDateTime();
    }
    char temp[256];
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileNames[BeginScan[iscan]],GRP_BIRTH,ITM_BIRTH,1,temp,NULL)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetPatDOB(). Date cannot be found. \n");
        return UDateTime();
    }
    int day = atoi(temp+6); temp[6] = 0;
    int mon = atoi(temp+4); temp[4] = 0;
    int yea = atoi(temp  );
    return UDateTime(yea, mon, day, 0, 0, 0);
}

UDateTime UDICOMData::GetScanDate(int iscan)
{
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetScanDate(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return UDateTime();
    }
    char temp[256];
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileNames[BeginScan[iscan]],GRP_SCANDATE,ITM_SCANDATE,1,temp,NULL)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetScanDate(). Date cannot be found. \n");
        return UDateTime();
    }
    int day = atoi(temp+6); temp[6] = 0;
    int mon = atoi(temp+4); temp[4] = 0;
    int yea = atoi(temp  );
    int hou = 0;
    int min = 0;
    int sec = 0;

    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileNames[BeginScan[iscan]],GRP_SCANTIME,ITM_SCANTIME,1,temp,NULL)<0)
        CI.AddToLog("WARNING: UDICOMData::GetScanData(). Time cannot be found. \n");
    else
    {
        double srt = atof(temp);
        hou = int(floor(srt/10000.));
        min = int(floor(srt/100.) - hou*100);
        sec = int(srt - hou*10000 - min*100);
    }
    return UDateTime(yea, mon, day, hou, min, sec);
}

double UDICOMData::GetScanTime(int iscan)
{
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetScanTime(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return 0.;
    }
    char temp[256];
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileNames[BeginScan[iscan]],GRP_SCANTIME,ITM_SCANTIME,1,temp,NULL)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetScanTime(). Time cannot be found. \n");
        return 0;
    }
    double srt = atof(temp);
    double hou = floor(srt/10000.);
    double min = floor(srt/100.) - hou*100;
    double sec = srt - hou*10000 - min*100;
    return hou*3600 + min*60 + sec;
}

double UDICOMData::GetRepTime(int iscan)
{
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetRepTime(). Scan number out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return 0.;
    }
    char temp[256];
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileNames[BeginScan[iscan]], GRP_REPTIME, ITM_REPTIME, 1, temp, NULL)<0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetRepTime(). Repetition time not present. Set to 0.\n");
        return 0.;
    }
    return atof(temp)/1000.; // convert from ms to s
}

const UString& UDICOMData::GetScanDescriptor(int iscan) const
{
    ScanDescriptor = UString();
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::GetScanDescriptor(). Scannumber out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        ScanDescriptor =UString("ERROR");
        return ScanDescriptor;
    }

    int first = BeginScan[iscan];
    switch(GInfo[first].Mod)
    {
    case U_MOD_UNKNOWN: ScanDescriptor += "U_";  break;
    case U_MOD_MR     : ScanDescriptor += "MR";  break;
    case U_MOD_fMRI   : ScanDescriptor += "fM";  break;
    case U_MOD_CT     : ScanDescriptor += "CT";  break;
    case U_MOD_PET    : ScanDescriptor += "PT";  break;
    }
    size_t len = strlen(GInfo[first].RelSubDir);
    for(int k=0; k<len; k++)
    {
             if(GInfo[first].RelSubDir[k]==' ' )  ScanDescriptor += "_";
        else if(GInfo[first].RelSubDir[k]=='\\')  ScanDescriptor += "_";
        else if(GInfo[first].RelSubDir[k]=='/' )  ScanDescriptor += "_";
        else ScanDescriptor += GInfo[first].RelSubDir[k];
    }

    ScanDescriptor += UString(iscan,"_%3.3d_");
    switch(GInfo[first].Ori)
    {
    case U_ORI_UNKNOWN: ScanDescriptor +="Unk"; break;
    case U_ORI_AXIAL  : ScanDescriptor +="Axi"; break;
    case U_ORI_CORONAL: ScanDescriptor +="Cor"; break;
    case U_ORI_SAGITAL: ScanDescriptor +="Sag"; break;
    }
    ScanDescriptor += UString(GInfo[first].nslices,"_%3.3d");
    ScanDescriptor += UString(GInfo[first].ndimx  ,"x%3.3d");
    ScanDescriptor += UString(GInfo[first].ndimy  ,"x%3.3d");

    return ScanDescriptor;
}

ErrorType UDICOMData::SetScanOrientation(OrientType OT, int iscan)
{
    if(iscan<0 || iscan>= Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::SetScanOrientation(). Scannumber out of range (iscan=%d, Nscans=%d) \n",iscan, Nscans);
        return U_ERROR;
    }
    int first = BeginScan[iscan];
    int last  = EndScan[iscan];

    for(int ifil=first; ifil<=last; ifil++)
        GInfo[ifil].Ori = OT;

    Orientation = OT;
    return U_OK;
}

UEuler  UDICOMData::GetScanToWld(void) const
{
    switch(Orientation)
    {
    case U_ORI_AXIAL:      return UEuler(0.,0.,0.,0.0,-PI/2,PI);
    case U_ORI_CORONAL:    return UEuler(0.,0.,0.,-0.5* PI, PI , 0.5* PI);
    case U_ORI_SAGITAL:    return UEuler(0.,0.,0.,0.0, 0.0 , -0.5* PI);
    }
    return UEuler();
}

ErrorType UDICOMData::ExportDICOMslices(UDirectory *DICOMout, int maskUIDref, int maskUIDser, int maskUIDsop, const char* PrefixName, const char* newPatID, int inMin, int inMax, int otMin, int otMax)
/*
    Export all edited DICOM files and use the DICOM files of *this
    object as template.

    *DICOMout -Directory to which the files should be exported.

    if(maskUID>0)  edit some UID strings, using changeUID() before exporting slices
    if(PrefixName) insert PrefixName[] before patient name
    if(newPatID)   change patient ID into newPatID

    inMin, inMax, otMin, otMax: parameters used for scaling the pixel data
                                when all are zero, do not apply pixel scaling
 */
{
    PixelInfo PInfo;
    GetPixelInfo(FileNames[BeginScan[0]], &PInfo);

    if(PInfo.FileCompressMode==1)
    {
        CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Reference is in compressed mode and can therefore not be used as template.\n");
        return U_ERROR;
    }

/* Test Directory*/
    if(DICOMout->GetStatus()!=UDirectory::U_EXIST)
    {
        if(DICOMout->CreateDir()!=U_OK)
        {
            CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot create directory %s\n",DICOMout->GetDirectoryName());
            return U_ERROR;
        }
    }

    int SERUIDoffset    = -1;
    int SOPUIDoffset    = -1;
    int REFUIDoffset    = -1;
    char  SERUID[256];
    char  SOPUID[256];
    char  REFUID[256];

/* Convert all slices*/
    for(int is=0; is<Nscans; is++)
    {
/* Read pixel offset and complete contents from reference (Filename1) */
        int first = BeginScan[is];
        int last  = EndScan[is];
        for(int i=first; i<=last; i++)
        {
            UFileName Filename1 = FileNames[i];

            memset(SERUID, 0, sizeof(SERUID));
            memset(SOPUID, 0, sizeof(SOPUID));
            memset(REFUID, 0, sizeof(REFUID));
            if(maskUIDser>0) SERUIDoffset = GetSeriesInstanceUID  (Filename1, SERUID);
            if(maskUIDsop>0) SOPUIDoffset = GetSOPInstanceUID     (Filename1, SOPUID);
            if(maskUIDref>0) REFUIDoffset = GetRefFrameInstanceUID(Filename1, REFUID);

            char PatName[256];
            int PatNameoffset   = GetPatName(Filename1,PatName);
            char PatID[256];
            int PatIDoffset     = GetPatID(Filename1,PatID);

            FILE* fp1           = fopen(Filename1,"rb",false);
            char* buffer        = NULL;
            long int Size       = 0;
            if(fp1)
            {
                Size      = GetFileSize(fp1);
                buffer    = new char[Size];
                if(buffer) fread(buffer,Size,1,fp1);
            }
            if(buffer==NULL)
            {
                if(fp1) fclose(fp1);
                else    CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot open file %s \n", (const char*)Filename1);
                CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Memory allocation, Size = %d .\n", int(Size));
            }
            fclose(fp1);

            int PixelOffSet = -1;
            UField*    Fpix = NULL;
            if(inMin || inMax || otMin || otMax)
            {
                Fpix = GetSliceAsField(Filename1, &PixelOffSet);
                if(Fpix==NULL || Fpix->GetError()!=U_OK)
                {
                    delete Fpix; Fpix = NULL;
                }
                else
                {
                    if(Fpix->ScaleData(inMin, inMax, otMin, otMax)!=U_OK)
                    {
                        delete Fpix; Fpix = NULL;
                    }
                }
            }
/* Create export file name */
            UFileName Filename2(DICOMout, "R", FileNames[i].GetBaseName());

/* Create new Series UID, by increasing all number characters, except '9'*/
            if(REFUIDoffset>=0)
            {
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old REFUID = %s \n",REFUID);
                ChangeUID(REFUID, maskUIDref);
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New REFUID = %s \n",REFUID);
            }
            if(SERUIDoffset>=0)
            {
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old SERUID = %s \n",SERUID);
                ChangeUID(SERUID, maskUIDser);
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New SERUID = %s \n",SERUID);
            }
            if(SOPUIDoffset>=0)
            {
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old SOPUID = %s \n",SOPUID);
                ChangeUID(SOPUID, maskUIDsop);
                if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New SOPUID = %s \n",SOPUID);
            }
            if(PatNameoffset>0 && PrefixName)
            {
                size_t nbytes = MIN(strlen(PrefixName), strlen(PatName));
                for(int k=0; k<nbytes; k++) PatName[k] = PrefixName[k];
            }
            if(PatIDoffset>0 && newPatID)
            {
                size_t nbytes = MIN(strlen(newPatID), strlen(PatID));
                strncpy(PatID, newPatID, nbytes);
            }

/* Copy contents from reference */
            FILE* fp2       = fopen(Filename2,"wb",false);
            if(fp2==NULL)
            {
                CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot write to file %s.\n",Filename2.GetFullFileName());

                delete[] buffer;
                return U_ERROR;
            }
            fwrite(buffer,Size,1,fp2);
            fclose(fp2);

            fp2       = fopen(Filename2,"r+b",false);

/* Set new series ID */
            if(REFUIDoffset>=0)
            {
                fseek(fp2, REFUIDoffset, SEEK_SET);
                fwrite(REFUID, 1, strlen(REFUID)-1, fp2);
            }
            if(SERUIDoffset>=0)
            {
                fseek(fp2, SERUIDoffset, SEEK_SET);
                fwrite(SERUID, 1, strlen(SERUID)-1, fp2);
            }
            if(SOPUIDoffset>=0)
            {
                fseek(fp2, SOPUIDoffset, SEEK_SET);
                fwrite(SOPUID, 1, strlen(SOPUID)-1, fp2);
            }
            if(PatNameoffset>=0)
            {
                fseek(fp2, PatNameoffset, SEEK_SET);
                fwrite(PatName, 1, strlen(PatName)-1, fp2);
            }
            if(PatIDoffset>=0)
            {
                fseek(fp2, PatIDoffset, SEEK_SET);
                fwrite(PatID, 1, strlen(PatID)-1, fp2);
            }
            if(PixelOffSet>=0)
            {
                if(Fpix==NULL && i==0)
                {
                    CI.AddToLog("WARING UDICOMData::ExportDICOMslices(). Rescaling pixel data. \n");
                }
                else if(Fpix)
                {
                    int nbytes = Fpix->GetNpoints()*Fpix->GetDataSize();
                    fseek(fp2, PixelOffSet, SEEK_SET);
                    fwrite(Fpix->GetData(), 1, nbytes, fp2);
                }
            }
            delete Fpix; Fpix = NULL;
            fclose(fp2);
        }
    }
    return U_OK;
}

ErrorType UDICOMData::ExportDICOMslices(const UField* Scan, int scannum, UDirectory *DICOMout, int maskUIDref, int maskUIDser, int maskUIDsop, const char* PrefixName, const char* newPatID, const char* NewSeriesDescription)
/*
    Export the 3D UField-object *Scan in DICOM format and use the DICOM files of *this
    object as template. Test if the image size of this reference and that of
    *Scan are equal, before exporting files.

    scannum   -DICOM scan used as reference
    *DICOMout -Directory to which the files should be exported.

    if(maskUID>0)  edit some UID strings, using changeUID() before exporting slices
    if(PrefixName) insert PrefixName[] before patient name
    if(newPatID)   change patient ID into newPatID

 */
{
/* Test scannum*/
    if(scannum<0 || scannum>=Nscans)
    {
        CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Scan number out of range (=%d)\n",scannum);
        return U_ERROR;
    }

/* Test image size */
    int first = BeginScan[scannum];
    int last  = EndScan[scannum];

/* Get general image info, hopefully identical for all slices */
    int   nx  = GInfo[first].ndimx;
    int   nz  = GInfo[first].ndimy;
    int   ny  = last-first+1;

    PixelInfo PInfo;
    UFileName  Filename = FileNames[first];
    GetPixelInfo(Filename, &PInfo);

    if(Scan->GetDimensions(0)!=nx || Scan->GetDimensions(1)!=ny || Scan->GetDimensions(2)!=nz)
    {
        CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Image dimendions of scan and template (%d,%d,%d) are different.\n",nx,ny,nz);
        return U_ERROR;
    }
    if(PInfo.FileCompressMode==1)
    {
        CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Reference is in compressed mode and can therefore not be used as template.\n");
        return U_ERROR;
    }
    int BytesPerPixel = PInfo.PixelDataLen / (nx*nz);
    if(  (Scan->GetDType()==UField::U_BYTE    && BytesPerPixel!=1) ||
         (Scan->GetDType()==UField::U_SHORT   && BytesPerPixel!=2) ||
         (Scan->GetDType()==UField::U_INTEGER && BytesPerPixel!=4))
    {
        CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Data type of scan and template are different. \n");
        return U_ERROR;
    }

/* Test Directory*/
    if(DICOMout->GetStatus()!=UDirectory::U_EXIST)
    {
        if(DICOMout->CreateDir()!=U_OK)
        {
            CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot create directory %s\n",DICOMout->GetDirectoryName());
            return U_ERROR;
        }
    }

    int SERUIDoffset    = -1;
    int SOPUIDoffset    = -1;
    int REFUIDoffset    = -1;
    char  SERUID[256];
    char  SOPUID[256];
    char  REFUID[256];

/* Convert all slices*/
    for(int i=0; i<ny; i++)
    {
/* Read pixel offset and complete contents from reference (Filename1) */
        UFileName Filename1 = FileNames[first+i];
        PixelInfo PInfo;
        GetPixelInfo(Filename1, &PInfo);

        memset(SERUID, 0, sizeof(SERUID));
        memset(SOPUID, 0, sizeof(SOPUID));
        memset(REFUID, 0, sizeof(REFUID));
        if(maskUIDser>0) SERUIDoffset = GetSeriesInstanceUID  (Filename1, SERUID);
        if(maskUIDsop>0) SOPUIDoffset = GetSOPInstanceUID     (Filename1, SOPUID);
        if(maskUIDref>0) REFUIDoffset = GetRefFrameInstanceUID(Filename1, REFUID);

        char PatName[256];
        int PatNameoffset   = GetPatName(Filename1,PatName);
        char PatID[256];
        int PatIDoffset     = GetPatID(Filename1,PatID);

        char  SerDescr[256];
        int   SerDescroffset = GetSeriesDescription(Filename1, SerDescr);

        FILE*    fp1         = fopen(Filename1,"rb",false);
        char*    buffer      = NULL;
        long int Size        = 0;
        if(fp1)
        {
            Size       = GetFileSize(fp1);
            buffer     = new char[Size];
            if(buffer) fread(buffer,Size,1,fp1);
        }
        if(buffer==NULL)
        {
            if(fp1) fclose(fp1);
            else    CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot open file %s \n", (const char*)Filename1);
            CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Memory allocation, Size = %d .\n", int(Size));
        }
        fclose(fp1);

/* Create export file name */
        UFileName Filename2(DICOMout, "R", Filename1.GetBaseName());

/* Create new Series UID, by increasing all number characters, except '9'*/
        if(REFUIDoffset>=0)
        {
            if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old REFUID = %s \n",REFUID);
            ChangeUID(REFUID, maskUIDref);
            if(i==first) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New REFUID = %s \n",REFUID);
        }
        if(SERUIDoffset>=0)
        {
            if(i==0) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old SERUID = %s \n",SERUID);
            ChangeUID(SERUID, maskUIDser);
            if(i==0) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New SERUID = %s \n",SERUID);
        }
        if(SOPUIDoffset>=0)
        {
            if(i==0) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). Old SOPUID = %s \n",SOPUID);
            ChangeUID(SOPUID, maskUIDsop);
            if(i==0) CI.AddToLog("Note: UDICOMData::ExportDICOMslices(). New SOPUID = %s \n",SOPUID);
        }
        if(PatNameoffset>0 && PrefixName)
        {
            size_t nbytes = MIN(strlen(PrefixName), strlen(PatName));
            for(int k=0; k<nbytes; k++) PatName[k] = PrefixName[k];
        }
        if(PatIDoffset>0 && newPatID)
        {
            size_t nbytes = MIN(strlen(newPatID), strlen(PatID));
            if(nbytes>sizeof(PatID)) nbytes = sizeof(PatID);
            strncpy(PatID, newPatID, nbytes);
        }
        if(SerDescroffset>0 && NewSeriesDescription)
        {
            size_t nbytes = MIN(strlen(NewSeriesDescription), strlen(SerDescr));
            if(nbytes>sizeof(SerDescr)) nbytes = sizeof(SerDescr);
            strncpy(SerDescr, NewSeriesDescription, nbytes);
        }

/* Copy contents from reference */
        FILE* fp2       = fopen(Filename2,"wb",false);
        if(fp2==NULL)
        {
            CI.AddToLog("ERROR UDICOMData::ExportDICOMslices(). Cannot write to file %s.\n",Filename2.GetFullFileName());
            delete[] buffer;
            return U_ERROR;
        }
        fwrite(buffer,Size,1,fp2);
        fclose(fp2);

/* Fill buffer with slice i from *Scan*/
        int    size   = Scan->GetDataSize();
        void*  data   = Scan->GetData();
        for(int iz=0;iz<nz;iz++)
            memcpy(buffer+iz*nx*size, ((char*)data)+(iz*ny+i)*nx*size, nx*size);

        if(swap==1 && BytesPerPixel==2)
        {
            for(char* pb=buffer; pb<buffer+2*nx*nz; pb+=2)
            {
                char sw = *pb;
                *pb     = *(pb+1);
                *(pb+1) = sw;
            }
        }
/* Swap x and z*/
       swapxy(buffer, BytesPerPixel, nx, nz);

/* Set pixels*/
        fp2       = fopen(Filename2,"r+b",false);
        fseek(fp2, PInfo.offset, SEEK_SET);
        fwrite(buffer, 1, PInfo.PixelDataLen, fp2);
        delete[] buffer;

/* Set new series ID */
        if(REFUIDoffset>=0)
        {
            fseek(fp2, REFUIDoffset, SEEK_SET);
            fwrite(REFUID, 1, strlen(REFUID)-1, fp2);
        }
        if(SERUIDoffset>=0)
        {
            fseek(fp2, SERUIDoffset, SEEK_SET);
            fwrite(SERUID, 1, strlen(SERUID)-1, fp2);
        }
        if(SOPUIDoffset>=0)
        {
            fseek(fp2, SOPUIDoffset, SEEK_SET);
            fwrite(SOPUID, 1, strlen(SOPUID)-1, fp2);
        }
        if(PatNameoffset>=0 && PrefixName)
        {
            fseek(fp2, PatNameoffset, SEEK_SET);
            fwrite(PatName, 1, strlen(PatName)-1, fp2);
        }
        if(PatIDoffset>=0 && newPatID)
        {
            fseek(fp2, PatIDoffset, SEEK_SET);
            fwrite(PatID, 1, strlen(PatID)-1, fp2);
        }
        if(SerDescroffset>=0)
        {
            fseek(fp2, SerDescroffset, SEEK_SET);
            fwrite(SerDescr, 1, strlen(SerDescr)-1, fp2);
        }
        fclose(fp2);
    }
    return U_OK;
}

UField* UDICOMData::GetRawScan(int iscan)
{
    UField* F = ReadSlices(iscan, -1, 1, 1, false, false, true, -1, -1, UField::U_DCONVERT_MINMAX);
    if(F==NULL || F->GetError()!=U_OK)
    {
        delete F;
        CI.AddToLog("ERROR: UDICOMData::GetRawScan(). Getting UField for scan %d  .\n", iscan);
        return NULL;
    }
    GeomInfo G  = GInfo[BeginScan[iscan]];
    if(G.ScanTilted==true)
    {
        CI.AddToLog("WARNING: UDICOMData::GetRawScan(). Scan is tilted (scan=%d)  .\n", iscan);
    }

////
//    if(Orientation==U_ORI_CORONAL)
//        F->ReverseData(1, false);
////


    UVector3 Fp = F->GetFirstx();
    UVector3 Lp = F->GetLastx();
    UVector3 Shift;

    switch(G.Ori)
    {
    case U_ORI_AXIAL:   Shift =  UVector3(G.FirstY-Fp.Getx(), 0.       , G.FirstX-Lp.Getz() ); break;
    case U_ORI_SAGITAL: Shift =  UVector3(G.FirstZ-Lp.Getx(), 0.       , G.FirstY-Lp.Getz() ); break;
    case U_ORI_CORONAL:
        {
            UVector3 Ce = F->GetCenter(false, -1);
            UVector3 Pi = F->GetVoxel();
            int      nx = F->GetDimensions(0);
            int      nz = F->GetDimensions(2);
            Shift =  -UVector3(G.FirstZ-nx*Pi.Getx()-Fp.Getx(), 2*Ce.Gety(), G.FirstX-nz*Pi.Getz()-Fp.Getz() );
        }
        break;
    }
    F->ShiftCoords(Shift);
    return F;
}

UField* UDICOMData::ReadSlices(int scannum, int numslices, int pixdown, int slicedown, bool centerY, bool ReverseSlices, bool WordOn, int pixmin, int pixmax, UField::DatConvertType DatCon)
/*
    Read the slices of scan with number scannum and convert these slices into an UField object,
    of type U_RECTILINEAR.

    if(WordOn) Convert the pixels short, elso to byte.
    if data converted to byte, scale pixels according to DatCon, and,
    dependent on the case, pixmin and pixmax (see UField::ConvertDataToByte()).

    if(numslices>0) convert the first numslices slices.
    if(CenterY) shift slice coordinates such that the origin is in the middle of the scan
    if(ReverseSlices) reverse the sign of the slice coordinates.
 */
{
    if(scannum<0 || scannum>=Nscans)
    {
        CI.AddToLog("ERROR: UDICOMData::ReadSlices(). Scan number out of range (=%d). Total number of scans = %d\n",scannum, Nscans);
        return NULL;
    }
    if(numslices==0) return NULL;

    int first = BeginScan[scannum];
    int last  = EndScan[scannum];
    if(numslices>0) last = MIN(first+numslices, last);

    double dx   = GInfo[first].Dx;
    double dz   = GInfo[first].Dy;
    int    nx   = GInfo[first].ndimx;
    int    nz   = GInfo[first].ndimy;
    int    ny   = last-first+1;
    Orientation = GInfo[first].Ori;

/* The gantry tilt*/
    double GantryTilt = GInfo[first].Gtilt;
    if(GantryTilt>1.)
        CI.AddToLog("WARNING: UDICOMData::ReadSlices: gantry tilt is %f\n",GantryTilt);


/* Read slice coordinates*/
    double ys[MAX_SLICES];
    double t = 0;

    for(int i=first; i<=last; i++)
    {
        switch(Orientation)
        {
        case U_ORI_AXIAL:    ys[i-first] = GInfo[i].FirstZ;   break;
        case U_ORI_SAGITAL:  ys[i-first] = GInfo[i].FirstX;   break;
        case U_ORI_CORONAL:  ys[i-first] = GInfo[i].FirstY;   break;
        default:             ys[i-first] = GInfo[i].SlicePos; break;
        }

        if(i==first) continue;
        if(i==first+1)
        {
            t = ys[1] - ys[0];
        }
        else if(t * (ys[i-first]-ys[i-first-1]) < 0.0)
        {
            CI.AddToLog("WARNING: UDICOMData::ReadSlices(). Sign change in slice distance (slice %d)\n", i-first);
        }
        else if(t * (ys[i-first]-ys[i-first-1]) < 1.e-5)
        {
            CI.AddToLog("WARNING: UDICOMData::ReadSlices(). Almost identical slice coordinates (slice %d)\n", i-first);
        }
        t = ys[i-first] - ys[i-first-1];
    }

/* Center the Y coordinate */
    double ynew[MAX_SLICES];
    double yav = ys[0];
    for(int i=0; i<ny; i++) yav    += ys[i];
    yav /= ny;
    for(int i=0; i<ny; i++) ynew[i] = ys[i] - yav;

/* Create the volume field */
    int pixels  = nx * ny * nz;
    int nxny    = nx * ny;

/* Read each planar slice and add it into the volume in 2-byte units */
    bool           AllowRGB = true;
    short*         data     = new short[3*pixels];        /* allow RGB data too */
    unsigned char* scan_buf = new unsigned char[3*nx*nz]; /* allow RGB data too */
    if(data==NULL)
    {
        AllowRGB = false;
        data     = new short[pixels];
    }
    if(!data || !scan_buf)
    {
        CI.AddToLog("ERROR: UDICOMData::ReadSlices: Memory allocation error in read buffer. pixels = %d \n", pixels);
        delete[] data;
        delete[] scan_buf;
        return NULL;
    }

    int  BytesPerPixel = 0;
    for(int slice=0; slice<ny; slice++)
    {
        UFileName Filename2 = FileNames[first+slice];

        PixelInfo PInfo;
        if(GetPixelInfo(Filename2, &PInfo)!=U_OK)
        {
            CI.AddToLog("ERROR: UDICOMData::ReadSlices: Could not locate image start address\n");
            delete[] data;
            delete[] scan_buf;
            return NULL;
        }

        BytesPerPixel = PInfo.PixelDataLen / (nx*nz);

        if(BytesPerPixel<=0 || BytesPerPixel > 3 || (AllowRGB==false && BytesPerPixel>2))
        {
            if(PInfo.PixelDataLen==-1)
            {
                CI.AddToLog("WARNING: UDICOMData::ReadSlices: Pixel data length invalid or not found (PInfo.PixelDataLen = %d). Set data type equal to short.\n", PInfo.PixelDataLen);
                BytesPerPixel = 2;
            }
            else
            {
                CI.AddToLog("ERROR: UDICOMData::ReadSlices: file contains other that byte, short or color information (BytesPerPixel = %d, nx=%d, nz=%d).\n", BytesPerPixel, nx, nz);
                delete[] data;
                delete[] scan_buf;
                return NULL;
            }
        }
        if(GetPixels(Filename2, &PInfo, scan_buf)!=U_OK)
        {
            CI.AddToLog("ERROR: UDICOMData::ReadSlices: Getting pixels.\n");
            delete[] data;
            delete[] scan_buf;
            return NULL;
        }

        unsigned char* bp  = scan_buf;
        if(swap==1 && BytesPerPixel==2)
        {
            for(int x=0; x<nx; x++)
            {
                int nxslice = nx*slice + x;
                for(int z=0; z<nz; z++)
                {
                    unsigned char v = *bp++;
                    data[nxslice] = 256 * v + *(char *)bp++;
                    nxslice += nxny;
                }
            }
        }
        else
        {
            for(int x=0; x<nx; x++)
            {
                if(BytesPerPixel==1)
                {
                    int nxslice = nx*slice + x;
                    for(int z=0; z<nz; z++)
                    {
                        ((char *)data)[nxslice] = *(char *)bp++;
                        nxslice += nxny;
                    }
                }
                else if(BytesPerPixel==2)
                {
                    int nxslice = nx*slice + x;
                    for(int z=0; z<nz; z++)
                    {
                        unsigned char v = *bp++;
                        data[nxslice] = v + 256 * *(char *)bp++;
                        nxslice += nxny;
                    }
                }
                else if(BytesPerPixel==3)
                {
                    int nxslice = (nx*slice + x) * 3;
                    for(int z=0; z<nz; z++)
                    {
                        ((char *)data)[nxslice+2] = *(char *)bp++;
                        ((char *)data)[nxslice+1] = *(char *)bp++;
                        ((char *)data)[nxslice  ] = *(char *)bp++;
                        nxslice += nxny*3;
                    }
                }
            }
        }
    }
    delete[] scan_buf;

/* Create the 3D output field */
    int     ddims[3] = {(nx+pixdown-1)/pixdown, (ny+slicedown-1)/slicedown, (nz+pixdown-1)/pixdown};
    double* xcoords  = new double[ddims[0]];
    double* ycoords  = new double[ddims[1]];
    double* zcoords  = new double[ddims[2]];
    if(xcoords==NULL || ycoords==NULL || zcoords==NULL)
    {
        delete[] xcoords;
        delete[] ycoords;
        delete[] zcoords;
        delete[] data;
        CI.AddToLog("ERROR: UDICOMData::ReadSlices(). Could not allocate memory for field coordinates\n");
        return NULL;
    }
/* Fill coordinate arrays */
    double* p=NULL;
    int     i=0;
    for(p=xcoords, i=0; i<nx; i+=pixdown)           *p++ =  (i - (nx / 2)) * dx;
    if(centerY ==true)
        for(p=ycoords, i=0; i<ny; i+=slicedown)     *p++ =  ynew[i];
    else
        for(p=ycoords, i=0; i<ny; i+=slicedown)     *p++ =  ys[i];
    if(ReverseSlices==true)
        for(p=ycoords, i=0; i<ny; i+=slicedown,p++) *p   =  -*p;
    for(p=zcoords, i=0; i<nz; i+=pixdown)           *p++ = -(i - (nz / 2)) * dz;


    UField::DataType DT=UField::U_BYTE;
    if(BytesPerPixel==2) DT = UField::U_SHORT;

    int veclen = 1;
    if(BytesPerPixel==3) veclen = 3;

    UField* Output = new UField(xcoords, ycoords, zcoords, ddims, DT, veclen);
    delete[] xcoords;
    delete[] ycoords;
    delete[] zcoords;
    if(Output==NULL || Output->GetError()!=U_OK)
    {
        delete[] data;
        delete   Output;
        CI.AddToLog("ERROR: UDICOMData::ReadSlices(). Could not allocate memory for output field.\n");
        return NULL;
    }
/* General properties:*/
    UString Prop = this->GetProperties("// ", scannum);
    Output->AddFileComments(Prop);

/* Move the pixel data from the byte/short/RGB array (data) to the field */
    if(pixdown==1 && slicedown==1)
    {
        memcpy(Output->GetSdata(), data, pixels * BytesPerPixel);
    }
    else
    {
        if(BytesPerPixel==1)
        {
            unsigned char* bdata = (unsigned char *) data;
            unsigned char* bp    = Output->GetBdata();
            {
                for(int z=0; z<nz; z+=pixdown)
                    for(int y=0; y<ny; y+=slicedown)
                    {
                        unsigned char* bp2 = bdata + z*nxny + y*nx;
                        for(int x=0; x<nx; x+=pixdown)
                            *bp++ = bp2[x];
                    }
            }
        }
        else if(BytesPerPixel==2)
        {
            short* ips = Output->GetSdata();

            for(int z=0; z<nz; z+=pixdown)
                for(int y=0; y<ny; y+=slicedown)
                {
                    short* sp = data + z*nxny + y*nx;
                    for(int x=0; x<nx; x+=pixdown)
                    *ips++ = sp[x];
                }

        }
        else if(BytesPerPixel==3)
        {
            unsigned char* bdata = (unsigned char *) data;
            unsigned char* bp    = Output->GetBdata();
            {
                for(int z=0; z<nz; z+=pixdown)
                for(int y=0; y<ny; y+=slicedown)
                {
                    unsigned char* bp2 = bdata + z*nxny + y*nx;
                    for(int x=0; x<3*nx; x+=pixdown*3)
                    {
                        *bp++ = bp2[x  ];
                        *bp++ = bp2[x+1];
                        *bp++ = bp2[x+2];
                    }
                }
            }
        }
    }
    delete[] data;

    if(BytesPerPixel==2 && WordOn==false)
        Output->ConvertDataToByte(DatCon, pixmin, pixmax);
    if(BytesPerPixel==2 && Output->GetDType()==UField::U_SHORT)
    {
        int imin = 0, imax = 0;
        Output->GetMinMaxData(&imin, &imax);
        if(imin<0 && imax<0) (*Output) += (1<<15);
    }

    if(ny>1) return Output;

/* What to do with single slice?*/
    if(GInfo[first].ndimStamp==0  ||
       GInfo[first].ndimStamp==nx ||
       nx!=nz)
    {
        Output->DuplicateSingleSlice();
    }
    else
    {
        double Thickness = .1;
        UFileName  Filename  = FileNames[first];
        if(GetSliceDistance(Filename, &Thickness)!=U_OK)
            CI.AddToLog("WARNING: UDICOMData::ReadSlices().  Cannot get slice thickness from DICOM file. Assume %f cm.\n", Thickness);

        Output->StampUnpack(GInfo[first].ndimStamp, Thickness, true);
    }
    return Output;
}

const UString& UDICOMData::GetProperties(UString Comment, int iscan) 
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UDICOM-object\n");
        return Properties;
    }
    if(iscan<0 || iscan>= Nscans)
    {
        Properties = UString("ERROR");
        CI.AddToLog("ERROR: UDICOMData::GetProperties(). iscan = %d .\n", iscan);
        return Properties; 
    }
    Properties = UString();

    UFileName FileName = FileNames[BeginScan[iscan]];
    char temp[256];

    Properties  = "Patient:\n";
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_NAME,ITM_NAME,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Name               =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_PATID,ITM_PATID,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "PatientID          =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_BIRTH,ITM_BIRTH,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Date of Birth      =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_SEX,ITM_SEX,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Sex                =  %s\n");
    Properties += "Scan:\n";
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_SCANDATE,ITM_SCANDATE,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Date               =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_SCANTIME,ITM_SCANTIME,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Time               =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_PATORI,ITM_PATORI,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "PatientOrientation =  %s\n");
    switch(GInfo[BeginScan[iscan]].Ori)
    {
    case U_ORI_AXIAL:   Properties += UString(" ScanOrientation      =  Axial\n");   break;
    case U_ORI_SAGITAL: Properties += UString(" ScanOrientation      =  Sagital\n"); break;
    case U_ORI_CORONAL: Properties += UString(" ScanOrientation      =  Coronal\n"); break;
    case U_ORI_UNKNOWN: Properties += UString(" ScanOrientation      =  Unknown\n"); break;
    }
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_INSTIT,ITM_INSTIT,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Institution        =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_CONTRAST,ITM_CONTRAST,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "Contrast           =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_SERDESCR,ITM_SERDESCR,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "SeriesDescription  =  %s\n");
    memset(temp, 0, sizeof(temp));
    ACRNEMA_header(FileName,GRP_ADM_DIAGN,ITM_ADM_DIAGN,1,temp,NULL);
    if(temp[0]) Properties += UString(temp, "DiagnosisDescription =  %s\n");
    memset(temp, 0, sizeof(temp));
    ModalityType Mod = GInfo[BeginScan[iscan]].Mod;
    if(temp[0]) Properties += UString(GetModalityTypeText(Mod), "Modality           = %s\n");
    if(Mod==U_MOD_CT)
    {
        double GantryTilt = GInfo[BeginScan[iscan]].Gtilt;
        Properties += UString(GantryTilt, "GantryTilt         =  %s  // [degrees]\n");
    }
    else if(Mod==U_MOD_MR || Mod==U_MOD_fMRI)
    {
        MRInfo MR;
        if(GetMRInfo(FileName, &MR)!=U_ERROR)
        {
            Properties += UString(MR.ImageType ,"ImageType         = %s\n");
            Properties += UString(MR.ImageTime ,"ImageTime         = %s\n");
            Properties += UString(MR.Sequence  ,"Sequence          = %s\n");
            Properties += UString(MR.SeqName   ,"SeqName           = %s\n");
            Properties += UString(MR.FieldStr  ,"FieldStr.         = %s\n");
            Properties += UString(MR.EchoTime  ,"EchoTime          = %s //[ms]\n");
            Properties += UString(MR.InvTime   ,"InvTime           = %s //[ms]\n");
            Properties += UString(MR.RepTime   ,"RepTime           = %s //[ms]\n");
            Properties += UString(MR.FlipAngle ,"FlipAngle         = %s\n");
            Properties += UString(MR.NumAver   ,"NumAver           = %s\n");
            Properties += UString(MR.AcqMat    ,"AcqMat            = %s\n");
            Properties += UString(MR.TempPos   ,"TemporalPosition  = %s\n");
            Properties += UString(MR.NumTempPos,"NumTempPos        = %s\n");
            Properties += UString(MR.TempRes   ,"TempResolution    = %s\n");
        }
    }

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}


int UDICOMData::ACRNEMA_header(UFileName F, int group, int element, int forcestring, char *result, int *len)
{
    DICFile = UDICOMFile(F);
    if(DICFile.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDICOMData::ACRNEMA_header(). Setting UDICOMFile object. \n");
        return -1;
    }
    swap = DICFile.GetSwap();

    if(len) *len = 0;
    while(1)
    {
        ELEMENT*    E = DICFile.dicom_element();
        if(E==NULL) break;

        if(E->group != group || E->element != element)
        {
            DICFile.dicom_skip();
            continue;
        }
        unsigned int offset = DICFile.GetOffset();
        DICFile.dicom_load(AE);

        if(forcestring)
        {
            int Len = 127;
            memset(result, 0, 128);
            if(E->length<=0 || E->value.AE==NULL) strcpy(result, "Empty");
            else
            {
                int nc = 0;
                for(unsigned int k=0; k<E->vm; k++)
                {
                    switch(E->vr)
                    {
                    case AE: nc += sprintf(result+nc,"%s",(const char*)(E->value.AE[k])); break;
                    case AS: nc += sprintf(result+nc,"%s",(const char*)(E->value.AS[k])); break;
                    case CS: nc += sprintf(result+nc,"%s",(const char*)(E->value.CS[k])); break;
                    case DA: nc += sprintf(result+nc,"%s",(const char*)(E->value.DA[k])); break;
                    case LT: nc += sprintf(result+nc,"%s",(const char*)(E->value.LT   )); break;
                    case LO: nc += sprintf(result+nc,"%s",(const char*)(E->value.LO[k])); break;
                    case OB: nc += sprintf(result+nc,"%s",(const char*)(E->value.OB   )); break;
                    case OW: nc += sprintf(result+nc,"%s",(const char*)(E->value.OW   )); break;
                    case PN: nc += sprintf(result+nc,"%s",(const char*)(E->value.PN[k])); break;
                    case SH: nc += sprintf(result+nc,"%s",(const char*)(E->value.SH[k])); break;
                    case ST: nc += sprintf(result+nc,"%s",(const char*)(E->value.ST   )); break;
                    case TM: nc += sprintf(result+nc,"%s",(const char*)(E->value.TM[k])); break;
                    case UI: nc += sprintf(result+nc,"%s",(const char*)(E->value.UI[k])); break;
                    case IS: nc += sprintf(result+nc,"%s",(const char*)(E->value.IS[k])); break;

                    case DS: nc += sprintf(result+nc,"%s",(const char*)(E->value.DS[k])); break;
                    case UT: nc += sprintf(result+nc,"%s",(const char*)(E->value.UT   )); break;
                    case DT: nc += sprintf(result+nc,"%s",(const char*)(E->value.DT[k])); break;
                    case UN:
                    case SQ: nc += sprintf(result+nc,"%s",(const char*)(E->value.AE[k])); break;
                    case AT: nc += sprintf(result+nc, "(%d, %d)",E->value.AT[k].group,E->value.AT[k].element); break;

                    case FL: nc += sprintf(result+nc, "%f", E->value.FL[k]);   break;
                    case FD: nc += sprintf(result+nc, "%f", E->value.FD[k]);   break;
                    case SL: nc += sprintf(result+nc, "%d", E->value.SL[k]);   break;
                    case SS: nc += sprintf(result+nc, "%d", E->value.SS[k]);   break;
                    case UL: nc += sprintf(result+nc, "%d", E->value.UL[k]);   break;
                    case US: nc += sprintf(result+nc, "%d", E->value.US[k]);   break;
                    }
                    if(E->vr!=AE && E->vr!=AS && E->vr!=CS && E->vr!=DA && E->vr!=DS && E->vr!=DT &&
                       E->vr!=IS && E->vr!=LO && E->vr!=PN && E->vr!=SH && E->vr!=TM && E->vr!=UI) break;
                    if(len) *len = nc;
                    if(nc>Len) break;
                    if(k+1!=E->vm) nc += sprintf(result+nc,"\\");
                }
            }
        }
        else
        {
            if(len) *len = E->length;
        }
        return offset;
    }
    return -1;
}

int UDICOMData::nki_private_decompress(short int *dest, signed char *src) const
/* decoder for NKI private compressed pixel data VR 0x7fdf,0x0010
   arguments: dest    = (in) points to area where destination data is written (short)
              src     = (in) points compressed source data (byte stream)

   The return value is the number of pixels that have been processed.

   The compressed data looks like:
   (number of pixels)-1 times:
     OR 1 byte   = LL     7  bits signed (difference pixel[1] - pixel[0]);
     OR 2 bytes  = HHLL   15 bits signed (difference pixel[1] - pixel[0]) xored with 0x4000;
     OR 3 bytes  = 7FHHLL 16 bits absolute pixel data if 15 bits difference is exceeded
     OR 2 bytes  = 80NN   run length encode NN zero differences (max 255)

   The performance on typical CT or MRI data is 1.9 times compression and a very good speed
*/
{ int npixels, retvalue, mode, val;

  npixels = *(int *)src;
  src += 4;

  mode = *(int *)src;
  src += 4;

  /* mode 1 is the only supported mode for now */
  if (mode != 1) return 0;

  *dest = *(short int *)src;
  src+=2;

  retvalue = npixels;
  npixels--;

  do
  { val = *src;

    if (val >= -64 && val <= 63)
    { dest[1] = dest[0] + val;
      dest++;
      src++;
    }
    else if (val==0x7f)
    { dest[1] = ((int)(((unsigned char *)src)[1])<<8) + ((unsigned char*)src)[2];
      dest++;
      src+=3;
    }
    else if ((val&0xff)==0x80)
    { mode = ((unsigned char *)src)[1];
      npixels -= mode-1;
      do
      { dest[1] = dest[0];
        dest++;
      }
      while (--mode);
      src+=2;
    }
    else
    { signed short diff = ((val^0x40)<<8) + (unsigned char)(src[1]);
      dest[1] = dest[0] + diff;
      dest++;
      src+=2;
    }
  }
  while (--npixels);

  return retvalue;
}


static int GeomOrder(const void *elem1, const void *elem2)
{
    const struct UDICOMData::GeomInfo* G1 = (UDICOMData::GeomInfo*)elem1;
    const struct UDICOMData::GeomInfo* G2 = (UDICOMData::GeomInfo*)elem2;

    int dirorder = strncmp(G1->RelSubDir, G2->RelSubDir, sizeof(G1->RelSubDir));
    if(dirorder < 0) return -1;
    if(dirorder > 0) return  1;

    if((int)G1->GE < (int)G2->GE) return -1;
    if((int)G1->GE > (int)G2->GE) return  1;

    if((int)G1->Ori < (int)G2->Ori) return -1;
    if((int)G1->Ori > (int)G2->Ori) return  1;

    if(G1->Gtilt < G2->Gtilt) return -1;
    if(G1->Gtilt > G2->Gtilt) return  1;

    if(G1->ndimx < G2->ndimx) return -1;
    if(G1->ndimx > G2->ndimx) return  1;

    if(G1->ndimy < G2->ndimy) return -1;
    if(G1->ndimy > G2->ndimy) return  1;

    if(G1->Dx < G2->Dx) return -1;
    if(G1->Dx > G2->Dx) return  1;

    if(G1->Dy < G2->Dy) return -1;
    if(G1->Dy > G2->Dy) return  1;

    if(G1->SliceNumber < G2->SliceNumber) return -1;
    if(G1->SliceNumber > G2->SliceNumber) return  1;

    if(G1->ndimStamp < G2->ndimStamp) return -1;
    if(G1->ndimStamp > G2->ndimStamp) return  1;

    return 0;
}

ErrorType UDICOMData::AnalyzeDicomFiles(bool Nologging)
/*
    Analyze the files in the directory DicomDir and determine the
    first and last file of each scan. This is done by analyzing the
    pixel size, file number, z-coordinate, gantry tilt, etc. All these
    data of subsequent files should be consistent in order to belong to
    one scan.

    if(Nologging==false) Export cause of slice inconsistency to log file.
 */
{
    if(DicomDir.GetStatus()!=UDirectory::U_EXIST)
    {
        CI.AddToLog("ERROR : UDICOMData::AnalyzeDicomFiles(). Directory %s does not exist\n", DicomDir.GetDirectoryName());
        return U_ERROR;
    }

/* Make module re-entrant*/
    delete[] FileNames;
    delete[] GInfo;

/* Read all files from dicom directory and order alfabetically*/
    UFileName* UnOrderedFiles = DicomDir.GetAllFileNames("*",&Nfiles);
    GInfo                     = new GeomInfo[Nfiles];
    FileNames                 = new UFileName[Nfiles];
    if(Nfiles==0 || UnOrderedFiles==NULL || FileNames==NULL || GInfo==NULL)
    {
        if(Nfiles==0)
        {
            CI.AddToLog("ERROR : UDICOMData::AnalyzeDicomFiles(). No files found in %s\n", DicomDir.GetDirectoryName());
        }
        else
        {
            CI.AddToLog("ERROR : UDICOMData::AnalyzeDicomFiles(). Memory allocation. Nfiles = %d .\n",Nfiles);
        }
        delete[] UnOrderedFiles;
        delete[] FileNames;      FileNames      = NULL;
        delete[] GInfo;          GInfo          = NULL;
        return U_ERROR;
    }

    delete[] BeginScan;  BeginScan = new int[Nfiles];
    delete[] EndScan;    EndScan   = new int[Nfiles];
    if(BeginScan==NULL || EndScan==NULL)
    {
        delete[] BeginScan;      BeginScan      = NULL;
        delete[] EndScan;        EndScan        = NULL;
        delete[] UnOrderedFiles;
        delete[] FileNames;      FileNames      = NULL;
        delete[] GInfo;          GInfo          = NULL;
        CI.AddToLog("ERROR : UDICOMData::AnalyzeDicomFiles(). Memory allocation.\n");
        return U_ERROR;
    }

/* Get the geometrical information of all slices.*/
    for(int ifile=0; ifile<Nfiles; ifile++)
    {

/* Set defaults*/
        GInfo[ifile].Gtilt        = 0.;
        GInfo[ifile].Dx           = 0.;
        GInfo[ifile].Dy           = 0.;
        GInfo[ifile].ndimx        = 0;
        GInfo[ifile].ndimy        = 0;
        GInfo[ifile].nslices      = 0;
        GInfo[ifile].ndimStamp    = 0;
        GInfo[ifile].SliceNumber  = 0;
        GInfo[ifile].SlicePos     = 0.;
        GInfo[ifile].Ori          = U_ORI_UNKNOWN;
        GInfo[ifile].ScanTilted   = false;
        GInfo[ifile].FirstX       = 0.;
        GInfo[ifile].FirstY       = 0.;
        GInfo[ifile].FirstZ       = 0.;
        GInfo[ifile].Mod          = U_MOD_UNKNOWN;
        GInfo[ifile].GE           = U_ERR_NO;
        GInfo[ifile].FileIndex    = ifile;
        GInfo[ifile].RelSubDir[0] = 0;
        UFileName FileName        = UnOrderedFiles[ifile];

        UDirectory RelDir = FileName.GetRelDir(&DicomDir);
        strncpy(GInfo[ifile].RelSubDir, RelDir.GetDirectoryName(), sizeof(GInfo[ifile].RelSubDir));

        if(                                                              GetGantryTilt(FileName, &(GInfo[ifile].Gtilt))!=U_OK)                                                   GInfo[ifile].GE = U_ERR_GANTRY;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetPixelSize(FileName, &(GInfo[ifile].Dx),&(GInfo[ifile].Dy)) !=U_OK)                                   GInfo[ifile].GE = U_ERR_PIXEL;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetDimensions(FileName,&(GInfo[ifile].ndimx),&(GInfo[ifile].ndimy)) !=U_OK)                             GInfo[ifile].GE = U_ERR_NDIM;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetSliceNumber(FileName, &(GInfo[ifile].SliceNumber)) !=U_OK)                                           GInfo[ifile].GE = U_ERR_SLICENUMBER;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetOrientation(FileName, &(GInfo[ifile].Ori), &(GInfo[ifile].ScanTilted)) !=U_OK)                       GInfo[ifile].GE = U_ERR_ORIENTATION;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetSlicePosition(FileName, &(GInfo[ifile].SlicePos), ifile, GInfo[ifile].Ori) !=U_OK)                   GInfo[ifile].GE = U_ERR_SLICEPOS;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetFirstPixel(FileName, &(GInfo[ifile].FirstX), &(GInfo[ifile].FirstY), &(GInfo[ifile].FirstZ))!= U_OK) GInfo[ifile].GE = U_ERR_FIRSTPIX;
        if((GInfo[ifile].GE==U_ERR_NO||GInfo[ifile].GE==U_ERR_GANTRY) && GetNdimStamp(FileName, &(GInfo[ifile].ndimStamp)) !=U_OK)                                               GInfo[ifile].ndimStamp = 0;
        if( GInfo[ifile].GE!=U_ERR_NO&&GInfo[ifile].GE!=U_ERR_GANTRY  && Nologging==false)
            CI.AddToLog("WARNING : UDICOMData::AnalyzeDicomFiles(). Skip file %s, ERROR=%s. \n",FileName.GetFullFileName(), GeomErrorText[GInfo[ifile].GE]);
        GetScanMod(FileName, &(GInfo[ifile].Mod));    // Skip error test


        if(GInfo[ifile].GE==U_ERR_GANTRY) GInfo[ifile].GE=U_ERR_NO;
    }

/* sort file names and geom info*/
    qsort(GInfo, Nfiles, sizeof(GeomInfo), GeomOrder);
    bool Mixed = true;
    for(int n=0; n<Nfiles/2; n++)
        if(GInfo[2*n].SliceNumber!=GInfo[2*n+1].SliceNumber) {Mixed=false; break;}
    if(Mixed)
    {
        GeomInfo*  Gdum = new GeomInfo[Nfiles/2];
        if(Gdum)
        {
            for(int n=0; n<Nfiles/2; n++) Gdum [         n] = GInfo[2*n+1];
            for(int n=0; n<Nfiles/2; n++) GInfo[         n] = GInfo[2*n  ];
            for(int n=0; n<Nfiles/2; n++) GInfo[Nfiles/2+n] = Gdum [  n  ];
            delete[] Gdum;
            CI.AddToLog("Note:UDICOMData::AnalyzeDicomFiles(). Unmixing slices \n");
        }
    }
    for(int ifile=0; ifile<Nfiles; ifile++)
        FileNames[ifile] = UnOrderedFiles[GInfo[ifile].FileIndex];
    delete[] UnOrderedFiles;

/* Determine 'jumps' in scan geometry*/
    int first = 0;
    int last  = Nfiles-1;
    Nscans    = 0;

    while(first<Nfiles)
    {
        if(GInfo[first].GE != U_ERR_NO)
        {
            first++;  // Skip isolated erroneous first slice
            continue;
        }

/* Check consistency of the slices. Determine the last slice which is consistent */

        double ds1  = 0;
        double yold = GInfo[first].SlicePos;
        for(int i=first+1; i<=last && i-first<MAX_SLICES; i++)
        {
            GeomInfo  GInfo2 = GInfo[i];
            GeomErrorType GE = GInfo2.GE;

            double ds2 = yold-GInfo2.SlicePos;
            if(i==first+1) ds1  = GInfo[first].SlicePos-GInfo2.SlicePos;
            else           yold = GInfo[i].SlicePos;

            if(GE==U_ERR_SLICEPOS || ds1*ds2<1.e-5)
            {
                if(Nologging==false)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has incontigeous slice coordinate, (ds1,ds2) = (%f, %f). \n", ds1, ds2);
            }
            else
            {
                if(i-first ==GInfo[i].SliceNumber-GInfo[first].SliceNumber)
                {
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Slice numbers not contigeous. \n");
                }
                if(GE==U_ERR_NO &&
                   GInfo[first].Gtilt==GInfo[i].Gtilt &&
                   GInfo[first].Dx   ==GInfo[i].Dx    &&
                   GInfo[first].Dy   ==GInfo[i].Dy    &&
                   GInfo[first].ndimx==GInfo[i].ndimx &&
                   GInfo[first].ndimy==GInfo[i].ndimy &&
                   GInfo[first].Ori  ==GInfo[i].Ori)  continue;
            }
            if(Nologging==false)
            {
                if(GE==U_ERR_UNKNOWN)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Unknow reading Error. \n");

                if(GInfo[first].Gtilt!=GInfo[i].Gtilt)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has different gantry tilt. \n");

                if(GE==U_ERR_PIXEL || GInfo[first].Dx!=GInfo[i].Dx || GInfo[first].Dy!=GInfo[i].Dy)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has deviating pixel size. \n");

                if(GE==U_ERR_NDIM || GInfo[first].ndimx!=GInfo[i].ndimx || GInfo[first].ndimy!=GInfo[i].ndimy)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has deviating image dimensions. \n");

                if(GE==U_ERR_SLICENUMBER || i-first !=GInfo[i].SliceNumber-GInfo[first].SliceNumber)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has incontigeous slice number (i=%d, first=%d). \n", GInfo[i].SliceNumber, GInfo[first].SliceNumber);

                if(GInfo[first].Ori!=GInfo[i].Ori)
                    CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Next slice has different scan orientation. \n");
            }
            last = i-1;
            break;
        }

        if(Nologging==false)
            CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : Scannum = %d; Orientation = %d; Numslices = %d \n", Nscans, Orientation, last-first);

        BeginScan[Nscans]  = first;
        EndScan[Nscans]    = last;
        Nscans            += 1;
        first              = last+1;
        last               = Nfiles-1;
    }

    for(int is=0; is<Nscans; is++)
    {
        int nslices = EndScan[is] - BeginScan[is] + 1;
        for(int ifile=BeginScan[is]; ifile<=EndScan[is]; ifile++)
            GInfo[ifile].nslices = nslices;

        if(nslices<=1)
        {
            GInfo[BeginScan[is]].SliceOrder = U_SLI_UNKNOWN;
            if(GInfo[BeginScan[is]].Mod==U_MOD_MR) GInfo[BeginScan[is]].Mod=U_MOD_fMRI;
            continue;
        }
        switch(GInfo[BeginScan[is]].Ori)
        {
        case U_ORI_AXIAL:
            for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices/2; ifile++)
            {
                int       efile = BeginScan[is]+nslices-1-(ifile-BeginScan[is]);
                GeomInfo  G     = GInfo[ifile];
                GInfo[ifile]    = GInfo[efile];
                GInfo[efile]    = G;
            }
            if(GInfo[BeginScan[is]].FirstZ > GInfo[EndScan[is]].FirstZ) // Force Top->Bottom
            { // Try this on 30-3-13
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_TB;
            }
            else
            {
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_BT;
            }
            break;

        case U_ORI_SAGITAL:
            if(GInfo[BeginScan[is]].FirstX > GInfo[EndScan[is]].FirstX) // Force Right->Left
            {
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices/2; ifile++)
                {
                    int       efile = BeginScan[is]+nslices-1-(ifile-BeginScan[is]);
                    GeomInfo  G     = GInfo[ifile];
                    GInfo[ifile]    = GInfo[efile];
                    GInfo[efile]    = G;
                }
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_RL;
            }
            else
            {
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_LR;
            }
            break;

        case U_ORI_CORONAL:
            if(GInfo[BeginScan[is]].FirstY < GInfo[EndScan[is]].FirstY) // Force Back->Front
            {
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices/2; ifile++)
                {
                    int       efile = BeginScan[is]+nslices-1-(ifile-BeginScan[is]);
                    GeomInfo  G     = GInfo[ifile];
                    GInfo[ifile]    = GInfo[efile];
                    GInfo[efile]    = G;
                }
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_PF;
            }
            else
            {
                for(int ifile=BeginScan[is]; ifile<BeginScan[is]+nslices; ifile++) GInfo[ifile].SliceOrder = U_SLI_FP;
            }
            break;
        }
        if(Nscans>10 && GInfo[BeginScan[is]].Mod==U_MOD_MR) GInfo[BeginScan[is]].Mod=U_MOD_fMRI;
    }
    if(Nologging==false)
        CI.AddToLog("Note : UDICOMData::AnalyzeDicomFiles() : There are %d consistent scans. \n", Nscans);

    return U_OK;
}

ErrorType UDICOMData::GetSliceNumber(UFileName FileName, int *Slinum)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    if(ACRNEMA_header(FileName,GRP_SLINUM,ITM_SLINUM,1,temp,NULL)<0 || strlen(temp)==0) return U_ERROR;

    *Slinum = atoi(temp);
    return U_OK;
}

ErrorType UDICOMData::GetGantryTilt(UFileName FileName, double *Gtilt)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName,GRP_GTILT,ITM_GTILT,1,temp,NULL)<0) return U_ERROR;
    if(strlen(temp)==0)
    {
        *Gtilt = 0;
        return U_OK;
    }

    *Gtilt = atof(temp);
    return U_OK;
}

ErrorType UDICOMData::GetOrientation(UFileName FileName, OrientType* OT, bool* Tilted)
/*
     Read the scan orientation *OT from FileName[].
 */
{
    if(OT==NULL) return U_ERROR;

    char temp[256];
    memset(temp, 0, sizeof(temp));

    if(ACRNEMA_header(FileName,GRP_SCANORI,ITM_SCANORI,1,temp,NULL)<0) return U_ERROR;

    if(strlen(temp)==0)
    {
        *OT = U_ORI_UNKNOWN;
        return U_OK;
    }

    double coor[6] = {0.,0.,0.,0.,0.,0.};
    char* Sep=temp;
    for(int k=0; k<6; k++)
    {
        if(Sep) 
        {
            if(k>0) Sep++;
            coor[k]=atof(Sep);
        }
        else
        {
            coor[k]= 0.;
            continue;
        }
        Sep = strstr(Sep,"\\");
    }
    UVector3 Row(coor+0);  // x = R->L,  y = F->B and z = B->T
    UVector3 Col(coor+3);
    UVector3 Normal = Row^Col;
    double X = fabs(Normal.Getx());
    double Y = fabs(Normal.Gety());
    double Z = fabs(Normal.Getz());
    if(X>Y+Z)
    {
        *OT = U_ORI_SAGITAL;
    }
    else if(Y>Z+X)
    {
        *OT = U_ORI_CORONAL;
    }
    else if(Z>X+Y)
    {
        *OT = U_ORI_AXIAL;
    }
    else
    {
        *OT = U_ORI_UNKNOWN;
    }
    if(Tilted)
    {
        *Tilted = false;
        for(int k=0; k<6; k++)
            if(fabs(coor[k])>1.e-4 && fabs(fabs(coor[k])-1)>1.e-4)
            {
                *Tilted = true;
                break;
            }
    }
    return U_OK;
}

ErrorType UDICOMData::GetFirstPixel(UFileName FileName, double*X, double*Y, double*Z)
/*
     Read the coordinates of the first pixel (ToLeft, ToBack, ToTop)
 */
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    if(ACRNEMA_header(FileName,GRP_SCANFIRSTPIX,ITM_SCANFIRSTPIX,1,temp,NULL)<0) return U_ERROR;

    if(strlen(temp)==0)
    {
        if(X) *X=0.;
        if(Y) *Y=0.;
        if(Z) *Z=0.;
        return U_OK;
    }

    double coor[3] = {0.,0.,0.};
    char* Sep=temp;
    for(int k=0; k<3; k++)
    {
        if(!Sep) break;
        coor[k] = atof(Sep);
        Sep     = strstr(Sep,"\\");
        if(Sep) Sep += 1;
    }
    if(X) *X = coor[0]/10.;
    if(Y) *Y = coor[1]/10.;
    if(Z) *Z = coor[2]/10.;

    return U_OK;
}

int UDICOMData::GetRefFrameInstanceUID(UFileName FileName, char* SID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_REFFRAME_INSTANCE_UID,ITM_REFFRAME_INSTANCE_UID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetSeriesInstanceUID(UFileName FileName, char* SID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_SERIES_INSTANCE_UID,ITM_SERIES_INSTANCE_UID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetStudyInstanceUID(UFileName FileName, char* SID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_STUDY_INSTANCE_UID,ITM_STUDY_INSTANCE_UID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetStudyUID(UFileName FileName, char* SID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_STUDY_UID,ITM_STUDY_UID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetSOPInstanceUID(UFileName FileName, char* SID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_SOP_INSTANCE_UID,ITM_SOP_INSTANCE_UID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetSeriesDescription(UFileName FileName, char* SerDescr)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_SERDESCR,ITM_SERDESCR,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(SerDescr, temp, sizeof(temp));
    return offset;
}
int UDICOMData::GetPatName(UFileName FileName, char* PatName)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_NAME,ITM_NAME,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(PatName, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetPatID(UFileName FileName, char* PatID)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_PATID,ITM_PATID,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    memcpy(PatID, temp, sizeof(temp));
    return offset;
}

int UDICOMData::GetScanMod(UFileName FileName, ModalityType* Mod, char* ModText)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int offset = ACRNEMA_header(FileName,GRP_SCANMO,ITM_SCANMO,1,temp,NULL);
    if(offset<0 || strlen(temp)==0) return -1;

    if(ModText) memcpy(ModText, temp, sizeof(temp));
    if(Mod)     *Mod = GetModalityType(temp);
    return offset;
}

ErrorType UDICOMData::GetSlicePosition(UFileName FileName, double* slipos, int firstslice, OrientType Ori)
/*
     Read the slice position present in FileName and store the result in *slipos.

     Since in some Dicom variants, the slice position is not present in the file,
     the slice position is derived from the slice distance parameter. In these
     cases the routine counts the file number and the user has to give the starting point.
     if(firstslice==0) the routine (re)starts counting.
 */
{
    static int islice = 0;
    if(firstslice==0) islice=0;

    char temp[256];
    memset(temp, 0, sizeof(temp));

    int status = ACRNEMA_header(FileName, GRP_SLIPOS, ITM_SLIPOS, 1, temp, NULL);
    if(status>=0 && strlen(temp)>0)
    {
        *slipos = atof(temp)/10.0;
        islice++;
        return U_OK;
    }
    memset(temp, 0, sizeof(temp));
    if(Ori==U_ORI_SAGITAL || Ori==U_ORI_AXIAL || Ori==U_ORI_CORONAL)
    {
        status = ACRNEMA_header(FileName, GRP_SCANFIRSTPIX, ITM_SCANFIRSTPIX, 1, temp, NULL);
        if(status>=0 && strlen(temp)>0)
        {
            double coor[3] = {0.,0.,0.};
            char* Sep=temp;
            for(int k=0; k<3; k++)
            {
                if(Sep) 
                {
                    if(k>0) Sep++;
                    coor[k]=atof(Sep)/10.;
                }
                else
                {
                    coor[k]= 0.;
                    continue;
                }
                Sep = strstr(Sep,"\\");
            }
            if(Ori==U_ORI_SAGITAL) *slipos = coor[0];
            if(Ori==U_ORI_CORONAL) *slipos = coor[1];
            if(Ori==U_ORI_AXIAL  ) *slipos = coor[2];
        }
        islice++;
        return U_OK;
    }
    memset(temp, 0, sizeof(temp));
        
    status = ACRNEMA_header(FileName, GRP_SLIPOS2, ITM_SLIPOS2, 1, temp, NULL);
    if(status>=1 || strlen(temp)>0)
    {
        *slipos = atof(temp)/10.0;
        islice++;
        return U_OK;
    }
    memset(temp, 0, sizeof(temp));

    double slidist = 0;
    if(GetSliceDistance(FileName, &slidist)!=U_OK) return U_ERROR;
    *slipos = islice* slidist;
    islice++;
    return U_OK;
}

ErrorType UDICOMData::GetSliceDistance(UFileName FileName, double* slidist)
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    int status = ACRNEMA_header(FileName, GRP_SLISPAC, ITM_SLISPAC, 1, temp, NULL);
    if(status<0 || strlen(temp)==0) return U_ERROR;

    *slidist = atof(temp)/10.0;
    return U_OK;
}

ErrorType UDICOMData::GetPixelSize(UFileName FileName, double*dx, double*dy)
/*
     Get the pixel size in the x- and y- direction of the scan slice present in FileName[].
 */
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    if(ACRNEMA_header(FileName,GRP_PIXSIZ,ITM_PIXSIZ,1,temp,NULL)<0 || strlen(temp)==0)
    {
        if(ACRNEMA_header(FileName,GRP_FOV,ITM_FOV,1,temp,NULL)<0 || strlen(temp)==0)
            return U_ERROR;

        double FOV = atof(temp)/10.0;
        int dimx = 0;
        int dimy = 0;
        if(GetDimensions(FileName, &dimx, &dimy)!=U_OK) return U_ERROR;

        *dx = FOV/dimx;
        *dy = FOV/dimy;
        return U_OK;
    }
    *dx = atof(temp)/10.0;
    *dy = *dx;
    char*  c  = strchr(temp, '\\');
    if(c) *dy = (atof(c+1)/10.0);
    return U_OK;
}

ErrorType  UDICOMData::GetDimensions(UFileName FileName, int* dimx, int* dimy)
/*
     Get the number of pixels in the x- and y- direction of the scan slice present in FileName[].
 */
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    if(ACRNEMA_header(FileName, GRP_XDIM, ITM_XDIM, 1, temp, NULL)<0 || strlen(temp)==0) return U_ERROR;
    *dimx = atoi(temp);

    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_YDIM, ITM_YDIM, 1, temp, NULL)<0 || strlen(temp)==0) return U_ERROR;
    *dimy = atoi(temp);

    return U_OK;
}

ErrorType UDICOMData::GetNdimStamp(UFileName FileName, int *ndimStamp)
/*
     Get the true number of pixels in the x- and y- direction of the scan slice present in FileName[],
     assuming the data was exported in stamp format.
 */
{
    char temp[256];
    memset(temp, 0, sizeof(temp));

    *ndimStamp = 0;
    if(ACRNEMA_header(FileName, GRP_ACQMAT, ITM_ACQMAT, 1, temp, NULL)<0 || strlen(temp)==0) return U_ERROR;
    *ndimStamp = atoi(temp);

    return U_OK;
}


ErrorType UDICOMData::GetPixelInfo(UFileName FileName, PixelInfo* PInfo)
/*
    Get the information about the number and location of pixels.
 */
{
    if(PInfo==NULL) return U_ERROR;

    char temp[256];
    memset(temp, 0, sizeof(temp));

    PInfo->offset  = ACRNEMA_header(FileName, GRP_PIXEL, ITM_PIXEL, 0, temp, &(PInfo->PixelDataLen));
    PInfo->FileCompressMode = 0;

    if(PInfo->offset<0) return U_ERROR;

/* try find NKI private compressed pixel data */
    if(!strcmp(temp, "**(data not loaded)"))
    {
        PInfo->offset = ACRNEMA_header(FileName, GRP_PIXEL_NKI, ITM_PIXEL_NKI, 0, temp, &(PInfo->PixelDataLen));
        PInfo->FileCompressMode = 1;

        if(PInfo->offset<0) return U_ERROR;
        if(strcmp(temp, "**(data not loaded)")!=0) return U_ERROR;
    }
    return U_OK;
}

ErrorType UDICOMData::GetMRInfo(UFileName FileName, MRInfo* MInfo)
{
    if(MInfo==NULL) return U_ERROR;
    if(DoesFileExist(FileName)==false) return U_ERROR;

    memset(MInfo, 0, sizeof(MRInfo));

    char temp[256];

    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_IMTYPE, ITM_IMTYPE, 1, temp, NULL)<0)
    {
        sprintf(MInfo->ImageType,"Unknown");
    }
    else
    {
        strncpy(MInfo->ImageType, temp, sizeof(MInfo->ImageType)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_IMTIME, ITM_IMTIME, 1, temp, NULL)<0)
    {
        sprintf(MInfo->ImageTime,"Unknown");
    }
    else
    {
        strncpy(MInfo->ImageTime, temp, sizeof(MInfo->ImageTime)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_IMSEQ, ITM_IMSEQ, 1, temp, NULL)<0)
    {
        sprintf(MInfo->Sequence,"Unknown");
    }
    else
    {
        strncpy(MInfo->Sequence, temp, sizeof(MInfo->Sequence)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_SEQNAM, ITM_SEQNAM, 1, temp, NULL)<0)
    {
        sprintf(MInfo->SeqName,"Unknown");
    }
    else
    {
        strncpy(MInfo->SeqName, temp, sizeof(MInfo->SeqName)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_FIELD, ITM_FIELD, 1, temp, NULL)<0)
    {
        sprintf(MInfo->FieldStr,"Unknown");
    }
    else
    {
        strncpy(MInfo->FieldStr, temp, sizeof(MInfo->FieldStr)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_ECHOTIME, ITM_ECHOTIME, 1, temp, NULL)<0)
    {
        sprintf(MInfo->EchoTime,"Unknown");
    }
    else
    {
        strncpy(MInfo->EchoTime, temp, sizeof(MInfo->EchoTime)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_INVTIME, ITM_INVTIME, 1, temp, NULL)<0)
    {
        sprintf(MInfo->InvTime,"Unknown");
    }
    else
    {
        strncpy(MInfo->InvTime, temp, sizeof(MInfo->InvTime)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_REPTIME, ITM_REPTIME, 1, temp, NULL)<0)
    {
        sprintf(MInfo->RepTime,"Unknown");
    }
    else
    {
        strncpy(MInfo->RepTime, temp, sizeof(MInfo->RepTime)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_FLIPA, ITM_FLIPA, 1, temp, NULL)<0)
    {
        sprintf(MInfo->FlipAngle,"Unknown");
    }
    else
    {
        strncpy(MInfo->FlipAngle, temp, sizeof(MInfo->FlipAngle)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_NUMAV, ITM_NUMAV, 1, temp, NULL)<0)
    {
        sprintf(MInfo->NumAver,"Unknown");
    }
    else
    {
        strncpy(MInfo->NumAver, temp, sizeof(MInfo->NumAver)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_ACQMAT, ITM_ACQMAT, 1, temp, NULL)<0)
    {
        sprintf(MInfo->AcqMat,"Unknown");
    }
    else
    {
        strncpy(MInfo->AcqMat, temp, sizeof(MInfo->AcqMat)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_TEMPPOS, ITM_TEMPPOS, 1, temp, NULL)<0)
    {
        sprintf(MInfo->TempPos,"Unknown");
    }
    else
    {
        strncpy(MInfo->TempPos, temp, sizeof(MInfo->TempPos)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_NUMTEMP, ITM_NUMTEMP, 1, temp, NULL)<0)
    {
        sprintf(MInfo->NumTempPos,"Unknown");
    }
    else
    {
        strncpy(MInfo->NumTempPos, temp, sizeof(MInfo->NumTempPos)-1);
    }
    memset(temp, 0, sizeof(temp));
    if(ACRNEMA_header(FileName, GRP_TEMPRES, ITM_TEMPRES, 1, temp, NULL)<0)
    {
        sprintf(MInfo->TempRes,"Unknown");
    }
    else
    {
        strncpy(MInfo->TempRes, temp, sizeof(MInfo->TempRes)-1);
    }
    return U_OK;
}

UField* UDICOMData::GetSliceAsField(UFileName FileName, int* OffSet)
/*
     read data from file FileName[] and store the result in a 2D *UField, whivh is returned as
     new pointer.

     on output: *OffSet will contain the offset in the file, where the pixel information can be found.

     On error NULL will be returned.
 */
{
    PixelInfo PInfo;
    if(GetPixelInfo(FileName, &PInfo) != U_OK)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(). Getting pixel information from %s \n",FileName.GetFullFileName());
        return NULL;
    }
    if(PInfo.FileCompressMode!=0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(). Compressed data not supported. \n");
        return NULL;
    }
    if(OffSet) *OffSet = PInfo.offset;

    double Dx = 0;
    double Dy = 0;
    if(GetPixelSize(FileName, &Dx, &Dy) !=U_OK)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(). Getting pixelsize information from %s \n",FileName.GetFullFileName());
        return NULL;
    }
    int dimx=0;
    int dimy=0;
    if(GetDimensions(FileName, &dimx, &dimy)!=U_OK || dimx<=0 || dimy<=0)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(). Getting dimensions information from %s \n",FileName.GetFullFileName());
        return NULL;
    }

    int BytesPerPixel = PInfo.PixelDataLen / (dimx*dimy);

    if(BytesPerPixel<=0 || BytesPerPixel > 3)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(). File contains other that byte, short or color information.\n");
        return NULL;
    }
    if(BytesPerPixel==3)
    {
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(): 3-vector color data not supprted.\n");
        return NULL;
    }

/* create output field*/
    UVector2 Min(-Dx*dimx/2, -Dy*dimy/2);
    UVector2 Max = Min + UVector2(Dx*(dimx-1), Dy*(dimy-1));  // dimy-2?? JdM 14-05-07
    int Dims[2]  = {dimx, dimy};

    UField::DataType     DT = UField::U_BYTE;
    if(BytesPerPixel==2) DT = UField::U_SHORT;

    UField* F2 = new UField(Min, Max, Dims, DT);
    if(F2==NULL || F2->GetError()!=U_OK)
    {
        delete F2;
        CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(): Creating output UField.\n");
        return NULL;
    }

/* Copy data into field*/
    if(DT==UField::U_BYTE)
    {
        if(GetPixels(FileName, &PInfo, F2->GetBdata())!=U_OK)
        {
            delete F2;
            CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(): Getting pixel data (bytes).\n");
            return NULL;
        }
    }
    else
    {
        if(GetPixels(FileName, &PInfo, (unsigned char*)F2->GetSdata())!=U_OK)
        {
            delete F2;
            CI.AddToLog("ERROR: UDICOMData::GetSliceAsField(): Getting pixel data (short).\n");
            return NULL;
        }
        if(swap==1) SwapArray(F2->GetSdata(), dimx*dimy, false);
    }
    return F2;
}

ErrorType UDICOMData::GetPixels(UFileName FileName, PixelInfo* PInfo, unsigned char* buffer) const
/*
     read the pixels from file FileName[] and store the result in buffer[] (which should be allocated
     in the calling function).
     Adapt PInfo->PixelDataLen in case of Compressed data, such that the number of bytes
     per pixel can be computed in a standard way.

 */
{
    FILE* fp = fopen(FileName, "rb",false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UDICOMData::GetPixels(). Opening file %f \n", FileName.GetFullFileName());
        return U_ERROR;
    }
    if(buffer==NULL)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UDICOMData::GetPixels(). Invalid NULL argument. Buffer==NULL.\n");
        return U_ERROR;
    }
    ErrorType Result = U_ERROR;
    if(PInfo->FileCompressMode==0)
    {
        fseek(fp, PInfo->offset, SEEK_SET);
        fread(buffer, 1, PInfo->PixelDataLen, fp);
        Result = U_OK;
    }
    else if(PInfo->FileCompressMode==1)
    {
        signed char *CompressedData = new signed char[PInfo->PixelDataLen];
        if(CompressedData==NULL)
        {
            fclose(fp);
            return Result;
        }

        fseek(fp, PInfo->offset, SEEK_SET);
        fread(buffer, 1, PInfo->PixelDataLen, fp);

        PInfo->PixelDataLen = 2*nki_private_decompress((short int *)buffer, CompressedData);
        delete[] CompressedData;
        Result = U_OK;
    }

    fclose(fp);
    return Result;
}

void UDICOMData::ChangeUID(char* UID, int number)
{
    number = 100000+11111*number; // change at least five digits
    if(number<=0) number = -number;

    int      Ndig    = (int) ceil( log10((double) number) );
    size_t   len     = strlen(UID);
    int      Ndone   = 0;
    unsigned int p10 = 1;
    for(int k=0; k<len-1; k++)
    {
        if(UID[k]<'0' || UID[k]>'9') continue;
        UID[k] = '0' + ((UID[k]-'0' + number/p10)%10);
        Ndone++;
        p10 *= 10;
        if(Ndone>=Ndig) return;
    }
}

ErrorType UDICOMData::swapxy(void* buffer, int size, int nx, int ny) const
{
    char* temp = new char[size*nx*ny];
    if(temp==NULL)
    {
        CI.AddToLog("ERROR: UDICOMData::swapxy(). Memory allocation, nbytes = %d \n",size*nx*ny);
        return U_ERROR;
    }

    memcpy(temp, buffer, size*nx*ny);

    switch(size)
    {
    case 1:
        {
            char* cp = (char*) buffer;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *cp++ = temp[iy*nx+ix];
            break;
        }
    case 2:
        {
            short* sp     = (short*) buffer;
            short* sptemp = (short*) temp;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *sp++ = sptemp[iy*nx+ix];
            break;
        }
    case 4:
        {
            int* ip     = (int*) buffer;
            int* iptemp = (int*) temp;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++) *ip++ = iptemp[iy*nx+ix];
            break;
        }
    default:
        {
            char* cp = (char*)buffer;
            for(int ix=0; ix<nx; ix++)
                for(int iy=0; iy<ny; iy++)
                    for(int k=0; k<size; k++) *cp++ = temp[(iy*nx+ix)*size+k];
            break;
        }
    }
    delete[] temp;
    return U_OK;
}


ErrorType UField::StampUnpack(int ndimStamp, double slicethickness, bool RemoveZeroSlices)
/*
    Convert a single slice of slices (stamps) into a full 3D  volume. This unpacking is
    required for fMRI DICOM data.
 */
{
    if(veclen        != 1 ||
       ndim          != 3 ||
       nspace        != 3 ||
       dimensions[1] != 1 ||
       dimensions[0] != dimensions[2])
    {
        CI.AddToLog("ERROR: UField::StampUnpack(), Incompatible field-type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(ndimStamp<=0 || ndimStamp>=dimensions[0] || ndimStamp>=dimensions[2])
    {
        CI.AddToLog("ERROR: UField::StampUnpack(). Erroneous arguments, ndimStamp = %d \n",ndimStamp);
        return U_ERROR;
    }
    if(dimensions[0]%ndimStamp)
    {
        CI.AddToLog("ERROR: UField::StampUnpack(). ndimStamp = %d does not fit field dimensions %d \n",ndimStamp,dimensions[0]);
        return U_ERROR;
    }
    if(slicethickness<=0)
    {
        CI.AddToLog("ERROR: UField::StampUnpack(). Erroneous arguments, slicethickness = %f \n",slicethickness);
        return U_ERROR;
    }
    if(DType!=U_SHORT)
    {
        CI.AddToLog("ERROR: UField::StampUnpack(). Data type not (yet) supported (DType=%d). \n",DType);
        return U_ERROR;
    }

    int nshort = veclen*GetNpoints();
    short* sb = new short[nshort];

    if(sb==NULL)
    {
        CI.AddToLog("ERROR: UField::StampUnpack(). Memory allocation. nshort = %d \n", nshort);
        return U_ERROR;
    }
    int ratio     = dimensions[0]/ndimStamp;
    int nslicemax = ratio*ratio;
    short* psb    = sb;
    for(int z=0;z<ndimStamp; z++)
    {
        for(int y=nslicemax-1; y>=0; y--)
        {
            int y2 = y%ratio;
            int y1 = y/ratio;
            for(int x=0;x<ndimStamp; x++)
            {
                *psb++ = Sdata[(y2*ndimStamp+z)*dimensions[0]+y1*ndimStamp+x];
            }
        }
    }
    delete[] Sdata;
    Sdata     = sb;

    double dx = GetPixelSize(0);
    double dy = slicethickness;
    double dz = GetPixelSize(2);

    delete[] points; points = new float[6];
    points[0] = float(           - dx* ndimStamp/2 );
    points[1] = float( points[0] + dx*(ndimStamp-1));
    points[2] = float(           - dy* ndimStamp/2 );
    points[3] = float( points[2] + dy*(ndimStamp-1));
    points[4] = float(           - dz* ndimStamp/2 );
    points[5] = float( points[4] + dz*(ndimStamp-1));

    dimensions[0] = ndimStamp;
    dimensions[1] = nslicemax;
    dimensions[2] = ndimStamp;

    FType     = U_UNIFORM;

    if(RemoveZeroSlices)
    {
        int ndimStamp2 = ndimStamp*nslicemax;
        int skipfirst  = 0;
        for(int y=0; y<nslicemax; y++)
        {
            bool Skip = true;
            for(int x=0; x<ndimStamp; x++)
                for(int z=0; z<ndimStamp; z++)
                    if(sb[z*ndimStamp2+y*ndimStamp+x])
                        {Skip=false; break;}
            if(Skip==false) break;
            skipfirst++;
        }
        int skiplast   = 0;
        for(int y=nslicemax-1; y>=skipfirst+1; y--)
        {
            bool Skip = true;
            for(int x=0; x<ndimStamp; x++)
                for(int z=0; z<ndimStamp; z++)
                    if(sb[z*ndimStamp2+y*ndimStamp+x])
                    {Skip=false; break;}
            if(Skip==false)
                break;
            skiplast++;
        }
        CropSlices(skipfirst, skiplast);
        points[2] = float(           - dy* dimensions[1]/2 );
        points[3] = float( points[2] + dy*(dimensions[1]-1));

    }
    return U_OK;
}
