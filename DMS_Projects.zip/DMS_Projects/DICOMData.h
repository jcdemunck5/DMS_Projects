#ifndef _DICOMDATA_INCLUDED
#define _DICOMDATA_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "DateTime.h"
#include "Field.h"
#include "Directory.h"
#include "DICOMFile.h"

#define MAX_DICOM_FILNAME   512  /* The maximum number of characters for a file name      */

class DLL_IO UDICOMData
{
public:
    enum GeomErrorType{U_ERR_NO,         // Possible errors in reading geometrical information
                       U_ERR_UNKNOWN,
                       U_ERR_GANTRY,
                       U_ERR_PIXEL,
                       U_ERR_NDIM,
                       U_ERR_SLICENUMBER,
                       U_ERR_SLICEPOS,
                       U_ERR_ORIENTATION,
                       U_ERR_FIRSTPIX,
                       U_ERR_NUMERRORS
                       };

    struct GeomInfo               // Geometrical information about the scan which should
    {                                     // be present in each DICOM file.
        double         Gtilt;              // gantry tilt
        double         Dx;                 // pixel size in x-direction 
        double         Dy;                 // pixel size in y-direction
        int            ndimx;              // number of pixels in x-direction
        int            ndimy;              // number of pixels in y-direction
        int            nslices;            // number of slices belonging to the same scan
        int            ndimStamp;          // True number of dimensions, in case of StampFormat
        int            SliceNumber;           
        double         SlicePos;
        SliceOrderType SliceOrder;
        OrientType     Ori;                // Scan orientation
        bool           ScanTilted;         // TRUE iff scan is tilted w.r.t. scanner (directions of collumn/rows not multiple of 90 deg)
        double         FirstX;             // x-coordinate of first pixel (x->Left)
        double         FirstY;             // y-coordinate of first pixel (y->Back)
        double         FirstZ;             // z-coordinate of first pixel (z->Top)
        ModalityType   Mod;                // Scan modality: MR, CT, PET
        GeomErrorType  GE;                 // Slice reading error
        int            FileIndex;          // Index used to re-order files names on geometrical info
        char           RelSubDir[256];     // Part of the path between given DICOM dir. and DICOM file
    };
    
    UDICOMData(UFileName F, bool Nologging=false);
    UDICOMData(const char* DicDirName, bool Nologging=false);
    ~UDICOMData();  

    ErrorType          GetError(void)  const {return error;}
    const UString&     GetProperties(UString Comment, int iscan);
    const char*        GetDirectoryName(void) const {return DicomDir.GetDirectoryName();}

    UField*            GetRawScan(int iscan);
    UField*            ReadSlices(int scannum, int numslices, int pixdown, int slicedown, bool centerY, bool ReverseSlices, bool WordOn, int pixmin, int pixmax, UField::DatConvertType DatCon);
    UField*            GetSliceAsField(UFileName FileName, int* OffSet);

    ErrorType          ExportDICOMslices(const UField* Scan, int scannum, UDirectory *DICOMout, int maskUIDref, int maskUIDser, int maskUIDsop, const char* PrefixName, const char* newPatID, const char* newDescription);
    ErrorType          ExportDICOMslices(UDirectory *DICOMout, int maskUIDref, int maskUIDser, int maskUIDsop, const char* PrefixName, const char* newPatID, int inMin, int inMax, int otMin, int otMax);

    UEuler             GetScanToWld(void) const;
    OrientType         GetOrientation(void) const {return Orientation;}
    ErrorType          SetScanOrientation(OrientType OT, int iscan);
    int                GetNscans(void) const {return Nscans;}
    const UString&     GetScanDescriptor(int iscan) const;
    GeomInfo           GetGeomInfo(int iscan) const;

    UFileName          GetBeginFile(int iscan) const;
    UFileName          GetFileName(int iscan, int islice) const;
    const char*        GetPatName(int iscan);
    const char*        GetPatID(int iscan);
    UDateTime          GetPatDOB(int iscan); 
    UDateTime          GetScanDate(int iscan); 
    double             GetScanTime(int iscan); 
    double             GetRepTime(int iscan); 

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    struct PixelInfo              // Information about the location of the pixels in the file
    {
        int        offset;                // start of image if bytes from beginning of file
        int        PixelDataLen;          // total size of pixel data in bytes
        int        FileCompressMode;      // 0: no compression, 1: NKI compressed
    };
    struct MRInfo                 // Information, specific for MR images
    {
        char ImageType[33];
        char ImageTime[33];
        char Sequence[33];
        char SeqName[33];
        char FieldStr[33];
        char EchoTime[33];
        char InvTime[33];
        char RepTime[33];
        char FlipAngle[33];
        char NumAver[33];
        char AcqMat[33];
        char TempPos[33];
        char NumTempPos[33];
        char TempRes[33];
    };

    ErrorType          error;       // General error flag
    static UString     Properties;
    static UString     ScanDescriptor;
    static UString     GeomErrorText[U_ERR_NUMERRORS];

    UDirectory         DicomDir;    // Directory of DICOM files to be examined
    UDICOMFile         DICFile;     // Object referring to the DICOM data structure of current file
    UFileName*         FileNames;   // List of all files in DicomDir
    int                Nfiles;      // Number of files in DicomDir
    GeomInfo*          GInfo;       // Array with geometrical information of all files
    int*               BeginScan;   // Array of entries, referring to the first file of a new scan.
    int*               EndScan;     // Array of entries, referring to the last file of a scan.
    int                Nscans;      // Number of DICOM scans in DicomDir
    
    OrientType         Orientation; // scan orientation of current set of files.

    ErrorType          AnalyzeDicomFiles(bool Nologging);
    int                Rdicheader_compute(char *out, char *filename, int group, int elem, int forcestring);
    int                ACRNEMA_header(UFileName F, int group, int element, int forcestring, char *result, int *len);
    int                nki_private_decompress(short int *dest, signed char *src) const;

    int                swap;

    ErrorType          GetPixels(UFileName FileName, PixelInfo* PInfo, unsigned char* buffer) const;
    ErrorType          GetPixelInfo(UFileName FileName, PixelInfo* PInfo);
    ErrorType          GetMRInfo(UFileName FileName, MRInfo* MInfo);
    ErrorType          GetGantryTilt(UFileName FileName, double *Gtilt);
    ErrorType          GetPixelSize(UFileName FileName, double*dx, double* dy);
    ErrorType          GetDimensions(UFileName FileName, int* dimx, int* dimy);
    ErrorType          GetNdimStamp(UFileName FileName, int *ndimStamp);
    ErrorType          GetSliceNumber(UFileName FileName, int *Slinum);
    ErrorType          GetSlicePosition(UFileName FileName, double* slipos, int firstslice, OrientType Ori);
    ErrorType          GetSliceDistance(UFileName FileName, double* slidist);
    ErrorType          GetOrientation(UFileName FileName, OrientType* OT, bool* Tilted);
    ErrorType          GetFirstPixel(UFileName FileName, double* X, double* Y, double* Z);
    int                GetRefFrameInstanceUID(UFileName FileName, char* SID);    
    int                GetSeriesInstanceUID(UFileName FileName, char* SID);
    int                GetStudyInstanceUID(UFileName FileName, char* SID);
    int                GetStudyUID(UFileName FileName, char* SID);
    int                GetSOPInstanceUID(UFileName FileName, char* SID);
    int                GetPatName(UFileName FileName, char* PatName);
    int                GetPatID(UFileName FileName, char* PatID);
    int                GetSeriesDescription(UFileName Filename1, char* SerDescr);
    int                GetScanMod(UFileName FileName, ModalityType* Mod, char* ModText=NULL);

    void               ChangeUID(char* UID, int number);
    ErrorType          swapxy(void* buffer, int size, int nx, int ny) const;
};

#endif //_DICOMDATA_INCLUDED
