/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read a sinle DICOM file.                                           */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    01-02-09   Creation, derived from libdicom by Tony Voet
  JdM    04-02-09   Added operator=() and default constructor
  JdM    22-03-10   Replaced long by int for sake of compatibility
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    02-11-15   Added UFileName DICFile data member
*/
 
#include<stdlib.h> 
#include<string.h>

#include"DICOMFile.h"


void UDICOMFile::SetAllMembersDefault()
{
    error                 = U_OK;
    DICFile               = UFileName();
    element.group         = 0;
    element.element       = 0;
    element.vr            = AE;
    element.length        = 0;
    element.value.UN      = NULL;
    element.vm            = 0;
    element.encapsulated  = 0;
    element.sequence      = 0;
    dicom_transfer_syntax = NULL;
    FileBuffer            = NULL;
    FileSize              = 0;
    FileOffset            = NULL;
    meta                  = 0;
    syntax                = 0;
    endian                = 0;
}
void UDICOMFile::DeleteAllMembers(ErrorType E)
{
    delete[] FileBuffer;
    delete[] element.value.UN;
    
    SetAllMembersDefault();
    error = E;
}
UDICOMFile::UDICOMFile()
{
    SetAllMembersDefault();
}
UDICOMFile::UDICOMFile(const UDICOMFile &DIC)
{
    SetAllMembersDefault();
    *this = DIC;
}

UDICOMFile::UDICOMFile(const UFileName& DICF)
{
    SetAllMembersDefault();

    if(SetDICOMFileName(UFileName(DICF))!=U_OK)
    {
        CI.AddToLog("ERROR: UDICOMFile::UDICOMFile(). Apply settings from file %s .\n", (const char*)DICF);
        DeleteAllMembers(U_ERROR);
        return;
    }
}

UDICOMFile::~UDICOMFile()
{
    DeleteAllMembers(U_OK);
}

UDICOMFile& UDICOMFile::operator=(const UDICOMFile &DIC)
{
    if(this==NULL || &DIC==NULL)
    {
        if(this==NULL) 
        {
            CI.AddToLog("ERROR: UDICOMFile::operator=(). this==NULL . \n");
            static UDICOMFile D; D.error = U_ERROR;
            return D;
        }
        else
        {
            CI.AddToLog("ERROR: UDICOMFile::operator=(). Invalid NULL Address argument. \n");
            DeleteAllMembers(U_ERROR);
        }
        return *this;
    }
    if(this==&DIC) return *this;

    DeleteAllMembers(U_OK);

    DICFile               = DIC.DICFile;
    element.group         = DIC.element.group;
    element.element       = DIC.element.element;
    element.vr            = DIC.element.vr;
    element.length        = DIC.element.length;
    element.vm            = DIC.element.vm;
    element.encapsulated  = DIC.element.encapsulated;
    element.sequence      = DIC.element.sequence;
    FileSize              = DIC.FileSize;
    meta                  = DIC.meta;
    syntax                = DIC.syntax;
    endian                = DIC.endian;

    if(DIC.element.value.UN)
    {
        element.value.UN = new char[DIC.element.length];
        if(element.value.UN==NULL)
        {
            CI.AddToLog("ERROR: UDICOMFile::operator=(). Memory allocation. \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        memcpy(element.value.UN, DIC.element.value.UN, DIC.element.length);
    }

    if(DIC.FileBuffer) 
    {
        FileBuffer = new char[DIC.FileSize];
        if(FileBuffer==NULL)
        {
            CI.AddToLog("ERROR: UDICOMFile::operator=(). Memory allocation. \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        memcpy(FileBuffer, DIC.FileBuffer, DIC.FileSize);
    }
    if(DIC.dicom_transfer_syntax)
        dicom_transfer_syntax = FileBuffer + (unsigned long)(DIC.dicom_transfer_syntax - DIC.FileBuffer);
    if(DIC.FileOffset)
        FileOffset            = FileBuffer + (unsigned long)(DIC.FileOffset            - DIC.FileBuffer);
    return *this;
}

ErrorType UDICOMFile::SetDICOMFileName(const UFileName& DICF)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDICOMFile::SetDICOMFileName(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(FileBuffer && DICF==DICFile) return Rewind();

    DeleteAllMembers(U_OK);

    if(DoesFileExist(DICF)==false)
    {
        CI.AddToLog("ERROR: UDICOMFile::SetDICOMFileName(). File does not exts (%100s) \n", (const char*)DICF);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }

    FILE* fp=fopen(DICF,"rb");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UDICOMFile::SetDICOMFileName(). File cannot be opened (%s) \n", (const char*)DICF);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    DICFile    = DICF;
    FileSize   = GetFileSize(fp);
    FileBuffer = new char[FileSize];
    if(FileBuffer==NULL)
    {
        CI.AddToLog("ERROR: UDICOMFile::SetDICOMFileName(). Memory allocation (FileSize = %d) \n", (int)FileSize);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    fread(FileBuffer, FileSize, 1, fp);
    fclose(fp);
 
    if(!strncmp(FileBuffer+128,"DICM",4))
    {
        FileOffset =   FileBuffer+132;
        meta       =  -1;
        syntax     =   LITTLE|EXPLICIT;
    }
    else
    {
        FileOffset = FileBuffer;
        meta       = 0;

        if(*FileBuffer)
        {
            if(FileBuffer[5]) syntax=LITTLE|EXPLICIT;
            else              syntax=LITTLE|IMPLICIT;
        }
        else
        {
            if(FileBuffer[4]) syntax=BIG|EXPLICIT;
            else              syntax=BIG|IMPLICIT;
        }
    }
    U16 magic=0x1234;
    if( *((U8*)&magic)==0x12 )    endian=BIG;
    else                          endian=LITTLE;

    dicom_encapsulated(-1);
    dicom_sequence(NULL);

    return U_OK;
}

ErrorType UDICOMFile::Rewind(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(FileBuffer==NULL) return U_ERROR;

    element.group         = 0;
    element.element       = 0;
    element.vr            = AE;
    element.length        = 0;
    element.value.UN      = NULL;
    element.vm            = 0;
    element.encapsulated  = 0;
    element.sequence      = 0;
    dicom_transfer_syntax = NULL;
    meta                  = 0;
    syntax                = 0;
    endian                = 0;

    if(!strncmp(FileBuffer+128,"DICM",4))
    {
        FileOffset =   FileBuffer+132;
        meta       =  -1;
        syntax     = LITTLE|EXPLICIT;
    }
    else
    {
        FileOffset = FileBuffer;
        meta       = 0;

        if(*FileBuffer)
        {
            if(FileBuffer[5]) syntax=LITTLE|EXPLICIT;
            else              syntax=LITTLE|IMPLICIT;
        }
        else
        {
            if(FileBuffer[4]) syntax=BIG|EXPLICIT;
            else              syntax=BIG|IMPLICIT;
        }
    }
    U16 magic=0x1234;
    if( *((U8*)&magic)==0x12 )    endian=BIG;
    else                          endian=LITTLE;

    dicom_encapsulated(-1);
    dicom_sequence(NULL);
    return U_OK;
}

ELEMENT* UDICOMFile::dicom_element(void)
{
    if(FileBuffer==NULL)
    {
        CI.AddToLog("ERROR: UDICOMFile::dicom_element(). FileBuffer == NULL \n");
        return NULL;
    }
    if(FileOffset>=FileBuffer+FileSize) return NULL;

    delete[] element.value.UN; element.value.UN = NULL;

    char* OldOffset = FileOffset;
    memcpy(&element.group  , FileOffset, 2); FileOffset += 2;
    memcpy(&element.element, FileOffset, 2); FileOffset += 2;
    dicom_swap(&element.group  ,2);
    dicom_swap(&element.element,2);
    
    if(meta)
    {
        if(element.group>=0x0008)
        {
            meta=0;
            dicom_transfer();

            FileOffset -= 4;
            return dicom_element();
        }
    }
    if(syntax & IMPLICIT || element.group==0xFFFE)
    {
        dicom_vr();
        memcpy(&element.length, FileOffset, 4); FileOffset += 4;
        dicom_swap(&element.length,4);
    }
    else
    {
        U16     tmp    = 0;
        char    vr[2]  = {0,0};
        memcpy(vr  , FileOffset, 2); FileOffset += 2;
        element.vr=(vr[0]<<8)|vr[1];

        switch(element.vr)
        {
        case OB :
        case OW :
        case SQ :
        case UN :
        case UT :
            FileOffset += 2;
            memcpy(&element.length, FileOffset, 4); FileOffset += 4;
            dicom_swap(&element.length,4);
            break;

        default :
            memcpy(&tmp, FileOffset, 2); FileOffset += 2;
            dicom_swap(&tmp,2);
            element.length=tmp;
        }
    }
    dicom_encapsulated(0);
    dicom_sequence(OldOffset);

    if(element.group==0x0002 && element.element==0x0010)
        dicom_transfer_syntax = FileOffset;
    
    return &element;
}

int UDICOMFile::dicom_skip(void)
{
    if(FileBuffer==NULL) return -1;
    if(element.vr==SQ || element.length==0xFFFFFFFF) return 0;

    if(element.group==0xFFFE)
        if(!element.encapsulated)
            return 0;

    FileOffset += element.length; 
    return 0;
}

int UDICOMFile::dicom_load(VR vrArg)
{
    if(FileBuffer==NULL)
    {
        CI.AddToLog("ERROR: UDICOMFile::dicom_load(). FileBuffer == NULL. \n");
        return -1;
    }

    if(element.vr==UN)  element.vr = vrArg;
    if(element.vr==SQ || element.length==0xFFFFFFFF)  return 0;

    if(element.group==0xFFFE)
        if(!element.encapsulated)
            return 0;

    delete[] element.value.UN; element.value.UN = NULL;
    if(!element.length)
    {
        element.value.UN=NULL;
    }
    else
    {
        element.value.UN = new char[element.length];
        if(element.value.UN==NULL)
        {
            CI.AddToLog("ERROR: UDICOMFile::dicom_load(). Memory allocation (length = %d). \n", int(element.length));
            DeleteAllMembers(U_ERROR);
            return -2;
        }
        memcpy(element.value.UN, FileOffset, element.length); FileOffset += element.length;
        dicom_endian();
    }
    return dicom_vm();
}


int UDICOMFile::dicom_vm(void)
{
    char *c,**table,*s,*d;

    switch(element.length)
    {
    case 0:
        element.vm = 0;
        return 0;

    case 0xFFFFFFFF:
        element.vm = 1;
        return 0;
    }

    char* temp = NULL;
    switch(element.vr)
    {
    case LT :
    case OB :
    case OW :
    case SQ :
    case ST :
    case UT :
        element.vm=1;
        return 0;

    case SS :
    case US :
        element.vm=element.length>>1;
        return 0;

    case AT :
    case FL :
    case SL :
    case UL :
        element.vm=element.length>>2;
        return 0;

    case FD :
        element.vm=element.length>>3;
        return 0;

    case AE :
    case AS :
    case CS :
    case DA :
    case DS :
    case DT :
    case IS :
    case LO :
    case PN :
    case SH :
    case TM :
    case UI :
        element.vm=1;
        c = (char*) element.value.UN;
        for(U32 i=element.length; i; i--,c++)
            if (*c=='\\')
                element.vm++;

        temp = new char[element.vm * sizeof(char*) + element.length+1];
        if(temp==NULL)
        {
            CI.AddToLog("ERROR: UDICOMFile::dicom_vm(), Memory allocation. \n");
            DeleteAllMembers(U_ERROR);
            return -1;
        }
        memset(temp, 0, element.vm * sizeof(char*) + element.length+1);
        memcpy(temp, element.value.UN, element.length);
        delete[] element.value.UN; element.value.UN = temp;

        c = element.value.LT + element.vm*sizeof(char*);
        s = element.value.LT + element.length;
        d = c+element.length;
        for(U32 i=element.length; i; i--) *--d = *--s;

        table    = element.value.AE;
        *table++ = c;

        for(U32 i=element.length; i; i--,c++)
            if(*c=='\\')
            {
                *c=0;
                *table++=c+1;
            }

        *c = 0;

        if(!(element.length&1))
        if(*--c==' ') *c = 0;

        return 0;

    default :
        element.vm=1;
        return 0;
    }
}

void UDICOMFile::dicom_clean(void)
{
    U32   i = 0;
    char *c = NULL;

    switch(element.vr)
    {
    case PN :
        for (i=0; i<element.vm; i++)
            for(c=element.value.PN[i]; *c; c++)
                if(*c=='^') *c=' ';

    case AE :
    case AS :
    case CS :
    case DA :
    case DS :
    case DT :
    case IS :
    case LO :
    case SH :
    case TM :
    case UI :
    for(i=0; i<element.vm; i++)
    {
        for(c=element.value.AE[i]; *c; c++)
            if(*c==' ' || *c=='\t')
                element.value.AE[i]++;
            else
            break;

        for(; *c; c++);
        c--;

        for(; c>=element.value.AE[i]; c--)
            if (*c==' ' || *c=='\t')  *c=0;
            else                      break;
    }
    break;

    default:
        break;
    }
}


/** private **/
void UDICOMFile::dicom_transfer(void)
{
    if(dicom_transfer_syntax==NULL)
    {
        CI.AddToLog("WARNING: UDICOMFile::dicom_transfer(). No transfer syntax found. \n");
        return;
    }

    if(strncmp(dicom_transfer_syntax,"1.2.840.10008.1.2",17))
    {
        CI.AddToLog("WARNING: UDICOMFile::dicom_transfer(). Transfer syntax is not DICOM. \n");
        return;
    }

    if(dicom_transfer_syntax[17]!='.')
    {
        syntax=LITTLE|IMPLICIT;
    }
    else
    {
        switch(dicom_transfer_syntax[18])
        {
        case '1' :
        case '4' :
            break;
        case '2' :
            syntax=BIG|EXPLICIT;
            break;
        default :
            CI.AddToLog("WARNING: UDICOMFile::dicom_transfer(). Unknown transfer syntax (%s)", dicom_transfer_syntax);
        }
    }
}
void UDICOMFile::dicom_vr(void)
{
    static DICTIONARY data[]=
    {
      #include "dictionary.data.DICOM.h"
    };
    element.vr = dicom_private(data, &element)->vr;
}

void UDICOMFile::dicom_encapsulated(int reset)
{
    static int encapsulated;

    if(reset)
    {
        encapsulated=0;
        return;
    }
    element.encapsulated = encapsulated;

    if(encapsulated)
        if(element.group==0xFFFE)
            if(element.element==0xE0DD)                encapsulated=0;

    if(element.length==0xFFFFFFFF)
        if(element.vr!=SQ && element.group!=0xFFFE)    encapsulated=-1;
}

void UDICOMFile::dicom_sequence(char* OldOffset)
{
    static U32  length[0x100];
    static U8   sequence;

    if(OldOffset==NULL)
    {
        sequence=0;
        return;
    }

    element.sequence=sequence;

    if(sequence)
    {
        if(length[sequence]!=0xFFFFFFFF)
        {
            *length=FileOffset-OldOffset;
            if(element.length!=0xFFFFFFFF)
                if(element.group!=0xFFFE || element.element!=0xE000)
                    *length+=element.length;

            if(*length>length[sequence])
            {
                const int  MAXERROR = 25;
                static int NERROR   = 0;
                if(NERROR<MAXERROR)
                {
                    CI.AddToLog("WARNING: UDICOMFile::dicom_sequence(). Incorrect sequence length. \n");
                    NERROR++;
                    if(NERROR==MAXERROR) CI.AddToLog("Note: UDICOMFile::dicom_sequence(). Last message. \n");
                }
                sequence--;
            }
            else
                length[sequence]-=*length;

            if(!length[sequence])
                sequence--;
        }
    }
    if(element.vr==SQ) 
    {
        if(sequence!=0xFF)
        {
            sequence++;
            length[sequence]=element.length;
        }
        else
            CI.AddToLog("WARNING: UDICOMFile::dicom_sequence(). Deep sequence hierarchy. \n");
    }

    if(element.group==0xFFFE)
    {
        if(element.element==0xE0DD) 
        {
            if(!element.encapsulated) 
            {
                if(sequence)  sequence--;
                else          CI.AddToLog("WARNING: UDICOMFile::dicom_sequence(). Incorrect sequence delimiter. \n");
            }
        }
    }
}

void UDICOMFile::dicom_endian(void)
{
    U8  *s = NULL;

    if(syntax & endian)  return;

    switch(element.vr)
    {
    case AT :
    case OW :
    case SS :
    case US :
        s = (U8*)element.value.UN;
        for(U32 i=element.length>>1; i; i--,s+=2)
            dicom_swap(s,2);
        return;

    case SL :
    case UL :
    case FL :
        s = (U8*)element.value.UN;
        for(U32 i=element.length>>2; i; i--,s+=4)
            dicom_swap(s,4);
        return;

    case FD :
        s = (U8*)element.value.UN;
        for(U32 i=element.length>>3; i; i--,s+=8)
            dicom_swap(s,8);
        return;

    default:
        return;
    }
}

void UDICOMFile::dicom_swap(void *v, U8 n)
{
    if(syntax & endian) return;

    U8* b = (U8*)v;
    U8* e =      b+n-1;

    for(U8 i=n>>1; i; i--)
    {
        U8 tmp = *b;
        *b++   = *e;
        *e--   = tmp;
    }
}

DICTIONARY *dicom_query(ELEMENT *element)
{
    static DICTIONARY data[]=
    {
        #include "dictionary.data.DICOM.h"
    };
  
    if(element==NULL)
    {
        CI.AddToLog("ERROR: dicom_query(). Invalid NULL argument. \n");
        return NULL;
    }
    return dicom_private(data,element);
}

DICTIONARY *dicom_private(DICTIONARY *data, ELEMENT *e)
{
    static DICTIONARY *d = NULL;

    if(data==NULL)
    {
        CI.AddToLog("ERROR: dicom_private(). Invalid NULL dictionary. \n");
        return NULL;
    }
    if(e==NULL)
    {
        CI.AddToLog("ERROR: dicom_private(). Invalid NULL element. \n");
        return NULL;
    }

    for(d=data; d->group!=0xFFFF; d++)
    {
        if(e->group<d->group     )  continue;
        if(e->group>d->group_last)  continue;

        switch(d->group_match)
        {
        case ANY :   break;

        case EVEN :
            if(  e->group&1 ) continue;
            break;

        case ODD :
            if(!(e->group&1)) continue;
        }

        if(e->element<d->element     ) continue;
        if(e->element>d->element_last) continue;

        switch(d->element_match)
        {
        case ANY : break;
        
        case EVEN :
            if (  e->element&1 ) continue;
            break;

        case ODD :
            if (!(e->element&1)) continue;
        }
        break;
    }
    return d;
}
