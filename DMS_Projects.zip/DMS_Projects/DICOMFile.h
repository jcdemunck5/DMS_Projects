#ifndef _DICOMFILE_INCLUDED
#define _DICOMFILE_INCLUDED


#include "FileName.h"

#define S8  char
#define S16 short
#define S32 int

#define U8  unsigned S8
#define U16 unsigned S16
#define U32 unsigned S32

typedef struct
{
    U16 group;
    U16 element;
} TAG;

typedef enum
{
    AE=('A'<<8)|'E',   // maximum 16 chars
    AS=('A'<<8)|'S',   // Age string
    AT=('A'<<8)|'T',   // attribute tag (4 bytes binary)
    CS=('C'<<8)|'S',   // code string (16 chars)
    DA=('D'<<8)|'A',   // date (8 bytes: YYYYMMDD, 10 bytes: YYYY.MM.DD)
    DS=('D'<<8)|'S',   // Decimal String, maximum 16 bytes
    DT=('D'<<8)|'T',   // time?
    FL=('F'<<8)|'L',   // 4 bytes floats
    FD=('F'<<8)|'D',   // 8 bytes double
    IS=('I'<<8)|'S',   // integer string (maximum 12 bytes)
    LO=('L'<<8)|'O',   // long string
    LT=('L'<<8)|'T',   // long text (including line breaks)
    OB=('O'<<8)|'B',   // other bytes (possible extra NULL to make even length)
    OW=('O'<<8)|'W',   // other words
    PN=('P'<<8)|'N',   // Person name
    SH=('S'<<8)|'H',   // short string
    SL=('S'<<8)|'L',   // signed long (4 bytes)
    SQ=('S'<<8)|'Q',   // sequence of (nested) items (??)
    SS=('S'<<8)|'S',   // signed short integer (2bytes)
    ST=('S'<<8)|'T',   // short text, (including new lines)
    TM=('T'<<8)|'M',   // Time: hhmmss.fraction (max 16 bytes)
    UI=('U'<<8)|'I',   // UID (maximum 64 bytes)
    UL=('U'<<8)|'L',   // unsigned long, 4 bytes
    US=('U'<<8)|'S',   // unsigned short, 2 bytes
    UN=('U'<<8)|'N',   // ???
    UT=('U'<<8)|'T'    // ???
} VR;

typedef struct
{
    U16   group;
    U16   element;
    int   vr;
    U32   length;

    union
    {
        TAG     *AT;
        double  *FD;
        float   *FL;
        U32     *UL;
        S32     *SL;
        U16     *OW,*US;
        S16     *SS;
        U8      *OB;
        char    **AE,**AS,**CS,**DA,**DS,**DT,**IS,**LO,*LT,**PN,**SH,*ST,**TM,**UI,*UT;
        void    *SQ,*UN;
    } value;

    U32   vm;
    int   encapsulated;
    U8    sequence;
} ELEMENT;

typedef enum
{
    LITTLE   = 1,
    BIG      = 2,
    IMPLICIT = 4,
    EXPLICIT = 8
} EndianType;


class DLL_IO UDICOMFile
{
public:
    UDICOMFile();
    UDICOMFile(const UDICOMFile &DIC);
    UDICOMFile(const UFileName& DICF);
    virtual ~UDICOMFile();
    UDICOMFile& operator=(const UDICOMFile &DIC);

    ErrorType       GetError(void) const            {if(this) return error; return U_ERROR;}
    ErrorType       SetDICOMFileName(const UFileName& DICF);
    unsigned int    GetOffset(void) const           {if(this) return (unsigned long)(FileOffset-FileBuffer); return 0;}
    int             GetSwap(void) const {if(syntax & endian) return 0; return 1;}
    ErrorType       Rewind(void);

    ELEMENT*        dicom_element(void);
    int             dicom_load(VR vr);
    int             dicom_skip(void);
    void            dicom_clean(void);

protected:
    void            SetAllMembersDefault();
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;
    UFileName       DICFile;
    char*           dicom_transfer_syntax;
    ELEMENT         element;
    char*           FileBuffer;

    long int        FileSize;
    char*           FileOffset;
    int             meta;
    int             syntax;
    int             endian;

    void            dicom_transfer(void);
    void            dicom_vr(void);
    void            dicom_encapsulated(int);
    void            dicom_sequence(char* OldOffset);
    void            dicom_endian(void);
    int             dicom_vm(void);
    void            dicom_swap(void *,U8);
};


typedef enum
{
    EVEN,
    ODD,
    ANY
} MATCH;

typedef struct
{
    U16         group;
    U16         group_last;
    MATCH       group_match;
    U16         element;
    U16         element_last;
    MATCH       element_match;
    VR          vr;
    const char  *description;
} DICTIONARY;

DICTIONARY *dicom_query(ELEMENT *element);
DICTIONARY *dicom_private(DICTIONARY *data, ELEMENT *e);

#endif //_DICOMFILE_INCLUDED
