#ifndef _DLLIO_INCLUDED  // Prevent including this include-file twice.
#define _DLLIO_INCLUDED
// QTDIAL
#ifndef DLL_QT_IO_F   // JdM 07-05-2013: Changed from DLL_IO_F into DLL_QT_IO_F
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(_WINDOWS)
#  if defined(BUILD_QTDIAL_DLL) 
#    define DLL_QT_IO_F(type) __declspec(dllexport) type
#    define DLL_QT_IO         __declspec(dllexport)
#  elif defined(USE_QTDIAL_DLL) 
#    define DLL_QT_IO_F(type) __declspec(dllimport) type
#    define DLL_QT_IO         __declspec(dllimport)
#  else
#    define DLL_QT_IO_F(type) type
#    define DLL_QT_IO
#  endif
#else  // WIN32
#  define DLL_QT_IO_F(type) type
#  define DLL_QT_IO
#endif
#endif // DLL_QT_IO_F

// PMT
#ifndef DLL_IO_F
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(_WINDOWS)
#  if defined(BUILD_PMT_DLL)
#    define DLL_IO_F(type) __declspec(dllexport) type
#    define DLL_IO         __declspec(dllexport)
#  elif defined(USE_PMT_DLL)
#    define DLL_IO_F(type) __declspec(dllimport) type
#    define DLL_IO         __declspec(dllimport)
#  else
#    define DLL_IO_F(type) type
#    define DLL_IO
#  endif
#else  // WIN32
#  define DLL_IO_F(type) type
#  define DLL_IO
#endif
#endif // DLL_IO_F

// FFTW
#ifndef DLL_IMPORT_F
#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(_WINDOWS)
#  if defined(BUILD_FFTW_DLL)
#    define DLL_IMPORT_F(type) __declspec(dllexport) type
#    define DLL_IMPORT         __declspec(dllexport)
#  elif defined(USE_FFTW_DLL)
#    define DLL_IMPORT_F(type) __declspec(dllimport) type
#    define DLL_IMPORT         __declspec(dllimport)
#  else
#    define DLL_IMPORT_F(type) type
#    define DLL_IMPORT      
#  endif
#else
#  define DLL_IMPORT_F(type) type
#  define DLL_IMPORT      
#endif
#endif

#endif //_DLLIO_INCLUDED

