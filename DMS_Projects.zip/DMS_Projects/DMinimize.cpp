/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for minimizing a cost function, using Marquard's method.           */
/*     This file is a part of the UMinimize-object.                              */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    18-07-97   creation, derived from FORTRAN version
  Jdm    30-01-98   removed essential bugs
  Jdm    14-05-98   BUG: use cos(grad,deltap) instead of cos2(grad,deltap)
  JdM    08-10-98   separated include-files
  JdM    12-11-98   remove some warnings for the UNIX c++ compiler in lnsrch()
  JdM    28-12-98   added more comments.
  JdM    31-08-99   Made all arrays static, eliminate the use of malloc() and free()
                    Allow negative Tolerance parameter, for relative truncation test.
  JdM    19-07-01   Set MAXPAR to a higher value, 20 instead of 10
  JdM    03-02-02   Added mechanism to stop iterationes externally
  JdM    04-09-08   Use UString for IterationString[]
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/


#include <string.h>
#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <memory.h>

#include "Minimize.h"

#define EPSILON  1.e-20
#define NU       10.

int Uminimize::Marquardt(double *par)
/*
     This is an implemenation of the Marquardt algorithm for minimizing a (cost) function.
     This implementation is the direct translation of the FORTRAN version given halfway
     this file.

     In this algorithm, the function Cost() is called. In some cases, only the returned
     cost is needed, in other cases the gradient or the Hessian (Gassian approximation) of
     the cost are required too. In these cases, additional arguments (double pointers) are
     added, that are NULL by default.

     The member variable NormalizePar determines whether the normalized parameter values are
     used with the algorithm.
 */
{
    StopIterations = false;

    double lamda   = .0001;
    int    jjj     = 1;

    double plam[MAXPAR];
    double grad[MAXPAR];
    double norm[MAXPAR];
    double deltap[MAXPAR];
    double gauss[MAXPAR*MAXPAR];

    double dss2;
    while(StopIterations==false) // Continue iterations until convergence
    {
        if(iterations >= Maxiter)
        {
            IterationString = UString("Marquardt: Too many iterations");
            return -1;
        }

/* Determine residual, gradient and Gauss-matrix */
        dss2=Cost(par,grad,gauss);

/* Normalize gauss and grad*/
        int k;
        if(NormalizePar==true)
            for(k=0; k<ndim; k++) norm[k] = sqrt(fabs(gauss[(ndim+1)*k]));
        else
            for(k=0; k<ndim; k++) norm[k] = gauss[0];

        for(k=0; k<ndim; k++) if(fabs(norm[k])<1.e-10) norm[k] = 1.;

        int i;
        for(k=i=0; i<ndim; i++)
        {
            grad[i] /= norm[i];
            for(int j=0; j<ndim; j++,k++) gauss[k] /= (norm[i]*norm[j]);
        }

        while(1) // Continue until appropriate lamda is found
        {

/* Add lamda*diag to gauss and compute normalization */
            for(k=0; k<ndim; k++) gauss[(ndim+1)*k] += lamda;

/* Solve: (gauss + lamda*diag) deltap = grad */
            while(daxisb_c(gauss,deltap,grad,ndim,ndim,NULL)==-1)
            {
                lamda *= NU;
                for(k=0; k<ndim; k++) gauss[(ndim+1)*k] += lamda;
            }

/* System positive and solved. Compute co=cos(gamma) */
            double mgra2 = 0.;
            double mdel2 = 0.;
            double grdel = 0.;
            for(i=0; i<ndim; i++)
            {
                mgra2 +=   grad[i]*grad[i];
                mdel2 += deltap[i]*deltap[i];
                grdel +=   grad[i]*deltap[i];
            }
            double co = grdel/sqrt(mdel2*mgra2);

/* Scale deltap[] in the same way as grad[] and gauss[] */
            for(i=0;i<ndim;i++) deltap[i] /= norm[i];

/* Compute residual on new point*/
            double rm = 1.;
            double r0 = rm;
            double r1,r2;

            for(k=0;k<jjj;k++) r0*=.5;
            for(i=0;i<ndim;i++) plam[i] = par[i] + r0*deltap[i];

            double dss0 = Cost(plam);

/* Now it follows the core of the Marquardt algorithm, in combination
   with a "sofisticated line-search"*/

            double rsmin = grdel*r0+dss2-dss0;
            if(fabs(rsmin) > EPSILON)
                rsmin = .5*grdel*r0*r0/rsmin;
            else
                rsmin = .5*r0;

            if(dss0<dss2)
            {
                dss2  = dss0;
                jjj  /= 2;
                if(rsmin<0) rsmin = MIN(2*r0,rm);
                r1 = MIN(rsmin,(r0+rm)/2.);
                r1 = MIN(r1   , rm);
                if(fabs(r1-r0)>r0/10.)
                {
                    for(i=0;i<ndim;i++) plam[i] = par[i] + r1*deltap[i];
                    double dss1 = Cost(plam);
                    if(dss1<dss0)
                        dss2 = dss1;
                    else
                        for(i=0;i<ndim;i++) plam[i] = par[i] + r0*deltap[i];
                }
                break; // Lamda OK
            }
            else
            {
                if(co<.707) // direction is wrong, adapt lamda.
                {
                    lamda *= NU;
                }
                else  // dircetion OK, decrease stepsize
                {
                    r1 = r0;
                    while(1) // Continue until stepsize is small enough
                    {
                        r2 = MAX(.25*r1,MIN(.75*r1,rsmin));
                        r2 = MIN(r2,rm);

/* If the direction is good and the line search fails, stop iterations.*/
                        if(r2<1.e-7) return 1;

                        jjj++;
                        for(i=0;i<ndim;i++) plam[i] = par[i] + r2*deltap[i];

                        double dss1 = Cost(plam);
                        if(dss1<dss2)
                        {
                            dss2 = dss1;
                            break;    // stepsize OK
                        }
                        else
                        {
                            r1    = r2;
                            rsmin = grdel*r1+dss2-dss1;
                            if(fabs(rsmin) > EPSILON)
                                rsmin = .5*grdel*r0*r0/rsmin;
                            else
                                rsmin = .5*r0;
                        }
                    }
                }
                break; // Lamda OK
            }
        }
        lamda = MAX(lamda/NU,1.e-7);
        for(i=0;i<ndim;i++) par[i]=plam[i];

/* Determine the maximum derivative, afmx*/
        double afmx =0;
        for(i=0;i<ndim;i++) afmx = MAX(afmx, fabs(grad[i]*norm[i]));

/* Convergence test*/
        if(Tolerance>0)
        {
            if(afmx<=Tolerance) return 0;
        }
        else
        {
            if(afmx<=-Tolerance/dss2) return 0;
        }
    }
    return 0; // External interuption
}



/*******FORTRAN VERSION
CC$DEBUG
$DECLARE
$NOTRUNCATE
$INCLUDE:'MISC_C.FI'
C
C Deze file bevat enige niet-lineaire minimalisatie routines.
C
C MARQ2 (QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C VARMET(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C DIRDIM(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C R_RANG(ST,RI,N,RMIN,RMAX,ALFMIN,ALFMAX)
C
      SUBROUTINE MARQ2(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C
C     doel:
C minimum kwadratische aanpassing van een functie
C aan een serie observaties.
C
C   ---input---
C   QOUD(M)        : M start parameters
C   M              : aantal parameters, max 12
C   GAUSS(M,M)     : Gauss matrix
C   RMIN           : minimale waarde voor radiele coordinaat QNIE
C   RMAX           : maximale waarde voor radiele coordinaat QNIE
C
C   IERR           : fout melding: 0 - geen fout,
C                                 -1 - dipole out of head
C                                  1 - geen minimum gevonden op gradientlijn
C                                  2 - stopped artificially
C                                  3 - maximum number of iterations exceded
C
C   NITER          : maximale aantal iteraties,
C        na afloop : werkelijke aantal iteraties
C   DELTA          : relatieve afbreek precisie voor alle parameters
C        na afloop : MAX(i=1,..,M): ABS{ (d Residu/d qoudi)*(qoudi + .01) }
C
C   ---ouput---
C
C   QNIE(M)        : M parameters die het residu minimaliseren
C   DHHH           : Deze subroutine berekent het residu en
C                    partiele afgeleiden naar de parameters.
C
C   SUBROUTINE DHHH(Q,M,NOP,REPS,HHH,GRAD,GAUSS)
C       NOP            : =0  ->  alleen residu bepalen
C                        =1  ->  ook GRAD  berekenen
C                        =2  ->  ook GAUSS bepalen
C       REPS           : bepaalt effect van penalty functie
C   ---output---
C   HHH            : residu (DOUBLE PRECISION)
C   GRAD(M)        : MIN-Gradient van HHH (=residu-vector maal partiele
C                         afgeleidden naar fit-functie)
C
C   INTERUP        : Onderbreekt de iteraties
C
C   INTERUP(Q,HHH,AFMX,ITER,STOPIT)
C       AFMX       : Maximale partiele afgeleidde
C       ITER       : Iteratie nummer
C       STOPIT     : if true then stop iteration
C
C        ****  naar: Marquard: Estimation of Non-Linear Parameters
C               zie: 'Non-linear parameter estimation', Y. Bard, (1974)
C
C
C note:
C        The iteration may be interrupted
      EXTERNAL         DHHH,INTERUP
      INTEGER*4        M,IERR
      REAL*4           QOUD(M),QNIE(M),GAUSS(M,M)
C
$INCLUDE:'DMSPAR.INC'
$INCLUDE:'DMS.INC'
      INTEGER*4 AXISB_C
      DOUBLE PRECISION DSS0,DSS1,DSS2
      REAL*4           LAMDA,MGRA2,MDEL2,NU
      REAL*4           REPS,GRDEL,CO,AFMX,DET,R0,R1,R2,RQ,RM,RSMIN
      INTEGER*4        I,ITER,IERR,IPOS,J,JJJ
      LOGICAL          STOPIT
C
      IERR  = 0
      REPS  =  .002
      IF(RMIN.LT.RMAX-2*RTOL) REPS=0.
      AFMX  = 500.
      JJJ   = 1
      STOPIT=.false.
      ITER  = 0
      LAMDA =.01
      NU    = 10.
      IF(M.GT. 3) NU=5.
      IF(M.GT. 6) NU=3.
      IF(M.GT.10) NU=2.
      DO 10 I=1,M
10    PARK(I)=QOUD(I)
C
20    ITER=ITER+1
C
C Bepaal de Gauss matrix en partiele afgeleidden vector.
      CALL DHHH(PARK,M,2,REPS,DSS2,GRAD,GAUSS)
C
C Sla de diagonaal van GAUSS op in DIAG.
      DO 30 I=1,M
30    DIAG(I)=GAUSS(I,I)
C
C Tel LAMDA*DIAG bij GAUSS op en bereken de schalingsfactoren.
40    DO 50 I=1,M
      IF(ABS(DIAG(I)).LE.1.E-5) THEN
         GAUSS(I,I) = 1.
      ELSE
         GAUSS(I,I) = DIAG(I) + LAMDA*ABS(DIAG(I))
      ENDIF
50    NORM(I)=SQRT(ABS(GAUSS(I,I)))
C
C Normeer GAUSS en GRAD
      DO 60 I=1,M
      GRAD(I)=GRAD(I)/NORM(I)
      DO 60 J=1,M
60    GAUSS(J,I)=GAUSS(J,I)/(NORM(I)*NORM(J))
C
C Los op: (GAUSS+LAMDA*DIAG)*DELTAP=GRAD
      IPOS = AXISB_C(GAUSS,DELTAP,GRAD,M,M,DET)
      IF(IPOS.NE.0) THEN
         LAMDA=LAMDA*10.
         DO 70 I=1,M
         GRAD(I)=GRAD(I)*NORM(I)
         DO 70 J=1,M
70       GAUSS(I,J)=GAUSS(I,J)*NORM(I)*NORM(J)
         GOTO 40
      ENDIF
C
C bereken CO=cos2(gamma)
      MGRA2 = 0.
      MDEL2 = 0.
      GRDEL = 0.
      DO 80 I=1,M
      MGRA2 = MGRA2   +   GRAD(I)*GRAD(I)
      MDEL2 = MDEL2   + DELTAP(I)*DELTAP(I)
80    GRDEL = GRDEL   +   GRAD(I)*DELTAP(I)
      CO    = GRDEL*GRDEL/(MDEL2*MGRA2)
C
C Schaal DELTAP naar de dimensies van PARK, PLAM, etc
      DO 100 I=1,M
100   DELTAP(I)=DELTAP(I)/NORM(I)
C
C Bepaal maximale stapgrootte
      IF(RMIN.LT.RMAX-2*RTOL) THEN
         CALL R_RANG(PARK,DELTAP,M/3,RMIN+RTOL,RMAX-RTOL,RQ,RM)
      ELSE
         CALL R_RANG(PARK,DELTAP,M/3,RTOL,1.-RTOL,RQ,RM)
      ENDIF
C
      CALL INTERUP(PLAM,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
C
C Bereken residu op nieuwe punt
      R0 = .5*RM
      IF(JJJ.GT.0) R0 = R0*(.5**JJJ)
      DO 120 I=1,M
120   PLAM(I)  = PARK(I) + R0*DELTAP(I)
C
      CALL DHHH(PLAM,M,0,REPS,DSS0,GRAD,GAUSS)
C
C Nu volgt de kern van het Marquard-algoritme, in combinatie met
C een 'sofisticated' line-search.
C
      RSMIN = GRDEL*R0+DSS2-DSS0
      IF(ABS(RSMIN).GT.1.E-10) THEN
         RSMIN = .5*(GRDEL*R0*R0)/RSMIN
      ELSE
         RSMIN = .5*R0
      ENDIF
      IF(DSS0.LE.DSS2) THEN
         DSS2 = DSS0
         JJJ =JJJ/2
         IF(RSMIN.LE.0.) RSMIN=MIN(2*R0,RM)
         R1  = MIN( RSMIN, (R0+RM)/2., RM)
         IF(ABS(R1-R0).GT.R0/10) THEN
            DO 130 I=1,M
130         PLAM(I) = PARK(I) + R1*DELTAP(I)
            CALL DHHH(PLAM,M,0,REPS,DSS1,GRAD,GAUSS)
            IF(DSS1.LE.DSS0)  THEN
               DSS2 = DSS1
            ELSE
               DO 140 I=1,M
140            PLAM(I) = PARK(I) + R0*DELTAP(I)
            ENDIF
         ENDIF
      ELSE
C
C Als de richting fout is, pas dan LAMDA aan.
         IF(CO.LE..5) THEN
          LAMDA = LAMDA*NU
            DO 150 I=1,M
            GRAD(I)=GRAD(I)/NORM(I)
            DO 150 J=1,M
150         GAUSS(J,I)=GAUSS(J,I)/(NORM(I)*NORM(J))
            GOTO 40
         ENDIF
         R1 = R0
160      R2 = MAX(.25*R1,MIN(.75*R1,RSMIN))
         R2 = MIN(R2,RM)
C
C Als de richting goed is, en de line-search faalt stop er dan mee.
         IF(R2.LE.1.E-7) THEN
            IERR    = 1
            DO 170 I=1,M
170         PLAM(I) = PARK(I)
            GOTO 340
         ENDIF
         JJJ = JJJ+1
         DO 180 I=1,M
180      PLAM(I) = PARK(I) + R2*DELTAP(I)
         CALL DHHH(PLAM,M,0,REPS,DSS1,GRAD,GAUSS)
         IF(DSS1.LE.DSS2) THEN
            DSS2 = DSS1
         ELSE
            R1  = R2
            RSMIN  = .5*(GRDEL*R1*R1)/(GRDEL*R1+DSS2-DSS1)
            GOTO 160
         ENDIF
      ENDIF
C
      LAMDA=MAX(LAMDA/NU,1.E-7)
C
      AFMX = 0.
      DO 310 I=1,M
310   AFMX = MAX(AFMX,ABS( GRAD(I)*(PLAM(I)+.01)*NORM(I) ))
C
      CALL INTERUP(PLAM,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
C Geen convergentie als AFMX te groot is; Eventueel doorgaan met itereren.
C Als AFMX klein genoeg is kan de penalty functie opgegeten worden.
      IF(AFMX.GE.DELTA) THEN
         DO 330 I=1,M
330      PARK(I) = PLAM(I)
         IF(AFMX.GE..1) THEN
            REPS=.002
         ELSE
            REPS=.02*AFMX
         ENDIF
         IF(ITER.LT.NITER)  THEN
          GOTO 20
         ELSE
            IERR = 3
       ENDIF
      ENDIF
C
C *** convergentie : QNIE = PLAM
340   NITER = ITER
      DELTA = AFMX
      DO 350 I=1,M
350   QNIE(I)=PLAM(I)
C
      RETURN
      END
C
C
      SUBROUTINE VARMET(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C
C     zie MARQ2
C                 zie: 'Introduction to Numerical analysis',
C                       J. Stoer and R. Burlish, (New York, 1980)
C
      EXTERNAL         DHHH,INTERUP
      INTEGER*4        M,IERR
      REAL*4           QOUD(M),QNIE(M),GAUSS(M,M)
C
$INCLUDE:'DMSPAR.INC'
$INCLUDE:'DMS.INC'
      INTEGER*4        SYMIN_C
      REAL*4           REPS,GRDEL,D,ALF,AFMX,R0,R1,R2,RQ,RM,RSMIN
      INTEGER*4        I,ITER,IERR,IPOS,J,JJJ
      DOUBLE PRECISION DSS0,DSS1,DSS2
      LOGICAL          STOPIT
C
      IERR   =  0
      REPS   =  .002
      IF(RMIN.LT.RMAX-2*RTOL) REPS=0.
      AFMX   =  500.
      JJJ    =  1
      STOPIT = .false.
      ITER   =  0
C
C kopieer QOUD in PARK
      DO 10 I=1,M
10    PARK(I)=QOUD(I)
C
20    ITER=ITER+1
C
C Bepaal de gradient en starwaarde voor GAUSS.
      IF(ITER.EQ.1) THEN
         CALL DHHH(PARK,M,2,REPS,DSS2,GRAD,GAUSS)
60       IPOS = SYMIN_C(GAUSS,M,M,D)
         IF(IPOS.NE.0) THEN
            DO 50 I=1,M
            IF(GAUSS(I,I).LE.1.E-6) THEN
               GAUSS(I,I)=1.
            ELSE
               GAUSS(I,I)=GAUSS(I,I) + 10.*ABS(GAUSS(I,I))
            ENDIF
50          CONTINUE
            GOTO 60
         ENDIF
      ENDIF
C
C Bereken DELTAP
      GRDEL    = 0.
      DO 90 I=1,M
      DELTAP(I)=0.
      DO 80 J=1,M
80    DELTAP(I)= DELTAP(I) + GAUSS(I,J)*GRAD(J)
90    GRDEL    =   GRDEL   +   GRAD(I)*DELTAP(I)
C
C Bepaal maximale stapgrootte
      IF(RMIN.LT.RMAX-2*RTOL) THEN
         CALL R_RANG(PARK,DELTAP,M/3,RMIN+RTOL,RMAX-RTOL,RQ,RM)
      ELSE
         CALL R_RANG(PARK,DELTAP,M/3,RTOL,1.-RTOL,RQ,RM)
      ENDIF
C
C Sofisticated line-search, (Bard).
      R0 = .5*RM
      IF(JJJ.GT.0) R0 = R0*(.5**JJJ)
      DO 120 I=1,M
120   PARK1(I)=PARK(I) + R0*DELTAP(I)
      CALL DHHH(PARK1,M,0,REPS,DSS0,GRAD,GAUSS)
C
      CALL INTERUP(PARK1,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
      RSMIN = GRDEL*R0+DSS2-DSS0
      IF(ABS(RSMIN).GT.1.E-10) THEN
         RSMIN = .5*(GRDEL*R0*R0)/RSMIN
      ELSE
         RSMIN = .5*R0
      ENDIF
C
      IF(DSS0.LE.DSS2) THEN
         DSS2 = DSS0
         JJJ = JJJ/2
         IF(RSMIN.LT.0.) RSMIN=2*R0
         R1  = MIN( RSMIN, (R0+RM)/2., RM)
         IF(ABS(R1-R0).GT.R0/10) THEN
            DO 130 I=1,M
130         PARK1(I)=PARK(I) + R1*DELTAP(I)
            CALL DHHH(PARK1,M,0,REPS,DSS1,GRAD,GAUSS)
            IF(DSS1.LE.DSS0) THEN
               DSS2 = DSS1
            ELSE
               DSS2=DSS0
               DO 140 I=1,M
140            PARK1(I)=PARK(I) + R0*DELTAP(I)
            ENDIF
         ENDIF
      ELSE
         R1 = R0
150      R2 = MAX(.25*R1,MIN(.75*R1,RSMIN))
         R2 = MIN(R2,RM)
         IF(R2.LE..1E-7) THEN
            IERR    = 1
            DO 160 I=1,M
160         PARK1(I)=PARK(I)
            GOTO 340
         ENDIF
         JJJ=JJJ+1
         DO 170 I=1,M
170      PARK1(I)=PARK(I) + R2*DELTAP(I)
         CALL DHHH(PARK1,M,0,REPS,DSS1,GRAD,GAUSS)
         IF(DSS1.LE.DSS2) THEN
            DSS2 = DSS1
         ELSE
            R1  = R2
            RSMIN  = .5*(GRDEL*R1*R1)/(GRDEL*R1+DSS2-DSS1)
            GOTO 150
         ENDIF
      ENDIF
C
200   CALL INTERUP(PARK1,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
C
C Nu wordt GAUSSge-update, met PPK, QQK en ZZK.
      CALL DHHH(PARK1,M,1,REPS,DSS1,GRAD1,GAUSS)
      DO 230 I=1,M
      PPK(I)=      PARK1(I)-PARK(I)
      QQK(I)=-2.*( GRAD1(I)-GRAD(I) )
230   ZZK(I)=PPK(I)
C
      DO 240 I=1,M
      DO 240 J=1,M
240   ZZK(I)=ZZK(I) - GAUSS(I,J)*QQK(J)
C
      ALF   =0.
      DO 250 I=1,M
250   ALF   =ALF    + ZZK(I)*QQK(I)
C
      IF(ABS(ALF).LE..1E-6) THEN
         IF(ALF.LT.0.) THEN
            ALF = -.1E-6
       ELSE
            ALF =  .1E-6
       ENDIF
      ENDIF
      DO 260 I=1,M
      DO 260 J=1,M
260   GAUSS(I,J)=GAUSS(I,J)+ZZK(I)*ZZK(J)/ALF
C
      AFMX=0.
      DO 310 I=1,M
310   AFMX= MAX(AFMX,ABS( GRAD1(I)*(PARK1(I)+.01) ))
C
C Geen convergentie als AFMX te groot is; eventueel doorgaan met itereren.
C Als AFMX klein genoeg is kan de penalty functie opgegeten worden.
      IF(AFMX.GE.DELTA) THEN
         DO 330 I=1,M
         GRAD(I) = GRAD1(I)
330      PARK(I) = PARK1(I)
         IF(AFMX.GE..1) THEN
            REPS=.002
         ELSE
            REPS=.02*AFMX
         ENDIF
         IF(ITER.LT.NITER)  THEN
          GOTO 20
         ELSE
            IERR = 3
       ENDIF
      ENDIF
C
C *** convergentie : QNIE = PARK1
340   NITER=ITER
      DELTA=AFMX
      DO 350 I=1,M
350   QNIE(I)=PARK1(I)
C
      RETURN
      END
C
C
      SUBROUTINE DIRDIM(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C
C     zie MARQ2
C       ***** Methode: 'Directional Discrimination Method'
C                 zie: 'Non-linear parameter estimation', Y. Bard, (1974)
C
      EXTERNAL         DHHH,INTERUP
      INTEGER*4        M,IERR
      REAL*4           QOUD(M),QNIE(M),GAUSS(M,M)
C
$INCLUDE:'DMSPAR.INC'
$INCLUDE:'DMS.INC'
      DOUBLE PRECISION DSS0,DSS1,DSS2
      REAL*4           COND,AFMX,R0,R1,R2,RQ,RM,RSMIN
      REAL*4           EPSMIN,DELT,AA,A1,A2
      INTEGER*4        I,ITER,IERR,J,JJJ,K
C
      REAL*4   HULP(MAXPAR*MAXPAR)
      EQUIVALENCE(VVMIN,HULP)
C
      LOGICAL STOPIT
C
      DATA EPSMIN/.05/,DELT/.2/,AA/.01/
C
      IERR   = 0
      EPSMIN =  .002
      IF(RMIN.LT.RMAX-2*RTOL) EPSMIN=0.
      AFMX   =  500.
      JJJ    = 1
      STOPIT = .false.
      ITER   = 0
C
C kopieer QOUD in PARK
      DO 10 I=1,M
10    PARK(I)=QOUD(I)
C
20    ITER=ITER+1
C
C Bepaal de Gauss matrix en partiele afgeleidden vector.
      CALL DHHH(PARK,M,2,EPSMIN,DSS2,GRAD,GAUSS)
C
C Bereken de NORM en schaal GAUSS en GRAD.
      DO 40 I=1,M
      IF(GAUSS(I,I).GT.1.E-5) THEN
         NORM(I)=SQRT(ABS( GAUSS(I,I)))
      ELSE
         NORM(I)=1.
      ENDIF
40    CONTINUE
C
      DO 50 I=1,M
      DO 50 J=1,M
50    GAUSS(I,J)=GAUSS(I,J)/( NORM(I)*NORM(J) )
C
      DO 60 I=1,M
      DO 60 J=1,M
60    GAUHU(M*(I-1)+J)=GAUSS(I,J)
C
C Ontbindt GAUSS in singuliere waarden.
      CALL SVD(HULP,QQK,UUMIN,IERR,GAUHU,M,M,M,.true.,.false.,ZZK)
C
C Breng VVMIN naar de juiste dimensies
      DO 70 J=M,1,-1
      DO 70 I=M,1,-1
70    VVMIN(I,J)=HULP(M*(J-1)+I)
      COND=QQK(1)/QQK(M)
      IF(COND.GT.1.E4) PRINT*,' WARNING : condition number = ',COND
C
C Schaal de inversen van de singuliere waarden
C volgens de 'Neutral Method' (Bard)
      DO 80 I=1,M
      IF(QQK(I).GT.EPSMIN) QQK(I)=MAX(1./QQK(I),DELT)
      IF(QQK(I).LE.EPSMIN) QQK(I)=AA
80    CONTINUE
C
C Bereken de 'geschaalde' inverse van GAUSS
      DO 90 I=1,M
      DO 90 J=1,M
90    VVMIN(I,J)=VVMIN(I,J)/NORM(I)
C
      DO 100 I=1,M
      DO 100 J=1,M
      GAUSS(I,J)=0.
      DO 100 K=1,M
100   GAUSS(I,J)=GAUSS(I,J) + VVMIN(I,K)*QQK(K)*VVMIN(J,K)
C
      DO 110 I=1,M
      DELTAP(I)=0.
      DO 110 K=1,M
110   DELTAP(I)=DELTAP(I) + GAUSS(I,K)*GRAD(K)
C
C Bepaal maximale stapgrootte
      IF(RMIN.LT.RMAX-2*RTOL) THEN
         CALL R_RANG(PARK,DELTAP,M/3,RMIN+RTOL,RMAX-RTOL,RQ,RM)
      ELSE
         CALL R_RANG(PARK,DELTAP,M/3,RTOL,1.-RTOL,RQ,RM)
      ENDIF
C
      R0=.5*RM
      IF(JJJ.GT.0) R0 = R0*(.5**JJJ)
C
      A1=0.
      DO 140 I=1,M
      A1=A1 + GRAD(I)*DELTAP(I)
140   PARK1(I)=PARK(I) + R0*DELTAP(I)
      A1=-4.*A1
C
      CALL INTERUP(PARK1,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
C
C Sofisticated line-search, (Bard).
      CALL DHHH(PARK1,M,0,EPSMIN,DSS0,GRAD,GAUSS)
      A2 = SNGL( (DSS0-DSS2-A1*R0)/(R0*R0) )
      IF(ABS(A2).GT.1.E-10) THEN
         RSMIN =-A1/(2.*A2)
      ELSE
         RSMIN = .5*R0
      ENDIF
C
      IF(DSS0.LE.DSS2) THEN
         JJJ=JJJ/2
         IF(RSMIN.LT.0.) RSMIN=2*R0
         R1  = MIN( RSMIN, (R0+RM)/2., RM)
         IF(ABS(R1-R0).GT.R0/10) THEN
            DO 150 I=1,M
150         PARK1(I)=PARK(I) + R1*DELTAP(I)
            CALL DHHH(PARK1,M,0,EPSMIN,DSS1,GRAD,GAUSS)
            IF(DSS1.LE.DSS0) THEN
               DSS2  =DSS1
               RSMIN =R1
               GOTO 200
            ENDIF
         ENDIF
         DSS2  = DSS0
         RSMIN =R0
         DO 160 I=1,M
160      PARK1(I)=PARK(I) + R0*DELTAP(I)
      ELSE
         R1 = R0
170      R2 = MAX(.25*R1,MIN(.75*R1,RSMIN))
         R2 = MIN(R2,RM)
         IF(R2.LE.1.E-7) THEN
            IERR  = 1
            DO 180 I=1,M
180         PARK1(I)=PARK(I)
            GOTO 340
         ENDIF
         JJJ=JJJ+1
         R1 =R2
         DO 190 I=1,M
190      PARK1(I)=PARK(I) + R1*DELTAP(I)
         CALL DHHH(PARK1,M,0,EPSMIN,DSS1,GRAD,GAUSS)
         IF(DSS1.LE.DSS2) THEN
            DSS2=DSS1
            RSMIN =R1
            GOTO 200
         ELSE
            A2=SNGL( (DSS1-DSS2-A1*R1)/(R1*R1) )
            RSMIN=-A1/(2.*A2)
            GOTO 170
         ENDIF
      ENDIF
C
200   CALL INTERUP(PARK1,DSS2,AFMX,ITER,STOPIT)
      IF(STOPIT)  THEN
         IERR = 2
         GOTO 340
      ENDIF
C Convergentie-test:
      AFMX=0.
      DO 310 I=1,M
310   AFMX= MAX(AFMX,ABS( GRAD(I)*(PARK1(I)+.01) ))
C
C Geen convergentie als AFMX te groot is; eventueel doorgaan met itereren.
C Als AFMX klein genoeg is kan de penalty functie opgegeten worden.
      IF(AFMX.GE.DELTA) THEN
         DO 330 I=1,M
330      PARK(I) = PARK1(I)
         IF(AFMX.GE..1) THEN
            EPSMIN=.002
         ELSE
            EPSMIN=.02*AFMX
         ENDIF
         IF(ITER.LT.NITER) THEN
          GOTO 20
         ELSE
            IERR = 3
       ENDIF
      ENDIF
C
C *** convergentie : QNIE = PARK1
340   NITER  = ITER
      DELTA  = AFMX
      DO 350 I=1,M
350   QNIE(I)=PARK1(I)
C
      RETURN
      END

C
C
      SUBROUTINE R_RANG(ST,RI,N,RMIN,RMAX,ALFMIN,ALFMAX)
C
      REAL*4    ST(*),RI(*)
      REAL*4    RMIN,RMAX,ALFMIN,ALFMAX
      INTEGER*4 N
C
C Given the N 3D-vectors RI and ST and the radial ranges RMIN and RMAX.
C Assuming that RMIN < |ST| < RMAX, determine ALFMIN and ALFMAX such
C that for ALFMIN < ALFA < ALFMAX the vector QQ = ST +  ALFA*RI has the
C following property:
C
C               RMIN < |ST+ALFA*RI| < RMAX,
C
C for all N vectors in RI and ST.
C
C Note : If RMIN < 0 then this lower bound is not taken into account.
C
      REAL*4    ALFTES,DMIN,WDMIN,WDMAX
      REAL*4    SR,RR,SS
      INTEGER*4 I,I3
C
      ALFMIN = -1.234567E29
      ALFMAX =  1.234567E29
      DO 100 I=1,N
      I3 = 3*(I-1)
      SR = ST(I3+1)*RI(I3+1) + ST(I3+2)*RI(I3+2) + ST(I3+3)*RI(I3+3)
      RR = RI(I3+1)*RI(I3+1) + RI(I3+2)*RI(I3+2) + RI(I3+3)*RI(I3+3)
      SS = ST(I3+1)*ST(I3+1) + ST(I3+2)*ST(I3+2) + ST(I3+3)*ST(I3+3)
C
      IF(RR.GT.1.E-10) THEN
         ALFTES = -SR/RR
         WDMAX  =  SQRT( SR*SR - RR*(SS-RMAX*RMAX) )
         DMIN   =        SR*SR - RR*(SS-RMIN*RMIN)
C
C No section with the inner sphere:
         IF(DMIN.LT.0. .OR. RMIN.LT.0. ) THEN
            ALFMIN = MAX(ALFMIN,ALFTES-WDMAX/RR)
            ALFMAX = MIN(ALFMAX,ALFTES+WDMAX/RR)
C
C At least one section with the inner sphere:
         ELSE
            WDMIN = SQRT(DMIN)
            IF(ALFTES.LT.0.) THEN
               ALFMIN = MAX(ALFMIN,ALFTES+WDMIN/RR)
               ALFMAX = MIN(ALFMAX,ALFTES+WDMAX/RR)
          ELSE
               ALFMIN = MAX(ALFMIN,ALFTES-WDMAX/RR)
               ALFMAX = MIN(ALFMAX,ALFTES-WDMIN/RR)
          ENDIF
         ENDIF
      ENDIF
100   CONTINUE
      IF(ALFMIN.EQ.-1.234567E29.AND.ALFMAX.EQ.1.234567E29) THEN
         ALFMIN = -1.E-7
         ALFMAX =  1.E-7
      ENDIF
C
      RETURN
      END
C
C
      SUBROUTINE SIMPEL(QOUD,GAUSS,M,IERR,QNIE,DHHH,INTERUP)
C
      INTEGER*4 M,IERR
      REAL*4    QOUD(M),QNIE(M),GAUSS(M,M+1)
      EXTERNAL  DHHH,INTERUP
C
$INCLUDE:'DMSPAR.INC'
$INCLUDE:'DMS.INC'
C
      REAL*4           FTOL
      PARAMETER(FTOL=1.E-8)
      DOUBLE PRECISION DSS0
      REAL*4           ALFMIN,ALFMAX,DUM
      INTEGER*4        I,J
C
      DO 10 I=1,M
      DELTAP(I)  = 0.
10    GAUSS(I,1) = QOUD(I)
C
      DO 50 J=1,M
      DELTAP(J) = 1.
      CALL R_RANG(QOUD,DELTAP,M/3,-1.,.995,ALFMIN,ALFMAX)
C
      DO 50 I=1,M
50    GAUSS(I,J+1) = QOUD(I) + .5*ALFMAX*DELTAP(I)
C
      DO 100 J=1,M+1
      DO 90 I=1,M
90    PPK(I) = GAUSS(I,J)
      CALL DHHH(PPK,M,0,DUM,DSS0,DUM,DUM)
100   NORM(J) = SNGL(DSS0)
C
      CALL AMOEBA(GAUSS,NORM,M+1,M,M,FTOL,DHHH,NITER,INTERUP)
      DO 200 I=1,M
200   QNIE(I) = GAUSS(I,1)
C
      RETURN
      END
C
C
      SUBROUTINE AMOEBA(P,Y,MP,NP,M,FTOL,DHHH,ITER,INTERUP)
      INTEGER*4        NP,MP,M,ITER
      REAL*4           P(NP,MP),Y(MP),FTOL
      EXTERNAL         DHHH,INTERUP
C
      INTEGER*4        NMAX,ITMAX
      REAL*4           ALFA,BETA,GAMMA
      PARAMETER (NMAX=13,ALFA=1.0,BETA=0.5,GAMMA=2.0,ITMAX=500)
      REAL*4           RI(NMAX),PR(NMAX),PRR(NMAX),PBAR(NMAX)
      REAL*4           ALFMIN,ALFMAX,AL,YPR,YPRR,RTOL,DUM
      INTEGER*4        MPTS,ILO,IHI,INHI,I,J
      DOUBLE PRECISION DSS0
      LOGICAL          STOPIT
C
      MPTS = M+1
      ITER = 0
1     ILO  = 1
      IF(Y(1).GT.Y(2))THEN
         IHI=1
         INHI=2
      ELSE
         IHI=2
         INHI=1
      ENDIF
      DO 11 I=1,MPTS
      IF(Y(I).LT.Y(ILO)) ILO=I
      IF(Y(I).GT.Y(IHI))THEN
         INHI=IHI
         IHI =I
      ELSE IF(Y(I).GT.Y(INHI))THEN
         IF(I.NE.IHI) INHI=I
      ENDIF
11    CONTINUE
      RTOL=2.*ABS(Y(IHI)-Y(ILO))/(ABS(Y(IHI))+ABS(Y(ILO)))
      IF(RTOL.LT.FTOL.OR.ITER.EQ.ITMAX) RETURN
      ITER=ITER+1
      DO 12 J=1,M
        PBAR(J)=0.
12    CONTINUE
      DO 14 I=1,MPTS
        IF(I.NE.IHI)THEN
          DO 13 J=1,M
            PBAR(J)=PBAR(J)+P(J,I)
13        CONTINUE
        ENDIF
14    CONTINUE
C
      DO 15 J=1,M
      PBAR(J) = PBAR(J)/M
15    RI(J)   = PBAR(J)-P(J,IHI)
      CALL R_RANG(PBAR,RI,M/3,-1.,.995,ALFMIN,ALFMAX)
      AL      = MIN(ALFMAX,ALFA)
      DO 16 J=1,M
16    PR(J)   = PBAR(J) + AL*RI(J)
C
      CALL DHHH(PR,M,-1,DUM,DSS0,DUM,DUM)
      YPR=SNGL(DSS0)
      CALL INTERUP(PR,DSS0,0.,ITER,STOPIT)
      IF(STOPIT) RETURN
      IF(YPR.LE.Y(ILO))THEN
        DO 26 J=1,M
          PRR(J)=GAMMA*PR(J)+(1.-GAMMA)*PBAR(J)
26      CONTINUE
        YPRR=SNGL(DSS0)
        IF(YPRR.LT.Y(ILO))THEN
          DO 27 J=1,M
            P(J,IHI)=PRR(J)
27        CONTINUE
          Y(IHI)=YPRR
        ELSE
          DO 28 J=1,M
            P(J,IHI)=PR(J)
28        CONTINUE
          Y(IHI)=YPR
        ENDIF
      ELSE IF(YPR.GE.Y(INHI))THEN
        IF(YPR.LT.Y(IHI))THEN
          DO 29 J=1,M
            P(J,IHI)=PR(J)
29        CONTINUE
          Y(IHI)=YPR
        ENDIF
        DO 31 J=1,M
          PRR(J)=BETA*P(J,IHI)+(1.-BETA)*PBAR(J)
31      CONTINUE
        CALL DHHH(PRR,M,-1,DUM,DSS0,DUM,DUM)
        YPRR=SNGL(DSS0)
        IF(YPRR.LT.Y(IHI))THEN
           DO 32 J=1,M
           P(J,IHI)=PRR(J)
32         CONTINUE
           Y(IHI)=YPRR
        ELSE
           DO 44 I=1,MPTS
           IF(I.NE.ILO)THEN
              DO 43 J=1,M
              PR(J)=0.5*(P(J,I)+P(J,ILO))
              P(J,I)=PR(J)
43            CONTINUE
              CALL DHHH(PR,M,-1,DUM,DSS0,DUM,DUM)
              Y(I)=SNGL(DSS0)
            ENDIF
44          CONTINUE
            CALL INTERUP(PR,DSS0,0.,ITER,STOPIT)
            IF(STOPIT) RETURN
         ENDIF
      ELSE
         DO 45 J=1,M
         P(J,IHI)=PR(J)
45       CONTINUE
         Y(IHI)=YPR
      ENDIF
      GO TO 1
      END
*******/

int Uminimize::Marquardt2(double *par)
/*
     This is an implemenation of the Marquardt algorithm for minimizing a (cost) function.
     This implementation uses the line search lnsrch() from Numerical Recipes, p385.

     In this algorithm, the function Cost() is called. In some cases, only the returned
     cost is needed, in other cases the gradient or the Hessian (Gassian approximation) of
     the cost are required too. In these cases, additional arguments (double pointers) are
     added, that are NULL by default.

     The member variable NormalizePar determines whether the normalized parameter values are
     used with the algorithm.
 */
{
    StopIterations = false;
    double lamda   = .0001;

    double plam[MAXPAR];
    double grad[MAXPAR];
    double norm[MAXPAR];
    double deltap[MAXPAR];
    double gauss[MAXPAR*MAXPAR];

    while(StopIterations==false)  // Continue iterations until convergence
    {
        if(iterations >= Maxiter)
        {
            IterationString = UString("Marquardt: Too many iterations");
            return -1;
        }

/* Determine residual, gradient and Gauss-matrix */
        double dss = Cost(par,grad,gauss);

/* Normalize gauss and grad*/
        int k;
        if(NormalizePar==true)
            for(k=0; k<ndim; k++) norm[k] = sqrt(fabs(gauss[(ndim+1)*k]));
        else
            for(k=0; k<ndim; k++) norm[k] = gauss[0];

        for(k=0; k<ndim; k++) if(fabs(norm[k])<1.e-10) norm[k] = 1.;


        int i;
        for(k=i=0; i<ndim; i++)
        {
            grad[i] /= norm[i];
            for(int j=0; j<ndim; j++,k++) gauss[k] /= (norm[i]*norm[j]);
        }

        while(1) // Continue until appropriate lamda is found
        {

/* Add lamda*diag to gauss and compute normalization */
            for(k=0; k<ndim; k++) gauss[(ndim+1)*k] += lamda;

/* Solve: (gauss + lamda*diag) deltap = grad */
            while(daxisb_c(gauss,deltap,grad,ndim,ndim,NULL)==-1)
            {
                lamda *= NU;
                for(k=0; k<ndim; k++) gauss[(ndim+1)*k] += lamda;
            }

/* System positive and solved. Compute co=cos(gamma) */
            double mgra2 = 0.;
            double mdel2 = 0.;
            double grdel = 0.;
            for(i=0; i<ndim; i++)
            {
                mgra2 +=   grad[i]*grad[i];
                mdel2 += deltap[i]*deltap[i];
                grdel +=   grad[i]*deltap[i];
            }
            double co = grdel/sqrt(mdel2*mgra2);

/* Scale deltap[] in the same way as grad[] and gauss[] */
            for(i=0;i<ndim;i++) deltap[i] /= norm[i];

            double dsslam;
            if(lnsrch(par, dss, grad, deltap, plam, &dsslam, 1.))
            {
                if(co<.707)
                    lamda *= NU; // direction is wrong, adapt lamda.
                else if(co<.9)
                    lamda *= NU*NU; // direction is wrong, adapt lamda.
                else
                    return 1;
            }
            else
            {
                lamda = MAX(lamda/NU,1.e-7);
                for(i=0;i<ndim;i++) par[i]=plam[i];
            }

/* Determine the maximum derivative, afmx*/
            double afmx =0;
            for(i=0;i<ndim;i++) afmx = MAX(afmx, fabs(grad[i]*norm[i]));

/* Convergence test*/
            if(Tolerance>0)
            {
                if(afmx<=Tolerance) return 0;
            }
            else
            {
                if(afmx<=-Tolerance/dsslam) return 0;
            }
            break;
        }
    }
    return 0; // External interuption
}


int Uminimize::lnsrch(double* par, double res, double *grad, double *dir, double *pnew, double *resnew, double maxstep)
{
    double const ALFMIN = 1.e-4;
    double const TOLX   = 1.e-14;

    int i;
    double a,alam2=1.,b,disc,resnew2=0.,res2=0.,rhs1,rhs2,tmplam;

    double sum   = 0.;
    for(i=0;i<ndim;i++)   sum += dir[i]*dir[i];
    sum=sqrt(sum);
    if(sum > maxstep)
        for(i=0;i<ndim;i++) dir[i] *= maxstep/sum;
    double slope = 0.;
    for(i=0;i<ndim;i++) slope -= grad[i]*dir[i];

    double test=0.0;
    for(i=0;i<ndim;i++)
    {
        double temp = fabs(dir[i])/MAX(fabs(par[i]),1.0);
        if(temp > test) test=temp;
    }

    double alamin = TOLX/test;
    double alam   = 1.0;
    while(1)
    {
        for(i=0;i<ndim;i++) pnew[i] = par[i]+alam*dir[i];
        *resnew = Cost(pnew);

        if(alam < alamin)
        {
            if(*resnew <= res+ALFMIN*alam*slope) for(i=0;i<ndim;i++) pnew[i] = par[i];
            return 1;
        }
        else if(iterations > Maxiter)
        {
            if(*resnew <= res+ALFMIN*alam*slope) for(i=0;i<ndim;i++) pnew[i] = par[i];
            return 2;
        }
        else
        {
            if(*resnew <= res+ALFMIN*alam*slope)
            {
                return 0;
            }
            else
            {
                if(alam == 1.0)
                    tmplam = -slope/(2.0*(*resnew-res-slope));
                else
                {
                    rhs1 = *resnew - res  -alam*slope;
                    rhs2 = resnew2 - res2 -alam2*slope;
                    a    = (rhs1/(alam*alam)-rhs2/(alam2*alam2))/(alam-alam2);
                    b    = (-alam2*rhs1/(alam*alam)+alam*rhs2/(alam2*alam2))/(alam-alam2);
                    if(a == 0.0)
                        tmplam = -slope/(2.0*b);
                    else
                    {
                        disc = b*b-3.0*a*slope;
                        if(disc<0.0)  return -1; //"Roundoff problem in lnsrch."
                        tmplam=(-b+sqrt(disc))/(3.0*a);
                    }
                    if(tmplam>0.5*alam) tmplam=0.5*alam;
                }
            }
        }
        alam2   = alam;
        resnew2 = *resnew;
        res2    = res;
        alam    = MAX(tmplam, 0.1*alam);
    }
}
