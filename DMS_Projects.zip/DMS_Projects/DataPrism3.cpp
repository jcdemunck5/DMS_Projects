/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for projecting data onto a triangle structure.                     */                                   
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    17-05-08   creation.
  JdM    28-07-08   Added GetRefPoint()
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    03-11-08   Added Center parameter to ProjectData() and GetRefPoint()
  JdM    11-12-09   Added argument to SetData() (MIP)
  JdM    13-12-09   Added GetMinSide(), GetMaxSide() and GetJumpPoint()
  JdM    02-03-10   Renamed UTriangle3 into UDataPrism3
  JdM    24-06-10   ProjectData(), GetRefPoint(). Substract Center before projecting point
  JdM    13-07-10   SetData(). Added minimum intensity projection.
  JdM    19-10-10   Added argument to SetData() (GridToVol) to avoid center shifts in 
                    Combined Xfm/Ref views of UQSurfaceRender
AW/JdM   28-10-10   Several minor updates to remove warnings in g++ compiler
  JdM    07-03-11   ProjectData() added bool NearestNeig argument
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    14-08-14   BUG FIX. Replace all occurances of Rot90() by GetRot90(). Bug introduced since update 18-09-16 in MatVec.cpp (??)
*/

#include "DataPrism3.h"
#include "Field.h"
#include "Euler.h"

/* Inititalize static const parameters. */


void UDataPrism3::SetAllMembersDefault()
{
    error   = U_OK;
    p0      = UVector3();
    p1      = UVector3();
    p2      = UVector3();

    NSub    = 0;
    NPoints = 0;
    Data    = NULL;
}
void UDataPrism3::DeleteAllMembers(ErrorType ERROR)
{
    delete[] Data;
    SetAllMembersDefault();
    error = ERROR;
}

UDataPrism3::UDataPrism3()
{
    SetAllMembersDefault();
}

UDataPrism3::UDataPrism3(UVector3 P0, UVector3 P1, UVector3 P2)
{
    SetAllMembersDefault();
    p0 = P0;
    p1 = P1;
    p2 = P2;
}
UDataPrism3::UDataPrism3(const UDataPrism3& T)
{
    SetAllMembersDefault();
    *this = T;
}

UDataPrism3::~UDataPrism3()
{
    DeleteAllMembers(U_OK);
}
UDataPrism3& UDataPrism3::operator=(const UDataPrism3& T)
{
    if(this==NULL)
    {
        static UDataPrism3 Def; 
        Def.error = U_ERROR;
        CI.AddToLog("ERROR: UDataPrism3::operator=(). this==NULL\n");
        return Def;
    }
    if(this==&T) return *this;
    if(&T==NULL)
    {
        CI.AddToLog("ERROR: UDataPrism3::operator=(). Argument NULL\n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    error   = T.error;
    p0      = T.p0;
    p1      = T.p1;
    p2      = T.p2;;

    NSub    = T.NSub;
    NPoints = T.NPoints;
    
    if(NPoints>0 && T.Data)
    {
        Data = new double[NPoints];
        if(Data==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UDataPrism3::operator=(). Memory allocation (Npoints = %d). \n", NPoints);
            return *this;
        }
        for(int n=0; n<NPoints; n++) Data[n] = T.Data[n];
    }
    return *this;
}
ErrorType UDataPrism3::GetError(void) const
{
    if(this==NULL) return U_ERROR;
    return error;
}

double UDataPrism3::GetMinSide(void) const
{
    if(this==NULL) return 0.;

    double Side0 = (p1-p2).GetNorm2();
    double Side1 = (p2-p0).GetNorm2();
    double Side2 = (p0-p1).GetNorm2();
    double Side  = MIN(MIN(Side1,Side2), Side0);
    return sqrt(fabs(Side));
}
double UDataPrism3::GetMaxSide(void) const
{
    if(this==NULL) return 0.;

    double Side0 = (p1-p2).GetNorm2();
    double Side1 = (p2-p0).GetNorm2();
    double Side2 = (p0-p1).GetNorm2();
    double Side  = MAX(MAX(Side1,Side2), Side0);
    return sqrt(fabs(Side));
}

ErrorType UDataPrism3::SetSubSample(int NSubSamp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetSubSample(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NSubSamp<=0)
    {
        return U_ERROR;
    }

    int npoints = (NSubSamp+2)*(NSubSamp+1)/2;

    if(NSub==NSubSamp && NPoints==npoints && Data) 
    {
        for(int n=0; n<NPoints; n++) Data[n] = 0.;
        return U_OK;
    }

    NPoints = npoints;
    NSub    = NSubSamp;

    delete[] Data; Data = new double[NPoints];
    if(Data==NULL)
    {
        NPoints = 0;
        NSub    = 0;
        CI.AddToLog("ERROR: UDataPrism3::SetSubSample(). Memory allocation (NPoints=%d). \n", NPoints);
        return U_ERROR;
    }
    for(int n=0; n<NPoints; n++) Data[n] = 0.;
    return U_OK;
}

double* UDataPrism3::GetProfile(const UField* Vol, int interpol, UVector3 Center, double Offset, double Step, int NStep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(NPoints<=0 || NSub<=0 || NPoints!=(NSub+2)*(NSub+1)/2)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Npoints or NSub out of range (NPoints = %d, NSub = %d) .\n", NPoints, NSub);
        return NULL;
    }
    if(NStep<=0)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Invalid number of steps (NStep=%d). \n", NStep);
        return NULL;
    }
    if(Step==0. && NStep>1)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Invalid number of steps /step size (NStep=%d,Step=%f). \n", NStep, Step);
        return NULL;
    }
    if(Vol==NULL || Vol->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). NULL or erroneous UFiel Volume argument. \n");
        return NULL;
    }
    if(Vol->Getndim()!=3 || Vol->GetNspace()!=3 || (Vol->GetFType()!=UField::U_UNIFORM &&
                                                    Vol->GetFType()!=UField::U_RECTILINEAR))
    {
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Volume argument of wrong type (%s)\n", (const char*)Vol->GetProperties(""));
        return NULL;
    }
    
    UField* G = this->GetGrid(Center, Offset, Step, NStep);
    if(G==NULL || G->GetError()!=U_OK)
    {
        delete G;
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Getting grid. \n");
        return NULL;
    }
    UField* GData = Vol->ResampleField(UEuler(), G, interpol, 0, false, 0);
    delete  G;
    if(GData==NULL || GData->GetError()!=U_OK)
    {
        delete GData;
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Interpolating data. \n");
        return NULL;
    }
    double* Prof = new double[NStep]; 
    if(GData->ConvertData(UField::U_DOUBLE)!=U_OK || GData->GetDdata()==NULL || Prof==NULL)
    {
        delete   GData;
        delete[] Prof;
        CI.AddToLog("ERROR: UDataPrism3::GetProfile(). Memory allocation (NPoints = %d), or converting data to double. \n", NPoints);
        return NULL;
    }

    double* pG = GData->GetDdata();
    for(int is=0; is<NStep; is++)
    {
        Prof[is] = 0.;
        for(int k=0; k<NPoints; k++) Prof[is] += pG[k*NStep+is];
    }
    return Prof;
}
UVector3 UDataPrism3::GetPoint(UVector3 Center, double Offset, double Step, int istep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetPoint(). Object NULL or erroneous. \n");
        return UVector3();
    }
    UVector3 PT = (p0 + p1 + p2)*(1./3.);
    UVector3 NN = PT-Center;
    NN.Normalize();
    return PT + (Offset+istep*Step)*NN;
}

UVector3 UDataPrism3::GetJumpPoint(const UField* Vol, int interpol, UVector3 Center, double Offset, double Step, int NStep, bool AverProf, UDetectExtremeType DetEx) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Object NULL or erroneous. \n");
        return UVector3();
    }
    if(NPoints<=0 || NSub<=0 || NPoints!=(NSub+2)*(NSub+1)/2)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Npoints or NSub out of range (NPoints = %d, NSub = %d) .\n", NPoints, NSub);
        UVector3();
    }
    if(NStep<=0)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Invalid number of steps (NStep=%d). \n", NStep);
        return UVector3();
    }
    if(Step==0. && NStep>1)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Invalid number of steps /step size (NStep=%d,Step=%f). \n", NStep, Step);
        return UVector3();
    }
    int DefStep = 0;
    if(Step!=0) DefStep = int(-Offset/Step);

    if(Vol==NULL || Vol->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). NULL or erroneous UFiel Volume argument. \n");
        return UVector3();
    }
    if(Vol->Getndim()!=3 || Vol->GetNspace()!=3 || (Vol->GetFType()!=UField::U_UNIFORM &&
                                                    Vol->GetFType()!=UField::U_RECTILINEAR))
    {
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Volume argument of wrong type (%s)\n", (const char*)Vol->GetProperties(""));
        return UVector3();
    }
    if(AverProf==true)
    {
        double* Prof   = this->GetProfile(Vol, interpol, Center, Offset, Step, NStep);
        if(Prof==NULL)
        {
            CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Getting averaged profile. \n");
            return UVector3();
        }
        int      istep    = this->GetExtreme(Prof, NStep , DefStep, DetEx);
        UVector3 NewPoint = this->GetPoint(Center, Offset, Step   , istep);
        delete[] Prof;
        return NewPoint;
    }
    
    UField* G = this->GetGrid(Center, Offset, Step, NStep);
    if(G==NULL || G->GetError()!=U_OK)
    {
        delete G;
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Getting grid. \n");
        return UVector3();
    }
    UField* GData = Vol->ResampleField(UEuler(), G, interpol, 0, false, 0);
    delete  G;
    if(GData==NULL || GData->GetError()!=U_OK)
    {
        delete GData;
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Interpolating data. \n");
        return UVector3();
    }
    int* idepth = new int[NPoints]; 
    if(GData->ConvertData(UField::U_DOUBLE)!=U_OK || GData->GetDdata()==NULL || idepth==NULL)
    {
        delete   GData;
        delete[] idepth;
        CI.AddToLog("ERROR: UDataPrism3::GetJumpPoint(). Memory allocation (NPoints = %d), or converting data to double. \n", NPoints);
        return UVector3();
    }

    double   AverDepth = 0;
    double* pG = GData->GetDdata();
    for(int s2=0, n=0; s2<=NSub; s2++)
        for(int s1=0; s1<=NSub-s2; s1++,n++)
        {
            idepth[n]  = this->GetExtreme(pG, NStep, DefStep, DetEx);
            AverDepth += idepth[n]/ double(NPoints);
            pG        += NStep;
        }
    
    UVector3 NewPoint;
    double   SumW = 0;
    for(int n=0; n<NPoints; n++)
    {
        double D  = fabs(idepth[n] - AverDepth);
        double W  = 1./(0.01 + D*D*D);
        NewPoint += W * GData->GetPoint3(n*NPoints+idepth[n]);
        SumW     += W;
    }
    delete GData;
    delete[] idepth;

    NewPoint = NewPoint * (1./SumW);
    return NewPoint;
}

int UDataPrism3::GetExtreme(const double* Prof, int NStep, int DefStep, UDetectExtremeType DetEx) const
{
    if(Prof==NULL || NStep<=1) return DefStep;
    
    const double* pPr  = Prof;
    double        Ext  = Prof[0];
    int           iext = 0;

    switch(DetEx)
    {
    case U_DETEXT_LOCMIN:
        {
            if(NStep<3) return DefStep;
            for(int k=0; k<NStep; k++)
            {
                if(DefStep+k+1< NStep && Prof[DefStep+k]<Prof[DefStep+k-1] && Prof[DefStep+k]<Prof[DefStep+k+1]) return DefStep+k;
                if(DefStep-k-1>=0     && Prof[DefStep-k]<Prof[DefStep-k-1] && Prof[DefStep-k]<Prof[DefStep-k+1]) return DefStep-k;
            }
            return DefStep;
        }
    case U_DETEXT_ABSMIN:
        {
            pPr++;
            for(int k=1; k<NStep; k++, pPr++)
            {
                if(pPr[0]<Ext)
                {
                    iext = k;
                    Ext  = pPr[0];
                }
            }
            return iext;
        }
    case U_DETEXT_LOCMAX:
        {
            if(NStep<3) return DefStep;
            for(int k=0; k<NStep; k++)
            {
                if(DefStep+k+1< NStep && Prof[DefStep+k]>Prof[DefStep+k-1] && Prof[DefStep+k]>Prof[DefStep+k+1]) return DefStep+k;
                if(DefStep-k-1>=0     && Prof[DefStep-k]>Prof[DefStep-k-1] && Prof[DefStep-k]>Prof[DefStep-k+1]) return DefStep-k;
            }
            return DefStep;
        }
    case U_DETEXT_ABSMAX:
        {
            pPr++;
            for(int k=1; k<NStep; k++, pPr++)
            {
                if(pPr[0]>Ext)
                {
                    iext = k;
                    Ext  = pPr[0];
                }
            }
            return iext;
        }
    case U_DETEXT_MAXJUMP:
        {
            Ext  = 0.;
            iext = 0;
            pPr++;
            for(int k=1; k<NStep; k++, pPr++)
            {
                double tst = fabs(pPr[0]-pPr[-1]);
                if(tst>Ext)
                {
                    iext = k;
                    Ext  = tst;
                }
            }
            return iext;
        }
    }
    return DefStep;
}
ErrorType UDataPrism3::SetData(const UField* Vol, UEuler GridToVol, int interpol, UVector3 Center, double Offset, double Step, int NStep, bool ApplyMaxIP, bool ApplyMinIP)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NPoints<=0 || NSub<=0 || NPoints!=(NSub+2)*(NSub+1)/2)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Npoints or NSub out of range (NPoints = %d, NSub = %d) .\n", NPoints, NSub);
        return U_ERROR;
    }
    if(NStep<=0)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Invalid number of steps (NStep=%d). \n", NStep);
        return U_ERROR;
    }
    if(Step==0. && NStep>1)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Invalid number of steps /step size (NStep=%d,Step=%f). \n", NStep, Step);
        return U_ERROR;
    }
    if(Vol==NULL || Vol->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). NULL or erroneous UFiel Volume argument. \n");
        return U_ERROR;
    }
    if(Vol->Getndim()!=3 || Vol->GetNspace()!=3 || (Vol->GetFType()!=UField::U_UNIFORM &&
                                                    Vol->GetFType()!=UField::U_RECTILINEAR))
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Volume argument of wrong type (%s)\n", (const char*)Vol->GetProperties(""));
        return U_ERROR;
    }
    if(ApplyMaxIP && ApplyMinIP)
    {
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Maximum and minimum intensity projection are both switched on. \n");
        return U_ERROR;
    }

    UField* G = this->GetGrid(Center, Offset, Step, NStep);
    if(G==NULL || G->GetError()!=U_OK)
    {
        delete G;
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Getting grid. \n");
        return U_ERROR;
    }
    G->xfm(GridToVol);
    UField* GData = Vol->ResampleField(UEuler(), G, interpol, 0, false, 0);
    delete  G;
    if(GData==NULL || GData->GetError()!=U_OK)
    {
        delete GData;
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Interpolating data. \n");
        return U_ERROR;
    }
    delete[] Data;
    Data = new double[NPoints];
    if(Data==NULL || GData->ConvertData(UField::U_DOUBLE)!=U_OK || GData->GetDdata()==NULL)
    {
        delete GData;
        CI.AddToLog("ERROR: UDataPrism3::SetData(). Memory allocation (NPoints = %d), or converting data to double. \n", NPoints);
        return U_ERROR;
    }

    double* pG = GData->GetDdata();
    for(int s2=0, n=0; s2<=NSub; s2++)
        for(int s1=0; s1<=NSub-s2; s1++,n++)
        {
            if(ApplyMaxIP)
            {
                Data[n] = *pG++;
                for(int k=1; k<NStep; k++, pG++) if(fabs(Data[n])<fabs(*pG)) Data[n] = *pG;
            }
            else if(ApplyMinIP)
            {
                Data[n] = *pG++;
                for(int k=1; k<NStep; k++, pG++) if(fabs(Data[n])>fabs(*pG)) Data[n] = *pG;
            }
            else
            {
                Data[n] = 0;
                for(int k=0; k<NStep; k++, pG++) Data[n] += *pG;
                Data[n] /= NStep;
            }
        }
    
    delete GData;
    return U_OK;
}
ErrorType UDataPrism3::ProjectData(UField* Slice, const UEuler& XFM, UVector3 Center, ProjectionType PT, double RadView, bool NearestNeig) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NPoints<=0 || NSub<=0 || NPoints!=(NSub+2)*(NSub+1)/2)
    {
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). Npoints or NSub out of range (NPoints = %d, NSub = %d) .\n", NPoints, NSub);
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). Data array not set. \n");
        return U_ERROR;
    }
    if(Slice->Getndim()  !=2 || 
       Slice->GetNspace()!=2 || 
       Slice->GetFType() !=UField::U_UNIFORM)
    {
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). Slice argument of wrong type (%s)\n", (const char*)Slice->GetProperties(""));
        return U_ERROR;
    }
    if(RadView<=0)
    {
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). RadView (=%f) out of range. \n", RadView);
        return U_ERROR;
    }
    UVector3 x0 = XFM.xfm(p0-Center);
    UVector3 x1 = XFM.xfm(p1-Center);
    UVector3 x2 = XFM.xfm(p2-Center);
    
    double   Zmin = 0;
    if(PT==U_PROJECT_MERCATOR || PT==U_PROJECT_CYLINDRICAL) 
             Zmin = 10* cos( RadView/20. );

    if(x0.Getz()<=Zmin || x1.Getz()<=Zmin || x2.Getz()<=Zmin) return U_OK;

    switch(PT)
    {
    case U_PROJECT_FLAT:
        {
            UVector2 q0 = x0.Pz().GetRot90();
            UVector2 q1 = x1.Pz().GetRot90();
            UVector2 q2 = x2.Pz().GetRot90();
            UVector2 d1 = (q1-q0)*(1./NSub);
            UVector2 d2 = (q2-q0)*(1./NSub);

            double ZZ[3] = {0.,0.,0.};
            for(int s2=0; s2<NSub; s2++)
            {
                for(int s1=0; s1<NSub-s2; s1++)
                {
                    int      n  = (s2*(2*NSub-s2+3))/2 + s1;
                    UVector2 Q0 = q0 + d1*s1 + d2*s2;
                    UVector2 Q1 = Q0 + d1;
                    UVector2 Q2 = Q0 + d2;
                    ZZ[0]       = Data[n          ];
                    ZZ[1]       = Data[n+1        ];
                    ZZ[2]       = Data[n+1+NSub-s2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
            
                    if(s1+s2+1==NSub) continue;
            
                    Q0    = Q1;
                    ZZ[0] = ZZ[1];
                    Q1    = Q2 + d1;
                    ZZ[1] = Data[n+NSub-s2+2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
                }
            }
        }
        break;

    case U_PROJECT_MERCATOR:
        {
            UVector3 D1  = (x1-x0)*(1./NSub);
            UVector3 D2  = (x2-x0)*(1./NSub);

            double ZZ[3] = {0.,0.,0.};
            for(int s2=0; s2<NSub; s2++)
            {
                for(int s1=0; s1<NSub-s2; s1++)
                {
                    int      n  = (s2*(2*NSub-s2+3))/2 + s1;
                    UVector3 P0 = x0 + D1*s1 + D2*s2;
                    UVector3 P1 = P0 + D1;
                    UVector3 P2 = P0 + D2;
                    UVector2 Q0 = P0.GetMercator(RadView).GetRot90();
                    UVector2 Q1 = P1.GetMercator(RadView).GetRot90();
                    UVector2 Q2 = P2.GetMercator(RadView).GetRot90();

                    ZZ[0]       = Data[n          ];
                    ZZ[1]       = Data[n+1        ];
                    ZZ[2]       = Data[n+1+NSub-s2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
            
                    if(s1+s2+1==NSub) continue;
            
                    Q0    = Q1;
                    ZZ[0] = ZZ[1];
                    P1    = P2 + D1;
                    Q1    = P1.GetMercator(RadView).GetRot90();
                    ZZ[1] = Data[n+NSub-s2+2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
                }
            }
        }
        break;

    case U_PROJECT_CYLINDRICAL:
        {
            UVector3 D1  = (x1-x0)*(1./NSub);
            UVector3 D2  = (x2-x0)*(1./NSub);

            double ZZ[3] = {0.,0.,0.};
            for(int s2=0; s2<NSub; s2++)
            {
                for(int s1=0; s1<NSub-s2; s1++)
                {
                    int      n  = (s2*(2*NSub-s2+3))/2 + s1;
                    UVector3 P0 = x0 + D1*s1 + D2*s2;
                    UVector3 P1 = P0 + D1;
                    UVector3 P2 = P0 + D2;
                    UVector2 Q0 = P0.GetCylinder(RadView).GetRot90();
                    UVector2 Q1 = P1.GetCylinder(RadView).GetRot90();
                    UVector2 Q2 = P2.GetCylinder(RadView).GetRot90();

                    ZZ[0]       = Data[n          ];
                    ZZ[1]       = Data[n+1        ];
                    ZZ[2]       = Data[n+1+NSub-s2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
            
                    if(s1+s2+1==NSub) continue;
            
                    Q0    = Q1;
                    ZZ[0] = ZZ[1];
                    P1    = P2 + D1;
                    Q1    = P1.GetCylinder(RadView).GetRot90();
                    ZZ[1] = Data[n+NSub-s2+2];
                    Slice->PlotTriangle(Q0, Q1, Q2, ZZ, NearestNeig);
                }
            }
        }
        break;

    default:
        CI.AddToLog("ERROR: UDataPrism3::ProjectData(). Invalid projection type (%d) \n", PT);
        return U_ERROR;
    }
    return U_OK;
}
bool UDataPrism3::GetRefPoint(const UEuler& XFM, UVector3 Center, ProjectionType PT, double RadView, UVector2 P2, UVector3 *P3) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetRefPoint(). Object NULL or erroneous. \n");
        return false;
    }
    if(P3==NULL) return false;

    UVector3 x0 = XFM.xfm(p0-Center);
    UVector3 x1 = XFM.xfm(p1-Center);
    UVector3 x2 = XFM.xfm(p2-Center);
    
    double   Zmin = 0;
    if(PT==U_PROJECT_MERCATOR || PT==U_PROJECT_CYLINDRICAL) 
             Zmin = 10* cos( RadView/20. );

    if(x0.Getz()<=Zmin || x1.Getz()<=Zmin || x2.Getz()<=Zmin) return false;

/* Triangles is in sight, determine whether P2 is inside projected triangle */
    UVector2 q0, q1, q2;
    switch(PT)
    {
    case U_PROJECT_FLAT:
        q0 = x0.Pz().GetRot90();
        q1 = x1.Pz().GetRot90();
        q2 = x2.Pz().GetRot90();
        break;

    case U_PROJECT_MERCATOR:
        q0 = x0.GetMercator(RadView).GetRot90();
        q1 = x1.GetMercator(RadView).GetRot90();
        q2 = x2.GetMercator(RadView).GetRot90();
        break;

    case U_PROJECT_CYLINDRICAL:
        q0 = x0.GetCylinder(RadView).GetRot90();
        q1 = x1.GetCylinder(RadView).GetRot90();
        q2 = x2.GetCylinder(RadView).GetRot90();
        break;

    default:
        return false;
    }

    if(IsInTriangle(P2, q0, q1, q2)==false) return false;

    double Det  = GetDeterminant(q0, q1, q2); if(Det==0.) return false;            
    double Det0 = GetDeterminant(P2, q1, q2)/Det;
    double Det1 = GetDeterminant(P2, q2, q0)/Det;
    double Det2 = GetDeterminant(P2, q0, q1)/Det;

    *P3 = Det0*p0 + Det1*p1 + Det2*p2;
    return true;
}

UField* UDataPrism3::GetGrid(UVector3 Center, double Offset, double Step, int NStep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(NPoints<=0 || NSub<=0 || NPoints!=(NSub+2)*(NSub+1)/2)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Npoints or NSub out of range (NPoints = %d, NSub = %d) .\n", NPoints, NSub);
        return NULL;
    }
    if(NStep<=0)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Invalid number of steps (NStep=%d). \n", NStep);
        return NULL;
    }
    if(Step==0. && NStep>1)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Invalid number of steps /step size (NStep=%d,Step=%f). \n", NStep, Step);
        return NULL;
    }

    int NGridPoints = NPoints*NStep;

    UVector3* Gpnts = new UVector3[NGridPoints];
    if(Gpnts==NULL)
    {
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Memory allocation error (NGridPoints = %d). \n", NGridPoints);
        return NULL;
    }
    
    UVector3 d1 = (p1-p0)*(1./NSub);
    UVector3 d2 = (p2-p0)*(1./NSub);
    for(int s2=0, n=0; s2<=NSub; s2++)
        for(int s1=0; s1<=NSub-s2; s1++)
        {
            UVector3 PT = p0 + d1*s1 + d2*s2;
            UVector3 NN = PT-Center;
            NN.Normalize();
            for(int k=0; k<NStep; k++, n++)  Gpnts[n] = PT + (Offset+k*Step)*NN;
        }
    
    UField* Grid = new UField(Gpnts, NGridPoints);
    delete[] Gpnts;
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        delete Grid;
        CI.AddToLog("ERROR: UDataPrism3::GetGrid(). Creating UField object with grid points. \n");
        return NULL;
    }
    return Grid;
}

