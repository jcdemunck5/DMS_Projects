#ifndef _DATAPRISM_INCLUDED
#define _DATAPRISM_INCLUDED

#include "MatVec.h"
#include "String.h"
#include "Field.h"

class UEuler;
class DLL_IO UDataPrism3
{
public:
    UDataPrism3();
    UDataPrism3(UVector3 P0, UVector3 P1, UVector3 P2);
    UDataPrism3(const UDataPrism3& T);

    ~UDataPrism3();
    UDataPrism3& operator=(const UDataPrism3& T);
    ErrorType           GetError(void) const;

    double              GetMinSide(void) const;
    double              GetMaxSide(void) const;
    ErrorType           SetSubSample(int NSubSamp);
    ErrorType           SetData(const UField* Vol, UEuler GridToVol, int interpol, UVector3 Center, double Offset, double Step, int NStep, bool ApplyMaxIP, bool ApplyMinIP);

    UVector3            GetJumpPoint(const UField* Vol, int interpol, UVector3 Center, double Offset, double Step, int NStep, bool AverProf, UDetectExtremeType DetEx) const;
    double*             GetProfile(const UField* Vol, int interpol, UVector3 Center, double Offset, double Step, int NStep) const;
    UVector3            GetPoint(UVector3 Center, double Offset, double Step, int istep) const;

    bool                GetRefPoint(const UEuler& XFM, UVector3 Center, ProjectionType PT, double RadView, UVector2 P2, UVector3 *P3) const;
    ErrorType           ProjectData(UField* Slice, const UEuler& XFM, UVector3 Center, ProjectionType PT, double RadView, bool NearestNeig) const;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
    UField*             GetGrid(UVector3 Center, double Offset, double Step, int NStep) const;

private:
    ErrorType           error;

    UVector3            p0;
    UVector3            p1;
    UVector3            p2;

    int                 NSub;
    int                 NPoints;
    double*             Data;

    int                 GetExtreme(const double* Prof, int NStep, int DefStep, UDetectExtremeType DetEx) const;
};


#endif// _DATAPRISM_INCLUDED
