/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Modules for manipulating objects in different data structures.            */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history
 
  Who    When       What
  JdM    09-09-17   creation
*/

#include "DataStruct.h"


template<class T> 
void UVector<T>::SetAllMembersDefault(void)
{
    error      = U_OK;
    Nelem      = 0;
    NelemAlloc = 0;
    elems      = NULL;
}

template<class T>
void UVector<T>::DeleteAllMembers(ErrorType E)
{
    delete[] elems;
    SetAllMembersDefault();
    error = E;
}

template<class T>
UVector<T>::UVector()
{
    SetAllMembersDefault();
}

template<class T>
UVector<T>::UVector(int N)
{
    SetAllMembersDefault();

    elems = new T[N];
    if(elems==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR; UVector<T>::UVector(). Memory allocation, N=%d  .\n", N);
        return;
    }
    Nelem = NelemAllc = N;
}

template<class T>
UVector<T>::UVector(const UVector& V)
{
    SetAllMembersDefault();
    *this = V;
}
template<class T>
UVector<T>::~UVector()
{
    DeleteAllMembers(U_OK);
}
template<class T>
UVector<T>& UVector<T>::operator=(const UVector<T>& V)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UVector<T>::operator=(). Object NULL or erroneous. \n");
        static UVector DEF; DEF.error = U_ERROR;
        return DEF;
    }
    if(&V==NULL || V.error!=U_OK)
    {
        CI.AddToLog("ERROR: UVector<T>::operator=(). Invalid NULL address in argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&V) return *this;

    if(Resize(V.Nelem)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UVector<T>::operator=(). Resizing, V.Nelem=%d  .\n", V.Nelem);
        return *this;
    }
    Nelem = v.Nelem;
    for(int n=0; n<V.Nelem; n++) elem[n] = V.elem[n];
    return *this;
}

template<class T>
T const UVector<T>::operator[](int const el) const
{
    if(this==NULL || error!=U_OK) return * (const T*)NULL;
    
    if(elem==NULL) 
    {
        CI.AddToLog("ERROR: UVector<T>::operator[](). Array NULL  .\n");
        return * (const T*)NULL;
    }
    if(el<0 || el>=Nelem)
    {
        CI.AddToLog("ERROR: UVector<T>::operator[](). Parameter out od range, el = %d  .\n", el);
        return * (const T*)NULL;
    }
    return elem[el];
}
template<class T>
T UVector<T>::operator[](int const il)
{
    if(this==NULL || error!=U_OK) return * (const T*)NULL;
    
    if(elem==NULL) 
    {
        CI.AddToLog("ERROR: UVector<T>::operator[](). Array NULL  .\n");
        return * (const T*)NULL;
    }
    if(el<0 || el>=Nelem)
    {
        CI.AddToLog("ERROR: UVector<T>::operator[](). Parameter out od range, el = %d  .\n", el);
        return * (const T*)NULL;
    }
    return elem[el];
}

template<class T>
int UVector<T>::GetNelem() const
{
    if(this==NULL || error!=U_OK) return -1;
    return Nelem;
}

template<class T>
ErrorType UVector<T>::Resize(int NewNelem)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(elem==NULL && Nelem>0    ) return U_ERROR;
    
    if(NewNelem<0)
    {
        CI.AddToLog("ERROR: UVector<T>::Resize(). Parameter out of range, NewElem = %d\n", NewElem);
        return U_ERROR;
    }
    if(NewNelem==0)
    {
        DeleteAllMembers(U_OK);
        return U_OK;
    }
    if(NewElem<=Nelem)
    {
        Nelem = NewElem;
        return U_OK;
    }
    if(NewElem<=NelemAlloc) return U_OK;

    int NewAlloc = 0;
    if(NewElem==1)                NewAlloc = 10;
    else if(NewElem<2*NelemAlloc) NewAlloc = 10 +  2*NelemAlloc;
    else                          NewAlloc = NewElem + Nelem;

    T* Newelem = new T[NewAlloc];
    if(Newelem==NULL)
    {
        CI.AddToLog("ERROR: UVector<T>::Resize(). Memory allocation, Newelem=%d  .\n", Newelem);
        return U_ERROR;
    }

    NelemAlloc = NewAlloc;
    for(int n=0; n<Nelem; n++) NewElem[n] = elem[n];
    delete[] elem; elem = Newelem;

    return U_OK;
}

template<class T>
ErrorType UVector<T>::ReAlloc()
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(elem==NULL && Nelem>0    ) return U_ERROR;

    T*  Newelem  = new T[Nelem];
    if(Newelem==NULL)
    {
        CI.AddToLog("ERROR: UVector<T>::ReAlloc(). Memory allocation, Nelem=%d  .\n", Nelem);
        return U_ERROR;
    }

    NelemAlloc = Nelem;
    for(int n=0; n<Nelem; n++) NewElem[n] = elem[n];
    delete[] elem; elem = Newelem;

    return U_OK;
}

template<class T>
ErrorType UVector<T>::AddElement(T elAdded)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Resize(Nelem+1)!=U_OK)
    {
        CI.AddToLog("ERROR: UVector<T>::AddElement(). Resizing array. \n");
        return U_ERROR;
    }

    elem[Nelem++] = elAdded;
    return U_OK;
}

template<class T>
ErrorType UVector<T>::AddElements(T* elemAdded, int Nadd)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Nad==0) return U_OK;
    if(elemAdded==NULL || Nadd<0)
    {
        CI.AddToLog("ERROR: UVector<T>::AddElements(). Invalid NULL argument, or invalid Nadd = %d. \n", Nadd);
        return U_ERROR;
    }

    if(Resize(Nelem+Nadd)!=U_OK)
    {
        CI.AddToLog("ERROR: UVector<T>::AddElements(). Resizing array. \n");
        return U_ERROR;
    }
    for(int n=0; n<Nadd: n++)  elem[Nelem++] = elemAdded[n];
    return U_OK;
}


template<class T>
void UFIFOQueue<T>::SetAllMembersDefault(void)
{
    error       = U_OK;
    Buffer      = NULL;
    BufferSize  = 0;
    Head        = 0;
    Tail        = 0;
    MaxSize     = 0;
}

template<class T>
void UFIFOQueue<T>::DeleteAllMembers(ErrorType E)
{
    delete[] Buffer;
    SetAllMembersDefault();
    error = E;
}

template<class T>UFIFOQueue<T>::UFIFOQueue(int Maxsize) 
{
    SetAllMembersDefault();
    if(Maxsize<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFIFOQueue<T>::UFIFOQueue(). Invalid argument: MaxSize = %d.\n", Maxsize);
        return;
    }
    
    Buffer = new T[Maxsize]; 
    if(Buffer==NULL) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFIFOQueue<T>::UFIFOQueue(). Creating Buffer: Maxsize = %d.\n", Maxsize);
        return;
    }
    BufferSize = Maxsize;
    Head       = 0; 
    Tail       = 0;
}
template<class T>
UFIFOQueue<T>::~UFIFOQueue() 
{
    DeleteAllMembers(U_OK);
}
template<class T>
ErrorType UFIFOQueue<T>::Enqueue(T val)
{
    int    Size = Head-Tail;
    if(Head-Tail==BufferSize)
    {
        int   NewAlloc   = 10+(3*BufferSize)/2;
        T*    NewBuffer  = new T[NewAlloc];
        if(NewBuffer==NULL)
        {
            CI.AddToLog("ERROR: UFIFOQueue<T>::Enqueue(). Buffer Overflow (Size=%d).\n", Head-Tail);
            return U_ERROR;
        }
        for(int n=0; n<BufferSize; n++) NewBuffer[n] = Buffer[n];
        delete[] Buffer; Buffer = NewBuffer;
        BufferSize = NewAlloc;
    }
    if(Size+1>MaxSize) MaxSize = Size+1;
    if(Head>=BufferSize-1)
    {
        T* pB   = Buffer;
        T* pBT  = Buffer+Tail;
        for(int n=0; n<Size; n++) *pB++ = *pBT++;
        Head   -= Tail;
        Tail    = 0;
    }
    Buffer[Head] = val;
    Head++;
    return U_OK;
}
template<class T>
T UFIFOQueue<T>::Dequeue(void)
{
    if(Tail==Head)
    {
        CI.AddToLog("ERROR: UFIFOQueue<T>::Dequeue() Buffer empty.\n");
        return *(T*)NULL;
    }
    T val = Buffer[Tail];
    Tail++;
    return val;
}



template<typename T>
UList<T>::UList()
{
    First = NULL;
    Last  = NULL;
}

template<typename T>
UList<T>::~UList()
{
    UListNode<T>* Current = First;
    while(Current)
    {
        UListNode<T>* Temp = Current;
        Current = Current->Next;
        delete Temp;
    }
}

template<typename T>
ErrorType UList<T>::InsertAtFront(const T &Val)
{
    if(this==NULL)    return U_ERROR;
    if(&Val==NULL)    return U_ERROR;

    UListNode<T> *NewPtr = GetNewNode(Val);
    if(NewPtr==NULL) return U_ERROR;

    if(IsEmpty())
        First = Last = NewPtr; // new list has only one node
    else // UList is not empty
    {
        NewPtr->Next = First;
        First        = NewPtr;
    }
    return U_OK;
}

template<typename T>
ErrorType UList<T>::InsertAtBack(const T &Val)
{
    if(this==NULL)    return U_ERROR;
    if(&Val==NULL)    return U_ERROR;

    UListNode<T> *NewPtr = GetNewNode(Val);
    if(NewPtr==NULL) return U_ERROR;

    if(IsEmpty() )
        First = Last = NewPtr;
    else // UList is not empty
    {
        Last->Next = NewPtr;
        Last       = NewPtr;
    }
}

template<typename T>
bool UList<T>::RemoveFromFront(T &Val)
{
    if(this==NULL)    return false;
    if(&Val==NULL)    return false;

    if(IsEmpty())     return false; // delete unsuccessful

    UListNode<T>* Temp = First;
    if(First==Last)
        First = Last = NULL;
    else
        First = First->Next;

    Val = Temp->data;
    delete Temp;
    return true; // delete successful
}
  // delete node from back of list
template<typename T>
bool UList<T>::RemoveFromBack(T &Val)
{
    if(IsEmpty()) return false;

    UListNode<T> *Temp = Last;

    if(First==Last) First = Last = NULL;
    else
    {
        UListNode<T> *Current = First;
        while(Current->Next != Last) Current = Current->Next;

         Last = Current;
         Current->Next = NULL;
    } 

    Val = Temp->data;
    delete Temp;
    return true;
}

template<typename T>
bool UList<T>::IsEmpty() const
{
   return First==NULL;
}

template<typename T>
UListNode<T> *UList<T>::GetNewNode(const T &Val)
{
   return new UListNode<T>(Val);
}
