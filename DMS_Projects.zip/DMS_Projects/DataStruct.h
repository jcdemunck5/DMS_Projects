#ifndef _DATASTRUCT_INCLUDED
#define _DATASTRUCT_INCLUDED

#include "BasicInclude.h"

template<class T> class DLL_IO UVector 
{
public:
    UVector();
    UVector(int N);
    UVector(const UVector& M);
    ~UVector();
    UVector<T>& operator=(const UVector<T>& V);

    T const     operator[](int const il) const;
    T           operator[](int const il);

    ErrorType   GetError(void) const {if(this) return error; return U_ERROR;}
    int         GetNelem() const;
    ErrorType   AddElement(T elAdded);
    ErrorType   AddElements(T* elemAdded, int Nadd);

    ErrorType   ReAlloc();
protected:
    void        DeleteAllMembers(ErrorType E);
    void        SetAllMembersDefault(void);

private:
    ErrorType   error;
    T*          elems;
    int         Nelem;
    int         NelemAlloc;
    ErrorType   Resize(int NewNelem);
};

template<class T> class DLL_IO UFIFOQueue
{
public:
    UFIFOQueue(int MaxSize);
    ~UFIFOQueue();

    ErrorType   GetError(void) const {if(this) return error; return U_ERROR;}
    int         GetSize() const {if(this) return Head-Tail; return -1;}
    ErrorType   Enqueue(T Val);
    T           Dequeue(void);
    int         GetMaxSize(void) const {if(this) return MaxSize; return 0;}

protected:
    void        DeleteAllMembers(ErrorType E);
    void        SetAllMembersDefault(void);

private:
    ErrorType   error;
    int         BufferSize;
    T*          Buffer;
    int         Head;
    int         Tail;
    int         MaxSize;
};

template<typename T> class UList; 
template<class T> class DLL_IO UListNode
{
    friend class UList<T>;

public:
    UListNode(const T& Val)
    {
        data = Val;
        Next = NULL;
    }
    T GetData() const {if(this) return T; return *(const T*)NULL;}

private:
    T            data; 
    UListNode<T>*Next;
};

template<typename T> class UList
{
public:
    UList();
    ~UList(); // destructor
    ErrorType    InsertAtFront(const T& Val);
    ErrorType    InsertAtBack(const T& Val); 
    bool         RemoveFromFront(T& Val);
    bool         RemoveFromBack(T& Val);
    bool         IsEmpty() const;

private:
    UListNode<T> *First;
    UListNode<T> *Last;

    UListNode<T> *GetNewNode(const T&);
}; // end class List


#endif // _DATASTRUCT_INCLUDED
