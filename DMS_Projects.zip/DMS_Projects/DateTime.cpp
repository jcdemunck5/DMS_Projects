/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for manupulating date and time information in different formats    */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    22-01-02   creation 
  Jdm    12-02-02   added new constructors 
  JdM    14-03-02   added copy constructor and GetTimeOfDayInSec()
  JdM    24-11-02   string constructor: try yyyymmdd
  JdM    21-01-03   Added two default parameters to GetProperties()
                    Added constructor
  JdM    13-05-03   Added operator>() and operator<()
  JdM    13-05-04   string constructor: "YYYY.MM.DD HH:MM:SS"
  JdM    10-07-04   string constructor: "DD/MM/YYYY"
  JdM    14-12-05   Several improvements on the const char* constructor, as far a date detection is concerned.
  JdM    24-05-06   GetProperties(). Change output format (remove "Date=" and "Time=")
  JdM    07-06-06   Added GetDayOfYear() and GetTimeOfDayInHou()
                    char* constructor: allow nested comments
  JdM    24-09-06   Added ShiftSeconds()
                    Bug fix: ConvertToSec()
  JdM    24-10-06   Added GetYear2Digits()
  JdM    06-07-08   Bug fix string constructor (StrLen==8, swapped year and day)
  JdM    14-08-08   Improved reading date from string.
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    22-09-09   Added operator==() and operator!=()
  JdM    30-07-13   String constructor: use new functions from UString() 
  JdM    14-09-13   Allowed new string format in const char* constructor (order of year and day)
  JdM    02-04-17   const char* constructor. Avoid error message when reading seconds that are not present.
*/

#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "DateTime.h"
#include "String.h"

/* Inititalize static const parameters. */
const int UDateTime::MAXPROPERTIES = 100;

void UDateTime::SetAllMembersDefault(void)
{
    error      = U_OK;
    Properties = NULL;
    day        = 1;  
    mon        = 1;
    yea        = 1;  
    hou        = 0;  
    min        = 0;  
    sec        = 0;  
}
void UDateTime::DeleteAllMembers(ErrorType E)
{
    delete[] Properties;
    SetAllMembersDefault();
    error = E;
}


UDateTime::UDateTime()
{
    SetAllMembersDefault();
}

UDateTime::UDateTime(int YYYYMMDD)
/* 
    Initialize this object assuming that the given integer is of the format "YYYYMMDD"
 */
{
    SetAllMembersDefault();
    if(YYYYMMDD<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Invalid argument (%d). \n", YYYYMMDD);
        return;
    }
    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Memory allocation. \n");
        return;
    }
    yea =  YYYYMMDD/10000;
    mon = (YYYYMMDD-10000*yea) / 100;
    day = (YYYYMMDD-10000*yea-100*mon);

    if(IsValidDate()==false)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Invalid date (%2.2d-%2.2d-%4.4d)  . \n",day,mon,yea);
        return;
    }
    error = U_OK;
    return;
}


UDateTime::UDateTime(const char* DateTimeString)
/* 
    Initialize this object assuming the following format:
         "//   Date     =30/03/2001    Time    =16:23:02 "
    or   "//   Date     =2001/03/30    Time    =16:23:02 "
    or         Date = 06-02-2006 (dmy); ; Time = 16-20-05 (hms); ;)  . 
    or   "YYYYMMDD"               or "DDMMYYYY"
    or   "YYYY?MM?DD"             or "DD?MM?YYYY"
    or   "YYYY.MM.DD HH:MM:SS"    or "DD.MM.YYYY HH:MM:SS"
 */
{
    error      = U_ERROR;
    Properties = NULL;
    day        = 1;  
    mon        = 1;
    yea        = 1;  
    hou        = 0;  
    min        = 0;  
    sec        = 0;
    if(DateTimeString==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). NULL argument. \n");
        return;
    }
    size_t StrLen = strlen(DateTimeString);
    if(StrLen<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Invalid argument (DateTimeString = %s). \n", DateTimeString);
        return;
    }
    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Memory allocation. \n");
        return;
    }
    memset(Properties, 0, MAXPROPERTIES);

    bool CaseSense = false;
    UString SS(DateTimeString);
    if(SS.IsBegining(UString("//"), CaseSense))      SS = SS.GetStringAfterKey("//", CaseSense);
    else if(SS.IsBegining(UString("CC"), CaseSense)) SS = SS.GetStringAfterKey("CC", CaseSense);
    else if(SS.IsBegining(UString("#" ), CaseSense)) SS = SS.GetStringAfterKey("#" , CaseSense);
    
    error            = U_ERROR;
    int        Off   = 0;
    ErrorType  E     = U_OK;
    UString    SDate = SS.GetStringAfterKeyIs("date", CaseSense);
    if(SDate.IsNULL()==false && SDate.IsEmpty()==false)
    {
        int Nchar = 0;
        SDate.RemoveFirstBlanks();
        if(E==U_OK) day   = SDate.GetInt(Off, -1, &E, &Nchar); Off += Nchar+1;
        if(Nchar==4)
        {
            yea = day;
            if(E==U_OK) mon   = SDate.GetInt(Off, -1, &E, &Nchar); Off += Nchar+1;
            if(E==U_OK) day   = SDate.GetInt(Off, -1, &E, &Nchar); Off += Nchar+1;
        }
        else
        {
            if(E==U_OK) mon   = SDate.GetInt(Off, -1, &E, &Nchar); Off += Nchar+1;
            if(E==U_OK) yea   = SDate.GetInt(Off, -1, &E, &Nchar); Off += Nchar+1;
        }
        error = E;
    }
    if(error==U_ERROR && StrLen==8)
    {
        char temp[10];                            
        memset(temp, 0, sizeof(temp));
        memcpy(temp, DateTimeString, 8);          // try "YYYYMMDD"
        day   = atoi(temp+6); temp[6] = 0;
        mon   = atoi(temp+4); temp[4] = 0;
        yea   = atoi(temp  );
        if(IsValidDate()==false)
        {
            memcpy(temp, DateTimeString, 8);      // try "DDMMYYYY"
            yea   = atoi(temp+4); temp[4] = 0;
            mon   = atoi(temp+2); temp[2] = 0;
            day   = atoi(temp  );
        }
        if(IsValidDate()==false) error = U_ERROR;
        else                     error = U_OK;
    }
    if(error==U_ERROR && StrLen==10)
    {
        char temp[12];
        memset(temp, 0, sizeof(temp));
        memcpy(temp, DateTimeString, 12);         // try "YYYY.MM.DD"
        day   = atoi(temp+8); temp[8] = 0;
        mon   = atoi(temp+5); temp[5] = 0;
        yea   = atoi(temp  );
        if(IsValidDate()==false)
        {
            memcpy(temp, DateTimeString, 8);      // try "DD.MM.YYYY"
            yea   = atoi(temp+6); temp[6] = 0;
            mon   = atoi(temp+3); temp[3] = 0;
            day   = atoi(temp  );
        }
        if(IsValidDate()==false) error = U_ERROR;
        else                     error = U_OK;
    }
    if(error==U_ERROR && DateTimeString[4]=='.' && DateTimeString[7]=='.')
    {
        char temp[20];
        strncpy(temp, DateTimeString, sizeof(temp));
        temp[4]  = 0;
        temp[7]  = 0;
        yea      = atoi(temp  );
        mon      = atoi(temp+5); 
        day      = atoi(temp+8); 
        temp[10] = 0;
        temp[13] = 0;
        temp[16] = 0;
        hou      = atoi(temp+11);  
        min      = atoi(temp+14);
        sec      = atoi(temp+17);  
        
        if(IsValidDate()==false) error = U_ERROR;
        else                     error = U_OK;
        if(error==U_OK) return;
    }

    if(error!=U_OK        ||
       day<=0 || day>31   ||
       mon<=0 || mon>12   ||
       yea<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Erroneous date in string (%s)  . \n",DateTimeString);
        return;
    }
    if(IsValidDate()==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Invalid date (%2.2d-%2.2d-%4.4d)  . \n",day,mon,yea);
        return;
    }

    Off   = 0;
    E     = U_OK;
    UString STime = SS.GetStringAfterKeyIs("time", CaseSense);
    if(STime.IsNULL()==true || STime.IsEmpty()==true)
        STime = SS.GetStringAfterKeyIs("ime", CaseSense); // account the possibility that 't' has been replaced
    if(STime.IsNULL()==false && STime.IsEmpty()==false)
    {
        sec = 0;
        int Nchar = 0;
        STime.RemoveFirstBlanks();
        if(E==U_OK)                          hou   = STime.GetInt(Off, -1, &E  , &Nchar); Off += Nchar+1;
        if(E==U_OK)                          min   = STime.GetInt(Off, -1, &E  , &Nchar); Off += Nchar+1;
        if(E==U_OK && Off<STime.GetNbytes()) sec   = STime.GetInt(Off,  0, NULL, &Nchar); // Allow missing sec-value
        error = E;
    }
    if(error==U_ERROR    ||
       hou<0 || hou>24   ||
       min<0 || min>60   ||
       sec<0 || sec>60)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Erroneous time in string (%s)  . \n",DateTimeString);
        return;
    }
    error = U_OK;
}

UDateTime::UDateTime(int Year, int Month, int Day, int Hour, int Minute, int Second)
{
    yea = Year;
    mon = Month;
    day = Day;
    hou = Hour;
    min = Minute;
    sec = Second;

    if(yea<100)
    {
        if(yea<20) yea += 2000;
        else       yea += 1900;
    }

    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Memory allocation. \n");
        return;
    }
    error = U_OK;
}


UDateTime::UDateTime(int Year, unsigned int Nsec)
/*
    Initialize the object in such a way that the date and time correspond to nsec seconds
    after the given year.
 */
{
    SetAllMembersDefault();
    unsigned int Nday = Nsec/86400;
    yea = Year;
    while(1)     // Find the year and the number of days left
    {
        unsigned int Ndpy = 365;
        if((Year%4)==0) Ndpy = 366;
        if(Nday<Ndpy) break;
        Nday -= Ndpy;
        yea++;
    }

    day = Nday;
    mon = 0;
    if(day>=31)  // january
    {
        day-=31;
        mon++;
        int Ndpm = 28;
        if((yea%4)==0) Ndpm = 29;
        if(day>=Ndpm)  // february
        {
            day -= Ndpm;
            mon++;
            if(day>=31) // march
            {
                day-=31;
                mon++;                
                if(day>=30)  // april
                {
                    day-=30;
                    mon++;
                    if(day>=31) // may
                    {
                        day-=31;
                        mon++; 
                        if(day>=30)  // june    
                        {
                            day-=30;
                            mon++;
                            if(day>=31) // july
                            {
                                day-=31;
                                mon++;                
                                if(day>=31) // august
                                {
                                    day-=31;
                                    mon++;                
                                    if(day>=30)  // september 
                                    {
                                        day-=30;
                                        mon++;
                                        if(day>=31) // october
                                        {
                                            day-=31;
                                            mon++;
                                            if(day>=30)  // november
                                            {
                                                day-=30;
                                                mon++;
                                                if(day>=31) // december
                                                {
                                                    day-=31;
                                                    mon++;
                                                }
                                            }                                             
                                        }               
                                    }                                                                                                
                                }
                            }                                                                                               
                        }               
                    }                                
                }                                            
            }            
        }
    }
    day++; mon++;  // Start with 1

    int nsecleft = Nsec%86400;
    hou = nsecleft/3600;  
    nsecleft -= hou*3600;
    min = nsecleft/60;
    sec = nsecleft%60;

    Properties = new char[MAXPROPERTIES];
    if(Properties==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDateTime::UDateTime(). Memory allocation. \n");
        return;
    }
    error = U_OK;
}

UDateTime::UDateTime(const UDateTime& DT)
{
    SetAllMembersDefault();
    *this = DT;
}


UDateTime::~UDateTime()
{
    DeleteAllMembers(U_OK);
}

bool UDateTime::operator==(const UDateTime& DT) const
{
    if(this==NULL && &DT==NULL) return true;
    if(this==NULL || &DT==NULL) return false;
    if(yea!=DT.yea) return false;
    if(mon!=DT.mon) return false;
    if(day!=DT.day) return false;
    if(hou!=DT.hou) return false;
    if(min!=DT.min) return false;
    if(sec!=DT.sec) return false;
    
    return true;
}
bool UDateTime::operator!=(const UDateTime& DT) const
{
    return  NOT(*this==DT) ;
}
UDateTime& UDateTime::operator=(const UDateTime& DT)
{
    if(this==NULL)
    {
        static UDateTime D; D.error = U_ERROR;
        return D;
    }
    if(&DT==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&DT) return *this;

    DeleteAllMembers(U_OK);
    error      = DT.error;
    day        = DT.day;
    mon        = DT.mon;
    yea        = DT.yea;
    hou        = DT.hou;
    min        = DT.min;
    sec        = DT.sec;

/* Copy data, delete old data first*/
    if(DT.Properties)
    {
        Properties = new char[MAXPROPERTIES];
        if(Properties==NULL) error = U_ERROR;
        else                 memcpy(Properties, DT.Properties, MAXPROPERTIES);
    }
    return *this;
}

bool UDateTime::operator>(const UDateTime& DT) const
{
    if(yea>DT.yea) return true;
    if(yea<DT.yea) return false;
    if(mon>DT.mon) return true;
    if(mon<DT.mon) return false;
    if(day>DT.day) return true;
    if(day<DT.day) return false;
    if(hou>DT.hou) return true;
    if(hou<DT.hou) return false;
    if(min>DT.min) return true;
    if(min<DT.min) return false;
    if(sec>DT.sec) return true;
    if(sec<DT.sec) return false;
    
    return false; // Equal
}

bool UDateTime::operator<(const UDateTime& DT) const
{
    if(yea<DT.yea) return true;
    if(yea>DT.yea) return false;
    if(mon<DT.mon) return true;
    if(mon>DT.mon) return false;
    if(day<DT.day) return true;
    if(day>DT.day) return false;
    if(hou<DT.hou) return true;
    if(hou>DT.hou) return false;
    if(min<DT.min) return true;
    if(min>DT.min) return false;
    if(sec<DT.sec) return true;
    if(sec>DT.sec) return false;
    
    return false; // Equal
}

int UDateTime::GetYear2Digits(void) const
{
    return yea%100;
}

const char* UDateTime::GetProperties(const char* Comment, bool Date, bool Time) const
{
    if(Properties==NULL) return "UDateTime::GetProperties(). Error";

    char Begin[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,15);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties,0,MAXPROPERTIES);

    int nc = 0;
    if(error!=U_OK)
    {
        if(Comment) nc+=sprintf(Properties,"%s",Begin);
        nc+=sprintf(Properties+nc," ERROR in UDateTime-object %c", End);
        return Properties;
    }
    if(Date==true) nc += sprintf(Properties+nc,"%s %2.2d-%2.2d-%4.4d [dmy] %c",Begin,day,mon,yea,End);
    if(Time==true) nc += sprintf(Properties+nc,"%s %2.2d-%2.2d-%2.2d [hms] %c",Begin,hou,min,sec,End);

    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: UDateTime::GetProperties(). Array overflow: nc=%d .\n",nc);
    return Properties;
}

bool UDateTime::IsDateEqual(const UDateTime& DT) const
{
    if(day!=DT.day) return false;
    if(mon!=DT.mon) return false;
    if(yea!=DT.yea) return false;
    return true;
}

double UDateTime::GetTimeOfDayInSec(void) const
{
    return hou*3600 + min*60 + sec;
}

int UDateTime::GetDayOfYear(void) const
{
    return int( -TimeDifInDay(UDateTime(yea, 1, 1, 0, 0, 0)) );
}
double UDateTime::GetTimeOfDayInHou(void) const
{
    return GetTimeOfDayInSec()/3600.;
}

double UDateTime::TimeDifInSec(const UDateTime& DT, double TimeInSec) const
{
    double ThisTime = ConvertToSec();
    return DT.ConvertToSec() + TimeInSec - ThisTime;
}

double UDateTime::TimeDifInHou(const UDateTime& DT) const
{
    return TimeDifInSec(DT)/3600.;
}
double UDateTime::TimeDifInDay(const UDateTime& DT) const
{
    return TimeDifInSec(DT)/86400;
}
ErrorType UDateTime::ShiftSeconds(double Seconds, double* FracSec)
{
    int    NSeconds = (int) floor(Seconds);
    double Frac     = Seconds - NSeconds;
    
    double ThisTime = ConvertToSec();
    if(ThisTime+NSeconds < 0)
    {
        CI.AddToLog("ERROR: UDateTime::ShiftSeconds(). Only implemented for years after 2000. \n");
        return U_ERROR;
    }
    
    *this = UDateTime(2000, (unsigned int) (ThisTime+NSeconds));
    if(FracSec) *FracSec = Frac;
    return U_OK;
}

double UDateTime::ConvertToSec(void) const
/*
   Comput absolute time in s., wrt 1 jan 2000, 00:00:00
 */
{
    if(error!=U_OK) return 0;

    int Nday = (yea-2000)*365;
    if(yea>2000) Nday += (yea-2000-1)/4;
    
    for(int k=1; k<mon; k++)
    {
        switch(k)
        {
        case  1: Nday+=31; break; // jan
        case  2: Nday+=28; if(!(yea%4)) Nday++; break;
        case  3: Nday+=31; break;
        case  4: Nday+=30; break;
        case  5: Nday+=31; break;
        case  6: Nday+=30; break;
        case  7: Nday+=31; break; // jul
        case  8: Nday+=31; break; // aug
        case  9: Nday+=30; break; // sep
        case 10: Nday+=31; break;
        case 11: Nday+=30; break;
        }
    }
    Nday += day-1;

    return Nday*86400. + hou*3600. + min*60. + sec;
}

bool UDateTime::IsValidDate(void) const
{
    if(yea<=0) return false;
    if(day<=0) return false;

    switch(mon)
    {
    case  1: if(day>31) return false; else return true;
    case  2: if(day>29 || (yea%4 && day>28)) return false;
             else                            return true;
    case  3: if(day>31) return false; else return true;
    case  4: if(day>30) return false; else return true;
    case  5: if(day>31) return false; else return true;
    case  6: if(day>30) return false; else return true;
    case  7: if(day>31) return false; else return true;
    case  8: if(day>31) return false; else return true;
    case  9: if(day>30) return false; else return true;
    case 10: if(day>31) return false; else return true;
    case 11: if(day>30) return false; else return true;
    case 12: if(day>31) return false; else return true;
    }
    return false;
}


#define IGREG (15+31L*(10+12L*1582))


/**
 *   Convert conventional date to  corresponding Julian day
 */

int fiff_julday(int id,         /**< Day   */
        int mm,     /**< Month */
        int iyyy,   /**< Year  */
        long *julian)   /**< Output: Julian date */
  
{
  long jul;
  int ja,jy,jm;
  
  if (iyyy == 0) {
    fprintf(stderr,"JULDAY: there is no year zero.");
    return (-1);
  }
  if (iyyy < 0) ++iyyy;
  if (mm > 2) {
    jy=iyyy;
    jm=mm+1;
  } else {
    jy=iyyy-1;
    jm=mm+13;
  }
  jul = (long) (floor(365.25*jy)+floor(30.6001*jm)+id+1720995);
  if (id+31L*(mm+12L*iyyy) >= IGREG) {
    ja = (int) (0.01*jy);
    jul += 2-ja+(int) (0.25*ja);
  }
  *julian = jul;
  return (0);
}

#undef  IGREG
#define IGREG 2299161


/**
 * Convert Julian day to a conventional date
 */

int fiff_caldate (long julian,  /**< Julian day    */
          int *id,  /**< Output: day   */
          int *mm,  /**< Output: month */
          int *iyyy)    /**< Output: year  */

{
  long ja,jalpha,jb,jc,jd,je;
  
  if (julian >= IGREG) {
    jalpha = (long) (((float) (julian-1867216)-0.25)/36524.25);
    ja=julian+1+jalpha-(long) (0.25*jalpha);
  } else
    ja=julian;
  jb = ja+1524;
  jc = (long) (6680.0+((float) (jb-2439870)-122.1)/365.25);
  jd = (long) (365*jc+(0.25*jc));
  je = (long) ((jb-jd)/30.6001);
  *id = jb-jd-(int) (30.6001*je);
  *mm=je-1;
  if (*mm > 12) *mm -= 12;
  *iyyy=jc-4715;
  if (*mm > 2) --(*iyyy);
  if (*iyyy <= 0) --(*iyyy);
  return (0);
}

#undef IGREG

