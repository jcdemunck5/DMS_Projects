#ifndef _DATETIME_INCLUDED
#define _DATETIME_INCLUDED

#include "BasicInclude.h"

class DLL_IO UDateTime
{
public:
    UDateTime();
    UDateTime(int YYYYMMDD);
    UDateTime(int Year, unsigned int nsec);
    UDateTime(int Year, int Month, int Day, int Hour, int Minute, int Second);
    UDateTime(const char* DateTimeString);
    UDateTime(const UDateTime& DT);

    UDateTime&       operator=(const UDateTime& DT);
    bool             operator>(const UDateTime& DT) const;
    bool             operator<(const UDateTime& DT) const;
    bool             operator==(const UDateTime& DT) const;
    bool             operator!=(const UDateTime& DT) const;

    ~UDateTime();

    int              GetHour(void)   const {return hou;}
    int              GetMin(void)    const {return min;}
    int              GetSec(void)    const {return sec;}
    int              GetDay(void)    const {return day;}
    int              GetMonth(void)  const {return mon;}
    int              GetYear(void)   const {return yea;}
    int              GetYear2Digits(void)   const;
    int              GetDayOfYear(void) const;

    const char*      GetProperties(const char* Comment, bool Date=true, bool Time=true) const;
    ErrorType        GetError() const {return error;}

    bool             IsDateEqual(const UDateTime& DT) const;
    double           GetTimeOfDayInSec(void) const;
    double           GetTimeOfDayInHou(void) const;
    double           TimeDifInSec(const UDateTime& DT, double TimeInSec=0.) const;
    double           TimeDifInHou(const UDateTime& DT) const;
    double           TimeDifInDay(const UDateTime& DT) const;

    ErrorType        ShiftSeconds(double Seconds, double* FracSec);

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    ErrorType        error;         // General error flag.
    char*            Properties;
    static const int MAXPROPERTIES;

    int              day;  // Day of the month (1...31)
    int              mon;  // Month  (1...12)
    int              yea;  // Year   (0...2002,...)
    int              hou;  // Hour   (0...24)
    int              min;  // Minute (0...60)
    int              sec;  // Second (0...60)

    double           ConvertToSec(void) const;
    bool             IsValidDate(void) const;
};


#endif // _DATETIME_INCLUDED
