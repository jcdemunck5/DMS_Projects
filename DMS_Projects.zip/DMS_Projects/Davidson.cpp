/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for computing eigen values, eigen vectors of (sparse) symmetric    */
/*     matrices using the Davidson algorithm. The matrix vector multiplication   */
/*     should be defined in derived class.                                       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What 
  JdM    27-05-10   creation
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/


#include <math.h>
#include "Davidson.h"

void UDavidson::SetAllMembersDefault(void)
{
    error   = U_OK;
    Diag    = NULL;

    neig    = 0;
    ierr    = 0;
    ilow    = 0;
    niv     = 0;
    nmv     = 0;
    ihigh   = 0;
    nume    = 0;
    N       = 0;
    numemax = 0;
    limmax  = 0;
    lim     = 0;
    iiwsz   = 0;
    irwsz   = 0;
    maxiter = 0;
    iselec  = NULL;
    iwork   = NULL;
    work    = NULL;
    hiend   = false;
    crite   = 1e-15;
    critc   = 1e-12;
    critr   = 1e-8;
    ortho   = 1e-9;
    sum     = 0.;
    mblock  = 1;
    norm    = true;
    loop    = 0;
    inf     = false;
}
void UDavidson::DeleteAllMembers(ErrorType E)
{
    delete[] Diag;
    delete[] iselec;
    delete[] iwork;
    delete[] work;
}
UDavidson::UDavidson()
{
    SetAllMembersDefault();
}
UDavidson::~UDavidson()
{
    DeleteAllMembers(U_OK);
}
    
ErrorType UDavidson::ComputeEigen(int Neigen, bool Largest) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDavidson::ComputeEigen(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(this->IsSymmetric(1.e-13)!=true)
    {
        CI.AddToLog("ERROR: UDavidson::ComputeEigen(). Matrix is not symmetric. \n");
        return U_ERROR;
    }

    N       = this->GetNrow();
    hiend   = Largest;
    ilow    = 1;
    ihigh   = Neigen;
    if(ilow        <=0) ilow   = ihigh;
    if(ilow+ihigh-1> N) Neigen = N-ilow+1;

    nume    = Neigen;
    neig    = Neigen;
    numemax = Neigen;
    limmax  = numemax+20;
    lim     = limmax;
    iiwsz   = 6  *limmax + numemax;
    irwsz   = 2*N*limmax + limmax*limmax + (numemax+10)*limmax + numemax;
    maxiter = MAX( numemax*40, 200 );
    inf     = false;

    Diag    = GetDiagonal();
    iselec  = new int[limmax]; 
    iwork   = new int[iiwsz];
    work    = new double[irwsz];
    
    if(Diag==NULL || iselec==NULL || iwork==NULL || work==NULL)
    {
        delete[] iselec;
        delete[] iwork;
        delete[] work;
        CI.AddToLog("ERROR: UDavidson::ComputeEigen(). Getting diagonal or memory allocation error, N=%d, Neigen=%d.\n", N, Neigen);
        return U_ERROR;
    }
    for (int i=0; i<limmax; i++) iselec[i] =  0;
    for (int i=0; i<iiwsz ; i++) iwork[i]  =  0;
    for (int i=0; i<irwsz ; i++) work[i]   =0.0;

    if(Largest)  for(int i=0; i<Neigen; i++) iselec[i] =  Neigen-i;
    else         for(int i=0; i<Neigen; i++) iselec[i] =  i+1;


//set of initial vectors
////    if (Init) InitVectors();
////    CheckError(iselec);

//Assigning space for the real work arrays
    int  ibasis    =1,
         ieigval   =ibasis  +  N* lim,
         iab       =ieigval +     lim,
         is        =iab     +  N* lim,
         itemps    =is      +lim*(lim+1)/2,
         isvec     =itemps  +lim*(lim+1)/2,
         iscra1    =isvec   +lim*nume,
         ioldval   =iscra1  +8*lim,
         iscra2    =1,
         iscra3    =iscra2  +5*lim,
         iicv      =iscra3  +  lim;

    if(hiend) dscal(N,-1.0,Diag,1);
    int istart=niv;
    setup(N,lim,nume,hiend,&work[iscra1-1], &work[ibasis-1],&work[iab-1],&work[is-1],&istart);
    nmv = istart;
    
    dvdrvr(N,hiend,lim,mblock, nume,istart,neig,iselec,crite,critc,critr,
           ortho,maxiter,&work[ieigval-1],&work[ibasis-1],&work[iab-1],
           &work[is-1],&work[itemps-1],&work[isvec-1],&work[iscra1-1],
           &iwork[iscra2-1],&iwork[iscra3-1], &iwork[iicv-1],&work[ioldval-1],
           &nmv,&ierr, &loop, inf);
    if (hiend) 
    {
        dscal(N,-1.0,Diag,1);
        dscal(nume,-1.0,&work[ieigval-1],1);
    }
/*  -Copy the eigenvalues after the eigenvectors
*   -Next, copy the difference of eigenvalues between the last two steps  
*   -Next, copy the residuals for the first NUME estimates */
    dcopy(nume,&work[ieigval-1],1,&work[ibasis+ N   *nume-1],1);
    dcopy(nume,&work[ioldval-1],1,&work[ibasis+(N+1)*nume-1],1);
    dcopy(nume,&work[iscra1 -1],1,&work[ibasis+(N+2)*nume-1],1);

    for(int k=0; k<Neigen; k++)
    {
        double* E    = work + k*N;
        double  Norm = 0;
        for(int i=0; i<N; i++) Norm += E[i]*E[i];
        Norm = sqrt(fabs(Norm));
        for(int i=0; i<N; i++) E[i] /= Norm;
    }
    return U_OK;
}
const double* UDavidson::GetEigenVector(int ieigen) const
{
    return work + ieigen*N;
}
double UDavidson::GetEigenValue(int ieigen) const
{
    return work[nume*N+ieigen];
}
