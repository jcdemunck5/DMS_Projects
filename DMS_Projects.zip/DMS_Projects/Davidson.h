#ifndef _DAVIDSON_INCLUDED
#define _DAVIDSON_INCLUDED


#include "DavidsonBase.h"

class DLL_IO UDavidson : public UDavidsonBase
{
public:
    UDavidson(); 
    ~UDavidson();
    
    ErrorType           ComputeEigen(int Neigen, bool Largest);
    const double*       GetEigenVector(int ieigen) const;           
    double              GetEigenValue(int ieigen) const;           

protected: 
    virtual ErrorType   ComputeProduct(double* AB, const double* B, int Ncol) const =0;
    virtual double*     GetDiagonal(void) const =0;
    virtual int         GetNrow(void) const =0;
    virtual bool        IsSymmetric(double Tol) const =0;

    double*             Diag;
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
    const double*       GetSignedDiagonal(void) const {return Diag;}

private:
    ErrorType           error;
    int                 neig;
    int                 ierr;
    int                 ilow;
    int                 niv;
    int                 nmv;
    int                 ihigh;
    int                 iiwsz;
    int                 lim;
    int                 irwsz;
    int                 nume;
    int                 N;
    int                 numemax;
    int                 limmax;
    int*                iselec;
    int*                iwork;
    double*             work;
    bool                hiend;

    double              crite;
    double              critc;
    double              critr;
    double              ortho;
    double              sum;
    int                 maxiter;
    int                 mblock;
    bool                norm;
    int                 loop;
    bool                inf;

    double              suma(int n, double tab[]);
    ErrorType           ExecuteDavidson(void);
};

#endif //_DAVIDSON_INCLUDED
