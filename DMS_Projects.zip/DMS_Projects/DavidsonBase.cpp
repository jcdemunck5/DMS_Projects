/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Base class module for computing eigen values, eigen vectors of (sparse)   */
/*     symmetric matrices using the Davidson algorithm. The matrix vector        */
/*     multiplication should be defined in derived class.                        */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What 
  JdM    27-05-10   creation
  JdM    23-12-15   Bug Fix: ilaenv(). increased sizeof subnam[] to 8, in order to avoid overflow when second parameter is "dstebz " in call from dstebz()
*/


#include <math.h>
#include "DavidsonBase.h"

#ifndef MAX
#define MAX(x,y) (((x)>(y))? (x) : (y))
#endif
#ifndef MIN
#define MIN(x,y) (((x)<(y))? (x) : (y))
#endif

//---------------------------------------------------------------------------
void UDavidsonBase::addabs(int n, int lim, bool hiend, int kpass, int nncv,
            double basis[], double ab[], double s[]) const
/*-----------------------------------------------------------------------
*       Called by: DVDRVR, SETUP                                        
*                                                                       
*       Calculates the new column in the D matrix and the new column    
*       in the S matrix. The new D column is D(new)=AB(new). S has a    
*       new row and column, but being symmetric only the new column is  
*       stored. S(i,kpass+1)=B(i)^T D(kpass+1) for all i.               
*                                                                       
*       subroutines called:                                             
*       MatrixBase::dssbmv, DDOT, DSCAL
*
*   on entry                                                            
*   -------                                                             
*   N           The order of the matrix A                               
*   kpass       The current dimension of the expanding sub-basis        
*   NNCV        Number of new basis vectors.                            
*   Basis       the basis vectors, including the new NNCV ones.
*   diag        The object of MatrixBase class
*
*   on exit                                                             
*   -------                                                             
*   AB          The new matrix D=AB. (with new NNCV columns)            
*   S           The small matrix with NNCV new columns at the last part 
*-----------------------------------------------------------------------*/
{
// The user specified matrix-vector routine is called with the new
// basis vector B(*,kpass+1) and the result is assigned to AB(idstart)
    int idstart=kpass*n+1;

    this->ComputeProduct(&ab[idstart -1], &basis[idstart -1], nncv);

// If highest pairs are sought, use the negative of the matrix
    if (hiend) dscal(n*nncv,-1.0,&ab[idstart -1],1);

// The new S is calculated by adding the new last columns
// S(new)=B^T D(new).
    int isstart=kpass*(kpass+1)/2;
    for (int iv=1; iv<=nncv; iv++) {
        int ibstart=1;
        for (int ibv=1; ibv<=kpass+iv; ibv++) {
            s[isstart + ibv -1]=ddot(n,&basis[ibstart -1],1,&ab[idstart -1],1);
            ibstart+=n;
        }
        isstart += (kpass+iv);
        idstart += n;
    }
    return;
}
//---------------------------------------------------------------------------
double UDavidsonBase::dasum(int n,double dx[],int incx) const
{

/*   takes the sum of the absolute values.
     jack dongarra, linpack, 3/11/78.
     modified 3/93 to return if incx .le. 0.
     modified 12/3/93, array(1) declarations changed to array(*)  */

    double dtemp=0.0;
    int m,nincx;

    if ((n<=0) || (incx<=0)) return 0;
    if (incx!=1){
        //code for increment not equal to 1
        nincx = n*incx;
        for (int i=1;i<=nincx;i+=incx)
            dtemp += fabs(dx[i-1]);
        return dtemp;
    }
/*      code for increment equal to 1

        clean-up loop  */
    m=n%6;
    if (m){
        for (int i=1;i<=m;i++) dtemp += fabs(dx[i-1]);
        if (n<6) return dtemp;
    }
    for (int i=m+1;i<=n;i+=6)
        dtemp += fabs(dx[i-1]) + fabs(dx[i]) + fabs(dx[i+1])
                 + fabs(dx[i+2]) + fabs(dx[i+3]) + fabs(dx[i+4]);

    return dtemp;
}
//---------------------------------------------------------------------------
void UDavidsonBase::daxpy(int n, double da, double dx[], int incx, double dy[], int incy) const
{
/*   constant times a vector plus a vector.
     uses unrolled loops for increments equal to one.
     jack dongarra, linpack, 3/11/78.
     modified 12/3/93, array(1) declarations changed to array(*) */

      if (n<=0) return;
      if (da==0.0) return;
      if (!(incx==1 && incy==1)){
         //code for unequal increments or equal increments
         //not equal to 1
         int ix=1, iy=1;
         if (incx<0) ix=(-n+1)*incx+1;
         if (incy<0) iy=(-n+1)*incy+1;
         for (int i=1; i<=n; i++){
                dy[iy-1] += da*dx[ix-1];
            ix += incx;
            iy += incy;
         }
         return;
      }
//    code for both increments equal to 1

//    clean-up loop
      int m=n%4;
      if (m){
         for (int i=1; i<=m; i++) dy[i-1]+=da*dx[i-1];
         if (n<4) return;
      }
      for (int i=m + 1; i<=n; i+=4){
            dy[i-1] += da*dx[i-1];
            dy[i] += da*dx[i];
            dy[i + 1] += da*dx[i + 1];
            dy[i + 2] += da*dx[i + 2];
      }

      return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dcopy(int n, double dx[], int incx, double dy[], int incy) const
{
/*   copies a vector, x, to a vector, y.
     uses unrolled loops for increments equal to one.
     jack dongarra, linpack, 3/11/78.
     modified 12/3/93, array(1) declarations changed to array(*) */

    if (n<=0) return;
    if (!(incx==1 && incy==1)){
        //code for unequal increments or equal increments
        //not equal to 1
        int ix=1,iy=1;
        if (incx<0) ix=(-n+1)*incx+1;
        if (incy<0) iy=(-n+1)*incy+1;
        for (int i=1; i<=n; i++){
            dy[iy-1]=dx[ix-1];
            ix+=incx;
            iy+=incy;
        }
        return;
    }
//  code for both increments equal to 1
//
//  clean-up loop
    int m=n%7;
    if (m){
        for (int i=1; i<=m; i++) dy[i-1]=dx[i-1];
        if (n<7) return;
    }
    for (int i=m+1; i<=n; i+=7){
        dy[i-1] = dx[i-1];
        dy[i] = dx[i];
        dy[i + 1] = dx[i + 1];
        dy[i + 2] = dx[i + 2];
        dy[i + 3] = dx[i + 3];
        dy[i + 4] = dx[i + 4];
        dy[i + 5] = dx[i + 5];
    }
    return;
}
//---------------------------------------------------------------------------
double UDavidsonBase::ddot(int n, double dx[], int incx, double dy[], int incy) const
{
/*   forms the dot product of two vectors.
     uses unrolled loops for increments equal to one.
     jack dongarra, linpack, 3/11/78.
     modified 12/3/93, array(1) declarations changed to array(*) */

    double dtemp=0.0;

    if (n<=0) return 0.0;
    if (!(incx==1 && incy==1)){
        //code for unequal increments or equal increments
        //not equal to 1
        int ix=1, iy=1;
        if (incx<0) ix = (-n+1)*incx + 1;
        if (incy<0) iy = (-n+1)*incy + 1;
        for (int i=1; i<=n; i++){
            dtemp += dx[ix -1]*dy[iy -1];
            ix += incx;
        iy += incy;
        }
        return dtemp;
    }
//  code for both increments equal to 1
//
//  clean-up loop
    int m=n%5;
    if (m){
            for (int i=1; i<=m; i++) dtemp += dx[i -1]*dy[i -1];
            if (n<5) return dtemp;
    }
    for (int i=m + 1; i<=n; i+=5)
        dtemp += dx[i -1]*dy[i -1] + dx[i]*dy[i] + dx[i + 1]*dy[i + 1]
                 + dx[i + 2]*dy[i + 2] + dx[i + 3]*dy[i + 3];
    return dtemp;
}
//---------------------------------------------------------------------------
#define a(j,i) a[((((i)-1)*(lda))+((j)-1))]

void UDavidsonBase::dgemv(char trans, int m, int n, double alpha, double a[], int lda,
       double x[], int incx, double beta, double y[], int incy ) const
/*  Purpose
*  =======
*
*  DGEMV  performs one of the matrix-vector operations
*
*     y := alpha*A*x + beta*y,   or   y := alpha*A'*x + beta*y,
*
*  where alpha and beta are scalars, x and y are vectors and A is an
*  m by n matrix.
*
*  Parameters
*  ==========
*
*  TRANS  - CHARACTER*1.
*           On entry, TRANS specifies the operation to be performed as
*           follows:
*
*              TRANS = 'N' or 'n'   y := alpha*A*x + beta*y.
*
*              TRANS = 'T' or 't'   y := alpha*A'*x + beta*y.
*
*              TRANS = 'C' or 'c'   y := alpha*A'*x + beta*y.
*
*           Unchanged on exit.
*
*  M      - INTEGER.
*           On entry, M specifies the number of rows of the matrix A.
*           M must be at least zero.
*           Unchanged on exit.
*
*  N      - INTEGER.
*           On entry, N specifies the number of columns of the matrix A.
*           N must be at least zero.
*           Unchanged on exit.
*
*  ALPHA  - DOUBLE PRECISION.
*           On entry, ALPHA specifies the scalar alpha.
*           Unchanged on exit.
*
*  A      - DOUBLE PRECISION array of DIMENSION ( LDA, n ).
*           Before entry, the leading m by n part of the array A must
*           contain the matrix of coefficients.
*           Unchanged on exit.
*
*  LDA    - INTEGER.
*           On entry, LDA specifies the first dimension of A as declared
*           in the calling (sub) program. LDA must be at least
*           max( 1, m ).
*           Unchanged on exit.
*
*  X      - DOUBLE PRECISION array of DIMENSION at least
*           ( 1 + ( n - 1 )*abs( INCX ) ) when TRANS = 'N' or 'n'
*           and at least
*           ( 1 + ( m - 1 )*abs( INCX ) ) otherwise.
*           Before entry, the incremented array X must contain the
*           vector x.
*           Unchanged on exit.
*
*  INCX   - INTEGER.
*           On entry, INCX specifies the increment for the elements of
*           X. INCX must not be zero.
*           Unchanged on exit.
*
*  BETA   - DOUBLE PRECISION.
*           On entry, BETA specifies the scalar beta. When BETA is
*           supplied as zero then Y need not be set on input.
*           Unchanged on exit.
*
*  Y      - DOUBLE PRECISION array of DIMENSION at least
*           ( 1 + ( m - 1 )*abs( INCY ) ) when TRANS = 'N' or 'n'
*           and at least
*           ( 1 + ( n - 1 )*abs( INCY ) ) otherwise.
*           Before entry with BETA non-zero, the incremented array Y
*           must contain the vector y. On exit, Y is overwritten by the
*           updated vector y.
*
*  INCY   - INTEGER.
*           On entry, INCY specifies the increment for the elements of
*           Y. INCY must not be zero.
*           Unchanged on exit.
*
*
*  Level 2 Blas routine.
*
*  -- Written on 22-October-1986.
*     Jack Dongarra, Argonne National Lab.
*     Jeremy Du Croz, Nag Central Office.
*     Sven Hammarling, Nag Central Office.
*     Richard Hanson, Sandia National Labs.    */
{
    double temp;
    int info=0, ix, iy, jx, jy, kx, ky, lenx, leny;

    //Test the input parameters.
    if (!lsame(trans,'n') && !lsame(trans,'t') && !lsame(trans,'c'))
        info=1;
    else if (m<0) info=2;
        else if (n<0) info=3;
         else if (lda<MAX(1,m)) info=6;
                else if (!incx) info=8;
                     else if (!incy) info=11;
    if (info){
////        xerbla("dgemv ", info);
        return;
    }
    //Quick return if possible.
    if ((!m) || (!n) || ((!alpha) && (beta==1.0))) return;

    //Set  LENX  and  LENY, the lengths of the vectors x and y, and set
    //up the start points in  X  and  Y.
    if (lsame(trans,'N')){
        lenx = n;
        leny = m;
    } else {
        lenx = m;
        leny = n;
    }
    if (incx>0) kx=1;
        else kx=1-(lenx-1)*incx;
    if (incy>0) ky=1;
        else ky=1-(leny-1)*incy;

/*   Start the operations. In this version the elements of A are
     accessed sequentially with one pass through A.

     First form  y := beta*y.              */
    if (beta!=1.0)
        if (incy==1){
           if (!beta)
                for (int i=1; i<=leny; i++) y[i -1]=0;
           else
                for (int i=1; i<=leny; i++) y[i -1]=beta*y[i -1];
        } else {
               iy = ky;
               if (!beta)
                  for (int i=1; i<=leny; i++){
                      y[iy -1] = 0;
                      iy += incy;
                  }
               else {
                    for (int i=1; i<=leny; i++){
                        y[iy -1] = beta*y[iy -1];
                        iy += incy;
                    }
               }
        }
    if (!alpha) return;
    if (lsame(trans, 'n')){
//  Form  y := alpha*A*x + y.
       jx=kx;
       if (incy==1){
        for (int j=1; j<=n; j++){
               if (x[jx -1]){
                 temp=alpha*x[jx -1];
                   for (int i=1; i<=m; i++) y[i -1]+=temp*a(i,j);
               }
               jx += incx;
           }
       } else {
           for (int j=1; j<=n; j++){
               if (x[jx -1]){
                   temp=alpha*x[jx -1];
                   iy=ky;
                   for (int i=1; i<=m; i++){
                       y[iy -1]+=temp*a(i,j);
                       iy+=incy;
                   }
               }
               jx+=incx;
           }
       }
    } else {
        //Form  y := alpha*A'*x + y.
        jy=ky;
        if (incx==1){
           for (int j=1; j<=n; j++){
                temp=0;
                for (int i=1; i<=m; i++) temp+=a(i,j)*x[i -1];
                y[jy -1]+=alpha*temp;
                jy+=incy;
           }
        } else {
               for (int j=1; j<=n; j++){
                   temp=0;
                   ix=kx;
                   for (int i=1; i<=m; i++){
                       temp+=a(i,j)*x[ix -1];
                       ix+=incx;
                   }
                   y[jy -1]+=alpha*temp;
                   jy+=incy;
                }
        }
    }
    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
#define a(j,i) a[((((i)-1)*(lda))+((j)-1))]

void UDavidsonBase::dger(int  m, int n, double alpha, double x[], int incx, double y[],
          int incy, double a[], int lda ) const
/*  Purpose
*  =======
*
*  DGER   performs the rank 1 operation
*
*     A := alpha*x*y' + A,
*
*  where alpha is a scalar, x is an m element vector, y is an n element
*  vector and A is an m by n matrix.
*
*  Parameters
*  ==========
*
*  M      - INTEGER.
*           On entry, M specifies the number of rows of the matrix A.
*           M must be at least zero.
*           Unchanged on exit.
*
*  N      - INTEGER.
*           On entry, N specifies the number of columns of the matrix A.
*           N must be at least zero.
*           Unchanged on exit.
*
*  ALPHA  - DOUBLE PRECISION.
*           On entry, ALPHA specifies the scalar alpha.
*           Unchanged on exit.
*
*  X      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( m - 1 )*abs( INCX ) ).
*           Before entry, the incremented array X must contain the m
*           element vector x.
*           Unchanged on exit.
*
*  INCX   - INTEGER.
*           On entry, INCX specifies the increment for the elements of
*           X. INCX must not be zero.
*           Unchanged on exit.
*
*  Y      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( n - 1 )*abs( INCY ) ).
*           Before entry, the incremented array Y must contain the n
*           element vector y.
*           Unchanged on exit.
*
*  INCY   - INTEGER.
*           On entry, INCY specifies the increment for the elements of
*           Y. INCY must not be zero.
*           Unchanged on exit.
*
*  A      - DOUBLE PRECISION array of DIMENSION ( LDA, n ).
*           Before entry, the leading m by n part of the array A must
*           contain the matrix of coefficients. On exit, A is
*           overwritten by the updated matrix.
*
*  LDA    - INTEGER.
*           On entry, LDA specifies the first dimension of A as declared
*           in the calling (sub) program. LDA must be at least
*           max( 1, m ).
*           Unchanged on exit.
*
*
*  Level 2 Blas routine.
*
*  -- Written on 22-October-1986.
*     Jack Dongarra, Argonne National Lab.
*     Jeremy Du Croz, Nag Central Office.
*     Sven Hammarling, Nag Central Office.
*     Richard Hanson, Sandia National Labs.     */
{
    int info=0, ix, jy, kx;

    //Test the input parameters.
    if (m<0) info=1;
        else if (n<0) info=2;
            else if (!incx) info=5;
                else if (!incy) info=7;
                    else if (lda< MAX(1,m)) info=9;
    if (info){
////        xerbla("dger",info);
        return;
    }

    //Quick return if possible.
    if ((!m) || (!n) || (!alpha)) return;

//  Start the operations. In this version the elements of A are
//  accessed sequentially with one pass through A.
    if (incy>0) jy=1;
        else jy = 1 - ( n - 1 )*incy;
    if (incx==1){
        for (int j=1; j<=n; j++){
            if (y[jy -1]){
                double temp=alpha*y[jy -1];
                for (int i=1; i<=m; i++) a(i,j)+=x[i -1]*temp;
            }
            jy += incy;
        }
    } else {
        if (incx>0) kx=1;
            else kx = 1 - ( m - 1 )*incx;
        for (int j=1; j<=n; j++){
            if (y[jy -1]){
                double temp=alpha*y[jy -1];
                ix=kx;
                for (int i=1; i<=m; i++){
                    a(i,j) += x[ix -1]*temp;
                    ix     += incx;
                }
            }
            jy += incy;
        }
    }
    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
void UDavidsonBase::dinit(int n, double a, double x[], int incx ) const
/*=======================================================================
*       PURPOSE ... INITIALIZES DOUBLE PRECISION VECTOR TO              
*                   A CONSTANT VALUE 'A'                                
*=======================================================================*/
{
    if  ( incx == 1 )
        for (int i=1; i<=n; i++) x[i -1] = a;
    else {
        int xaddr = 1;
        if  ( incx < 0 ) xaddr = (-n+1)*incx + 1;
        for (int i=1; i<=n; i++) {
            x[xaddr -1] = a;
            xaddr += incx;
        }
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlae2(double a, double b, double c, double *rt1, double *rt2 ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992       */

/*  Purpose
*  =======
*
*  DLAE2  computes the eigenvalues of a 2-by-2 symmetric matrix
*     [  A   B  ]
*     [  B   C  ].
*  On return, RT1 is the eigenvalue of larger absolute value, and RT2
*  is the eigenvalue of smaller absolute value.
*
*  Arguments
*  =========
*
*  A       (input) DOUBLE PRECISION
*          The (1,1) element of the 2-by-2 matrix.
*
*  B       (input) DOUBLE PRECISION
*          The (1,2) and (2,1) elements of the 2-by-2 matrix.
*
*  C       (input) DOUBLE PRECISION
*          The (2,2) element of the 2-by-2 matrix.
*
*  RT1     (output) DOUBLE PRECISION
*          The eigenvalue of larger absolute value.
*
*  RT2     (output) DOUBLE PRECISION
*          The eigenvalue of smaller absolute value.
*
*  Further Details
*  ===============
*
*  RT1 is accurate to a few ulps barring over/underflow.
*
*  RT2 may be inaccurate if there is massive cancellation in the
*  determinant A*C-B*B; higher precision or correctly rounded or
*  correctly truncated arithmetic would be needed to compute RT2
*  accurately in all cases.
*
*  Overflow is possible only if RT1 is within a factor of 5 of overflow.
*  Underflow is harmless if the input data is 0 or exceeds
*     underflow_threshold / macheps.
*/
{
    double acmn=a, acmx=c, rt,
         sm = a + c, df = a - c, adf = fabs( df ), tb = b + b, ab = fabs( tb );

    //Compute the eigenvalues
    if (fabs(a)>fabs(c)){
        acmx = a;
        acmn = c;
    }
    if (adf>ab) rt = adf*sqrt( 1.0+( ab / adf )*( ab / adf ));
        else if (adf<ab) rt = ab*sqrt( 1.0+( adf / ab )*( adf / ab ));
            //Includes case AB=ADF=0
            else rt = ab*sqrt( 2.0 );
    if (sm<0) {
        *rt1 = 0.5*( sm-rt );

        /*Order of execution important.
        To get fully accurate smaller eigenvalue,
        next line needs to be executed in higher precision. */

        *rt2 = ( acmx / *rt1 )*acmn - ( b / *rt1 )*b;
    } else if (sm>0) {
        *rt1 = 0.5*( sm+rt );

        /*Order of execution important.
        To get fully accurate smaller eigenvalue,
        next line needs to be executed in higher precision.  */

        *rt2 = ( acmx / *rt1 )*acmn - ( b / *rt1 )*b;
    } else {
        //Includes case RT1 = RT2 = 0
        *rt1 = 0.5*rt;
        *rt2 = -0.5*rt;
    }
    return;
}
//---------------------------------------------------------------------------
#define ab(j,i) ab[((((i)-1)*(mmax))+((j)-1))]
#define nab(j,i) nab[((((i)-1)*(mmax))+((j)-1))]

void UDavidsonBase::dlaebz(int ijob, int nitmax, int n, int mmax, int minp,
            int nbmin, double abstol, double reltol, double pivmin, double d[],
            double e[], double e2[], int nval[], double ab[], double c[], int *mout,
            int nab[], double work[], int iwork[], int *info ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*  Purpose
*  =======
*
*  DLAEBZ contains the iteration loops which compute and use the
*  function N(w), which is the count of eigenvalues of a symmetric
*  tridiagonal matrix T less than or equal to its argument  w.  It
*  performs a choice of two types of loops:
*
*  IJOB=1, followed by
*  IJOB=2: It takes as input a list of intervals and returns a list of
*          sufficiently small intervals whose union contains the same
*          eigenvalues as the union of the original intervals.
*          The input intervals are (AB(j,1),AB(j,2)], j=1,...,MINP.
*          The output interval (AB(j,1),AB(j,2)] will contain
*          eigenvalues NAB(j,1)+1,...,NAB(j,2), where 1 <= j <= MOUT.
*
*  IJOB=3: It performs a binary search in each input interval
*          (AB(j,1),AB(j,2)] for a point  w(j)  such that
*          N(w(j))=NVAL(j), and uses  C(j)  as the starting point of
*          the search.  If such a w(j) is found, then on output
*          AB(j,1)=AB(j,2)=w.  If no such w(j) is found, then on output
*          (AB(j,1),AB(j,2)] will be a small interval containing the
*          point where N(w) jumps through NVAL(j), unless that point
*          lies outside the initial interval.
*
*  Note that the intervals are in all cases half-open intervals,
*  i.e., of the form  (a,b] , which includes  b  but not  a .
*
*  To avoid underflow, the matrix should be scaled so that its largest
*  element is no greater than  overflow**(1/2) * underflow**(1/4)
*  in absolute value.  To assure the most accurate computation
*  of small eigenvalues, the matrix should be scaled to be
*  not much smaller than that, either.
*
*  See W. Kahan "Accurate Eigenvalues of a Symmetric Tridiagonal
*  Matrix", Report CS41, Computer Science Dept., Stanford
*  University, July 21, 1966
*
*  Note: the arguments are, in general, *not* checked for unreasonable
*  values.
*
*  Arguments
*  =========
*
*  IJOB    (input) INTEGER
*          Specifies what is to be done:
*          = 1:  Compute NAB for the initial intervals.
*          = 2:  Perform bisection iteration to find eigenvalues of T.
*          = 3:  Perform bisection iteration to invert N(w), i.e.,
*                to find a point which has a specified number of
*                eigenvalues of T to its left.
*          Other values will cause DLAEBZ to return with INFO=-1.
*
*  NITMAX  (input) INTEGER
*          The maximum number of "levels" of bisection to be
*          performed, i.e., an interval of width W will not be made
*          smaller than 2^(-NITMAX) * W.  If not all intervals
*          have converged after NITMAX iterations, then INFO is set
*          to the number of non-converged intervals.
*
*  N       (input) INTEGER
*          The dimension n of the tridiagonal matrix T.  It must be at
*          least 1.
*
*  MMAX    (input) INTEGER
*          The maximum number of intervals.  If more than MMAX intervals
*          are generated, then DLAEBZ will quit with INFO=MMAX+1.
*
*  MINP    (input) INTEGER
*          The initial number of intervals.  It may not be greater than
*          MMAX.
*
*  NBMIN   (input) INTEGER
*          The smallest number of intervals that should be processed
*          using a vector loop.  If zero, then only the scalar loop
*          will be used.
*
*  ABSTOL  (input) DOUBLE PRECISION
*          The minimum (absolute) width of an interval.  When an
*          interval is narrower than ABSTOL, or than RELTOL times the
*          larger (in magnitude) endpoint, then it is considered to be
*          sufficiently small, i.e., converged.  This must be at least
*          zero.
*
*  RELTOL  (input) DOUBLE PRECISION
*          The minimum relative width of an interval.  When an interval
*          is narrower than ABSTOL, or than RELTOL times the larger (in
*          magnitude) endpoint, then it is considered to be
*          sufficiently small, i.e., converged.  Note: this should
*          always be at least radix*machine epsilon.
*
*  PIVMIN  (input) DOUBLE PRECISION
*          The minimum absolute value of a "pivot" in the Sturm
*          sequence loop.  This *must* be at least  max |e(j)**2| *
*          safe_min  and at least safe_min, where safe_min is at least
*          the smallest number that can divide one without overflow.
*
*  D       (input) DOUBLE PRECISION array, dimension (N)
*          The diagonal elements of the tridiagonal matrix T.
*
*  E       (input) DOUBLE PRECISION array, dimension (N)
*          The offdiagonal elements of the tridiagonal matrix T in
*          positions 1 through N-1.  E(N) is arbitrary.
*
*  E2      (input) DOUBLE PRECISION array, dimension (N)
*          The squares of the offdiagonal elements of the tridiagonal
*          matrix T.  E2(N) is ignored.
*
*  NVAL    (input/output) INTEGER array, dimension (MINP)
*          If IJOB=1 or 2, not referenced.
*          If IJOB=3, the desired values of N(w).  The elements of NVAL
*          will be reordered to correspond with the intervals in AB.
*          Thus, NVAL(j) on output will not, in general be the same as
*          NVAL(j) on input, but it will correspond with the interval
*          (AB(j,1),AB(j,2)] on output.
*
*  AB      (input/output) DOUBLE PRECISION array, dimension (MMAX,2)
*          The endpoints of the intervals.  AB(j,1) is  a(j), the left
*          endpoint of the j-th interval, and AB(j,2) is b(j), the
*          right endpoint of the j-th interval.  The input intervals
*          will, in general, be modified, split, and reordered by the
*          calculation.
*
*  C       (input/output) DOUBLE PRECISION array, dimension (MMAX)
*          If IJOB=1, ignored.
*          If IJOB=2, workspace.
*          If IJOB=3, then on input C(j) should be initialized to the
*          first search point in the binary search.
*
*  MOUT    (output) INTEGER
*          If IJOB=1, the number of eigenvalues in the intervals.
*          If IJOB=2 or 3, the number of intervals output.
*          If IJOB=3, MOUT will equal MINP.
*
*  NAB     (input/output) INTEGER array, dimension (MMAX,2)
*          If IJOB=1, then on output NAB(i,j) will be set to N(AB(i,j)).
*          If IJOB=2, then on input, NAB(i,j) should be set.  It must
*             satisfy the condition:
*             N(AB(i,1)) <= NAB(i,1) <= NAB(i,2) <= N(AB(i,2)),
*             which means that in interval i only eigenvalues
*             NAB(i,1)+1,...,NAB(i,2) will be considered.  Usually,
*             NAB(i,j)=N(AB(i,j)), from a previous call to DLAEBZ with
*             IJOB=1.
*             On output, NAB(i,j) will contain
*             max(na(k),min(nb(k),N(AB(i,j)))), where k is the index of
*             the input interval that the output interval
*             (AB(j,1),AB(j,2)] came from, and na(k) and nb(k) are the
*             the input values of NAB(k,1) and NAB(k,2).
*          If IJOB=3, then on output, NAB(i,j) contains N(AB(i,j)),
*             unless N(w) > NVAL(i) for all search points  w , in which
*             case NAB(i,1) will not be modified, i.e., the output
*             value will be the same as the input value (modulo
*             reorderings -- see NVAL and AB), or unless N(w) < NVAL(i)
*             for all search points  w , in which case NAB(i,2) will
*             not be modified.  Normally, NAB should be set to some
*             distinctive value(s) before DLAEBZ is called.
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (MMAX)
*          Workspace.
*
*  IWORK   (workspace) INTEGER array, dimension (MMAX)
*          Workspace.
*
*  INFO    (output) INTEGER
*          = 0:       All intervals converged.
*          = 1--MMAX: The last INFO intervals did not converge.
*          = MMAX+1:  More than MMAX intervals were generated.
*
*  Further Details
*  ===============
*
*      This routine is intended to be called only by other LAPACK
*  routines, thus the interface is less user-friendly.  It is intended
*  for two purposes:
*
*  (a) finding eigenvalues.  In this case, DLAEBZ should have one or
*      more initial intervals set up in AB, and DLAEBZ should be called
*      with IJOB=1.  This sets up NAB, and also counts the eigenvalues.
*      Intervals with no eigenvalues would usually be thrown out at
*      this point.  Also, if not all the eigenvalues in an interval i
*      are desired, NAB(i,1) can be increased or NAB(i,2) decreased.
*      For example, set NAB(i,1)=NAB(i,2)-1 to get the largest
*      eigenvalue.  DLAEBZ is then called with IJOB=2 and MMAX
*      no smaller than the value of MOUT returned by the call with
*      IJOB=1.  After this (IJOB=2) call, eigenvalues NAB(i,1)+1
*      through NAB(i,2) are approximately AB(i,1) (or AB(i,2)) to the
*      tolerance specified by ABSTOL and RELTOL.
*
*  (b) finding an interval (a',b'] containing eigenvalues w(f),...,w(l).
*      In this case, start with a Gershgorin interval  (a,b).  Set up
*      AB to contain 2 search intervals, both initially (a,b).  One
*      NVAL element should contain  f-1  and the other should contain  l
*      , while C should contain a and b, resp.  NAB(i,1) should be -1
*      and NAB(i,2) should be N+1, to flag an error if the desired
*      interval does not lie in (a,b).  DLAEBZ is then called with
*      IJOB=3.  On exit, if w(f-1) < w(f), then one of the intervals --
*      j -- will have AB(j,1)=AB(j,2) and NAB(j,1)=NAB(j,2)=f-1, while
*      if, to the specified tolerance, w(f-k)=...=w(f+r), k > 0 and r
*      >= 0, then the interval will have  N(AB(j,1))=NAB(j,1)=f-k and
*      N(AB(j,2))=NAB(j,2)=f+r.  The cases w(l) < w(l+1) and
*      w(l-r)=...=w(l+k) are handled similarly.
*/
{
    int itmp1, itmp2, kfnew, klnew;
    double tmp1, tmp2;

    //Check for Errors
    *info = 0;
    if (ijob<1 || ijob>3) {
        *info = -1;
        return;
    }

    if( ijob==1 ) {
        //Compute the number of eigenvalues in the initial intervals.
        *mout = 0;
        for (int ji=1; ji<=minp; ji++) {
            for (int jp=1; jp<=2; jp++) {
                tmp1 = d[1 -1] - ab(ji,jp);
                if (fabs( tmp1 )<pivmin) tmp1 = -pivmin;
                nab(ji,jp) = 0;
                if (tmp1<=0.0)  nab(ji,jp) = 1;
                for (int j=2; j<=n; j++) {
                    tmp1 = d[j -1] - e2[j-1 -1] / tmp1 -  ab(ji,jp);
                    if (fabs( tmp1 )<pivmin) tmp1 = -pivmin;
                    if (tmp1<=0.0)  nab(ji,jp)++;
                }
            }
            *mout = *mout +  nab(ji,2) - nab(ji,1);
        }
        return;
    }

/*    Initialize for loop
*
*     KF and KL have the following meaning:
*        Intervals 1,...,KF-1 have converged.
*        Intervals KF,...,KL  still need to be refined.    */
    int kf = 1,
         kl = minp;

/*    If IJOB=2, initialize C.
*     If IJOB=3, use the user-supplied starting point. */
    if (ijob==2)
        for (int ji=1; ji<=minp; ji++) c[ji -1] = 0.5*( ab(ji,1)+ab(ji,2) );

    //Iteration loop
    for (int jit=1; jit<=nitmax; jit++) {
        //Loop over intervals
        if ( (kl-kf+1)>=nbmin && nbmin>0) {
            //Begin of Parallel Version of the loop
            for (int ji=kf; ji<=kl; ji++) {
                //Compute N(c), the number of eigenvalues less than c
                work[ji -1] = d[1 -1] - c[ji -1];
                iwork[ji -1] = 0;
                if( work[ji -1]<=pivmin ) {
                    iwork[ji -1] = 1;
                    work[ji -1] = MIN( work[ji -1], -pivmin );
                }
                for (int j=2; j<=n; j++) {
                        work[ji -1] = d[j -1] - e2[j-2] / work[ji -1] - c[ji -1];
                        if (work[ji -1]<=pivmin) {
                            iwork[ji -1] = iwork[ji -1] + 1;
                            work[ji -1] = MIN( work[ji -1], -pivmin );
                        }
                }
            }
            if (ijob<=2) {
                //IJOB=2: Choose all intervals containing eigenvalues.
                klnew = kl;
                for (int ji=kf; ji<=kl; ji++){
                    //Insure that N(w) is monotone
                    iwork[ji -1] = MIN( nab(ji,2), (MAX( nab(ji,1), iwork[ji -1] )) );
                    //Update the Queue -- add intervals if both halves
                    //contain eigenvalues.
                    if (iwork[ji -1]==nab(ji,2))
                            //No eigenvalue in the upper interval:
                            //just use the lower interval.
                            ab(ji,2)=c[ji -1];
                        else if (iwork[ji -1]==nab(ji,1))
                                //No eigenvalue in the lower interval:
                                //just use the upper interval.
                                ab(ji,1) = c[ji -1];
                            else {
                                klnew = klnew + 1;
                                if (klnew<=mmax) {
                                    //Eigenvalue in both intervals -- add upper to
                                    //queue.
                                    ab(klnew,2)=ab(ji,2);
                                    nab(klnew,2)=nab(ji,2);
                                    ab(klnew,1)=c[ji -1];
                                    nab(klnew,1)=iwork[ji -1];
                                    ab(ji,2)=c[ji -1];
                                    nab(ji,2)=iwork[ji -1];
                                } else *info = mmax + 1;
                            }
                }
                if (*info!=0) return;
                kl = klnew;
            } else {
                //IJOB=3: Binary search.  Keep only the interval containing
                //w   s.t. N(w) = NVAL
                for (int ji=kf; ji<=kl; ji++) {
                    if (iwork[ji -1]<=nval[ji -1]) {
                        ab(ji,1) = c[ji -1];
                        nab(ji,1) = iwork[ji -1];
                    }
                    if (iwork[ji -1]>=nval[ji -1]) {
                        ab(ji,2) = c[ji -1];
                        nab(ji,2) = iwork[ji -1];
                    }
                }
            }
        } else {
            //End of Parallel Version of the loop
            //Begin of Serial Version of the loop
            klnew = kl;
            for (int ji=kf; ji<=kl; ji++) {
                tmp1 = c[ji -1];
                tmp2 = d[1 -1] - tmp1;
                itmp1 = 0;
                if (tmp2<=pivmin) {
                    itmp1 = 1;
                    tmp2 = MIN( tmp2, (-pivmin) );
                }
                //A series of compiler directives to defeat vectorization
                //for the next loop
                for (int j=2; j<=n; j++) {
                    tmp2 = d[j -1] - e2[j-2] / tmp2 - tmp1;
                    if (tmp2<=pivmin) {
                        ++itmp1;
                        tmp2 = MIN( tmp2, (-pivmin) );
                    }
                }
                if (ijob<=2) {
                    //IJOB=2: Choose all intervals containing eigenvalues.
                    //Insure that N(w) is monotone
                    itmp1 = MIN( nab(ji,2),MAX( nab(ji,1), itmp1 ) );
                    //Update the Queue -- add intervals if both halves
                    //contain eigenvalues.
                    if (itmp1==nab(ji,2))
                            //No eigenvalue in the upper interval:
                            //just use the lower interval.
                            ab(ji,2) = tmp1;
                        else if (itmp1==nab(ji,1))
                                //No eigenvalue in the lower interval:
                                //just use the upper interval.
                                ab(ji,1) = tmp1;
                            else if (klnew<mmax) {
                                //Eigenvalue in both intervals -- add upper to queue.
                                klnew++;
                                ab(klnew,2)=ab(ji,2);
                                nab(klnew,2)=nab(ji,2);
                                ab(klnew,1)=tmp1;
                                nab(klnew,1)=itmp1;
                                ab(ji,2)=tmp1;
                                nab(ji,2)=itmp1;
                            } else {
                                *info = mmax + 1;
                                return;
                            }
                } else {
                    //IJOB=3: Binary search.  Keep only the interval
                    //containing  w  s.t. N(w) = NVAL
                    if (itmp1<=nval[ji -1]) {
                        ab(ji,1) = tmp1;
                        nab(ji,1) = itmp1;
                    }
                    if( itmp1>=nval[ji -1] ) {
                        ab(ji,2) = tmp1;
                        nab(ji,2) = itmp1;
                    }
                }
            }
            kl = klnew;
            //End of Serial Version of the loop
        }
        //Check for convergence
        kfnew = kf;
        for (int ji=kf; ji<=kl; ji++) {
            tmp1 = fabs( ab(ji,2)-ab(ji,1) );
            tmp2 = MAX( fabs( ab(ji,2) ), fabs( ab(ji,1) ) );
            if (tmp1<(MAX( (MAX(abstol, pivmin)), reltol*tmp2 )) || nab(ji,1)>=nab(ji,2) ) {
                //Converged -- Swap with position KFNEW,
                //then increment KFNEW
                if (ji>kfnew) {
                    tmp1 = ab(ji,1);
                    tmp2 = ab(ji,2);
                    itmp1 = nab(ji,1);
                    itmp2 = nab(ji,2);
                    ab(ji,1) = ab(kfnew,1);
                    ab(ji,2) = ab(kfnew,2);
                    nab(ji,1) = nab(kfnew,1);
                    nab(ji,2) = nab(kfnew,2);
                    ab(kfnew,1) = tmp1;
                    ab(kfnew,2) = tmp2;
                    nab(kfnew,1) = itmp1;
                    nab(kfnew,2) = itmp2;
                    if (ijob==3){
                        itmp1 = nval[ji -1];
                        nval[ji -1] = nval[kfnew -1];
                        nval[kfnew -1] = itmp1;
                    }
                }
                kfnew++;
            }
        }
        kf = kfnew;
        //Choose Midpoints
        for (int ji=kf; ji<=kl; ji++) c[ji -1]=0.5*( ab(ji,1)+ab(ji,2) );
        //If no more intervals to refine, quit.
        if (kf>kl) {
            *info = MAX( kl+1-kf, 0 );
            *mout = kl;
            return;
        }
    }
    //Converged
    *info = MAX( kl+1-kf, 0 );
    *mout = kl;

    return;
}

#undef ab  //(j,i)
#undef nab //(j,i)
//---------------------------------------------------------------------------
void UDavidsonBase::dlaev2(double a, double b, double c, double *rt1, double *rt2,
            double *cs1, double *sn1) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAEV2 computes the eigendecomposition of a 2-by-2 symmetric matrix
*     [  A   B  ]
*     [  B   C  ].
*  On return, RT1 is the eigenvalue of larger absolute value, RT2 is the
*  eigenvalue of smaller absolute value, and (CS1,SN1) is the unit right
*  eigenvector for RT1, giving the decomposition
*
*     [ CS1  SN1 ] [  A   B  ] [ CS1 -SN1 ]  =  [ RT1  0  ]
*     [-SN1  CS1 ] [  B   C  ] [ SN1  CS1 ]     [  0  RT2 ].
*
*  Arguments
*  =========
*
*  A       (input) DOUBLE PRECISION
*          The (1,1) element of the 2-by-2 matrix.
*
*  B       (input) DOUBLE PRECISION
*          The (1,2) element and the conjugate of the (2,1) element of
*          the 2-by-2 matrix.
*
*  C       (input) DOUBLE PRECISION
*          The (2,2) element of the 2-by-2 matrix.
*
*  RT1     (output) DOUBLE PRECISION
*          The eigenvalue of larger absolute value.
*
*  RT2     (output) DOUBLE PRECISION
*          The eigenvalue of smaller absolute value.
*
*  CS1     (output) DOUBLE PRECISION
*  SN1     (output) DOUBLE PRECISION
*          The vector (CS1, SN1) is a unit right eigenvector for RT1.
*
*  Further Details
*  ===============
*
*  RT1 is accurate to a few ulps barring over/underflow.
*
*  RT2 may be inaccurate if there is massive cancellation in the
*  determinant A*C-B*B; higher precision or correctly rounded or
*  correctly truncated arithmetic would be needed to compute RT2
*  accurately in all cases.
*
*  CS1 and SN1 are accurate to a few ulps barring over/underflow.
*
*  Overflow is possible only if RT1 is within a factor of 5 of overflow.
*  Underflow is harmless if the input data is 0 or exceeds
*     underflow_threshold / macheps.
*/
{
    double acmn=a, acmx=c, acs, cs, ct, rt, tn,
         sm = a + c, df = a - c, adf = fabs( df ), tb = b + b, ab = fabs( tb );
    int sgn1, sgn2;

    //Compute the eigenvalues
    if (fabs(a)>fabs(c)) {
        acmx = a;
        acmn = c;
    }
    if (adf>ab) rt = adf*sqrt( 1.0+( ab / adf )*( ab / adf ));
        else if (adf<ab) rt = ab*sqrt( 1.0+( adf / ab )*( adf / ab ));
            else
                //Includes case AB=ADF=0
                rt = ab*sqrt( 2.0 );
    if (sm<0.0) {
        *rt1 = 0.5*( sm-rt );
        sgn1 = -1;
        /*Order of execution important.
          To get fully accurate smaller eigenvalue,
          next line needs to be executed in higher precision.  */
        *rt2 = ( acmx / *rt1 )*acmn - ( b / *rt1 )*b;
    } else if (sm>0.0) {
        *rt1 = 0.5*( sm+rt );
        sgn1 = 1;
        /*Order of execution important.
          To get fully accurate smaller eigenvalue,
          next line needs to be executed in higher precision.  */
        *rt2 = ( acmx / *rt1 )*acmn - ( b / *rt1 )*b;
    } else {
        //Includes case RT1 = RT2 = 0
        *rt1 = 0.5*rt;
        *rt2 = -0.5*rt;
        sgn1 = 1;
    }
    //Compute the eigenvector
    if (df>=0.0) {
        cs = df + rt;
        sgn2 = 1;
    } else {
        cs = df - rt;
        sgn2 = -1;
    }
    acs = fabs( cs );
    if (acs>ab) {
        ct = -tb / cs;
        *sn1 = 1.0 / sqrt( 1.0+ct*ct );
        *cs1 = ct**sn1;
    } else if (!ab) {
        *cs1 = 1.0;
        *sn1 = 0.0;
    } else {
        tn = -cs / tb;
        *cs1 = 1.0 / sqrt( 1.0+tn*tn );
        *sn1 = tn**cs1;
    }
    if (sgn1==sgn2) {
        tn = *cs1;
        *cs1 = -*sn1;
        *sn1 = tn;
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlagtf(int n, double a[], double lambda, double b[], double c[],
            double tol, double d[], int in[], int *info) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  DLAGTF factorizes the matrix (T - lambda*I), where T is an n by n
*  tridiagonal matrix and lambda is a scalar, as
*
*     T - lambda*I = PLU,
*
*  where P is a permutation matrix, L is a unit lower tridiagonal matrix
*  with at most one non-zero sub-diagonal elements per column and U is
*  an upper triangular matrix with at most two non-zero super-diagonal
*  elements per column.
*
*  The factorization is obtained by Gaussian elimination with partial
*  pivoting and implicit row scaling.
*
*  The parameter LAMBDA is included in the routine so that DLAGTF may
*  be used, in conjunction with DLAGTS, to obtain eigenvectors of T by
*  inverse iteration.
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The order of the matrix T.
*
*  A       (input/output) DOUBLE PRECISION array, dimension (N)
*          On entry, A must contain the diagonal elements of T.
*
*          On exit, A is overwritten by the n diagonal elements of the
*          upper triangular matrix U of the factorization of T.
*
*  LAMBDA  (input) DOUBLE PRECISION
*          On entry, the scalar lambda.
*
*  B       (input/output) DOUBLE PRECISION array, dimension (N-1)
*          On entry, B must contain the (n-1) super-diagonal elements of
*          T.
*
*          On exit, B is overwritten by the (n-1) super-diagonal
*          elements of the matrix U of the factorization of T.
*
*  C       (input/output) DOUBLE PRECISION array, dimension (N-1)
*          On entry, C must contain the (n-1) sub-diagonal elements of
*          T.
*
*          On exit, C is overwritten by the (n-1) sub-diagonal elements
*          of the matrix L of the factorization of T.
*
*  TOL     (input) DOUBLE PRECISION
*          On entry, a relative tolerance used to indicate whether or
*          not the matrix (T - lambda*I) is nearly singular. TOL should
*          normally be chose as approximately the largest relative error
*          in the elements of T. For example, if the elements of T are
*          correct to about 4 significant figures, then TOL should be
*          set to about 5*10**(-4). If TOL is supplied as less than eps,
*          where eps is the relative machine precision, then the value
*          eps is used in place of TOL.
*
*  D       (output) DOUBLE PRECISION array, dimension (N-2)
*          On exit, D is overwritten by the (n-2) second super-diagonal
*          elements of the matrix U of the factorization of T.
*
*  IN      (output) INTEGER array, dimension (N)
*          On exit, IN contains details of the permutation matrix P. If
*          an interchange occurred at the kth step of the elimination,
*          then IN(k) = 1, otherwise IN(k) = 0. The element IN(n)
*          returns the smallest positive integer j such that
*
*             abs( u(j,j) ).le. norm( (T - lambda*I)(j) )*TOL,
*
*          where norm( A(j) ) denotes the sum of the absolute values of
*          the jth row of the matrix A. If no such j exists then IN(n)
*          is returned as zero. If IN(n) is returned as positive, then a
*          diagonal element of U is small, indicating that
*          (T - lambda*I) is singular or nearly singular,
*
*  INFO    (output) INTEGER
*          = 0   : successful exit
*          .lt. 0: if INFO = -k, the kth argument had an illegal value
*/
{
    double piv1, piv2;

    *info=0;
    if (n<0) {
        *info=-1;
////        xerbla("dlagtf ",-*info);
        return;
    }
    if (!n) return;
    a[0] -= lambda;
    in[ n  -1] = 0;
    if (n==1)
        if (!a[0]) {
            in[0]=1;
            return;
        }
    double eps = dlamch( 'e' ),
         tl = MAX( tol, eps ),
         scale1 = fabs( a[0] ) + fabs( b[0] );
    for (int k=1; k<=n-1; k++) {
        a[k] -= lambda;
        double scale2 = fabs( c[ k  -1] ) + fabs( a[k] );
        if (k<(n-1)) scale2 += fabs( b[k] );
        if (!a[k -1]) piv1 = 0.0;
            else piv1 = fabs( a[ k  -1] ) / scale1;
        if (!c[k -1]) {
            in[k -1] = 0;
            piv2 = 0.0;
            scale1 = scale2;
            if (k<(n-1)) d[k -1]=0.0;
        } else {
            piv2 = fabs( c[k -1] ) / scale2;
            if (piv2<=piv1) {
                in[ k  -1] = 0;
                scale1 = scale2;
                c[ k  -1] /= a[ k  -1];
                a[k] -= c[ k  -1]*b[ k  -1];
                if (k<(n-1)) d[k -1]=0.0;
            } else {
                in[k -1]=1;
                double mult = a[ k  -1] / c[ k  -1],
                     temp = a[k];
                a[ k  -1] = c[ k  -1];
                a[k] = b[ k  -1] - mult*temp;
                if (k<(n-1)) {
                    d[ k  -1] = b[k];
                    b[k] = -mult*d[ k  -1];
                }
                b[ k  -1] = temp;
                c[ k  -1] = mult;
            }
        }
        if ((MAX(piv1,piv2)<=tl) && (!in[n -1])) in[n -1]=k;
    }
    if ((fabs(a[n -1])<=scale1*tl) && (!in[n -1])) in[n -1]=n;
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dladtsf(double *absak, double *ak, double *pert, double *temp,
             double one, double zero, double sfmin, double bignum) const
{
    *absak = fabs( *ak );
    if (*absak<one)
        if (*absak<sfmin){
            if ( (*absak==zero) || (fabs( *temp )*sfmin>*absak) ) {
                *ak += *pert;
                *pert *= 2;
                dladtsf(absak, ak, pert, temp, one, zero, sfmin, bignum);
            } else {
                *temp *= bignum;
                *ak *= bignum;
            }
        } else if ( fabs( *temp )>(*absak*bignum) ) {
            *ak += *pert;
            *pert *= 2;
            dladtsf(absak, ak, pert, temp, one, zero, sfmin, bignum);
        }
     return;
}


void UDavidsonBase::dlagts(int job, int n, double a[], double b[], double c[], double d[],
            int in[], double y[], double *tol, int *info ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAGTS may be used to solve one of the systems of equations
*
*     (T - lambda*I)*x = y   or   (T - lambda*I)'*x = y,
*
*  where T is an n by n tridiagonal matrix, for x, following the
*  factorization of (T - lambda*I) as
*
*     (T - lambda*I) = P*L*U ,
*
*  by routine DLAGTF. The choice of equation to be solved is
*  controlled by the argument JOB, and in each case there is an option
*  to perturb zero or very small diagonal elements of U, this option
*  being intended for use in applications such as inverse iteration.
*
*  Arguments
*  =========
*
*  JOB     (input) INTEGER
*          Specifies the job to be performed by DLAGTS as follows:
*          =  1: The equations  (T - lambda*I)x = y  are to be solved,
*                but diagonal elements of U are not to be perturbed.
*          = -1: The equations  (T - lambda*I)x = y  are to be solved
*                and, if overflow would otherwise occur, the diagonal
*                elements of U are to be perturbed. See argument TOL
*                below.
*          =  2: The equations  (T - lambda*I)'x = y  are to be solved,
*                but diagonal elements of U are not to be perturbed.
*          = -2: The equations  (T - lambda*I)'x = y  are to be solved
*                and, if overflow would otherwise occur, the diagonal
*                elements of U are to be perturbed. See argument TOL
*                below.
*
*  N       (input) INTEGER
*          The order of the matrix T.
*
*  A       (input) DOUBLE PRECISION array, dimension (N)
*          On entry, A must contain the diagonal elements of U as
*          returned from DLAGTF.
*
*  B       (input) DOUBLE PRECISION array, dimension (N-1)
*          On entry, B must contain the first super-diagonal elements of
*          U as returned from DLAGTF.
*
*  C       (input) DOUBLE PRECISION array, dimension (N-1)
*          On entry, C must contain the sub-diagonal elements of L as
*          returned from DLAGTF.
*
*  D       (input) DOUBLE PRECISION array, dimension (N-2)
*          On entry, D must contain the second super-diagonal elements
*          of U as returned from DLAGTF.
*
*  IN      (input) INTEGER array, dimension (N)
*          On entry, IN must contain details of the matrix P as returned
*          from DLAGTF.
*
*  Y       (input/output) DOUBLE PRECISION array, dimension (N)
*          On entry, the right hand side vector y.
*          On exit, Y is overwritten by the solution vector x.
*
*  TOL     (input/output) DOUBLE PRECISION
*          On entry, with  JOB .lt. 0, TOL should be the minimum
*          perturbation to be made to very small diagonal elements of U.
*          TOL should normally be chosen as about eps*norm(U), where eps
*          is the relative machine precision, but if TOL is supplied as
*          non-positive, then it is reset to eps*max( abs( u(i,j) ) ).
*          If  JOB .gt. 0  then TOL is not referenced.
*
*          On exit, TOL is changed as described above, only if TOL is
*          non-positive on entry. Otherwise TOL is unchanged.
*
*  INFO    (output) INTEGER
*          = 0   : successful exit
*          .lt. 0: if INFO = -i, the i-th argument had an illegal value
*          .gt. 0: overflow would occur when computing the INFO(th)
*                  element of the solution vector x. This can only occur
*                  when JOB is supplied as positive and either means
*                  that a diagonal element of U is very small, or that
*                  the elements of the right-hand side vector y are very
*                  large.
*/
{
    double absak, ak, pert, temp;

    *info = 0;
    if (( abs( job )>2 ) || ( !job )) *info = -1;
        else if (n<0) *info = -2;
    if (*info){
////            xerbla( "dlagts ", -*info );
            return;
    }
    if (!n) return;

    double eps = dlamch( 'e' ),
         sfmin = dlamch( 's' ),
         bignum = 1.0 / sfmin;

    if (job<0) {
        if (*tol<=0.0) {
            *tol = fabs( a[0] );
            if (n>1) *tol = MAX( (MAX(*tol, fabs(a[1]))), fabs(b[0]) );
            for (int k=3; k<=n; k++)
                *tol = MAX( (MAX(*tol, fabs(a[k -1]))), (MAX(fabs(b[k-2]),fabs(d[k-3]))) );
            *tol*=eps;
            if (!(*tol)) *tol = eps;
        }
    }
    if (abs( job )==1) {
        for (int k=2; k<=n; k++)
            if (!in[k-2]) y[k -1] = y[k -1] - c[k-2]*y[k-2];
                else {
                    temp = y[k-2];
                    y[k-2] = y[k -1];
                    y[k -1] = temp - c[k-2]*y[k -1];
                }
        if (job==1)
            for (int k=n; k>=1; k--) {
                if (k<=(n-2)) temp = y[k -1] - b[k -1]*y[k] - d[k -1]*y[k+1];
                    else if (k==(n-1)) temp = y[k -1] - b[k -1]*y[k];
                        else temp = y[k -1];
                ak = a[k -1];
                absak = fabs( ak );
                if (absak<1.0)
                    if (absak<sfmin) {
                        if ( !absak || (fabs( temp )*sfmin)>(absak) ) {
                            *info = k;
                            return;
                        } else {
                            temp *= bignum;
                            ak *= bignum;
                        }
                    } else if ( fabs( temp )>(absak*bignum) ) {
                        *info = k;
                        return;
                    }
                y[k -1] = temp / ak;
            }
        else {
            for (int k=n; k>=1; k--){
                if (k<=(n-2)) temp = y[k -1] - b[k -1]*y[k] - d[k -1]*y[k+1];
                    else if ( k==(n-1)) temp = y[k -1] - b[k -1]*y[k];
                        else temp = y[k -1];
                ak = a[k -1];
                pert = sign( tol, &ak );
                dladtsf(&absak, &ak, &pert, &temp, 1.0, 0.0, sfmin, bignum);
                y[k -1] = temp / ak;
            }
        }
    } else {
        //Come to here if  JOB = 2 or -2
        if (job==2)
            for (int k=1; k<=n; k++) {
                if (k>=3) temp = y[k -1] - b[k-2]*y[k-2] - d[k-3]*y[k-3];
                    else if (k==2) temp = y[k -1] - b[k-2]*y[k-2];
                        else temp = y[k -1];
                ak = a[k -1];
                absak = fabs( ak );
                if ( absak<1.0 )
                    if (absak<sfmin) {
                        if ( (!absak) || (fabs( temp )*sfmin>absak) ) {
                            *info = k;
                            return;
                        } else {
                            temp *= bignum;
                            ak *= bignum;
                        }
                    } else if ( fabs( temp )>absak*bignum ) {
                        *info = k;
                        return;
                    }
                y[k -1] = temp / ak;
            }
        else
            for (int k=1; k<=n; k++) {
                if (k>=3) temp = y[k -1] - b[k-2]*y[k-2] - d[k-3]*y[k-3];
                    else if (k==2) temp = y[k -1] - b[k-2]*y[k-2];
                        else temp = y[k -1];
                ak = a[k -1];
                pert = sign( tol, &ak );
                dladtsf(&absak, &ak, &pert, &temp, 1.0, 0.0, sfmin, bignum);
                y[k -1] = temp / ak;

            }
            for (int k=n; k>=2; k--) {
                if ( !in[k-2] ) y[k-2] -= c[k-2]*y[k -1];
                    else {
                        temp = y[k-2];
                        y[k-2] = y[k -1];
                        y[k -1] = temp - c[k-2]*y[k -1];
                    }
            }
    }
    return;
}
//---------------------------------------------------------------------------
/* DLAMC3  is intended to force  A  and  B  to be stored prior to doing
*  the addition of  A  and  B ,  for use in situations where optimizers
*  might hold one of these in a register.    */
#define dlamc3(a,b) ((a)+(b))

void UDavidsonBase::dlamc1(int *beta, int *t, bool *rnd, bool *ieee1 ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAMC1 determines the machine parameters given by BETA, T, RND, and
*  IEEE1.
*
*  Arguments
*  =========
*
*  BETA    (output) INTEGER
*          The base of the machine.
*
*  T       (output) INTEGER
*          The number of ( BETA ) digits in the mantissa.
*
*  RND     (output) LOGICAL
*          Specifies whether proper rounding  ( RND = .TRUE. )  or
*          chopping  ( RND = .FALSE. )  occurs in addition. This may not
*          be a reliable guide to the way in which the machine performs
*          its arithmetic.
*
*  IEEE1   (output) LOGICAL
*          Specifies whether rounding appears to be done in the IEEE
*          'round to nearest' style.
*
*  Further Details
*  ===============
*
*  The routine is based on the routine  ENVRON  by Malcolm and
*  incorporates suggestions by Gentleman and Marovich. See
*
*     Malcolm M. A. (1972) Algorithms to reveal properties of
*        floating-point arithmetic. Comms. of the ACM, 15, 949-951.
*
*     Gentleman W. M. and Marovich S. B. (1974) More on algorithms
*        that reveal properties of floating point arithmetic units.
*        Comms. of the ACM, 17, 276-277.
*/
{
    volatile static bool first=1, lieee1, lrnd;
    volatile static int lbeta, lt;
    volatile double a, b, c, f, one, qtr, savec, t1, t2;

    if (first) {
        first = 0;
        one = 1;
/*       LBETA,  LIEEE1,  LT and  LRND  are the  local values  of  BETA,
*        IEEE1, T and RND.
*
*        Throughout this routine  we use the function  DLAMC3  to ensure
*        that relevant values are  stored and not held in registers,  or
*        are not affected by optimizers.
*
*        Compute  a = 2.0**m  with the  smallest positive integer m such
*        that
*
*           fl( a + 1.0 ) = a.  */
        a = 1;
        c = 1;
        for (;;)
            if (c==one){
                a *= 2;
                c = dlamc3( a, one );
                c = dlamc3( c, -a );
            } else break;
/*      Now compute  b = 2.0**m  with the smallest positive integer m
*       such that
*
*       fl( a + b ) .gt. a.                 */
        b = 1;
        c = dlamc3( a, b );
        for (;;)
            if (c==a) {
                b *= 2;
                c = dlamc3( a, b );
            } else break;
/*        Now compute the base.  a and c  are neighbouring floating point
*        numbers  in the  interval  ( beta**t, beta**( t + 1 ) )  and so
*        their difference is beta. Adding 0.25 to c is to ensure that it
*        is truncated to beta and not ( beta - 1 ).  */
        qtr = one / 4;
        savec = c;
        c = dlamc3( c, -a );
        lbeta = int(c + qtr);
//      Now determine whether rounding or chopping occurs,  by adding a
//      bit  less  than  beta/2  and a  bit  more  than  beta/2  to  a.
        b = lbeta;
        f = dlamc3( b / 2, -b / 100 );
        c = dlamc3( f, a);
        if (c==a) lrnd = 1;
            else lrnd = 0;
        f = dlamc3( b / 2, b / 100 );
        c = dlamc3( f, a );
        if( ( lrnd ) && ( c==a ) ) lrnd = 0;
/*       Try and decide whether rounding is done in the  IEEE  'round to
*        nearest' style. B/2 is half a unit in the last place of the two
*        numbers A and SAVEC. Furthermore, A is even, i.e. has last  bit
*        zero, and SAVEC is odd. Thus adding B/2 to A should not  change
*        A, but adding B/2 to SAVEC should change SAVEC. */
        t1 = dlamc3( b / 2, a );
        t2 = dlamc3( b / 2, savec );
        lieee1 = ( t1==a ) && ( t2>savec ) && lrnd;
/*       Now find  the  mantissa, t.  It should  be the  integer part of
*        log to the base beta of a,  however it is safer to determine  t
*        by powering.  So we find t as the smallest positive integer for
*        which
*
*           fl( beta**t + 1.0 ) = 1.0. */
        lt = 0;
        a = c = 1;
        for (;;)
            if (c==one) {
                ++lt;
                a *= lbeta;
                c = dlamc3( a, one );
                c = dlamc3( c, -a );
            } else break;
    }
    *beta = lbeta;
    *t = lt;
    *rnd = lrnd;
    *ieee1 = lieee1;

    return;
}

void UDavidsonBase::dlamc4(int *emin, double start, int base ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAMC4 is a service routine for DLAMC2.
*
*  Arguments
*  =========
*
*  EMIN    (output) EMIN
*          The minimum exponent before (gradual) underflow, computed by
*          setting A = START and dividing by BASE until the previous A
*          can not be recovered.
*
*  START   (input) DOUBLE PRECISION
*          The starting point for determining EMIN.
*
*  BASE    (input) INTEGER
*          The base of the machine.
*/
{
    volatile double a, b1, b2, c1, c2, d1, d2, one, rbase, zero;

    a = start;
    one = 1;
    rbase = one / base;
    zero = 0;
    *emin = 1;
    b1 = dlamc3( a*rbase, zero );
    c1 = a;
    c2 = a;
    d1 = a;
    d2 = a;
    for (;;)
        if (( c1==a ) && ( c2==a ) && ( d1==a ) && ( d2==a ) ) {
            --*emin;
            a = b1;
            b1 = dlamc3( a / base, zero );
            c1 = dlamc3( b1*base, zero );
            d1 = zero;
            for (int i=1; i<=base; i++) d1 = d1 + b1;
            b2 = dlamc3( a*rbase, zero );
            c2 = dlamc3( b2 / rbase, zero );
            d2 = zero;
            for (int i=1; i<=base; i++) d2 = d2 + b2;
        } else break;

    return;
}

void UDavidsonBase::dlamc5(int beta, int p, int emin, bool ieee, int *emax, double *rmax ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAMC5 attempts to compute RMAX, the largest machine floating-point
*  number, without overflow.  It assumes that EMAX + abs(EMIN) sum
*  approximately to a power of 2.  It will fail on machines where this
*  assumption does not hold, for example, the Cyber 205 (EMIN = -28625,
*  EMAX = 28718).  It will also fail if the value supplied for EMIN is
*  too large (i.e. too close to zero), probably with overflow.
*
*  Arguments
*  =========
*
*  BETA    (input) INTEGER
*          The base of floating-point arithmetic.
*
*  P       (input) INTEGER
*          The number of base BETA digits in the mantissa of a
*          floating-point value.
*
*  EMIN    (input) INTEGER
*          The minimum exponent before (gradual) underflow.
*
*  IEEE    (input) LOGICAL
*          A logical flag specifying whether or not the arithmetic
*          system is thought to comply with the IEEE standard.
*
*  EMAX    (output) INTEGER
*          The largest exponent before overflow
*
*  RMAX    (output) DOUBLE PRECISION
*          The largest machine floating-point number.
*/
{
    volatile double zero = 0.0, one = 1.0;
    volatile int exbits, expsum, lexp, nbits, tryy, uexp;
    volatile double oldy, recbas, y, z;

/*    First compute LEXP and UEXP, two powers of 2 that bound
*     abs(EMIN). We then assume that EMAX + abs(EMIN) will sum
*     approximately to the bound that is closest to abs(EMIN).
*     (EMAX is the exponent of the required number RMAX). */
    lexp = 1;
    exbits = 1;
    for (;;) {
        tryy=lexp*2;
        if (tryy<=(-emin)) {
            lexp = tryy;
            ++exbits;
        } else break;
    }
    if (lexp==(-emin)) uexp = lexp;
        else {
            uexp = tryy;
            ++exbits;
        }
/*    Now -LEXP is less than or equal to EMIN, and -UEXP is greater
*     than or equal to EMIN. EXBITS is the number of bits needed to
*     store the exponent.         */
    if (( uexp+emin )>( -lexp-emin )) expsum = 2*lexp;
        else expsum = 2*uexp;
/*    EXPSUM is the exponent range, approximately equal to
*     EMAX - EMIN + 1 .                    */
    *emax = expsum + emin - 1;
/*    NBITS is the total number of bits needed to store a
*     floating-point number. */
    nbits = 1 + exbits + p;
    if (((nbits%2)==1 ) && ( beta==2 ))
/*        Either there are an odd number of bits used to store a
*        floating-point number, which is unlikely, or some bits are
*        not used in the representation of numbers, which is possible,
*        (e.g. Cray machines) or the mantissa has an implicit bit,
*        (e.g. IEEE machines, Dec Vax machines), which is perhaps the
*        most likely. We have to assume the last alternative.
*        If this is true, then we need to reduce EMAX by one because
*        there must be some way of representing zero in an implicit-bit
*        system. On machines like Cray, we are reducing EMAX by one
*        unnecessarily. */
        --*emax;
    if( ieee )
/*       Assume we are on an IEEE machine which reserves one exponent
*        for infinity and NaN. */
        --*emax;
/*    Now create RMAX, the largest machine number, which should
*     be equal to (1.0 - BETA**(-P)) * BETA**EMAX .
*
*     First compute 1.0 - BETA**(-P), being careful that the
*     result is less than 1.0 . */
    recbas = one / beta;
    z = beta - one;
    y = zero;
    for (int i=1; i<=p; i++) {
        z = z*recbas;
        if( y<one ) oldy = y;
        y = dlamc3( y, z );
    }
    if( y>=one ) y = oldy;
    //Now multiply by BETA**EMAX to get RMAX.
    for (int i = 1; i<=*emax; i++) y = dlamc3( y*beta, zero );
    *rmax = y;

    return;
}


void UDavidsonBase::dlamc2(int *beta, int *t, bool *rnd, double *eps, int *emin, double *rmin,
            int *emax, double *rmax ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAMC2 determines the machine parameters specified in its argument
*  list.
*
*  Arguments
*  =========
*
*  BETA    (output) INTEGER
*          The base of the machine.
*
*  T       (output) INTEGER
*          The number of ( BETA ) digits in the mantissa.
*
*  RND     (output) LOGICAL
*          Specifies whether proper rounding  ( RND = .TRUE. )  or
*          chopping  ( RND = .FALSE. )  occurs in addition. This may not
*          be a reliable guide to the way in which the machine performs
*          its arithmetic.
*
*  EPS     (output) DOUBLE PRECISION
*          The smallest positive number such that
*
*             fl( 1.0 - EPS ) .LT. 1.0,
*
*          where fl denotes the computed value.
*
*  EMIN    (output) INTEGER
*          The minimum exponent before (gradual) underflow occurs.
*
*  RMIN    (output) DOUBLE PRECISION
*          The smallest normalized number for the machine, given by
*          BASE**( EMIN - 1 ), where  BASE  is the floating point value
*          of BETA.
*
*  EMAX    (output) INTEGER
*          The maximum exponent before overflow occurs.
*
*  RMAX    (output) DOUBLE PRECISION
*          The largest positive number for the machine, given by
*          BASE**EMAX * ( 1 - EPS ), where  BASE  is the floating point
*          value of BETA.
*
*  Further Details
*  ===============
*
*  The computation of  EPS  is based on a routine PARANOIA by
*  W. Kahan of the University of California at Berkeley.
*/
{
    bool ieee, lieee1, lrnd;
    int gnmin, gpmin, ngnmin, ngpmin;
    volatile double a, b, c, half, one, rbase, sixth, small, third, two, zero;

    static bool first=1, iwarn=0;
    static int lbeta, lemax, lemin, lt;
    static double leps, lrmax, lrmin;

    if( first ) {
        first = 0;
        zero = 0;
        one = 1;
        two = 2;
/*        LBETA, LT, LRND, LEPS, LEMIN and LRMIN  are the local values of
*        BETA, T, RND, EPS, EMIN and RMIN.
*
*        Throughout this routine  we use the function  DLAMC3  to ensure
*        that relevant values are stored  and not held in registers,  or
*        are not affected by optimizers.
*
*        DLAMC1 returns the parameters  LBETA, LT, LRND and LIEEE1.*/
        dlamc1( &lbeta, &lt, &lrnd, &lieee1 );
        //Start to find EPS.
        b = lbeta;
        a=pow(b, -lt);
        leps = a;
        //Try some tricks to see whether or not this is the correct  EPS.
        b = two / 3;
        half = one / 2;
        sixth = dlamc3( b, -half );
        third = dlamc3( sixth, sixth );
        b = dlamc3( third, -half );
        b = dlamc3( b, sixth );
        b = fabs( b );
        if( b<leps ) b = leps;
        leps = 1;
        for (;;)
            if (( ( leps>b ) && ( b>zero ) )) {
                leps = b;
                c = dlamc3( half*leps, ( pow(two,5) )*( pow(leps,2) ) );
                c = dlamc3( half, -c );
                b = dlamc3( half, c );
                c = dlamc3( half, -b );
                b = dlamc3( half, c );
            } else break;
        if( a<leps ) leps = a;
/*       Computation of EPS complete.
*
*        Now find  EMIN.  Let A = + or - 1, and + or - (1 + BASE**(-3)).
*        Keep dividing  A by BETA until (gradual) underflow occurs. This
*        is detected when we cannot recover the previous A.  */
        rbase = one / lbeta;
        small = one;
        for (int i=1; i<=3; i++) small = dlamc3( small*rbase, zero );
        a = dlamc3( one, small );
        dlamc4( &ngpmin, one, lbeta );
        dlamc4( &ngnmin, -one, lbeta );
        dlamc4( &gpmin, a, lbeta );
        dlamc4( &gnmin, -a, lbeta );
        ieee = 0;
        if ( ( ngpmin==ngnmin ) && ( gpmin==gnmin ) ) {
            if( ngpmin==gpmin )
                    lemin = ngpmin;
                    //( Non twos-complement machines, no gradual underflow;
                    //e.g.,  VAX )
                else if( ( gpmin-ngpmin )==3 ) {
                    lemin = ngpmin - 1 + lt;
                    ieee = 1;
                    //( Non twos-complement machines, with gradual underflow;
                    //e.g., IEEE standard followers )
                } else {
                    lemin = MIN( ngpmin, gpmin );
                    //( A guess; no known machine )
                    iwarn = 1;
                }
        } else if (( ngpmin==gpmin ) && ( ngnmin==gnmin )) {
            if( abs( ngpmin-ngnmin )==1 ) lemin = MAX( ngpmin, ngnmin );
                //( Twos-complement machines, no gradual underflow;
                //e.g., CYBER 205 )
                else {
                    lemin = MIN( ngpmin, ngnmin );
                    //( A guess; no known machine )
                    iwarn = 1;
                }
        } else if (( abs( ngpmin-ngnmin )==1 ) && ( gpmin==gnmin )) {
            if( ( gpmin-MIN( ngpmin, ngnmin ) )==3 ) lemin = MAX( ngpmin, ngnmin ) - 1 + lt;
                //( Twos-complement machines with gradual underflow;
                //no known machine )
                else {
                    lemin = MIN( ngpmin, ngnmin );
                    //( A guess; no known machine )
                    iwarn = 1;
                }
        } else {
            lemin = MIN( MIN(ngpmin, ngnmin), MIN(gpmin, gnmin) );
            //( A guess; no known machine )
            iwarn = 1;
        }
        // Comment out this if block if EMIN is ok
        if( iwarn ) {
            first = 1;
            printf("\n warning. the value emin may be incorrect: emin = %i8",lemin );
            printf("\n if, after inspection, the value emin looks");
            printf("\n acceptable please comment out");
            printf("\n the if block as marked within the code of routine");
            printf("\n dlamc2 otherwise supply emin explicitly.");
        }
/*        Assume IEEE arithmetic if we found denormalised  numbers above,
*        or if arithmetic seems to round in the  IEEE style,  determined
*        in routine DLAMC1. A true IEEE machine should have both  things
*        true; however, faulty machines may have one or the other.*/
        ieee = ieee || lieee1;
/*        Compute  RMIN by successive division by  BETA. We could compute
*        RMIN as BASE**( EMIN - 1 ),  but some machines underflow during
*        this computation.        */
        lrmin = 1;
        for (int i = 1; i<=1-lemin; i++) lrmin = dlamc3( lrmin*rbase, zero );
        //Finally, call DLAMC5 to compute EMAX and RMAX.
        dlamc5( lbeta, lt, lemin, ieee, &lemax, &lrmax );
    }

    *beta = lbeta;
    *t = lt;
    *rnd = lrnd;
    *eps = leps;
    *emin = lemin;
    *rmin = lrmin;
    *emax = lemax;
    *rmax = lrmax;

    return;
}

double UDavidsonBase::dlamch(char cmach ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAMCH determines double precision machine parameters.
*
*  Arguments
*  =========
*
*  CMACH   (input) CHARACTER*1
*          Specifies the value to be returned by DLAMCH:
*          = 'E' or 'e',   DLAMCH := eps
*          = 'S' or 's ,   DLAMCH := sfmin
*          = 'B' or 'b',   DLAMCH := base
*          = 'P' or 'p',   DLAMCH := eps*base
*          = 'N' or 'n',   DLAMCH := t
*          = 'R' or 'r',   DLAMCH := rnd
*          = 'M' or 'm',   DLAMCH := emin
*          = 'U' or 'u',   DLAMCH := rmin
*          = 'L' or 'l',   DLAMCH := emax
*          = 'O' or 'o',   DLAMCH := rmax
*
*          where
*
*          eps   = relative machine precision
*          sfmin = safe minimum, such that 1/sfmin does not overflow
*          base  = base of the machine
*          prec  = eps*base
*          t     = number of (base) digits in the mantissa
*          rnd   = 1.0 when rounding occurs in addition, 0.0 otherwise
*          emin  = minimum exponent before (gradual) underflow
*          rmin  = underflow threshold - base**(emin-1)
*          emax  = largest exponent before overflow
*          rmax  = overflow threshold  - (base**emax)*(1-eps)
*/
{
    bool   lrnd;
    int    beta, imax, imin, it;
    double rmach, small;

    static bool first=1;
    static double eps, base, sfmin, t, rnd, emin, rmin, emax, prec, rmax;

    if( first ) {
        first = 0;
        dlamc2( &beta, &it, &lrnd, &eps, &imin, &rmin, &imax, &rmax );
        base = beta;
        t = it;
        if( lrnd ) {
            rnd = 1.0;
            eps = ( pow(base,( 1-it )) ) / 2;
        } else {
            rnd = 0.0;
            eps = pow(base,( 1-it ));
        }
        prec = eps*base;
        emin = imin;
        emax = imax;
        sfmin = rmin;
        small = 1.0 / rmax;
        if( small>=sfmin )
            //Use SMALL plus a bit, to avoid the possibility of rounding
            //causing overflow when computing  1/sfmin.
            sfmin = small*( 1.0+eps );
    }
    if( lsame( cmach, 'e' ) ) rmach = eps;
        else if( lsame( cmach, 's' ) ) rmach = sfmin;
            else if( lsame( cmach, 'b' ) ) rmach = base;
                else if( lsame( cmach, 'p' ) ) rmach = prec;
                    else if( lsame( cmach, 'n' ) ) rmach = t;
                        else if( lsame( cmach, 'r' ) ) rmach = rnd;
                            else if( lsame( cmach, 'm' ) ) rmach = emin;
                                else if( lsame( cmach, 'u' ) ) rmach = rmin;
                                    else if( lsame( cmach, 'l' ) ) rmach = emax;
                                        else if( lsame( cmach, 'o' ) ) rmach = rmax;
    return rmach;
}
//---------------------------------------------------------------------------
double UDavidsonBase::dlansp(char norm, char uplo, int n, double ap[], double work[]) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLANSP  returns the value of the one norm,  or the Frobenius norm, or
*  the  infinity norm,  or the  element of  largest absolute value  of a
*  real symmetric matrix A,  supplied in packed form.
*
*  Description
*  ===========
*
*  DLANSP returns the value
*
*     DLANSP = ( max(abs(A(i,j))), NORM = 'M' or 'm'
*              (
*              ( norm1(A),         NORM = '1', 'O' or 'o'
*              (
*              ( normI(A),         NORM = 'I' or 'i'
*              (
*              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
*
*  where  norm1  denotes the  one norm of a matrix (maximum column sum),
*  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
*  normF  denotes the  Frobenius norm of a matrix (square root of sum of
*  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
*
*  Arguments
*  =========
*
*  NORM    (input) CHARACTER*1
*          Specifies the value to be returned in DLANSP as described
*          above.
*
*  UPLO    (input) CHARACTER*1
*          Specifies whether the upper or lower triangular part of the
*          symmetric matrix A is supplied.
*          = 'U':  Upper triangular part of A is supplied
*          = 'L':  Lower triangular part of A is supplied
*
*  N       (input) INTEGER
*          The order of the matrix A.  N >= 0.  When N = 0, DLANSP is
*          set to zero.
*
*  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
*          The upper or lower triangle of the symmetric matrix A, packed
*          columnwise in a linear array.  The j-th column of A is stored
*          in the array AP as follows:
*          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
*          if UPLO = 'L', AP(i + (j-1)*(2n-j)/2) = A(i,j) for j<=i<=n.
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
*          where LWORK >= N when NORM = 'I' or '1' or 'O'; otherwise,
*          WORK is not referenced.
*/
{
    double absa, value, scale=0, sum=0;
    int k;

    if (!n) value = 0.0;
    else if (lsame(norm, 'm')) {
        // Find max(abs(A(i,j))).
        value = 0.0;
        if (lsame(uplo, 'u')) {
            k=1;
            for (int j=1;j<=n;j++) {
                for (int i=k;i<=k+j-1;i++) value=MAX(value,fabs(ap[i -1]));
                k+=j;
            }
        } else {
            k=1;
            for (int j=1;j<=n;j++) {
                for (int i=k;i<=k+n-j;i++) value=MAX(value,fabs(ap[i -1]));
                k += n - j + 1;
            }
        }
    } else if ( lsame(norm, 'i') || lsame(norm, 'o') || (norm=='1')) {
        //Find normI(A) ( = norm1(A), since A is symmetric).
        value = 0.0;
        k = 1;
        if (lsame(uplo,'u')) {
            for (int j=1; j<=n; j++) {
                sum = 0.0;
                for (int i=1;i<=j-1;i++) {
                    absa = fabs(ap[k -1]);
                        sum = sum + absa;
                        work[i -1] = work[i -1] + absa;
                        k+=1;
                }
                work[j -1] = sum + fabs( ap[k -1] );
                ++k;
            }
            for (int i=1;i<=n;i++) value = MAX(value, work[i -1]);
        } else {
            for (int i=1;i<=n;i++) work[i -1] = 0.0;
            for (int j=1;j<=n;j++) {
                sum = work[j -1] + fabs( ap[k -1] );
                k += 1;
                for (int i=j+1;i<=n;i++) {
                    absa = fabs( ap[k -1] );
                    sum += absa;
                    work[i -1] = work[i -1]+absa;
                    k += 1;
                }
                value = MAX( value, sum );
            }
        }
    } else if (lsame(norm, 'f') || lsame(norm, 'e')) {
        //Find normF(A).
        scale = 0.0;
        sum = 1.0;
        k = 2;
        if (lsame( uplo, 'u' ))
            for (int j=2;j<=n;j++) {
                dlassq( j-1, &ap[k -1], 1, &scale, &sum );
                k += j;
            }
        else
            for (int j=1;j<=n-1;j++) {
                dlassq( n-j, &ap[k -1], 1, &scale, &sum );
                k += n - j + 1;
            }
        sum *= sum;
        k = 1;
        for (int i=1;i<=n;i++) {
            if (!ap[k -1]) {
                absa = fabs( ap[k -1] );
                if (scale<absa) {
                    sum = 1.0+sum*(scale/absa)*(scale/absa);
                    scale = absa;
                } else
                    sum += (absa/(scale))*(absa/(scale));
            }
            if (lsame( uplo, 'u' )) k += i + 1;
                else k += n - i + 1;
        }
        value = scale*sqrt( sum );
    }
    return value;
}
//---------------------------------------------------------------------------
double UDavidsonBase::dlanst(char norm, int n, double d[], double e[]) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     February 29, 1992
*
*
*  =======
*
*  DLANST  returns the value of the one norm,  or the Frobenius norm, or
*  the  infinity norm,  or the  element of  largest absolute value  of a
*  real symmetric tridiagonal matrix A.
*
*  Description
*  ===========
*
*  DLANST returns the value
*
*     DLANST = ( max(abs(A(i,j))), NORM = 'M' or 'm'
*              (
*              ( norm1(A),         NORM = '1', 'O' or 'o'
*              (
*              ( normI(A),         NORM = 'I' or 'i'
*              (
*              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
*
*  where  norm1  denotes the  one norm of a matrix (maximum column sum),
*  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
*  normF  denotes the  Frobenius norm of a matrix (square root of sum of
*  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
*
*  Arguments
*  =========
*
*  NORM    (input) CHARACTER*1
*          Specifies the value to be returned in DLANST as described
*          above.
*
*  N       (input) INTEGER
*          The order of the matrix A.  N >= 0.  When N = 0, DLANST is
*          set to zero.
*
*  D       (input) DOUBLE PRECISION array, dimension (N)
*          The diagonal elements of A.
*
*  E       (input) DOUBLE PRECISION array, dimension (N-1)
*          The (n-1) sub-diagonal or super-diagonal elements of A.
*/
{
    double anorm;

    if( n<=0 )
        anorm = 0.0;
    else if( lsame( norm, 'm' ) ){
        //Find max(abs(A(i,j))).
        anorm = fabs( d[ n -1] );
        for (int i=1; i<=n-1; i++) {
            anorm = MAX( anorm, fabs( d[ i -1] ) );
            anorm = MAX( anorm, fabs( e[ i -1] ) );
        }
    } else if( lsame( norm, 'o' ) || norm=='1' || lsame( norm, 'i' ) ) {
        //Find norm1(A).
        if( n==1 )
            anorm = fabs( d[0] );
        else {
            anorm = MAX( fabs( d[0] )+fabs( e[0] ), fabs( e[ n-2] )+fabs( d[ n -1] ) );
            for (int i=2; i<=n-1; i++)
                anorm = MAX( anorm, fabs( d[ i -1] )+fabs( e[ i -1] )+fabs( e[ i-2] ) );
        }
    } else if( ( lsame( norm, 'f' ) ) || ( lsame( norm, 'e' ) ) ) {
        //Find normF(A).
        double scale = 0.0,
             sum = 1.0;
        if( n>1 ) {
            dlassq( n-1, e, 1, &scale, &sum );
            sum *= 2;
        }
        dlassq( n, d, 1, &scale, &sum );
        anorm = scale*sqrt( sum );
    }
    return anorm;
}
//---------------------------------------------------------------------------
double UDavidsonBase::dlapy2(double x, double y) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLAPY2 returns sqrt(x**2+y**2), taking care not to cause unnecessary
*  overflow.
*
*  Arguments
*  =========
*
*  X       (input) DOUBLE PRECISION
*  Y       (input) DOUBLE PRECISION
*          X and Y specify the values x and y.
*/
{
    double xabs = fabs( x ),
         yabs = fabs( y ),
         w = MAX( xabs, yabs ),
         z = MIN( xabs, yabs );
    if (!z) return w;
        else return w*sqrt( 1.0+( z / w )*( z / w ) );
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlarf(char side, int m, int n, double v[], int incv, double tau,
           double c[], int ldc, double work[]) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     February 29, 1992
*
*
*  Purpose
*  =======
*
*  DLARF applies a real elementary reflector H to a real m by n matrix
*  C, from either the left or the right. H is represented in the form
*
*        H = I - tau * v * v'
*
*  where tau is a real scalar and v is a real vector.
*
*  If tau = 0, then H is taken to be the unit matrix.
*
*  Arguments
*  =========
*
*  SIDE    (input) CHARACTER*1
*          = 'L': form  H * C
*          = 'R': form  C * H
*
*  M       (input) INTEGER
*          The number of rows of the matrix C.
*
*  N       (input) INTEGER
*          The number of columns of the matrix C.
*
*  V       (input) DOUBLE PRECISION array, dimension
*                     (1 + (M-1)*abs(INCV)) if SIDE = 'L'
*                  or (1 + (N-1)*abs(INCV)) if SIDE = 'R'
*          The vector v in the representation of H. V is not used if
*          TAU = 0.
*
*  INCV    (input) INTEGER
*          The increment between elements of v. INCV <> 0.
*
*  TAU     (input) DOUBLE PRECISION
*          The value tau in the representation of H.
*
*  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
*          On entry, the m by n matrix C.
*          On exit, C is overwritten by the matrix H * C if SIDE = 'L',
*          or C * H if SIDE = 'R'.
*
*  LDC     (input) INTEGER
*          The leading dimension of the array C. LDC >= max(1,M).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension
*                         (N) if SIDE = 'L'
*                      or (M) if SIDE = 'R'
*/
{
    if( lsame( side, 'l' ) ) {
        //Form  H * C
        if( tau ) {
            //w := C' * v
            dgemv( 't', m, n, 1.0, c, ldc, v, incv, 0.0, work, 1 );     //'transpose'
            // C := C - v * w'
            dger( m, n, -tau, v, incv, work, 1, c, ldc );
        }
    } else {
        //Form  C * H
        if( tau ) {
            //w := C * v
            dgemv( 'n', m, n, 1.0, c, ldc, v, incv, 0.0, work, 1 ); //'no transpose'
            //C := C - w * v'
            dger( m, n, -tau, work, 1, v, incv, c, ldc );
        }
    }

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlarfg(int n, double *alpha, double x[], int incx, double *tau ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DLARFG generates a real elementary reflector H of order n, such
*  that
*
*        H * ( alpha ) = ( beta ),   H' * H = I.
*            (   x   )   (   0  )
*
*  where alpha and beta are scalars, and x is an (n-1)-element real
*  vector. H is represented in the form
*
*        H = I - tau * ( 1 ) * ( 1 v' ) ,
*                      ( v )
*
*  where tau is a real scalar and v is a real (n-1)-element
*  vector.
*
*  If the elements of x are all zero, then tau = 0 and H is taken to be
*  the unit matrix.
*
*  Otherwise  1 <= tau <= 2.
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The order of the elementary reflector.
*
*  ALPHA   (input/output) DOUBLE PRECISION
*          On entry, the value alpha.
*          On exit, it is overwritten with the value beta.
*
*  X       (input/output) DOUBLE PRECISION array, dimension
*                         (1+(N-2)*abs(INCX))
*          On entry, the vector x.
*          On exit, it is overwritten with the vector v.
*
*  INCX    (input) INTEGER
*          The increment between elements of X. INCX > 0.
*
*  TAU     (output) DOUBLE PRECISION
*          The value tau.
*/
{
    if( n<=1 ) {
        *tau = 0.0;
        return;
    }
    double xnorm = dnrm2( n-1, x, incx );
    if( !xnorm )
        //H  =  I
        *tau=0.0;
    else {
        //general case
        double d=dlapy2( *alpha, xnorm ),
             beta = -sign( &d, alpha ),
             safmin = dlamch( 's' ) / dlamch( 'e' );
        if( fabs( beta )<safmin ) {
            //XNORM, BETA may be inaccurate; scale X and recompute them
            double rsafmn = 1.0 / safmin;
            int knt = 0;
            do {
                knt++;
                dscal( n-1, rsafmn, x, incx );
                beta *= rsafmn;
                *alpha *= rsafmn;
            } while (fabs( beta )<safmin);
            //New BETA is at most 1, at least SAFMIN
            xnorm = dnrm2( n-1, x, incx );
            d=dlapy2( *alpha, xnorm );
            beta = -sign( &d, alpha );
            *tau = ( beta-*alpha ) / beta;
            dscal( n-1, 1.0 / ( *alpha-beta ), x, incx );
            //If ALPHA is subnormal, it may lose relative accuracy
            *alpha = beta;
            for (int j=1; j<=knt; j++) *alpha *= safmin;
        } else {
            *tau = ( beta-*alpha ) / beta;
            dscal( n-1, 1.0 / ( *alpha-beta ), x, incx );
            *alpha = beta;
        }
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlarnv(int idist, int iseed[], int n, double x[] ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DLARNV returns a vector of n random real numbers from a uniform or
*  normal distribution.
*
*  Arguments
*  =========
*
*  IDIST   (input) INTEGER
*          Specifies the distribution of the random numbers:
*          = 1:  uniform (0,1)
*          = 2:  uniform (-1,1)
*          = 3:  normal (0,1)
*
*  ISEED   (input/output) INTEGER array, dimension (4)
*          On entry, the seed of the random number generator; the array
*          elements must be between 0 and 4095, and ISEED(4) must be
*          odd.
*          On exit, the seed is updated.
*
*  N       (input) INTEGER
*          The number of random numbers to be generated.
*
*  X       (output) DOUBLE PRECISION array, dimension (N)
*          The generated random numbers.
*
*  Further Details
*  ===============
*
*  This routine calls the auxiliary routine DLARUV to generate random
*  real numbers from a uniform (0,1) distribution, in batches of up to
*  128 using vectorisable code. The Box-Muller method is used to
*  transform numbers from a uniform to a normal distribution.
*/
{
    int il2, lv = 128;
    double *u = new double[lv];

    for (int iv=1; iv<=n; iv+=lv/2) {
        int il = MIN( lv / 2, n-iv+1 );
        if (idist==3) il2 = 2*il;
            else il2 = il;
/*       Call DLARUV to generate IL2 numbers from a uniform (0,1)
*        distribution (IL2 <= LV)   */
        dlaruv(iseed,il2,u);
        if (idist==1)
                //Copy generated numbers
                for (int i=1; i<=il; i++) x[ iv+i-2] = u[ i  -1];
            else if (idist==2)
                    //Convert generated numbers to uniform (-1,1) distribution
                    for (int i=1; i<=il; i++) x[ iv+i-2] = 2.0*u[ i  -1] - 1.0;
                else if (idist==3)
                        //Convert generated numbers to normal (0,1) distribution
                        for (int i=1; i<=il; i++)
                            x[iv+i-2]=sqrt(-2.0*log(u[2*i-2]))*cos(6.2831853071795864769252867663*u[2*i -1]);

    }

    delete[] u;
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlartg(double f, double g, double *cs, double *sn, double *r ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DLARTG generate a plane rotation so that
*
*     [  CS  SN  ]  .  [ F ]  =  [ R ]   where CS**2 + SN**2 = 1.
*     [ -SN  CS  ]     [ G ]     [ 0 ]
*
*  This is a slower, more accurate version of the BLAS1 routine DROTG,
*  with the following other differences:
*     F and G are unchanged on return.
*     If G=0, then CS=1 and SN=0.
*     If F=0 and (G .ne. 0), then CS=0 and SN=1 without doing any
*        floating point operations (saves work in DBDSQR when
*        there are zeros on the diagonal).
*
*  If F exceeds G in magnitude, CS will be positive.
*
*  Arguments
*  =========
*
*  F       (input) DOUBLE PRECISION
*          The first component of vector to be rotated.
*
*  G       (input) DOUBLE PRECISION
*          The second component of vector to be rotated.
*
*  CS      (output) DOUBLE PRECISION
*          The cosine of the rotation.
*
*  SN      (output) DOUBLE PRECISION
*          The sine of the rotation.
*
*  R       (output) DOUBLE PRECISION
*          The nonzero component of the rotated vector.
*/
{
    int    count;
    double eps, f1, g1, scale;

    static bool first=1;
    static double safmin, safmn2, safmx2;

    if( first ) {
        first = 0;
        safmin = dlamch( 's' );
        eps = dlamch( 'e' );
        safmn2 = pow(dlamch( 'b' ),(int)( log( safmin / eps )) / log( dlamch( 'b' ) ) / 2.0 );
        safmx2 = 1.0 / safmn2;
    }
    if( !g ) {
        *cs = 1.0;
        *sn = 0.0;
        *r = f;
    } else if( !f ) {
        *cs = 0.0;
        *sn = 1.0;
        *r = g;
    } else {
        f1 = f;
        g1 = g;
        scale = MAX( fabs( f1 ), fabs( g1 ) );
        if( scale>=safmx2 ) {
            count = 0;
            do {
                ++count;
                f1 *= safmn2;
                g1 *= safmn2;
                scale = MAX( fabs( f1 ), fabs( g1 ) );
            } while (scale>=safmx2);
            *r = sqrt( pow(f1,2)+pow(g1,2) );
            *cs = f1 / *r;
            *sn = g1 / *r;
            for (int i=1; i<=count; i++) *r *= safmx2;
        } else if (scale<=safmn2) {
            count = 0;
            do {
                ++count;
                f1 *= safmx2;
                g1 *= safmx2;
                scale = MAX( fabs( f1 ), fabs( g1 ) );
            } while (scale<=safmn2);
            *r = sqrt( pow(f1,2)+pow(g1,2) );
            *cs = f1 / *r;
            *sn = g1 / *r;
            for (int i=1; i<=count; i++) *r *= safmn2;
        } else {
            *r = sqrt( pow(f1,2)+pow(g1,2) );
            *cs = f1 / *r;
            *sn = g1 / *r;
        }
        if( fabs( f )>fabs( g ) && *cs<0.0 ){
            *cs = -*cs;
            *sn = -*sn;
            *r = -*r;
        }
    }

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dlaruv(int iseed[], int n, double x[] ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLARUV returns a vector of n random real numbers from a uniform (0,1)
*  distribution (n <= 128).
*
*  This is an auxiliary routine called by DLARNV and ZLARNV.
*
*  Arguments
*  =========
*
*  ISEED   (input/output) INTEGER array, dimension (4)
*          On entry, the seed of the random number generator; the array
*          elements must be between 0 and 4095, and ISEED(4) must be
*          odd.
*          On exit, the seed is updated.
*
*  N       (input) INTEGER
*          The number of random numbers to be generated. N <= 128.
*
*  X       (output) DOUBLE PRECISION array, dimension (N)
*          The generated random numbers.
*
*  Further Details
*  ===============
*
*  This routine uses a multiplicative congruential method with modulus
*  2**48 and multiplier 33952834046453 (see G.S.Fishman,
*  'Multiplicative congruential random number generators with modulus
*  2**b: an exhaustive analysis for b = 32 and a partial analysis for
*  b = 48', Math. Comp. 189, pp 331-344, 1990).
*
*  48-bit integers are stored in 4 integer array elements with 12 bits
*  per element. Hence the routine is portable across machines with
*  integers of 32 bits or more.
*/
{
    int lv = 128, ipw2 = 4096;
    double r = 1.0 / ipw2;

    static int mm[128][4]={{494, 322, 2508, 2549},
                          {2637, 789, 3754, 1145},
                          {255, 1440, 1766, 2253},
                          {2008, 752, 3572, 305},
                          {1253, 2859, 2893, 3301},
                          {3344, 123, 307, 1065},
                          {4084, 1848, 1297, 3133},
                          {1739, 643, 3966, 2913},
                          {3143, 2405, 758, 3285},
                          {3468, 2638, 2598, 1241},
                          {688, 2344, 3406, 1197},
                          {1657, 46, 2922, 3729},
                          {1238, 3814, 1038, 2501},
                          {3166, 913, 2934, 1673},
                          {1292, 3649, 2091, 541},
                          {3422, 339, 2451, 2753},
                          {1270, 3808, 1580, 949},
                          {2016, 822, 1958, 2361},
                          {154, 2832, 2055, 1165},
                          {2862, 3078, 1507, 4081},
                          {697, 3633, 1078, 2725},
                          {1706, 2970, 3273, 3305},
                          {491, 637, 17, 3069},
                          {931, 2249, 854, 3617},
                          {1444, 2081, 2916, 3733},
                          {444, 4019, 3971, 409},
                          {3577, 1478, 2889, 2157},
                          {3944, 242, 3831, 1361},
                          {2184, 481, 2621, 3973},
                          {1661, 2075, 1541, 1865},
                          {3482, 4058, 893, 2525},
                          {657, 622, 736, 1409},
                          {3023, 3376, 3992, 3445},
                          {3618, 812, 787, 3577},
                          {1267, 234, 2125, 77},
                          {1828, 641, 2364, 3761},
                          {164, 4005, 2460, 2149},
                          {3798, 1122, 257, 1449},
                          {3087, 3135, 1574, 3005},
                          {2400, 2640, 3912, 225},
                          {2870, 2302, 1216, 85},
                          {3876, 40, 3248, 3673},
                          {1905, 1832, 3401, 3117},
                          {1593, 2247, 2124, 3089},
                          {1797, 2034, 2762, 1349},
                          {1234, 2637, 149, 2057},
                          {3460, 1287, 2245, 413},
                          {328, 1691, 166, 65},
                          {2861, 496, 466, 1845},
                          {1950, 1597, 4018, 697},
                          {617, 2394, 1399, 3085},
                          {2070, 2584, 190, 3441},
                          {3331, 1843, 2879, 1573},
                          {769, 336, 153, 3689},
                          {1558, 1472, 2320, 2941},
                          {2412, 2407, 18, 929},
                          {2800, 433, 712, 533},
                          {189, 2096, 2159, 2841},
                          {287, 1761, 2318, 4077},
                          {2045, 2810, 2091, 721},
                          {1227, 566, 3443, 2821},
                          {2838, 442, 1510, 2249},
                          {209, 41, 449, 2397},
                          {2770, 1238, 1956, 2817},
                          {3654, 1086, 2201, 245},
                          {3993, 603, 3137, 1913},
                          {192, 840, 3399, 1997},
                          {2253, 3168, 1321, 3121},
                          {3491, 1499, 2271, 997},
                          {2889, 1084, 3667, 1833},
                          {2857, 3438, 2703, 2877},
                          {2094, 2408, 629, 1633},
                          {1818, 1589, 2365, 981},
                          {688, 2391, 2431, 2009},
                          {1407, 288, 1113, 941},
                          {634, 26, 3922, 2449},
                          {3231, 512, 2554, 197},
                          {815, 1456, 184, 2441},
                          {3524, 171, 2099, 285},
                          {1914, 1677, 3228, 1473},
                          {516, 2657, 4012, 2741},
                          {164, 2270, 1921, 3129},
                          {303, 2587, 3452, 909},
                          {2144, 2961, 3901, 2801},
                          {3480, 1970, 572, 421},
                          {119, 1817, 3309, 4073},
                          {3357, 676, 3171, 2813},
                          {837, 1410, 817, 2337},
                          {2826, 3723, 3039, 1429},
                          {2332, 2803, 1696, 1177},
                          {2089, 3185, 1256, 1901},
                          {3780, 184, 3715, 81},
                          {1700, 663, 2077, 1669},
                          {3712, 499, 3019, 2633},
                          {150, 3784, 1497, 2269},
                          {2000, 1631, 1101, 129},
                          {3375, 1925, 717, 1141},
                          {1621, 3912, 51, 249},
                          {3090, 1398, 981, 3917},
                          {3765, 1349, 1978, 2481},
                          {1149, 1441, 1813, 3941},
                          {3146, 2224, 3881, 2217},
                          {33, 2411, 76, 2749},
                          {3082, 1907, 3846, 3041},
                          {2741, 3192, 3694, 1877},
                          {359, 2786, 1682, 345},
                          {3316, 382, 124, 2861},
                          {1749, 37, 1660, 1809},
                          {185, 759, 3997, 3141},
                          {2784, 2948, 479, 2825},
                          {2202, 1862, 1141, 157},
                          {2199, 3802, 886, 2881},
                          {1364, 2423, 3514, 3637},
                          {1244, 2051, 1301, 1465},
                          {2020, 2295, 3604, 2829},
                          {3160, 1332, 1888, 2161},
                          {2785, 1832, 1836, 3365},
                          {2772, 2405, 1990, 361},
                          {1217, 3638, 2058, 2685},
                          {1822, 3661, 692, 3745},
                          {1245, 327, 1194, 2325},
                          {2252, 3660, 20, 3609},
                          {3904, 716, 3285, 3821},
                          {2774, 1842, 2046, 3537},
                          {997, 3987, 2107, 517},
                          {2573, 1368, 3508, 3017},
                          {1148, 1848, 3525, 2141},
                          {545, 2366, 3801, 1537}};

    int i1 = iseed[0],
        i2 = iseed[1],
        i3 = iseed[2],
        i4 = iseed[3],
        it1, it2, it3, it4;

    for (int i=1; i<=MIN( n, lv ); i++) {
        //Multiply the seed by i-th power of the multiplier modulo 2**48
        it4  = i4*mm[i-1][3];
        it3  = it4 / ipw2;
        it4 -= ipw2*it3;
        it3 += i3*mm[i-1][3] + i4*mm[i-1][2];
        it2  = it3 / ipw2;
        it3 -= ipw2*it2;
        it2 += i2*mm[i-1][3] + i3*mm[i-1][2] + i4*mm[i-1][1];
        it1  = it2 / ipw2;
        it2 -= ipw2*it1;
        it1 += i1*mm[i-1][3] + i2*mm[i-1][2] + i3*mm[i-1][1] + i4*mm[i-1][0];
        it1 %= ipw2;
        //Convert 48-bit integer to a real number in the interval (0,1)
        x[i-1] = r*((double)it1+r*((double)it2+r*((double)it3+r*(double)it4)));
    }
    //Return final value of seed
    iseed[0] = it1;
    iseed[1] = it2;
    iseed[2] = it3;
    iseed[3] = it4;

    return;
}
//---------------------------------------------------------------------------
#define a(j,i) a[ ((((i)-1)*(lda))+((j)-1)) ]

void UDavidsonBase::dlascl(char type, int kl, int ku, double cfrom, double cto, int m, int n,
            double a[], int lda, int *info ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     February 29, 1992
*
*
*  Purpose
*  =======
*
*  DLASCL multiplies the M by N real matrix A by the real scalar
*  CTO/CFROM.  This is done without over/underflow as long as the final
*  result CTO*A(I,J)/CFROM does not over/underflow. TYPE specifies that
*  A may be full, upper triangular, lower triangular, upper Hessenberg,
*  or banded.
*
*  Arguments
*  =========
*
*  TYPE    (input) CHARACTER*1
*          TYPE indices the storage type of the input matrix.
*          = 'G':  A is a full matrix.
*          = 'L':  A is a lower triangular matrix.
*          = 'U':  A is an upper triangular matrix.
*          = 'H':  A is an upper Hessenberg matrix.
*          = 'B':  A is a symmetric band matrix with lower bandwidth KL
*                  and upper bandwidth KU and with the only the lower
*                  half stored.
*          = 'Q':  A is a symmetric band matrix with lower bandwidth KL
*                  and upper bandwidth KU and with the only the upper
*                  half stored.
*          = 'Z':  A is a band matrix with lower bandwidth KL and upper
*                  bandwidth KU.
*
*  KL      (input) INTEGER
*          The lower bandwidth of A.  Referenced only if TYPE = 'B',
*          'Q' or 'Z'.
*
*  KU      (input) INTEGER
*          The upper bandwidth of A.  Referenced only if TYPE = 'B',
*          'Q' or 'Z'.
*
*  CFROM   (input) DOUBLE PRECISION
*  CTO     (input) DOUBLE PRECISION
*          The matrix A is multiplied by CTO/CFROM. A(I,J) is computed
*          without over/underflow if the final result CTO*A(I,J)/CFROM
*          can be represented without over/underflow.  CFROM must be
*          nonzero.
*
*  M       (input) INTEGER
*          The number of rows of the matrix A.  M >= 0.
*
*  N       (input) INTEGER
*          The number of columns of the matrix A.  N >= 0.
*
*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,M)
*          The matrix to be multiplied by CTO/CFROM.  See TYPE for the
*          storage type.
*
*  LDA     (input) INTEGER
*          The leading dimension of the array A.  LDA >= max(1,M).
*
*  INFO    (output) INTEGER
*          0  - successful exit
*          <0 - if INFO = -i, the i-th argument had an illegal value.
*/
{
    bool   done;
    int   itype=-1;

    //Test the input arguments
    *info = 0;
    if( lsame( type, 'g' ) ) itype = 0;
        else if( lsame( type, 'l' ) ) itype = 1;
            else if( lsame( type, 'u' ) ) itype = 2;
                else if( lsame( type, 'h' ) ) itype = 3;
                    else if( lsame( type, 'b' ) ) itype = 4;
                        else if( lsame( type, 'q' ) ) itype = 5;
                            else if( lsame( type, 'z' ) ) itype = 6;
    if( itype==-1 ) *info = -1;
        else if( !cfrom ) *info = -4;
            else if( m<0 ) *info = -6;
                else if( n<0 || ( itype==4 && n!=m ) || ( itype==5 && n!=m ) ) *info = -7;
                    else if( itype<=3 && lda<MAX( 1, m ) ) *info = -9;
                        else if( itype>=4 ) {
                                if( kl<0 || kl>MAX( m-1, 0 ) ) *info = -2;
                                    else if( ku<0 || ku>MAX( n-1, 0 ) || ( ( itype==4 || itype==5 ) && kl!=ku ) ) *info = -3;
                                        else if( ( itype==4 && lda<kl+1 ) || ( itype==5 && lda<ku+1 ) || ( itype==6 && lda<2*kl+ku+1 ) ) *info = -9;
                             }
    if( *info ) {
////            xerbla( "dlascl ", -*info );
            return;
    }
    //Quick return if possible
    if( !n || !m ) return;
    //Get machine parameters
    double smlnum = dlamch( 's' ),
         bignum = 1.0 / smlnum,
         cfromc = cfrom,
         ctoc = cto;

    int k1, k2, k3, k4;
    double mul;
    do {
        double cfrom1 = cfromc*smlnum,
             cto1 = ctoc / bignum;
        if( fabs( cfrom1 )>fabs( ctoc ) && ctoc ) {
            mul = smlnum;
            done = false;
            cfromc = cfrom1;
        } else if( fabs( cto1 )>fabs( cfromc ) ) {
            mul = bignum;
            done = false;
            ctoc = cto1;
        } else {
            mul = ctoc / cfromc;
            done = true;
        }
        if( !itype ){
            // Full matrix
            for (int j=1; j<=n; j++)
                for (int i=1; i<=m; i++)
                    a( i, j ) *= mul;
        } else if( itype==1 ){
            //Lower triangular matrix
            for (int j=1; j<=n; j++)
                for (int i=j; i<=m; i++)
                    a( i, j ) *= mul;
        } else if( itype==2 ) {
            //Upper triangular matrix
            for (int j=1; j<=n; j++)
                for (int i=1; i<=MIN( j, m ); i++)
                    a( i, j ) *= mul;
        } else if( itype==3 ){
            //Upper Hessenberg matrix
            for (int j=1; j<=n; j++)
                for (int i=1; i<=MIN( j+1, m ); i++)
                    a( i, j ) *= mul;
        } else if( itype==4 ) {
            //Lower half of a symmetric band matrix
            k3 = kl + 1;
            k4 = n + 1;
            for (int j=1; j<=n; j++)
                for (int i=1; i<=MIN( k3, k4-j ); i++)
                    a( i, j ) *= mul;
        } else if( itype==5 ) {
            //Upper half of a symmetric band matrix
            k1 = ku + 2;
            k3 = ku + 1;
            for (int j=1; j<=n; j++)
                for (int i=MAX( k1-j, 1 ); i<=k3; i++)
                    a( i, j ) *= mul;
        } else if( itype==6 ){
            //Band matrix
            k1 = kl + ku + 2;
            k2 = kl + 1;
            k3 = 2*kl + ku + 1;
            k4 = kl + ku + 1 + m;
            for (int j=1; j<=n; j++)
                for (int i=MAX( k1-j, k2 ); i<=MIN( k3, k4-j ); i++)
                    a( i, j ) *= mul;
        }
    } while (!done);

    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
#define a(j,i) a[ ((((i)-1)*(lda))+((j)-1)) ]

void UDavidsonBase::dlaset(char uplo, int m, int n, double alpha, double beta, double a[], int lda ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLASET initializes an m-by-n matrix A to BETA on the diagonal and
*  ALPHA on the offdiagonals.
*
*  Arguments
*  =========
*
*  UPLO    (input) CHARACTER*1
*          Specifies the part of the matrix A to be set.
*          = 'U':      Upper triangular part is set; the strictly lower
*                      triangular part of A is not changed.
*          = 'L':      Lower triangular part is set; the strictly upper
*                      triangular part of A is not changed.
*          Otherwise:  All of the matrix A is set.
*
*  M       (input) INTEGER
*          The number of rows of the matrix A.  M >= 0.
*
*  N       (input) INTEGER
*          The number of columns of the matrix A.  N >= 0.
*
*  ALPHA   (input) DOUBLE PRECISION
*          The constant to which the offdiagonal elements are to be set.
*
*  BETA    (input) DOUBLE PRECISION
*          The constant to which the diagonal elements are to be set.
*
*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
*          On exit, the leading m-by-n submatrix of A is set as follows:
*
*          if UPLO = 'U', A(i,j) = ALPHA, 1<=i<=j-1, 1<=j<=n,
*          if UPLO = 'L', A(i,j) = ALPHA, j+1<=i<=m, 1<=j<=n,
*          otherwise,     A(i,j) = ALPHA, 1<=i<=m, 1<=j<=n, i.ne.j,
*
*          and, for all UPLO, A(i,i) = BETA, 1<=i<=min(m,n).
*
*  LDA     (input) INTEGER
*          The leading dimension of the array A.  LDA >= max(1,M).
*/
{
    if( lsame( uplo, 'u' ) ) {
/*       Set the strictly upper triangular or trapezoidal part of the
*        array to ALPHA.    */
        for (int j=2; j<=n; j++)
            for (int i=1; i<=MIN( j-1, m ); i++)
                a( i, j ) = alpha;
    } else if( lsame( uplo, 'l' ) ) {
/*       Set the strictly lower triangular or trapezoidal part of the
*        array to ALPHA.    */
        for (int j=1; j<=MIN( m, n ); j++)
            for (int i=j+1; i<=m; i++)
                a( i, j ) = alpha;
    } else {
// Set the leading m-by-n submatrix to ALPHA.
        for (int j=1; j<=n; j++)
            for (int i=1; i<=m; i++)
                a( i, j ) = alpha;
    }
//Set the first min(M,N) diagonal elements to BETA.
    for (int i=1; i<=MIN( m, n ); i++) a( i, i ) = beta;

    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
#define a(j1,i1) a[(((lda)*((i1)-1))+((j1)-1))]

void UDavidsonBase::dlasr(char side, char pivot, char direct, int m, int n, double c[],
           double s[], double a[], int lda ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     October 31, 1992
*
*
*  Purpose
*  =======
*
*  DLASR   performs the transformation
*
*     A := P*A,   when SIDE = 'L' or 'l'  (  Left-hand side )
*
*     A := A*P',  when SIDE = 'R' or 'r'  ( Right-hand side )
*
*  where A is an m by n real matrix and P is an orthogonal matrix,
*  consisting of a sequence of plane rotations determined by the
*  parameters PIVOT and DIRECT as follows ( z = m when SIDE = 'L' or 'l'
*  and z = n when SIDE = 'R' or 'r' ):
*
*  When  DIRECT = 'F' or 'f'  ( Forward sequence ) then
*
*     P = P( z - 1 )*...*P( 2 )*P( 1 ),
*
*  and when DIRECT = 'B' or 'b'  ( Backward sequence ) then
*
*     P = P( 1 )*P( 2 )*...*P( z - 1 ),
*
*  where  P( k ) is a plane rotation matrix for the following planes:
*
*     when  PIVOT = 'V' or 'v'  ( Variable pivot ),
*        the plane ( k, k + 1 )
*
*     when  PIVOT = 'T' or 't'  ( Top pivot ),
*        the plane ( 1, k + 1 )
*
*     when  PIVOT = 'B' or 'b'  ( Bottom pivot ),
*        the plane ( k, z )
*
*  c( k ) and s( k )  must contain the  cosine and sine that define the
*  matrix  P( k ).  The two by two plane rotation part of the matrix
*  P( k ), R( k ), is assumed to be of the form
*
*     R( k ) = (  c( k )  s( k ) ).
*              ( -s( k )  c( k ) )
*
*  This version vectorises across rows of the array A when SIDE = 'L'.
*
*  Arguments
*  =========
*
*  SIDE    (input) CHARACTER*1
*          Specifies whether the plane rotation matrix P is applied to
*          A on the left or the right.
*          = 'L':  Left, compute A := P*A
*          = 'R':  Right, compute A:= A*P'
*
*  DIRECT  (input) CHARACTER*1
*          Specifies whether P is a forward or backward sequence of
*          plane rotations.
*          = 'F':  Forward, P = P( z - 1 )*...*P( 2 )*P( 1 )
*          = 'B':  Backward, P = P( 1 )*P( 2 )*...*P( z - 1 )
*
*  PIVOT   (input) CHARACTER*1
*          Specifies the plane for which P(k) is a plane rotation
*          matrix.
*          = 'V':  Variable pivot, the plane (k,k+1)
*          = 'T':  Top pivot, the plane (1,k+1)
*          = 'B':  Bottom pivot, the plane (k,z)
*
*  M       (input) INTEGER
*          The number of rows of the matrix A.  If m <= 1, an immediate
*          return is effected.
*
*  N       (input) INTEGER
*          The number of columns of the matrix A.  If n <= 1, an
*          immediate return is effected.
*
*  C, S    (input) DOUBLE PRECISION arrays, dimension
*                  (M-1) if SIDE = 'L'
*                  (N-1) if SIDE = 'R'
*          c(k) and s(k) contain the cosine and sine that define the
*          matrix P(k).  The two by two plane rotation part of the
*          matrix P(k), R(k), is assumed to be of the form
*          R( k ) = (  c( k )  s( k ) ).
*                   ( -s( k )  c( k ) )
*
*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
*          The m by n matrix A.  On exit, A is overwritten by P*A if
*          SIDE = 'R' or by A*P' if SIDE = 'L'.
*
*  LDA     (input) INTEGER
*          The leading dimension of the array A.  LDA >= max(1,M).
*/
{
    double ctemp, stemp, temp;

    //Test the input parameters
    int info = 0;
    if( !( lsame( side, 'l' ) || lsame( side, 'r' ) ) ) info = 1;
        else if( !( lsame( pivot, 'v' ) || lsame( pivot,'t' ) || lsame( pivot, 'b' ) ) ) info = 2;
            else if( !( lsame( direct, 'f' ) || lsame( direct, 'b' ) ) ) info = 3;
                else if( m<0 ) info = 4;
                    else if( n<0 ) info = 5;
                        else if( lda<MAX( 1, m ) ) info = 9;
    if( info ){
////            xerbla( "dlasr ", info );
            return;
    }
    //Quick return if possible
    if( !m || !n ) return;
    if( lsame( side, 'l' ) ) {
        //Form  P * A
        if( lsame( pivot, 'v' ) ) {
            if ( lsame( direct, 'f' ) ) {
                for (int j=1; j<=m-1; j++) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=n; i++) {
                            temp = a(j+1,i);
                            a( j+1, i ) = ctemp*temp - stemp*a( j, i );
                            a( j, i ) = stemp*temp + ctemp*a( j, i );
                        }
                }
            } else if ( lsame( direct, 'b' ) ) {
                for (int j=m-1; j>=1; j--) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=n; i++) {
                            temp = a( j+1, i );
                            a( j+1, i ) = ctemp*temp - stemp*a( j, i );
                            a( j, i ) = stemp*temp + ctemp*a( j, i );
                        }
                }
            }
        } else if (lsame( pivot, 't' )) {
            if( lsame( direct, 'f' ) ){
                for (int j=2; j<=m; j++) {
                    ctemp = c[j-1 -1];
                    stemp = s[j-1 -1];
                    if( ( ctemp!=1.0 ) || stemp ){
                        for (int i=1; i<=n; i++) {
                            temp = a( j, i );
                            a( j, i ) = ctemp*temp - stemp*a( 1, i );
                            a( 1, i ) = stemp*temp + ctemp*a( 1, i );
                        }
                    }
                }
            } else if (lsame( direct, 'b' )) {
                for (int j=m; j>=2; j--) {
                    ctemp = c[j-1 -1];
                    stemp = s[j-1 -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=n; i++) {
                            temp = a( j, i );
                            a( j, i ) = ctemp*temp - stemp*a( 1, i );
                            a( 1, i ) = stemp*temp + ctemp*a( 1, i );
                        }
                }
            }
        } else if (lsame( pivot, 'b' )) {
            if (lsame( direct, 'f' )) {
                for (int j=1; j<=m-1; j++) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=n; i++) {
                            temp = a( j, i );
                            a( j, i ) = stemp*a( m, i ) + ctemp*temp;
                            a( m, i ) = ctemp*a( m, i ) - stemp*temp;
                        }
                }
            } else if (lsame( direct, 'b' )) {
                for (int j=m-1; j>=1; j--) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=n; i++) {
                            temp = a( j, i );
                            a( j, i ) = stemp*a( m, i ) + ctemp*temp;
                            a( m, i ) = ctemp*a( m, i ) - stemp*temp;
                        }
                }
            }

        }
    } else if (lsame( side, 'r' )) {
        //Form A * P'
        if( lsame( pivot, 'v' ) ){
            if( lsame( direct, 'f' ) ) {
                for (int j=1; j<=n-1; j++) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j+1 );
                            a( i, j+1 ) = ctemp*temp - stemp*a( i, j );
                            a( i, j ) = stemp*temp + ctemp*a( i, j );
                        }
                }
            } else if (lsame( direct, 'b' ))
                for (int j=n-1; j>=1; j--) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j+1 );
                            a( i, j+1 ) = ctemp*temp - stemp*a( i, j );
                            a( i, j ) = stemp*temp + ctemp*a( i, j );
                        }
                }
        } else if (lsame( pivot, 't' )) {
            if( lsame( direct, 'f' ) ){
                for (int j=2; j<=n; j++) {
                    ctemp = c[j-1 -1];
                    stemp = s[j-1 -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j );
                            a( i, j ) = ctemp*temp - stemp*a( i, 1 );
                            a( i, 1 ) = stemp*temp + ctemp*a( i, 1 );
                        }
                }
            } else if (lsame( direct, 'b' ))
                for (int j=n; j>=2; j--) {
                    ctemp = c[j-1 -1];
                    stemp = s[j-1 -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j );
                            a( i, j ) = ctemp*temp - stemp*a( i, 1 );
                            a( i, 1 ) = stemp*temp + ctemp*a( i, 1 );
                        }
                }
        } else if (lsame( pivot, 'b' )) {
            if( lsame( direct, 'f' ) ) {
                for (int j=1; j<=n-1; j++) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j );
                            a( i, j ) = stemp*a( i, n ) + ctemp*temp;
                            a( i, n ) = ctemp*a( i, n ) - stemp*temp;
                        }
                }
            } else if( lsame( direct, 'b' ) )
                for (int j=n-1; j>=1; j--) {
                    ctemp = c[j -1];
                    stemp = s[j -1];
                    if( ( ctemp!=1.0 ) || stemp )
                        for (int i=1; i<=m; i++) {
                            temp = a( i, j );
                            a( i, j ) = stemp*a( i, n ) + ctemp*temp;
                            a( i, n ) = ctemp*a( i, n ) - stemp*temp;
                        }
                }
            }
    }
    return;
}

#undef a //(j1,i1)
//---------------------------------------------------------------------------
#define stack( i, j ) stack[i-1][j-1]

void UDavidsonBase::dlasrt(char id, int n, double d[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  Sort the numbers in D in increasing order (if ID = 'I') or
*  in decreasing order (if ID = 'D' ).
*
*  Use Quick Sort, reverting to Insertion sort on arrays of
*  size <= 20. Dimension of STACK limits N to about 2**32.
*
*  Arguments
*  =========
*
*  ID      (input) CHARACTER*1
*          = 'I': sort D in increasing order;
*          = 'D': sort D in decreasing order.
*
*  N       (input) INTEGER
*          The length of the array D.
*
*  D       (input/output) DOUBLE PRECISION array, dimension (N)
*          On entry, the array to be sorted.
*          On exit, D has been sorted into increasing order
*          (D(1) <= ... <= D(N) ) or into decreasing order
*          (D(1) >= ... >= D(N) ), depending on ID.
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*/
{
    int dir = -1;

    //Test the input paramters.
    *info = 0;
    if( lsame( id, 'd' ) ) dir = 0;
        else if( lsame( id, 'i' ) ) dir = 1;
    if( dir==-1 ) *info = -1;
        else if( n<0 ) *info = -2;
    if( *info ) {
////        xerbla( "dlasrt ", -*info );
        return;
    }
    int stack[ 2 ][ 32 ];
    //Quick return if possible
    if( n<=1 ) return;
    int stkpnt = 1;
    stack( 1, 1 ) = 1;
    stack( 2, 1 ) = n;

    int select = 20, i, j;
    double dmnmx, tmp;
    do {
        int start = stack( 1, stkpnt ),
             endd = stack( 2, stkpnt );
        stkpnt = stkpnt - 1;
        if( endd-start<=select && endd-start>0 ) {
            //Do Insertion sort on D( START:ENDD )
            if( !dir ){
                //Sort into decreasing order
                for (int i=start+1; i<=endd; i++)
                    for (int j=i; j>=start+1; j--) {
                        if( d[ j -1]>d[ j-2 ] ) {
                            dmnmx = d[ j -1];
                            d[ j -1] = d[ j-2 ];
                            d[ j-2 ] = dmnmx;
                        } else break;
                    }
            } else {
                //Sort into increasing order
                for (int i=start+1; i<=endd; i++)
                    for (int j=i; j>=start+1; j--)
                        if( d[ j -1]<d[ j-2 ] ){
                            dmnmx = d[ j -1];
                            d[ j -1] = d[ j-2 ];
                            d[ j-2 ] = dmnmx;
                        } else break;
            }
        } else if( endd-start>select ) {
            //Partition D( START:ENDD ) and stack parts, largest one first
            //Choose partition entry as median of 3
            double d1 = d[ start -1],
                 d2 = d[ endd -1];
            i = ( start+endd ) / 2;
            double d3 = d[ i -1];
            if( d1<d2 ) {
                if( d3<d1 ) dmnmx = d1;
                    else if( d3<d2 ) dmnmx = d3;
                        else dmnmx = d2;
            } else {
                if( d3<d2 ) dmnmx = d2;
                    else if( d3<d1 ) dmnmx = d3;
                        else dmnmx = d1;
            }
            if( !dir ){
                //Sort into decreasing order
                i = start - 1;
                j = endd + 1;
                do {
                    do
                        --j;
                    while (d[ j -1]<dmnmx);
                    do
                        ++i;
                    while (d[ i -1]>dmnmx);
                    if (i<j) {
                        tmp = d[ i -1];
                        d[ i -1] = d[ j -1];
                        d[ j -1] = tmp;
                    }
                } while (i<j);
                if( j-start>endd-j-1 ){
                    ++stkpnt;
                    stack( 1, stkpnt ) = start;
                    stack( 2, stkpnt ) = j;
                    ++stkpnt;
                    stack( 1, stkpnt ) = j + 1;
                    stack( 2, stkpnt ) = endd;
                } else {
                    ++stkpnt;
                    stack( 1, stkpnt ) = j + 1;
                    stack( 2, stkpnt ) = endd;
                    ++stkpnt;
                    stack( 1, stkpnt ) = start;
                    stack( 2, stkpnt ) = j;
                }
            } else {
                //Sort into increasing order
                i = start - 1;
                j = endd + 1;
                do {
                    do
                        --j;
                    while (d[ j -1]>dmnmx);
                    do
                        ++i;
                    while (d[ i -1]<dmnmx);
                    if( i<j ) {
                        tmp = d[ i -1];
                        d[ i -1] = d[ j -1];
                        d[ j -1] = tmp;
                    }
                } while (i<j);
                if ( j-start>endd-j-1 ){
                    ++stkpnt;
                    stack( 1, stkpnt ) = start;
                    stack( 2, stkpnt ) = j;
                    ++stkpnt;
                    stack( 1, stkpnt ) = j + 1;
                    stack( 2, stkpnt ) = endd;
                } else {
                    ++stkpnt;
                    stack( 1, stkpnt ) = j + 1;
                    stack( 2, stkpnt ) = endd;
                    ++stkpnt;
                    stack( 1, stkpnt ) = start;
                    stack( 2, stkpnt ) = j;
                }
            }
        }
    } while (stkpnt>0);

    return;
}

#undef stack //( i, j )
//---------------------------------------------------------------------------
void UDavidsonBase::dlassq(int n, double x[], int incx, double *scale, double *sumsq) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  DLASSQ  returns the values  scl  and  smsq  such that
*
*     ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq,
*
*  where  x( i ) = X( 1 + ( i - 1 )*INCX ). The value of  sumsq  is
*  assumed to be non-negative and  scl  returns the value
*
*     scl = max( scale, abs( x( i ) ) ).
*
*  scale and sumsq must be supplied in SCALE and SUMSQ and
*  scl and smsq are overwritten on SCALE and SUMSQ respectively.
*
*  The routine makes only one pass through the vector x.
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The number of elements to be used from the vector X.
*
*  X       (input) DOUBLE PRECISION array, dimension (N)
*          The vector for which a scaled sum of squares is computed.
*             x( i )  = X( 1 + ( i - 1 )*INCX ), 1 <= i <= n.
*
*  INCX    (input) INTEGER
*          The increment between successive values of the vector X.
*          INCX > 0.
*
*  SCALE   (input/output) DOUBLE PRECISION
*          On entry, the value  scale  in the equation above.
*          On exit, SCALE is overwritten with  scl , the scaling factor
*          for the sum of squares.
*
*  SUMSQ   (input/output) DOUBLE PRECISION
*          On entry, the value  sumsq  in the equation above.
*          On exit, SUMSQ is overwritten with  smsq , the basic sum of
*          squares from which  scl  has been factored out.
*/
{
    double absxi;

    if (n>0)
        for (int ix=1; ix<=1+(n-1)*incx; ix+=incx) {
            if (x[ix -1]) {
                absxi = fabs(x[ix -1]);
                if (*scale<absxi) {
                        *sumsq = 1 + *sumsq*(*scale/absxi)*(*scale/absxi);
                        *scale = absxi;
                } else *sumsq=*sumsq+(absxi/(*scale))*(absxi/(*scale));
            }
        }
    return;
}
//---------------------------------------------------------------------------
double UDavidsonBase::dnrm2(int n, double x[], int incx ) const
/* DNRM2 returns the euclidean norm of a vector via the function
*  name, so that
*
*     DNRM2 := sqrt( x'*x )
*
*
*
*  -- This version written on 25-October-1982.
*     Modified on 14-October-1993 to inline the call to DLASSQ.
*     Sven Hammarling, Nag Ltd.  */
{
    double absxi, norm;

    if (n<1 || incx<1) norm=0.0;
    else if (n==1) norm=fabs(x[1 -1]);
    else {
        double scale = 0.0,
             ssq   = 1.0;
/*       The following loop is equivalent to this call to the LAPACK
*        auxiliary routine:
*        DLASSQ( N, X, INCX, SCALE, SSQ )  */
        for (int ix=1; ix<=1 + ( n - 1 )*incx; ix += incx) {
            if (x[ix -1]) {
                absxi=fabs(x[ix -1]);
                if (scale<absxi) {
                    ssq = 1.0 + ssq*(scale/absxi)*(scale/absxi);
                    scale = absxi;
                } else ssq += (absxi/scale)*(absxi/scale);
            }
        }
        norm=scale*sqrt(ssq);
    }

    return norm;
}
//---------------------------------------------------------------------------
#define q(j,i) q[ ((((i)-1)*(ldq))+((j)-1)) ]

void UDavidsonBase::dopgtr(char uplo, int n, double ap[], double tau[], double q[], int ldq,
            double work[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DOPGTR generates a real orthogonal matrix Q which is defined as the
*  product of n-1 elementary reflectors H(i) of order n, as returned by
*  DSPTRD using packed storage:
*
*  if UPLO = 'U', Q = H(n-1) . . . H(2) H(1),
*
*  if UPLO = 'L', Q = H(1) H(2) . . . H(n-1).
*
*  Arguments
*  =========
*
*  UPLO    (input) CHARACTER*1
*          = 'U': Upper triangular packed storage used in previous
*                 call to DSPTRD;
*          = 'L': Lower triangular packed storage used in previous
*                 call to DSPTRD.
*
*  N       (input) INTEGER
*          The order of the matrix Q. N >= 0.
*
*  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
*          The vectors which define the elementary reflectors, as
*          returned by DSPTRD.
*
*  TAU     (input) DOUBLE PRECISION array, dimension (N-1)
*          TAU(i) must contain the scalar factor of the elementary
*          reflector H(i), as returned by DSPTRD.
*
*  Q       (output) DOUBLE PRECISION array, dimension (LDQ,N)
*          The N-by-N orthogonal matrix Q.
*
*  LDQ     (input) INTEGER
*          The leading dimension of the array Q. LDQ >= max(1,N).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (N-1)
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*/
{
    int iinfo, ij;

    //Test the input arguments
    *info = 0;
    bool upper = lsame( uplo, 'u' );
    if( !upper && !lsame( uplo, 'l' ) ) *info = -1;
        else if( n<0 ) *info = -2;
            else if( ldq<MAX( 1, n ) ) *info = -6;
    if( *info ) {
////        xerbla( "dopgtr ", -*info );
        return;
    }
    //Quick return if possible
    if( !n ) return;
    if( upper ) {
/*       Q was determined by a call to DSPTRD with UPLO = 'U'
*
*        Unpack the vectors which define the elementary reflectors and
*        set the last row and column of Q equal to those of the unit
*        matrix     */
        ij = 2;
        for (int j=1; j<=n-1; j++) {
            for (int i=1; i<=j-1; i++) {
                q( i,j ) = ap[ij -1];
                ++ij;
            }
            ij += 2;
            q( n,j ) = 0.0;
        }
        for (int i=1; i<=n-1; i++) q( i,n ) = 0.0;
        q( n,n ) = 1.0;
        //Generate Q(1:n-1,1:n-1)
        dorg2l( n-1, n-1, n-1, q, ldq, tau, work, &iinfo );
    } else {
/*       Q was determined by a call to DSPTRD with UPLO = 'L'.
*
*        Unpack the vectors which define the elementary reflectors and
*        set the first row and column of Q equal to those of the unit
*        matrix */
        q( 1,1 ) = 1.0;
        for (int i=2; i<=n; i++) q( i,1 ) = 0.0;
        ij = 3;
        for (int j=2; j<=n; j++) {
            q( 1,j ) = 0.0;
            for (int i=j+1; i<=n; i++) {
                q( i,j ) = ap[ij -1];
                ++ij;
            }
            ij += 2;
        }
        if( n>1 )
            //Generate Q(2:n,2:n)
            dorg2r( n-1, n-1, n-1, &q( 2,2 ), ldq, tau, work, &iinfo );
    }

    return;
}

#undef q //(j,i)
//---------------------------------------------------------------------------
#define c(j,i) c[ ((((i)-1)*(ldc))+((j)-1)) ]

void UDavidsonBase::dopmtr(char side, char uplo, char trans, int m, int n,
                    double ap[], double tau[], double c[], int ldc, double work[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DOPMTR overwrites the general real M-by-N matrix C with
*
*                  SIDE = 'L'     SIDE = 'R'
*  TRANS = 'N':      Q * C          C * Q
*  TRANS = 'T':      Q**T * C       C * Q**T
*
*  where Q is a real orthogonal matrix of order nq, with nq = m if
*  SIDE = 'L' and nq = n if SIDE = 'R'. Q is defined as the product of
*  nq-1 elementary reflectors, as returned by DSPTRD using packed
*  storage:
*
*  if UPLO = 'U', Q = H(nq-1) . . . H(2) H(1);
*
*  if UPLO = 'L', Q = H(1) H(2) . . . H(nq-1).
*
*  Arguments
*  =========
*
*  SIDE    (input) CHARACTER*1
*          = 'L': apply Q or Q**T from the Left;
*          = 'R': apply Q or Q**T from the Right.
*
*  UPLO    (input) CHARACTER*1
*          = 'U': Upper triangular packed storage used in previous
*                 call to DSPTRD;
*          = 'L': Lower triangular packed storage used in previous
*                 call to DSPTRD.
*
*  TRANS   (input) CHARACTER*1
*          = 'N':  No transpose, apply Q;
*          = 'T':  Transpose, apply Q**T.
*
*  M       (input) INTEGER
*          The number of rows of the matrix C. M >= 0.
*
*  N       (input) INTEGER
*          The number of columns of the matrix C. N >= 0.
*
*  AP      (input) DOUBLE PRECISION array, dimension
*                               (M*(M+1)/2) if SIDE = 'L'
*                               (N*(N+1)/2) if SIDE = 'R'
*          The vectors which define the elementary reflectors, as
*          returned by DSPTRD.  AP is modified by the routine but
*          restored on exit.
*
*  TAU     (input) DOUBLE PRECISION array, dimension (M-1) if SIDE = 'L'
*                                     or (N-1) if SIDE = 'R'
*          TAU(i) must contain the scalar factor of the elementary
*          reflector H(i), as returned by DSPTRD.
*
*  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
*          On entry, the M-by-N matrix C.
*          On exit, C is overwritten by Q*C or Q**T*C or C*Q**T or C*Q.
*
*  LDC     (input) INTEGER
*          The leading dimension of the array C. LDC >= max(1,M).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension
*                                   (N) if SIDE = 'L'
*                                   (M) if SIDE = 'R'
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*/
{
    bool forwrd;
    int i1, i2, i3, ic, jc, ii, mi, ni, nq;
    double aii;

    //Test the input arguments
    *info = 0;
    bool left = lsame( side, 'l' ),
         notran = lsame( trans, 'n' ),
         upper = lsame( uplo, 'u' );
    //NQ is the order of Q
    if( left ) nq = m;
        else nq = n;
    if( !left && !lsame( side, 'r' ) ) *info = -1;
        else if( !upper && !lsame( uplo, 'l' ) ) *info = -2;
            else if( !notran && !lsame( trans, 't' ) ) *info = -3;
                else if( m<0 ) *info = -4;
                    else if( n<0 ) *info = -5;
                        else if( ldc<MAX( 1, m ) ) *info = -9;
    if( *info ) {
////            xerbla( "dopmtr ", -*info );
            return;
    }
    //Quick return if possible
    if( !m || !n ) return;
    if( upper ) {
        // Q was determined by a call to DSPTRD with UPLO = 'U'
        forwrd = (( left && notran ) || ( !left && !notran ));
        if( forwrd ) {
            i1 = 1;
            i2 = nq - 1;
            i3 = 1;
            ii = 2;
        } else {
            i1 = nq - 1;
            i2 = 1;
            i3 = -1;
            ii = nq*( nq+1 ) / 2 - 1;
        }
        if( left ) ni = n;
        else  mi = m;
        for (int i=i1; forwrd?i<=i2:i>=i2; i+=i3) {
            if( left )
                    //H(i) is applied to C(1:i,1:n)
                    mi = i;
                else
                    //H(i) is applied to C(1:m,1:i)
                    ni = i;
            //Apply H(i)
            aii = ap[ii -1];
            ap[ii -1] = 1.0;
            dlarf( side, mi, ni, &ap[ii-i+1 -1], 1, tau[i -1], c, ldc, work );
            ap[ii -1] = aii;
            if( forwrd ) ii=ii+i+2;
                else ii=ii-i-1;
        }
    } else {
        //Q was determined by a call to DSPTRD with UPLO = 'L'.
        forwrd = (( left && !notran ) || ( !left && notran ));
        if( forwrd ) {
            i1 = 1;
            i2 = nq - 1;
            i3 = 1;
            ii = 2;
        } else {
            i1 = nq - 1;
            i2 = 1;
            i3 = -1;
            ii = nq*( nq+1 ) / 2 - 1;
        }
        if( left ) {
            ni = n;
            jc = 1;
        } else {
            mi = m;
            ic = 1;
        }
        for (int i=i1; forwrd?i<=i2:i>=i2; i+=i3) {
            aii = ap[ii -1];
            ap[ii -1] = 1.0;
            if( left ) {
                //H(i) is applied to C(i+1:m,1:n)
                mi = m - i;
                ic = i + 1;
            } else {
                //H(i) is applied to C(1:m,i+1:n)
                ni = n - i;
                jc = i + 1;
            }
            //Apply H(i)
            dlarf( side, mi, ni, &ap[ii -1], 1, tau[i -1], &c( ic,jc ), ldc, work );
            ap[ii -1] = aii;
            if( forwrd ) ii=ii+nq-i+1;
                else ii=ii-nq+i-2;
        }
    }

    return;
}

#undef c //(j,i)
//---------------------------------------------------------------------------
#define a(j,i) a[ ((((i)-1)*(lda))+((j)-1)) ]

void UDavidsonBase::dorg2l(int m, int n, int k, double a[], int lda, double tau[], double work[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     February 29, 1992
*
*
*  Purpose
*  =======
*
*  DORG2L generates an m by n real matrix Q with orthonormal columns,
*  which is defined as the last n columns of a product of k elementary
*  reflectors of order m
*
*        Q  =  H(k) . . . H(2) H(1)
*
*  as returned by DGEQLF.
*
*  Arguments
*  =========
*
*  M       (input) INTEGER
*          The number of rows of the matrix Q. M >= 0.
*
*  N       (input) INTEGER
*          The number of columns of the matrix Q. M >= N >= 0.
*
*  K       (input) INTEGER
*          The number of elementary reflectors whose product defines the
*          matrix Q. N >= K >= 0.
*
*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
*          On entry, the (n-k+i)-th column must contain the vector which
*          defines the elementary reflector H(i), for i = 1,2,...,k, as
*          returned by DGEQLF in the last k columns of its array
*          argument A.
*          On exit, the m by n matrix Q.
*
*  LDA     (input) INTEGER
*          The first dimension of the array A. LDA >= max(1,M).
*
*  TAU     (input) DOUBLE PRECISION array, dimension (K)
*          TAU(i) must contain the scalar factor of the elementary
*          reflector H(i), as returned by DGEQLF.
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
*
*  INFO    (output) INTEGER
*          = 0: successful exit
*          < 0: if INFO = -i, the i-th argument has an illegal value
*/
{
    int ii;

    //Test the input arguments
    *info = 0;
    if( m<0 ) *info = -1;
        else if( n<0 || n>m ) *info = -2;
            else if( k<0 || k>n ) *info = -3;
                else if( lda<MAX( 1, m ) ) *info = -5;
    if( *info ){
////        xerbla( "dorg2l ", -*info );
        return;
    }
    //Quick return if possible
    if( n<=0 ) return;
    //Initialise columns 1:n-k to columns of the unit matrix
    for (int j=1; j<=n-k; j++) {
        for (int l=1; l<=m; l++) a( l,j ) = 0.0;
            a( (m-n+j),j ) = 1.0;
    }
    for (int i=1; i<=k; i++) {
        ii = n - k + i;
        //Apply H(i) to A(1:m-k+i,1:n-k+i) from the left
        a( (m-n+ii),ii ) = 1.0;
        dlarf( 'l', m-n+ii, ii-1, &a( 1,ii ), 1, tau[i -1], a, lda, work );
        dscal( m-n+ii-1, -tau[i -1], &a( 1,ii ), 1 );
        a( (m-n+ii),ii ) = 1.0 - tau[i -1];
        //Set A(m-k+i+1:m,n-k+i) to zero
        for (int l=m-n+ii+1; l<=m; l++) a( l,ii )=0.0;
    }

    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
#define a(j,i) a[ ((((i)-1)*(lda))+((j)-1)) ]

void UDavidsonBase::dorg2r(int m, int n, int k, double a[], int lda, double tau[], double work[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     February 29, 1992
*
*
*  Purpose
*  =======
*
*  DORG2R generates an m by n real matrix Q with orthonormal columns,
*  which is defined as the first n columns of a product of k elementary
*  reflectors of order m
*
*        Q  =  H(1) H(2) . . . H(k)
*
*  as returned by DGEQRF.
*
*  Arguments
*  =========
*
*  M       (input) INTEGER
*          The number of rows of the matrix Q. M >= 0.
*
*  N       (input) INTEGER
*          The number of columns of the matrix Q. M >= N >= 0.
*
*  K       (input) INTEGER
*          The number of elementary reflectors whose product defines the
*          matrix Q. N >= K >= 0.
*
*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
*          On entry, the i-th column must contain the vector which
*          defines the elementary reflector H(i), for i = 1,2,...,k, as
*          returned by DGEQRF in the first k columns of its array
*          argument A.
*          On exit, the m-by-n matrix Q.
*
*  LDA     (input) INTEGER
*          The first dimension of the array A. LDA >= max(1,M).
*
*  TAU     (input) DOUBLE PRECISION array, dimension (K)
*          TAU(i) must contain the scalar factor of the elementary
*          reflector H(i), as returned by DGEQRF.
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
*
*  INFO    (output) INTEGER
*          = 0: successful exit
*          < 0: if INFO = -i, the i-th argument has an illegal value
*/
{
    //Test the input arguments
    *info = 0;
    if( m<0 ) *info = -1;
        else if( n<0 || n>m ) *info = -2;
            else if( k<0 || k>n ) *info = -3;
                else if( lda<MAX( 1, m ) ) *info = -5;
    if( *info ){
////        xerbla( "dorg2r ", -*info );
        return;
    }
    //Quick return if possible
    if( n<=0 ) return;
    //Initialise columns k+1:n to columns of the unit matrix
    for (int j=k+1; j<=n; j++) {
        for (int l=1; l<=m; l++) a( l,j )=0.0;
            a( j,j )=1.0;
    }
    for (int i=k; i>=1; i--) {
        //Apply H(i) to A(i:m,i:n) from the left
        if( i<n ) {
            a( i,i ) = 1.0;
            dlarf('l', m-i+1, n-i, &a( i,i ), 1, tau[i -1], &a( i,(i+1) ), lda, work );
            // czy nie powinno by�r zamiast l w arg. f. dlarf
        }
        if( i<m ) dscal( m-i, -tau[i -1], &a( (i+1),i ), 1 );
        a( i,i ) = 1.0 - tau[i -1];
        //Set A(1:i-1,i) to zero
        for (int l=1; l<=i-1; l++) a( l,i )=0.0;
    }
    return;
}

#undef a //(j,i)
//---------------------------------------------------------------------------
void UDavidsonBase::dscal(int n, double da, double dx[], int incx) const
/*   scales a vector by a constant.
     uses unrolled loops for increment equal to one.
     jack dongarra, linpack, 3/11/78.
     modified 3/93 to return if incx .le. 0.
     modified 12/3/93, array(1) declarations changed to array(*) */
{
    if (n<=0 || incx<=0) return;
    if (incx!=1) {
        //code for increment not equal to 1
        int nincx = n*incx;
        for (int i=1; i<=nincx; i+=incx) dx[i -1] *= da;
        return;
    }
/*      code for increment equal to 1

        clean-up loop  */
    int m=n%5;
    if (m) {
        for (int i=1; i<=m; i++) dx[i -1] = da*dx[i -1];
        if (n<5) return;
    }
    for (int i=m + 1; i<=n; i+=5) {
        dx[i -1] *= da;
        dx[i] *= da;
        dx[i + 1] *= da;
        dx[i + 2] *= da;
        dx[i + 3] *= da;
    }
    return;
}
//---------------------------------------------------------------------------
#define z(j,i) z[ ((((i)-1)*(ldz))+((j)-1)) ]

void UDavidsonBase::dspevx(char jobz, char range, char uplo, int n, double ap[], double vl,
            double vu, int il, int iu, double abstol, int *m, double w[], double z[],
            int ldz, double work[], int iwork[], int ifail[], int *info ) const
/**  -- LAPACK driver routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  DSPEVX computes selected eigenvalues and, optionally, eigenvectors
*  of a real symmetric matrix A in packed storage.  Eigenvalues/vectors
*  can be selected by specifying either a range of values or a range of
*  indices for the desired eigenvalues.
*
*  Arguments
*  =========
*
*  JOBZ    (input) CHARACTER*1
*          = 'N':  Compute eigenvalues only;
*          = 'V':  Compute eigenvalues and eigenvectors.
*
*  RANGE   (input) CHARACTER*1
*          = 'A': all eigenvalues will be found;
*          = 'V': all eigenvalues in the half-open interval (VL,VU]
*                 will be found;
*          = 'I': the IL-th through IU-th eigenvalues will be found.
*
*  UPLO    (input) CHARACTER*1
*          = 'U':  Upper triangle of A is stored;
*          = 'L':  Lower triangle of A is stored.
*
*  N       (input) INTEGER
*          The order of the matrix A.  N >= 0.
*
*  AP      (input/output) DOUBLE PRECISION array, dimension (N*(N+1)/2)
*          On entry, the upper or lower triangle of the symmetric matrix
*          A, packed columnwise in a linear array.  The j-th column of A
*          is stored in the array AP as follows:
*          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
*          if UPLO = 'L', AP(i + (j-1)*(2*n-j)/2) = A(i,j) for j<=i<=n.
*
*          On exit, AP is overwritten by values generated during the
*          reduction to tridiagonal form.  If UPLO = 'U', the diagonal
*          and first superdiagonal of the tridiagonal matrix T overwrite
*          the corresponding elements of A, and if UPLO = 'L', the
*          diagonal and first subdiagonal of T overwrite the
*          corresponding elements of A.
*
*  VL      (input) DOUBLE PRECISION
*  VU      (input) DOUBLE PRECISION
*          If RANGE='V', the lower and upper bounds of the interval to
*          be searched for eigenvalues. VL < VU.
*          Not referenced if RANGE = 'A' or 'I'.
*
*  IL      (input) INTEGER
*  IU      (input) INTEGER
*          If RANGE='I', the indices (in ascending order) of the
*          smallest and largest eigenvalues to be returned.
*          1 <= IL <= IU <= N, if N > 0; IL = 1 and IU = 0 if N = 0.
*          Not referenced if RANGE = 'A' or 'V'.
*
*  ABSTOL  (input) DOUBLE PRECISION
*          The absolute error tolerance for the eigenvalues.
*          An approximate eigenvalue is accepted as converged
*          when it is determined to lie in an interval [a,b]
*          of width less than or equal to
*
*                  ABSTOL + EPS *   max( |a|,|b| ) ,
*
*          where EPS is the machine precision.  If ABSTOL is less than
*          or equal to zero, then  EPS*|T|  will be used in its place,
*          where |T| is the 1-norm of the tridiagonal matrix obtained
*          by reducing AP to tridiagonal form.
*
*          Eigenvalues will be computed most accurately when ABSTOL is
*          set to twice the underflow threshold 2*DLAMCH('S'), not zero.
*          If this routine returns with INFO>0, indicating that some
*          eigenvectors did not converge, try setting ABSTOL to
*          2*DLAMCH('S').
*
*          See "Computing Small Singular Values of Bidiagonal Matrices
*          with Guaranteed High Relative Accuracy," by Demmel and
*          Kahan, LAPACK Working Note #3.
*
*  M       (output) INTEGER
*          The total number of eigenvalues found.  0 <= M <= N.
*          If RANGE = 'A', M = N, and if RANGE = 'I', M = IU-IL+1.
*
*  W       (output) DOUBLE PRECISION array, dimension (N)
*          If INFO = 0, the selected eigenvalues in ascending order.
*
*  Z       (output) DOUBLE PRECISION array, dimension (LDZ, max(1,M))
*          If JOBZ = 'V', then if INFO = 0, the first M columns of Z
*          contain the orthonormal eigenvectors of the matrix A
*          corresponding to the selected eigenvalues, with the i-th
*          column of Z holding the eigenvector associated with W(i).
*          If an eigenvector fails to converge, then that column of Z
*          contains the latest approximation to the eigenvector, and the
*          index of the eigenvector is returned in IFAIL.
*          If JOBZ = 'N', then Z is not referenced.
*          Note: the user must ensure that at least max(1,M) columns are
*          supplied in the array Z; if RANGE = 'V', the exact value of M
*          is not known in advance and an upper bound must be used.
*
*  LDZ     (input) INTEGER
*          The leading dimension of the array Z.  LDZ >= 1, and if
*          JOBZ = 'V', LDZ >= max(1,N).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (8*N)
*
*  IWORK   (workspace) INTEGER array, dimension (5*N)
*
*  IFAIL   (output) INTEGER array, dimension (N)
*          If JOBZ = 'V', then if INFO = 0, the first M elements of
*          IFAIL are zero.  If INFO > 0, then IFAIL contains the
*          indices of the eigenvectors that failed to converge.
*          If JOBZ = 'N', then IFAIL is not referenced.
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*          > 0:  if INFO = i, then i eigenvectors failed to converge.
*                Their indices are stored in array IFAIL.
*/
{
    char order;
    int i, iinfo, imax, indee, indibl, indisp, indiwo, itmp1, nsplit;
    double anrm, sigma, tmp1, vll, vuu;

    //Test the input parameters.
    bool wantz  = lsame( jobz, 'v' ),
         alleig = lsame( range, 'a' ),
         valeig = lsame( range, 'v' ),
         indeig = lsame( range, 'i' ),
         opusc  = false;

    *info = 0;
    if( !( wantz || lsame( jobz, 'n' ) ) ) *info = -1;
        else if( !( alleig || valeig || indeig ) ) *info = -2;
            else if( !( lsame( uplo, 'l' ) || lsame( uplo, 'u' ) ) )*info = -3;
                else if( n<0 ) *info = -4;
                    else {
                        if( valeig ) {
                            if( n>0 && vu<=vl ) *info = -7;
                        } else if( indeig ) {
                            if( il<1 || il>MAX( 1, n ) ) *info = -8;
                            else if( iu<MIN( n, il ) || iu>n ) *info = -9;
                        }
                    }
    if( !*info )
        if( ldz<1 || ( wantz && ldz<n ) ) *info = -14;
    if( *info ) {
////        xerbla( "dspevx ", -*info );
        return;
    }
    //Quick return if possible
    *m = 0;
    if( !n ) return;
    if( n==1 ) {
        if( alleig || indeig ) {
            *m = 1;
            w[0] = ap[0];
        } else if( vl<ap[0] && vu>=ap[0] ) {
            *m = 1;
            w[0] = ap[0];
        }
        if( wantz ) z( 1,1 ) = 1.0;
        return;
    }
    //Get machine constants.
    double safmin = dlamch('s'),
            eps = dlamch('p'),
         smlnum = safmin / eps,
         bignum = 1.0 / smlnum,
           rmin = sqrt(smlnum),
           rmax = MIN( sqrt( bignum ), 1.0 / sqrt( sqrt( safmin ) ) ),
         abstll = abstol;
    //Scale matrix to allowable range, if necessary.
    int iscale = 0;
    if( valeig ) {
        vll = vl;
        vuu = vu;
    } else vll = vuu = 0.0;
    anrm = dlansp( 'm', uplo, n, ap, work );
    if( anrm>0.0 && anrm<rmin ) {
        iscale = 1;
        sigma = rmin / anrm;
    } else if( anrm>rmax ) {
        iscale = 1;
        sigma = rmax / anrm;
    }
    if( iscale==1 ) {
        dscal( ( n*( n+1 ) ) / 2, sigma, ap, 1 );
        if( abstol>0 )
            abstll = abstol*sigma;
        if( valeig ) {
            vll = vl*sigma;
            vuu = vu*sigma;
        }
    }
    //Call DSPTRD to reduce symmetric packed matrix to tridiagonal form.
    int indtau = 1,
          inde = indtau + n,
          indd = inde + n,
        indwrk = indd + n;
    dsptrd( uplo, n, ap, &work[indd-1], &work[inde-1], &work[indtau-1], &iinfo);
/*    If all eigenvalues are desired and ABSTOL is less than or equal
*     to zero, then call DSTERF or DOPGTR and SSTEQR.  If this fails
*     for some eigenvalue, then try DSTEBZ. */
    if( ( alleig || ( indeig && il==1 && iu==n ) ) && ( abstol<=0.0 ) ) {
        dcopy( n, &work[indd -1], 1, w, 1 );
        indee = indwrk + 2*n;
        if( !wantz ) {
            dcopy( n-1, &work[inde-1], 1, &work[indee-1], 1 );
            dsterf( n, w, &work[indee-1], info );
        } else {
            dopgtr( uplo, n, ap, &work[indtau-1], z, ldz, &work[indwrk-1], &iinfo );
            dcopy( n-1, &work[inde-1], 1, &work[indee-1], 1 );
            dsteqr( jobz, n, w, &work[indee-1], z, ldz, &work[indwrk-1], info );
            if( !*info )
                for (i=1; i<=n; i++) ifail[i-1]=0;
        }
        if( !*info ) {
            *m = n;
            opusc=true;
        }
        if (!opusc) *info = 0;
    }
    if (!opusc) {
        opusc=false;
        //Otherwise, call DSTEBZ and, if eigenvectors are desired, SSTEIN.
        if( wantz ) order = 'b';
            else order = 'e';
        indibl = 1;
        indisp = indibl + n;
        indiwo = indisp + n;
        dstebz( range, order, n, vll, vuu, il, iu, abstll,
                &work[indd-1], &work[inde-1], m, &nsplit, w,
                &iwork[indibl-1], &iwork[indisp-1], &work[indwrk-1],
                &iwork[indiwo-1], info );
        if( wantz ) {
            dstein( n, &work[indd-1], &work[inde-1], *m, w,
                    &iwork[indibl-1], &iwork[indisp-1], z, ldz,
                    &work[indwrk-1], &iwork[indiwo-1], ifail, info );
/*       Apply orthogonal matrix used in reduction to tridiagonal
*        form to eigenvectors returned by DSTEIN.   */
            dopmtr( 'l', uplo, 'n', n, *m, ap, &work[indtau-1], z, ldz,
                    &work[indwrk-1], info );
        }
    }
    //If matrix was scaled, then rescale eigenvalues appropriately.
    if( iscale==1 ) {
        if( !*info ) imax = *m;
        else imax = *info - 1;
        dscal( imax, 1.0 / sigma, w, 1 );
    }
/*    If eigenvalues are not in order, then sort them, along with
*     eigenvectors. */
    if( wantz )
        for (int j=1; j<=*m - 1; j++) {
            i = 0;
            tmp1 = w[j-1];
            for (int jj=j+1; jj<=*m; jj++)
                if (w[jj-1]<tmp1) {
                    i = jj;
                    tmp1 = w[jj-1];
                }
            if( i ) {
                itmp1 = iwork[indibl+i-2];
                w[i-1] = w[j-1];
                iwork[indibl+i-2] = iwork[indibl+j-2];
                w[j-1] = tmp1;
                iwork[indibl+j-2] = itmp1;
                dswap( n, &z( 1, i ), 1, &z( 1, j ), 1 );
                if (*info) {
                    itmp1 = ifail[i-1];
                    ifail[i-1] = ifail[j-1];
                    ifail[j-1] = itmp1;
                }
            }
        }
    return;
}

#undef z //(j,i)
//---------------------------------------------------------------------------
void UDavidsonBase::dspmv(char uplo, int n, double alpha, double ap[], double x[], int incx,
           double beta, double y[], int incy ) const
/*  Purpose
*  =======
*
*  DSPMV  performs the matrix-vector operation
*
*     y := alpha*A*x + beta*y,
*
*  where alpha and beta are scalars, x and y are n element vectors and
*  A is an n by n symmetric matrix, supplied in packed form.
*
*  Parameters
*  ==========
*
*  UPLO   - CHARACTER*1.
*           On entry, UPLO specifies whether the upper or lower
*           triangular part of the matrix A is supplied in the packed
*           array AP as follows:
*
*              UPLO = 'U' or 'u'   The upper triangular part of A is
*                                  supplied in AP.
*
*              UPLO = 'L' or 'l'   The lower triangular part of A is
*                                  supplied in AP.
*
*           Unchanged on exit.
*
*  N      - INTEGER.
*           On entry, N specifies the order of the matrix A.
*           N must be at least zero.
*           Unchanged on exit.
*
*  ALPHA  - DOUBLE PRECISION.
*           On entry, ALPHA specifies the scalar alpha.
*           Unchanged on exit.
*
*  AP     - DOUBLE PRECISION array of DIMENSION at least
*           ( ( n*( n + 1 ) )/2 ).
*           Before entry with UPLO = 'U' or 'u', the array AP must
*           contain the upper triangular part of the symmetric matrix
*           packed sequentially, column by column, so that AP( 1 )
*           contains a( 1, 1 ), AP( 2 ) and AP( 3 ) contain a( 1, 2 )
*           and a( 2, 2 ) respectively, and so on.
*           Before entry with UPLO = 'L' or 'l', the array AP must
*           contain the lower triangular part of the symmetric matrix
*           packed sequentially, column by column, so that AP( 1 )
*           contains a( 1, 1 ), AP( 2 ) and AP( 3 ) contain a( 2, 1 )
*           and a( 3, 1 ) respectively, and so on.
*           Unchanged on exit.
*
*  X      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( n - 1 )*abs( INCX ) ).
*           Before entry, the incremented array X must contain the n
*           element vector x.
*           Unchanged on exit.
*
*  INCX   - INTEGER.
*           On entry, INCX specifies the increment for the elements of
*           X. INCX must not be zero.
*           Unchanged on exit.
*
*  BETA   - DOUBLE PRECISION.
*           On entry, BETA specifies the scalar beta. When BETA is
*           supplied as zero then Y need not be set on input.
*           Unchanged on exit.
*
*  Y      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( n - 1 )*abs( INCY ) ).
*           Before entry, the incremented array Y must contain the n
*           element vector y. On exit, Y is overwritten by the updated
*           vector y.
*
*  INCY   - INTEGER.
*           On entry, INCY specifies the increment for the elements of
*           Y. INCY must not be zero.
*           Unchanged on exit.
*
*
*  Level 2 Blas routine.
*
*  -- Written on 22-October-1986.
*     Jack Dongarra, Argonne National Lab.
*     Jeremy Du Croz, Nag Central Office.
*     Sven Hammarling, Nag Central Office.
*     Richard Hanson, Sandia National Labs.
*/
{
    double temp1, temp2;
    int info=0, ix, iy, jx, jy, k, kk, kx, ky;

    //Test the input parameters.
    if (!lsame(uplo,'u') && !lsame(uplo,'l')) info=1;
        else if (n<0) info=2;
            else if (!incx) info=6;
                else if (!incy) info=9;
    if (info) {
////        xerbla("dspmv", info);
        return;
    }
    //Quick return if possible.
    if (!n || (!alpha && (beta==1.0))) return;
    //Set up the start points in  X  and  Y.
    if (incx>0) kx=1;
        else kx = 1 - ( n - 1 )*incx;
    if (incy>0) ky=1;
        else ky = 1 - ( n - 1 )*incy;
/*     Start the operations. In this version the elements of the array AP
*     are accessed sequentially with one pass through AP.
*
*     First form  y := beta*y.      */
    if (beta!=1.0) {
        if (incy==1) {
            if (!beta)  for (int i=1; i<=n; i++) y[i-1]=0.0;
            else for (int i=1; i<=n; i++) y[i-1]*=beta;
        } else {
            iy=ky;
            if (!beta) {
                for (int i=1; i<=n; i++) {
                    y[iy -1]=0.0;
                    iy+=incy;
                }
            } else for (int i=1; i<=n; i++) {
                y[iy -1] *= beta;
                iy += incy;
            }
        }
    }
    if (!alpha) return;
    kk=1;
    if (lsame(uplo,'u')) {
        //Form  y  when AP contains the upper triangle.
        if ((incx==1) && (incy==1))
            for (int j=1; j<=n; j++) {
                temp1 = alpha*x[j-1];
                temp2 = 0.0;
                k     = kk;
                for (int i=1; i<=j-1; i++) {
                    y[i-1] += temp1*ap[k -1];
                    temp2 += ap[k -1]*x[i -1];
                    ++k;
                }
                y[j-1] += temp1*ap[kk + j - 2] + alpha*temp2;
                kk  += j;
            }
        else {
            jx = kx;
            jy = ky;
            for (int j=1; j<=n; j++) {
                temp1 = alpha*x[jx -1];
                temp2 = 0.0;
                ix    = kx;
                iy    = ky;
                for (k=kk; k<=kk+j-2; k++) {
                    y[iy-1] += temp1*ap[k -1];
                    temp2 += ap[k -1]*x[ix -1];
                    ix    += incx;
                    iy    += incy;
                }
                y[jy-1] += temp1*ap[kk + j - 1 -1]+alpha*temp2;
                jx    += incx;
                jy    += incy;
                kk    += j;
            }
        }
    } else {
        //Form  y  when AP contains the lower triangle.
        if ((incx==1) && (incy==1))
            for (int j=1; j<=n; j++) {
                temp1  = alpha*x[j -1];
                temp2  = 0.0;
                y[j-1] += temp1*ap[kk -1];
                k = kk+1;
                for (int i=j+1; i<=n; i++) {
                    y[i-1] += temp1*ap[k -1];
                    temp2 += ap[k -1]*x[i -1];
                    ++k;
                }
                y[j-1] += alpha*temp2;
                kk += ( n - j + 1 );
            }
        else {
            jx = kx;
            jy = ky;
            for (int j=1; j<=n; j++) {
                temp1 = alpha*x[jx -1];
                temp2 = 0.0;
                y[jy-1] += temp1*ap[kk -1];
                ix    = jx;
                iy    = jy;
                for (k=kk+1; k<=kk+n-j; k++) {
                    ix      += incx;
                    iy      += incy;
                    y[iy-1] += temp1*ap[k -1];
                    temp2   += ap[k -1]*x[ix -1];
                }
                y[jy-1] += alpha*temp2;
                jx    += incx;
                jy    += incy;
                kk    += ( n - j + 1 );
            }
        }
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dspr2(char uplo, int n, double alpha, double x[], int incx, double y[],
           int incy, double ap[]) const
/*  Purpose
*  =======
*
*  DSPR2  performs the symmetric rank 2 operation
*
*     A := alpha*x*y' + alpha*y*x' + A,
*
*  where alpha is a scalar, x and y are n element vectors and A is an
*  n by n symmetric matrix, supplied in packed form.
*
*  Parameters
*  ==========
*
*  UPLO   - CHARACTER*1.
*           On entry, UPLO specifies whether the upper or lower
*           triangular part of the matrix A is supplied in the packed
*           array AP as follows:
*
*              UPLO = 'U' or 'u'   The upper triangular part of A is
*                                  supplied in AP.
*
*              UPLO = 'L' or 'l'   The lower triangular part of A is
*                                  supplied in AP.
*
*           Unchanged on exit.
*
*  N      - INTEGER.
*           On entry, N specifies the order of the matrix A.
*           N must be at least zero.
*           Unchanged on exit.
*
*  ALPHA  - DOUBLE PRECISION.
*           On entry, ALPHA specifies the scalar alpha.
*           Unchanged on exit.
*
*  X      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( n - 1 )*abs( INCX ) ).
*           Before entry, the incremented array X must contain the n
*           element vector x.
*           Unchanged on exit.
*
*  INCX   - INTEGER.
*           On entry, INCX specifies the increment for the elements of
*           X. INCX must not be zero.
*           Unchanged on exit.
*
*  Y      - DOUBLE PRECISION array of dimension at least
*           ( 1 + ( n - 1 )*abs( INCY ) ).
*           Before entry, the incremented array Y must contain the n
*           element vector y.
*           Unchanged on exit.
*
*  INCY   - INTEGER.
*           On entry, INCY specifies the increment for the elements of
*           Y. INCY must not be zero.
*           Unchanged on exit.
*
*  AP     - DOUBLE PRECISION array of DIMENSION at least
*           ( ( n*( n + 1 ) )/2 ).
*           Before entry with  UPLO = 'U' or 'u', the array AP must
*           contain the upper triangular part of the symmetric matrix
*           packed sequentially, column by column, so that AP( 1 )
*           contains a( 1, 1 ), AP( 2 ) and AP( 3 ) contain a( 1, 2 )
*           and a( 2, 2 ) respectively, and so on. On exit, the array
*           AP is overwritten by the upper triangular part of the
*           updated matrix.
*           Before entry with UPLO = 'L' or 'l', the array AP must
*           contain the lower triangular part of the symmetric matrix
*           packed sequentially, column by column, so that AP( 1 )
*           contains a( 1, 1 ), AP( 2 ) and AP( 3 ) contain a( 2, 1 )
*           and a( 3, 1 ) respectively, and so on. On exit, the array
*           AP is overwritten by the lower triangular part of the
*           updated matrix.
*
*
*  Level 2 Blas routine.
*
*  -- Written on 22-October-1986.
*     Jack Dongarra, Argonne National Lab.
*     Jeremy Du Croz, Nag Central Office.
*     Sven Hammarling, Nag Central Office.
*     Richard Hanson, Sandia National Labs.
*/
{
    double temp1, temp2;
    int info=0, ix, iy, jx, jy, k, kk, kx, ky;

    //Test the input parameters.
    if (!lsame(uplo, 'u') && !lsame(uplo, 'l')) info=1;
        else if (n<0) info=2;
            else if (!incx) info=5;
                else if (!incy) info=7;
    if (info) {
////        xerbla("dspr2 ", info);
        return;
    }
    //Quick return if possible.
    if (!n || !alpha) return;
/*    Set up the start points in X and Y if the increments are not both
*     unity.    */
    if ((incx!=1) || (incy!=1)) {
        if (incx>0) kx=1;
            else kx = 1 - ( n - 1 )*incx;
        if (incy>0) ky=1;
            else ky = 1 - ( n - 1 )*incy;
        jx=kx;
        jy=ky;
    }
/*    Start the operations. In this version the elements of the array AP
*     are accessed sequentially with one pass through AP.   */
    kk=1;
    if (lsame(uplo, 'u')) {
        //Form  A  when upper triangle is stored in AP.
            if ((incx==1) && (incy==1)) {
                    for (int j=1; j<=n; j++) {
                        if (x[j-1] || y[j-1]) {
                            temp1=alpha*y[j-1];
                            temp2=alpha*x[j-1];
                            k=kk;
                            for (int i=1; i<=j; i++) {
                                ap[k-1]=ap[k-1]+x[i-1]*temp1+y[i-1]*temp2;
                                ++k;
                            }
                        }
                        kk += j;
                    }
            } else {
                for (int j=1; j<=n; j++) {
                    if (x[jx-1] || y[jy-1]) {
                        temp1=alpha*y[jy-1];
                        temp2=alpha*x[jx-1];
                        ix=kx;
                        iy=ky;
                        for (int k=kk; k<=kk+j-1; k++) {
                            ap[k-1] = ap[k-1] + x[ix-1]*temp1 + y[iy-1]*temp2;
                            ix += incx;
                            iy += incy;
                        }
                    }
                    jx+=incx;
                    jy+=incy;
                    kk+=j;
                }
            }
    } else {
        //Form  A  when lower triangle is stored in AP.
        if ((incx==1) && (incy==1)) {
            for (int j=1; j<=n; j++) {
                if (x[j-1] || y[j-1]) {
                    temp1=alpha*y[j-1];
                    temp2=alpha*x[j-1];
                    k=kk;
                    for (int i=j; i<=n; i++) {
                        ap[k-1] = ap[k-1]+x[i-1]*temp1+y[i-1]*temp2;
                        ++k;
                    }
                }
                kk=kk+n-j+1;
            }
        } else {
            for (int j=1; j<=n; j++) {
                if (x[jx-1] || y[jy-1]) {
                    temp1=alpha*y[jy-1];
                    temp2=alpha*x[jx-1];
                    ix=jx;
                    iy=jy;
                    for (int k=kk; k<=kk+n-j; k++) {
                        ap[k-1]=ap[k-1]+x[ix-1]*temp1+y[iy-1]*temp2;
                        ix   += incx;
                        iy   += incy;
                    }
                }
                jx += incx;
                jy += incy;
                kk = kk + n - j + 1;
            }
        }
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dsptrd(char uplo, int n, double ap[], double d[], double e[],
            double tau[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     March 31, 1993
*
*
*  Purpose
*  =======
*
*  DSPTRD reduces a real symmetric matrix A stored in packed form to
*  symmetric tridiagonal form T by an orthogonal similarity
*  transformation: Q**T * A * Q = T.
*
*  Arguments
*  =========
*
*  UPLO    (input) CHARACTER*1
*          = 'U':  Upper triangle of A is stored;
*          = 'L':  Lower triangle of A is stored.
*
*  N       (input) INTEGER
*          The order of the matrix A.  N >= 0.
*
*  AP      (input/output) DOUBLE PRECISION array, dimension (N*(N+1)/2)
*          On entry, the upper or lower triangle of the symmetric matrix
*          A, packed columnwise in a linear array.  The j-th column of A
*          is stored in the array AP as follows:
*          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
*          if UPLO = 'L', AP(i + (j-1)*(2*n-j)/2) = A(i,j) for j<=i<=n.
*          On exit, if UPLO = 'U', the diagonal and first superdiagonal
*          of A are overwritten by the corresponding elements of the
*          tridiagonal matrix T, and the elements above the first
*          superdiagonal, with the array TAU, represent the orthogonal
*          matrix Q as a product of elementary reflectors; if UPLO
*          = 'L', the diagonal and first subdiagonal of A are over-
*          written by the corresponding elements of the tridiagonal
*          matrix T, and the elements below the first subdiagonal, with
*          the array TAU, represent the orthogonal matrix Q as a product
*          of elementary reflectors. See Further Details.
*
*  D       (output) DOUBLE PRECISION array, dimension (N)
*          The diagonal elements of the tridiagonal matrix T:
*          D(i) = A(i,i).
*
*  E       (output) DOUBLE PRECISION array, dimension (N-1)
*          The off-diagonal elements of the tridiagonal matrix T:
*          E(i) = A(i,i+1) if UPLO = 'U', E(i) = A(i+1,i) if UPLO = 'L'.
*
*  TAU     (output) DOUBLE PRECISION array, dimension (N-1)
*          The scalar factors of the elementary reflectors (see Further
*          Details).
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*
*  Further Details
*  ===============
*
*  If UPLO = 'U', the matrix Q is represented as a product of elementary
*  reflectors
*
*     Q = H(n-1) . . . H(2) H(1).
*
*  Each H(i) has the form
*
*     H(i) = I - tau * v * v'
*
*  where tau is a real scalar, and v is a real vector with
*  v(i+1:n) = 0 and v(i) = 1; v(1:i-1) is stored on exit in AP,
*  overwriting A(1:i-1,i+1), and tau is stored in TAU(i).
*
*  If UPLO = 'L', the matrix Q is represented as a product of elementary
*  reflectors
*
*     Q = H(1) H(2) . . . H(n-1).
*
*  Each H(i) has the form
*
*     H(i) = I - tau * v * v'
*
*  where tau is a real scalar, and v is a real vector with
*  v(1:i) = 0 and v(i+1) = 1; v(i+2:n) is stored on exit in AP,
*  overwriting A(i+2:n,i), and tau is stored in TAU(i).
*/
{
    int i1, i1i1, ii;
    double alpha, taui;

    //Test the input parameters
    *info = 0;
    bool upper = lsame( uplo, 'u' );
    if (!upper && !lsame( uplo, 'l' )) *info = -1;
    else if( n<0 ) *info = -2;
    if( *info ) {
////        xerbla( "dsptrd ", -*info );
        return;
    }
    //Quick return if possible
    if( n<=0 ) return;
    if (upper) {
/*       Reduce the upper triangle of A.
*        I1 is the index in AP of A(1,I+1). */
        i1 = n*( n-1 ) / 2 + 1;
        for (int i=n-1; i>=1; i--) {
            //Generate elementary reflector H(i) = I - tau * v * v'
            //to annihilate A(1:i-1,i+1)
            dlarfg( i, &ap[i1+i-2], &ap[i1-1], 1, &taui );
            e[i-1] = ap[i1+i-2];
            if (taui) {
                // Apply H(i) from both sides to A(1:i,1:i)
                ap[i1+i-2] = 1.0;
                //Compute  y := tau * A * v  storing y in TAU(1:i)
                dspmv( uplo, i, taui, ap, &ap[i1-1], 1, 0.0, tau, 1 );
                //Compute  w := y - 1/2 * tau * (y'*v) * v
                alpha = -0.5*taui*ddot( i, tau, 1, &ap[i1-1], 1 );
                daxpy( i, alpha, &ap[i1-1], 1, tau, 1 );
                /*Apply the transformation as a rank-2 update:
                  A := A - v * w' - w * v'  */
                dspr2( uplo, i, -1.0, &ap[i1-1], 1, tau, 1, ap );
                ap[i1+i-2] = e[i-1];
            }
            d[i] = ap[i1+i-1];
            tau[i-1] = taui;
            i1 -= i;
        }
        d[0] = ap[0];
    } else {
    /*   Reduce the lower triangle of A. II is the index in AP of
        A(i,i) and I1I1 is the index of A(i+1,i+1).   */
        ii = 1;
        for (int i=1; i<=n-1; i++) {
            i1i1 = ii + n - i + 1;
            /* Generate elementary reflector H(i) = I - tau * v * v'
            to annihilate A(i+2:n,i)    */
            dlarfg( n-i, &ap[ii], &ap[ii+1], 1, &taui );
            e[i-1] = ap[ii];
            if (taui) {
                //Apply H(i) from both sides to A(i+1:n,i+1:n)
                ap[ii] = 1.0;
                //Compute  y := tau * A * v  storing y in TAU(i:n-1)
                dspmv( uplo, n-i, taui, &ap[i1i1-1], &ap[ii], 1, 0.0, &tau[i-1], 1 );
                //Compute  w := y - 1/2 * tau * (y'*v) * v
                alpha = -0.5*taui*ddot( n-i, &tau[i-1], 1, &ap[ii], 1 );
                daxpy( n-i, alpha, &ap[ii], 1, &tau[i-1], 1 );
                /* Apply the transformation as a rank-2 update:
*                  A := A - v * w' - w * v' */
                dspr2( uplo, n-i, -1.0, &ap[ii], 1, &tau[i-1], 1, &ap[i1i1-1] );
                ap[ii] = e[i-1];
            }
            d[i-1] = ap[ii-1];
            tau[i-1] = taui;
            ii = i1i1;
        }
        d[n-1] = ap[ii-1];
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dstebz(char range, char order, int n, double vl, double vu, int il, int iu,
            double abstol, double d[], double e[], int *m, int *nsplit, double w[],
            int iblock[], int isplit[], double work[], int iwork[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  DSTEBZ computes the eigenvalues of a symmetric tridiagonal
*  matrix T.  The user may ask for all eigenvalues, all eigenvalues
*  in the half-open interval (VL, VU], or the IL-th through IU-th
*  eigenvalues.
*
*  To avoid overflow, the matrix must be scaled so that its
*  largest element is no greater than overflow**(1/2) *
*  underflow**(1/4) in absolute value, and for greatest
*  accuracy, it should not be much smaller than that.
*
*  See W. Kahan "Accurate Eigenvalues of a Symmetric Tridiagonal
*  Matrix", Report CS41, Computer Science Dept., Stanford
*  University, July 21, 1966.
*
*  Arguments
*  =========
*
*  RANGE   (input) CHARACTER
*          = 'A': ("All")   all eigenvalues will be found.
*          = 'V': ("Value") all eigenvalues in the half-open interval
*                           (VL, VU] will be found.
*          = 'I': ("Index") the IL-th through IU-th eigenvalues (of the
*                           entire matrix) will be found.
*
*  ORDER   (input) CHARACTER
*          = 'B': ("By Block") the eigenvalues will be grouped by
*                              split-off block (see IBLOCK, ISPLIT) and
*                              ordered from smallest to largest within
*                              the block.
*          = 'E': ("Entire matrix")
*                              the eigenvalues for the entire matrix
*                              will be ordered from smallest to
*                              largest.
*
*  N       (input) INTEGER
*          The order of the tridiagonal matrix T.  N >= 0.
*
*  VL      (input) DOUBLE PRECISION
*  VU      (input) DOUBLE PRECISION
*          If RANGE='V', the lower and upper bounds of the interval to
*          be searched for eigenvalues.  Eigenvalues less than or equal
*          to VL, or greater than VU, will not be returned.  VL < VU.
*          Not referenced if RANGE = 'A' or 'I'.
*
*  IL      (input) INTEGER
*  IU      (input) INTEGER
*          If RANGE='I', the indices (in ascending order) of the
*          smallest and largest eigenvalues to be returned.
*          1 <= IL <= IU <= N, if N > 0; IL = 1 and IU = 0 if N = 0.
*          Not referenced if RANGE = 'A' or 'V'.
*
*  ABSTOL  (input) DOUBLE PRECISION
*          The absolute tolerance for the eigenvalues.  An eigenvalue
*          (or cluster) is considered to be located if it has been
*          determined to lie in an interval whose width is ABSTOL or
*          less.  If ABSTOL is less than or equal to zero, then ULP*|T|
*          will be used, where |T| means the 1-norm of T.
*
*          Eigenvalues will be computed most accurately when ABSTOL is
*          set to twice the underflow threshold 2*DLAMCH('S'), not zero.
*
*  D       (input) DOUBLE PRECISION array, dimension (N)
*          The n diagonal elements of the tridiagonal matrix T.
*
*  E       (input) DOUBLE PRECISION array, dimension (N-1)
*          The (n-1) off-diagonal elements of the tridiagonal matrix T.
*
*  M       (output) INTEGER
*          The actual number of eigenvalues found. 0 <= M <= N.
*          (See also the description of INFO=2,3.)
*
*  NSPLIT  (output) INTEGER
*          The number of diagonal blocks in the matrix T.
*          1 <= NSPLIT <= N.
*
*  W       (output) DOUBLE PRECISION array, dimension (N)
*          On exit, the first M elements of W will contain the
*          eigenvalues.  (DSTEBZ may use the remaining N-M elements as
*          workspace.)
*
*  IBLOCK  (output) INTEGER array, dimension (N)
*          At each row/column j where E(j) is zero or small, the
*          matrix T is considered to split into a block diagonal
*          matrix.  On exit, if INFO = 0, IBLOCK(i) specifies to which
*          block (from 1 to the number of blocks) the eigenvalue W(i)
*          belongs.  (DSTEBZ may use the remaining N-M elements as
*          workspace.)
*
*  ISPLIT  (output) INTEGER array, dimension (N)
*          The splitting points, at which T breaks up into submatrices.
*          The first submatrix consists of rows/columns 1 to ISPLIT(1),
*          the second of rows/columns ISPLIT(1)+1 through ISPLIT(2),
*          etc., and the NSPLIT-th consists of rows/columns
*          ISPLIT(NSPLIT-1)+1 through ISPLIT(NSPLIT)=N.
*          (Only the first NSPLIT elements will actually be used, but
*          since the user cannot know a priori what value NSPLIT will
*          have, N words must be reserved for ISPLIT.)
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (4*N)
*
*  IWORK   (workspace) INTEGER array, dimension (3*N)
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*          > 0:  some or all of the eigenvalues failed to converge or
*                were not computed:
*                =1 or 3: Bisection failed to converge for some
*                        eigenvalues; these eigenvalues are flagged by a
*                        negative block number.  The effect is that the
*                        eigenvalues may not be as accurate as the
*                        absolute and relative tolerances.  This is
*                        generally caused by unexpectedly inaccurate
*                        arithmetic.
*                =2 or 3: RANGE='I' only: Not all of the eigenvalues
*                        IL:IU were found.
*                        Effect: M < IU+1-IL
*                        Cause:  non-monotonic arithmetic, causing the
*                                Sturm sequence to be non-monotonic.
*                        Cure:   recalculate, using RANGE='A', and pick
*                                out eigenvalues IL:IU.  In some cases,
*                                increasing the PARAMETER "FUDGE" may
*                                make things work.
*                = 4:    RANGE='I', and the Gershgorin interval
*                        initially used was too small.  No eigenvalues
*                        were computed.
*                        Probable cause: your machine has sloppy
*                                        floating-point arithmetic.
*                        Cure: Increase the PARAMETER "FUDGE",
*                              recompile, and try again.
*
*  Internal Parameters
*  ===================
*
*  RELFAC  DOUBLE PRECISION, default = 2.0e0
*          The relative tolerance.  An interval (a,b] lies within
*          "relative tolerance" if  b-a < RELFAC*ulp*max(|a|,|b|),
*          where "ulp" is the machine precision (distance from 1 to
*          the next larger floating point number.)
*
*  FUDGE   DOUBLE PRECISION, default = 2
*          A "fudge factor" to widen the Gershgorin intervals.  Ideally,
*          a value of 1 should work, but on machines with sloppy
*          arithmetic, this needs to be larger.  The default for
*          publicly released versions should be large enough to handle
*          the worst machine around.  Note that this has no effect
*          on accuracy of the solution.
*/
{
    int ib, ibegin, idiscl, idiscu, ie, iend, iinfo, im, in, ioff, iorder,
         iout, irange, itmax, itmp1, iw, iwoff, nwl, nwu;
    double atoli, bnorm, gl, gu, pivmin, tmp1, tmp2, tnorm, wkill,
         wl, wlu, wu, wul;
    int idumma[1];

    *info = 0;
    //Decode RANGE
    if( lsame( range, 'a' ) ) irange = 1;
        else if( lsame( range, 'v' ) ) irange = 2;
            else if( lsame( range, 'i' ) ) irange = 3;
                else irange = 0;
    //Decode ORDER
    if( lsame( order, 'b' ) ) iorder = 2;
        else if( lsame( order, 'e' ) ) iorder = 1;
            else iorder = 0;
    //Check for Errors
    if( irange<=0 ) *info = -1;
        else if( iorder<=0 ) *info = -2;
            else if( n<0 ) *info = -3;
                else if( irange==2 ) {
                            if( vl>=vu ) *info = -5;
                    } else if( irange==3 && ( il<1 || il>MAX( 1, n ) ) ) *info = -6;
                            else if( irange==3 && ( iu<MIN( n, il ) || iu>n ) ) *info = -7;
    if( *info ) {
////        xerbla( "dstebz ", -*info );
        return;
    }
    //Initialize error flags
    *info = 0;
    bool ncnvrg = false,
         toofew = false;
    //Quick return if possible
    *m = 0;
    if( !n ) return;
    //Simplifications:
    if( irange==3 && il==1 && iu==n ) irange = 1;
/*    Get machine constants
*     NB is the minimum vector length for vector bisection, or 0
*     if only scalar is to be done. */
    double safemn = dlamch( 's' ),
            ulp = dlamch( 'p' ),
          rtoli = ulp*2.0;
    int nb = ilaenv( 1, "dstebz ", " ", n, -1, -1, -1 );
    if( nb<=1 ) nb = 0;
//Special Case when N=1
    if( n==1 ) {
        *nsplit = 1;
        isplit[0] = 1;
        if( irange==2 && ( vl>=d[0] || vu<d[0] ) ) *m = 0;
        else {
            w[0] = d[0];
            iblock[0] = 1;
            *m = 1;
        }
        return;
    }
    //Compute Splitting Points
    *nsplit = 1;
    work[n-1] = 0.0;
    pivmin = 1.0;
    for (int j=2; j<=n; j++) {
        tmp1 = e[j-2]*e[j-2];
        if( fabs( d[j-1]*d[j-2] )*ulp*ulp+safemn>tmp1 ) {
            isplit[*nsplit-1] = j - 1;
            (*nsplit)++;
            work[j-2] = 0.0;
        } else {
            work[j-2] = tmp1;
            pivmin = MAX( pivmin, tmp1 );
        }
    }
    isplit[*nsplit-1] = n;
    pivmin *= safemn;
    //Compute Interval and ATOLI
    if( irange==3 ) {
/*       RANGE='I': Compute the interval containing eigenvalues
*                   IL through IU.
*
*        Compute Gershgorin interval for entire (split) matrix
*        and use it as the initial interval */
        gu = gl = d[0];
        tmp1 = 0.0;
        for (int j=1; j<=n-1; j++) {
            tmp2 = sqrt( work[j -1] );
            gu = MAX( gu, d[j-1]+tmp1+tmp2 );
            gl = MIN( gl, d[j-1]-tmp1-tmp2 );
            tmp1 = tmp2;
        }
        gu = MAX( gu, d[n-1]+tmp1 );
        gl = MIN( gl, d[n-1]-tmp1 );
        tnorm = MAX( fabs( gl ), fabs( gu ) );
        gl = gl - 2.0*tnorm*ulp*n - 2.0*2.0*pivmin;
        gu = gu + 2.0*tnorm*ulp*n + 2.0*pivmin;
        //Compute Iteration parameters
        itmax = (int)(( log( tnorm+pivmin )-log( pivmin )) / log(2.0) ) + 2;
        if( abstol<=0.0 ) atoli = ulp*tnorm;
        else atoli = abstol;
        work[n] = gl;
        work[n+1] = gl;
        work[n+2] = gu;
        work[n+3] = gu;
        work[n+4] = gl;
        work[n+5] = gu;
        iwork[0] = -1;
        iwork[1] = -1;
        iwork[2] = n + 1;
        iwork[3] = n + 1;
        iwork[4] = il - 1;
        iwork[5] = iu;
        dlaebz( 3, itmax, n, 2, 2, nb, atoli, rtoli, pivmin, d, e,
               work, &iwork[4], &work[n], &work[n+4], &iout,
               iwork, w, iblock, &iinfo );
        if( iwork[6 -1]==iu ) {
            wl = work[n];
            wlu = work[n+2];
            nwl = iwork[0];
            wu = work[n+3];
            wul = work[n+1];
            nwu = iwork[3];
        } else {
            wl = work[n+1];
            wlu = work[n+3];
            nwl = iwork[1];
            wu = work[n+2];
            wul = work[n];
            nwu = iwork[2];
        }
        if( nwl<0 || nwl>=n || nwu<1 || nwu>n ) {
            *info = 4;
            return;
        }
    } else {
        //RANGE='A' or 'V' -- Set ATOLI
        tnorm = MAX(fabs( d[0] )+fabs( e[0] ), fabs( d[n-1] )+fabs(e[n-2]));
        for (int j=2; j<=n-1; j++)
            tnorm = MAX(tnorm, fabs( d[j-1] )+fabs( e[j-2] )+fabs(e[j-1]));
        if( abstol<=0.0 ) atoli = ulp*tnorm;
            else atoli = abstol;
        if( irange==2 ) {
            wl = vl;
            wu = vu;
        } else wl = wu = 0.0;
    }
/*    Find Eigenvalues -- Loop Over Blocks and recompute NWL and NWU.
*     NWL accumulates the number of eigenvalues .le. WL,
*     NWU accumulates the number of eigenvalues .le. WU */
    *m = iend = *info = nwl = nwu = 0;
    for (int jb=1; jb<=*nsplit; jb++) {
        ioff = iend;
        ibegin = ioff + 1;
        iend = isplit[jb -1];
        in = iend - ioff;
        if( in==1 ) {
            //Special Case -- IN=1
            if( irange==1 || wl>=d[ibegin-1]-pivmin ) ++nwl;
            if( irange==1 || wu>=d[ibegin-1]-pivmin ) ++nwu;
            if( irange==1 || (wl<d[ibegin-1]-pivmin && wu>=d[ibegin-1]-pivmin)){
                ++(*m);
                w[*m -1] = d[ibegin-1];
                iblock[*m-1] = jb;
            }
        } else {
        /*  General Case -- IN > 1

            Compute Gershgorin Interval
            and use it as the initial interval  */
            gu = gl = d[ibegin-1];
            tmp1 = 0.0;
            for (int j=ibegin; j<=iend-1; j++) {
                tmp2 = fabs( e[j-1] );
                gu = MAX( gu, d[j-1]+tmp1+tmp2 );
                gl = MIN( gl, d[j-1]-tmp1-tmp2 );
                tmp1 = tmp2;
            }
            gu = MAX( gu, d[iend-1]+tmp1 );
            gl = MIN( gl, d[iend-1]-tmp1 );
            bnorm = MAX( fabs( gl ), fabs( gu ) );
            gl = gl - 2.0*bnorm*ulp*in - 2.0*pivmin;
            gu = gu + 2.0*bnorm*ulp*in + 2.0*pivmin;
            //Compute ATOLI for the current submatrix
            if( abstol<=0.0 ) atoli = ulp*MAX( fabs( gl ), fabs( gu ) );
            else atoli = abstol;
            if( irange>1 ) {
                if (gu<wl) {
                    nwl += in;
                    nwu += in;
                    continue;
                }
                gl = MAX( gl, wl );
                gu = MIN( gu, wu );
                if( gl>=gu ) continue;
            }
            //Set Up Initial Interval
            work[n] = gl;
            work[n+in] = gu;
            dlaebz( 1, 0, in, in, 1, nb, atoli, rtoli, pivmin,
                    &d[ibegin-1], &e[ibegin-1], &work[ibegin-1],
                    idumma, &work[n], &work[n+2*in], &im,
                    iwork, &w[*m], &iblock[*m], &iinfo );
            nwl += iwork[1 -1];
            nwu += iwork[in+1 -1];
            iwoff = *m - iwork[1 -1];
            //Compute Eigenvalues
            itmax = (int)( (log( gu-gl+pivmin )-log( pivmin ))/log(2.0)) + 2;
            dlaebz( 2, itmax, in, in, 1, nb, atoli, rtoli, pivmin,
                    &d[ibegin-1], &e[ibegin-1], &work[ibegin-1],
                    idumma, &work[n], &work[n+2*in], &iout,
                    iwork, &w[*m], &iblock[*m], &iinfo );
    /*      Copy Eigenvalues Into W and IBLOCK
            Use -JB for block number for unconverged eigenvalues.   */
            for (int j=1; j<=iout; j++) {
                tmp1 = 0.5*( work[j+n-1]+work[j+in+n-1] );
                //Flag non-convergence.
                if( j>iout-iinfo ) {
                    ncnvrg = true;
                    ib = -jb;
                } else ib = jb;
                for (int je=iwork[j-1]+1+iwoff; je<=iwork[j+in-1]+iwoff; je++){
                    w[je-1] = tmp1;
                    iblock[je-1] = ib;
                }
            }
            *m += im;
        }
    }
/*    If RANGE='I', then (WL,WU) contains eigenvalues NWL+1,...,NWU
*     If NWL+1 < IL or NWU > IU, discard extra eigenvalues. */
    if( irange==3 ) {
        im = 0;
        idiscl = il - 1 - nwl;
        idiscu = nwu - iu;
        if( idiscl>0 || idiscu>0 ) {
            for (int je=1; je<=*m; je++) {
                if( w[je -1]<=wlu && idiscl>0 ) idiscl--;
                    else if( w[je -1]>=wul && idiscu>0 ) idiscu--;
                        else {
                            im++;
                            w[im-1] = w[je-1];
                            iblock[im-1] = iblock[je-1];
                        }
            }
            *m = im;
        }
        if( idiscl>0 || idiscu>0 ) {
/*          Code to deal with effects of bad arithmetic:
*           Some low eigenvalues to be discarded are not in (WL,WLU],
*           or high eigenvalues to be discarded are not in (WUL,WU]
*           so just kill off the smallest IDISCL/largest IDISCU
*           eigenvalues, by simply finding the smallest/largest
*           eigenvalue(s).
*
*           (If N(w) is monotone non-decreasing, this should never
*               happen.)    */
            if( idiscl>0 ) {
                wkill = wu;
                for (int jdisc=1; jdisc<=idiscl; jdisc++) {
                    iw = 0;
                    for (int je=1; je<=*m; je++)
                        if (iblock[je-1] && ( w[je-1]<wkill || !iw )) {
                            iw = je;
                            wkill = w[je-1];
                        }
                    iblock[iw -1] = 0;
                }
            }
            if( idiscu>0 ) {
                wkill = wl;
                for (int jdisc=1; jdisc<=idiscu; jdisc++) {
                    iw = 0;
                    for (int je=1; je<=*m; je++)
                        if (iblock[je-1] && ( w[je-1]>wkill || !iw )) {
                            iw = je;
                            wkill = w[je -1];
                        }
                    iblock[iw-1] = 0;
                }
            }
            im = 0;
            for (int je=1; je<=*m; je++)
                if( iblock[je-1] ) {
                    im++;
                    w[im-1] = w[je-1];
                    iblock[im-1] = iblock[je-1];
                }
            *m = im;
        }
        if( idiscl<0 || idiscu<0 ) toofew=true;
    }
/*    If ORDER='B', do nothing -- the eigenvalues are already sorted
*        by block.
*     If ORDER='E', sort the eigenvalues from smallest to largest   */
    if( iorder==1 && *nsplit>1 )
        for (int je=1; je<=*m-1; je++) {
            ie = 0;
            tmp1 = w[je -1];
            for (int j=je+1; j<=*m; j++)
                if (w[j -1]<tmp1) {
                    ie = j;
                    tmp1 = w[j-1];
                }
            if( ie ) {
                itmp1 = iblock[ie-1];
                w[ie-1] = w[je-1];
                iblock[ie-1] = iblock[je-1];
                w[je-1] = tmp1;
                iblock[je-1] = itmp1;
            }
        }
    *info = 0;
    if( ncnvrg ) *info++;
    if( toofew ) *info += 2;

    return;
}
//---------------------------------------------------------------------------
#define z(j,i) z[ ((((i)-1)*(ldz))+((j)-1)) ]

void UDavidsonBase::dstein(int n, double d[], double e[], int m, double w[], int iblock[],
            int isplit[], double z[], int ldz, double work[], int iwork[],
            int ifail[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DSTEIN computes the eigenvectors of a real symmetric tridiagonal
*  matrix T corresponding to specified eigenvalues, using inverse
*  iteration.
*
*  The maximum number of iterations allowed for each eigenvector is
*  specified by an internal parameter MAXITS (currently set to 5).
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The order of the matrix.  N >= 0.
*
*  D       (input) DOUBLE PRECISION array, dimension (N)
*          The n diagonal elements of the tridiagonal matrix T.
*
*  E       (input) DOUBLE PRECISION array, dimension (N)
*          The (n-1) subdiagonal elements of the tridiagonal matrix
*          T, in elements 1 to N-1.  E(N) need not be set.
*
*  M       (input) INTEGER
*          The number of eigenvectors to be found.  0 <= M <= N.
*
*  W       (input) DOUBLE PRECISION array, dimension (N)
*          The first M elements of W contain the eigenvalues for
*          which eigenvectors are to be computed.  The eigenvalues
*          should be grouped by split-off block and ordered from
*          smallest to largest within the block.  ( The output array
*          W from DSTEBZ with ORDER = 'B' is expected here. )
*
*  IBLOCK  (input) INTEGER array, dimension (N)
*          The submatrix indices associated with the corresponding
*          eigenvalues in W; IBLOCK(i)=1 if eigenvalue W(i) belongs to
*          the first submatrix from the top, =2 if W(i) belongs to
*          the second submatrix, etc.  ( The output array IBLOCK
*          from DSTEBZ is expected here. )
*
*  ISPLIT  (input) INTEGER array, dimension (N)
*          The splitting points, at which T breaks up into submatrices.
*          The first submatrix consists of rows/columns 1 to
*          ISPLIT( 1 ), the second of rows/columns ISPLIT( 1 )+1
*          through ISPLIT( 2 ), etc.
*          ( The output array ISPLIT from DSTEBZ is expected here. )
*
*  Z       (output) DOUBLE PRECISION array, dimension (LDZ, M)
*          The computed eigenvectors.  The eigenvector associated
*          with the eigenvalue W(i) is stored in the i-th column of
*          Z.  Any vector which fails to converge is set to its current
*          iterate after MAXITS iterations.
*
*  LDZ     (input) INTEGER
*          The leading dimension of the array Z.  LDZ >= max(1,N).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (5*N)
*
*  IWORK   (workspace) INTEGER array, dimension (N)
*
*  IFAIL   (output) INTEGER array, dimension (M)
*          On normal exit, all elements of IFAIL are zero.
*          If one or more eigenvectors fail to converge after
*          MAXITS iterations, then their indices are stored in
*          array IFAIL.
*
*  INFO    (output) INTEGER
*          = 0: successful exit.
*          < 0: if INFO = -i, the i-th argument had an illegal value
*          > 0: if INFO = i, then i eigenvectors failed to converge
*               in MAXITS iterations.  Their indices are stored in
*               array IFAIL.
*
*  Internal Parameters
*  ===================
*
*  MAXITS  INTEGER, default = 5
*          The maximum number of iterations performed.
*
*  EXTRA   INTEGER, default = 2
*          The number of iterations performed after norm growth
*          criterion is satisfied, should be at least 1.
*/
{
    double odm3=1.0e-3, odm1=1.0e-1;
    int b1, blksiz, bn, gpind, iinfo, indrv1, indrv2, indrv3, indrv4,
         indrv5, its, j1, jblk, jmax, nrmchk;
    double dtpcrt, eps, eps1, nrm, onenrm, ortol, pertol, scl, sep, tol, xj, xjm=0, ztr;
    int iseed[4];

    //Test the input parameters.
    *info = 0;
    for (int i=1; i<=m; i++) ifail[i-1] = 0;
    if( n<0 ) *info = -1;
        else if( m<0 || m>n ) *info = -4;
            else if( ldz<MAX( 1, n ) ) *info = -9;
                else for (int j=2; j<=m; j++) {
                        if( iblock[j-1]<iblock[j-2] ) {
                            *info = -6;
                            break;
                        }
                        if( iblock[j-1]==iblock[j-2] && w[j-1]<w[j-2] ) {
                            *info = -5;
                            break;
                        }
                     }
    if( *info ) {
////        xerbla( "dstein ", -*info );
        return;
    }
    //Quick return if possible
    if( !n || !m ) return;
    else if( n==1 ) {
        z( 1,1 ) = 1.0;
        return;
    }
    //Get machine constants.
    eps = dlamch( 'p' );
    //Initialize seed for random number generator DLARNV.
    for (int i=1; i<=4; i++) iseed[i-1] = 1;
    //Initialize pointers.
    indrv1 = 0;
    indrv2 = indrv1 + n;
    indrv3 = indrv2 + n;
    indrv4 = indrv3 + n;
    indrv5 = indrv4 + n;
    //Compute eigenvectors of matrix blocks.
    j1 = 1;
    for (int nblk=1; nblk<=iblock[m-1]; nblk++) {
        //Find starting and ending indices of block nblk.
        if( nblk==1 ) b1=1;
        else b1=isplit[nblk-2]+1;
        bn = isplit[nblk -1];
        blksiz = bn - b1 + 1;
        if( blksiz!=1 ) {
            gpind = b1;
            //Compute reorthogonalization criterion and stopping criterion.
            onenrm = fabs( d[b1-1] ) + fabs( e[b1-1] );
            onenrm = MAX( onenrm, fabs( d[bn-1] )+fabs( e[bn-2] ) );
            for (int i=b1+1; i<=bn-1; i++)
                onenrm = MAX( onenrm, fabs( d[i-1] )+fabs( e[i-2] )+fabs( e[i-1] ) );
            ortol = odm3*onenrm;
            dtpcrt = sqrt( odm1 / blksiz );
            //Loop through eigenvalues of block nblk.
        }
        jblk = 0;
        for (int j=j1; j<=m; j++) {
            if( iblock[j -1]!=nblk ) {
                j1 = j;
                break;
            }
            jblk += 1;
            xj = w[j -1];
            //Skip all the work if the block size is one.
            if( blksiz==1 ) work[indrv1] = 1.0;
            else {
                /* If eigenvalues j and j-1 are too close, add a relatively
                small perturbation. */
                if( jblk>1 ) {
                    eps1 = fabs( eps*xj );
                    pertol = 10.0*eps1;
                    sep = xj - xjm;
                    if( sep<pertol ) xj=xjm+pertol;
                }
                its = 0;
                nrmchk = 0;
                //Get random starting vector.
                dlarnv( 2, iseed, blksiz, &work[indrv1] );
                //Copy the matrix T so it won't be destroyed in factorization.
                dcopy( blksiz, &d[b1 -1], 1, &work[indrv4], 1 );
                dcopy( blksiz-1, &e[b1 -1], 1, &work[indrv2+1], 1 );
                dcopy( blksiz-1, &e[b1 -1], 1, &work[indrv3], 1 );
                //Compute LU factors with partial pivoting  ( PT = LU )
                tol = 0.0;
                dlagtf( blksiz, &work[indrv4], xj, &work[indrv2+1],
                        &work[indrv3], tol, &work[indrv5], iwork,
                        &iinfo );
                do {
                    do {
                        //Update iteration count.
                        its++;
                        if( its>5 ) {
                        /*  If stopping criterion was not satisfied, update info and
                            store eigenvector number in array ifail.    */
                            *info++;
                            ifail[*info -1] = j;
                            break;
                        }
                        //Normalize and scale the righthand side vector Pb.
                        scl=blksiz*onenrm*MAX(eps,fabs(work[indrv4+blksiz-1]))/dasum(blksiz,&work[indrv1],1);
                        dscal( blksiz, scl, &work[indrv1], 1 );
                        //Solve the system LU = Pb.
                        dlagts( -1, blksiz, &work[indrv4], &work[indrv2+1],
                                &work[indrv3], &work[indrv5], iwork,
                                &work[indrv1], &tol, &iinfo );
                        /*Reorthogonalize by modified Gram-Schmidt if eigenvalues are
*                         close enough.     */
                        if( jblk!=1 ) {
                            if( fabs( xj-xjm )>ortol ) gpind = j;
                            if( gpind!=j )
                                for (int i=gpind; i<=j-1; i++) {
                                    ztr = -ddot( blksiz, &work[indrv1], 1, &z( b1,i ), 1 );
                                    daxpy( blksiz, ztr, &z( b1,i ), 1, &work[indrv1], 1 );
                                }
                        }
                        //Check the infinity norm of the iterate.
                        jmax = idamax( blksiz, &work[indrv1], 1 );
                        nrm = fabs( work[indrv1+jmax -1] );
                    /* Continue for additional iterations after norm reaches
                       stopping criterion.   */
                    } while (nrm<dtpcrt);
                    if( its>5 ) break;
                    nrmchk++;
                } while (nrmchk<3);
                //Accept iterate as jth eigenvector.
                scl = 1.0 / dnrm2( blksiz, &work[indrv1], 1 );
                jmax = idamax( blksiz, &work[indrv1], 1 );
                if( work[indrv1+jmax -1]<0.0 ) scl = -scl;
                dscal( blksiz, scl, &work[indrv1], 1 );
            }
            for (int i=1; i<=n; i++) z( i,j ) = 0.0;
            for (int i=1; i<=blksiz; i++) z( (b1+i-1),j ) = work[ indrv1+i  -1];
            /* Save the shift to check eigenvalue spacing at next
               iteration.   */
            xjm = xj;
        }
    }
    return;
}

#undef z //(j,i)
//---------------------------------------------------------------------------
#define z(j,i) z[ ((((i)-1)*(ldz))+((j)-1)) ]

void UDavidsonBase::dsteqr_140(int *jtot, int *n, int *iscale, double *ssfmin,  double *ssfmax,
                double *anorm, int *lendsv, int *nmaxit, int *lsv, double d[],
                double e[], int *info) const
{
    if( *iscale==1 ) {
        dlascl( 'g', 0, 0, *ssfmax, *anorm, *lendsv-*lsv+1, 1, &d[ *lsv -1], *n, info );
        dlascl( 'g', 0, 0, *ssfmax, *anorm, *lendsv-*lsv, 1, &e[ *lsv -1], *n, info );
    } else if( *iscale==2 ) {
        dlascl( 'g', 0, 0, *ssfmin, *anorm, *lendsv-*lsv+1, 1, &d[ *lsv -1], *n, info );
        dlascl( 'g', 0, 0, *ssfmin, *anorm, *lendsv-*lsv, 1, &e[ *lsv -1], *n, info );
    }
    return;
}

void UDavidsonBase::dsteqr(char compz, int n, double d[], double e[], double z[], int ldz,
            double work[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  DSTEQR computes all eigenvalues and, optionally, eigenvectors of a
*  symmetric tridiagonal matrix using the implicit QL or QR method.
*  The eigenvectors of a full or band symmetric matrix can also be found
*  if DSYTRD or DSPTRD or DSBTRD has been used to reduce this matrix to
*  tridiagonal form.
*
*  Arguments
*  =========
*
*  COMPZ   (input) CHARACTER*1
*          = 'N':  Compute eigenvalues only.
*          = 'V':  Compute eigenvalues and eigenvectors of the original
*                  symmetric matrix.  On entry, Z must contain the
*                  orthogonal matrix used to reduce the original matrix
*                  to tridiagonal form.
*          = 'I':  Compute eigenvalues and eigenvectors of the
*                  tridiagonal matrix.  Z is initialized to the identity
*                  matrix.
*
*  N       (input) INTEGER
*          The order of the matrix.  N >= 0.
*
*  D       (input/output) DOUBLE PRECISION array, dimension (N)
*          On entry, the diagonal elements of the tridiagonal matrix.
*          On exit, if INFO = 0, the eigenvalues in ascending order.
*
*  E       (input/output) DOUBLE PRECISION array, dimension (N-1)
*          On entry, the (n-1) subdiagonal elements of the tridiagonal
*          matrix.
*          On exit, E has been destroyed.
*
*  Z       (input/output) DOUBLE PRECISION array, dimension (LDZ, N)
*          On entry, if  COMPZ = 'V', then Z contains the orthogonal
*          matrix used in the reduction to tridiagonal form.
*          On exit, if INFO = 0, then if  COMPZ = 'V', Z contains the
*          orthonormal eigenvectors of the original symmetric matrix,
*          and if COMPZ = 'I', Z contains the orthonormal eigenvectors
*          of the symmetric tridiagonal matrix.
*          If COMPZ = 'N', then Z is not referenced.
*
*  LDZ     (input) INTEGER
*          The leading dimension of the array Z.  LDZ >= 1, and if
*          eigenvectors are desired, then  LDZ >= max(1,N).
*
*  WORK    (workspace) DOUBLE PRECISION array, dimension (max(1,2*N-2))
*          If COMPZ = 'N', then WORK is not referenced.
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*          > 0:  the algorithm has failed to find all the eigenvalues in
*                a total of 30*N iterations; if INFO = i, then i
*                elements of E have not converged to zero; on exit, D
*                and E contain the elements of a symmetric tridiagonal
*                matrix which is orthogonally similar to the original
*                matrix.
*/
{
    int maxit=30;
    int i, icompz, iscale, k, l, lend,
         lendm1, lendp1, lendsv, lm1, lsv, m, mm, mm1;
    double anorm, b, c, f, g, p, r, rt1, rt2, s, tst;

    bool   opusc=false, opusc60=false, opusc110=false, opuscMqeL=true;

    //Test the input parameters.
    *info = 0;
    if( lsame( compz, 'n' ) ) icompz = 0;
        else if( lsame( compz, 'v' ) ) icompz = 1;
            else if( lsame( compz, 'i' ) ) icompz = 2;
                else icompz = -1;
    if( icompz<0 ) *info = -1;
        else if( n<0 ) *info = -2;
            else if( ( ldz<1 ) || ( icompz>0 && ldz<MAX( 1, n ) ) ) *info = -6;
    if( *info ){
////        xerbla( "dsteqr ", -*info );
        return;
    }
    //Quick return if possible
    if( !n ) return;
    if( n==1 ) {
        if( icompz==2 ) z( 1, 1 ) = 1.0;
        return;
    }
    //Determine the unit roundoff and over/underflow thresholds.
    double eps = dlamch( 'e' ),
        eps2 = eps*eps,
      safmin = dlamch( 's' ),
      safmax = 1.0 / safmin,
      ssfmax = sqrt( safmax ) / 3.0,
      ssfmin = sqrt( safmin ) / eps2;
/*    Compute the eigenvalues and eigenvectors of the tridiagonal
*     matrix.   */
    if( icompz==2 ) dlaset( 'f', n, n, 0.0, 1.0, z, ldz );
    int nmaxit = n*maxit,
           jtot = 0,
/*    Determine where the matrix splits and choose QL or QR iteration
*     for each block, according to whether top or bottom diagonal
*     element is smaller.   */
             l1 = 1,
            nm1 = n - 1;

    while (l1<=n) {
        if (l1>1) e[l1-2] = 0.0;
        if ( l1<=nm1 )
            for (m = l1; m <=nm1; m++) {
                tst = fabs( e[m-1] );
                if ( !tst ) {
                    opusc=true;
                    break;
                }
                if( tst<=( sqrt( fabs( d[m-1] ) )*sqrt( fabs( d[m] ) ) )*eps ) {
                    e[m-1] = 0.0;
                    opusc=true;
                    break;
                }
            }
        if (!opusc) m = n;
        opusc=false;
        l = l1;
        lsv = l;
        lend = m;
        lendsv = lend;
        l1 = m + 1;

        if (lend==l) continue;
        //Scale submatrix in rows and columns L to LEND
        anorm = dlanst( 'i', lend-l+1, &d[l-1], &e[l-1] );
        iscale = 0;
        if ( !anorm ) continue;

        if( anorm>ssfmax ) {
            iscale = 1;
            dlascl( 'g', 0, 0, anorm, ssfmax, lend-l+1, 1, &d[l-1], n, info );
            dlascl( 'g', 0, 0, anorm, ssfmax, lend-l, 1, &e[l-1], n, info );
        } else if ( anorm<ssfmin ) {
            iscale = 2;
            dlascl( 'g', 0, 0, anorm, ssfmin, lend-l+1, 1, &d[l-1], n, info );
            dlascl( 'g', 0, 0, anorm, ssfmin, lend-l, 1, &e[l-1], n, info );
        }
        //Choose between QL and QR iteration
        if( fabs( d[lend-1] )< fabs( d[l-1] ) ) {
            lend = lsv;
            l = lendsv;
        }
/*       QL Iteration
*
*        Look for small subdiagonal element.    */
        if( lend>l ) {
            do {
                if( l!=lend ) {
                    lendm1 = lend - 1;
                    for (m = l; m<=lendm1; m++) {
                        tst = pow(fabs( e[m-1] ),2);
                        if( tst<=( eps2*fabs( d[m-1] ) )*fabs( d[m] )+ safmin ) {
                            opusc60=true;
                            break;
                        }
                    }
                }
                if (!opusc60) m = lend;
                opusc60=false;
                if( m<lend ) e[m-1] = 0.0;
                p = d[l-1];
                if( m!=l ) {
                /*  If remaining matrix is 2-by-2, use DLAE2 or SLAEV2
                    to compute its eigensystem. */
                    if( m==(l+1) ) {
                        if( icompz>0 ) {
                            dlaev2( d[l-1], e[l-1], d[l], &rt1, &rt2, &c, &s );
                            work[l-1] = c;
                            work[n-2+l] = s;
                            dlasr( 'r', 'v', 'b', n, 2, &work[l-1], &work[n-2+l], &z( 1, l ), ldz );
                        } else dlae2( d[l-1], e[l-1], d[l], &rt1, &rt2 );
                        d[l-1] = rt1;
                        d[l] = rt2;
                        e[l-1] = 0.0;
                        l += 2;
                        if( l<=lend ) continue;
                        opuscMqeL=false;
                        break;
                    }
                    if( jtot==nmaxit ) {
                        dsteqr_140(&jtot, &n, &iscale, &ssfmin, &ssfmax, &anorm, &lendsv, &nmaxit, &lsv, d, e, info);
                        if( jtot<nmaxit ) continue;
                        for (int i=1; i<=n-1; i++)
                            if( e[i-1] ) ++*info;
                        return;
                    }
                    ++jtot;
                    //Form shift.
                    g = ( d[l]-p ) / ( 2.0*e[l-1] );
                    r = dlapy2( g, 1.0 );
                    g = d[m-1] - p + ( e[l-1] / ( g+sign( &r, &g ) ) );
                    s = c = 1.0;
                    p = 0.0;
                    //Inner loop
                    mm1 = m - 1;
                    for (int i = mm1; i>=l; i--) {
                        f = s*e[i-1];
                        b = c*e[i-1];
                        dlartg( g, f, &c, &s, &r );
                        if( i!=m-1 ) e[i] = r;
                        g = d[i] - p;
                        r = ( d[i-1]-g )*s + 2.0*c*b;
                        p = s*r;
                        d[i] = g + p;
                        g = c*r - b;
                        //If eigenvectors are desired, then save rotations.
                        if( icompz>0 ) {
                            work[i-1] = c;
                            work[n-2+i] = -s;
                        }
                    }
                    //If eigenvectors are desired, then apply saved rotations.
                    if( icompz>0 ) {
                        mm = m - l + 1;
                        dlasr( 'r', 'v', 'b', n, mm, &work[l-1], &work[n-2+l], &z( 1, l ), ldz );
                    }
                    d[l-1] = d[l-1] - p;
                    e[l-1] = g;
                    continue;
                    //Eigenvalue found.
                }
                d[l-1] = p;
                ++l;
                if( l<=lend ) continue;
                opuscMqeL=false;
                break;
            } while (true);
            if (!opuscMqeL) {
                opuscMqeL=true;
                dsteqr_140(&jtot, &n, &iscale, &ssfmin, &ssfmax, &anorm, &lendsv, &nmaxit, &lsv, d, e, info);
                if( jtot<nmaxit ) continue;
                for (int i=1; i<=n-1; i++)
                    if( e[ i -1] ) ++*info;
                return;
            }
        } else {
        /* QR Iteration

           Look for small superdiagonal element.    */
            do {
                if( l!=lend ) {
                    lendp1 = lend + 1;
                    for (m = l; m>=lendp1; m--) {
                        tst = pow( fabs( e[m-2] ),2 );
                        if( tst<=( eps2*fabs( d[m-1] ) )*fabs( d[m-2] )+ safmin ) {
                            opusc110=true;
                            break;
                        }
                    }
                }
                if (!opusc110) m = lend;
                opusc110=false;
                if( m>lend ) e[m-2] = 0.0;
                p = d[l-1];
                if( m!=l ) {
                    /* If remaining matrix is 2-by-2, use DLAE2 or SLAEV2
                    to compute its eigensystem. */
                    if( m==(l-1) ) {
                        if( icompz>0 ) {
                            dlaev2( d[l-2], e[l-2], d[l-1], &rt1, &rt2, &c, &s );
                             work[m-1] = c;
                             work[n-2+m] = s;
                             dlasr( 'r', 'v', 'f', n, 2, &work[ m -1], &work[ n-1+m ], &z( 1, l-1 ), ldz );
                         } else dlae2( d[l-2], e[l-2], d[l-1], &rt1, &rt2 );
                         d[l-2] = rt1;
                         d[l-1] = rt2;
                         e[l-2] = 0.0;
                         l -= 2;
                         if( l>=lend ) continue;
                         opuscMqeL=false;
                         break;
                     }
                     if( jtot==nmaxit ) {
                        opuscMqeL=false;
                        break;
                     }
                    ++jtot;
                    //Form shift.
                    g = ( d[l-2]-p ) / ( 2.0*e[l-2] );
                    r = dlapy2( g, 1.0 );
                    g = d[m-1] - p + ( e[l-2] / ( g+sign( &r, &g ) ) );
                    s = c = 1.0;
                    p = 0.0;
                    //Inner loop
                    lm1 = l - 1;
                    for (int i = m; i<=lm1; i++) {
                        f = s*e[i-1];
                        b = c*e[i-1];
                        dlartg( g, f, &c, &s, &r );
                        if( i!=m ) e[ i-2] = r;
                        g = d[i-1] - p;
                        r = ( d[i]-g )*s + 2.0*c*b;
                        p = s*r;
                        d[i-1] = g + p;
                        g = c*r - b;
                        ////If eigenvectors are desired, then save rotations.
                        if( icompz>0 ) {
                            work[i-1] = c;
                            work[n-2+i] = s;
                        }
                    }
                    //If eigenvectors are desired, then apply saved rotations.
                    if( icompz>0 ) {
                        mm = l - m + 1;
                        dlasr( 'r', 'v', 'f', n, mm, &work[m-1], &work[ n-2+m ], &z( 1, m ), ldz );
                    }
                    d[l-1] = d[l-1] - p;
                    e[lm1-1] = g;
                    continue;
                    //Eigenvalue found.
                }
                d[l-1] = p;
                --l;
                if( l>=lend ) continue;
                opuscMqeL=false;
                break;
            } while (true);
            if (!opuscMqeL) {
                opuscMqeL=true;
                //Undo scaling if necessary
                dsteqr_140(&jtot, &n, &iscale, &ssfmin, &ssfmax, &anorm, &lendsv, &nmaxit, &lsv, d, e, info);
                /* Check for no convergence to an eigenvalue after a total
                of N*MAXIT iterations.  */
                if( jtot<nmaxit ) continue;
                for (int i=1; i<=n-1; i++)
                    if( e[i-1] ) ++*info;
                return;
            }
        }
        break;
        //Order eigenvalues and eigenvectors.
    }
    if( !icompz )
        //Use Quick Sort
        dlasrt( 'i', n, d, info );
    else
        //Use Selection Sort to minimize swaps of eigenvectors
    for(int ii = 2; ii<=n; ii++) {
        i = ii - 1;
        k = i;
        p = d[i-1];
        for (int j = ii; j<=n; j++)
            if( d[j-1]<p ){
                k = j;
                p = d[j-1];
            }
        if( k!=i ) {
            d[k-1] = d[i-1];
            d[i-1] = p;
            dswap( n, &z( 1, i ), 1, &z( 1, k ), 1 );
        }
    }
    return;
}

#undef z //(j,i)
//---------------------------------------------------------------------------
void UDavidsonBase::dsterf(int n, double d[], double e[], int *info ) const
/*  -- LAPACK routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  DSTERF computes all eigenvalues of a symmetric tridiagonal matrix
*  using the Pal-Walker-Kahan variant of the QL or QR algorithm.
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The order of the matrix.  N >= 0.
*
*  D       (input/output) DOUBLE PRECISION array, dimension (N)
*          On entry, the n diagonal elements of the tridiagonal matrix.
*          On exit, if INFO = 0, the eigenvalues in ascending order.
*
*  E       (input/output) DOUBLE PRECISION array, dimension (N-1)
*          On entry, the (n-1) subdiagonal elements of the tridiagonal
*          matrix.
*          On exit, E has been destroyed.
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          < 0:  if INFO = -i, the i-th argument had an illegal value
*          > 0:  the algorithm failed to find all of the eigenvalues in
*                a total of 30*N iterations; if INFO = i, then i
*                elements of E have not converged to zero.
*/
{
    int maxit=30, iscale, l, lend, lendsv, lsv, m;
    double alpha, anorm, bb, c, gamma, oldc, oldgam, p, r, rt1, rt2,
         rte, s;
    bool opusc30=false, opusc70=false, opusc120=false, opuscMeqL=true;

    //Test the input parameters.
    *info = 0;
    if( n<0 ) {
        *info = -1;
////        xerbla( "dsterf ", -*info );
        return;
    }
    //Quick return if possible
    if( n<=1 ) return;
    //Determine the unit roundoff for this environment.
    double eps = dlamch( 'e' ),
           eps2 = eps*eps,
           safmin = dlamch( 's' ),
           safmax = 1.0 / safmin,
           ssfmax = sqrt( safmax ) / 3.0,
           ssfmin = sqrt( safmin ) / eps2,
           sigma = 0.0;
    //Compute the eigenvalues of the tridiagonal matrix.
    int nmaxit = n*maxit,
        jtot = 0,
/*    Determine where the matrix splits and choose QL or QR iteration
*     for each block, according to whether top or bottom diagonal
*     element is smaller.   */
        l1 = 1;

    while (l1<=n) {
        if ( l1>1 ) e[ l1-2] = 0.0;
        for (m = l1; m<=n - 1; m++) {
            if( fabs( e[ m -1] )<=( sqrt( fabs( d[ m-1] ) )*sqrt( fabs( d[m] ) ) )*eps ) {
                e[ m -1] = 0.0;
                opusc30=true;
                break;
            }
        }
        if (!opusc30) m = n;
        opusc30=false;
        l = l1;
        lsv = l;
        lend = m;
        lendsv = lend;
        l1 = m + 1;
        if( lend==l ) continue;
        //Scale submatrix in rows and columns L to LEND
        anorm = dlanst( 'i', lend-l+1, &d[ l -1], &e[ l -1] );
        iscale = 0;
        if( anorm>ssfmax ) {
            iscale = 1;
            dlascl( 'g', 0, 0, anorm, ssfmax, lend-l+1, 1, &d[ l -1], n, info );
            dlascl( 'g', 0, 0, anorm, ssfmax, lend-l, 1, &e[ l -1], n, info );
        } else if (anorm<ssfmin) {
            iscale = 2;
            dlascl( 'g', 0, 0, anorm, ssfmin, lend-l+1, 1, &d[ l -1], n, info );
            dlascl( 'g', 0, 0, anorm, ssfmin, lend-l, 1, &e[ l -1], n, info );
        }
        for (int i = l; i<=lend - 1; i++) e[ i -1] = pow( e[ i -1],2 );
        //Choose between QL and QR iteration
        if( fabs( d[ lend -1] )<fabs( d[ l -1] ) ) {
            lend = lsv;
            l = lendsv;
        }
        if( lend>=l ) {
/*       QL Iteration
*
*        Look for small subdiagonal element.    */
            do {
                if( l!=lend )
                    for (m = l; m<=lend - 1; m++)
                        if( fabs( e[ m -1] )<=eps2*fabs( d[ m -1]*d[m] ) ) {
                            opusc70=true;
                            break;
                        }
                if (!opusc70) m = lend;
                opusc70=false;
                if ( m<lend ) e[ m -1] = 0.0;
                p = d[ l -1];
                if ( m!=l ) {
                    /* If remaining matrix is 2 by 2, use DLAE2 to compute its
                    eigenvalues.    */
                    if( m==(l+1) ) {
                            rte = sqrt( e[ l -1] );
                            dlae2( d[ l -1], rte, d[l], &rt1, &rt2 );
                            d[ l -1] = rt1;
                            d[ l] = rt2;
                            e[ l -1] = 0.0;
                            l += 2;
                            if( l<=lend ) continue;
                            opuscMeqL=false;
                            break;
                    }
                    if( jtot==nmaxit ) {
                            opuscMeqL=false;
                            break;
                    }
                    ++jtot;
                    //Form shift.
                    rte = sqrt( e[ l -1] );
                    sigma = ( d[l]-p ) / ( 2.0*rte );
                    r = dlapy2( sigma, 1.0 );
                    sigma = p - ( rte / ( sigma+sign( &r, &sigma ) ) );
                    c = 1.0;
                    s = 0.0;
                    gamma = d[ m -1] - sigma;
                    p = gamma*gamma;
                    //Inner loop
                    for (int i = m - 1; i>=l; i--) {
                        bb = e[ i -1];
                        r = p + bb;
                        if( i!=(m-1) ) e[i] = s*r;
                        oldc = c;
                        c = p / r;
                        s = bb / r;
                        oldgam = gamma;
                        alpha = d[ i -1];
                        gamma = c*( alpha-sigma ) - s*oldgam;
                        d[i] = oldgam + ( alpha-gamma );
                        if( c ) p = ( gamma*gamma ) / c;
                            else p = oldc*bb;
                    }
                    e[ l -1] = s*p;
                    d[ l -1] = sigma + gamma;
                    //Eigenvalue found.
                    continue;
                }
                d[ l -1] = p;
                ++l;
                if( l<=lend ) continue;
                opuscMeqL=false;
                break;
            } while (true);
            if (!opuscMeqL) {
                opuscMeqL=true;
                if( iscale==1 )
                    dlascl( 'g', 0, 0, ssfmax, anorm, lendsv-lsv+1, 1, &d[ lsv -1], n, info );
                if( iscale==2 )
                    dlascl( 'g', 0, 0, ssfmin, anorm, lendsv-lsv+1, 1, &d[ lsv -1], n, info );
                if( jtot<nmaxit ) continue;
                for (int i = 1; i<=n - 1; i++)
                    if( e[ i -1] ) ++*info;
                return;
            }
        } else {
/*       QR Iteration
*
*        Look for small superdiagonal element.  */
            do {
                for (m = l; m>=lend + 1; m--)
                    if( fabs( e[ m-2] )<=eps2*fabs( d[ m -1]*d[ m-2] ) ) {
                        opusc120=true;
                        break;
                    }
                if (!opusc120) m = lend;
                opusc120=false;
                if( m>lend ) e[m-2] = 0.0;
                p = d[ l -1];
                if( m!=l ) {
                    /* If remaining matrix is 2 by 2, use DLAE2 to compute its
                       eigenvalues. */
                    if( m==(l-1) ) {
                        rte = sqrt( e[ l-2] );
                        dlae2( d[ l -1], rte, d[ l-2], &rt1, &rt2 );
                        d[l-1] = rt1;
                        d[l-2] = rt2;
                        e[l-2] = 0.0;
                        l -= 2;
                        if( l>=lend ) continue;
                        opuscMeqL=false;
                        break;
                    }
                    if( jtot==nmaxit ) {
                        opuscMeqL=false;
                        break;
                    }
                    ++jtot;
                    //Form shift.
                    rte = sqrt( e[ l-2] );
                    sigma = ( d[ l-2]-p ) / ( 2.0*rte );
                    r = dlapy2( sigma, 1.0 );
                    sigma = p - ( rte / ( sigma+sign( &r, &sigma ) ) );
                    c = 1.0;
                    s = 0.0;
                    gamma = d[m-1] - sigma;
                    p = gamma*gamma;
                    //Inner loop
                    for (int i = m; i<=l - 1; i++) {
                        bb = e[ i -1];
                        r = p + bb;
                        if( i!=m ) e[ i-2] = s*r;
                        oldc = c;
                        c = p / r;
                        s = bb / r;
                        oldgam = gamma;
                        alpha = d[i];
                        gamma = c*( alpha-sigma ) - s*oldgam;
                        d[ i -1] = oldgam + ( alpha-gamma );
                        if( c ) p = ( gamma*gamma ) / c;
                            else p = oldc*bb;
                    }
                    e[l-2] = s*p;
                    d[l-1] = sigma + gamma;
                    //Eigenvalue found.
                    continue;
                }
                d[ l -1] = p;
                --l;
                if( l>=lend ) continue;
                opuscMeqL=false;

                break;
            } while (true);
            if (!opuscMeqL) {
                opuscMeqL=true;
                //Undo scaling if necessary
                if( iscale==1 )
                    dlascl( 'g', 0, 0, ssfmax, anorm, lendsv-lsv+1, 1, &d[ lsv -1], n, info );
                if( iscale==2 )
                    dlascl( 'g', 0, 0, ssfmin, anorm, lendsv-lsv+1, 1, &d[ lsv -1], n, info );
                /* Check for no convergence to an eigenvalue after a total
                of N*MAXIT iterations.  */
                if( jtot<nmaxit ) continue;
                for (int i = 1; i<=n - 1; i++)
                    if( e[ i -1] ) ++*info;
                return;
            }
        }
        break;
    }
    //Sort eigenvalues in increasing order.
    dlasrt( 'i', n, d, info );

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dswap(int n, double dx[], int incx, double dy[], int incy) const
/*   interchanges two vectors.
     uses unrolled loops for increments equal one.
     jack dongarra, linpack, 3/11/78.
     modified 12/3/93, array(1) declarations changed to array(*) */
{
    double dtemp;

    if (n<=0) return;
    if (!(incx==1 && incy==1)) {
/*       code for unequal increments or equal increments not equal
         to 1   */
        int ix=1, iy=1;
        if (incx<0) ix=(-n+1)*incx+1;
        if (incy<0) iy=(-n+1)*incy+1;
        for (int i=1; i<=n; i++) {
            dtemp = dx[ix -1];
            dx[ix -1] = dy[iy -1];
            dy[iy -1] = dtemp;
            ix += incx;
            iy += incy;
        }
        return;
    }
/*     code for both increments equal to 1

       clean-up loop    */
    int m=n%3;
    if (m) {
        for (int i=1; i<=m; i++) {
            dtemp = dx[i -1];
            dx[i -1] = dy[i -1];
            dy[i -1] = dtemp;
        }
        if (n<3) return;
    }
    for (int i=m + 1; i<=n; i+=3) {
        dtemp = dx[i -1];
        dx[i -1] = dy[i -1];
        dy[i -1] = dtemp;
        dtemp = dx[i];
        dx[i] = dy[i];
        dy[i] = dtemp;
        dtemp = dx[i + 1];
        dx[i + 1] = dy[i + 1];
        dy[i + 1] = dtemp;
    }
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::dvdrvr(int n, bool hiend, int lim, int mblock, int nume, int niv, int neig,
            int iselec[], double crite, double critc, double critr, double ortho, int maxiter,
            double eigval[], double basis[], double ab[], double s[], double temps[],
            double svec[], double scra1[], int iscra2[], int incv[], int icv[], double oldval[],
            int *nmv, int *ierr, int *loop, bool inf) const
/*                                                                      
*       Driver routine implementing Davidson's main loop. On entry it   
*       is given the Basis, the work matrix D=AB and the small symmetric
*       matrix to be solved, S=B^TAB (as found by SETUP). In each step  
*       the small problem is solved by calling DSPEVX.
*       TSTSEL tests for eigenvalue convergence and selects the next    
*       pairs to be considered for targeting (as a block).              
*       NEWVEC computes the new vectors (block) to be added in the      
*       expanding basis, and tests for residual convergence.            
*       ADDABS is the critical step of matrix multiplication. The new   
*       vectors of D are found Dnew=ABnew, and the new small problem S, 
*       is calculated. The algorithm is repeated.                       
*       In case of a large expanding basis (KPASS=LIM) the Basis, AB,   
*       SVEC and S are collapsed.                                       
*       At the end the current eigenvector estimates are computed as    
*       well as the residuals and eigenvalue differences.               
*                                                                       
*       Subroutines called:                                             
*       DSPEVX, MULTBC, TSTSEL, OVFLOW, NEWVEC, ADDABS,                 
*       DCOPY, DDOT, DAXPY
*                                                                       
*   on entry                                                            
*   -------                                                             
*
*   N           The order of the matrix A
*   HIEND       Logical. True only if the highest eigenpairs are needed.
*   LIM         The limit on the size of the expanding Basis            
*   MBLOCK      Number of vectors to be targeted in each iteration.     
*   diag        Poiter for object of MatrixBase class
*   NUME        The largest index of the eigenvalues wanted.
*   NIV         Starting dimension of expanding basis.                  
*   NEIG        Number of eigenvalues wanted.                           
*   ISELEC      Array containg the indices of those NEIG eigenpairs.    
*   CRITE       Convergence thresholds for eigenvalues, coefficients    
*   CRITC,CRITR and residuals.                                          
*   BASIS       Array with the basis vectors.                           
*   AB          Array with the vectors D=AB                             
*   S           Array keeping the symmetric matrix of the small problem.
*   TEMPS       scratch array                                           
*   SVEC        Array for holding the eigenvectors of S                 
*   SCRA1       Srcatch array used by DSPEVX.                           
*   ISCRA2      Integer Srcatch array used by DSPEVX.
*   INCV        Srcatch array used in DSPEVX. Also used in TSTSEL and   
*               NEWVEC where it holds the Indices of uNConVerged pairs  
*   ICV         It contains "1" to the locations of ConVerged eigenpairs
*   OLDVAL      Array keeping the previous' step eigenvalue estimates.  
*
*   silence     if 0 then program displays a informations (e.g number of
*               iterations and respondes to ENTER in order to breaking
*               calculations)
*   inf         if -1 then maxiter=infinity
*
*
*   on exit                                                             
*   -------                                                             
*                                                                       
*   EIGVAL      Array containing the NUME lowest eigenvalues of the     
*               the matrix A (or -A if the highest are sought).         
*   Basis       On exit Basis stores the NUME corresponding eigenvectors
*   OLDVAL      On exit it stores the final differences of eigenvalues. 
*   SCRA1       On exit it stores the NUME corresponding residuals.     
*   NLOOPS      Number of loops taken by the algorithm                  
*   NMV         Number of matrix-vector products performed.
*   loop        thr number of iterations it took the algorithm
*   ierr        if ierr = 2048 then NLOOPS>MAXITER
                if ierr = 4096 then the program have been breaking
                calculations on request user
*
*-----------------------------------------------------------------------*/
{
    bool restart, first=true, done, omin_to=false, userbreak=false;
    int nfound, info, nloops=0;;

    for (int i=1; i<=nume; i++) {
        eigval[i-1]=1.0e+30;
        icv[i-1]=0;
    }
    int kpass =niv,
         nncv  =kpass;

    do {
/*      (iterations for kpass=NUME,LIM)
*
*       Diagonalize the matrix S. Find only the NUME smallest eigenpairs    */
        dcopy(nume,eigval,1,oldval,1);
        dcopy((kpass*(kpass+1))/2,s,1,temps,1);
        dspevx('v','i','u', kpass,temps,-1.0,-1.0,1,  //'vectors also','in a range','upper triangular'
                nume,0.0,&nfound,eigval,svec,kpass,scra1,iscra2,incv,&info);
        *ierr=-abs(info);
        if (*ierr!=0) return;
/* TeST for convergence on the absolute difference of eigenvalues between
*  successive steps. Also SELect the unconverged eigenpairs and sort them
*  by the largest magnitude in the last added NNCV rows of Svec.    */
        done=tstsel(kpass,nume,neig,iselec,svec,eigval,icv,crite,critc,
                    scra1,iscra2,oldval,&nncv,incv);
        if ((done)||(kpass>=n)) {
            omin_to=true;
            break;
        }
        if (kpass==lim) {
/* Maximum size for expanding basis. Collapse basis, D, and S, Svec
*  Consider the basis vectors found in TSTSEL for the newvec.   */
            multbc(n,lim,nume,svec,scra1,basis);
            multbc(n,lim,nume,svec,scra1,ab);
            ovflow(nume,lim,s,svec,eigval);
            kpass=nume;
        }
/* Compute and add the new vectors. NNCV is set to the number of new
*  vectors that have not converged. If none, DONE=true, exit.   */
        const double* diag = this->GetSignedDiagonal();
        newvec(n,nume,lim,mblock,kpass,critr,ortho,&nncv,incv, diag, svec,
               eigval,ab,basis,icv,&restart,&done);
/*          ..An infinite loop is avoided since after a collapsing Svec=I
*          ..=> Res=Di-lBi which is just computed and it is orthogonal.
*          ..The following is to prevent an improbable infinite loop.  */
        if (!restart) first=true;
        else if (first) {
            first=false;
            multbc(n,kpass+nncv,nume,svec,scra1,basis);
            multbc(n,kpass+nncv,nume,svec,scra1,ab);
            ovflow(nume,kpass+nncv,s,svec,eigval);
            kpass=nume;
            continue;
        } else {
            *ierr += 1024;
            omin_to=true;
            break;
        }
        if (done){
            omin_to=true;
            break;
        }
//Add new columns in D and S, from the NNCV new vectors.
        addabs(n,lim,hiend,kpass,nncv,basis,ab,s);
        *nmv += nncv;
        kpass += nncv;
        ++nloops;
        if (userbreak) break;
        if (inf) maxiter=nloops+1;
    } while (nloops<maxiter || inf);
    if (!omin_to) {
        omin_to=false;
        if (userbreak) *ierr += 4096; //przerwane na zyczenie uytkownika
            else *ierr += 2048;
        //--nloops;        //tak ma byc zobacz (np. dla maxiter=1)
        kpass -= nncv;
    }
    if (omin_to) {
        ++nloops;
    }
/* Calculate final results. EIGVAL contains the eigenvalues, BASIS the
*  eigenvectors, OLDVAL the eigenvalue differences, and SCRA1 residuals.    */
    for (int i=1; i<=nume; i++) oldval[i-1]=fabs(oldval[i-1]-eigval[i-1]);
    multbc(n,kpass,nume,svec,scra1,basis);
    multbc(n,kpass,nume,svec,scra1,ab);
/* i=1,NUME residual(i)= DCi-liBCi= newDi-linewBi                        ACPZ0579
*  temporarily stored in AB(NUME*N+1)   */
    for (int i=1; i<=nume; i++) {
        dcopy(n,&ab[(i-1)*n],1,&ab[nume*n],1);
        daxpy(n,-eigval[i-1],&basis[(i-1)*n],1,&ab[nume*n],1);
        scra1[i-1]=sqrt(ddot(n,&ab[nume*n],1,&ab[nume*n],1));
    }
    *loop=nloops;
    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::gather(int n, double a[], double b[], int index[]) const
/*      This subroutine collects array elements accessed via an     
*       integer pointer to contiguous storage.  */
{
    for (int i=1; i<=n; i++)
        a[i -1] = b[index[i -1] -1];

    return;
}
//---------------------------------------------------------------------------
int UDavidsonBase::idamax(int n, double dx[], int incx) const
/*    finds the index of element having max. absolute value.
      jack dongarra, linpack, 3/11/78.
      modified 3/93 to return if incx .le. 0.
      modified 12/3/93, array(1) declarations changed to array(*)   */
{
      double dmax;
      int ix,fidamax=1;         // fidamax=1 poniewa nie wiem czy w dalszej cz�i programu
                                 // (trzecie if) idamax nie moe by�=1

      if (n<1 || incx<=0) return 0;
      if (n==1) return 1;
      if (incx!=1) {
        //code for increment not equal to 1
        ix=1;
        dmax = fabs(dx[0]);
        ix += incx;
        for (int i=2; i<=n; i++) {
            if (fabs(dx[ix -1])>dmax) {
                fidamax = i;
                dmax = fabs(dx[ix -1]);
            }
            ix += incx;
        }
        return fidamax;
      }
      //code for increment equal to 1
      dmax=fabs(dx[0]);
      for (int i=2; i<=n; i++)
        if (fabs(dx[i -1])>dmax) {
            fidamax=i;
            dmax=fabs(dx[i -1]);
        }
      return fidamax;
}
//---------------------------------------------------------------------------
int UDavidsonBase::ieeeck(int ispec, double zero, double one ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1998
*  Purpose
*  =======
*
*  IEEECK is called from the ILAENV to verify that Infinity and
*  possibly NaN arithmetic is safe (i.e. will not trap).
*
*  Arguments
*  =========
*
*  ISPEC   (input) INTEGER
*          Specifies whether to test just for inifinity arithmetic
*          or whether to test for infinity and NaN arithmetic.
*          = 0: Verify infinity arithmetic only.
*          = 1: Verify infinity and NaN arithmetic.
*
*  ZERO    (input) REAL
*          Must contain the value 0.0
*          This is passed to prevent the compiler from optimizing
*          away this code.
*
*  ONE     (input) REAL
*          Must contain the value 1.0
*          This is passed to prevent the compiler from optimizing
*          away this code.
*
*  RETURN VALUE:  INTEGER
*          = 0:  Arithmetic failed to produce the correct answers
*          = 1:  Arithmetic produced the correct answers
*/
{
    double nan1, nan2, nan3, nan4, nan5, nan6, neginf, negzro, newzro, posinf;

    if (!zero) return 1;    //dodana przeze mnie tak aby funkcja zwracaa t sam wartoc co w f77

    posinf = one / zero;
    if( posinf<=one ) return 0;
    neginf = -one / zero;
    if( neginf>=zero ) return 0;
    negzro = one / ( neginf+one );
    if( negzro!=zero ) return 0;
    neginf = one / negzro;
    if( neginf>=zero ) return 0;
    newzro = negzro + zero;
    if( newzro!=zero ) return 0;
    posinf = one / newzro;
    if( posinf<=one ) return 0;
    neginf = neginf*posinf;
    if( neginf>=zero ) return 0;
    posinf = posinf*posinf;
    if( posinf<=one ) return 0;

    //Return if we were only asked to check infinity arithmetic
    if( ispec==0 ) return 1;

    nan1 = posinf + neginf;
    nan2 = posinf / neginf;
    nan3 = posinf / posinf;
    nan4 = posinf*zero;
    nan5 = neginf*negzro;
    nan6 = nan5*0.0;

    if( nan1==nan1 ) return 0;
    if( nan2==nan2 ) return 0;
    if( nan3==nan3 ) return 0;
    if( nan4==nan4 ) return 0;
    if( nan5==nan5 ) return 0;
    if( nan6==nan6 ) return 0;

    return 1;
}
//---------------------------------------------------------------------------
void UDavidsonBase::scopy(const char* co, char* tu) const
{
    int i=-1;

    do {
        ++i;
        tu[i]=co[i];
    } while (co[i]);

}


int UDavidsonBase::ilaenv(int ispec, const char* name, const char* opts, int n1, int n2,
                        int n3, int n4 ) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*
*
*  Purpose
*  =======
*
*  ILAENV is called from the LAPACK routines to choose problem-dependent
*  parameters for the local environment.  See ISPEC for a description of
*  the parameters.
*
*  This version provides a set of parameters which should give good,
*  but not optimal, performance on many of the currently available
*  computers.  Users are encouraged to modify this subroutine to set
*  the tuning parameters for their particular machine using the option
*  and problem size information in the arguments.
*
*  This routine will not function correctly if it is converted to all
*  lower case.  Converting it to all upper case is allowed.
*
*  Arguments
*  =========
*
*  ISPEC   (input) INTEGER
*          Specifies the parameter to be returned as the value of
*          ILAENV.
*          = 1: the optimal blocksize; if this value is 1, an unblocked
*               algorithm will give the best performance.
*          = 2: the minimum block size for which the block routine
*               should be used; if the usable block size is less than
*               this value, an unblocked routine should be used.
*          = 3: the crossover point (in a block routine, for N less
*               than this value, an unblocked routine should be used)
*          = 4: the number of shifts, used in the nonsymmetric
*               eigenvalue routines
*          = 5: the minimum column dimension for blocking to be used;
*               rectangular blocks must have dimension at least k by m,
*               where k is given by ILAENV(2,...) and m by ILAENV(5,...)
*          = 6: the crossover point for the SVD (when reducing an m by n
*               matrix to bidiagonal form, if max(m,n)/min(m,n) exceeds
*               this value, a QR factorization is used first to reduce
*               the matrix to a triangular form.)
*          = 7: the number of processors
*          = 8: the crossover point for the multishift QR and QZ methods
*               for nonsymmetric eigenvalue problems.
*          = 9: maximum size of the subproblems at the bottom of the
*               computation tree in the divide-and-conquer algorithm
*               (used by xGELSD and xGESDD)
*          =10: ieee NaN arithmetic can be trusted not to trap
*          =11: infinity arithmetic can be trusted not to trap
*
*  NAME    (input) CHARACTER*(*)
*          The name of the calling subroutine, in either upper case or
*          lower case.
*
*  OPTS    (input) CHARACTER*(*)
*          The character options to the subroutine NAME, concatenated
*          into a single character string.  For example, UPLO = 'U',
*          TRANS = 'T', and DIAG = 'N' for a triangular routine would
*          be specified as OPTS = 'UTN'.
*
*  N1      (input) INTEGER
*  N2      (input) INTEGER
*  N3      (input) INTEGER
*  N4      (input) INTEGER
*          Problem dimensions for the subroutine NAME; these may not all
*          be required.
*
* (ILAENV) (output) INTEGER
*          >= 0: the value of the parameter specified by ISPEC
*          < 0:  if ILAENV = -k, the k-th argument had an illegal value.
*
*  Further Details
*  ===============
*
*  The following conventions have been used when calling ILAENV from the
*  LAPACK routines:
*  1)  OPTS is a concatenation of all of the character options to
*      subroutine NAME, in the same order that they appear in the
*      argument list for NAME, even if they are not used in determining
*      the value of the parameter specified by ISPEC.
*  2)  The problem dimensions N1, N2, N3, N4 are specified in the order
*      that they appear in the argument list for NAME.  N1 is used
*      first, N2 second, and so on, and unused problem dimensions are
*      passed a value of -1.
*  3)  The parameter value returned by ILAENV is checked for validity in
*      the calling subroutine.  For example, ILAENV is used to retrieve
*      the optimal blocksize for STRTRI as follows:
*
*      NB = ILAENV( 1, 'STRTRI', UPLO // DIAG, N, -1, -1, -1 )
*      IF( NB.LE.1 ) NB = MAX( 1, N )
*/
{
    bool cname, sname;
    char c1;
    char c2[3], c4[3];
    char c3[4];
    char subnam[8];
    int  ic, iz, nb, nbmin, nx, _ilaenv;

    c2[2]=c3[3]=c4[2]=subnam[7]='\0';

    switch (ispec) {
        case   1:
        case   2:
        case   3:   //Convert NAME to upper case if the first character is lower case.
                    _ilaenv = 1;
                    scopy(name, subnam);
                    ic = (int)( subnam[ 1 -1] );
                    iz = (int)('z');
                    if( iz==90 || iz==122 ) {
                        //ASCII character set
                        if( ic>=97 && ic<=122 ) {
                            subnam[ 1 -1 ] =  (char)(ic-32);
                            for (int i=2; i<=6; i++) {
                                ic = (int)( subnam[ i -1 ] );
                                if( ic>=97 && ic<=122 ) subnam[ i -1 ] =  (char)(ic-32);
                            }
                        }
                    } else if (iz==233 || iz==169) {
                        //EBCDIC character set
                        if ( ( ic>=129 && ic<=137 ) || ( ic>=145 && ic<=153 ) || ( ic>=162 && ic<=169 ) ) {
                            subnam[ 1 -1 ] =  (char)(ic+64);
                            for (int i=2; i<=6; i++) {
                                ic = (int)( subnam[ i -1 ] );
                                if( ( ic>=129 && ic<=137 ) || ( ic>=145 && ic<=153 ) || ( ic>=162 && ic<=169 ) )
                                    subnam[ i -1 ] = (char)( ic+64 );
                            }
                        }
                    } else if (iz==218 || iz==250) {
                        //Prime machines:  ASCII+128
                        if( ic>=225 && ic<=250 ) {
                            subnam[ 1 -1 ] = (char)( ic-32 );
                            for (int i=2; i<=6; i++) {
                                ic = (int)( subnam[ i -1 ] );
                                if( ic>=225 && ic<=250 ) subnam[ i -1 ] = (char)( ic-32 );
                            }
                        }
                    }
                    c1 = subnam[ 1 -1 ];
                    sname = c1=='s' || c1=='d';
                    cname = c1=='c' || c1=='z';
                    if( !( cname || sname ) ) break;
                    c2[0] = subnam[ 2 -1]; //subnam( 2:3 )
                    c2[1] = subnam[ 3 -1];
                    c3[0] = subnam[ 4 -1]; //subnam( 4:6 )
                    c3[1] = subnam[ 5 -1];
                    c3[2] = subnam[ 6 -1];
                    c4[0] = c3[ 2 -1];  //c3( 2:3 )
                    c4[1] = c3[ 3 -1];
                    switch (ispec) {
                        case 1:
                                /*     ISPEC = 1:  block size

                                In these examples, separate code is provided for setting NB for
                                real and complex.  We assume that NB will take the same value in
                                single or double precision. */
                                nb = 1;
                                if( c2=="ge " ) {
                                    if (c3=="trf ") nb = 64;
                                        else if (c3=="qrf " || c3=="rqf " || c3=="lqf " || c3=="qlf " ) nb = 32;
                                            else if( c3=="hrd " ) nb = 32;
                                                else if( c3=="brd " ) nb = 32;
                                                    else if( c3=="tri " ) nb = 64;
                                } else if ( c2=="po " ) {
                                    if( c3=="trf " ) nb = 64;
                                } else if( c2=="sy " ) {
                                    if( c3=="trf " ) nb = 64;
                                        else if ( sname && c3=="trd " ) nb = 32;
                                            else if( sname && c3=="gst " ) nb = 64;
                                }else if( cname && c2=="he " ) {
                                    if( c3=="trf " ) nb = 64;
                                        else if( c3=="trd " ) nb = 32;
                                            else if( c3=="gst " ) nb = 64;
                                } else if( sname && c2=="or " ) {
                                    if( c3[ 1 -1 ]=='g' ) {
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nb = 32;
                                    } else if( c3[ 1 -1 ]=='m' )
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nb = 32;
                                }else if ( cname && c2=="un " ) {
                                    if( c3[ 1 -1 ]=='g' )   {
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nb = 32;
                                    } else if (c3[ 1 -1 ]=='m')
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nb = 32;
                                } else if( c2=="gb " ){
                                    if( c3=="trf " ) {
                                        if( sname ) {
                                            if( n4<=64 ) nb = 1;
                                            else nb = 32;
                                        } else {
                                            if( n4<=64 ) nb = 1;
                                            else nb = 32;
                                        }
                                    }
                                } else if( c2=="pb " ) {
                                    if( c3=="trf " ) {
                                        if( sname ) {
                                            if( n2<=64 ) nb = 1;
                                            else nb = 32;
                                        } else {
                                            if( n2<=64 ) nb = 1;
                                            else nb = 32;
                                        }
                                    }
                                } else if( c2=="tr " ) {
                                    if( c3=="tri " ) nb = 64;
                                } else if( c2=="la " ) {
                                    if( c3=="uum " ) nb = 64;
                                } else if( sname && c2=="st " )
                                    if( c3=="ebz " ) nb = 1;
                                _ilaenv = nb;
                                break;
                        case 2: //ISPEC = 2:  minimum block size
                                nbmin = 2;
                                if( c2=="ge " ) {
                                    if( c3=="qrf " || c3=="rqf " || c3=="lqf " || c3=="qlf " ) nbmin = 2;
                                        else if( c3=="hrd " ) nbmin = 2;
                                            else if( c3=="brd " ) nbmin = 2;
                                                else if( c3=="tri " ) nbmin = 2;
                                } else if( c2=="sy " ) {
                                    if( c3=="trf " ) nbmin = 8;
                                        else if( sname && c3=="trd " ) nbmin = 2;
                                } else if( cname && c2=="he " ) {
                                    if( c3=="trd " ) nbmin = 2;
                                } else if( sname && c2=="or " ) {
                                    if( c3[ 1 -1 ]=='g' ){
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nbmin = 2;
                                    } else if (c3[ 1 -1 ]=='m') {
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nbmin = 2;
                                    }
                                } else if( cname && c2=="un " ) {
                                    if( c3[ 1 -1 ]=='g' ) {
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nbmin = 2;
                                    } else if ( c3[ 1 -1 ]=='m' )
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nbmin = 2;
                                }
                                _ilaenv = nbmin;
                                break;
                        case 3: //ISPEC = 3:  crossover point
                                nx = 0;
                                if( c2=="ge " ) {
                                    if( c3=="qrf " || c3=="rqf " || c3=="lqf " || c3=="qlf " ) nx = 128;
                                        else if( c3=="hrd " ) nx = 128;
                                            else if( c3=="brd " ) nx = 128;
                                } else if (c2=="sy ") {
                                    if( sname && c3=="trd " ) nx = 32;
                                } else if( cname && c2=="he " ) {
                                    if( c3=="trd " ) nx = 32;
                                } else if( sname && c2=="or " ) {
                                    if( c3[ 1 -1 ]=='g' )
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nx = 128;
                                } else if( cname && c2=="un " ) {
                                    if( c3[ 1 -1 ]=='g' )
                                        if( c4=="qr " || c4=="rq " || c4=="lq " || c4=="ql " || c4=="hr " || c4=="tr " || c4=="br " ) nx = 128;
                                }
                                _ilaenv = nx;
                                break;
                    }
                    break;
        case   4:   //ISPEC = 4:  number of shifts (used by xHSEQR)
                    _ilaenv = 6;
                    break;
        case   5:   //ISPEC = 5:  minimum column dimension (not used)
                    _ilaenv = 2;
                    break;
        case   6:   //ISPEC = 6:  crossover point for SVD (used by xGELSS and xGESVD)
                    _ilaenv = (int)(  MIN( n1, n2 ) *1.6f );   //w f77 : real( MIN( n1, n2 )
                    break;
        case   7:   //ISPEC = 7:  number of processors (not used)
                    _ilaenv = 1;
                    break;
        case   8:   //ISPEC = 8:  crossover point for multishift (used by xHSEQR)
                    _ilaenv = 50;
                    break;
        case   9:
                    /*ISPEC = 9:  maximum size of the subproblems at the bottom of the
*                   computation tree in the divide-and-conquer algorithm
*                   (used by xGELSD and xGESDD)*/
                    _ilaenv = 25;
                    break;
        case  10:   //ISPEC = 10: ieee NaN arithmetic can be trusted not to trap
                    // w f77 bylo jeszcze ilaenv = 0
                    //_ilaenv = 1;
                    /*if( _ilaenv==1 )*/ _ilaenv = ieeeck( 0, 0.0, 1.0 );
                    break;
        case  11:   //ISPEC = 11: infinity arithmetic can be trusted not to trap
                    // w f77 bylo jeszcze ilaenv = 0
                    //_ilaenv = 1;
                    /*if( _ilaenv==1 )*/ _ilaenv = ieeeck( 1, 0.0, 1.0 );
                    break;
        default :   //nvalid value for ISPEC
                    _ilaenv = -1; break;
    }

    return _ilaenv;
}
//---------------------------------------------------------------------------
bool UDavidsonBase::lsame(char ca, char cb) const
/*  -- LAPACK auxiliary routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     September 30, 1994
*
*
*  Purpose
*  =======
*
*  LSAME returns .TRUE. if CA is the same letter as CB regardless of
*  case.
*
*  Arguments
*  =========
*
*  CA      (input) CHARACTER*1
*  CB      (input) CHARACTER*1
*          CA and CB specify the single characters to be compared.
*/
{
    int inta, intb, zcode;

    //Test if the characters are equal
    if (ca==cb) return true;

    //Now test for equivalence if both characters are alphabetic.
    zcode=(int)'z';
/*    Use 'Z' rather than 'A' so that ASCII can be detected on Prime
*     machines, on which ICHAR returns a value with bit 8 set.
*     ICHAR('A') on Prime machines returns 193 which is the same as
*     ICHAR('A') on an EBCDIC machine.  */
    inta =(int)ca;
    intb =(int)cb;

    if (zcode==90 || zcode==122) {
/*       ASCII is assumed - ZCODE is the ASCII code of either lower or
*        upper case 'Z'.    */
        if( inta>=97 && inta<=122 ) inta -= 32;
        if( intb>=97 && intb<=122 ) intb -= 32;

    } else if (zcode==233 || zcode==169) {
/*       EBCDIC is assumed - ZCODE is the EBCDIC code of either lower or
*        upper case 'Z'.    */
        if( inta>=129 && inta<=137 || inta>=145 && inta<=153 ||
            inta>=162 && inta<=169 ) inta += 64;
        if( intb>=129 && intb<=137 || intb>=145 && intb<=153 ||
            intb>=162 && intb<=169 ) intb += 64;
    } else if (zcode==218 || zcode==250) {
/*       ASCII is assumed, on Prime machines - ZCODE is the ASCII code
*        plus 128 of either lower or upper case 'Z'.    */
        if( inta>=225 && inta<=250 ) inta -= 32;
        if( intb>=225 && intb<=250 ) intb -= 32;
    }

    return (inta==intb);
}
//---------------------------------------------------------------------------
void UDavidsonBase::multbc(int n, int k, int m, double c[], double temp[], double b[]) const
/*-----------------------------------------------------------------------
*       called by: DVDRVR
*                                                                       
*       Multiplies B(N,K)*C(K,M) and stores it in B(N,M)                
*       Used for collapsing the expanding basis to current estimates,   
*       when basis becomes too large, or for returning the results back 
                                                                        
*       Subroutines called                                              
*       DINIT, DGEMV, DCOPY                                             
*-----------------------------------------------------------------------*/
{
    for (int irow=1; irow<=n; irow++) {
        dgemv('t',k,m, 1.0, c,k,&b[irow -1],n, 0.0 ,temp,1);
        dcopy(m,temp,1,&b[irow -1],n);
    }

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::newvec(int n, int nume, int lim, int mblock, int kpass,
            double critr, double ortho, int *nncv, int incv[], const double diag[],
            double svec[], double eigval[], double ab[], double basis[], int icv[],
            bool *restart, bool *done) const
/*-----------------------------------------------------------------------
*                                                                       
*       Called by: DVDRVR
*                                                                       
*       It calculates the new expansion vectors of the basis.
*       For each one of the vectors in INCV starting with the largest   
*       megnitude one, calculate its residual Ri= DCi-liBCi and check   
*       the ||Ri|| for convergence. If it is converged do not add it    
*       but look for the immediate larger coefficient and its vector.   
*       The above procedure continues until MBLOCK vectors have been    
*       added to the basis, or the upper limit has been encountered.    
*       Thus only  the required MBLOCK residuals are computed. Then,    
*       calculate the first order correction on the added residuals     
*       Ri(j) = Ri(j)/(li-Ajj) and orthonormalizes the new vectors      
*       to the basis and to themselves.                                 
*                                                                       
*       Subroutines called:
*       ORTHNRM, DDOT, DGEMV                                            
*
*   on entry                                                            
*   --------                                                            
*   N           The order of the matrix A                               
*   NUME        The largest index of the eigenvalues wanted.
*   LIM         The limit on the size of the expanding Basis            
*   MBLOCK      Maximum number of vectora to enter the basis
*   KPASS       the current dimension of the expanding basis            
*   CRITR       Convergence threshold for residuals                     
*   ORTHO       Orthogonality threshold to be passed to ORTHNRM         
*   NNCV        Number of Non ConVerged pairs (MBLOCK will be targeted) 
*   INCV        Index to the corresponding SVEC columns of these pairs. 
*   DIAG        Array of size N with the diagonal elements of A
*   SVEC,EIGVAL Arrays holding the eigenvectors and eigenvalues of S    
*   AB          Array with the vectors D=AB                             
*   BASIS       the expanding basis having kpass vectors                
*   ICV         Index of converged eigenpairs (ICV(i)=1 <=>i converged) 
                                                                        
*   on exit
*   -------                                                             
*   NNCV        The number of vectors finally added to the basis.       
*   BASIS       The new basis incorporating the new vectors at the end  
*   ICV         Index of converged eigenpairs (updated)                 
*   DONE        logical, if covergance has been reached.                
*   RESTART     logical, if because of extreme loss of orthogonality
*               the Basis should be collapsed to current approximations.
*-----------------------------------------------------------------------*/
{
    double ss, dg;
    int indx;

    *done   = false;
    int newstart= kpass*n+1,
        nadded  = 0,
        icvc    = 0,
        limadd  = MIN( lim, mblock+kpass ),
        icur    = newstart;

// Compute RESIDUALS for the MBLOCK of the NNCV not converged vectors.
    for (int i=1; i<=*nncv; i++) {
        indx=incv[i -1];
/*         ..Compute  Newv=BASIS*Svec_indx , then                       ACPZ0893
           ..Compute  Newv=AB*Svec_indx - eigval*Newv and then          ACPZ0894
           ..compute the norm of the residual of Newv   */
        dgemv('n',n,kpass,1.0,basis,n,&svec[(indx-1)*kpass+1 -1],1, 0.0,&basis[icur -1],1);
        dgemv('n',n,kpass,1.0,ab,n,&svec[(indx-1)*kpass+1 -1],1,-eigval[indx -1],&basis[icur -1],1);
        ss = dnrm2(n,&basis[icur -1],1);

        //..Check for convergence of this residual
        if (ss<critr) {
            //..Converged,do not add. Go for next non converged one
            ++icvc;
            icv[ indx -1] = 1;
            if (icvc<*nncv) continue;
            //..All have converged.
            *done=true;
            return;
        } else {
            //..Not converged. Add it in the basis
            ++nadded;;
            incv[nadded -1]=indx;
            if ((nadded+kpass)==limadd) break;
            //..More to be added in the block
            icur += n;
        }
    }
    *nncv=nadded;

// Diagonal preconditioning: newvect(i)=newvect(i)/(l-Aii)               ACPZ0924
// If (l-Aii) is very small (or zero) divide by 10.D-6
    icur=newstart-1;
    for (int i=1; i<=*nncv; i++) {
        for (int irow=1; irow<=n; irow++) {
            dg=eigval[incv[i -1] -1]-diag[irow -1];
            if (fabs(dg)>(1.0e-13)) basis[icur+irow -1] = basis[icur+irow -1] / dg;
            else basis[icur+irow -1]=basis[icur+irow -1] /1.0e-13;
        }
        icur += n;
    }

// ORTHONORMALIZATION
    orthnrm(n,lim,ortho,kpass,nncv,&ab[newstart -1], basis,restart);

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::orthnrm(int n, int lim, double ortho, int kpass, int *nncv,
                double scra1[], double basis[], bool *restart) const
/*-----------------------------------------------------------------------
*
*       It orthogonalizes the new NNCV basis vectors starting from the  
*       kpass+1, to the previous vectors of the basis and to themselves.
*       A Gram-Schmidt method is followed after which the residuals     
*       should be orthogonal to the BASIS. Because of machine arithmetic
*       errors this orthogonality may be lost, and a reorthogonalization
*       procedure is adopted whenever orthogonality loss is above a     
*       ORTHO. If after some reorthogonalizations the procedure does not
*       converge to orthogonality, the basis is collapsed to the        
*       current eigenvector approximations.                             
*                                                                       
*       Subroutines called:                                             
*       DAXPY, DDOT, DSCAL                                              
*
*   on entry                                                            
*   --------                                                            
*   N           The order of the matrix A                               
*   LIM         The limit on the size of the expanding Basis
*   ORTHO       The orthogonality threshold                             
*   KPASS       The number of basis vectors already in Basis            
*   NNCV        The number of new vectors in the basis                  
*   SCRA1       Scratch vector of size N                                
*   BASIS       the expanding basis having kpass vectors                
*                                                                       
*   on exit
*   -------                                                             
*   BASIS       the new basis orthonormalized                           
*   RESTART     Logical, if true the algoritm will collapse BASIS.      
*-----------------------------------------------------------------------*/
{
    bool powrot;
    int  icur, iv, ibstart;
    double dprev, dcur;

// ORTHOGONALIZATION
    *restart=false;
    icur=kpass*n+1;

    //.. do iv=1,nncv
    iv = 1;

    do {
        dprev=1.0e+7;
        do {
            powrot=false;
            dcur=0.0;
            ibstart=1;
            for (int i=1; i<=kpass+iv-1; i++) {
                scra1[i -1]=ddot(n,&basis[ibstart -1],1,&basis[icur -1],1);
                dcur=MAX(dcur,fabs(scra1[i -1]));
                ibstart += n;
            }
            ibstart=1;
            for (int i=1; i<=kpass+iv-1; i++) {
                daxpy(n,-scra1[i -1],&basis[ibstart -1],1,&basis[icur -1],1);
                ibstart += n;
            }
            if (dcur>=ortho) {
                if (dcur>dprev) {
                    *restart=true;
                    //..Adjust the number of added vectors.
                    *nncv=iv-1;
                    return;
                } else {
                    dprev=dcur;
                    powrot=true;
                }
            }
        } while (powrot);

// NORMALIZATION 
        scra1[1 -1]=ddot(n,&basis[icur -1],1,&basis[icur -1],1);
        scra1[1 -1]=sqrt(scra1[1 -1]);
        if (scra1[1 -1]<1e-14) {
            dcopy(n,&basis[ n*(*nncv-1)+1 -1],1,&basis[icur -1],1);
            --*nncv;
        } else {
            dscal(n,1/scra1[1 -1],&basis[icur -1],1);
            icur += n;
            ++iv;
        }
    } while (iv<=*nncv);

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::ovflow(int nume, int lim, double s[], double svec[], double eigval[]) const
/*-----------------------------------------------------------------------
*       Called by: DVDRVR
*       Called when the upper limit (LIM) has been reached for the basis
*       expansion. The new S is computed as S'(i,j)=l(i)delta(i,j) where
*       l(i) eigenvalues, and delta of Kronecker, i,j=1,NUME. The new   
*       eigenvectors of the small matrix are the unit vectors.          
*                                                                       
*       Subroutines called:                                             
*       DCOPY, DINIT                                                    
*
*   on entry                                                            
*   -------                                                             
*   NUME        The largest index of eigenvalues wanted.                
*   SVEC        the kpass eigenvectors of the smaller system solved
*   EIGVAL      the eigenvalues of this small system                    
*   on exit                                                             
*   -------                                                             
*   S           The new small matrix to be solved.                      
*-----------------------------------------------------------------------*/
{
// calculation of the new upper S=diag(l1,...,l_NUME) and
// its matrix Svec of eigenvectors (e1,...,e_NUME)
    dinit((nume*(nume+1))/2,0.0,s,1);
    dinit(nume*nume,0.0,svec,1);
    int ind=0, icur=0;
    for (int i=1; i<=nume; i++) {
        s[ind+i -1]=eigval[i -1];
        svec[icur+i -1]=1;
        icur += nume;
        ind += i;
    }

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::scatter(int n, double a[], int index[], double b[]) const
/* This subroutine disperses array elements accessed via an integer
*  pointer from contiguous storage to the appropriate location. */
{
    for (int i=1; i<=n; i++)
        a[index[i -1] -1] = b[i -1];

    return;
}
//---------------------------------------------------------------------------
void UDavidsonBase::setup(int n, int lim, int nume, bool hiend,
          double minelem[], double basis[], double ab[], double s[], int *niv) const
/*       Subroutine for setting up (i) the initial BASIS if not provided,
*       (ii) the product of the matrix A with the Basis into matrix AB,
*       and (iii) the small matrix S=B^TAB. If no initial estimates are
*       available, the BASIS =(e_i1,e_i2,...,e_iNUME), where i1,i2,...,
*       iNUME are the indices of the NUME lowest diagonal elements, and
*       e_i the i-th unit vector. (ii) and (iii) are handled by ADDABS.
*
*
*   on entry                                                            
*   --------                                                            
*   OP          The block matrix-vector operation, passed to ADDABS     
*   N           the order of the matrix A                               
*   LIM         The limit on the size of the expanding Basis            
*   NUME        Largest index of the wanted eigenvalues.
*   HIEND       Logical. True only if the highest eigenpairs are needed.
*   diag        poiter for object of MatrixBase class
*   MINELEM     Array keeping the indices of the NUME lowest diagonals. 
*
*   on exit                                                             
*   -------                                                             
*   BASIS       The starting basis.                                     
*   AB, S       The starting D=AB, and small matrix S=B^TAB
*   NIV         The starting dimension of BASIS.
*/
{
    const double* diag = this->GetSignedDiagonal();

    if ((*niv>lim) || (*niv<nume)) {
/*         ..Initial estimates are not available. Give as estimates unitACPZ0374
*          ..vectors corresponding to the NUME minimum diagonal elementsACPZ0375
*          ..First find the indices of these NUME elements (in MINELEM).ACPZ0376
*          ..Array AB is used temporarily as a scratch array.   */
        dinit(n,-1.0,ab,1);
        for (int i=1; i<=nume; i++) {
            int imin=n+1;
            for (int j=1; j<=n; j++)
                if (ab[j -1]<0) {
                    imin=j;
                    break;
                }
            for (int j=imin+1; j<=n; j++)
                if ((ab[j-1]<0)&&(diag[j -1]<diag[imin-1])) imin=j;
            minelem[i-1]=imin;
            ab[imin-1]=1.0;
        }
        // ..Build the Basis. B_i=e_(MINELEM(i))
        dinit(n*lim,0.0,basis,1);
        for (int j=1; j<=nume; j++) {
            int i=int((j-1)*n+minelem[j-1]);
            basis[i-1]=1.0;
        }
        *niv=nume;
    }    

/* Find the matrix AB by matrix-vector multiplies, as well as the        ACPZ0403
*  small matrix S = B^TAB.  */
    int kpass=0;
    addabs(n,lim,hiend,kpass,*niv,basis,ab,s);

    return;
}
//---------------------------------------------------------------------------
double UDavidsonBase::sign(double *a, double *b) const
{
    if (*b<0) {
        if (*a>0) *a*=(-1);
    } else if (*a<0) *a*=(-1);

    return *a;
}
//---------------------------------------------------------------------------

bool UDavidsonBase::tstsel(int kpass, int nume, int neig, int iselec[],
            double svec[], double eigval[], int icv[], double crite, double critc,
            double rowlast[], int ind[], double oldval[], int *nncv, int incv[]) const
/*-----------------------------------------------------------------------
*                                                                       
*       Called by: DVDRVR                                               
                                                                        
*       It first checks if the wanted eigenvalues have reached          
*       convergence and updates OLDVAL. Second, for each wanted and non 
*       converged eigenvector, it finds the largest absolute coefficient
*       of the NNCV last added vectors (from SVEC) and if not coverged, 
*       places it in ROWLAST. IND has the corresponding indices.        
*       Third, it sorts ROWLAST in decreasing order and places the      
*       corresponding indices in the array INCV. The index array INCV   
*       and the number of unconverged pairs NNCV, are passed to DVDRVR.
*       Later in NEWVEC only the first MBLOCK of NNCV pairs will be     
*       targeted, since if ROWLAST(i) > ROWLAST(j)                      
*       then approximately RESIDUAL(i) > RESIDUAL(j)                    
*                                                                       
*       Subroutines called
*       IDAMAX

*                                                                       
*   on entry                                                            
*   -------                                                             
*   KPASS       current dimension of the expanding Basis                
*   NUME        Largest index of the wanted eigenvalues.                
*   NEIG        number of wanted eigenvalues of original matrix         
*   ISELEC      index array of the wanted eigenvalues.
*   SVEC        the eigenvectors of the small system                    
*   EIGVAL      The NUME lowest eigenvalues of the small problem        
*   ICV         Index of converged eigenpairs.ICV(i)=1 iff eigenpair i
*               has converged, and ICV(i)=0 if eigenpair i has not.
*   CRITE,CRITC Convergence thresholds for eigenvalues and coefficients 
*   ROWLAST     scratch array, keeping the largest absolute coefficient
*               of the NNCV last rows of Svec.                          
*   IND         scratch array, temporary keeping the indices of Rowlast 
*   OLDVAL      The previous iteration's eigenvalues.                   
*                                                                       
*   on exit
*   -------                                                             
*   NNCV         Number of non converged eigenvectors (to be targeted)  
*   INCV         Index to these columns in decreasing order of magnitude
*   TSTSEL       returns true if convergence has been reached                   
*                                                                       
*-----------------------------------------------------------------------*/
{
    bool done=false;

// Test all wanted eigenvalues for convergence under CRITE
    int nnce=0;
    for (int i=1; i<=neig; i++) {
        int ival=iselec[i -1];
        if (fabs(oldval[ival -1]-eigval[ival -1])>=crite) ++nnce;
    }
    if (!nnce) return true;

// Find the maximum element of the last NNCV coefficients of unconverged
// eigenvectors. For those unconverged coefficients, put their indices
// to IND and find their number NNCV
    double tmax, temp;
    int indx, itemp, icur, icnt=0;
    for (int i=1; i<=neig; i++)
        if (icv[iselec[i -1] -1]==0) {
            //..Find coefficient and test for convergence
            icur=kpass*iselec[i -1];
            tmax=fabs( svec[icur -1] );
            for (int l=1; l<=*nncv-1; l++) tmax=MAX(tmax, fabs(svec[icur-l -1]));
            if (tmax<critc)
                //..this  coefficient converged
                icv[iselec[i -1] -1]=1;
            else {
                //..Not converged. Add it to the list.
                ++icnt;
                ind[icnt -1]=iselec[i -1];
                rowlast[icnt -1]=tmax;
            }
        }
    *nncv=icnt;
    if (!(*nncv)) done=true;

// Sort the ROWLAST elements interchanging their indices as well
    for (int i=1; i<=*nncv; i++) {
        indx=idamax(*nncv-i+1,&rowlast[i -1],1);
        incv[i -1]=ind[indx+i-1 -1];
        temp=rowlast[indx+i-1  -1];
        rowlast[indx+i-1 -1]=rowlast[i -1];
        rowlast[i -1]=temp;
        itemp=ind[indx+i-1 -1];
        ind[indx+i-1 -1]=ind[i -1];
        ind[i -1]=itemp;
    }

    return done;
}
