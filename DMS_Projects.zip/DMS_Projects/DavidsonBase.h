#ifndef _DAVIDSONBASE_INCLUDED
#define _DAVIDSONBASE_INCLUDED


#include "BasicInclude.h"

class DLL_IO UDavidsonBase
{
public:
    void     setup(int n, int lim, int nume, bool hiend,
                     double minelem[], double basis[], double ab[], double s[], int *niv) const;
    void     dvdrvr(int n, bool hiend, int lim, int mblock, int nume, int niv, int neig,
                     int iselec[], double crite, double critc, double critr, double ortho, int maxiter,
                     double eigval[], double basis[], double ab[], double s[], double temps[],
                     double svec[], double scra1[], int iscra2[], int incv[], int icv[], double oldval[],
                     int *nmv, int *ierr, int *loop, bool inf) const;
    void     dscal(int n, double da, double dx[], int incx) const;
    void     dcopy(int n, double dx[], int incx, double dy[], int incy) const;

protected:
    virtual ErrorType      ComputeProduct(double* AB, const double* B, int Ncol) const =0;
    virtual const double*  GetSignedDiagonal(void) const =0;

private:
    int      idamax(int n, double dx[], int incx) const;
    int      ieeeck(int ispec, double zero, double one) const;
    int      ilaenv(int ispec, const char* name, const char* opts, int n1, int n2, int n3, int n4 ) const;
    double   dasum(int n, double dx[], int incx) const;
    double   ddot(int n, double dx[], int incx, double dy[], int incy) const;
    double   dnrm2(int n, double x[], int incx ) const;
    double   dlamch(char cmach ) const;
    double   dlansp(char norm, char uplo, int n, double ap[], double work[]) const;
    double   dlanst(char norm, int n, double d[], double e[]) const;
    double   dlapy2(double x, double y) const;
    double   sign(double *a, double *b) const;
    bool     lsame(char ca, char cb) const;
    bool     tstsel(int kpass, int nume, int neig, int iselec[], double svec[],
                     double eigval[], int icv[], double crite, double critc, double rowlast[],
                     int ind[], double oldval[], int *nncv, int incv[]) const;
    void     daxpy(int n, double da, double dx[], int incx, double dy[], int incy) const;
    void     dgemv(char trans, int m, int n, double alpha, double a[], int lda, double x[],
                 int incx, double beta, double y[], int incy ) const;
    void     dger(int  m, int n, double alpha, double x[], int incx, double y[], int incy,
                 double a[], int lda ) const;
    void     dspmv(char uplo, int n, double alpha, double ap[], double x[], int incx,
                 double beta, double y[], int incy ) const;
    void     dspr2(char uplo, int n, double alpha, double x[], int incx, double y[],
                 int incy, double ap[]) const;
    void     dswap (int n, double dx[], int incx, double dy[], int incy) const;
    void     xerbla(char srname[], int info ) const;
    void     dinit(int n, double a, double x[], int incx ) const;
    void     gather(int n, double a[], double b[], int index[]) const;
    void     scatter(int n, double a[], int index[], double b[]) const;
    void     multbc(int n, int k, int m, double c[], double temp[], double b[]) const;
    void     ovflow(int nume, int lim, double s[], double svec[], double eigval[]) const;
    void     newvec(int n, int nume, int lim, int mblock, int kpass, double critr,
                    double ortho, int *nncv, int incv[], const double diag[], double svec[],
                    double eigval[], double ab[], double basis[], int icv[], bool *restart,
                    bool *done) const;
    void     orthnrm(int n, int lim, double ortho, int kpass, int *nncv, double scra1[],
                        double basis[], bool *restart) const;
    void     dlae2(double a, double b, double c, double *rt1, double *rt2 ) const;
    void     dlaebz(int ijob, int nitmax, int n, int mmax, int minp, int nbmin,
                    double abstol, double reltol, double pivmin, double d[], double e[],
                    double e2[], int nval[], double ab[], double c[], int *mout, int nab[],
                    double work[], int iwork[], int *info ) const;
    void     dlaev2(double a, double b, double c, double *rt1, double *rt2,
                    double *cs1, double *sn1) const;
    void     dlagtf(int n, double a[], double lambda, double b[], double c[],
                    double tol, double d[], int in[], int *info) const;
    void     dladtsf(double *absak, double *ak, double *pert, double *temp,
                        double one, double zero, double sfmin, double bignum) const;
    void     dlarf(char side, int m, int n, double v[], int incv, double tau,  double c[],
                    int ldc, double work[]) const;
    void     dlarfg(int n, double *alpha, double x[], int incx, double *tau ) const;
    void     dlarnv(int idist, int iseed[], int n, double x[] ) const;
    void     dlartg(double f, double g, double *cs, double *sn, double *r ) const;
    void     dlaruv(int iseed[], int n, double x[] ) const;
    void     dlascl(char type, int kl, int ku, double cfrom, double cto, int m, int n,
                    double a[], int lda, int *info ) const;
    void     dlaset(char uplo, int m, int n, double alpha, double beta, double a[],
                    int lda ) const;
    void     dlasr(char side, char pivot, char direct, int m, int n, double c[],
                    double s[], double a[], int lda ) const;
    void     dlasrt(char id, int n, double d[], int *info ) const;
    void     dlassq(int n, double x[], int incx, double *scale, double *sumsq) const;
    void     dopgtr(char uplo, int n, double ap[], double tau[], double q[], int ldq,
                    double work[], int *info ) const;
    void     dopmtr(char side, char uplo, char trans, int m, int n, double ap[],
                    double tau[], double c[], int ldc, double work[], int *info ) const;
    void     dorg2l(int m, int n, int k, double a[], int lda, double tau[],
                    double work[], int *info ) const;
    void     dorg2r(int m, int n, int k, double a[], int lda, double tau[],
                    double work[], int *info ) const;
    void     dspevx(char jobz, char range, char uplo, int n, double ap[], double vl,
                    double vu, int il, int iu, double abstol, int *m, double w[], double z[],
                    int ldz, double work[], int iwork[], int ifail[], int *info ) const;
    void     dsptrd(char uplo, int n, double ap[], double d[], double e[], double tau[],
                    int *info ) const;
    void     dstebz(char range, char order, int n, double vl, double vu, int il, int iu,
                    double abstol, double d[], double e[], int *m, int *nsplit, double w[],
                    int iblock[], int isplit[], double work[], int iwork[], int *info) const;
    void     dstein(int n, double d[], double e[], int m, double w[], int iblock[],
                    int isplit[], double z[], int ldz, double work[], int iwork[],
                    int ifail[], int *info) const;
    void     dsteqr(char compz, int n, double d[], double e[], double z[], int ldz,
                    double work[], int *info ) const;
    void     dsterf(int n, double d[], double e[], int *info ) const;
    void     dlagts(int job, int n, double a[], double b[], double c[], double d[],
                    int in[], double y[], double *tol, int *info ) const;
    void     addabs(int n, int lim, bool hiend, int kpass, int nncv, double basis[],
                    double ab[], double s[]) const;
    void     dsteqr_140(int *jtot, int *n, int *iscale, double *ssfmin,  double *ssfmax,
                        double *anorm, int *lendsv, int *nmaxit, int *lsv, double d[],
                        double e[], int *info) const;

    void     scopy(const char* co, char* tu) const;
    void     dlamc1(int *beta, int *t, bool *rnd, bool *ieee1 ) const;
    void     dlamc2(int *beta, int *t, bool *rnd, double *eps, int *emin, double *rmin, int *emax, double *rmax ) const;
    void     dlamc4(int *emin, double start, int base ) const;
    void     dlamc5(int beta, int p, int emin, bool ieee, int *emax, double *rmax ) const;
};

#endif //_DAVIDSONBASE_INCLUDED
