/*********************************************************************************/
/*                                                                               */
/*     Solve a x = b, using Cholesky decomposition, assuming a positive.         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    ??-??-??   creation
Jdm/GdV  11-06-99   define daxis_b() as  extern "C"
*/


#include <stddef.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
/***

  Note: changed long int into int.
***/
#ifdef __cplusplus
extern "C" 
{
    int daxisb_c(double *amat, double *x, const double *b, int n, int ndim, double *det);
}
#endif

int daxisb_c(double *amat, double *x, const double *b, int n, int ndim, double *det)
/*
 Solve the system of equations amat x=b, where amat is a symmetric matrix.
   
   *amat  : Symmetric matrix, positive definit
   *x     : Solution vector
   *b     : right hand side vector
   n      : Mathematical dimension of the matrix
   ndim   : Physical dimension of amat, (as it is stored)
   *det   : Determinant of amat
            if det==NULL No determinant is computed 


 return
       0 no errors
      -1 amat not positive
      -2 inconsisten dimensions
      -3 memory allocation error

   methode: Cholescky ontbinding                                     
*/

{  register int i,j,k;
   int   ierr;
   double dum;
   double *p=NULL,*h=NULL;
   
   if(n>ndim) return ierr=-2;

   p = (double *) malloc(n*sizeof(p[0]));
   h = (double *) malloc(n*sizeof(h[0]));
   if( h==NULL || p==NULL) {ierr= -3; goto error;}
   
   ierr  = 0;
   if(det) *det  = 1.F;
   for(i=0;i<n;i++)
   {  
      for(j=i;j<n;j++)
      {  
         dum = amat[i+j*ndim];
         for(k=(i-1)*ndim;k>=0;k-=ndim) dum -= amat[j+k]*amat[i+k];

         if(i==j) 
         {  
            if(dum<=0.) {ierr = -1; goto error;} 
            p[i]  = sqrt(dum);
            if(det) *det *= p[i];
         } 
         else
            amat[j+i*ndim] = dum/p[i]; 
      }
   }
   if(det) *det = (*det)*(*det);
   
/*  amat=L*[L]T, nu zit L onder de hoofddiagonaal van amat. */
/*  Los op: Lh=b                                            */
   
   for(k=0;k<n;k++) h[k]=b[k];
   for(k=0;k<n;k++) 
   {  
      for(j=0;j<k;j++) h[k] -= amat[k+j*ndim]*h[j];
      h[k] /= p[k];
   }   
   
/* Los op: [L]Tx=h */

   for(k=0;k<n;k++) x[k]=h[k];
   for(j=n-1;j>=0;j--)
   {
      for(k=j+1;k<n;k++) x[j] -= amat[k+j*ndim]*x[k];
      x[j] /= p[j];
   }
   
/* Herstel het onderdriehoeksdeel van amat. */
 
error:   
   for(i=1;i<n;i++)
      for(j=0;j<i;j++) amat[i+j*ndim] = amat[j+i*ndim];

   free(p); free(h);
   return ierr;
}
     
   
