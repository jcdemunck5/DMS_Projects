/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for profiling and debugging classes derived from UDebug.           */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    19-04-08   Creation
  JdM    13-05-11   Replaced UDebug::UDebug() by AddClassFunction()
  JdM    21-07-14   Added const char* based AddClassFunction()
*/

#include "Debug.h"
#include "String.h"
#include "FileName.h"

class UClassFunction
{
public:
    UClassFunction();
    UClassFunction(const UClassFunction& CF);
    UClassFunction(UString Name);
    int                    IncreaseCalls();
    UString                GetFuncName(void) const {return FunctionName;}
    const UString&         GetProperties() const;

private:
    static  UString        Properties;
    UString FunctionName;
    int     NCalled;
};

class UDebugClass
{
public:
    UDebugClass();
    UDebugClass(UString CName, UString FName);
    UDebugClass(const UDebugClass& DC);
    UDebugClass&           operator=(const UDebugClass& DC);
    ~UDebugClass();

    ErrorType              FunctionCalled(UString FuncName);
    UString                GetClassName(void) const {return ClassName;}
    const UString&         GetProperties(UString Comment) const;

private:
    static UString         Properties;
    UString                ClassName;
    int                    NFunc;
    int                    NFuncAlloc;
    UClassFunction*        FuncArray;
};

UString         UClassFunction::Properties  = UString();
UString         UDebugClass   ::Properties  = UString();

UFileName       UDebug        ::DebugFile   = UFileName("_Debug.txt");
bool            UDebug        ::DebugOn     = false;
int             UDebug        ::NClass      = 0;
int             UDebug        ::NClassAlloc = 0;
UDebugClass*    UDebug        ::ClassArray  = NULL;



UClassFunction::UClassFunction()
{
    NCalled      = 0;
    FunctionName = UString();
}
UClassFunction::UClassFunction(const UClassFunction& CF)
{
    NCalled      = CF.NCalled;
    FunctionName = CF.FunctionName;
}
UClassFunction::UClassFunction(UString Name)
{
    NCalled      = 1;
    FunctionName = Name;
}
const UString& UClassFunction::GetProperties() const
{
    Properties  =  FunctionName + UString(NCalled," \t%d ");
    return Properties;
}
int UClassFunction::IncreaseCalls(void)
{
    NCalled++;
    return NCalled;
}

UDebugClass::UDebugClass()
{
    NFunc      = 0;
    NFuncAlloc = 0;
    FuncArray  = NULL;
}
UDebugClass::UDebugClass(const UDebugClass& DC)
{
    NFunc      = 0;
    NFuncAlloc = 0;
    FuncArray  = NULL;
    *this      = DC;
}
UDebugClass::UDebugClass(UString CName, UString FName)
{
    ClassName    =  CName;
    NFunc        =  1;
    NFuncAlloc   = 20;
    FuncArray    = new UClassFunction[NFuncAlloc];
    FuncArray[0] = UClassFunction(FName);
}
UDebugClass::~UDebugClass()
{
    delete[] FuncArray;
}
UDebugClass& UDebugClass::operator=(const UDebugClass& DC)
{
    ClassName  = DC.ClassName;
    NFunc      = DC.NFunc;
    NFuncAlloc = DC.NFuncAlloc;
    FuncArray  = new UClassFunction[NFuncAlloc];
    if(FuncArray)
        for(int k=0; k<NFunc; k++) FuncArray[k] = DC.FuncArray[k];
    return *this;
}


const UString& UDebugClass::GetProperties(UString Comment) const
{
    Properties  =  UString();

    for(int k=0; k<NFunc; k++)
        Properties += ClassName + UString(" \t") + FuncArray[k].GetProperties() + UString("\n");
    
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UDebugClass::FunctionCalled(UString FuncName)
{
    int ifunc = -1;
    for(int k=0; k<NFunc; k++)
        if(FuncName==FuncArray[k].GetFuncName())
        {
            ifunc = k;
            break;
        }

    if(ifunc<0)
    {
        ifunc = NFunc;
        if(ifunc>=NFuncAlloc)
        {
            int             NewNFuncAlloc = NFuncAlloc + 20;
            UClassFunction* NewFuncArray  = new UClassFunction[NewNFuncAlloc];
            if(NewFuncArray)
            {
                NFuncAlloc = NewNFuncAlloc;
                for(int k=0; k<NFunc; k++) NewFuncArray[k] = FuncArray[k];
                delete[] FuncArray; 
                FuncArray  = NewFuncArray;
            }
            else
            {
                CI.AddToLog("ERROR: UDebugClass::FunctionCalled(). Memory allocation, NewNFuncAlloc = %d. \n", NewNFuncAlloc);
                return U_ERROR;
            }
        }
        FuncArray[ifunc] = UClassFunction(FuncName);
        NFunc++;
    }
    else
        FuncArray[ifunc].IncreaseCalls();

    return U_OK;
}

UDebug::UDebug(bool SetDebug)
{
    NClass     = 0;
    DebugOn    = SetDebug;
    DebugFile  = UFileName(CI.GetLogFileName());
    DebugFile.InsertBeforeExtension("_Debug");
    DebugFile.ReplaceExtension(".txt");

    NClassAlloc = 20;
    ClassArray  = new UDebugClass[NClassAlloc];
    if(ClassArray==NULL)
    {
        DebugOn     = false;
        NClassAlloc = 0;
        CI.AddToLog("ERROR. UDebug::UDebug(). Memory allocation. \n");
    }
}

void UDebug::AddClassFunction(const char* ClassName, const char* FuncName)
{
    if(DebugOn==false) return;

    UString C(ClassName);
    UString F(FuncName);
    AddClassFunction(C, F);
}

void UDebug::AddClassFunction(const UString& ClassName, const UString& FuncName)
{
    if(DebugOn==false) return;

    int iclass = -1;
    for(int k=0; k<NClass; k++)
        if(ClassName==ClassArray[k].GetClassName())
        {
            iclass = k;
            break;
        }

    if(iclass<0)
    {
        iclass = NClass;
        if(iclass>=NClassAlloc)
        {
            int          NewNClassAlloc = NClassAlloc + 20;
            UDebugClass* NewClassArray  = new UDebugClass[NewNClassAlloc];
            if(NewClassArray)
            {
                NClassAlloc = NewNClassAlloc;
                for(int k=0; k<NClass; k++) NewClassArray[k] = ClassArray[k];
                delete[] ClassArray; 
                ClassArray  = NewClassArray;
            }
            else
            {
                CI.AddToLog("ERROR: UDebug::UDebug(). Memory allocation, Nclasses (%d). \n", iclass);
                DebugOn     = false;
                NClassAlloc = 0;
                return;
            }
        }
        ClassArray[iclass] = UDebugClass(ClassName, FuncName);
        NClass++;
    }
    ClassArray[iclass].FunctionCalled(FuncName);

    FILE* fp = fopen(DebugFile, "wt");

    fprintf(fp,"Debug1.0\n");
    fprintf(fp,"%s",CI.GetProperties("//  "));
    fprintf(fp,"//  \n");
    fprintf(fp,"LAST_CLASS    = %s\n", (const char*)ClassName);
    fprintf(fp,"LAST_FUNCTION = %s\n", (const char*)FuncName);
    fprintf(fp,"//  \n");
    for(int k=0; k<NClass; k++)
    {
        UString Text = ClassArray[k].GetProperties("//  ");
        fprintf(fp,"%s", (const char*)Text);
    }
    fclose(fp);
}
UDebug::~UDebug()
{
    if(DebugOn==false) return;
}

