#ifndef _DEBUG_INCLUDED
#define _DEBUG_INCLUDED

#include"DLLio.h"

class UDebugClass;
class UString;
class DLL_IO UFileName;

class DLL_IO UDebug
{
public:
    UDebug(bool SetDebug=false);
    ~UDebug();
    void   AddClassFunction(const char* ClassName, const char* FuncName);
    void   AddClassFunction(const UString& ClassName, const UString& FuncName);

private:
    static int             NClass;
    static int             NClassAlloc;
    static UDebugClass*    ClassArray;
    static bool            DebugOn;
    static UFileName       DebugFile;
};

#endif // _DEBUG_INCLUDED
