/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     Module for computation of eigenvalue decomposition of Hermitian           */
/*     (symmetric) matrices.                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    25-10-07   creation
  JdM    11-11-07   Bug fix: IsHermitian(). Only real part was tested.
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    04-03-13   Added decomposition of symmetric (real) matrix
  JdM    06-03-13   Added GetEigenValues()
  JdM    01-12-13   IsSymmetric() and IsHermitian(). Use 10*EPSILON
                    Added JointDiagonalize(), GetMatMul(), MatMul(), PreMultDiag() and PostMultDiag().
  JdM    14-12-13   Added ForceSymmetric()
*/

#include <math.h>
#include "DecompHermitian.h"

#define PYTHAG(a, b)  sqrt((a)*(a) + (b)*(b))


const int DEFAULTMAXITER = 50;


void UDecompHermitian::SetAllMembersDefault(void)
{
    SetMaxIter(-1);
    SetEPSILON();
}

void UDecompHermitian::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
}

UDecompHermitian::UDecompHermitian()
{
    SetAllMembersDefault();
}

ErrorType UDecompHermitian::SetMaxIter(int MaxIter)
{
    if(MaxIter==0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::SetMaxIter(). Invalid MaxIter (=%d) \n", MaxIter);
        return U_ERROR;
    }
    if(MaxIter<0) MAXITER = DEFAULTMAXITER;
    else          MAXITER = MaxIter;

    return U_OK;
}

bool UDecompHermitian::IsHermitian(int N, const double* ar, const double* ai, bool AddToLog) const
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::IsHermitian(). Invalid N (=%d) \n", N);
        return false;
    }
    if(ar==NULL || ai==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::IsHermitian(). NULL input matrix. \n");
        return false;
    }
    for(int i=0; i<N; i++)
    {
        for(int j=i; j<N; j++)
        {
            if(fabs(ar[i*N+j]-ar[j*N+i])>10*EPSILON) 
            {
                if(AddToLog) CI.AddToLog("Note: UDecompHermitian::IsHermitian(). ar[%d,%d] violates symmetry. \n", i,j);
                return false;
            }
            if(fabs(ai[i*N+j]+ai[j*N+i])>10*EPSILON) 
            {
                if(AddToLog) CI.AddToLog("Note: UDecompHermitian::IsHermitian(). ai[%d,%d] violates anti-symmetry. \n", i,j);
                return false;
            }
        }
    }
    return true;
}
bool  UDecompHermitian::IsSymmetric(int N, const double* a, bool AddToLog) const
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::IsSymmetric(). Invalid N (=%d) \n", N);
        return false;
    }
    if(a==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::IsSymmetric(). NULL input matrix. \n");
        return false;
    }
    for(int i=0; i<N; i++)
    {
        for(int j=i; j<N; j++)
        {
            if(fabs(a[i*N+j]-a[j*N+i])>10*EPSILON) 
            {
                if(AddToLog) CI.AddToLog("Note: UDecompHermitian::IsSymmetric(). ar[%d,%d] violates symmetry. \n", i,j);
                return false;
            }
        }
    }
    return true;
}
ErrorType UDecompHermitian::ForceSymmetric(int N, double* a, double Tol) const
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::ForceSymmetric(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(a==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::ForceSymmetric(). NULL input matrix. \n");
        return U_ERROR;
    }
    if(Tol<=0.)
    {
        CI.AddToLog("ERROR: UDecompHermitian::ForceSymmetric(). Invalid tolerance parameter (%f). \n", Tol);
        return U_ERROR;
    }
    for(int i=0; i<N; i++)
    {
        double RowSum = 0;
        for(int j=i  ; j<N; j++) RowSum += fabs(a[i*N+j]);

        for(int j=i+1; j<N; j++)
        {
            double Diff = fabs(a[i*N+j]-a[j*N+i]);
            if(RowSum>0.) Diff /= RowSum;
            if(Diff>Tol) 
            {
                CI.AddToLog("Note: UDecompHermitian::ForceSymmetric(). ar[%d,%d] asymmetry larger than tolerance (Diff = %20.15e). \n", i,j, Diff);
                return U_ERROR;
            }
            double Aver = (a[i*N+j]+a[j*N+i])/2.;
            a[i*N+j] = a[j*N+i] = Aver;
        }
    }
    return U_OK;
}

ErrorType UDecompHermitian::Decompose(int N, double* ar, double* ai, bool matz, double* w, double* zr, double* zi) const
{
/* ch()
c     this subroutine calls the recommended sequence of
c     subroutines from the eigensystem subroutine package (eispack)
c     to find the eigenvalues and eigenvectors (if desired)
c     of a complex hermitian matrix.
c
c     on input
c
c        nm  must be set to the row dimension of the two-dimensional
c        array parameters as declared in the calling program
c        dimension statement.
c
c        n  is the order of the matrix  a=(ar,ai).
c
c        ar  and  ai  contain the real and imaginary parts,
c        respectively, of the complex hermitian matrix.
c
c        matz  is an integer variable set equal to zero if
c        only eigenvalues are desired.  otherwise it is set to
c        any non-zero integer for both eigenvalues and eigenvectors.
c
c     on output
c
c        w  contains the eigenvalues in ascending order.
c
c        zr  and  zi  contain the real and imaginary parts,
c        respectively, of the eigenvectors if matz is not zero.
c
c        ierr  is an integer output variable set equal to an error
c           completion code described in the documentation for tqlrat
c           and tql2.  the normal completion code is zero.
c
c
c     questions and comments should be directed to burton s. garbow,
c     mathematics and computer science div, argonne national laboratory
c
c     this version dated august 1983.
c
c     ------------------------------------------------------------------
c
*/
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(ar==NULL || ai==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL real or imaginary part of input. \n");
        return U_ERROR;
    }
    if(w==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL diagonal matrix. \n");
        return U_ERROR;
    }
    if(IsHermitian(N, ar, ai, true)==false)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Matrix not Hermitian. \n");
        return U_ERROR;
    }

    if(matz==true)
    {
        if(zr==NULL || zi==NULL)
        {
            CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL real or imaginary part of output. \n");
            return U_ERROR;
        }
    }

    double* fv1 = new double[  N];
    double* fv2 = new double[  N];
    double* fm1 = new double[2*N];
    if(fv1==NULL || fv2==NULL || fm1==NULL)
    {
        delete[] fv1;
        delete[] fv2;
        delete[] fm1;
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Memory allocation, N=%d. \n", N);
        return U_ERROR;
    }

    ErrorType E = UDecompHermitian::htridi(N,ar,ai,w,fv1,fv2,fm1);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Perforing htridi() \n");
    }
    if(E==U_OK)
    {
        if(matz==true)
        {
            for(int nn=0; nn<N*N; nn++   ) zr[nn]=0;
            for(int nn=0; nn<N*N; nn+=N+1) zr[nn]=1;

            if(tql2  (N,w,fv1,zr)         !=U_OK || 
               htribk(N,ar,ai,fm1,N,zr,zi)!=U_OK)
            {
                E = U_ERROR;
                CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Perforing tql2() or htribk(). \n");

            }
        }
        else // find eigenvalues only
        {
            if(tqlrat(N,w,fv2)!=U_OK)
            {
                E = U_ERROR;
                CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Perforing tqlrat() \n");
            }
        }
    }
    delete[] fv1;
    delete[] fv2;
    delete[] fm1;

/* Restore input matrices */
    for(int i=0; i<N; i++)
    {
        for(int j=0; j<i; j++) 
        {
            ar[i*N+j] =  ar[j*N+i];
            ai[i*N+j] = -ai[j*N+i];
        }
        ai[i*N+i] = 0;
    }
    return E;
}

ErrorType UDecompHermitian::Decompose(int N, double* a, bool matz, double* w, double* z) const
/*
    Input, int N, the order of the matrix.

    Input, double a[N*N], the real symmetric matrix.

    Input, int matz, is zero if only eigenvalues are desired, 
    and nonzero if both eigenvalues and eigenvectors are desired.

    Output, double w[N], the eigenvalues in ascending order.

    Output, double z[N*N], contains the eigenvectors, if matz
    is nonzero.
 */
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(a==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL pointer for input matrix. \n");
        return U_ERROR;
    }
    if(w==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL diagonal matrix. \n");
        return U_ERROR;
    }
    if(IsSymmetric(N, a, true)==false)
    {
        CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Matrix not symmetric. \n");
        return U_ERROR;
    }

    ErrorType E = U_OK;
    double *fv1 = NULL;
    double *fv2 = NULL;
    if(matz==true)
    {
        if(z==NULL)
        {
            CI.AddToLog("ERROR: UDecompHermitian::Decompose(). NULL pointer for eigenvector output. \n");
            return U_ERROR;
        }

        fv1 = new double[N];
        if(fv1==NULL)
        {
            CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Memory allocation, N= %d. \n", N);
            return U_ERROR;
        }

        if(E==U_OK) E = tred2(N, a, w, fv1, z);
        if(E==U_OK) E = tql2R(N, w, fv1, z);

        for(int i=0; i<N; i++) // Transpose z[]
        {
            for(int j=0  ; j<N; j++) fv1[j]   =   z[i*N+j];
            for(int j=i+1; j<N; j++) z[i*N+j] =   z[j*N+i];
            for(int j=i+1; j<N; j++) z[j*N+i] = fv1[j];
        }
        delete[] fv1;
    }
    else
    {
        fv1 = new double[N];
        fv2 = new double[N];
        if(fv1==NULL || fv2==NULL)
        {
            delete[] fv1; delete[] fv2;
            CI.AddToLog("ERROR: UDecompHermitian::Decompose(). Memory allocation, N= %d. \n", N);
            return U_ERROR;
        }

        if(E==U_OK) E =   tred1(N, a, w, fv1, fv2);
        if(E==U_OK) E = tqlratR(N, w, fv2);
        for(int i=0; i<N; i++) // Transpose a[]
        {
            for(int j=0  ; j<N; j++) fv1[j]   =   a[i*N+j];
            for(int j=i+1; j<N; j++) a[i*N+j] =   a[j*N+i];
            for(int j=i+1; j<N; j++) a[j*N+i] = fv1[j];
        }

        delete[] fv1;
        delete[] fv2;
    }

/* Restore input matrices */
    for(int i=0; i<N; i++)
        for(int j=0; j<i; j++) a[i*N+j] =  a[j*N+i];
    return E;
}

double* UDecompHermitian::GetSumKPXisB(const double* a1, const double* a2, int NA, const double* b1, const double* b2, int NB, const double* bvec) const
/*
    Return the solution of the sustem A VEC(x) = VEC(bvec),
    where A = a1[] KP b1[] + a2[] KP b2[], 
    a1[] and a2[] pos. def NA x NA
    b1[] and b2[] pos. def NB x NB
    bvec[] is NA x NB matrix
 */
{
    if(NA<=0 || NB<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). Invalid NA (=%d) or NB (=%d). \n", NA, NB);
        return NULL;
    }
    if(a1==NULL || a2==NULL || b1==NULL || b2==NULL || bvec==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). NULL input matrix/matrices \n");
        return NULL;
    }

    double* LambAA = new double[NA];
    double* WmatAA = new double[NA*NA];
    double* LambBB = new double[NB];
    double* WmatBB = new double[NB*NB];
    double* xvec   = new double[NA*NB];

    if(LambAA==NULL || WmatAA==NULL || LambBB==NULL || WmatBB==NULL || xvec==NULL)
    {
        delete[] LambAA; delete[] WmatAA;
        delete[] LambBB; delete[] WmatBB;
        delete[] xvec;
        CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). Memory allocation. NA (=%d) or NB (=%d). \n", NA, NB);
        return NULL;
    }

    ErrorType    Ea = UDecompHermitian::JointDiagonalize(NA, a1, a2, LambAA, WmatAA);
    if(Ea!=U_OK) Ea = UDecompHermitian::JointDiagonalize(NA, a2, a1, LambAA, WmatAA);
    ErrorType    Eb = UDecompHermitian::JointDiagonalize(NB, b1, b2, LambBB, WmatBB);
    if(Eb!=U_OK) Eb = UDecompHermitian::JointDiagonalize(NB, b2, b1, LambBB, WmatBB);
    if(Ea!=U_OK || Eb!=U_OK)
    {
        delete[] LambAA; delete[] WmatAA;
        delete[] LambBB; delete[] WmatBB;
        delete[] xvec;
        if(Ea!=U_OK) CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). Performing joint diagonalization of a1[] - a2[]. \n");
        if(Eb!=U_OK) CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). Performing joint diagonalization of b1[] - b2[]. \n");
        return NULL;
    }

    double* Whulp   = UDecompHermitian::GetMatMul(WmatAA, NA, NA, false, bvec  , NA, NB, false);
    double* WAABWBB = UDecompHermitian::GetMatMul(Whulp , NA, NB, false, WmatBB, NB, NB, true);

    if(Whulp==NULL || WAABWBB==NULL)
    {
        delete[] LambAA; delete[] WmatAA;
        delete[] LambBB; delete[] WmatBB;
        delete[] Whulp ; delete[] WAABWBB;
        delete[] xvec;
        CI.AddToLog("ERROR: UDecompHermitian::GetSumKPXisB(). First pre-whitening. . \n");
        return NULL;
    }

// Diagonal KP
    for(int i=0; i<NA; i++)
        for(int j=0; j<NB; j++)
            WAABWBB[i*NB+j] /= (LambAA[i]*LambBB[j] + 1.);


    UDecompHermitian::MatMul(Whulp, WmatAA, NA, NA, true , WAABWBB, NA, NB, false);
    UDecompHermitian::MatMul(xvec , Whulp , NA, NB, false, WmatBB , NB, NB, false);

    delete[] LambAA; delete[] WmatAA;
    delete[] LambBB; delete[] WmatBB;
    delete[] Whulp ; delete[] WAABWBB;

    return xvec;
}

ErrorType UDecompHermitian::JointDiagonalize(int N, const double* a, const double* b, double* lambda, double* z, bool InvertZ) const
/*
    Assuming that both a[] and b[] are symmetric N x N matrices, and that b[] is positive definite,
    compute the N vector lamda[] and the NxN matrix z[] such that:

    Z * a * Zt = diag(lamda)
    Z * b * Zt = I
 */
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(a==NULL || b==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). NULL input matrix/matrices \n");
        return U_ERROR;
    }
    if(z==NULL || lambda==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). NULL output matrix/matrices \n");
        return U_ERROR;
    }
    UDecompHermitian A;
    if(A.IsSymmetric(N, a, false)!=true)
    {
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Input matrix a[] not symmetric.\n");
        return U_ERROR;
    }
    UDecompHermitian B;
    if(B.IsSymmetric(N, b, false)!=true)
    {
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Input matrix b[] not symmetric.\n");
        return U_ERROR;
    }
    double* lamB  = new double[N  ];
    double* zB    = new double[N*N];
    double* cHelp = new double[N*N];

    if(lamB==NULL || zB==NULL || cHelp==NULL)
    {
        delete[] lamB; delete[] zB; delete[] cHelp;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Memory allocation, N=%d  .\n", N);
        return U_ERROR;
    }
    for(int ij=0; ij<N*N; ij++) cHelp[ij] = b[ij];

    B.Decompose(N, cHelp, true, lamB, zB);
    
    double EigenOffset = 0;
    if(lamB[N-1]<0.)
    {
        EigenOffset = fabs(lamB[N-1]) *1.1;
        CI.AddToLog("WARNING: UDecompHermitian::JointDiagonalize(). Matrix b[] not pos. def. LamB[%d]=%20.15e   . Apply eigenvalue shift (%20.15e).\n", N-1, lamB[N-1], EigenOffset);
    }
    for(int i=0; i<N; i++)
    {
        if(lamB[i]+EigenOffset>0)
        {
            lamB[i] = sqrt( lamB[i]+EigenOffset);
            continue;
        }
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). N=%d. Matrix b[] not pos. def. LamB[%d]=%20.15e   .\n", N, i, lamB[i]);
        delete[] lamB; delete[] zB; delete[] cHelp;
        return U_ERROR;
    }

    for(int i=0; i<N; i++) lamB[i] = 1./lamB[i];

    if(MatMul(cHelp, a, N, N, false, zB, N, N, false)!=U_OK)
    {
        delete[] lamB; delete[] zB; delete[] cHelp;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Computing matrix product a * zB  .\n");
        return U_ERROR;
    }
    double* c =  GetMatMul(zB, N, N, true, cHelp, N, N, false);
    delete[] cHelp;
    if(c==NULL)
    {
        delete[] lamB; delete[] zB;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Computing matrix product zBT * a * zB  .\n");
        return U_ERROR;
    }

    if(PreMultDiag(N, lamB, c)!=U_OK || PostMultDiag(N, lamB, c)!=U_OK)
    {
        delete[] lamB; delete[] zB; delete[] c;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Computing matrix product c  .\n");
        return U_ERROR;
    }

// Decompose c[]
    UDecompHermitian C;
    if(C.ForceSymmetric(N, c, 1.e-10)!=U_OK && C.ForceSymmetric(N, c, 1.e-6)!=U_OK)
    {
        delete[] lamB; delete[] zB; delete[] c;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Intermediate matrix c[] not symmetric.\n");
        return U_ERROR;
    }
    double* zC   = new double[N*N];

    if(zC==NULL)
    {
        delete[] lamB; delete[] zB;
        delete[] zC;   delete[] c;
        CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Memory allocation, N=%d  (Before decomposing c[]) .\n", N);
        return U_ERROR;
    }
    C.Decompose(N, c, true, lambda, zC);
    delete[] c;

    if(InvertZ) // Compute inverse of z[]
    {
        for(int i=0; i<N; i++) lamB[i] = 1./lamB[i];

        PostMultDiag(N, lamB, zB);
        delete[] lamB;

        if(MatMul(z, zB, N, N, false, zC, N, N, false)!=U_OK)
        {
            delete[] zB; delete[] zC;
            CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Computing final matrix multiplication.\n");
            return U_ERROR;
        }
    }
    else
    {
        PostMultDiag(N, lamB, zB);
        delete[] lamB;

        if(MatMul(z, zC, N, N, true, zB, N, N, true)!=U_OK)
        {
            delete[] zB; delete[] zC;
            CI.AddToLog("ERROR: UDecompHermitian::JointDiagonalize(). Computing final matrix multiplication.\n");
            return U_ERROR;
        }
    }
    delete[] zB; delete[] zC;
    return U_OK;
}

double* UDecompHermitian::GetEigenValues(int N, double* ar, double* ai) const
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Invalid N (=%d) \n", N);
        return NULL;
    }
    if(ar==NULL || ai==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). NULL real or imaginary part of input. \n");
        return NULL;
    }
    if(IsHermitian(N, ar, ai, true)==false)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Matrix not Hermitian. \n");
        return NULL;
    }
    double* Eigen = new double[N];
    if(Eigen==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). NULL diagonal matrix. \n");
        return NULL;
    }
    if(Decompose(N, ar, ai, false, Eigen, NULL, NULL)!=U_OK)
    {
        delete[] Eigen;
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Computing eigen values.\n");
        return NULL;
    }
    return Eigen;
}
double* UDecompHermitian::GetEigenValues(int N, double* a) const
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Invalid N (=%d) \n", N);
        return NULL;
    }
    if(a==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). NULL real or imaginary part of input. \n");
        return NULL;
    }
    if(IsSymmetric(N, a, true)==false)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Matrix not Symmetric. \n");
        return NULL;
    }
    double* Eigen = new double[N];
    if(Eigen==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). NULL diagonal matrix. \n");
        return NULL;
    }
    if(Decompose(N, a, false, Eigen, NULL)!=U_OK)
    {
        delete[] Eigen;
        CI.AddToLog("ERROR: UDecompHermitian::GetEigenValues(). Computing eigen values.\n");
        return NULL;
    }
    return Eigen;
}

ErrorType UDecompHermitian::htridi(int N, double* ar, double* ai, double* d, double* e, double* e2, double* tau) const
{
/*
c
c     this subroutine is a translation of a complex analogue of
c     the algol procedure tred1, num. math. 11, 181-195(1968)
c     by martin, reinsch, and wilkinson.
c     handbook for auto. comp., vol.ii-linear algebra, 212-226(1971).
c
c     this subroutine reduces a complex hermitian matrix
c     to a real symmetric tridiagonal matrix using
c     unitary similarity transformations.
c
c     on input
c
c        n is the order of the matrix.
c
c        ar and ai contain the real and imaginary parts,
c          respectively, of the complex hermitian input matrix.
c          only the lower triangle of the matrix need be supplied.
c
c     on output
c
c        ar and ai contain information about the unitary trans-
c          formations used in the reduction in their full lower
c          triangles.  their strict upper triangles and the
c          diagonal of ar are unaltered.
c
c        d contains the diagonal elements of the the tridiagonal matrix.
c
c        e contains the subdiagonal elements of the tridiagonal
c          matrix in its last n-1 positions.  e(1) is set to zero.
c
c        e2 contains the squares of the corresponding elements of e.
c          e2 may coincide with e if the squares are not needed.
c
c        tau contains further information about the transformations.
c
c     calls PYTHAG for  dsqrt(a*a + b*b) .
c
c     questions and comments should be directed to burton s. garbow,
c     mathematics and computer science div, argonne national laboratory
c
c     this version dated august 1983.
c
c     ------------------------------------------------------------------
c
*/
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::htridi(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(ar==NULL || ai==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::htridi(). NULL real or imaginary part of input. \n");
        return U_ERROR;
    }
    if(d==NULL || e==NULL || e2==NULL || tau==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::htridi(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }
    tau[  N-1] = 1;
    tau[2*N-1] = 0;

    for(int i=0  ; i< N; i++) d[i] = ar[i*N+i];

    for(int i=N-1; i>=0; i--)
    {
        int    l     = i-1;
        double h     = 0. ;

        e [i]        = 0.;
        e2[i]        = 0.;
        
        double scale = 0.;
        if(l>=0)
        {
           tau[  l]  = 1;
           tau[N+l]  = 0;
           for(int k=0; k<=l; k++) scale += fabs(ar[i*N+k]) + fabs(ai[i*N+k]);
        }
        if(scale>0.)
        {
            for(int k=0; k<=l; k++)
            {
                ar[i*N+k] /= scale;
                ai[i*N+k] /= scale;
                h         += ar[i*N+k]*ar[i*N+k] + ai[i*N+k]*ai[i*N+k]; 
            }

            e2[i]      = scale * scale * h;
            double g   = sqrt(h);
            e[i]       = scale * g;
            double f   = PYTHAG(ar[i*N+l], ai[i*N+l]);

/*  .......... form next diagonal element of matrix t .......... */
            double si  = 0;
            if(f!=0.0)
            {
                tau[l]     = (ai[i*N+l] * tau[N+i] - ar[i*N+l] * tau[i]) / f;
                si         = (ar[i*N+l] * tau[N+i] + ai[i*N+l] * tau[i]) / f;
                h         += f * g;
                g          = 1.0 + g / f;
                ar[i*N+l] *= g;
                ai[i*N+l] *= g;
            }
            else
            {
                tau[l]    = -tau[  i];
                si        =  tau[N+i];
                ar[i*N+l] = g;
            }
            if(l!=0 && f!=0.0)
            {
                f = 0.0;
                for(int j=0; j<=l; j++)
                {
                    double g =  0.0;
                    double gi = 0.0;
/*     .......... form element of a*u .......... */
                    for(int k=0; k<=j; k++)
                    {
                        g  +=  ar[j*N+k] * ar[i*N+k] + ai[j*N+k] * ai[i*N+k];
                        gi += -ar[j*N+k] * ai[i*N+k] + ai[j*N+k] * ar[i*N+k];
                    }

                    for(int k=j+1; k<=l; k++)
                    {
                        g  +=   ar[k*N+j] * ar[i*N+k] - ai[k*N+j] * ai[i*N+k];
                        gi += - ar[k*N+j] * ai[i*N+k] - ai[k*N+j] * ar[i*N+k];
                    }
/*     .......... form element of p ..........*/
                    e[j]      = g  / h;
                    tau[N+j]  = gi / h;
                    f        += e[j] * ar[i*N+j] - tau[N+j] * ai[i*N+j];    
                }

                double hh = f / (h + h);
/*     .......... form reduced a ..........*/
                for(int j=0; j<=l; j++)
                {
                    double f  =   ar[i*N+j];
                    double g  =   e[j] - hh * f;
                    e[j]      =   g;
                    double fi = - ai[i*N+j];
                    double gi =  tau[  N+j] - hh * fi;
                    tau[N+j]  = -gi;

                    for(int k=0; k<=j; k++)
                    {
                        ar[j*N+k] += -f*e  [  k] - g*ar[i*N+k]  + fi*tau[N+k] + gi * ai[i*N+k];
                        ai[j*N+k] += -f*tau[N+k] - g*ai[i*N+k]  - fi*e  [  k] - gi * ar[i*N+k];
                    }
                }
            }
            for(int k=0; k<=l; k++)
            {
                ar[i*N+k] *= scale;
                ai[i*N+k] *= scale;
            }
            tau[N+l] = -si;
        }
        double hh = d[i];
        d[i]      = ar[i*N+i];
        ar[i*N+i] = hh;
        ai[i*N+i] = scale * sqrt(h);
    }
    return U_OK;
}

ErrorType UDecompHermitian::tqlratR(int N, double* d, double* e2) const
/*
    tqlratR() computes all eigenvalues of a real symmetric tridiagonal matrix.
    Input, int N, the order of the matrix.

    Input/output, double D[N].  On input, D contains the diagonal
    elements of the matrix.  On output, D contains the eigenvalues in ascending
    order.  If an error exit was made, then the eigenvalues are correct
    in positions 1 through IERR-1, but may not be the smallest eigenvalues.

    Input/output, double E2[N], contains in positions 2 through N 
    the squares of the subdiagonal elements of the matrix.  E2(1) is
    arbitrary.  On output, E2 has been overwritten by workspace
    information.

    Output, int TQLRAT, error flag.
    0, for no error,
*/
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tqlratR(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(N==1) return U_OK;

    if(d==NULL || e2==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tqlratR(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }
    for(int i=1; i<N; i++) e2[i-1] = e2[i];

    double f = 0.0;
    double t = 0.0;
    e2[N-1]  = 0.0;

    for(int l=0; l<N; l++)
    {
        double h = r8_abs ( d[l] ) + sqrt ( e2[l] );
        double c = 0.;
        double b = 0.;

        if(t<=h)
        {
            t = h;
            b = r8_abs ( t ) * r8_epsilon ( );
            c = b * b;
        }
/*  Look for small squared sub-diagonal element. */
        int m=l;
        for(m=l; m<N; m++) if(e2[m] <= c) break;

        int iter = 0;

        if(m!=l)
        {
            while(1)
            {
                iter++;
                if(iter>=MAXITER)
                {
                    CI.AddToLog("ERROR: UDecompHermitian::tqlratR(). Maximum number of iterations exceeded (iter=%d). \n", iter);
                    return U_ERROR;
                }

                int    l1 = l + 1;         /*  Form shift.*/
                double s  = sqrt ( e2[l] );
                double g  = d[l];
                double p  = ( d[l1] - g ) / ( 2.0 * s );
                double r  = PYTHAG( p, 1.0 );
                d[l]      = s / ( p + r8_abs ( r ) * r8_sign ( p ) );
                h         = g - d[l];
                for(int i = l1; i<N; i++ ) d[i] -= h;
                f += h;

                g = d[m]; /*  Rational QL transformation.*/
                if(g==0.0) g = b;

                h         = g;
                s         = 0.0;
                int mml   = m - l;

                for(int ii=1; ii<=mml; ii++ )
                {
                    int i   = m - ii;
                    p       = g * h;
                    r       = p + e2[i];
                    e2[i+1] = s * r;
                    s       = e2[i] / r;
                    d[i+1]  = h + s * ( h + d[i] );
                    g       = d[i] - e2[i] / g;
                    if(g == 0.0) g = b;
                    h       = g * p / r;
                }
                e2[l] = s * g;
                d[l]  = h;
                if(h == 0.0 ) break; /*  Guard against underflow in convergence test. */

                if(r8_abs ( e2[l] ) <= r8_abs ( c / h ) ) break;

                e2[l] = h * e2[l];

                if(e2[l] == 0.0) break;
            }
        }
        double p = d[l] + f;

        for(int i=l; 0<=i; i--) /*  Order the eigenvalues. */
        {
            if(i == 0)
            {
                d[i] = p;
                break;
            }
            else if(d[i-1] > p)
            {
                d[i] = p;
                break;
            }
            d[i] = d[i-1];
        }
    }
    return U_OK;
}
ErrorType UDecompHermitian::tqlrat(int N, double* d, double* e2) const
{
/*
**** for old version, "send otqlrat from eispack"
** From dana!moler Tue, 1 Sep 87 10:15:40 PDT
** New TQLRAT

  
C
      INTEGER I,J,L,M,N,II,L1,MML,IERR
      DOUBLE PRECISION D(N),E2(N)
      DOUBLE PRECISION B,C,F,G,H,P,R,S,T,EPSLON,PYTHAG
C
C     This subroutine is a translation of the Algol procedure tqlrat,
C     Algorithm 464, Comm. ACM 16, 689(1973) by Reinsch.
C
C     This subroutine finds the eigenvalues of a symmetric
C     tridiagonal matrix by the rational QL method.
C
C     On input
C
C        N is the order of the matrix.
C
C        D contains the diagonal elements of the input matrix.
C
C        E2 contains the squares of the subdiagonal elements of the
C          input matrix in its last N-1 positions.  E2(1) is arbitrary.
C
C      On output
C
C        D contains the eigenvalues in ascending order.  If an
C          error exit is made, the eigenvalues are correct and
C          ordered for indices 1,2,...IERR-1, but may not be
C          the smallest eigenvalues.
C
C        E2 has been destroyed.
C
C        IERR is set to
C          zero       for normal return,
C          J          if the J-th eigenvalue has not been
C                     determined after 30 iterations.
C
C     Calls PYTHAG for  DSQRT(A*A + B*B) .
C
C     Questions and comments should be directed to Burton S. Garbow,
C     Mathematics and Computer Science Div, Argonne National Laboratory
C
C     This version dated August 1987.
C     Modified by C. Moler to fix underflow/overflow difficulties,
C     especially on the VAX and other machines where epslon(1.0d0)**2
C     nearly underflows.  See the loop involving statement 102 and
C     the two statements just before statement 200.
C
C     ------------------------------------------------------------------
C
*/
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tqlrat(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(N==1) return U_OK;

    if(d==NULL || e2==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tqlrat(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }

    for(int i=1; i<N; i++) e2[i-1] = e2[i];
    
    double  b = 0.;
    double  c = 0.;
    double  f = 0.;
    double  t = 0.;
    e2[N-1]   = 0.;

    for(int l=0; l<N; l++)
    {
        double h = fabs(d[l]) + sqrt(fabs(e2[l]));
        if(t<=h)
        {
            t = h;
            b = EPSILON*fabs(t);
            c = b*b;
            if(c==0.0) //        Spliting tolerance underflowed.  Look for larger value.
            {
                for(int i=l;i<N;i++)
                {
                    h = fabs(d[i]) + sqrt(fabs(e2[i]));
                    if(h>t) t=h;
                }
                b = EPSILON*fabs(t);
                c = b*b;
            }
        }
//     .......... LOOK FOR SMALL SQUARED SUB-DIAGONAL ELEMENT ..........

//     .......... E2(N) IS ALWAYS ZERO, SO THERE IS NO EXIT
//                THROUGH THE BOTTOM OF THE LOOP ..........
        int m = l;    
        for(m=l; m<N; m++) if(e2[m]<=c) break;

        int iter = 0;

        if(m!=l)
        {
            while(1)
            {
                iter++;
                if(iter>=MAXITER)
                {
                    CI.AddToLog("ERROR: UDecompHermitian::tqlrat(). Maximum number of iterations exceeded (iter=%d). \n", iter);
                    return U_ERROR;
                }

//     .......... FORM SHIFT ..........
         
                int    l1 = l + 1;
                double s  = sqrt(fabs(e2[l]));
                double g  =  d[l ];
                double p  = (d[l1] - g) / (2.0 * s);
                double r  = PYTHAG(p,1.0);
                d[l]      = s / (p + DSIGN(r,p));
                h         = g - d[l];

                for(int i=l1; i<N; i++) d[i]-=h;
                f += h;

//     .......... RATIONAL QL TRANSFORMATION ..........
                g = d[m];
                if(g==0.) g = b;
                h = g;
                s = 0.;
            
                for(int i=m-1; i>=l; i--)
                {
                    p       = g * h;
                    r       = p + e2[i];
                    e2[i+1] = s * r;
                    s       = e2[i] / r;
                    d[i+1]  = h + s * (h + d[i]);
                    g       = d[i] - e2[i] / g;
//           Avoid division by zero on next pass
                    if(g==0.0) 
                        g   = EPSILON*fabs(d[i]);
                    h       =  g * (p / r);
                }
            
                e2[l] = s*g;
                d [l] = h;
//     .......... GUARD AGAINST UNDERFLOW IN CONVERGENCE TEST ..........
                if(h==0 || fabs(e2[l])<=fabs(c/h)) break;

                e2[l] *= h;
                if(e2[l]==0.) break;            
            }
        }
        double p = d[l] + f;
//     .......... ORDER EIGENVALUES ..........
    
        int i=0;
        if(l!=0)
        {
            for(  i=l; i>=1;i--) 
            {
                if(p<=d[i-1]) break;
                d[i] = d[i-1];
            }
        }
        d[i] = p;
    }
    return U_OK;
}

void UDecompHermitian::SetEPSILON(void)
{
/*
      double precision x
c
c     estimate unit roundoff in quantities of size x.
c
      double precision a,b,c,eps
c
c     this program should function properly on all systems
c     satisfying the following two assumptions,
c        1.  the base used in representing floating point
c            numbers is not a power of three.
c        2.  the quantity  a  in statement 10 is represented to 
c            the accuracy used in floating point variables
c            that are stored in memory.
c     the statement number 10 and the go to 10 are intended to
c     force optimizing compilers to generate code satisfying 
c     assumption 2.
c     under these assumptions, it should be true that,
c            a  is not exactly equal to four-thirds,
c            b  has a zero for its last bit or digit,
c            c  is not exactly equal to one,
c            eps  measures the separation of 1.0 from
c                 the next larger floating point number.
c     the developers of eispack would appreciate being informed
c     about any systems where these assumptions do not hold.
c
c     this version dated 4/6/83.
c
*/
    double eps = 0;
    double a   = 4.0/3.0;
    while(1)               /// 10
    {
        double b = a - 1.0;
        double c = b + b + b;
        eps      = fabs(c-1.0);
        if(eps  != 0.) break;
        eps      = 2.2204460492503e-016;
        break;
    }
    EPSILON = eps;
}

double UDecompHermitian::DSIGN(double a, double b) const
{
    if(b>=0.) return fabs(a);
    return          -fabs(a);
}
ErrorType UDecompHermitian::tql2R(int N, double* d, double*e, double* z) const
/*
    tql2R() computes all eigenvalues/vectors, real symmetric tridiagonal matrix.

    Input, int N, the order of the matrix.

    Input/output, double d[N].  On input, the diagonal elements of
    the matrix.  On output, the eigenvalues in ascending order. 

    Input/output, double e[N].  On input, E(2:N) contains the
    subdiagonal elements of the input matrix, and E(1) is arbitrary.
    On output, E has been destroyed.

    Input, double z[N*N].  On input, the transformation matrix
    produced in the reduction by tred2, if performed.  If the eigenvectors of
    the tridiagonal matrix are desired, Z must contain the identity matrix.
    On output, Z contains the orthonormal eigenvectors of the symmetric
    tridiagonal (or full) matrix.  If an error exit is made, Z contains
    the eigenvectors associated with the stored eigenvalues.

    Output, int TQL2, error flag.
    0, normal return,
    J, if the J-th eigenvalue has not been determined after
    MAXITER iterations.
*/
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tql2R(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(N==1) return U_OK;

    if(d==NULL || e==NULL || z==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tql2R(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }

    for(int i=1; i<N; i++) e[i-1] = e[i];

    double f    = 0.0;
    double tst1 = 0.0;
    e[N-1]      = 0.0;

    for(int l=0; l <N; l++)
    {
        int    iter = 0;
        double h    = r8_abs( d[l] ) + r8_abs ( e[l] );
        tst1        = r8_max( tst1, h );

/*  Look for a small sub-diagonal element. */
        int m=l;
        for(   ; m<N; m++)
        {
            double tst2 = tst1 + r8_abs ( e[m] );
            if(tst2==tst1) break;
        }

        if(m != l)
        {
            while(1)
            {
                iter++;
                if(iter>=MAXITER)
                {
                    CI.AddToLog("ERROR: UDecompHermitian::tql2R(). Maximum number of iterations exceeded (iter=%d). \n", iter);
                    return U_ERROR;
                }
                int    l1  = l + 1; /*  Form shift.*/
                int    l2  = l1 + 1;
                double g   = d[l];
                double p   = ( d[l1] - g ) / ( 2.0 * e[l] );
                double r   = PYTHAG( p, 1.0 );
                d[l]       = e[l] / ( p + r8_sign ( p ) * r8_abs ( r ) );
                d[l1]      = e[l] * ( p + r8_sign ( p ) * r8_abs ( r ) );
                double dl1 = d[l1];
                double h   = g - d[l];
                for(int i = l2; i <N; i++) d[i] -= h;
                f += h;
                
                p          = d[m]; /*  QL transformation.*/
                double c   = 1.0;
                double c2  = c;
                double el1 = e[l1];
                double s   = 0.0;
                int    mml = m - l;

                double c3  = 0.;
                double s2  = 0.;
                for(int ii=1; ii<=mml; ii++ )
                {
                    c3        = c2;
                    c2        = c;
                    s2        = s;
                    int    i  = m - ii;
                    g         = c * e[i];
                    h         = c * p;
                    r         = PYTHAG(p, e[i]);
                    e[i+1]    = s * r;
                    s         = e[i] / r;
                    c         = p / r;
                    p         = c * d[i] - s * g;
                    d[i+1]    = h + s * (c*g + s*d[i]);

                    for(int k=0; k<N; k++) /*  Form vector. */
                    {
                        h            =     z[k+(i+1)*N];
                        z[k+(i+1)*N] = s * z[k+ i   *N] + c * h;
                        z[k+ i   *N] = c * z[k+ i   *N] - s * h;
                    }
                }
                p    = - s * s2 * c3 * el1 * e[l] / dl1;
                e[l] = s * p;
                d[l] = c * p;
                double tst2 = tst1 + r8_abs ( e[l] );
                if(tst2 <= tst1) break;
            }
        }
        d[l] += f;
    }
/*  Order eigenvalues and eigenvectors. */
    for(int ii=1; ii<N; ii++)
    {
        int    i = ii - 1;
        int    k = i;
        double p = d[i];
        for(int j=ii; j<N; j++)
        {
            if(d[j] >= p)
            {
                k = j;
                p = d[j];
            }
        }
        if(k == i) continue;

        d[k] = d[i];
        d[i] = p;
        for(int j=0; j<N; j++)
        {
            double t = z[j+i*N];
            z[j+i*N] = z[j+k*N];
            z[j+k*N] = t;
        }
    }
    return U_OK;
}

ErrorType UDecompHermitian::tql2(int N, double* d, double*e, double* z) const
{
/*
c
      integer i,j,k,l,m,n,ii,l1,l2,nm,mml,ierr
      double precision d(n),e(n),z(nm,n)
      double precision c,c2,c3,dl1,el1,f,g,h,p,r,s,s2,tst1,tst2,pythag
c
c     this subroutine is a translation of the algol procedure tql2,
c     num. math. 11, 293-306(1968) by bowdler, martin, reinsch, and
c     wilkinson.
c     handbook for auto. comp., vol.ii-linear algebra, 227-240(1971).
c
c     this subroutine finds the eigenvalues and eigenvectors
c     of a symmetric tridiagonal matrix by the ql method.
c     the eigenvectors of a full symmetric matrix can also
c     be found if  tred2  has been used to reduce this
c     full matrix to tridiagonal form.
c
c     on input
c
c        nm must be set to the row dimension of two-dimensional
c          array parameters as declared in the calling program
c          dimension statement.
c
c        n is the order of the matrix.
c
c        d contains the diagonal elements of the input matrix.
c
c        e contains the subdiagonal elements of the input matrix
c          in its last n-1 positions.  e(1) is arbitrary.
c
c        z contains the transformation matrix produced in the
c          reduction by  tred2, if performed.  if the eigenvectors
c          of the tridiagonal matrix are desired, z must contain
c          the identity matrix.
c
c      on output
c
c        d contains the eigenvalues in ascending order.  if an
c          error exit is made, the eigenvalues are correct but
c          unordered for indices 1,2,...,ierr-1.
c
c        e has been destroyed.
c
c        z contains orthonormal eigenvectors of the symmetric
c          tridiagonal (or full) matrix.  if an error exit is made,
c          z contains the eigenvectors associated with the stored
c          eigenvalues.
c
c        ierr is set to
c          zero       for normal return,
c          j          if the j-th eigenvalue has not been
c                     determined after 30 iterations.
c
c     calls pythag for  dsqrt(a*a + b*b) .
c
c     questions and comments should be directed to burton s. garbow,
c     mathematics and computer science div, argonne national laboratory
c
c     this version dated august 1983.
c
c     ------------------------------------------------------------------
c
*/
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tql2(). Invalid N (=%d) \n", N);
        return U_ERROR;
    }
    if(N==1) return U_OK;

    if(d==NULL || e==NULL || z==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::tql2(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }
    for(int i=1; i<N; i++) e[i-1] = e[i];
    e[N-1]   = 0.0;
    
    double f  = 0.0;
    double t1 = 0.0;

    for(int l=0; l<N; l++)
    {
        double    h  = fabs(d[l]) + fabs(e[l]);
        if(t1<=h) t1 = h;
        
        int m=l;
        for(m=l; m<N-1; m++) 
        {
            double t2 = t1 + fabs(e[m]);
            if(t2==t1) break;
        }
        int iter = 0;
        if(m!=l)
        {
            while(1)
            {
                iter++;
                if(iter>=MAXITER)
                {
                    CI.AddToLog("ERROR: UDecompHermitian::tql2(). Maximum number of iterations exceeded (iter=%d). \n", iter);
                    return U_ERROR;
                }
                int    l1  = l+1;
                int    l2  = l+2;
 
                double g   =  d[l ];
                double p   = (d[l1] - g) / (2.0 * e[l]);

                double r   = PYTHAG(p, 1.0);
                d[l ]      = e[l] / (p + DSIGN(r,p));
                d[l1]      = e[l] * (p + DSIGN(r,p));
                double dl1 = d[l1];
                double h   = g - d[l];
                f         += h;

                for(int i=l2; i<N; i++) d[i] -= h;

//     .......... ql transformation ..........
                p          = d[m];
                double c   = 1.;
                double c2  = 1.;
                double c3  = c2;
                double el1 = e[l1];
                double s   = 0.0;
                double s2  = s;

                for(int i=m-1; i>=l; i--)
                {
                    c3        = c2;
                    c2        = c;
                    s2        = s;
                    g         = c * e[i];
                    h         = c * p;
                    r         = PYTHAG(p,e[i]);
                    e[i+1]    = s * r;
                    s         = e[i] / r;
                    c         = p    / r;
                    p         = c * d[i] - s * g;
                    d[i+1]    = h + s * (c * g + s * d[i]);
//     .......... form vector ..........
                    for(int k=0; k<N; k++)
                    {
                        h          = z[k*N+i+1];
                        z[k*N+i+1] = s * z[k*N+i] + c * h;
                        z[k*N+i  ] = c * z[k*N+i] - s * h;
                    }
                }
                p         = -s * s2 * c3 * el1 * e[l] / dl1;
                e[l]      =  s * p;
                d[l]      =  c * p;
                double t2 = t1 + fabs(e[l]);
                if (t2<=t1) break;
            }
        }
        d[l] += f;
    }
//     .......... order eigenvalues and eigenvectors ..........

    for(int i=0; i<N; i++)
    {
        int    k = i;
        double p = d[i];

        for(int j=i+1; j<N; j++)
        {
            if(d[j]<=p) continue;
            k = j;
            p = d[j];
        }

        if(k==i) continue;

        for(int j=0; j<N; j++)
        {
            p        = z[j*N+i];
            z[j*N+i] = z[j*N+k];
            z[j*N+k] = p;
        }
        p    = d[i];
        d[i] = d[k];
        d[k] = p;
    }
    return U_OK;
}

ErrorType UDecompHermitian::htribk(int N, double* ar, double* ai, double* tau, int Nback, double* zr, double* zi) const 
/*
c
      integer i,j,k,l,m,n,nm
      double precision ar(nm,n),ai(nm,n),tau(2,n),zr(nm,m),zi(nm,m)
      double precision h,s,si
c
c     this subroutine is a translation of a complex analogue of
c     the algol procedure trbak1, num. math. 11, 181-195(1968)
c     by martin, reinsch, and wilkinson.
c     handbook for auto. comp., vol.ii-linear algebra, 212-226(1971).
c
c     this subroutine forms the eigenvectors of a complex hermitian
c     matrix by back transforming those of the corresponding
c     real symmetric tridiagonal matrix determined by  htridi.
c
c     on input
c
c        nm must be set to the row dimension of two-dimensional
c          array parameters as declared in the calling program
c          dimension statement.
c
c        n is the order of the matrix.
c
c        ar and ai contain information about the unitary trans-
c          formations used in the reduction by  htridi  in their
c          full lower triangles except for the diagonal of ar.
c
c        tau contains further information about the transformations.
c
c        m is the number of eigenvectors to be back transformed.
c
c        zr contains the eigenvectors to be back transformed
c          in its first m columns.
c
c     on output
c
c        zr and zi contain the real and imaginary parts,
c          respectively, of the transformed eigenvectors
c          in their first m columns.
c
c     note that the last component of each returned vector
c     is real and that vector euclidean norms are preserved.
c
c     questions and comments should be directed to burton s. garbow,
c     mathematics and computer science div, argonne national laboratory
c
c     this version dated august 1983.
c
c     ------------------------------------------------------------------
*/
{
    if(N<=0 || Nback<0 || Nback>N)
    {
        CI.AddToLog("ERROR: UDecompHermitian::htribk(). Invalid N (=%d) or Nback (=%d)\n", N, Nback);
        return U_ERROR;
    }
    if(Nback==0) return U_OK;

    if(ar==NULL || ai==NULL || tau==NULL || zr==NULL || zi==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::htribk(). Invalid NULL argument for help array. \n");
        return U_ERROR;
    }

//     .......... transform the eigenvectors of the real symmetric
//                tridiagonal matrix to those of the hermitian
//                tridiagonal matrix. ..........

    for(int k=0; k<N; k++)
        for(int j=0; j<Nback; j++)
        {
            zi[k*N+j] = -zr[k*N+j] * tau[N+k];
            zr[k*N+j] =  zr[k*N+j] * tau[  k];
        }

    if(N==1) return U_OK;

//     .......... recover and apply the householder matrices ..........

    for(int i=1; i<N; i++)
    {
        int    l = i-1;
        double h = ai[i*N+i];

        if(h==0.) continue;

        for(int j=0; j<Nback; j++)
        {
            double s  = 0.;
            double si = 0.;

            for(int k=0; k<=l; k++)
            {
               s  += ar[i*N+k] * zr[k*N+j] - ai[i*N+k] * zi[k*N+j];
               si += ar[i*N+k] * zi[k*N+j] + ai[i*N+k] * zr[k*N+j];
            }
//     .......... double divisions avoid possible underflow ..........
            s  = (s  / h) / h;
            si = (si / h) / h;
            for(int k=0; k<=l; k++)
            {
               zr[k*N+j] += - s  * ar[i*N+k] - si * ai[i*N+k];
               zi[k*N+j] += - si * ar[i*N+k] + s  * ai[i*N+k];
            }
        }
    }
    return U_OK;
}

ErrorType UDecompHermitian::tred1(int N, double* a, double* d, double* e, double* e2) const
/*
    TRED1 transforms a real symmetric matrix to symmetric tridiagonal form.
    Input, int N, the order of the matrix a.

    Input/output, double a[N*N], on input, contains the real
    symmetric matrix.  Only the lower triangle of the matrix need be supplied.
    On output, a contains information about the orthogonal transformations
    used in the reduction in its strict lower triangle.
    The full upper triangle of a is unaltered.

    Output, double d[N], contains the diagonal elements of the
    tridiagonal matrix.

    Output, double e[N], contains the subdiagonal elements of the
    tridiagonal matrix in its last N-1 positions.  E(1) is set to zero.

    Output, double e2[N], contains the squares of the corresponding
    elements of E. e2 may coincide with E if the squares are not needed.
*/
{
    if(N<=0)                                      return U_ERROR;
    if(a==NULL || d==NULL || e==NULL || e2==NULL) return U_ERROR;


    for(int j=0; j<N; j++) d[j]       = a[N-1+j*N];
    for(int i=0; i<N; i++) a[N-1+i*N] = a[i  +i*N];

    for(int i=N-1; 0<= i; i-- )
    {
        int    l     = i - 1;
        double h     = 0.0;
        double scale = 0.0;
        for(int k=0; k<= l; k++ )
            scale += r8_abs(d[k]);

        if(scale == 0.0 )
        {
            for(int j=0; j<=l; j++ )
            {
                d[j]     = a[l+j*N];
                a[l+j*N] = a[i+j*N];
                a[i+j*N] = 0.0;
            }
            e[i] = 0.0;
            e2[i] = 0.0;
            continue;
        }

        for(int k=0; k<= l; k++) d[k] /= scale;
        for(int k=0; k<= l; k++) h    += d[k] * d[k];

        e2[i]    = h * scale * scale;
        double f = d[l];
        double g = - sqrt ( h ) * r8_sign(f);
        e[i]     = scale * g;
        h        = h - f * g;
        d[l]     = f - g;

        if(0 <= l ) /* Form A * U */
        {
            for(int k=0; k <= l; k++) e[k] = 0.0;

            for(int j = 0; j <= l; j++ )
            {
                double f = d[j];
                double g = e[j] + a[j+j*N] * f;

                for(int k = j + 1; k <= l; k++ )
                {
                    g    +=  a[k+j*N] * d[k];
                    e[k] +=  a[k+j*N] * f;
                }
                e[j] = g;
            }

            f = 0.0; /* Form P*/
            for(int j = 0; j <= l; j++ )
            {
                e[j]  = e[j] / h;
                f    += e[j] * d[j];
            }
            h = f / ( h + h );

            for(int j=0; j<=l; j++) e[j] -=  h * d[j];  /* Form Q*/

/*  Form reduced A.*/
            for(int j=0; j<=l; j++)
            {
                f = d[j];
                g = e[j];
                for(int k=j; k<=l; k++) a[k+j*N] -= (f * e[k] + g * d[k]);
            }
        }

        for(int j=0; j <= l; j++ )
        {
            f        = d[j];
            d[j]     = a[l+j*N];
            a[l+j*N] = a[i+j*N];
            a[i+j*N] = f * scale;
        }
    }
    return U_OK;
}
ErrorType UDecompHermitian::tred2(int N, double* a, double* d, double* e, double* z) const
/*
    TRED2 transforms a real symmetric matrix to symmetric tridiagonal form.

    a and z may coincide, in which case a single storage area is used
    for the input of a and the output of Z.

    Input, int N, the order of the matrix.

    Input, double a[N*N], the real symmetric input matrix.  Only the
    lower triangle of the matrix need be supplied.

    Output, double d[N], the diagonal elements of the tridiagonal
    matrix.

    Output, double e[N], contains the subdiagonal elements of the
    tridiagonal matrix in e(2:N).  e(1) is set to zero.

    Output, double z[N*N], the orthogonal transformation matrix
    produced in the reduction.
*/
{
    if(N<=0)                                     return U_ERROR;
    if(a==NULL || d==NULL || e==NULL || z==NULL) return U_ERROR;

    for(int j=0; j<N; j++)
        for(int i=j; i<N; i++)
            z[i+j*N] = a[i+j*N];

    for(int j=0; j<N; j++) d[j] = a[N-1+j*N];

    for(int i=N-1; 1<= i; i-- )
    {
        int    l     = i-1;
        double h     = 0.0;
        double scale = 0.0; /* Scale row */
        for(int k=0; k<=l; k++) scale += r8_abs( d[k] );

        if(scale == 0.0)
        {
            e[i] = d[l];

            for(int j=0; j<= l; j++)
            {
                d[j]     = z[l+j*N];
                z[i+j*N] = 0.0;
                z[j+i*N] = 0.0;
            }
            d[i] = 0.0;
            continue;
        }

        for(int k=0; k<=l; k++) d[k] /= scale;

        h = 0.0;
        for(int k=0; k<=l; k++) h    += d[k] * d[k];

        double f = d[l];
        double g = - sqrt ( h ) * r8_sign ( f );
        e[i]     = scale * g;
        h       -= f * g;
        d[l]     = f - g;

        for(int k=0; k<= l; k++) e[k] = 0.0;/*  Form A*U.*/

        for(int j=0; j<= l; j++)
        {
            f        = d[j];
            z[j+i*N] = f;
            g        = e[j] + z[j+j*N] * f;

            for(int k=j+1; k<=l; k++)
            {
                g    += z[k+j*N] * d[k];
                e[k] += z[k+j*N] * f;
            }
            e[j] = g;
        }

        for(int k=0; k<=l; k++) e[k] /= h; /*  Form P. */

        f = 0.0;
        for(int k=0; k<=l; k++ ) f    += e[k] * d[k];
        double hh = 0.5 * f / h;
        for(int k=0; k<=l; k++ ) e[k] -= hh * d[k];/*  Form Q.*/
    
        for(int j=0; j<=l; j++) /*  Form reduced A.*/
        {
            f = d[j];
            g = e[j];

            for(int k=j; k<=l; k++) z[k+j*N] -= (f*e[k] + g*d[k]);

            d[j]     = z[l+j*N];
            z[i+j*N] = 0.0;
        }
        d[i] = h;
    }

/*  Accumulation of transformation matrices. */
    for(int i=1; i<N; i++)
    {
        int l      = i - 1;
        z[N-1+l*N] = z[l+l*N];
        z[l+  l*N] = 1.0;
        double h   = d[i];

        if(h!= 0.0)
        {
            for(int k=0; k<=l; k++) d[k] = z[k+i*N] / h;

            for(int j=0; j<=l; j++)
            {
                double g = 0.0;
                for(int k=0; k<=l; k++) g        += z[k+i*N] * z[k+j*N];
                for(int k=0; k<=l; k++) z[k+j*N] -= g * d[k];
            }
        }
        for(int k=0; k<=l; k++) z[k+i*N] = 0.0;
    }

    for(int j=0; j<N  ; j++) d[j]       = z[N-1+j*N];
    for(int j=0; j<N-1; j++) z[N-1+j*N] = 0.0;
    z[N-1+(N-1)*N] = 1.0;
    e[0] = 0.0;

    return U_OK;
}

double UDecompHermitian::r8_abs(double x) const
{
    double value = 0.;
    if( 0.0 <= x) value = + x;
    else          value = - x;
    return value;
}
double UDecompHermitian::r8_sign(double x) const
{
    double value = 0.;
    if( x < 0.0 ) value = - 1.0;
    else          value = + 1.0;
    return value;
}
double UDecompHermitian::r8_max(double x, double y) const
{
    double value = 0;
    if( y < x ) value = x;
    else        value = y;
    return value;
}
double UDecompHermitian::r8_min(double x, double y) const
{
    double value = 0;
    if( y > x ) value = x;
    else        value = y;
    return value;
}
double UDecompHermitian::r8_epsilon(void) const
{
    static double value = 2.220446049250313E-016;
    return value;
}
double UDecompHermitian::r8_pythag(double a, double b) const
{
    double p = r8_max( r8_abs(a), r8_abs(b) );

    if(p != 0.0)
    {
        double r = r8_min( r8_abs(a), r8_abs(b) ) / p;
        r = r * r;

        while(1)
        {
            double t = 4.0 + r;
            if(t == 4.0) break;

            double s = r / t;
            double u = 1.0 + 2.0 * s;
            p        = u * p;
            r        = ( s / u ) * ( s / u ) * r;
        }
    }
    return p;
}

ErrorType UDecompHermitian::MatMul(double*ab, const double* a, int NrowA, int NcolA, bool TranspA, const double* b, int NrowB, int NcolB, bool TranspB)
{
    if(NrowA<=0 || NcolA<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Invalid NrowA=%d or NcolA=%d .\n", NrowA, NcolA);
        return U_ERROR;         
    }
    if(NrowB<=0 || NcolB<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Invalid NrowB=%d or NcolB=%d .\n", NrowB, NcolB);
        return U_ERROR;         
    }
    if(ab==NULL || a==NULL || b==NULL)   
    {                        
        CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Invalid NULL pointer argument(s) .\n");
        return U_ERROR;         
    }

    if(TranspA)
    {
        if(TranspB)
        {
            if(NrowA != NcolB)
            {
                CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Incompatible NrowA=%d and NcolB=%d .\n", NrowA, NcolB);
                return U_ERROR;
            }
            for(int i=0; i<NcolA; i++)
            {
                for(int j=0; j<NrowB; j++)
                {
                    double        prod  = 0;
                    const double *pA    = a +i;
                    const double *pB    = b +j*NcolB;

                    for(int k=0; k<NrowA; k++,pA+=NcolA) prod += *pA * *pB++;
                    ab[i*NrowB+j] = prod;
                }
            }
        }
        else // NOT(TranspB)
        {
            if(NrowA != NrowB)
            {
                CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Incompatible NrowA=%d and NrowB=%d .\n", NrowA, NrowB);
                return U_ERROR;
            }
            for(int i=0; i<NcolA; i++)
            {
                for(int j=0; j<NcolB; j++)
                {
                    double        prod = 0;
                    const double* pA   = a+i;
                    const double* pB   = b+j;

                    for(int k=0; k<NrowA; k++, pA+=NcolA, pB+=NcolB) prod += *pA * *pB;
                    ab[i*NcolB+j] = prod;
                }
            }
        }
    }
    else // NOT(TranspA)
    {
        if(TranspB)
        {
            if(NcolA != NcolB)
            {
                CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Incompatible NcolA=%d and NcolB=%d .\n", NcolA, NcolB);
                return U_ERROR;
            }
            for(int i=0; i<NrowA; i++)
            {
                for(int j=0; j<NrowB; j++)
                {
                    double        prod =     0;
                    const double *pA   = a+i*NcolA;
                    const double *pB   = b+j*NcolB;

                    for(int k=0; k<NcolA; k++) prod += *pA++ * *pB++;
                    ab[i*NrowB+j] = prod;
                }
            }
        }
        else  // NOT(TranspB)
        {
            if(NcolA != NrowB)
            {
                CI.AddToLog("ERROR: UDecompHermitian::MatMul(). Incompatible NcolA=%d and NrowB=%d .\n", NcolA, NrowB);
                return U_ERROR;
            }
            for(int i=0; i<NrowA; i++)
            {
                for(int j=0; j<NcolB; j++)
                {
                    double        prod  = 0;
                    const double *pA    = a +i*NcolA;
                    const double *pB    = b +j;

                    for(int k=0; k<NcolA; k++,pB+=NcolB) prod += *pA++ * *pB;
                    ab[i*NcolB+j] = prod;
                }
            }
        }
    }
    return U_OK;
}

double* UDecompHermitian::GetMatMul(const double* a, int NrowA, int NcolA, bool TranspA, const double* b, int NrowB, int NcolB, bool TranspB)
{
    if(a==NULL || b==NULL)   
    {                        
        CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Invalid NULL pointer argument(s) .\n");
        return NULL;         
    }
    int Nelem = 0;
    if(TranspA && TranspB)
    {
        if(NrowA != NcolB)
        {
            CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Incompatible NrowA=%d and NcolB=%d .\n", NrowA, NcolB);
            return NULL;
        }
        Nelem = NcolA*NrowB;
    }
    if(TranspA && NOT(TranspB))
    {
        if(NrowA != NrowB)
        {
            CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Incompatible NrowA=%d and NrowB=%d .\n", NrowA, NrowB);
            return NULL;
        }
        Nelem = NcolA*NcolB;
    }
    if(NOT(TranspA) && TranspB)
    {
        if(NcolA != NcolB)
        {
            CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Incompatible NcolA=%d and NcolB=%d .\n", NcolA, NcolB);
            return NULL;
        }
        Nelem = NrowA*NrowB;
    }
    if(NOT(TranspA) && NOT(TranspB))
    {
        if(NcolA != NrowB)
        {
            CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Incompatible NcolA=%d and NrowB=%d .\n", NcolA, NrowB);
            return NULL;
        }
        Nelem = NrowA*NcolB;
    }

    double* prod = (Nelem>0) ? (new double[Nelem]) : NULL;
    if(prod==NULL)
    {
        CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Memory allocation, Nelem (=%d) .\n", Nelem);
        return NULL;         
    }
    for(int ij=0; ij<Nelem; ij++) prod[ij] = 0.;

    if(MatMul(prod, a, NrowA, NcolA, TranspA, b, NrowB, NcolB, TranspB)!=U_OK)
    {
        delete[] prod;
        CI.AddToLog("ERROR: UDecompHermitian::GetMatMul(). Computing matrix product .\n");
        return NULL;
    }
    return prod;
}                            
ErrorType UDecompHermitian:: PreMultDiag(int N, const double* lamda, double* a)
{                            
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::PreMultDiag(). Invalid N (=%d) .\n", N);
        return U_ERROR;
    }
    if(lamda==NULL || a==NULL)   
    {                        
        CI.AddToLog("ERROR: UDecompHermitian::PreMultDiag(). Invalid NULL pointer argument(s) .\n");
        return U_ERROR;
    }
    
    double*       pA = a;
    const double* pL = lamda;
    for(int i=0; i<N; i++, pL++)
    {
        for(int j=0; j<N; j++, pA++) *pA *= *pL;
    }
    return U_OK;
}                            
ErrorType UDecompHermitian:: PostMultDiag(int N, const double* lamda, double* a)
{
    if(N<=0)
    {
        CI.AddToLog("ERROR: UDecompHermitian::PostMultDiag(). Invalid N (=%d) .\n", N);
        return U_ERROR;
    }
    if(lamda==NULL || a==NULL)   
    {                        
        CI.AddToLog("ERROR: UDecompHermitian::PostMultDiag(). Invalid NULL pointer argument(s) .\n");
        return U_ERROR;
    }
    
    double* pA = a;
    for(int i=0; i<N; i++)
    {
        const double* pL = lamda;
        for(int j=0; j<N; j++, pA++, pL++) *pA *= *pL;
    }
    return U_OK;
}
 