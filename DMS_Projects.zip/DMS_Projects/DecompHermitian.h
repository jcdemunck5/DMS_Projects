#ifndef _DECOMPHERMITIAN_INCLUDED  // Prevent including this include-file twice.
#define _DECOMPHERMITIAN_INCLUDED
#include "BasicInclude.h"

class DLL_IO UDecompHermitian
{
public:
    UDecompHermitian();
    ErrorType         SetMaxIter(int MaxIter);

    bool              IsHermitian(int N, const double* ar, const double* ai, bool AddToLog) const;
    bool              IsSymmetric(int N, const double* a, bool AddToLog) const;
    ErrorType         ForceSymmetric(int N, double* a, double Tol) const;

    ErrorType         Decompose(int N, double* ar, double* ai, bool CompEigenVector, double* w, double* zr, double* zi) const;
    ErrorType         Decompose(int N, double* a, bool matz, double* w, double* z) const;
    ErrorType         JointDiagonalize(int N, const double* a, const double* b, double* lambdaa, double* z, bool InvertZ=false) const;
    double*           GetSumKPXisB(const double* a1, const double* a2, int NA, const double* b1, const double* b2, int NB, const double* bvec) const;

    double*           GetEigenValues(int N, double* ar, double* ai) const;
    double*           GetEigenValues(int N, double* a) const;

protected:
    void              SetAllMembersDefault(void);
    void              DeleteAllMembers(ErrorType E);

public:
    static double*    GetMatMul(const double* a, int NrowA, int NcolA, bool TranspA, const double* b, int NrowB, int NcolB, bool TranspB);
    static ErrorType  MatMul(double*ab, const double* a, int NrowA, int NcolA, bool TranspA, const double* b, int NrowB, int NcolB, bool TranspB);
    static ErrorType  PreMultDiag(int N, const double* lamda, double* a);
    static ErrorType  PostMultDiag(int N, const double* lamda, double* a);

private:
    double            EPSILON;
    int               MAXITER;

    void              SetEPSILON();
    double            DSIGN(double a, double b) const;
    double            r8_abs(double x) const;
    double            r8_sign(double x) const;
    double            r8_max(double x, double y) const;
    double            r8_min(double x, double y) const;
    double            r8_epsilon(void) const;
    double            r8_pythag(double a, double b) const;

    ErrorType         htridi (int N, double* ar, double* ai, double* d, double* e, double* e2, double* tau) const;
    ErrorType         tqlrat (int N, double* d, double* e2) const;
    ErrorType         tqlratR(int N, double* d, double* e2) const;
    ErrorType         tql2   (int N, double* d, double*e, double* z) const;
    ErrorType         tql2R  (int N, double* d, double*e, double* z) const;
    ErrorType         htribk (int N, double* ar, double* ai, double* tau, int Nback, double* zr, double* zi) const;

    ErrorType         tred1(int N, double* a, double* d, double* e, double* e2) const;
    ErrorType         tred2(int N, double* a, double* d, double* e, double* z) const;
};
#endif //_DECOMPHERMITIAN_INCLUDED
