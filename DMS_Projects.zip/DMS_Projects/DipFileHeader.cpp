/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    13-09-01   creation, splitted off from DipoleMoveList.cpp
                    Added date, nMEG and nEEG and operator=()
JdM/SG   09-11-01   Bug Fix: GetEvent(). Round off errors, use floor()
  JdM    14-12-01   Added GetSpherePos()
  JdM    22-01-02   Use UDateTime() object to determine date and time of recording
  JdM    15-04-02   Added GetGroup(), a function to retrieve an optional integer
                    value accompanying a dipole
  JdM    22-05-02   Launch message in UDipFileHeader::UDipFileHeader() when group info is not present
  JdM    10-07-02   GetGroup(): Allow doubles instead of integers
  JdM    31-10-02   Added DecreaseNdip()
  JdM    02-12-02   Added Copy constructor
  JdM    15-12-02   Added SetAllMembersDefault and added tests for NULL adress arguments
  JdM    10-02-03   Added MR coordinates of nasion, left and right ear plus MRtoWld
  JdM    16-02-03   bug fix DecreaseNdip(). Allow Ndip==0 after decrease
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-01-05   Remove UAnalyzeLineExt data member (use as argument of various functions)
  JdM    04-01-05   Added WriteHeader() and WriteDipole()
  JdM    07-11-05   FILE* constructor, UDipFileHeader(). Skip empty lines.
  JdM    10-04-09   Bug fixes UDipFileHeader(): compilor errors on MSVC2008 (const char*)
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    02-08-13   Added TimeInfo type to choose between absolute or relative time
  JdM    28-01-14   BUG FIX: WriteHeader(), WriteDipole(). Test for relative time (introduced 02-08-13) was falsely skipped
*/

#include <stdlib.h>
#include <string.h>

#include "DipFileHeader.h"
#include "AnalyzeLineExt.h"
#include "MEEGDataBase.h"
#include "Epochs.h"
#include "HeadModel.h"

#define  TITLE_GROUP  "group"
#define  TITLE_GROUP0 "group0"


/* Local defines */
#define MAXLINE       10000
#define MAXDIPLINE    400

void UDipFileHeader::SetAllMembersDefault(void)
{
    error          = U_OK;
    DatTim         = UDateTime();
    sprintf(subject_id,"UNKNOWN Subject");
    sprintf(DataSetName,"UNKNOWN.ds");
    srate          = 0;
    Stime          = 0.;
    prestim        = 0;
    nsamp          = 0;
    ntrial         = 0;
    nMEG           = 0;
    nEEG           = 0;
    Tinf           = U_TIME_UNKNOWN;
    NsimulDip      = 0;
    Ndip           = 0;
    SampleCol      = 0;
    MEGDatPowCol   = 0;
    ResErrorCol    = 0;

    NasionMEG      = UVector3();
    LeftMEG        = UVector3();
    RightMEG       = UVector3();
    SpherePos      = UVector3();
    NasionMR       = UVector3();
    LeftMR         = UVector3();
    RightMR        = UVector3();
    MRtoWld        = UEuler();

    IdipOffSet     = NULL;
    DeltaOffSet    = NULL;
    GroupOffSet    = NULL;

    VersionNumber  = 0.;
    StringDat      = UString();
    StringEpo      = UString();
    StringHM       = UString();
}

void UDipFileHeader::DeleteAllMembers(void)
{
    delete[] IdipOffSet;
    delete[] DeltaOffSet;
    delete[] GroupOffSet;
    SetAllMembersDefault();
}

UDipFileHeader::UDipFileHeader(UFileName Fname)
{
    SetAllMembersDefault();

    FILE* fp = fopen(Fname, "rt", false);
    *this = UDipFileHeader(fp);
    fclose(fp);
}

UDipFileHeader::UDipFileHeader(const UDipFileHeader& D)
{
    SetAllMembersDefault();
    if(&D==NULL)
    {
        CI.AddToLog("ERROR: UDipFileHeader::UDipFileHeader(). NULL address argument. \n");
        return;
    }
    *this = D;
}

UDipFileHeader::UDipFileHeader(const UMEEGDataBase* Data, const UHeadModel* HM, const UEpochs* Epo, bool TimeInSamp, bool UseAbsTime, UDipole::DipoleType DipType, bool ConfInt)
{
    SetAllMembersDefault();

    if(Data==NULL || Data->GetError()!=U_OK ||
       HM  ==NULL || HM  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipFileHeader::UDipFileHeader(). NULL or Erroneous UMEEGDataBase or UHeadModel argument(s) .\n");
        error = U_ERROR;
        return;
    }
    StringDat      =         Data->GetProperties("//   ");
    StringHM       = UString(  HM->GetProperties("//   "));
    if(Epo && Epo->GetError()==U_OK)
        StringEpo  = UString(Epo->GetProperties("//   "));

    strncpy(subject_id ,             Data->GetPatName()     , sizeof(subject_id));
    strncpy(DataSetName,(const char*)Data->GetDataFileName(),sizeof(DataSetName));
    DatTim         = Data->GetDateTime();

    srate          =       Data->GetSampleRate();
    Stime          = 1000.*Data->GetSampleTime_s();
    prestim        =       Data->GetPreTriggerTime_s();
    nsamp          =       Data->GetNsampTrial();
    ntrial         =       Data->GetNtrial();
    nMEG           =       Data->GetNkan(U_DAT_MEG);
    nEEG           =       Data->GetNkan(U_DAT_EEG);
    if(UseAbsTime)
    {
        if(TimeInSamp==true) Tinf = U_TIME_INSAMPLES;
        else                 Tinf = U_TIME_INMS;
    }
    else
    {
        if(TimeInSamp==true) Tinf = U_TIME_INSAMPLES_REL;
        else                 Tinf = U_TIME_INMS_REL;
    }
    NsimulDip      = 1;
    Ndip           = 0;

    NasionMEG      = Data->GetNLRMarker(0);
    LeftMEG        = Data->GetNLRMarker(1);
    RightMEG       = Data->GetNLRMarker(2);
    SpherePos      = HM->GetSpherePos();
    if(HM->GetCondModelType()==U_CONDMOD_BEM)
    {
        NasionMR       = HM->GetMRmarker(0);
        LeftMR         = HM->GetMRmarker(1);
        RightMR        = HM->GetMRmarker(2);
        MRtoWld        = HM->GetMRtoWld();
    }
/* Collumns */
    UDipole DumDip(UVector3(), UVector3(), DipType);
    SampleCol      = 0;
    IdipOffSet     = new int[1];
    IdipOffSet[0]  = 1;
    int Icol       = 1 + DumDip.GetNDipCollums();
    if(ConfInt==true)
    {
        DeltaOffSet    = new int[1];
        DeltaOffSet[0] = Icol;
        Icol          += 3;
    }
    GroupOffSet    = new int[1];
    GroupOffSet[0] = Icol++;
    ResErrorCol    = Icol++;
    MEGDatPowCol   = Icol++;
}

UDipFileHeader::UDipFileHeader(FILE* fp, const UDipFileHeader* Prev)
/*
      Read dipole header information from an open (text) file with pointer fp.
      Increase the file pointer until the first line that does not start with "//"
      If that line does not start with "Samp" nor "Time", Tinf  == U_TIME_UNKNOWN,
      indicating that fp probably just points to some empty lines or comment lines
      without header information.
 */
{
    SetAllMembersDefault();
    UAnalyzeLineExt AA;

    if(fp==NULL) 
        CI.AddToLog("ERROR: UDipoleMoveList::UDipFileHeader::UDipFileHeader(). Invalid argument.\n");
    
    int  Nitem = 0;
    while(1)
    {
        long ioff = ftell(fp);
        char line[MAXLINE];
        if(!GetLine(line, sizeof(line), fp)) break;

        AA = UAnalyzeLineExt(line);
        if(AA.IsEmptyLine()==true) continue;
        if(strncmp(line,"//",2))  // Process Collumn header
        {
            if(!strnicmp(line,"Time",4))        Tinf = U_TIME_INMS;
            else  if(!strnicmp(line,"Samp",4))  Tinf = U_TIME_INSAMPLES;
            else                                Tinf = U_TIME_UNKNOWN;

            if(Tinf==U_TIME_UNKNOWN && Prev)
            {
                fseek(fp, ioff, SEEK_SET);    
                NsimulDip  = Prev->NsimulDip;
                IdipOffSet = new int[NsimulDip];
                if(Prev->DeltaOffSet)  DeltaOffSet = new int[3*NsimulDip];
                else                   DeltaOffSet = NULL;
                if(Prev->GroupOffSet)  GroupOffSet = new int[NsimulDip];
                else                   GroupOffSet = NULL;

                if(IdipOffSet && Prev->IdipOffSet) 
                    for(int k=0; k<NsimulDip; k++) 
                        IdipOffSet[k]      = Prev->IdipOffSet[k];

                if(DeltaOffSet && Prev->DeltaOffSet) 
                    for(int k=0; k<NsimulDip; k++) 
                    {
                        DeltaOffSet[3*k  ] = Prev->DeltaOffSet[3*k  ];
                        DeltaOffSet[3*k+1] = Prev->DeltaOffSet[3*k+1];
                        DeltaOffSet[3*k+2] = Prev->DeltaOffSet[3*k+2];
                    }

                if(GroupOffSet && Prev->GroupOffSet) 
                    for(int k=0; k<NsimulDip; k++) 
                        GroupOffSet[k]      = Prev->GroupOffSet[k];

                if( (!IdipOffSet  &&  Prev->IdipOffSet)  ||
                    (!DeltaOffSet &&  Prev->DeltaOffSet) ||
                    (!GroupOffSet &&  Prev->GroupOffSet)    )   NsimulDip=0;
                    
                ResErrorCol = Prev->ResErrorCol;
                SampleCol   = Prev->SampleCol;
                MEGDatPowCol= Prev->MEGDatPowCol;
                break;
            }
            AA = UAnalyzeLineExt(line);

/* Determine Dipole collumn*/
            const char* off  = line;
            while(off)
            {
                const char* test = strstr(off, "Type");
                if(!test) break;
                off = test+3;
                NsimulDip++;
            }
            IdipOffSet = new int[NsimulDip];
            if(IdipOffSet==NULL) 
            {
                NsimulDip=0;
                break;
            }
            for(int k=0; k<NsimulDip; k++)
            {
                if(k==0)
                {
                    int col = AA.GetCollumn("Type","%");
                    if(col>0)
                    {
                        IdipOffSet[k] = col;
                        continue;
                    }
                }
                char String[10];
                sprintf(String,"Type%d",k);

                int col = AA.GetCollumn(String,"%");
                if(col<0) return;
                IdipOffSet[k] = col;
            }

/* Determine Delta?? collumn*/
            if(NsimulDip)
            {
                if(AA.GetCollumn("DeltaX")>0 || AA.GetCollumn("DeltaX0")>0)
                    DeltaOffSet = new int[3*NsimulDip];
                if(AA.GetCollumn(TITLE_GROUP)>0 || AA.GetCollumn(TITLE_GROUP0)>0)
                    GroupOffSet = new int[NsimulDip];
                static bool FirstMessage = true;
                if(GroupOffSet==NULL && FirstMessage==true)
                {
                    FirstMessage = false;
                    CI.AddToLog("Note: UDipFileHeader::UDipFileHeader(). Collumn (%s) nor (%s) present in first header. \n",TITLE_GROUP, TITLE_GROUP0);
                }
            }
            if(DeltaOffSet)
            {
                for(int k=0; k<3*NsimulDip; k++) DeltaOffSet[k]=-1;
                for(int k=0; k<NsimulDip; k++)
                {
                    if(k==0)
                    {
                        DeltaOffSet[k  ] = AA.GetCollumn("DeltaX","%");
                        DeltaOffSet[k+1] = AA.GetCollumn("DeltaY","%");
                        DeltaOffSet[k+2] = AA.GetCollumn("DeltaZ","%");
                        if(DeltaOffSet[k]>=0 && DeltaOffSet[k+1]>=0 && DeltaOffSet[k+2]>=0) continue;
                    }
                    char String[20];
                    sprintf(String,"DeltaX%d",k);
                    DeltaOffSet[3*k  ] = AA.GetCollumn(String,"%");
                    sprintf(String,"DeltaY%d",k);                    
                    DeltaOffSet[3*k+1] = AA.GetCollumn(String,"%");
                    sprintf(String,"DeltaZ%d",k);                    
                    DeltaOffSet[3*k+1] = AA.GetCollumn(String,"%");
                }
                for(int k=0; k<NsimulDip; k++)
                {
                    if(DeltaOffSet[3*k  ]<=0) CI.AddToLog("WARNING:UDipFileHeader::UDipFileHeader(). DeltaX collumn for dipole %d not found in header line.\n",k);
                    if(DeltaOffSet[3*k+1]<=0) CI.AddToLog("WARNING:UDipFileHeader::UDipFileHeader(). DeltaY collumn for dipole %d not found in header line.\n",k);
                    if(DeltaOffSet[3*k+2]<=0) CI.AddToLog("WARNING:UDipFileHeader::UDipFileHeader(). DeltaZ collumn for dipole %d not found in header line.\n",k);
                }
            }
            if(GroupOffSet)
            {
                for(int k=0; k<NsimulDip; k++) GroupOffSet[k]=-1;
                for(int k=0; k<NsimulDip; k++)
                {
                    if(k==0)
                    {
                        GroupOffSet[k] = AA.GetCollumn(TITLE_GROUP,"%");
                        if(GroupOffSet[k]>=0) continue;
                    }
                    char String[20];
                    sprintf(String,"%s%d",TITLE_GROUP,k);
                    GroupOffSet[k] = AA.GetCollumn(String,"%");
                }
                for(int k=0; k<NsimulDip; k++)
                    if(GroupOffSet[k]<=0) 
                        CI.AddToLog("WARNING:UDipFileHeader::UDipFileHeader(). %s collumn for dipole %d not found in header line.\n",TITLE_GROUP,k);
            }

/* Determine Error and Time collumn*/
            ResErrorCol  = AA.GetCollumn("ERROR","%");
            SampleCol    = AA.GetCollumn("Time","%");
            MEGDatPowCol = AA.GetCollumn("AverDataPower","%");
            if(SampleCol<0)    SampleCol    = AA.GetCollumn("Samp","%");
            if(MEGDatPowCol<0) MEGDatPowCol = AA.GetCollumn("DataPower","%");

            break;
        }

        UAnalyzeLineExt AA(line+2);
        if(AA.IsIdentifierIsInLine("Subject",true)==true)
        {
            memset(subject_id, 0, sizeof(subject_id));
            strncpy(subject_id,AA.GetPointer(),sizeof(subject_id)-1);
            for(int k=0; k<sizeof(subject_id)-1; k++)
            {
                char c = subject_id[k];
                if(c<=' ' ||c==',' || c==';' || c=='|' || 127<=c) subject_id[k]=' ';
            }
        }
        if(AA.IsIdentifierIsInLine("date",true)==true)
            DatTim = UDateTime(line);

        if(AA.IsIdentifierIs("NASION")==true)     NasionMEG = AA.GetNextVector3();
        if(AA.IsIdentifierIs("LEFT")  ==true)     LeftMEG   = AA.GetNextVector3();
        if(AA.IsIdentifierIs("RIGHT") ==true)     RightMEG  = AA.GetNextVector3();
        if(AA.IsIdentifierIs("SPHERE_POS")==true) SpherePos = AA.GetNextVector3();
        if(SpherePos==UVector3()) SpherePos = UVector3(0.,0.,4.);


        if(AA.IsIdentifierIs("NASION_MR")==true)     NasionMR = AA.GetNextVector3();
        if(AA.IsIdentifierIs("LEFT_MR")  ==true)     LeftMR   = AA.GetNextVector3();
        if(AA.IsIdentifierIs("RIGHT_MR") ==true)     RightMR  = AA.GetNextVector3();

        if(AA.IsIdentifierIsInLine("rx,ry,rz",true)==true)
        {
            UVector3 R = AA.GetNextVector3();
            UVector3 T;
            if(AA.IsIdentifierIs("tx,ty,tz")==true) T = AA.GetNextVector3();
            MRtoWld = UEuler(T.Getx(), T.Gety(), T.Getz(), PI*R.Getx()/180., PI*R.Gety()/180., PI*R.Getz()/180.);
        }

        if(AA.IsIdentifierIsInLine("File",true)==true)
        {
            strncpy(DataSetName,AA.GetPointer(),sizeof(DataSetName));
            char* lastExt = strstr(DataSetName,".ds");
            while(lastExt)
            {
                char* Ext = lastExt;
                lastExt   = strstr(Ext+1,".ds");
                if(lastExt==NULL)
                {
                    Ext[sizeof(".ds")-1] = 0;
                    break;
                }
            }
        }
        if(AA.IsIdentifierIsInLine("Version",true)==true)
        {
            VersionNumber = AA.GetNextDouble();
            if(strstr(line,"FITDIP~1")==NULL &&
               strstr(line,"FitDipoles")==NULL ) VersionNumber = -VersionNumber;
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("SampleRate",true)==true)
        {
            srate = AA.GetNextDouble();
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("nsamp",true)==true)
        {
            nsamp = AA.GetNextInt();
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("ntrial",true)==true)
        {
            ntrial = AA.GetNextInt();
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("nMEG",true)==true)
        {
            nMEG = AA.GetNextInt();
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("nEEG",true)==true)
        {
            nEEG = AA.GetNextInt();
            Nitem++;
        }
        if(AA.IsIdentifierIsInLine("PreTriggerTime",true)==true)
        {
            prestim = AA.GetNextDouble();
            Nitem++;
        }
    }

    if(srate>0) Stime = 1000./srate;
    else        Stime = 1;

    if(Nitem<5) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::UDipFileHeader::UDipFileHeader(). Not all items can be read. Nitem =%d .\n",Nitem);
        CI.AddToLog("Note : VersionNumber = %6.2f \n",VersionNumber);
        CI.AddToLog("Note : SampleRate = %f \n",srate);
        CI.AddToLog("Note : nsamp = %d \n",nsamp);
        CI.AddToLog("Note : ntrial = %d \n",ntrial);
        CI.AddToLog("Note : PreTriggerTime = %f \n",prestim);
        error = U_ERROR;
        return;
    }

    if(Tinf==U_TIME_UNKNOWN ||
       IdipOffSet==NULL)     error = U_ERROR;
    else                     error = U_OK;
}

UDipFileHeader::~UDipFileHeader()
{
    DeleteAllMembers();
}

UDipFileHeader& UDipFileHeader::operator=(const UDipFileHeader& D)
{
    if(&D==NULL)
    {
        CI.AddToLog("ERROR: UDipFileHeader::operator=(). NULL address argument. \n");
        return *this;
    }
    error         = D.error;   
    memcpy(subject_id,  D.subject_id,  sizeof(subject_id));
    DatTim        = D.DatTim;
    memcpy(DataSetName, D.DataSetName, sizeof(DataSetName));
    srate         = D.srate;
    Stime         = D.Stime;
    prestim       = D.prestim;
    nsamp         = D.nsamp;
    ntrial        = D.ntrial;
    nMEG          = D.nMEG;
    nEEG          = D.nEEG;
    VersionNumber = D.VersionNumber;
    Tinf          = D.Tinf;
    Ndip          = D.Ndip;

    NsimulDip     = D.NsimulDip;

    delete[] IdipOffSet; IdipOffSet=NULL;
    if(NsimulDip>0 && NsimulDip)
    {
        IdipOffSet    = new int[NsimulDip];
        for(int k=0; k<NsimulDip; k++) 
            IdipOffSet[k] = D.IdipOffSet[k];
    }
    SampleCol     = D.SampleCol;
    MEGDatPowCol  = D.MEGDatPowCol;
    ResErrorCol   = D.ResErrorCol;
    
    delete[] DeltaOffSet; DeltaOffSet = NULL;
    if(NsimulDip>0 && D.DeltaOffSet)
    {
        DeltaOffSet = new int[3*NsimulDip];
        for(int k=0; k<3*NsimulDip; k++) 
            DeltaOffSet[k] = D.DeltaOffSet[k];
    }
    delete[] GroupOffSet; GroupOffSet = NULL;
    if(NsimulDip>0 && D.GroupOffSet)
    {
        GroupOffSet = new int[NsimulDip];
        for(int k=0; k<NsimulDip; k++) 
            GroupOffSet[k] = D.GroupOffSet[k];
    }
    NasionMEG     = D.NasionMEG;
    LeftMEG       = D.LeftMEG; 
    RightMEG      = D.RightMEG;
    SpherePos     = D.SpherePos;
    NasionMR      = D.NasionMR;
    LeftMR        = D.LeftMR; 
    RightMR       = D.RightMR;
    MRtoWld       = D.MRtoWld;

    StringDat     = D.StringDat;
    StringEpo     = D.StringEpo;
    StringHM      = D.StringHM;

    return *this;
}

ErrorType UDipFileHeader::WriteHeader(FILE* fpOut, UDipole::DipoleType DipType) const
{
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteHeader(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteHeader(). Header not properly set. \n");
        return U_ERROR;
    }
    if((Tinf!= U_TIME_INSAMPLES && Tinf!= U_TIME_INMS && Tinf!= U_TIME_INSAMPLES_REL && Tinf!= U_TIME_INMS_REL) || 
        NsimulDip!=1)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteHeader(). Header not properly set. Tinf = %d, NsimulDip = %d  .\n", Tinf, NsimulDip);
        return U_ERROR;
    }

    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut, "%s", CI.GetProperties("//   "));
    fprintf(fpOut,"// \n");
    fprintf(fpOut,"// DATA:\n");
    if(StringDat.IsEmpty()==false && StringDat.IsNULL()==false)
    {
        fprintf(fpOut,"%s",(const char*)StringDat);
    }
    else
    {
        fprintf(fpOut,"//   File  = %s \n",DataSetName);
        fprintf(fpOut,"//   Subject  = %s \n",subject_id);
        fprintf(fpOut,"%s",DatTim.GetProperties("//   "));
        fprintf(fpOut,"//   SampleRate     = %f \n", srate);
        fprintf(fpOut,"//   nsamp          = %d \n", nsamp);
        fprintf(fpOut,"//   PreTriggerTime = %f (s)\n", prestim);
        fprintf(fpOut,"//   trial          = %d \n", ntrial);
        fprintf(fpOut,"//   Nmeg           = %d \n", nMEG);
        fprintf(fpOut,"//   Neeg           = %d \n", nEEG);
    }
    fprintf(fpOut,"// \n");
    if(StringEpo.IsEmpty()==false && StringEpo.IsNULL()==false)
    {
        fprintf(fpOut,"// EPOCHS:\n");
        fprintf(fpOut,"%s",(const char*)StringEpo);
        fprintf(fpOut,"// \n");
    }
    fprintf(fpOut,"// \n");
    fprintf(fpOut,"// COORDINATES:\n");
    fprintf(fpOut,"//   MEG FIDUCIALS:\n");
    fprintf(fpOut,"//   NASION    = %s \n", NasionMEG.GetProperties());
    fprintf(fpOut,"//   LEFT      = %s \n", LeftMEG  .GetProperties());
    fprintf(fpOut,"//   RIGHT     = %s \n", RightMEG .GetProperties());
    fprintf(fpOut,"// \n");
    if(StringHM.IsEmpty()==false && StringHM.IsNULL()==false)
    {
        fprintf(fpOut,"// HEADMODEL:\n");
        fprintf(fpOut,"%s",(const char*)StringHM);
    }
    else
    {
        if(SpherePos!=UVector3()) fprintf(fpOut,"//   SPHERE_POS= %s \n", SpherePos.GetProperties());
        fprintf(fpOut,"// \n");
        fprintf(fpOut,"// \n");
        if(NasionMR !=UVector3()) fprintf(fpOut,"//   NASION_MR    = %s \n", NasionMR.GetProperties());
        if(LeftMR   !=UVector3()) fprintf(fpOut,"//   LEFT_MR      = %s \n", LeftMR  .GetProperties());
        if(RightMR  !=UVector3()) fprintf(fpOut,"//   RIGHT_MR     = %s \n", RightMR .GetProperties());
        if(MRtoWld  !=UEuler())   fprintf(fpOut,"//   MRtoWld:     %s \n",   MRtoWld .GetProperties(NULL));
    }        
    fprintf(fpOut,"// \n");
    fprintf(fpOut,"// \n");

/*Create Collumn header. Use Fixed Order, that may be different from File Input */
    UString HeadLine;
    if(Tinf==U_TIME_INSAMPLES||Tinf==U_TIME_INSAMPLES_REL) HeadLine = UString("Samp\t");
    if(Tinf==U_TIME_INMS     ||Tinf==U_TIME_INMS_REL     ) HeadLine = UString("Time\t");

    UDipole DumDip(UVector3(), UVector3(), DipType);
    char    line[MAXDIPLINE];
    DumDip.PrintParameters(line,-MAXDIPLINE, 0);
    HeadLine += UString(line);
    if(DeltaOffSet)
    {
        HeadLine += UString("\tDeltaX0");
        HeadLine += UString("\tDeltaY0");
        HeadLine += UString("\tDeltaZ0");
    }
    if(GroupOffSet)
        HeadLine += UString("\tGroup0");
    if(ResErrorCol>0)
        HeadLine += UString("\tERROR (%)");
    if(MEGDatPowCol>0)
        HeadLine += UString("\tDataPower");
    HeadLine += UString("\n");

    fprintf(fpOut,"%s",(const char*)HeadLine);
    return U_OK;
}

ErrorType UDipFileHeader::WriteDipole(FILE* fpOut, UDipoleMove Dip, int NDigits) const
{
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteDipole(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteDipole(). Header not properly set. \n");
        return U_ERROR;
    }
    if((Tinf!= U_TIME_INSAMPLES && Tinf!= U_TIME_INMS && Tinf!= U_TIME_INSAMPLES_REL && Tinf!= U_TIME_INMS_REL) || 
        NsimulDip!=1)
    {
        CI.AddToLog("ERROR: UDipFileHeader::WriteDipole(). Header not properly set. Tinf = %d, NsimulDip = %d  .\n", Tinf, NsimulDip);
        return U_ERROR;
    }

    double Time = 1000*prestim + Dip.GetTime(); // in ms
    int    Samp = int(floor(Time*srate/1000.));

    UString DipLine;
    if(Tinf==U_TIME_INSAMPLES||Tinf==U_TIME_INSAMPLES_REL) DipLine = UString(Samp,"%6.6d\t");
    if(Tinf==U_TIME_INMS     ||Tinf==U_TIME_INMS_REL     ) DipLine = UString(Time,"%f\t");

    char    line[MAXDIPLINE];
    Dip.PrintParameters(line, MAXDIPLINE, 0, NDigits);
    DipLine += UString(line);
    if(DeltaOffSet)
    {
        UVector3 D = Dip.GetDelta();
        DipLine   += UString(D.Getx(), "\t%f ");
        DipLine   += UString(D.Gety(), "\t%f ");
        DipLine   += UString(D.Getz(), "\t%f ");
    }
    if(GroupOffSet)
        DipLine += UString(Dip.GetGroup(),"\t%d ");
    if(ResErrorCol>0)
        DipLine += UString(Dip.GetResidualError(),"\t%f ");
    if(MEGDatPowCol>0)
        DipLine += UString(Dip.GetMEGDataPower(),"\t%f ");
    DipLine += UString("\n");

    fprintf(fpOut, "%s", (const char*)DipLine);
    return U_OK;
}
       
UDipole UDipFileHeader::GetDipole(int idip, UAnalyzeLineExt& AA) const
{
    if(idip<0 || idip>=NsimulDip ||
       IdipOffSet==NULL)                 
    {
        CI.AddToLog("ERROR: UDipFileHeader::GetDipole(). Argument out of range: idip=%d, NsimulDip=%d\n",idip,NsimulDip);
        return UDipole();
    }
    UDipole ReturnDip = AA.GetDipole(IdipOffSet[idip]);
    if(AA.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipFileHeader::GetDipole(). Reading dipole %d, collumn %d. ",idip,IdipOffSet[idip]);
        CI.AddToLog("String = '%20.20s ...' \n",AA.GetPointer());
    }
    return ReturnDip;
}

UVector3 UDipFileHeader::GetDelta(int idip, UAnalyzeLineExt& AA) const
{
    if(idip<0 || idip>=NsimulDip)         
    {
        CI.AddToLog("ERROR: UDipFileHeader::GetDelta(). Argument out of range: idip=%d, NsimulDip=%d\n",idip,NsimulDip);
        return UVector3();
    }
    if(DeltaOffSet==NULL) return UVector3();

    double DeltaX=AA.GetCollumn_d(DeltaOffSet[3*idip  ], 0.);
    double DeltaY=AA.GetCollumn_d(DeltaOffSet[3*idip+1], 0.);
    double DeltaZ=AA.GetCollumn_d(DeltaOffSet[3*idip+2], 0.);
    return UVector3(DeltaX, DeltaY, DeltaZ);
}

int UDipFileHeader::GetGroup(int idip, UAnalyzeLineExt& AA) const
{
    if(idip<0 || idip>=NsimulDip)         
    {
        CI.AddToLog("ERROR: UDipFileHeader::GetGeneralProp(). Argument out of range: idip=%d, NsimulDip=%d\n",idip,NsimulDip);
        return 0;
    }
    if(GroupOffSet==NULL) return 0;

    if(GroupOffSet[idip]<0 && GroupOffSet[0]<0) return 0;

    int Result = -1;
    if(GroupOffSet[idip]<0) Result = AA.GetCollumn_i(GroupOffSet[0], -1);
    else                    Result = AA.GetCollumn_i(GroupOffSet[idip  ], -1);
    if(Result==-1)
    {
        double Result_d = -1.;
        if(GroupOffSet[idip]<0) Result_d = AA.GetCollumn_d(GroupOffSet[0], -1.);
        else                    Result_d = AA.GetCollumn_d(GroupOffSet[idip  ], -1.);
        if(Result_d<0) return 0;
        return int(floor(Result_d+.5));
    }
    return Result;
}

ErrorType UDipFileHeader::DecreaseNdip(void)
{
    if(Ndip<=0) return U_ERROR;
    Ndip--;
    return U_OK;
}

ErrorType UDipFileHeader::IncreaseNdip(void)
{
    Ndip++;
    return U_OK;
}

double UDipFileHeader::GetSample(UAnalyzeLineExt& AA) const
{
    return AA.GetCollumn_d(SampleCol, 0.);
}

double UDipFileHeader::MEGDataPower(UAnalyzeLineExt& AA) const
{
    if(MEGDatPowCol<=0) return 0.;
    return AA.GetCollumn_d(MEGDatPowCol, 0.);
}

double UDipFileHeader::GetResError(UAnalyzeLineExt& AA) const
{
    return AA.GetCollumn_d(ResErrorCol, 1000.);
}

UEvent UDipFileHeader::GetEvent(double AbsTimeInms) const
{
    int abssamp = int(floor( (AbsTimeInms/Stime)+.5 ));
    return UEvent(abssamp/nsamp, abssamp%nsamp);
}

double UDipFileHeader::GetTimeInms(double FirstCollumn, int DefaultTrial) const
{
    if(Tinf==U_TIME_UNKNOWN) return 0;

    if(Tinf==U_TIME_INMS)    return FirstCollumn;

    if(VersionNumber<0 || VersionNumber>=6.0)   return FirstCollumn*Stime;

    return (DefaultTrial*nsamp+FirstCollumn)*Stime;  // Trial Unknown
}
