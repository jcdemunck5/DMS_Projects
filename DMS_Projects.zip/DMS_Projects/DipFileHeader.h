#ifndef _DIPFILEHEADER_INCLUDED
#define _DIPFILEHEADER_INCLUDED

#include "Event.h"
#include "FileName.h"
#include "DateTime.h"
#include "Euler.h"
#include "Dipole.h"
#include "DipoleMove.h"
#include "String.h"

class UAnalyzeLineExt;
class UHeadModel;
class UMEEGDataBase;
class UEpochs;

class DLL_IO UDipFileHeader
{
public:
    enum TimeInfo
    {  
        U_TIME_UNKNOWN,         // time information (first collumn) unknown
        U_TIME_INSAMPLES,       // time expressed in sample number wrt beginning of file
        U_TIME_INMS,            // time expressed in ms wrt beginning of file
        U_TIME_INSAMPLES_REL,   // time expressed in sample number wrt trial (information lost)
        U_TIME_INMS_REL         // time expressed in ms wrt trial (information lost)
    };

    UDipFileHeader(UFileName Fname);
    UDipFileHeader(FILE* fp, const UDipFileHeader* Prev=NULL);
    UDipFileHeader(const UMEEGDataBase* Data, const UHeadModel* HM, const UEpochs* Epo, bool TimeInSamp, bool UseAbsTime, UDipole::DipoleType DipType, bool ConfInt);
    UDipFileHeader(const UDipFileHeader& D);

    virtual ~UDipFileHeader();

    UDipFileHeader& operator=(const UDipFileHeader& D);

    
    ErrorType       GetError(void) const     {return error;}
    TimeInfo        GetTimeInfo(void) const  {return Tinf;}
    UVector3        GetNasionMEG(void) const {return NasionMEG;}
    UVector3        GetLeftMEG(void) const   {return LeftMEG;}
    UVector3        GetRightMEG(void) const  {return RightMEG;}
    UVector3        GetSpherePos(void) const {return SpherePos;}
    UVector3        GetNasionMR(void) const  {return NasionMR;}
    UVector3        GetLeftMR(void) const    {return LeftMR;}
    UVector3        GetRightMR(void) const   {return RightMR;}
    UEuler          GetMRtoWld(void) const   {return MRtoWld;}
    
    UEvent          GetEvent(double AbsTimeInms) const;
    double          GetTimeInms(double FirstCollumn, int DefaultTrial=0) const;
    const char*     GetSubject()   const {return subject_id;}
    UDateTime       GetDateTime()  const {return DatTim;}
    const char*     GetDataSetName() const {return DataSetName;}
    double          GetSRate() const {return srate;}
    double          GetPreStim() const {return prestim;}

/* The meaning of the collumns*/
    int             GetNsimulDip(void) const {return NsimulDip;}
    int             GetNdip(void)      const {return Ndip;}
    int             GetNsamp(void)     const {return nsamp;}
    int             GetNtrial(void)    const {return ntrial;}
    int             GetNmeg(void)      const {return nMEG;}
    int             GetNeeg(void)      const {return nEEG;}
    void            SetNdip(int nd)          {Ndip = nd;}
    ErrorType       DecreaseNdip(void);
    ErrorType       IncreaseNdip(void);
    UDipole         GetDipole(int idip, UAnalyzeLineExt& AA) const;
    UVector3        GetDelta(int idip, UAnalyzeLineExt& AA) const;
    int             GetGroup(int idip, UAnalyzeLineExt& AA) const;
    double          GetSample(UAnalyzeLineExt& AA) const;
    double          MEGDataPower(UAnalyzeLineExt& AA) const;
    double          GetResError(UAnalyzeLineExt& AA) const;
    bool            ConfIntervalComputed(void) const {if(DeltaOffSet) return true; return false;}

    ErrorType       WriteHeader(FILE* fpOut, UDipole::DipoleType DipType) const;
    ErrorType       WriteDipole(FILE* fpOut, UDipoleMove Dip, int NDigits) const;

protected:
    void            SetAllMembersDefault(void); // Reset all members
    void            DeleteAllMembers(void);     // Delete all members

private:
    ErrorType       error;         // General error flag.
    UDateTime       DatTim;        // Recording date and time
    char            subject_id[32];// Name of the subject
    char            DataSetName[256]; // Name of the data set
    double          srate;         // Sample frequency
    double          Stime;         // sample time in ms. (==1000./srate)
    double          prestim;       // Time before the stimulus (trigger) (s)
    int             nsamp;         // Number of samples per trial, per channel
    int             ntrial;        // Number of trials
    int             nMEG;          // Number of MEG channels in data file
    int             nEEG;          // Number of EEG channels in data file
    double          VersionNumber; // Version number of FitDipoles.exe used to create dipole file
    TimeInfo        Tinf;          // Determines the meaning of first collumn in dipole file
    int             Ndip;          // The number of (selected) dipoles for a given file header

/* Coordinate system*/
    UVector3        NasionMEG;     // Nasion position in MEG NLR coordinates
    UVector3        LeftMEG;       // Left pre-auricular position in MEG NLR coordinates
    UVector3        RightMEG;      // Left pre-auricular position in MEG NLR coordinates
    UVector3        SpherePos;     // The position of the best fitting sphere in NLR coordinates
    UVector3        NasionMR;      // Nasion position in MR coordinates (realistic models)
    UVector3        LeftMR;        // Left pre-auricular position in MR coordinates (realistic models)
    UVector3        RightMR;       // Left pre-auricular position in MR coordinates (realistic models)
    UEuler          MRtoWld;       // Fit of the MR to ConQuest world coordinates 

/* The meaning of the collumns: */
    int             NsimulDip;     // The number of simultaneous active dipoles (printed on the same line)
    int*            IdipOffSet;    // Determines at which collumn the first parameter of each dipole can be read
    int             SampleCol;     // Determines at which collumn the sample information can be found
    int             MEGDatPowCol;  // Determines at which collumn the MEG data power can be found
    int             ResErrorCol;   // Determines at which collumn the residual error infomation is present
    int*            DeltaOffSet;   // Determines at which collumn the DeltaX, DeltaY, DeltaZ of each simultaneous dipole can be found
    int*            GroupOffSet;   // Determines at which collumn the Group of each simultaneous dipole can be found

/* Comments */
    UString         StringDat;     // Data string
    UString         StringEpo;     // Epochs string
    UString         StringHM;      // Head model string
};


#endif // _DIPFILEHEADER_INCLUDED
