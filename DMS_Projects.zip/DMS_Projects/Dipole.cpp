/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for maintaining the data of a dipole.                              */
/*     A dipole can by of several types: Normal current dipole, a symmetric      */
/*     current dipole, a semei symmetric current dipole (only the position is    */
/*     symmetric), or a magnetic dipole (a current throught a coil).             */
/*     The counterpart of a symmetric dipole is found by a reflection w.r.t. the */
/*     plane through a best-fitting sphere. The position of this sphere is to    */
/*     be given expicitly.                                                       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    03-09-98   creation (derived from inline version)
  JdM    25-09-98   print dipole moments in %e-format, instead of %f
  JdM    08-10-98   separated include-files
  Jdm    24-10-98   Use the UAnalyzeLine-object to read dipole parameters from a string
  Jdm    19-12-98   Added _error-flag, and a constructor using a string
  Jdm    21-12-98   BUG FIX: ReadParameters(), reading symmetric dipoles
  Jdm    28-12-98   Added more detailed comments
  GdV    22-04-99   Adapted to Unix
DvT/JdM  21-06-99   Added Dipoles compare functions (outside object)
  JdM    30-08-99   Added functions to get and store dipole orientations by the tangential angle
  JdM    17-02-00   Changed include files to avoid circular inclusion
  JdM    11-04-00   Added new setd() and setx()
  JdM    28-06-00   Add UAnalyzeLineExt::GetNextDipole()
  JdM    10-08-00   Add parameter to PrintParameters(), update ReadParameter()
                    Added SetStrength() and GetRadAngle()
  JdM    28-08-00   Bug Fix in AngleCompare(). Apply acos() on inner product
  JdM    19-09-00   Added operator==()
  JdM    15-11-00   Added GetProperties()
  JdM    24-12-00   GetNextDipole() Restore Pointer when reading dipole is not succesfull
  JdM    16-01-01   Move UAnalyzeLineExt::GetDipole() to Dipole.cpp
  JdM    29-11-01   Added GetRadAngleSym() and Normalize()
  JdM    14-12-01   Added GetRadComp() and GetRadCompSym()
  JdM    25-08-02   Added Distance2()
  JdM    10-03-03   Added SetTangential()
  FB     02-10-03   Bug fix: SetTangential(): take opposite y-coordinate for _ddSym
  JdM    04-12-04   Added (and used) new PrintParameters(), having NDigit
  JdM    05-01-05   Added GetNDipCollums()
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    23-06-09   Added GetDipoleTypeText()
  JdM    15-11-12   UDipole::UDipole(). BUG FIX: dd 29-08-08. Update members AFTER calling SetAllMembersDefault()
  JdM    21-01-15   Added virtual GetResidualError() and GetTime(), to be used in derived classes
  JdM    25-05-15   Added int conversion functions for PotInterPolType and BEMSmoothType
*/

#include <string.h>

#include "Dipole.h"
#include "AnalyzeLineExt.h"
#include "HeadModel.h"

char UDipole::Properties[MAXDIPOLE_PROPERTIES]  =  "";

const char* GetDipoleTypeText(UDipole::DipoleType DType)
{
    switch(DType)
    {
    case UDipole::Current:      return "CurrentDipole";
    case UDipole::Magnetic:     return "MagneticDipole";
    case UDipole::Symmetric:    return "SymmetricDipole";
    case UDipole::SymmetricPos: return "SemiSymmetricDipole";
    }
    return "UnknownDipoleType";
}

CondModelType GetCondModelType(int itype)
{
    switch(itype)
    {
    case  0: return  U_CONDMOD_UNKNOWN;
    case  1: return  U_CONDMOD_INFINITEMEDIUM;
    case  2: return  U_CONDMOD_SPHERE;        
    case  3: return  U_CONDMOD_HOMSPHERE;     
    case  4: return  U_CONDMOD_THREESPHERE;   
    case  5: return  U_CONDMOD_MULTISPHERE;   
    case  6: return  U_CONDMOD_BEM;          
    }
    CI.AddToLog("ERROR: GetCondModelType. invalid index (itype=%d)  .\n", itype);
    return U_CONDMOD_UNKNOWN;
}
const char* GetCondModelTypeText(CondModelType CT)
{
    switch(CT)
    {
    case U_CONDMOD_UNKNOWN:         return "Undefined model";
    case U_CONDMOD_INFINITEMEDIUM:  return "Infinite medium";
    case U_CONDMOD_SPHERE:          return "Spherical symmetric model used for MEG";
    case U_CONDMOD_HOMSPHERE:       return "Homogeneously conducting sphere";
    case U_CONDMOD_THREESPHERE:     return "Three sphere model";
    case U_CONDMOD_MULTISPHERE:     return "General multi-sphere model";
    case U_CONDMOD_BEM:             return "Boundary element head model";
    }    
    CI.AddToLog("ERROR: GetCondModelTypeText(). invalid index (CT=%d)  .\n", CT);
    return "Invalid head model type";
};

PotInterPolType GetPotInterPolType(int itype)
{
    switch(itype)
    {
    case 0: return U_POTINTER_UNKNOWN ;
    case 1: return U_POTINTER_CONSTANT;
    case 2: return U_POTINTER_LINEAR  ;
    }
    CI.AddToLog("ERROR: GetPotInterPolType(). Invalid argument (%d)\n", itype);
    return U_POTINTER_UNKNOWN;
}
int GetPotInterPolInt(PotInterPolType PIPT)
{
    switch(PIPT)
    {
    case U_POTINTER_UNKNOWN :      return 0;
    case U_POTINTER_CONSTANT:      return 1;
    case U_POTINTER_LINEAR  :      return 2;
    }
    CI.AddToLog("ERROR: GetPotInterPolInt(). Invalid argument (%d)\n", int(PIPT));
    return -1;
}
const char* GetPotInterTypeText(PotInterPolType PT)
{
    switch(PT)
    {
    case  U_POTINTER_UNKNOWN:   return "UnknownInterpolation";
    case  U_POTINTER_CONSTANT:  return "PiecewiseConstant";
    case  U_POTINTER_LINEAR:    return "PiecewiseLinear";
    }
    CI.AddToLog("ERROR: GetPotInterTypeText(). invalid index (PT=%d)  .\n", PT);
    return NULL;
}
BEMSmoothType GetBEMSmoothType(int itype)
{
    switch(itype)
    {
    case  0: return U_SMOOTH_UNKNOWN;    
    case  1: return U_SMOOTH_DEFAULT;    
    case  2: return U_SMOOTH_RAW;           
    case  3: return U_SMOOTH_SMOOTH;          
    }
    CI.AddToLog("ERROR: GetBEMSmoothType(). invalid index (itype=%d)  .\n", itype);
    return U_SMOOTH_UNKNOWN;
}
int GetBEMSmoothInt(BEMSmoothType BST)
{
    switch(BST)
    {
    case U_SMOOTH_UNKNOWN: return 0;
    case U_SMOOTH_DEFAULT: return 1;
    case U_SMOOTH_RAW    : return 2;
    case U_SMOOTH_SMOOTH : return 3;
    }
    CI.AddToLog("ERROR: GetBEMSmoothInt(). Invalid argument (%d)\n", int(BST));
    return U_SMOOTH_UNKNOWN;
}
const char* GetBEMSmoothTypeText(BEMSmoothType BST)
{
    switch(BST)
    {
    case  U_SMOOTH_UNKNOWN:  return "UnknownSmoothing";
    case  U_SMOOTH_DEFAULT:  return "DefaultSmoothing (RHS follows matrix)";
    case  U_SMOOTH_RAW:      return "SmoothingOff";           
    case  U_SMOOTH_SMOOTH:   return "SmoothingOn";          
    }
    CI.AddToLog("ERROR: GetBEMSmoothTypeText(). invalid index (BST=%d)  .\n", BST);
    return NULL;
}


void UDipole::SetAllMembersDefault(void)
{
    _error   = U_OK;
    _xd      = UVector3(); 
    _dd      = UVector3(); 
    _ddSym   = UVector3(); 
    _DipType = Current;
    memset(Properties, 0, MAXDIPOLE_PROPERTIES);
}
void UDipole::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    _error   = E;
}

UDipole::UDipole(UVector3 xd, UVector3 dd, DipoleType DipType) 
/*  
     Create a dipole with position xd, dipole vector dd and type DipType.
 */
{ 
    SetAllMembersDefault();
    _xd     = xd; 
    _dd     = _ddSym = dd; 
    _ddSym.MirrorY(); 
    _DipType = DipType;
}

UDipole::UDipole(UVector3 xd, UVector3 dd, UVector3 ddSym) 
/*  
     Create a seme-symmetric dipole with position xd, left dipole vector dd 
     and right dipole vector ddSym.
 */
{ 
    SetAllMembersDefault();
    _xd      = xd; 
    _dd      = dd; 
    _ddSym   = ddSym; 
    _DipType = SymmetricPos;
}

UDipole::UDipole(double x, double y, double z, double dx, double dy, double dz,  DipoleType DipType)    
/*  
     Create a dipole with position (x, y, z), dipole vector (dx, dy, dz) and type DipType.
 */
{
    SetAllMembersDefault();
    _xd      = UVector3(x, y, z );
    _dd      = UVector3(dx,dy,dz);
    _ddSym   = _dd;
    _ddSym.MirrorY();
    _DipType = DipType;
}

UDipole::UDipole(double x, double y, double z, double dx, double dy, double dz, double dxS, double dyS, double dzS) 
/*  
     Create a seme-symmetric dipole with position (x,y,z), left dipole vector (dx, dy, dz) 
     and right dipole vector (dxS, dyS, dzS).
 */
{
    SetAllMembersDefault();
    _xd      = UVector3(x  ,y  ,z  );
    _dd      = UVector3(dx ,dy ,dz );
    _ddSym   = UVector3(dxS,dyS,dzS);

    _DipType = SymmetricPos;
}

UDipole::UDipole(double x, double y, double z, double Th, double Fi,  DipoleType DipType) 
/*  
     Create a dipole with position (x,y,z), normalized dipole vector (cos Th cos Fi, cos Th sin Fi, sin Th) 
     and type DipType.
 */
{
    SetAllMembersDefault();
    _xd      = UVector3(x, y, z);
    _dd      = UVector3(Th, Fi);
    _ddSym   = _dd;
    _ddSym.MirrorY();
    _DipType = DipType;
}

UDipole::UDipole(const UDipole &dip)
/*
    Copy constructor.
 */
{
    SetAllMembersDefault();
    *this = dip;
}

UDipole::UDipole(char* String, int MaxChar) 
/*
    Create dipole by reading parameters from a string.
 */
{
    SetAllMembersDefault();
    if(ReadParameters(String, MaxChar)<0) _error = U_ERROR;
    else                                  _error = U_OK;
}

UDipole& UDipole::operator=(const UDipole& dip)
/* 
  Assignment operator
*/
{
    if(this==NULL)
    {
        static UDipole D; D._error = U_ERROR;
        return D;
    }
    if(&dip==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&dip) return *this;
    DeleteAllMembers(U_OK);

    _error   = dip._error;
    _xd      = dip._xd; 
    _dd      = dip._dd; 
    _ddSym   = dip._ddSym; 
    _DipType = dip._DipType; 
    return *this;
}

bool UDipole::operator==(const UDipole& dip) const
{
    if(_error  !=dip._error  ) return false;
    if(_xd     !=dip._xd     ) return false;
    if(_dd     !=dip._dd     ) return false;
    if(_DipType!=dip._DipType) return false;
    if(_DipType==SymmetricPos &&
       _ddSym  !=dip._ddSym)   return false;

    return true;
}

UDipole UDipole::Transform(const UEuler& euler)    
/*
     Apply the Euler transform euler onto the dipole parameters and return
     the transformed dipole.
 */
{
    _xd = euler.xfm(_xd); 
    _dd = euler.xfm(_dd,true);
    _ddSym = euler.xfm(_ddSym,true);

    return *this;
}

UDipole UEuler::xfm(const UDipole &d) const
{
    UDipole Rd(d);
    Rd.Setx(   xfm(d.Getx()));
    Rd.Setd(   xfm(d.Getd(), true));
    Rd.SetdSym(xfm(d.GetdSym(), true));
    return Rd;
}


void UDipole::Mirror(UVector3 SpherePos)
/*
    If the dipole has a symmetric counterpart, swap both dipoles.
 */
{
    if(_DipType==Symmetric)
    {
        _xd.MirrorY(SpherePos);
        _dd.MirrorY();
        _ddSym.MirrorY();
    }
    if(_DipType==SymmetricPos) // swap left and right dipoles
    {
        _xd.MirrorY(SpherePos);
        UVector3 v = _dd;
        _dd        = _ddSym;
        _ddSym     = v;
    }
}

void UDipole::SetSymRight(UVector3 SpherePos)
/*
     Put the symmetric part of the dipole (if present) onto the left side
     of the head. In this way it is achieved that the y-coordinate of the
     dipole position is greater than or equal to zero.
 */
{
    if(_DipType!=Symmetric && _DipType!=SymmetricPos) return;

    if(_xd.Gety() < 0.)  Mirror(SpherePos);
}

double UDipole::GetRadAngle(UVector3 SpherePos) const
{
    double CompTh = _dd&(_xd-SpherePos).GetUThe();
    double CompFi = _dd&(_xd-SpherePos).GetUFi();
    double CompRa = _dd&(_xd-SpherePos).GetURad();

    return UVector3(CompFi, CompTh, CompRa).GetTheta();
}

double UDipole::GetTanAngle(UVector3 SpherePos) const
{
    double CompTh = _dd&(_xd-SpherePos).GetUThe();
    double CompFi = _dd&(_xd-SpherePos).GetUFi();
    if(fabs(CompTh)+fabs(CompFi)<1.e-10) return 0;
    
    return atan2(CompFi, CompTh);
}

double UDipole::GetRadAngleSym(UVector3 SpherePos) const
{
    double CompTh = _ddSym&(_xd-SpherePos).GetUThe();
    double CompFi = _ddSym&(_xd-SpherePos).GetUFi();
    double CompRa = _ddSym&(_xd-SpherePos).GetURad();

    return UVector3(CompFi, CompTh, CompRa).GetTheta();
}

double UDipole::GetRadComp(UVector3 SpherePos) const
{
    return _dd&(_xd-SpherePos).GetURad();
}

double UDipole::GetRadCompSym(UVector3 SpherePos) const
{
    return _ddSym&(_xd-SpherePos).GetURad();
}

ErrorType UDipole::SetTangential(UVector3 SpherePos)
{
    UVector3 Rdir = (_xd-SpherePos).GetURad();
    _dd    -= (_dd   &Rdir) * Rdir;
	Rdir.Sety(-Rdir.Gety());
    _ddSym -= (_ddSym&Rdir) * Rdir;

    return U_OK;
}

void UDipole::Setd(UVector3 SpherePos, double TanAngle, double Mag)
{
    double CompTh = Mag*cos(TanAngle);
    double CompFi = Mag*sin(TanAngle);
    UVector3  UT  = (_xd-SpherePos).GetUThe();
    UVector3  UF  = (_xd-SpherePos).GetUFi();
    
    _dd = CompTh*UT + CompFi*UF;
}

void UDipole::Setd(const double *Dir)
{
    if(Dir==NULL) return;
    _dd    = UVector3(Dir);    

    if(_DipType==Symmetric   ) 
    {
        _ddSym = _dd;
        _ddSym.MirrorY();
        return;
    }
    if(_DipType==SymmetricPos)  _ddSym = UVector3(Dir+3);
}

void UDipole::SetStrength(double Sleft, double Sright)
{
    _dd.Normalize();
    _dd = Sleft*_dd;

    if(_DipType==Symmetric   ) 
    {
        _ddSym = _dd;
        _ddSym.MirrorY();
        return;
    }
    if(_DipType==SymmetricPos)  
    {
        _ddSym.Normalize();
        _ddSym = Sright*_ddSym;
    }
}

const char* UDipole::GetProperties(void) const
{
    memset(Properties,0, MAXDIPOLE_PROPERTIES);

    PrintParameters(Properties, MAXDIPOLE_PROPERTIES, 0);
    return Properties;
}

int UDipole::PrintParameters(char *String, int Maxchar, int Dipno, bool ManyDigits) const
/*
     if(Maxchar>0) write the contents of *this object to the String-string 
                   in a fixed ASCII-format
                   ignore Dipno
                   if(ManyDigits==true) print dipole parameters in 12 digits
     if(Maxchar<0) write the header corresponding to the contents of *this object
                   to the String-string in a fixed ASCII-format.
                   if(Dipno>=0) print the value of Dipno directly after each item
                   ignore ManyDigits

     The string *String should be allocated in the calling function.

     return the number of characters written to String, iff this number is less
            than abs(Maxchar).
            -1 if the number of characters needed is more than Maxchar.                   
 */
{
    if(ManyDigits==true) return PrintParameters(String, Maxchar, Dipno, 10);
    return PrintParameters(String, Maxchar, Dipno, 3);        
}

int UDipole::PrintParameters(char *String, int Maxchar, int Dipno, int NDigit) const
/*
     if(Maxchar>0) write the contents of *this object to the String-string 
                   in a fixed ASCII-format
                   ignore Dipno 
                   print dipole parameters in NDigit digits
     if(Maxchar<0) write the header corresponding of the contents of *this object
                   to the String-string in a fixed ASCII-format.
                   if(Dipno>=0) print the value of Dipno directly after each item
                   ignore NDigit

     The string *String should be allocated in the calling function.

     return the number of characters written to String, iff this number is less
            than abs(Maxchar).
            -1 if the number of characters needed is more than Maxchar.                   
 */
{
    int nc=0;

    if(Maxchar==0) return nc;
    
    for(int k=0; k<abs(Maxchar)-1; k++)   String[k] = ' ';
    String[abs(Maxchar)-1] = 0;
    if(nc>abs(Maxchar)-10) return -1;

    if(Maxchar<0)
    {
        nc+=sprintf(String+nc,"\tType");        if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        if(nc>abs(Maxchar)-10) return -1;
        nc+=sprintf(String+nc,"\tPos_x");       if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        if(nc>abs(Maxchar)-10) return -1;
        nc+=sprintf(String+nc,"\tPos_y");       if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        if(nc>abs(Maxchar)-10) return -1;
        nc+=sprintf(String+nc,"\tPos_z");       if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        if(nc>abs(Maxchar)-10) return -1;

        if(_DipType!=SymmetricPos)
        {
            nc+=sprintf(String+nc,"\tMom_x");   if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMom_y");   if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMom_z");   if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        }
        else
        {
            nc+=sprintf(String+nc,"\tMLeft_x"); if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMLeft_y"); if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMLeft_z"); if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMRight_x");if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMRight_y");if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
            if(nc>abs(Maxchar)-10) return -1;
            nc+=sprintf(String+nc,"\tMRight_z");if(Dipno>=0) nc+=sprintf(String+nc,"%d",Dipno);
        }
        return nc;
    }

    switch(_DipType)
    {
    case Magnetic:
        nc+=sprintf(String+nc,"\tCoil ");
        break;
    case Current: 
        nc+=sprintf(String+nc,"\tCurrent ");
        break;
    case Symmetric:
        nc+=sprintf(String+nc,"\tFull_S. ");
        break;
    case SymmetricPos:
        nc+=sprintf(String+nc,"\tHalf_S. ");
        break;
    }

    NDigit = MIN(12, MAX(2, NDigit));
    char FormatX[50];    sprintf(FormatX,"\t%%%d.%df ",NDigit+5, NDigit);
    char FormatD[50];    sprintf(FormatD,"\t%%%d.%de ",NDigit+6, NDigit);

    if(nc>abs(Maxchar)-(NDigit+5)) return -1;
    nc+=sprintf(String+nc,FormatX,_xd.Getx());
    if(nc>abs(Maxchar)-(NDigit+5)) return -1;
    nc+=sprintf(String+nc,FormatX,_xd.Gety());
    if(nc>abs(Maxchar)-(NDigit+5)) return -1;
    nc+=sprintf(String+nc,FormatX,_xd.Getz());

    if(nc>abs(Maxchar)-(NDigit+6)) return -1;
    nc+=sprintf(String+nc,FormatD,_dd.Getx());
    if(nc>abs(Maxchar)-(NDigit+6)) return -1;
    nc+=sprintf(String+nc,FormatD,_dd.Gety());
    if(nc>abs(Maxchar)-(NDigit+6)) return -1;
    nc+=sprintf(String+nc,FormatD,_dd.Getz());

    if(_DipType==SymmetricPos)
    {
        if(nc>abs(Maxchar)-(NDigit+6)) return -1;
        nc+=sprintf(String+nc,FormatD,_ddSym.Getx());
        if(nc>abs(Maxchar)-(NDigit+6)) return -1;
        nc+=sprintf(String+nc,FormatD,_ddSym.Gety());
        if(nc>abs(Maxchar)-(NDigit+6)) return -1;
        nc+=sprintf(String+nc,FormatD,_ddSym.Getz());
    }
    return nc;        
}

int UDipole::GetNDipCollums(void) const
{
    switch(_DipType)
    {
    case Magnetic: 
    case Current: 
    case Symmetric:
        return 7;
    case SymmetricPos:
        return 10;
    }
    return 0;
}   

int UDipole::ReadParameters(char *String, int Maxchar) 
/* 
      Read the dipole parameters from the string String[] and store the results in
      this object. Here, the same format as UDipole::PrintParameters() is assumed.

      return the number of bytes read from String[].
             -1 on error
 */
{     
    if(strncmp(String,"Coil",sizeof("Coil")-1)==0)            _DipType=Magnetic;
    else 
        if(strncmp(String,"Current",sizeof("Current")-1)==0)  _DipType=Current;
    else 
        if(strncmp(String,"Full_S.",sizeof("Full_S.")-1)==0)  _DipType=Symmetric;
    else 
        if(strncmp(String,"Half_S.",sizeof("Half_S.")-1)==0)  _DipType=SymmetricPos;
    else
        return -1;
      
    UAnalyzeLine AA(String, Maxchar);
    _xd.Setx(AA.GetNextDouble());
    _xd.Sety(AA.GetNextDouble());
    _xd.Setz(AA.GetNextDouble());
    _dd.Setx(AA.GetNextDouble());
    _dd.Sety(AA.GetNextDouble());
    _dd.Setz(AA.GetNextDouble());
    if(AA.GetError()!=U_OK) return -1;
    if(_DipType!=SymmetricPos)
    {
        _ddSym = _dd;
        return AA.GetNcharRead();
    }

/* The semi-symmetric case*/
    _ddSym.Setx(AA.GetNextDouble());
    _ddSym.Sety(AA.GetNextDouble());
    _ddSym.Setz(AA.GetNextDouble());
    if(AA.GetError()!=U_OK) return -1;
    return AA.GetNcharRead();
}

void UDipole::Mirror(UHeadModel *Hmod) 
{
    Mirror( Hmod->GetSpherePos() );
}

void UDipole::SetSymRight(UHeadModel *Hmod)     
{
    SetSymRight( Hmod->GetSpherePos() );
}

double PosCompare(UDipole Dip1, UDipole Dip2)   
/*
     Return the position error, comparing Dip1 and Dip2
     Note: Dipoles are assumed to be non-symmetric
 */
{
    return  (Dip1.Getx()-Dip2.Getx()).GetNorm();
}

double Distance2(const UDipole& Dip1, const UDipole& Dip2)   
/*
     Return the distance sqyuared between the positions of Dip1 and Dip2
 */
{
    return  (Dip1.Getx()-Dip2.Getx()).GetNorm2();
}

double AmpCompare(UDipole Dip1, UDipole Dip2)   
/*
     Return the amplitude error, comparing Dip1 and Dip2
     Note: Dipoles are assumed to be non-symmetric

 */
{
    double amp1 = Dip1.Getd().GetNorm();
    double amp2 = Dip2.Getd().GetNorm();
    if(amp2<1.e-10)   return 99999999999.;

    return 1.-amp1/amp2;
}

double AngleCompare(UDipole Dip1, UDipole Dip2)
/*
     Return the direction error, comparing Dip1 and Dip2,
            in RADIANS
     Note: Dipoles are assumed to be non-symmetric
 */
{
    double amp1 = Dip1.Getd().GetNorm();
    double amp2 = Dip2.Getd().GetNorm();
    if(amp1<1.e-10 || amp2<1.e-10) return 0;

    double innerprod = Dip1.Getd()&Dip2.Getd()/(amp1*amp2);

    return acos(MAX(-1, MIN(1.,innerprod)));
}

UDipole UAnalyzeLineExt::GetNextDipole()
/* 
      Read the dipole parameters from Pointer and stores the in a dipole-object.
      This code is similar to the ReadParameters()-function of the UDipole-object.
 */
{     
    UDipole Dip;
    const char* OldPointer  = Pointer;
    const char* DTypeString = GetNextString(8);

    if(strcmp(DTypeString,"Coil")==0)        Dip.SetDipoleType(UDipole::Magnetic);
    else 
        if(strcmp(DTypeString,"Current")==0) Dip.SetDipoleType(UDipole::Current);
    else 
        if(strcmp(DTypeString,"Full_S.")==0)  Dip.SetDipoleType(UDipole::Symmetric);
    else 
        if(strcmp(DTypeString,"Half_S.")==0)  Dip.SetDipoleType(UDipole::SymmetricPos);
    else
    {
        Pointer = OldPointer;
        error   = U_ERROR;
        return Dip;
    } 

/* Dipole position*/
    OldPointer = Pointer;
    Dip.Setx(GetNextVector3());
    if(error!=U_OK) 
    {
        Pointer = OldPointer;
        return Dip;
    }

/* Dipole moment*/
    OldPointer = Pointer;
    Dip.Setd(GetNextVector3());
    if(error!=U_OK) 
    {
        Pointer = OldPointer;
        return Dip;
    }

    if(Dip.GetDipoleType()!=UDipole::SymmetricPos)
    {
        Dip.SetdSym(Dip.Getd());
        return Dip;
    }

/* The semi-symmetric case*/
    OldPointer = Pointer;
    Dip.SetdSym(GetNextVector3());
    if(error!=U_OK) 
    {
        Pointer = OldPointer;
        return Dip;
    }
    
    return Dip;
}

UDipole  UAnalyzeLineExt::GetDipole(int icol)
{
    error = U_OK;
    if(MoveToCollumn(icol)!=U_OK) 
    {
        error = U_ERROR;
        return UDipole();
    }
    return  GetNextDipole();
}
