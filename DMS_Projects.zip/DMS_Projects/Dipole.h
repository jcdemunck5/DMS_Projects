#ifndef _DIPOLE_INCLUDED
#define _DIPOLE_INCLUDED


/*
  Update history
  
  Who    When       What
  JdM    15-06-00   Added GetMagnitude() and GetMagnitudeSym()
  JdM    04-12-04   Added StartDipType
  JdM    21-11-07   Added CondModelType, PotInterPolType, SurfInterPolType and BEMSmoothType
*/
#include "Euler.h"

#define MAXDIPOLE_PROPERTIES 128

enum StartDipType
{
    U_SDIP_UNKNOWN,
    U_SDIP_DEFAULT,
    U_SDIP_PREVSAMP,
    U_SDIP_GLOBSEARCH,
    U_SDIP_GLOBSEARCHPREV,
    U_SDIP_FILE
};

enum CondModelType   
{
    U_CONDMOD_UNKNOWN,       // Undefined model
    U_CONDMOD_INFINITEMEDIUM,// Infinite medium
    U_CONDMOD_SPHERE,        // General spherical symmetric model (precise specifications not necessary for MEG)
    U_CONDMOD_HOMSPHERE,     // Homogeneously conducting sphere
    U_CONDMOD_THREESPHERE,   // Three sphere model of Ary et al.
    U_CONDMOD_MULTISPHERE,   // General multi sphere model
    U_CONDMOD_BEM            // Boundary element head model
};          
CondModelType DLL_IO GetCondModelType(int itype);
PMT_CCP       DLL_IO GetCondModelTypeText(CondModelType CT);

enum PotInterPolType         // Determines the way the potential is interpolated
{
    U_POTINTER_UNKNOWN,      // Unknown
    U_POTINTER_CONSTANT,     // Constant on each triangle, unknowm potentials at centre of triangles
    U_POTINTER_LINEAR        // Linear on each triangle, unknowm potentials at corners of triangles
};
PotInterPolType  DLL_IO GetPotInterPolType(int itype);
int              DLL_IO GetPotInterPolInt(PotInterPolType PIPT);
PMT_CCP          DLL_IO GetPotInterTypeText(PotInterPolType PIPT);

enum BEMSmoothType           // Determines whether the matrix elements are smoothed or not
{
    U_SMOOTH_UNKNOWN,        // Unknown
    U_SMOOTH_DEFAULT,        // Take value from Amat (only used with Bvec)
    U_SMOOTH_RAW,            // "Raw" matrix elements
    U_SMOOTH_SMOOTH          // Matrix elements are smoothed over view-points
};
BEMSmoothType    DLL_IO GetBEMSmoothType(int itype);
int              DLL_IO GetBEMSmoothInt(BEMSmoothType BST);
PMT_CCP          DLL_IO GetBEMSmoothTypeText(BEMSmoothType BST);

class UHeadModel;
class DLL_IO UDipole
{
public: 
    enum DipoleType   
    {
        Magnetic,      // Energized coil
        Current,       // "Normal" current dipole
        Symmetric,     // Current dipole with full symmetric counterpart (position and orientation)
        SymmetricPos   // Current dipole with counter part at symmetric position.
    };

    UDipole(UVector3 xd=UVector3(), UVector3 dd=UVector3(), DipoleType DipType = Current);
    UDipole(UVector3 xd, UVector3 dd, UVector3 ddSym); 
    UDipole(double x, double y, double z, double dx, double dy, double dz,  DipoleType DipType = Current);
    UDipole(double x, double y, double z, double dx, double dy, double dz, double dxS, double dyS, double dzS);
    UDipole(double x, double y, double z, double Th, double Fi,  DipoleType DipType = Current);
    UDipole(char *String, int Maxchar);
    UDipole(const UDipole &dip);

    UDipole&         operator=(const UDipole& dip);
    bool             operator==(const UDipole& dip) const;
    ErrorType        GetError(void) const              {return _error;}
    const char*      GetProperties(void) const;

    UVector3         Getx(void) const                  {return _xd;}
    UVector3         Getd() const                      {return _dd;}
    UVector3         GetdSym() const                   {return _ddSym;}
    DipoleType       GetDipoleType(void) const         {return _DipType;}
    double           GetRadAngle(UVector3 SpherePos) const;
    double           GetTanAngle(UVector3 SpherePos) const;
    double           GetRadAngleSym(UVector3 SpherePos) const;
    double           GetRadComp(UVector3 SpherePos) const;
    double           GetRadCompSym(UVector3 SpherePos) const;
    ErrorType        SetTangential(UVector3 SpherePos);

    void             Setx(UVector3 x)                  {_xd = x;}
    void             Setx(const double* Pos)           {_xd = UVector3(Pos);}
    void             Setd(UVector3 d)                  {_dd = d;}
    void             Setd(const double *Dir);           
    void             Setd(UVector3 Spos, double TanAngle, double Mag);
    void             SetdSym(UVector3 d)               {_ddSym = d;}
    void             SetDipoleType(DipoleType DipType) {_DipType = DipType;}
    void             SetStrength(double Sleft, double Sright=0);
    UDipole          Transform(const UEuler& euler);
    void             Mirror(UVector3 SpherePos);
    void             Mirror(UHeadModel *Hmod);
    void             SetSymRight(UVector3 SpherePos);
    void             SetSymRight(UHeadModel *Hmod);
    int              PrintParameters(char *String, int Maxchar=100, int Dipno=-1, bool ManyDigits=false) const;
    int              PrintParameters(char *String, int Maxchar    , int Dipno   , int  NDigit) const;
    int              GetNDipCollums(void) const;
    int              ReadParameters(char *String, int Maxchar);
    double           GetMagnitude(void) const          {return _dd.GetNorm();}  
    double           GetMagnitudeSym(void) const       {return _ddSym.GetNorm();}  
    void             Normalize(void)                   {SetStrength(1., 1.);}
    virtual double   GetResidualError(void) const {return 0.;}
    virtual double   GetTime(void)          const {return 0.;}

protected:
    UVector3         _xd;     // Position
    UVector3         _dd;     // Orientation
    UVector3         _ddSym;  // Orientation of symmetric dipole of type SymmetricPos
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:    
    static char Properties[MAXDIPOLE_PROPERTIES];
    ErrorType   _error;  // General Error Flag
    DipoleType  _DipType;// Dipole Type
};

double Distance2(const UDipole& Dip1, const UDipole& Dip2);
double PosCompare(UDipole Dip1, UDipole Dip2);
double AmpCompare(UDipole Dip1, UDipole Dip2);
double AngleCompare(UDipole Dip1, UDipole Dip2);

const char* GetDipoleTypeText(UDipole::DipoleType DType);

#endif // _DIPOLE_INCLUDED
