/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    23-07-04   creation, splitting oof from file QMarkers3DDial.cpp
  JdM    22-11-04   Bug fix: MergeDipolesFromFile(). Several bug fixes.
  JdM    07-12-04   Bug Fix: SaveDipoles() Transform to MRI-coordinates before saving
  JdM    20-03-05   Added GetNdipComponents(), GetDipoleComponentName()
                    Use UString
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    28-02-08   GetDipoleName(). Return UString (instead of const char*)
  JdM    12-03-08   Bug fix: GetDipolesAsSourceGrid(), GetDipoleComponentName(), SaveDipoles(). Use UString (instead of const char*)
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
*/
 
 
#include <string.h>
#include "DipoleEditList.h"
#include "AnalyzeLine.h"
#include "Grid.h"

void UDipoleEdit::SetAllMembersDefault(void)
{
    Rotating = false;
    Name     = UString();
}
void UDipoleEdit::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
}

UDipoleEdit::UDipoleEdit(UVector3 xd, UVector3 dd, const char* DipName, bool rot) :
    UDipole(xd, dd)
{
    SetAllMembersDefault();
    Name = GetDefaultDipName();
    if(DipName) Name = UString(DipName);
    Rotating = rot;
}

UDipoleEdit::~UDipoleEdit()
{
    DeleteAllMembers(U_OK);
}

UDipoleEdit& UDipoleEdit::operator=(const UDipole& Dip)
{
    static UDipoleEdit DefDip;
    if(this==NULL || &Dip==NULL) return DefDip;

    UDipole::operator=(Dip);
    Name = GetDefaultDipName();

    return *this;
}

UDipoleEdit& UDipoleEdit::operator=(const UDipoleEdit& DE)
{
    static UDipoleEdit DefDip;
    if(this==NULL || &DE==NULL) return DefDip;
    if(this==&DE)               return *this;

    UDipole::operator=((UDipole)DE);

    Rotating = DE.Rotating;
    Name     = DE.Name;
    return *this;
}

UString UDipoleEdit::GetName() const
{
    return Name;
}

bool UDipoleEdit::GetRotating() const
{
    return Rotating;
}

ErrorType UDipoleEdit::SetName(UString NewName)
{
    Name = GetDefaultDipName();
    if(NewName.IsNULL()==false) Name = NewName;
    return U_OK;
}

ErrorType UDipoleEdit::SetRotating(bool rot)
{
    Rotating = rot;
    return U_OK;
}

int UDipoleEdit::GetNdipComponents(void) const
{
    if(Rotating==true)
    {
        switch(GetDipoleType())
        {
        case UDipole::Current:      return 3;
        case UDipole::Symmetric:    return 4;
        case UDipole::SymmetricPos: return 6;
        }
    }
    else
    {
        switch(GetDipoleType())
        {
        case UDipole::Current:      return 1;
        case UDipole::Symmetric:    return 2;
        case UDipole::SymmetricPos: return 2;
        }
    }
    return 0;
}

UString UDipoleEdit::GetDefaultDipName(void) const
{
    UString DipName("Error");
    
    if(     GetDipoleType()==UDipole::Current)      DipName = UString("Cur_");
    else if(GetDipoleType()==UDipole::Symmetric)    DipName = UString("Sym_");
    else if(GetDipoleType()==UDipole::SymmetricPos) DipName = UString("SemSym_");

    if(Rotating==false) DipName += UString("Fix");
    else                DipName += UString("Rot");
    return DipName;
}
UString UDipoleEdit::GetDefaultDipName(int dipnum) const
{
    return GetDefaultDipName() + UString(dipnum, "_%d");
}

UString UDipoleEdit::GetDipoleComponentName(int idip, int icomp) const
{
    if(icomp<0 || icomp>=GetNdipComponents()) return UString(icomp, "ERROR_DipComp%d");
    UString Name = GetDefaultDipName(idip);

    if(GetRotating()==true)
    {
        switch(GetDipoleType())
        {
        case UDipole::Current:      
            if(icomp==0) return Name + UString("_x");
            if(icomp==1) return Name + UString("_y");
            if(icomp==2) return Name + UString("_z");
            break;
        case UDipole::Symmetric: 
            if(icomp==0) return Name + UString("_L_x");
            if(icomp==1) return Name + UString("_L_y");
            if(icomp==2) return Name + UString("_L_z");
            if(icomp==3) return Name + UString("_R");
            break;
        case UDipole::SymmetricPos: 
            if(icomp==0) return Name + UString("_L_x");
            if(icomp==1) return Name + UString("_L_y");
            if(icomp==2) return Name + UString("_L_z");
            if(icomp==3) return Name + UString("_R_x");
            if(icomp==4) return Name + UString("_R_y");
            if(icomp==5) return Name + UString("_R_z");
            break;
        }
    }
    else
    {
        switch(GetDipoleType())
        {
        case UDipole::Current:      
            return Name;
            break;
        case UDipole::Symmetric:    
            if(icomp==0) return Name + UString("_L");
            if(icomp==1) return Name + UString("_R");
            break;
        case UDipole::SymmetricPos: 
            if(icomp==0) return Name + UString("_L");
            if(icomp==1) return Name + UString("_R");
            break;
        }
    }
    return UString("Unknown");
}

void UDipoleEditList::SetAllMembersDefault(void)
{
    error        =  U_OK;
    ActiveDipole = -1;
    Ndip         =  0;
    ShowDipoles  =  false;
    Nas          =  UVector3( 10.,  0.,0.);
    Lef          =  UVector3(  0., 10.,0.);
    Rig          =  UVector3(  0.,-10.,0.);
}
void UDipoleEditList::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UDipoleEditList::UDipoleEditList()
{
    SetAllMembersDefault();
}

UDipoleEditList::~UDipoleEditList()
{
    DeleteAllMembers(U_OK);
}

ErrorType UDipoleEditList::SetNLR(UVector3 N, UVector3 L, UVector3 R)
{
    if( ((L-N)^(R-N)).GetNorm2()<1.e-6)
    {
        CI.AddToLog("ERROR: UDipoleEditList::SetNLR(). N, L and R are co-linear. \n");
        return U_ERROR;
    }
    Nas   =  N;
    Lef   =  L;
    Rig   =  R;
    return U_OK;
}

ErrorType UDipoleEditList::MergeDipolesFromFile(UFileName DipFile)
{
    FILE* fp = fopen(DipFile, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Cannot open dipole file: %s. \n", DipFile.GetFullFileName());
        return U_ERROR;
    }

    char line[200];
    GetLine(line, sizeof(line), fp);
    if(strncmp(line, "DipSourceFile", 13))
    {
        fclose(fp);
        CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid dipole file. First line = %s     . \n", line);
        return U_ERROR;
    }
    GetLine(line, sizeof(line), fp);
    UAnalyzeLine AA(line, sizeof(line));
    if(AA.IsIdentifierIs("Version",true)==false ||
       AA.GetNextDouble(1000.)>1.0)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid dipole file version. Second line = %s     . \n", line);
        return U_ERROR;
    }

    UVector3 NewN;
    UVector3 NewL;
    UVector3 NewR;
    UEuler   ToNLR;
    bool     MarkersFound = false;
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsComment()==true || AA.IsEmptyLine()==true) continue;
        if(AA.IsIdentifierIs("Nasion",true)==true)
        {
            double X  = AA.GetNextDouble(1000.);
            double Y  = AA.GetNextDouble(1000.);
            double Z  = AA.GetNextDouble(1000.);
            if(fabs(X)>=100. || fabs(Y)>=100. || fabs(Z)>=100.)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid Nasion marker (%f, %f, %f) \n", X, Y, Z);
                return U_ERROR;
            }
            NewN = UVector3(X, Y, Z);
            continue;
        }
        if(AA.IsIdentifierIs("Left",true)==true)
        {
            double X  = AA.GetNextDouble(1000.);
            double Y  = AA.GetNextDouble(1000.);
            double Z  = AA.GetNextDouble(1000.);
            if(fabs(X)>=100. || fabs(Y)>=100. || fabs(Z)>=100.)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid Left marker (%f, %f, %f) \n", X, Y, Z);
                return U_ERROR;
            }
            NewL = UVector3(X, Y, Z);
            continue;
        }
        if(AA.IsIdentifierIs("Right",true)==true)
        {
            double X  = AA.GetNextDouble(1000.);
            double Y  = AA.GetNextDouble(1000.);
            double Z  = AA.GetNextDouble(1000.);
            if(fabs(X)>=100. || fabs(Y)>=100. || fabs(Z)>=100.)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid Right marker (%f, %f, %f) \n", X, Y, Z);
                return U_ERROR;
            }
            NewR = UVector3(X, Y, Z);
            continue;
        } 
        if(MarkersFound==false && NewN!=UVector3() && NewL!=UVector3() && NewR!=UVector3())
        {
            ToNLR        = UEuler(NewN, NewL, NewR);
            MarkersFound = true;
            Nas   = NewN;
            Lef   = NewL;
            Rig   = NewR;
        }
        if(AA.IsIdentifierIs("DipoleRot",true)==true)
        {
            if(MarkersFound==false)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). DipoleRot given before all NLR markers. \n");
                return U_ERROR;
            }
            double X  = AA.GetNextDouble(1000.);
            double Y  = AA.GetNextDouble(1000.);
            double Z  = AA.GetNextDouble(1000.);
            if(fabs(X)>=100. || fabs(Y)>=100. || fabs(Z)>=100.)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid dipole position (%f, %f, %f) \n", X, Y, Z);
                return U_ERROR;
            }
            UVector3     DipPos = ToNLR.xfm(UVector3(X, Y, Z));
            const char*  Name   = AA.GetNextString(10);
            UDipoleEdit  Dip(DipPos, UVector3(0.,0.,1), Name, true);

            if(AddDipole(Dip)!=U_OK)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Adding rotating dipole. \n");
                return U_ERROR;
            }
        }
        if(AA.IsIdentifierIs("Dipole",true)==true)
        {
            if(MarkersFound==false)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Dipole given before all NLR markers. \n");
                return U_ERROR;
            }
            double X  = AA.GetNextDouble(1000.);
            double Y  = AA.GetNextDouble(1000.);
            double Z  = AA.GetNextDouble(1000.);
            if(fabs(X)>=100. || fabs(Y)>=100. || fabs(Z)>=100.)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Invalid dipole position (%f, %f, %f) \n", X, Y, Z);
                return U_ERROR;
            }
            UVector3     DipPos = ToNLR.xfm(UVector3(X, Y, Z));
            X  = AA.GetNextDouble(12345.);
            Y  = AA.GetNextDouble(12345.);
            Z  = AA.GetNextDouble(12345.);
            if(X==12345. || Y==12345. || Z==12345.)
                CI.AddToLog("WARNING: UDipoleEditList::MergeDipolesFromFile(). Invalid dipole moment??? (%f, %f, %f) \n", X, Y, Z);
            UVector3     DipMom = ToNLR.xfm(UVector3(X, Y, Z), true);
            const char*  Name   = AA.GetNextString(10);
            UDipoleEdit  Dip(DipPos, DipMom, Name, false);

            if(AddDipole(Dip)!=U_OK)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UDipoleEditList::MergeDipolesFromFile(). Adding fixed dipole. \n");
                return U_ERROR;
            }
        }
    }

    fclose(fp);
    return U_OK;
}

ErrorType UDipoleEditList::SaveDipoles(UFileName DipFile) const
{
    UFileName SourceFile(DipFile);
    SourceFile.ReplaceExtension(".txt");
    FILE* fp = fopen(SourceFile, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UDipoleEditList::SaveDipoles(). Opening dipole source file %s for writing.\n", SourceFile.GetFullFileName());
        return U_ERROR;
    }
    fprintf(fp,"DipSourceFile      // File identifier\n");
    fprintf(fp,"Version = 1.0      // Version Number \n");
    fprintf(fp,"//\n");
    fprintf(fp,"// File created by UDipoleEditList::SaveDipoles().\n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"//\n");
    fprintf(fp,"// This file is meant to provide signal space sources for various applications . \n");
    fprintf(fp,"//\n");
    fprintf(fp,"// Position parameters are all in MR coordinates. To convert them to Nasion ear coordinates, \n");
    fprintf(fp,"// the MR coordinates of the Nasion, Left and Right pre-auricular points must also be \n");
    fprintf(fp,"// given in this file, in the same MR coordinates. \n");
    fprintf(fp,"//\n");
    fprintf(fp,"// Markers in MRI coordinates: \n");
    fprintf(fp,"//\n");
    fprintf(fp,"Nasion = %8.3f  %8.3f  %8.3f  \n", Nas.Getx(), Nas.Gety(), Nas.Getz());
    fprintf(fp,"Left   = %8.3f  %8.3f  %8.3f  \n", Lef.Getx(), Lef.Gety(), Lef.Getz());
    fprintf(fp,"Right  = %8.3f  %8.3f  %8.3f  \n", Rig.Getx(), Rig.Gety(), Rig.Getz());
    fprintf(fp,"//\n");
    fprintf(fp,"// Dipoles in MRI coordinates:\n");
    fprintf(fp,"//\n");

    UEuler ToNLR = UEuler(Nas, Lef, Rig);
    UEuler ToMRI = ToNLR.GetInverse();

    for(int idip=0; idip<Ndip; idip++)
    {
        UVector3 x = ToMRI.xfm(this->GetDipolePosition(idip));
        UString Name = this->GetDipoleName(idip);

        if(this->GetDipoleRotation(idip)==true)
        {
            fprintf(fp,"DipoleRot  = %8.3f  %8.3f  %8.3f  %s \n", x.Getx(), x.Gety(), x.Getz(), (const char*)Name);
        }
        else
        {
            UVector3 m = ToMRI.xfm(this->GetDipoleMoment(idip), true);
            m.Normalize();
            fprintf(fp,"Dipole  = %8.3f  %8.3f  %8.3f ", x.Getx(), x.Gety(), x.Getz());
            fprintf(fp,"    %8.3f  %8.3f  %8.3f  %s \n", m.Getx(), m.Gety(), m.Getz(), (const char*)Name);
        }
    }
    fclose(fp);
    return U_OK;
}

int UDipoleEditList::GetNdip() const
{
    return Ndip;
}

int UDipoleEditList::GetActiveDipoleIndex() const
{
    return ActiveDipole;
}

bool UDipoleEditList::GetActiveDipoleRotation(void) const
{
    return GetDipoleRotation(ActiveDipole);
}

UDipole UDipoleEditList::GetActiveDipole() const
{
    if(ActiveDipole<0 || ActiveDipole>=Ndip) return UDipole();

    return (UDipole)DipArr[ActiveDipole];
}

UDipole UDipoleEditList::GetActiveDipoleRef() const
{
    return GetDipoleRef(ActiveDipole);
}

UVector3 UDipoleEditList::GetDipolePosition(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipolePosition(). Index out of range: idip = %d .\n", idip);
        return UVector3();
    }
    return DipArr[idip].Getx();
}

UDipole UDipoleEditList::GetDipole(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipole(). Index out of range: idip = %d .\n", idip);
        return UDipole();
    }
    return DipArr[idip];
}

UDipole UDipoleEditList::GetDipoleRef(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipole(). Index out of range: idip = %d .\n", idip);
        return UDipole();
    }
    UEuler  NasionEarToRef = UEuler(Nas, Lef, Rig).GetInverse();
    UDipole Dip            = GetDipole(idip);
    return Dip.Transform(NasionEarToRef);
}

UVector3 UDipoleEditList::GetDipoleMoment(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipoleMoment(). Index out of range: idip = %d .\n", idip);
        return UVector3();
    }
    return DipArr[idip].Getd();
}

UString UDipoleEditList::GetDipoleName(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipoleName(). Index out of range: idip = %d .\n", idip);
        return "ERROR Dip";
    }
    return DipArr[idip].GetName();
}


bool UDipoleEditList::GetDipoleRotation(int idip) const
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipoleRotation(). Index out of range: idip = %d .\n", idip);
        return false;
    }
    return DipArr[idip].GetRotating();
}

ErrorType UDipoleEditList::AddDipole(UDipole Dip)
{
    if(Ndip>=MAX_NDIPOLES)
    {
        CI.AddToLog("ERROR: UDipoleEditList::AddDipole(). Too many dipoles. Ndip = %d .\n", Ndip);
        return U_ERROR;
    }
    ActiveDipole = Ndip;
    Ndip++;
    DipArr[ActiveDipole] = Dip;
    DipArr[ActiveDipole].SetRotating(false);
    DipArr[ActiveDipole].SetName(UString("MirDip"));

    return U_OK;
}

ErrorType UDipoleEditList::AddDipole(UDipoleEdit Dip) // private
{
    if(Ndip>=MAX_NDIPOLES)
    {
        CI.AddToLog("ERROR: UDipoleEditList::AddDipole(). Too many dipoles. Ndip = %d .\n", Ndip);
        return U_ERROR;
    }
    ActiveDipole         = Ndip;
    DipArr[ActiveDipole] = Dip;
    Ndip++;
    return U_OK;
}

ErrorType UDipoleEditList::DeleteActiveDipole()
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    
    for(int idip=ActiveDipole; idip<Ndip-1; idip++)
        DipArr[idip] = DipArr[idip+1];

    Ndip--;
    return U_OK;
}

ErrorType UDipoleEditList::RenameActiveDipole(const char* NewName)
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;

    return DipArr[ActiveDipole].SetName(UString(NewName));
}

ErrorType UDipoleEditList::PrevDipole()
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    ActiveDipole--;
    if(ActiveDipole<0) ActiveDipole = Ndip-1;
    return U_OK;
}

ErrorType  UDipoleEditList::NextDipole()
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    ActiveDipole++;
    if(ActiveDipole>=Ndip) ActiveDipole = 0;
    return U_OK;

}
ErrorType UDipoleEditList::SetActiveDipole(int idip)
{
    if(idip<0 || idip>=Ndip) 
    {
        CI.AddToLog("ERROR: UDipoleEditList::SetActiveDipole(). Index out of range: idip = %d .\n", idip);
        return U_ERROR;
    }
    ActiveDipole = idip;
    return U_OK;
}

ErrorType UDipoleEditList::SetActiveDipole(UDipole Dip)
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    DipArr[ActiveDipole].Setx(Dip.Getx());
    DipArr[ActiveDipole].Setd(Dip.Getd());
    return U_OK;
}

ErrorType UDipoleEditList::SetActiveDipolePosition(UVector3 Pos)
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    DipArr[ActiveDipole].Setx(Pos);
    return U_OK;
}

ErrorType UDipoleEditList::SetActiveDipoleMoment(UVector3 Mom)
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    DipArr[ActiveDipole].Setd(Mom);
    return U_OK;
}

ErrorType UDipoleEditList::SetActiveDipoleRef(UDipole DipRef)
{
    UEuler  RefToNasionEar = UEuler(Nas, Lef, Rig);
    UDipole Dip            = DipRef.Transform(RefToNasionEar);
    return SetActiveDipole(Dip);
}

ErrorType UDipoleEditList::SetActiveDipoleRotation(bool rot)
{
    if(Ndip<=0 || ActiveDipole<0) return U_ERROR;
    return DipArr[ActiveDipole].SetRotating(rot);
}

ErrorType  UDipoleEditList::SetShowDipoles(bool show)
{
    ShowDipoles = show;
    return U_OK;
}

UGrid* UDipoleEditList::GetDipolesAsSourceGrid(void) const
{
    if(Ndip<=0)
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Number of dipoles invalid (Ndip=%d) .\n", Ndip);
        return NULL;
    }

    UGrid* SourceGrid = new UGrid();
    if(SourceGrid==NULL || SourceGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Creating empty source grid .\n");
        return NULL;
    }

    for(int idip=0; idip<Ndip; idip++)
    {
        UVector3  x        = DipArr[idip].Getx();
        UVector3  n        = DipArr[idip].Getd();
        UString   BaseName = DipArr[idip].GetName();

        if(DipArr[idip].GetRotating()==false)
        {
            if(n==UVector3())
            {
                CI.AddToLog("WARNING: UDipoleEditList::GetDipolesAsSourceGrid(). Skipping dipole with NULL vector orientation. \n");
                continue;
            }
            n.Normalize();

            USensor S(x, n, UVector3(), USensor::U_SEN_VECTOR, (const char*)BaseName);
            if(SourceGrid->AddSensor(S)!=U_OK)
            {
                delete SourceGrid; SourceGrid = NULL;
                CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Adding source to source grid .\n");
                return NULL;
            }
            continue;
        }
        else
        {
            USensor S(x, UVector3(1.,0.,0.), UVector3(), USensor::U_SEN_VECTOR, (const char*)BaseName);
            S.AddToName("_x");
            if(SourceGrid->AddSensor(S)!=U_OK)
            {
                delete SourceGrid; SourceGrid = NULL;
                CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Adding source to source grid .\n");
                return NULL;
            }
            S = USensor(x, UVector3(0.,1.,0.), UVector3(), USensor::U_SEN_VECTOR, (const char*)BaseName);
            S.AddToName("_y");
            if(SourceGrid->AddSensor(S)!=U_OK)
            {
                delete SourceGrid; SourceGrid = NULL;
                CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Adding source to source grid .\n");
                return NULL;
            }
            S = USensor(x, UVector3(0.,0.,1.), UVector3(), USensor::U_SEN_VECTOR, (const char*)BaseName);
            S.AddToName("_z");
            if(SourceGrid->AddSensor(S)!=U_OK)
            {
                delete SourceGrid; SourceGrid = NULL;
                CI.AddToLog("ERROR: UDipoleEditList::GetDipolesAsSourceGrid(). Adding source to source grid .\n");
                return NULL;
            }
            continue;
        }
    }
    return SourceGrid;
}

