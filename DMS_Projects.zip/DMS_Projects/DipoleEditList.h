#ifndef DIPOLEEDITLIST_H
#define DIPOLEEDITLIST_H


#define MAX_NDIPOLES  64

#include "Dipole.h"
#include "FileName.h"
#include "String.h"

class UGrid;
class DLL_IO UDipoleEdit : public UDipole
{
public:
    UDipoleEdit(UVector3 xd=UVector3(), UVector3 dd=UVector3(), const char* DipName=NULL, bool rot = false);
    ~UDipoleEdit();

    UDipoleEdit&    operator=(const UDipole& Dip);
    UDipoleEdit&    operator=(const UDipoleEdit& DE);
    UString         GetName(void) const;
    bool            GetRotating(void) const;

    ErrorType       SetName(UString NewName);
    ErrorType       SetRotating(bool rot);
    int             GetNdipComponents(void) const;
    UString         GetDefaultDipName(void) const;
    UString         GetDefaultDipName(int dipnum) const;
    UString         GetDipoleComponentName(int idip, int icomp) const;

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    UString         Name;
    bool            Rotating;
};

class DLL_IO UDipoleEditList
{
public:
    UDipoleEditList();
    ~UDipoleEditList();

    ErrorType       SetNLR(UVector3 N, UVector3 L, UVector3 R);
    ErrorType       MergeDipolesFromFile(UFileName DipFile);
    ErrorType       SaveDipoles(UFileName DipFile) const;

    int             GetNdip() const;
    int             GetActiveDipoleIndex() const;
    UDipole         GetActiveDipole() const;
    UDipole         GetActiveDipoleRef() const;

    bool            GetShowDipoles(void) const {return ShowDipoles;}
    UVector3        GetDipolePosition(int idip) const;
    UVector3        GetDipoleMoment(int idip) const;
    UString         GetDipoleName(int idip) const;
    bool            GetDipoleRotation(int idip) const;
    bool            GetActiveDipoleRotation(void) const;
    UDipole         GetDipole(int idip) const;
    UDipole         GetDipoleRef(int idip) const;

    ErrorType       AddDipole(UDipole Dip);
    ErrorType       DeleteActiveDipole();
    ErrorType       RenameActiveDipole(const char* NewName);
    ErrorType       PrevDipole();
    ErrorType       NextDipole();
    ErrorType       SetActiveDipole(int idip);
    ErrorType       SetActiveDipole(UDipole Dip);
    ErrorType       SetActiveDipoleRef(UDipole DipRef);
    ErrorType       SetActiveDipoleRotation(bool rot);
    ErrorType       SetActiveDipolePosition(UVector3 Pos);
    ErrorType       SetActiveDipoleMoment(UVector3 Mom);
    ErrorType       SetShowDipoles(bool show);

    UGrid*          GetDipolesAsSourceGrid(void) const;

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;
    UVector3        Nas;   // (Default) coordinates of Nasion/Left/Right marker
    UVector3        Lef;
    UVector3        Rig;

    int             ActiveDipole;
    int             Ndip;
    UDipoleEdit     DipArr[MAX_NDIPOLES];
    bool            ShowDipoles;

    ErrorType       AddDipole(UDipoleEdit Dip);
};
#endif // DIPOLEEDITLIST_H
