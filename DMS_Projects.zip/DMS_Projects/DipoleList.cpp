/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     The intention of this object is to create (from scratch) an array of       */
/*     dipoles, typically in programs where dipoles are computed from M/EEG data. */
/*     With UDipoleList, you can, e.g. determine the position statistics of a     */
/*     cloud of dipoles.                                                          */
/*                                                                                */
/*     A related (and derived) object is UDipoleList, which is intended to be     */
/*     created from a dipole file (created by e.g. FitDipoles). UDipoleList       */
/*     also contains information on the fit-error, time, etc.                     */
/*                                                                                */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    13-03-99	creation 
  JdM    18-03-99	BUG Fix: Compute Minx and Maxx for (semi) symmetric dipoles
  JdM    19-03-99   Added default constructor and the function GetDipoles()
  GdV	 22-04-99   Adapted to Unix
  JdM	 02-06-99   Added more comments in properties[], when calling ReadDipoles()
  JdM    07-06-99   Added GetEulerArray(int nADC)
AdJ/JdM  10-06-99   Added GetOrientationList() (again)
  JdM    09-08-99   Added WriteXDR()
  JdM    17-08-99   Move XDR-functions to derived class: UDipolePlotList()
  JdM    28-08-99   Added more statistics to dipole positions and orientations: GetStatistics() 
AdJ/JdM  30-09-99   BUG FIX: GetDipStat() angle converted to degrees
  JdM    30-09-99   BUG FIX: ReadDipoles() : Skip non-comment text lines
  JdM    25-01-00   Complete revision: Use an array of pointers to dipoles instead of an array of dipoles
  JdM    01-02-00   Re-implemented GetDipoles(), according to changes made on 25-01-00
                    Added SetDipole().
  JdM    02-02-00   Bug fix in GetPointsNLR(), array boundaries when nADC==3
  JdM    09-02-00   Allow for sample times in double format
  JdM    11-02-00   MaxError<0 means: take all dipoles
  JdM    30-04-00   Added defintion of protected UDipFileHeader()-object
  JdM    15-06-00   Remove constructor by filename. This part is moved to UDipoleMoveList()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    19-09-00   Bug fix: destructor, test DipoleArray!=NULL
  JdM    03-10-00   GetPointsNLR(). Extend to cases nADC=1 or nADC=2
JdM/AdJ  13-02-01   Removed some functions from UDipoleMoveList() to here, such that
                    WriteXDR() can now be calle from UDipoleList() directly.
JdM/AdJ  16-02-01   Protect some functions for zero number of dipoles
  JdM    13-03-01   Move all Plot functions to base class: UDipolePlotList() in DipolePlotList.cpp
  JdM    06-04-01   Extend the information provided by GetDipStat()
  JdM    16-01-02   Allow 16 bytes in comment header of GetDipStat()
  JdM    25-08-02   Derive UDipoleList from UCluster, so that dipole can be clusterd based on distance information
  JdM    24-12-02   Add several distance types to be used with clustering
  JdM    06-02-03   Bug Fix: GetDistance2() computing distances in case of U_CLUSTDIST_ORI and U_CLUSTDIST_BOTH
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-01-05   GetDipStat(): use UString()
                    Remove (obsolete) Properties
                    Add AddDipole()
  JdM    05-01-05   Added DeleteAllMembers() and SetAllMembersDefault()
*/


#include <string.h>
#include <stdlib.h>

#include "DipoleList.h"
#include "AnalyzeLineExt.h"
#include "Directory.h"
#include "Field.h"
#include "Sensor.h"
#include "PatTree.h"

/* Inititalize static const parameters. */

static int DubCompare(const void* Dub1, const void* Dub2)
{
    if(*(double*)Dub1  <  *(double*)Dub2) return -1;
    if(*(double*)Dub1  >  *(double*)Dub2) return  1;
    return 0;
}

void UDipoleList::SetAllMembersDefault(void)
{
    error         = U_OK;
    DipoleArray   = NULL;
    Ndip          = 0;
    NdipAllocated = 0;

    Minx          = UVector3();
    Maxx          = UVector3();
    DistType      = U_CLUSTDIST_POS;
}

void UDipoleList::DeleteAllMembers(void)
{
    if(DipoleArray)
        for(int n=0; n<NdipAllocated; n++) delete DipoleArray[n];
    delete[] DipoleArray;
    SetAllMembersDefault();
}

UDipoleList::UDipoleList() 
{
    SetAllMembersDefault();
}

UDipoleList::UDipoleList(int Ndp, UDipole::DipoleType DT) 
{
    SetAllMembersDefault();
    DipoleArray   = new UDipole*[Ndp];
    if(DipoleArray==NULL )
    {
        error = U_ERROR;
        return;
    }

    for(int n=0; n<Ndp; n++) 
    {
        DipoleArray[n] = new UDipole(UVector3(), UVector3(), DT);
        if(DipoleArray[n]==NULL)
        {
            DeleteAllMembers();
            error = U_ERROR;
            return;
        }
    }
    Ndip          = Ndp;
    NdipAllocated = Ndp;

    UpdateMinMax();
    DistType     = U_CLUSTDIST_POS;
}

UDipoleList::~UDipoleList() 
{
    DeleteAllMembers();
}

ErrorType UDipoleList::AddDipole(UDipole Dip)
{
    if(NdipAllocated-Ndip<1) // Allocate new memory for dip
    {
        int NewAlloc = 2*NdipAllocated+2;
        if(NewAlloc<100)   NewAlloc = 100;
        if(NewAlloc>10000) NewAlloc = NdipAllocated+10000; 

        UDipole** NewDipoleArray = new UDipole*[NewAlloc];
        if(NewDipoleArray==NULL)
        {
            CI.AddToLog("WARNING: UDipoleList::AddDipole(). Re-allocating memory, NdipAllocated = %d, Ndip = %d  .\n", NdipAllocated, Ndip);
            return U_ERROR;
        }
        for(int n=0;    n<Ndip;     n++) NewDipoleArray[n] = DipoleArray[n];
        for(int n=Ndip; n<NewAlloc; n++) NewDipoleArray[n] = NULL;

        delete[] DipoleArray;    DipoleArray = NewDipoleArray;
        NdipAllocated = NewAlloc;
    }
    DipoleArray[Ndip++] = new UDipole(Dip);
    if(DipoleArray[Ndip-1]==NULL) 
    {
        CI.AddToLog("WARNING: UDipoleList::AddDipole(). Creating new dipole, Ndip = %d .\n", Ndip);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UDipoleList::ReAllocateMemory(void)
/*
    Reduce the amount of allocated memory,
    such that on return Ndip == NdipAllocated
*/
{
    if(NdipAllocated==Ndip) return U_OK;

    UDipole** NewDipoleArray = new UDipole*[Ndip];
    if(NewDipoleArray==NULL)
    {
        CI.AddToLog("WARNING: UDipoleList::ReAllocateMemory(). Re-allocating memory, NdipAllocated = %d, Ndip = %d  .\n", NdipAllocated, Ndip);
        return U_ERROR;
    }

    for(int n=0; n<Ndip; n++) NewDipoleArray[n] = DipoleArray[n];
    delete[] DipoleArray;    DipoleArray = NewDipoleArray;
    NdipAllocated = Ndip;

    return U_OK;
}

double UDipoleList::GetDistance2(int i1, int i2) 
/*
    Return the "distance" between dipoles i1 and i2, according to the previously set
    parameter DistType. This function is meant for building ditance tables for hierachical
    clustering of dipole sets.
 */
{
    if(DipoleArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleList::GetDistance2(). DipoleArray not set. \n");
        return 0.;
    }
    if(i1<0 || i2<0 || i1>=Ndip || i2>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleList::GetDistance2(). Arguments out of range: i1=%d i2=%d \n",i1,i2);
        return 0.;
    }
    UVector3 Ori1, Ori2;
    double   Cos = 0.;
    switch(DistType)
    {
    case U_CLUSTDIST_POS:  /* Distance between dipole positions */
        return Distance2(*DipoleArray[i1], *DipoleArray[i2]);

    case U_CLUSTDIST_ORI:     /* 1-cos of angle between dipole orientations (more or les proportional to angle between dipole orientations) */
    case U_CLUSTDIST_SIN2ORI: /* sin**2 of angle between dipole orientations (ignores sign of dipole orientation) */
        Ori1 = DipoleArray[i1]->Getd();
        Ori2 = DipoleArray[i2]->Getd();
        Ori1.Normalize();     /* Make it a unit vector*/
        Ori2.Normalize();
        Cos = Ori1&Ori2;      /* Compute inner product: x1*x2 + y1*y2 + z1*z2 */
        if(DistType==U_CLUSTDIST_ORI) return 1.-Cos;
        return 1.-Cos*Cos;
    }
    CI.AddToLog("ERROR: UDipoleList::GetDistance2(). Invalid distance type (%d). \n", DistType);
    return 0.;
}

UDipole UDipoleList::GetDipole(int k)  const
{
    if(k<0 || k>=Ndip) return UDipole();
    return *DipoleArray[k];
}

UVector3* UDipoleList::GetPositionList(int *Npoints) const
{
    *Npoints=0;
    for(int n=0; n<Ndip; n++)
    {
        (*Npoints)++;
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos) (*Npoints)++;
    }

    UVector3* Positions = new UVector3[*Npoints];
    if(Positions == NULL) return NULL;

    int k =0;
    for(int n=0; n<Ndip; n++)
    {
        Positions[k++] = DipoleArray[n]->Getx();
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos) Positions[k++] = DipoleArray[n]->Getx().GetMirrorY();
    }
    return Positions;
}

UVector3* UDipoleList::GetOrientationList(int *Npoints) const
{
    *Npoints=0;
    for(int n=0; n<Ndip; n++)
    {
        (*Npoints)++;
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos) (*Npoints)++;
    }

    UVector3* Orientations = new UVector3[*Npoints];
    if(Orientations == NULL) return NULL;

    int k =0;
    for(int n=0; n<Ndip; n++)
    {
        Orientations[k++] = DipoleArray[n]->Getd();
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos) Orientations[k++] = DipoleArray[n]->Getd().GetMirrorY();
    }
    return Orientations;
}



UVector3* UDipoleList::GetPointsNLR(UVector3 *NLR, int nADC, char* Statistics, int ncPerPoint, double Tip) const
/*
    Return an array of points corresponding to every fourth coil. This coil is expressed
    in the Nasion, Left Ear, Right Ear coordinate system, assuming that the positions
    of the dipoles in the DipoleArray are ordered as follows:
    (N0,L0, R0, PointA0,...,PointQ1, N1, L1, R1, Point1,...,PointQ1,....) etc.
    So, the dipoles correspond to nADC channels per trial.

    if(NLR) The average positions of the Nasion, Left and Right coils are computed and stored in 
            NLR[].
    if(Statistics) print some statistical information int it, using at maximum ncPerPoint
            characters per point.

    Tip is used to correct the position of the fourth coil for the tip length.

    Note: if nADC==1, or nADC==2, no transformation to NLR system is applied
 */
{
    if(nADC<=0)   return NULL;
    if(Ndip%nADC) return NULL;

    if(nADC<3)
    {
        if(Statistics)  memset(Statistics, 0, Ndip*ncPerPoint/nADC);

        UVector3* Points  = new UVector3[Ndip];
        if(!Points)  return NULL;

        CI.AddToLog("WARNING: UDipoleList::GetPointsNLR(). There are %d ADC channels. Dipoles not converted to NLR coordinates.\n");
        for(int ipoint=0; ipoint < Ndip; ipoint++)
        {
            UVector3 Pos = DipoleArray[ipoint]->Getx();
            UVector3 Ori = DipoleArray[ipoint]->Getd();
            Ori.Normalize();
            USensor sens(Pos,Ori);
            sens.Setx(sens.GetCorrectTipx(Tip));
            Points[ipoint] = sens.Getx();
        }
        return Points;
    }
    
    int nPoints       = Ndip/nADC;
    UVector3* Points  = new UVector3[nPoints];
    if(!Points)  return NULL;

    if(Statistics)  memset(Statistics, 0, nPoints*ncPerPoint);

    if(NLR)  NLR[0] = NLR[1] = NLR[2] = UVector3();

    for(int ipoint=0,ipNADC=0; ipoint < nPoints; ipoint++,ipNADC+=nADC)
    {
        int nc = ipoint*ncPerPoint;

        if(Statistics)
        {
            double d01 = (DipoleArray[ipNADC+0]->Getx()-DipoleArray[ipNADC+1]->Getx()).GetNorm();
            double d12 = (DipoleArray[ipNADC+1]->Getx()-DipoleArray[ipNADC+2]->Getx()).GetNorm();
            double d20 = (DipoleArray[ipNADC+2]->Getx()-DipoleArray[ipNADC+0]->Getx()).GetNorm();

            nc  += sprintf(Statistics+nc," dist. (%8.3f,%8.3f,%8.3f); ",d01,d12,d20);
            if(nADC==3)
                nc  += sprintf(Statistics+nc," Calib (%10.5e,%10.5e,%10.5e); ",
                               DipoleArray[ipNADC+0]->Getd().GetNorm(),
                               DipoleArray[ipNADC+1]->Getd().GetNorm(),
                               DipoleArray[ipNADC+2]->Getd().GetNorm());
            else
                nc  += sprintf(Statistics+nc," Calib (%10.5e,%10.5e,%10.5e,%10.5e); ",
                               DipoleArray[ipNADC+0]->Getd().GetNorm(),
                               DipoleArray[ipNADC+1]->Getd().GetNorm(),
                               DipoleArray[ipNADC+2]->Getd().GetNorm(),
                               DipoleArray[ipNADC+3]->Getd().GetNorm());
        }
        
        if(nADC==3)
        {
            Points[ipoint] = UVector3();
        }
        else
        {
            UVector3 Pos = DipoleArray[ipNADC+3]->Getx();
            UVector3 Ori = DipoleArray[ipNADC+3]->Getd();
            Ori.Normalize();
            USensor sens(Pos,Ori);

/* Transformation matrix to Nasion Ear System*/
            UEuler ToNasionEar(DipoleArray[ipNADC+0]->Getx(), 
                               DipoleArray[ipNADC+1]->Getx(), 
                               DipoleArray[ipNADC+2]->Getx());
            sens = ToNasionEar.xfm(sens);
            if(NLR)
            {
                NLR[0] += ToNasionEar.xfm(DipoleArray[ipNADC+0]->Getx());
                NLR[1] += ToNasionEar.xfm(DipoleArray[ipNADC+1]->Getx());
                NLR[2] += ToNasionEar.xfm(DipoleArray[ipNADC+2]->Getx());
            }
/* Apply Tip correction*/
            sens.Setx(sens.GetCorrectTipx(Tip));
            Points[ipoint] = sens.Getx();
        }
    }
    if(NLR)
    {
        NLR[0] = NLR[0]/nPoints;
        NLR[1] = NLR[1]/nPoints;
        NLR[2] = NLR[2]/nPoints;
    }
    return Points;
}

UEuler* UDipoleList::GetEulerArray(int nADC) const
/* */
{
    if(nADC<3 || nADC>Ndip || Ndip%nADC) return NULL;

    int     nEuler     = Ndip/nADC;
    UEuler* EulerArray = new UEuler[nEuler];
    if(!EulerArray) return NULL;

    for(int n=0; n<nEuler; n++) 
    {
        UVector3 Nas  = DipoleArray[n*nADC + 0]->Getx();
        UVector3 Lef  = DipoleArray[n*nADC + 1]->Getx();
        UVector3 Rig  = DipoleArray[n*nADC + 2]->Getx();
        EulerArray[n] = UEuler(Nas, Lef, Rig);
    }
    return EulerArray;
}


ErrorType UDipoleList::UpdateMinMax(void)
{
    if(Ndip<=0)
    {
        CI.AddToLog("ERROR: UDipoleList::UpdateMinMax(). Invalid numberof dipoles: %d \n",Ndip);
        return U_ERROR;
    }
    Minx = DipoleArray[0]->Getx();
    Maxx = DipoleArray[0]->Getx();
    for(int n=1; n< Ndip; n++)
    {
        Minx = Min(Minx, DipoleArray[n]->Getx());
        Maxx = Max(Maxx, DipoleArray[n]->Getx());
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos) 
        {
            UVector3 x = DipoleArray[n]->Getx().GetMirrorY();
            Minx       = Min(Minx, x);
            Maxx       = Max(Maxx, x);
        }  
    }

    Minx = floor(Minx);
    Maxx = ceil(Maxx);   

    return U_OK;
}

UString UDipoleList::GetDipStat(const char* Comment) const
/*
    Return a char pointer to a string containing some statistics 
    of the dipole cloud in text format. This pointer is deleted by this object itself.
    On error return NULL.
 */
{
    UString Begin("");
    UString End("\n");
    if(Comment)
    {
        Begin = UString(Comment);
        End   = UString("\n");
    }

    UString DipStat;
    if(Ndip<=0)
    {
        DipStat += Begin + UString("Dipole Statistics:") + End;
        DipStat += Begin + UString(Ndip, "Invalid number of dipoles :%d%") + End;
        return DipStat;
    }

/* Compute the following:*/
    UVector3  Medx;             // Median (x,y,z) of all dipoles
    double    MedRadius;        // Median distance between Medx and dipoles
    double    MedRadX;          // Median distance between Medx and dipoles in X-direction
    double    MedRadY;          // Median distance between Medx and dipoles in Y-direction
    double    MedRadZ;          // Median distance between Medx and dipoles in Z-direction
    UVector3  MedMom;           // Median dipole moment
    double    MedAngle;         // Median angle between MedOri and dipole 
    int       Nsel;


    if(GetDipStat(U_ALLDIP, &Nsel, &Medx, &MedRadius, &MedRadX, &MedRadY, &MedRadZ, &MedMom, &MedAngle)!=U_OK)
    {
        DipStat += Begin + UString("Dipole Statistics:") + End;
        DipStat += Begin + UString("Error in computing dipole statistics.") + End;
        return DipStat;
    }

/* Export results to text format*/
    DipStat += Begin + UString("Dipole Statistics both hemispheres:") + End
             + Begin + UString(Ndip,                  "Ndipoles = %d  (selected)") + End
             + Begin + UString(Medx.GetProperties(),  "Center  = %s (median)") + End
             + Begin + UString(MedRadius,             "Radius  = %f ") + End
             + Begin + UString(MedRadX,               "RadiusX = %f ") + End
             + Begin + UString(MedRadY,               "RadiusY = %f ") + End
             + Begin + UString(MedRadZ,               "RadiusZ = %f ") + End
             + Begin + UString(MedMom.GetProperties(),"Moment  = %s (median)") + End
             + Begin + UString(MedAngle,              "Angle   = %f (median angle w.r.t. median moment in degrees)") + End;

    if(GetDipStat(U_LEFTDIP, &Nsel, &Medx, &MedRadius, &MedRadX, &MedRadY, &MedRadZ, &MedMom, &MedAngle)==U_OK)
    {
        DipStat += Begin + UString("Dipole Statistics left hemispheres:") + End
                 + Begin + UString(Ndip,                  "NdipolesL = %d  (selected)") + End
                 + Begin + UString(Medx.GetProperties(),  "CenterL  = %s (median)") + End
                 + Begin + UString(MedRadius,             "RadiusL  = %f ") + End
                 + Begin + UString(MedRadX,               "RadiusXL = %f ") + End
                 + Begin + UString(MedRadY,               "RadiusYL = %f ") + End
                 + Begin + UString(MedRadZ,               "RadiusZL = %f ") + End
                 + Begin + UString(MedMom.GetProperties(),"MomentL  = %s (median)") + End
                 + Begin + UString(MedAngle,              "AngleL   = %f (median angle w.r.t. median moment in degrees)") + End;
    }
    if(GetDipStat(U_RIGHTDIP, &Nsel, &Medx, &MedRadius, &MedRadX, &MedRadY, &MedRadZ, &MedMom, &MedAngle)==U_OK)
    {
        DipStat += Begin + UString("Dipole Statistics right hemispheres:") + End
                 + Begin + UString(Ndip,                  "NdipolesR = %d  (selected)") + End
                 + Begin + UString(Medx.GetProperties(),  "CenterR  = %s (median)") + End
                 + Begin + UString(MedRadius,             "RadiusR  = %f ") + End
                 + Begin + UString(MedRadX,               "RadiusXR = %f ") + End
                 + Begin + UString(MedRadY,               "RadiusYR = %f ") + End
                 + Begin + UString(MedRadZ,               "RadiusZR = %f ") + End
                 + Begin + UString(MedMom.GetProperties(),"MomentR  = %s (median)") + End
                 + Begin + UString(MedAngle,              "AngleR   = %f (median angle w.r.t. median moment in degrees)") + End;
    }
    if(DipStat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleList::GetDipStat(). Printing statistics to DipStat UString. \n");
        return UString();
    }
    return DipStat;
}

UDipole* UDipoleList::GetDipoles(void) const
{
    UDipole* DL=new UDipole[Ndip];
    if(DL==NULL) return NULL;

    for(int k=0; k<Ndip; k++) DL[k] = *DipoleArray[k];
    return DL;
}

ErrorType UDipoleList::SetDipole(int idip, const UDipole& Dip)
{
    if(idip<0||idip>=Ndip) return U_ERROR;

    delete DipoleArray[idip];
    DipoleArray[idip] = new UDipole(Dip);
    if(DipoleArray[idip]==NULL) return U_ERROR;

    return U_OK;
}

ErrorType UDipoleList::WriteXDR(const char* XDRdirName, const UEuler* XFM, ProjType ProjT, PlotType PlotT, UColor rgb)
/*
    Export dipoles to AVS-XDR format with Conquest conventions.
    XDRDir[]   - directory name, to which ".structure" is appended (if not present)
                 The dipoles are written into this directory, under the name "structure.xdr"
    *XFM       - The transformation to apply to the dipoles, in order to transform
                 them from Nasion Ear to MRI. This transformation is only copied
                 under the name "structure_to_wld.xdr". (if(XFM==NULL), do not write transform)

    ProjT      - determines the way the dipoles are projected. U_NOP: no projection,
                 U_PX: project on x-plane, etc.
    PlotT      - determines the way the dipoles are ploteed: dots or vectors.
 */
{
    if(XDRdirName==NULL) 
    {
        CI.AddToLog("ERROR: UDipoleList::WriteXDR(). Invalid argument. \n");
        return U_ERROR;
    }

    UPatTree XDRdir(XDRdirName, UPatTree::U_STRUCTURE);
    if(XDRdir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleList::WriteXDR(). Directory cannot be created: %s. \n",XDRdir.GetDirectoryName());
        return U_ERROR;
    }

/* Create and write the points file-file*/
    int Npoints;
    UVector3* p = GetPositionList(&Npoints);

    UField DipField;
    if(ProjT!=U_NOP)
    {
        UVector2* p2 = new UVector2[Npoints];
        switch(ProjT)
        {
        case U_PX: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Px(); } break;
        case U_PY: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Py(); } break;
        case U_PZ: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Pz(); } break;
        }
        DipField = UField(p2, Npoints, MAXPLOTBUFFER);
        delete[] p2;
    }
    else
        DipField = UField(p, Npoints, MAXPLOTBUFFER);

    delete[] p;
    if(DipField.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleList::WriteXDR(). Memory allocation.\n");
        return U_ERROR;
    }

    char* Pdata = (char*) DipField.GetBdata();
    if(Pdata==NULL)
    {
        CI.AddToLog("ERROR: UDipoleList::WriteXDR(). NULL pointer in dipole UField data.\n");
        return U_ERROR;
    }

    for(int n=0; n<Ndip; n++)
    {
        UVector3 Dir = DipoleArray[n]->Getd();
        Dir.Normalize();

        if(XFM) Dir = XFM->xfm(Dir, true);

        switch(PlotT)
        {
        case U_DOT:
        case U_DOT_TIME:
        case U_CONFINT:
            PlotDot(Pdata, rgb);
            break;

        case U_VECTOR:
            switch(ProjT)
            {
                case U_NOP:  PlotVector(Pdata, Dir, rgb);      break;
                case U_PX:   PlotVector(Pdata, Dir.Px(), rgb); break;
                case U_PY:   PlotVector(Pdata, Dir.Py(), rgb); break;
                case U_PZ:   PlotVector(Pdata, Dir.Pz(), rgb); break;
            }
            break;
        }
        Pdata += MAXPLOTBUFFER;          

        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos)
        {

            UVector3 Dir = DipoleArray[n]->GetdSym();
            Dir.Normalize();

            switch(PlotT)
            {
            case U_DOT:
            case U_DOT_TIME:
            case U_CONFINT:
                PlotDot(Pdata, rgb);
                break;

            case U_VECTOR:
                switch(ProjT)
                {
                    case U_NOP:  PlotVector(Pdata, Dir,rgb);       break;
                    case U_PX:   PlotVector(Pdata, Dir.Px(), rgb); break;
                    case U_PY:   PlotVector(Pdata, Dir.Py(), rgb); break;
                    case U_PZ:   PlotVector(Pdata, Dir.Pz(), rgb); break;
                }
                break;
            }
            Pdata += MAXPLOTBUFFER;          
        }
    }

    if(XDRdir.SetScan(&DipField, GetDipStat("// "))!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleList::WriteXDR(). Cannot write dipoles structure. \n");
        return U_ERROR;
    }
    
/* Create and write dummy index file.*/
    int* Index    = new int[Npoints];
    if(!Index )
    {
        CI.AddToLog("ERROR UDipoleList::WriteXDR(). Cannot create index arrays.\n");
        return U_ERROR;
    }
    for(int n=0; n<Npoints; n++) Index[n]    = n;
    UField IndexField(Index, Npoints, 1, true);
    delete[] Index;

    if(XDRdir.SetIndex(&IndexField, GetDipStat("// "))!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleList::WriteXDR(). Cannot write index field. \n");
        return U_ERROR;
    }

/* Write the transformation, when present */    
    if(XFM && XDRdir.SetMatchToWld(*XFM)!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleList::WriteXDR(). Cannot write transform file. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UDipoleList::GetDipStat(ALRType ALR, int *NdipSel, UVector3* Medx, double* MedRadius, double* MedRadX, double* MedRadY, double* MedRadZ, UVector3* MedMom, double* MedAngle) const
{
    if(NdipSel==NULL) return U_ERROR;

    int n    = 0;
    *NdipSel = 0;
    switch(ALR)
    {
    case U_ALLDIP:
        *NdipSel = Ndip;
        break;

    case U_LEFTDIP:
        *NdipSel = 0;
        for(n=0; n<Ndip; n++)
            if(DipoleArray[n]->Getx().Gety()>=0) (*NdipSel)++;
        break;

    case U_RIGHTDIP:
        *NdipSel = 0;
        for(n=0; n<Ndip; n++)
            if(DipoleArray[n]->Getx().Gety()<=0) (*NdipSel)++;
        break;
    default:
        return U_ERROR;
    }
    if(*NdipSel<=0) return U_ERROR;


    double* Item = new double[*NdipSel];
    if(Item==NULL)
    {
        delete[] Item; 
        CI.AddToLog("ERROR: UDipoleList::GetDipStat(). Memory allocation error. NdipSelected = %d .\n",*NdipSel);
        return U_ERROR;
    }

    int NdipSel2 = (*NdipSel)/2;

/* Get median coordinates*/
    if(Medx)
    {
        int k=0;
        for(n=k=0; n<Ndip; n++) 
        {
            double X = DipoleArray[n]->Getx().Getx();
            double Y = DipoleArray[n]->Getx().Gety();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = X;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        Medx->Setx(Item[NdipSel2]);

        for(n=k=0; n<Ndip; n++) 
        {
            double Y = DipoleArray[n]->Getx().Gety();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = Y;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        Medx->Sety(Item[NdipSel2]);

        for(n=k=0; n<Ndip; n++) 
        {
            double Y = DipoleArray[n]->Getx().Gety();
            double Z = DipoleArray[n]->Getx().Getz();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = Z;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        Medx->Setz(Item[NdipSel2]);

/* Get median radius*/
        if(MedRadius)
        {
            for(n=k=0; n<Ndip; n++) 
            {
                double Y = DipoleArray[n]->Getx().Gety();
                double R = (DipoleArray[n]->Getx()-*Medx).GetNorm();
                if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = R;
            }
            qsort(Item, *NdipSel, sizeof(double), DubCompare);
            *MedRadius = Item[NdipSel2];
        }
        if(MedRadX)
        {
            for(n=k=0; n<Ndip; n++) 
            {
                double Y = DipoleArray[n]->Getx().Gety();
                double D = fabs(DipoleArray[n]->Getx().Getx()-Medx->Getx());
                if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = D;
            }
            qsort(Item, *NdipSel, sizeof(double), DubCompare);
            *MedRadX = Item[NdipSel2];
        }
        if(MedRadY)
        {
            for(n=k=0; n<Ndip; n++) 
            {
                double Y = DipoleArray[n]->Getx().Gety();
                double D = fabs(DipoleArray[n]->Getx().Gety()-Medx->Gety());
                if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = D;
            }
            qsort(Item, *NdipSel, sizeof(double), DubCompare);
            *MedRadY = Item[NdipSel2];
        }
        if(MedRadZ)
        {
            for(n=k=0; n<Ndip; n++) 
            {
                double Y = DipoleArray[n]->Getx().Gety();
                double D = fabs(DipoleArray[n]->Getx().Getz()-Medx->Getz());
                if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = D;
            }
            qsort(Item, *NdipSel, sizeof(double), DubCompare);
            *MedRadZ = Item[NdipSel2];
        }
    }
    if(MedMom)
    {
        int k=0;
        for(n=k=0; n<Ndip; n++) 
        {
            double Y = DipoleArray[n]->Getx().Gety();
            double M = DipoleArray[n]->Getd().Getx();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = M;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        MedMom->Setx(Item[NdipSel2]);

        for(n=k=0; n<Ndip; n++) 
        {
            double Y = DipoleArray[n]->Getx().Gety();
            double M = DipoleArray[n]->Getd().Gety();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = M;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        MedMom->Sety(Item[NdipSel2]);

        for(n=k=0; n<Ndip; n++) 
        {
            double Y = DipoleArray[n]->Getx().Gety();
            double M = DipoleArray[n]->Getd().Getz();
            if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = M;
        }
        qsort(Item, *NdipSel, sizeof(double), DubCompare);
        MedMom->Setz(Item[NdipSel2]);

/* Get medium angle*/
        if(MedAngle)
        {
            for(n=k=0; n<Ndip; n++) 
            {
                double Y = DipoleArray[n]->Getx().Gety();
                double A = Angle(DipoleArray[n]->Getd(), *MedMom);
                if(ALR==U_ALLDIP || (ALR==U_LEFTDIP&&Y>=0.) || (ALR==U_RIGHTDIP&&Y<=0.)) Item[k++] = A;
            }
            qsort(Item, *NdipSel, sizeof(double), DubCompare);
            *MedAngle = 180*Item[NdipSel2]/PI;
        }
    }
    delete[] Item;

    return U_OK;
}
