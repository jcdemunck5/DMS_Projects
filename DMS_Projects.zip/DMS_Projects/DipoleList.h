#ifndef _DIPOLELIST_INCLUDED
#define _DIPOLELIST_INCLUDED

#include "AnnotateConQuest.h"
#include "Event.h"
#include "Dipole.h"
#include "Cluster.h"
#include "String.h"

class DLL_IO UDipoleList: public UAnnotateConQuest, public UCluster
{
public:
    UDipoleList();
    UDipoleList(int Ndp, UDipole::DipoleType DT);
    virtual ~UDipoleList();

    ErrorType       GetError(void)      const {return error;} 
    UString         GetDipStat(const char* Comment) const;

    UDipole         GetDipole(int k)    const;
    int             GetNdip(void)       const {return Ndip;}
    UVector3        GetMinx(void)       const {return Minx;}
    UVector3        GetMaxx(void)       const {return Maxx;}

    UVector3*       GetPositionList(int *Npoints) const;
    UVector3*       GetOrientationList(int *Npoints) const;

    UVector3*       GetPointsNLR(UVector3 *NLR, int nADC, char* Statistics, int ncPerPoint, double Tip) const;
    UEuler*         GetEulerArray(int nADC) const;
    UDipole*        GetDipoles()        const;
    ErrorType       SetDipole(int idip, const UDipole& Dip);
    ErrorType       WriteXDR(const char* XDRdirName, const UEuler* XFM, ProjType ProjT, PlotType PlotT, UColor rgb);

    ErrorType       AddDipole(UDipole Dip);
    ErrorType       ReAllocateMemory(void);


/* Functions for clustering dipoles */
    enum UClusterDistanceType // Distance measure used for clustering
    {
        U_CLUSTDIST_POS,      // Position
        U_CLUSTDIST_ORI,      // Orientation
        U_CLUSTDIST_SIN2ORI,  // sin**2 (orientation)
    };
    void            SetDistanceType(UClusterDistanceType DT) {DistType = DT;}
    ErrorType       InitClustering(LinkType LM) {return UCluster::InitClustering(LM);}

protected:
    UDipole**       DipoleArray;      // Array of pointers to UDipole() objects or derived classes
    int             Ndip;             // Number of (selected) dipoles
    int             NdipAllocated;    // Number of allocated dipoles

    UVector3        Minx;             // Minimum (x,y,z) of all dipoles
    UVector3        Maxx;             // Maximum (x,y,z) of all dipoles
    UClusterDistanceType  DistType;

    ErrorType       UpdateMinMax(void);
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(void);

private:
    virtual double  GetDistance2(int i1, int i2);
    virtual int     GetNobjects(void) const {return Ndip;}

    ErrorType       error;
    enum ALRType {U_ALLDIP, U_LEFTDIP, U_RIGHTDIP};
    ErrorType       GetDipStat(ALRType ALR, int *NdipSel, UVector3* Medx, double* MedRadius, double* MedRadX, double* MedRadY, double* MedRadZ, UVector3* MedMom, double* MedAngle) const;
};

#endif // _DIPOLELIST_INCLUDED
