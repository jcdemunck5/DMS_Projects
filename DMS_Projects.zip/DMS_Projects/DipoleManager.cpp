/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for keeping track of all kinds of free and fixed dipole parameters */
/*     in the stationary dipole model with several constraints on the dipoles.   */
/*                                                                               */
/*     Each dipole position can be fixed (at its starting position), or free.    */
/*     Each dipole orientation can be either rotating, or be kep constant. In    */
/*     the latter case the dipole orientation is estimated from the data using   */
/*     a dedicated function.                                                     */
/*     Each dipole can be single (current dipole), magnetic dipole, symmetric    */
/*     semi-symmetric. In all cases, the strength-time functions are esimated    */
/*     from the data. In case of semi-symmetric dipoles, the number of estimated */
/*     time functions per dipole is doubled.                                     */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    27-11-01   creation  
  Jdm    01-12-01   Add Emfield, multiple purpose pointer used to store EM (lead)fields
  FB     02-10-03   Add SetDipolesTangential(UVector3 SpherePos)
  JdM    10-03-05   Disable language extensions (for-loops) for compatability with Linux C++
JdM/FB   30-03-05   Added new constructor(), based on UDipoleEdit, to allow for multiple types 
                    Added SetAllMembersDefault() and DeleteAllMembers()
  FB     06-04-05   Added GetAllDipoles() based on UDipoleEdit
  JdM    20-05-11   Use UString for GetProperties()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include <string.h>
#include "DipoleManager.h"
#include "DipoleEditList.h"
#include "EMfield.h"


/* Inititalize static const parameters. */
UString UDipoleManager::Properties    = UString();

UDipoleFix::UDipoleFix() : UDipole()
{
    PositionFixed   = false;
    MomentsRotating = false;
}


UDipoleFix::UDipoleFix(UDipole Dip, bool PosFix, bool MomRot) : UDipole(Dip)
{
    PositionFixed   = PosFix;
    MomentsRotating = MomRot;
}


UDipoleFix& UDipoleFix::operator=(const UDipoleFix& dip)
{
    UDipole::operator=((UDipole) dip);
    
    PositionFixed   = dip.PositionFixed;
    MomentsRotating = dip.MomentsRotating;
    return *this;
}

UDipoleFix& UDipoleFix::operator=(const UDipole& dip)
{
    UDipole::operator=((UDipole) dip);    
    return *this;
}

void UDipoleManager::SetAllMembersDefault(void)
{
    error           = U_OK;
    Nsens           = 0;
    Ndip            = 0;
    DipArr          = NULL;
    NSourceTimeFunc = 0;
    Nmoment         = 0;         
    Npospars        = 0;         
    PosPars         = NULL;      
    pWDerPsi        = NULL;      
    Emfield         = NULL;
    Properties      = UString();
}
void UDipoleManager::DeleteAllMembers(ErrorType E)
{
    delete[] DipArr;
    delete[] PosPars;
    if(pWDerPsi)
        for(int k=0; k<Ndip; k++)
            delete[] pWDerPsi[k];

    delete[] pWDerPsi;
    delete[] Emfield;

    SetAllMembersDefault();
    error = E;
}


UDipoleManager::UDipoleManager()
{
    SetAllMembersDefault();
}


UDipoleManager::UDipoleManager(const UDipoleFix* DipoleArray, int Ndipoles, const double*const* pWDerivField, int Nsensors)
/*
    DipoleArray[]   - All dipoles (fixed or not)
    Ndipoles        - Number of dipoles used in the model
    *pWDerivField[] - Lead fields of all dipoles
    Nsensors        - Number of sensors (MEG, EEG or both)
 */
{
/* Set defaults*/
    SetAllMembersDefault();

    if(DipoleArray==NULL || pWDerivField==NULL || Ndipoles<=0 || Nsensors<=0)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Invalid parameters. NULL pointer? Ndipoles = %d, Nsensors = %d \n", Ndipoles, Nsensors);
        return;
    }
    
    DipArr     = new UDipoleFix[Ndipoles];
    PosPars    = new double[3*Ndipoles];
    pWDerPsi   = new double*[Ndipoles];

    if(DipArr==NULL || PosPars==NULL || pWDerPsi==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Memory allocation. Ndipoles = %d\n", Ndipoles);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Nsens           = Nsensors;
    Ndip            = Ndipoles;
        
    for(int k=0; k<Ndip; k++)
    {
        DipArr[k] = DipoleArray[k];
        int Ncomp = 3;
        if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) Ncomp = 6;
        pWDerPsi[k] = new double[Ncomp*Nsens];
        if(pWDerPsi[k] && pWDerivField[k])
        {
            for(int i=0; i<Ncomp*Nsens; i++) pWDerPsi[k][i] = pWDerivField[k][i];
        }
        else
        {
            if(pWDerPsi[k]==NULL)
                CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Memory allocation. Dip=%d, Ndipoles = %d, Nsensors = %d \n", k, Ndipoles, Nsensors);
            if(pWDerivField[k]==NULL)
                CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). NULL pointer input. Dip=%d \n", k);

            for(int kk=k; kk>=0; kk--)
                delete[] pWDerPsi[kk];
            delete[] pWDerPsi; pWDerPsi = NULL;
            
            Nsens  =  Ndip  = 0;
            NSourceTimeFunc = 0;
            Nmoment         = 0;
            Npospars        = 0;
            return;
        }
        
        NSourceTimeFunc += GetNfreeSTF(k);
        Nmoment         += GetNfreeMoment(k);

        if(DipArr[k].IsPositionFixed()==false) 
        {
            PosPars[Npospars  ] = DipArr[k].Getx().Getx();
            PosPars[Npospars+1] = DipArr[k].Getx().Gety();
            PosPars[Npospars+2] = DipArr[k].Getx().Getz();
            Npospars += 3;                    
        }
    }

    int Nfield = MAX(Nmoment, NSourceTimeFunc);
    Emfield = new double[Nfield*Nsens];
    if(Emfield==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Memory allocation. Nfield=%d, Nsens=%d .\n",Nfield, Nsens);
        DeleteAllMembers(U_ERROR);
        return;
    }    
    error = U_OK;    
}

UDipoleManager::UDipoleManager(const UDipole* DipoleArray, int Ndipoles, bool AllRotating, const double*const* pWDerivField, int Nsensors)
/*
    DipoleArray[]   - All dipoles, all not fixed
    Ndipoles        - Number of dipoles used in the model
    AllRotating     - true iff all dipole orienations are free
    *pWDerivField[] - Lead fields of all dipoles
    Nsensors        - Number of sensors (MEG, EEG or both)
 */
{
/* Set defaults*/
    SetAllMembersDefault();

    if(DipoleArray==NULL || pWDerivField==NULL || Ndipoles<=0 || Nsensors<=0)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Invalid parameters. NULL pointer? Ndipoles = %d, Nsensors = %d \n", Ndipoles, Nsensors);
        return;
    }


    UDipoleFix* DF = new UDipoleFix[Ndipoles];
    if(DF==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Memory allocation. Ndipoles=%d \n",Ndipoles);
        return;
    }
    for(int k=0; k<Ndipoles; k++)
        DF[k] = UDipoleFix(DipoleArray[k], false, AllRotating);

    *this = UDipoleManager(DF, Ndipoles, pWDerivField, Nsensors);

    delete[] DF;
}

UDipoleManager::UDipoleManager(int Ndipoles, const UDipoleEdit* DipEd, const double*const* pWDerivField, int Nsensors)
{
/* Set defaults*/
    SetAllMembersDefault();

    if(DipEd==NULL || pWDerivField==NULL || Ndipoles<=0 || Nsensors<=0)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Invalid parameters. NULL pointer? Ndipoles = %d, Nsensors = %d \n", Ndipoles, Nsensors);
        return;
    }

    UDipoleFix* DF = new UDipoleFix[Ndipoles];
    if(DF==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UDipoleManager(). Memory allocation. Ndipoles=%d \n",Ndipoles);
        return;
    }
    for(int k=0; k<Ndipoles; k++)
        DF[k] = UDipoleFix((UDipole)DipEd[k], false, DipEd[k].GetRotating());

    *this = UDipoleManager(DF, Ndipoles, pWDerivField, Nsensors);

    delete[] DF;
}
    
UDipoleManager::~UDipoleManager()
{
    DeleteAllMembers(U_OK);
}

UDipoleManager& UDipoleManager::operator=(const UDipoleManager& DM)
{
    if(this==NULL)
    {
        static UDipoleManager Def; 
        Def.error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleManager::operator=(). this==NULL\n");
        return Def;
    }
    if(this==&DM) return *this;
    if(&DM==NULL)
    {
        CI.AddToLog("ERROR: UDataPrism3::operator=(). Argument NULL\n");
        return *this;
    }    
    DeleteAllMembers(U_OK);

    error           = DM.error;
    Nsens           = DM.Nsens;
    Ndip            = DM.Ndip;
    NSourceTimeFunc = DM.NSourceTimeFunc;
    Nmoment         = DM.Nmoment;         
    Npospars        = DM.Npospars;         


    if(DM.DipArr)
    {
        DipArr = new UDipoleFix[Ndip];
        if(DipArr)
            for(int k=0; k<Ndip; k++)
                DipArr[k] = DM.DipArr[k];
    }
    if(DM.PosPars)
    {
        PosPars = new double[3*Ndip]; 
        if(PosPars)
            for(int k=0; k<3*Ndip; k++)
                PosPars[k] = DM.PosPars[k];
    }
    if(DM.pWDerPsi)
    {
        pWDerPsi   = new double*[Ndip];
        if(pWDerPsi)
        {
            for(int k=0; k<Ndip; k++)
            {
                int Ncomp = 3;
                if(DM.DipArr[k].GetDipoleType()==UDipole::SymmetricPos) Ncomp = 6;
                pWDerPsi[k] = new double[Ncomp*Nsens];
                if(pWDerPsi[k] && DM.pWDerPsi[k])
                {
                    for(int i=0; i<Ncomp*Nsens; i++) 
                        pWDerPsi[k][i] = DM.pWDerPsi[k][i];
                }
                else if(pWDerPsi[k]==NULL)
                {
                    for(int kk=k; kk>=0; kk--) delete[] pWDerPsi[kk];
                    delete[] pWDerPsi;
                    pWDerPsi = NULL;
                }
            }
        }
    }

    if(DM.Emfield)
    {
        int Nfield = MAX(DM.Nmoment, DM.NSourceTimeFunc);
        Emfield = new double[Nfield*DM.Nsens];
    }
    
/* Test all memory allocations*/
    if( (!DipArr     && DM.DipArr    ) ||
        (!PosPars    && DM.PosPars   ) ||
        (!pWDerPsi   && DM.pWDerPsi  ) ||
        (!Emfield    && DM.Emfield   ) )
    {
        CI.AddToLog("ERROR: UDipoleManager::operator=() Memory allocation. \n");
        DeleteAllMembers(U_ERROR);
    }
    return *this;
}

UString& UDipoleManager::GetProperties(UString Comment) const
/*
     Return the properties in text format
 */
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("UDipoleManager::GetProperties() NULL or erroneous. \n");
        return Properties;
    }

    Properties  = UString();
    Properties += UString("The dipole parameters:\n");
    Properties += UString(Ndip," NDipoles = %d \n");
    for(int k=0; k<Ndip; k++)
    {
        Properties += UString(k, "   Dipole[%d]: \n"); 
        switch(DipArr[k].GetDipoleType())
        {
        case UDipole::Current:      Properties+= "    DipoleType = CurrentDipole, "; break;
        case UDipole::Magnetic:     Properties+= "    DipoleType = MagneticCoil, " ;  break;
        case UDipole::Symmetric:    Properties+= "    DipoleType = FullSymmetric, "; break;
        case UDipole::SymmetricPos: Properties+= "    DipoleType = SemiSymmetric, "; break;           
        }

        if(DipArr[k].IsPositionFixed()==true)    Properties+= "PositionFixed, ";
        else                                     Properties+= "PositionFree, ";

        if(DipArr[k].AreMomentsRotating()==true) Properties+= "MomentsRotate \n";
        else                                     Properties+= "MomentsFixed \n";
    }
    if(Comment.IsNULL() || Comment.IsEmpty())    Properties.ReplaceAll('\n', ';');
    else                                         Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UDipoleManager::SetNdipoles(int Ndipoles)
/*
    Restrict the number of dipoles by disregarding the last ones in the dipole manager arrays.
 */
{
    if(Ndipoles<=0 || Ndipoles>Ndip)
    {
        CI.AddToLog("ERROR: UDipoleManager::SetNdipoles(). Invalid input. Nipoles = %d, max = %d \n", Ndipoles, Ndip);
        return U_ERROR;
    }

    NSourceTimeFunc = 0;
    Nmoment         = 0;
    Npospars        = 0;
    for(int k=0; k<Ndip; k++)
    {
        if(k<Ndipoles)
        {
            NSourceTimeFunc += GetNfreeSTF(k);
            Nmoment         += GetNfreeMoment(k);
            Npospars        += GetNfreePosPars(k);
        }
        else
            delete[] pWDerPsi[k];
    }
    Ndip = Ndipoles;
    
    delete[] Emfield;

    int Nfield = MAX(Nmoment, NSourceTimeFunc);
    Emfield = new double[Nfield*Nsens];
    if(Emfield==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::SetNdipoles(). Memory allocation. Nfield=%d, Nsens=%d .\n",Nfield, Nsens);
        return U_ERROR;
    }
    return U_OK;
}


ErrorType UDipoleManager::UpdateDipolePositions(const double* FreePositions)
/*
    Update those position parameters that are not fixed at their starting values
 */
{
    if(FreePositions==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UpdateDipolePositions(). NULL argument.\n");
        return U_ERROR;
    }

    const double* pFreeDip = FreePositions;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==false) 
        {
            UVector3 x(pFreeDip);
            DipArr[k].Setx(x);
            pFreeDip += 3;                    
        }
    }
    for(int k=0; k<Npospars; k++) PosPars[k] = FreePositions[k];
    
    return U_OK;    
}


ErrorType UDipoleManager::SetDipolesTangential(UVector3 SpherePos)
{
	for(int p=0;p<Ndip;p++)
	{
		if(DipArr[p].SetTangential(SpherePos) !=U_OK)
			return U_ERROR;
		DipArr[p].Normalize();
	}
	return U_OK;

}

ErrorType UDipoleManager::UpdateFreeDipoles(const UDipole* DipoleArray)
/*
    Update those dipole position and moment parameters that are not fixed at 
    their starting values. Normalize dipole moments.
 */
{
    if(DipoleArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UpdateFreeDipoles(). NULL argument.\n");
        return U_ERROR;
    }

    for(int k=0,kk=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==false)
        {
            DipArr[k] = DipoleArray[kk];
            DipArr[k].Normalize();
            kk++;
        }
    }
    for(int k=0; k<Npospars/3; k++) 
    {
        PosPars[3*k  ] = DipoleArray[k].Getx().Getx();
        PosPars[3*k+1] = DipoleArray[k].Getx().Gety();
        PosPars[3*k+2] = DipoleArray[k].Getx().Getz();
    }
    return U_OK;
}


ErrorType UDipoleManager::UpdateDipoleMoments(const double* FreeMoments)
/*
    Update those dipole position and moment parameters that are not fixed at 
    their starting values. Normalize dipole moments.
 */
{
    if(FreeMoments==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::UpdateDipoleMoments(). NULL argument.\n");
        return U_ERROR;
    }

    const double* pFreeDip = FreeMoments;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].AreMomentsRotating()==false) 
        {
            DipArr[k].Setd(UVector3(pFreeDip));
            pFreeDip += 3;                    
            if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) 
            {
                DipArr[k].SetdSym(UVector3(pFreeDip));
                pFreeDip += 3;                    
            }
            else
                DipArr[k].SetSymRight(UVector3());
            DipArr[k].Normalize();
        }
    }    
    return U_OK;    
}

ErrorType UDipoleManager::GetAllDipoles(UDipole* DipArray)
/*
    Copy an array of all dipoles, free or fixed to DipArray[]
 */
{
    if(DipArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetAllDipoles(). NULL argument.\n");
        return U_ERROR;
    }
    for(int k=0; k<Ndip; k++)
    {
        DipArray[k].Setx(DipArr[k].Getx());
        DipArray[k].Setd(DipArr[k].Getd());
        DipArray[k].SetdSym(DipArr[k].GetdSym());
        DipArray[k].SetDipoleType(DipArr[k].GetDipoleType());
    }
    return U_OK;
}

ErrorType UDipoleManager::GetAllDipoles(UDipoleEdit* DipEd)
/*
    Copy an array of all dipoles, free or fixed to DipEd[]
 */
{
    if(DipEd==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetAllDipoles(). NULL argument in DipEd.\n");
        return U_ERROR;
    }
    for(int k=0; k<Ndip; k++)
    {
        DipEd[k].Setx(DipArr[k].Getx());
        DipEd[k].Setd(DipArr[k].Getd());
        DipEd[k].SetdSym(DipArr[k].GetdSym());
        DipEd[k].SetDipoleType(DipArr[k].GetDipoleType());
        DipEd[k].SetRotating(IsDipoleRotating(k));
    }
    return U_OK;
}


ErrorType UDipoleManager::GetFreeDipoles(UDipole* DipArray)
/*
    Copy an array of all free dipoles, to be estmated from the data, to DipArray[]
 */
{
    if(DipArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetFreeDipoles(). NULL argument.\n");
        return U_ERROR;
    }
    for(int k=0,kk=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==true) continue;

        DipArray[kk].Setx(DipArr[k].Getx());
        DipArray[kk].Setd(DipArr[k].Getd());
        DipArray[kk].SetdSym(DipArr[k].GetdSym());
        DipArray[kk].SetDipoleType(DipArr[k].GetDipoleType());
        kk++;
    }
    return U_OK;
}

ErrorType UDipoleManager::SetFreeDerivField(const double* const* pWFreeDerivField)
/*
    Update the lead fealds of all free dipoles.
 */
{
    if(pWFreeDerivField==NULL)
    {
        CI.AddToLog("ERROR: UDipoleManager::SetFreeDerivField(). NULL argument.\n");
        return U_ERROR;
    }

    for(int k=0,kk=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==true) continue;

        int Ncomp = 3;
        if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) Ncomp = 6;
        
        for(int i=0; i<Nsens*Ncomp; i++)
            pWDerPsi[k][i] = pWFreeDerivField[kk][i];

        kk++;
    }
    return U_OK;
}

int UDipoleManager::GetNfreeSTF(int idip) const
/*
    Get the number of source time functions corresponding to dipole idip.
 */
{
    if(idip<0 || idip>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetNfreeSTF(). Argument out of range: idip = %d, max = %d \n",idip, Ndip);
        return 0;
    }
    if(DipArr[idip].AreMomentsRotating()==true) 
    {
        if(DipArr[idip].GetDipoleType()==UDipole::SymmetricPos) return 6;
        return 3;
    }
    if(DipArr[idip].GetDipoleType()==UDipole::SymmetricPos) return 2;
    return 1;
}

int UDipoleManager::GetNfreeSTFMEG(void) const
/*
    Get the total number of linearly independent source time functions, that can be estimated
    from the data, using MEG alone and a spherical head model.
 */
{
    int NfreeSTFMEG = 0;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].AreMomentsRotating()==false) 
        {
            NfreeSTFMEG+=1;
            if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) 
                NfreeSTFMEG+=1;
        }
        else
        {
            NfreeSTFMEG+=2;
            if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) 
                NfreeSTFMEG+=2;
        }
    }
    return NfreeSTFMEG;
}

const double* UDipoleManager::GetFieldSTF(void) const
/*
    Get the the lead fields (in case of rotating dipoles), or its multiplication with the
    dipole vector (incase of constant orientation dipoles) in one new one dimensional
    matrix, with channel as fast index and source time function as slow index.

    This function is to be used in the estimation function for the dource time functions
 */
{
    double* pDerFreeField = Emfield;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].AreMomentsRotating()==false) 
        {
            if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos)
            {
                double d[6] = {DipArr[k].Getd().Getx()   ,DipArr[k].Getd()   .Gety(),DipArr[k].Getd().Getz()   ,
                               DipArr[k].GetdSym().Getx(),DipArr[k].GetdSym().Gety(),DipArr[k].GetdSym().Getz()};            

                const double*  pk = pWDerPsi[k];
                for(int i=0; i<Nsens; i++, pk+=6)
                    *pDerFreeField++ = d[0]*pk[0] + d[1]*pk[1] + d[2]*pk[2];

                pk = pWDerPsi[k];
                for(int i=0; i<Nsens; i++, pk+=6)
                    *pDerFreeField++ = d[3]*pk[3] + d[4]*pk[4] + d[5]*pk[5];
            }
            else
            {
                double d[3] = {DipArr[k].Getd().Getx(),DipArr[k].Getd().Gety(),DipArr[k].Getd().Getz()};
            
                const double*  pk = pWDerPsi[k];
                for(int i=0; i<Nsens; i++, pk+=3)
                    *pDerFreeField++ = d[0]*pk[0] + d[1]*pk[1] + d[2]*pk[2];
            }
        }
        else
        {
            int Ncomp = 3;
            if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) Ncomp = 6;
        
            const double* pk = pWDerPsi[k];
            for(int c=0; c<Ncomp; c++)
            {
                const double* pkc = pk+c;
                for(int i=0; i<Nsens; i++, pkc+=Ncomp)
                    *pDerFreeField++ =*pkc;
            }
        }
    }
    return Emfield;
}

int UDipoleManager::GetNfreeMoment(int idip) const
/*
    Get the number of moment parameters to be estimated from the data, for dipole idip.
 */
{
    if(idip<0 || idip>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetNfreeMoment(). Argument out of range: idip = %d, max = %d \n",idip, Ndip);
        return 0;
    }
    if(DipArr[idip].AreMomentsRotating()==true) return 0;
    if(DipArr[idip].GetDipoleType()==UDipole::SymmetricPos) return 6;
    return 3;
}

int UDipoleManager::GetNfreeMomentMEG(void) const
/*
    Get the total number of moment parameters that can be independently be estimated
    from pure MEG data using a spherical head model.
 */
{
    int NmomMEG = 0;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].AreMomentsRotating()==true) continue;

        NmomMEG += 2;
        if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) NmomMEG += 2;
    }
    return NmomMEG;
}

const double* UDipoleManager::GetFieldMoment(void) const
/*
    Get the the lead fields of the constant orientation dipoles in one new one dimensional
    matrix, with channel as fast index and moment as slow index.

    This function is to be used in the estimation function for the (fixed) dipole orientations
 */
{
    double* pDerFreeField = Emfield;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].AreMomentsRotating()==true) continue;

        int Ncomp = 3;
        if(DipArr[k].GetDipoleType()==UDipole::SymmetricPos) Ncomp = 6;
        
        const double* pk = pWDerPsi[k];
        for(int c=0; c<Ncomp; c++)
        {
            const double* pkc = pk+c;
            for(int i=0; i<Nsens; i++, pkc+=Ncomp)
                *pDerFreeField++ = *pkc;
        }
    }
    return Emfield;
}


const double* UDipoleManager::GetPositionArray(void) const 
/*
   Return a pointer to an array of free dipole positions.
 */
{
    double* pFreeDip = PosPars;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==true)  continue;
        
        pFreeDip[0] = DipArr[k].Getx().Getx();
        pFreeDip[1] = DipArr[k].Getx().Gety();
        pFreeDip[2] = DipArr[k].Getx().Getz();
        pFreeDip += 3;                    
    }
    return PosPars;
}

ErrorType UDipoleManager::GetPositionArray(double* PosAr) const
/*
   Store an array of free dipole positions in PosAr[]
 */
{
    if(PosAr==NULL) return U_ERROR;

    double* pFreeDip = PosAr;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==true)  continue;
        
        pFreeDip[0] = DipArr[k].Getx().Getx();
        pFreeDip[1] = DipArr[k].Getx().Gety();
        pFreeDip[2] = DipArr[k].Getx().Getz();
        pFreeDip += 3;                    
    }
    return U_OK;
}

int UDipoleManager::GetNfreePosPars(int idip) const
/*
    Get the number of free dipole position parameters of dipole idip .
    This number is either 0 or 3.

 */
{
    if(idip<0 || idip>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleManager::GetNfreePosPars(). Argument out of range: idip = %d, max = %d \n",idip, Ndip);
        return 0;
    }

    if(DipArr[idip].IsPositionFixed()==true)  return 0;
    return 3;
}

UDipoleFix  UDipoleManager::GetFreeDipole(int idip) const
/*
    Return the idip-th free dipole (non-position fixed dipole).

    The error default on error.
 */
{
    if(idip<0 || idip>=Ndip) return UDipoleFix();
    
    int idtest =0;
    for(int k=0; k<Ndip; k++)
    {
        if(DipArr[k].IsPositionFixed()==true)  continue;

        if(idip==idtest)
            return DipArr[k];

        idtest++;
    }
    return UDipoleFix();
}

bool UDipoleManager::IsDipoleRotating(int idip)
/*
    Return true iff the idip-th dipole is rotating.

    The error value is false.
 */
{
    if(idip<0 || idip>=Ndip) return false;
    return DipArr[idip].AreMomentsRotating();
}

bool UDipoleManager::IsDipolePosFixed(int idip)
/*
    Return true iff the idip-th dipole is fixed at its starting values..

    The error value is false.
 */
{
    if(idip<0 || idip>=Ndip) return true;
    return DipArr[idip].IsPositionFixed();
}
