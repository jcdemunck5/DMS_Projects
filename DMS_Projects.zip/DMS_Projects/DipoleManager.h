/*
  Update history
  
  Who    When       What
  Jdm    27-11-01   creation  
  FB     10-12-02   Made some private members protected
*/
#ifndef _DIPOLEMAN_INCLUDED
#define _DIPOLEMAN_INCLUDED


#include "Dipole.h"

class UDipoleFix : public UDipole
{
public:
    UDipoleFix(UDipole Dip, bool PosFix, bool MomRot);
    UDipoleFix();
    UDipoleFix& operator=(const UDipoleFix& dip);
    UDipoleFix& operator=(const UDipole& dip);
    
    bool IsPositionFixed(void) const {return PositionFixed;}
    bool AreMomentsRotating(void) const {return MomentsRotating;}

private:
    bool PositionFixed;    // iff true: Fixed at start position
    bool MomentsRotating;  // iff true: All moments are free to rotate
};

class UDipoleEdit;
class UDipoleManager
{
public:
    UDipoleManager();
    UDipoleManager(const UDipoleFix* DipoleArray, int Ndipoles, const double* const* pWDerivField, int Nsensors);
    UDipoleManager(const UDipole* DipoleArray, int Ndipoles, bool AllRotating, const double* const* pWDerivField, int Nsensors);
    UDipoleManager(int Ndipoles, const UDipoleEdit* DipEd, const double*const* pWDerivField, int Nsensors);

    virtual ~UDipoleManager();
    UDipoleManager& operator=(const UDipoleManager& DM);

    ErrorType        GetError(void) const {if(this) return error; return U_ERROR;}
    UString&         GetProperties(UString Comment) const;

    ErrorType        SetNdipoles(int Ndipoles);
    ErrorType        UpdateDipolePositions(const double* FreePositions);
    ErrorType        UpdateDipoleMoments(const double* FreeMoments);
    ErrorType        UpdateFreeDipoles(const UDipole* DipoleArray);
	ErrorType        SetDipolesTangential(UVector3 SpherePos);

    ErrorType        GetAllDipoles(UDipole* DipArray);
    ErrorType        GetAllDipoles(UDipoleEdit* DipEd);
    ErrorType        GetFreeDipoles(UDipole* DipArray);
    ErrorType        SetFreeDerivField(const double* const* pWFreeDerivField);
    bool             IsDipoleRotating(int idip);
    bool             IsDipolePosFixed(int idip);

    int              GetNfreeSTF(void) const {return NSourceTimeFunc;}
    int              GetNfreeSTF(int idip) const;
    int              GetNfreeSTFMEG(void) const;
    const double*    GetFieldSTF(void) const;

    int              GetNDipoles(void) const {return Ndip;}
    
    int              GetNfreeMoment(void) const {return Nmoment;}
    int              GetNfreeMoment(int idip) const;
    int              GetNfreeMomentMEG(void) const;
    const double*    GetFieldMoment(void) const;

    int              GetNfreePosPars(void) const {return Npospars;}
    int              GetNfreePosPars(int idip) const;
    const double*    GetPositionArray(void) const;
    ErrorType        GetPositionArray(double* PosAr) const;
    UDipoleFix       GetFreeDipole(int idip) const;
    
protected:
    int              Ndip;                  // The number of dipoles
    int              NSourceTimeFunc;       // The number of free source time functions
    UDipoleFix*      DipArr;                // Array with constraint and free dipoles
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    static UString   Properties;       // General flag containing properties in text format   
    ErrorType        error;            // General error flag

    int              Nsens;            // Number of sensors
    int              Nmoment;          // The number of free moment parameters
    int              Npospars;         // The number of free position parameters
    double*          PosPars;          // array with free dipole position parameters
    double**         pWDerPsi;         // array with derivatives of dipole fields w.r.t. (all) moments,
                                       // multiplied with the square root of the spatial covariance
    double*          Emfield;          // General purpose array to store emfields, returned by e.g.
                                       // GetDerFreeField() and GetFieldSTF()
};


#endif // _DIPOLEMAN_INCLUDED
