/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for maintaining the data of a dipole an additional property: Value.*/
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    17-08-99   creation
  JdM    31-12-00   Added DeltaX, DeltaY and DeltaZ
  JdM    11-04-01   Added MEGDataPower
  JdM    15-04-02   Added GroupNo    
  JdM    12-12-02   Added Col
  JdM    13-05-03   Added HeaderIndex
*/

#include"DipoleMove.h"


UDipoleMove::UDipoleMove(UVector3 xd, UVector3 dd, DipoleType DipType) : 
    UDipole(xd, dd, DipType)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(UVector3 xd, UVector3 dd, UVector3 ddSym) :
   UDipole(xd, dd, ddSym)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(double x, double y, double z, double dx, double dy, double dz,  DipoleType DipType) :
   UDipole(x, y, z, dx, dy, dz, DipType)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(double x, double y, double z, double dx, double dy, double dz, double dxS, double dyS, double dzS) : 
    UDipole(x, y, z, dx, dy, dz, dxS, dyS, dzS)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(double x, double y, double z, double Th, double Fi,  DipoleType DipType) : 
   UDipole(x, y, z, Th, Fi, DipType)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(const UDipoleMove &dip)  :
    UDipole((UDipole)dip)
/*
    Copy constructor.
 */
{
    ResError     = dip.ResError;
    Time         = dip.Time;
    MEGDataPower = dip.MEGDataPower;
    DeltaX       = dip.DeltaX;
    DeltaY       = dip.DeltaY;
    DeltaZ       = dip.DeltaZ;
    GroupNo      = dip.GroupNo;
    Col          = dip.Col;
    HeaderIndex  = dip.HeaderIndex;
}

UDipoleMove::UDipoleMove(const UDipole &dip)  :
    UDipole((UDipole)dip)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove::UDipoleMove(char* String, int MaxChar) :
    UDipole(String, MaxChar)
{
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
}

UDipoleMove& UDipoleMove::operator=(const UDipoleMove& dip)
/* 
  Assignment operator
*/
{
    UDipole::operator=((UDipole) dip);
    
    ResError     = dip.ResError;
    Time         = dip.Time;
    MEGDataPower = dip.MEGDataPower;
    DeltaX       = dip.DeltaX;
    DeltaY       = dip.DeltaY;
    DeltaZ       = dip.DeltaZ;
    GroupNo      = dip.GroupNo;
    Col          = dip.Col;
    HeaderIndex  = dip.HeaderIndex;

    return *this;
}

UDipoleMove& UDipoleMove::operator=(const UDipole& dip)
/* 
  Assignment operator
*/
{
    UDipole::operator=(dip);
    ResError     = 0.;
    Time         = 0.;
    MEGDataPower = 0.;
    DeltaX       = 0.;
    DeltaY       = 0.;
    DeltaZ       = 0.;
    GroupNo      = 0;
    HeaderIndex  = 0;
    return *this;
}
