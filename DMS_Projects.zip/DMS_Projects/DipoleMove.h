#ifndef _DIPOLEMOVE_INCLUDED
#define _DIPOLEMOVE_INCLUDED

#include "Dipole.h"
#include "Color.h"

class DLL_IO UDipoleMove : public UDipole
{
public: 
    UDipoleMove(UVector3 xd=UVector3(), UVector3 dd=UVector3(), DipoleType DipType = Current);
    UDipoleMove(UVector3 xd, UVector3 dd, UVector3 ddSym); 
    UDipoleMove(double x, double y, double z, double dx, double dy, double dz,  DipoleType DipType = Current);
    UDipoleMove(double x, double y, double z, double dx, double dy, double dz, double dxS, double dyS, double dzS);
    UDipoleMove(double x, double y, double z, double Th, double Fi,  DipoleType DipType = Current);
    UDipoleMove(char *String, int Maxchar);
    UDipoleMove(const UDipoleMove &dip);
    UDipoleMove(const UDipole &dip);

    UDipoleMove& operator=(const UDipoleMove& dip);
    UDipoleMove& operator=(const UDipole& dip);

    void             SetResidualError(double Res) {ResError=Res;}
    void             SetTime(double tim)          {Time    =tim;}
    void             SetDelta(UVector3 Del)       {DeltaX  = Del.Getx(); DeltaY = Del.Gety(); DeltaZ = Del.Getz();}
    void             SetMEGDataPower(double MEGDP){MEGDataPower=MEGDP;}
    void             SetGroup(int Grp)            {GroupNo = Grp;}
    void             SetColor(UColor C)           {Col     = C;}
    void             SetColor(unsigned char R, unsigned char G, unsigned char B) {Col=UColor(R,G,B);} 
    void             SetHeaderIndex(int index)    {HeaderIndex = index;}

    virtual double   GetResidualError(void) const {return ResError;}
    virtual double   GetTime(void)          const {return Time;}
    UVector3         GetDelta(void)         const {return UVector3(DeltaX, DeltaY, DeltaZ);}
    double           GetMEGDataPower(void)  const {return MEGDataPower;}
    int              GetGroup(void)   const {return GroupNo;}
    UColor           GetColor(void)   const {return Col;}
    int              GetHeaderIndex(void) const {return HeaderIndex;}

private:            
    double           ResError;       // Residual error in %
    double           Time;           // Time in ms (!!!), starting from the recording of the data file
    double           MEGDataPower;   // (Average) power of the MEG data, at the time the dipole was fitted
    double           DeltaX;         // 95% confidence interval in x-coordinate
    double           DeltaY;         // 95% confidence interval in y-coordinate
    double           DeltaZ;         // 95% confidence interval in z-coordinate
    int              GroupNo;        // Number put in dipole file, used for color coding 
    int              HeaderIndex;    // Dipole header index, used to retrieve additional dipole info
    UColor           Col;            // Color
};

#endif // _DIPOLEMOVE_INCLUDED


