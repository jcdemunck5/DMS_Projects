/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    17-08-99   creation 
  JdM    21-01-00   For column 0, substract sample number of first dipole
  AdJ    24-01-00   Bug fix in plotting dipoles (begin/end mark)
  JdM    25-01-00   Added GetValue() and GetDipole()
  JdM    25-01-00   Complete revision: Use an array of pointers to dipoles instead of an array of dipoles
  JdM    09-02-00   Allow for sample times in double format
  JdM    11-02-00   MaxError<0 means: take all dipoles
JdM/AdJ  16-06-00   Renamed DipolePlotList to DipoleMoveList
                    Major revision: use UDistribution object to avoid outliers, etc
  JdM    04-09-00   Revision, use the sub-header collumn info to read simultaneous dipoles
  JdM    12-09-00   Added data set name to UDipFileHeader()-object
  JdM    19-09-00   bug fix: fopen() Use binary, else ftell() does not work
                    InitLine() return U_ERROR for empty lines (which are subsequently skipped)
                    Added GetHeaderNumber() and GetEvent() on UDipoleMoveList
  AdJ    20-09-00   bug fix: GetHeaderNumber. return HeaderNumbers corrected
                    Added GetSRate() and GetPreStim() in header file
  JdM    31-12-00   Added Reading and color coding of confidence intervals
  JdM    02-01-01   Added PlotConfInterval(), added option to export confidence intervals in WriteXDR()
                    Bug Fix WriteXDR(): rotate dipole direction to world before plotting Dir
  JdM    04-01-01   Launch error when MAXLINE is too small to read line
  JdM    05-01-01   Allow for isolated comment lines in the file, which do not represent a dipole header
  JdM    23-01-01   Bug fix in UDipFileHeader::UDipFileHeader(), test for NULL pointers       
  JdM    07-02-01   Read NLR position from dipole file sub-header
  JdM    11-02-01   Several bug fixes in plotting confidence intervals
  JdM    15-02-01   GetProperties(): Bug fixes in computing the fraction of good fitting dipoles.
 AdJ/JdM 19-02-01   UDipFileHeader::UDipFileHeader() and ReadDipoles() : 
                    Some bug fixes, dealing with old dipole files, with many sub-headers
  JdM    11-03-01   Added ConfIntervalComputed() and WriteConfEllipses()
  JdM    13-03-01   Move all Plot functions to base class: UDipolePlotList() in DipolePlotList.cpp
  JdM    22-03-01   Put Dipole header properties in separate string, DipFileProperties[], which is exported as comments in XDR-files
                    Bug fixs in WriteConfEllipses(): (semi) symmetric dipoles
  JdM    11-04-01   Added readinf MEGdataPower collumn  (called "AverDataPower")
                    Added GetDipole()
  GdV    09-05-01   small change(s) for Unix compatibility
  JdM    01-06-01   Added SortDipoles(ColorCode CC);
  JdM    22-08-01   Added CorrectPreStimTimes()
  JdM    23-08-01   ALWAYS correct time information for prestiminterval (Remove CorrectPreStimTimes())
                    Allow dipole selection by time information
  JdM    31-08-01   Bug fix: ReadDipoles(). Ignore time information when Tmin>Tmax
  JdM    13-09-01   Split off the dipole header part into "DipHeader.cpp"
JdM/SG   09-11-01   Bug Fix: GetEvent(). Due to changes dd 23-08-01 the dipole time has to be corrected for the pre-stimulus time
  JdM    14-12-01   Added GetSpherePos()
  JdM    09-01-02   Bug fix: GetHeaderNumber(). 
  JdM    16-01-02   Allow 16 bytes in GetProperties() comment string
  JdM    23-01-02   Bug fix: For compatibility of old dipole files and intermediate
                    comment strings, reset NdipHead only after the dipole header was found corect
  JdM    15-04-02   Add the option to color code the dipoles accorging to a collumn named "group"
  JdM    31-10-02   Added the time range within the dipole selection is made. Add GetDipoleSelection();
  JdM    12-12-02   Remove obsolete data members (ColorDistr and Pal) and functions (SetColorCode).
                    Add functions SetDipoleColors() and ComputeMagitudeScalind()
                    add MergeDipoles()
  JdM    15-12-02   Add two other MergeDipoles(), based upon UBitmap and UColor
                    Bug fix MergeDipoles(). Adding headers (idices)
  JdM    16-12-02   Add the option to color code according to HeaderNumber
  JdM    25-12-02   Added SetGroupNumber()
  JdM    07-02-03   Added GetDatasetName()
  JdM    17-02-03   SetDipoleColors(). Added color coding based on U_CC_MAGNITUDE   
  JdM    13-05-03   Account for HeaderIndex member of UDipoleMove
                    Allow sortin of dipoles on time
                    Add SubSample()
  JdM    14-05-03   Added GetGroupNumbers(), GetNGroup(), GetNDataSetNames() and GetDataSetName()
  JdM    18-05-03   Bug fix GetGroupNumbers(), GetNGroup()
  JdM    24-05-03   Added: IsMatchMRtoWldInAllHeaders(), IsMatchMRtoWldInHeader(), IsNLR_MR_InAllHeaders(), IsNLR_MR_InHeader()
                           GetNdipoles() and GetNsampInDataSet()
                    Note: Renamed GetDatasetName() into GetDipDataSetName()
                          and     GetDataSetName() into GetDataSetNameIndex()
  JdM    25-05-03   Bug fix: SetDipoleColors(). Prevent overflow of unsigned char
  JdM    20-09-03   Added GetDipoleDensity();
  JdM    24-09-04   Added GetDipoleDensityScan();
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-01-05   Use UAnalyzeLineExt as argument of various of UDipFileHeader()
  JdM    05-01-05   Add AddDipole()
                    GetProperties(): use UString()
  JdM    05-01-05   Added DeleteAllMembers() and SetAllMembersDefault()
                    new constructor and WriteDipoles()
  JdM    06-01-05   SetDipoleColors(), use (0.,1.) to set default UDistribution()
  JdM    11-01-05   Copy constructor: set NdipAllocated
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    18-01-11   GetDipoleDensityScan(). Removed reference to UScan::RawCenter
  JdM    02-08-13   Added AbsoluteTime-parameter to choose between absolute or relative time
  JdM    09-09-13   SetDipoleColors(). Changed algorithm to map iheader and group numbers to color scale (avoid first and last colors on bitmap scale)
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    22-01-15   Added GetMinResidualErrorPresent()
  */

#include <stdlib.h>
#include <string.h>
 
#include "DipoleMoveList.h"
#include "AnalyzeLineExt.h"
#include "Palette.h"
#include "BitMap.h"

#include "Distribution.h"
#include "PatTree.h"
#include "Field.h"
#include "Surface.h"
#include "Scan.h"

#include "MEEGDataBase.h"
#include "HeadModel.h"

/* Inititalize static const parameters. */

/* Local defines */
#define MAXLINE    10000

void UDipoleMoveList::SetAllMembersDefault(void)
{
    error             = U_OK;

    DipFileProperties = UString();
    DipFileName       = NULL;    
    Nheader           = 0; 
    Nfiles            = 0;
    Ndip              = 0;
    NtotDip           = 0; 
    MinError          = 0.;
    MaxError          = 0.;    
    MinTimeRange      = 0.;
    MaxTimeRange      = 0.;
    SubSampleMS       = 0.;

    for(int k=0; k<MAXHEADER; k++) headers[k] = NULL;
}

void UDipoleMoveList::DeleteAllMembers(void)
{
    for(int k=0; k<MAXHEADER; k++) 
        delete headers[k];
    delete[] DipFileName;
    SetAllMembersDefault();
}

UDipoleMoveList::UDipoleMoveList(const char* FileName, double MaxEr, double Tmin, double Tmax) :
    UDipoleList()
{
    SetAllMembersDefault();
    if(FileName==NULL)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Invalid NULL FileName. \n");
        return;
    }
    size_t nbytes     = strlen(FileName) + 1;
    DipFileName       = new char[nbytes];
    if(DipFileName==NULL)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Memory allocation. \n");
        return;
    }
    memset(DipFileName, 0, nbytes);
    memcpy(DipFileName, FileName, nbytes-1);


    for(int k=0; k<MAXHEADER; k++) headers[k] = NULL;
    Nfiles        = 1;
    error         = ReadDipoles(FileName, MaxEr, Tmin, Tmax);
    if(error!=U_OK)
    {
        DeleteAllMembers();
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Reading dipoles from %s  . \n", FileName);
        return;
    }
    MaxError      = MaxEr;    
    MinTimeRange  = Tmin;
    MaxTimeRange  = Tmax;
}

UDipoleMoveList::UDipoleMoveList(const UMEEGDataBase* Data, const UHeadModel* HM, const UEpochs* Epo, bool TimeInSamp, bool UseAbsTime, UDipole::DipoleType DipType, bool ConfInt) :
    UDipoleList()
{
    SetAllMembersDefault();
    if(Data==NULL || Data->GetError()!=U_OK ||
       HM  ==NULL || HM  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). NULL or Erroneous UMEEGDataBase or UHeadModel argument(s) .\n");
        error = U_ERROR;
        return;
    }

    headers[0] = new UDipFileHeader(Data, HM, Epo, TimeInSamp, UseAbsTime, DipType, ConfInt);
    if(headers[0]==NULL || headers[0]->GetError()!=U_OK)
    {
        DeleteAllMembers();
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). NULL or Erroneous UMEEGDataBase or UHeadModel argument(s) .\n");
        error = U_ERROR;
        return;
    }
    Nheader       = 1; 
    NdipAllocated = 100;
    DipoleArray   = new UDipole*[NdipAllocated];
    if(DipoleArray==NULL)
    {
        UDipoleList::DeleteAllMembers();
        DeleteAllMembers();
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Memory allocation: NdipAllocated = %d  .\n", NdipAllocated);
        error = U_ERROR;
        return;
    }
    for(int n=0; n<NdipAllocated; n++) DipoleArray[n] = NULL;
}

UDipoleMoveList::UDipoleMoveList(const UDipoleMoveList& DML) :
    UDipoleList()
{
    SetAllMembersDefault();

    if(&DML==NULL)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Argument has NULL address. \n");
        return;
    }

/* Start copying */
    DistType          = DML.DistType;
    Ndip              = DML.Ndip;
    NtotDip           = DML.NtotDip; 
    Nheader           = DML.Nheader; 
    Nfiles            = DML.Nfiles;
    MinError          = DML.MinError;
    MaxError          = DML.MaxError;    
    MinTimeRange      = DML.MinTimeRange;
    MaxTimeRange      = DML.MaxTimeRange;    
    SubSampleMS       = DML.SubSampleMS;
    DipFileProperties = DML.DipFileProperties;

    if(DML.DipFileName)
    {
        size_t   nb = 2+strlen(DML.DipFileName);
        DipFileName = new char[nb];
        if(DipFileName) strcpy(DipFileName, DML.DipFileName);
    }
    for(int n=0; n<Nheader; n++)
    {
        headers[n] = new UDipFileHeader( *(DML.headers[n]) );
        if(headers[n]->GetError()!=U_OK)
        {
            for(int nn=0; nn<=n; nn++)
            {
                delete headers[nn];
                headers[nn] = NULL;
            }
            UDipoleList::DeleteAllMembers();
            DeleteAllMembers();
            error = U_ERROR;
            CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Copying headers, starting from %d \n", n);
            return;
        }
    }
    DipoleArray = new UDipole*[Ndip];
    if(DipoleArray)
    {
        for(int n=0; n<Ndip; n++)
        {
            UDipoleMove* pDipMove = (UDipoleMove*) (DML.DipoleArray[n]);
            DipoleArray[n]        = new UDipoleMove( *pDipMove );
            if(DipoleArray[n] == NULL)
            {
                for(int nn=0; nn<=n; nn++)
                    delete DipoleArray[n];
                delete[] DipoleArray; DipoleArray = NULL;

                UDipoleList::DeleteAllMembers();
                DeleteAllMembers();
                error = U_ERROR;

                CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Copying dipole, starting from %d \n", n);
                return;
            }
        }
        NdipAllocated = Ndip;
    }

/* Test for succes */    
    if(  (DML.DipFileName         && !DipFileName      ) ||
         (DML.DipoleArray         && !DipoleArray      ))
    {
        CI.AddToLog("ERROR: UDipoleMoveList::UDipoleMoveList(). Copying objects. \n");
        UDipoleList::DeleteAllMembers();
        DeleteAllMembers();
        error = U_ERROR;
        return;
    }
    error = U_OK;
}

UDipoleMoveList::~UDipoleMoveList()
{
    DeleteAllMembers();
}

ErrorType UDipoleMoveList::AddDipole(UDipole Dip)
{
    return AddDipole(UDipoleMove(Dip));
}

ErrorType UDipoleMoveList::AddDipole(UDipoleMove Dip)
{
    if(NdipAllocated-Ndip<1) // Allocate new memory for dip
    {
        int NewAlloc = 2*NdipAllocated+2;
        if(NewAlloc<100)   NewAlloc = 100;
        if(NewAlloc>10000) NewAlloc = NdipAllocated+10000; 

        UDipole** NewDipoleArray = new UDipole*[NewAlloc];
        if(NewDipoleArray==NULL)
        {
            CI.AddToLog("WARNING: UDipoleMoveList::AddDipole(). Re-allocating memory, NdipAllocated = %d, Ndip = %d  .\n", NdipAllocated, Ndip);
            return U_ERROR;
        }
        for(int n=0;    n<Ndip;     n++) NewDipoleArray[n] = DipoleArray[n];
        for(int n=Ndip; n<NewAlloc; n++) NewDipoleArray[n] = NULL;

        delete[] DipoleArray;    DipoleArray = NewDipoleArray;
        NdipAllocated = NewAlloc;
    }
    DipoleArray[Ndip] = new UDipoleMove(Dip);
    if(DipoleArray[Ndip]==NULL) 
    {
        CI.AddToLog("WARNING: UDipoleMoveList::AddDipole(). Creating new moving dipole, Ndip = %d .\n", Ndip);
        return U_ERROR;
    }
    Ndip++;
    NtotDip++;
    headers[Nheader-1]->IncreaseNdip();
    return U_OK;
}

ErrorType UDipoleMoveList::ReadDipoles(const char *FileName, double MaxEr, double Tmin, double Tmax)
/*
      Read the dipole file FileName[], take dipoles with maximum errors MaxEr
      and set time and error parameter in each UDipoleMove
 */
{
    FILE*        fp = NULL;
    if(FileName) fp = fopen(FileName,"rb");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::ReadDipoles(). Cannot open dipole file %s\n",FileName);
        return U_ERROR;
    }

    for(int k=0; k<MAXHEADER; k++) 
    {
        delete headers[k];
        headers[k] = NULL;
    }

/* read and allocate first header*/
    headers[0] = new UDipFileHeader(fp);
    if(headers[0]==NULL || headers[0]->GetError()!=U_OK || headers[0]->GetTimeInfo()==UDipFileHeader::U_TIME_UNKNOWN)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UDipoleMoveList::ReadDipoles(). Dipole file does not start with valid header. File= %s\n",FileName);
        return U_ERROR;
    }
    Nheader  = 1;  

    for(int n=0; n<Ndip; n++) delete DipoleArray[n];
    delete[] DipoleArray;

/* Count the number of dipoles with an error smaller than MaxEr*/
    char line[MAXLINE];

    Ndip          =  0;   // The number of dipoles with a sub-threshold error
    NtotDip       =  0;   // The total number of dipoles; 
    int  NdipHead =  0;   // The number of dipoles for each header

    bool FirstComment = true;
    while(1)
    {
        long ioff     = ftell(fp);
        if(!GetLine(line, sizeof(line), fp)) break;
        if(line[sizeof(line)-1]!=0)
        {
            fclose(fp);
            CI.AddToLog("ERROR: UDipoleMoveList::ReadDipoles(). Line buffer overflow. Max char = %d\n",(int)sizeof(line));
            return U_ERROR;
        }

        UAnalyzeLineExt AA(line, MAXLINE);
        if(AA.IsEmptyLine()==true) continue;

        if(AA.IsComment() == false) 
        {
            FirstComment = false;

            double  Err  = headers[Nheader-1]->GetResError(AA);
            int     Nsim = headers[Nheader-1]->GetNsimulDip();

            if(MaxEr<0 || Err<=MaxEr) 
            {
                double PreStimMs = 1000*headers[Nheader-1]->GetPreStim();
                double Sample    = headers[Nheader-1]->GetSample(AA);
                double Time      = -PreStimMs + headers[Nheader-1]->GetTimeInms(Sample);
                
                if(Tmin>Tmax || (Tmin<=Time && Time<=Tmax))
                {
                    Ndip    += Nsim;
                    NdipHead+= Nsim;
                }
            }
            NtotDip += Nsim;
        }
        else
        {
            fseek(fp, ioff, SEEK_SET);    // Include first comment statement in header
            headers[Nheader-1]->SetNdip(NdipHead);
            headers[Nheader  ] = new UDipFileHeader(fp, headers[Nheader-1]);
            if(headers[Nheader] && headers[Nheader]->GetError()==U_OK)
            {
                NdipHead = 0;  // Reset number of dipoles per header
                Nheader++;
            }
            else
            {
                delete headers[Nheader]; headers[Nheader] = NULL;
                static int Nwarning = 0;
                if(Nwarning<10)
                {
                    CI.AddToLog("WARNING: UDipoleMoveList::ReadDipoles(). Ignore erroneous sub-header, assume pure comment lines. File= %s; Subheader %d.\n", FileName, Nheader);
                    Nwarning++;
                }
            }
        }
    }
    headers[Nheader-1]->SetNdip(NdipHead);

    DipoleArray        = new UDipole*[Ndip];

    if(DipoleArray==NULL) 
    {
        delete[] DipoleArray;        DipoleArray        = NULL;
        CI.AddToLog("ERROR: UDipoleMoveList::ReadDipoles(). Memory allocation. Ndip = %d \n", Ndip);
        Ndip = -1;
        fclose(fp); 
        return U_ERROR;
    }

/* Read the file.*/
    rewind(fp);
    UDipFileHeader DumH(fp); // Skip header info

    Ndip        = 0;
    NtotDip     = 0;
    int iheader = 0;

    while(1)
    {
        long ioff     = ftell(fp);
        if(!GetLine(line, sizeof(line), fp)) break;

        UAnalyzeLineExt AA(line, MAXLINE);
        if(AA.IsEmptyLine()==true) continue;

        if(AA.IsComment() == false) 
        {
            double  Err  = headers[iheader]->GetResError(AA);
            int     Nsim = headers[iheader]->GetNsimulDip();

            if(MaxEr<0 || Err<=MaxEr)
            {
                double MEGDP     = headers[iheader]->MEGDataPower(AA);
                double PreStimMs = 1000*headers[iheader]->GetPreStim();
                double Sample    = headers[iheader]->GetSample(AA);
                double Time      = -PreStimMs + headers[iheader]->GetTimeInms(Sample);
                
                if(Tmin>Tmax || (Tmin<=Time && Time<=Tmax))
                {
                    for(int k=0; k<Nsim; k++, Ndip++)
                    {
                        UDipole Dip       = headers[iheader]->GetDipole(k, AA);
                        DipoleArray[Ndip] = new UDipoleMove(Dip);
                            
                        ((UDipoleMove*)DipoleArray[Ndip])->SetTime(Time);
                        ((UDipoleMove*)DipoleArray[Ndip])->SetMEGDataPower(MEGDP);
                        ((UDipoleMove*)DipoleArray[Ndip])->SetResidualError(Err);

                        UVector3 Delta = headers[iheader]->GetDelta(k, AA);
                        int      Grp   = headers[iheader]->GetGroup(k, AA);
                        ((UDipoleMove*)DipoleArray[Ndip])->SetDelta(Delta);
                        ((UDipoleMove*)DipoleArray[Ndip])->SetGroup(Grp);
                        ((UDipoleMove*)DipoleArray[Ndip])->SetHeaderIndex(iheader);
                    }
                }
            }
            NtotDip += Nsim;
        }
        else
        {
            fseek(fp, ioff, SEEK_SET);    // Include first comment statement in header
            UDipFileHeader DumH(fp);      // Skip header info
            if(DumH.GetError()==U_OK) iheader++;
        }
    }

/* Store first comment lines in properties string*/
    rewind(fp);

    DipFileProperties = UString(Nheader, "// Nheader= %d; ") +
                        UString(MaxEr,   "MaxEr = %6.2f %%; ") +
                        UString(NtotDip, "Total Samples = %d; ") +
                        UString(Ndip,    "Total Dipoles = %d; First Header:\n");

    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLineExt AA(line, MAXLINE);
        if(AA.IsComment() == false) break;
        DipFileProperties += UString(line);
    }
    fclose(fp);
    return U_OK;
}

double UDipoleMoveList::GetMinResidualErrorPresent(void) const
{
    if(this==NULL || error!=U_OK) return 0.;
    
    if(DipoleArray==NULL || Ndip<=0) return 0.;
    
    double MinE = DipoleArray[0]->GetResidualError();
    for(int j=0; j<Ndip; j++)
    {
        if(MinE <= DipoleArray[j]->GetResidualError()) continue;
        MinE = DipoleArray[j]->GetResidualError();
    }
    return MinE;
}


ErrorType UDipoleMoveList::WriteDipoles(UFileName File, bool Append, int NDigits) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). Object NULL or not properly set. \n");
        return U_ERROR;
    }
    if(DipoleArray==0 || DipoleArray[0]==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). Dipole array not set or empty. \n");
        return U_ERROR;
    }
    if(Append==false)
    {
        FILE* fpOut = fopen(File, "wt", false); // Create File
        if(fpOut==NULL)
        {
            CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). File cannot be crated: %s .\n", (const char*)File);
            return U_ERROR;
        }
        fclose(fpOut);
    }
    FILE* fpOut = fopen(File, "at", false); // Create File
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). File cannot be crated: %s .\n", (const char*)File);
        return U_ERROR;
    }
    
    ErrorType E = U_OK;
    for(int ihead=0, idip=0; ihead<Nheader; ihead++)
    {
        if(DipoleArray[idip]==NULL || 
           headers[ihead]   ==NULL ||
           headers[ihead]->WriteHeader(fpOut, DipoleArray[idip]->GetDipoleType())!=U_OK)
        {
            CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). Writing header %d; idip = %d .\n", ihead, idip);
            E = U_ERROR;
            break;
        }
        for(int k=0; k<headers[ihead]->GetNdip(); k++, idip++)
        {
            if(DipoleArray[idip]==NULL || 
               headers[ihead]->WriteDipole(fpOut, *((UDipoleMove*)(DipoleArray[idip])), NDigits)!=U_OK)
            {
                CI.AddToLog("ERROR: UDipoleMoveList::WriteDipoles(). Writing dipole %d in header %d .\n", idip, ihead);
                E = U_ERROR;
                break;
            }
        }
        if(E!=U_OK) break;
    }

    fclose(fpOut);
    return E;
}

UDipoleMoveList* UDipoleMoveList::GetDipoleSelection(double MinEr, double MaxEr, double Tmin, double Tmax) const
{
    if(MinEr<MaxEr && MinError<MaxError)
    {
        if(MinEr < MinError || MaxEr>MaxError)
        {
            CI.AddToLog("WARNING: UDipoleMoveList::GetDipoleSection(). Dipole selection migth miss dipoles with low or high residual errors. \n");
        }
    }
    if(Tmin<Tmax && MinTimeRange<MaxTimeRange)
    {
        if(Tmin < MinTimeRange || Tmax>MaxTimeRange)
        {
            CI.AddToLog("WARNING: UDipoleMoveList::GetDipoleSection(). Dipole selection migth miss dipoles with low or high time values. \n");
        }
    }

/* Copy *this*/
    UDipoleMoveList* pDML = new UDipoleMoveList(*this);
    if(pDML==NULL || pDML->GetError()!=U_OK)
    {
        delete pDML;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleSection(). Copying raw dipole UDipoleMoveList object. \n\n");
        return NULL;    
    }

/* and make selection*/
    for(int n=0; n<Ndip; n++)
    {
        int          ihead = GetHeaderNumber(n);  // Get header number from original. Copy may be affected
        UDipoleMove* pDip  = (UDipoleMove*)(pDML->DipoleArray[n]);
        if(pDip && MinEr<MaxEr) // if false, skip error test
        {
            double ResEr = pDip->GetResidualError();
            if(ResEr<MinEr || ResEr>MaxEr)
            {
                delete pDML->DipoleArray[n]; pDML->DipoleArray[n] = NULL;
                pDML->headers[ihead]->DecreaseNdip();
                continue;
            }
        }
        if(pDip && Tmin<Tmax ) // if false, skip time test
        {
            double Time = pDip->GetTime();
            if(Time<Tmin || Time>Tmax)
            {
                delete pDML->DipoleArray[n]; pDML->DipoleArray[n] = NULL;
                pDML->headers[ihead]->DecreaseNdip();
                continue;
            }
        }
    }

/* shift NULL pointers to begin */
    int Nd = 0;
    for(int n=0; n<Ndip; n++)
    {
        if(pDML->DipoleArray[n]==NULL) continue;
        
        pDML->DipoleArray[Nd++] = pDML->DipoleArray[n];
    }
    for(int n=Nd; n<Ndip; n++) pDML->DipoleArray[n] = NULL;

    pDML->Ndip = Nd;

    pDML->MinError     = MinEr;
    pDML->MaxError     = MaxEr;
    pDML->MinTimeRange = Tmin;
    pDML->MaxTimeRange = Tmax;

    pDML->UpdateMinMax();
    return pDML;
}

UDipoleMoveList* UDipoleMoveList::SubSample(double TimeMS) const
/*
    Sort all dipoles on time, then remove all dipoles from the list that are closer than
    TimeMS ms. away from the previous dipole.
 */
{
    if(TimeMS<0)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SubSample(). Argument out of range: TimeMS = %f \n", TimeMS);
        return NULL;
    }

/* Copy *this*/
    UDipoleMoveList* pDML = new UDipoleMoveList(*this);
    if(pDML==NULL || pDML->GetError()!=U_OK)
    {
        delete pDML;
        CI.AddToLog("ERROR: UDipoleMoveList::SubSample(). Copying raw dipole UDipoleMoveList object. \n");
        return NULL;    
    }
    if(TimeMS==0.) return pDML;

/* sort on time */
    if(pDML->SortDipoles(U_CC_ABSTIME)!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SubSample(). Sorting dipoles on time. \n");
        return NULL;    
    }

/* and make selection*/
    UDipoleMove* DipOld   = (UDipoleMove*)(pDML->DipoleArray[0]);
    int          iheadOld = DipOld->GetHeaderIndex();
    for(int n=1; n<Ndip; n++)
    {
        UDipoleMove* DipNew   = (UDipoleMove*)(pDML->DipoleArray[n]);
        int          iheadNew = DipNew->GetHeaderIndex();

        if(iheadNew==iheadOld && DipOld->GetTime()+TimeMS>DipNew->GetTime())
        {
            delete pDML->DipoleArray[n]; pDML->DipoleArray[n] = NULL;
            pDML->headers[iheadNew]->DecreaseNdip();
            continue;
        }
        DipOld   = DipNew;
        iheadOld = iheadNew;
    }

/* shift NULL pointers to begin */
    int Nd = 0;
    for(int n=0; n<Ndip; n++)
    {
        if(pDML->DipoleArray[n]==NULL) continue;
        
        pDML->DipoleArray[Nd++] = pDML->DipoleArray[n];
    }
    for(int n=Nd; n<Ndip; n++) pDML->DipoleArray[n] = NULL;

    pDML->Ndip         = Nd;
    pDML->SubSampleMS  = TimeMS;
    pDML->UpdateMinMax();
    return pDML;
}

ErrorType UDipoleMoveList::MergeDipoles(const char*FileName)
{
    UDipoleMoveList DML(FileName, MaxError, MinTimeRange, MaxTimeRange);
    if(DML.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Reading dipoles from %s \n", FileName);
        return U_ERROR;
    }
    return MergeDipoles(DML);
}

ErrorType UDipoleMoveList::MergeDipoles(const UDipoleMoveList& DML)
{
    if(&DML==NULL || DML.GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Invalid or NULL argument. \n");
        return U_ERROR;
    }
    if(MaxError!=DML.MaxError)
        CI.AddToLog("WARNING: UDipoleMoveList::MergeDipoles(). MaxError not compatible: MaxError = %f, DML.MaxError = %f. \n", MaxError, DML.MaxError);
    if(MinTimeRange!=DML.MinTimeRange)
        CI.AddToLog("WARNING: UDipoleMoveList::MergeDipoles(). MinTimeRange not compatible: MinTimeRange = %f, DML.MinTimeRange = %f. \n", MinTimeRange, DML.MinTimeRange);
    if(MaxTimeRange!=DML.MaxTimeRange)
        CI.AddToLog("WARNING: UDipoleMoveList::MergeDipoles(). MaxTimeRange not compatible: MaxTimeRange = %f, DML.MaxTimeRange = %f. \n", MaxTimeRange, DML.MaxTimeRange);

    if(Nheader+DML.Nheader>MAXHEADER)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Too many headers (N=%d) \n", Nheader+DML.Nheader);
        return U_ERROR;
    }
    for(int n=Nheader; n<Nheader+DML.Nheader; n++)
    {
        int nAdd = n-Nheader;
        if(DML.headers[nAdd])  headers[n] = new UDipFileHeader( *(DML.headers[nAdd]) );
        else                   headers[n] = NULL;
        if(headers[n]==NULL || headers[n]->GetError()!=U_OK)
        {
            for(int nn=Nheader; nn<=n; nn++)
            {
                delete headers[nn];
                headers[nn] = NULL;
            }
            CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Copying headers, starting from %d \n", n);
            return U_ERROR;
        }
    }

    int      NewNdip = Ndip + DML.Ndip;
    UDipole** NewAr  = new UDipole*[NewNdip];
    if(NewAr==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Allocating memory for %d dipole pointers. \n", NewNdip);
        return U_ERROR;
    }
    for(int n=0; n<NewNdip; n++)
    {
        if(n<Ndip)
        {
            UDipoleMove* pDipMove = (UDipoleMove*) (DipoleArray[n]);
            NewAr[n]              = new UDipoleMove( *pDipMove );
        }
        else
        {
            UDipoleMove* pDipMove = (UDipoleMove*) (DML.DipoleArray[n-Ndip]);
            NewAr[n]              = new UDipoleMove( *pDipMove );
            if(NewAr[n]) ((UDipoleMove*)NewAr[n])->SetHeaderIndex(((UDipoleMove*)NewAr[n])->GetHeaderIndex()+Nheader);
        }
        if(NewAr[n] == NULL)
        {
            for(int nn=0; nn<=n; nn++)
                delete NewAr[n];
            CI.AddToLog("ERROR: UDipoleMoveList::MergeDipoles(). Copying dipole, starting from %d \n", n);
            return U_ERROR;
        }
    }
    delete[] DipoleArray;
    DipoleArray = NewAr;
    Ndip        = NewNdip;
    NtotDip    += DML.NtotDip;
    Nheader    += DML.Nheader;  
    Nfiles++;

    return UpdateMinMax();
}

bool UDipoleMoveList::IsMatchMRtoWldInAllHeaders() const
/*
     Return true iff MatchScanToWld (from string "(tx=,ty=,tz=), (rx=,ry=,rz=)") is present
     (non-trivial) in all (non-empty) headers.
 */
{
    for(int n=0; n<Nheader; n++)
    {
        if(headers[n]->GetNdip()==0) continue;
        if(this->IsMatchMRtoWldInHeader(n)==false) return false;
    }
    return true;
}

bool UDipoleMoveList::IsMatchMRtoWldInHeader(int ihead) const
/*
     Return true iff MatchScanToWld (from string "(tx=,ty=,tz=), (rx=,ry=,rz=)") is present
     in header ihead.
 */
{
    if(ihead<0 || ihead>=Nheader)
    {
        CI.AddToLog("ERROR:UDipoleMoveList::IsMatchMRtoWldInHeader(). Argument out of range: ihead = %d . \n", ihead);
        return false;
    }
    UEuler MRtoWld = headers[ihead]->GetMRtoWld();
    if(MRtoWld==UEuler()) return false;

    return true;
}

bool UDipoleMoveList::IsNLR_MR_InAllHeaders() const
/*
     Return true iff both Nasion, Left and Right markers are present in MR coordinates 
     (non-trivial) in all (non-empty) headers.
 */
{
    for(int n=0; n<Nheader; n++)
    {
        if(headers[n]->GetNdip()==0) continue;
        if(this->IsNLR_MR_InHeader(n)==false) return false;
    }
    return true;
}

bool UDipoleMoveList::IsNLR_MR_InHeader(int ihead) const
/*
     Return true iff both Nasion, Left and Right markers are present in MR coordinates in header ihead.
 */
{
    if(ihead<0 || ihead>=Nheader)
    {
        CI.AddToLog("ERROR:UDipoleMoveList::IsNLR_MR_InHeader(). Argument out of range: ihead = %d . \n", ihead);
        return false;
    }
    UVector3 NasMR = headers[ihead]->GetNasionMR(); if(NasMR==UVector3()) return false;
    UVector3 LefMR = headers[ihead]->GetLeftMR();   if(LefMR==UVector3()) return false;
    UVector3 RigMR = headers[ihead]->GetRightMR();  if(RigMR==UVector3()) return false;

    return true;
}

ErrorType UDipoleMoveList::SetGroupNumber(int idip, int igroup)
{
    if(idip<0 || idip>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetGroupNumber(). Parameter out of range, idip=%d\n",idip);
        return U_ERROR;
    }
    if(DipoleArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetGroupNumber(). DipoleArray not set (==NULL). \n");
        return U_ERROR;
    }
    ((UDipoleMove*)DipoleArray[idip])->SetGroup(igroup);
    return U_OK;
}

int UDipoleMoveList::GetHeaderNumber(int idip) const
{
    if(idip<0 || idip>=Ndip)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetHeaderNumber(). Parameter out of range, idip=%d\n",idip);
        return 0;
    }
    return ((UDipoleMove*)DipoleArray[idip])->GetHeaderIndex();
}

const char* UDipoleMoveList::GetDipDataSetName(int idip) const
{
    int ihead = GetHeaderNumber(idip);
    if(headers[ihead]==NULL) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipDatasetName(). Data set unknown for dipole (%d), header (%d)", idip, ihead);
        return "Data_set_unknown";
    }               
    return headers[ihead]->GetDataSetName();
}

bool UDipoleMoveList::ConfIntervalComputed(void) const
/* 
   return true iff confidence interval are present in at least one of the dipole headers
 */
{
    for(int ihead=0; ihead<Nheader; ihead++)
        if(headers[ihead]->ConfIntervalComputed()==true) return true;
    return false;
}

UEvent UDipoleMoveList::GetEvent(int idip) const
{
    int ihead        = GetHeaderNumber(idip);
    double PreStimMs = 1000*headers[ihead]->GetPreStim();
    double TimeAbs   = PreStimMs + ((UDipoleMove* )DipoleArray[idip])->GetTime();

    return headers[ihead]->GetEvent( TimeAbs );
}

UDipoleMove UDipoleMoveList::GetDipole(int idip) const
{
    if(idip<0 || idip>=NtotDip)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipole(). Parameter out of range, idip=%d\n",idip);
        return UDipoleMove();
    }
    return *((UDipoleMove*)DipoleArray[idip]);
}

UVector3 UDipoleMoveList::GetSpherePos(int idip) const
{
    if(idip<0 || idip>=NtotDip)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetSpherePos(). Parameter out of range, idip=%d\n",idip);
        return UVector3();
    }
    int ihead = GetHeaderNumber(idip);
    return headers[ihead]->GetSpherePos();
}

ErrorType UDipoleMoveList::SetDipoleColors(const UColor *Col)
/*
   Give all dipoles the color *Col.
 */
{
    if(Col==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Invalid NULL color argument.\n");
        return U_ERROR;
    }

/* Color the dipoles*/    
    for(int n=0; n<Ndip; n++)
    {
        ((UDipoleMove*)DipoleArray[n])->SetColor(*Col);
    }
    return U_OK;
}

ErrorType UDipoleMoveList::SetDipoleColors(ColorCode CC, const UBitMap *Bit)
/*
   Attribute a color to each dipole (UDipoleMove) according to the coloring scheme CC
   and the pallette present in *Bit
 */
{
    if(Bit==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Invalid NULL bitmap argument.\n");
        return U_ERROR;
    }
    
    const int NBIN = 256;
    UDistribution PropDis(NBIN, 0., 1.);
    if(PropDis.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Cannot create UDistribution object for residual errors.\n");
        return U_ERROR;
    }
    double MaxDat = 0;
    if(CC==U_CC_MAGNITUDE)
    {
        for(int k=0; k<Ndip; k++) MaxDat += ((UDipoleMove*)DipoleArray[k])->GetMagnitude();
        if(Ndip) MaxDat = 5*MaxDat/Ndip;
    }
    if(CC==U_CC_DATAPOWER)
    {
        for(int k=0; k<Ndip; k++) MaxDat += ((UDipoleMove*)DipoleArray[k])->GetMEGDataPower();
        if(Ndip) MaxDat = MIN(100000., 5*MaxDat/Ndip);
    }
    ErrorType E = U_ERROR;
    switch(CC)
    {
        case U_CC_MAGNITUDE: E=PropDis.SetMinMaxRange(0., MaxDat);         break;
        case U_CC_RESERROR:  E=PropDis.SetMinMaxRange(MinError, MaxError); break;
        case U_CC_DATAPOWER: E=PropDis.SetMinMaxRange(0., MaxDat);         break;
        case U_CC_DELTAX:    
        case U_CC_DELTAY:    
        case U_CC_DELTAZ:    E=PropDis.SetMinMaxRange(0., 10.);            break;
        case U_CC_DELTAVOL:  E=PropDis.SetMinMaxRange(0., 100.);           break;
        case U_CC_GROUP:     E=PropDis.SetMinMaxRange(-1., (double)NBIN);  break;
        case U_CC_HEADER:    E=PropDis.SetMinMaxRange(-1., (double)NBIN);  break;
        default:
            CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Invalid argument (%d).\n",CC);
            return U_ERROR;
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Seting distribution range for CC =%d.\n",CC);
        return U_ERROR;
    }

    for(int k=0; k<Ndip; k++)
    {
        double E = 0;
        switch(CC)
        {
        case U_CC_MAGNITUDE: E = ((UDipoleMove*)DipoleArray[k])->GetMagnitude();          break;
        case U_CC_RESERROR:  E = ((UDipoleMove*)DipoleArray[k])->GetResidualError();      break;
        case U_CC_DATAPOWER: E = ((UDipoleMove*)DipoleArray[k])->GetMEGDataPower();       break;
        case U_CC_DELTAX:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Getx();       break;
        case U_CC_DELTAY:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Gety();       break;
        case U_CC_DELTAZ:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Getz();       break;
        case U_CC_DELTAVOL:  E = ((UDipoleMove*)DipoleArray[k])->GetDelta().GetVolume();  break;
        case U_CC_GROUP:     E = ((UDipoleMove*)DipoleArray[k])->GetGroup();              break;
        case U_CC_HEADER:    E = ((UDipoleMove*)DipoleArray[k])->GetHeaderIndex();        break;
        }
        PropDis.AddValue(E);
    }

/* Redistribute the values over the bins */
    double ColFactor = 1.;
    E                = U_ERROR;
    if(CC==U_CC_GROUP||CC==U_CC_HEADER)
    {
        E         = PropDis.RemoveEmptyBins();
        ColFactor = (PropDis.GetNbin()+1)/255.;
        if(ColFactor>0) ColFactor = 1./ColFactor;
        else            ColFactor = 1;
    }
    else
    {
        double Min  = PropDis.GetMinValue();
        double Max  = 5*PropDis.GetMedian();
        if(Max<=Min || Max>PropDis.GetMaxValue()) Max = PropDis.GetMaxValue();
        if(Min==Max) Min-=.00001;
        E = PropDis.ReDistribute(Min, Max, NBIN);
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Redistributing the dipole property histograms.\n");
        return U_ERROR;
    }

/* Color the dipoles*/    
    for(int n=0; n<Ndip; n++)
    {
        double Value = 0;
        switch(CC)
        {
        case U_CC_MAGNITUDE: Value = ((UDipoleMove*)DipoleArray[n])->GetMagnitude();         break;
        case U_CC_RESERROR:  Value = ((UDipoleMove*)DipoleArray[n])->GetResidualError();     break;
        case U_CC_DATAPOWER: Value = ((UDipoleMove*)DipoleArray[n])->GetMEGDataPower();      break;
        case U_CC_DELTAX:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Getx();      break;
        case U_CC_DELTAY:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Gety();      break;
        case U_CC_DELTAZ:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Getz();      break;
        case U_CC_DELTAVOL:  Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().GetVolume(); break;
        case U_CC_GROUP:     Value = ((UDipoleMove*)DipoleArray[n])->GetGroup();             break;
        case U_CC_HEADER:    Value = ((UDipoleMove*)DipoleArray[n])->GetHeaderIndex();       break;
        }
        int icol = PropDis.GetBinNumber(Value);
        if(CC==U_CC_GROUP || CC==U_CC_HEADER) icol = int(ColFactor/2 + icol*ColFactor);
        PMT_RGBQUAD RGB = Bit->GetColor(icol);
        UColor  rgb = UColor(RGB.red, RGB.green, RGB.blue);
        ((UDipoleMove*)DipoleArray[n])->SetColor(rgb);
    }
    return U_OK;
}

ErrorType UDipoleMoveList::SetDipoleColors(ColorCode CC, const UPalette *Pal)
/*
   Attribute a color to each dipole (UDipoleMove) according to the coloring scheme CC
   and the pallette Pal
 */
{
    if(Pal==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Invalid NULL pallette argument.\n");
        return U_ERROR;
    }
    
    const int NBIN = 1000;
    UDistribution PropDis(NBIN, 0., 1.);
    if(PropDis.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Cannot create UDistribution object for residual errors.\n");
        return U_ERROR;
    }

    double MaxDat = 0;
    if(CC==U_CC_MAGNITUDE)
    {
        for(int k=0; k<Ndip; k++) MaxDat += ((UDipoleMove*)DipoleArray[k])->GetMagnitude();
        if(Ndip) MaxDat = 5*MaxDat/Ndip;
    }
    if(CC==U_CC_DATAPOWER)
    {
        for(int k=0; k<Ndip; k++) MaxDat += ((UDipoleMove*)DipoleArray[k])->GetMEGDataPower();
        if(Ndip) MaxDat = MIN(100000., 5*MaxDat/Ndip);
    }
    ErrorType E = U_ERROR;
    switch(CC)
    {
        case U_CC_MAGNITUDE: E=PropDis.SetMinMaxRange(0., MaxDat);         break;
        case U_CC_RESERROR:  E=PropDis.SetMinMaxRange(MinError, MaxError); break;
        case U_CC_DATAPOWER: E=PropDis.SetMinMaxRange(0., MaxDat);         break;
        case U_CC_DELTAX:    
        case U_CC_DELTAY:    
        case U_CC_DELTAZ:    E=PropDis.SetMinMaxRange(0., 10.);            break;
        case U_CC_DELTAVOL:  E=PropDis.SetMinMaxRange(0., 100.);           break;
        case U_CC_GROUP:     E=PropDis.SetMinMaxRange(-1., (double)NBIN);  break;
        case U_CC_HEADER:    E=PropDis.SetMinMaxRange(-1., (double)NBIN);  break;
        default:
            CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Invalid argument (%d).\n",CC);
            return U_ERROR;
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Setting distribution range for CC= %d.\n",CC);
        return U_ERROR;
    }

    for(int k=0; k<Ndip; k++)
    {
        double E = 0;
        switch(CC)
        {
        case U_CC_MAGNITUDE: E = ((UDipoleMove*)DipoleArray[k])->GetMagnitude();         break;
        case U_CC_RESERROR:  E = ((UDipoleMove*)DipoleArray[k])->GetResidualError();     break;
        case U_CC_DATAPOWER: E = ((UDipoleMove*)DipoleArray[k])->GetMEGDataPower();      break;
        case U_CC_DELTAX:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Getx();      break;
        case U_CC_DELTAY:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Gety();      break;
        case U_CC_DELTAZ:    E = ((UDipoleMove*)DipoleArray[k])->GetDelta().Getz();      break;
        case U_CC_DELTAVOL:  E = ((UDipoleMove*)DipoleArray[k])->GetDelta().GetVolume(); break;
        case U_CC_GROUP:     E = ((UDipoleMove*)DipoleArray[k])->GetGroup();             break;
        case U_CC_HEADER:    E = ((UDipoleMove*)DipoleArray[k])->GetHeaderIndex();       break;
        }
        PropDis.AddValue(E);
    }

/* Redistribute the values over the bins */
    E = U_ERROR;
    if(CC==U_CC_GROUP||CC==U_CC_HEADER)
    {
        E = PropDis.RemoveEmptyBins();
    }
    else
    {
        double Min  = PropDis.GetMinValue();
        double Max  = 5*PropDis.GetMedian();
        if(Max<=Min || Max>PropDis.GetMaxValue()) Max = PropDis.GetMaxValue();
        int    Nbin = Pal->GetNColor();
        if(Min==Max) Min-=.00001;
        E = PropDis.ReDistribute(Min, Max, Nbin);
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetDipoleColors(). Redistributing the dipole property histograms.\n");
        return U_ERROR;
    }

/* Color the dipoles*/    
    for(int n=0; n<Ndip; n++)
    {
        double Value = 0;
        switch(CC)
        {
        case U_CC_MAGNITUDE: Value = ((UDipoleMove*)DipoleArray[n])->GetMagnitude();         break;
        case U_CC_RESERROR:  Value = ((UDipoleMove*)DipoleArray[n])->GetResidualError();     break;
        case U_CC_DATAPOWER: Value = ((UDipoleMove*)DipoleArray[n])->GetMEGDataPower();      break;
        case U_CC_DELTAX:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Getx();      break;
        case U_CC_DELTAY:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Gety();      break;
        case U_CC_DELTAZ:    Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().Getz();      break;
        case U_CC_DELTAVOL:  Value = ((UDipoleMove*)DipoleArray[n])->GetDelta().GetVolume(); break;
        case U_CC_GROUP:     Value = ((UDipoleMove*)DipoleArray[n])->GetGroup();             break;
        case U_CC_HEADER:    Value = ((UDipoleMove*)DipoleArray[n])->GetHeaderIndex();       break;
        }
        int    index = PropDis.GetBinNumber(Value);
        UColor   rgb = Pal->GetColor(index-1);
        ((UDipoleMove*)DipoleArray[n])->SetColor(rgb);
    }    
    return U_OK;
}

ErrorType UDipoleMoveList::WriteConfEllipses(const char* XDRdirName, const UEuler* XFM)
/*
    Export dipoles and confidence intervals as 3-D elllipses, in XDR format.
 */
{
    if(ConfIntervalComputed()==false)
    {
        CI.AddToLog("WARNING: UDipoleMoveList::WriteConfEllipses(). No confidence intervals present in dipole file.");
        return U_OK;
    }

    if(XDRdirName==NULL) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteConfEllipses(). NULL argument. \n");
        return U_ERROR;
    }
    UPatTree XDRdir(XDRdirName, UPatTree::U_STRUCTURE);
    if(XDRdir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteConfEllipses(). Directory cannot be created: %s. \n",XDRdir.GetDirectoryName());
        return U_ERROR;
    }

    int Npoints;
    UVector3* p = GetPositionList(&Npoints);

    USurface S;
    for(int n=0,k=0; n<Ndip; n++)
    {
        UVector3 Del = ((UDipoleMove*)DipoleArray[n])->GetDelta();
            
        if(Del.Getx()<0.) Del.Setx(-Del.Getx());
        if(Del.Gety()<0.) Del.Sety(-Del.Gety());
        if(Del.Getz()<0.) Del.Setz(-Del.Getz());

        if(Del.Getx()==0) Del.Setx(.2);
        if(Del.Gety()==0) Del.Sety(.2);
        if(Del.Getz()==0) Del.Setz(.2);

        double Rad      = pow(Del.Getx()*Del.Gety()*Del.Getz(), 1./3.);
        double MeshSize = Rad/5;
        USurface Ellipse(MeshSize, Del.Getx(), Del.Gety(), Del.Getz(), U_GEOM_SPHERE);
        Ellipse.Transform(UEuler(p[k++]));
        
        if(S.Concatenate(&Ellipse)!=U_OK)
        {
            delete[] p;
            CI.AddToLog("ERROR: UDipoleMoveList::WriteConfEllipses(). Merging ellipsoidal confidence regions.\n");
            return U_ERROR;
        }
        if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
           DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos)
        {
            USurface Ellipse(MeshSize, Del.Getx(), Del.Gety(), Del.Getz(), U_GEOM_SPHERE);
            Ellipse.Transform(UEuler(p[k++]));
        
            if(S.Concatenate(&Ellipse)!=U_OK)
            {
                delete[] p;
                CI.AddToLog("ERROR: UDipoleMoveList::WriteConfEllipses(). Merging ellipsoidal confidence regions.\n");
                return U_ERROR;
            }
        }
    }
    delete[] p;

    return S.WriteXDR(XDRdirName, XFM, "Created by UDipoleMoveList::WriteConfEllipses().");
}

ErrorType UDipoleMoveList::WriteXDR(const char* XDRdirName, const UEuler* XFM, ProjType ProjT, PlotType PlotT)
/*
    Export dipoles to AVS-XDR format with Conquest conventions.
    XDRDir[]   - directory name, to which ".structure" is appended (if not present)
                 The dipoles are written into this directory, under the name "structure.xdr"
    *XFM       - The transformation to apply to the dipoles, in order to transform
                 them from Nasion Ear to MRI. This transformation is only copied
                 under the name "structure_to_wld.xdr". (if(XFM==NULL), do not write transform)

    ProjT      - determines the way the dipoles are projected. U_NOP: no projection,
                 U_PX: project on x-plane, etc.
    PlotT      - determines the way the dipoles are ploteed: dots or vectors.
 */
{
    if(XDRdirName==NULL) 
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteXDR(). Invalid argument. \n");
        return U_ERROR;
    }

    UPatTree XDRdir(XDRdirName, UPatTree::U_STRUCTURE);
    if(XDRdir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteXDR(). Directory cannot be created: %s. \n",XDRdir.GetDirectoryName());
        return U_ERROR;
    }

/* Create and write the points file-file*/
    int Npoints;
    UVector3* p = GetPositionList(&Npoints);

    UField DipField;
    if(ProjT!=U_NOP)
    {
        UVector2* p2 = new UVector2[Npoints];
        switch(ProjT)
        {
        case U_PX: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Px(); } break;
        case U_PY: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Py(); } break;
        case U_PZ: {  for(int k=0; k<Npoints; k++) p2[k] = p[k].Pz(); } break;
        }
        DipField = UField(p2, Npoints, MAXPLOTBUFFER);
        delete[] p2;
    }
    else
        DipField = UField(p, Npoints, MAXPLOTBUFFER);

    delete[] p;
    if(DipField.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::WriteXDR(). Memory allocation.\n");
        return U_ERROR;
    }

    char* Pdata = (char*) DipField.GetBdata();
    if(Pdata==NULL)
    {
        CI.AddToLog("ERROR: UDipoleList::WriteXDR(). NULL pointer in dipole UField data.\n");
        return U_ERROR;
    }

    double MaxMagnitude = ComputeMagnitudeScaling();

    if(MaxMagnitude>1.e-10)
    {
        for(int n=0; n<Ndip; n++)
        {
            UVector3 Dir = DipoleArray[n]->Getd()/MaxMagnitude;
            UVector3 Del = ((UDipoleMove*)DipoleArray[n])->GetDelta();
            UColor   rgb = ((UDipoleMove*)DipoleArray[n])->GetColor();

            if(XFM) Dir = XFM->xfm(Dir, true);

            switch(PlotT)
            {
            case U_DOT:
                PlotDot(Pdata, rgb);
                break;

            case U_DOT_TIME:
                {
                    int    nc   = PlotDot(Pdata, rgb);
                    double Time = ((UDipoleMove*)DipoleArray[n])->GetTime();
                    AddAnnotation(Pdata+nc, Time, "%9.1f", MAXPLOTBUFFER-nc-1);
                }
                break;

            case U_VECTOR:
                switch(ProjT)
                {
                    case U_NOP:  PlotVector(Pdata, Dir, rgb);      break;
                    case U_PX:   PlotVector(Pdata, Dir.Px(), rgb); break;
                    case U_PY:   PlotVector(Pdata, Dir.Py(), rgb); break;
                    case U_PZ:   PlotVector(Pdata, Dir.Pz(), rgb); break;
                }
                break;

            case U_CONFINT:
                switch(ProjT)
                {
                    case U_NOP:  PlotConfInterval(Pdata, XFM, Del, rgb); break;
                    case U_PX:   PlotConfInterval(Pdata, Del.Px(), rgb); break;
                    case U_PY:   PlotConfInterval(Pdata, Del.Py(), rgb); break;
                    case U_PZ:   PlotConfInterval(Pdata, Del.Pz(), rgb); break;
                }
                break;
            }
            Pdata += MAXPLOTBUFFER;          

            if(DipoleArray[n]->GetDipoleType()==UDipole::Symmetric ||
               DipoleArray[n]->GetDipoleType()==UDipole::SymmetricPos)
            {
                UVector3 Dir = DipoleArray[n]->GetdSym()/MaxMagnitude;

                switch(PlotT)
                {
                case U_DOT:
                    PlotDot(Pdata, rgb);
                    break;

                case U_DOT_TIME:
                    {
                        int    nc   = PlotDot(Pdata, rgb);
                        double Time = ((UDipoleMove*)DipoleArray[n])->GetTime();
                        AddAnnotation(Pdata+nc, Time, "%9.1f", MAXPLOTBUFFER-nc-1);
                    }
                    break;

                case U_VECTOR:
                    switch(ProjT)
                    {
                        case U_NOP:  PlotVector(Pdata, Dir, rgb);      break;
                        case U_PX:   PlotVector(Pdata, Dir.Px(), rgb); break;
                        case U_PY:   PlotVector(Pdata, Dir.Py(), rgb); break;
                        case U_PZ:   PlotVector(Pdata, Dir.Pz(), rgb); break;
                    }
                    break;

                case U_CONFINT:
                    switch(ProjT)
                    {
                        case U_NOP:  PlotConfInterval(Pdata, XFM, Del, rgb); break;
                        case U_PX:   PlotConfInterval(Pdata, Del.Px(), rgb); break;
                        case U_PY:   PlotConfInterval(Pdata, Del.Py(), rgb); break;
                        case U_PZ:   PlotConfInterval(Pdata, Del.Pz(), rgb); break;
                    }
                    break;
                }
                Pdata += MAXPLOTBUFFER;          
            }
        }
    }

    if(XDRdir.SetScan(&DipField, GetProperties("// "), DipFileProperties)!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleMoveList::WriteXDR(). Cannot write dipoles structure. \n");
        return U_ERROR;
    }
    
/* Create and write dummy index file.*/
    int* Index    = new int[Npoints];
    if(!Index )
    {
        CI.AddToLog("ERROR UDipoleMoveList::WriteXDR(). Cannot create index arrays.\n");
        return U_ERROR;
    }
    for(int n=0; n<Npoints; n++) Index[n]    = n;
    UField IndexField(Index, Npoints, 1, true);
    delete[] Index;

    if(XDRdir.SetIndex(&IndexField, GetProperties("// "), DipFileProperties)!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleMoveList::WriteXDR(). Cannot write index field. \n");
        return U_ERROR;
    }

/* Write the transformation, when present */    
    if(XFM && XDRdir.SetMatchToWld(*XFM)!=U_OK)
    {
        CI.AddToLog("ERROR UDipoleMoveList::WriteXDR(). Cannot write transform file. \n");
        return U_ERROR;
    }
    return U_OK;
}

UString UDipoleMoveList::GetProperties(const char* Comment) const
{
    UString Begin("");
    UString End("\n");
    if(Comment)
    {
        Begin = UString(Comment);
        End   = UString("\n");
    }

    UString Properties;

    if(error!=U_OK)
    {
        Properties = Begin + UString(" ERROR in UDipoleMoveList-object") + End;
        return Properties;
    }

    Properties = Begin + UDipoleList::GetDipStat(Comment) + End;

    if(Nfiles==1)
        Properties += Begin + UString(DipFileName, " DipoleFile = %s") + End;
    else
        Properties += Begin + UString(DipFileName, " DipoleFile = %s // First File") + End;
    
    Properties += Begin + UString(Nfiles      ,"Nfiles       = %d ") + End;
    Properties += Begin + UString(Nheader     ,"Nheader      = %d ") + End;
    Properties += Begin + UString(MaxError    ,"MaxError     = %f ") + End;
    Properties += Begin + UString(MinTimeRange,"MinTimeRange = %f ") + End;
    Properties += Begin + UString(MaxTimeRange,"MaxTimeRange = %f ") + End;
    Properties += Begin + UString(SubSampleMS ,"SubSampleMS  = %f ") + End;
    Properties += Begin + UString(NtotDip     ,"TotalDipolesInFile  = %d ") + End;

    int NdipInDataSets    = 0;
    for(int k=0; k<Nheader; k++) 
        NdipInDataSets += headers[k]->GetNsamp() * headers[k]->GetNtrial();
    Properties += Begin + UString(NdipInDataSets  ,"TotalDipolesInDataSets  = %d ") + End;

    double Frac = 0.;
    if(NdipInDataSets) Frac = 100.*Ndip/NdipInDataSets;
    Properties += Begin + UString(Frac ,"FractionSelectedDipoles = %9.6g %%  ") + End;
    
    return Properties;    
}

static UDipoleMoveList::ColorCode SortDip;
static UDipFileHeader**          SortHead;

static int DipOrder(const void *elem1, const void *elem2)
{
    const UDipoleMove*const* pD1 = (UDipoleMove**)elem1;
    const UDipoleMove*const* pD2 = (UDipoleMove**)elem2;
    const UDipoleMove* D1 = *pD1;
    const UDipoleMove* D2 = *pD2;

    double V1 = 0.;
    double V2 = 0.;
    switch(SortDip)
    {
    case UDipoleMoveList::U_CC_MAGNITUDE:
        if(D1->Getd().GetNorm2() > D2->Getd().GetNorm2()) return  1;
        if(D1->Getd().GetNorm2() < D2->Getd().GetNorm2()) return -1;
        return 0;
        
    case UDipoleMoveList::U_CC_RESERROR:
        if(D1->GetResidualError() > D2->GetResidualError() ) return  1;
        if(D1->GetResidualError() < D2->GetResidualError() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_DATAPOWER:
        if(D1->GetResidualError() > D2->GetMEGDataPower() ) return  1;
        if(D1->GetResidualError() < D2->GetMEGDataPower() ) return -1;
        return 0;
        
    case UDipoleMoveList::U_CC_DELTAX:
        if(D1->GetDelta().Getx() > D2->GetDelta().Getx() ) return  1;
        if(D1->GetDelta().Getx() < D2->GetDelta().Getx() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_DELTAY:
        if(D1->GetDelta().Gety() > D2->GetDelta().Gety() ) return  1;
        if(D1->GetDelta().Gety() < D2->GetDelta().Gety() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_DELTAZ:
        if(D1->GetDelta().Getz() > D2->GetDelta().Getz() ) return  1;
        if(D1->GetDelta().Getz() < D2->GetDelta().Getz() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_GROUP:
        if(D1->GetGroup() > D2->GetGroup() ) return  1;
        if(D1->GetGroup() < D2->GetGroup() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_HEADER:
        if(D1->GetHeaderIndex() > D2->GetHeaderIndex() ) return  1;
        if(D1->GetHeaderIndex() < D2->GetHeaderIndex() ) return -1;
        return 0;

    case UDipoleMoveList::U_CC_DELTAVOL:
        V1 = D1->GetDelta().Getx()*D1->GetDelta().Gety()*D1->GetDelta().Getz();
        V2 = D2->GetDelta().Getx()*D2->GetDelta().Gety()*D2->GetDelta().Getz();
        if(V1 > V2) return  1;
        if(V1 < V2) return -1;
        return 0;
    
    case UDipoleMoveList::U_CC_ABSTIME:
        if(SortHead)
        {
            int hindex1 = D1->GetHeaderIndex();
            int hindex2 = D2->GetHeaderIndex();
            if(SortHead[hindex1]==NULL || SortHead[hindex2]==NULL) return 1;
            
            UDateTime Dat1(SortHead[D1->GetHeaderIndex()]->GetDateTime());
            UDateTime Dat2(SortHead[D2->GetHeaderIndex()]->GetDateTime());
            if(Dat1>Dat2) return  1;
            if(Dat1<Dat2) return -1;
            
            V1 = D1->GetTime();
            V2 = D2->GetTime();

            if(V1 > V2) return  1;
            if(V1 < V2) return -1;
            return 0;
        }
        else
            return 1;
        return 0;
    }
    return 0;
}

ErrorType UDipoleMoveList::SortDipoles(ColorCode CC)
/*
     Order the dipoles according to CC.
 */
{
    if(CC!=U_CC_MAGNITUDE && 
       CC!=U_CC_RESERROR  && 
       CC!=U_CC_DATAPOWER && 
       CC!=U_CC_DELTAX    &&
       CC!=U_CC_DELTAY    &&
       CC!=U_CC_DELTAZ    &&
       CC!=U_CC_DELTAVOL  &&
       CC!=U_CC_GROUP     &&
       CC!=U_CC_HEADER    &&
       CC!=U_CC_ABSTIME)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SortDipoles(). Invalid argument (%d).\n",CC);
        return U_ERROR;
    }

    SortDip  = CC;
    SortHead = headers;
    qsort(DipoleArray, Ndip, sizeof(DipoleArray[0]), DipOrder);
    return U_OK;
}

double UDipoleMoveList::ComputeMagnitudeScaling(void) const
/*
    Detertermine the distribution of the magnitudes, used for the length scaling of 
    dipole vectors.
 */
{
    double MAXMAGN = 0;
    for(int k=0; k<Ndip; k++)
    {
        double M = ((UDipoleMove*)DipoleArray[k])->GetMagnitude();
        MAXMAGN  = MAX(M, MAXMAGN);
    }
    const int    NBINMAG = 10000;
    UDistribution MagDis(NBINMAG, 0., 1.1*MAXMAGN);
    if(MagDis.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::SetMagnitudeScaling(). Cannot create UDistribution object for magnitudes.\n");
        return 0.;
    }
    for(int k=0; k<Ndip; k++)
    {
        double M = ((UDipoleMove*)DipoleArray[k])->GetMagnitude();
        MagDis.AddValue(M);
        if(DipoleArray[k]->GetDipoleType()==UDipole::SymmetricPos)
        {
            M = ((UDipoleMove*)DipoleArray[k])->GetMagnitudeSym();
            MagDis.AddValue(M);
        }
    }
    double MaxMagnitude = 5*MagDis.GetMedian();
    if(MaxMagnitude>MagDis.GetMaxValue()) MaxMagnitude = MagDis.GetMaxValue();
    return MaxMagnitude;
}

int  UDipoleMoveList::GetNGroup() const
{
    int NGroup = 0;
    for(int n1=0; n1<Ndip; n1++)
    {
        int  ig1    = ((UDipoleMove*)DipoleArray[n1])->GetGroup();
        bool NewGrp = true;
        for(int n2=n1-1; n2>=0; n2--)
        {
            int ig2 = ((UDipoleMove*)DipoleArray[n2])->GetGroup();
            if(ig2==ig1)
            {
                NewGrp = false;
                break;
            }
        }
        if(NewGrp==true) NGroup++;
    }
    return NGroup;
}

int* UDipoleMoveList::GetGroupNumbers() const
{
    int  NGroup     = this->GetNGroup();
    int* GroupArray = new int[NGroup];
    if(GroupArray==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetGroupNumbers(). Memory allocation. NGroup = %d \n", NGroup);
        return NULL;
    }

    int ig = 0;
    for(int n1=0; n1<Ndip; n1++)
    {
        int  ig1    = ((UDipoleMove*)DipoleArray[n1])->GetGroup();
        bool NewGrp = true;
        for(int n2=n1-1; n2>=0; n2--)
        {
            int ig2 = ((UDipoleMove*)DipoleArray[n2])->GetGroup();
            if(ig2==ig1)
            {
                NewGrp = false;
                break;
            }
        }
        if(NewGrp==true) GroupArray[ig++] = ig1;
    }
    return GroupArray;
}

int UDipoleMoveList::GetNDataSetNames(void) const
/*
    Return the number of data sets used to create dipole selection
 */
{
    const char* DSNames[MAXHEADER];
    for(int ih=0; ih<MAXHEADER; ih++) DSNames[ih] = NULL;

    int NDS = 0;
    for(int ih1=0; ih1<Nheader; ih1++)
    {
        const char* ds = headers[ih1]->GetDataSetName();
        bool  NewDS    = true;
        for(int ih2=0; ih2<NDS; ih2++)
        {
            if(!strcmp(ds, DSNames[ih2]))
            {
                NewDS = false;
                break;
            }
        }
        if(NewDS==true) DSNames[NDS++] = ds;
    }
    return NDS;
}

const char* UDipoleMoveList::GetDataSetNameIndex(int index) const
/*
    Return the index-th new data set name used to create dipole selection
 */
{
    const char* DSNames[MAXHEADER];
    for(int ih=0; ih<MAXHEADER; ih++) DSNames[ih] = NULL;

    int NDS = 0;
    for(int ih1=0; ih1<Nheader; ih1++)
    {
        const char* ds = headers[ih1]->GetDataSetName();
        bool  NewDS    = true;
        for(int ih2=0; ih2<NDS; ih2++)
        {
            if(!strcmp(ds, DSNames[ih2]))
            {
                NewDS = false;
                break;
            }
        }
        if(NewDS==true) 
        {
            if(NDS==index) return ds;
            DSNames[NDS++] = ds;
        }
    }
    CI.AddToLog("ERROR: UDipoleMoveList::GetDataSetName(). index (=%d) out of range. \n", index);
    return NULL;
}

int UDipoleMoveList::GetNdipoles(int DataSetIndex, int GroupNumber) const
/*
    Return the number of dipoles with dataset name corresponding to DataSetIndex, and group number
    GroupNumber.
 */
{
    const char* DSName = this->GetDataSetNameIndex(DataSetIndex);
    if(DSName==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetNdipoles(). DataSetIndex out of range: DataSetIndex = %d . \n", DataSetIndex);
        return 0;
    }

    int NdipSel = 0;

    for(int n=0; n<Ndip; n++)
    {
        const char* DSdip = this->GetDipDataSetName(n);
        if(DSdip==NULL) continue;

        if(!strcmp(DSName, DSdip) && GroupNumber == GetDipole(n).GetGroup()) NdipSel++;
    }
    return NdipSel;
}

int UDipoleMoveList::GetNsampInDataSet(const char* DataSetName) const
/*
     Return the total number of samples in data set named *DataSetName .
 */
{
    if(DataSetName==NULL)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetNSampInDataSet(). Invalid NULL argument . \n");
        return 0;
    }
    for(int ih=0; ih<Nheader; ih++)
    {
        const char* ds = headers[ih]->GetDataSetName();
        if(ds==NULL) continue;
        if(!strcmp(DataSetName, ds))
            return ( headers[ih]->GetNsamp() * headers[ih]->GetNtrial());
    }
    CI.AddToLog("WARNING: UDipoleMoveList::GetNSampInDataSet(). Dataset not used: %f . \n", DataSetName);
    return 0;
}

UField* UDipoleMoveList::GetDipoleDensity(double BinSize, double VoxSize) 
{
    if(BinSize<=0. || VoxSize<=0.)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensity(). Parameters out of range: BinSize = %f, VoxSize = %f . \n", BinSize, VoxSize);
        return NULL;
    }
// VoxSize & BinSize in cm
    UpdateMinMax();
    UVector3 MinxA = GetMinx();
    UVector3 MaxxA = GetMaxx();
    UVector3 MinxB = MinxA - UVector3(.5*BinSize,.5*BinSize,.5*BinSize);
    UVector3 MaxxB = MaxxA + UVector3(.5*BinSize,.5*BinSize,.5*BinSize);

    UField* Density1 = new UField(BinSize, MinxA, MaxxA, UField::U_SHORT);
    if(Density1==NULL || Density1->GetError()!=U_OK)
    {
        delete Density1;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensity(). Creating UField object.  \n");
        return NULL;
    }

    for(int k=0; k<GetNdip(); k++)
    {
        UDipole Dip = GetDipole(k);
        Density1->AddPointValue(Dip.Getx(),1);
        if(Dip.GetDipoleType()==UDipole::Symmetric || Dip.GetDipoleType()==UDipole::SymmetricPos)
        {
            Density1->AddPointValue(Dip.Getx().GetMirrorY(),1);
        }
    }

/* Make blocks of small pixel size (VoxSize)*/
    UField* Density2 = new UField(VoxSize, MinxB, MaxxB, UField::U_SHORT); 
    if(Density2==NULL || Density2->GetError()!=U_OK)
    {
        delete Density1;
        delete Density2;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensity(). Creating second UField object.  \n");
        return NULL;
    }

    for(double x=MinxB.Getx(); x <= MaxxB.Getx(); x += VoxSize) 
    {
        for(double y=MinxB.Gety(); y <= MaxxB.Gety(); y += VoxSize)
        {
            for(double z=MinxB.Getz(); z <= MaxxB.Getz(); z += VoxSize)
            {
                UVector3 Xcopy = UVector3(x,y,z);
                Density2->AddPointValue(Xcopy, Density1->GetPointValue(Xcopy, 0));
            } 
        }
    } 
    delete Density1;
    return Density2;
}

UScan* UDipoleMoveList::GetDipoleDensityScan(double BinSize, double VoxSize) 
{
    if(BinSize<=0. || VoxSize<=0.)
    {
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensityScan(). Parameters out of range: BinSize = %f, VoxSize = %f . \n", BinSize, VoxSize);
        return NULL;
    }
// VoxSize & BinSize in cm
    UpdateMinMax();
    UVector3 MinxA    = GetMinx(); MinxA.SwapDirections(true);
    UVector3 MaxxA    = GetMaxx(); MaxxA.SwapDirections(true);
    
/* Force the RawCenter to be at (0.,0.,0.) to avoid shift problems. */
    double   Xmm      = MAX(fabs(MinxA.Getx()), fabs(MaxxA.Getx()));
    double   Ymm      = MAX(fabs(MinxA.Gety()), fabs(MaxxA.Gety()));
    double   Zmm      = MAX(fabs(MinxA.Getz()), fabs(MaxxA.Getz()));
    MinxA = UVector3(-Xmm, -Ymm, -Zmm);
    MaxxA = UVector3( Xmm,  Ymm,  Zmm);

    UField*  Density1 = new UField(BinSize, MinxA, MaxxA, UField::U_SHORT);
    if(Density1==NULL || Density1->GetError()!=U_OK || Density1->GetSdata()==NULL)
    {
        delete Density1;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensityScan(). Creating UField object.  \n");
        return NULL;
    }
    for(int k=0; k<GetNdip(); k++)
    {
        UDipole  Dip = GetDipole(k);
        UVector3 X   = Dip.Getx();   X.SwapDirections(true);
        Density1->AddPointValue(X,1);
        if(Dip.GetDipoleType()==UDipole::Symmetric || Dip.GetDipoleType()==UDipole::SymmetricPos)
        {
            Dip = GetDipole(k);
            X   = Dip.Getx().GetMirrorY();   X.SwapDirections(true);
            Density1->AddPointValue(X,1);
        }
    }

/* Make blocks of small pixel size (VoxSize)*/
    UVector3 MinxB    = MinxA - UVector3(.5*BinSize,.5*BinSize,.5*BinSize);
    UVector3 MaxxB    = MaxxA + UVector3(.5*BinSize,.5*BinSize,.5*BinSize);
    UField* Density2  = new UField(VoxSize, MinxB, MaxxB, UField::U_SHORT); 
    if(Density2==NULL || Density2->GetError()!=U_OK || Density2->GetSdata()==NULL)
    {
        delete Density1;
        delete Density2;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensityScan(). Creating second UField object.  \n");
        return NULL;
    }

    for(double x=MinxB.Getx(); x <= MaxxB.Getx(); x += VoxSize) 
    {
        for(double y=MinxB.Gety(); y <= MaxxB.Gety(); y += VoxSize)
        {
            for(double z=MinxB.Getz(); z <= MaxxB.Getz(); z += VoxSize)
            {
                UVector3 Xcopy = UVector3(x,y,z);
                Density2->AddPointValue(Xcopy, Density1->GetPointValue(Xcopy, 0));
            }
        }
    } 
    delete Density1;
    UScan* ScanDens = new UScan(*Density2);
    delete Density2;
    if(ScanDens==NULL || ScanDens->GetError()!=U_OK)
    {
        delete ScanDens;
        CI.AddToLog("ERROR: UDipoleMoveList::GetDipoleDensityScan(). Copying density UField() to UScan(). \n");
        return NULL;
    }

    ScanDens->ReverseData(0, false);
    ScanDens->ReverseData(2, false);
    ScanDens->SetOrientation(U_ORI_CORONAL);    
    ScanDens->SetMatchScanToWld(UPatTree::GetToWld(U_ORI_CORONAL));

    ScanDens->SetScanName("Dipole Density");
    ScanDens->SetDateTime(this->GetFileHeader(0)->GetDateTime());
    ScanDens->SetPatName( this->GetFileHeader(0)->GetSubject() );
    ScanDens->SetModality(U_MOD_MEG); 
    UVector3 Center =  ScanDens->GetCenter(false);
    ScanDens->ShiftCoords(-Center);

    return ScanDens;
}
