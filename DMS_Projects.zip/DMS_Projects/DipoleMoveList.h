#ifndef _DIPOLEMOVELIST_INCLUDED
#define _DIPOLEMOVELIST_INCLUDED

                

#include "DipoleList.h"
#include "DipoleMove.h"
#include "DipFileHeader.h"
#include "String.h"


class UColor;
class UPalette;
class UBitMap;
class UDistribution;
class UField;
class UScan;
class UEpochs;

#define MAXHEADER 512  // The maximum number of file headers that can be processed


class DLL_IO UDipoleMoveList : public UDipoleList
{
public:    
    enum ColorCode{U_CC_NOTSET,    //  Color coding not set
                   U_CC_MAGNITUDE, //  Color code each dipole according to magnitude
                   U_CC_RESERROR,  //  Color code each dipole according to residual error
                   U_CC_DATAPOWER, //  Color code each dipole according to data power
                   U_CC_DELTAX,    //  Color code each dipole according to X-confidence interval
                   U_CC_DELTAY,    //  Color code each dipole according to Y-confidence interval
                   U_CC_DELTAZ,    //  Color code each dipole according to Z-confidence interval
                   U_CC_DELTAVOL,  //  Color code each dipole according to confidence volume
                   U_CC_GROUP,     //  Color code each dipole according to the group number
                   U_CC_HEADER,    //  Color code each dipole according to the header number
                   U_CC_ABSTIME};  //  Color code each dipole according to absolute time

    UDipoleMoveList(const char*FileName, double MaxEr, double Tmin, double Tmax);
    UDipoleMoveList(const UMEEGDataBase* Data, const UHeadModel* HM, const UEpochs* Epo, bool TimeInSamp, bool UseAbsTime, UDipole::DipoleType DipType, bool ConfInt);
    UDipoleMoveList(const UDipoleMoveList& DML);
    virtual ~UDipoleMoveList();
    
    ErrorType        AddDipole(UDipole Dip);
    ErrorType        AddDipole(UDipoleMove Dip);
    ErrorType        WriteDipoles(UFileName File, bool Append, int NDigits) const;


/******** Part of Arent for dip2conq  *********/
    enum ConqDirType{U_DIPSCAN, 
                     U_DOSE, 
                     U_DIP, 
                     U_MEGMARKER,
                     U_MRIMARKER,
                     U_DIPPROJ,
                     U_MRI,
                     U_INFO};

    ErrorType        SetBitMap(char * FileName, ConqDirType Type, const UPalette* Pal=NULL) const;
    ErrorType        WriteDose(const char* XDRdirName, const UEuler* XFM, double BinSize, double VoxSize);
    ErrorType        WriteProjections(const char* RootDirName, const UEuler* XFM, const UEuler* XFM_MRI);
    ErrorType        WriteMEGMarkers(const char* XDRdirName, const UEuler* XFM);
    ErrorType        WriteMRIMarkers(const char* XDRdirName, const UEuler* XFM_MRI, UVector3 NMRI, UVector3 LMRI, UVector3 RMRI) const;
/******* End of part of Arent for dip2conq *********/

    ErrorType        GetError(void) const {return error;}
    UString          GetProperties(const char* Comment) const;
    UString          GetDipFileProperties(void) const {return DipFileProperties;}

    UField*          GetDipoleDensity(double BinSize, double VoxSize);
    UScan*           GetDipoleDensityScan(double BinSize, double VoxSize);
 
    UDipoleMoveList* GetDipoleSelection(double MinEr, double MaxEr, double Tmin, double Tmax) const;
    UDipoleMoveList* SubSample(double TimeMS) const;
    ErrorType        MergeDipoles(const char*FileName);
    ErrorType        MergeDipoles(const UDipoleMoveList& DML);

    ErrorType        SetGroupNumber(int idip, int igroup);
    ErrorType        SetDipoleColors(ColorCode CC, const UBitMap *B);
    ErrorType        SetDipoleColors(ColorCode CC, const UPalette *P);
    ErrorType        SetDipoleColors(const UColor *C);
    double           ComputeMagnitudeScaling(void) const;

    ErrorType        WriteXDR(const char* XDRDir, const UEuler* XFM=NULL, ProjType PT=U_NOP, PlotType PloType=U_VECTOR);
    ErrorType        WriteConfEllipses(const char* XDRDir, const UEuler* XFM=NULL);

    const char*      GetDipFileName(void) const          {return DipFileName;}
    const char*      GetDipDataSetName(int idip) const;
    bool             ConfIntervalComputed(void) const;

    ErrorType        SortDipoles(ColorCode CC);
    ErrorType        SelectTimeInterval(double Tmin, double Tmax);
    
    UDipFileHeader*  GetFileHeader(int ihead = 0) const {if(ihead<0||ihead>=Nheader) return NULL;
                                                        return headers[ihead];}
    int              GetNHeader() {return Nheader;}
    int              GetHeaderNumber(int idip) const;
    UEvent           GetEvent(int idip) const;
    UDipoleMove      GetDipole(int idip) const;
    UVector3         GetSpherePos(int idip) const;

    int              GetNDataSetNames(void) const;
    const char*      GetDataSetNameIndex(int index) const;
    int              GetNGroup(void) const;
    int*             GetGroupNumbers() const;
    bool             IsMatchMRtoWldInAllHeaders(void) const;
    bool             IsMatchMRtoWldInHeader(int ihead) const;
    bool             IsNLR_MR_InAllHeaders(void) const;
    bool             IsNLR_MR_InHeader(int ihead) const;
    int              GetNdipoles(int DataSetIndex, int GroupNumber) const;
    int              GetNsampInDataSet(const char* DataSetName) const;

    double           GetMinResidualErrorPresent(void) const;
    double           GetMinErrorRange(void) const {if(this) return MinError;     return 0.;}
    double           GetMaxErrorRange(void) const {if(this) return MaxError;     return 0.;}
    double           GetMinTimeRange(void)  const {if(this) return MinTimeRange; return 0.;}
    double           GetMaxTimeRange(void)  const {if(this) return MaxTimeRange; return 0.;}
    double           GetSubSampleMS(void)   const {if(this) return SubSampleMS;  return 0.;}

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(void);

private:
    ErrorType        error;            // General error flag (for constructor)
    UString          DipFileProperties;// String containg the ASCII header of the dipole file


    UDipFileHeader*  headers[MAXHEADER]; // Pointers to all subsequent dipole file headers
    int              Nheader;           // The number of file headers
    int              Nfiles;            // The number of merged files (usually 1)

    ErrorType        ReadDipoles(const char*FileName, double MaxError, double Tmin, double Tmax);

    char*            DipFileName;      // The name of the dipole file used to initialize the object
    int              NtotDip;          // Total number of dipoles present in dipole file
    double           MinError;         // The minimum allowed fit error for selecting dipoles from file
    double           MaxError;         // The maximum allowed fit error for selecting dipoles from file
    double           MinTimeRange;     // Time range within which the dipoles are selected
    double           MaxTimeRange;
    double           SubSampleMS;      // Applied sub-sampling time in ms. (0==no subsampling)
};

#endif // _DIPOLEMOVELIST_INCLUDED
