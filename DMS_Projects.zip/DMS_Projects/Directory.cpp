/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     The goal if this object is to manipulate directory and file names,        */
/*     to create a directory on disk, and to test the status of a directory.     */
/*     This object contains one directory-name, but it can return UDirectory-    */
/*     objects refering to parent or child directories.                          */
/*                                                                               */
/*     NOTE:                                                                     */
/*     This object also works under HP-UNIX, provided that the functions         */
/*     UpdateStatus() and CreateDir() are functioning properly.                  */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    28-02-99   creation
  AdJ    05-03-99   BUGFIX :  Parent() 
  JdM    05-03-99   Make Child() more flexible w.r.t. SLASH
  JdM    30-09-99   Added GetFileNames()
GdV/JdM  17-12-99   Bug fixes in UNIX versions of GetFileNames()
  JdM    14-01-00   Added new constructor.
  JdM    20-01-00   Added Sibling()
  JdM    27-03-00   operator==() : Test whether this==&d
  JdM    28-09-00   Default constructor: take 0-string, in stead of NULL pointer for dir. name
  JdM    15-11-00   Bug Fix in GetFileNames(). When buffersize is too small, initialize the file-getting mechanism
  JdM    16-11-00   Added parameter to GetFileNames() inorder to get sub-directories
  JdM    02-02-01   GetBaseName(). Only consider the part after the last '.' as the name extension
  JdM    12-02-01   Bug Fix: MergeDirFileExt(). Merging extension, (skipping possible double '.')
  JdM    11-03-01   Split off the OS dependent part, and put this in DirectorySystem.cpp
  JdM    29-03-01   GetFileNames() : test for existence of directory
  JdM    10-05-01   UDirectory() : strip off wild cards from string name
  JdM    11-05-01   Added GetAllFileNames()
  JdM    28-05-01   Bug fix: GetBaseName(). Ending '.' does not belong to BaseName[]
  JdM    29-08-01   Added parameter to one constructors (IgnoreWildCards), remove default
  JdM    29-08-01   GetAllSubdirNames(): increase the maximum number of directories to 10000
  JdM    19-10-01   Added HasExtension().
  JdM    19-01-02   Always allocate at least 2 bytes for the directory name
  JdM    29-01-03   GetAllSubdirNames(). Ignore wild cards under UNIX (not yet implemented)
  JdM    04-12-04   Added type cast operator to const char*
  JdM    17-03-05   Bug Fix GetAllSubdirNames(). UNIX version allocate array of 1 element
 JdM/DT  20-05-05   GetAllSubdirNames(). Removed discrimination between platforms. This is now done in GetFileNames()
  JdM    11-08-06   Added operator+()
  JdM    16-07-07   Added const char* constructor
  JdM    07-03-08   Constructors: remove first and last "-characters, if both present
  JdM    25-10-08   operator+(). Test DirectoryName[0]==0
  JdM    28-02-09   GetAllFileNames(). Set MaxFileNames = 10000 and give warning if maximum is reached.
  JdM    11-08-10   GetBaseName(): return const char* (so, include extension). This way the bahaviour is similar to UFileName::GetBaseName()
                    Copy a few other methods from UFileName()
  JdM    16-11-11   Bug Fix: UDirectory::UDirectory(const char *). Initialize DirectoryName=NULL
  JdM    29-03-11   GetAllFileNames(), GetAllSubdirNames(). Test whether all sub-directories exist.
  JdM    22-04-12   Bug Fix: ReplaceExtension(): call UpdateStatus()
  JdM    27-07-12   Added operator==() and operator!=()
  JdM    30-09-13   Use UDirFileName::IsSlash() from newly created base class i.s.o. *SLASH
  JdM    01-10-13   Bug Fix: Parent(), GetBaseName(), AddExtension(), GetExtensionOffset(), GetBaseNameOffset()
                             The use of size_t instead of int leads to erroneous results when testing for negative values
  JdM    13-01-14   GetAllFileNames(). Set MaxFileNames (max number of files) equal to 100000
  JdM    15-01-14   Added and used GetNFileDirs() GetAllNFileDirs()
  JdM    16-01-14   Completely restructured GetFileNames() and GetSubDirNames()
  JdM    19-01-14   Bug Fix operator+(). Place -1 at the end of the expression.
  JdM    29-06-14   Added InsertBeforeExtension()
  JdM    30-06-14   bug fix. GetAllSubdirNames(). Do not try to allocate memory when ngood==0
  JdM    31-07-14   Added (system dependent) CompletePath()
  JdM    05-08-14   Bug Fix. GetAllSubdirNames(). Skip empty sub-directories without error message. This appeared crucial for LINUX version.
  JdM    13-12-14   Bug Fix. GetAllFileNames(). return NULL if there are no "good" files
  JdM    01-03-18   MergeDirFileExt(). Made last argument const char*
  JdM    21-04-18   IsSlash(). Defined proper output incase MSVC_2017 defined
                    Added SplitOffWildcards(). Removed IgnoreWildCards constructor
  JdM    27-04-18   GetNDigitBeforeExtension() and GetNumberBeforeExtension(). If there is no extension, start from last char
  JdM    13-07-18   Added CombineDirFile() and operator+() with UDirectory argument
*/

#include <string.h>
#include <stdlib.h>

#include"Directory.h"
#include"FileName.h"

UDirectory::UDirectory()
{
    DirectoryName    = new char[3];
    DirectoryName[0] = 0;
    DirStatus        = U_NOSTAT;
}

UDirectory::UDirectory(const UDirectory& d)
/*
   The copy constructor
 */
{
    DirectoryName    = new char[3];
    DirectoryName[0] = 0;
    *this = d;
}

UDirectory::UDirectory(const char *Dir)
{
    DirectoryName    = NULL;
    DirStatus        = U_NOSTAT;
    if(Dir==NULL)
    {
        *this = UDirectory();
        return;
    }
    size_t nbytes = strlen(Dir);
    DirectoryName = new char[nbytes+2];
    if(DirectoryName) 
    {
        memset(DirectoryName, 0, nbytes+1);
        memcpy(DirectoryName, Dir, nbytes);
    }
    else
    {
        CI.AddToLog("ERROR: UDirectory::UDirectory(). Memory allocation (nbytes = %d) .\n", int(nbytes));
        return;
    }
    if(DirectoryName[0]=='"' && DirectoryName[nbytes-1]=='"')
    {
        for(int k=0; k<nbytes-1; k++) DirectoryName[k] = DirectoryName[k+1];
        DirectoryName[nbytes-1] = 0;
    }
    DirStatus = UpdateStatus();
}

UDirectory::UDirectory(const char *Dir, const char *Ext)
/*
     Create an UDirectory()-object, with the name Dir[] and (possible) extension Ext[].
 */
{
    if(Dir==NULL)
    {
        *this = UDirectory();
        return;
    }
    size_t  nbytes  = strlen(Dir);
    if(Ext) nbytes += strlen(Ext)+1;

    DirectoryName = new char[nbytes+1];
    if(DirectoryName) 
    {
        memset(DirectoryName, 0, nbytes+1);
        memcpy(DirectoryName, Dir, nbytes);
        if(Ext)
        {
            if(Ext[0]!='.') strcat(DirectoryName,".");
            strcat(DirectoryName,Ext);
        }
    }    
    if(DirectoryName[0]=='"' && DirectoryName[nbytes-1]=='"')
    {
        for(size_t k=0; k<nbytes-1; k++) DirectoryName[k] = DirectoryName[k+1];
        DirectoryName[nbytes-1] = 0;
    }
    DirStatus     = UpdateStatus();
}

UDirectory::UDirectory(const char *FileName, bool IsFileName)
/*
    if(IdFileName==true)
        Create an UDirectory()-object, with the name of the directory, where the file FileName[] is located.
    else
        Create an UDirectory()-object, with the name FileName[].
 */
{
    DirectoryName    = new char[3];
    DirectoryName[0] = 0;
    if(IsFileName==true)
    {
        *this = UDirectory(FileName, CNULL).Parent();
    }
    else 
    {
        *this = UDirectory(FileName, CNULL);
    }
    DirStatus     = UpdateStatus();
}

UDirectory::~UDirectory()
{
    delete[] DirectoryName;
}


UDirectory& UDirectory::operator=(const UDirectory &d)
/*
    The assignment operator.
 */
{
    if(this==&d) return *this;  // Nothing to do

    DirStatus = d.DirStatus;

    if(d.DirectoryName)
    {
        delete[] DirectoryName;
        size_t nbytes = strlen(d.DirectoryName);
        DirectoryName = new char[nbytes+1];
        if(DirectoryName) 
        {
            memcpy(DirectoryName, d.DirectoryName, nbytes);
            DirectoryName[nbytes] = 0;
        }
        else
            DirStatus = U_NOSTAT;
    }
    else
        DirectoryName = NULL;

    return *this;
}

bool UDirectory::operator==(const UDirectory &D) const
{
    if(this==NULL || &D==NULL) return false;
    if(DirectoryName == D.DirectoryName) return true;
    if(  DirectoryName == NULL ||
       D.DirectoryName == NULL) return false;

    size_t l1 = strlen(  DirectoryName);
    size_t l2 = strlen(D.DirectoryName);
    if(l1!=l2) return false;

    for(size_t n=0; n<l1; n++)
    {
        if(IsSlash(DirectoryName[n]) && IsSlash(D.DirectoryName[n])) continue;
        if(DirectoryName[n] != D.DirectoryName[n]) return false;
    }
    return true;
}
bool UDirectory::operator!=(const UDirectory &D) const
{
    if(*this==D) return false;
    return true;
}

UFileName UDirectory::operator+(const UFileName& F) const
{
    if(this==NULL)          
    {
        CI.AddToLog("ERROR: UDirectory::operator+(). this==NULL \n");
        return F;
    }
    if(DirectoryName==NULL || DirectoryName[0]==0) return F;
    if(F.GetFullFileName()==NULL) return UFileName(DirectoryName);

    size_t nbytes = 2+strlen(DirectoryName) + strlen((const char*)F);
    
    char* FileName = new char[nbytes];
    if(FileName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::operator+(). Memory allocation. \n");
        return F;
    }
    FileName[0] = 0;
    strcat(FileName, DirectoryName);
    if(IsSlash(FileName[strlen(FileName)-1])==false) strcat(FileName,SLASH);
    if(IsSlash(((const char*)F)[0])==false)          strcat(FileName, (const char*)F);
    else                                             strcat(FileName,((const char*)F)+1);

    return UFileName(FileName);
}
UDirectory UDirectory::operator+(const UDirectory& D) const
{
    if(this==NULL)          
    {
        CI.AddToLog("ERROR: UDirectory::operator+(). this==NULL \n");
        return D;
    }
    if(DirectoryName==NULL || DirectoryName[0]==0) return D;
    if(D.GetDirectoryName()==NULL) return *this;

    size_t nbytes = 2+strlen(DirectoryName) + strlen(D.DirectoryName);

    char* DirName = new char[nbytes];
    if(DirName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::operator+(). Memory allocation. \n");
        return D;
    }
    DirName[0] = 0;
    strcat(DirName, DirectoryName);
    if(IsSlash(DirName[strlen(DirName)-1])==false) strcat(DirName,SLASH);
    if(IsSlash(D.DirectoryName[0])==false)         strcat(DirName, D.DirectoryName);
    else                                           strcat(DirName, D.DirectoryName+1);

    return UDirectory(DirName);
}
char* UDirectory::SplitOffWildcards(void)
{
    if(this==NULL)          
    {
        CI.AddToLog("ERROR: UDirectory::SplitOffWildcards(). this==NULL \n");
        return NULL;
    }
    if(DirectoryName==NULL || DirectoryName[0]==0) return NULL;

    size_t nbytes     = strlen(DirectoryName);
    size_t firstWC    = nbytes +1;
    size_t LastSlash  = 0;

    for(size_t k=0; k<nbytes; k++)
    {
        if(IsSlash(DirectoryName[k])) LastSlash = k;
        if(DirectoryName[k]!='*') continue;
        firstWC = k;
        break;
    }
    if(firstWC>nbytes) return NULL;

    nbytes -= LastSlash;
    char* WildCards   = new char[nbytes+1];
    if(WildCards==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::SplitOffWildcards(). Memory allocation (%d) \n", int(nbytes));
        return NULL;
    }
    for(int k=0; k<nbytes+1; k++) WildCards[k] = 0;
    for(int k=0; k<nbytes-1; k++) WildCards[k] = DirectoryName[LastSlash+1+k];

    if(LastSlash==0)
    {
        DirectoryName[0] = '.';
        DirectoryName[1] = 0;
    }
    else
    {
        DirectoryName[LastSlash+1] = 0;
    }
    DirStatus = UpdateStatus();
    return WildCards;
}

UDirectory UDirectory::Parent(void) const
/*
     Return a directory-object corresponding to the parent-directory
     of this object. If no parent can be determined, return a default directory-object.
 */
{
    if(DirectoryName==NULL) return UDirectory();
    
    size_t k=strlen(DirectoryName);
    if(k>0)   // Do not substract 1 if k==0
    {
        k--;
        for(; k>0; k--)
            if(IsSlash(DirectoryName[k])) break;
    }
    if(k<=0) return UDirectory();

    char* ParentName = new char[k+1];
    if(ParentName==NULL) return UDirectory();

    memset(ParentName,0,k+1);
    memcpy(ParentName,DirectoryName,k);
    
    UDirectory Parent(ParentName, CNULL);
    delete[] ParentName;
    return Parent;
}

UDirectory UDirectory::Child(const char* SubdirName, const char* Ext) const
/*
     Return a directory-object corresponding to the subdirectory
     SubdirName[] of the directory corresponding to this object. 
     if(Ext!=NULL) merge the extension Ext[] onto the sub-directory name.

     On error, return the default directory object.

     Notes:
     SubdirName[] may or may not start with a SLASH-character, 
     Ext[] may or may not start with a '.'-character, 
     
 */
{
    if(SubdirName==NULL) return UDirectory();
    
    size_t  nbytes  = strlen(DirectoryName)+strlen(SubdirName)+2;
    if(Ext) nbytes += strlen(Ext)+2;

    char *ChildName = new char[nbytes+1];
    if(ChildName==NULL) return UDirectory();

    memset(ChildName,0,nbytes+1);
    strcpy(ChildName,DirectoryName);

    if(ChildName[0]==0)
    {
        strcat(ChildName,SubdirName);
    }
    else
    {
        if(IsSlash(ChildName[strlen(ChildName)-1])==false) strcat(ChildName,SLASH);
    
        if(IsSlash(SubdirName[0])==true)  strcat(ChildName,SubdirName+1); 
        else                              strcat(ChildName,SubdirName);
    }
    if(Ext)
    {
        if(Ext[0]!='.') strcat(ChildName,".");
        strcat(ChildName,Ext);
    }

    UDirectory Child(ChildName, CNULL);
    delete[] ChildName;    
    return Child;
}

UDirectory UDirectory::Sibling(const char* SiblingName, const char* Ext) const
/*
     Return a directory-object corresponding to sibling-directory
     SiblingName[] of the directory corresponding to this object. 
     if(Ext!=NULL) merge the extension Ext[] onto the sibling-directory name.

     On error, return the default directory object.

     Notes:
     SiblingName[] may or may not start with a SLASH-character, 
     Ext[] may or may not start with a '.'-character, 
     
 */
{
    if(SiblingName==NULL) return UDirectory();
    
    UDirectory Par = Parent();
    return     Par.Child(SiblingName, Ext);
}

char* UDirectory::MergeDirFileExt(const char* FileName, int nAddChar, const char* Ext) const
/*
     If(FileName== "a pure filename")  // See function IsPureFile()
     {
        Merge the DirectoryName and the filename Filename.
        Allocate memory (using new[]) for the merged path and flename and for nAddChar 
        additional characters.
        return a pointer to this new string.

     }
     else
     {
        return a pointer to a new string, to which Filename is copied, followed
        by nAddChar characters
     }
     In both cases, if(Ext!=NULL) allocate also memory for the file extenstion Ext[]
     (dot will be added if not present in Ext[]) and merge the file extension to
     the returned string. 
     If(Ext!=NULL   and nAddChar!=NULL), insert nAddChar underscore '_' characters, 
     before merging the file extension.

     Note:
     The purpose of the addidional characterters is to add file-numbers or versions.

 */
{
    if(FileName==NULL || nAddChar<0) return NULL;

    char *PathFile = NULL;
    if(IsPureFile(FileName)==true)
    {
        size_t  nbytes  = strlen(DirectoryName)+strlen(FileName)+3+nAddChar;
        if(Ext) nbytes += strlen(Ext)+2;

        if((PathFile = new char[nbytes]) == NULL) return NULL;
        memset(PathFile, 0, nbytes);

        memcpy(PathFile, DirectoryName, strlen(DirectoryName)+1);
        if(IsSlash(PathFile[strlen(PathFile)-1])==false) strcat(PathFile,SLASH);
    }
    else
    {
        size_t  nbytes  = strlen(FileName)+3+nAddChar;
        if(Ext) nbytes += strlen(Ext)+2;
        if((PathFile = new char[nbytes]) == NULL) return NULL;
        memset(PathFile, 0, nbytes);
    }
    strcat(PathFile,FileName);
    
    if(Ext)    
    {
        if(PathFile[strlen(PathFile)-1] == '.')
            PathFile[strlen(PathFile)-1] = 0;

        for(int k=0; k<nAddChar; k++) strcat(PathFile,"_");
        if(Ext[0] != '.') strcat(PathFile,".");
        strcat(PathFile,Ext);
    }

    return PathFile;
}

const char* UDirectory::GetBaseName(void) const
{
    if(this==NULL || DirectoryName==NULL) return NULL;

    for(size_t k=strlen(DirectoryName); k>0; k--)  // Do not substract 1
        if(IsSlash(DirectoryName[k-1]) || DirectoryName[k-1]==':') return DirectoryName+k;
    
    return DirectoryName;
}
bool UDirectory::HasAnyExtension(void) const
{
    if(this==NULL)          return false;
    if(DirectoryName==NULL) return false;
    int ioff = GetExtensionOffset();
    if(ioff<=0) return false; 
    if(DirectoryName[ioff+1]==0) return false;
    return true;
}
ErrorType UDirectory::ReplaceExtension(const char* Ext)
{
    if(this==NULL) return U_ERROR;
    if(DirectoryName==NULL)
    {
        *this     = UDirectory(Ext);
        DirStatus = UpdateStatus();
        if(DirectoryName) return U_OK;
        return U_ERROR;
    }

    int ioff = GetExtensionOffset();
    if(Ext==NULL || Ext[0]==0)
    {
        if(ioff>0) DirectoryName[ioff] = 0;
        DirStatus = UpdateStatus();
        return U_OK;
    }

    size_t nbytes          = strlen(DirectoryName) + strlen(Ext) + 4;
    
    char *NewDirectoryName = new char[nbytes];
    if(NewDirectoryName==NULL) return U_ERROR;
    memset(NewDirectoryName, 0, nbytes);
    strcat(NewDirectoryName, DirectoryName);

    if(ioff>0) NewDirectoryName[ioff] = 0;
        
    if(Ext[0]!='.') strcat(NewDirectoryName, ".");
    strcat(NewDirectoryName, Ext);
    
    delete[] DirectoryName;
    DirectoryName = NewDirectoryName;
    DirStatus     = UpdateStatus();
    return U_OK;
}
bool UDirectory::HasExtension(const char* Ext, bool CaseSensitive) const
{
    if(DirectoryName==NULL) return false;
    UFileName F(DirectoryName);
    return F.HasExtension(Ext, CaseSensitive);    
}
ErrorType UDirectory::AddExtension(const char* Ext)
{
    if(this==NULL) return U_ERROR;
    if(Ext==NULL || Ext[0]==0) return U_OK;

    if(DirectoryName==NULL)
    {
        *this = UDirectory(Ext);
        if(DirectoryName) return U_OK;
        return U_ERROR;
    }

    size_t nbytes          = strlen(DirectoryName) + strlen(Ext) + 4;
    
    char *NewDirectoryName = new char[nbytes];
    if(NewDirectoryName==NULL) return U_ERROR;
    memset(NewDirectoryName, 0, nbytes);
    strcat(NewDirectoryName, DirectoryName);
    
    size_t lastchar = strlen(DirectoryName); // Do not substract 1
    if(NewDirectoryName[lastchar-1] != '.') NewDirectoryName[lastchar] = '.';
    if(Ext[0]                       != '.') strcat(NewDirectoryName, Ext);
    else                                    strcat(NewDirectoryName, Ext+1);
    
    delete[] DirectoryName;
    DirectoryName = NewDirectoryName;
    return U_OK;
}
ErrorType UDirectory::InsertBeforeExtension(const char* Insert, const char* Insert2)
{
    if( (Insert ==NULL || Insert [0]==0) &&
        (Insert2==NULL || Insert2[0]==0)) return U_OK;

    if(DirectoryName==NULL)
    {
        *this = UDirectory(Insert);
        if(DirectoryName) return U_OK;
        return U_ERROR;
    }

    size_t      nbytes  = strlen(DirectoryName);
    if(Insert ) nbytes += strlen(Insert ) + 4;
    if(Insert2) nbytes += strlen(Insert2) + 4;

    char *NewDirName = new char[nbytes];
    if(NewDirName==NULL) return U_ERROR;
    memset(NewDirName, 0, nbytes);
    strcat(NewDirName, DirectoryName);

    int ioff = GetExtensionOffset();
    if(ioff>0)
    {
        NewDirName[ioff] = 0;
        if(Insert ) strcat(NewDirName, Insert );
        if(Insert2) strcat(NewDirName, Insert2);

        size_t      Ninsert  = 0;
        if(Insert ) Ninsert += strlen(Insert);
        if(Insert2) Ninsert += strlen(Insert2);

        for(size_t kk=ioff; kk<strlen(DirectoryName); kk++) NewDirName[kk+Ninsert] = DirectoryName[kk];
    }
    else
    {
        if(Insert ) strcat(NewDirName, Insert);
        if(Insert2) strcat(NewDirName, Insert2);
    }

    delete[] DirectoryName; DirectoryName = NewDirName;
    return U_OK;
}

int UDirectory::GetNumberBeforeExtension(int DefNum) const
{
    if(this==NULL || DirectoryName==NULL) return DefNum;
    int ioff = -1+GetExtensionOffset();
    if(ioff==0 || ioff==1) return DefNum;
    if(ioff<0)
    {
        ioff = strlen(DirectoryName)-1;
        if(IsSlash(DirectoryName[ioff]) ) ioff--;
    }
    int NDigit = 0;
    for(int k=ioff; k>=0; k--)
    {
        if(DirectoryName[k]<'0' || '9'<DirectoryName[k]) break;
        NDigit++;
    }
    if(NDigit<=0) return DefNum;

    return atoi(DirectoryName+ioff+1-NDigit);
}
int UDirectory::GetNDigitBeforeExtension(void) const
{
    if(this==NULL || DirectoryName==NULL) return 0;
    int ioff = -1+-1+ GetExtensionOffset();
    if(ioff==0 || ioff==1) return -1;
    if(ioff<0)
    {
        ioff = strlen(DirectoryName)-1;
        if(IsSlash(DirectoryName[ioff]) ) ioff--;
    }
    int NDigitUsed  = 0;
    for(int k=ioff; k>=0; k--)
    {
        if('0'<=DirectoryName[k] && DirectoryName[k]<='9') 
        {
            NDigitUsed++;
            continue;
        }
        break;
    }
    return NDigitUsed;
}

bool UDirectory::IsPureFile(const char* FileName) const
/*
    Return true iff FileName does not contain any slashes and the second character
    is not equal to ':'
 */
{
    if(this==NULL)       return true;
    if(FileName[1]==':') return false;
    for(size_t k=0; k<strlen(FileName); k++) if(IsSlash(FileName[k])) return false;

    return true;
}
const char* UDirectory::GetExtension(void) const
{
    if(this==NULL || DirectoryName==NULL) NULL;

    int extoff = GetExtensionOffset();
    if(extoff<0) return NULL;
    return DirectoryName + extoff;
}

int UDirectory::GetExtensionOffset(void) const
{
    if(this==NULL || DirectoryName==NULL) return -1;

    for(size_t k=strlen(DirectoryName); k>0; k--) // Do not substract 1
    {
        if(IsSlash(DirectoryName[k-1])) return -1;
        if(DirectoryName[k-1]==    '.') return  int(k-1);
    }
    return -1;
}
 
int UDirectory::GetBaseNameOffset(void) const
{
    if(this==NULL || DirectoryName==NULL) return -1;

    for(size_t k=strlen(DirectoryName); k>0; k--) // Do not substract 1
        if(IsSlash(DirectoryName[k-1])) return int(k-1);

    return -1;
}

UFileName* UDirectory::GetFileNames(const char* FileDescr, int* Nfiles, bool AddParentName) const
{
    if(this==NULL || DirectoryName==NULL) return NULL;
    return GetFileDirNames(FileDescr, Nfiles, U_GET_FILES, AddParentName);
}
UFileName* UDirectory::GetSubdirNames(const char* FileDescr, int* Nfiles, bool AddParentName) const
{
    if(this==NULL || DirectoryName==NULL) return NULL;
    return GetFileDirNames(FileDescr, Nfiles, U_GET_SUBDIRS, AddParentName);
}

static UFileName* GlobNames;
static int FileNameOrder(const void *elem1, const void *elem2)
{
    const UFileName* F1 = (const UFileName*)(GlobNames+(*(int*)elem1));
    const UFileName* F2 = (const UFileName*)(GlobNames+(*(int*)elem2));

    int order = GetFileNameOrder(F1, F2);
    return order;
}

UFileName* UDirectory::GetAllSubdirNames(const char* FileDescr, int* Ndirs) const
/*
    Return a pointer to a new array of UFileNames, corresponding to all
    subdirectories of *this, whose name is compatible to FileDescr[].

    Note1: Each array element contains the complete directory name, including the name of *this
    Note2: The maximum number of directory name that are returned is MaxNsubDirs 
           (see below)
 */
{
    if(this==NULL || DirectoryName==NULL || DirectoryName[0]==0)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(). Object NULL or not properly set.\n");
        return NULL;
    }
    if(DirStatus!=U_EXIST)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(). Directory does not exist: %s \n", DirectoryName);
        return NULL;
    }

    if(Ndirs==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): NULL argument.\n");
        return NULL;
    }
    const int MaxNsubDirs = 10000;
    
    UFileName* pSubDirNames = new UFileName[MaxNsubDirs];
    if(pSubDirNames==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): Memory allocation error.\n");
        return NULL;
    }

    pSubDirNames[0] = UFileName(DirectoryName);

    int FirstDir  =  0;
    int LastDir   =  1;
    int NnewDirs  = -1;
    while(NnewDirs)
    {
        NnewDirs = 0;
        for(int n=FirstDir, nn=LastDir; n<LastDir; n++)
        {
            int nDir  = 0;

            UDirectory Sdir(pSubDirNames[n].GetFullFileName(), CNULL);

            UFileName* pNewDirs = Sdir.GetSubdirNames("*", &nDir, false);
            if(pNewDirs==NULL && nDir==0) continue;
            if(pNewDirs==NULL)
            {
                CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(). Getting subdirectories from %s .\n",Sdir.GetDirectoryName());
                delete[] pSubDirNames;
                return NULL;
            }
            
            int nSkipDir = 0;
            for(int n1=0; n1<nDir; n1++,nn++)
            {
                if(pNewDirs[n1].GetFullFileName()[0]=='.')
                {
                    nSkipDir++;
                    nn--;
                    continue;
                }
                
                if(nn>=MaxNsubDirs)
                {
                    CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): Too many directories, more than %d  .\n",MaxNsubDirs);
                    *Ndirs = MaxNsubDirs;
                    return pSubDirNames;
                }
                pSubDirNames[nn] = UFileName(pSubDirNames[n].GetFullFileName(), pNewDirs[n1].GetFullFileName());
            }
            delete[] pNewDirs;

            nDir     -= nSkipDir;
            NnewDirs += nDir;
        }
        FirstDir = LastDir;
        LastDir  = FirstDir + NnewDirs;
    }

/* Test directories*/
    for(int n=0; n<LastDir; n++)
    {
        if(pSubDirNames[n].GetFullFileName()==NULL)
        {
            if(n==0)
                CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): Memory allocation error in first directory: %s .\n",DirectoryName);
            else
                CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): Memory allocation error in directory after = %s\n",pSubDirNames[n-1].GetFullFileName());
            delete[] pSubDirNames;
            return NULL;
        }
    }

/* Skip incompatible names*/
    int ngood = 0;
    for(int n=0; n<LastDir; n++)
    {
        if(pSubDirNames[n].IsFullFileNameCompatible(FileDescr)==false) continue;
        pSubDirNames[ngood++] = pSubDirNames[n];
    }    
    *Ndirs = ngood;
    if(ngood==NULL)
    {
        delete[] pSubDirNames;
        return NULL;
    }

/* Sort subdir names*/
    int* index = new int[ngood];
    if(index==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllSubdirNames(): Memory allocation, nfiles = %d\n", ngood);
        return pSubDirNames;
    }
    for(int n=0; n<ngood; n++) index[n] = n;

    GlobNames = pSubDirNames;
    qsort(index, ngood, sizeof(index[0]), FileNameOrder);

/* Compress and store sorted array*/
    UFileName* pGoodDir = new UFileName[ngood];
    if(pGoodDir)
    {
        for(int n=0; n<ngood; n++) pGoodDir[n] = pSubDirNames[index[n]];
        delete[] pSubDirNames; delete[] index;
        return pGoodDir;
    }
    delete[] index;
    return pSubDirNames;
}

UFileName* UDirectory::GetAllFileNames(const char* FileDescr, int* Nfiles) const
/*
    Return a pointer to a new array of UFileNames, corresponding to all
    file names in or below the directory corresponding to *this, whose name is 
    compatible to FileDescr[].

    Note1: Each array element contains the complete file name name, including the 
           name of *this
    Note2: The maximum number of directory name that are returned is MaxFileNames
           (see below)
 */
{
    if(this==NULL || DirectoryName==NULL || DirectoryName[0]==0)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllFileNames(). Object NULL or not properly set.\n");
        return NULL;
    }
    if(DirStatus!=U_EXIST)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllFileNames(). Directory does not exist: %s \n", DirectoryName);
        return NULL;
    }
    int        Ndirs    = 0;
    UFileName* pSubDirs = GetAllSubdirNames("*", &Ndirs);
    if(pSubDirs==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllFileNames(). Getting sub-directories.\n");
        return NULL;
    }
    const int MaxFileNames = 100000;
    UFileName* pFiles = new UFileName[MaxFileNames];
    if(pFiles==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetAllFileNames(). Memory allocation.\n");
        delete[] pSubDirs;
        return NULL;
    }

/* Get all compatible file names*/
    int ngood = 0;
    for(int n=0; n<Ndirs; n++)
    {
        UDirectory Dir(pSubDirs[n].GetFullFileName(), CNULL);
        int         NsubFiles = 0;
        UFileName*  pSubFiles = Dir.GetFileNames("*", &NsubFiles);

        if(pSubFiles)
        {
            for(int k=0; k<NsubFiles; k++)
            {
                UFileName TestFileName(Dir, pSubFiles[k]);
                if(TestFileName.IsFullFileNameCompatible(FileDescr)==false) continue;
                
                if(ngood<MaxFileNames)
                {
                    pFiles[ngood] = TestFileName;
                    ngood++;
                }
                else
                {
                    CI.AddToLog("WARNING: UDirectory::GetAllFileNames(). Too many files. Not all files are returned.\n");
                    break;
                }
            }
        }
        delete[] pSubFiles;
    }
    *Nfiles = ngood;
    if(ngood<=0)
    {
        delete[] pFiles;
        return NULL;
    }

/* Sort file names*/
    int* index = new int[ngood];
    if(index==NULL)
    {
        CI.AddToLog("WARNING: UDirectory::GetAllFileNames(): Memory allocation, nfiles = %d. Files not sorted. \n", ngood);
        return pFiles;
    }
    for(int n=0; n<ngood; n++) index[n] = n;

    GlobNames = pFiles;
    qsort(index, ngood, sizeof(index[0]), FileNameOrder);

/* Store sorted array*/
    UFileName* pSortFile = new UFileName[ngood];
    if(pSortFile)
    {
        for(int n=0; n<ngood; n++)   pSortFile[n] = pFiles[index[n]];
        delete[] pFiles;  delete[] index;
        return pSortFile;
    }
    delete[] index;
    return pFiles;
}

UFileName CombineDirFile(UDirectory Pre, UFileName Post, const char* DirExt)
{
    if(DirExt==NULL) return Pre+Post;

    bool       CaseSense = false;
    UDirectory Dir1      = Pre;
    while(Dir1.HasExtension(DirExt, CaseSense)==false)
    {
        Dir1 = Dir1.Parent();
        if(Dir1==UDirectory())
        {
            CI.AddToLog("ERROR: CombineDirFile(). Directory Pre (%s) has no parent with extension %s .\n", Pre.GetDirectoryName(), DirExt);
            return UFileName();
        }
    }
    UDirectory Dir;
    UDirectory Dir2 = Post.GetDirectory();
    while(Dir2.HasExtension(DirExt, CaseSense)==false)
    {
        Dir  = Dir + UDirectory(Dir2.GetBaseName());
        Dir2 = Dir2.Parent();
        if(Dir2==UDirectory())
        {
            CI.AddToLog("ERROR: CombineDirFile(). Directory Post (%s) has no parent with extension %s .\n", Post.GetFullFileName(), DirExt);
            return UFileName();
        }
    }
    return Dir + UFileName(Post.GetBaseName());
}

