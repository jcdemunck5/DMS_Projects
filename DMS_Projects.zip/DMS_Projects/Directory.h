/**** Meaning of Linux defines
    DT_BLK     //Block device file. 
    DT_CHR     //Character device file. 
    DT_DIR     //Directory. 
    DT_FIFO    //FIFO or named pipe. 
    DT_LNK     //Symbolic link. 
    DT_REG     //Regular file. 
    DT_SOCK    //Socket. 
    DT_UNKNOWN //Unknown file type. 
    DT_WHT     //Whiteout entry (BSD systems only). 
****/

#ifndef _DIRECTORY_INCLUDED
#define _DIRECTORY_INCLUDED

#include "BasicInclude.h"

class UFileName;

class DLL_IO UDirFileName
{
public:
    UDirFileName()  {return;}
    ~UDirFileName() {return;}

    static bool IsSlash(char c)
    {
#if defined ( _WINDOWS) &&  (defined(MSVC10)) || defined(MSVC_2017)
        return c=='\\' || c== '/';
#elif defined(WIN32) || defined(MSVC10) || defined(MSVC_2017)
        return c=='\\';
#else
        return c== '/';
#endif
    }
    static char ToLowerCase(char c)
    {
        if('A'<=c && c<='Z') return c+'a'-'A';
        return c;
    }
};

#if defined( _WINDOWS) &&  (defined(MSVC10) || defined(MSVC_2017))
    #define SLASH "\\"
#elif defined(WIN32) || defined(MSVC10) || defined(MSVC_2017)
    #define SLASH "\\"
#else
    #define SLASH "/"
#endif


class DLL_IO UDirectory : public UDirFileName
{
public:
    enum DirStat  {U_NOSTAT,           // Status can not be determined, or error
                   U_EXIST,            // The directory exists
                   U_NOACCESS,         // The direcory cannot be accessed
                   U_CANBECREATED,     // The directory does not exist, but can be created
                   U_NOTEXIST };       // The directory does not exist and cannot be created 

    UDirectory();
    UDirectory(const char *Dir);
    UDirectory(const char *Dir, const char *Ext);
    UDirectory(const char *FileName, bool IsFileName);
    UDirectory(const UDirectory& d);

    virtual ~UDirectory();

    operator const char*() const {return DirectoryName;}
    virtual UDirectory& operator=(const UDirectory &D);
    bool                operator==(const UDirectory &D) const; 
    bool                operator!=(const UDirectory &D) const; 
    UFileName           operator+(const UFileName &F) const;
    UDirectory          operator+(const UDirectory &D) const;

    
    DirStat             GetStatus(void)         const {if(this) return DirStatus;     return U_NOSTAT;}
    const char*         GetDirectoryName(void)  const {if(this) return DirectoryName; return NULL;    }
    char*               SplitOffWildcards(void);

    ErrorType           CompletePath(void);
    UFileName*          GetFileNames(const char* FileDescr, int* Nfiles, bool AddParentName=true) const;
    UFileName*          GetSubdirNames(const char* FileDescr, int* Nfiles, bool AddParentName=true) const;
    UFileName*          GetAllSubdirNames(const char* FileDescr, int* Ndirs) const;
    UFileName*          GetAllFileNames(const char* FileDescr, int* Nfiles) const;
        
    UDirectory          Parent(void) const;
    UDirectory          Child(const char* SubdirName, const char* Ext=NULL) const;
    UDirectory          Sibling(const char* SiblingName, const char* Ext=NULL) const;
        
    char*               MergeDirFileExt(const char* FileName, int nAddChar=0, const char* Ext=NULL) const;
    const char*         GetBaseName(void) const;
    const char*         GetExtension(void) const;
    
    bool                HasAnyExtension(void) const;
    ErrorType           ReplaceExtension(const char* Ext);
    ErrorType           SetExtension(const char* Ext) {return ReplaceExtension(Ext);}
    ErrorType           RemoveExtension(void)         {return ReplaceExtension(NULL);}

    ErrorType           AddExtension(const char* Ext);
    bool                HasExtension(const char* Ext, bool CaseSensitive=true) const;
    ErrorType           InsertBeforeExtension(const char* Insert, const char* Insert2=NULL);
    int                 GetNumberBeforeExtension(int DefNum=-1) const;
    int                 GetNDigitBeforeExtension(void) const;

    ErrorType           RenameDir(const char* NewName);
    ErrorType           CreateDir(void);
    ErrorType           RemoveDir(void);
    ErrorType           DeleteAllFiles(void);
    bool                IsPureFile(const char* FileName) const;
        
protected:
    char                *DirectoryName;          // Name of the directory
    DirStat             DirStatus;               // Status of the directory
    DirStat             UpdateStatus();

private:
    enum GetWhat  {U_GET_FILES, U_GET_SUBDIRS};

    int                 GetExtensionOffset(void) const;
    int                 GetBaseNameOffset(void) const;

    int                 GetNFileDirs(GetWhat GW) const;                                                    // platform dept.
    int                 GetAllNFileDirs(GetWhat GW=U_GET_FILES) const;
    UFileName*          GetFileDirNames(const char* FileDescr, int* Nfiles, GetWhat GW, bool AddParentName) const;  // platform dept.
};


UFileName      CombineDirFile(UDirectory Pre, UFileName Post, const char* DirExt);
#endif// _DIRECTORY_INCLUDED

