/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     This file contains the following operating system dependent parts of the  */
/*     UDirecory() implementation:                                               */
/*                                                                               */
/*     UFileName::RenameFile()                                                   */
/*     UDirectory::RenameDir()                                                   */
/*     UDirectory::RemoveDir()                                                   */
/*     UDirectory::DeleteAllFiles()                                              */
/*     UDirectory::CreateDir()                                                   */
/*     UDirectory::UpdateStatus()                                                */
/*     UDirectory::GetFileNames()                                                */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    11-03-01   creation, split off from Directory.cpp
  JdM    22-06-01   Bug Fix: UpdateStatus(). Test if DirectoryName refers to an existing file
  JdM    09-07-01   Compatibility with SUN compiler (SetData() and Smooth())
  JdM    12-07-01   UpdateStatus(). Do not test whether directory is file, under SUN sparc
  JdM    30-10-01   CreateDir() (UNIX) Use of access() function to test whether directory exists
  JdM    31-10-01   Added IsDirName()
JdM/GdV  25-03-02   Use small fonts for BOOL, TRUE and FALSE
JdM/GdV  07-11-02   Aplly the appropriate defines for linux
  JdM    05-03-03   Only include <windows.h> when not useing MFC
JdM/DT   20-05-05   GetFileNames() discriminate files and directories under linux
  JdM    09-01-06   GetFileNames(). Increase maximum buffer size from 100000 to 1000000
  JdM    22-02-06   GetFileNames().linux bug fix: discriminating files and directories
  JdM    10-05-06   CreateDir(). WIN32: Test dir status after _mkdir()
  JdM    10-09-08   Bug Fix: CreateDir(). WIN32: _mkdir() test errno==EEXIST
  JdM    04-01-09   Added UDirectory::RenameDir(), UDirectory::RemoveDir() and UFileName::RenameFile()
  JdM    24-03-09   Bug Fix: GetFileNames(). FindFirstFile(): test on INVALID_HANDLE_VALUE (instead of NULL)
  JdM    22-03-10   bug fix RenameFile() (#ifndef WIN32 ) : used valid filenames
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    21-03-11   GetFileNames() in case of #linux. Use stat()-function to distinguish files from directories
                    UpdateStatus() in case of #linux. Use mkdir() and rmdir() to define directory status
  JdM    29-03-11   UpdateStatus(). Test for wild cards in string. If present, return U_NOSTAT.
   AM    19-05-11   Added the include file sys/stat.h #elif linux. This include is required for compatibility with newer versions of GCC 
  JdM    24-07-12   Split DirectorySystem.cpp into DirectorySystemWIN32.h, DirectorySystemLINUX.h and DirectorySystemSPARC.h
                    Remove (obsolete) IsDirName().
   JdeM  03-03-18   Include case MSVC_2017
*/

#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "Directory.h"
#include "FileName.h"


#ifdef WIN32
#include "DirectorySystemWIN32.h"

#elif WIN64
#include "DirectorySystemWIN32.h"

#elif MSVC_2017
#include "DirectorySystemWIN32.h"

#elif linux
#include "DirectorySystemLINUX.h"

#elif sparc // not WIN32, UNIX, linux:
#include "DirectorySystemSPARC.h"

#endif  // WIN32