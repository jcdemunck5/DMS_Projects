/*********************************************************************************/
/*                                                                               */
/*     This file contains the following LINUX dependent parts of the             */
/*     UDirecory() implementation:                                               */
/*                                                                               */
/*     UFileName::RenameFile()                                                   */
/*     UFileName::RemoveFile()                                                   */
/*     UDirectory::RenameDir()                                                   */
/*     UDirectory::RemoveDir()                                                   */
/*     UDirectory::DeleteAllFiles()                                              */
/*     UDirectory::CreateDir()                                                   */
/*     UDirectory::UpdateStatus()                                                */
/*     UDirectory::GetFileDirNames()                                             */
/*     UDirectory::GetNFileDirs()                                                */
/*     UDirectory::CompletePath()                                                */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    24-07-12   creation, split off from DirectorySystem.cpp
  JdM    29-07-14   Replace (obsolete) GetFileNames() by GetFileDirNames() (new implementation)
                    Added GetNFileDirs()
JdM/FB   29-07-14   Bug Fix. Use delete[] instead of delete to free memory for array of UFileName
  JdM    31-07-14   Added CompletePath()
  JdM    03-08-14   Bug fixed: CompletePath()
 */

#include <sys/dir.h>    //// DIR
#include <sys/stat.h>   //// stat
#include <errno.h>      //// errno
#include <unistd.h>     //// rmdir()

#include <limits.h>
#include <stdlib.h>

////////////////
// See http://www.delorie.com/gnu/docs/glibc/libc_275.html
////////////////

/*     UFileName::RenameFile()                                                   */
/*     UFileName::RemoveFile()                                                   */
/*     UDirectory::RenameDir()                                                   */
/*     UDirectory::RemoveDir()                                                   */
/*     UDirectory::DeleteAllFiles()                                              */
/*     UDirectory::CreateDir()                                                   */
/*     UDirectory::UpdateStatus()                                                */
/*     UDirectory::GetFileDirNames()                                             */
/*     UDirectory::GetNFileDirs()                                                */



ErrorType UFileName::RenameFile(const char* NewFileName) const
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_FILE_CANBEREAD)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). File does not exist: %s.\n", FullFileName);
        return U_ERROR;
    }
    if(NewFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Invalid NULL argument. \n");
        return U_ERROR;
    }

    char command[500];
    int  nb = strlen(FullFileName) + strlen(NewFileName);
    if(nb<sizeof(command)-20)
    {
        sprintf(command,"ren %s %s", FullFileName, NewFileName);
        if(system(command)==0) return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameFile(). Renaming %s to %s. \n", FullFileName, NewFileName);
    return U_OK;
}
ErrorType UFileName::RemoveFile(void) const
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RemoveFile(). Object NULL or not set.\n");
        return U_ERROR;
    }
    CI.AddToLog("ERROR: UDirectory::RemoveFile(). Function not yet implemented. \n");
    return U_ERROR;
}
ErrorType UDirectory::RenameDir(const char* NewName)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_EXIST)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Directory does not exist: %s.\n", DirectoryName);
        return U_ERROR;
    }
    if(NewName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    char command[500];
    int  nb = strlen(DirectoryName) + strlen(NewName);
    if(nb<sizeof(command)-20)
    {
        sprintf(command,"ren %s %s",DirectoryName, NewName);
        if(system(command)==0) return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameDir(). Renaming %s to %s. \n", DirectoryName, NewName);
    return U_ERROR;
}

ErrorType UDirectory::RemoveDir(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RemoveDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

    if(rmdir(DirectoryName)==0)
    {
        DirStatus = U_NOTEXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::RemoveDir(). Deleting %s \n",DirectoryName);
    switch(errno)
    {
    case ENOTEMPTY: CI.AddToLog("ERROR: UDirectory::RemoveDir(). Directory not empty.\n"); break;
    case EACCES:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). No access.\n");           break;
    case ENOENT:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path not found.\n");      break;
    case EINVAL:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
}
ErrorType UDirectory::DeleteAllFiles(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::DeleteAllFiles(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

    char command[300];
    sprintf(command,"del %s/*",DirectoryName);
    if(system(command)==0) return U_OK;

    CI.AddToLog("ERROR UDirectory::DeleteAllFiles(). Deleting %s \n",DirectoryName);
    return U_ERROR;
}

ErrorType UDirectory::CreateDir(void)
/*
     Create the directory on disk, corresponding to DirectoryName[].
     return U_OK on succes, U_ERROR on any error. If the directory
     already exists, return U_OK right away.
 */
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::CreateDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_EXIST) return U_OK;

    struct stat st;
    stat(DirectoryName, &st);
    if(S_ISDIR(st.st_mode)) return U_OK;

    if(mkdir(DirectoryName, 0x777)==0 || errno==EEXIST)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::CreateDir(). Creating %s \n",DirectoryName);
    switch(errno)
    {
    case EEXIST: CI.AddToLog("ERROR: UDirectory::CreateDir(). Directory or file already exists.\n"); break;
    case EACCES: CI.AddToLog("ERROR: UDirectory::CreateDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path not found.\n");      break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
}

UDirectory::DirStat UDirectory::UpdateStatus()
/*
     return the current status of the direcory DirectoryName[]
 */
{
    if(this==NULL)                            return U_NOSTAT;
    if(!DirectoryName || DirectoryName[0]==0) return U_NOSTAT;
    int NB = strlen(DirectoryName);
    for(int k=0; k<NB; k++) if(DirectoryName[k]=='*') return U_NOSTAT;

    struct stat st;
    stat(DirectoryName, &st);
    if(S_ISREG(st.st_mode)) return U_NOTEXIST;  // It is a file!
    if(S_ISDIR(st.st_mode)) return U_EXIST;     // It is a directory
    
    if(mkdir(DirectoryName, 0x777)==0)
    {
        rmdir(DirectoryName);
        return U_CANBECREATED;
    }
    if(errno==EACCES || errno==EEXIST) return U_EXIST;
    if(errno==ENOENT)                  return U_NOTEXIST;
    return U_NOSTAT;
}

int UDirectory::GetNFileDirs(GetWhat GW) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetNFileDirs(). Object NULL or not set.\n");
        return 0;
    }
    if(DirectoryName==NULL || DirectoryName[0]==0)
    {
        CI.AddToLog("ERROR: UFileName::GetNFileDirs(). Directory name empty or not set.\n");
        return 0;
    }
#ifdef UNICODE
    CI.AddToLog("ERROR: UDirectory::GetNFileDirs(): Function not implemented for #define UNICODE \n");
    return 0;
#endif

    DIR* dir = opendir(DirectoryName);
    if(dir==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetNFileDirs(): Reading directory %s   . \n",DirectoryName);
        return NULL;
    }

    int   nfiles     = 0;
    while(1)
    {
        dirent* dirp = readdir(dir);
        if(dirp==NULL) break;
        if(!strncmp(dirp->d_name,".",1) || !strncmp(dirp->d_name,"..",2))  continue;

        UFileName Ftest = *this + UFileName(dirp->d_name);
        struct stat st;
        stat((const char*)Ftest, &st);

        if(GW==U_GET_FILES              && !S_ISREG(st.st_mode)) continue;  // Test regular file
        if(GW==U_GET_SUBDIRS            && !S_ISDIR(st.st_mode)) continue;  // Test directory

        nfiles++;
    }
    closedir(dir);

    return nfiles;
}

static UFileName* GlobNames;
static int FileNameOrder(const void *elem1, const void *elem2)
{
    const UFileName* F1 = (UFileName*)GlobNames+ (*(int*)elem1);
    const UFileName* F2 = (UFileName*)GlobNames+ (*(int*)elem2);

    return strcmp(F1->GetFullFileName(),F2->GetFullFileName());
}

UFileName* UDirectory::GetFileDirNames(const char* FileDescr, int* Nfiles, GetWhat GW, bool AddParentName) const
/*
    return a new pointer containing an array of UFileName objects which are present in the directory
    corresponding to this object. Filenames include this->DirectoryName.

    Filenames are ordered alphabetically

    *Nfiles will contain the number of files.
    The parameter GW determines whether files, sub-directories or both are returned

    return NULL on any error.

    Note1: The SUBDIRS "." and ".." are ignored
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetFileDirNames(). Object NULL or not set.\n");
        return NULL;
    }
    if(DirectoryName==NULL || DirectoryName[0]==0)
    {
        CI.AddToLog("ERROR: UFileName::GetFileDirNames(). Directory name empty or not set.\n");
        return NULL;
    }

#ifdef UNICODE
    CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Function not implemented for #define UNICODE \n");
    return NULL;
#endif

    if(FileDescr==NULL || Nfiles==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): NULL argument \n");
        return NULL;
    }
    *Nfiles = 0;

    int   NFmax       = GetNFileDirs(GW);
    if(NFmax<=0) return NULL;

    UFileName* FileNames   = new UFileName[NFmax];
    if(FileNames==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Memory allocation %s\n", DirectoryName);
        return NULL;
    }

/* Open directory, return 0 when no files are found.*/
    DIR* dir = opendir(DirectoryName);
    if(dir==NULL)
    {
        delete[] FileNames;
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Reading directory %s   . \n",DirectoryName);
        return NULL;
    }

    int   nfiles     = 0;
    while(1)
    {
        dirent* dirp = readdir(dir);
        if(dirp==NULL) break;
        if(!strncmp(dirp->d_name,".",1) || !strncmp(dirp->d_name,"..",2))  continue;

        UFileName Ftest = *this + UFileName(dirp->d_name);
        struct stat st;
        stat((const char*)Ftest, &st);

        if(GW==U_GET_FILES        && !S_ISREG(st.st_mode)) continue;
        if(GW==U_GET_SUBDIRS      && !S_ISDIR(st.st_mode)) continue;

        UFileName F = AddParentName ? *this + UFileName(dirp->d_name) : UFileName(dirp->d_name);
        if(F.IsFullFileNameCompatible(FileDescr)) FileNames[nfiles++] = F;
    }
    closedir(dir);

    if(nfiles<=0)
    {
        CI.AddToLog("WARNING: UDirectory::GetFileDirNames(): No files of specified type present %s\n", DirectoryName);
        *Nfiles = 0;
        delete[] FileNames;
        return NULL;
    }

/* Compute the file ordering index */
    int* index = new int[nfiles];
    if(index==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Memory allocation, nfiles = %d\n", nfiles);
        return FileNames;
    }
    for(int n=0; n<nfiles; n++) index[n] = n;

    GlobNames = FileNames;
    qsort(index, nfiles, sizeof(index[0]), FileNameOrder);

    *Nfiles = nfiles;
    UFileName* FGood = new UFileName[nfiles];
    if(FGood)
    {
        for(int k=0; k<nfiles; k++) FGood[k] = FileNames[index[k]];
        delete[] FileNames; delete[] index;
        return FGood;
    }
    delete[] index;
    return FileNames;
}
ErrorType UDirectory::CompletePath(void)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CompletePath(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(!DirectoryName || DirectoryName[0]==0) return U_ERROR;

    UDirectory P = Sibling("."); // Only call realpath() from an existing directory

    char* p = realpath((const char*)P, NULL);
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CompletePath(). realpath() function failed (%s).\n", (const char*)P);
        return U_ERROR;
    }
    P     = UDirectory((const char*)p);
    *this = UDirectory((const char*)(P + UFileName(this->GetBaseName())));
    free(p);
    return U_OK;
}
