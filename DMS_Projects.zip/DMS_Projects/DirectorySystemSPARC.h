/*********************************************************************************/
/*                                                                               */
/*     This file contains the following SUN SPARC dependent parts of the         */
/*     UDirecory() implementation:                                               */
/*                                                                               */
/*     UFileName::RenameFile()                                                   */
/*     UDirectory::RenameDir()                                                   */
/*     UDirectory::RemoveDir()                                                   */
/*     UDirectory::DeleteAllFiles()                                              */
/*     UDirectory::CreateDir()                                                   */
/*     UDirectory::UpdateStatus()                                                */
/*     UDirectory::GetFileNames()                                                */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    24-07-12   creation, split off from DirectorySystem.cpp
*/

///#include <sys/dir.h>
///#include <io.h>
#   include <dirent.h>
#   include <unistd.h>
#   include <fcntl.h>
#define _access(a, b) access(a, b)
/**
   int _access(const char *path, int mode)
   6   Check for read and write permission
   4   Check for read permission
   2   Check for write permission
   1   Execute (ignored)
   0   Check for existence of file
**/









ErrorType UFileName::RenameFile(const char* NewFileName) const
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_FILE_CANBEREAD)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). File does not exist: %s.\n", FullFileName);
        return U_ERROR;
    }
    if(NewFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Invalid NULL argument. \n");
        return U_ERROR;
    }
#ifdef WIN32
    if(rename(FullFileName, NewFileName)==0) return U_OK;

    CI.AddToLog("ERROR: UFileName::RenameFile(). Renaming %s to %s. \n", FullFileName, NewFileName);
    switch(errno)
    {
    case EACCES: CI.AddToLog("ERROR: UFileName::RenameFile(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UFileName::RenameFile(). Old path not found.\n");  break;
    case EINVAL: CI.AddToLog("ERROR: UFileName::RenameFile(). New path invalid.\n");    break;
    }
    return U_ERROR;
#else
    char command[500];
    int  nb = strlen(FullFileName) + strlen(NewFileName);
    if(nb<sizeof(command)-20)
    {
        sprintf(command,"ren %s %s", FullFileName, NewFileName);
        if(system(command)==0) return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameDir(). Renaming %s to %s. \n", FullFileName, NewFileName);
    return U_OK;
#endif
}

ErrorType UDirectory::RenameDir(const char* NewName)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_EXIST)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Directory does not exist: %s.\n", DirectoryName);
        return U_ERROR;
    }
    if(NewName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Invalid NULL argument. \n");
        return U_ERROR;
    }
#ifdef WIN32
    if(rename(DirectoryName, NewName)==0)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameDir(). Renaming %s to %s. \n", DirectoryName, NewName);
    switch(errno)
    {
    case EACCES: CI.AddToLog("ERROR: UDirectory::RenameDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::RenameDir(). Old path not found.\n");  break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::RenameDir(). New path invalid.\n");    break;
    }
    return U_ERROR;
#else
    char command[500];
    int  nb = strlen(DirectoryName) + strlen(NewName);
    if(nb<sizeof(command)-20)
    {
        sprintf(command,"ren %s %s",DirectoryName, NewName);
        if(system(command)==0) return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameDir(). Renaming %s to %s. \n", DirectoryName, NewName);
    return U_ERROR;
#endif
}

ErrorType UDirectory::RemoveDir(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RemoveDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

#ifdef WIN32
    if(_rmdir(DirectoryName)==0)
    {
        DirStatus = U_NOTEXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::RemoveDir(). Deleting %s \n",DirectoryName);
    switch(errno)
    {
    case ENOTEMPTY: CI.AddToLog("ERROR: UDirectory::RemoveDir(). Directory not empty.\n"); break;
    case EACCES:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). No access.\n");           break;
    case ENOENT:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path not found.\n");      break;
    case EINVAL:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
#else
#ifdef linux
    if(rmdir(DirectoryName)==0)
    {
        DirStatus = U_NOTEXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::RemoveDir(). Deleting %s \n",DirectoryName);
    switch(errno)
    {
    case ENOTEMPTY: CI.AddToLog("ERROR: UDirectory::RemoveDir(). Directory not empty.\n"); break;
    case EACCES:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). No access.\n");           break;
    case ENOENT:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path not found.\n");      break;
    case EINVAL:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
#endif
    char command[270];
    sprintf(command,"rmdir %s ",DirectoryName);
    if(system(command)==0) return U_OK;
///    if(mkdir(DirectoryName)==0)
///    {
///        DirStatus = U_EXIST;
///        return U_OK;
///    }
///    else
///        return U_ERROR;

///////    return U_ERROR;
    CI.AddToLog("ERROR UDirectory::RemoveDir(). Deleting %s \n",DirectoryName);
    return U_ERROR;
#endif
}
ErrorType UDirectory::DeleteAllFiles(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::DeleteAllFiles(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

    char command[300];
#ifdef WIN32
    sprintf(command,"del /Q /S %s\\*.*",DirectoryName);
#else
    sprintf(command,"del %s/*",DirectoryName);
#endif
    if(system(command)==0) return U_OK;
    CI.AddToLog("ERROR UDirectory::DeleteAllFiles(). Deleting %s \n",DirectoryName);
    return U_ERROR;
}

ErrorType UDirectory::CreateDir(void)
/*
     Create the directory on disk, corresponding to DirectoryName[].
     return U_OK on succes, U_ERROR on any error. If the directory
     already exists, return U_OK right away.
 */
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::CreateDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_EXIST) return U_OK;

#ifdef WIN32
    if(_mkdir(DirectoryName)==0)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    UpdateStatus();
    if(_mkdir(DirectoryName)==0 || errno==EEXIST)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::CreateDir(). Creating %s \n",DirectoryName);
    switch(errno)
    {
    case EEXIST: CI.AddToLog("ERROR: UDirectory::CreateDir(). Directory or file already exists.\n"); break;
    case EACCES: CI.AddToLog("ERROR: UDirectory::CreateDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path not found.\n");      break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
#elif linux
    struct stat st;
    stat(DirectoryName, &st);
    if(S_ISDIR(st.st_mode)) return U_OK;

    if(mkdir(DirectoryName, 0x777)==0 || errno==EEXIST)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::CreateDir(). Creating %s \n",DirectoryName);
    switch(errno)
    {
    case EEXIST: CI.AddToLog("ERROR: UDirectory::CreateDir(). Directory or file already exists.\n"); break;
    case EACCES: CI.AddToLog("ERROR: UDirectory::CreateDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path not found.\n");      break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
#else
    if(!_access(DirectoryName, 6)) return U_OK;

    char command[270];
    sprintf(command,"mkdir %s ",DirectoryName);
    if(system(command)==0) return U_OK;
    return U_ERROR;
#endif
}

UDirectory::DirStat UDirectory::UpdateStatus()
/*
     return the current status of the direcory DirectoryName[]
 */
{
    if(!DirectoryName || DirectoryName[0]==0) return U_NOSTAT;
    int NB = strlen(DirectoryName);
    for(int k=0; k<NB; k++) if(DirectoryName[k]=='*') return U_NOSTAT;

#ifndef sparc
#ifndef linux
    FILE* fp = fopen(DirectoryName,"rb");
    if(fp)
    {
        fclose(fp);
        return U_NOTEXIST; // It is a file!
    }
#endif
#endif
#ifdef WIN32
    if(_mkdir(DirectoryName) == 0)
    {
        _rmdir(DirectoryName);
        return U_CANBECREATED;
    }
    else
    {
        if(errno==EACCES || errno==EEXIST) return U_EXIST;
        if(errno==ENOENT)                  return U_NOTEXIST;
        return U_NOSTAT;
    }
#else
    struct stat st;
    stat(DirectoryName, &st);

    if(S_ISDIR(st.st_mode)) return U_EXIST;

    if(mkdir(DirectoryName, 0x777)==0)
    {
        rmdir(DirectoryName);
        return U_CANBECREATED;
    }
    else
    {
        if(errno==EACCES || errno==EEXIST) return U_EXIST;
        if(errno==ENOENT)                  return U_NOTEXIST;
        return U_NOSTAT;
    }
#endif
}

static char* GlobNames;
static int FileOrder(const void *elem1, const void *elem2)
{
    return strcmp(GlobNames+ *(int*)elem1,GlobNames+ *(int*)elem2);
}

char* UDirectory::GetFileNames(const char* FileDescr, int* Nfiles, int **index, GetWhat GW) const
/*
    return a new pointer containing a list of files which are present in the directory
    corresponding to this object. Filenames are separated by zeroes.

    The newly allocated array index[] is filled such that index[0] points to the
    first (alfabetic) file, index[1] to the second, etc.

    *Nfiles will contain the number of files.
    The parameter GW determines whether files, sub-directories or both are returned

    return NULL on any error.


    Note1: The SUBDIRS "." and ".." are ignored
    Note2: On UNIX FileDescr[] is ignored
 */
{
#ifdef UNICODE
    CI.AddToLog("ERROR: UDirectory::GetFileNames(): Function not implemented for #define UNICODE \n");
    return NULL;
#else
    if(FileDescr==NULL || Nfiles==NULL || index==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileNames(): NULL argument \n");
        return NULL;
    }
    *index  = NULL;
    *Nfiles = 0;

    char*  FileNames  = NULL;
    char*  buffer     = NULL;

#ifdef WIN32
    char* Files = new char[strlen(DirectoryName)+strlen(FileDescr)+2];
    if(Files==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileNames(): Memory allocation.\n");
        return NULL;
    }
    strcpy(Files, DirectoryName);
    if(DirectoryName[0])
        strcat(Files, SLASH);
    strcat(Files, FileDescr);

/* Find first file in the directory  dir, return 0 when no files are found.*/
    WIN32_FIND_DATA c_file;
    HANDLE          hFile =  FindFirstFile(Files, &c_file );
    if(hFile==INVALID_HANDLE_VALUE)
    {
        CI.AddToLog("WARNING: UDirectory::GetFileNames(): Cannot find first file of type %s\n", Files);
        delete[] Files;
        return NULL;
    }

    int       nfiles      = 0;
    ErrorType BufferError = U_ERROR;
    for(int BufferSize = 8000; BufferSize<1000000 && BufferError==U_ERROR; BufferSize *= 2)
    {
        delete[] FileNames;
        FileNames  = new char[BufferSize];
        if(!FileNames)
        {
            delete[] FileNames; FileNames = NULL;
            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Memory allocation error in directory, BufferSize = %d. \n",BufferSize);
            return NULL;
        }
        memset(FileNames,0,BufferSize);

        int    nbytes    = 0;
        char   *newfilep = FileNames;
        BufferError      = U_OK;

/* Skip SUBDIRS, c.q. filenames*/
        nfiles    = 0;
        if(  GW==U_GET_FILES_AND_SUBDIRS ||
            (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
            (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )
        {
            nbytes   += (1+strlen(c_file.cFileName));
            if(nbytes>BufferSize)
            {
                BufferError = U_ERROR;
                hFile       = FindFirstFile(Files, &c_file );
                continue;
            }
            strcpy(newfilep, c_file.cFileName);
            newfilep += (1+strlen(c_file.cFileName));
            nfiles++;
        }

/* Find the rest of files */
        while(FindNextFile(hFile, &c_file)==TRUE)
        {
            if(  GW==U_GET_FILES_AND_SUBDIRS ||
                (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
                (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )
            {
                nbytes   += (1+strlen(c_file.cFileName));
                if(nbytes>BufferSize)
                {
                    BufferError = U_ERROR;
                    hFile       = FindFirstFile(Files, &c_file );
                    break;
                }
                strcpy(newfilep,c_file.cFileName);
                newfilep += (1+strlen(c_file.cFileName));
                nfiles++;
            }
        }
        if(BufferError==U_OK) FindClose( hFile );
    }
    if(BufferError!=U_OK)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileNames(). Too many files, increase buufer size. \n");
        FindClose( hFile );
        delete[] FileNames;
        return NULL;
    }

#elif linux
    int       nfiles      = 0;
    ErrorType BufferError = U_ERROR;
    for(int BufferSize = 8000; BufferSize<1000000 && BufferError==U_ERROR; BufferSize *= 2)
    {
        delete[] FileNames;
        FileNames  = new char[BufferSize];
        if(!FileNames)
        {
            delete[] FileNames; FileNames = NULL;
            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Memory allocation error in directory, BufferSize = %d. \n",BufferSize);
            return NULL;
        }
        memset(FileNames,0,BufferSize);
        int    nbytes    = 0;
        char   *newfilep = FileNames;
        BufferError      = U_OK;
        DIR* dir = opendir(DirectoryName);
        if(dir==NULL)
        {
            delete[] FileNames; FileNames = NULL;
            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Reading directory %s   . \n",DirectoryName);
            return NULL;
        }
        while(1)
        {
            dirent* dirp = readdir(dir);
            if(dirp==NULL) break;
            if(!strncmp(dirp->d_name,".",1) || !strncmp(dirp->d_name,"..",2))  continue;

            UFileName F(DirectoryName, dirp->d_name, NULL);
            struct stat st;
            stat((const char*)F, &st);

            if( !S_ISREG(st.st_mode)  && !S_ISDIR(st.st_mode) ) continue;
            if(GW!=U_GET_FILES_AND_SUBDIRS)
            {
                if(GW==U_GET_FILES              && !S_ISREG(st.st_mode)) continue;
                if(GW==U_GET_SUBDIRS            && !S_ISDIR(st.st_mode)) continue;

                nbytes   += (1+strlen(dirp->d_name));
                if(nbytes>BufferSize)
                {
                    BufferError = U_ERROR;
                    closedir(dir);
                    continue;
                }
                strcpy(newfilep,dirp->d_name);
                newfilep += (1+strlen(dirp->d_name));
                nfiles++;
            }
        }
        if(BufferError==U_OK) closedir(dir);
    }
    if(BufferError!=U_OK)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileNames(). Too many files, increase buffer size. \n");
        delete[] FileNames;
        return NULL;
    }

#elif sparc // not WIN32, UNIX, linux:
    int       nfiles      = 0;
    int       nfiles      = 0;
    ErrorType BufferError = U_ERROR;
    for(int BufferSize = 8000; BufferSize<1000000 && BufferError==U_ERROR; BufferSize *= 2)
    {
        delete[] FileNames;
        delete[] buffer;
        FileNames  = new char[BufferSize];
        buffer     = new char[BufferSize];
        if(!FileNames || !buffer)
        {
            delete[] FileNames; FileNames = NULL;
            delete[] buffer;    buffer    = NULL;

            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Memory allocation error in directory (1)");
            return NULL;
        }
        memset(FileNames, 0, BufferSize);
        memset(buffer   , 0, BufferSize);

        int    n;
        int    nbytes    = 0;
        char   *newfilep = FileNames;

        int    hFile = open(DirectoryName, O_RDONLY);
        if(hFile<=-1)
        {
            delete[] FileNames; FileNames = NULL;
            delete[] buffer;    buffer    = NULL;
            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Directory can not be opened %s\n", DirectoryName);
            return NULL;
        }
        nfiles      = 0;
        BufferError = U_OK;

        while(1)
        {
            int testdir=getdents(hFile, (dirent*)buffer, BufferSize);
            if(testdir<0)
            {
                BufferError=U_ERROR;
                break;
            }
            if(testdir==0) break;

            n=0;
            while(n<BufferSize)
            {
                dirent *dirp = (dirent*) (buffer+n);

                if(dirp->d_reclen==0) break;
                n   += dirp->d_reclen;
                if(!strncmp(dirp->d_name,".",1) || !strncmp(dirp->d_name,"..",2))  continue;
                if(dirp->d_type!=DT_REG && dirp->d_type!=DT_DIR)                   continue;
                if(GW!=U_GET_FILES_AND_SUBDIRS)
                {
                    if(GW==U_GET_FILES              && dirp->d_type!=DT_REG) continue;
                    if(GW==U_GET_SUBDIRS            && dirp->d_type!=DT_DIR) continue;
                }
                if(newfilep+strlen(dirp->d_name)+1 > FileNames+BufferSize)
                {
                    BufferError=U_ERROR;
                    break;
                }

                memcpy(newfilep, dirp->d_name, strlen(dirp->d_name));

                newfilep[strlen(dirp->d_name)] = 0;
                newfilep += strlen(dirp->d_name)+1;
                nfiles++;
            }
            memset(buffer, 0, BufferSize);
        }
        off_t  basep=0;
        memset(buffer, 0, BufferSize);
        while(1)
        {
            int testdir=getdirentries(hFile, (direct*)buffer, BufferSize, &basep);
            if(testdir<0)
            {
                BufferError=U_ERROR;
                break;
            }

            if(testdir==0) break;

            n=0;
            while(n<BufferSize)
            {
                direct *dirp = (direct*) (buffer+n);

                if(dirp->d_reclen==0) break;
                n   += dirp->d_reclen;
                if(!strncmp(dirp->d_name,".",1))                   continue;
                if(dirp->d_type!=DT_REG && dirp->d_type!=DT_DIR)   continue;
                if(GW!=U_GET_FILES_AND_SUBDIRS)
                {
                    if(GW==U_GET_FILES    && dirp->d_type!=DT_REG) continue;
                    if(GW==U_GET_SUBDIRS  && dirp->d_type!=DT_DIR) continue;
                }
                if(newfilep+strlen(dirp->d_name)+1 > FileNames+BufferSize)
                {
                    BufferError=U_ERROR;
                    break;
                }

                memcpy(newfilep, dirp->d_name, strlen(dirp->d_name));

                newfilep[strlen(dirp->d_name)] = 0;
                newfilep += strlen(dirp->d_name)+1;
                nfiles++;
            }
            memset(buffer, 0, BufferSize);
        }

    }
    delete[] buffer;

#endif  // WIN32
/* Compute the file ordering index */
    GlobNames = FileNames;
    if(nfiles)
    {
        *index = new int[nfiles];
        if(!(*index))
        {
            CI.AddToLog("ERROR: UDirectory::GetFileNames(): Cannot allocate memory for %d files\n",nfiles);
            delete[] FileNames;
            return NULL;
        }

        (*index)[0] = 0;
        for(int n=1; n<nfiles;n++)  (*index)[n] = (*index)[n-1] + strlen(FileNames+ (*index)[n-1])+1;

        qsort(*index, nfiles, sizeof((*index)[0]), FileOrder);
    }
    *Nfiles = nfiles;

    return FileNames;
#endif // UNICODE
}
