/*********************************************************************************/
/*                                                                               */
/*     This file contains the following WIN32 dependent parts of the             */
/*     UDirecory() implementation:                                               */
/*                                                                               */
/*     UFileName::RenameFile()                                                   */
/*     UFileName::RemoveFile()                                                   */
/*     UDirectory::RenameDir()                                                   */
/*     UDirectory::RemoveDir()                                                   */
/*     UDirectory::DeleteAllFiles()                                              */
/*     UDirectory::CreateDir()                                                   */
/*     UDirectory::UpdateStatus()                                                */
/*     UDirectory::GetFileDirNames()                                             */
/*     UDirectory::GetNFileDirs()                                                */
/*     UDirectory::CompletePath()                                                */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    24-07-12   creation, split off from DirectorySystem.cpp
  JdM    08-08-12   Bug Fix. UpdateStatus(). Test whether directory can be created.
  JdM    01-08-13   Added RemoveFile()
  JdM    16-01-14   Added GetNFileDirs() and GetFileDirNames(). Completely restructured GetFileNames() and GetFileNames()
  JdM    28-06-14   Bug fix. UDirectory::GetNFileDirs(). delete[] Files after printing WARNING
JdM/FB   29-07-14   Bug Fix. Use delete[] instead of delete to free memory for array of UFileName
  JdM    31-06-14   Added CompletePath()
  JdM    07-12-15   UpdateStatus(). Changed algorithm to test whether directory exists
  JdM    27-04-18   Bug Fix: GetFileDirNames(). Change algorithm
*/

#include <direct.h>
#include <stdlib.h>
#include <errno.h>


#ifndef _AFXDLL
#include <windows.h>
#endif

ErrorType UFileName::RenameFile(const char* NewFileName) const
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_FILE_CANBEREAD)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). File does not exist: %s.\n", FullFileName);
        return U_ERROR;
    }
    if(NewFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RenameFile(). Invalid NULL argument. \n");
        return U_ERROR;
    }

    if(rename(FullFileName, NewFileName)==0) return U_OK;

    CI.AddToLog("ERROR: UFileName::RenameFile(). Renaming %s to %s. \n", FullFileName, NewFileName);
    switch(errno)
    {
    case EACCES: CI.AddToLog("ERROR: UFileName::RenameFile(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UFileName::RenameFile(). Old path not found.\n");  break;
    case EINVAL: CI.AddToLog("ERROR: UFileName::RenameFile(). New path invalid.\n");    break;
    }
    return U_ERROR;
}
ErrorType UFileName::RemoveFile(void) const
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RemoveFile(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_FILE_CANBEREAD)
    {
        CI.AddToLog("ERROR: UFileName::RemoveFile(). File does not exist: %s.\n", FullFileName);
        return U_ERROR;
    }

    if(remove(FullFileName)==0) return U_OK;

    switch(errno)
    {
    case EACCES: CI.AddToLog("ERROR: UFileName::RemoveFile(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UFileName::RemoveFile(). Old path not found.\n");  break;
    case EINVAL: CI.AddToLog("ERROR: UFileName::RemoveFile(). New path invalid.\n");    break;
    }
    return U_ERROR;
}
ErrorType UDirectory::RenameDir(const char* NewName)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(GetStatus()!=U_EXIST)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Directory does not exist: %s.\n", DirectoryName);
        return U_ERROR;
    }
    if(NewName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RenameDir(). Invalid NULL argument. \n");
        return U_ERROR;
    }

    if(rename(DirectoryName, NewName)==0)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR: UDirectory::RenameDir(). Renaming %s to %s. \n", DirectoryName, NewName);
    switch(errno)
    {
    case EACCES: CI.AddToLog("ERROR: UDirectory::RenameDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::RenameDir(). Old path not found.\n");  break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::RenameDir(). New path invalid.\n");    break;
    }
    return U_ERROR;
}

ErrorType UDirectory::RemoveDir(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::RemoveDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

    if(_rmdir(DirectoryName)==0)
    {
        DirStatus = U_NOTEXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::RemoveDir(). Deleting %s \n",DirectoryName);
    switch(errno)
    {
    case ENOTEMPTY: CI.AddToLog("ERROR: UDirectory::RemoveDir(). Directory not empty.\n"); break;
    case EACCES:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). No access.\n");           break;
    case ENOENT:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path not found.\n");      break;
    case EINVAL:    CI.AddToLog("ERROR: UDirectory::RemoveDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
}

ErrorType UDirectory::DeleteAllFiles(void)
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::DeleteAllFiles(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_NOTEXIST) return U_OK;

//// Use: remove()
    char command[300];
    sprintf(command,"del /Q /S %s\\*.*",DirectoryName);
    if(system(command)==0) return U_OK;

    CI.AddToLog("ERROR UDirectory::DeleteAllFiles(). Deleting %s \n",DirectoryName);
    return U_ERROR;
}

ErrorType UDirectory::CreateDir(void)
/*
     Create the directory on disk, corresponding to DirectoryName[].
     return U_OK on succes, U_ERROR on any error. If the directory
     already exists, return U_OK right away.
 */
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::CreateDir(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(DirStatus==U_EXIST) return U_OK;

    if(_mkdir(DirectoryName)==0)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    UpdateStatus();
    if(_mkdir(DirectoryName)==0 || errno==EEXIST)
    {
        DirStatus = U_EXIST;
        return U_OK;
    }
    CI.AddToLog("ERROR UDirectory::CreateDir(). Creating %s \n",DirectoryName);
    switch(errno)
    {
    case EEXIST: CI.AddToLog("ERROR: UDirectory::CreateDir(). Directory or file already exists.\n"); break;
    case EACCES: CI.AddToLog("ERROR: UDirectory::CreateDir(). No access.\n");           break;
    case ENOENT: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path not found.\n");      break;
    case EINVAL: CI.AddToLog("ERROR: UDirectory::CreateDir(). Path invalid.\n");        break;
    }
    return U_ERROR;
}

UDirectory::DirStat UDirectory::UpdateStatus()
/*
     return the current status of the direcory DirectoryName[]
 */
{
    if(!DirectoryName || DirectoryName[0]==0) return U_NOSTAT;
    size_t NB = strlen(DirectoryName);
    for(unsigned int k=0; k<NB; k++) if(DirectoryName[k]=='*') return U_NOSTAT;

    FILE* fp = fopen(DirectoryName,"rb");
    if(fp)
    {
        fclose(fp);
        return U_NOTEXIST; // It is a file!
    }

    if(_mkdir(DirectoryName) == 0)
    {
        _rmdir(DirectoryName);
        return U_CANBECREATED;
    }

    DWORD ftyp = GetFileAttributesA(DirectoryName);
    if(ftyp == INVALID_FILE_ATTRIBUTES)
        return U_NOTEXIST;  //something is wrong with your path!

    if(ftyp & FILE_ATTRIBUTE_DIRECTORY)
        return U_EXIST;   // this is a directory!

    return U_NOTEXIST;    // this is not a directory!
}

int UDirectory::GetNFileDirs(GetWhat GW) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetNFileDirs(). Object NULL or not set.\n");
        return 0;
    }
#ifdef UNICODE
    CI.AddToLog("ERROR: UDirectory::GetNFileDirs(): Function not implemented for #define UNICODE \n");
    return 0;
#else
    size_t    NB      = strlen(DirectoryName)+strlen("*")+2;
    char*  Files      = new char[NB];
    if(Files==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetNFileDirs(): Memory allocation.\n");
        return 0;
    }
    memset(Files, 0, NB);
    strcpy(Files, DirectoryName);
    if(DirectoryName[0]) strcat(Files, SLASH);
    strcat(Files, "*");

/* Find first file in the directory  dir, return 0 when no files are found.*/
    WIN32_FIND_DATA c_file;
    HANDLE          hFile =  FindFirstFile(Files, &c_file );
    delete[] Files;
    if(hFile==INVALID_HANDLE_VALUE)
    {
        CI.AddToLog("WARNING: UDirectory::GetNFileDirs(): Cannot find first file of type %s\n", DirectoryName);
        return 0;
    }

    int       nfiles      = 0;
    if( (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
        (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )    nfiles++;

/* Find the rest of files */
    while(FindNextFile(hFile, &c_file)==TRUE)
    {
        if( (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
            (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )  nfiles++;
    }
    FindClose( hFile );
    
    return nfiles;
#endif // UNICODE
}

static UFileName* GlobNames;
static int FileNameOrder(const void *elem1, const void *elem2)
{
    const UFileName* F1 = (UFileName*)GlobNames+ (*(int*)elem1);
    const UFileName* F2 = (UFileName*)GlobNames+ (*(int*)elem2);

    return strcmp(F1->GetFullFileName(),F2->GetFullFileName());
}

UFileName* UDirectory::GetFileDirNames(const char* FileDescr, int* Nfiles, GetWhat GW, bool AddParentName) const
/*
    return a new pointer containing an array of UFileName objects which are present in the directory
    corresponding to this object. Filenames include this->DirectoryName.

    Filenames are ordered alphabetically

    *Nfiles will contain the number of files.
    The parameter GW determines whether files, sub-directories or both are returned

    return NULL on any error.
 */
{
    if(this==NULL || DirectoryName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetFileDirNames(). Object NULL or not set.\n");
        return NULL;
    }
#ifdef UNICODE
    CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Function not implemented for #define UNICODE \n");
    return NULL;
#else
    if(FileDescr==NULL || Nfiles==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): NULL argument \n");
        return NULL;
    }
    *Nfiles = 0;

    int   NFmax       = GetNFileDirs(GW);
    if(NFmax<=0) return NULL;

    size_t    NB      = strlen(DirectoryName)+strlen("*")+4;
    char*  Files      = new char[NB];
    if(Files==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetNFileDirs(): Memory allocation.\n");
        return 0;
    }
    memset(Files, 0, NB);
    strcpy(Files, DirectoryName);
    if(DirectoryName[0]) strcat(Files, SLASH);
    strcat(Files, "*");

/* Find first file in the directory  dir, return 0 when no files are found.*/
    WIN32_FIND_DATA c_file;
    HANDLE          hFile =  FindFirstFile(Files, &c_file );
    delete[] Files;

    if(hFile==INVALID_HANDLE_VALUE)
    {
        CI.AddToLog("WARNING: UDirectory::GetFileDirNames(): Cannot find first file of type %s\n", DirectoryName);
        return NULL;
    }

    UFileName* FileNames   = new UFileName[NFmax];
    if(FileNames==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Memory allocation %s\n", DirectoryName);
        FindClose( hFile );
        return NULL;
    }
    
    int nfiles      = 0;

/* Skip SUBDIRS, c.q. filenames*/
    if( (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
        (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )
    {
        UFileName F1 = AddParentName ? *this + UFileName(c_file.cFileName) : UFileName(c_file.cFileName);
        UFileName F2 = AddParentName ? *this + UFileName(FileDescr)        : UFileName(FileDescr);
        if(F1.IsFullFileNameCompatible(F2)) FileNames[nfiles++] = F1;
    }

/* Find the rest of files */
    while(FindNextFile(hFile, &c_file)==TRUE)
    {
        if( (GW==U_GET_FILES   && !(c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) ||
            (GW==U_GET_SUBDIRS &&  (c_file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) )
        {
            UFileName F1 = AddParentName ? *this + UFileName(c_file.cFileName) : UFileName(c_file.cFileName);
            UFileName F2 = AddParentName ? *this + UFileName(FileDescr)        : UFileName(FileDescr);
            if(F1.IsFullFileNameCompatible(F2)) FileNames[nfiles++] = F1;
        }
    }
    FindClose( hFile );

    if(nfiles<=0)
    {
        CI.AddToLog("WARNING: UDirectory::GetFileDirNames(): No files of specified type present %s\n", DirectoryName);
        *Nfiles = 0;
        delete[] FileNames;
        return NULL;
    }

/* Compute the file ordering index */
    int* index = new int[nfiles];
    if(index==NULL)
    {
        CI.AddToLog("ERROR: UDirectory::GetFileDirNames(): Memory allocation, nfiles = %d\n", nfiles);
        return FileNames;
    }
    for(int n=0; n<nfiles; n++) index[n] = n;

    GlobNames = FileNames;
    qsort(index, nfiles, sizeof(index[0]), FileNameOrder);

    *Nfiles = nfiles;
    UFileName* FGood = new UFileName[nfiles];
    if(FGood)
    {
        for(int k=0; k<nfiles; k++) FGood[k] = FileNames[index[k]];
        delete[] FileNames; delete[] index;
        return FGood;
    }
    delete[] index;
    return FileNames;
#endif // UNICODE
}
ErrorType UDirectory::CompletePath(void)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CompletePath(). Object NULL or not set.\n");
        return U_ERROR;
    }
    if(!DirectoryName || DirectoryName[0]==0) return U_ERROR;
    if(DirectoryName[0]!='.') return U_OK;

    CI.AddToLog("ERROR: UFileName::CompletePath(). Function not yet implemented for Windows.\n");
    return U_ERROR;
}
