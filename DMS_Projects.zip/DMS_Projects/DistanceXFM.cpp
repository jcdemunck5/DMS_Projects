/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     File containing special functions (methods) of UField, derived from the   */
/*     AvL/NKI AVS module library.                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    14-04-00   creation, of DistanceXFM() ,derived from Avs_dist.cpp, 
                    develloped by M. van Herk at NKI
  JdM    29-04-00   Bug fix for uniform fields: computation of step size did not work
  JdM    06-05-00   Bug fix in run_filter (conversion from implementation of Avs_dist.cpp)
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include"Field.h"

/************************************************************************/
/*                    DEFINES, ENUMERATED TYPES AND CONSTANTS           */
/************************************************************************/

#define LARGEINT 1000000000             /* almost 2^31 (seed for max) */
#define SMALL    0.00000001             /* zero tolerance             */
#define MAXS 2048                       /* maximum dimension          */

static void rmorfdist(int *array, int cnt, int step)
{ int val      = LARGEINT;
  int cnt_save = cnt;

  while (cnt--) if (*array < val) val =  *array++ + step;
       else              *array++ = val, val += step;

  val   = LARGEINT;
  array --;
  cnt   = cnt_save;

  while (cnt--) if (*array < val) val =  *array-- + step;
        else              *array-- = val, val += step;
}

/* short version of distance transform */

static void srmorfdist(short int *array, int cnt, int step)
{ int val      = 32767;
  int cnt_save = cnt;

  while (cnt--) if (*array < val) val =  *array++ + step;
        else              *array++ = val, val += step;

  val   = 32767;
  array --;
  cnt   = cnt_save;

  while (cnt--) if (*array < val) val =  *array-- + step;
        else              *array-- = val, val += step;
}

/* byte version of distance xfm */

static void crmorfdist(unsigned char *array, int cnt, int step)
{ int val = 255;
  int cnt_save = cnt;

  while (cnt--) if ((int)(*array) < val) val =  *array++ + step;
        else                     *array++ = val, val += step;

  val   = 255;
  array --;
  cnt   = cnt_save;

  while (cnt--) if ((int)(*array) < val) val =  *array-- + step;
        else                     *array-- = val, val += step;
}

/************************** in-place distance xfm ***************************/
/* in-place integer version of distance xfm along other axes */

static void iprmorfdist(int *array, int cnt, int step, int skip)
{ int val      = LARGEINT;
  int cnt_save = cnt;

  while (cnt--) if (*array < val) val =  *array + step,      array+=skip;
        else              *array = val, val += step, array+=skip;

  val   = LARGEINT;
  array -= skip;
  cnt   = cnt_save;

  while (cnt--) if (*array < val) val =  *array + step,      array-=skip;
        else              *array = val, val += step, array-=skip;
}

/* in-place short version of distance xfm */

static void ipsrmorfdist(short int *array, int cnt, int step, int skip)
{ int val = 32767;
  int cnt_save = cnt;

  while (cnt--) if ((int)(*array) < val) val =  *array + step,      array+=skip;
        else                     *array = val, val += step, array+=skip;

  val   = 32767;
  array -= skip;
  cnt   = cnt_save;

  while (cnt--) if ((int)(*array) < val) val =  *array + step,      array-=skip;
        else                     *array = val, val += step, array-=skip;
}

/* in-place byte version of distance xfm */

static void ipcrmorfdist(unsigned char *array, int cnt, int step, int skip)
{ int val = 255;
  int cnt_save = cnt;

  while (cnt--) if ((int)(*array) < val) val =  *array + step,      array+=skip;
        else                     *array = val, val += step, array+=skip;

  val   = 255;
  array -= skip;
  cnt   = cnt_save;

  while (cnt--) if ((int)(*array) < val) val =  *array + step,      array-=skip;
        else                     *array = val, val += step, array-=skip;
}

/************************ irregular distance xfm ***************************/
/* irregular in-place integer version of distance xfm along other axes
   NOTE: 1) the arrays steps[n] contains distances from n to n+1
     2) the element steps[-1] should be a valid element (contents undefined)
*/

static void iprrmorfdist(int *array, int cnt, int *steps, int skip)
{ int val      = LARGEINT;
  int cnt_save = cnt;

  while (cnt--) if (*array < val) val =  *array + *steps++,      array+=skip;
        else              *array = val, val += *steps++, array+=skip;

  val    = LARGEINT;
  array -= skip;
  steps -= 2;
  cnt    = cnt_save;

  while (cnt--) if (*array < val) val =  *array + *steps--,      array-=skip;
        else              *array = val, val += *steps--, array-=skip;
}

/* irregular in-place short version of distance xfm */

static void ipsrrmorfdist(short int *array, int cnt, int *steps, int skip)
{ int val = 32767;
  int cnt_save = cnt;

  while (cnt--) if ((int)(*array) < val) val =  *array + *steps++,      array+=skip;
        else                     *array = val, val += *steps++, array+=skip;

  val    = 32767;
  array -= skip;
  steps -= 2;
  cnt    = cnt_save;

  while (cnt--) if ((int)(*array) < val) val =  *array + *steps--,      array-=skip;
        else                     *array = val, val += *steps--, array-=skip;
}

/* irregular in-place byte version of distance xfm */

static void ipcrrmorfdist(unsigned char *array, int cnt, int *steps, int skip)
{ int val = 255;
  int cnt_save = cnt;

  while (cnt--) if ((int)(*array) < val) val =  *array + *steps++,      array+=skip;
        else                     *array = val, val += *steps++, array+=skip;

  val    = 255;
  array -= skip;
  steps -= 2;
  cnt    = cnt_save;

  while (cnt--) if ((int)(*array) < val) val =  *array + *steps--,      array-=skip;
        else                     *array = val, val += *steps--, array-=skip;
}

/* Basic filter routine for smooth, min, max and distance xfm */

static int run_filter(UField *field, int *kernels, int *dim1steps)
{ 
    int i, j, dim, kernel;
    int *q, cdim=field->GetDimensions(0);

    unsigned char *bq;
    short         *sq;

    int step, rest;

    for (dim=0; dim < field->Getndim(); dim++)
    { 
        if (field->GetDimensions(dim) > MAXS)
        { 
            CI.AddToLog("ERROR: run_filter(): avs_dist: dimension %d is larger than %d pixels (%d)\n",dim, MAXS, field->GetDimensions(dim));
            return 0;
        }
    }

/* calculate amount of pixels to be processed */

    step = 1; rest = 1;
    for(dim=1; dim < field->Getndim(); dim++)
        rest *= field->GetDimensions(dim);

/* process first dimension separately */

    if(field->GetDType() == UField::U_INTEGER)
    { 
        q = field->GetIdata();

        for(i = 0; i < rest; i++)
            rmorfdist(q + i*cdim, cdim, *kernels);
    }
    else if (field->GetDType() == UField::U_SHORT)
    { 
        sq = (short *)(field->GetSdata());

        for(i = 0; i < rest; i++)
            srmorfdist(sq + i*cdim, cdim, *kernels);
    }
    else
    { 
        bq = (unsigned char *)(field->GetBdata());

        for(i = 0; i < rest; i++)
            crmorfdist(bq + i*cdim, cdim, *kernels);
    }

/* process the other dimensions */

    for(dim = 1; dim < field->Getndim(); dim++)
    { 
        cdim   = field->GetDimensions(dim);
        step  *= field->GetDimensions(dim-1);
        rest  /= cdim;
        kernel = kernels[dim];

/* run over pages and columns */
        for(i = 0; i < rest; i++)                  /* # pages */
        { 
            for(j = 0; j < step; j++)                /* # columns */
            {
                if(dim==1 && dim1steps)                /* irregular slice spacing */
                {
                    if(field->GetDType() == UField::U_BYTE)
                    { 
                        bq = (unsigned char *)(field->GetBdata()) + i*step*cdim + j;

                        ipcrrmorfdist(bq, cdim, dim1steps+1, step);
                    }
                    else if(field->GetDType() == UField::U_SHORT)
                    { 
                        sq = (short *)(field->GetSdata()) + i*step*cdim + j;

                        ipsrrmorfdist(sq, cdim, dim1steps+1, step);
                    }
                    else
                    { 
                        q = field->GetIdata() + i*step*cdim + j;

                        iprrmorfdist(q, cdim, dim1steps+1, step);
                    }
                }
                else
                { 
                    if(field->GetDType() == UField::U_BYTE)
                    { 
                        bq = (unsigned char *)(field->GetBdata()) + i*step*cdim + j;

                        ipcrmorfdist(bq, cdim, kernel, step);
                    }
                    else if(field->GetDType() == UField::U_SHORT)
                    { 
                        sq = (short *)(field->GetSdata()) + i*step*cdim + j;

                        ipsrmorfdist(sq, cdim, kernel, step);
                    }
                    else
                    { 
                        q = field->GetIdata() + i*step*cdim + j;

                        iprmorfdist(q, cdim, kernel, step);
                    }
                }
            }
        }
    }
    return 1;                                     /* return OK */
}


ErrorType UField::DistanceXFM(bool scale_extents, bool ir_slices, int kernel, int clip)
{ 
    int    dim, pixels, i, *in, *out, kernels[3];
    float  *rcoords = points;
    float  steps[3], minstep=(float)LARGEINT;
    unsigned char *inb, *outb;
    short *ins, *outs;

    float *slicesteps=NULL;
    int *islicesteps=NULL;

    /* check input data */

    if(FType==U_IRREGULAR)
    { 
        CI.AddToLog("ERROR: UField::DistanceXFM(): irregular fields are not allowed as input\n");
        return U_ERROR;
    }

    if(FType==U_RECTILINEAR && scale_extents==false)
        CI.AddToLog("WARNING: UField::DistanceXFM(): rectilinear fields without scaling to extents\n");

    if(ndim<1 || ndim>3)
    { 
        CI.AddToLog("ERROR: UField::DistanceXFM(): data not between 1 and 3-dimensional. ndim=%d\n",ndim);
        return U_ERROR;
    }
    
    if(ndim < 2 && ir_slices==true)
    { 
        CI.AddToLog("ERROR: UField::DistanceXFM(): one-dimensional data does not have slices.\n");
        return U_ERROR;
    }
    
    if (DType != U_BYTE    &&
        DType != U_INTEGER &&
        DType != U_SHORT  )
    { 
        CI.AddToLog("ERROR: UField::DistanceXFM(): only byte, short or integer data allowed as input.\n");
        return U_ERROR;
    }
    
/* calculate amount of pixels to be processed */

    pixels = GetNpoints();

/* for scaled data, adapt the kernel size according to average
   stepsize for each dimension. For the distance transform, the
   step values are enlarged relative to the smallest step.
*/

    if(scale_extents==true)
    { 
        if(FType == U_RECTILINEAR) /* average the step size of each dimension */
        { 
            for(dim=0; dim < ndim; dim++)
            { 
                steps[dim] = (float)0.0;

                for (i=0; i<dimensions[dim]-1; i++)
                    steps[dim] += fabs(rcoords[1] - rcoords[0]), rcoords++;

                steps[dim] /= dimensions[dim]-1;
                rcoords++;
            }

            if(ir_slices)
            { 
                slicesteps  = new float[dimensions[1]];
                islicesteps = new int[dimensions[1]+1];

                rcoords = points + dimensions[0];

                for(i=0; i<dimensions[1]-1; i++)
                    slicesteps[i] = fabs(rcoords[1] - rcoords[0]), rcoords++;

                slicesteps[dimensions[1]-1] = steps[1];
            }
        }
        else /* for uniform data, find step size from extents of the dimensions */
        { 
            for(dim=0; dim < ndim; dim++)
                steps[dim] = float(fabs(GetPixelSize(dim)));

            ir_slices = false;
        }

/* find minimal step size */

        for(dim=0; dim < ndim; dim++)
            if(steps[dim] < minstep && steps[dim] > SMALL)
        minstep = steps[dim];

/* enlarge relative to minimal step size for distance transform */

        for(dim=0; dim < ndim; dim++)
            kernels[dim] = (int)((float)kernel * steps[dim] / minstep + 0.5);

        if(ir_slices)
        { 
            for(i=0; i<dimensions[1]; i++)
                islicesteps[i+1] = (int)((float)kernel * slicesteps[i] / minstep + 0.5);

            islicesteps[0] = 0;
        }
    }
    else
    { 
        for(dim=0; dim < ndim; dim++) kernels[dim] = kernel;          
    }

/* create the output port from input port (unless out==in) */


/* copy and translate true/false into zero/high (performs clipping as well) */

    if(DType == U_INTEGER)
    { 
        if(clip<=0) clip = 1000000;

        in    =   Idata;
        out   =   Idata;

        for(i=0; i<pixels; i++) out[i] = in[i] ? 0 : clip;
    }
    else if(DType == U_SHORT)
    { 
        if (clip <=0) clip = 32767;

        ins   =   Sdata;
        outs  =   Sdata;

        for (i=0; i<pixels; i++) outs[i] = ins[i] ? 0 : clip;
    }
    else
    { 
        if (clip <= 0 || clip > 255) clip = 255;

        inb   = Bdata;
        outb  = Bdata;

        for(i=0; i<pixels; i++) outb[i] = inb[i] ? 0 : clip;
    }

/* perform the filter operations */

    run_filter(this, kernels, islicesteps);

    delete[] slicesteps;
    delete[] islicesteps;
    return U_OK;                             /* return OK */
}
