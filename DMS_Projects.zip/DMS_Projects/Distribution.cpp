/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for creating and updating distributions of (univariate) values.    */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    10-02-00   creation
  Jdm    11-02-00   Several bug fixes
  JdM    15-02-00   Added GetStandardDev()
  JdM    19-02-00   Bug fix in the determination of the appr. bin. (shift one to right)
  JdM    24-02-00   Added Smooth()
  JdM    27-02-00   Bug fixes in Smooth()
  JdM    04-04-00   Added ReDistribute()
  JdM    11-04-00   Some bug-fixes in ReDistribute(), Write Smooth in terms of new Redistribute()
  JdM    12-04-00   Added GetRightMax(void) and new constructor.
  JdM    13-04-00   Bug fix in ReDistribute() (for the case that the new bins are smaller than the original).
  JdM    14-06-00   Bug fix in ReDistribute() (computation of variable Fb2).
  JdM    16-06-00   Added GetBinNumber()
  JdM    17-06-00   Bug fix in UDistribution()-constructor. MinRan was ignored when setting Bins[]. Bins[0] was always set to 0.
                    Added EqualizeBins() and ClearCounts()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    02-08-00   BUg Fix in UDistribution(int , int*). Computation of MinValue and MaxValue.
  JdM    31-12-00   Added SetMinMaxRange();
  JdM    16-02-01   Add parameter to GetRightMax()
  JdM    22-03-01   Bug Fix GetMedian(), start counting from 0.
  JdM    23-03-01   Added GetLower() and operator=()
                    Increased efficiency of creating UDistribution from UField() data
  JdM    29-03-01   Creating UDistribution() from UField(): Skip negative pixel values for type short and int
  JdM    11-04-01   Add parameter to GetDistributionText()
  JdM    13-04-01   Added default constructor
  JdM    13-10-01   GetDistributionText(): Return new private pointer DistributionText
  JdM    22-10-01   GetProperties(). Add minimum and maximum value
  JdM    17-12-01   Add SetTitle()
  JdM    16-04-02   Add RemoveEmptyBins()
  JdM    04-07-02   GetDistributionText(). Add array overflow test.
  JdM    11-09-02   ReDistribute(). Less restrictive argument testing (WARNING instead of ERROR)
  JdM    13-10-02   Bug fix ReDistribute(). Testing max range
  JdM    01-11-02   Add copy constructor
  JdM    17-09-03   Extended UField-based constructopr to types float and double
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-01-06   Added component parameter to the UField* based constructor.
  JdM    08-03-06   Bug fix: GetRightMax(). Test Nbin>1 to avoid out of range index.
  JdM    09-09-07   Major update. Use UString and DeleteAllMembers() and SetAllMembersDefault()
                    Added GetDistributionAsFieldGraph()
  JdM    10-09-07   Added WriteAsText()
  JdM    26-09-07   Bug fix int one of constructors (due to 09-09-07??): initialize k in several loops.
  JdM    22-08-08   Bug Fix GetDistributionAsFieldGraph(). Text whether Bins==NULL
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    30-05-09   Added GetUpperQuantile() GetFraction()
  JdM    04-08-09   Systematically check if this==NULL or whether object is empty.
  JdM    10-02-10   Added GetOtsuThreshold()
  JdM    11-02-10   UField() constructor: reduced Nbin for U_SHORT and U_INTEGER
  JdM    25-02-10   Bug Fix: UField() constructor: test range in case of U_SHORT
  JdM    09-09-13   RemoveEmptyBins(). Initialize Bins[Nbin+1]
  JdM    29-09-13   Avoid memory leak in case of UField constructor (occured for U_FLOAT and DOUBLE)
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    14-12-14   UField constructor, case U_SHORT and U_INTEGER: adapt Nbin to data range
                    Added two out-of-range count parameters to int* constructor
 FB/JdM  22-04-15   WriteAsText(): Added default parameter
  JdM    15-05-15   Added GetFractionFromBin() and GetValueFromBin()
  JdM    09-04-16   WriteAsText(): Added two default parameters
  JdM    26-11-16   Added GetCountsFromBin() and GetCenterBin()
  JdM    16-07-18   Added GetFirstMinimum()
 */

#include <string.h>
#include <math.h>

#include "Distribution.h"
#include "FileName.h"
#include "String.h"
#include "Field.h"
#include "FieldGraph.h"

/* Inititalize static const parameters. */
UString UDistribution::Properties = UString();

void UDistribution::SetAllMembersDefault(void)
{
    error       = U_OK;
    MinRange    = 0;
    MaxRange    = 0;
    MinValue    = 0;
    MaxValue    = 0;
    Ntotal      = 0;
    NinRange    = 0;
    Nbin        = 0;
    SumInRange  = 0.;
    Sum2InRange = 0.;

    Bins        = NULL;
    Count       = NULL;
    Properties  = UString();
    Title       = UString("No Name");
}
void UDistribution::DeleteAllMembers(ErrorType E)
{
    delete[] Bins;
    delete[] Count;
    SetAllMembersDefault();
    error = E;
}

UDistribution::UDistribution()
{
    SetAllMembersDefault();
}

UDistribution::UDistribution(int Nb, double MinRan, double MaxRan)
{
    SetAllMembersDefault();

    Bins             = new double[Nb+2];
    Count            = new int[Nb+2];
    if(Bins==NULL || Count==NULL || MinRan==MaxRan)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDistribution::UDistribution(). Memory allocation. \n");
        return;
    }

    for(int k=0; k<Nb+2; k++) Count[k] = 0;
    for(int k=0; k<Nb+2; k++) Bins[k]  = MinRan + k*(MaxRan-MinRan)/Nb;

    MinRange = MinRan;
    MaxRange = MaxRan;
    Nbin     = Nb;
}

UDistribution::UDistribution(int Nb, int* Histo, int Nlow, int Nhigh)
{
    SetAllMembersDefault();
    
    if(Nb<=0 || Histo==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDistribution::UDistribution(). Invalid arguments. \n");
        return;
    }

    Bins             = new double[Nb+2];
    Count            = new int[Nb+2];
    if(Bins==NULL || Count==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDistribution::UDistribution(). Memory allocation (Nb=%d). \n", Nb);
        return;
    }
    Count[0]    = MAX(0, Nlow);
    Count[Nb+1] = MAX(0, Nhigh);
    for(int k=1; k<Nb+1; k++) Count[k] = Histo[k-1];
    for(int k=0; k<Nb+2; k++) Bins[k]  = k;

    NinRange = 0;
    MinRange = 0;
    MaxRange = Nb;
    Nbin     = Nb;

    for(int k=1; k<=Nbin; k++)
    {
        NinRange    += Count[k];
        double Val   = (Bins[k-1] + Bins[k])/2.;
        SumInRange  += Count[k]*Val;
        Sum2InRange += Count[k]*Val*Val;
    }
    Ntotal   = NinRange + Count[0] + Count[Nb+1];

    MinValue =    .5; for(int k=1;    k<=Nbin; k++) if(Count[k]) {MinValue = (Bins[k-1] + Bins[k])/2.; break;}
    MaxValue = Nb-.5; for(int k=Nbin; k>=1;    k--) if(Count[k]) {MaxValue = (Bins[k-1] + Bins[k])/2.; break;}

    error    = U_OK;
}

UDistribution::UDistribution(const UField& fld, int Nsubsample, int icomp)
/*
    Create a histogram of the gray values present in the data array of fld.
 */
{
    SetAllMembersDefault();
    if(&fld==NULL || fld.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDistribution::UDistribution(). Invalid arguments. \n");
        return;
    }
    if(icomp>=fld.GetVeclen())
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDistribution::UDistribution(), Ivalid component parameter: icomp = %d, fld.veclen = %d .\n",icomp, fld.GetVeclen());
        return;
    }

    Nbin     = 256;
    if(fld.GetDType()==UField::U_SHORT  ) Nbin = 2000;
    if(fld.GetDType()==UField::U_INTEGER) Nbin = 5000;

    if(fld.GetDType()==UField::U_SHORT || fld.GetDType()==UField::U_INTEGER)
    {
        int Imin=0;
        int Imax=0;
        fld.GetMinMaxData(&Imin, &Imax);
        int Range = Imax-Imin;
        if( Range > int(1.5 *Nbin)) Nbin = int(Range/1.5);
    }

    int Nvox = fld.GetNpoints();
    if(icomp<0)
    {
        if(Nsubsample<=0)
        {
            Nsubsample = 1+fld.GetNpoints()/10000;
            if(fld.GetVeclen()>1)
            {
                Nsubsample = 1 + Nsubsample / fld.GetVeclen();
                if(Nsubsample%fld.GetVeclen()==0) Nsubsample++;
            }
        }
        else
        {
            Nsubsample *= fld.GetVeclen();
        }
        Nvox  = fld.GetVeclen()*fld.GetNpoints();
        icomp = 0;
    }
    else
    {
        if(Nsubsample<=0) Nsubsample  = 1+fld.GetNpoints()/10000;
        Nsubsample *= fld.GetVeclen();
    }
    switch(fld.GetDType())
    {
    case UField::U_BYTE:
        {
            unsigned char* data = fld.GetBdata();
            int*          Histo = new int[Nbin];
            if(data && Histo)
            {
                for(int k=0; k<Nbin; k++) Histo[k] = 0;
                for(int k=icomp; k<Nvox; k+=Nsubsample) Histo[data[k]]++;
                *this = UDistribution(Nbin, Histo);
                delete[] Histo;
            }
            else
            {
                delete[] Histo;
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UDistribution::UDistribution(). UField has NULL data pointer or memory allocation error.\n");
                return;
            }
        }
        break;

    case UField::U_SHORT:
        {
            short* data  = fld.GetSdata();
            int*   Histo = new int[Nbin];
            if(data && Histo)
            {
                int Nlow = 0;
                int Nhig = 0;
                for(int k=0; k<Nbin; k++) Histo[k] = 0;
                for(int k=icomp; k<Nvox; k+=Nsubsample)
                {
                    int dat = data[k];
                    if(dat< 0   ) {Nlow++; continue; }
                    if(dat>=Nbin) {Nhig++; continue; }
                    Histo[dat]++;
                }
                *this = UDistribution(Nbin, Histo, Nlow, Nhig);
                delete[] Histo;
            }
            else
            {
                delete[] Histo;
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UDistribution::UDistribution(). UField has NULL data pointer or memory allocation error.\n");
                return;
            }
        }
        break;

    case UField::U_INTEGER:
        {
            int* data  = fld.GetIdata();
            int* Histo = new int[Nbin];
            if(data && Histo)
            {
                int Nlow = 0;
                int Nhig = 0;
                for(int k=0; k<Nbin; k++) Histo[k] = 0;
                for(int k=icomp; k<Nvox; k+=Nsubsample)
                {
                    int dat = data[k];
                    if(dat< 0   ) {Nlow++; continue; }
                    if(dat>=Nbin) {Nhig++; continue; }
                    Histo[dat]++;
                }
                *this = UDistribution(Nbin, Histo, Nlow, Nhig);
                delete[] Histo;
            }
            else
            {
                delete[] Histo;
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UDistribution::UDistribution(). UField has NULL data pointer or memory allocation error.\n");
                return;
            }
        }
        break;

    case UField::U_FLOAT:
        {
            float* data = fld.GetFdata();
            if(data)
            {
                double Dmin = 0.;
                double Dmax = 0.;
                fld.GetMinMaxData(&Dmin, &Dmax, icomp);
                if(Dmin==Dmax)
                {
                    CI.AddToLog("ERROR: UDistribution::UDistribution(). UField Mindata == Maxdata = %f .\n", Dmin);
                    *this = UDistribution();
                    return;
                }
                UDistribution Dis(Nbin, Dmin, Dmax);
                for(int k=icomp; k<Nvox; k+=Nsubsample)
                    Dis.AddValue(data[k]);
                *this = Dis;
            }
            else
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UDistribution::UDistribution(). UField has NULL data pointer: %s.\n",(const char*)fld.GetProperties(""));
                return;
            }
        }
        break;

    case UField::U_DOUBLE:
        {
            double* data = fld.GetDdata();
            if(data)
            {
                double Dmin = 0.;
                double Dmax = 0.;
                fld.GetMinMaxData(&Dmin, &Dmax, icomp);
                if(Dmin==Dmax)
                {
                    CI.AddToLog("ERROR: UDistribution::UDistribution(). UField Mindata == Maxdata = %f .\n", Dmin);
                    *this = UDistribution();
                    return;
                }
                UDistribution Dis(Nbin, Dmin, Dmax);
                for(int k=icomp; k<Nvox; k+=Nsubsample)
                    Dis.AddValue(data[k]);
                *this = Dis;
            }
            else
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UDistribution::UDistribution(). UField has NULL data pointer: %s.\n",(const char*)fld.GetProperties(""));
                return;
            }
        }
        break;

    default:
        CI.AddToLog("ERROR: UDistribution::UDistribution(). Invalid data type, %s.",(const char*)fld.GetProperties(""));
        DeleteAllMembers(U_ERROR);
        return;
    }
}

UDistribution::UDistribution(const UDistribution& d)
{
    SetAllMembersDefault();
    *this = d;
}

UDistribution::~UDistribution()
{
    DeleteAllMembers(U_OK);
}

UDistribution& UDistribution::operator=(const UDistribution& Dis)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::operator=(). this==NULL  . \n");
        static UDistribution Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&Dis==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Dis) return *this;

    DeleteAllMembers(U_OK);
    error       = Dis.error;
    MinRange    = Dis.MinRange;
    MaxRange    = Dis.MaxRange;
    MinValue    = Dis.MinValue;
    MaxValue    = Dis.MaxValue;
    Ntotal      = Dis.Ntotal;
    NinRange    = Dis.NinRange;
    Nbin        = Dis.Nbin;
    SumInRange  = Dis.SumInRange;
    Sum2InRange = Dis.Sum2InRange;
    Title       = Dis.Title;

    if(Dis.Bins)
    {
        Bins = new double[Dis.Nbin+2];
        if(Bins==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UDistribution::operator=(). Memory allocation Bins (Dis.Nbin=%d). \n", Dis.Nbin);
            return *this;
        }
        else
            for(int k=0; k<Dis.Nbin+2; k++) Bins[k] = Dis.Bins[k];
    }

    if(Dis.Count)
    {
        Count = new int[Dis.Nbin+2];
        if(Count==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UDistribution::operator=(). Memory allocation Count (Dis.Nbin=%d). \n", Dis.Nbin);
            return *this;
        }
        else
            for(int k=0; k<Dis.Nbin+2; k++) Count[k] = Dis.Count[k];
    }
    return *this;
}

ErrorType UDistribution::SetTitle(UString NewTitle)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Title = NewTitle;
    return U_OK;
}

ErrorType UDistribution::SetMinMaxRange(double NewMin, double NewMax)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(NewMin>=NewMax)
    {
        CI.AddToLog("ERROR: UDistribution::SetMinMaxRange(). Arguments out of range(): %f, %f\n",NewMin, NewMax);
        return U_ERROR;
    }
    if(Bins==NULL || Nbin<=0)
    {
        CI.AddToLog("ERROR: UDistribution::SetMinMaxRange(). Bins not set, Nbin = %d  .\n",Nbin);
        return U_ERROR;
    }
    ClearCounts();

    for(int k=0; k<Nbin+2; k++) Bins[k]  = NewMin + k*(NewMax-NewMin)/Nbin;

    MinRange = NewMin;
    MaxRange = NewMax;

    return U_OK;
}

int UDistribution::GetCountsFromBin(int ibin) const
{
    if(this==NULL || error!=U_OK) return 0;
    if(Count==NULL)               return 0;

    if(ibin<0 || ibin>Nbin) 
    {
        CI.AddToLog("ERROR: UDistribution::GetCountsFromBin(). Argument out of range (ibin=%d)\n", ibin);
        return 0;
    }
    return Count[ibin];
}

double UDistribution::GetCenterBin(int ibin) const
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Bins==NULL)                return 0.;

    if(ibin<1 || ibin>Nbin) 
    {
        CI.AddToLog("ERROR: UDistribution::GetCenterBin(). Argument out of range (ibin=%d)\n", ibin);
        return 0.;
    }
    return .5*(Bins[ibin-1]+Bins[ibin]);
}

double UDistribution::GetValueFromBin(int ibin) const
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Bins==NULL)                return 0.;

    if(ibin<0 || ibin>Nbin) 
    {
        CI.AddToLog("ERROR: UDistribution::GetValueFromBin(). Argument out of range (ibin=%d)\n", ibin);
        return 0.;
    }
    if(ibin==0) return MinValue;
    return Bins[ibin];
}
ErrorType UDistribution::AddValue(double Val)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Ntotal++;
    if(Ntotal==1) MinValue = MaxValue = Val;
    else
    {
        if(Val<MinValue) MinValue = Val;
        if(Val>MaxValue) MaxValue = Val;
    }

/* Test for out of range:*/
    if(Val<MinRange)
    {
        Count[0]++;
        return U_OK;
    }
    if(Val>MaxRange)
    {
        Count[Nbin+1]++;
        return U_OK;
    }

    int ibin = GetBinNumber(Val);

/* Update statistics*/
    Count[ibin]++;
    NinRange++;
    SumInRange  += Val;
    Sum2InRange += Val*Val;

    return U_OK;
}

const UString& UDistribution::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UDistribution-object\n");
        return Properties;
    }
    if(Bins==NULL || Count==NULL || Ntotal<=0)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionText(). Object not properly set. \n");
        Properties = UString(" Empty UDistribution-object\n");
    }

    int    Bmax     = Count[1];
    int    iBmx     = 1;
    for(int ibin=1;ibin<=Nbin; ibin++)
    {
        if(Count[ibin]>=Bmax)
        {
            iBmx = ibin;
            Bmax = Count[ibin];
        }
    }
    double BinMax  = (Bins[iBmx]+Bins[iBmx-1])/2.;
    double Average = GetAverage();
    double StdDev  = GetStandardDev();
    double Median  = GetMedian();

    Properties  =  UString();
    Properties +=  UString("Title          = ") + Title + UString(" \n");
    Properties +=  UString(MinRange, "RangeMin       = %f  \n");
    Properties +=  UString(MaxRange, "RangeMax       = %f  \n");
    Properties +=  UString(Ntotal  , "Ntotal         = %d  \n");
    Properties +=  UString(NinRange, "NInRange       = %d  \n");
    Properties +=  UString(BinMax  , "BinMax         = %7.1f  \n");
    Properties +=  UString(Bmax    , "NinBinMax      = %d     \n");
    Properties +=  UString(Average , "Average        = %f   // (of in range values)\n");
    Properties +=  UString(StdDev  , "StdDev         = %f   // (of in range values)\n");
    Properties +=  UString(Median  , "Median         = %f  \n");
    Properties +=  UString(MinValue, "MinValue       = %f  \n");
    Properties +=  UString(MaxValue, "MaxValue       = %f  \n");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

UString UDistribution::GetDistributionText(UString Comment, bool CenterBin, bool Normalize, bool Cumulative) const
/*
     Return a UString containting the distribution in text format.
     Each bin is separated with '\n'. On error, return NULL.

     if(Comment) each line starts with Comment[]

     if(CenterBin==true) compute the center of each bin
     else                give the exact range of each bin
     if(Normalize==true) compute fractions (probabilities)
     else                give absolute numbers
     if(Cumulative=true) compute cumulative distributions
     else                give distribution itself
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionText(). Object NULL or erroneous. \n");
        return UString("UDistribution. ERROR. \n");
    }
    if(Bins==NULL || Count==NULL || Ntotal<=0)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionText(). Object not properly set. \n");
        Properties = UString(" Empty UDistribution-object\n");
    }
    UString DistributionText;

    if(Cumulative==true)
    {
        if(Normalize==true)
        {
            DistributionText += UString("Cumulative, normalized distribution  \n");
            double Norm       = Ntotal; if(Norm<=0.) Norm =1;
            double totCount   = Count[0]/Norm;

            DistributionText += UString(Bins[0]," <%f ") + UString(totCount, "\t%10.8f\n");
            for(int k=1; k<Nbin+1; k++)
            {
                totCount += Count[k]/Norm;
                if(CenterBin==true)
                    DistributionText += UString(.5*(Bins[k-1]+Bins[k])," %f ") + UString(totCount, "\t%10.8f\n");
                else
                    DistributionText += UString(Bins[k-1]," %f ") + UString(Bins[k],"- %f ") + UString(totCount, "\t%10.8f\n");
            }
            totCount += Count[Nbin+1]/Norm;
            DistributionText += UString(Bins[Nbin]," >%f ") + UString(totCount, "\t%10.8f\n");;
        }
        else
        {
            DistributionText += UString("Cumulative, non-normalized distribution  \n");
            int totCount = Count[0];

            DistributionText += UString(Bins[0]," <%f ") + UString(totCount, "\t%d\n");
            for(int k=1; k<Nbin+1; k++)
            {
                totCount += Count[k];
                if(CenterBin==true)
                    DistributionText += UString(.5*(Bins[k-1]+Bins[k])," %f ") + UString(totCount, "\t%d\n");
                else
                    DistributionText += UString(Bins[k-1]," %f ") + UString(Bins[k],"- %f ") + UString(totCount, "\t%d\n");
            }
            totCount += Count[Nbin+1];
            DistributionText += UString(Bins[Nbin]," >%f ") + UString(totCount, "\t%d\n");
        }
    }
    else
    {
        if(Normalize==true)
        {
            DistributionText += UString("Normalized distribution \n");
            double Norm       = Ntotal; if(Norm<=0.) Norm =1;

            DistributionText += UString(Bins[0]," <%f ") + UString(Count[0]/Norm, "\t%10.8f\n");
            for(int k=1; k<Nbin+1; k++)
            {
                if(CenterBin==true)
                    DistributionText += UString(.5*(Bins[k-1]+Bins[k])," %f ") + UString(Count[k]/Norm, "\t%10.8f\n");
                else
                    DistributionText += UString(Bins[k-1]," %f ") + UString(Bins[k],"- %f ") + UString(Count[k]/Norm, "\t%10.8f\n");
            }
            DistributionText += UString(Bins[Nbin]," >%f ") + UString(Count[Nbin+1]/Norm, "\t%10.8f\n");;
        }
        else
        {
            DistributionText += UString("Non-normalized distribution  \n");
            DistributionText += UString(Bins[0]," <%f ") + UString(Count[0], "\t%d\n");
            for(int k=1; k<Nbin+1; k++)
            {
                if(CenterBin==true)
                    DistributionText += UString(.5*(Bins[k-1]+Bins[k])," %f ") + UString(Count[k], "\t%d\n");
                else
                    DistributionText += UString(Bins[k-1]," %f ") + UString(Bins[k],"- %f ") + UString(Count[k], "\t%d\n");
            }
            DistributionText += UString(Bins[Nbin]," >%f ") + UString(Count[Nbin+1], "\t%d\n");
        }
    }
    DistributionText.InsertAtEachLine(Comment);

    return DistributionText;
}

UFieldGraph* UDistribution::GetDistributionAsFieldGraph(bool Normalize, bool Cumulative) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionAsFieldGraph(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Nbin<0 || Bins==NULL || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionAsFieldGraph(). Invalid Nbin (=%d). \n", Nbin);
        return NULL;
    }

    int      Npoints = Nbin+3;
    float*   points  = new float[Npoints];
    if(points==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetDistributionAsFieldGraph(). Memory allocation, Npoints = %d. \n", Npoints);
        return NULL;
    }
    double Width = 1.; if(Nbin>0) Width = (Bins[Nbin]-Bins[0])/Nbin;

    points[0]      =                          float( Bins[0   ] - 3*Width );   /// Extra
    for(int k=0; k<Nbin+1; k++) points[k+1] = float( Bins[k   ]           );
    points[Nbin+2] =                          float( Bins[Nbin] + 3*Width );

    UFieldGraph* FG = new UFieldGraph(points, Npoints, UField::U_DOUBLE, 1);
    delete[] points;
    if(FG==NULL || FG->GetError()!=U_OK || FG->GetDdata()==NULL)
    {
        delete FG;
        CI.AddToLog("ERROR: UDistribution::GetDistributionAsFieldGraph(). Creating UFieldgraph. \n");
        return NULL;
    }

    double* Data = FG->GetDdata();
    Data[0] = 0;
    if(Cumulative==true)
    {
        Data[1] = Count[0];
        for(int k=1; k<Nbin+2; k++)     Data[k+1] = Data[k] + Count[k];
    }
    else
    {
        for(int k=0; k<Nbin+2; k++)     Data[k+1] = Count[k];
    }
    if(Normalize && Ntotal>0)
        for(int k=1; k<Nbin+2; k++) Data[k]  /= Ntotal;

    FG->SetLabel(Title);
    FG->AddFileComments((const char*)GetProperties(" "));
    return FG;
}

double UDistribution::GetAverage(void) const
/*
    Return the average of all values investigated, that are in range.
 */
{
    if(this==NULL || error!=U_OK) return 0.;
    if(NinRange) return SumInRange/NinRange;
    return 0.;
}

double UDistribution::GetStandardDev(void) const
/*
    Return the standard deviation of all values investigated, that are in range.
 */
{
    if(this==NULL || error!=U_OK) return 0.;
    if(NinRange)
    {
        double Aver = SumInRange/NinRange;
        return sqrt(fabs( Sum2InRange/NinRange - Aver*Aver) );
    }
    return 0.;
}
double UDistribution::GetOtsuThreshold(void) const
{
    if(this==NULL || error!=U_OK) return 0;
    if(Bins==NULL || Count==NULL || Ntotal<=0)
    {
        CI.AddToLog("ERROR: UDistribution::GetOtsuThreshold(). Object not properly set. \n");
        return 0.;
    }
    if(NinRange<=0 || Bins[Nbin]-Bins[0]==0)
    {
        CI.AddToLog("ERROR: UDistribution::GetOtsuThreshold(). Bins not filled. \n");
        return 0.;
    }

    double Aver   = GetAverage() * (Bins[Nbin]-Bins[0]);
    double MaxDif = 0.;
    double Thresh = 0.;
    for(int ib=1; ib<=Nbin; ib++)
    {
        double Low  = 0;
        double LowB = 0;
        double Hig  = 0;
        double HigB = 0;
        for(int ibb= 1; ibb<ib+1; ibb++)
        {
            Low  +=                             Count[ibb];
            LowB += 0.5*(Bins[ibb-1]+Bins[ibb])*Count[ibb];
        }
        for(int ibb=ib+1; ibb<Nbin+1; ibb++)
        {
            Hig  +=                             Count[ibb];
            HigB += 0.5*(Bins[ibb-1]+Bins[ibb])*Count[ibb];
        }
        Low  /= NinRange;
        Hig  /= NinRange;
        LowB /= NinRange;
        HigB /= NinRange;

        double VarL = Low*(LowB-Aver)*(LowB-Aver);
        double VarH = Hig*(HigB-Aver)*(HigB-Aver);
        double Test = VarL+VarH;
        if(Test>MaxDif)
        {
            MaxDif = Test;
            Thresh = 0.5*(Bins[ib-1]+Bins[ib]);
        }
    }
    return Thresh;
}
double UDistribution::GetFractionFromBin(int ibin) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetFractionFromBin(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetFractionFromBin(). Object not properly set. \n");
        return 0.;
    }
    if(ibin<0 || ibin>Nbin)
    {
        CI.AddToLog("WARNING: UDistribution::GetFractionFromBin(). ibin parameter out of range (ibin = %d). \n", ibin);
        ibin = MIN(Nbin, MAX(0, ibin));
    }
    int Nunder  = 0;
    for(int n=0; n<=ibin; n++) Nunder += Count[n];
    
    return Nunder/double(Ntotal);
}
double UDistribution::GetFraction(double Min, double Max) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetFraction(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Count==NULL || Ntotal<=0)
    {
        CI.AddToLog("ERROR: UDistribution::GetFraction(). Object not properly set. \n");
        return 0.;
    }
    if(Min>=Max) return 0.;

    int N = 0;
    for(int ib=0; ib<=Nbin; ib++)
    {
        if(Bins[ib]<Min) continue;
        N += Count[ib];
        if(Max<Bins[ib]) break;
    }
    return N/double(Ntotal);
}
double UDistribution::GetUpperQuantile(double Fraction) const
/*
    Return the (approximate) upperquantile of all values investigated
    (including out of range values)
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetUpperQuantile(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetUpperQuantile(). Object not properly set. \n");
        return 0.;
    }
    if(Fraction<0 || Fraction>1)
    {
        CI.AddToLog("WARNING: UDistribution::GetUpperQuantile(). Fraction parameter out of range (Fraction = %f). \n", Fraction);
        Fraction = MIN(1., MAX(0., Fraction));
    }
    int Nunder  = 0;
    int NThresh = int(Fraction*Ntotal);
    for(int n=0; n<Nbin+2; n++)
    {
        Nunder += Count[n];
        if(Nunder>=NThresh)
        {
            if(n==0) return Bins[0];
            else
            {
                double F = Fraction*Ntotal - NThresh;
                return F*Bins[n]+(1.-F)*Bins[n-1];
            }
        }
    }
    return Bins[Nbin+1];
}
double UDistribution::GetLower(double Fraction) const
/*
    Return the threshold value such that Fraction of the data points
    (including the out of range values) has a value smaller that this threshold.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetLower(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetLower(). Object empty. \n");
        return 0.;
    }
    int Nlower=0;
    for(int n=0; n<Nbin+2; n++)
    {
        Nlower += Count[n];
        if(Nlower>Fraction*Ntotal)
        {
            if(n==0) return  Bins[0];
            else     return (Bins[n]+Bins[n-1])/2.;
        }
    }
    return Bins[Nbin+1];
}


double UDistribution::GetMedian(void) const
/*
    Return the (approximate) median of all values investigated
    (including out of range values)
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetMedian(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetMedian(). Object empty. \n");
        return 0.;
    }
    int Nhalf=0;
    for(int n=0; n<Nbin+2; n++)
    {
        Nhalf += Count[n];
        if(2*Nhalf>Ntotal)
        {
            if(n==0) return Bins[0];
            else     return (Bins[n]+Bins[n-1])/2.;
        }
    }
    return Bins[Nbin+1];
}
double UDistribution::GetFirstMinimum(int Threshold) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetFirstMinimum(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetFirstMinimum(). Object empty. \n");
        return 0.;
    }
    if(Threshold<0) Threshold=0;
    for(int ibin=1; ibin<Nbin; ibin++)
        if(Count[ibin-1]<Count[ibin]+Threshold && Count[ibin]+Threshold<Count[ibin+1]) return Bins[ibin];

    return Bins[Nbin];
}

double UDistribution::GetRightMax(int BinMin) const
/*
     Return the center of the bin where the 'Right maximum' occurs.
     This is the point such that left of it the number of counts decreases
     (arbitrarily) or increase uniformly. The minimum allowed bin number is BinMin

     This point is usefull for MR thresholding, using relative
     thresholds while ignoring the back-ground pixels.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetRightMax(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetRightMax(). Object empty. \n");
        return 0.;
    }
    int CountMaxL = -1; int imaxL = Nbin;
    int CountMaxR = -1; int imaxR = Nbin;

    BinMin = MAX(1, MIN(Nbin, BinMin));

    for(int i=Nbin; i>=BinMin; i--)
    {
        if(Count[i]>CountMaxL)
        {
            if(CountMaxR<0)
            {
                CountMaxR = Count[i];
                imaxR     = i;
            }
            CountMaxL = Count[i];
            imaxL     = i;
        }
        else
        {
            CountMaxR = CountMaxL;
            imaxR     = imaxL;
        }
    }
    imaxR = MAX(1, MIN(Nbin, imaxR));
    return (Bins[imaxR]+Bins[imaxR-1])/2.;
}

int UDistribution::GetBinNumber(double Value) const
/*
    return 0 iff Value<=Bins[0]
    else
    return the value k such that Bins[k-1]<Value<=Bins[k],
    else
    return Nbin+1 iff Value >Bins[Nbin]
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::GetBinNumber(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::GetBinNumber(). Object empty. \n");
        return 0;
    }
    int jl = 0;
    int ju = Nbin+1;
    while(ju-jl > 1)
    {
        int jm=(ju+jl) >> 1;
        if(Value > Bins[jm])
            jl=jm;
        else
            ju=jm;
    }
    return jl+1;
}

ErrorType UDistribution::Smooth(double Factor)
/*
    Smooth the histogram by merging bins and dividing bins over new ones.
    Make a new estimate of NinRange, SumInRange and Sum2InRange

    Note: the smoothing factor Factor should be larger than 1.
 */
{
    if(Factor<1.) return U_ERROR;

/* The new number of bins:*/
    int NbNew = int(floor(.5 + (MaxRange-MinRange)/Factor));

    return ReDistribute(MinRange, MaxRange, NbNew);
}

ErrorType UDistribution::ReDistribute(double NewMin, double NewMax, int NewNbin)
/*
    Redistribute the contents of Count[] over new bins using piecewise linear interpolation.

    NewMin  - The new minimum
    NewMax  - The new maximum
    NewNbin - The new number of bins

    Make a new estimate of NinRange, SumInRange and Sum2InRange
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::ReDistribute(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::ReDistribute(). Object empty. \n");
        return U_ERROR;
    }
    if(NewNbin<=0)     return U_ERROR;

    if(NewMin>=NewMax)
    {
        CI.AddToLog("ERROR: UDistribution::ReDistribute(). New minimum and maximum out of range: (%f,%f)\n",NewMin,NewMax);
        return U_ERROR;
    }
    if(NewMin<MinRange)
    {
        NewMin=MinRange;
        CI.AddToLog("WARNING: UDistribution::ReDistribute(). New minimum lower than old range. Set new minimum equal to old range (NewMin=%f).\n", NewMin);
    }
    if(NewMax>MaxRange)
    {
        NewMax=MaxRange;
        CI.AddToLog("WARNING: UDistribution::ReDistribute(). New maximum higher than old range. Set new maximum equal to old range (NewMax=%f).\n", NewMax);
    }
    if(NewMin==MinRange && NewMax==MaxRange && NewNbin==Nbin)
    {
        CI.AddToLog("Note: UDistribution::ReDistribute(). New ranges and number of bins are equal to old ones. \n");
        return U_OK;
    }

    double *Bnew = new double[NewNbin+2];
    int    *Nnew = new int[NewNbin+2];
    if(Bnew==NULL||Nnew==NULL)
    {
        delete[] Bnew;
        delete[] Nnew;
        CI.AddToLog("ERROR: UDistribution::ReDistribute(). Memory allocation. NewNbin=%d\n",NewNbin);
        return U_ERROR;
    }

/* The new distribution of bins*/
    MinRange = NewMin;
    MaxRange = NewMax;
    int k = 0;
    for(     ; k<NewNbin+2; k++) Bnew[k] = MinRange + k*(MaxRange-MinRange)/NewNbin;
    k = 0;
    for(     ; k<NewNbin+2; k++) Nnew[k] = 0;

/* The new distribution of counts*/
    int ilowb =  0;
    Nnew[0]   =  Count[0];
    while(Bins[ilowb+1]<Bnew[0] && ilowb<Nbin+1)
    {
        ilowb++;
        Nnew[0] += Count[ilowb];
    }

    for(k=0; k<NewNbin+1; k++)
    {
        if(Bnew[k+1]<Bins[ilowb+1])
        {
            double Fb2  = 0;
            if(Bnew[k]<Bins[ilowb])  Fb2 = (Bnew[k+1]-Bins[ilowb])/(Bins[ilowb+1]-Bins[ilowb]);
            else                     Fb2 = (Bnew[k+1]-Bnew[k]    )/(Bins[ilowb+1]-Bins[ilowb]);
            Nnew[k+1]  += int(floor(Fb2*Count[ilowb+1]+.5));
            continue;
        }

        double Fb  = (Bnew[k]-Bins[ilowb])/(Bins[ilowb+1]-Bins[ilowb]);
        int Nfrac  = int(floor(Fb*Count[ilowb+1]+.5));

        Nnew[k]   += Nfrac;

        Nnew[k+1] += Count[ilowb+1]-Nfrac;
        ilowb++;

        while(Bins[ilowb+1]<Bnew[k+1] && ilowb<Nbin+1)
        {
            ilowb++;
            Nnew[k+1] += Count[ilowb];
        }
    }
    int i=ilowb+1;
    for(        ; i<=Nbin+1; i++) Nnew[NewNbin+1] += Count[i];

    delete[] Bins;
    delete[] Count;
    Bins  = Bnew;
    Count = Nnew;
    Nbin  = NewNbin;


    NinRange    = 0;
    SumInRange  = 0.;
    Sum2InRange = 0.;
    for(int i=1; i<=Nbin; i++)
    {
        NinRange    += Count[i];
        double Val   = (Bins[i-1] + Bins[i])/2.;
        SumInRange  += Count[i]*Val;
        Sum2InRange += Count[i]*Val*Val;
    }

    return U_OK;
}

ErrorType UDistribution::EqualizeBins(int NewNbin)
/*
    Reorganize the bin sizes in such a way that the number of counts is constant
    in each bin. Keep the range parameters fixed.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::EqualizeBins(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::EqualizeBins(). Object empty. \n");
        return U_ERROR;
    }
    if(NewNbin<=0) return U_ERROR;

    double DNewC = NinRange/(double)NewNbin;

    double *Bnew = new double[NewNbin+2];
    int    *Nnew = new int[NewNbin+2];
    if(Bnew==NULL||Nnew==NULL)
    {
        delete[] Bnew;
        delete[] Nnew;
        CI.AddToLog("ERROR: UDistribution::EqualizeBins(). Memory allocation. NewNbin=%d\n",NewNbin);
        return U_ERROR;
    }

/* First construct a cumulative distribution of the counts.*/
    Nnew[0] = Count[0];
    Bnew[0] = Bins[0];
    for(int ib=1; ib<Nbin+1; ib++) Count[ib] += Count[ib-1];

/* Compute a new distribution of Bins and Counts */
    for(int k=1; k<NewNbin+1; k++)
    {
        double Dcum = k*DNewC;

/* Find the enclosing bins*/
        int jl = 0;
        int ju = Nbin+1;
        while(ju-jl > 1)
        {
            int jm=(ju+jl) >> 1;
            if(Dcum > Count[jm])
                jl=jm;
            else
                ju=jm;
        }
        double Fm = 0.;
        if(Count[jl+1]!=Count[jl]) Fm = (Dcum-Count[jl])/(Count[jl+1]-Count[jl]);

        Bnew[k]   = (1-Fm)*Bins[jl] + Fm*Bins[jl+1];
        Nnew[k]   = int(floor(k*DNewC+.5) - floor((k-1)*DNewC+.5));
    }
    Nnew[NewNbin+1] = Count[Nbin+1];

    delete[] Bins;
    delete[] Count;
    Bins  = Bnew;
    Count = Nnew;
    Nbin  = NewNbin;

    return U_OK;
}

ErrorType UDistribution::RemoveEmptyBins(void)
/*
    Remove the empty bins (except the outlier bins) by enlarging the boundaries of
    the non-empty bins.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::RemoveEmptyBins(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Bins==NULL || Nbin<1 || Count==NULL)
    {
        CI.AddToLog("WARNING: UDistribution::EqualizeBins(). Object empty. \n");
        return U_OK;
    }

/* Count the non-empty bins*/
    int NewNbin = 0;
    for(int k=1; k<Nbin+1; k++)
        if(Count[k]) NewNbin++;

    if(NewNbin==Nbin) return U_OK; // There are no empty bins

/* Create new bins and counts */
    double *Bnew = new double[NewNbin+2];
    int    *Nnew = new int[NewNbin+2];
    if(Bnew==NULL||Nnew==NULL)
    {
        delete[] Bnew;
        delete[] Nnew;
        CI.AddToLog("ERROR: UDistribution::RemoveEmptyBins(). Memory allocation. NewNbin=%d\n",NewNbin);
        return U_ERROR;
    }

    Bnew[0]  = Bins[0];
    Nnew[0]  = Count[0];
    int knew = 1;
    int k    = 1;
    while(k<Nbin+1 && knew<NewNbin+1)
    {
        if(Count[k])
        {
            Bnew[knew-1] = Bins[k-1];
            Nnew[knew  ] = Count[k];
            k++;
        }
        else
        {
            int kmin = k;  /* There are zeroes from kmin to kmax (not included)*/
            int kmax = Nbin;
            for(int kk=k+1; kk<Nbin+1; kk++)
                if(Count[kk]) {kmax=kk; break;}

            Bnew[knew-1] = (Bins[kmin-1]+Bins[kmax-1])/2;
            Nnew[knew  ] = Count[kmax];
            k            = kmax;
        }
        knew++;
    }
    Bnew[NewNbin  ] =  Bins[Nbin  ];
    Bnew[NewNbin+1] =  Bins[Nbin+1];
    Nnew[NewNbin+1] = Count[Nbin+1];

    delete[] Bins;   Bins  = Bnew;
    delete[] Count;  Count = Nnew;
       
    Nbin  = NewNbin;
    return U_OK;
}


void UDistribution::ClearCounts(void)
/*
    Reset all parameters of this object as if no values were added.
    Keep distribution into Bins fixed.
 */
{
    MinValue    = 0.;
    MaxValue    = 0.;
    Ntotal      = 0;
    NinRange    = 0;
    SumInRange  = 0.;
    Sum2InRange = 0.;

    if(Count) for(int k=0; k<Nbin+2; k++) Count[k] = 0;
}

ErrorType UDistribution::WriteAsText(const UFileName& Fout, bool CenterBin, bool Normalize, bool Cumulative) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDistribution::WriteAsText(). Object NULL or erroneous.\n");
        return U_ERROR;
    }

    FILE* fp=fopen(Fout, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UDistribution::WriteAsText(). Cannot create or open file %s   .\n", (const char*)Fout);
        return U_ERROR;
    }

    fprintf(fp, GetProperties("//  "));
    fprintf(fp,"//  ");
    fprintf(fp, GetDistributionText("  ", CenterBin, Normalize, Cumulative));

    fclose(fp);
    return U_OK;
}


