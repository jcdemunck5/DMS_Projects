#ifndef _UDISTRIBUTION_INCLUDED
#define _UDISTRIBUTION_INCLUDED

#include "String.h"

class UField;
class UFieldGraph;
class UFileName;

class DLL_IO UDistribution
{
public:
    UDistribution();
    UDistribution(int Nbin, double MinRan, double MaxRan);
    UDistribution(int Nbin, int* Histo, int Nlow=0, int Nhigh=0);
    UDistribution(const UField& fld, int Nsubsample=-1, int icomp=-1);
    UDistribution(const UDistribution& d);

    virtual ~UDistribution();  
    UDistribution& operator=(const UDistribution& d);

    ErrorType         GetError(void) const {if(this) return error; return U_ERROR;}
    int               GetNbin(void) const  {if(this) return Nbin;  return 0;}
    ErrorType         SetTitle(UString NewTitle);
    UString           GetTitle(void) const {return Title;}
    const UString&    GetProperties(UString Comment) const;

    ErrorType         AddValue(double Val);
    double            GetAverage(void) const;
    double            GetStandardDev(void) const;
    double            GetOtsuThreshold(void) const;
    double            GetMedian(void) const;
    double            GetUpperQuantile(double Fraction) const;
    double            GetLower(double Fraction) const;
    int               GetCountsFromBin(int ibin) const;
    double            GetCenterBin(int ibin) const;
    double            GetValueFromBin(int ibin) const;
    double            GetFractionFromBin(int ibin) const;
    double            GetFraction(double Min, double Max) const;
    double            GetFirstMinimum(int Threshold) const;
    double            GetRightMax(int BinMin=1) const;
    int               GetBinNumber(double Value) const;
    double            GetMinValue(void) const {return MinValue;}
    double            GetMaxValue(void) const {return MaxValue;}
    double            GetMinRange(void) const {return MinRange;}
    double            GetMaxRange(void) const {return MaxRange;}

    void              ClearCounts(void);
    ErrorType         SetMinMaxRange(double NewMin, double NewMax);

    ErrorType         Smooth(double Factor);
    ErrorType         ReDistribute(double NewMin, double NewMax, int NewNbin);
    ErrorType         EqualizeBins(int NewNbin);
    ErrorType         RemoveEmptyBins(void);

    UString           GetDistributionText(UString Comment, bool CenterBin, bool Normalize, bool Cumulative) const;
    UFieldGraph*      GetDistributionAsFieldGraph(bool Normalize, bool Cumulative) const;

    ErrorType         WriteAsText(const UFileName& Fout, bool CenterBin=false, bool Normalize=false, bool Cumulative=false) const;

protected:
    void              SetAllMembersDefault(void);
    void              DeleteAllMembers(ErrorType E);

private:
    static UString    Properties;
    ErrorType         error;
    UString           Title;

    double            *Bins;       // The distribution of the bins, wherein  the number of values is counted
    int               *Count;      // Count[0     ] = Number of values below Bins[0] = MinRange
                                   // Count[Nbin+1] = Number of values larger than Bins[Nbin] = MaxRange
                                   // Count[k     ] = Number of values between Bins[k-1] and Bins[k], k=1,...Nbin
    int               Nbin;        // The number of bins, determines the resolution of the distribution
    double            MinRange;    // The minimum and the maximum between which the distribution is determined
    double            MaxRange;
    double            MinValue;    // Running minimum
    double            MaxValue;    // Running maximum
    int               Ntotal;      // Number of values investigated 
    int               NinRange;    // Number of examined values that are in range
    double            SumInRange;  // Running sum of all values in range
    double            Sum2InRange; // Running sum of squares of all values in range
};

#endif //_UDISTRIBUTION_INCLUDED
