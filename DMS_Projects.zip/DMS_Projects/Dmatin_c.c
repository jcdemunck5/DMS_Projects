#include <stddef.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>



int dmatin_c(double *a, long int n, long int ndim, double *det)


/* This routine inverts the matrix *a.
   a[i+ndim*j]  : matrix elements i,j
   n            : order of the matrix
   *det         : resulting determinant
   
   return value:  0 if OK, -1 if error

*/   

{
   double biga,hold;
   int    i,ij,ik,iz,j,ji,jk,jp,jq,jr,k,ki,kj,kk,nk;
   int    *l=NULL,*m=NULL;

   l = (int *)malloc(n*sizeof(l[0]));
   m = (int *)malloc(n*sizeof(m[0]));
   if(l==NULL || m==NULL) goto error;
   
/* Search for largest element  */
   *det = 1.e0;
   nk   =-ndim; 

   for(k=0;k<n;k++)
   {
      nk  += ndim;
      l[k] = k; 
      m[k] = k;
      kk   = nk+k;
      biga = a[kk];

      for(j=k;j<n;j++)
      {
         iz  = ndim*j;
         for(i=k;i<n;i++)
    {
            ij   = iz+i;
            hold = fabs(biga)-fabs(a[ij]);
            if(hold<0.) 
            {  biga=a[ij];
               l[k]=i;
               m[k]=j;
            }
         }
      }

/* interchange rows  */
      j=l[k]; 
      if(j>k) 
      {  ki=k-ndim ;
         for(i=0;i<n;i++)
         {  ki   = ki+ndim; 
            hold =-a[ki]; 
            ji   = ki-k+j; 
            a[ki]= a[ji]; 
            a[ji]= hold;
         }
      }

/*  interchange colums  */
      i=m[k];
      if(i>k) 
      {  jp=ndim*i;
         for(j=0;j<n;j++)
         {
            jk   = nk+j;
            ji   = jp+j;
            hold =-a[jk];
            a[jk]= a[ji];
            a[ji]= hold;
         }
      }

/* Divide colums by minus pivot (value of pivot element is 
   contained in biga).
*/
      if(biga==0.) goto error;
      
      for(i=0;i<n;i++) if(i!=k) 
                       {
                          ik    = nk+i;
                          a[ik]/= (-biga);
                       }

/* Reduce matrix */
      for(i=0;i<n;i++)
      {
         ik   = nk+i;
         hold = a[ik];
         ij   = i-ndim;
         for(j=0;j<n;j++)
         {
            ij +=ndim;
            if(i!=k && j!=k) 
            {  kj=ij-i+k;
               a[ij]=hold*a[kj]+a[ij]; 
            }
         }
      }

/* Divide row by pivot */

      kj=k-ndim; 
      for(j=0;j<n;j++)
      {
         kj += ndim; 
         if(j!=k) a[kj]=a[kj]/biga;
      }
/*  product of pivots and replace pivot by reciprocal */
/*    *det  *= biga; */
      a[kk] =1./biga;
   }

/* Final row and column interchange */
   for(k=n-1;k>=0;k--)
   {
      i=l[k];
      if(i>k) 
      {  jq=ndim*k;
         jr=ndim*i;

         for(j=0;j<n;j++)
         {
            jk   = jq+j;
            hold = a[jk]; 
            ji   = jr+j;
            a[jk]=-a[ji]; 
            a[ji]= hold; 
         }
      }

      j=m[k];
      if(j>k) 
      {  ki=k-ndim;
         for(i=0;i<n;i++)
         {  
       ki  += ndim;
            hold = a[ki];
            ji   = ki-k+j;
            a[ki]=-a[ji];
            a[ji]= hold;
         }
      }
   }

   free(l);free(m);
   return 0;

error:
   free(l);free(m);
   return -1;
}
