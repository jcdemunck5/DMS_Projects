/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a 3D drawing.                                      */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    02-09-01   creation
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    07-10-02   Add AddPoint() and GetPlaneIntersection()
  JdM    13-10-02   GetPlaneIntersection() add crossing points
  JdM    05-11-02   Add DeleteLastPoints()
  JdM    14-11-02   Added another WriteXDR()
  JdM    19-11-02   Added Filename constructor
  JdM    07-02-05   Added GetEdge() and CloseLastSegment()
  JdM    08-02-05   Added InContour()
  JdM    31-12-05   Bug fix: InContour().
  JdM    22-01-06   WriteXDR() changed first argument type into UFileName
  JdM    23-01-06   Switched off MS C++ language extensions.
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    24-01-08   Added GetLastSegmentLengthStraight() and GetLastSegmentLengthCurved()
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
                    Use UString for Properties and Name
  JdM    23-09-08   Default drawing name = "NoName"
  JdM    17-03-10   Bug Fix: WriteASCII(). Made copy of GetProperties(), writing edges
  JdM    11-05-10   Added WriteMatLab()
  JdM    27-12-10   Added argment to WriteMatLab()
                    Renamed DeleteLastPoints() as DeleteLastSegment()
                    BUG FIX Concatenate(): Invalid concatenation of indices
  JdM    25-10-11   Call InvalidateKDTree() UpdateKDTree() when points array is changed
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    27-04-15   Remove (obsolete) ReAllocateMemory()
  JdM    28-04-16   Added GetProjectedArea()
  JdM    07-09-16   Added GetNComponents(), GetLargestComponent()
 JdM/FaB 12-09-16   Bug Fix: GetLargestComponent(). Wrong points were selected
  JdM    14-10-16   Added GetComponents() and MergeComponents()
  JdM    22-10-16   Added WriteVTK(), which also writes the edges
  JdM    31-03-17   BUG fix: MergeComponents(). call InvalidateKDTree() after merging points from smaller contours.
  JdM    11-05-17   Added contour tracing constructors
  JdM    15-05-17   Tracing constructor: avoid infinite loop
  JdM    12-06-18   Added RemoveDoublePoints()
  JdM    22-06-18   WriteVTK(). Add parameter (tube thickness)
  JdM    02-07-18   Added RemovePoints(), ReorderSegments() and SplitPlanes()
  JdM    04-07-18   Added GetPointsComponents()
  JdM    11-07-18   Added GetTotalLength() and ResampleCurve()
  JdM    16-07-18   Inserted parameters to UField 3D constructor to control level selection
                    Bug fix in_cont(). Tested y > Ndimy instead of y >= Ndimy
                    GetPlaneIntersection(). Added tolerance parameter
                    Added Crop().
  JdM    09-09-18   UField constructors: Convert data to int
                    Bug Fix: Tracing in UField constructor did not work in case of dir==2 (dir==3 was tested).
  JdM    11-09-18   Bug Fix: SplitPlanes(). if(Resample==true), The toltal length of all curves was wrongly computed.
                    ReorderSegments(). Immediately return when Nsegm==1.
  JdM    14-09-18   UTraceContour(). Renamed private functions
 */
 
#include<string.h>

#include "Drawing.h"
#include "InterpolateCircle.h"
#include "Surface.h"
#include "FileName.h"
#include "Directory.h"
#include "Field.h"
#include "SortSemiSort.h"

 
/* Inititalize static const parameters. */
UString UDrawing::Properties = UString();

void UTraceContour::SetAllMembersDefault(void)
{
    error    = U_OK;
    Level    = 0;
    Idat     = NULL;
    Ndimx    = 0;
    Ndimy    = 0;

    xInit    = 0;
    yInit    = 0;
    dirLast  = 0;
}
void UTraceContour::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UTraceContour::UTraceContour(const UField* F2D, int LevelField)
{
    SetAllMembersDefault();
    if(F2D==NULL || F2D->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UTraceContour::UTraceContour(). Object argument NULL or erroneous. \n");
        return;
    }
    if(F2D->GetFType()!=UField::U_UNIFORM &&
       F2D->GetFType()!=UField::U_RECTILINEAR)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UTraceContour::UTraceContour(). Input field of wrong type (%d). \n",F2D->GetFType());
        return;
    }
    if(F2D->GetDType()!=UField::U_INTEGER || F2D->GetIdata()==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UTraceContour::UTraceContour(). Input field has wrong data type (%d). \n",F2D->GetDType());
        return;
    }
    if(F2D->Getndim()!=2 || F2D->GetDimensions(0)<3 || F2D->GetDimensions(1)<3 || F2D->GetVeclen()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UTraceContour::UTraceContour(). Input field has wrong dimensions (%s). \n",F2D->GetProperties(""));
        return;
    }
    Level   = LevelField;
    Ndimx   = F2D->GetDimensions(0);
    Ndimy   = F2D->GetDimensions(1);
    Idat    = F2D->GetIdata();
}

ErrorType UTraceContour::InitTracing(int*init_x, int*init_y)
{
    if(this==NULL || error!=U_OK || Idat==NULL) return U_ERROR;
    if(init_x==NULL || init_y==NULL) return U_ERROR;

    xInit = yInit = -1;

    dirLast = -1;
    for(int y=0, k=0; y<Ndimy; y++)
    {
        for(int x=0; x<Ndimx; x++, k++)
        {
            if(IsAtLevel(x, y) && !IsAtLevel(x+1, y))
            {
                xInit = x;
                yInit = y;
                break;
            }
        }
        if(xInit>=0) break;
    }
    *init_x = xInit;
    *init_y = yInit;
    return U_OK;
}
bool UTraceContour::ComputeNext(int*new_x, int*new_y)
{
    if(xInit<0 || yInit<0) 
    {
        *new_x = -1;
        *new_y = -1;
        return true;   // No points
    }
    int x = *new_x;
    int y = *new_y;
    if(dirLast<0)
    {
        for(int k=0; k<=8; k++)
        {
            dirLast = (k+4)%8;
            if(k==8)                                          return true;  // Isolated point
            if(IsNeigborAtLevel(x, y, dirLast, new_x, new_y)) return false;
        }
    }

    dirLast = GetNewDirAtLevel(x, y, (dirLast+1)%8, new_x, new_y);
    return (*new_x==xInit && *new_y==yInit);
}
bool UTraceContour::IsNeigborAtLevel(int x, int y, int dir, int*new_x, int*new_y)
/*
            3  2  1
            4  *  0
            5  6  7
*/
{
    if( (dir < 2) || (dir > 6) )    ++x;
    if( (dir > 2) && (dir < 6) )    --x;
    if( (dir > 0) && (dir < 4) )    ++y;
    if(  dir > 4)                   --y;

    *new_x = x;
    *new_y = y;
    return IsAtLevel(x, y);
}
int UTraceContour::GetNewDirAtLevel(int x, int y, int last_dir, int* new_x, int* new_y)
{
    int new_dir = -1;
    if(last_dir & 0x01)  new_dir = last_dir + 2; // ???
    else                 new_dir = last_dir + 1;

    if(new_dir > 7)      new_dir -= 8;

    for(int n = 0; n < 8; n++)
    {
        if(IsNeigborAtLevel(x, y, new_dir, new_x, new_y)) return new_dir;
        if(--new_dir < 0) new_dir += 8;
    }
    return -1; // should never happen
}
bool UTraceContour::IsAtLevel(int x, int y)
{
    if ( (x < 0) || (x >=Ndimx) || (y < 0) || (y >= Ndimy) ) return false;
    return Idat[y*Ndimx+x]==Level;
}
void UDrawing::SetAllMembersDefault(void)
{
    Nedge      = 0;
    NedgeAlloc = 0;
    EdgeList   = NULL;
    Name       = UString("NoName");
    Properties = UString();
    error      = U_OK;
}
void UDrawing::DeleteAllMembers(ErrorType E)
{
    delete[] EdgeList;
    SetAllMembersDefault();
    error = E;
}

UDrawing::UDrawing() : UPointList()
{
    SetAllMembersDefault();
}

UDrawing::UDrawing(const UDrawing& d) : UPointList((UPointList) d)
{
    SetAllMembersDefault();
    *this = d;
}

UDrawing::UDrawing(const UVector3* plist, int np, const char *gname): 
    UPointList(plist, np)
/*
      Create a drawing object, consisting of the points array plist[] 
      a circular contour from plist[0] to plist[1], etc, to plist[0]

      plist[] pointer to array of drawing points
      np      number of surface points
 */
{
    SetAllMembersDefault();

/* Cheque the consistency of the parameters*/
    if(UPointList::GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Creating base class. \n");
        return;
    }
    if(np<=0 || plist==NULL)     
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). NULL parameters. \n");
        return;
    }
    if(gname) Name = UString(gname);
    else      Name = UString("No Name");

/* Copy edges */
    EdgeList   = new int[2*np];
    if(EdgeList==NULL) 
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Memory allocation: np = %d \n", np);
        return;
    }
    Nedge      = np;
    NedgeAlloc = np;

    for(int i=0; i<np; i++) 
    {
        EdgeList[2*i  ] = i;
        EdgeList[2*i+1] = (i+1)%np;
    }
}

UDrawing::UDrawing(const char* FileName) : 
    UPointList()
{
    SetAllMembersDefault();
    if(FileName==NULL)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Erroneous NULL argument. \n");
        return;
    }
    
/* Read the points as AVS UField */
    UFileName DrawFile(FileName);
    DrawFile.ReplaceExtension("dwp");

    UPointList::operator=( UPointList(DrawFile));
    if(UPointList::GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Reading points from %s .\n", DrawFile.GetFullFileName());
        return;
    }

/* Read the indices as AVS UField */
    DrawFile.ReplaceExtension("DWI");
    UField IndexField(DrawFile.GetFullFileName());
    if(IndexField.GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Indices from %s .\n", DrawFile.GetFullFileName());
        return;
    }
    if(IndexField.Getndim()!=1 || 
       IndexField.GetDType()!=UField::U_INTEGER || 
       IndexField.GetVeclen()!=3)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Index file contains the wrong UField data: %s .\n", (const char*)IndexField.GetProperties(""));
        return;
    }

/* Copy data to members */
    EdgeList   = new int[2*IndexField.GetDimensions(0)];
    if(EdgeList==NULL)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Memory allocation. Nedges = %d . \n", IndexField.GetDimensions(0));
        return;
    }
    Nedge   = IndexField.GetDimensions(0);

    int * Idata = IndexField.GetIdata();
    for(int n=0; n<Nedge; n++)
    {
        EdgeList[2*n  ] = Idata[3*n  ];
        EdgeList[2*n+1] = Idata[3*n+1];
    }

    NedgeAlloc       = Nedge;
    SetName(DrawFile.GetBaseName());
}
UDrawing::UDrawing(const UField* F2D, int dir, double coord, int Level, const char* DName)
{
    SetAllMembersDefault();

    if(F2D==NULL || F2D->GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). NULL or erroneous UField- argument. \n");
        return;
    }
    if(dir<0 || 3<=dir)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Parameter out of range (dir=%d). \n", dir);
        return;
    }
    UField FInt(*F2D);
    if(FInt.ConvertData(UField::U_INTEGER)!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Converting data to int. \n");
        return;
    }

    UTraceContour TC(&FInt, Level);
    if(TC.GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Creating UTraceContour object. \n");
        return;
    }
    int x = 0;
    int y = 0;
    TC.InitTracing(&x, &y);
    if(x>=0 && y>=0)
    {
        int MaxNP = F2D->GetNpoints();
        while(NOT(TC.ComputeNext(&x,&y)))
        {
            if(Npoints>MaxNP)
            {
                CI.AddToLog("ERROR: UDrawing::UDrawing(). Starting point not found, np = %d. \n", Npoints);
                break;
            }
            if(x<0 || y<0) break;
            UVector3 Xvec;
            switch(dir)
            {
            case 0: Xvec = UVector3(coord, F2D->GetCoord(0,x), F2D->GetCoord(1,y)); break;
            case 1: Xvec = UVector3(F2D->GetCoord(1,y), coord, F2D->GetCoord(0,x)); break;
            case 2: Xvec = UVector3(F2D->GetCoord(0,x), F2D->GetCoord(1,y), coord); break;
            }
            AddPoint(Xvec, Npoints>0);
        }
        if(Npoints>1) CloseLastSegment();
    }
    if(DName) Name = UString(DName);
}
UDrawing::UDrawing(const UField* F3D, int dir, int SliceStep, LevelType LT, int Level, const char* DName)
{
    SetAllMembersDefault();

    if(F3D==NULL || F3D->GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). NULL or erroneous UField- argument. \n");
        return;
    }
    if(dir<0 || 3<=dir)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Parameter out of range (dir=%d). \n", dir);
        return;
    }
    if(F3D==NULL || F3D->GetError()!=U_OK)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Object argument NULL or erroneous. \n");
        return;
    }
    if(F3D->GetFType()!=UField::U_UNIFORM &&
       F3D->GetFType()!=UField::U_RECTILINEAR)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Input field of wrong type (%d). \n",F3D->GetFType());
        return;
    }
    if(F3D->GetDType()!=UField::U_BYTE && F3D->GetDType()!=UField::U_SHORT && F3D->GetDType()!=UField::U_INTEGER)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Input field has wrong data type (%d). \n",F3D->GetDType());
        return;
    }
    if(F3D->Getndim()!=3 || F3D->GetDimensions(0)<3 || F3D->GetDimensions(1)<3 || F3D->GetDimensions(2)<3 || F3D->GetVeclen()!=1)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Input field has wrong dimensions (%s). \n",F3D->GetProperties(""));
        return;
    }
    if(SliceStep<=0||SliceStep>=F3D->GetDimensions(dir))
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::UDrawing(). Slice step parameter out of range (%d). \n",SliceStep);
        return;
    }

    for(int k=0; k<F3D->GetDimensions(dir); k+=SliceStep)
    {
        UField* SL  = F3D->GetSlice(dir, k);
        if(SL==NULL || SL->GetError()!=U_OK)
        {
            delete SL;
            UPointList::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UDrawing::UDrawing(). Getting slice %d. \n", k);
            return;
        }
        SL->Segment(LT, Level, 0);

        int     NC     = 0;
        UField* SLcmp  = SL->ConnectComponents(&NC);
        delete SL;
        if(SLcmp==NULL || SLcmp->GetError()!=U_OK || SLcmp->GetIdata()==NULL)
        {
            delete SLcmp;
            UPointList::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UDrawing::UDrawing(). Getting connected component from slice %d. \n", k);
            return;
        }
        if(NC>1)
        {
            UDrawing D(SLcmp, dir, F3D->GetCoord(dir, k), 1, "Slice");
            if(D.GetError()==U_OK)  this->Concatenate(&D);
        }
        delete SLcmp;
    }
    if(DName) Name = UString(DName);
}

UDrawing::~UDrawing()
{
    DeleteAllMembers(U_OK);
}

UDrawing& UDrawing::operator=(const UDrawing &d)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::operator=(). this==NULL. \n");
        static UDrawing D; D.error=U_ERROR;
        return D;
    }
    if(&d==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::operator=(). Argument has NULL address. \n");
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&d) return *this;

    UPointList::operator=(d);
    if(UPointList::GetError() != U_OK) 
    {
        UPointList::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UDrawing::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    
    Nedge      = d.Nedge;
    NedgeAlloc = d.NedgeAlloc;
    Name       = d.Name;
    
    if(d.EdgeList)
    {
        EdgeList = new int[2*MAX(Nedge,NedgeAlloc)];
        if(EdgeList==NULL) 
        {
            UPointList::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int i=0; i<2*Nedge; i++) EdgeList[i] = d.EdgeList[i];
    }

    return *this;
}
ErrorType UDrawing::RemovePoints(UVector3 P, double Tol)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::RemovePoints(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(p==NULL || EdgeList==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::RemovePoints(). Object not properly set. \n");
        return U_ERROR;
    }
    if(Tol<0.)
    {
        CI.AddToLog("ERROR: UDrawing::RemovePoints(). Argument out of range: Tol=%f .\n", Tol);
        return U_ERROR;
    }
    int* NewIndex = NULL;
    if(UPointList::RemovePoints(P, Tol, &NewIndex)!=U_OK)
    {
        delete[] NewIndex;
        CI.AddToLog("ERROR: UDrawing::RemovePoints(). Getting indices with removed points. \n");
        return U_ERROR;
    }
    if(NewIndex==NULL) return U_OK; // No points removed

    for(int m2=0; m2<2*Nedge; m2++) EdgeList[m2] = NewIndex[EdgeList[m2]];
    delete[] NewIndex;

    int NedgeNew = 0;
    for(int m=0; m<Nedge;m++)
    {
        if(EdgeList[2*m]<0 || EdgeList[2*m+1]<0) continue;
        EdgeList[2*NedgeNew  ] = EdgeList[2*m  ];
        EdgeList[2*NedgeNew+1] = EdgeList[2*m+1];
        NedgeNew++;
    }
    Nedge = NedgeNew;
    return U_OK;
}

ErrorType UDrawing::RemoveDoublePoints(double Tol)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::RemoveDoublePoints(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(p==NULL || EdgeList==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::RemoveDoublePoints(). Object not properly set. \n");
        return U_ERROR;
    }
    if(Tol<0.)
    {
        CI.AddToLog("ERROR: UDrawing::RemoveDoublePoints(). Argument out of range: Tol=%f .\n", Tol);
        return U_ERROR;
    }
    int* NewIndex = NULL;
    if(UPointList::RemoveDoublePoints(Tol, &NewIndex)!=U_OK || NewIndex==NULL)
    {
        delete[] NewIndex;
        CI.AddToLog("ERROR: UDrawing::RemoveDoublePoints(). Getting indices with double points. \n");
        return U_ERROR;
    }
    for(int m2=0; m2<2*Nedge; m2++) EdgeList[m2] = NewIndex[EdgeList[m2]];
    delete[] NewIndex;

    int NedgeNew = 0;
    for(int m=0; m<Nedge;m++)
    {
        if(EdgeList[2*m]==EdgeList[2*m+1]) continue;
        if(EdgeList[2*m]<0 || EdgeList[2*m+1]<0) continue;
        EdgeList[2*NedgeNew  ] = EdgeList[2*m  ];
        EdgeList[2*NedgeNew+1] = EdgeList[2*m+1];
        NedgeNew++;
    }
    Nedge = NedgeNew;
    return U_OK;
}
ErrorType UDrawing::Crop(UVector3 Minco, UVector3 Maxco)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::Crop(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(p==NULL || EdgeList==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::Crop(). Object not properly set. \n");
        return U_ERROR;
    }
    int* NewIndex = NULL;
    if(UPointList::Crop(Minco, Maxco, &NewIndex)!=U_OK || NewIndex==NULL)
    {
        delete[] NewIndex;
        CI.AddToLog("ERROR: UDrawing::Crop(). Getting indices with double points. \n");
        return U_ERROR;
    }
    for(int m2=0; m2<2*Nedge; m2++) EdgeList[m2] = NewIndex[EdgeList[m2]];
    delete[] NewIndex;

    int NedgeNew = 0;
    for(int m=0; m<Nedge;m++)
    {
        if(EdgeList[2*m]==EdgeList[2*m+1]) continue;
        if(EdgeList[2*m]<0 || EdgeList[2*m+1]<0) continue;
        EdgeList[2*NedgeNew  ] = EdgeList[2*m  ];
        EdgeList[2*NedgeNew+1] = EdgeList[2*m+1];
        NedgeNew++;
    }
    Nedge = NedgeNew;
    return U_OK;
}

int UDrawing::GetNComponents(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::GetNComponents(). this==NULL or erroneous. \n");
        return 0;
    }
    if( (Nedge<=0   || EdgeList==NULL) ||
        (Npoints<=0 || p       ==NULL))
    {
        CI.AddToLog("ERROR: UDrawing::GetNComponents(). Object empty or not properly set (Npoints, Nedge) = (%d,%d). \n", Npoints, Nedge);
        return 0;
    }
    int* ListA = new int[Nedge];
    int* ListB = new int[Nedge];
    if(ListA==NULL || ListB==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetNComponents(). Memory allocation. \n");
        delete[] ListA; delete[] ListB;
        return 0;
    }
    for(int n=0; n<Nedge; n++)
    {
        ListA[n] = EdgeList[2*n  ];
        ListB[n] = EdgeList[2*n+1];
    }
    int  NC   = 0;
    int* Equi = GetEquivalenceClass(Npoints, ListA, ListB, Nedge, &NC);
    if(Equi==NULL)
    {
        delete[] ListA; delete[] ListB;
        CI.AddToLog("ERROR: UDrawing::GetNComponents(). Getting equivalence classes. \n");
        return 0;
    }

    delete[] Equi; delete[] ListA; delete[] ListB;
    return NC;
}
UDrawing* UDrawing::GetLargestComponent(int* NCompOld) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::GetLargestComponent(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (Nedge<=0   || EdgeList==NULL) ||
        (Npoints<=0 || p       ==NULL))
    {
        CI.AddToLog("ERROR: UDrawing::GetLargestComponent(). Object empty or not properly set (Npoints, Nedge) = (%d,%d). \n", Npoints, Nedge);
        return NULL;
    }
    int* ListA = new int[Nedge];
    int* ListB = new int[Nedge];
    if(ListA==NULL || ListB==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetLargestComponent(). Memory allocation. \n");
        delete[] ListA; delete[] ListB;
        return NULL;
    }
    for(int n=0; n<Nedge; n++)
    {
        ListA[n] = EdgeList[2*n  ];
        ListB[n] = EdgeList[2*n+1];
    }
    int  NC   = 0;
    int* Equi = GetEquivalenceClass(Npoints, ListA, ListB, Nedge, &NC);
    int* Temp = new int[Npoints];
    if(Equi==NULL || Temp==NULL)
    {
        delete[] Temp; delete[] Equi; delete[] ListA; delete[] ListB;
        CI.AddToLog("ERROR: UDrawing::GetLargestComponent(). Getting equivalence classes. \n");
        return NULL;
    }
    delete[] ListA; delete[] ListB;
    if(NCompOld) *NCompOld = NC;

    for(int i=0; i<Npoints; i++) Temp[i]=0;
    for(int i=0; i<Npoints; i++) Temp[Equi[i]]++;
    int Emax = -1, Smax=0;
    for(int i=0; i<Npoints; i++) if(Temp[i]>Smax) {Smax=Temp[i]; Emax=i;}

/* Select all points and edges with ID Emax */
    for(int i=0; i<Npoints; i++) Temp[i] = -1;
    UDrawing* DLarge = new UDrawing();
    for(int i=0,k=0; i<Npoints; i++)
    {
        if(Equi[i]!=Emax) continue;
        ((UPointList*) DLarge)->AddPoint(p[i]);
        Temp[i] = k++;
    }
    for(int i=0; i<Nedge; i++)
    {
        if(Equi[EdgeList[2*i]]!=Emax || Equi[EdgeList[2*i+1]]!=Emax) continue;
        DLarge->AddEdge(Temp[EdgeList[2*i]], Temp[EdgeList[2*i+1]]);
    }

    delete[] Equi; delete[] Temp;
    return DLarge;
}
int* UDrawing::GetPointsComponents(int* NComp, int** PClass) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::GetPointsComponents(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (Nedge<=0   || EdgeList==NULL) ||
        (Npoints<=0 || p       ==NULL))
    {
        CI.AddToLog("ERROR: UDrawing::GetPointsComponents(). Object empty or not properly set (Npoints, Nedge) = (%d,%d). \n", Npoints, Nedge);
        return NULL;
    }
    if(NComp==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetPointsComponents(). Invalid NULL pointer argument. \n");
        return NULL;
    }

    int* ListA = new int[Nedge];
    int* ListB = new int[Nedge];
    if(ListA==NULL || ListB==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetPointsComponents(). Memory allocation. \n");
        delete[] ListA; delete[] ListB;
        return NULL;
    }
    for(int n=0; n<Nedge; n++)
    {
        ListA[n] = EdgeList[2*n  ];
        ListB[n] = EdgeList[2*n+1];
    }
    int* EquiP = PClass ? GetEquivalenceClass(Npoints, ListA, ListB, Nedge, NComp, PClass) :
                          GetEquivalenceClass(Npoints, ListA, ListB, Nedge, NComp);
    delete[] ListA; delete[] ListB;
    return EquiP;
}

UDrawing** UDrawing::GetComponents(int* NComp) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::GetComponents(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (Nedge<=0   || EdgeList==NULL) ||
        (Npoints<=0 || p       ==NULL))
    {
        CI.AddToLog("ERROR: UDrawing::GetComponents(). Object empty or not properly set (Npoints, Nedge) = (%d,%d). \n", Npoints, Nedge);
        return NULL;
    }
    if(NComp==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetComponents(). Invalid NULL pointer argument. \n");
        return NULL;
    }

    int* ListA = new int[Nedge];
    int* ListB = new int[Nedge];
    if(ListA==NULL || ListB==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetComponents(). Memory allocation. \n");
        delete[] ListA; delete[] ListB;
        return NULL;
    }
    for(int n=0; n<Nedge; n++)
    {
        ListA[n] = EdgeList[2*n  ];
        ListB[n] = EdgeList[2*n+1];
    }
    int*       PClass = NULL;
    int*       EquiP  = GetEquivalenceClass(Npoints, ListA, ListB, Nedge, NComp, &PClass);
    int*       EquiE  = new int[Nedge];
    int*       Index  = new int[Npoints];
    UDrawing** DrCom  = *NComp>0 ? new UDrawing*[*NComp] : NULL;
    if(PClass==NULL || EquiP==NULL || EquiE==NULL || Index==NULL || DrCom==NULL)
    {
        delete[] PClass; delete[] EquiP; delete[] EquiE; delete[] Index; delete[] ListA; delete[] ListB; delete[] DrCom;
        CI.AddToLog("ERROR: UDrawing::GetComponents(). Getting equivalence classes. \n");
        return NULL;
    }
    delete[] ListA; delete[] ListB;

    for(int ic=0; ic<*NComp; ic++) DrCom[ic] = NULL;
    for(int m =0; m<Nedge  ; m++ ) EquiE[m]  = EquiP[EdgeList[2*m]];

    ErrorType E = U_OK;
    for(int ic=0; ic<*NComp ; ic++) 
    {
        DrCom[ic] = new UDrawing();
        if(DrCom[ic]==NULL || DrCom[ic]->GetError()!=U_OK) {E=U_ERROR; break;}

        for(int n=0;      n<Npoints           ; n++) Index[n] = -1;
        for(int n=0, k=0; n<Npoints && E==U_OK; n++) 
        {
            if(PClass[ic]!=EquiP[n]) continue;
            E        = ((UPointList*)DrCom[ic])->AddPoint(p[n]);
            Index[n] = k++;
        }
        for(int m=0; m<Nedge && E==U_OK; m++) 
        {
            if(PClass[ic]!=EquiE[m]) continue;
            E = DrCom[ic]->AddEdge(Index[EdgeList[2*m]], Index[EdgeList[2*m+1]]);
        }
    }
    delete[] PClass; delete[] EquiP; delete[] EquiE; delete[] Index;
    if(E!=U_OK)
    {
        for(int ic=0; ic<*NComp ; ic++) delete DrCom[ic]; delete[] DrCom;
        CI.AddToLog("ERROR: UDrawing::GetComponents(). Splitting components. \n");
        return NULL;
    }
    return DrCom;
}

ErrorType UDrawing::MergeComponents(double DistThresh)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::MergeComponents(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (Nedge<=0   || EdgeList==NULL) ||
        (Npoints<=0 || p       ==NULL))
    {
        CI.AddToLog("ERROR: UDrawing::MergeComponents(). Object empty or not properly set (Npoints, Nedge) = (%d,%d). \n", Npoints, Nedge);
        return U_ERROR;
    }
    UVector3*  ptemp = new UVector3[Npoints];
    UVector3*  pbuff = new UVector3[Npoints];
    int        NComp = -1;
    UDrawing** DrCom = GetComponents(&NComp);
    if(DrCom==NULL ||NComp<=0 || SortSize((UPointList**)DrCom, NComp)!=U_OK || ptemp==NULL || pbuff==NULL)
    {
        delete[] ptemp; delete[] pbuff;
        if(DrCom) for(int ic=0; ic<NComp; ic++) delete DrCom[ic]; delete[] DrCom;
        CI.AddToLog("ERROR: UDrawing::MergeComponents(). Finding or sorting components. \n");
        return U_ERROR;
    }
    if(NComp==1)
    {
        delete[] ptemp;  delete[] pbuff;
        delete DrCom[0]; delete[] DrCom;
        return U_OK;
    }
    int NpointsOld   = Npoints;
    *this            = *DrCom[0];
    for(int i=0; i<Npoints; i++) pbuff[i] = p[i];
    delete[] p;    p = pbuff;
    NpointsAllocated = NpointsOld;

    for(int ic=1; ic<NComp; ic++)
    {
        int    i1   = -1;
        int    i2   = -1;
        double Dist = ::GetDistance((UPointList*)this, (UPointList*)DrCom[ic], &i1, &i2);
        if(Dist<0 || Dist>=DistThresh) continue;
        if(i1<0 || i2<0)
        {
            for(int ic=0; ic<NComp; ic++) delete DrCom[ic]; delete[] DrCom;
            CI.AddToLog("ERROR: UDrawing::MergeComponents(). Finding indices of minimum distance. \n");
            return U_ERROR;
        }
        int N2 = DrCom[ic]->GetNpoints();

        for(int k= 0   ; k<i1        ; k++) ptemp[k] = p[k];
        for(int k=i1   ; k<i1+N2     ; k++) ptemp[k] = DrCom[ic]->p[k-i1];
        for(int k=i1+N2; k<Npoints+N2; k++) ptemp[k] = p[k-N2];

        Npoints += N2;
        for(int k= 0; k<Npoints; k++) p[k] = ptemp[k];
        InvalidateKDTree();
    }
    delete[] ptemp;
    for(int ic=0; ic<NComp; ic++) delete DrCom[ic]; delete[] DrCom;

    if(NedgeAlloc<Npoints)
    {
        delete[] EdgeList; EdgeList = new int[2*Npoints];
        if(EdgeList==NULL)
        {
            CI.AddToLog("ERROR: UDrawing::MergeComponents(). Memory allocation for edges (Nedge = %d). \n", Npoints);
            return U_ERROR;
        }
        NedgeAlloc = Npoints;
    }

    Nedge = Npoints;
    for(int i=0; i<Npoints; i++) 
    {
        EdgeList[2*i  ] = i;
        EdgeList[2*i+1] = (i+1)%Npoints;
    }
    return U_OK;
}
double UDrawing::GetTotalLength(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetTotalLength(). Object NULL or erroneous. \n");
        return 0.;
    }

    if(Npoints<=1)     return 0.;
    if(EdgeList==NULL) return 0.;

    double Ltot = 0;;
    for(int ie=0,ie2=0; ie<Nedge; ie++,ie2+=2) Ltot += (p[EdgeList[ie2]]-p[EdgeList[ie2+1]]).GetNorm();
    return Ltot;
}
double UDrawing::GetLastSegmentLengthStraight(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetLastSegmentLengthStraight(). Object NULL or erroneous. \n");
        return 0.;
    }
    
    if(Npoints<1)      return 0.;
    if(EdgeList==NULL) return 0.;

    int NeBac   = 0;
    for(int ie=Nedge-1; ie>=0; ie--)
    {
        if(EdgeList[2*ie  ]!=Npoints-NeBac-1 &&
           EdgeList[2*ie+1]!=Npoints-NeBac-1)    return (p[Npoints-NeBac-1]-p[Npoints-1]).GetNorm();
        NeBac++;
    }
    return (p[0]-p[Npoints-1]).GetNorm();
}
double UDrawing::GetLastSegmentLengthCurved() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: GetLastSegmentLengthCurved(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Npoints<1)      return 0.;
    if(EdgeList==NULL) return 0.;

    double Dist  = 0.;
    int    NeBac = 0 ;
    for(int ie=Nedge-1; ie>=0; ie--)
    {
        if(EdgeList[2*ie  ]!=Npoints-NeBac-1 &&
           EdgeList[2*ie+1]!=Npoints-NeBac-1)    return Dist; 

        UVector3 p1 = p[EdgeList[2*ie  ]];
        UVector3 p2 = p[EdgeList[2*ie+1]];
        Dist       += (p1-p2).GetNorm();
        NeBac++;
    }
    return Dist;
}

ErrorType UDrawing::DeleteLastSegment(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::DeleteLastSegment(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Npoints<1)      return U_OK;
    if(EdgeList==NULL) return U_ERROR;

    int NpRem = 1;
    int NeRem = 0;
    for(int ie=Nedge-1; ie>=0; ie--)
    {
        if(EdgeList[2*ie  ]!=Npoints-NpRem &&
           EdgeList[2*ie+1]!=Npoints-NpRem)   break;
        NpRem++;
        NeRem++;
    }
    Npoints -= NpRem;
    Nedge   -= NeRem;

    InvalidateKDTree();
    return U_OK;
}

ErrorType UDrawing::CloseLastSegment(void)
{
    if(Npoints<1) return U_OK;
    if(EdgeList==NULL) return U_ERROR;

    int NeBac = 0;
    for(int ie=Nedge-1; ie>=0; ie--)
    {
        if(EdgeList[2*ie  ]!=Npoints-NeBac-1 &&
           EdgeList[2*ie+1]!=Npoints-NeBac-1)   
        {
            return AddEdge(Npoints-1,Npoints-NeBac-1);
        }
        NeBac++;
    }
    return AddEdge(Npoints-1,0);
}
double UDrawing::GetProjectedArea(int dir) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(p==NULL || Npoints<2) return 0.;
    if(dir<0 || dir>2)
    {
        CI.AddToLog("ERROR: UDrawing::GetEdge(). Direction parameter out of range: %d .\n", dir);
        return 0.;
    }

    double Area = 0;
    for(int n=0; n<Npoints; n++)
    {
        int nn = (n+1)%Npoints;
        Area  += ::GetDeterminant(p[n].Project(dir), p[nn].Project(dir));
    }
    return Area/2.;
}

ErrorType UDrawing::GetEdge(int Iedge, UVector3* p1, UVector3* p2) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(EdgeList==NULL || p==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetEdge(). Points or edges not set. \n");
        return U_ERROR;
    }
    if(Iedge<0 || Iedge>=Nedge)
    {
        CI.AddToLog("ERROR: UDrawing::GetEdge(). Edge index out of range: Iedge=%d, Nedge=%d . \n",Iedge, Nedge);
        return U_ERROR;
    }
    if(p1==NULL || p2==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::GetEdge(). Invalid NULL pointer arguments. \n");
        return U_ERROR;
    }
    int i1 = EdgeList[2*Iedge  ];
    int i2 = EdgeList[2*Iedge+1];
    if(i1<0 || i1>=Npoints ||
       i2<0 || i2>=Npoints)
    {
        CI.AddToLog("ERROR: UDrawing::GetEdge(). Edge indeces out of range: i1=%d, i2=%d. \n", i1,i2);
        return U_ERROR;
    }
    *p1 = p[i1];
    *p2 = p[i2];
    return U_OK;
}

bool UDrawing::InContour(UVector3 view) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::InContour(). Object NULL or erroneous.\n");
        return false;
    }
    if(p==NULL || EdgeList==NULL) return false;

    double omeg = 0.;
    int    ip0  =-1;
    int    ip1  =-1;
    int    ips  =-1; // Start point
    for(int i=0; i<Nedge; i++)
    {
        if(ip0<0 || ip1<0)
        {
            ip0 = EdgeList[2*i  ];
            ip1 = EdgeList[2*i+1];
            ips = ip0;
        }
        else
        {
            if(ip0==EdgeList[2*i  ] || 
               ip1==EdgeList[2*i+1])    {ip0=EdgeList[2*i+1]; ip1=EdgeList[2*i  ];}
            else                        {ip0=EdgeList[2*i  ]; ip1=EdgeList[2*i+1];}
        }
        UVector3  y0; 
        UVector3  y1;
        if(GetEdge(i, &y0, &y1)!=U_OK)
        {
            CI.AddToLog("ERROR: UDrawing::InContour(). Getting Edge. \n");
            return false;
        }
        y0       -= view;
        y1       -= view;
        double d0 = y0.GetNorm();
        double d1 = y1.GetNorm();
        if(d0==0. || d1==0.) return false; // On contour
        
        omeg  += acos((y0&y1)/(d0*d1));
        if(ip1==ips)
        {
            if( (int) floor(.00002+omeg/PI2) ) return true;
            ip0  = -1;
            ip1  = -1;
            ips  = -1;
            omeg = 0.;
        }
    }    
    return false;
}

bool UDrawing::InContour(UVector3 view, int OrthoPlane) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::InContour(). Object NULL or erroneous.\n");
        return false;
    }
    if(OrthoPlane<0 || OrthoPlane>=3)
    {
        CI.AddToLog("ERROR: UDrawing::InContour(). OrthoPlane (=%d) out of range.\n", OrthoPlane);
        return false;
    }
    if(p==NULL || EdgeList==NULL) return false;

    int       NpCon = 0;
    UVector2* Cont  = Get2DContour(OrthoPlane, &NpCon);
    if(Cont==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::InContour(). Gettng contour from drawing. \n");
        return false;
    }
    
    UVector2 V    = view.Project(OrthoPlane);
    int      Wind = 0;
    UVector2 Vold = Cont[NpCon-1];
    for(int n=0; n<NpCon; n++)
    {
        UVector2 Vnew = Cont[n];
        if(Vold.Gety() < V.Gety() && V.Gety() <= Vnew.Gety())   
        {
            if(GetDeterminant(Vold-V, Vnew-V)>0) Wind++;
        }
        else if(Vnew.Gety() < V.Gety()  && V.Gety() <= Vold.Gety())
        {
            if(GetDeterminant(Vold-V, Vnew-V)<0) Wind--;
        }
        Vold = Cont[n];
    }
    delete[] Cont;

    if(abs(Wind)%2 ==1) return true;
    return false;
}

UVector2* UDrawing::Get2DContour(int OrthoPlane, int*Np) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::Get2DContour(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(OrthoPlane<0 || OrthoPlane>=3)
    {
        CI.AddToLog("ERROR: UDrawing::Get2DContour(). OrthoPlane (=%d) out of range.\n", OrthoPlane);
        return NULL;
    }
    if(p==NULL || EdgeList==NULL || Nedge<=1 || Npoints<=1) 
    {
        if(Np) *Np = 0;
        return NULL;
    }

    bool   Forward  = (EdgeList[1]==EdgeList[2]);
    int    ip0      = EdgeList[0];
    int    ip1      = EdgeList[1];
    int    ips      = ip1; // Start point
    if(Forward) ips = ip0;
    int    NpCon    = 1;
    for(int i=1; i<Nedge; i++)
    {
        ip0 = EdgeList[2*i  ];
        ip1 = EdgeList[2*i+1];
        NpCon++;
        if(Forward)   
        {
            if(ip1==ips) break;
        } 
        else
        {
            if(ip0==ips) break;
        }  
    }
    
    UVector2* Points2D = new UVector2[NpCon];
    if(Points2D==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::Get2DContour(). Memory allocation, (NpCon=%d).\n", NpCon);
        return NULL;
    }
    if(Np) *Np = NpCon;

    ip0    = EdgeList[0];
    ip1    = EdgeList[1];
    ips    = ip1; 
    if(Forward) ips = ip0;
    int ic = 0;
    for(int i=1; i<Nedge+1; i++)
    {
        Points2D[ic] = p[ips].Project(OrthoPlane); ic++;
        if(ic==NpCon) break;
        if(i ==Nedge) break;

        ip0             = EdgeList[2*i  ];
        ip1             = EdgeList[2*i+1];
        if(Forward) ips = ip0;
        else        ips = ip1;
    }
    return Points2D;
}
ErrorType UDrawing::ResampleCurve(int NPcont, bool ReverseOrder)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::ResampleCurve(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::ResampleCurve(). Object not properly set. \n");
        return U_ERROR;
    }
    if(NPcont<=1)
    {
        CI.AddToLog("ERROR: UDrawing::ResampleCurve(). NPcont parameter out of range (=%d). \n", NPcont);
        return U_ERROR;
    }
    UInterpolateCircle IC(p, Npoints, ReverseOrder);
    UVector3* pNew = new UVector3[NPcont];
    if(IC.GetError()!=U_OK||pNew==NULL)
    {
        delete[] pNew;
        CI.AddToLog("ERROR: UDrawing::ResampleCurve(). Creating interpolation object or memory allocation, (NPcont =%d). \n", NPcont);
        return U_ERROR;
    }
    for(int n=0; n<NPcont; n++) pNew[n] = IC.GetInterpolVector3(n/(double)NPcont);
    
    delete[] p;        p        = pNew; Npoints = NPcont; NpointsAllocated = NPcont;
    delete[] EdgeList; EdgeList = 0;    Nedge   = 0;      NedgeAlloc       = 0;
    for(int n=0; n<NPcont; n++) AddEdge(n,(n+1)%NPcont);
    return U_OK;
}
ErrorType UDrawing::WriteVTK(UFileName FileName, ULinTran XFM, double Radius, double RelTubRatio) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Object not properly set (File = %s). \n", (const char*)FileName);
        return U_ERROR;
    }
    if(Radius<=0.)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Radius parameter out of range (=%f). \n", Radius);
        return U_ERROR;
    }
    USurface S(Radius, 1);
    const int* TrilS =S.GetTriList();
    if(S.GetError()!=U_OK || TrilS==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Creating base sphere.\n");
        return U_ERROR;
    }
    int NPS = S.GetNpoints();
    int NTS = S.GetNtri();

    double TubRad = RelTubRatio<=0.?Radius/2:Radius*RelTubRatio;
    USurface T(UVector3(), UVector3(0.,0.,1.), TubRad, 6, false);
    const int* TrilT =T.GetTriList();
    if(T.GetError()!=U_OK || TrilT==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Creating base tube.\n");
        return U_ERROR;
    }
    int NPT = RelTubRatio<=0. ? 0:T.GetNpoints();
    int NTT = RelTubRatio<=0. ? 0:T.GetNtri();

    UFileName FileVTK(FileName);  FileVTK.SetExtension("vtk");

    FILE* fpV = fopen(FileVTK, "wb", false);
    if(fpV==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteVTK(). Cannot open points file (%s) .\n", (const char*)FileVTK);
        return U_ERROR;
    }

    UString Prop = CI.GetProperties(NULL);
    Prop.Truncate(250);
    Prop.RemoveNewLines(false);
    fprintf(fpV, "# vtk DataFile Version 3.0\n");
    fprintf(fpV, "%s\n",(const char*)Prop);
    fprintf(fpV, "BINARY\n");
    fprintf(fpV, "DATASET POLYDATA\n");
    fprintf(fpV, "POINTS %d float\n", NPT*Nedge+NPS*Npoints);
    if(RelTubRatio>=0.)
    {
        for(int n=0; n<Nedge; n++)
        {
            UVector3 pXFM1 = XFM.xfm(p[EdgeList[2*n  ]]);
            UVector3 pXFM2 = XFM.xfm(p[EdgeList[2*n+1]]);

            USurface T(pXFM1, pXFM2, TubRad, 6, false);
            for(int m=0; m<NPT; m++)
            {
                UVector3 Q = UPointList(T).GetPoint(m);
                ::WriteBinary(float(10.*Q.Getx()), false, fpV);
                ::WriteBinary(float(10.*Q.Gety()), false, fpV);
                ::WriteBinary(float(10.*Q.Getz()), false, fpV);
            }
        }
    }
    for(int n=0; n<Npoints; n++)
    {
        UVector3 pXFM = XFM.xfm(p[n]);

        for(int m=0; m<NPS; m++)
        {
            UVector3 Q = pXFM + UPointList(S).GetPoint(m);
            ::WriteBinary(float(10.*Q.Getx()), false, fpV);
            ::WriteBinary(float(10.*Q.Gety()), false, fpV);
            ::WriteBinary(float(10.*Q.Getz()), false, fpV);
        }
    }
    fprintf(fpV, "POLYGONS %d %d\n", NTT*Nedge+NTS*Npoints, 4*(NTT*Nedge+NTS*Npoints));
    if(RelTubRatio>=0.)
    {
        for(int n=0; n<Nedge; n++)
        {
            for(int m=0; m<NTT; m++)
            {
                int ind[4] = {3, n*NPT+TrilT[3*m  ], n*NPT+TrilT[3*m+1], n*NPT+TrilT[3*m+2]};
                ::WriteBinary(ind, 4, false, fpV);
            }
        }
    }
    for(int n=0; n<Npoints; n++)
    {
        for(int m=0; m<NTS; m++)
        {
            int ind[4] = {3, NPT*Nedge+n*NPS+TrilS[3*m  ], NPT*Nedge+n*NPS+TrilS[3*m+1], NPT*Nedge+n*NPS+TrilS[3*m+2]};
            ::WriteBinary(ind, 4, false, fpV);
        }
    }
    fclose(fpV);
    return U_OK;
}
ErrorType UDrawing::WriteMatLab(UFileName Fname, bool NumberSegments)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::WriteMatLab(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteMatLab(). Object not properly set. \n");
        return U_ERROR;
    }
    
    if(NumberSegments)
    {
        int   iseg   = 0;
        bool  NewSeg = true;
        FILE* fpP    = NULL;
        UFileName FPoints;
        for(int ie=0; ie<Nedge; ie++)
        {
            if(NewSeg==true)
            {
                FPoints =UFileName(Fname);  
                FPoints.InsertFileNumber(iseg, 3);
                fpP = fopen(FPoints, "wt", false);
            }
            if(fpP==NULL) 
            {
                CI.AddToLog("ERROR: UDrawing::WriteMatLab(). Cannot open points file (%s) .\n", (const char*)FPoints);
                return U_ERROR;
            }
            int ip0  = EdgeList[2*ie  ];
            int ip1  = EdgeList[2*ie+1];
            if(ie==Nedge-1)
            {
                fprintf(fpP,"%f \t%f \t%f\n", p[ip0].Getx(), p[ip0].Gety(),p[ip0].Getz() );
                fprintf(fpP,"%f \t%f \t%f\n", p[ip1].Getx(), p[ip1].Gety(),p[ip1].Getz() );
                fclose(fpP);
                break;
            }
            int ip2  = EdgeList[2*ie+2];
            int ip3  = EdgeList[2*ie+3];
            if(ip0==ip3 || ip0==ip2)
            {
                fprintf(fpP,"%f \t%f \t%f\n", p[ip1].Getx(), p[ip1].Gety(),p[ip1].Getz() );
                NewSeg   = false;
            }
            else if(ip1==ip2 || ip1==ip3)
            {
                fprintf(fpP,"%f \t%f \t%f\n", p[ip0].Getx(), p[ip0].Gety(),p[ip0].Getz() );
                NewSeg   = false;
            }
            else
            {
                fprintf(fpP,"%f \t%f \t%f\n", p[ip0].Getx(), p[ip0].Gety(),p[ip0].Getz() );
                fprintf(fpP,"%f \t%f \t%f\n", p[ip1].Getx(), p[ip1].Gety(),p[ip1].Getz() );
                fclose(fpP);
                NewSeg   = true;
                iseg++;
                continue;
            }
        }
        return U_OK;
    }
    else
    {
        UFileName FPoints(Fname);  
        FILE* fpP = fopen(FPoints, "wt", false);
        if(fpP==NULL) 
        {
            CI.AddToLog("ERROR: UDrawing::WriteMatLab(). Cannot open points file (%s) .\n", (const char*)FPoints);
            return U_ERROR;
        }
        for(int n=0; n<Npoints; n++)
            fprintf(fpP,"%f \t%f \t%f\n", p[n].Getx(), p[n].Gety(),p[n].Getz() );
        fclose(fpP);
    }
    return U_OK;
}
ErrorType UDrawing::WriteXDR(UFileName Fname, const UEuler* Xfm, const char* Comment) const
/*
    Export Surface in AVS XDR-format, using the Conquest viewer naming conventions.
    
    *Fname is the full file name wherein the data is stored. Extensions are dded when required

    if(Xfm) the transformation Xfm will be applied to the exported points
    else    the points will be exported as they are
 */
{
    if(&Fname==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteXDR(). NULL argument. \n");
        return U_ERROR;
    }

/* Create and write the points file-file*/
    UField PointsField(p, Npoints);
    if(Xfm) PointsField.xfm(*Xfm);

    UFileName DrawFile(Fname);
    DrawFile.ReplaceExtension("dwp");
    if(PointsField.WriteXDR(DrawFile.GetFullFileName(), GetProperties("// "), Comment) !=U_OK)
    {
        CI.AddToLog("ERROR UDrawing::WriteXDR(). Cannot write points file in: %s .\n",DrawFile.GetFullFileName());
        return U_ERROR;
    }
    
/* Create and write the index file-file*/
    UField IndexField(EdgeList, Nedge, 2, true);

    DrawFile.ReplaceExtension("DWI");
    if(IndexField.WriteXDR(DrawFile.GetFullFileName(), GetProperties("// "), Comment) !=U_OK)
    {
        CI.AddToLog("ERROR UDrawing::WriteXDR(). Cannot write points file in: %s  .\n",DrawFile.GetFullFileName());
        return U_ERROR;
    }

    return U_OK;
}
ErrorType UDrawing::WriteXDR(UPatTree* XDRdir, const char* Fname, const UEuler* Xfm, const char* Comment)
/*
    Export Surface in AVS XDR-format, using the Conquest viewer naming conventions.
    
    *XDRdir is considered as the directory name where the data are to be stored.

    if(Xfm) the transformation Xfm will be applied to the exported points
    else    the points will be exported as they are
 */
{
    if(XDRdir==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::WriteXDR(). NULL argument. \n");
        return U_ERROR;
    }
    const char* FileName = NULL;
    if(Fname) FileName = Fname;
    else      FileName = (const char*)Name;
    if(FileName==NULL || FileName[0]==0)
    {
        CI.AddToLog("ERROR: UDrawing::WriteXDR(). No appropriate file name. \n");
        return U_ERROR;
    }

/* Create and write the points file-file*/
    UField PointsField(p, Npoints);
    if(Xfm) PointsField.xfm(*Xfm);

    UFileName DrawFile(XDRdir->GetDirectoryName(), FileName);
    DrawFile.ReplaceExtension("dwp");
    if(PointsField.WriteXDR(DrawFile.GetFullFileName(), GetProperties("// "), Comment) !=U_OK)
    {
        CI.AddToLog("ERROR UDrawing::WriteXDR(). Cannot write points file in: %s  .\n",XDRdir->GetDirectoryName());
        return U_ERROR;
    }
    
/* Create and write the index file-file*/
    UField IndexField(EdgeList, Nedge, 2, true);

    DrawFile.ReplaceExtension("DWI");
    if(IndexField.WriteXDR(DrawFile.GetFullFileName(), GetProperties("// "), Comment) !=U_OK)
    {
        CI.AddToLog("ERROR UDrawing::WriteXDR(). Cannot write points file in: %s   .\n",XDRdir->GetDirectoryName());
        return U_ERROR;
    }

    return U_OK;
}
ErrorType UDrawing::WriteASCII(const char* FileName)
{
    FILE* fp = NULL;
    if(FileName) fp = fopen(FileName, "wt");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UDrawing::WriteASCII(). Cannot open %s .\n", FileName);
        return U_ERROR;
    }

    UString Prop = GetProperties("//");
    fprintf(fp, "%s", (const char*)Prop);

    fprintf(fp,"Npoints = %d\n",Npoints);
    for(int n=0; n<Npoints; n++)
        fprintf(fp,"%f \t%f \t%f \n", p[n].Getx(), p[n].Gety(),p[n].Getz() );

    fprintf(fp,"Nedge = %d\n",Nedge);
    for(int i=0; i<Nedge; i++)
        fprintf(fp,"%d \t%d \n", EdgeList[2*i+0], EdgeList[2*i+1]);

    fclose(fp);
    return U_OK;
}

ErrorType UDrawing::SetName(const char*name)
{
    if(this==NULL) return U_ERROR;
    Name = UString(name);
    return U_OK;
}

const UString& UDrawing::GetProperties(UString Comment) const
{
    if(this==NULL||error!=U_OK) 
    {
        Properties = UString("ERROR: UDrawing::GetProperties(). Object erroneous");
        return Properties;
    }

    Properties = UString((const char*)Name, " Name        =  %s \n")
               + UString(Nedge,             " Nedges      =  %d \n")
               + UString(NedgeAlloc,        " NedgesAlloc =  %d \n")
               + UString(Npoints,           " Npoints     =  %d \n");
    Properties += UString(UPointList::GetMinx().GetProperties(), " MinBound    =  %s \n")
                + UString(UPointList::GetMaxx().GetProperties(), " MaxBound    =  %s \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');  
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UDrawing::Concatenate(const UDrawing* D)
/*
     Concatenate *this drawing and *D, DO NOT SKIP points and edges that
     may occur double in the the merged arrays.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::Concatenate(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(D==NULL || D->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::Concatenate(). Erroneous drawing argument. \n");
        return U_ERROR;
    }
    int NpOld = Npoints;
    if(UPointList::Concatenate((const UPointList*)D)!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::Concatenate(). Concatenating points. \n");
        return U_ERROR;
    }
    int NnewEdge = Nedge   + D->Nedge;
    if(NnewEdge>NedgeAlloc)
    {
        int* Enew  = new int[2*NnewEdge];
        if(Enew==NULL)
        {
            CI.AddToLog("ERROR: UDrawing::Concatenate(). Memory allocation. NnewEdge=%d\n",NnewEdge);
            return U_ERROR;
        }
        for(int i=0;i<2*Nedge;i++) Enew[i] = EdgeList[i];
        delete[] EdgeList; EdgeList = Enew;
        NedgeAlloc = NnewEdge;
    }

/* Merge the points and edges arrays */
    for(int id=0,i=2*Nedge;id<2*D->Nedge;id++, i++)
        EdgeList[i] = D->EdgeList[id] + NpOld;

    Nedge = NnewEdge;
    
    return U_OK;
}

ErrorType UDrawing::AddPoint(UVector3 NewP, bool ConnectEdge)
{
    if(UPointList::AddPoint(NewP)!=U_OK)
    {
        CI.AddToLog("ERROR: UDrawing::AddPoint(). Adding new point to base class. \n");
        return U_ERROR;
    }
    if(ConnectEdge==true)
        return AddEdge(Npoints-2, Npoints-1);

    return U_OK;
}

ErrorType UDrawing::AddEdge(int ind0, int ind1)
{
    if(ind0<0 || ind0>=Npoints ||
       ind1<0 || ind1>=Npoints)
    {
        CI.AddToLog("ERROR: UDrawing::AddEdge(). Indices out of range: ind0=%d, ind1=%d and Npoints = %d \n", ind0, ind1, Npoints);
        return U_ERROR;
    }

    if(NedgeAlloc-Nedge<2) // Allocate new memory for new edge
    {
        int NewNedgeAlloc = 2*NedgeAlloc+2;
        if(NewNedgeAlloc<100)   NewNedgeAlloc = 100;
        if(NewNedgeAlloc>10000) NewNedgeAlloc = NedgeAlloc+10000; 
        int* edgeNew = new int[2*NewNedgeAlloc];
        if(edgeNew==NULL)
        {
            CI.AddToLog("ERROR: USurface::AddEdge(). Memory allocation. NedgeAlloc = %d, NewAllocated = %d  .\n", NedgeAlloc, NewNedgeAlloc);
            return U_ERROR;
        }
        for(int n=0; n<2*Nedge; n++) edgeNew[n] = EdgeList[n];
        delete[] EdgeList;  EdgeList = edgeNew;
        NedgeAlloc = NewNedgeAlloc;
    }
    EdgeList[2*Nedge  ] = ind0;
    EdgeList[2*Nedge+1] = ind1;
    Nedge++;
    return U_OK;
}

UDrawing** UDrawing::SplitPlanes(int* NComp, double Tol, UVector3* Normal, bool Resample, int MeanNPPCont) const
{
    if(this==NULL || error!=U_OK) return NULL;

    if(p==NULL || Npoints<=0)
    {
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Points not properly set. \n");
        return NULL;
    }
    if(NComp==NULL||Tol<=0.||Normal==NULL)
    {
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Invalid NULL parameter(s) or Tol = %f out of range. \n", Tol);
        return NULL;
    }
    if(Resample && MeanNPPCont<3)
    {
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). MeanNPPCont = %d out of range. \n", MeanNPPCont);
        return NULL;
    }

    UPointList** PLL      = UPointList::SplitPlanes(NComp, Tol, Normal);
    if(PLL==NULL|| NComp<=0)
    {
        delete[] PLL;
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Splitting into point planes using base class. \n");
        return NULL;
    }
    double* ZOff = new double[*NComp];
    if(ZOff==NULL)
    {
        delete[] ZOff;
        for(int ic=0; ic<*NComp; ic++) delete PLL[ic]; delete[] PLL;
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Memory allocation. \n");
        return NULL;
    }
    for(int ic=0; ic<*NComp; ic++) 
    {
        UVector3 N;
        double   O;
        PLL[ic]->FitPlane(&N, &O);
        ZOff[ic] = (N.operator&(*Normal)>0.) ? O : -O;
    }

    int* Index    = GetOrderIndexArray(ZOff, *NComp, false, false);
    int* CumI     = new int[*NComp];
    int* Ncon     = new int[Npoints];
    UDrawing** DL = new UDrawing*[*NComp];
    if(Index==NULL||CumI==NULL||Ncon==NULL||DL==NULL)
    {
        for(int ic=0; ic<*NComp; ic++) delete PLL[ic]; delete[] PLL;
        delete[] ZOff; delete[] Index; delete[] CumI; delete[] Ncon; delete[] DL; 
        CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Ordering contours or memory allocation. \n");
        return NULL;
    }
    for(int ic=0; ic<*NComp ; ic++) {DL[ic]   = NULL; CumI[ic]=0;}
    for(int ic=1; ic<*NComp ; ic++)  CumI[ic] = CumI[ic-1]+PLL[ic-1]->GetNpoints();
    for(int ip=0; ip<Npoints; ip++)  Ncon[ip] = 0;
    for(int  m=0;  m<Nedge  ;  m++) {Ncon[EdgeList[2*m]]++; Ncon[EdgeList[2*m+1]]++;}


    int NDraw = 0;
    int IpOff = CumI[Index[0]];
    DL[0]     = new UDrawing();
    for(int ip=0; ip<PLL[Index[0]]->GetNpoints(); ip++) DL[0]->AddPoint(PLL[Index[0]]->GetPoint(ip),ip>0 && (Ncon[IpOff+ip]==2||Ncon[IpOff+ip-1]==2));
    for(int ic=1; ic<*NComp; ic++)
    {
        if(fabs(ZOff[Index[ic]]-ZOff[Index[ic-1]])>1.e-3) NDraw++;

        if(DL[NDraw]==NULL) DL[NDraw] = new UDrawing();
        UPointList* PL = PLL[Index[ic]];
        int IpOff      = CumI[Index[ic]];
        for(int ip=0; ip<PL->GetNpoints(); ip++) DL[NDraw]->AddPoint(PL->GetPoint(ip),ip>0 && (Ncon[IpOff+ip]==2||Ncon[IpOff+ip-1]==2));
    }
    for(int ic=0; ic<*NComp; ic++) delete PLL[ic]; delete[] PLL;
    delete[] ZOff; delete[] Index; delete[] CumI; delete[] Ncon;

     NDraw++;
    *NComp = NDraw;
    for(int k=0; k<NDraw; k++) DL[k]->ReorderSegments();

    if(Resample)
    {
        int Ntot = NDraw * MeanNPPCont;
        
        double Ltot = 0.;
        for(int k=0; k<NDraw; k++) Ltot += DL[k]->GetTotalLength();
        if(Ltot>0.)
        {
            for(int k=0; k<NDraw; k++)
            {
                int NPcont = int(0.5 + Ntot * DL[k]->GetTotalLength()/Ltot);
                DL[k]->ResampleCurve(MAX(3, NPcont), true);
            }
        }
        else
            CI.AddToLog("ERROR: UDrawing::SplitPlanes(). Total length = %f. \n", Ltot);
    }
    return DL;
}
ErrorType UDrawing::ReorderSegments()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(p==NULL || Npoints<=0 || EdgeList==NULL || Nedge<=0)
    {
        CI.AddToLog("UDrawing::ReorderSegments(). Points/edges not properly set. \n");
        return U_ERROR;
    }

/* Detect connected components */
    int* PClass = NULL;
    int  Nsegm  = 0;
    int* EquiP  = GetPointsComponents(&Nsegm, &PClass);
    int* EquiE  = new int[Nedge];
    if(EquiP==NULL||EquiE==NULL||PClass==NULL|| Nsegm<=0)
    {
        delete[] EquiP; delete[] EquiE; delete[] PClass;
        CI.AddToLog("UDrawing::ReorderSegments(). Getting equivalent points (Nsegm=%d). \n", Nsegm);
        return U_ERROR;
    }
    if(Nsegm==1)
    {
        delete[] EquiP; delete[] EquiE; delete[] PClass;
        return U_OK;
    }
    for(int m=0; m<Nedge; m++) EquiE[m] = EquiP[EdgeList[2*m]];

    int*  Ib = Nsegm>0 ? new int[Nsegm] : NULL;
    int*  Ie = Nsegm>0 ? new int[Nsegm] : NULL;
    if(Ib==NULL||Ie==NULL)
    {
        delete[] EquiP; delete[] EquiE; delete[] PClass;
        delete[] Ib; delete[] Ie;
        CI.AddToLog("UDrawing::ReorderSegments(). Memory allocation, Nsegm=%d \n", Nsegm);
        return U_ERROR;
    }

/* Test whether components consist of segments points (not closed contour) */
    int* Buffer = EquiP;
    for(int k=0; k<Nsegm; k++)
    {
        for(int n=0; n<Npoints; n++) Buffer[n]=0;
        for(int m=0; m<Nedge; m++)
        {
            if(PClass[k]!=EquiE[m]) continue;
            Buffer[EdgeList[2*m  ]]++;
            Buffer[EdgeList[2*m+1]]++;
        }
        Ib[k] = Ie[k] = -1;
        for(int n=0; n<Npoints; n++) 
        {
            if(Buffer[n]==0) continue;
            if(Buffer[n]==1)
            {
                if(Ib[k]==-1)      Ib[k] = n;
                else if(Ie[k]==-1) Ie[k] = n;
                else               Ib[k] = Ie[k] = -2;
            }
        }
        if(Ib[k]<0||Ie[k]<0)
        {
            CI.AddToLog("UDrawing::ReorderSegments(). Component %d is not an open segment, \n", k);
            delete[] EquiP; delete[] EquiE;
            delete[] Ib; delete[] Ie;
            return U_ERROR;
        }
    }
    delete[] EquiP; delete[] EquiE; delete[] PClass;

    UVector3* Pcopy = new UVector3[NpointsAllocated];
    int*      Ecopy = new int[2*NedgeAlloc];
    bool*     Done  = new bool[Nsegm];
    if(Pcopy==NULL||Ecopy==NULL||Done==NULL)
    {
        delete[] Done; delete[] Ecopy; delete[] Pcopy;
        CI.AddToLog("UDrawing::ReorderSegments(). Memory allocation, Npoints=%d \n", Npoints);
        return U_ERROR;
    }
    for(int is=0; is<Nsegm; is++) Done[is] = false;

/* Concatenate each string in right order according to smallest distance to next one */
    bool      Forw    = false;
    int       iseg    = 0;
    UVector3* pNew    = Pcopy;
    int*      eNew    = Ecopy;
    int       NewEInd = 0;
    double    TotJmp  = 0.;
    for(int is1=0; is1<Nsegm; is1++)
    {
        if(Forw)   for(int n=0; n<=Ie[iseg]-Ib[iseg]; n++) *pNew++ = p[Ib[iseg]+n];
        else       for(int n=0; n<=Ie[iseg]-Ib[iseg]; n++) *pNew++ = p[Ie[iseg]-n];
        for(int n=0; n<Ie[iseg]-Ib[iseg]; n++) {*eNew++ = NewEInd+n; *eNew++ = NewEInd+n+1;}
        Done[iseg]  = true;
        NewEInd    += Ie[iseg]-Ib[iseg]+1;
        if(is1==Nsegm-1) TotJmp += (Pcopy[0]- *(pNew-1)).GetNorm();

        int    iend  = Forw ? Ie[iseg] : Ib[iseg];
        int    ibest = -1;
        double Best  = 0.;
        for(int is2=0; is2<Nsegm; is2++)
        {
            if(Done[is2]) continue;
            if(is2==iseg) continue;

            double TestF = (p[iend]-p[Ib[is2]]).GetNorm();
            if(TestF<Best || ibest<0) 
            {
                Best = TestF; ibest=is2; Forw = true;
            }
            double TestB = (p[iend]-p[Ie[is2]]).GetNorm();
            if(TestB<Best || ibest<0)
            {
                Best = TestB; ibest=is2; Forw = false;
            }
        }
        iseg    = ibest;
        TotJmp += Best;
    }

    for(int n=0; n<Npoints; n++) p[n]        = Pcopy[n];
    for(int m=0; m<2*Nedge; m++) EdgeList[m] = Ecopy[m];

    delete[] Done; delete[] Ib; delete[] Ie; delete[] Pcopy; delete[] Ecopy;
    return U_OK;
}

ErrorType UDrawing::GetPlaneIntersection(UVector3 n, UVector3 s, double Tol, UVector3** EdgePoints, int* NedgeInt) const
/*
    Compute the intersection between *this drawing, and the plane given by n&x = n&s

    n           - normal vector of the plane
    s           - an arbitrary point on then plane
    *Edgepoints - a pointer (allocated here) containg the begin and en points of all
                  edges intersecting the plane. (The number of points allocated is 2* *Nedge
    *Nedge      - the number of intersecting edges.
 */
{
    if(this==NULL) return U_ERROR;
    if(error!=U_OK || p==NULL || EdgeList==NULL)
    {
        if(Npoints>0 && p==NULL       )  CI.AddToLog("UDrawing::GetPlaneIntersection(). Points not properly set. \n");
        else return U_OK;
        if(Nedge  >0 && EdgeList==NULL)  CI.AddToLog("UDrawing::GetPlaneIntersection(). Points not properly set. \n");
        else return U_OK;
        return U_ERROR;
    }
    if(EdgePoints==NULL || NedgeInt==NULL)
    {
        CI.AddToLog("UDrawing::GetPlaneIntersection(). Invalid NULL arguments. \n");
        return U_ERROR;
    }
    if(n.Normalize()<=1.e-5)
    {
        CI.AddToLog("UDrawing::GetPlaneIntersection(). Invalid normal vector (n=%s). \n", n.GetProperties());
        return U_ERROR;
    }

/* Determine projections of all points*/
    double* Mu   = new double[Npoints];
    int* EdgeInt = new int[Nedge];        // all possible edges
    if(Mu==NULL || EdgeInt==NULL)
    {
        delete[] Mu;
        delete[] EdgeInt;
        CI.AddToLog("UDrawing::GetPlaneIntersection(). Memory allocation for Mu or EdgeInt, Npoints = %d and Nedge = %d . \n", Npoints, Nedge);
        return U_ERROR;
    }
    for(int m=0; m<Npoints; m++)  Mu[m]      = n&(s-p[m]);
    for(int i=0; i<Nedge; i++)    EdgeInt[i] = -1;

/* Determine all edges that are completely inside the given plane */
    *NedgeInt = 0;
    for(int it=0; it<Nedge; it++)
    {
        double Mu0 = Mu[EdgeList[2*it+0]];
        double Mu1 = Mu[EdgeList[2*it+1]];
        if(fabs(Mu0)<Tol && fabs(Mu1)<Tol) /* Coindident edges must have both points inside the plane */
        {
            EdgeInt[*NedgeInt] = it;
            (*NedgeInt)++;
            continue;
        }
        if( (Mu0<0&&Mu1>0) || (Mu1<0&&Mu0>0) )
        {
            EdgeInt[*NedgeInt] = -it-1;
            (*NedgeInt)++;
            continue;
        }
    }

    if(*NedgeInt==0)  // Intersection is empty
    {
        delete[] Mu;
        delete[] EdgeInt;
        *EdgePoints = NULL;
        return U_OK;
    }

/* Determine and store intersections*/
    *EdgePoints = new UVector3[2* *NedgeInt];
    if(*EdgePoints==NULL)
    {
        delete[] Mu;
        delete[] NedgeInt;
        CI.AddToLog("UDrawing::GetPlaneIntersection(). Memory allocation for EdgePoints, *NedgeInt = %d . \n", *NedgeInt);
        *NedgeInt = 0;
        return U_ERROR;
    }

    UVector3 *pEP = *EdgePoints;
    for(int ied=0; ied<*NedgeInt; ied++)
    {
        int it = EdgeInt[ied];
        if(it>=0) // edge inside plane 
        {
            *pEP++ = p[EdgeList[2*it+0]];
            *pEP++ = p[EdgeList[2*it+1]];
        }
        else    // Crossing edge
        {
            it = -it-1;
            double Mu0 = Mu[EdgeList[2*it+0]];
            double Mu1 = Mu[EdgeList[2*it+1]];
            UVector3 Pcr = (Mu1/(Mu1-Mu0))*p[EdgeList[2*it+0]] - (Mu0/(Mu1-Mu0))*p[EdgeList[2*it+1]];
            *pEP++ = Pcr;
            *pEP++ = Pcr;
        }
    }
    delete[] Mu;

    delete[] EdgeInt;
    return U_OK;
}
