#ifndef _DRAWING_INCLUDED
#define _DRAWING_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include"PointList.h"
#include"PatTree.h"
#include"String.h"

class UTraceContour
{
public:
    UTraceContour(const UField* F2D, int LevelField);

    ErrorType     GetError(void) const {if(this) return error; return U_ERROR;}
    ErrorType     InitTracing(int*init_x, int*init_y);
    bool          ComputeNext(int*new_x , int*new_y);

protected:
    void          SetAllMembersDefault(void);
    void          DeleteAllMembers(ErrorType E);

private:
    ErrorType     error;
    int           Level;
    const int*    Idat;
    int           Ndimx;
    int           Ndimy;

    int           xInit;
    int           yInit;
    int           dirLast;

    bool          IsAtLevel(int x, int y);
    bool          IsNeigborAtLevel(int x, int y, int dir, int*new_x, int*new_y);
    int           GetNewDirAtLevel(int x, int y, int last_dir, int* new_x, int* new_y);
};

class DLL_IO UDrawing : public UPointList
{
public:
    UDrawing();
    UDrawing(const char* FileName);
    UDrawing(const UDrawing& d);
    UDrawing(const UVector3* plist, int np, const char* Name);
    UDrawing(const UField* F2D, int dir, double coord, int Level, const char* Name);
    UDrawing(const UField* F3D, int dir, int SliceStep, LevelType LT, int Level, const char* Name);

    ~UDrawing();
    UDrawing& operator=(const UDrawing &d);

    const UString&      GetProperties(UString Comment) const;
    ErrorType           GetError() const            {if(this) return error; return U_ERROR;}
    UString             GetName() const             {if(this) return Name;  return UString();} 
    ErrorType           SetName(const char*Name);

    ErrorType           DeleteLastSegment(void);
    ErrorType           CloseLastSegment(void);
    double              GetProjectedArea(int dir) const;

    int                 GetNedge() const             {return Nedge;}
    ErrorType           GetEdge(int Iedge, UVector3* p1, UVector3* p2) const;
    bool                InContour(UVector3 view) const;
    bool                InContour(UVector3 view, int OrthoPlane) const;
    UVector2*           Get2DContour(int OrthoPlane, int*Np) const;
    ErrorType           ResampleCurve(int NPcont, bool ReverseOrder);

    double              GetLastSegmentLengthStraight() const;
    double              GetLastSegmentLengthCurved() const;
    double              GetTotalLength() const;

    ErrorType           AddPoint(UVector3 NewP, bool ConnectEdge);
    ErrorType           AddPoint(double x, double y, double z, bool ConnectEdge) {return AddPoint(UVector3(x,y,z),ConnectEdge);}

    UDrawing**          SplitPlanes(int* NComp, double Tol, UVector3* Normal, bool Resample, int MeanNPPCont) const;
    ErrorType           ReorderSegments();
    ErrorType           GetPlaneIntersection(UVector3 n, UVector3 s, double Tol, UVector3** EdgePoints, int* NedgeInt) const;
    ErrorType           RemovePoints(UVector3 P, double Tol);
    ErrorType           RemoveDoublePoints(double Tol);
    ErrorType           Crop(UVector3 Minco, UVector3 Maxco);
    ErrorType           Concatenate(const UDrawing* D);
    ErrorType           MergeComponents(double DistThresh);
    int                 GetNComponents(void) const;
    UDrawing*           GetLargestComponent(int* NCompOld=NULL) const;
    UDrawing**          GetComponents(int* NComp) const;
    int*                GetPointsComponents(int* NComp, int** PClass=NULL) const;

    ErrorType           WriteVTK(UFileName FileName, ULinTran XFM, double Rad, double RelTubRatio=0.5) const;
    ErrorType           WriteMatLab(UFileName Fname, bool NumberSegments);
    ErrorType           WriteXDR(UFileName Fname, const UEuler* Xfm=NULL, const char* Comment=NULL) const;
    ErrorType           WriteXDR(UPatTree* XDRdirName, const char* Fname, const UEuler* Xfm=NULL, const char* Comment=NULL);
    ErrorType           WriteASCII(const char* FileName);
protected:
    UString             Name;       // Name of the Drawing (e.g. "Tumour1").
    int*                EdgeList;   // List with indices to the surface points, such that they form the drawings on each slice
    int                 Nedge;      // Number of edges (lines)

    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
private:    
    static UString      Properties;
    ErrorType           error;      // General error flag
    int                 NedgeAlloc; // Number of allocated edges

    ErrorType           AddEdge(int ind0, int ind1);
};


#endif// _DRAWING_INCLUDED
