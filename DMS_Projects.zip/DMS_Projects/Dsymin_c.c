#include <stddef.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>

#ifdef __cplusplus
extern "C" 
{
        int dsymin_c(double *amat, int n, int ndim, double *det);
}
#endif

int dsymin_c(double *amat, int n, int ndim, double *det)
/*
 Invert the positive symmetric matrix amat.
   
   *amat  : Symmetric matrix, positive definit
   n     : Mathematical dimension of the matrix
   ndim  : Physical dimension of amat, (as it is stored)
   *det  : Determinant of amat. If(det==NULL) no determinant is computed)

 return
       0 no errors
      -1 amat not positive
      -2 inconsistent dimensions
      -3 memory allocation error

   methode: Cholescky ontbinding                                     
*/

{  register int i,j,k;
   int    ierr,jd,kd;
   double dum;
   double *p=NULL,*h=NULL;
   
   if(n>ndim) return -2;

   p = (double*)malloc((int)n*sizeof(p[0]));
   h = (double*)malloc((int)n*sizeof(h[0]));
   if( h==NULL || p==NULL) {ierr = -3; goto error;}
   
   ierr  = 0;
   if(det) *det  = 1.;
   for(i=0;i<n;i++)
   {  
      for(j=i;j<n;j++)
      {  
         dum = amat[i+j*ndim];
         for(k=(i-1)*ndim;k>=0;k-=ndim) dum -= amat[j+k]*amat[i+k];

         if(i==j) 
         {  
            if(dum<=0.) {ierr = -1; goto error;} 
            p[i]  = sqrt(dum);
            if(det) *det *= p[i];
         } 
         else
            amat[j+i*ndim] = dum/p[i]; 
      }
   }
   if(det) *det = (*det)*(*det);
   
/*  amat=L*[L]T, nu zit L onder de hoofddiagonaal van amat. */
    for(i=0;i<n;i++)
    {
    
/*  Solve: Lh=ei    */
       for(k=0;k<n;k++) h[k]=0;
       for(k=i;k<n;k++) 
       {  
          if(k==i) h[k] = 1;
          for(j=i;j<k;j++) h[k] -= amat[k+j*ndim]*h[j];
          h[k] /= p[k];
       }   
   
/* Solve: [L]Tx a[i,j] = h[i], for j=0,...,i*/
       for(j=n-1;j>=i;j--)
       { 
          dum = h[j];
          jd  = j*ndim;
          kd  = (j+1)*ndim;
          for(k=j+1;k<n;k++) { dum -= amat[k+jd]*amat[i+kd]; kd+=ndim;}
          amat[i+j*ndim] = dum/p[j];
       } 
    }

/* Herstel het onderdriehoeksdeel van amat. */
 
error:   
   for(i=1;i<n;i++)
      for(j=0;j<i;j++) amat[i+j*ndim] = amat[j+i*ndim];

   if(p) free(p); 
   if(h) free(h);
   return ierr;
}
     
   
