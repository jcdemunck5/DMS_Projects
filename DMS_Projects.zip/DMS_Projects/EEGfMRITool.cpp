/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for correct EEG with fMRI scanning artefacts.                      */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    01-09-16   creation, derived from QMEEGToolCorrectfMRIArt.cpp
*/


#include "EEGfMRITool.h"
#include "Directory.h"
#include "FileName.h"
#include "MEEGDataWriteCTF.h"
#include "MEEGDataEpochs.h"
#include "MEEGDataBase.h"

#include "CTFDataSet.h"
#include "MarkerArray.h"
#include "Epochs.h"
#include "Grid.h"
#include "Interpolate.h"
#include "MatrixSparse.h"
#include "Partition.h"

static const double SLICETIMETHRESH    = 1.e-5;
static const int    MAXTOL_EQUIDISTANT = 20;

UString  UEEGfMRITool::Properties      = UString();

void UEEGfMRITool::SetAllMembersDefault(void)
{
    error                   = U_OK;
    OutputFile              = UFileName();

    CorrectEEG              = false;
    CorrectADC              = false;
    CorrectEKG              = false;

    CorrectVolumes          = false;
    iMarkVol                = -1;
    iMarkVolSkip            = -1;
    SkippedToZero           = true;
    VolSubGroups            = false;
    VolSubGroupSize         = 0;
    UsePartitionFile        = false;
    PartitionFile           = UFileName();

    ApplyLowPass3           = true;
    DownSamp                = false;
    DownSampFres            = 400.;

    CorrectSlices           = false;
    NSlices                 = -1;
    TimeToSlice             = 0.;
    SliceTime               = 0.;
    InterpolationType       = U_TIMESHIFT_FFT;
    IgnoreTimeShift         = false;

    CorrectRF               = false;
    WinRFFrom               =  0;
    WinRFTo                 = -1;
    CorrectRefLayer         = false;
    NcompRefLayer           =  0;
    BandRefLayerLow         =  -1.;
    BandRefLayerHigh        =  -1.;

    CorrectBCG              = false;
    NMarkEKG                =  0;
    for(int k=0; k<MAXEKGMARKERS; k++) EKGMarkers[k]=-1;
    WinEKGFrom              =  0;
    WinEKGTo                = -1;
    OverlappingArtifacts    = true;
    BCGOutlierFraction      = 0.05;
    AdaptEKGArtefactAmp     = false;
    ApplyBPFilter           = false;
    OutputBCGArt            = false;
    OutputAvBCG             = false;

    MergeLog                = false;
    MergeVolMarker          = UString();
    MergeLogFile            = UFileName();
    MergeLogNDummy          = 0;
}
void UEEGfMRITool::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}


UEEGfMRITool::UEEGfMRITool()
{
    SetAllMembersDefault();
}
UEEGfMRITool::~UEEGfMRITool()
{
    DeleteAllMembers(U_OK);
}

bool UEEGfMRITool::IsVolumeMarkerSet(void) const
{
    if(this==NULL) return false;
    if(TemplateData==NULL                              || TemplateData->GetError()!=U_OK                             ) return false;
    if(TemplateData->GetData()==NULL                   || TemplateData->GetData()->GetError()!=U_OK                  ) return false;
    if(TemplateData->GetData()->GetMarkerArray()==NULL || TemplateData->GetData()->GetMarkerArray()->GetError()!=U_OK) return false;

    if(iMarkVol<0) return false;
    return true;
}
double UEEGfMRITool::GetVolTime(void) const
{
    if(IsVolumeMarkerSet()==false) return 0.;
    
    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
    return MarkerArray->GetAverageTimeInterval(iMarkVol);
}
ErrorType UEEGfMRITool::SetTemplateData(const UMEEGDataEpochs* TemplData)
{
    TemplateData = NULL;
    if(TemplData &&
        (TemplData->GetError()!=U_OK ||
         TemplData->GetData()==NULL ||
         TemplData->GetData()->GetError()!=U_OK))
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetTemplateData(). Erroneous argument. \n");
        return U_ERROR;
    }
    TemplateData = TemplData;
    return U_OK;
}
ErrorType UEEGfMRITool::SetOutputDataFile(UFileName OutputFileName)
{
    if(TemplateData && OutputFileName.GetFullFileName()==OutputFileName.GetBaseName())
    {
        OutputFile = TemplateData->GetData()->GetDataFileName().GetSiblingFileName(OutputFileName);
    }
    else
        OutputFile = OutputFileName;
    return U_OK;
}
ErrorType UEEGfMRITool::SetVolumeMarker(UString VolName)
{
    if(TemplateData==NULL || TemplateData->GetData()==NULL || TemplateData->GetData()->GetMarkerArray()==NULL)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetVolumeMarker(). Data template not set, or data has no markers. \n");
        return U_ERROR;
    }
    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
    const UMarker*      Mark        = MarkerArray->GetMarker(VolName);
    if(Mark==NULL || Mark->GetError()!=U_OK || Mark->GetnSamples()<=0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetVolumeMarker(). Marker not present: %s. \n", (const char*)VolName);
        return U_ERROR;
    }
    iMarkVol = MarkerArray->GetMarkerIndex(VolName);
    if(iMarkVol<0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetVolumeMarker(). Marker index not found: %s. \n", (const char*)VolName);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UEEGfMRITool::SetCorrectVolumes(bool Apply, UString VolNameBAD, bool SetSkippedToZero)
{
    if(TemplateData==NULL || TemplateData->GetData()==NULL || TemplateData->GetData()->GetMarkerArray()==NULL) return U_ERROR;

    CorrectVolumes = false;
    if(Apply==true)
    {
        const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
        if(IsVolumeMarkerSet()==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectVolumes(). Volume marker not set. \n");
            return U_ERROR;
        }
        if(VolNameBAD.IsEmpty()==true) {iMarkVolSkip = -1;}
        else
        {
            iMarkVolSkip = MarkerArray->GetMarkerIndex(VolNameBAD);
            if(iMarkVolSkip<0)
            {
                CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectVolumes(). BADVolume marker not found: %d. \n", (const char*)VolNameBAD);
                return U_ERROR;
            }
        }
        CorrectVolumes = true;
        SkippedToZero  = SetSkippedToZero;
    }
    return U_OK;
}
ErrorType UEEGfMRITool::ApplySubGroups(bool Apply, int SizeSub)
{
    VolSubGroups     = false;
    if(Apply) 
    {
        if(CorrectVolumes==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::ApplySubGroups(). Volume correction not set. \n");
            return U_ERROR;
        }
        if(SizeSub<=1)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::ApplySubGroups(). SizeSub (=%d) out of range. \n", SizeSub);
            return U_ERROR;
        }
        VolSubGroupSize  = SizeSub;
        VolSubGroups     = true;
        UsePartitionFile = false;
    }
    return U_OK;
}
ErrorType UEEGfMRITool::ApplyPartionFile(bool Apply, UFileName PartFileName)
{
    UsePartitionFile  = false;
    if(Apply) 
    {
        if(CorrectVolumes==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::ApplyPartionFile(). Volume correction not set. \n");
            return U_ERROR;
        }
        if(PartFileName.DoesFileExist()==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::ApplyPartionFile(). Partition file does not exist: %s. \n", (const char*)PartFileName);
            return U_ERROR;
        }
        PartitionFile     = PartFileName;
        UsePartitionFile  = true;
        VolSubGroups      = false;
    }
    return U_OK;
}
ErrorType UEEGfMRITool::SetPostProcess(bool DownSample, double DownSampleFreq, bool ApplyLowPass)
{
    DownSamp      =  false;
    if(DownSample==false)
    {
        DownSampFres  =  0.;
        ApplyLowPass3 =  false;
        return U_OK;
    }
    if(CorrectVolumes==false && CorrectSlices==false && CorrectRF==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetPostProcess(). Volume correction not set. \n");
        return U_ERROR;
    }

    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetPostProcess(). Volume marker not set. \n");
        return U_ERROR;
    }
    DownSamp      = true;
    DownSampFres  = DownSampleFreq;
    ApplyLowPass3 = ApplyLowPass;
    return U_OK;
}
ErrorType UEEGfMRITool::CorrectDataTypes(bool CorEEG, bool CorADC, bool CorEKG)
{
    CorrectEEG = CorEEG;
    CorrectADC = CorADC;
    CorrectEKG = CorEKG;
    return U_OK;
}
ErrorType UEEGfMRITool::SetCorrectSlices(bool Apply, int NSli, double Tim2SLi, double SliTim, TimeShiftType Inter, bool IgnoreShift)
{
    CorrectSlices     = false;
    if(Apply==false)
    {
        NSlices           = -1;
        TimeToSlice       = 0.;
        SliceTime         = 0.;
        InterpolationType = U_TIMESHIFT_FFT;
        IgnoreTimeShift   = false;
        return U_OK;
    }
    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectSlices(). Volume marker not set. \n");
        return U_ERROR;
    }
    double VolTime = GetVolTime(); 
    if(NSli<=0 || Tim2SLi<=0. || SliTim<=0 || Tim2SLi+NSli*SliTim > VolTime)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectSlices(). Parameters out of range: NSli=%d, Tim2SLi=%f, SliTim=%f. \n",NSli,Tim2SLi,SliTim);
        return U_ERROR;
    }
    double SRate       = TemplateData->GetData()->GetSampleRate();
    int NsampEpoch     = TemplateData->GetData()->GetMarkerArray()->GetMinInterval(iMarkVol);
    int NsampSlice     = SliTim*SRate;
    int SliceOffSetMax = 1 + int(floor(Tim2SLi + (NSli-1)*SliTim)*SRate ); 
    if(SliceOffSetMax + NsampSlice>=NsampEpoch)
    {
        if(SliceOffSetMax + NsampSlice==NsampEpoch)
        {
            double NewTim2SLi = NsampEpoch- NsampSlice-(NSli-1)*SliTim*SRate-1.;
            CI.AddToLog("WARNING: UEEGfMRITool::SetCorrectSlices(). Rounding off TimeToSlice = %f to NewTimeToSlice = %f. \n", Tim2SLi, NewTim2SLi);
            Tim2SLi = NewTim2SLi;
        }
        else
        {
            CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectSlices(). Parameters out of range: NSli=%d, Tim2SLi=%f, SliTim=%f (after roundoff to samples). \n",NSli,Tim2SLi,SliTim);
            return U_ERROR;
        }
    }
    CorrectSlices     = true;
    NSlices           = NSli;
    TimeToSlice       = Tim2SLi;
    SliceTime         = SliTim;
    InterpolationType = Inter;
    IgnoreTimeShift   = IgnoreShift;
    return U_OK;
}

ErrorType UEEGfMRITool::SetCorrectRFPulse(bool Apply, int BeginSamp, int EndSamp)
{
    CorrectRF               = false;
    if(Apply==false)
    {
        WinRFFrom           = -1;
        WinRFTo             =  0;
        return U_OK;
    }
    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRFPulse(). Volume marker not set. \n");
        return U_ERROR;
    }
    if(NSlices<=0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRFPulse(). Invalid number of slices: NSlices = %d. \n", NSlices);
        return U_ERROR;
    }
    if(TimeToSlice<0. ||  SliceTime <= 0.)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRFPulse(). Invalid slice time parameters: TimeToSlice =%f  SliceTime = %f  . \n", TimeToSlice, SliceTime);
        return U_ERROR;
    }
    if(BeginSamp>=EndSamp)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRFPulse(). Parameters out of range:  BeginSamp = %d, EndSamp = %d  .\n", BeginSamp, EndSamp);
        return U_ERROR;
    }
    CorrectRF               = true;
    WinRFFrom               = BeginSamp;
    WinRFTo                 = EndSamp;
    return U_OK;
}
ErrorType UEEGfMRITool::SetCorrectRefLayer(bool Apply, int Ncomp, double RLasLow, double RLasHigh)
{
    CorrectRefLayer         = false;
    if(Apply==false)
    {
        NcompRefLayer       =  -1;
        BandRefLayerLow     =  -1.;
        BandRefLayerHigh    =  -1.;
        return U_OK;
    }
    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRefLayer(). Volume marker not set. \n");
        return U_ERROR;
    }
    if(Ncomp<=0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectRefLayer(). Parameter out of range:  Ncomp = %d  .\n", Ncomp);
        return U_ERROR;
    }
    CorrectRefLayer         = true;
    NcompRefLayer           = Ncomp;
    BandRefLayerLow         = RLasLow >0. ? RLasLow : -1.;
    BandRefLayerHigh        = RLasHigh>0. ? RLasHigh :-1.;
    if(BandRefLayerLow>0. && BandRefLayerHigh>0. && BandRefLayerLow>=BandRefLayerHigh)
    {
        BandRefLayerLow     =  -1.;
        BandRefLayerHigh    =  -1.;
    }
    return U_OK;
}
ErrorType UEEGfMRITool::SetCorrectBCG(bool Apply, int NEKG, int BeginSamp, int EndSamp, double OutFrac, bool Overlap, bool AdaptAmp, bool CopyFilt)
{
    CorrectBCG              = false;
    if(Apply==false)
    {
        NMarkEKG                = 0;
        for(int k=0; k<MAXEKGMARKERS; k++) EKGMarkers[k]=-1;
        WinEKGFrom              = -1;
        WinEKGTo                = 0;
        OverlappingArtifacts    = true;
        BCGOutlierFraction      = 0.05;
        AdaptEKGArtefactAmp     = false;
        ApplyBPFilter           = false;
        return U_OK;
    }
    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectBCG(). Volume marker not set. \n");
        return U_ERROR;
    }
    if(NEKG<=0 || MAXEKGMARKERS<NEKG || BeginSamp>=EndSamp)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectBCG(). Parameter(s) out of range:  NEKG=%d, BeginSamp = %d, EndSamp = %d  .\n", NEKG, BeginSamp, EndSamp);
        return U_ERROR;
    }
    if(OutFrac<0. || 1.<=OutFrac)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetCorrectBCG(). Parameter(s) out of range:  OutFrac=%f  .\n", OutFrac);
        return U_ERROR;
    }

    CorrectBCG              = true;
    if(NMarkEKG != NEKG) for(int k=0; k<MAXEKGMARKERS; k++) EKGMarkers[k]=-1;
    NMarkEKG                = NEKG;
    WinEKGFrom              = BeginSamp;
    WinEKGTo                = EndSamp;
    OverlappingArtifacts    = Overlap;
    BCGOutlierFraction      = OutFrac;
    AdaptEKGArtefactAmp     = AdaptAmp;
    ApplyBPFilter           = CopyFilt;
    return U_OK;
}
ErrorType UEEGfMRITool::SetEKGMarker(UString Name)
{
    if(CorrectBCG==false || NMarkEKG<=0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetEKGMarker(). BCG correction or NMarkEKG (=%d) not set. \n", NMarkEKG);
        return U_ERROR;
    }
    if(IsVolumeMarkerSet()==false)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetEKGMarker(). Volume marker not set. \n");
        return U_ERROR;
    }
    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
    int iMark                       = MarkerArray->GetMarkerIndex(Name);
    if(iMark<0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::SetEKGMarker(). Marker not present: %s. \n", (const char*)Name);
        return U_ERROR;
    }
    for(int k=0; k<NMarkEKG; k++)
    {
        if(EKGMarkers[k]>=0) continue;
        EKGMarkers[k] = iMark;
        return U_OK;
    }
    EKGMarkers[0] = iMark;

    return U_OK;
}
ErrorType UEEGfMRITool::OutputBCGArtefacts(bool AllArtefacts, bool Averge)
{
    OutputBCGArt = AllArtefacts;
    OutputAvBCG  = Averge;
    return U_OK;
}

ErrorType UEEGfMRITool::SetMergeLogFile(bool Apply, UFileName LogFile, UString VolName, int NDummy)
{
    MergeLog = false;
    if(Apply)
    {
        if(CorrectADC==true)
            CI.AddToLog("WARNING: UEEGfMRITool::MergeLogFile(). Merging log file not compatible with correcting ADC channels. \n");

        if(IsVolumeMarkerSet()==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::MergeLogFile(). Volume marker not set. \n");
            return U_ERROR;
        }
        if(LogFile.DoesFileExist()==false)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::MergeLogFile(). Log file does not exist: %s. \n", LogFile);
            return U_ERROR;
        }
        MergeVolMarker = VolName;
        MergeLogFile   = LogFile;
        MergeLogNDummy = NDummy;
        MergeLog       = true;
    }
    return U_OK;
}
const UString& UEEGfMRITool::GetProperties(UString Comment) const
{
    if(TemplateData==NULL || TemplateData->GetData()==NULL || TemplateData->GetData()->GetMarkerArray()==NULL)
    {
        Properties = UString("Data not set. \n");
        return Properties;
    }
    Properties      = UString();
    double SampRate = TemplateData->GetData()->GetSampleRate();
    double StimeMs  = SampRate>0. ? 1000./SampRate  : 0.;

    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
    Properties += UString("fMRI scanning artefact-correction-settings: \n");
    Properties += UString(TemplateData->GetData()->GetDataFileName(), "File         = %s \n");

    Properties += UString(BoolAsText(CorrectEEG), "EEGCorrection     =  %s \n");
    Properties += UString(BoolAsText(CorrectADC), "ADCCorrection     =  %s \n");
    Properties += UString(BoolAsText(CorrectEKG), "ECGCorrection     =  %s // Gradient artefacts only\n");

    if(CorrectVolumes || CorrectSlices || CorrectRF || CorrectRefLayer || CorrectBCG)
    {
        Properties += UString(MarkerArray->GetMarkerName(iMarkVol), "VolumeMarker  =   %s  \n");
        Properties += UString(MarkerArray->GetAverageTimeInterval(iMarkVol) , "VolumeTimeEEG  =   %14.10f  \n");
    }
    if(CorrectVolumes==true) 
    {
        Properties += UString("VolumeCorrection  =  TRUE \n");

        if(NOT(VolSubGroups) && NOT(UsePartitionFile)) 
        {
            Properties += UString("VolumeSingleGroup =  TRUE \n");
            if(iMarkVolSkip>=0)
                Properties += UString(MarkerArray->GetMarkerName(iMarkVolSkip)  , "VolumeMarkerSkip          = %s \n");
        }
        else if(VolSubGroups)
        {
            Properties += UString("VolumeGrouping    =  TRUE \n");
            Properties += UString(VolSubGroupSize,"VolumeGroupSize   =  %d \n");
            if(iMarkVolSkip>=0)
                Properties += UString(MarkerArray->GetMarkerName(iMarkVolSkip)  , "VolumeMarkerSkip          = %s \n");
        }
        else if(UsePartitionFile)
        {
            Properties += UString("VolumePartitioning=  TRUE \n");
            Properties += UString("VolumeParitionFile=  ") + UString((const char*)PartitionFile) + " \n";
            Properties += UString("IgnoreTimeShift   =  ") + BoolAsText(IgnoreTimeShift)+ "\n";
        }
    }
    else
        Properties += UString("VolumeCorrection  =  FALSE \n");

    if(CorrectSlices==true) 
    {
        Properties += UString(             "SliceCorrection  =  TRUE \n");
        Properties += UString(NSlices    , "NSlices          =   %d  \n");
        Properties += UString(TimeToSlice, "TimeToSlice      =   %14.10f  \n");
        Properties += UString(SliceTime  , "SliceTime        =   %14.10f  \n");
    }
    else
        Properties += UString(             "SliceCorrection  =  FALSE \n");
    
    if(CorrectVolumes==true || CorrectSlices==true)
        Properties += UString(GetTimeShiftText(InterpolationType), "TimeInterpolation    =  %s \n");

    if(CorrectRF==true) 
    {
        Properties += UString("LinearInterpolation = TRUE  \n");
        Properties += UString(WinRFFrom*StimeMs, "BegInt              =   %9.5f  \n");
        Properties += UString(WinRFTo  *StimeMs, "EndInt              =   %9.5f  \n");
    }
    else
        Properties += UString("LinearInterpolation = FALSE  \n");

    if(CorrectVolumes==true || CorrectSlices==true || CorrectRF==true || CorrectRefLayer==true)
    {
        double SampRate = TemplateData->GetData()->GetSampleRate();
        if(ApplyLowPass3==true)
            Properties += UString(SampRate/3., "LowPassFilter          = %f \n");
        if(CorrectEKG   ==true)
            Properties += UString("ECGcorrected = TRUE \n");
    }
    if(CorrectRefLayer==true)
    {
        Properties += UString(                      "ReferenceLayer      = TRUE  \n");
        Properties += UString(NcompRefLayer       , "NSVDrefereceLayer   =   %d  \n");
        if(BandRefLayerLow >0. && BandRefLayerLow>=BandRefLayerHigh) 
            Properties += UString(BandRefLayerLow , "BandPassLowFreq     =   %f  \n");
        if(BandRefLayerHigh>0. && BandRefLayerLow>=BandRefLayerHigh) 
            Properties += UString(BandRefLayerHigh, "BandPassHighFreq    =   %f  \n");
    }
    else
        Properties += UString("ReferenceLayer      = FALSE  \n");

    if(CorrectBCG==true) 
    {
        Properties += UString("BCGCorrection         = TRUE. \n");
        Properties += UString(NMarkEKG, "N_EKGMarkers          = %d \n");
        Properties += UString("EKGMarkers            =  ");
        for(int k=0; k<NMarkEKG; k++)
        {
            if(EKGMarkers[k]<0) continue;
            UString T = MarkerArray->GetMarkerName(k);
            if(k<NMarkEKG-1) Properties += UString((const char*) T," %s ,");
            else             Properties += UString((const char*) T," %s \n");
        }
        Properties += UString(WinEKGFrom*StimeMs, "EndEKG               =   %9.5f  \n");
        Properties += UString(WinEKGTo  *StimeMs, "StartEKG             =   %9.5f  \n");
        
        if(OverlappingArtifacts==false)
        {
            Properties += UString("OverlappingArtifacts = ") + UString(BoolAsText(false))                    +UString(" \n");
            Properties += UString("ApplyBandPass        = ") + UString(BoolAsText(ApplyBPFilter            ))+UString(" \n");
            Properties += UString("AdaptAmplitude       = ") + UString(BoolAsText(AdaptEKGArtefactAmp))+UString(" \n");
        }
        else
        {
            Properties += UString("OverlappingArtifacts = ") + UString(BoolAsText(true)) +UString(" \n");
            Properties += UString("ApplyBandPass        = ") + UString(BoolAsText(false))+UString(" \n");
            Properties += UString("AdaptAmplitude       = ") + UString(BoolAsText(false))+UString(" \n");
            Properties += UString(100.*BCGOutlierFraction,"OutlierFraction      = %f // [%%] \n");
        }
    }
    else
        Properties += UString("BCGCorrection  = FALSE. \n");

    if(CorrectADC==false)
    {
        if(MergeLog==true) Properties += UString("LogFile          = ") + MergeLogFile + UString(" \n");
        if(DownSamp==true) Properties += UString("DownSampleFreq   = ") + UString(DownSampFres,"%8.1f")+ UString(" \n");
    }
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UEEGfMRITool::CopyEpDat(UMEEGDataEpochs** EpDatTo, const UMEEGDataEpochs* EpDatFrom) const
{
    if(EpDatTo==NULL) return U_ERROR;
    if(EpDatFrom && EpDatFrom->GetError()!=U_OK) return U_ERROR;

    *EpDatTo = EpDatFrom ? new UMEEGDataEpochs(*EpDatFrom) : new UMEEGDataEpochs(*TemplateData);
    if(*EpDatTo==NULL || (*EpDatTo)->GetError()!=U_OK)
    {
        delete *EpDatTo; *EpDatTo = NULL;
        CI.AddToLog("ERROR: UEEGfMRITool::CopyEpDat(). Error generating UMEEGDataEpochs object. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UEEGfMRITool::ComputeSaveCorrectedData(void)
{
    if(TemplateData==NULL            || TemplateData->GetError()!=U_OK ||
       TemplateData->GetData()==NULL || TemplateData->GetData()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Template (input) data structure not (properly) set. \n");
        return U_ERROR;
    }
    double              SampRate    = TemplateData->GetData()->GetSampleRate();
    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();
    if(MarkerArray==NULL  || MarkerArray->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Markers not (properly) set. \n");
        return U_ERROR;
    }
    if(iMarkVol<0 || MarkerArray->GetMarker(iMarkVol)==NULL)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Volume marker not set.\n");
        return U_ERROR;
    }
    else if(MarkerArray->GetMarker(iMarkVol)->GetnSamples() <1)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Number of samples smaller than 1 for Marker = %s .\n", MarkerArray->GetMarkerName(iMarkVol));
        return U_ERROR;
    }
    else if(MarkerArray->GetAverageTimeInterval(iMarkVol)<=0.)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Estimated volume time not positive. Marker = %s .\n", MarkerArray->GetMarkerName(iMarkVol));
        return U_ERROR;
    }
    double VolTime   = MarkerArray->GetAverageTimeInterval(iMarkVol);

    if(CorrectBCG) 
    {
        if(NMarkEKG<=0)
        {
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). No EKG markers selected or EKG markers wrongly selected, NMarkEKG=%d. \n", NMarkEKG);
            return U_ERROR;
        }
        for(int k=0; k<NMarkEKG; k++)
        {
            if(CorrectVolumes && iMarkVol==EKGMarkers[k])
            {
                CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Volume marker used as EKG marker (%s) \n", MarkerArray->GetMarkerName(iMarkVol));
                return U_ERROR;
            }
            if(EKGMarkers[k]<0)
            {
                CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). EKG marker (%d) not set\n", k);
                return U_ERROR;
            }
        }
    }
    

/* Copy data template and set epochs and filters in the appropriate way */
    UMEEGDataEpochs* EpDat = NULL;
    if(CopyEpDat(&EpDat, NULL)!= U_OK || EpDat==NULL || EpDat->GetError()!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Error generating UMEEGDataEpochs object. \n");
        return U_ERROR;
    }   

    int Nvol     = MarkerArray->GetMarker(iMarkVol)->GetnSamples();
    int NsampMin = MarkerArray->GetMinInterval(iMarkVol);
    int NsampMax = MarkerArray->GetMaxInterval(iMarkVol);
    if(NsampMin<NsampMax-1)
        CI.AddToLog("WARNING: UEEGfMRITool::ComputeSaveCorrectedData(). Volume markers not equidistant (NsampMin=%d, NsampMax=%d). \n", NsampMin, NsampMax);

    if(NsampMin<NsampMax-MAXTOL_EQUIDISTANT)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Volume markers not equidistant (NsampMin=%d, NsampMax=%d). \n", NsampMin, NsampMax);
        return U_ERROR;
    }
    if(EpDat->SetEpochsMarker(0, NsampMin-1, MarkerArray->GetMarkerName(iMarkVol))!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Setting Epochs equal to volume markers. \n");
        return U_ERROR;
    }    
    
    UPartition Part(Nvol);
    if(CorrectVolumes==true || CorrectSlices==true || CorrectRF==true || CorrectRefLayer==true)
    {
        ErrorType   E = Part.GetError();
        
        if(E==U_OK)
        {
            if(VolSubGroups)
            {
                E      = Part.MakeEqualGroups(VolSubGroupSize);
            }
            else if(UsePartitionFile)
            {
                Part   = UPartition((const char*)PartitionFile);
                E      = Part.GetError();
            }
        }
        if(iMarkVolSkip>=0)
        {
            if(iMarkVolSkip==iMarkVol)
            {
                delete EpDat;
                CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Invalid BAD volume index (%d) iMarkerVol = %d. \n", iMarkVolSkip, iMarkVol);
                return U_ERROR;
            }
            const UMarker* BADMarker = MarkerArray->GetMarker(iMarkVolSkip);
            if(BADMarker==NULL || BADMarker->GetError()!=U_OK)
            {
                delete EpDat;
                CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). NULL or invalid BAD volume selected. \n");
                return U_ERROR;
            }
            int  NBAD  = 0;
            int* EpBAD = BADMarker->GetInEpochArray(EpDat->GetEpochs(), &NBAD);
            if(EpBAD && NBAD>0)
                E = Part.SetGroup(EpBAD, NBAD, -1);
            delete[] EpBAD;
        }
        if(E==U_OK) E = Part.MergeNegIDGroups();
        if(E!=U_OK)
        {
            delete EpDat;
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Partitioning object. \n");
            return U_ERROR;
        }

        if((CorrectVolumes==true || CorrectSlices==true || CorrectRF==true) && SliceTime<SLICETIMETHRESH)
        {
            delete EpDat;
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Invalid slice time (SliceTime =%f). \n", SliceTime);
            return U_ERROR;
        }
    }

    UPowerLineType  PowerLine      = U_POWERLINE_NO;
    double          PLWidth        = 0.;
    bool            NoExtraSamples = true;
    double          FIRWindow      = 1.;

    EpDat->SetFilter(U_PREP_OFFSET, PowerLine, PLWidth, NoExtraSamples, FIRWindow);
    EpDat->SetRereference(U_REF_RAW, U_REF_RAW);
    if(CorrectEKG && (CorrectVolumes==true || CorrectSlices==true || CorrectRF==true)) EpDat->ConvertDataType(U_DAT_EKG, U_DAT_EEG);

/* ADC import object */
    UEPRADC EPRImport;
    if(CorrectADC==false && MergeLog)
    {
        SendMessage("Initialize .log file import\n");
        EPRImport = UEPRADC(MergeLogFile, (const char*)MergeVolMarker, MergeLogNDummy, EpDat);

        if(EPRImport.GetError()!=U_OK)
        {
            delete EpDat;
            SendMessage("ERROR: Initialization. see .Log-file\n");
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Creating ADC import object. \n");
            return U_ERROR;
        }
    }

/* Set output data set */
    UMEEGDataWriteCTF CTFout(*(EpDat->GetData())); 

    ErrorType   E = CTFout.GetError();
    if(E==U_OK) E = CTFout.SetDataFileName(OutputFile);
    if(E==U_OK) E = CTFout.SetNtrial(EpDat->GetEpochs()->GetnEpochs());
    if(E==U_OK) E = CTFout.SetNsampTrial(NsampMin);

    if(E!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Setting UMEEGDataWriteCTF() object. \n");
        return U_ERROR;
    }
    UString Comment = UString(CI.GetProperties(" ")) + GetProperties("  ");
    CTFout.AddComment((const char*)Comment);

    if(CorrectEEG) CTFout.SetGridEEG(EpDat->GetData()->GetGridEEG()); else CTFout.SetGridEEG(NULL);
    if(CorrectADC) CTFout.SetGridADC(EpDat->GetData()->GetGridADC()); else CTFout.SetGridADC(EPRImport.GetMergedGrid());
    CTFout.SetGridMEG(NULL);
        
    if(CTFout.WriteHeader()!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Writing CTF header file. \n");
        return U_ERROR;
    }
    CTFout.DeleteBadChannelFile();

/* Convert old to new markers and write marker filename */    
    UMarkerArray Mnew(*MarkerArray);
    if(Mnew.GetError()!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Creating creating new UMarkerArray object. \n");
        return U_ERROR;
    }
    if(Mnew.RedistributeTrials(EpDat->GetEpochs())!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Redistributing markers over trials. \n");
        return U_ERROR;
    }
    if(EPRImport.GetTemplateMarkerArray()) Mnew.MergeMarkerArray(EPRImport.GetTemplateMarkerArray());
    if(CTFout.WriteMarkerArray(&Mnew, true)!=U_OK)
    {
        delete EpDat;
        CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Error in WriteMarkerFile(). \n");
        return U_ERROR;
    }

/* Correction over slices (and interpolation) and computation of volume averages */    
    if(CorrectVolumes==true || CorrectSlices==true || CorrectRF==true || CorrectRefLayer==true)
    {
        int          NGroup   = Part.GetNGroup();
        double       SampTime = EpDat->GetSampleTime_s();
        UMultiChan** VolAverE = new UMultiChan*[NGroup];
        UMultiChan** VolAverA = new UMultiChan*[NGroup];
        if(VolAverE==NULL || VolAverA==NULL)
        {
            delete EpDat;
            delete[] VolAverE; delete[] VolAverA;
            CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Memory allocation error for volume array. \n");
            return U_ERROR;
        }
        for(int ig=0; ig<NGroup; ig++)
        {
            VolAverE[ig] = new UMultiChan();
            VolAverA[ig] = new UMultiChan();
        }
        for(int it=0; it<Nvol; it++) // loop over volumes 
        {       
            ProcessEvents();
     
            const UGroupElem* Elem  = Part.GetElement(it);
            if(Elem==NULL)
            {
                delete EpDat;
                for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Getting group element of volume %d   . \n", it);
                return U_ERROR;
            }

            UMultiChan*       DataE = NULL;
            UMultiChan*       DataA = NULL;
            if(CorrectEEG)    
            {
                DataE = EpDat->GetFilteredMultiChan(it,U_DAT_EEG);
                if(DataE==NULL || DataE->GetError()!=U_OK)
                {
                    delete EpDat;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                    delete DataE; delete DataA;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Getting EEG data of volume %d   . \n", it);
                    return U_ERROR;
                }
            }
            if(CorrectADC)
            {
                DataA = EpDat->GetFilteredMultiChan(it,U_DAT_ADC);
                if(DataA==NULL || DataA->GetError()!=U_OK)
                {
                    delete EpDat;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                    delete DataE; delete DataA;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Getting ADC data of volume %d   . \n", it);
                    return U_ERROR;
                }
            }
            if(Elem->GetGroupID()<0)
            {
                if(SkippedToZero)
                {
                    if(DataE) DataE->SetData(0.);
                    if(DataA) DataA->SetData(0.);
                    UString Status(it, "Setting zero data block at volume %d  ...\n");
                    SendMessage((const char*)Status);
                }
                else
                {
                    UString Status(it, "Copying volume %d  ...\n");
                    SendMessage((const char*)Status);
                }
            }
            else
            {
                if(CorrectSlices==true)
                {
                    if(CorrectDataSlices(EpDat, VolTime, SliceTime, TimeToSlice, it, NSlices, IgnoreTimeShift, InterpolationType, DataE)!=U_OK ||
                       CorrectDataSlices(EpDat, VolTime, SliceTime, TimeToSlice, it, NSlices, IgnoreTimeShift, InterpolationType, DataA)!=U_OK)
                    {
                        delete EpDat;
                        for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                        for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                        delete DataE; delete DataA;
                        CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Computing slice correction in volume %d \n", it);
                        return U_ERROR;
                    }
                }
                else if(IgnoreTimeShift==false)// No slice correction 
                {
                    if(CorrectVolumes==true || CorrectRF==true || CorrectRefLayer==true)
                    {
                        double VolTime = MarkerArray->GetAverageTimeInterval(iMarkVol);
                        int    nsamp   = EpDat->GetEpochs()->GetBeginSample(it) - EpDat->GetEpochs()->GetBeginSample(0);
                        double delta   = it*VolTime - nsamp*SampTime;
                        if(DataE) DataE->ShiftData(delta, InterpolationType);
                        if(DataA) DataA->ShiftData(delta, InterpolationType);
                    }
                }
                int        ig    = Elem->GetGroupIndex();
                if(DataE) *(VolAverE[ig]) += *DataE;
                if(DataA) *(VolAverA[ig]) += *DataA;

                UString Status(it, "Processed volume %d: Slice correction and/or volume average.");
                Status += UString(ig, " Group = %d\n");
                SendMessage((const char*)Status);            
            }

/* Data is now slice corrected, or shifted over volume time (but not yet volume corrected) */
            if(DataE) CTFout.WriteTrial(DataE->GetData(), U_DAT_EEG, it);  // Write slice corrected or (shifted) raw data
            if(DataA) CTFout.WriteTrial(DataA->GetData(), U_DAT_ADC, it);  // Write slice corrected or (shifted) raw data
            delete DataE; delete DataA;

            if(NOT(CorrectADC) && EPRImport.GetMergedGrid())
            {
                UMultiChan* DataADC = EPRImport.GetMergedADCMultiChan(EpDat, it);
                if(DataADC==NULL || CTFout.WriteTrial(DataADC->GetData(), U_DAT_ADC, it) !=U_OK)
                {
                    delete EpDat;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                    delete    DataADC;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Inserting EPR data in volume %d \n", it);
                    return U_ERROR;
                }
                delete DataADC;
            }
        }

/*Set EpDat equal to file just written and re-do te EEG part */
        UGrid Gold = *(EpDat->GetData()->GetGridAll());
        delete EpDat; EpDat = new UMEEGDataEpochs(CTFout.GetDataFileName(), NULL, NULL);
        if(EpDat->GetError()!=U_OK)
        {
            delete EpDat;
            for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
            for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Error generating UMEEGDataEpochs object. \n");
            return U_ERROR;
        }    
        EpDat->CopySensorIDsFromNames(&Gold);
        EpDat->SetEpochs(0,-1);
        EpDat->SetFilter(U_PREP_OFFSET, PowerLine, PLWidth, NoExtraSamples, FIRWindow);
        EpDat->SetRereference(U_REF_RAW, U_REF_RAW);
        if(CorrectEKG)  // This is required because the CTF reader will automatically "ECG" labeled EEG convert to ECG
            EpDat->ConvertDataType(U_DAT_EKG, U_DAT_EEG);

        if(CorrectVolumes==true || CorrectRF==true|| CorrectRefLayer==true)       // Replace EEG-data part. Header stays the same
        {
            for(int ig=0; ig<NGroup; ig++)
            {
                if(Part.GetNElem(ig)>0)
                {
                    if(CorrectEEG && VolAverE[ig]) *(VolAverE[ig]) /= Part.GetNElem(ig);
                    if(CorrectADC && VolAverA[ig]) *(VolAverA[ig]) /= Part.GetNElem(ig);
                }
                else                     
                    CI.AddToLog("WARNING: UEEGfMRITool::ComputeSaveCorrectedData(). No elements in volume group %d .\n", ig);
            }
            for(int it=0; it<EpDat->GetNEpoch(); it++)
            {
                UString Status(it, "Correcting volume %d  ...\n");
                SendMessage((const char*)Status);
                ProcessEvents();

                const UGroupElem* Elem  = Part.GetElement(it);
                UMultiChan*       DataE = CorrectEEG ? DataE = EpDat->GetFilteredMultiChan(it,U_DAT_EEG) : NULL;
                UMultiChan*       DataA = CorrectADC ? DataA = EpDat->GetFilteredMultiChan(it,U_DAT_ADC) : NULL;
                if(Elem==NULL || (CorrectEEG && (DataE==NULL || DataE->GetError()!=U_OK))
                              || (CorrectADC && (DataA==NULL || DataA->GetError()!=U_OK)) )
                {
                    delete EpDat;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                    for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                    delete DataE; delete DataA;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Retrieving data of volume %i from intermediate data set. \n", it);
                    return U_ERROR;
                }

                if(Elem->GetGroupID()>=0)
                {
                    int ig = Elem->GetGroupIndex();

/* Volume correction */
                    if(CorrectVolumes==true) // Subtract average
                    {
                        if(DataE) *DataE  -= *(VolAverE[ig]); 
                        if(DataA) *DataA  -= *(VolAverA[ig]); 
                    }
/* Cut RF peaks by linear interpolation */
                    if(CorrectRF ==true)                            // remove peaks by interpolation
                    {
                        for(int s=0; s<NSlices; s++)
                        {
                            int Begin = floor(.5 + WinRFFrom + (TimeToSlice + s*SliceTime)*SampRate);
                            int End   = floor(.5 + WinRFTo   + (TimeToSlice + s*SliceTime)*SampRate);     
                            if(DataE) DataE->InterpolateDataSegment(Begin, End, -1);
                            if(DataA) DataA->InterpolateDataSegment(Begin, End, -1);
                        }
                    }

/* Apply filter at 1/3 of the acq. rate to remove FFT artefact */
                    if(ApplyLowPass3==true)
                    {
                        ULinearFilter F(SampRate);
                        F.SetFilter(0., SampRate/3., U_PREP_OFFSET, PowerLine, PLWidth, FIRWindow);
                        
                        if( (DataE && DataE->ApplyLinearFilter(F)!=U_OK) ||
                            (DataA && DataA->ApplyLinearFilter(F)!=U_OK))
                        {
                            delete EpDat;
                            for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                            for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                            delete DataE; delete DataA;
                            CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Error filtering corrected data. \n", it);
                            return U_ERROR;
                        }
                    }
                    if(CorrectRefLayer==true && DataE)
                    {
                        if(DataE->RemoveReferenceComponents(NcompRefLayer, BandRefLayerLow, BandRefLayerHigh)!=U_OK)
                        {
                            delete EpDat;
                            for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
                            for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
                            delete DataE; delete DataA;
                            CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Removing reference components, trial = %d. \n", it);
                            return U_ERROR;
                        }
                    }
                }
                if(DataE) CTFout.WriteTrial(DataE->GetData(), U_DAT_EEG, it);
                if(DataA) CTFout.WriteTrial(DataA->GetData(), U_DAT_ADC, it);
                delete DataE; delete DataA;
            }
        }
        for(int ig=0; ig<NGroup; ig++) delete VolAverE[ig]; delete[] VolAverE;
        for(int ig=0; ig<NGroup; ig++) delete VolAverA[ig]; delete[] VolAverA;
    }

/* Resampling */
    if(DownSamp==true && (CorrectVolumes==true || CorrectSlices==true || CorrectRF==true || CorrectRefLayer==true))
    {
        if(DownSampFres<=0 || SampRate<=0 || DownSampFres==SampRate)
        {
            delete EpDat;
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Invalid (re)sample frequency (Fres=%f, SampRate=%f). \n", DownSampFres, SampRate);
            return U_ERROR;
        }        
        if(EpDat->ReadResampleWriteCTFData(DownSampFres)!=U_OK)
        {
            delete EpDat;
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeSaveCorrectedData(). Resampling data. \n");
            return U_ERROR;
        }
    }
    if(CorrectBCG==true)
    {
        if(CorrectSlices==true || CorrectVolumes==true || CorrectRF==true || CorrectRefLayer==true) /* In case volume and/or slice correction were applied, set EpDat equal to file just written */
        {
            delete EpDat; EpDat = new UMEEGDataEpochs(CTFout.GetDataFileName(), NULL, NULL);
            if(EpDat==NULL || EpDat->GetError()!=U_OK)
            {
                delete EpDat;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Re-initializing UMEEGDataEpochs()-object. \n");
                return U_ERROR;
            }
            Comment = UString();

/* Reset EKG channels to EEG */
            if(CorrectEKG) 
            {
                ChanInfo* ChOld = TemplateData->GetData()->GetChanInfo();
                if(EpDat->SelectChannels(ChOld)!=U_OK)
                {
                    delete EpDat; delete[] ChOld;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Resetting ECG channels form EEG to ECG type. \n");
                    return U_ERROR;
                }
                delete[] ChOld;
            }
            EpDat->SetEpochs(0,-1);
        }
        UPowerLineType  PowerLine       = U_POWERLINE_NO;
        double          PLWidth         = 0.;
        bool            NoExtraSamples  = true;
        double          Window          = 1.;

        if(ApplyBPFilter) EpDat->SetFilter(TemplateData->GetFilter(), TemplateData->GetNoExtraSamples());
        else              EpDat->SetFilter(U_PREP_OFFSET, PowerLine, PLWidth, NoExtraSamples, Window);

        if(CorrectSlices==true || CorrectVolumes==true || CorrectRF==true || CorrectRefLayer==true|| EPRImport.GetMergedGrid()==NULL) // Logfiles already merged in this case
        {
            if(ComputeCorrectedBCG(EpDat, Comment, NULL)!=U_OK)
            {
                delete EpDat;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Error correcting BCG artefact. \n");
                return U_ERROR;
            }
        }
        else
        {
            if(ComputeCorrectedBCG(EpDat, Comment, &EPRImport)!=U_OK)
            {
                delete EpDat;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Error correcting BCG artefact. \n");
                return U_ERROR;
            }
        }
    }
    if(CorrectVolumes==true || CorrectSlices==true || CorrectRF==true || CorrectRefLayer==true || CorrectBCG==true || EPRImport.GetEPRGrid()==NULL)
    {
        delete EpDat;
        return U_OK;
    }
    
    for(int it=0; it<Nvol; it++) // loop over volumes 
    {       
        ProcessEvents();

        UString Status(it, "Merging ADC data from volume %d  ...");
        SendMessage((const char*)Status);

        UMultiChan*  DataEEG  = EpDat->GetFilteredMultiChan(it,U_DAT_EEG);
        if(DataEEG==NULL || CTFout.WriteTrial(DataEEG->GetData(), U_DAT_EEG, it)!=U_OK)
        {
            delete EpDat; delete DataEEG;
            CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Getting EEG data of volume %d   . \n", it);
            return U_ERROR;
        }
        delete DataEEG;

        if(EPRImport.GetMergedGrid())
        {
            UMultiChan* DataADC = EPRImport.GetMergedADCMultiChan(EpDat, it);
            if(DataADC==NULL || CTFout.WriteTrial(DataADC->GetData(), U_DAT_ADC, it) !=U_OK)
            {
                delete EpDat;
                delete DataADC;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeSaveCorrectedData(). Inserting EPR data in volume %d \n", it);
                return U_ERROR;
            }
            delete DataADC;
        }
    }
    delete EpDat;
    return U_OK;
}
ErrorType UEEGfMRITool::CorrectDataSlices(const UMEEGDataEpochs* Epo, double VolTime, double SliceTime, double TimeToSlice, int ivol, int NSli, bool IgnoreVolumeShift, TimeShiftType TST, UMultiChan* DataVol) // static
{
    if(Epo==NULL)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CorrectDataSlices(). Input data pointer is NULL.\n");
        return U_ERROR;
    }
    if(ivol<0 || NSli<=0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CorrectDataSlices(). Invalid input volume/slice number(s); %d, %d\n", ivol, NSli);
        return U_ERROR;
    }
    if(VolTime<=0. || SliceTime<=0. || TimeToSlice<=0. || TimeToSlice+(NSli-1)*SliceTime>VolTime)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CorrectDataSlices(). Inconsistent timing parameters: TimeToSlice=%f, SliceTime=%f, VolTime%f .\n", TimeToSlice, SliceTime, VolTime);
        return U_ERROR;
    }
    
    if(DataVol    ==NULL) return U_OK;

    double       Srate       = Epo->GetData()  ->GetSampleRate();
    int          NsampSlice  = SliceTime*Srate;
    UMultiChan   SliceAv;
    UMultiChan** Slices      = new UMultiChan*[NSli];
    int*         SliceOffSet = new int[NSli];
    if(SliceAv.GetError()!=U_OK || Slices==NULL || SliceOffSet==NULL)
    {
        delete[] Slices; delete[] SliceOffSet;
        CI.AddToLog("ERROR UEEGfMRITool::CorrectDataSlices(). Memory allocation error. \n");
        return U_ERROR;
    }
    for(int s=0; s<NSli; s++) Slices[s] = NULL;
    for(int s=0; s<NSli; s++) 
    {
        double  delta  = 0.;
        SliceOffSet[s] = CompSliceOffSet(Epo, VolTime, SliceTime, TimeToSlice, ivol, s, IgnoreVolumeShift, &delta);
        Slices[s]      = new UMultiChan(*DataVol, SliceOffSet[s], NsampSlice);
        if(SliceOffSet[s]<0 || Slices[s]==NULL || Slices[s]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR UEEGfMRITool::CorrectDataSlices(). Getting data of slice %d, vol %d . \n", s, ivol);
            for(int i=0; i<NSli; i++) delete Slices[i];
            delete[]  Slices; delete[]  SliceOffSet;
            return U_ERROR;
        }
        Slices[s]->ShiftData(delta, TST);  // Chequed sign of delta, dd 11-09-2016
        SliceAv += *Slices[s];
    }
    SliceAv /= NSli;
    for(int s=0;s<NSli;s++) 
    {
        *(Slices[s]) -= SliceAv;
        Slices[s]->CopyCol( 1,  0,  0);
        Slices[s]->CopyCol(-2, -1, -1);
        DataVol->CopyData(*Slices[s],0,NsampSlice,SliceOffSet[s]);
        if(s<NSli-1)
        {
            int Begin = SliceOffSet[s]+NsampSlice;
            int End   = SliceOffSet[s+1];
            if(Begin<End) DataVol->CopyCol(Begin-1,Begin, End-1);
        }
    }
    for(int s=0;s<NSli;s++) delete Slices[s];
    delete[] Slices; delete[] SliceOffSet;

    return U_OK;
}
int UEEGfMRITool::CompSliceOffSet(const UMEEGDataEpochs* Epo, double VolTime, double SliceTime, double TimeToSlice, int ivol, int isli, bool IgnoreVolumeShift, double* Delta) // static
{
    if(Epo==NULL)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CompSliceOffSet(). Input data pointer is NULL.\n");
        return -1;
    }
    if(ivol<0 || isli<0)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CompSliceOffSet(). Invalid input volume/slice number(s); %d, %d\n", ivol, isli);
        return -1;
    }
    if(VolTime<=0. || SliceTime<=0. || TimeToSlice<=0. || TimeToSlice+isli*SliceTime>VolTime)
    {
        CI.AddToLog("ERROR: UEEGfMRITool::CompSliceOffSet(). Inconsistent timing parameters: TimeToSlice=%f, SliceTime=%f, VolTime%f .\n", TimeToSlice, SliceTime, VolTime);
        return -1;
    }
    
    double Srate    = Epo->GetData()  ->GetSampleRate();
    int    samp     = Epo->GetEpochs()->GetBeginSample(ivol) - Epo->GetEpochs()->GetBeginSample(0);
    int SliceOffSet = 0;
    if(IgnoreVolumeShift) SliceOffSet = int(floor(.5 + ( (               TimeToSlice + isli*SliceTime)*Srate        ))); 
    else                  SliceOffSet = int(floor(.5 + ( (ivol*VolTime + TimeToSlice + isli*SliceTime)*Srate - samp ))); 

    if(SliceOffSet<0    ) SliceOffSet = 0;

    if(IgnoreVolumeShift) *Delta = (               TimeToSlice + isli*SliceTime) - (     SliceOffSet)/Srate;
    else                  *Delta = (ivol*VolTime + TimeToSlice + isli*SliceTime) - (samp+SliceOffSet)/Srate;

    return SliceOffSet;
}

ErrorType UEEGfMRITool::ComputeCorrectedBCG(UMEEGDataEpochs* Epo, const UString& Comment, const UEPRADC* EPRImport)
{
    if(NMarkEKG<=0) return U_ERROR;
    
    double              SampRate    = TemplateData->GetData()->GetSampleRate();
    const UMarkerArray* MarkerArray = TemplateData->GetData()->GetMarkerArray();

    for(int k=0; k<NMarkEKG; k++)
    {
        int     iMarkEKG = EKGMarkers[k];
        if(iMarkEKG<0 || iMarkEKG>=MarkerArray->GetnMarkers())
        {            
            CI.AddToLog("ERROR: UEEGfMRITool::ComputeCorrectedBCG(). Marker not found: %d \n", iMarkEKG);
            return U_ERROR;
        }
    }
    if(WinEKGFrom>=WinEKGTo)
    {
        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ECG range invalid (%f  -  %f). \n", WinEKGFrom, WinEKGTo);
        return U_ERROR;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error in input arguments. \n");
        return U_ERROR;
    }  
    if(Epo->GetData()       ==NULL || Epo->GetData()       ->GetError()!=U_OK ||
       Epo->GetMarkerArray()==NULL || Epo->GetMarkerArray()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Data or Markers not set. \n");
        return U_ERROR;
    }

    UMEEGDataEpochs* EKGEpochs = NULL;
    if(CopyEpDat(&EKGEpochs, Epo)!=U_OK)
    {
        delete EKGEpochs;
        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error creating UMEEGDataEpochs object based on ECG markers. \n");
        return U_ERROR;
    }

    int          NsampTrial  =            Epo->GetData()->GetNsampTrial();
    int          Nsamples    = WinEKGTo+WinEKGFrom+1;

    int*         NEKGepochs  = new int        [NMarkEKG];
    int**        EKGOffset   = new int*       [NMarkEKG];
    UMultiChan** AverE       = new UMultiChan*[NMarkEKG];
    UMultiChan** AverA       = new UMultiChan*[NMarkEKG];
    if(NEKGepochs==NULL || EKGOffset==NULL || AverE==NULL || AverA==NULL)
    {
        delete EKGEpochs;
        delete[] NEKGepochs; delete[] EKGOffset;
        delete[] AverE;      delete[] AverA;
        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Memory allocation. \n");
        return U_ERROR;
    }
    for(int n=0; n<NMarkEKG; n++) {NEKGepochs[n]=0; EKGOffset[n]=NULL; AverE[n]=AverA[n]=NULL;}

/* Write header of seperate artifact trials */    
    UMEEGDataWriteCTF CTFoutput;
    if(OutputBCGArt==true && OverlappingArtifacts==false)
    {
        SendMessage("Writing all occurrences of pulse artefacts into data set ...");

        int NtotEpoch = 0;
        for(int k=0; k<NMarkEKG; k++)
            NtotEpoch += MarkerArray->GetMarker(EKGMarkers[k])->GetnEvents(); /// Note: the true number of artefacts inside the data set can be smaller
        CTFoutput = UMEEGDataWriteCTF(*EKGEpochs->GetData());        
        CTFoutput.SetDataFileName(OutputFile.GetDirectory()+UFileName("BCGart.ds"));
        CTFoutput.SetNtrial(NtotEpoch);
        CTFoutput.SetNsampTrial(Nsamples);
        CTFoutput.WriteHeader();
    }
    double**    AmpFactorE = NULL;
    double**    AmpFactorA = NULL;

/* Compute averages */
    if(OverlappingArtifacts==true)
    {
        SendMessage("Getting summed artefact...");

        double*             XX      = NULL;
        double*             BB      = NULL;
        double*             ColRows = NULL;
        const UEventArray** Evar    = new const UEventArray*[NMarkEKG];
        if(Evar)        
        {
            for(int k=0; k<NMarkEKG; k++)
            {
                const UMarker* M        = MarkerArray->GetMarker(EKGMarkers[k]);
                Evar[k]                 = (const UEventArray*)M;
                if(CorrectEEG) AverE[k] = EKGEpochs->GetSummedFilteredMultiChan(M, WinEKGFrom, WinEKGTo, U_DAT_EEG, -1, BCGOutlierFraction);
                if(CorrectADC) AverA[k] = EKGEpochs->GetSummedFilteredMultiChan(M, WinEKGFrom, WinEKGTo, U_DAT_ADC, -1, BCGOutlierFraction);
                if((CorrectEEG && (AverE[k]==NULL || AverE[k]->GetError()!=U_OK || AverE[k]->GetNtime()!=Nsamples)) ||
                   (CorrectADC && (AverA[k]==NULL || AverA[k]->GetError()!=U_OK || AverA[k]->GetNtime()!=Nsamples)))
                {
                    for(int kk=0; kk<NMarkEKG; kk++) {delete AverE[kk]; AverE[kk]=NULL;}
                    for(int kk=0; kk<NMarkEKG; kk++) {delete AverA[kk]; AverA[kk]=NULL;}
                    delete[] Evar; Evar=NULL;
                    break;
                }
            }
            if(Evar)
            {
                ColRows = GetCrossingBlockArray(Evar, NMarkEKG, WinEKGFrom, WinEKGTo, EKGEpochs->GetData()->GetNtrial());
                XX      = new double[NMarkEKG*Nsamples];
                BB      = new double[NMarkEKG*Nsamples];
            }
        }
        if(Evar==NULL || ColRows==NULL || XX==NULL || BB==NULL)
        {
            delete   EKGEpochs;
            delete[] Evar; Evar=NULL;
            delete[] XX;   delete[] BB;  delete[] ColRows;
            delete[] NEKGepochs; delete[] EKGOffset;
            for(int kk=0; kk<NMarkEKG; kk++) delete AverE[kk]; delete[] AverE;
            for(int kk=0; kk<NMarkEKG; kk++) delete AverA[kk]; delete[] AverA;
            CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Memory allocation (NMarkEKG=%d). \n", NMarkEKG);
            return U_ERROR;
        }
        delete[] Evar; Evar=NULL;

        UMatrixSparse MS;
        MS.SetBlockToeplitz(ColRows, NMarkEKG, Nsamples);
        CI.AddToLog("// Sparse Matrix\n%s",(const char*)MS.GetProperties("// "));
        if(OutputBCGArt) MS.WriteXDR(OutputFile.GetDirectory()+UFileName("Sparse.xdr"), true);

        int Neeg = 0; if(CorrectEEG) Neeg = AverE[0]->GetNChan();
        int Nadc = 0; if(CorrectADC) Nadc = AverA[0]->GetNChan();
        for(int ic=0; ic<Neeg+Nadc; ic++)
        {
            int           itol  = 1;
            double        Tol   = 1.e-10;
            int           itmax = 2*Nsamples;
            int           Niter = 0;
            double        Err   = 0;
            const double* ChDat = NULL;

            for(int k=0; k<NMarkEKG; k++)
            {
                if(ic<Neeg)   ChDat = AverE[k]->GetChannelData(ic     );
                else          ChDat = AverA[k]->GetChannelData(ic-Neeg);
                double        Diag  = ColRows[k*(NMarkEKG+1)*2*Nsamples];
                for(int j=0; j<Nsamples; j++) BB[k*Nsamples+j] = ChDat[j];     
                for(int j=0; j<Nsamples; j++) XX[k*Nsamples+j] = ChDat[j]/Diag;
            }
            if(MS.Solve(BB, XX, NMarkEKG*Nsamples, itol, Tol, itmax, &Niter, &Err)!=U_OK)
            {
                delete   EKGEpochs;
                delete[] XX;    delete[] BB; delete[] ColRows;
                delete[] NEKGepochs;
                delete[] EKGOffset;
                {for(int k=0; k<NMarkEKG; k++) delete AverE[k];} delete[] AverE;
                {for(int k=0; k<NMarkEKG; k++) delete AverA[k];} delete[] AverA;
                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Computing co-efficients. \n");
                return U_ERROR;
            }
            if(ic<Neeg) {for(int k=0; k<NMarkEKG; k++) AverE[k]->SetChannelData(XX+k*Nsamples, ic     );}
            else        {for(int k=0; k<NMarkEKG; k++) AverA[k]->SetChannelData(XX+k*Nsamples, ic-Neeg);}
            UString Stat = UString(ic, "Computed artefact template of channel %d") + UString(Neeg+Nadc," of %d (NChan)") + UString(Niter," in %d iterations.");
            SendMessage((const char*)Stat);
            ProcessEvents();
        }
        delete[] XX; delete[] BB; delete[] ColRows;
    }
    else
    {
        int ittot = 0;
        for(int k=0; k<NMarkEKG; k++)
        {
            UString Name = MarkerArray->GetMarkerName(k);
            if(EKGEpochs->SetEpochsMarker(-WinEKGFrom, WinEKGTo, Name)!=U_OK)
            {
                delete EKGEpochs; delete[] NEKGepochs;
                for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error setting ECG epochs. \n");
                return U_ERROR;
            }
            NEKGepochs[k] = EKGEpochs->GetNEpoch();
            EKGOffset[k]  = new int[MAX(1,NEKGepochs[k])];
            if(NEKGepochs[k]<=0 || EKGOffset[k]==NULL)
            {
                delete EKGEpochs; delete EKGEpochs; delete[] NEKGepochs;
                for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Memory allocation error for average ECG artefact, or no events for marker %s. \n", Name);
                return U_ERROR;
            }

            for(int it=0; it<NEKGepochs[k]; it++)
            {
                UString Status = UString(it, "Adding event %d")+UString(Name, " of  EKG marker %s to average");
                SendMessage((const char*)Status);
                ProcessEvents();

                UMultiChan* DataE = NULL; if(CorrectEEG) DataE = EKGEpochs->GetFilteredMultiChan(it,U_DAT_EEG);
                UMultiChan* DataA = NULL; if(CorrectADC) DataA = EKGEpochs->GetFilteredMultiChan(it,U_DAT_ADC);
                if((CorrectEEG && (DataE==NULL || DataE->GetError()!=U_OK)) ||
                   (CorrectADC && (DataA==NULL || DataA->GetError()!=U_OK)))
                {
                    delete EKGEpochs; delete[] NEKGepochs;
                    delete DataE;     delete   DataA;
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error retrieving ECG epoch nr. %i. \n", it);
                    return U_ERROR;
                }
                UEvent Beg         = EKGEpochs->GetEpochs()->GetBegin(it);
                UEvent End         = EKGEpochs->GetEpochs()->GetEnd(it);
                EKGOffset[k][it]   = Beg.GetAbsSample(NsampTrial);
                if(DataE)
                {
                    if(it==0) AverE[k]  = new UMultiChan(*DataE);
                    else    *(AverE[k])+= *DataE;
                }
                if(DataA)
                {
                    if(it==0) AverA[k]  = new UMultiChan(*DataA);
                    else    *(AverA[k])+= *DataA;
                }

                if(OutputBCGArt==true && OverlappingArtifacts==false)
                {
                    if(DataE) CTFoutput.WriteTrial(DataE->GetData(), U_DAT_EEG, ittot);
                    if(DataA) CTFoutput.WriteTrial(DataA->GetData(), U_DAT_ADC, ittot);
                    ittot++;
                }
                delete DataE; delete DataA;
                if((CorrectEEG && (AverE[k]==NULL || AverE[k]->GetError()!=U_OK)) ||
                   (CorrectADC && (AverA[k]==NULL || AverA[k]->GetError()!=U_OK)))
                {
                    delete[] NEKGepochs;
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). computng averag ECG artefact, or no events for marker %s. \n", Name);
                    return U_ERROR;
                }
            }
            if(CorrectEEG)
            {
                (*AverE[k]) /= NEKGepochs[k];
                AverE[k]->RemoveLinearTrend();
            }
            if(CorrectADC)
            {
                (*AverA[k]) /= NEKGepochs[k];
                AverA[k]->RemoveLinearTrend();
            }
        }

        if(AdaptEKGArtefactAmp==true && OverlappingArtifacts==false)
        {
            const double OUTLIERFACTOR = 4.;
            AmpFactorE = new double*[NMarkEKG];
            AmpFactorA = new double*[NMarkEKG];
            if(AmpFactorE && AmpFactorA) 
            {
                for(int n=0; n<NMarkEKG; n++) AmpFactorE[n] = AmpFactorA[n] = NULL;
                for(int n=0; n<NMarkEKG; n++)
                {
                    AmpFactorE[n] = new double[NEKGepochs[n]];
                    AmpFactorA[n] = new double[NEKGepochs[n]];
                    if(AmpFactorE[n]==NULL || AmpFactorA[n]==NULL) 
                    {
                        for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn]; 
                        for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn]; 
                        delete[] AmpFactorE; AmpFactorE = NULL; 
                        delete[] AmpFactorA; AmpFactorA = NULL; 
                        break;
                    }
                }
            }
            if(AmpFactorE==NULL || AmpFactorA==NULL)
            {
                delete EKGEpochs; delete[] NEKGepochs;
                for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
                for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Memory allocation for amplitude factors. \n");
                return U_ERROR;
            }
            for(int k=0; k<NMarkEKG; k++)
            {
                UString Name     = MarkerArray->GetMarkerName(EKGMarkers[k]);
                if(EKGEpochs->SetEpochsMarker(-WinEKGFrom, WinEKGTo, Name)!=U_OK)
                {
                    delete EKGEpochs; delete[] NEKGepochs;
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn];  delete[] EKGOffset; 
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];      delete[] AverE;     
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];      delete[] AverA;     
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn]; delete[] AmpFactorE;
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn]; delete[] AmpFactorA;
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error setting ECG epochs. \n");
                    return U_ERROR;
                }
                CI.AddToLog("Factors of %s \n", (const char*)Name);
                for(int it=0; it<NEKGepochs[k]; it++)
                {
                    UMultiChan* DataE = NULL; if(CorrectEEG) DataE = EKGEpochs->GetFilteredMultiChan(it,U_DAT_EEG);
                    UMultiChan* DataA = NULL; if(CorrectADC) DataA = EKGEpochs->GetFilteredMultiChan(it,U_DAT_ADC);
                    if((CorrectEEG && (DataE==NULL || DataE->GetError()!=U_OK)) ||
                       (CorrectADC && (DataA==NULL || DataA->GetError()!=U_OK)))
                    {
                        delete   DataE; delete   DataA;
                        delete[] NEKGepochs;
                        for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn];  delete[] EKGOffset; 
                        for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];      delete[] AverE;     
                        for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];      delete[] AverA;     
                        for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn]; delete[] AmpFactorE;
                        for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn]; delete[] AmpFactorA;
                        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error retrieving ECG epoch nr. in amplidude determination phase. %d. \n", it);
                        return U_ERROR;
                    }
                    if(DataE) DataE->RemoveLinearTrend();
                    if(DataA) DataA->RemoveLinearTrend();

                    AmpFactorE[k][it] = 0.; 
                    AmpFactorA[k][it] = 0.; 
                    if(DataE) AmpFactorE[k][it]  = DataE->GetAmplitudeFactor(AverE[k], OUTLIERFACTOR);
                    if(DataA) AmpFactorA[k][it]  = DataA->GetAmplitudeFactor(AverA[k], OUTLIERFACTOR);
                    delete DataE; delete DataA;

                    CI.AddToLog("%f \t", AmpFactorE[k][it]);
                    CI.AddToLog("%f \t", AmpFactorA[k][it]);
                }
                CI.AddToLog("\n");
            }
        }
    }

/* Write header of BCG corrected CTF file */
    CTFoutput = UMEEGDataWriteCTF(*Epo->GetData()); 
    CTFoutput.SetDataFileName(OutputFile);
    CTFoutput.SetNtrial(Epo->GetNEpoch());
    CTFoutput.SetNsampTrial(Epo->GetNSampEpoch(0));
    CTFoutput.SetSampleRate(Epo->GetData()->GetSampleRate());
    CTFoutput.AddComment((const char*) Comment);
    CTFoutput.SetGridMEG(NULL);
    if(NOT(CorrectADC))
    {
        if(EPRImport && EPRImport->GetMergedGrid()) CTFoutput.SetGridADC(EPRImport->GetMergedGrid());
        else                                        CTFoutput.SetGridADC(NULL);
    }
    CTFoutput.WriteHeader();

/* Write trials of BCG corrected CTF file */
    for(int it=0; it<Epo->GetNEpoch(); it++)
    {
        UString Stat(it, "Trial %d: Correcting for pulse artefact ...");
        SendMessage((const char*)Stat);
        ProcessEvents();

        UMultiChan* DataE = NULL; if(CorrectEEG) DataE = Epo->GetFilteredMultiChan(it,U_DAT_EEG);
        UMultiChan* DataA = NULL; if(CorrectADC) DataA = Epo->GetFilteredMultiChan(it,U_DAT_ADC);
        if((CorrectEEG && (DataE==NULL || DataE->GetError()!=U_OK)) ||
           (CorrectADC && (DataA==NULL || DataA->GetError()!=U_OK)))
        {
            delete DataE;     delete   DataA;
            delete EKGEpochs; delete[] NEKGepochs;
            for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn];  delete[] EKGOffset; 
            for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];      delete[] AverE;     
            for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];      delete[] AverA;     
            if(AmpFactorE) {for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn]; delete[] AmpFactorE;}
            if(AmpFactorA) {for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn]; delete[] AmpFactorA;}

            CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Error retrieving epoch nr. %i. \n", it);
            return U_ERROR;
        }
        UEvent  Begin    = Epo ->GetEpochs()->GetBegin(it);
        UEvent  End      = Epo ->GetEpochs()->GetEnd  (it);
        int     AbsBegin = Begin.GetAbsSample(NsampTrial);
        if(OverlappingArtifacts==true)
        {
            for(int k=0; k<NMarkEKG; k++)
            {
                UMarker  MM(*MarkerArray->GetMarker(EKGMarkers[k]));
                MM.SortEvents();

                for(int iev=0; iev<MM.GetnEvents(); iev++)
                {
                    int Shift = MM.GetAbsSample(iev) - WinEKGFrom - AbsBegin; // Shift applied to template
                    if(DataE && DataE->ShiftSubstract(*(AverE[k]), Shift)!=U_OK)
                    {
                        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %d, trial %d. \n", iev, it);
                        UString Text(it, "Warning: Error occurred in pulse correction for trial %d"); 
                        SendMessage((const char*)Text);
                    }
                    if(DataA && DataA->ShiftSubstract(*(AverA[k]), Shift)!=U_OK)
                    {
                        CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %d, trial %d. \n", iev, it);
                        UString Text(it, "Warning: Error occurred in pulse correction for trial %d"); 
                        SendMessage((const char*)Text);
                    }
                }
            }
        }
        else
        {
            for(int n=0; n<NMarkEKG; n++)
            {
                for(int k=0; k<NEKGepochs[n]; k++)
                {
                    int Shift = EKGOffset[n][k] - AbsBegin;
                    if(DataE)
                    {
                        if(AmpFactorE)
                        {
                            UMultiChan AverFact = *(AverE[n]);
                            AverFact           *= AmpFactorE[n][k];
                            if(DataE->ShiftSubstract(AverFact, Shift)!=U_OK)
                            {
                                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %i, trial %i (amp fact on). \n", k, it);
                                UString Text(it,"Warning: Error occurred in pulse correction for trial %d");
                                SendMessage((const char*)Text);
                            }
                        }
                        else
                        {
                            if(DataE->ShiftSubstract(*(AverE[n]), Shift)!=U_OK)
                            {
                                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %i, trial %i. \n", k, it);
                                UString Text(it,"Warning: Error occurred in pulse correction for trial %d");
                                SendMessage((const char*)Text);
                            }
                        }
                    }
                    if(DataA)
                    {
                        if(AmpFactorA)
                        {
                            UMultiChan AverFact = *(AverA[n]);
                            AverFact           *= AmpFactorA[n][k];
                            if(DataA->ShiftSubstract(AverFact, Shift)!=U_OK)
                            {
                                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %i, trial %i (amp fact on). \n", k, it);
                                UString Text(it,"Warning: Error occurred in pulse correction for trial %d");
                                SendMessage((const char*)Text);
                            }
                        }
                        else
                        {
                            if(DataA->ShiftSubstract(*(AverA[n]), Shift)!=U_OK)
                            {
                                CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). ShiftSubtract() returned error for pulse occurrence %i, trial %i. \n", k, it);
                                UString Text(it,"Warning: Error occurred in pulse correction for trial %d");
                                SendMessage((const char*)Text);
                            }
                        }
                    }
                }
            }
        }
        if(DataE) CTFoutput.WriteTrial(DataE->GetData(), U_DAT_EEG, it);
        if(DataA) CTFoutput.WriteTrial(DataA->GetData(), U_DAT_ADC, it);
        delete DataE; delete DataA;

        if(NOT(CorrectADC))
        {
            if(EPRImport && EPRImport->GetMergedGrid())
            {
                UMultiChan* DataADC = EPRImport->GetMergedADCMultiChan(Epo, it);
                if(DataADC==NULL || CTFoutput.WriteTrial(DataADC->GetData(), U_DAT_ADC, it) !=U_OK)
                {
                    delete EKGEpochs; delete[] NEKGepochs; delete   DataADC;
                    for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn];  delete[] EKGOffset; 
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];      delete[] AverE;     
                    for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];      delete[] AverA;     
                    if(AmpFactorE) {for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn]; delete[] AmpFactorE;}
                    if(AmpFactorA) {for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn]; delete[] AmpFactorA;}
                    CI.AddToLog("ERROR UEEGfMRITool::ComputeCorrectedBCG(). Inserting EPR data in volume %d \n", it);
                    return U_ERROR;
                }
                delete DataADC;
            }
        }
    }
    if(AmpFactorE)  for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorE[nn];  delete[] AmpFactorE; 
    if(AmpFactorA)  for(int nn=0; nn<NMarkEKG; nn++) delete[] AmpFactorA[nn];  delete[] AmpFactorA; 
    

    if(OutputAvBCG==true)
    {
        SendMessage("Writing average pulse artefact ...");
        UMEEGDataWriteCTF CTFout(*EKGEpochs->GetData()); 
        CTFout.SetDataFileName(OutputFile.GetDirectory()+UFileName("EKGartAver.ds"));
        CTFout.SetNtrial(NMarkEKG);
        CTFout.SetNsampTrial(Nsamples);
        CTFout.SetSampleRate(Epo->GetData()->GetSampleRate());
        CTFoutput.AddComment((const char*) Comment);
        CTFout.WriteHeader();
        for(int n=0; n<NMarkEKG; n++)
        {
            if(CorrectEEG) CTFout.WriteTrial(AverE[n]->GetData(), U_DAT_EEG, n);
            if(CorrectADC) CTFout.WriteTrial(AverA[n]->GetData(), U_DAT_ADC, n);
        }
    }
    delete EKGEpochs; delete[] NEKGepochs;
    for(int nn=0; nn<NMarkEKG; nn++) delete[] EKGOffset[nn]; delete[] EKGOffset;
    for(int nn=0; nn<NMarkEKG; nn++) delete   AverE[nn];     delete[] AverE;    
    for(int nn=0; nn<NMarkEKG; nn++) delete   AverA[nn];     delete[] AverA;    
    return U_OK;
} 

void UEPRADC::SetAllMembersDefault()
{
    error       = U_OK;
    EPRGrid     = UGrid();
    MergedGrid  = UGrid();
    
    EpoEKG      = NULL;
    InterEKG    = NULL;
    EpoPulse    = NULL;
    InterPulse  = NULL;
    EpoResp     = NULL;
    InterResp   = NULL;
    EpoADC      = NULL;
    InterADC    = NULL;
    MarTemplate = NULL;
}
void UEPRADC::DeleteAllMembers(ErrorType E)
{
    delete EpoEKG;
    delete InterEKG;
    delete EpoPulse;
    delete InterPulse;
    delete EpoResp;
    delete InterResp;
    delete EpoADC;
    delete InterADC;
    delete MarTemplate;

    SetAllMembersDefault();
    error = E;
}

UEPRADC::UEPRADC()
{
    SetAllMembersDefault();
}
UEPRADC::UEPRADC(const UEPRADC& EPR)
{
    SetAllMembersDefault();
    *this = EPR;
}
UEPRADC::UEPRADC(const char* LogFile, const char*VolMark, int NdumVol, const UMEEGDataEpochs* InputData)
{
    SetAllMembersDefault();
    if(InputData==NULL            || InputData->GetError()!=U_OK ||
       InputData->GetData()==NULL || InputData->GetEpochs()==NULL)
    {
        CI.AddToLog("ERROR: UEPRADC::UEPRADC(). InputData NULL, erronous or not set. \n");
        error = U_ERROR;
        return;
    }
    if(LogFile==NULL || LogFile[0]==0)
    {
        CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Invalid NULL or empty argument for file name.\n");
        error = U_ERROR;
        return;
    }

    if(InputData->GetEpochs()->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UEPRADC::UEPRADC(). InputData has no constant epochs. \n");
        error = U_ERROR;
        return;
    }
    int Nvol     = InputData->GetNEpoch();
    int NtimeEEG = InputData->GetEpochs()->GetNsamp(0);

    if(InputData->GetData()->GetGridADC())
        MergedGrid = UGrid(*InputData->GetData()->GetGridADC());

    UFileName Efile(LogFile); Efile.SetExtension(".ecg");   bool E = Efile.DoesFileExist();
    UFileName Pfile(LogFile); Pfile.SetExtension(".puls");  bool P = Pfile.DoesFileExist();
    UFileName Rfile(LogFile); Rfile.SetExtension(".resp");  bool R = Rfile.DoesFileExist();

    MarTemplate = new UMarkerArray();
    if(E==true||P==true||R==true)
    {
        if(E)
        {    
            UFileName F = Efile;
            EpoEKG = new UMEEGDataEpochs(F);
            if(EpoEKG==NULL || EpoEKG->GetError()!=U_OK || EpoEKG->GetData()==NULL ||
               EpoEKG->GetData()->GetMarkerArray()==NULL)
            {
                CI.AddToLog("WARNING: UEPRADC::UEPRADC(). Skipping Erroneous EKG data object. \n");
            }
            else
            {
                const UMarker* M = EpoEKG->GetData()->GetMarkerArray()->GetMarker("TR");
                if(M==NULL || M->GetError()!=U_OK) 
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). TR-marker not present in %s. \n", (const char*)F);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(M->GetnEvents()-NdumVol != Nvol)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Number of events TR-marker (%d) does not match number of dummies (%d) and number of volumes (%d) (EKG). \n", M->GetnEvents(), NdumVol, Nvol);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                CI.AddToLog("Note: UEPRADC::UEPRADC(). Minimum TR-interval = %d, maximum TR-interval=%d (EKG). \n", M->GetMinInterval(), M->GetMaxInterval());

                int Nsamp = M->GetMedianInterval();
                if(EpoEKG->SetEpochsMarker(0, Nsamp-1, M)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting EKG epochs. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(NdumVol>0 && EpoEKG->ExcludeEpochs(0,NdumVol-1)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting EKG epochs range. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                UMarkerArray Mlog(*EpoEKG->GetData()->GetMarkerArray());
                Mlog.RedistributeTrials(EpoEKG->GetEpochs(), InputData->GetSampleRate());
                Mlog.PrependName(-1, "EKG_");
                MarTemplate->MergeMarkerArray(&Mlog);

/* Create interpolation object */
                InterEKG = new UInterpolate(Nsamp, NtimeEEG, U_INTERPOL_FFT);
                if(InterEKG==NULL || InterEKG->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Creating UInterpolate-object for EKG. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                USensor S(UVector3(-20.,0.,0.), UVector3(1.,0.,0.), UVector3(-1.,0.,0.), USensor::U_SEN_POINT, "EKG");
                if(EPRGrid.AddSensor(S)!=U_OK || MergedGrid.AddSensor(S)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Adding EKG sensor. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
            }
        }
        if(P)
        {    
            UFileName F = Pfile;
            EpoPulse = new UMEEGDataEpochs(F);
            if(EpoPulse==NULL || EpoPulse->GetError()!=U_OK || EpoPulse->GetData()==NULL ||
               EpoPulse->GetData()->GetMarkerArray()==NULL)
            {
                CI.AddToLog("WARNING: UEPRADC::UEPRADC(). Skipping Erroneous Pulse data object. \n");
            }
            else
            {
                const UMarker* M = EpoPulse->GetData()->GetMarkerArray()->GetMarker("TR");
                if(M==NULL || M->GetError()!=U_OK) 
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). TR-marker not present in %s. \n", (const char*)F);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(M->GetnEvents()-NdumVol != Nvol)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Number of events TR-marker (%d) does not match number of dummies (%d) and number of volumes (%d) (Pulse). \n", M->GetnEvents(), NdumVol, Nvol);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                CI.AddToLog("Note: UEPRADC::UEPRADC(). Minimum TR-interval = %d, maximum TR-interval=%d (Pulse). \n", M->GetMinInterval(), M->GetMaxInterval());

                int Nsamp = M->GetMedianInterval();
                if(EpoPulse->SetEpochsMarker(0, Nsamp-1, M)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting Pulse epochs. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(NdumVol>0 && EpoPulse->ExcludeEpochs(0,NdumVol-1)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting Pulse epochs range. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                UMarkerArray Mlog(*EpoPulse->GetData()->GetMarkerArray());
                Mlog.RedistributeTrials(EpoPulse->GetEpochs(), InputData->GetSampleRate());
                Mlog.PrependName(-1, "Pulse_");
                MarTemplate->MergeMarkerArray(&Mlog);

/* Create interpolation object */
                InterPulse = new UInterpolate(Nsamp, NtimeEEG, U_INTERPOL_FFT);
                if(InterPulse==NULL || InterPulse->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Creating UInterpolate-object for Pulse. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                USensor S(UVector3(-30.,0.,0.), UVector3(1.,0.,0.), UVector3(-1.,0.,0.), USensor::U_SEN_POINT,"Pulse");
                if(EPRGrid.AddSensor(S)!=U_OK || MergedGrid.AddSensor(S)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Adding Pulse sensor. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
            }
        }
        if(R)
        {    
            UFileName F(Rfile);
            EpoResp = new UMEEGDataEpochs(F);
            if(EpoResp==NULL || EpoResp->GetError()!=U_OK || EpoResp->GetData()==NULL ||
               EpoResp->GetData()->GetMarkerArray()==NULL)
            {
                CI.AddToLog("WARNING: UEPRADC::UEPRADC(). Skipping Erroneous Resp data object. \n");
            }
            else
            {
                const UMarker* M = EpoResp->GetData()->GetMarkerArray()->GetMarker("TR");
                if(M==NULL || M->GetError()!=U_OK) 
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). TR-marker not present in %s. \n", (const char*)F);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(M->GetnEvents()-NdumVol != Nvol)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Number of events TR-marker (%d) does not match number of dummies (%d) and number of volumes (%d) (Resp). \n", M->GetnEvents(), NdumVol, Nvol);
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                CI.AddToLog("Note: UEPRADC::UEPRADC(). Minimum TR-interval = %d, maximum TR-interval=%d (Resp). \n", M->GetMinInterval(), M->GetMaxInterval());

                int Nsamp = M->GetMedianInterval();

                if(EpoResp->SetEpochsMarker(0, Nsamp-1, M)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting Resp epochs. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                if(NdumVol>0 && EpoResp->ExcludeEpochs(0,NdumVol-1)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting Resp epochs range. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                UMarkerArray Mlog(*EpoResp->GetData()->GetMarkerArray());
                Mlog.RedistributeTrials(EpoResp->GetEpochs(), InputData->GetSampleRate());
                Mlog.PrependName(-1, "Resp_");
                MarTemplate->MergeMarkerArray(&Mlog);

/* Create interpolation object */
                InterResp = new UInterpolate(Nsamp, NtimeEEG, U_INTERPOL_FFT);
                if(InterResp==NULL || InterResp->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Creating UInterpolate-object for Resp. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
                USensor S(UVector3(-20.,0.,0.), UVector3(1.,0.,0.), UVector3(-1.,0.,0.), USensor::U_SEN_POINT, "Resp");
                if(EPRGrid.AddSensor(S)!=U_OK || MergedGrid.AddSensor(S)!=U_OK)
                {
                    CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Adding Resp sensor. \n");
                    DeleteAllMembers(U_ERROR); 
                    return;
                }
            }
        }
    }
    else
    {
        UFileName F(LogFile);
        EpoADC = new UMEEGDataEpochs(F);
        if(EpoADC==NULL || EpoADC->GetError()!=U_OK || EpoADC->GetData()==NULL ||
            EpoADC->GetData()->GetMarkerArray()==NULL || EpoADC->GetData()->GetNADC()<=0)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Invalid data file: %s . \n", (const char*)F);
            DeleteAllMembers(U_ERROR);
            return;
        }

        const UMarker* M = EpoADC->GetData()->GetMarkerArray()->GetMarker(VolMark);
        if(M==NULL || M->GetError()!=U_OK) 
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Trigger-marker not present in %s. \n", (const char*)F);
            DeleteAllMembers(U_ERROR); 
            return;
        }
        if(M->GetnEvents()-NdumVol != Nvol)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Number of events TR-marker (%d) does not match number of dummies (%d) and number of volumes (%d) (EKG). \n", M->GetnEvents(), NdumVol, Nvol);
            DeleteAllMembers(U_ERROR); 
            return;
        }
        CI.AddToLog("Note: UEPRADC::UEPRADC(). Minimum Event-interval = %d, maximum Event-interval=%d (ADC). \n", M->GetMinInterval(), M->GetMaxInterval());

        int Nsamp = M->GetMedianInterval();
        if(EpoADC->SetEpochsMarker(0, Nsamp-1, M)!=U_OK)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting epochs for merged data file. \n");
            DeleteAllMembers(U_ERROR); 
            return;
        }
        if(NdumVol>0 && EpoADC->ExcludeEpochs(0,NdumVol-1)!=U_OK)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Setting epochs range. \n");
            DeleteAllMembers(U_ERROR); 
            return;
        }
        UMarkerArray Mlog(*EpoADC->GetData()->GetMarkerArray());
        Mlog.RedistributeTrials(EpoADC->GetEpochs(), InputData->GetSampleRate());
        Mlog.PrependName(-1, "ADC_");
        MarTemplate->MergeMarkerArray(&Mlog);

/* Create interpolation object */
        InterADC = new UInterpolate(Nsamp, NtimeEEG, U_INTERPOL_FFT);
        if(InterADC==NULL || InterADC->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Creating UInterpolate-object for merged data file. \n");
            DeleteAllMembers(U_ERROR); 
            return;
        }
        const UGrid* GADC = EpoADC->GetData()->GetGridADC();
        if(EPRGrid.AddGrid(GADC)!=U_OK || MergedGrid.AddGrid(GADC)!=U_OK)
        {
            CI.AddToLog("ERROR: UEPRADC::UEPRADC(). Adding ADC sensor(s). \n");
            DeleteAllMembers(U_ERROR); 
            return;
        }
    }
}

UEPRADC::~UEPRADC()
{
    DeleteAllMembers(U_OK);
}

UEPRADC& UEPRADC::operator=(const UEPRADC& EPR)
{
    if(this==NULL)
    {
        static UEPRADC Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: UEPRADC::operator=(). this==NULL. \n");
        return Def;
    }
    if(&EPR==NULL)
    {
        CI.AddToLog("ERROR: UEPRADC::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&EPR) return *this;

    DeleteAllMembers(U_OK);
    error      = EPR.error;
    EPRGrid    = EPR.EPRGrid;
    MergedGrid = EPR.MergedGrid;
    
    if(EPR.EpoEKG)
    {
        EpoEKG = new UMEEGDataEpochs(*EPR.EpoEKG);
        if(EpoEKG==NULL || EpoEKG->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying EpoEKG. \n");
            return *this;
        }
    }
    if(EPR.InterEKG)
    {
        InterEKG = new UInterpolate(*EPR.InterEKG);
        if(InterEKG==NULL || InterEKG->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying InterEKG. \n");
            return *this;
        }
    }
    if(EPR.EpoPulse)
    {
        EpoPulse = new UMEEGDataEpochs(*EPR.EpoPulse);
        if(EpoPulse==NULL || EpoPulse->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying EpoPulse. \n");
            return *this;
        }
    }
    if(EPR.InterPulse)
    {
        InterPulse = new UInterpolate(*EPR.InterPulse);
        if(InterPulse==NULL || InterPulse->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying InterPulse. \n");
            return *this;
        }
    }
    if(EPR.EpoResp)
    {
        EpoResp = new UMEEGDataEpochs(*EPR.EpoResp);
        if(EpoResp==NULL || EpoResp->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying EpoResp. \n");
            return *this;
        }
    }
    if(EPR.InterResp)
    {
        InterResp = new UInterpolate(*EPR.InterResp);
        if(InterResp==NULL || InterResp->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying InterResp. \n");
            return *this;
        }
    }
    if(EPR.EpoADC)
    {
        EpoADC = new UMEEGDataEpochs(*EPR.EpoADC);
        if(EpoADC==NULL || EpoADC->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying EpoADC. \n");
            return *this;
        }
    }
    if(EPR.InterADC)
    {
        InterADC = new UInterpolate(*EPR.InterADC);
        if(InterADC==NULL || InterADC->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying InterADC. \n");
            return *this;
        }
    }
    if(EPR.MarTemplate)
    {
        MarTemplate = new UMarkerArray(*EPR.MarTemplate);
        if(MarTemplate==NULL || MarTemplate->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEPRADC::operator=(). Copying MarTemplate. \n");
            return *this;
        }
    }
    return *this;
}

const UGrid* UEPRADC::GetEPRGrid()   const 
{
    if(EPRGrid.GetNpoints()<=0) return NULL;
    return &EPRGrid;  
}
const UGrid* UEPRADC::GetMergedGrid() const 
{
    if(MergedGrid.GetNpoints()<=0) return NULL;
    return &MergedGrid;
}
UMultiChan* UEPRADC::GetMergedADCMultiChan(UMEEGDataEpochs* InputData, int ivol) const
{
    if(InputData==NULL            || InputData->GetError()!=U_OK ||
       InputData->GetData()==NULL || InputData->GetEpochs()==NULL)
    {
        CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). InputData NULL, erronous or not set. \n");
        return NULL;
    }
    if(ivol<0 || ivol>=InputData->GetNEpoch())
    {
        CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Erroneous volume (%d) . \n", ivol);
        return NULL;
    }
    
    UMultiChan* OldADC   = NULL;
    if(InputData->GetData()->GetGridADC()) 
    {
        OldADC = InputData->GetFilteredMultiChan(ivol,U_DAT_ADC);
        if(OldADC==NULL || OldADC->GetError()!=U_OK)
        {
            delete OldADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Reading existing ADC channels\n");
            return NULL;
        }
    }

    int         NChan   = EPRGrid.GetNpoints();
    int         Nsamp   = 0;
    double*     DataADC = NULL;
    if( (EpoEKG    && InterEKG  ) ||
        (EpoPulse  && InterPulse) ||
        (EpoResp   && InterResp ))
    {
        Nsamp = -1;
        if(EpoEKG  && InterEKG  ) Nsamp = InterEKG  ->GetNsampOutput();
        if(EpoPulse&& InterPulse) Nsamp = InterPulse->GetNsampOutput();
        if(EpoResp && InterResp ) Nsamp = InterResp ->GetNsampOutput();
    
        if(NChan<=0 || Nsamp<=0)
        {
            delete OldADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Invalid NChan (=%d) or Nsamp (=%d) .\n", NChan, Nsamp);
            return NULL;
        }
        DataADC = new double[NChan*Nsamp];
        if(DataADC==NULL)
        {
            delete OldADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan() Memory allocation. \n");
            return NULL;
        }

/* Read data*/    
        int ichan =  0;
        if(EpoEKG  && InterEKG  ) 
        {
            if(ivol>=EpoEKG->GetNEpoch())
            {
                CI.AddToLog("WARNING: UEPRADC::GetMergedADCMultiChan(). Volume number out of range (ivol=%d). Seeting EKG-data to zero. \n", ivol);
                for(int j=0; j<Nsamp; j++) DataADC[ichan*Nsamp+j] = 0;
            }
            else
            {
                UMultiChan* MC = EpoEKG->GetFilteredMultiChan(ivol, U_DAT_EKG, 0);
                if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Getting EKG from volume %d. \n", ivol);
                    return NULL;
                }
                if(InterEKG->Resample(MC->GetData(), DataADC+ichan*Nsamp)!=U_OK)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Resampling EKG from volume %d. \n", ivol);
                    return NULL;
                }
                delete MC;
            }
            ichan++;
        }
        if(EpoPulse&& InterPulse  ) 
        {
            if(ivol>=EpoPulse->GetNEpoch())
            {
                CI.AddToLog("WARNING: UEPRADC::GetMergedADCMultiChan(). Volume number out of range (ivol=%d). Seeting Pulse-data to zero. \n", ivol);
                for(int j=0; j<Nsamp; j++) DataADC[ichan*Nsamp+j] = 0;
            }
            else
            {
                UMultiChan* MC = EpoPulse->GetFilteredMultiChan(ivol, U_DAT_EKG, 0);
                if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Getting Pulse from volume %d. \n", ivol);
                    return NULL;
                }
                if(InterPulse->Resample(MC->GetData(), DataADC+ichan*Nsamp)!=U_OK)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Resampling Pulse from volume %d. \n", ivol);
                    return NULL;
                }
                delete MC;
            }
            ichan++;
        }
        if(EpoResp && InterResp ) 
        {
            if(ivol>=EpoResp->GetNEpoch())
            {
                CI.AddToLog("WARNING: UEPRADC::GetMergedADCMultiChan(). Volume number out of range (ivol=%d). Seeting Resp-data to zero. \n", ivol);
                for(int j=0; j<Nsamp; j++) DataADC[ichan*Nsamp+j] = 0;
            }
            else
            {
                UMultiChan* MC = EpoResp->GetFilteredMultiChan(ivol, U_DAT_EKG, 0);
                if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Getting Resp from volume %d. \n", ivol);
                    return NULL;
                }
                if(InterResp->Resample(MC->GetData(), DataADC+ichan*Nsamp)!=U_OK)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Resampling Resp from volume %d. \n", ivol);
                    return NULL;
                }
                delete MC;
            }
            ichan++;
        }
    }
    else if(EpoADC&&InterADC)
    {
        Nsamp = InterADC->GetNsampOutput();
        if(NChan<=0 || Nsamp<=0)
        {
            delete OldADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Invalid NChan (=%d) or Nsamp (=%d) .\n", NChan, Nsamp);
            return NULL;
        }
        DataADC = new double[NChan*Nsamp];
        if(DataADC==NULL)
        {
            delete OldADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan() Memory allocation. \n");
            return NULL;
        }
        for(int ij=0; ij<NChan*Nsamp; ij++) DataADC[ij] = 0;

/* Read data*/    
        if(ivol>=EpoADC->GetNEpoch())
        {
            CI.AddToLog("WARNING: UEPRADC::GetMergedADCMultiChan(). Volume number out of range (ivol=%d). Setting ADC-data to zero. \n", ivol);
            for(int ij=0; ij<Nsamp*NChan; ij++) DataADC[ij] = 0;
        }
        else
        {
            UMultiChan* MC = EpoADC->GetFilteredMultiChan(ivol, U_DAT_ADC, -1);
            if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
            {
                delete   OldADC;  delete MC;
                delete[] DataADC;
                CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Getting ADC for volume %d. \n", ivol);
                return NULL;
            }
            for(int ichan=0; ichan<MC->GetNChan(); ichan++)
            {
                if(InterADC->Resample(MC->GetChannelData(ichan), DataADC+ichan*Nsamp)!=U_OK)
                {
                    delete   OldADC;  delete MC;
                    delete[] DataADC;
                    CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Resampling ADC for volume %d. \n", ivol);
                    return NULL;
                }
            }
            delete MC;
        }
    }

    UMultiChan* NewADC = new UMultiChan(DataADC, &EPRGrid, Nsamp, InputData->GetData()->GetSampleTime_s());
    delete[] DataADC;
    if(NewADC==NULL || NewADC->GetError()!=U_OK)
    {
        delete OldADC; delete NewADC;
        CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Conversion to UMultichan. \n");
        return NULL;
    }

    if(NewADC||OldADC)
    {
        UMultiChan* MergedADC = new UMultiChan();
        if(MergedADC==NULL || MergedADC->GetError()!=U_OK) 
        {
            delete OldADC; delete NewADC;
            delete MergedADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Creating merged UMultichan. \n");
            return NULL;
        }
        
        ErrorType ADCError = U_OK;
        if(ADCError==U_OK&&OldADC) ADCError = MergedADC->MergeChannels(*OldADC);
        if(ADCError==U_OK&&NewADC) ADCError = MergedADC->MergeChannels(*NewADC);

        delete OldADC; delete NewADC;
        if(ADCError!=U_OK)
        {
            delete MergedADC;
            CI.AddToLog("ERROR: UEPRADC::GetMergedADCMultiChan(). Merging UMultiChan  parts. \n");
            return NULL;
        }
        return MergedADC;
    }
    return NULL; // OK, both parts are zero
}

