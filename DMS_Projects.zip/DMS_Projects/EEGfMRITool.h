#ifndef _EEGFMRITOOL_INCLUDED
#define _EEGFMRITOOL_INCLUDED


#include "MEEGDataEpochs.h"
#include "Grid.h"

class UEPRADC;

#define MAXEKGMARKERS 32

class DLL_IO UEEGfMRITool
{
public:
    UEEGfMRITool();
    ~UEEGfMRITool();

    ErrorType                   GetError(void) {if(this) return error; return U_ERROR;}
    const UString&              GetProperties(UString Comment) const;

    ErrorType                   SetTemplateData(const UMEEGDataEpochs* TemplData);
    ErrorType                   SetOutputDataFile(UFileName OutputFileName);
    ErrorType                   SetVolumeMarker(UString VolName);

    ErrorType                   SetCorrectVolumes(bool Apply, UString VolNameBAD, bool SetSkippedToZero);
    ErrorType                   ApplySubGroups(bool Apply, int SizeSub);
    ErrorType                   ApplyPartionFile(bool Apply, UFileName PartFileName);
    ErrorType                   SetPostProcess(bool DownSample, double DownSampleFreq, bool ApplyLowPass);
    ErrorType                   CorrectDataTypes(bool CorEEG, bool CorADC, bool CorEKG);

    ErrorType                   SetCorrectSlices(bool Apply, int NSli, double Tim2SLi, double SliTim, TimeShiftType Inter, bool IgnoreShift);
    ErrorType                   SetCorrectRFPulse(bool Apply, int BeginSamp, int EndSamp);
    ErrorType                   SetCorrectRefLayer(bool Apply, int Ncomp, double RLasLow, double RLasHigh);

    ErrorType                   SetCorrectBCG(bool Apply, int NEKG, int BeginSamp, int EndSamp, double OutFrac, bool Overlap, bool AdaptAmp, bool CopyFilt);
    ErrorType                   SetEKGMarker(UString Name);
    ErrorType                   OutputBCGArtefacts(bool AllArtefacts, bool Averge);

    ErrorType                   SetMergeLogFile(bool Apply, UFileName LogFile, UString VolName, int NDummy);

    ErrorType                   ComputeSaveCorrectedData(void);

protected:
    virtual void                ShowStatus(const char* Status)                          {if(Status ) CI.AddToLog(Status);}
    virtual void                ShowStatus(const char* Status, int istep, int Nstep)    {if(Status ) CI.AddToLog(Status,istep, Nstep);}
    virtual void                SendMessage(const char* Message)                        {if(Message) CI.AddToLog(Message);}
    virtual void                ProcessEvents()                                         {return;}

    static ErrorType            CorrectDataSlices(const UMEEGDataEpochs* Epo, double VolTime, double SliceTime, double TimeToSlice, int ivol, int NSli, bool IgnoreVolumeShift, TimeShiftType TST, UMultiChan* DataVol);
    static int                  CompSliceOffSet(const UMEEGDataEpochs* Epo, double VolTime, double SliceTime, double TimeToSlice, int ivol, int isli, bool IgnoreVolumeShift, double* Delta);

    void                        SetAllMembersDefault(void);
    void                        DeleteAllMembers(ErrorType E);

    const UMEEGDataEpochs*      TemplateData;
    static UString              Properties;
private:
    ErrorType                   error;
    UFileName                   OutputFile;           //      = GetUFileName(LE_FileName->text());

    bool                        CorrectEEG;           // = CB_CorrectEEG->isChecked();
    bool                        CorrectADC;           // = CB_CorrectADC->isChecked();
    bool                        CorrectEKG;           // = CB_VolSliceCorrectEKG->isChecked()

    bool                        CorrectVolumes;       //VolCorr         = CB_CorrectVol         ->isChecked();
    int                         iMarkVol;
    int                         iMarkVolSkip;            // <0 then dont skip
    bool                        SkippedToZero;           //CB_SkippedToZero->isChecked()
    bool                        VolSubGroups;
    int                         VolSubGroupSize;
    bool                        UsePartitionFile;       ///    if(RB_Vol_PartitionFile->isChecked())
    UFileName                   PartitionFile;         ///                    UFileName F = GetUFileName(LE_VolPartitionFile->text());

    bool                        ApplyLowPass3;         ////CB_LowPass->isChecked()
    bool                        DownSamp;             //// = CB_DownSample->isChecked();
    double                      DownSampFres;       //// = SBD_DownSample->GetDoubleValue();

    bool                        CorrectSlices;       ///SliceCorr       = CB_CorrectSlices      ->isChecked();
    int                         NSlices;
    double                      TimeToSlice;
    double                      SliceTime;
    TimeShiftType               InterpolationType;
    bool                        IgnoreTimeShift;         /// = RB_Vol_PartitionFile      ->isChecked() &&   CB_SkipTimeShiftCorrection->isChecked(); 

    bool                        CorrectRF;          ////LinInt          = CB_CorrectRF          ->isChecked();
    int                         WinRFFrom;                        ////   double  BegInt;
    int                         WinRFTo;                       ////double                 EndInt;
    bool                        CorrectRefLayer;
    int                         NcompRefLayer;
    double                      BandRefLayerLow;
    double                      BandRefLayerHigh;

    bool                        CorrectBCG;                 ////EKGCorr         = CB_CorrectBCG         ->isChecked();
    int                         NMarkEKG;
    int                         EKGMarkers[MAXEKGMARKERS];                 ///// GetUString(LW_EKGMarkerSelected->item(n))///    UString*               EKGMarkers ; // GetUString(LW_EKGMarkerSelected->item(n))
    int                         WinEKGFrom;
    int                         WinEKGTo;
    bool                        OverlappingArtifacts;       /// = CB_OverlappingHBWindows->isChecked();
    double                      BCGOutlierFraction;          ////  0.01 * SB_RemoveOutliers->value();
    bool                        AdaptEKGArtefactAmp;
    bool                        ApplyBPFilter;              ///     = CB_ApplyBandPassFilter->isChecked();
    bool                        OutputBCGArt;               ////;     = CB_ExportAllEKG       ->isChecked();
    bool                        OutputAvBCG;                ////= CB_ExportAverageEKG   ->isChecked();

    bool                        MergeLog;                   //   = CB_MergeLog  ->isChecked()
    UString                     MergeVolMarker;             /// = GetUString(CB_VolMarkerMerge->currentText())
    UFileName                   MergeLogFile;               //// = LE_LogFileName  ->text()
    int                         MergeLogNDummy;             //// = SB_Ndummy->value()

    ErrorType                   ComputeCorrectedBCG(UMEEGDataEpochs* Epo, const UString& Comment, const UEPRADC* EPRImport);

    double                      GetVolTime(void) const;
    bool                        IsVolumeMarkerSet(void) const;
    virtual ErrorType           CopyEpDat(UMEEGDataEpochs** EpDatTo, const UMEEGDataEpochs* EpDatFrom) const;
};

class DLL_IO UEPRADC
{
public:
    UEPRADC();
    UEPRADC(const char* LogFile, const char*VolMark, int Ndum, const UMEEGDataEpochs* InputData);
    UEPRADC(const UEPRADC& EPR);
    ~UEPRADC();
    UEPRADC&               operator=(const UEPRADC& EPR);
    
    ErrorType              GetError() const {return error;}
    const UGrid*           GetEPRGrid()   const;
    const UGrid*           GetMergedGrid() const;
    UMultiChan*            GetMergedADCMultiChan(UMEEGDataEpochs* InputData, int ivol) const;
    const UMarkerArray*    GetTemplateMarkerArray(void) const {return MarTemplate;}

protected:
    void                   SetAllMembersDefault();
    void                   DeleteAllMembers(ErrorType E);

private:
    ErrorType              error;

    UGrid                  EPRGrid;
    UGrid                  MergedGrid;

    UMEEGDataEpochs*       EpoEKG;
    UInterpolate*          InterEKG; 
    UMEEGDataEpochs*       EpoPulse;
    UInterpolate*          InterPulse; 
    UMEEGDataEpochs*       EpoResp;
    UInterpolate*          InterResp; 

    UMEEGDataEpochs*       EpoADC;
    UInterpolate*          InterADC; 

    UMarkerArray*          MarTemplate;
};

#endif// _EEGFMRITOOL_INCLUDED
