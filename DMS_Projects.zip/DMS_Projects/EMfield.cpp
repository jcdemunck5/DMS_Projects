/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*     This module contains the implementation of the UEMfield object. The purpose  */
/*     of that object is to compute the electric potential and/or the               */
/*     magnetic field component at a sensor array (UGrid) caused by a dipolar       */
/*     source (UDipole). Also the derivatives of the field w.r.t. the dipole        */
/*     parameters can be computed.                                                  */
/*                                                                                  */
/*     USAGE:                                                                       */
/*     At the creation of an UEMfield object, a pointer to a head model is given    */
/*     (UHeadModel-object). That object is used to initialize some tables and       */
/*     coefficients.                                                                */
/*     The main function of the UEMfield-object is GetEMfield(), which              */
/*     returns a pointer to a new array with electric and magnetic field values.    */
/*     The modality computed depends on the corresponding sensor type (USensor)     */
/*     (which can be electrode, magnetometer, or gradiometer). The source is a      */
/*     dipole (UDipole), which can be a normal current dipole, a (semi-) symmetric  */
/*     current dipole or a magnetic dipole.                                         */
/*                                                                                  */
/*     NOTE:                                                                        */
/*     Not all combinations of derivaties, sensor and source modalities.            */
/*                                                                                  */
/*                                                                                  */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    11-12-96   creation
  Jdm    21-02-97   Derived from C-version
  Jdm    04-04-97   Added case of magnetic dipole and its derivative (tested numerically)
  Jdm    18-06-97   Integrated magnetic field computations and their derivatives in one function
                    NOT TESTED
  Jdm    07-11-97   added documentation
  Jdm    16-01-98   include position of best fitting sphere, w.r.t head system.
                    The dipole and sensor coordinates must also be considered as coordinates
                    w.r.t. the head system. Before using the sphere model, the sphere position
                    is substracted from both the dipole and the sensor coordinates.
  Jdm    18-02-98   Updated interfaces, for changes in grid.h
  Jdm    20-02-98   Changes in UDipole definition
  Jdm    23-02-98   Changes in UEMfield Interface (DerivType)
  Jdm    27-02-98   Added and tested second derivative
  Jdm    30-03-98   New interface: use class USensor() instead of struct SENSOR
  Jdm    21-04-98   Changed meaning of D_OriPos11: matrix of derivatives (9 components)
  Jdm    01-07-98   added full symmetric dipoles
  Jdm    02-09-98   added half symmetric dipoles, which only have a symmetric position
  Jdm    24-09-98   IMPORTANT BUG FIX, in the computation of _EMfieldDer for (full) symmetric dipoles,
                    with deriv==D_OriPos10 and deriv==D_OriPos01
  JdM    01-10-98   separated include-files, added homogeneous sphere model for EEG
                    SERIOUS(?) BUG FIX in the computation of the field with D_OriPos00 for full symmetric dipoles
  JdM    04-10-98   added multi-sphere model, first version
  JdM    08-10-98   separated include-files, fixed bug in error setting in constructor
  JdM    28-12-98   Added more detailed comments
  JdM    31-03-99   The pointers with the electric/magnetic fields are not a part of the object
                    anymore. Therefore, these pointer should now be deleted by the calling function.
                    The fuctions that compute the EMfield are now called GetEMfield() i.s.o. ComputeEMfield()
  JdM    06-06-99   Added derivatives of multi-sphere model.
  JdM    10-06-99   Added operator=() and realistic models
JdM/DvT  16-06-99   Aded parameter to discriminate betweem EEG and MEG in realistic models
  JdM    01-07-99   Some bug fixes for multi-sphere model
  JdM    27-07-99   Some bug fixes for multi-sphere model
  JdM    06-08-99   Remove obsolete operator=()
  JdM    20-08-99   BUG FIX: Do not get head-model-type, when no headmodel is present
  JdM    18-01-00   GetEMfield(): Added parameter range test in the multi-sphere model (return NULL on error).
  JdM    04-02-00   return 0. for the magnetic field caused by a dipole at the center, instead of crashing
  JdM    21-02-00   Make a few public functions const.
  JdM    27-03-00   Added GetSpherePos(), SetSigma(), GetModel() and Geteps().
                    Fit a sphere on the outer surface of the conductor in constructor.
  JdM    22-05-00   Major Update: Derive UEMfield from UMultiSphereModel
  JdM    04-10-00   Only call UMultiSphereModel::UpdateRadialCoefficients() when GridEEG is set
JdM/SG   10-10-00   Added GetEfield() function for EIT
  JdM    12-10-00   Added a few error messages for inconsistant function calls
  JdM    17-10-00   Added new constructor
                    Count number of EEG sensors before updating radial coefficients
 JdM/SG  09-11-00   Added another parameter to SetSigma() (ManySigmas)
  JdM    29-11-00   Bug fix in SetSigma()
 JdM/SG  01-12-00   Added reference parameter to GetPotentialEIT()
  JdM    11-07-01   Reorganized public functions such that it is possible to get the MEG and EEG simultaneously
  JdM    17-08-01   Added functions to control the MEG balancing of the forward models
  JdM    18-08-01   Implemented balancing for spherical models
  JdM    24-08-01   Bug fix in forward balancing, dd 18-08-01
  JdM    28-08-01   Bug fix GetEMfieldSphere(). delete[] Rf, when rereferencing
  JdM    13-09-01   Implemented D_OriPos11. Fast index differentiates to position, slow index to moment
  JdM    13-09-01   Tested and Bug fixed D_OriPos11.
  JdM    19-11-01   Extended balancing of magnetic field computations to realistic models,
                    using BalanceBfield().
  JdM    27-11-01   Extended GetProperties()
  JdM    29-11-01   Added new GetNcomp()
  JdM    09-07-03   SetGrid(). Lauch warning on wrong electrode positions.
  JdM    22-08-03   Change output of MEG and EEG to new units (By default). Old units can be set using SetUseOldUnits())
                    GetEMfieldSphere() and GetEMfield(). Use ConvertMerge() to convert data to appropriate units and to merge MEG and EEG data arrays.
  JdM    26-08-03   Reverse scaling factors introduced 22-08-03
  JdM    29-09-03   Bug fix: GetEMfieldSphere(). Skip BalanceBfield(), when no MEG field is requested.
JdM/MA   13-05-04   Bug fix: Initializing UseOldUnits in the UConductor - constructor
  JdM    28-03-05   Added SetAllMembersDefault(), DeleteAllMembers(). Default constructor, copy constructor and operator=(). Use UString for GetProperties()
                    Removed obsolete DerConvert(), moved GrossModelType to outside,
  JdM    14-04-05   BalanceBfield(). Account for the MEG channel labels to find the appropriate table
  JdM    04-03-06   Replaced UCTFData::ReReferenceType by ReReferenceType
  JdM    05-01-07   Removed SetBalancing() referring to obsolete UCTFData
                    Bug fix: Use ReRef as ::ReReferenceType, i.s.o. UCTFData::ReReferenceType
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    20-11-07   Adapted to new implementation of UHeadModel::ModelType
  JdM    23-11-07   UpdateE(), case U_CONDMOD_INFINITEMEDIUM. Added -sign at fact
  JdM    17-08-08   BUG FIX: UEMfield::BalanceBfield(). Test all UMEEGDataBase::MAXMEG pBal-elements, instead of only the nMEG first ones
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    04-09-08   Bug Fix. UEMfield::operator=(). Testing whether EMF.pBal is NULL
  JdM    07-12-08   SetBalancing(). Do not test validity of GridMEG
  JdM    21-11-12   ComputeEM(). Test whether dipole is at origin for spherical models
  JdM    02-02-14   GetEfield() EIT variant: add interface to newly created Multi-sphere version.
  JdM    04-02-14   SetGrid(). Set conductivities in case of ManySigmas==true. This eleminates the need for a first call of SetSigma()
  JdM    25-01-15   Added GetEMfieldAsMatrix(), GetEfieldAsMatrix() and GetBfieldAsMatrix().
  JdM    22-02-15   Removed option of curved triangles (UBemMatrix3::SurfInterPolType)
  JdM    05-07-15   GetEfieldAsMatrix(). Added UseMonoLayer parameter (restricted version, EIT only)
  JdM    18-08-15   GetEfieldAsMatrix(). Added UseMonoLayer parameter, which now also valid for dipoles
  JdM    23-08-15   Made UsemonoLayer data member of UBemMatrix3
  JdM    27-08-15   Replace pointers to double* arrays to UMatrix objects
  JdM    18-03-18   Added GetEfieldAsMatrix()
  JdM    01-06-18   Added another constructor, where BEM settings of UHeadModel argument are overwritten.
  JdM    13-07-18   Added SwapSurfaces() (this is essentially a bug fix).
  */

#include <math.h>
#include <string.h>

#include "EMfield.h"
UString UEMfield::Properties = UString();

#define  MAXNCOMP 36

const double MEGNewUnits = 10.;
const double EEGNewUnits = 0.001;

const int    MAXMEG      = UMEEGDataBase::MAXMEG;

void UEMfield::SetAllMembersDefault(void)
{
    error       = U_OK;
    pBal        = NULL;
    ReRef       = U_REF_RAW;
    UseOldUnits = false;

    GrossModel  = U_GMODEL_UNKNOWN;
}
void UEMfield::DeleteAllMembers(ErrorType E)
{
    if(pBal)
        for(int i=0; i<MAXMEG; i++)
            delete pBal[i];

    delete[] pBal;
    SetAllMembersDefault();
    error = E;
}


// Public functions
UEMfield::UEMfield(const UHeadModel* Hmod) :  UMultiSphereModel(Hmod), UBemField(Hmod)
{
    SetAllMembersDefault();

    if(Hmod==NULL)
    {
        GrossModel = U_GMODEL_SPHERE;
        return;
    }
    else
    {
        if(Hmod->GetCondModelType()==U_CONDMOD_INFINITEMEDIUM ||
           Hmod->GetCondModelType()==U_CONDMOD_SPHERE         ||
           Hmod->GetCondModelType()==U_CONDMOD_HOMSPHERE      ||
           Hmod->GetCondModelType()==U_CONDMOD_THREESPHERE    ||
           Hmod->GetCondModelType()==U_CONDMOD_MULTISPHERE)
        {
            GrossModel = U_GMODEL_SPHERE;
            error      = UMultiSphereModel::GetError();
        }
        else if(Hmod->GetCondModelType()==U_CONDMOD_BEM)   // Other models are not supported yet
        {
            GrossModel = U_GMODEL_REALISTIC;
            error      = UBemField::GetError();
        }
        else
        {
            GrossModel = U_GMODEL_UNKNOWN;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEMfield::UEMfield(). Invalid model type: Model = %d \n", Hmod->GetCondModelType());
        }
    }
    if(error!=U_OK) DeleteAllMembers(U_ERROR);
}
UEMfield::UEMfield(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer) :
    UMultiSphereModel(NULL), UBemField(Hmod, PInt, Smo, UseMonoLayer)
{
    SetAllMembersDefault();

    if(Hmod==NULL || Hmod->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEMfield::UEMfield(). UHeadModel argument NULL or erroneous.\n");
        return;
    }
    if(Hmod->GetCondModelType()==U_CONDMOD_INFINITEMEDIUM ||
       Hmod->GetCondModelType()==U_CONDMOD_SPHERE         ||
       Hmod->GetCondModelType()==U_CONDMOD_HOMSPHERE      ||
       Hmod->GetCondModelType()==U_CONDMOD_THREESPHERE    ||
       Hmod->GetCondModelType()==U_CONDMOD_MULTISPHERE)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEMfield::UEMfield(). Headmodel type should be BEM - like (for this constructor).\n");
        return;
    }
    if(Hmod->GetCondModelType()==U_CONDMOD_BEM)   // Other models are not supported yet
    {
        GrossModel = U_GMODEL_REALISTIC;
        error      = UBemField::GetError();
    }
    else
    {
        GrossModel = U_GMODEL_UNKNOWN;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEMfield::UEMfield(). Invalid model type: Model = %d \n", Hmod->GetCondModelType());
    }
    if(error!=U_OK) DeleteAllMembers(U_ERROR);
}


UEMfield::UEMfield(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer) :
    UMultiSphereModel(NULL), UBemField(C, PInt, Smo, UseMonoLayer)
{
    SetAllMembersDefault();

    GrossModel  = U_GMODEL_REALISTIC;
    error       = UBemField::GetError();
}

UEMfield::UEMfield(const UEMfield &EMF)
{
    SetAllMembersDefault();
    *this = EMF;
}

UEMfield::~UEMfield()
{
    DeleteAllMembers(U_OK);
}

UEMfield& UEMfield::operator=(const UEMfield &EMF)
{
    if(this==NULL || &EMF==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::operator=(). this==NULL or invalid NULL Address argument. \n");
        if(this)
        {
            DeleteAllMembers(U_ERROR);
            UMultiSphereModel::DeleteAllMembers(U_ERROR);
            UBemField        ::DeleteAllMembers(U_ERROR);
            UBemMatrix3      ::DeleteAllMembers(U_ERROR);
            UConductor3      ::DeleteAllMembers(U_ERROR);
        }
        return *this;
    }
    if(this==&EMF) return *this;

    UBemField::operator=((UBemField) EMF);
    if(UBemField::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UMultiSphereModel::DeleteAllMembers(U_ERROR);
        UBemField        ::DeleteAllMembers(U_ERROR);
        UBemMatrix3      ::DeleteAllMembers(U_ERROR);
        UConductor3      ::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::operator=(). Copying realistic BEM base class. \n");
        return *this;
    }
    UMultiSphereModel::operator=((UMultiSphereModel) EMF);
    if(UMultiSphereModel::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        UMultiSphereModel::DeleteAllMembers(U_ERROR);
        UBemField        ::DeleteAllMembers(U_ERROR);
        UBemMatrix3      ::DeleteAllMembers(U_ERROR);
        UConductor3      ::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UBemField::operator=(). Copying multisphere base class. \n");
        return *this;
    }

/* Start copying the derived class */
    DeleteAllMembers(U_OK);

    ReRef       = EMF.ReRef;
    UseOldUnits = EMF.UseOldUnits;
    GrossModel  = EMF.GrossModel;
    if(EMF.pBal)
    {
        pBal    = new UBalance*[MAXMEG];
        if(pBal)
        {
            for(int i=0; i<MAXMEG; i++) pBal[i] = NULL;
            for(int i=0; i<MAXMEG; i++)
            {
                if(EMF.pBal[i]==NULL) continue;
                pBal[i] = new UBalance( *EMF.pBal[i] );
                if(pBal[i]==NULL || pBal[i]->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UEMfield::operator=(). Copying table number %d .\n", i);
                    for(int ii=0; ii<=i; ii++)
                    {
                        delete pBal[i];
                        pBal[i] = NULL;
                    }
                    delete[] pBal;
                    pBal = NULL;
                    break;
                }
            }
        }
        if(pBal==NULL)
        {
            DeleteAllMembers(U_ERROR);
            UMultiSphereModel::DeleteAllMembers(U_ERROR);
            UBemField        ::DeleteAllMembers(U_ERROR);
            UBemMatrix3      ::DeleteAllMembers(U_ERROR);
            UConductor3      ::DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UBemField::operator=(). Copying balancing tables. \n");
            return *this;
        }
    }
    return *this;
}

UVector3 UEMfield::GetSpherePos(void) const
{
    if(GrossModel==U_GMODEL_SPHERE) return UMultiSphereModel::SpherePos;
    return UVector3();
}

ErrorType UEMfield::SetSigma(const double* Sigma)
{
    if(GrossModel==U_GMODEL_SPHERE)    return UMultiSphereModel::SetSigma(Sigma);
    if(GrossModel==U_GMODEL_REALISTIC) return UBemField::SetSigma(Sigma);

    return U_ERROR;
}

CondModelType UEMfield::GetCondModelType(void) const
{
    if(GrossModel==U_GMODEL_SPHERE)     return UMultiSphereModel::CondModel;
    return U_CONDMOD_UNKNOWN;
}

double UEMfield::GetEps(int j) const
{
    if(GrossModel==U_GMODEL_SPHERE) return UMultiSphereModel::GetEps(j);
    return 0.;
}


void UEMfield::ResetBalancing(void)
{
    if(pBal)
        for(int i=0; i<MAXMEG; i++)
            delete pBal[i];

    delete[] pBal;
    pBal  = NULL;
    ReRef = U_REF_RAW;
}

ErrorType UEMfield::SetBalancing(const UGrid *GridR, const UBalance** pB, int nB, ReReferenceType RRef)
{
    if(GrossModel!=U_GMODEL_SPHERE && GrossModel!=U_GMODEL_REALISTIC)
    {
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). MEG balancing is not implemented for this model %d \n", GrossModel);
        return U_ERROR;
    }
/****
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). MEG grid not yet (properly set). \n");
        return U_ERROR;
    }
****/

/* Reset old balancing parameters and tables*/
    ResetBalancing();
    if(RRef==U_REF_RAW) return U_OK;

    if(GridR==NULL || GridR->GetError()!=U_OK || pB==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). Invalid arguments. \n");
        return U_ERROR;
    }
    if(nB!=MAXMEG)
    {
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). Number of balancing tables (%d) is not equal to number of MAXMEG sensors(%d). \n", nB, MAXMEG);
        return U_ERROR;
    }

/* Copy Grid*/
    delete GridREF;
    GridREF = new UGrid(*GridR);
    if(GridREF==NULL || GridREF->GetError()!=U_OK)
    {
        ReRef = U_REF_RAW;
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). Copying reference Grid. \n");
        return U_ERROR;
    }

    if(GrossModel==U_GMODEL_REALISTIC)
    {
        if(UBemField::SetGridREF(GridR)!=U_OK) return U_ERROR;
    }

/* Set Rereferening parameter:*/
    ReRef = U_REF_RAW;
    if(RRef==U_REF_SECONDFORWARD ||
       RRef==U_REF_THIRDFORWARD)  ReRef = RRef;
    else
        CI.AddToLog("WARNING: UEMfield::SetBalancing(). Balancing parameter set to raw. Input parameter is %d .\n",RRef);

/* Copy balancing tables*/
    pBal = new UBalance*[MAXMEG];
    if(pBal)
    {
        for(int i=0; i<MAXMEG; i++) pBal[i] = NULL;
        for(int i=0; i<MAXMEG; i++)
        {
            if(pB[i]==NULL) continue;
            pBal[i] = new UBalance( *pB[i] );
            if(pBal[i]==NULL || pBal[i]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UEMfield::SetBalancing(). Copying table number %d .\n", i);
                for(int ii=0; ii<=i; ii++)
                {
                    delete pBal[i];
                    pBal[i] = NULL;
                }
                delete[] pBal;
                pBal = NULL;
                break;
            }
        }
    }
    if(pBal==NULL)
    {
        ResetBalancing();
        CI.AddToLog("ERROR: UEMfield::SetBalancing(). Memory allocation. nB = %d \n", nB);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UEMfield::SetGrid(const UGrid *GridM, const UGrid *GridE, bool FewRightHandSides, bool ManySigmas)
{
    if(GridE)
    {
        for(int i=0; i<GridE->GetNpoints(); i++)
        {
            if(fabs( GridE->GetPosition(i).GetNorm()) < 0.2)
                CI.AddToLog("WARNING: UEMfield::SetGrid(). Electrode %s not properly set (close to origin).\n", GridE->GetName(i));
            if(fabs( GridE->GetPosition(i).GetNorm()) > 30.)
                CI.AddToLog("WARNING: UEMfield::SetGrid(). Electrode %s not properly set (too far from origin).\n", GridE->GetName(i));
        }
    }
    if(GrossModel==U_GMODEL_REALISTIC)
    {
        if(UBemField::GetError()!=U_OK) return U_ERROR;

        ErrorType E = UBemField::SetGrid(GridM, GridE, FewRightHandSides, ManySigmas);

/* Invalidate previous referencing information*/
        if(GridM) ResetBalancing();
        return E;
    }
    else
    {
        if(GridM)
        {
            delete GridMEG; GridMEG = new UGrid(*GridM);
            if(GridMEG==NULL || GridMEG->GetError()!=U_OK) return U_ERROR;

/* Invalidate previous referencing information*/
            ResetBalancing();
        }
        if(GridE)
        {
            delete GridEEG; GridEEG = new UGrid(*GridE);
            if(GridEEG==NULL || GridEEG->GetError()!=U_OK) return U_ERROR;
        }
    }
    return U_OK;
}
ErrorType UEMfield::SwapSurfaces(int is1, int is2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(GrossModel!=U_GMODEL_REALISTIC)
    {
        CI.AddToLog("ERROR: UEMfield::SwapSurfaces(). Object not iniitalized as BEM model.\n");
        return U_ERROR;
    }

    if(is1<0 || is1>=Nsurfaces || is2<0 || is2>=Nsurfaces)
    {
        CI.AddToLog("ERROR: UEMfield::SwapSurfaces(). Parameter(s) out of range: is1 = %d, is2=%d.\n", is1, is2);
        return U_ERROR;
    }
    if(is1==is2) return U_OK;

    if(UBemField::ResetMatrices()!=U_OK || UConductor3::SwapSurfaces(is1, is2)!=U_OK||UBemMatrix3::UpdateMatSize()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::SwapSurfaces(). Swapping surfaces or updating matrix sizes.\n");
        return U_ERROR;
    }
    return U_OK;
}
const UString& UEMfield::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UEMfield-object");
        return Properties;
    }
    Properties   = UString();
    UString Base;

    switch(GrossModel)
    {
    case U_GMODEL_SPHERE:
        Properties   += UString(" SphereModel: \n");
        if(Comment.IsNULL() || Comment.IsEmpty())  Base = UMultiSphereModel::GetProperties(Comment);
        else                                       Base = UMultiSphereModel::GetProperties(Comment+"   ");
        Properties += Base;
        break;
    case U_GMODEL_REALISTIC:
        Properties   += UString(" RealisticModel: \n");
        if(Comment.IsNULL() || Comment.IsEmpty())  Base = UBemField::GetProperties(Comment);
        else                                       Base = UBemField::GetProperties(Comment+"   ");
        Properties   += Base;
        break;
    default:
        Properties   += UString(" UnknownModel \n");
        break;
    }

    if(GridREF)  Properties += UString(GridREF->GetNpoints(), " Nref=%d \n");
    if(GridMEG)  Properties += UString(GridMEG->GetNpoints(), " Nmeg=%d \n");
    if(GridEEG)  Properties += UString(GridEEG->GetNpoints(), " Neeg=%d \n");

    if(GridREF)
    {
        switch(ReRef)
        {
        case U_REF_SECONDFORWARD:
            Properties += UString(" Second order Balancing \n");
            break;
        case U_REF_THIRDFORWARD:
            Properties += UString(" Third order Balancing \n");
            break;
        default:
            Properties += UString(ReRef," Unknown Balancing = %d \n");
        }
    }
    else
    {
        Properties += UString(" No Balancing \n");
    }
    if(UseOldUnits==true) Properties += UString("UNITS = undefined  // (compatible with period before 22-08-2003) \n");
    else                  Properties += UString("UNITS = cm, nA*cm, 1./(Ohm*cm) \n");

    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);

    return Properties;
}

UMatrix UEMfield::GetEMfieldAsMatrix(const UDipole *Dipole, DerivType deriv, FieldType FldT)
/*
     Return an UMatrix containing (derivatives) of magnetic/electric/both field
     corresponding to a current/magnetic dipole. In case of a current dipole,
     the volume conductor model used, corresponds to the one set at the construction of
     this object. The fields are computed at the magnetic/electric sensors, set
     by the last call to the function SetGrid(), prior to GetEMfieldAsMatrix().
     If both MEG and EEG are to be computed, the magnetic field are stored first,
     and the the electric potentials.

     switch(deriv)
     {
     case  D_OriPos00:  compute field alone
     case  D_OriPos10:  compute first  derivative w.r.t. orientation(s)
     case  D_OriPos01:  compute first  derivative w.r.t. position
     case  D_OriPos11:  compute first  derivative w.r.t. orientation(s) and position
     case  D_OriPos20:  compute second derivative w.r.t. orientation(s) (== 0)
     case  D_OriPos02:  compute second derivative w.r.t. position
     default: return NULL;
     }

     switch(FldT)
     {
     case U_MEG:    Compute magnetic field (derivatives) alone
     case U_EEG:    Compute electric field (derivatives) alone
     case U_MEGEEG: Compute magnetic and electric field (derivatives)
     default: return NULL
     }


     Note: Electric potentials are computed w.r.t. average reference.
     Note: Not all combinations of sensors, dipoles, head models and derivatives have yet
           been implemented.
     Note: With the multi-sphere models it is assumed that all electrodes are at the
           same distance from the best-fitting sphere center.

     Note: If(UseOldUnits==false) the MEG and EEG are converted to fT and uV respectively,
                                  assuming that the dipole strength is in nA*cm
                                  and the conductivity is in 1./(Ohm*cm),
                                  and all sensor positions are in cm.
                                  In this case MEGNewUnits and EEGNewUnits, are multiplied to the output arrays.
           else                   MEGNewUnits and EEGNewUnits are not applied.


 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(GrossModel==U_GMODEL_REALISTIC && UBemField::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Internal base class error (UBemField). \n");
        return UMatrix(U_ERROR);
    }
    if(Dipole==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Erroneous UDipole parameter. \n");
        return UMatrix(U_ERROR);
    }
    if(UBemMatrix3::GetMonoLayer()==true)
    {
        if(FldT!=U_EEG)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Monolayer approach not implemented for MEG.\n");
            return UMatrix(U_ERROR);
        }
    }


/* Test if grids are properly set, and compute fields for realistic models. */
    UMatrix Bf;
    UMatrix Ef;
    switch(FldT)
    {
    case U_MEG:
        if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). MEG Grid not properly set.\n");
            return UMatrix(U_ERROR);
        }
        if(GrossModel==U_GMODEL_REALISTIC)
        {
            Bf = UBemField::GetBfield(Dipole, deriv);
            if(BalanceBfield(Dipole, deriv, &Bf)!=U_OK)
            {
                CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Forward balancing magnetic field. \n");
                return UMatrix(U_ERROR);
            }
        }
        break;

    case U_EEG:
        if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). EEG Grid not properly set.\n");
            return UMatrix(U_ERROR);
        }
        if(GrossModel==U_GMODEL_REALISTIC)
        {
            Ef = UBemField::GetPotential(Dipole, deriv);
        }
        break;

    case U_MEGEEG:
        if(GridMEG==NULL || GridMEG->GetError()!=U_OK ||
           GridEEG==NULL || GridEEG->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). MEG and/or EEG Grid not properly set.\n");
            return UMatrix(U_ERROR);
        }
        if(GrossModel==U_GMODEL_REALISTIC)
        {
            Bf = UBemField::GetBfield(Dipole, deriv);
            if(BalanceBfield(Dipole, deriv, &Bf)!=U_OK)
            {
                CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Forward balancing magnetic field. \n");
                return UMatrix(U_ERROR);
            }
            Ef = UBemField::GetPotential(Dipole, deriv);
        }
        break;

    default:
        CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Invalid field parameter (FldT = %d) . \n", FldT);
        return UMatrix(U_ERROR);
    }
    if(GrossModel==U_GMODEL_REALISTIC)
        return ConvertMerge(FldT, GetNcomp(deriv, *Dipole), &Bf, &Ef);

/* The Multi-sphere model */
    if(GrossModel==U_GMODEL_SPHERE)
        return GetEMfieldSphere(Dipole, deriv, FldT);

    CI.AddToLog("ERROR: UEMfield::GetEMfieldAsMatrix(). Invalid volume conductor model (GrossModel=%d). \n", GrossModel);
    return UMatrix(U_ERROR);
}
UMatrix UEMfield::GetEfieldAsMatrix(double Current, int el1, int el2, int elref)
/*
     Return a new array with the electric potentials, caused by injecting and
     extracting a current Current to/from electrodes el1 and el2.

     If the index elref is inside the range (0, nEEG-1) compute the potential w.r.t. the electrode elref
     Else                                               use average reference (skip injection electrodes oin reference)
     Set potential at injection electrodes equal to 0.

     On error, return NULL
 */
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(GridEEG==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Electrode grid not set.\n");
        return UMatrix(U_ERROR);
    }
    if(GridEEG->GetNpoints()<=3)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Electrode grid has too few points (%d).\n", GridEEG->GetNpoints());
        return UMatrix(U_ERROR);
    }
    if(el1==el2 || el1==elref || el2==elref)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Electrodes overlap (el1, el2, elref) = (%d, %d, %d).\n", el1, el2, elref);
        return UMatrix(U_ERROR);
    }
    if(el1<0 || el1>=GridEEG->GetNpoints() ||
       el2<0 || el2>=GridEEG->GetNpoints())
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Electrode indices out of range (%d,%d).\n",el1,el2);
        return UMatrix(U_ERROR);
    }

    if(GrossModel!=U_GMODEL_REALISTIC && GrossModel!=U_GMODEL_SPHERE)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Model should be realistic or multi-sphere.\n");
        return UMatrix(U_ERROR);
    }

    if(GrossModel==U_GMODEL_REALISTIC)
    {
        UMatrix Ef = UBemField::GetPotentialEIT(Current, el1, el2, elref);
        if(Ef.GetMatrixArray()==NULL || Ef.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Computing potential for realistic model.\n");
            return UMatrix(U_ERROR);
        }
        return Ef;
    }
    int     nEEG = GridEEG->GetNpoints();
    UMatrix Pot(DNULL, nEEG, 1);
    if(Pot.GetError()!=U_OK || Pot.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Creating output UMatrix, memory allocation (?), nEEG =%d   .\n",nEEG);
        return UMatrix(U_ERROR);
    }

    USensor   S1 = GridEEG->GetSensor(el1);
    USensor   S2 = GridEEG->GetSensor(el2);
    UVector3 xs1 = S1.Getx()-UMultiSphereModel::SpherePos;
    UVector3 xs2 = S2.Getx()-UMultiSphereModel::SpherePos;

    for(int i=0; i<nEEG; i++)
    {
        if(i==el1 || i==el2) continue;
        USensor   S = GridEEG->GetSensor(i);
        UVector3 xs = S.Getx()-UMultiSphereModel::SpherePos;
        UMultiSphereModel::ProjectElectrode(&xs); // Project electrode on outer radius

        double Pot1 = UMultiSphereModel::GetPotentialEIT(Current, xs1, xs);
        double Pot2 = UMultiSphereModel::GetPotentialEIT(Current, xs2, xs);

        Pot.Data[i] = Pot1-Pot2;
    }

    if(elref<0 || nEEG<=elref)
    {
        double ave = 0;
        for(int i=0; i<nEEG; i++) if(i!=el1 && i!=el2) ave += Pot.Data[i];
        ave /= (nEEG-2);
        for(int i=0; i<nEEG; i++) Pot.Data[i] -= ave;
    }
    else
    {
        double Refpot = Pot.Data[elref];
        for(int i=0; i<nEEG; i++) Pot.Data[i] -= Refpot;
    }
    Pot.Data[el1] = Pot.Data[el2] = 0.;

    return Pot;
}
UMatrix UEMfield::GetEfieldAsMatrix(double Current, double ElSizeCm)
/*
  Return an UMatrix with the electric potentials, caused by injecting at the z-axis and  extracting a current at the UGrid electrodes.
*/
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(GridEEG==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Electrode grid not set.\n");
        return UMatrix(U_ERROR);
    }

    if(GrossModel!=U_GMODEL_REALISTIC && GrossModel!=U_GMODEL_SPHERE)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Model should be realistic or multi-sphere.\n");
        return UMatrix(U_ERROR);
    }
    if(ElSizeCm<=0 || ElSizeCm>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::SetInjectionSize(). SizeCm = %f out of range. \n",ElSizeCm);
        return UMatrix(U_ERROR);
    }

    if(GrossModel == U_GMODEL_REALISTIC)
    {
        UMatrix Ef = UBemField::GetPotentialEIT(Current);
        if (Ef.GetMatrixArray() == NULL || Ef.GetError() != U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Computing potential for realistic model.\n");
            return UMatrix(U_ERROR);
        }
        return Ef;
    }

    int     nEEG = GridEEG->GetNpoints();
    UMatrix Pot(DNULL, nEEG, 1);
    if(Pot.GetError()!=U_OK || Pot.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEfieldAsMatrix(). Creating output UMatrix, memory allocation (?), nEEG =%d   .\n",nEEG);
        return UMatrix(U_ERROR);
    }
    for(int i=0; i<nEEG; i++)
    {
        USensor   S = GridEEG->GetSensor(i);
        UVector3 xs = S.Getx()-UMultiSphereModel::SpherePos;
        UMultiSphereModel::ProjectElectrode(&xs); // Project electrode on outer radius

        Pot.Data[i] = UMultiSphereModel::GetPotentialEIT(Current, ElSizeCm, xs);
    }
    int isz = 0;
    GridEEG->GetSensorClosestToAxis(2, false, &isz);
    Pot -= Pot[isz];

    return Pot;
}


UMatrix UEMfield::GetBfieldAsMatrix(const UDipole *Dipole, DerivType deriv)
{
    return GetEMfieldAsMatrix(Dipole, deriv, U_MEG);
}

UMatrix UEMfield::GetEfieldAsMatrix(const UDipole *Dipole, DerivType deriv)
{
    return GetEMfieldAsMatrix(Dipole, deriv, U_EEG);
}

double* UEMfield::GetEMfield(const UDipole *Dipole, DerivType deriv, FieldType FldT)
{
    if(this==NULL || error!=U_OK) return NULL;

    UMatrix M = GetEMfieldAsMatrix(Dipole, deriv, FldT);
    if(M.GetError()!=U_OK || M.GetMatrixArray()==NULL) return NULL;
    
    double* F = M.Data; M.Data = NULL;
    return F;
}
double* UEMfield::GetEfield(double Current, int el1, int el2, int elref)
{
    if(this==NULL || error!=U_OK) return NULL;

    UMatrix M = GetEfieldAsMatrix(Current, el1, el2, elref);
    if(M.GetError()!=U_OK || M.GetMatrixArray()==NULL) return NULL;
    
    double* F = M.Data; M.Data = NULL;
    return F;
}
double* UEMfield::GetBfield(const UDipole *Dipole, DerivType deriv)
{
    if(this==NULL || error!=U_OK) return NULL;

    UMatrix M = GetEMfieldAsMatrix(Dipole, deriv, U_MEG);
    if(M.GetError()!=U_OK || M.GetMatrixArray()==NULL) return NULL;
    
    double* F = M.Data; M.Data = NULL;
    return F;
}
double* UEMfield::GetEfield(const UDipole *Dipole, DerivType deriv)
{
    if(this==NULL || error!=U_OK) return NULL;

    UMatrix M = GetEMfieldAsMatrix(Dipole, deriv, U_EEG);
    if(M.GetError()!=U_OK || M.GetMatrixArray()==NULL) return NULL;
    
    double* F = M.Data; M.Data = NULL;
    return F;
}

ErrorType UEMfield::BalanceBfield(const UDipole *Dipole, DerivType deriv, UMatrix* Bfield) const
/*
    Correct the magnetic field Bfield[] for reference magnetometer and gradiometer effects.
 */
{
    if(ReRef!=U_REF_SECONDFORWARD &&
       ReRef!=U_REF_THIRDFORWARD)      return U_OK; // Nothing to do!

    if(GridREF==NULL || GridREF->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Reference grid not (properly) set. \n");
        return U_ERROR;
    }
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::BalanceBfield(). MEG grid not (properly) set. \n");
        return U_ERROR;
    }
    if(Bfield==NULL || Bfield->GetMatrixArray()==NULL || Bfield->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::BalanceBfield(). NULL pointer argument. \n");
        return U_ERROR;
    }

    int     Ncomp = GetNcomp(deriv, Dipole->GetDipoleType());
    int     Nref  = GridREF->GetNpoints();
    UMatrix Rf;

    if(GrossModel==U_GMODEL_SPHERE)
    {
        Rf = UMatrix(DNULL, Nref, Ncomp);
        if(Rf.GetMatrixArray()==NULL || Rf.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Creating temporary array. \n");
            return U_ERROR;
        }

        double* pRef = Rf.Data;
        for(int i=0;i<Nref;i++)
        {
            USensor       S = GridREF->GetSensor(i);
            const double *b = ComputeEM(S, Dipole, deriv);
            for(int k=0;k<Ncomp;k++) *pRef++ = *b++;
        }
    }
    else if(GrossModel==U_GMODEL_REALISTIC)
    {
        Rf = UBemField::GetRfield(Dipole, deriv);
        if(Rf.GetMatrixArray()==NULL || Rf.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Computing dipole field on reference grid using realistic model. \n");
            return U_ERROR;
        }
    }
    else
    {
        CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Erroneous head model (%d). \n",GrossModel);
        return U_ERROR;
    }

    ErrorType E     =  U_OK;
    int       ibold = -1;
    int       i     = 0;
    for(i=0; i<GridMEG->GetNpoints(); i++)
    {
        int ib =-1;
        for(int k=0; k<MAXMEG; k++)
        {
            int test = (ibold+1+k)%MAXMEG;
            if(pBal[test]==NULL) continue;
            if(pBal[test]->IsMEGLabel(GridMEG->GetName(i))==false) continue;
            ib = ibold = test;
            break;
        }
        if(ib<0)
        {
            CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Balancing balancing table not found for MEG label %s.\n",GridMEG->GetName(i));
            E = U_ERROR;
        }
        if(E!=U_OK) break;

        E = pBal[ib]->Balance(Bfield->Data + i*Ncomp, Rf.Data, Ncomp, ReRef);
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UEMfield::BalanceBfield(). Rereferencing failed in sensor %d \n", i);
        return U_ERROR;
    }
    return U_OK;
}

UMatrix UEMfield::GetEMfieldSphere(const UDipole *Dipole, DerivType deriv, FieldType FldT)
/*
     Given the MEG and/or EEG UGrid and *Dipole compute the magnetic field/electric potential,
     using the spherical volume conductor model, or the magnetic dipole.

     Note: Electric potentials are computed w.r.t. average reference.
     Note: Not all combinations of sensors, dipoles, head models and derivatives have yet
           been implemented.
     Note: With the multi-sphere models it is assumed that all electrodes are at the
           same distance from the best-fitting sphere center.
 */
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(GrossModel!=U_GMODEL_SPHERE)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Invalid volume conductor model (GrossModel=%d). \n", GrossModel);
        return UMatrix(U_ERROR);
    }
    if(Dipole==NULL)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Erroneous UDipole parameter. \n");
        return UMatrix(U_ERROR);
    }

    int Ncomp = GetNcomp(deriv, Dipole->GetDipoleType());
    if(Ncomp<=0 || Ncomp>MAXNCOMP)
    {
        CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Ncomp = %d . \n", Ncomp);
        return UMatrix(U_ERROR);
    }

    UMatrix Bf;
    UMatrix Ef;

/* Compute magnetic fields */
    if(FldT==U_MEG || FldT==U_MEGEEG)
    {
        int nMEG = GridMEG->GetNpoints();
        Bf       = UMatrix(DNULL, nMEG, Ncomp);
        if(Bf.GetMatrixArray()==NULL || Bf.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Creating MEG matrix . \n");
            return UMatrix(U_ERROR);
        }

        double* pBf = Bf.Data;
        for(int i=0;i<nMEG;i++)
        {
            USensor       S = GridMEG->GetSensor(i);
            const double *b = ComputeEM(S, Dipole, deriv);
            for(int k=0;k<Ncomp;k++) *pBf++ = *b++;
        }
    }

/* Compute electric potentials */
    if(FldT==U_EEG || FldT==U_MEGEEG)
    {
        int nEEG = GridEEG->GetNpoints();
        Ef       = UMatrix(DNULL, nEEG, Ncomp);
        if(Ef.GetMatrixArray()==NULL || Ef.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Creating EEG matrix . \n");
            return UMatrix(U_ERROR);
        }

        if(UMultiSphereModel::UpdateRadialCoefficients( Dipole->Getx())!=U_OK)
        {
            static int NMESS = 0;
            if(NMESS<20) CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Updating radial coefficients of the spherical model. \n");
            NMESS++;
            return UMatrix(U_ERROR);
        }

        double* pEf = Ef.Data;
        for(int i=0;i<nEEG;i++)
        {
            USensor       S = GridEEG->GetSensor(i);
            const double *e = ComputeEM(S, Dipole, deriv);
            for(int k=0;k<Ncomp;k++) *pEf++  = *e++;
        }
        if(GridEEG->GetNpoints()>0 && UMultiSphereModel::CondModel!=U_CONDMOD_INFINITEMEDIUM) Ef.DeMeanCols();
    }

    if(FldT==U_MEG || FldT==U_MEGEEG)
    {
        if(BalanceBfield(Dipole, deriv, &Bf)!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::GetEMfieldSphere(). Forward balancing magnetic field. \n");
            return UMatrix(U_ERROR);
        }
    }
    return ConvertMerge(FldT, GetNcomp(deriv, *Dipole), &Bf, &Ef);
}

const double* UEMfield::ComputeEM(const USensor& S, const UDipole *dip, DerivType deriv) const
/*
    Given a sensor and the dipole coordinates xd and orientation dd,
    return the magnetic field.
 */
{
    static double fld[MAXNCOMP];
    for(int k=0; k<MAXNCOMP; k++) fld[k] = 0.;

    UVector3 Spos = UMultiSphereModel::SpherePos;
    UVector3 dd   = dip->Getd();
    UVector3 xd   = dip->Getx() - Spos;
    if(GrossModel!=U_GMODEL_REALISTIC && S.GetStype()==USensor::U_SEN_EEG)
    {
        if(xd.GetNorm()<=1.e-7)
        {
            const int MAXMESS = 10;
            static int NMess  =  0;
            if(NMess<MAXMESS) CI.AddToLog("WARNING: EMfield::ComputeEM(). Dipole at origin. \n");
            NMess++;
            return fld;
        }
    }
    UVector3 ns;
    UVector3 xs;

    int ncoil = 1;
    if(S.GetStype()==USensor::U_SEN_GRAD) ncoil = 2;

    for(int icoil=0; icoil<ncoil; icoil++)
    {
        if(icoil==0)
        {
            ns =  S.Getn();
            xs =  S.Getx() - Spos;
        }
        else
        {
            ns = -S.Getn();
            xs =  S.Getc() - Spos;
        }
        if(S.GetStype()==USensor::U_SEN_EEG) // Correct electrode
        {
            UMultiSphereModel::ProjectElectrode(&xs); // Project electrode on outer radius
        }
        if(dip->GetDipoleType()!=UDipole::Magnetic)   // Electric dipole
        {
            if(deriv==D_OriPos02)
            {
                static bool FirstMessage = true;
                if(FirstMessage==true)
                {
                    FirstMessage = false;
                    CI.AddToLog("ERROR UEMfield::ComputeEM(). Second order derivatives not yet implemented. \n");
                }
                return NULL;  // Not yet implemented
            }
            if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld);
            else                                  UpdateB(xd,dd,xs,ns,deriv,fld);

            if(dip->GetDipoleType()==UDipole::Symmetric)
            {
                dd.MirrorY();
                xd.MirrorY();
                switch(deriv)
                {
                case D_OriPos00:
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld);
                    break;

                case D_OriPos10:
                case D_OriPos01:
                    fld[3] = fld[4] = fld[5] = 0.;
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld+3);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld+3);
                    fld[0] += fld[3];
                    fld[1] -= fld[4];
                    fld[2] += fld[5];
                    break;

                case D_OriPos11:
                case D_OriPos02:
                    fld[9] = fld[10] = fld[11] = fld[12] = fld[13] = fld[14] = fld[15] = fld[16] = fld[17] = 0.;
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld+9);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld+9);
                    fld[0] += fld[ 9];
                    fld[1] -= fld[10];
                    fld[2] += fld[11];
                    fld[3] -= fld[12];
                    fld[4] += fld[13];
                    fld[5] -= fld[14];
                    fld[6] += fld[15];
                    fld[7] -= fld[16];
                    fld[8] += fld[17];
                    break;
                }
                dd.MirrorY();
                xd.MirrorY();
            }
            if(dip->GetDipoleType()==UDipole::SymmetricPos)
            {
                dd = dip->GetdSym();
                xd.MirrorY();
                switch(deriv)
                {
                case D_OriPos00:
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld);
                    break;

                case D_OriPos10:
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld+3);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld+3);
                    break;

                case D_OriPos01:
                    fld[3] = fld[4] = fld[5] = 0.;
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld+3);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld+3);
                    fld[0] += fld[3];
                    fld[1] -= fld[4];      // differentiate w.r.t. mirrored position
                    fld[2] += fld[5];
                    break;

                case D_OriPos11:
                    if(S.GetStype()==USensor::U_SEN_EEG)  UpdateE(xd,dd,xs,   deriv,fld+9);
                    else                                  UpdateB(xd,dd,xs,ns,deriv,fld+9);

                    if(icoil==ncoil-1)
                    {
                        fld[10] = -fld[10];// differentiate w.r.t. mirrored position
                        fld[13] = -fld[13];
                        fld[16] = -fld[16];
                    }
                    break;
                }
                dd = dip->Getd();
                xd.MirrorY();
            }
        }
        else // Magnetic dipole
        {
            UVector3 x = xs-xd;
            switch(deriv)
            {
            case D_OriPos00:                                 // Tested 30-06-1997
                {
                    double xx = x.GetNorm2();
                    double a  = xx*xx*x.GetNorm();

                    *fld     += (3*(x&dd)*(x&ns) - xx*(dd&ns)) /a;
                }
                break;

            case D_OriPos10:                                 // Tested 24-02-1998
                {
                    double   xx   = x.GetNorm2();
                    double   a    = xx*xx*x.GetNorm();

/* Derivative with respect to dipole component vector:*/
                    UVector3 deri = ( (3.*x&ns)*x -xx*ns ) / a;

                    fld[0] += deri.Getx();
                    fld[1] += deri.Gety();
                    fld[2] += deri.Getz();
                }
                break;

            case D_OriPos01:                                 // Tested 24-02-1998
                {
                    double   xx   = x.GetNorm2();
                    double   xdd  = x&dd;
                    double   xns  = x&ns;
                    double   ddns = dd&ns;
                    double   a    = xx*xx*xx*x.GetNorm();

/* Derivative with respect to dipole position vector:*/
                    UVector3 deri = (-3*xx*(xdd*ns + xns*dd + ddns*x) + (15*xdd*xns)*x)/ a;

                    fld[0] += deri.Getx();
                    fld[1] += deri.Gety();
                    fld[2] += deri.Getz();
                }
                break;

            case D_OriPos11:                                    // Tested 20-09-2001
                {
                    double   xx   = x.GetNorm2();
                    double   xns  = x&ns;
                    double   a    = xx*xx*xx*x.GetNorm();
                    double   dia  = -3*xx*xns/a;

                    UVector3 deri;
                    deri = (-3*xx*(x.Getx()*ns + ns.Getx()*x) + (15*x.Getx()*xns)*x)/ a;

                    fld[0] += deri.Getx() + dia;
                    fld[3] += deri.Gety();
                    fld[6] += deri.Getz();

                    deri = (-3*xx*(x.Gety()*ns + ns.Gety()*x) + (15*x.Gety()*xns)*x)/ a;
                    fld[1] += deri.Getx();
                    fld[4] += deri.Gety() + dia;
                    fld[7] += deri.Getz();

                    deri = (-3*xx*(x.Getz()*ns + ns.Getz()*x) + (15*x.Getz()*xns)*x)/ a;
                    fld[2] += deri.Getx();
                    fld[5] += deri.Gety();
                    fld[8] += deri.Getz() + dia;
                }
                break;

            case D_OriPos20:
                break;                                          // Result is identically zero

            case D_OriPos02:                                    // Tested 27-02-1998
                {
                    double  xx   = x.GetNorm2();
                    double  a    = xx*xx*xx*x.GetNorm();
                    double  xdd  = x&dd;
                    double  xns  = x&ns;
                    double  ddns = dd&ns;

                    double  c0   = 3*(xx*ddns - 5*xdd*xns)/a;
                    double  c1   = 3*xx/a;
                    double  c2   = -15*xdd/a;
                    double  c3   = -15*xns/a;

                    double  c4   = -15*(xx*ddns - 7*xdd*xns)/(a*xx);

                    UMatrix9 m   = UMatrix9(c0)       +
                                   UMatrix9(dd,ns)*c1 +
                                   UMatrix9(ns,x)*c2  +
                                   UMatrix9(dd,x)*c3  +
                                   UMatrix9(x)*c4;

                    m.AddMatrix(fld);
                }
                break;

            default:
                return NULL;
            }
        }
    }
    return fld;
}

void UEMfield::UpdateB(UVector3 &xd, UVector3 &dd, UVector3 &xs, UVector3 &ns, const DerivType deriv, double *fld) const
{
    if(UMultiSphereModel::CondModel==U_CONDMOD_INFINITEMEDIUM)
    {
        UVector3 x    = xs-xd;
        double   r    = x.GetNorm();
        double   fact = 1./(r*r*r);

        switch(deriv)
        {
        case D_OriPos00:
            fld[0]        +=  ( dd & (x^ns) )*fact;
            break;

        case D_OriPos10:                        // Tested against D_OriPos00 14-06-99
            {
                UVector3 xn  =  x^ns;
                fld[0]    +=  xn.Getx()*fact;
                fld[1]    +=  xn.Gety()*fact;
                fld[2]    +=  xn.Getz()*fact;
            }
            break;

        case D_OriPos01:                         // Tested against D_OriPos00 13-08-99
            {
                UVector3 nm  =  dd^ns;
                fld[0]    +=  nm.Getx()*fact;
                fld[1]    +=  nm.Gety()*fact;
                fld[2]    +=  nm.Getz()*fact;
                fact        *= -3*(x&nm)/(r*r);
                fld[0]    +=   x.Getx()*fact;
                fld[1]    +=   x.Gety()*fact;
                fld[2]    +=   x.Getz()*fact;
            }
            break;

        case D_OriPos11:                         // Tested 21-09-2001
            {
                fld[1]    -= ns.Getz()*fact;
                fld[2]    += ns.Gety()*fact;
                fld[3]    += ns.Getz()*fact;
                fld[5]    -= ns.Getx()*fact;
                fld[6]    -= ns.Gety()*fact;
                fld[7]    += ns.Getx()*fact;

                UVector3 nx  =  (ns^x) *(-3*fact/(r*r));
                fld[0]    +=   x.Getx()*nx.Getx();
                fld[1]    +=   x.Gety()*nx.Getx();
                fld[2]    +=   x.Getz()*nx.Getx();
                fld[3]    +=   x.Getx()*nx.Gety();
                fld[4]    +=   x.Gety()*nx.Gety();
                fld[5]    +=   x.Getz()*nx.Gety();
                fld[6]    +=   x.Getx()*nx.Getz();
                fld[7]    +=   x.Gety()*nx.Getz();
                fld[8]    +=   x.Getz()*nx.Getz();
            }
            break;

        case D_OriPos02: // Not yet implemented
            {
                static bool FirstMessage = true;
                if(FirstMessage==true)
                {
                    FirstMessage = false;
                    CI.AddToLog("ERROR UEMfield::UpdateB(). Derivative type not yet implemented for nfinite medium. \n");
                }
            }
            case D_OriPos20: // Results identically zero
            break;
        }
        return;
    }
    switch(deriv)
    {
    case D_OriPos00:
        {
            UVector3 x   = xs-xd;
            double   a   = x.GetNorm();
            double   r   = xs.GetNorm();    if(r<1.e-8) return;
            double   ax  = xs&x;
            double   f   = a*(a*r+ax);

            double   f2  = a + 2*r +ax/a;
            double   f12 = a + a*a/r;

            UVector3 gf  = f12*xs + f2*x;
            UVector3 emf = dd^xd;
            double   h   = (emf&xs)/f;

            emf   = (emf - h*gf)/f;

            *fld += emf&ns;
        }
        break;

    case D_OriPos10:                                     // Tested 28-08-1997
        {
            UVector3 x   = xs-xd;

            double   a   = x.GetNorm();
            double   r   = xs.GetNorm();    if(r<1.e-8) return;
            double   ax  = xs&x;
            double   f   = a*(a*r+ax);

            double   f2  = a + 2*r +ax/a;
            double   f12 = a + a*a/r;

            UVector3 gf  = f12*xs + f2*x;
            double   h   = ns&gf/(f*f);

            UVector3 emf = (xd^ns)/f - (xd^xs)*h;
            fld[0]      += emf.Getx();
            fld[1]      += emf.Gety();
            fld[2]      += emf.Getz();
        }
        break;

    case D_OriPos01:                         // tested 19-03-1998
        {
            UVector3 x     =   xs-xd;
            double   a     =   x.GetNorm();
            double   r     =   xs.GetNorm();    if(r<1.e-8) return;
            double   ax    =   xs&x;
            double   f     =   a*(a*r+ax);

            double   an    =   ns&x;
            double   h1    =   2*r+a+ax/a;
            double   h2    =  (an*(1.-ax/(a*a)) + (ns&xs)*(2*a/r+1))/a;
            double   h3    =   an/a;
            double   h4    =   a + a*a/r;

            UVector3 gf    =    h4*xs +  h1*x;
            UVector3 gdf   =  (-a)*xs - (h1-a)*x;
            UVector3 emf   =  (ns^dd)/f;
            emf            =   emf - gdf*( (emf&xd)/f);

            UVector3 xsXdd =   xs^dd;
            double   nsgff =   (ns&gf)/f;
            emf           -=   xsXdd*(nsgff/f);
            double   detfa =( xsXdd&xd)/(f*f);

            emf           +=  detfa*((2*nsgff)*gdf + h1*ns + h2*x + h3*xs);

            fld[0] += emf.Getx();
            fld[1] += emf.Gety();
            fld[2] += emf.Getz();
        }
        break;

    case D_OriPos20:  // Result is identically zero
        break;

    case D_OriPos11:                           // Tested 20-09-2001
        {
            UVector3 x     =   xs-xd;
            double   a     =   x.GetNorm();
            double   r     =   xs.GetNorm();    if(r<1.e-8) return;
            double   ax    =   xs&x;
            double   f     =   a*(a*r+ax);

            double   an    =   ns&x;
            double   h1    =   2*r+a+ax/a;
            double   h2    =  (an*(1.-ax/(a*a)) + (ns&xs)*(2*a/r+1))/a;
            double   h3    =   an/a;
            double   h4    =   a + a*a/r;

            UVector3 gf    =    h4*xs +  h1*x;
            UVector3 gdf   =  (-a)*xs - (h1-a)*x;
            double   nsgff =   (ns&gf)/f;

/* Cross products*/
            double  b1     =  -nsgff/f;
            fld[1]        += (ns.Getz()/f + xs.Getz()*b1);
            fld[2]        -= (ns.Gety()/f + xs.Gety()*b1);
            fld[3]        -= (ns.Getz()/f + xs.Getz()*b1);
            fld[5]        += (ns.Getx()/f + xs.Getx()*b1);
            fld[6]        += (ns.Gety()/f + xs.Gety()*b1);
            fld[7]        -= (ns.Getx()/f + xs.Getx()*b1);

            UVector3 gdf2  =  gdf*((1./(f*f)));

            UVector3 nsXxd =   ns^xd;

            UVector3 xdXxs =  (xd^xs)/(f*f);
            UVector3 b2    =  (2*nsgff)*gdf + h1*ns + h2*x + h3*xs;

            fld[0]        += gdf2.Getx()*nsXxd.Getx() + b2.Getx()*xdXxs.Getx();
            fld[1]        += gdf2.Gety()*nsXxd.Getx() + b2.Gety()*xdXxs.Getx();
            fld[2]        += gdf2.Getz()*nsXxd.Getx() + b2.Getz()*xdXxs.Getx();
            fld[3]        += gdf2.Getx()*nsXxd.Gety() + b2.Getx()*xdXxs.Gety();
            fld[4]        += gdf2.Gety()*nsXxd.Gety() + b2.Gety()*xdXxs.Gety();
            fld[5]        += gdf2.Getz()*nsXxd.Gety() + b2.Getz()*xdXxs.Gety();
            fld[6]        += gdf2.Getx()*nsXxd.Getz() + b2.Getx()*xdXxs.Getz();
            fld[7]        += gdf2.Gety()*nsXxd.Getz() + b2.Gety()*xdXxs.Getz();
            fld[8]        += gdf2.Getz()*nsXxd.Getz() + b2.Getz()*xdXxs.Getz();
        }
        break;

    case D_OriPos02:  // Not yet implemented
        break;

    }
}

void UEMfield::UpdateE(UVector3 &xd, UVector3 &dd, UVector3 &xs, const DerivType deriv, double *fld) const
/*
    Compute the potentials in the spherical symmetric models.
 */
{
    if(UMultiSphereModel::CondModel==U_CONDMOD_INFINITEMEDIUM)
    {
        UVector3 xx    = xs-xd;
        double   r     = xx.GetNorm();
        double   fact  = -1./(r*r*r*PI4*GetEps(0));

        switch(deriv)
        {
        case D_OriPos00:
            fld[0] += ( dd&xx ) * fact;
            break;

        case D_OriPos10:
            fld[0]  += xx.Getx()*fact;
            fld[1]  += xx.Gety()*fact;
            fld[2]  += xx.Getz()*fact;
            break;

        case D_OriPos01:
            {
                UVector3 emf = dd*fact;
                fact    *= -3.*(dd&xx)/(r*r);
                emf     += xx *fact;
                fld[0]  += -emf.Getx();
                fld[1]  += -emf.Gety();
                fld[2]  += -emf.Getz();
            }
            break;

        case D_OriPos11:
            {
                double fac2  = -3*fact/(r*r);
                fld[0]  += -xx.Getx()*xx.Getx()*fac2 - fact;
                fld[1]  += -xx.Gety()*xx.Getx()*fac2;
                fld[2]  += -xx.Getz()*xx.Getx()*fac2;
                fld[3]  += -xx.Getx()*xx.Gety()*fac2;
                fld[4]  += -xx.Gety()*xx.Gety()*fac2 - fact;
                fld[5]  += -xx.Getz()*xx.Gety()*fac2;
                fld[6]  += -xx.Getx()*xx.Getz()*fac2;
                fld[7]  += -xx.Gety()*xx.Getz()*fac2;
                fld[8]  += -xx.Getz()*xx.Getz()*fac2 - fact;
            }
            break;

        case D_OriPos02: // Not yet implemented
            {
                static bool FirstMessage = true;
                if(FirstMessage==true)
                {
                    FirstMessage = false;
                    CI.AddToLog("ERROR UEMfield::UpdateE(). Second order derivatives not yet implemented for infinite medium potential. \n");
                }
            }
        case D_OriPos20: // Results identically zero
            {
            }
        }
    }
    else if(UMultiSphereModel::CondModel==U_CONDMOD_HOMSPHERE) // It is assumed that the electrode is on the outer surface!
    {
        switch(deriv)
        {
        case D_OriPos00:
            {
                UVector3 x    = xs-xd;
                double   a    = x.GetNorm();
                double   a3   = a*a*a;
                double   r    = xs.GetNorm();
                double   xdd  = x&dd;
                double   xsdd = xs&dd;
                double   xsx  = xs&x;
                *fld  += (2*xdd/a3 + (xdd/a+xsdd/r)/(xsx+a*r))/(PI4*GetEps(0));
            }
            break;                                          // Tested 02-10-1998

        case D_OriPos10:
            {
                UVector3 x    = xs-xd;
                double   a    = x.GetNorm();
                double   a3   = a*a*a;
                double   r    = xs.GetNorm();
                double   xsx  = xs&x;
                double   h    = 1./(xsx+a*r);
                UVector3 emf  = (2./a3 + h/a)*x + (h/r)*xs;

                fld[0]      += emf.Getx()/(PI4*GetEps(0));
                fld[1]      += emf.Gety()/(PI4*GetEps(0));
                fld[2]      += emf.Getz()/(PI4*GetEps(0));
            }
            break;

        case D_OriPos01:  // Not yet implemented
            break;

        case D_OriPos20:  // Result is identically zero
            break;

        case D_OriPos11:  // Not yet implemented
        case D_OriPos02:  // Not yet implemented
            break;
        }
    }
    else  // Multi-sphere models
    {
        double r     = xs.GetNorm();
        double rd    = xd.GetNorm();
        double cosom = (xs&xd)/(r*rd);

        double sum0, sum1, sum2, sum3, sum4;

        switch(deriv)
        {
        case D_OriPos00:
        case D_OriPos10:
            {
                GetSums(cosom, &sum0, &sum1);
                double    f_xs  =  sum0/r;
                double    f_xd  = (sum1-sum0*cosom)/rd;
                UVector3  emf   = f_xs*xs + f_xd*xd;
                if(deriv==D_OriPos00)
                {
                    *fld += emf&dd;
                }
                else
                {
                    fld[0] += emf.Getx();
                    fld[1] += emf.Gety();
                    fld[2] += emf.Getz();
                }
            }
            break;

        case D_OriPos01:
            {
                GetSums(cosom, &sum0, &sum1, &sum2, &sum3, &sum4);

                double g_xdddxd = 3*cosom*sum0-sum1 + sum2*rd/r + (-2*sum3 + cosom*sum4)*cosom;
                double g_xdddxs = -sum0 + sum3 - cosom*sum4;
                double ddxsr    = (dd&xs)/r;
                double ddxdrd   = (dd&xd)/rd;

                double f_xd  = (g_xdddxs*ddxsr  + g_xdddxd*ddxdrd)/rd;
                double f_xs  = (sum4*ddxsr      + g_xdddxs*ddxdrd)/r;
                double f_dd  =  sum1-cosom*sum0;

                UVector3 emf = f_xd*xd + f_xs*xs + f_dd*dd;

                fld[0] += emf.Getx()/rd;
                fld[1] += emf.Gety()/rd;
                fld[2] += emf.Getz()/rd;
            }
            break;

        case D_OriPos20:  // Result is identically zero
            break;

        case D_OriPos11:                                          // Tested 20-09-2001
            {
                GetSums(cosom, &sum0, &sum1, &sum2, &sum3, &sum4);

                double g_xdddxd = 3*cosom*sum0-sum1 + sum2*rd/r + (-2*sum3 + cosom*sum4)*cosom;
                double g_xdddxs = -sum0 + sum3 - cosom*sum4;
                double f_dd     = (sum1-cosom*sum0)/rd;

                double Dddxsr   = xs.Getx()/r;
                double Dddxdrd  = xd.Getx()/rd;

                double f_xd  = (g_xdddxs*Dddxsr  + g_xdddxd*Dddxdrd)/(rd*rd);
                double f_xs  = (sum4*Dddxsr      + g_xdddxs*Dddxdrd)/(r *rd);

                UVector3 deri;
                deri         = f_xd*xd + f_xs*xs;

                fld[0]   += deri.Getx() + f_dd;
                fld[3]   += deri.Gety();
                fld[6]   += deri.Getz();

                Dddxsr    = xs.Gety()/r;
                Dddxdrd   = xd.Gety()/rd;
                f_xd      = (g_xdddxs*Dddxsr  + g_xdddxd*Dddxdrd)/(rd*rd);
                f_xs      = (sum4*Dddxsr      + g_xdddxs*Dddxdrd)/(r *rd);
                deri      = f_xd*xd + f_xs*xs;

                fld[1]   += deri.Getx();
                fld[4]   += deri.Gety() + f_dd;
                fld[7]   += deri.Getz();

                Dddxsr    = xs.Getz()/r;
                Dddxdrd   = xd.Getz()/rd;
                f_xd      = (g_xdddxs*Dddxsr  + g_xdddxd*Dddxdrd)/(rd*rd);
                f_xs      = (sum4*Dddxsr      + g_xdddxs*Dddxdrd)/(r *rd);
                deri      = f_xd*xd + f_xs*xs;

                fld[2]   += deri.Getx();
                fld[5]   += deri.Gety();
                fld[8]   += deri.Getz() + f_dd;
            }
            break;

        case D_OriPos02:  // Not yet implemented
            break;
        }
    }
}

double UEMfield::ComputeEM(const USensor& S, double *xdip, double *dd) const
/*
    Given a sensor and the dipole coordinates xd and orienation dd,
    return the magnetic field.
 */
{
    double h1,h2,h3,h4,h5,h6;
    double d1,d2,d3,d4,d5,d6,d9;
    double xs[3],xd[3],ns[3],emf[3];

    UVector3   Spos = UMultiSphereModel::SpherePos;

    xs[0]  = S.Getx().Getx() - Spos.Getx();
    xs[1]  = S.Getx().Gety() - Spos.Gety();
    xs[2]  = S.Getx().Getz() - Spos.Getz();
    xd[0]  = xdip[0]         - Spos.Getx();
    xd[1]  = xdip[1]         - Spos.Gety();
    xd[2]  = xdip[2]         - Spos.Getz();
    ns[0]  = S.Getn().Getx();
    ns[1]  = S.Getn().Gety();
    ns[2]  = S.Getn().Getz();

    h1     = xs[0]-xd[0];
    h2     = xs[1]-xd[1];
    h3     = xs[2]-xd[2];
    d1     = sqrt( h1*h1+h2*h2+h3*h3 );                            // a
    d2     = sqrt( xs[0]*xs[0] + xs[1]*xs[1] + xs[2]*xs[2] );      // r
    d3     =          h1*xs[0] +    h2*xs[1] +    h3*xs[2];        // xa
    d4     = d1*(d2*d1+d3);                                        // f

    d5     = d1 + 2*d2 + d3/d1;                                    // f2
    d6     = d1 + d1*d1/d2;                                        // a+a2/r = f1-f2
    h4     = d6*xs[0] + d5*h1;                                     // gf
    h5     = d6*xs[1] + d5*h2;
    h6     = d6*xs[2] + d5*h3;

    emf[0] =  xd[1]*ns[2] - xd[2]*ns[1];                        // q x x0
    emf[1] =  xd[2]*ns[0] - xd[0]*ns[2];
    emf[2] =  xd[0]*ns[1] - xd[1]*ns[0];

    d9     = ( h4*ns[0]+h5*ns[1]+h6*ns[2] )/d4;
    emf[0] = ( emf[0] + d9*(xs[1]*xd[2]-xs[2]*xd[1]) )/d4;
    emf[1] = ( emf[1] + d9*(xs[2]*xd[0]-xs[0]*xd[2]) )/d4;
    emf[2] = ( emf[2] + d9*(xs[0]*xd[1]-xs[1]*xd[0]) )/d4;

    return dd[0]*emf[0] + dd[1]*emf[1] + dd[2]*emf[2];
}

UMatrix UEMfield::ConvertMerge(FieldType FldT, int Ncomp, const UMatrix* Bf, const UMatrix* Ef) const
/*
    switch(FldT)
    {
    case U_MEG:    Test Bf, Convert to appropriate units, return Bf
    case U_EEG:    Test Ef, Convert to appropriate units, return Ef
    case U_MEGEEG: Test Bf,Ef, Convert to appropriate units, Merge, delete Bf anf Ef return Merged arrays
    }
    in case of error, return UMatrix(U_ERROR);
 */
{
    UMatrix M1,M2;
    switch(FldT)
    {
    case U_MEG:
    case U_MEGEEG:
        if(Bf==NULL || Bf->Data==NULL || Bf->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::ConvertMerge(). Fltd==U_MEG and Bf==NULL. \n");
            return UMatrix(U_ERROR);
        }
        M1 = UseOldUnits ? *Bf : (*Bf) * MEGNewUnits;
        if(FldT==U_MEG) return M1;

    case U_EEG:
        if(Ef==NULL || Ef->Data==NULL || Ef->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEMfield::ConvertMerge(). Fltd==U_EEG and Ef==NULL. \n");
            return NULL;
        }
        M2 = UseOldUnits ? *Ef : (*Ef) * EEGNewUnits;
        if(FldT==U_EEG) return M2;

        return M1.GetConcatCollumns(M2);
    }

    CI.AddToLog("ERROR: UEMfield::ConvertMerge(). Invalid field parameter (FldT = %d) . \n", FldT);
    return UMatrix(U_ERROR);
}
