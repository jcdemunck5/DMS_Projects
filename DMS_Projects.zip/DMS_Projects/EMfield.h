#ifndef _EMFIELD_INCLUDED
#define _EMFIELD_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    25-08-99   Use explicit public declaration for privately inhereted functions
JdM/SG   22-06-01   Made inheritance of UBemField public
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "BemField.h"

#include "HeadModel.h"
#include "MultiSphereModel.h"
#include "Dipole.h"
#include "Grid.h"
#include "Balance.h"
#include "MEEGDataBase.h"
#include "Matrix.h"

enum GrossModelType
{
    U_GMODEL_UNKNOWN,
    U_GMODEL_SPHERE,
    U_GMODEL_REALISTIC
};

class UMatrix;
class DLL_IO UEMfield : private UMultiSphereModel, public UBemField
{
public:
    enum FieldType   
    {
        U_UNKNOWN,
        U_MEG,
        U_EEG,
        U_MEGEEG
    };

    UEMfield(const UHeadModel* Hmod = NULL);
    UEMfield(const UHeadModel* Hmod, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer);
    UEMfield(const UConductor3& C, PotInterPolType PInt, BEMSmoothType Smo, bool UseMonoLayer);
    UEMfield(const UEMfield &EMF);    
    virtual ~UEMfield();
    UEMfield& operator=(const UEMfield &EMF);

    ErrorType             GetError(void) const {return error;}
    const UString&        GetProperties(UString Comment) const;

/* Make privately inhereted functions public*/
    const UNestedSurface* GetNestedSurface(int j) const               {return UBemMatrix3::GetNestedSurface(j);}
    const UNestedSurface* GetNestedSurface(const char* SurfName) const{return UBemMatrix3::GetNestedSurface(SurfName);}
    const UNestedSurface* GetSurface(int iSurface) const              {return UConductor3::GetSurface(iSurface);}
    int                   GetOuterSurf(void)                          {return UConductor3::GetOuterSurf();}
    int                   GetInnerSurf(void)                          {return UConductor3::GetInnerSurf();}
    UVector3              FitSphere(int isurf, double* Radius=NULL, double* Error=NULL) const
                                                                      {return UConductor3::FitSphere(isurf, Radius, Error);}

    double                GetInnerRadius(void)                  const {return UMultiSphereModel::GetInnerRadius();}
    ErrorType             SetRelativeElectrodeRadius(double rel)      {return UMultiSphereModel::SetRelativeElectrodeRadius(rel);}

/* Functions to control the volume conductor model*/
    UVector3              GetSpherePos(void) const;
    ErrorType             SetSigma(const double *Sigma);
    double                GetEps(int j) const;
    CondModelType         GetCondModelType(void) const;
    GrossModelType        GetGrossModelType(void) const {return GrossModel;}
    ErrorType             SwapSurfaces(int i1, int i2);

    void                  ResetBalancing(void);
    ErrorType             SetBalancing(const UGrid *GridR, const UBalance** pB, int nBal, ReReferenceType RRef);
    ErrorType             SetGrid(const UGrid *GridM=NULL, const UGrid *GridE=NULL, bool FewRightHandSides=false, bool ManySigmas=false);

/* Functions to compute the fields:*/
    bool                  GetUseOldUnits(void) const {return UseOldUnits;}
    void                  SetUseOldUnits(bool Set)   {UseOldUnits = Set;}

    UMatrix               GetEMfieldAsMatrix(const UDipole *Dipole, DerivType deriv, FieldType FldT);
    UMatrix               GetBfieldAsMatrix(const UDipole *Dipole, DerivType deriv);            // Set GridMEG in advance
    UMatrix               GetEfieldAsMatrix(const UDipole *Dipole, DerivType deriv);            // Set GridEEG in advance
    UMatrix               GetEfieldAsMatrix(double Current, int el1, int el2, int elref);
    UMatrix               GetEfieldAsMatrix(double Current, double ElSizeCm);

/* These ones are now obsolete and should be eliminated in the future */
/* Still used in BeamFormer.cpp, LocCodeDip.cpp, LocCoil.cpp, LocStatDip.cpp SignalSpaceProj.cpp and StartDipole.cpp */
    double*               GetEMfield(const UDipole *Dipole, DerivType deriv, FieldType FldT);
    double*               GetBfield(const UDipole *Dipole, DerivType deriv);                    // Set GridMEG in advance
    double*               GetEfield(const UDipole *Dipole, DerivType deriv);                    // Set GridEEG in advance
    double*               GetEfield(double Current, int el1, int el2, int elref);

protected:
    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    static UString        Properties;

    ErrorType             error;            // General error flag
    bool                  UseOldUnits;      // If true use old (undefined) units for dipole strengths to get consistency with files created before 22-08-03
                                            // else use cm for all distances, nAm*cm for dipole strength and 1./(Ohm*cm) for conductivity

    ErrorType             BalanceBfield(const UDipole *Dipole, DerivType deriv, UMatrix* Bfield) const;
    UMatrix               GetEMfieldSphere(const UDipole *Dipole, DerivType deriv, FieldType FldT);
    UMatrix               ConvertMerge(FieldType FldT, int Ncomp, const UMatrix* Bf, const UMatrix* Ef) const;

    GrossModelType        GrossModel;       // Determines whether to return data from UMultiSphereModel or UBemField
    UBalance**            pBal;             // Tables to compute balancing of the MEG forward model
    ReReferenceType       ReRef;            // Type of forward balancing (no, second or third gradient)

    double                ComputeEM(const USensor& S, double *xdip, double *dd) const;                        // Sphere models
    const double*         ComputeEM(const USensor& S, const UDipole* dip, DerivType deriv=D_OriPos00) const;  // Obsolete???
    void                  UpdateB(UVector3 &xd, UVector3 &dd, UVector3 &xs, UVector3 &ns, const DerivType deriv, double *fld) const;
    void                  UpdateE(UVector3 &xd, UVector3 &dd, UVector3 &xs, const DerivType deriv, double *fld) const;
};
#endif // _EMFIELD_INCLUDED
