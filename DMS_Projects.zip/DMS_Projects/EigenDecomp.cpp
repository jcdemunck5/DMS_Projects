/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*  GENERAL:                                                                        */
/*  The goal of the object determine the eigenvalue decomposition of a symmetric    */
/*  or Hermitian matrix. Eigenvalues are stored from large to small (possibly       */
/*  negative).                                                                      */
/*                                                                                  */
/*  NOTE:                                                                           */
/*  if(InvertEigenValues==true) Hinv = WW'                                          */
/*  else                        H    = WW' where H is the input Hermitian matrix.   */
/*                                                                                  */
/*                                                                                  */
/*  The (real) matrix H[][] can be reconstructed from:                              */
/*                                                                                  */
/*  H[k1][k2] = 0;                                                                  */
/*  for(int k=0; k<N; k++) H[k1][k2] += E1[k][k1] * E1[k][k2]*D1.GetEigenValue(k);  */
/*                                                                                  */
/*                                                                                  */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    11-10-07   Creation
  JdM    29-06-08   ComputeRatio(). Skip test on InvertEigenValues
  JdM    17-11-09   renamed ComputeRatio() as ComputeSandwitch()
  JdM    18-11-09   Added GetProperties(), added offset parameter to constructor, to regularize matrix
  JdM    13-02-10   Added Selection parameters on constructor.
  JdM    05-03-13   Added specical case of symmetric (instead of hermitian) matrix. Carefully tested code.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include<math.h>     
#include<string.h>

#include "EigenDecomp.h"
#include "DecompHermitian.h"

/* Inititalize static const parameters. */
UString UEigenDecomp::Properties       = UString();

void UEigenDecomp::SetAllMembersDefault(void)
{
    if(this==NULL) return;

    error               = U_OK;
    Ndim                = 0;
    NeigPos             = 0;
    NeigNeg             = 0;
    InvertEigenValues   = false;
    Eigen               = NULL;
    WR                  = NULL;
    WI                  = NULL;
    Properties          = UString();
}
void UEigenDecomp::DeleteAllMembers(ErrorType E)
{
    if(this==NULL) return;
 
    delete[] Eigen;
    delete[] WR;
    delete[] WI;
    SetAllMembersDefault();
    error = E;
}

UEigenDecomp::UEigenDecomp()
{
    if(this==NULL) return;
    SetAllMembersDefault();
}
UEigenDecomp::UEigenDecomp(const UEigenDecomp& EDec)
{
    if(this==NULL) return;
    SetAllMembersDefault();
    *this = EDec;
}

UEigenDecomp::UEigenDecomp(int N, const double* AmatR, const double* AmatI, bool Invert, double DiagOffset, const int* Select, int NSelect)
{
    SetAllMembersDefault();
    
    if(N<=0 || AmatR==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid N (=%d) or NULL argument. \n", N);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Select)
    {
        if(NSelect<=0||NSelect>N)
        {
            CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid NSelect (=%d). \n", NSelect);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int is=0; is<NSelect; is++)
            if(Select[is]<0 || Select[is]>=N)
            {
                CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid Selection (Select[%d]=%d). \n", is, Select[is]);
                DeleteAllMembers(U_ERROR);
                return;
            }
        Ndim   = NSelect;
    }
    else
    {
        Ndim   = N;
    }
    double* AR = new double[Ndim*Ndim];
    double* AI = new double[Ndim*Ndim];
    if(AR==NULL || AI==NULL)
    {
        delete[] AR;
        delete[] AI;
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Memory allocation. Ndim = %d   . \n", Ndim);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Select)
    {
        for(int n1=0; n1<Ndim; n1++)
            for(int n2=0; n2<Ndim; n2++)
            {
                int nnS = Select[n1]*N   +Select[n2];
                int nn  =        n1 *Ndim+       n2 ;
                AR[nn]           = AmatR[nnS];
                if(AmatI) AI[nn] = AmatI[nnS];
                else      AI[nn] = 0;
            }
    }
    else
    {
        for(int nn=0; nn<Ndim*Ndim; nn++)
        {
            AR[nn]           = AmatR[nn];
            if(AmatI) AI[nn] = AmatI[nn];
            else      AI[nn] = 0;
        }
    }
    Eigen  = new double[Ndim];
    WR     = new double[Ndim*Ndim];
    WI     = new double[Ndim*Ndim];
    if(Eigen==NULL || WR==NULL || WI==NULL)
    {
        delete[] AR;
        delete[] AI;
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Memory allocation (member arrays). Ndim = %d   . \n", Ndim);
        DeleteAllMembers(U_ERROR);
        return;
    }
    UDecompHermitian Herm;

    if(Herm.Decompose(Ndim, AR, AI, true, Eigen, WR, WI)!=U_OK)
    {
        delete[] AR;
        delete[] AI;
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Decomposing matrix. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    delete[] AR;
    delete[] AI;

    NeigPos             = 0;
    NeigNeg             = 0;
    InvertEigenValues   = Invert;

    for(int k=0; k<Ndim;k++) Eigen[k] += DiagOffset*Eigen[0];
    for(int k=0; k<Ndim;k++)
    {
        double SqEig    = sqrt(fabs(Eigen[k]));
        double SqEigInv = 0.;
        if(SqEig*SqEig !=.0) 
               SqEigInv = 1./SqEig;

        if(Invert== true)
        {
            for(int i=0;i<Ndim;i++) WR[i*Ndim+k] *= SqEigInv;
            for(int i=0;i<Ndim;i++) WI[i*Ndim+k] *= SqEigInv;
        }
        else
        {
            for(int i=0;i<Ndim;i++) WR[i*Ndim+k] *= SqEig;
            for(int i=0;i<Ndim;i++) WI[i*Ndim+k] *= SqEig;
        }
        if(Eigen[k]>0.) NeigPos++;
        if(Eigen[k]<0.) NeigNeg++;
    }    
    if(AmatI==NULL)
    {
        delete[] WI; WI = NULL;
    }
}
UEigenDecomp::UEigenDecomp(int N, const double* Amat, bool Invert, double DiagOffset, const int* Select, int NSelect)
{
    SetAllMembersDefault();
    
    if(N<=0 || Amat==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid N (=%d) or NULL argument. \n", N);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Select)
    {
        if(NSelect<=0||NSelect>N)
        {
            CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid NSelect (=%d). \n", NSelect);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int is=0; is<NSelect; is++)
            if(Select[is]<0 || Select[is]>=N)
            {
                CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Invalid Selection (Select[%d]=%d). \n", is, Select[is]);
                DeleteAllMembers(U_ERROR);
                return;
            }
        Ndim   = NSelect;
    }
    else
    {
        Ndim   = N;
    }
    double* A = new double[Ndim*Ndim];
    if(A==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Memory allocation. Ndim = %d   . \n", Ndim);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Select)
    {
        for(int n1=0; n1<Ndim; n1++)
            for(int n2=0; n2<Ndim; n2++)
            {
                int nnS = Select[n1]*N   +Select[n2];
                int nn  =        n1 *Ndim+       n2 ;
                A[nn]   = Amat[nnS];
            }
    }
    else
    {
        for(int nn=0; nn<Ndim*Ndim; nn++) A[nn]  = Amat[nn];
    }
    Eigen  = new double[Ndim];
    WR     = new double[Ndim*Ndim];
    if(Eigen==NULL || WR==NULL)
    {
        delete[] A;
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Memory allocation (member arrays). Ndim = %d   . \n", Ndim);
        DeleteAllMembers(U_ERROR);
        return;
    }
    UDecompHermitian Herm;

    if(Herm.Decompose(Ndim, A, true, Eigen, WR)!=U_OK)
    {
        delete[] A;
        CI.AddToLog("ERROR: UEigenDecomp::UEigenDecomp(). Decomposing matrix. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    delete[] A;

    NeigPos             = 0;
    NeigNeg             = 0;
    InvertEigenValues   = Invert;

    for(int k=0; k<Ndim;k++) Eigen[k] += DiagOffset*Eigen[0];
    for(int k=0; k<Ndim;k++)
    {
        double SqEig    = sqrt(fabs(Eigen[k]));
        double SqEigInv = 0.;
        if(SqEig*SqEig !=.0) 
               SqEigInv = 1./SqEig;

        if(Invert== true)
        {
            for(int i=0;i<Ndim;i++) WR[i*Ndim+k] *= SqEigInv;
        }
        else
        {
            for(int i=0;i<Ndim;i++) WR[i*Ndim+k] *= SqEig;
        }
        if(Eigen[k]>0.) NeigPos++;
        if(Eigen[k]<0.) NeigNeg++;
    }    
}
UEigenDecomp::~UEigenDecomp()
{
    DeleteAllMembers(U_OK);
}

UEigenDecomp& UEigenDecomp::operator=(const UEigenDecomp &EDec)
{
    if(this==NULL)
    {
        static UEigenDecomp Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: UEigenDecomp::operator=(). this==NULL. \n");
        return Def;
    }
    if(&EDec==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&EDec) return *this;

    DeleteAllMembers(U_OK);

    error               = EDec.error;
    Ndim                = EDec.Ndim;
    NeigPos             = EDec.NeigPos;
    NeigNeg             = EDec.NeigNeg;
    InvertEigenValues   = EDec.InvertEigenValues;
    if(EDec.Eigen)
    {
        Eigen = new double[Ndim];
        if(Eigen==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEigenDecomp::operator=(). Allocating memory for Eigen[]. \n");
            return *this;
        }
        for(int k=0; k<Ndim; k++) Eigen[k] = EDec.Eigen[k];
    }
    if(EDec.WR)
    {
        WR  = new double[Ndim*Ndim];
        if(WR==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEigenDecomp::operator=(). Allocating memory for WR[]. \n");
            return *this;
        }
        for(int k=0; k<Ndim*Ndim; k++) WR[k] = EDec.WR[k];
    }
    if(EDec.WI)
    {
        WI  = new double[Ndim*Ndim];
        if(WI==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEigenDecomp::operator=(). Allocating memory for WI[]. \n");
            return *this;
        }
        for(int k=0; k<Ndim*Ndim; k++) WI[k] = EDec.WI[k];
    }
    return *this;
}

ErrorType UEigenDecomp::GetError(void) const
{
    if(this==NULL||error!=U_OK) return U_ERROR;
    return U_OK;
}

bool UEigenDecomp::IsPositiveSemiDef(void) const
{
    if(this==NULL||error!=U_OK) return false;
    if(Ndim<=0)                 return false;
    if(NeigNeg>0)               return false;
    return true;
}
bool UEigenDecomp::IsNegativeSemiDef(void) const
{
    if(this==NULL||error!=U_OK) return false;
    if(Ndim<=0)                 return false;
    if(NeigPos>0)               return false;
    return true;
}

int UEigenDecomp::GetNeigPos(void) const
{
    if(this==NULL||error!=U_OK) return 0;
    return NeigPos;
}
int UEigenDecomp::GetNeigNeg(void) const
{
    if(this==NULL||error!=U_OK) return 0;
    return NeigNeg;
}
double UEigenDecomp::GetEigenValue(int index) const
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenValue(). this==NULL or erroneous. \n");
        return 0;
    }
    if(Eigen==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenValue(). Eigen==NULL. \n");
        return 0;
    }
    if(index<0 || index>Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenValue(). invalid index (=%d). \n", index);
        return 0;
    }
    return Eigen[index];
}
double* UEigenDecomp::GetEigenVectorR(int index) const
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorR(). this==NULL or erroneous. \n");
        return NULL;
    }
    if(Eigen==NULL || WR==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorR(). Eigen==NULL or WR==NULL. \n");
        return NULL;
    }
    if(index<0 || index>Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorR(). Invalid index (=%d). \n", index);
        return NULL;
    }
    double* EigVec = new double[Ndim];
    if(EigVec==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorR(). Memory allocation, Ndim = %d. \n", Ndim);
        return NULL;
    }
    double SqEig    = sqrt(fabs(Eigen[index]));
    double SqEigInv = 0.;
    if(SqEig*SqEig !=.0) 
           SqEigInv = 1./SqEig;

    if(InvertEigenValues== true) for(int i=0;i<Ndim;i++) EigVec[i] = WR[i*Ndim+index] * SqEig;
    else                         for(int i=0;i<Ndim;i++) EigVec[i] = WR[i*Ndim+index] * SqEigInv;

    return EigVec;
}
double* UEigenDecomp::GetEigenVectorI(int index) const
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorI(). this==NULL or erroneous. \n");
        return NULL;
    }
    if(Eigen==NULL || WI==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorI(). Eigen==NULL or WI==NULL. \n");
        return NULL;
    }
    if(index<0 || index>Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorI(). Invalid index (=%d). \n", index);
        return NULL;
    }
    double* EigVec = new double[Ndim];
    if(EigVec==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::GetEigenVectorI(). Memory allocation, Ndim = %d. \n", Ndim);
        return NULL;
    }
    double SqEig    = sqrt(fabs(Eigen[index]));
    double SqEigInv = 0.;
    if(SqEig*SqEig !=.0) 
           SqEigInv = 1./SqEig;

    if(InvertEigenValues== true) for(int i=0;i<Ndim;i++) EigVec[i] = WI[i*Ndim+index] * SqEig;
    else                         for(int i=0;i<Ndim;i++) EigVec[i] = WI[i*Ndim+index] * SqEigInv;

    return EigVec;
}

int UEigenDecomp::GetNdim(void) const
{
    if(this==NULL||error!=U_OK) return 0;
    return Ndim;
}
int UEigenDecomp::SetEigenRelThreshold(double RelThreshold)
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetEigenRelThreshold(). this==NULL or erroneous. \n");
        return 0;
    }
    if(Eigen==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetEigenRelThreshold(). Eigen==NULL. \n");
        return 0;
    }
    if(RelThreshold<0)
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetEigenRelThreshold(). Erroneous threshold argument: RelThreshold=%g  . \n", RelThreshold);
        return 0;
    }

    double SumAbsEigen = 0;
    for(int k=0;k<Ndim; k++) SumAbsEigen += fabs(Eigen[k]);
    if(SumAbsEigen<1.e-20)
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetEigenRelThreshold(). SumAbsEigen==%g is too small. \n", SumAbsEigen);
        return 0;
    }
    double AbsThreshold = RelThreshold * SumAbsEigen;

    NeigPos = 0;
    NeigNeg = 0;

    for(int k=0;k<Ndim; k++) 
    {
        if(Eigen[k]>= AbsThreshold)     NeigPos++;
        else 
            if(Eigen[k]<=-AbsThreshold) NeigNeg++;
    }
    return NeigPos;
}
ErrorType UEigenDecomp::SetNeigPos(int Neig)
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigPos(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Eigen==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigPos(). Eigen==NULL. \n");
        return U_ERROR;
    }
    if(Neig<0 || Neig>Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigPos(). Erroneous Neig argument: Neig=%d  . \n", Neig);
        return U_ERROR;
    }
    int MaxPos = 0;
    for(int k=0;k<Ndim; k++) if(Eigen[k]>=0) MaxPos++;

    NeigPos = MIN(MaxPos, Neig);
    return U_OK;
}
ErrorType UEigenDecomp::SetNeigNeg(int Neig)
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigNeg(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Eigen==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigNeg(). Eigen==NULL. \n");
        return U_ERROR;
    }
    if(Neig<0 || Neig>Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::SetNeigNeg(). Erroneous Neig argument: Neig=%d  . \n", Neig);
        return U_ERROR;
    }
    int MaxNeg = 0;
    for(int k=0;k<Ndim; k++) if(Eigen[k]<0) MaxNeg++;

    NeigNeg = MIN(MaxNeg, Neig);
    return U_OK;
}

UEigenDecomp UEigenDecomp::ComputeSandwitch(const UEigenDecomp& EDecMid, const UEigenDecomp& EDecFlank) // static
/*
     Returns   (EDecFlank.W)T * EDecMid * EDecFlank.W
 */
{
    UEigenDecomp Default; Default.error = U_ERROR;

    if(&EDecMid==NULL            || &EDecFlank==NULL            || 
        EDecMid.GetError()!=U_OK ||  EDecFlank.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEigenDecomp::ComputeSandwitch(). NULL or erroneous arguments. \n");
        return Default;
    }

    if(EDecMid.Ndim != EDecFlank.Ndim)
    {
        CI.AddToLog("ERROR: UEigenDecomp::ComputeSandwitch(). Dimensions not compatible (%d and %d). \n", EDecMid.Ndim, EDecFlank.Ndim);
        return Default;
    }

    double* ProdR = NULL;
    double* ProdI = NULL;
    if(EDecMid.Compute_MatT_A_Mat(EDecFlank.WR, EDecFlank.WI, EDecFlank.Ndim, &ProdR, &ProdI)!=U_OK)
    {
        delete[] ProdR; 
        delete[] ProdI; 
        CI.AddToLog("ERROR: UEigenDecomp::ComputeSandwitch(). Computing matrix product. \n");
        return Default;
    }

    UEigenDecomp Result(EDecFlank.Ndim, ProdR, ProdI, false);
    delete[] ProdR; 
    delete[] ProdI; 
    if(Result.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEigenDecomp::ComputeSandwitch(). Combining end results. \n");
        return Default;
    }
    return Result;
}

ErrorType UEigenDecomp::Compute_MatT_A_Mat(const double* MatR, const double* MatI, int Ncol, double** ProdR, double**ProdI) const
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Eigen==NULL || WR==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). Eigen==NULL || WR==NULL. \n");
        return U_ERROR;
    }

    if(MatR==NULL || Ncol<=0)
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). NULL real part of matrix argument, Ncol = %d  .\n",Ncol);
        return U_ERROR;
    }
    if(ProdR==NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). NULL real part of output matrix argument.\n");
        return U_ERROR;
    }
    *ProdR = new double[Ncol*Ncol];
    if(*ProdR == NULL)
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). Memory allocation. Ndim=%d, Ncol = %d  .\n",Ndim,Ncol);
        return U_ERROR;
    }
    for(int k=0; k<Ncol*Ncol; k++) (*ProdR)[k] = 0.;

    if(ProdI)
    {
        *ProdI = new double[Ncol*Ncol];
        if(*ProdI == NULL)
        {
            if(ProdR) {delete[] *ProdR; *ProdR = NULL;}
            CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). Memory allocation. Ndim=%d, Ncol = %d  .\n",Ndim,Ncol);
            return U_ERROR;
        }
        for(int k=0; k<Ncol*Ncol; k++) (*ProdI)[k] = 0.;
    }

    double* WTMatR = NULL;
    double* WTMatI = NULL;

    if(Compute_WT_Mat(MatR, MatI, Ncol, &WTMatR, &WTMatI)!=U_OK || WTMatR==NULL)
    {
        delete[] WTMatR; 
        delete[] WTMatI; 
        if(ProdR) {delete[] *ProdR; *ProdR = NULL;}
        if(ProdI) {delete[] *ProdI; *ProdI = NULL;}

        CI.AddToLog("ERROR: UEigenDecomp::Compute_MatT_A_Mat(). Computation of WT * Mat. \n");
        return U_ERROR;
    }

    for(int j1=0; j1<Ncol; j1++)
    {
        for(int j2=0; j2<Ncol; j2++) 
        {
            (*ProdR)[j1*Ncol+j2]  = 0.;
            (*ProdI)[j1*Ncol+j2]  = 0.;

            if(j2>=j1)
            {
                double PosR        = 0.;
                double PosI        = 0.;
                const double* pWR1 = WTMatR+j1;
                const double* pWR2 = WTMatR+j2;
                const double* pWI1 = NULL; if(WTMatI) pWI1 = WTMatI+j1;
                const double* pWI2 = NULL; if(WTMatI) pWI2 = WTMatI+j2;

                for(int k=0;      k <NeigPos;      k++, pWR1+=Ncol, pWR2+=Ncol) PosR += *pWR1 * *pWR2; 
                if(WTMatI)
                {
                    pWR1 = WTMatR+j1;
                    pWR2 = WTMatR+j2;
                    for(int k=0;      k <NeigPos;      k++, pWR1+=Ncol, pWR2+=Ncol, pWI1+=Ncol, pWI2+=Ncol) 
                    {
                        PosR           += *pWI1 * *pWI2; 
                        if(ProdI) PosI += *pWR1 * *pWI2 - *pWI1 * *pWR2; 
                    }
                }
                          (*ProdR)[j1*Ncol+j2] += PosR;                
                if(ProdI) (*ProdI)[j1*Ncol+j2] += PosI;


                double NegR = 0.;
                double NegI = 0.;
                pWR1        = WTMatR+j1;
                pWR2        = WTMatR+j2;
                pWI1        = NULL; if(WTMatI) pWI1 = WTMatI+j1;
                pWI2        = NULL; if(WTMatI) pWI2 = WTMatI+j2;

                for(int k=Ndim-1; k>=Ndim-NeigNeg; k--, pWR1+=Ncol, pWR2+=Ncol) NegR += *pWR1 * *pWR2; 
                if(WTMatI)
                {
                    pWR1 = WTMatR+j1;
                    pWR2 = WTMatR+j2;
                    for(int k=Ndim-1; k>=Ndim-NeigNeg; k--, pWR1+=Ncol, pWR2+=Ncol, pWI1+=Ncol, pWI2+=Ncol) 
                    {
                                  NegR += *pWI1 * *pWI2; 
                        if(ProdI) NegI += *pWR1 * *pWI2 - *pWI1 * *pWR2; 
                    }
                }
                          (*ProdR)[j1*Ncol+j2] -= NegR;                
                if(ProdI) (*ProdI)[j1*Ncol+j2] -= NegI;
            }
            else 
            {
                if(ProdR) (*ProdR)[j1*Ncol+j2]  = (*ProdR)[j2*Ncol+j1];
                if(ProdI) (*ProdI)[j1*Ncol+j2]  =-(*ProdI)[j2*Ncol+j1];
            }
        }
    }
    delete[] WTMatR;
    delete[] WTMatI;
    return U_OK;
}

ErrorType UEigenDecomp::Compute_WT_Mat(const double* MatR, const double* MatI, int Ncol, double** WTMatR, double** WTMatI) const
{
    if(this==NULL||error!=U_OK) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_WT_Mat(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Eigen==NULL || WR==NULL) 
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_WT_Mat(). Eigen==NULL || WR==NULL. \n");
        return U_ERROR;
    }
    if(WTMatR==NULL && WTMatI==NULL) return U_OK; // Nothing to do

    if(MatR==NULL || Ncol<=0)
    {
        CI.AddToLog("ERROR: UEigenDecomp::Compute_WT_Mat(). NULL real part of matrix argument, Ncol = %d  .\n",Ncol);
        return U_ERROR;
    }
    if(WTMatR)
    {
        *WTMatR = new double[Ndim*Ncol];
        if(*WTMatR == NULL)
        {
            CI.AddToLog("ERROR: UEigenDecomp::Compute_WT_Mat(). Memory allocation. Ndim=%d, Ncol = %d  .\n",Ndim,Ncol);
            return U_ERROR;
        }
    }
    if(WTMatI)
    {
        *WTMatI = new double[Ndim*Ncol];
        if(*WTMatI == NULL)
        {
            if(WTMatR) {delete[] *WTMatR; *WTMatR = NULL;}
            CI.AddToLog("ERROR: UEigenDecomp::Compute_WT_Mat(). Memory allocation. Ndim=%d, Ncol = %d  .\n",Ndim,Ncol);
            return U_ERROR;
        }
    }

    if(WTMatR) for(int jk=0; jk<Ncol*Ndim; jk++) (*WTMatR)[jk] = 0;
    if(WTMatI) for(int jk=0; jk<Ncol*Ndim; jk++) (*WTMatI)[jk] = 0;

    for(int j=0; j<Ncol; j++)
    {
        for(int k=0;      k <NeigPos;      k++) 
        {
            if(WTMatR)
            {
                double PosR       = 0.;
                const double* pWR = WR  +k;
                const double* pMR = MatR+j;
                const double* pWI = NULL; if(WI  ) pWI = WI  +k;
                const double* pMI = NULL; if(MatI) pMI = MatI+j;
                               for(int i=0; i<Ndim; i++, pWR+=Ndim, pMR+=Ncol) PosR += *pWR * *pMR;           
                if(pWI && pMI) for(int i=0; i<Ndim; i++, pWI+=Ndim, pMI+=Ncol) PosR += *pWI * *pMI;
            
                (*WTMatR)[k*Ncol+j] += PosR;
            }
            if(WTMatI)
            {
                double PosI       = 0.;
                const double* pWR = WR  +k;
                const double* pMR = MatR+j;
                const double* pWI = NULL; if(WI  ) pWI = WI  +k;
                const double* pMI = NULL; if(MatI) pMI = MatI+j;
                if(pMI)        for(int i=0; i<Ndim; i++, pWR+=Ndim, pMI+=Ncol) PosI += *pWR * *pMI;     
                if(pWI)        for(int i=0; i<Ndim; i++, pWI+=Ndim, pMR+=Ncol) PosI -= *pWI * *pMR;     

                (*WTMatI)[k*Ncol+j] += PosI;
            }
        }

        for(int k=Ndim-1; k>=Ndim-NeigNeg; k--) 
        {
            if(WTMatR)
            {
                double NegR       = 0.;
                const double* pWR = WR  +k;
                const double* pMR = MatR+j;
                const double* pWI = NULL; if(WI  ) pWI = WI  +k;
                const double* pMI = NULL; if(MatI) pMI = MatI+j;
                               for(int i=0; i<Ndim; i++, pWR+=Ndim, pMR+=Ncol) NegR += *pWR * *pMR;           
                if(pWI && pMI) for(int i=0; i<Ndim; i++, pWI+=Ndim, pMI+=Ncol) NegR += *pWI * *pMI;
            
                (*WTMatR)[k*Ncol+j] -= NegR;
            }
            if(WTMatI)
            {
                double NegI       = 0.;
                const double* pWR = WR  +k;
                const double* pMR = MatR+j;
                const double* pWI = NULL; if(WI  ) pWI = WI  +k;
                const double* pMI = NULL; if(MatI) pMI = MatI+j;
                if(pMI)   for(int i=0; i<Ndim; i++, pWR+=Ndim, pMI+=Ncol) NegI += *pWR * *pMI;     
                if(pWI)   for(int i=0; i<Ndim; i++, pWI+=Ndim, pMR+=Ncol) NegI -= *pWI * *pMR;     

                (*WTMatI)[k*Ncol+j] -= NegI;
            }
        }
    }
    return U_OK;
}

const UString& UEigenDecomp::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UEigenDecomp-object\n");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(BoolAsText(InvertEigenValues) 
                                                  ,"InvertMat          = %s \n");
    Properties += UString(Ndim                    ,"Ndim               = %d \n");
    Properties += UString(NeigPos                 ,"NeigenPos          = %d \n");
    Properties += UString(NeigNeg                 ,"NeigenNeg          = %d \n");
    if(Eigen)
    {
        Properties += UString(Eigen[0]                ,"LargestEigenvalue  = %f \n");
        Properties += UString(Eigen[NeigPos-1]        ,"SmallestEigenvalue = %f \n");
        Properties += UString(Eigen[Ndim-1]           ,"Eigen[N-1]         = %f \n");
        if(Eigen[NeigPos-1]>0.)
        {
            double EigenRatio = Eigen[0]/Eigen[NeigPos-1];
            Properties += UString(EigenRatio              ,"EigenRatio         = %f \n");
        }
    }

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}
