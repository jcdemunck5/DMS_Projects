#ifndef _EIGENDECOMP_INCLUDED
#define _EIGENDECOMP_INCLUDED

#include "String.h"


class DLL_IO UEigenDecomp
{
public:
    UEigenDecomp();
    UEigenDecomp(const UEigenDecomp& EDec); 
    UEigenDecomp(int N, const double* AmatR, const double* AmatI, bool Invert, double DiagOffset = 0., const int* Select=NULL, int NSelect=-1);
    UEigenDecomp(int N, const double* Amat, bool Invert, double DiagOffset = 0., const int* Select=NULL, int NSelect=-1);
    ~UEigenDecomp();
    UEigenDecomp&       operator=(const UEigenDecomp &EDec);


    ErrorType           GetError(void) const;
    const UString&      GetProperties(UString Comment) const;

    int                 GetNdim(void) const;
    int                 GetNeigPos(void) const;
    int                 GetNeigNeg(void) const;
    bool                IsPositiveSemiDef(void) const;
    bool                IsNegativeSemiDef(void) const;
    double              GetEigenValue(int index) const;
    double*             GetEigenVectorR(int index) const;
    double*             GetEigenVectorI(int index) const;
    int                 SetEigenRelThreshold(double Thresh);
    ErrorType           SetNeigPos(int Neig);
    ErrorType           SetNeigNeg(int Neig);

    ErrorType           Compute_MatT_A_Mat(const double* MatR, const double* MatI, int Ncol, double** ProdR, double**ProdI) const;
    static UEigenDecomp ComputeSandwitch(const UEigenDecomp& EDecMid, const UEigenDecomp& EDecFlank);

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
    ErrorType           Compute_WT_Mat(const double* MatR, const double* MatI, int Ncol, double** WTMatR, double** WTMatI) const;

private:
    static UString      Properties;
    ErrorType           error;
    int                 Ndim;
    int                 NeigPos;
    int                 NeigNeg;
    bool                InvertEigenValues;
    double*             Eigen;
    double*             WR;
    double*             WI;
};
#endif // _EIGENDECOMP_INCLUDED
