/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    20-06-14   creation
*/


#include "ElasticNet.h"
#include "MatrixSquare.h"

static const double MINDELTA = 1.e-12;

UString UElasticNet::Properties = UString();

#include "PWLSolutionPath.h"
////UString UPathStep  ::Properties = UString();


void UElasticNet::SetAllMembersDefault(void)
{
    Properties  = UString();   
    error       = U_OK;

    X           = UMatrix();
    y           = UMatrix();

    Nrow        = 0;
    Ncol        = 0;
    Nact        = 0;
    Iact        = NULL;
    Ipas        = NULL;
    Delta       = 0.;
    Path        = NULL;
    NStep       = 0;
    NStepAlloc  = 0;
}
void UElasticNet::DeleteAllMembers(ErrorType E)
{
    delete[] Iact;
    delete[] Ipas;
    if(Path)  for(int s=0; s<NStepAlloc; s++) delete Path[s];
    delete[] Path;
    Path        = NULL;
    NStep       = 0;
    NStepAlloc  = 0;

    SetAllMembersDefault();
    error       = E;
}

UElasticNet::UElasticNet()
{
    SetAllMembersDefault();
}
UElasticNet::UElasticNet(ErrorType E)
{
    SetAllMembersDefault();
    error       = E;
}
UElasticNet::UElasticNet(const UElasticNet& EN)
{
    SetAllMembersDefault();
    *this = EN;
}
UElasticNet::UElasticNet(const UMatrix& A, const UMatrix& b, double delta)
{
    SetAllMembersDefault();

    if(&A==NULL || A.GetError()!= U_OK || &b==NULL || b.GetError()!= U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UElasticNet::UElasticNet(). Erroneous UMatrix argument(s).\n");
        return;
    }
    if(A.GetNrow()!=b.GetNrow() || A.GetNrow()<1 || b.GetNcol()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UElasticNet::UElasticNet(). Invalid matrix size(a) A(%d,%d), b(%d,%d).\n", A.GetNrow(), A.GetNcol(), b.GetNrow(), b.GetNcol());
        return;
    }
    X      = A;
    y      = b;
    Delta  = MAX(0., delta);
    if(delta!=0 && Delta<MINDELTA)
    {
        CI.AddToLog("Warning: UElasticNet::UElasticNet(). Delta (%g) rounded off to 0. .\n", Delta);
        Delta = 0;
    }

    if(InitializePath()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UElasticNet::UElasticNet(). Initializing solution path.\n");
        return;
    }
}
UElasticNet::~UElasticNet()
{
    DeleteAllMembers(U_OK);
}
UElasticNet& UElasticNet::operator=(const UElasticNet& EN)
{
    if(this==NULL)
    {
        static UElasticNet ERROR(U_ERROR);
        CI.AddToLog("ERROR: UElasticNet::operator=(). Object NULL.\n");
        return ERROR;
    }
    if(&EN==NULL || EN.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UElasticNet::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    Nrow        = EN.Nrow;
    Ncol        = EN.Ncol;
    Nact        = EN.Nact;
    if(EN.Iact)
    {
        Iact   = new bool[EN.Ncol];
        if(Iact) for(int k=0; k<Ncol; k++) Iact[k] = EN.Iact[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UElasticNet::operator=(). Memory allocation (NCol=%d).\n", Ncol);
            return *this;
        }
    }
    if(EN.Ipas)
    {
        Ipas   = new bool[EN.Ncol];
        if(Ipas  ) for(int k=0; k<Ncol; k++) Ipas[k] = EN.Ipas[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UElasticNet::operator=(). Memory allocation, (NCol=%d).\n", Ncol);
            return *this;
        }
    }
    Delta       = EN.Delta;
    X           = EN.X;
    y           = EN.y;
    if(X.GetError()!=U_OK || y.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Copying one of the UMatrix objects.\n");
        return *this;
    }

    NStep       = EN.NStep;
    NStepAlloc  = EN.NStep;
    if(EN.Path)
    {
        Path = new UPathStep*[NStep];
        if(Path)
        {
            for(int s=0; s<NStep; s++) Path[s] = NULL;
            for(int s=0; s<NStep; s++)
            {
                Path[s] = new UPathStep(*EN.Path[s]);
                if(Path[s]==NULL || Path[s]->GetError()!=U_OK)
                {
                    for(int ss=0; ss<NStep; ss++) {delete Path[s]; Path[s]=NULL;}
                    delete[] Path; Path=NULL;
                    break;
                }
            }
        }
    }
    if(Path==NULL && EN.Path!=NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Copying solution path.\n");
        return *this;
    }

    return *this;
}

const UString& UElasticNet::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMatrix() object.\n");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(Nrow      , "Nrow          = %d \n");
    Properties += UString(Ncol      , "Ncol          = %d \n");
    Properties += UString(Delta     , "Delta         = %f \n");
    Properties += UString(NStep     , "NStep         = %d \n");
    Properties += UString(NStepAlloc, "NStepAlloc    = %d \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UElasticNet::InitializePath()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(X.GetNcol()<1 || X.GetNrow()<1 || y.GetNrow()<1 || y.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UElasticNet::InitializePath(). Data matrices not set.  (Nrow, Ncol) = (%d, %d).\n", X.GetNrow(), X.GetNcol());
        return U_ERROR;
    }

    NStep  = 0;
    Nrow   = X.GetNrow();
    Ncol   = X.GetNcol();
    Nact   = 0;
    delete[] Iact; Iact   = new bool[Ncol];
    delete[] Ipas; Ipas   = new bool[Ncol];
    if(Iact==NULL || Ipas  ==NULL)
    {
        CI.AddToLog("ERROR: UElasticNet::InitializePath(). Memory allocation, Ncol = %d.\n", Ncol);
        return U_ERROR;
    }
    for(int k=0; k<Ncol; k++) {Iact[k]=false; Ipas[k]=true;}

    return U_OK;
}
ErrorType UElasticNet::AddFirstStep(int FirstActive)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(FirstActive<0 || FirstActive>=Ncol)
    {
        CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Index out of range, %d  .\n", FirstActive);
        return U_ERROR;
    }
    if(NStep!=0)
    {
        CI.AddToLog("WARNING: UElasticNet::AddSolutionStep(). Deleting prevoius %d steps = %d .\n", NStep);
        if(Path) for(int s=0;s<NStepAlloc; s++) delete Path[s];
        NStep = 0;
    }
    if(Path==NULL || NStepAlloc<=0)
    {
        int NewAlloc = 100;
        Path = new UPathStep*[NewAlloc];
        if(Path==NULL)
        {
            CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Initializing path.\n");
            return U_ERROR;
        }
        for(int s=0; s<NewAlloc; s++) Path[s] = NULL;
        NStepAlloc = NewAlloc;
    }
    UPathStep* Pnew = new UPathStep(X, y, FirstActive, Delta, U_PWL_ELASTICNET, 0., U_PATH_UNKNOWN);
    if(Pnew==NULL||Pnew->GetError()!=U_OK)
    {
        delete Pnew;
        CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Computing first step.\n");
        return U_ERROR;
    }
    Path[0] = Pnew;
    NStep = 1;
    return U_OK;
}

ErrorType UElasticNet::AddSolutionStep(const UMatrix& Bet, bool* Iact)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Path==NULL || NStepAlloc<=0)
    {
        int NewAlloc = 100;
        Path = new UPathStep*[NewAlloc];
        if(Path==NULL)
        {
            CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Initializing path.\n");
            return U_ERROR;
        }
        for(int s=0; s<NewAlloc; s++) Path[s] = NULL;
        NStepAlloc = NewAlloc;
    }
    if(NStep+1>NStepAlloc)
    {
        int         NewAlloc = 2*NStep;
        UPathStep** NewPath  = new UPathStep*[NewAlloc];
        if(NewPath==NULL)
        {
            CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Memory allocation, NewAlloc = %d.\n", NewAlloc);
            return U_ERROR;
        }
        for(int s=0    ; s<NStep   ; s++) NewPath[s] = Path[s];
        for(int s=NStep; s<NewAlloc; s++) NewPath[s] = NULL;
        NStepAlloc = NewAlloc;
        delete[] Path; Path = NewPath;
    }
    UPathStep* Pnew = new UPathStep(X, y, Bet, Iact, Delta, U_PWL_ELASTICNET, 0., U_PATH_UNKNOWN, true);
    if(Pnew==NULL||Pnew->GetError()!=U_OK)
    {
        delete Pnew;
        CI.AddToLog("ERROR: UElasticNet::AddSolutionStep(). Computing next step, NStep = %d.\n", NStep);
        return U_ERROR;
    }
    Path[NStep++] = Pnew;
    return U_OK;
}
ErrorType UElasticNet::ComputeSolutionPathStep(int MinNStep, bool LARS)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathStep(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MinNStep<=0)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathStep(). Invalid argument, MinNStep = %d  .\n", MinNStep);
        return U_ERROR;
    }

    if(LARS) return ComputeSolutionPathLARS(false, 0., true, MinNStep);
    else     return ComputeSolutionPath    (false, 0., true, MinNStep);
}

ErrorType UElasticNet::ComputeSolutionPathLam(double MaxLam1, bool LARS)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLam(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MaxLam1<0)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLam(). Invalid argument, Lam1 = %f  .\n", MaxLam1);
        return U_ERROR;
    }

    if(LARS) return ComputeSolutionPathLARS(true, MaxLam1, false, -1);
    else     return ComputeSolutionPath    (true, MaxLam1, false, -1);
}
ErrorType UElasticNet::ComputeSolutionPathLARS(bool MaxLam, double MaxLam1, bool MinStep, int MinNStep)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MaxLam==false && MinStep==false)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). No Stopping ciriterium set.\n");
        return U_ERROR;
    }
    if(Path==NULL || Iact==NULL || Ipas==NULL)
    {
        if(InitializePath()!=U_OK)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Initializing path.\n");
            return U_ERROR;
        }
    }
    if(MaxLam)
    {
        if(MaxLam1<0)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Invalid argument, MaxLam1 = %f  .\n", MaxLam1);
            return U_ERROR;
        }
        if(MinStep==false && NStep>0 && Path && Path[NStep-1]->GetLamda1()<=MaxLam1) return U_OK;
    }
    if(MinStep)
    {
        if(MinNStep<=0)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Invalid argument, MinNStep = %d  .\n", MinNStep);
            return U_ERROR;
        }
        if(MaxLam==false && NStep>=MinNStep && Path) return U_OK;
    }
    if(MaxLam&&MinStep)
    {
        if(NStep>=MinNStep && Path && Path[NStep-1]->GetLamda1()<=MaxLam1) return U_OK;
    }

    if(Path)
    {
        Nact = 0;
        for(int k=0; k<Ncol; k++) 
        {
            Iact[k] = Path[NStep-1]->IsActive(k); 
            Ipas[k] = NOT(Iact[k]);
            if(Iact[k]) Nact++;
        }
        CI.AddToLog("WARNING: UElasticNet::ComputeSolutionPathLARS(). Continuing from existing path not yet tested!!! (NStep=%d)\n", NStep);
    }

// Conitnue adding terms to solution path
    UMatrixSquare    Gram = X.GetMTM() + (UMatrix(Ncol)*Delta);
    if(Gram.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Creating Gram matrix.\n", Ncol);
        return U_ERROR;
    }

    int  maxVariables = GetMaxNVar();
    int  maxSteps     = NStep + 8*maxVariables;
    bool lassoCond    = false;

    UMatrix Mu(DNULL, Nrow, 1); // Might be wrong if Path!=NULL

// While not at OLS solution, early stopping criterion is met, or too many steps have passed 
    while(Nact<maxVariables && NStep < maxSteps)
    {
        UMatrix r = y - Mu;
        UMatrix c = GetMatMul(X, true, r, false);
        
        bool    Fabs = true;
        int     cind = -1;                                    // index of next active variable
        double  cmax = c.GetColMax(0, Fabs, Ipas, &cind);     // Find max correlation in the passive set
        
        if(cind<0)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Finding maximum correlation in step %d.\n", NStep);
            return U_ERROR;
        }
        if(NStep==0 && AddFirstStep(cind)!=U_OK)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Adding first step.\n");
            return U_ERROR;
        }

        if(lassoCond==false)  {Iact[cind] = true; Ipas[cind]=false; Nact++;}     // add variable
        lassoCond     = false;                                                   // if a variable has been dropped, do one step with this configuration (don't add new one right away) 

        UMatrix bOLS  = Gram.GetAxIsB(GetMatMul(X, true, y,false), Iact);        // partial OLS solution and direction from current position to the OLS
        UMatrix d     = GetMatMul(X, bOLS, Iact) - Mu;
        UMatrix b     = (Path==NULL) ? UMatrix() : Path[NStep-1]->GetBeta();
  
        int    dropIndex   = -1;
        double gamma_tilde =  100.;
        for(int k=0; k<Ncol; k++)
        {
            if(k==cind  || Iact[k]==false) continue;
            double bk         = b   .GetElement(k,0);
            double bkO        = bOLS.GetElement(k,0);
            if(bk==bkO) continue;
            double gamma_test = bk/(bk-bkO);
            if(gamma_test<=0.) continue;

            if(dropIndex==-1 || gamma_test<gamma_tilde)
            {
                dropIndex   = k;
                gamma_tilde = gamma_test;
            }
        }

        double gamma = 1.; // if all variables active, go all the way to the OLS solution
        if(Nact<Ncol)  
        {
            UMatrix cd = GetMatMul(X, true, d, false);
            gamma      = -1.;
            for(int k=0; k<Ncol; k++)
            {
                if(Iact[k]==true) continue;
                double ck      = c .GetElement(k,0);
                double cdk     = cd.GetElement(k,0);
                double gamma_m = cdk== cmax ? 0. : (ck-cmax) / (cdk-cmax);
                double gamma_p = cdk==-cmax ? 0. : (ck+cmax) / (cdk+cmax);
                if(gamma_m<=0 && gamma_p<=0)  continue;
                
                double gamma_t = (gamma_m<=0) ? gamma_p : ((gamma_p<=0) ? gamma_m : MIN(gamma_p, gamma_m));
                
                if(gamma==-1 || gamma_t<gamma) gamma = gamma_t;
            }
            if(gamma<=0)
            {
                CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Could not find a positive direction towards the next event. NStep = %d.\n", NStep);
                return U_ERROR;
            }
        }

        if(gamma_tilde < gamma) // check if variable should be dropped
        {
            lassoCond = true;
            gamma     = gamma_tilde;
        }
    
        AddSolutionStep(b + (bOLS-b)*gamma, Iact);
        Mu  += d*gamma;
/////
        ////CI.AddToLog("Nact = %d \n", Nact);
        ////for(int k=0; k<Ncol; k++) CI.AddToLog("%d \t", int(Iact[k])); CI.AddToLog("\n");
        ////UMatrix Dir = Path[NStep-1]->GetBeta();    Dir.Transpose();      Dir.Print(true);
        ////Dir = (bOLS-b);    Dir.NormalizeCols();    Dir.Transpose();      Dir.Print(true);
/////
        bool Break = true;
        if(MinStep) Break &= (NStep>=MinNStep);
        if(MaxLam ) Break &= (Path[NStep-1]->GetLamda1()<=MaxLam1);
        if(Break) break;

// If LASSO condition satisfied, drop variable from active set
        if(lassoCond) {Ipas[dropIndex] = true; Iact[dropIndex] = false; Nact--;}
    }

    if(NStep>=maxSteps)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPathLARS(). Algorithm did not converge in %d steps .\n", NStep);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UElasticNet::ComputeSolutionPath(bool MaxLam, double MaxLam1, bool MinStep, int MinNStep)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Ncol<1 || Nrow<1)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Data matrices not set (Nrow, Ncol) = (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MaxLam==false && MinStep==false)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). No Stopping ciriterium set.\n");
        return U_ERROR;
    }
    if(Path==NULL || Iact==NULL || Ipas==NULL)
    {
        if(InitializePath()!=U_OK)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Initializing path.\n");
            return U_ERROR;
        }
    }
    if(MaxLam)
    {
        if(MaxLam1<0)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Invalid argument, MaxLam1 = %f  .\n", MaxLam1);
            return U_ERROR;
        }
        if(MinStep==false && NStep>0 && Path && Path[NStep-1]->GetLamda1()<=MaxLam1) return U_OK;
    }
    if(MinStep)
    {
        if(MinNStep<=0)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Invalid argument, MinNStep = %d  .\n", MinNStep);
            return U_ERROR;
        }
        if(MaxLam==false && NStep>=MinNStep && Path) return U_OK;
    }
    if(MaxLam&&MinStep)
    {
        if(NStep>=MinNStep && Path && Path[NStep-1]->GetLamda1()<=MaxLam1) return U_OK;
    }

// Conitnue adding terms to solution path
    UMatrixSquare    Gram = X.GetMTM() + (UMatrix(Ncol)*Delta);
    if(Gram.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Creating Gram matrix.\n", Ncol);
        return U_ERROR;
    }
    UMatrix StepDir;
    UMatrix Beta;

    if(Path)
    {
        Nact = 0;
        for(int k=0; k<Ncol; k++) 
        {
            Iact[k] = Path[NStep-1]->IsActive(k); 
            Ipas[k] = NOT(Iact[k]);
            if(Iact[k]) Nact++;
        }
        Beta     = Path[NStep-1]->GetBeta();
        StepDir  = Gram.GetAxIsB(Beta.GetSIGN(), Iact);
    }
    else
    {
        Beta              = UMatrix(DNULL,Ncol, 1);
        UMatrix GradLBeta = GetMatMul(X, true, X*Beta-y, false);
        bool    Fabs = true;
        int     cind = -1;
        double  cmax = GradLBeta.GetColMax(0, Fabs, NULL, &cind);     // Find regressor with max correlation 
        if(AddFirstStep(cind)!=U_OK)
        {
            CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Adding first step.\n");
            return U_ERROR;
        }
        Iact[cind] = true; 
        Ipas[cind] = false; 
        Nact++;

        StepDir = UMatrix(DNULL, Ncol, 1);
        StepDir.SetElement(cind, 0, -SIGN(GradLBeta.GetElement(cind,0)));
    }

    int  maxVariables = GetMaxNVar();
    int  maxSteps     = NStep + 8*maxVariables;
    int  indskippass  = -1;
    while(Nact<maxVariables && NStep<maxSteps)
    {
        int    ind1   = -1;
        int    ind2   = -1;
        double gamma1 = GetMinPosStepPassive(Beta, StepDir, &ind1, indskippass);
        double gamma2 = GetMinPosStepActive(Beta, StepDir, &ind2);

        if(ind1<0 && ind2<0)
        {
            CI.AddToLog("ERROR: UElasticNet::UElasticNet(). Finding active or passive steps at NStep = %d.\n", NStep);
            return U_ERROR;
        }
        if(gamma1<=0 && gamma2<=0)
        {
            CI.AddToLog("ERROR: UElasticNet::UElasticNet(). Finding positive gammas at NStep = %d.\n", NStep);
            return U_ERROR;
        }
        double gamma = gamma1<=0 ? gamma2 : (gamma2<=0. ? gamma1 : MIN(gamma1, gamma2));
        Beta         = Beta + StepDir * gamma;
        AddSolutionStep(Beta, Iact);
/////
        ////CI.AddToLog("Nact = %d \n", Nact);
        ////for(int k=0; k<Ncol; k++) CI.AddToLog("%d \t", int(Iact[k])); CI.AddToLog("\n");
        ////UMatrix Dir = Path[NStep-1]->GetBeta();        Dir.Transpose();      Dir.Print(true);
        ////Dir = StepDir;     Dir.NormalizeCols();        Dir.Transpose();      Dir.Print(true);
/////

        if(gamma==gamma1) { Iact[ind1] = true;  Ipas[ind1] = false;  Nact++; indskippass=-1;  }
        else              { Ipas[ind2] = true;  Iact[ind2] = false;  Nact--; indskippass=ind2;}

        UMatrix GradLBeta = GetMatMul(X, true, X*Beta-y, false);
        StepDir = UMatrix(DNULL, Ncol, 1);
        for(int k=0; k<Ncol; k++) if(Iact[k]) StepDir.SetElement(k, 0, -SIGN(GradLBeta.GetElement(k,0)));
        StepDir = Gram.GetAxIsB(StepDir, Iact);

        bool Break = true;
        if(MinStep) Break &= (NStep>=MinNStep);
        if(MaxLam ) Break &= (Path[NStep-1]->GetLamda1()<=MaxLam1);
        if(Break) break;
    }

    if(NStep>=maxSteps)
    {
        CI.AddToLog("ERROR: UElasticNet::ComputeSolutionPath(). Algorithm did not converge in %d steps .\n", NStep);
        return U_ERROR;
    }
    return U_OK;
}
double UElasticNet::GetMinPosStepPassive(UMatrix& Beta, UMatrix& StepDir, int* ind, int indskippass) const
{
    *ind = -1;
    UMatrix d = X*Beta - y;
    UMatrix e = X*StepDir;

    int iactF = UMatrix::GetFirstSelect(Iact, Ncol);
    if(iactF<0)
    {
        CI.AddToLog("ERROR: UElasticNet::GetMinPosStepPassive(). First active direction not found.\n");
        return -1.;
    }
    double xact_d = GetColProduct(X, iactF, d, 0) + Delta*Beta   .GetElement(iactF,0);
    double xact_e = GetColProduct(X, iactF, e, 0) + Delta*StepDir.GetElement(iactF,0);

    double PosMin = -1.;
    for(int k=0; k<Ncol; k++)
    {
        if(Iact[k]) continue;
        if(k==indskippass) continue;

        double xpas_d = GetColProduct(X, k, d, 0);
        double xpas_e = GetColProduct(X, k, e, 0);

        double TestP = (xpas_e== xact_e) ? -1. : -(xpas_d-xact_d) / (xpas_e-xact_e);
        double TestM = (xpas_e==-xact_e) ? -1. : -(xpas_d+xact_d) / (xpas_e+xact_e);

        if(TestP<=0. && TestM<0.) continue;

        double Test = (TestM<=0) ? TestP : ((TestP<=0) ? TestM : MIN(TestP, TestM));

        if(Test<=0.) continue;
        if(PosMin<0 || Test<PosMin)
        {
            PosMin  = Test;
            *ind    = k;
        }
    }
    return PosMin;
}
double UElasticNet::GetMinPosStepActive(UMatrix& Beta, UMatrix& StepDir, int* ind) const
{
    *ind          = -1;
    double PosMin = -1.;
    for(int k=0; k<Ncol; k++)
    {
        if(Ipas[k]) continue;

        double b    = Beta.GetElement(k);
        double d    = StepDir.GetElement(k);
        if(d   ==0.) continue;
        double Test = -b/d;
        if(Test<=0.) continue;
        if(PosMin<0 || Test<PosMin)
        {
            PosMin  = Test;
            *ind    = k;
        }
    }
    return PosMin;
}

UMatrix UElasticNet::GetBetaMin(double Lam1)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::GetBetaMin(). Object NULL or erroneous  .\n");
        return UMatrix(U_ERROR);
    }
    if(Lam1<0)
    {
        CI.AddToLog("ERROR: UElasticNet::GetBetaMin(). Invalid argument, Lam1 = %f  .\n", Lam1);
        return UMatrix(U_ERROR);
    }
    if(ComputeSolutionPathLam(Lam1)!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::GetBetaMin(). Computing solution path  .\n");
        return UMatrix(U_ERROR);
    }
    UMatrix Beta(DNULL, Ncol, 1);
    if(Lam1 > Path[0]->GetLamda1()) return Beta;

    for(int s=1; s<NStep; s++)
    {
        double L1 = Path[s-1]->GetLamda1();
        double L0 = Path[s  ]->GetLamda1();
        if(Lam1<L0) continue;

        if(L0>=L1) 
        {
            CI.AddToLog("ERROR: UElasticNet::GetBetaMin(). Invalid path (L0=%f, L1=%f) .\n", L0, L1);
            break;
        }
        double S = (Lam1-L1)/(L0-L1);
        return Path[s  ]->GetBeta() * S + Path[s-1]->GetBeta() * (1-S);
    }
    
    if(Path[NStep-1]->GetNActive()!=GetMaxNVar())
        CI.AddToLog("ERROR: UElasticNet::GetBetaMin(). Requested solution not found in path (Lam1=%f) .\n", Lam1);

    return Path[NStep-1]->GetBeta();
}
UPathStep UElasticNet::GetStep(int istep)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::GetStep(). Object NULL or erroneous. \n");
        return UPathStep(U_ERROR);
    }
    if(istep<0)
    {
        CI.AddToLog("ERROR: UElasticNet::GetStep(). Invalid argument: istep = %d. \n", istep);
        return UPathStep(U_ERROR);
    }
    if(ComputeSolutionPathStep(istep+1)!=U_OK)
    {
        CI.AddToLog("ERROR: UElasticNet::GetStep(). Computing solution path until istep+1 = %d. \n", istep+1);
        return UPathStep(U_ERROR);
    }
    if(Path==NULL || istep>=NStep)
    {
        CI.AddToLog("ERROR: UElasticNet::GetStep(). Inconsistent computation solution path until istep+1 = %d. \n", istep+1);
        return UPathStep(U_ERROR);
    }
    return *(Path[istep]);
}
/*****
void UPathStep::SetAllMembersDefault(void)
{
    error     = U_OK;
    Beta      = UMatrix();
    NActive   = 0;
    Lamda1    = 0.;
    ResErr2   = 0.;
    Penal1    = 0.;
}
void UPathStep::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UPathStep::UPathStep()
{
    SetAllMembersDefault();
}
UPathStep::UPathStep(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UPathStep::UPathStep(const UPathStep& PS)
{
    SetAllMembersDefault();
    *this = PS;
}
UPathStep::UPathStep(const UMatrix& X, const UMatrix& y, int FirstActive, double Delta)
{
    SetAllMembersDefault();

    if(X.GetNrow()!= y.GetNrow())
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). X.Nrow (= %d) does not match y.Nrow (=%d) .\n", X.GetNrow());
        return;
    }
    if(y.GetNcol()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). y and Bet must be collumn vectors .\n");
        return;
    }
    if(FirstActive<0 || FirstActive>=X.GetNcol())
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). Invalid index, FirstActive = %d .\n", FirstActive);
        return;
    }

    Beta          = UMatrix(NULL, X.GetNcol(), 1);
    if(Beta.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep:UPathStep(). Copying Beta.\n");
        return;
    }
    Lamda1  = 2*fabs(GetColProduct(X, FirstActive, y, 0));

    ResErr2 = y.GetFrobNorm2();
    Penal1  = 0; 
}

UPathStep::UPathStep(const UMatrix& X, const UMatrix& y, const UMatrix& Bet, const bool* Iact, double Delta)
{
    SetAllMembersDefault();

    if(X.GetNrow()!= y.GetNrow())
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). X.Nrow (= %d) does not match y.Nrow (=%d) .\n", X.GetNrow(), Bet.GetNrow());
        return;
    }
    if(X.GetNcol()!= Bet.GetNrow())
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). X.Ncol (= %d) does not match Bet.Nrow (=%d) .\n", X.GetNcol(), Bet.GetNrow());
        return;
    }
    if(y.GetNcol()!=1 || Bet.GetNcol()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). y and Bet must be collumn vectors .\n");
        return;
    }
    if(Iact==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::UPathStep(). Invalid NULL pointer argument of Iact .\n");
        return;
    }

    Beta          = Bet;
    UMatrix Res   = y - GetMatMul(X, Beta, Iact);
    NActive       = UMatrix::GetNSelect(Iact, Beta.GetNrow());
    if(Beta.GetError()!=U_OK || Res.GetError()!=U_OK || NActive<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep:UPathStep(). Copying Beta, computing residuals or getting active indices (Nrow = %d, Nactive =%d) (>0??).\n", Beta.GetNrow(), NActive);
        return;
    }
    double* LH       = new double[NActive];
    if(LH==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep:UPathStep(). Memory allocation, (NSel = %d).\n", NActive);
        return;
    }
    for(int k=0, is=0; k<Beta.GetNrow(); k++)
    {
        if(Iact[k]==false)  Beta.SetElement(k, 0, 0.);               
        else                LH[is++] = fabs(GetColProduct(X, k, Res, 0) - Delta*Bet.GetElement(k,0));
    }
    Lamda1  = 2*GetMedian(LH, NActive);
    delete[] LH;

    ResErr2 = Res.GetFrobNorm2();
    Penal1  = 0; 
    for(int k=0; k<Beta.GetNrow(); k++) 
    {
        if(Iact[k]==false) continue;
        Penal1 += fabs(Beta.GetElement(k,0));
    }
    Penal1 *= Lamda1;
}
UPathStep::~UPathStep()
{
    DeleteAllMembers(U_OK);
}
UPathStep& UPathStep::operator= (const UPathStep& PS)
{
    if(this==NULL)
    {
        static UPathStep ERROR(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::operator=(). Object NULL.\n");
        return ERROR;
    }
    if(&PS==NULL || PS.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    Beta      = PS.Beta;
    Lamda1    = PS.Lamda1;
    ResErr2   = PS.ResErr2;
    Penal1    = PS.Penal1;
    NActive   = PS.NActive;

    if(Beta.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UPathStep::operator=(). Copying Beta.\n");
        return *this;
    }
    return *this;
}
const UString& UPathStep::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMatrix() object.");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(NActive   , "NActive       = %d \n");
    if(Lamda1>1.e-5) Properties += UString(Lamda1    , "Lamda1        = %f \n");
    else             Properties += UString(Lamda1    , "Lamda1        = %e \n");
    if(ResErr2>1.e-5)Properties += UString(ResErr2   , "ResErr2       = %f \n");
    else             Properties += UString(ResErr2   , "ResErr2       = %e \n");
    if(Penal1>1.e-5) Properties += UString(Penal1    , "Penal1        = %f \n");
    else             Properties += UString(Penal1    , "Penal1        = %e \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

bool UPathStep::IsActive(int icomp) const
{
    if(this==NULL || error!=U_OK) return false;

    if(icomp<0 || icomp>=Beta.GetNrow())
    {
        CI.AddToLog("ERROR: UPathStep::operator=(). Component out of range, icomp = %d .\n", icomp);
        return false;
    }
    return fabs(Beta.GetElement(icomp,0)) > 1.e-14;
}
*****/
