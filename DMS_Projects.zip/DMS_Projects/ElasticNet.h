#ifndef _ELASTICNET_INCLUDED
#define _ELASTICNET_INCLUDED

#include "Matrix.h"

class UPathStep;
class DLL_IO UElasticNet
{
public:
    UElasticNet();                                            // default constructor -> empty matrix
    UElasticNet(ErrorType E);                                 // constructor used to return an empty, Erroneous ElasticNet
    UElasticNet(const UElasticNet& EN);                       // Copy constructor 
    UElasticNet(const UMatrix& A, const UMatrix& b, double delta);

    virtual ~UElasticNet();
    UElasticNet& operator= ( const UElasticNet& EN);

    ErrorType          GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&     GetProperties(UString Comment) const;
    int                GetNStep(void)           const {if(this) return NStep; return 0;}

    ErrorType          ComputeSolutionPathStep(int MinNStep, bool LARS=true);
    ErrorType          ComputeSolutionPathLam(double MaxLam1, bool LARS=true);
    UMatrix            GetBetaMin(double Lam1);
    UPathStep          GetStep(int istep);

protected:   
    void               SetAllMembersDefault(void);
    void               DeleteAllMembers(ErrorType E);

private:
    static UString     Properties;    // General property string.
    ErrorType          error;         // General error flag

    UMatrix            X;
    UMatrix            y;

    int                Nrow;          // Copy of X.Nrow
    int                Ncol;          // Copy of X.Ncol
    int                Nact;          // Number of non-zero beta components
    bool*              Iact;          // Active collumns
    bool*              Ipas;          // Passible collums
    double             Delta;         // L2 penalty factor
    UPathStep**        Path;          // Solution path
    int                NStep;         // Number of path elements
    int                NStepAlloc;    // Number of allocated elements of Path[]

    ErrorType          ComputeSolutionPathLARS(bool MaxLam, double MaxLam1, bool MinStep, int MinNStep);
    ErrorType          ComputeSolutionPath(bool MaxLam, double MaxLam1, bool MinStep, int MinNStep);
    double             GetMinPosStepPassive(UMatrix& Beta, UMatrix& StepDir, int* ind, int indskippass) const;
    double             GetMinPosStepActive(UMatrix& Beta, UMatrix& StepDir, int* ind) const;

    ErrorType          InitializePath();
    ErrorType          AddFirstStep(int FirstActive);
    ErrorType          AddSolutionStep(const UMatrix& Bet, bool* Iact);
    int                GetMaxNVar(void) const {if(this) return (Delta==0.) ? MIN(Ncol,Nrow):Ncol; return -1;}
};

/*****
class  DLL_IO UPathStep
{
public:
    UPathStep();
    UPathStep(ErrorType E);
    UPathStep(const UPathStep& PS);
    UPathStep(const UMatrix& X, const UMatrix& y, int FirstActive, double Delta);
    UPathStep(const UMatrix& X, const UMatrix& y, const UMatrix& Bet, const bool* Iact, double Delta);
    ~UPathStep();
    UPathStep& operator= (const UPathStep& PS);
    ErrorType          GetError(void)           const {if(this) return error ;    return U_ERROR;}
    const UString&     GetProperties(UString Comment) const;
    int                GetNActive(void)         const {if(this) return NActive;   return -1;}
    double             GetLamda1(void)          const {if(this) return Lamda1;    return  0;}
    UMatrix            GetBeta(void)            const {if(this) return Beta;      return UMatrix();}
    bool               IsActive(int icomp)      const;

protected:
    void               SetAllMembersDefault(void);
    void               DeleteAllMembers(ErrorType E);

private:
    static UString     Properties;    // General property string.
    ErrorType          error;
    UMatrix            Beta;          // Parameter parameter estimates at jump
    int                NActive;
    double             Lamda1;
    double             ResErr2;
    double             Penal1;
};
****/

#endif //_ELASTICNET_INCLUDED
