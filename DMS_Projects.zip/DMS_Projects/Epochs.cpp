/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*   Module create and change and UEpochs-object.                                 */
/*                                                                                */
/*   An UEpochs-object contains a list of time segments of a CTF Data Set.        */
/*   The time segments consist of a begin event (UVent-object) and an end         */
/*   event (UEvent-object). Both events refer to a certain trial and sample       */
/*   in the data file.                                                            */
/*   There are different ways to create these epochs.                             */
/*   More advanced ways to create epochs are offered by the UEpochsData()-object. */
/*                                                                                */
/*   Jan de Munck                                                                 */
/*                                                                                */
/**********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    26-11-98   Creation, from spitting ReadMarkers.cpp smaller parts
                    Renamed UEpoch as UEpochs, because this is more consistent.
  JdM    28-12-98   Added more detailed comments
  JdM    03-02-99   Added AreEpochTimesEqual() and GetNsamp()
  JdM    05-03-99   MAJOR UPDATE: The epochs are now based upon UEvent-objects. Therefore,
                    the start and end sample of an epoch can now be located in different trials.
  JdM    04-04-99   Added copy constructor.
  JdM    02-06-99   Added the function GetTotalSamples()
  JdM    01-09-99   BUG Fix in Constructor (int,int,int,int) : write outside array boundaries
  JdM    06-10-00   Added the private parameter nSampTrial, and excluded this parameter from few functions
                    Added IsOverlapping(), MergeOverlapping() and SortEpochs()
  JdM    12-10-00   Added LogProperties()
  JdM    18-12-00   Extend use of SetnEpochs()
  JdM    23-01-01   Added GetIndicator()
  JdM    14-05-01   Added Subsample()
  JdM    23-09-01   Added GetEvent() and GetEventMergedEpochs()
  JdM    14-03-02   Added GetBeginSample()
  JdM    10-07-02   BUG FIX SortEpochs(): When swapping Begin[], simultaneously swap End[]
  JdM    28-08-02   Support an optional text string array (EpOri[]) containing the description of each epoch
                    Add: SetOriginText() and DeleteEpoch()
  JdM    02-09-02   Bug Fix: copy constructor. Allocating bytes for Orig
  JdM    10-10-02   Major Update: Use embedded object UEpoch instead of three parallel arrays Begin[] End[] and Origin[]
  JdM    14-10-02   Add CopyEpoch() and functions to manipulate class indices
  JdM    20-10-02   Add SetEpoch(), IsMarkerIsInDescriptor() and GetNMarkerIsInDescriptor()
  FB     11-12-02   Bug fix: IsMarkerIsInDescriptor(). Added +1, after strlen(MarkerName)
  JdM    22-11-03   Major Update, added history string, and copied functionality from UEpochs data.
  JdM    05-12-03   Added IsInEpoch()
  JdM    10-02-04   Bug fix operator=(). Allocating memory for History must be consistent with Nhistory
  JdM    22-06-04   Added IsInAnyEpoch() and GetEpochIndex()
  JdM    27-08-04   Allow for multiple names, separated by ';' in one of the constructors (using markernames and offsets)
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    06-11-04   Added GetEventsPerEpochAsField()
  JdM    20-10-05   Added AreEpochsContiguous()
  JdM    26-10-05   Bug fix: AreEpochsContiguous()
  JdM    24-11-05   Added another IsInEpoch()
  JdM    01-12-05   Added GetFirstEpoch() and GetLastEpoch()
  JdM    14-12-05   Initialize Properties[] string in all constructors
  JdM    24-01-06   Added new constuctor, based on single marker
  JdM    16-02-06   Added ConvertGraphToMarkers()
  JdM    25-02-06   Added ExcludeEpochs()
  JdM    19-03-06   Bug fix ExcludeEpochs(): calling RemoveEpochs() (meaning of last par.)
  JdM    19-03-06   Bug fix ExcludeEpochs(): calling RemoveEpochs() (meaning of last par.)
  JdM    08-06-06   History string is UString object
  JdM    26-11-06   Replace GetEventsPerEpochAsField() by GetEventsPerEpochAsFieldGraph()
  JdM    08-03-08   Added operator==() and other IsOverlapping()
  JdM    09-03-08   Added new constructor, based on arrays of abs. begin/end samples
  JdM    16-03-08   Bug Fix: AreEpochsContiguous(). Test GetNsamples()==2 (i.s.o. ==1)
  JdM    23-05-08   Use of UString in Descriptor
  JdM    23-05-08   GetEventsPerEpochAsFieldGraph() added NSegment parameter
  JdM    28-05-08   Bug Fix: GetEventsPerEpochAsFieldGraph(), shifting event
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
                    Use UString for Properties and EpochName
  JdM    24-10-08   Added UFieldGraph* constructor
  JdM    12-02-10   Systematically test this==NULL
  JdM    12-08-12   Added new copy constructor, with NewNsampTrial-argument
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    09-04-15   Added DoEpochsHaveGaps()
                    Slightly updated AreEpochsContiguous()
  JdM    07-04-16   Added GetFirstBegin() and  GetLastEnd()
                    AreEpochsCintigeous(): added tolerance parameter, bool AllowOneSampleSkipped
*/

#include<string.h>
#include<stdlib.h>
#include<math.h>

#include "Epochs.h"
#include "MarkerArray.h"
#include "Field.h"
#include "FieldGraph.h"
#include "AnalyzeLine.h"
#include "String.h"


/* Inititalize static const parameters. */
UString UEpochs::Properties = UString();

static int SortEvent(const void *elem1, const void *elem2)
{
    UEpochs::UEpoch* E1 = (UEpochs::UEpoch*)elem1;
    UEpochs::UEpoch* E2 = (UEpochs::UEpoch*)elem2;

    if(E1->GetBegin().trial < E2->GetBegin().trial) return -1; // First sort on begin trial
    if(E1->GetBegin().trial > E2->GetBegin().trial) return  1;

    if(E1->GetBegin().sample < E2->GetBegin().sample) return -1; // Then sort on begin sample
    if(E1->GetBegin().sample > E2->GetBegin().sample) return  1;

    return 0;
}

void UEpochs::SetAllMembersDefault(void)
{
    error        = U_OK;
    Properties   = UString();
    History      = UString();
    EpochName    = UString();
    nEpochs      = 0;
    nEpochsAlloc = 0;
    Ep           = NULL;
    nSampTrial   = 0;
}

void UEpochs::DeleteAllMembers(ErrorType E)
{
    delete[] Ep;
    SetAllMembersDefault();
    error = E;
}


UEpochs::UEpochs()
/*
    Default constructor.
 */
{
    SetAllMembersDefault();
    error = AddToHistory("Hist. Default constructor.\n");
}

UEpochs::UEpochs(const char *name, int nEp, int NsampPTrial)
/*
    Create nEp epochs with empty (or nonsense) contents)
 */
{
    SetAllMembersDefault();

    if(nEp<=0 || NsampPTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid arguments. nEp=%d, NsampPTrial = %d  .\n", nEp, NsampPTrial);
        return;
    }

    Ep = new UEpoch[nEp];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEp=%d\n", nEp);
        return;
    }

    if(name)  EpochName = UString(name);
    else      EpochName = UString("NONAME");

    nEpochs      = nEp;
    nEpochsAlloc = nEp;
    nSampTrial   = NsampPTrial;

    UString H(nEp,"Hist. Constructor with %d empty epochs");
    error        = AddToHistory(H);
}

UEpochs::UEpochs(const unsigned char* Indicator, int NsampPTrial, int Ntrial, const char* Name)
{
    SetAllMembersDefault();

    if(Indicator==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). NULL argument.\n");
        return;
    }
    if(NsampPTrial<=0 || Ntrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Arguments out of range: (NsampPTrial,Ntrial) =  (%d,%d)\n", NsampPTrial, Ntrial);
        return;
    }

/* Count the epochs*/
    nEpochs    = 0;
    if(Indicator[0]) nEpochs=1;
    int k = 1;
    for(     ; k<NsampPTrial*Ntrial; k++)
        if(!Indicator[k-1] && Indicator[k])  nEpochs++;

/* Allocate memory*/
    Ep = new UEpoch[nEpochs];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", nEpochs);
        return;
    }

/* Fill the edge events*/
    int iep=0;
    if(Indicator[0]) Ep[iep++].SetBegin(UEvent(0,0));
    for(k=1; k<NsampPTrial*Ntrial-1; k++)
    {
        if( Indicator[k  ] && !Indicator[k+1]) Ep[iep-1].SetEnd  (UEvent(k/NsampPTrial, k%NsampPTrial));
        if(!Indicator[k-1] &&  Indicator[k  ]) Ep[iep++].SetBegin(UEvent(k/NsampPTrial, k%NsampPTrial));
    }
    if(Indicator[NsampPTrial*Ntrial-1])
        Ep[iep-1].SetEnd( UEvent((NsampPTrial*Ntrial-1)/NsampPTrial, (NsampPTrial*Ntrial-1)%NsampPTrial));

    if(Name)   EpochName = UString(Name);
    else       EpochName = UString("Indicator");

    nEpochsAlloc = nEpochs;
    nSampTrial   = NsampPTrial;

    error        = AddToHistory("Hist. Constructor using indicator.");
}

UEpochs::UEpochs(const int* BeginSamp, const int* EndSamp, int Nep, int NSampPTrial, const char* Name)
{
    SetAllMembersDefault();
    if(BeginSamp==NULL || EndSamp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid NULL argument(s).\n");
        return;
    }
    if(Nep<=0 || NSampPTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid argument(s): Nep=%d NSampPTrial=%d  .\n", Nep, NSampPTrial);
        return;
    }
/* Allocate memory*/
    Ep = new UEpoch[Nep];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", Nep);
        return;
    }

    nEpochs      = Nep;
    nEpochsAlloc = Nep;
    nSampTrial   = NSampPTrial;

    for(int iep=0; iep<nEpochs; iep++)
    {
        UEvent B(BeginSamp[iep]/nSampTrial, BeginSamp[iep]%nSampTrial);
        UEvent E(  EndSamp[iep]/nSampTrial,   EndSamp[iep]%nSampTrial);

        Ep[iep].SetBegin(B);
        Ep[iep].SetEnd  (E);
    }
    if(Name)   EpochName = UString(Name);
    else       EpochName = UString("AbsSampArr");

    error = AddToHistory("Hist. Constructor arrays of absolute samples.");
}

UEpochs::UEpochs(const UEpochs& eps)
{
    SetAllMembersDefault();
    *this = eps;
}
UEpochs::UEpochs(const UEpochs& eps, int NewNsampTrial)
{
    SetAllMembersDefault();
    if(NewNsampTrial<=0)
    {
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid argument,  NewNsampTrial = %d .\n", NewNsampTrial);
        error = U_ERROR;
        return;
    }
    *this = eps;
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid argument,  Copying eps.\n");
        return;
    }
    for(int iep=0; iep<nEpochs; iep++)
    {
        int iabsB = GetBeginSample(iep);
        int iabsE = GetEndSample(iep);
        
        Ep[iep].SetBegin( UEvent(iabsB/NewNsampTrial, iabsB%NewNsampTrial) );
        Ep[iep].SetEnd  ( UEvent(iabsE/NewNsampTrial, iabsE%NewNsampTrial) );
    }
    nSampTrial = NewNsampTrial;
}

UEpochs::UEpochs(int starttrial, int endtrial, int startsample, int endsample, int NsampPTrial)
/*
    Create epochs by taking a fixed interval on a selected range of trials.
 */
{
    SetAllMembersDefault();

    if(starttrial<0  || endtrial<0  ||  starttrial>endtrial ||
       startsample<0 || endsample<0 || startsample>endsample)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid arguments: starttrial=%d, endtrial=%d, startsample=%d, endsample=%d . \n", starttrial, endtrial, startsample, endsample);
        return;
    }

    nEpochs    = endtrial-starttrial+1;
    Ep         = new UEpoch[nEpochs];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", nEpochs);
        return;
    }

    for(int tr=starttrial,k=0; tr<=endtrial; tr++,k++)
        Ep[k] = UEpoch(UEvent(tr,startsample), UEvent(tr,endsample), NULL, 0);

    EpochName = UString(starttrial ,"Tr%d-")  + UString(endtrial   ,"%d,")
              + UString(startsample,"s%d-")   + UString(endsample  ,"%d");

    nEpochsAlloc = nEpochs;
    nSampTrial   = NsampPTrial;

    char line[200];
    sprintf(line,"//   Hist. Constructor using all samples (%d-%d) from trials (%d,%d). \n", startsample,endsample,starttrial,endtrial);

    UString H = UString(startsample,endsample, "Hist. Constructor using all samples (%d-%d) ")
              + UString(starttrial ,endtrial , "from trials (%d-%d).");
    error     = AddToHistory(H);
}

UEpochs::UEpochs(int BeginOffset, int EndOffset, const UMarker* M)
{
    SetAllMembersDefault();

    if(BeginOffset>EndOffset)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs(). startsample after end sample (%d, %d)\n", BeginOffset, EndOffset);
        return;
    }

    if(M==NULL || M->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Marker object not set.\n");
        return;
    }
    nSampTrial = M->GetnSampTrial();
    if(nSampTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid number of samples per trial (%d).\n", nSampTrial);
        return;
    }
    if(M->GetnSamples()<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). No events present in marker. \n", M->GetMarkerName());
        return;
    }
    nEpochs      = M->GetnSamples();
    nEpochsAlloc = nEpochs;
    Ep           = new UEpoch[nEpochsAlloc];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochsAlloc=%d\n", nEpochsAlloc);
        return;
    }

/* Fill the Epochs()-object*/
    for(int i=0; i<nEpochs; i++)
    {
        UEvent Ev    = M->GetEvent(i);
        UEvent Begin = Ev.GetShiftedEvent(BeginOffset, nSampTrial);
        UEvent End   = Ev.GetShiftedEvent(EndOffset,   nSampTrial);

        UString Descriptor;
        Descriptor += UString(M->GetMarkerName(),"MARKER=%s ");
        Descriptor += UString(Ev.trial,"\tEvent=(%d");
        Descriptor += UString(Ev.sample,",%d)");
        SetEpoch(i, Begin, End, 0, (const char*)Descriptor);
    }

    EpochName = UString(M->GetMarkerName());
    UString H = UString("Hist.  markers named ") + UString(M->GetMarkerName())
              + UString(BeginOffset, EndOffset, ", which are shifted by %d and %d samples.");
    error     = AddToHistory(H);
}

UEpochs::UEpochs(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername)
{
    SetAllMembersDefault();

    if(BeginOffset>EndOffset)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs(). startsample after end sample (%d, %d)\n", BeginOffset, EndOffset);
        return;
    }

    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Data or Marker object not set.\n");
        return;
    }
    nSampTrial = Mar->GetnSampTrial();
    if(nSampTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid number of samples per trial (%d).\n", nSampTrial);
        return;
    }

/*Test for multiple names.*/
    int    Nnames = 0;
    char** Names  = NULL;
    if(::GetNamesFromString(markername, 0, &Nnames, &Names) !=U_OK || Nnames<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Analyzing string: %s \n", markername);
        return;
    }

/*Count number of markers within the specified range.*/
    int nTotalSamp = 0;
    for(int k=0; k<Nnames; k++)
        nTotalSamp += Mar->GetnTotalSamples(Names[k]);

    if(nTotalSamp<=0)
    {
        DeleteAllMembers(U_ERROR);

        if(Names) {for(int k=0; k<Nnames; k++) delete[] Names[k];} delete[] Names;
        if(!markername || markername[0]==0)
            CI.AddToLog("ERROR: UEpochs::UEpochs(). No markers are present. \n");
        else
            CI.AddToLog("ERROR: UEpochs::UEpochs(). No markers named %s are present. \n", markername);
        return;
    }

/* Allocate the memory */
    Ep  = new UEpoch[nTotalSamp];
    if(Ep==NULL)
    {
        if(Names) {for(int k=0; k<Nnames; k++) delete[] Names[k];} delete[] Names;

        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEp=%d\n", nTotalSamp);
        return;
    }
    nEpochsAlloc = nTotalSamp;

/* Fill the Epochs()-object*/
    int MarkerClass = 0;
    nEpochs         = 0;
    for(int kk=0; kk<Nnames; kk++)
    {
        for(int n=0; n<Mar->GetnMarkers(); n++)
        {
            const UMarker* Marker = Mar->GetMarker(n);
            if(Marker==NULL)
            {
                CI.AddToLog("WARNING: UEpochs::UEpochs(). NULL Marker in UMarkerArray(), n=%d .\n", n);
                continue;
            }
            if(Mar->IsNameEquivalent(n, Names[kk])==false) continue;

            for(int i=0; i<Marker->GetnSamples(); i++)
            {
                UEvent Ev    = Marker->GetEvent(i);
                UEvent Begin = Ev.GetShiftedEvent(BeginOffset, nSampTrial);
                UEvent End   = Ev.GetShiftedEvent(EndOffset,   nSampTrial);

                UString Descriptor;
                Descriptor += UString(Marker->GetMarkerName(), "MARKER=%s ");
                Descriptor += UString(Ev.trial               , "Event=(%d");
                Descriptor += UString(Ev.sample              , ",%d)");
                SetEpoch(nEpochs++, Begin, End, MarkerClass, (const char*)Descriptor);
            }
            MarkerClass++;
        }
    }
    if(Names) {for(int k=0; k<Nnames; k++) delete[] Names[k];} delete[] Names;

    if(markername)  EpochName = UString(markername);
    else            EpochName = UString("NONAME");

    UString H;
    if(markername)
    {
        H = UString("Hist. Constructor using markers named ") + UString(markername)
          + UString(BeginOffset, EndOffset, ", which are shifted by %d and %d samples. \n");
    }
    else
    {
        H = UString("Hist. Constructor using all markers")
          + UString(BeginOffset, EndOffset, ", which are shifted by %d and %d samples. \n");
    }
    error = AddToHistory(H);
}

UEpochs::UEpochs(const UMarkerArray* Mar, const char* BEName)
/*
    Create epochs by looking for pairs of BEGIN and END markers in the marker-file. BEGIN
    and END markers are markers whose name start with "Begin" and "End" (case insensitive,
    see UCTFDataMarker::GetEpochs()).
    Only markers located between starttrial and endtrial are considered.
*/
{
    SetAllMembersDefault();

/* Test arguments */
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Data or Marker object not set.\n");
        return;
    }
    nSampTrial = Mar->GetnSampTrial();
    if(nSampTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid number of samples per trial (%d).\n", nSampTrial);
        return;
    }

/* Look for the begin marker*/
    const UMarker* Mbegin = Mar->GetBeginMarker(BEName);
    const UMarker* Mend   = Mar->GetEndMarker(BEName);

    if(Mbegin==NULL || Mend==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Cannot find begin or end markers compatible to %s \n", BEName);
        return;
    }

/*Count the begin- and end- markers*/
    int nBegin = Mbegin->GetnSamples();
    int nEnd   = Mend->GetnSamples();
    if(nBegin!=nEnd || nBegin==0)
    {
        DeleteAllMembers(U_ERROR);
        if(BEName && BEName[0])
        {
            CI.AddToLog("ERROR: UEpochs::UEpochs(). Different number (or zero) of begin (%d) and end markers (%d) ",nBegin,nEnd);
            CI.AddToLog("of name %s. \n",BEName);
        }
        else
            CI.AddToLog("ERROR: UEpochs::UEpochs(). Different number (or zero) of begin (%d) and end markers (%d). \n",nBegin,nEnd);

        CI.AddToLog("ERROR: UEpochs::UEpochs(). No Begin markers = %d, No End markers is %d. \n",nBegin, nEnd);
        return;
    }

    Ep  = new UEpoch[nBegin];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEp=%d\n", nBegin);
        return;
    }
    nEpochsAlloc = nBegin;

/* Fill the Epochs()-object*/
    nEpochs = 0;
    for(int n=0; n<nBegin; n++)
    {
        UEvent Begin = Mbegin->GetEvent(n);
        UEvent End   = Mend  ->GetEvent(n);

        if(GetNsamples(Begin, End, nSampTrial)<0)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEpochs::UEpochs(). Begin marker located after end marker. \n");
            return;
        }
        SetBegin(nEpochs, Begin);
        SetEnd  (nEpochs, End);
        nEpochs++;
    }

    CI.AddToLog("Note: UEpochs::UEpochs(). Epochs created succesfully! \n");

    UString H;
    if(BEName)
    {
        H = UString("Hist. Constructor using begin/end markers compatible to ") + UString(BEName);
    }
    else
    {
        H = UString("Hist. Hist. Constructor using all begin/end markers.");
    }
    error = AddToHistory(H);
}

UEpochs::UEpochs(int Npieces, int Ntrial, int NsampTr, bool ForcePower2, bool IgnoreTrialBounds)
/*
     Create epochs by dividing each of Ntrial trials into (approximately) Npieces
     non-overlapping pieces. The number of samples per trial is NsampTr.

     If(ForcePower2      ==true) the size of the non-overlapping pieces will be forced to be a power of two.
     If(IgnoreTrialBounds==true) the trial boundaries will be ignored during subdivsion of the trials.
 */
{
    SetAllMembersDefault();

/* Test arguments */
    if(Npieces<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Erroneous number of data pieces (Npieces=%d). \n",Npieces);
        return;
    }
    if(Ntrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Erroneous number of trials (Ntrial=%d) . \n",Ntrial);
        return;
    }
    if(NsampTr<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Erroneous number of samples per trial (NsampTr=%d)  .\n",NsampTr);
        return;
    }

    int size = NsampTr/Npieces;
    if(ForcePower2==true)
    {
        int nlarge = 1<<(int) ceil( log((double)size)/log(2.) );
        if(abs(nlarge/2-size)<abs(nlarge-size)) size = nlarge/2;
        else                                    size = nlarge;
    }
    if(size==0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Too many data pieces (Npieces=%d, NsampTr=%d)\n",Npieces, NsampTr);
        return;
    }

    int nEp = 0;
    if(IgnoreTrialBounds==true)  nEp = ( Ntrial *  NsampTr )/size;
    else                         nEp =   Ntrial *( NsampTr  /size);

    Ep  = new UEpoch[nEp];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEp=%d\n", nEp);
        return;
    }
    nEpochsAlloc = nEp;
    nEpochs      = nEp;
    nSampTrial   = NsampTr;

    if(IgnoreTrialBounds==true)
    {
        for(int k=0; k<nEp; k++)
        {
            int EpAbs = k*size;
            SetBegin(k, UEvent(EpAbs/nSampTrial, EpAbs%nSampTrial));

            EpAbs    += size-1;
            SetEnd(k, UEvent(EpAbs/nSampTrial, EpAbs%nSampTrial));
        }
    }
    else
    {
        for(int it=0,k=0; it<Ntrial; it++)
        {
            for(int is=size; is<=nSampTrial; is+=size,k++)
            {
                SetBegin(k, UEvent(it, is-size));
                SetEnd  (k, UEvent(it, is-1));
            }
        }
    }

    EpochName = UString("SubdivideTrials");

    UString H;
    if(IgnoreTrialBounds==true)
    {
        H = UString(size, "Hist. Constructor using a subdivision of all trials in new trial of % samples (ignoring trial boundaries).");
    }
    else
    {
        H = UString(Npieces," Hist. Constructor using a subdivision of each trial into % pieces.");
    }
    error = AddToHistory(H);
}

UEpochs::UEpochs(int NsampSkip, int NewTrialLen, int startsample, int endsample, int NsampPTrial, int Ntrial)
/*
    Create epochs from a data set of Ntrial trial of NsampPTrial samples per trial.
    Skip the first NsampSkip samples, and take of each subsequent "trial" of
    NewTrialLen samples, only the samples from startsample to endsample.
 */
{
    SetAllMembersDefault();

    if(NewTrialLen<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Invalid trial length parameter: %d \n", NewTrialLen);
        return;
    }
    if(startsample>endsample)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Invalid start and endsample: %d, %d \n", startsample, endsample);
        return;
    }
    if(endsample-startsample+1>NewTrialLen)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Invalid start and endsample: %d, %d, NewTrialLen=%d  . \n", startsample, endsample, NewTrialLen);
        return;
    }
    if(NsampPTrial<=0 || Ntrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Invalid trial parameters: NsampPTrial=%d, Ntrial=%d \n", NsampPTrial, Ntrial);
        return;
    }

    NsampSkip      = MAX(0, NsampSkip);
    int ntotalsamp = NsampPTrial * Ntrial;
    nEpochs        = (ntotalsamp-NsampSkip)/NewTrialLen;
    if(nEpochs<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Too few samples. ntotalsamp = %d, NsampSkip = %d, NewTrialLen=%d \n", ntotalsamp, NsampSkip, NewTrialLen);
        return;
    }

    Ep  = new UEpoch[nEpochs];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", nEpochs);
        return;
    }
    nEpochsAlloc = nEpochs;
    nSampTrial   = NsampPTrial;

    for(int n=0; n<nEpochs; n++)
    {
        UEvent B, E;
        B.trial  = (NsampSkip + n*NewTrialLen + startsample) / NsampPTrial;
        B.sample = (NsampSkip + n*NewTrialLen + startsample) % NsampPTrial;
        E.trial  = (NsampSkip + n*NewTrialLen + endsample)   / NsampPTrial;
        E.sample = (NsampSkip + n*NewTrialLen + endsample)   % NsampPTrial;
        SetBegin(n, B);
        SetEnd(n, E);
    }

    EpochName = UString("NewTrials");

    UString H = UString(NsampSkip, NewTrialLen, "Hist. Constructor using new trials (NsampSkip=%d, NewTrialLen=%d)")
              + UString(startsample, endsample, ", of which a subset (%d-%d) is taken.");
    error     = AddToHistory(H);
}

UEpochs::UEpochs(int EpochLen, int EpochShift, int NsampPTrial, int Ntrial)
{
    SetAllMembersDefault();

    if(EpochLen<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs(). Invalid epoch length parameter: %d \n", EpochLen);
        return;
    }
    if(EpochShift<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs(). Invalid epoch shift parameter: %d \n", EpochShift);
        return;
    }
    if(NsampPTrial<=0 || Ntrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Invalid trial parameters: NsampPTrial=%d, Ntrial=%d \n", NsampPTrial, Ntrial);
        return;
    }

    int ntotalsamp = NsampPTrial * Ntrial;
    nEpochs        = (ntotalsamp-EpochLen)/EpochShift;
    if(nEpochs<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UEpochs::UEpochs() : Too few samples. ntotalsamp = %d, EpochLen = %d, EpochShift = %d . \n", ntotalsamp, EpochLen, EpochShift);
        return;
    }

    Ep = new UEpoch[nEpochs];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", nEpochs);
        return;
    }
    nEpochsAlloc = nEpochs;
    nSampTrial   = NsampPTrial;

    for(int n=0; n<nEpochs; n++)
    {
        UEvent B, E;
        B.trial  = (n*EpochShift             ) / NsampPTrial;
        B.sample = (n*EpochShift             ) % NsampPTrial;
        E.trial  = (n*EpochShift + EpochLen-1) / NsampPTrial;
        E.sample = (n*EpochShift + EpochLen-1) % NsampPTrial;
        SetBegin(n, B);
        SetEnd(n, E);
    }

    EpochName = UString("ShiftedEpoch");

    UString H(EpochLen, EpochShift,"Hist. Constructor a shifting window of %d samples, shifted %d samples, each time.");
    error = AddToHistory(H);
}

UEpochs::UEpochs(const UFieldGraph* FG, double Level, double Stime, int NsampPTrial)
{
    SetAllMembersDefault();

    if(FG==NULL || FG->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). NULL or erroneous UFieldGraph argument.\n");
        return;
    }
    if((FG->GetFType()!=UField::U_UNIFORM && FG->GetFType()!=UField::U_RECTILINEAR) ||
        FG->Getndim()!=1 || FG->GetNpoints()<1 || FG->GetVeclen()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). UFieldGraph argument of wrong type (%s).\n", FG->GetProperties(""));
        return;
    }
    if(Stime<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid sample time (Stime = %f). \n", Stime);
        return;
    }
    if(NsampPTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Invalid NsampPTrial (= %d). \n", NsampPTrial);
        return;
    }
    nSampTrial   = NsampPTrial;
    nEpochsAlloc = FG->GetNpoints();
    Ep           = new UEpoch[nEpochsAlloc];
    if(Ep==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", nEpochsAlloc);
        return;
    }

/* Count the epochs*/
    int NSampEp = int(0.5 + FG->GetPixelSize(0)/Stime);
    nEpochs     =  0;
    int  NCat   =  0;
    int  jbAcc  = -1;
    for(int k=0; k<nEpochsAlloc; k++)
    {
        if(FG->GetCoord(0, k)<0.) continue;

        bool Accept = false;
        switch(FG->GetDType())
        {
        case UField::U_BYTE   :   if(FG->GetBdata()[k]>=Level) Accept=true; break;
        case UField::U_SHORT  :   if(FG->GetSdata()[k]>=Level) Accept=true; break;
        case UField::U_INTEGER:   if(FG->GetIdata()[k]>=Level) Accept=true; break;
        case UField::U_FLOAT  :   if(FG->GetFdata()[k]>=Level) Accept=true; break;
        case UField::U_DOUBLE :   if(FG->GetDdata()[k]>=Level) Accept=true; break;
        }
        if(Accept==false || k==nEpochsAlloc-1)
        {
            if(Accept==true)
            {
                if(jbAcc<0) jbAcc = int(FG->GetCoord(0, k)/Stime);
                NCat++;
            }
            if(NCat>0)
            {
                int        jb     = int(FG->GetCoord(0, k)/Stime);
                int        jeAcc  = jb+NSampEp-1;
                UEvent     B      = UEvent(jbAcc/nSampTrial, jbAcc%nSampTrial);
                UEvent     E      = UEvent(jeAcc/nSampTrial, jeAcc%nSampTrial);
                UString    S      = UString(k, "Point_%d");
                Ep[nEpochs++]     = UEpoch(B, E, -1, S);
                NCat              = 0;
                jbAcc             =-1;
            }
        }
        else
        {
            if(jbAcc<0) jbAcc = int(FG->GetCoord(0, k)/Stime);
            NCat++;
        }

    }
    ReAllocateMemory();

    int MinEpLen = Ep[0].GetNsamples(nSampTrial);
    for(int k=0; k<nEpochs; k++)
    {
        int Len = Ep[k].GetNsamples(nSampTrial);
        if(Len<MinEpLen) MinEpLen = Len;
    }
    for(int k=0; k<nEpochs; k++)
    {
        UEvent E = Ep[k].GetBegin().GetShiftedEvent(MinEpLen, nSampTrial);
        Ep[k].SetEnd(E);
    }

    EpochName = FG->GetName();
    UString H = UString("His.  FieldGraph = ")+FG->GetName()+UString(Level," Level = %f ");
    error     = AddToHistory(H);
}

UEpochs::~UEpochs()
{
    DeleteAllMembers(U_OK);
}

UEpochs& UEpochs::operator=(const UEpochs &eps)
{
    if(this==NULL)
    {
        static UEpochs E; E.error = U_ERROR;
        CI.AddToLog("ERROR: UEpochs::operator=(). this == NULL\n");
        return E;
    }
    if(&eps==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEpochs::operator=(). In valid NULL address\n");
        return *this;
    }
    if(this==&eps) return *this;

    DeleteAllMembers(U_OK);

    nEpochs      = eps.nEpochs;
    nEpochsAlloc = eps.nEpochsAlloc;
    nSampTrial   = eps.nSampTrial;
    History      = eps.History;
    EpochName    = eps.EpochName;

    if(eps.Ep)
    {
        Ep  = new UEpoch[eps.nEpochsAlloc];
        if(Ep)
        {
            for(int k=0; k<eps.nEpochs; k++) Ep[k] = eps.Ep[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UEpochs::UEpochs(). Memory allocation. nEpochs=%d\n", eps.nEpochs);
            return *this;
        }
    }
    return *this;
}

bool UEpochs::operator==(const UEpochs &eps) const
{
    if(this==&eps) return true;
    if(this==NULL || &eps==NULL) return false;

    if(error      !=eps.error     ) return false;
    if(nEpochs    !=eps.nEpochs   ) return false;
    if(nSampTrial !=eps.nSampTrial) return false;

    if(Ep==NULL   && eps.Ep!=NULL ) return false;
    if(Ep!=NULL   && eps.Ep==NULL ) return false;
    if(Ep==NULL   && eps.Ep==NULL ) return true;

    for(int iep=0; iep<nEpochs; iep++)
    {
        if(Ep[iep].GetBegin() != eps.Ep[iep].GetBegin()) return false;
        if(Ep[iep].GetEnd()   != eps.Ep[iep].GetEnd()  ) return false;
    }
    return true;
}

const UString& UEpochs::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UEpochs-object");
        return Properties;
    }
    Properties  = UString((const char*)EpochName, " EpochsName = %s \n")
                + UString(nEpochs,                " nEpochs    = %d \n")
                + UString(                        " First Epochs:   \n");
    for(int n=0; n<MIN(nEpochs, 10); n++)
    {
        UEvent B = Ep[n].GetBegin();
        UEvent E = Ep[n].GetEnd();

        Properties += UString(n,"Epoch %d  :  ")
                    + UString(B.trial,"Begin(%d,") + UString(B.sample,"%d)  to ")
                    + UString(E.trial,"End(%d,")   + UString(E.sample,"%d)");
        if(Ep[n].GetDescriptor()) Properties += UString(Ep[n].GetDescriptor());
        Properties += UString("  \n");
    }

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

const char* UEpochs::GetHistory(void) const
{
    if(History) return (const char*)History;
    return "//   Hist. No History recorded. \n";
}

UEvent UEpochs::GetFirstBegin(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstBegin(). Object NULL or erroneous. \n");
        return UEvent();
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstBegin(). Epochs not set. \n");
        return UEvent();
    }

    int iepFB = 0;
    int AbsFB = Ep[0].GetBegin().GetAbsSample(nSampTrial);

    for(int iep=1; iep<nEpochs; iep++)
    {
        int itest = Ep[iep].GetBegin().GetAbsSample(nSampTrial);
        if(itest>AbsFB) continue;
        iepFB = iep;
        AbsFB = itest;
    }
    return Ep[iepFB].GetBegin();
}
UEvent UEpochs::GetLastEnd(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetLastEnd(). Object NULL or erroneous. \n");
        return UEvent();
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetLastEnd(). Epochs not set. \n");
        return UEvent();
    }

    int iepLE = 0;
    int AbsLE = Ep[0].GetEnd().GetAbsSample(nSampTrial);

    for(int iep=1; iep<nEpochs; iep++)
    {
        int itest = Ep[iep].GetEnd().GetAbsSample(nSampTrial);
        if(itest<AbsLE) continue;
        iepLE = iep;
        AbsLE = itest;
    }
    return Ep[iepLE].GetEnd();
}

int UEpochs::GetnEpochs(int ClassIndex)  const
/*
   return the number of epoohs with class index ClassIndex.
   if(ClassIndex<0) return the total number of epochs
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetnEpochs(). Object NULL or erroneous. \n");
        return 0;
    }
    if(ClassIndex<0) return nEpochs;
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetnEpochs(). Epochs not set. \n");
        return 0;
    }
    int N = 0;
    for(int iep=0; iep<nEpochs; iep++)
        if(Ep[iep].GetClassIndex()==ClassIndex) N++;

    return N;
}

int UEpochs::GetTotalSamples(int ClassIndex)  const
/*
    Return the total number of samples, counted over all epochs with class index ClassIndex.
    if(ClassIndex<0) return the total number of samples;
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetTotalSamples(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetTotalSamples(). Epochs not set. \n");
        return 0;
    }
    int nTot = 0;
    for(int iep=0; iep<nEpochs; iep++)
    {
        if(ClassIndex<0 || Ep[iep].GetClassIndex()==ClassIndex)
            nTot += Ep[iep].GetNsamples(nSampTrial);
    }
    return nTot;
}

UEvent UEpochs::GetBegin(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetBegin(). Object NULL or erroneous. \n");
        return UEvent(-1,-1);
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetBegin(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return UEvent(-1,-1);
    }
    return Ep[iep].GetBegin();
}

UEvent UEpochs::GetEnd(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEnd(). Object NULL or erroneous. \n");
        return UEvent(-1,-1);
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetEnd(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return UEvent(-1,-1);
    }
    return Ep[iep].GetEnd();
}

int UEpochs::GetBeginSample(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetBeginSample(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetBeginSample(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return 0;
    }
    return Ep[iep].GetBegin().GetAbsSample(nSampTrial);
}

int UEpochs::GetEndSample(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEndSample(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetEndSample(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return 0;
    }
    return Ep[iep].GetEnd().GetAbsSample(nSampTrial);
}

int UEpochs::GetMidSample(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetMidSample(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetMidSample(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return 0;
    }
    return (GetBeginSample(iep)+GetEndSample(iep)+1)/2;
}

int  UEpochs::GetNsamp(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetNsamp(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetNsamp(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return 0;
    }
    return Ep[iep].GetNsamples(nSampTrial);
}

int UEpochs::GetFirstEpoch(bool Begin) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstEpoch(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || nEpochs<=0)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstEpoch(). Epochs not set, or nEpochs=%d.\n", nEpochs);
        return 0;
    }
    int iep = 0;
    if(Begin==true)
    {
        int isamp = GetBeginSample(iep);
        for(int k=1; k<nEpochs; k++)
        {
            if(GetBeginSample(k)>=isamp) continue;
            isamp = GetBeginSample(k);
            iep   = k;
        }
        return iep;
    }
    else
    {
        int isamp = GetEndSample(iep);
        for(int k=1; k<nEpochs; k++)
        {
            if(GetEndSample(k)>=isamp) continue;
            isamp = GetEndSample(k);
            iep   = k;
        }
        return iep;
    }
    return -1;
}

int UEpochs::GetLastEpoch(bool Begin) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetLastEpoch(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || nEpochs<=0)
    {
        CI.AddToLog("ERROR: UEpochs::GetLastEpoch(). Epochs not set, or nEpochs=%d.\n", nEpochs);
        return 0;
    }
    int iep = nEpochs-1;
    if(Begin==true)
    {
        int isamp = GetBeginSample(iep);
        for(int k=0; k<nEpochs-1; k++)
        {
            if(GetBeginSample(k)<=isamp) continue;
            isamp = GetBeginSample(k);
            iep   = k;
        }
        return iep;
    }
    else
    {
        int isamp = GetEndSample(iep);
        for(int k=0; k<nEpochs-1; k++)
        {
            if(GetEndSample(k)<=isamp) continue;
            isamp = GetEndSample(k);
            iep   = k;
        }
        return iep;
    }
    return -1;
}
int UEpochs::GetClassIndex(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetClassIndex(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetClassIndex(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return 0;
    }
    return Ep[iep].GetClassIndex();
}

int UEpochs::GetEpochIndex(UEvent E, int* Offset) const
/*
   Return the epoch number of the (first) epoch in which E is located.
   if(Offset) set *Offset equal to the sample number in the epoch, corresponding to E.

   if E is not within any epoch, return -1
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEpochIndex(). Object NULL or erroneous. \n");
        return -1;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetEpochIndex(). Epochs not properly set. \n");
        return -1;
    }

    for(int iep=0; iep<nEpochs; iep++)
    {
        if(::IsInEpoch(Ep[iep].GetBegin(), Ep[iep].GetEnd(), E, nSampTrial)==true)
        {
            if(Offset)
                *Offset = E.GetAbsSample(nSampTrial) - Ep[iep].GetBegin().GetAbsSample(nSampTrial);
            return iep;
        }
    }
    return -1;
}

bool UEpochs::AreEpochsContiguous(UEvent B, UEvent E, bool AllowOneSampleSkipped) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AreEpochsContiguous(). Object NULL or erroneous. \n");
        return false;
    }
    if(nEpochs<=0 || Ep==NULL)
    {
        CI.AddToLog("WARNING: UEpochs::AreEpochsContiguous(). nEpochs=%d .\n", nEpochs);
        return false;
    }

    bool   FirstFound = false;
    UEvent Last;
    for(int iep=0; iep<nEpochs; iep++)
    {
        if(FirstFound==false)
        {
            if(IsInEpoch(iep, B)==true)
            {
                if(IsInEpoch(iep, E)==true) return true;
                FirstFound = true;
                Last       = Ep[iep].GetEnd();
            }
        }
        else
        {
            bool                      Contigeous = Last.GetAbsSample(nSampTrial)+1==Ep[iep].GetBegin().GetAbsSample(nSampTrial);
            if(AllowOneSampleSkipped) Contigeous|= Last.GetAbsSample(nSampTrial)+2==Ep[iep].GetBegin().GetAbsSample(nSampTrial);
            
            if(NOT(Contigeous))          return false;
            if(IsInEpoch(iep, E)==true)  return true;

            Last = Ep[iep].GetEnd();
        }
    }
    return false;
}
bool UEpochs::DoEpochsHaveGaps(UEvent B, UEvent E) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::DoEpochsHaveGaps(). Object NULL or erroneous. \n");
        return true;
    }
    if(nEpochs<=0 || Ep==NULL)
    {
        CI.AddToLog("WARNING: UEpochs::DoEpochsHaveGaps(). nEpochs=%d .\n", nEpochs);
        return true;
    }
    if(B.GetAbsSample(nSampTrial) > E.GetAbsSample(nSampTrial)) return true;

    bool   FirstFound = false;
    UEvent Last;
    for(int iep=0; iep<nEpochs; iep++)
    {
        if(FirstFound==false)
        {
            if(IsInEpoch(iep, B)==true)
            {
                if(IsInEpoch(iep, E)==true) return false;
                FirstFound = true;
                Last       = Ep[iep].GetEnd();
            }
        }
        else
        {
            if(Last.GetAbsSample(nSampTrial) < Ep[iep].GetBegin().GetAbsSample(nSampTrial)) return true;
            if(IsInEpoch(iep, E)==true)                                                     return false;

            Last = Ep[iep].GetEnd();
        }
    }
    return true;
}

bool UEpochs::AreEpochTimesEqual(const char* MarkerName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AreEpochTimesEqual(). Object NULL or erroneous. \n");
        return false;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AreEpochTimesEqual(). Object NULL or erroneous. \n");
        return false;
    }
    if(nEpochs==0)  return true;

    if(MarkerName==NULL)
    {
        int nsamp = GetNsamp(0);
        for(int iep=1; iep<nEpochs; iep++)
            if(nsamp != GetNsamp(iep)) return false;
    }
    else
    {
        int nsamp = -1;
        for(int iep=0; iep<nEpochs; iep++)
        {
            if(IsMarkerIsInDescriptor(iep, MarkerName)==false) continue;

            if(nsamp==-1) nsamp = GetNsamp(iep);
            if(nsamp != GetNsamp(iep)) return false;
        }
    }
    return true;
}

bool UEpochs::AreEpochsInOneTrial(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AreEpochsInOneTrial(). Object NULL or erroneous. \n");
        return false;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::AreEpochsInOneTrial(). Epochs not properly set. \n");
        return false;
    }
    for(int iep=0; iep<nEpochs; iep++)
        if(Ep[iep].GetBegin().trial != Ep[iep].GetEnd().trial) return false;

    return true;
}

bool UEpochs::IsOverlapping(UEvent B, UEvent E) const
/*
    Return false iff the interval (B,E) has not any overlap with each of the epochs.
    else   return true.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Object NULL or erroneous. \n");
        return false;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Epochs not properly set. \n");
        return false;
    }
    for(int iep=0; iep<nEpochs; iep++)
        if(::IsOverlapping(B, E, Ep[iep].GetBegin(), Ep[iep].GetEnd(), nSampTrial)==true) return true;

    return false;
}

bool UEpochs::IsOverlapping(int iep, const UEpochs* EpTar, int iepTar) const
{
    if(this==NULL || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Epochs not properly set. \n");
        return false;
    }
    if(iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Epoch out of range (iep=%d). \n", iep);
        return false;
    }
    if(EpTar==NULL || EpTar->Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Argument NULL or erroneous \n");
        return false;
    }
    if(iepTar<0 || iepTar>=EpTar->GetnEpochs())
    {
        CI.AddToLog("ERROR: UEpochs::IsOverlapping(). Target Epoch out of range (iepTar=%d). \n", iepTar);
        return false;
    }
    int B1 = GetBeginSample(iep);
    int E1 = GetEndSample(iep);
    if(B1>E1)
    {
        CI.AddToLog("WARNING: UEpochs::IsOverlapping(). Begin after End, epoch %d. \n",iep);
        int dum = B1;
        B1      = E1;
        E1      = dum;
    }
    int B2 = EpTar->GetBeginSample(iepTar);
    int E2 = EpTar->GetEndSample(iepTar);
    if(B2>E2)
    {
        CI.AddToLog("WARNING: UEpochs::IsOverlapping(). Begin after End, target epoch %d. \n",iepTar);
        int dum = B2;
        B2      = E2;
        E2      = dum;
    }
    if(E1<B2 || E2<B1) return false;

    return true;
}

bool UEpochs::IsInEpoch(int iep, UEvent Ev) const
{
    if(this==NULL || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::IsInEpoch(). Epochs not properly set. \n");
        return false;
    }
    if(iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::IsInEpoch(). Epoch out of range (iep=%d). \n", iep);
        return false;
    }
    return ::IsInEpoch(Ep[iep].GetBegin(), Ep[iep].GetEnd(), Ev, nSampTrial);
}

bool UEpochs::IsInEpoch(int iep, const UMarker* M) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::IsInEpoch(). Object NULL or erroneous. \n");
        return false;
    }
    if(M==NULL) return false;

    if(M->GetError()!=U_OK || M->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEpochs::IsInEpoch(). Erroneous Marker, or erroneous Nsamptrial (%d), must be %d .\n", M->GetnSampTrial(), nSampTrial);
        return false;
    }
    for(int iev=0; iev<M->GetnEvents(); iev++)
        if(this->IsInEpoch(iep, M->GetEvent(iev))==true) return true;

    return false;
}

bool UEpochs::IsInAnyEpoch(UEvent Ev) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::IsInAnyEpoch(). Object NULL or erroneous. \n");
        return false;
    }
    for(int iep=0; iep<nEpochs; iep++)
        if(IsInEpoch(iep, Ev)) return true;

    return false;
}
bool UEpochs::IsInAnyEpoch(const UMarker* M, const int* Offset, int Noff) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::IsInAnyEpoch(). Object NULL or erroneous. \n");
        return false;
    }
    if(M==NULL || M->GetError()!=U_OK || Offset==NULL || Noff<=0)
    {
        CI.AddToLog("ERROR: UEpochs::IsInAnyEpoch(). Invalid or NULL pointer arguments, Noff = %d .\n", Noff);
        return false;
    }
    int NsampTr = M->GetnSampTrial();
    for(int iev=0; iev<M->GetnEvents(); iev++)
    {
        for(int n=0; n<Noff; n++)
        {
            UEvent Ev = M->GetEvent(iev).GetShiftedEvent(Offset[n], NsampTr);
            if(IsInAnyEpoch(Ev)==false) return false;
        }
    }
    return true;
}

bool UEpochs::IsMarkerIsInDescriptor(int iep, const char* MarkerName) const
/*
     Return true iff epoch iep has the string MARKER=MarkerName[] in
     its descriptor.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::IsMarkerIsInDescriptor(). Object NULL or erroneous. \n");
        return false;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::IsMarkerIsInDescriptor(). Invalid object, or invalid argument. iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return false;
    }
    if(Ep[iep].GetDescriptor()==NULL) return false; // No descriptor set

    if(MarkerName==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::IsMarkerIsInDescriptor(). NULL pointer for MarkerName. \n");
        return false;
    }

    UAnalyzeLine AA(Ep[iep].GetDescriptor());
    bool IgnoreCase = true;
    if(AA.IsIdentifierIsInLine("MARKER", IgnoreCase)==false) return false; // No "MARKER =" in line
    const char* Str = AA.GetNextString(int(strlen(MarkerName)+1));

    if(strcmp(Str, MarkerName)) return false; // Strings are different

    return true;
}

int UEpochs::GetNMarkerIsInDescriptor(const char* MarkerName) const
/*
     Return the number of epochs that have the string MARKER=MarkerName[] in
     their descriptor.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetNMarkerIsInDescriptor(). Object NULL or erroneous. \n");
        return 0;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetNMarkerIsInDescriptor(). Epochs not set. \n");
        return 0;
    }
    if(MarkerName==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetNMarkerIsInDescriptor(). NULL pointer for MarkerName. \n");
        return 0;
    }

    int N=0;
    for(int iep=0; iep<nEpochs; iep++)
        if(IsMarkerIsInDescriptor(iep, MarkerName)) N++;

    return N;
}

int UEpochs::GetFirstEpochIndex(const char* MarkerName) const
/*
    Return the index of the first epoch with markername MarkerName[] in its descriptor.
    Return -1 when this name is not present in any of the epoch descriptors.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstEpochIndex(). Object NULL or erroneous. \n");
        return -1;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstEpochIndex(). Epochs not set. \n");
        return -1;
    }
    if(MarkerName==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetFirstEpochIndex(). NULL pointer for MarkerName. \n");
        return -1;
    }
    for(int iep=0; iep<nEpochs; iep++)
        if(IsMarkerIsInDescriptor(iep, MarkerName)) return iep;

    return -1;
}

UEvent UEpochs::GetEvent(int iep, int sample) const
/*
    Return the event, corresponding to sample sample of epoch iep.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEvent(). Object NULL or erreneous. \n");
        return UEvent(0, 0);
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetEvent(). Invalid object, or invalid argument. iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return UEvent(0, 0);
    }
    if(sample<0 || sample >= this->GetNsamp(iep))
    {
        CI.AddToLog("ERROR: UEpochs::GetEvent(). Sample out of range: %d Nsamp = %d .\n", sample, GetNsamp(iep));
        return UEvent(0, 0);
    }
    return Ep[iep].GetBegin().GetShiftedEvent(sample, nSampTrial);
}

UEvent UEpochs::GetEventMergedEpochs(int sample) const
/*
   Return the event, corresponding to the sample number sample, of the merged epochs
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventMergedEpochs(). Object NULL or erreneous. \n");
        return UEvent(0, 0);
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventMergedEpochs(). Invalid object. \n");
        return UEvent(0, 0);
    }
    if(sample<0)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventMergedEpochs(). Invalid argument: %d \n", sample);
        return UEvent(0, 0);
    }
    int CumSamp = 0;
    for(int iep=0; iep<nEpochs; iep++)
    {
        CumSamp += this->GetNsamp(iep);
        if(CumSamp>sample)
            return Ep[iep].GetBegin().GetShiftedEvent(sample-CumSamp, nSampTrial);
    }

    CI.AddToLog("ERROR: UEpochs::GetEventMergedEpochs(). sample out of range: %d NtotSamp = %d .\n", sample, GetTotalSamples());
    return UEvent(0, 0);
}

unsigned char* UEpochs::GetIndicator(int Ntrial) const
/*
    Return a char array of length Ntrial*nSampTrial, which elements
    correspond to the absolute sample number if the data file.
    Each element is filled with a number, equal to the number of epochs, to which it belongs.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetIndicator(). Object NULL or erreneous. \n");
        return NULL;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetIndicator(). Epochs not (properly) set. \n");
        return NULL;
    }
    int Ntot = Ntrial*nSampTrial;
    unsigned char* Indicator = new unsigned char[Ntot];
    if(Indicator==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetIndicator(). Memory allocation, Ntot=%d\n",Ntot);
        return NULL;
    }
    memset(Indicator, 0, Ntot);

    for(int iep=0; iep<nEpochs; iep++)
    {
        int ib = Ep[iep].GetBegin().GetAbsSample(nSampTrial);
        int ie = Ep[iep].GetEnd().GetAbsSample(nSampTrial);

        for(int k=MIN(Ntot-1,ib); k<=MIN(Ntot-1,ie); k++)
            if(Indicator[k]<255) Indicator[k]++;
    }
    return Indicator;
}

ErrorType UEpochs::LogProperties(const char* FileName) const
/*
    if(FileName) add properties to standard .log file
    else         add properties to FileName[]
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::LogProperties(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::LogProperties(). Epochs not set. \n");
        return U_ERROR;
    }
    if(FileName)
    {
        FILE* fp = fopen(FileName, "wt");
        if(fp==NULL) return LogProperties(NULL);

        fprintf(fp, "EpochsName = %s\n", (const char*)EpochName);
        fprintf(fp, "nEpochs = %d\n", nEpochs);
        fprintf(fp, "Begin(t,s)  End(t,s)  Begin-End\n");
        for(int n=0; n<nEpochs; n++)
        {
            UEvent Begin = Ep[n].GetBegin();
            UEvent End   = Ep[n].GetEnd();
            fprintf(fp, " %d \t%d  \t",Begin.trial,Begin.sample);
            fprintf(fp, " %d \t%d  \t",End.trial,End.sample);
            fprintf(fp, " %d - \t%d\t",Begin.GetAbsSample(nSampTrial),End.GetAbsSample(nSampTrial));
            if(Ep[n].GetDescriptor()) fprintf(fp, "%s\n",Ep[n].GetDescriptor());
            else                      fprintf(fp, "\n");
        }
        fclose(fp);
        return U_OK;
    }
    CI.AddToLog("EpochsName = %s\n", EpochName);
    CI.AddToLog("nEpochs = %d\n", nEpochs);
    CI.AddToLog("Begin(t,s)  End(t,s)  Begin-End\n");
    for(int n=0; n<nEpochs; n++)
    {
        UEvent Begin = Ep[n].GetBegin();
        UEvent End   = Ep[n].GetEnd();
        CI.AddToLog(" %d \t%d  \t",Begin.trial,Begin.sample);
        CI.AddToLog(" %d \t%d  \t",End.trial,End.sample);
        CI.AddToLog(" %d - \t%d\t",Begin.GetAbsSample(nSampTrial),End.GetAbsSample(nSampTrial));
        if(Ep[n].GetDescriptor()) CI.AddToLog( "%s\n",Ep[n].GetDescriptor());
        else                      CI.AddToLog("\n");
    }
    return U_OK;
}

const char* UEpochs::GetDescriptor(int iep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetDescriptor(). Object NULL or erreneous. \n");
        return NULL;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::GetDescriptor(). Parameter out of range. iep = %d, nEpochs = %d \n", iep, nEpochs);
        return NULL;
    }
    return Ep[iep].GetDescriptor();
}

/* Manipulating epochs */
ErrorType UEpochs::SetnEpochs(int nEp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetnEpochs(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(nEp<0)
    {
        CI.AddToLog("ERROR: UEpochs::SetnEpochs(). Argument nEp = %d\n",nEp);
        return U_ERROR;
    }
    UEpoch* NewEp = new UEpoch[nEp];
    if(NewEp==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::SetnEpochs(). Memory allocation. nEp=%d\n",nEp);
        return U_ERROR;
    }
    for(int n=0; n<nEp; n++)
        if(n<nEpochs)
            NewEp[n] = Ep[n];

    delete[] Ep; Ep = NewEp;

    nEpochs      = nEp;
    nEpochsAlloc = nEp;

    char line[200];
    sprintf(line,"//   Hist. Reset number of epochs to %d . \n", nEp);
    return AddToHistory(line);
}

ErrorType  UEpochs::SetBegin(int iep, UEvent ev)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetBegin(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::SetBegin(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return U_ERROR;
    }
    Ep[iep].SetBegin(ev);
    return U_OK;
}

ErrorType  UEpochs::SetEnd(int iep, UEvent ev)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetEnd(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::SetEnd(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return U_ERROR;
    }

    Ep[iep].SetEnd(ev);
    return U_OK;
}

ErrorType UEpochs::SetClassIndex(int iep, int ClassIndex)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetClassIndex(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::SetClassIndex(). iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return U_ERROR;
    }
    Ep[iep].SetClassIndex(ClassIndex);
    return U_OK;
}

ErrorType UEpochs::SetDescriptor(int iep, const char* Descr)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetDescriptor(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::SetDescriptor(). Parameter out of range. iep = %d, nEpochs = %d \n", iep, nEpochs);
        return U_ERROR;
    }
    return Ep[iep].SetDescriptor(Descr);
}

ErrorType UEpochs::SetEpoch(int iep, UEvent B, UEvent E, int ClassIndex, const char* Descr)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SetEpoch(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::SetEpoch(). Invalid object, or invalid argument. iep=%d, nEpochs=%d .\n", iep, nEpochs);
        return U_ERROR;
    }
    Ep[iep] = UEpoch(B, E, ClassIndex, Descr);
    return U_OK;
}

ErrorType UEpochs::RemoveEpoch(int iep)
/*
   Remove epoch iep and shift all subsequent epochs one place back.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::RemoveEpoch(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::RemoveEpoch(). Parameter out of range. iep = %d, nEpochs = %d \n", iep, nEpochs);
        return U_ERROR;
    }

    for(int n=iep; n<nEpochs-1; n++)
        Ep[n] = Ep[n+1];

    nEpochs-=1;
    return U_OK;
}

ErrorType UEpochs::RemoveEpochs(int iep, int Nremove)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::RemoveEpochs(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iep<0 || iep>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::RemoveEpoch(). Parameter out of range. iep = %d, nEpochs = %d \n", iep, nEpochs);
        return U_ERROR;
    }
    if(Nremove<0 || Nremove+iep>nEpochs) Nremove = nEpochs-iep;

    for(int n=iep; n<nEpochs-Nremove; n++)
        Ep[n] = Ep[n+Nremove];

    nEpochs-=Nremove;
    ReAllocateMemory();
    return U_OK;
}

ErrorType UEpochs::AddEpoch(UEvent B, UEvent E, int ClassIndex, const char* Descr)
/*
     Add the epoch, defined by B, E, etc to the existing array of epochs.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AddEpoch(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    UEpoch NewE(B, E, ClassIndex, Descr);

    if(nEpochsAlloc-nEpochs<1) // Allocate new memory for epochs
    {
        int NewAlloc = 2*nEpochsAlloc+2;
        if(NewAlloc<100)  NewAlloc = 100;
        if(NewAlloc>1000) NewAlloc = nEpochsAlloc+1000;
        UEpoch* EpNew = new UEpoch[NewAlloc];
        if(EpNew==NULL)
        {
            CI.AddToLog("ERROR: UEpochs::AddEpoch. Memory allocation. nEpochsAlloc = %d, NewAlloc = %d  .\n", nEpochsAlloc, NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEpochs; n++) EpNew[n] = Ep[n];
        delete[] Ep;  Ep = EpNew;
        nEpochsAlloc     = NewAlloc;
    }
    Ep[nEpochs++] = NewE;

    return U_OK;
}

ErrorType UEpochs::CopyEpoch(int iepTo, const UEpochs* EpFrom, int iepFrom, const UEvent* NewBegin, const UEvent* NewEnd)
/*
    Copy UEpoch number iepFrom of the EpFrom[] array to UEpoch number iepTo of this[].
    if(NewBegin) set the begin of UEpoch iepTo equal to *NewBegin
    if(NewEnd)   set the end   of UEpoch iepTo equal to *NewEnd
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::CopyEpoch(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || iepTo<0 || iepTo>=nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::CopyEpoch(). Parameter out of range. iepTo = %d, nEpochs = %d \n", iepTo, nEpochs);
        return U_ERROR;
    }
    if(EpFrom==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::CopyEpoch(). Invalid NULL argument EpFrom==NULL. \n");
        return U_ERROR;
    }
    if(iepFrom<0 || iepFrom>=EpFrom->nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::CopyEpoch(). Parameter out of range. iepFrom = %d, nEpochs = %d \n", iepFrom, EpFrom->nEpochs);
        return U_ERROR;
    }
    Ep[iepTo] = EpFrom->Ep[iepFrom];

    if(NewBegin) Ep[iepTo].SetBegin(*NewBegin);
    if(NewEnd)   Ep[iepTo].SetEnd(*NewEnd);

    return U_OK;
}

ErrorType UEpochs::MergeOverlapping(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::MergeOverlapping(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::MergeOverlapping(). Invalid Epochs (Ep==NULL) .\n");
        return U_ERROR;
    }
    if(nSampTrial<=0)
    {
        CI.AddToLog("ERROR: UEpochs::MergeOverlapping(). Invalid nSampTrial (=%d) .\n", nSampTrial);
        return U_ERROR;
    }

    CI.AddToLog("Note: UEpochs::MergeOverlapping(). Name = %s, NepochsInput =%d ",EpochName,nEpochs);
    int i1=0;
    while(i1<nEpochs)
    {
        int nOver = -1;
        while(nOver)
        {
            nOver=0;
            for(int i2=i1+1; i2<nEpochs; i2++)
            {
                if(this->MergeOverlapping(Ep+i1, Ep+i2)==true) nOver++;
            }
            if(nOver>0) // Overwrite double epochs by shifting epochs to the left
            {
                for(int i2=i1+1, i2new=i1+1; i2<nEpochs; i2++)
                {
                    if(Ep[i1].GetBegin()!=Ep[i2].GetBegin() ||
                       Ep[i1].GetEnd()  !=Ep[i2].GetEnd())
                    {
                        Ep[i2new] = Ep[i2];
                        Ep[i2new].SetDescriptor(NULL);
                        i2new++;
                    }
                }
                nEpochs-=nOver;
            }
            else
            {
                i1++;
                nOver = -1;
            }
            if(i1>=nEpochs) break;
        }
    }
    CI.AddToLog(", NepochsOutput =%d .\n",nEpochs);

    char line[200];
    sprintf(line,"//   Hist. Merge overllaping epochs. New number of epochs is %d . \n", nEpochs);
    return AddToHistory(line);
}

ErrorType UEpochs::SortEpochs(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SortEpochs(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::SortEpochs(). Epochs not set. \n");
        return U_ERROR;
    }

    qsort(Ep, nEpochs, sizeof(Ep[0]), SortEvent);

    char line[200];
    sprintf(line,"//   Hist. Sorted epochs. \n");
    return AddToHistory(line);
}

ErrorType UEpochs::Subsample(int Ntake, int Nphase)
/*
    Exclusively take every Ntake-epochs, starting with Nphase
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::SubSample(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(Ep==NULL || Ntake<=0 || Nphase<0 || Nphase>nEpochs)
    {
        CI.AddToLog("ERROR: UEpochs::Subsample(). Invalid parameters. Ntake = %d, Nphase = %d .\n",Ntake, Nphase);
        return U_ERROR;
    }

    int  NnewEpochs  = (nEpochs-Nphase+Ntake-1)/Ntake;

    UEpoch* NewEp = new UEpoch[NnewEpochs];

    if(NewEp==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::Subsample(). Memory allocation. NnewEpochs = %d .\n",NnewEpochs);
        return U_ERROR;
    }

/*Sub sample epochs*/
    for(int iep=Nphase,inew=0; iep<nEpochs; iep+=Ntake,inew++)
        NewEp[inew] = Ep[iep];

/*Set new parameters*/
    delete[] Ep; Ep = NewEp;

    nEpochs = NnewEpochs;

    char line[200];
    sprintf(line,"//   Hist. Subsample epochs, with Ntake = %d, Nphase = %d . \n", Ntake, Nphase);
    return AddToHistory(line);
}

ErrorType UEpochs::ForceEqualSize(int NsampEp, bool NsampAverage, bool ForcePower2)
/*
    Adapt the positions of the begin and end markers of Epochs[] such that
    all eposchs have the same number of samples.
    if(NsampAverage==true)
    {
        new number of samples per epoch is the average number of samples of the existing epochs.
    }
    else
    {
        new number of samples per epoch is NsampEp
    }
    If(ForcePower2==true)
        new number of samples is power of 2, nearest to NsampEp/(the average number of samples per epoch).
*/
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ForceEqualSize(). Object not properly set. \n");
        return U_ERROR;
    }
    if(nEpochs==0) return U_OK;
    if(ForcePower2==false && AreEpochTimesEqual()==true) return U_OK;

/*Compute the Epoch-size.*/
    if(NsampAverage==true)
    {
        double AvSize = 0;
        for(int n=0; n<nEpochs; n++) AvSize += GetNsamp(n);
        NsampEp = (int)floor(.5 + AvSize/nEpochs);
    }

    if(ForcePower2==true)
    {
        int nlarge = 1<<(int) ceil( log((double)NsampEp)/log(2.) );
        if(abs(nlarge/2-NsampEp)<abs(nlarge-NsampEp)) NsampEp = nlarge/2;
        else                                          NsampEp = nlarge;
    }

/* Adapt begin and end samples, try to keep them symmetrically about the center*/
    for(int n=0; n<nEpochs; n++)
    {
        UEvent Cent   = Ep[n].GetCenter(nSampTrial);
        UEvent NewBeg = Cent.GetShiftedEvent(-NsampEp/2, nSampTrial);
        UEvent NewEnd = NewBeg.GetShiftedEvent(NsampEp-1, nSampTrial);

        SetBegin(n, NewBeg);
        SetEnd  (n, NewEnd);
    }

    char line[200];
    sprintf(line,"//   Hist. Forced epochs to be of equal size of %d samples. \n",NsampEp);
    return AddToHistory(line);
}

ErrorType UEpochs::ForceEpochsInDataSet(int Ntrial)
/*
    Remove all epochs outside data set.
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ForceEpochsInDataSet(). Object not properly set. \n");
        return U_ERROR;
    }
    if(nEpochs==0) return U_OK;

    int nRem = 0;
    for(int n=0; n<nEpochs; n++)
    {
        if(Ep[n].GetBegin().trial>=0 && Ep[n].GetEnd().trial<Ntrial) continue;
        RemoveEpoch(n--);
        nRem++;
    }

    char line[200];
    sprintf(line,"//   Hist. Forced epochs to be in data range, Removed %d epochs. \n",nRem);
    return AddToHistory(line);
}

ErrorType UEpochs::ExcludeOverlapping(void)
/*
   This function excludes epochs that overlap one another. Herewith, first the epoch
   with the maximum number of overlapping neighbour epochs is removed first. Then
   of the remaing epochs this procedure is repeated until no (overlapping) eochs
   are left.
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeOverlapping(). Object not properly set. \n");
        return U_ERROR;
    }

    int* Nover = new int[nEpochs];
    if(Nover==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeOverlapping(). Memory allocation error, nEpochs = %d . \n", nEpochs);
        return U_ERROR;
    }

    int nRem = 0;
    while(nEpochs>1)
    {
        int NoverMax  = 0; // The maximum number of overlapping epochs
        int noverMax  = 0; // The epoch having the maximum number of overlapping epochs

        for(int n1=0; n1<nEpochs; n1++)
        {
            Nover[n1] = 0;
            UEvent B1 = GetBegin(n1);
            UEvent E1 = GetEnd(n1);
            for(int n2=0; n2<nEpochs; n2++)
            {
                if(n1==n2) continue;
                UEvent B2 = GetBegin(n2);
                UEvent E2 = GetEnd(n2);
                if(::IsOverlapping(B1, E1, B2, E2, nSampTrial)==true) Nover[n1]++;
            }
            if(Nover[n1]>NoverMax)
            {
                NoverMax = Nover[n1];
                noverMax = n1;
            }
        }
        if(NoverMax>0)
        {
            UEvent B = GetBegin(noverMax);
            UEvent E = GetEnd(noverMax);
            CI.AddToLog("Note: UEpochs::ExcludeOverlapping() : Epoch {(%d,%d)-(%d,%d)} removed.\n",B.trial,B.sample,E.trial,E.sample);
            RemoveEpoch(noverMax);
            nRem++;
        }
        else
            break;
    }
    delete[] Nover;

    char line[200];
    sprintf(line,"//   Hist. Removed %d overlapping epochs. \n",nRem);
    return AddToHistory(line);
}

ErrorType UEpochs::ExcludeTrials(int starttrial, int endtrial)
/*
     Exclude all epochs that have at least one data sample outside trial
     starttrial to entrial.

     if(endtrial<0) ignore endtrial
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeTrials(). Object not properly set. \n");
        return U_ERROR;
    }
    if(endtrial>=0 && starttrial>endtrial)
    {
        CI.AddToLog("ERROR Epochs::ExcludeTrials() : Starttrial after Endtrial : (%d, %d)\n",starttrial,endtrial);
        return U_ERROR;
    }

    int nRem    = 0;  // Total
    int RemFrom = 0;
    int Nremove = 0;  // contigeous parts
    for(int n=0; n<nEpochs; n++)
    {
        int  Btrial = GetBegin(n).trial;
        int  Etrial = GetEnd(n).trial;
        bool Remo   = false;

        if(endtrial<0)
        {
            if(Btrial<starttrial ||
               Etrial<starttrial)
            {
               Remo = true;
               Nremove++;
            }
        }
        else
        {
            if(Btrial<starttrial || Btrial>endtrial ||
               Etrial<starttrial || Etrial>endtrial)
            {
               Remo = true;
               Nremove++;
            }
        }
        if((Remo==false || n==nEpochs-1) && Nremove>0)
        {
            nRem    += Nremove;
            RemoveEpochs(RemFrom, Nremove);
            n        = RemFrom;
            Nremove  = 0;
        }
        else if(Remo==true && Nremove==1) RemFrom = n;
    }

    char line[200];
    sprintf(line,"//   Hist. Exclude %d epochs outside trials [%d,%d] \n", nRem, starttrial, endtrial);
    return AddToHistory(line);
}

ErrorType UEpochs::ExcludeEpochs(int startepoch, int endepoch)
/*
     Exclude all epochs from startepoch to endepoch

     if(endepoch<0) ignore endepoch
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeEpochs(). Object not properly set. \n");
        return U_ERROR;
    }
    if(endepoch<0) endepoch = nEpochs;
    if(startepoch>endepoch)
    {
        CI.AddToLog("ERROR Epochs::ExcludeEpochs() : Startepoch after Endepoch : (%d, %d)\n",startepoch,endepoch);
        return U_ERROR;
    }

    RemoveEpochs(startepoch, endepoch-startepoch+1);

    char line[200];
    sprintf(line,"//   Hist. Exclude epochs from %d to %d \n", startepoch, endepoch);
    return AddToHistory(line);
}

ErrorType UEpochs::ExcludeEpochs(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername)
/*
     Exclude complete epochs that have at least one point in common with marker[] of *Mar.
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeEpochs(). Object not properly set. \n");
        return U_ERROR;
    }

    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeEpochs(). Invalid UMarkerArray() argument. \n");
        return U_ERROR;
    }
    if(nSampTrial!=Mar->GetnSampTrial())
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeEpochs(). nSampTrial (=%d) inconsistent with number of samples per trial in UMarkerArray()-object (=%d). \n", nSampTrial, Mar->GetnSampTrial());
        return U_ERROR;
    }
    if(BeginOffset>EndOffset)
    {
        CI.AddToLog("ERROR UEpochs::ExcludeEpochs(). startsample after end sample (%d, %d)\n", BeginOffset, EndOffset);
        return U_ERROR;
    }

    UEpochs* ExEpo = new UEpochs(BeginOffset, EndOffset, Mar, markername);
    if(ExEpo==NULL || ExEpo->GetError()!=U_OK || ExEpo->GetnEpochs()<=0)
    {
        delete ExEpo;
        CI.AddToLog("WARNING: UEpochs::ExcludeEpochs(). Cannot exclude samples in neighbourhood of markers called %s\n",markername);
        return U_OK;
    }
    ExEpo->MergeOverlapping();
    ExEpo->SortEpochs();

    int Nold  = nEpochs;
    for(int k1=0; k1<nEpochs; k1++) // nEpochs may not be constant!
    {
        UEvent B1 = GetBegin(k1);
        UEvent E1 = GetEnd(k1);
        for(int k2=0; k2<ExEpo->GetnEpochs(); k2++)
        {
            UEvent B2 = ExEpo->GetBegin(k2);
            UEvent E2 = ExEpo->GetEnd(k2);

            if(::IsOverlapping(B1,E1,B2,E2,nSampTrial)==true)
            {
                RemoveEpoch(k1--);
                break;
            }
        }
    }
    delete ExEpo;

    int nRem = Nold - nEpochs;
    CI.AddToLog("Note: UEpochs::ExcludeEpochs(). MarkerName = %s, NumberRemovedEpochs = %d  .\n",markername, nRem);

    char line[200];
    sprintf(line,"//   Hist. Exclude %d epochs that are within a range of (%d,%d) samples from markers named %s \n", nRem, BeginOffset, EndOffset, markername);
    return AddToHistory(line);
}

ErrorType UEpochs::ExcludeSamples(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername)
/*
     Exclude complete all samples that coincide with a range of halfwidth samples
     about markers named marker[] of *Mar.

     Note: due to this function, epochs may be split and the number of samples per
     epoch may decrease.
 */
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeSamples(). Object not properly set. \n");
        return U_ERROR;
    }

    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeSamples(). Invalid UMarkerArray() argument. \n");
        return U_ERROR;
    }
    if(nSampTrial!=Mar->GetnSampTrial())
    {
        CI.AddToLog("ERROR: UEpochs::ExcludeSamples(). nSampTrial (=%d) inconsistent with number of samples per trial in UMarkerArray()-object (=%d). \n", nSampTrial, Mar->GetnSampTrial());
        return U_ERROR;
    }
    if(BeginOffset>EndOffset)
    {
        CI.AddToLog("ERROR UEpochs::ExcludeSamples(). startsample after end sample (%d, %d)\n", BeginOffset, EndOffset);
        return U_ERROR;
    }

    UEpochs* ExEpo = new UEpochs(BeginOffset, EndOffset, Mar, markername);
    if(ExEpo==NULL || ExEpo->GetError()!=U_OK || ExEpo->GetnEpochs()<=0)
    {
        delete ExEpo;
        CI.AddToLog("WARNING: UEpochs::ExcludeSamples(). Cannot exclude samples in neighbourhood of markers called %s\n",markername);
        return U_OK;
    }
    ExEpo->MergeOverlapping();
    ExEpo->SortEpochs();


/* Count an upper bound for the number of new epochs*/
    int NnewEpochs = nEpochs;  // This is an upperbound for the number of epochs
    int k1 = 0;
    for(      ; k1<nEpochs; k1++)
    {
        UEvent B1 = GetBegin(k1);
        UEvent E1 = GetEnd(k1);
        for(int k2=0; k2<ExEpo->GetnEpochs(); k2++)
        {
            UEvent B2 = ExEpo->GetBegin(k2);
            UEvent E2 = ExEpo->GetEnd(k2);

            if(::IsOverlapping(B1,E1,B2,E2,nSampTrial)==false) continue;

            if(::IsEnclosing(B1,E1,B2,E2,nSampTrial)==true) // Epoch is split
            {
                NnewEpochs++;
                continue;
            }
        }
    }

/* Allocate memory for a new list of epochs (of which the last part may remain unused)*/
    UEpochs *NewEpochs = new UEpochs(GetEpochName(), NnewEpochs, nSampTrial);
    if(NewEpochs==NULL || NewEpochs->GetError()!=U_OK)
    {
        delete NewEpochs;
        CI.AddToLog("ERROR UEpochs::ExcludeSamples() : Cannot create UEpochs-object\n");
        return U_ERROR;
    }

/* Compute and count the new epochs*/
    NnewEpochs = 0;
    for(k1=0; k1<nEpochs; k1++)
    {
        UEvent B1 = GetBegin(k1);
        UEvent E1 = GetEnd(k1);

        bool AllB2E2BeforeB1E1 = false;
        for(int k2=0; k2<ExEpo->GetnEpochs(); k2++)
        {
            UEvent B2 = ExEpo->GetBegin(k2);
            UEvent E2 = ExEpo->GetEnd(k2);

            if(IsEnclosing(B2,E2,B1,E1,nSampTrial)==true) // Skip the epoch (B1,E1)
            {
                AllB2E2BeforeB1E1 = true;
                break;
            }
            if(E2.GetAbsSample(nSampTrial)<B1.GetAbsSample(nSampTrial)) continue;
            if(::IsInEpoch(B1, E1, B2, nSampTrial)==true)
            {
                UEvent End = B2.GetShiftedEvent(-1,nSampTrial);
                NewEpochs->CopyEpoch(NnewEpochs, this, k1, &B1, &End);

                NnewEpochs++;
                if(::IsInEpoch(B1, E1, E2, nSampTrial)==false)
                {
                    AllB2E2BeforeB1E1 = true;
                    break;
                }
                B1 = E2.GetShiftedEvent(1,nSampTrial);
                continue;
            }
            else if(::IsInEpoch(B1, E1, E2 ,nSampTrial)==true)
            {
                B1 = E2.GetShiftedEvent(1,nSampTrial);
                continue;
            }
            else
            {
                AllB2E2BeforeB1E1 = true;
                NewEpochs->CopyEpoch(NnewEpochs, this, k1, &B1, &E1);
                NnewEpochs++;
                break;
            }
        }
        if(AllB2E2BeforeB1E1==false) // All (B2,E2) epochs are located before (B1,E1)
        {
            NewEpochs->CopyEpoch(NnewEpochs, this, k1, &B1, &E1);
            NnewEpochs++;
        }
    }
    delete ExEpo;

/* Replace old epochs by new epochs, keep history preserved */
    NewEpochs->History = History;
    *this = *NewEpochs;
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR UEpochs::ExcludeSamples(). Copying results. \n");
        return U_ERROR;
    }

    LogProperties();

    UString H = UString(BeginOffset, EndOffset, "Hist. Exclude samples that are witin (%d,%d) samples from markers named ") + UString(markername);
    return AddToHistory(H);
}

UEpochs::UEpoch::UEpoch()
{
    Begin      = UEvent();
    End        = UEvent();
    Descriptor = NULL;
    ClassIndex = 0;
}

UEpochs::UEpoch::UEpoch(const UEpochs::UEpoch& e)
{
    Begin      = UEvent();
    End        = UEvent();
    Descriptor = NULL;
    ClassIndex = 0;
    *this      = e;
}

UEpochs::UEpoch::UEpoch(UEvent B, UEvent E, int ClassInd, const char* Descript)
{
    Begin      = B;
    End        = E;
    Descriptor = NULL;
    if(Descript  ) Descriptor = new char[strlen(Descript)+2];
    if(Descriptor) strcpy(Descriptor, Descript);
    ClassIndex = ClassInd;
}

UEpochs::UEpoch::~UEpoch()
{
    delete[] Descriptor;
}

UEpochs::UEpoch& UEpochs::UEpoch::operator=(const UEpochs::UEpoch& e)
{
    Begin      = e.Begin;
    End        = e.End;
    ClassIndex = e.ClassIndex;
    delete[] Descriptor; Descriptor = NULL;
    if(e.Descriptor)
    {
        Descriptor = new char[strlen(e.Descriptor)+2];
        if(Descriptor) strcpy(Descriptor, e.Descriptor);
    }
    return *this;
}

UEvent UEpochs::UEpoch::GetCenter(int NsampTrial) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::UEpoch::GetCenter(). Object NULL or erreneous. \n");
        return UEvent(0,0);
    }
    return Center(Begin, End, NsampTrial);
}

ErrorType UEpochs::UEpoch::SetDescriptor(const char* Descript)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::UEpoch::SetDescriptor(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    delete[] Descriptor; Descriptor = NULL;
    if(Descript  ) Descriptor = new char[strlen(Descript)+2];
    if(Descriptor) strcpy(Descriptor, Descript);
    if(Descript && !Descriptor) return U_ERROR;
    return U_OK;
}

int UEpochs::UEpoch::GetNsamples(int nSampTrial) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::UEpoch::GetNsamples(). Object NULL or erreneous. \n");
        return 0;
    }
    return::GetNsamples(Begin, End, nSampTrial);
}

bool UEpochs::MergeOverlapping(UEpoch*EP1, UEpoch*EP2) const
/*
     if the intervals EP1 and EP2 overlap
        - replace both EP1 and EP2 with the merged intervals
        - return true
     else
        - do not change the intervals
        - return false
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::UEpoch::MergeOverlapping(). Object NULL or erreneous. \n");
        return false;
    }
    UEvent B1 = EP1->GetBegin();
    UEvent E1 = EP1->GetEnd();
    UEvent B2 = EP2->GetBegin();
    UEvent E2 = EP2->GetEnd();
    if(::MergeOverlapping(&B1, &E1, &B2, &E2, nSampTrial)==false) return false;
    EP1->SetBegin(B1);
    EP1->SetEnd(E1);
    EP2->SetBegin(B2);
    EP2->SetEnd(E2);
    return true;
}

ErrorType UEpochs::AddToHistory(const char* String)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::AddToHistory(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(String == NULL)
    {
        CI.AddToLog("ERROR: UEpochs::AddToHistory(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    History += UString(String) + UString("\n");

    return U_OK;
}

ErrorType UEpochs::ReAllocateMemory(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::ReAllocateMemory(). Object NULL or erreneous. \n");
        return U_ERROR;
    }
    if(nEpochsAlloc==nEpochs) return U_OK;

    UEpoch* EpNew = new UEpoch[nEpochs];
    if(EpNew==NULL)
    {
        CI.AddToLog("WARNING: UEpochs::ReAllocateMemory(). Re-allocating memory, nEpochsAllocated = %d, nEpochs = %d  .\n", nEpochsAlloc, nEpochs);
        return U_ERROR;
    }

    for(int n=0; n<nEpochs; n++) EpNew[n] = Ep[n];
    delete[] Ep;   Ep = EpNew;
    nEpochsAlloc = nEpochs;

    return U_OK;
}

UFieldGraph* UEpochs::GetEventsPerEpochAsFieldGraph(const UMarker* M, double Stime, int EpBin, int* NEpochsLeft, int NSegment) const
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Object not properly set. \n");
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Invalid UMarker() argument. \n");
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Invalid sample time argument, Stime = %f. \n", Stime);
        return NULL;
    }
    if(NSegment<1)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Invalid NSegment argument, NSegment = %d. \n", NSegment);
        return NULL;
    }
    if(NSegment>1 && AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Epoch times should be equal when NSegment (=%d) >1). \n", NSegment);
        return NULL;
    }
    if(EpBin<=0) EpBin = 1;

    int  nEvents = M->GetnSamples();
    int  nE      = nEpochs;
    int  diff    = 0;
    if(EpBin>1)
    {
        if(EpBin>nEpochs)
        {
            CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Invalid epoch binning (EpBin=%i>nEpochs=%i). \n", EpBin, nEpochs);
            return NULL;
        }
        nE   = nEpochs/EpBin;
        diff = nEpochs - nE * EpBin;
        if(diff>0)
            CI.AddToLog("WARNING: UEpochs::GetEventsPerEpochAsFieldGraph(). nEpochs is not a multiple of binning number. Last %i epochs left out. \n", diff);
    }
    if(NEpochsLeft) *NEpochsLeft = diff;

    double BegTime    = Stime*GetBeginSample(0);
    double EndTime    = Stime*GetBeginSample(nEpochs-1-diff);

    UFieldGraph* FieldGr = new UFieldGraph((float)BegTime, (float)EndTime, nE, UField::U_INTEGER, NSegment);
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetIdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEpochs::GetEventsPerEpochAsFieldGraph(). Saving markers: Setting UField object. \n");
        return NULL;
    }
    FieldGr ->SetLabel(UString("Dens_")+UString(M->GetMarkerName()));
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);
    if(NSegment>1)
        FieldGr ->SetComponentsDataType(U_COMPDAT_SLICEPROPER);

    UString Comment  = UString(" Markername =") + UString(M->GetMarkerName()) + UString(" \n");
            Comment += UString(nEpochs, " NumEpochs       = %d \n");
            Comment += UString(EpBin,   " EpochBinSize    = %d \n");
            Comment += UString(diff,    " NumpochsLeftOut = %d \n");
            Comment += UString(NSegment," NSegment        = %d \n");
    FieldGr->AddFileComments(Comment);

    int* EvCount = FieldGr->GetIdata();
    for(int i=0; i<nE*NSegment; i++) EvCount[i] = 0;

    int NSampBin = EpBin*GetNsamp(0);
    for(int i=0; i<nE; i++)
    {
        int EpBeg = i * EpBin;
        int EpEnd = i * EpBin + EpBin;
        for(int n=0; n<nEvents; n++)
        {
            UEvent Event  = M->GetEvent(n);
            for(int is=0; is<NSegment; is++)
            {
                int shift = -(is*NSampBin)/NSegment;
                UEvent ES = Event.GetShiftedEvent(shift, nSampTrial);
                for(int iep=EpBeg; iep<EpEnd; iep++)
                    if(this->IsInEpoch(iep, ES)==true) EvCount[i*NSegment+is] +=1;
            }
        }
    }

    FieldGr->ConvertData(UField::U_DOUBLE);
    return FieldGr;
}

UMarker* UEpochs::ConvertGraphToMarkers(const UFieldGraph* Graph) const
{
    if(this==NULL || error!=U_OK || Ep==NULL)
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Object not properly set. \n");
        return NULL;
    }
    if(Graph==NULL || Graph->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Erroneous or NULL argument. \n");
        return NULL;
    }
    if(nEpochs!=Graph->GetNpoints())
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Number of epochs (%d) not compatible to number of graph-points (%d). \n", nEpochs, Graph->GetNpoints());
        return NULL;
    }
    int veclen = Graph->GetVeclen();
    if(veclen<=0)
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Invalid veclen. \n", veclen);
        return NULL;
    }
    if(Graph->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Invalid Graph->ndim. \n");
        return NULL;
    }

    UMarker* M = new UMarker((const char*)Graph->GetLabel(), 0, nSampTrial, 0, "Coverted from graph", 0, true);
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEpochs::ConvertGraphToMarkers(). Creating UMarker. \n");
        return M;
    }

    for(int n=0; n<Graph->GetNpoints(); n++)
    {
        switch(Graph->GetDType())
        {
        case UField::U_BYTE   : if(Graph->GetBdata()[n*veclen]==0) continue; M->AddEvent(UEvent(n, 0)); break;
        case UField::U_SHORT  : if(Graph->GetSdata()[n*veclen]==0) continue; M->AddEvent(UEvent(n, 0)); break;
        case UField::U_INTEGER: if(Graph->GetIdata()[n*veclen]==0) continue; M->AddEvent(UEvent(n, 0)); break;
        case UField::U_FLOAT  : if(Graph->GetFdata()[n*veclen]==0) continue; M->AddEvent(UEvent(n, 0)); break;
        case UField::U_DOUBLE : if(Graph->GetDdata()[n*veclen]==0) continue; M->AddEvent(UEvent(n, 0)); break;
        }
    }
    return M;
}
