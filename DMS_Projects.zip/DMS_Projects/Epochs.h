#ifndef _EPOCHS_INCLUDED
#define _EPOCHS_INCLUDED

#include "Event.h"
#include "String.h"

class UMarkerArray;
class UMarker;
class UFieldGraph;
class UField;

class DLL_IO UEpochs 
{
public:
    UEpochs();
    UEpochs(const char *Name, int nEp, int NsampPTrial);
    UEpochs(int starttrial, int endtrial, int startsample, int endsample, int NsampPTrial);
    UEpochs(const unsigned char* Indicator, int NsampPTrial, int Ntrial, const char* Name);
    UEpochs(const int* BeginSamp, const int* EndSamp, int Nep, int NsampPTrial, const char* Name);
    UEpochs(int BeginOffset, int EndOffset, const UMarker* M);
    UEpochs(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername);
    UEpochs(const UMarkerArray* Mar, const char* BEName);
    UEpochs(int Npieces, int Ntrial, int NsampTr, bool ForcePower2, bool IgnoreTrialBounds);
    UEpochs(int NsampSkip, int NewTrialLen, int startsample, int endsample, int NsampPTrial, int Ntrial);
    UEpochs(int EpochLen, int EpochShift, int NsampPTrial, int Ntrial);
    UEpochs(const UFieldGraph* FG, double Level, double Stime, int NsampPTrial);
    UEpochs(const UEpochs& Eps);
    UEpochs(const UEpochs& eps, int NewNsampTrial);

    virtual ~UEpochs();
    UEpochs&         operator= (const UEpochs &eps);
    bool             operator==(const UEpochs &eps) const;


/* Getting data from epochs */
    ErrorType        GetError(void)    const {return error;}
    const UString&   GetProperties(UString Comment) const;
    const char*      GetHistory(void) const;

    int              GetnSampTrial(void) const {if(this) return nSampTrial; return 0;}
    int              GetnEpochs(int ClassIndex=-1)  const;
    int              GetTotalSamples(int ClassIndex=-1)  const;
    const char*      GetEpochName(void) const {return EpochName;}

    UEvent           GetFirstBegin(void) const;
    UEvent           GetLastEnd(void) const;
    UEvent           GetBegin(int iep) const;
    UEvent           GetEnd(int iep)   const;
    int              GetBeginSample(int iep) const;
    int              GetEndSample(int iep) const;
    int              GetMidSample(int iep) const;
    int              GetNsamp(int iep) const;
    int              GetFirstEpoch(bool Begin) const;
    int              GetLastEpoch(bool Begin) const;
    int              GetClassIndex(int iep) const;
    int              GetEpochIndex(UEvent E, int* Offset=NULL) const;

    bool             AreEpochTimesEqual(const char* MarkerName=NULL) const;
    bool             AreEpochsInOneTrial(void) const;
    bool             IsOverlapping(UEvent B, UEvent E) const;
    bool             IsOverlapping(int iep, const UEpochs* EpTar, int iepTar) const;
    bool             IsInEpoch(int iep, UEvent Ev) const;
    bool             IsInEpoch(int iep, const UMarker* M) const;
    bool             IsInAnyEpoch(UEvent Ev) const;
    bool             IsInAnyEpoch(const UMarker* M, const int* Offset, int Noff) const;
    bool             AreEpochsContiguous(UEvent B, UEvent E, bool AllowOneSampleSkipped) const;
    bool             DoEpochsHaveGaps(UEvent B, UEvent E) const;

    bool             IsMarkerIsInDescriptor(int iep, const char* MarkerName) const;
    int              GetNMarkerIsInDescriptor(const char* MarkerName) const;
    int              GetFirstEpochIndex(const char* MarkerName) const;

    UEvent           GetEvent(int iep, int sample) const;
    UEvent           GetEventMergedEpochs(int sample) const;

    unsigned char*   GetIndicator(int Ntrial) const;
    ErrorType        LogProperties(const char* FileName=NULL) const;
    const char*      GetDescriptor(int iep) const;

    UFieldGraph*     GetEventsPerEpochAsFieldGraph(const UMarker* M, double Stime, int EpBin, int* NEpochsLeft, int NSegment) const;
    UMarker*         ConvertGraphToMarkers(const UFieldGraph* Graph) const;


/* Manipulating epochs */
    ErrorType        SetnEpochs(int nEp);    
    ErrorType        SetBegin(int iep, UEvent ev);
    ErrorType        SetEnd(int iep, UEvent ev);
    ErrorType        SetClassIndex(int iep, int ClassIndex);
    ErrorType        SetDescriptor(int iep, const char* Descr);
 
    ErrorType        SetEpoch(int iep, UEvent B, UEvent E, int ClassIndex=-1, const char* Descr = NULL);
    ErrorType        RemoveEpoch(int iep);
    ErrorType        RemoveEpochs(int iep, int Nremove);
    ErrorType        AddEpoch(UEvent B, UEvent E, int ClassIndex=-1, const char* Descr = NULL);
    ErrorType        CopyEpoch(int iepTo, const UEpochs* EpFrom, int iepFrom, const UEvent* NewBegin=NULL, const UEvent* NewEnd=NULL); 
    
    ErrorType        MergeOverlapping(void);
    ErrorType        SortEpochs(void);
    ErrorType        Subsample(int Ntake, int Nphase);

    ErrorType        ForceEqualSize(int NsampEp, bool NsampAverage=true, bool ForcePower2=false);
    ErrorType        ForceEpochsInDataSet(int Ntrial);
    ErrorType        ExcludeOverlapping(void);
    ErrorType        ExcludeTrials(int starttrial, int endtrial);
    ErrorType        ExcludeEpochs(int startepoch, int endepoch);
    ErrorType        ExcludeEpochs(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername);
    ErrorType        ExcludeSamples(int BeginOffset, int EndOffset, const UMarkerArray* Mar, const char* markername);

    class UEpoch
    {
    public:
        UEpoch();
        UEpoch(const UEpoch& e);
        UEpoch(UEvent B, UEvent E, int ClassInd, const char* Desript);
        ~UEpoch();
        UEpoch& operator=(const UEpoch& e);

        UEvent      GetBegin() const {return Begin;}
        UEvent      GetEnd()   const {return End;}
        UEvent      GetCenter(int NsampTrial) const;
        const char* GetDescriptor(void) const {return Descriptor;}
        int         GetClassIndex(void) const {return ClassIndex;}

        void        SetBegin(UEvent B) {Begin = B;}
        void        SetEnd(UEvent E) {End = E;}
        ErrorType   SetDescriptor(const char* Desript);
        void        SetClassIndex(int ClassInd) {ClassIndex = ClassInd;}

        int         GetNsamples(int nSampTrial) const;

    private:
        UEvent  Begin;
        UEvent  End;
        char*   Descriptor;
        int     ClassIndex;
    };

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;                   // General ERROR flag
    static UString      Properties;              // General Properties
    UString             History;                 // Global "history" of epochs creation and manipulation    
    UString             EpochName;               // Name of the epochs
    int                 nEpochs;                 // Number of valid epochs
    int                 nEpochsAlloc;            // Number of allocated epochs
    UEpoch*             Ep;                      // An Array of nEpochs epochs
    int                 nSampTrial;              // The number of samples per trial           

    bool                MergeOverlapping(UEpoch*E1, UEpoch*E2) const;
    ErrorType           AddToHistory(const char* String);
    ErrorType           ReAllocateMemory(void);
};

#endif //_EPOCHS_INCLUDED
