/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for maintaining an Euler transform, C++ version.                   */
/*     An Euler transform is a combination of a rotation and a translation.      */
/*                                                                               */
/*     UEuler-objects can be created in different ways, multiplied, inverted and */
/*     the can be used to transform objects (UVector3, UDipole, USensor) into    */
/*     displaced ones. UEuler objects are usefull, eg. when working with         */
/*     different coordinate systems.                                             */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    20-02-97   creation
  Jdm    27-01-98   separated Euler and Grid -parts
  Jdm    04-03-98   added PrintParameters() function
  Jdm    26-03-98   added Conversion to Nasion Ear System
  Jdm    26-03-98   added PrintMatrix()
  Jdm    26-03-98   added Constructor that reads data from AVS .fld-file.
                    Invert() returns *this instead of void
  Jdm    25-09-98   Format of PrintParameters() : one string without \n
  JdM    08-10-98   separated include-files
  JdM    17-12-98   Added WriteXDR()
  JdM    28-12-98   Use INTEL_byte_ORDER() in WriteXDR()
                    Added more detailed comments
  JdM    24-02-99   Added assignment operator, added GetParameters()
  JdM    18-03-99   Omit obsolete variable _maxtra and _maxrot. Changed interface to Randomize()
  JdM    06-06-99   End of File test when reading .xdr-file
  JdM    30-07-99   UEuler(Left, Right, Nasion) : Set unit matrix in case of co-linear points
  JdM    18-08-99   Added PrintParameters() in WriteXDR()
  JdM    23-08-99   Added a new constructor 
  JdM    12-11-99   Add GetAxis() and RotCompare()
  JdM    18-11-99   Added SetRotMatrix()
  JdM    25-11-99   Added Inverse()
  JdM    30-05-00   Bug Fix in GetAxis().
  JdM    20-06-00   WriteXDR(). Export rotation axis and angle.
  JdM    02-10-00   Added constructor (CT gantry tilt correction)
  JdM    09-11-00   Made a few parameters const
  JdM    01-02-01   Move UEuler::xfm() from Euler.cpp to Sensor.cpp
  JdM    08-02-01   Added definition of the transform of an UDipole()
  JdM    11-02-01   Implemented GetProperties()
  JdM    22-10-01   WriteXDR(): Export matrix in comment
                    Added Mirror()
                    Bug fix: GetParameters(). Case _mat[0]==_mat[1]==0
  JdM    23-10-01   Added a new constructor 
                    Bug Fix in GetAxis()
  JdM    28-05-02   Added operator==()
  JdM    08-10-02   BUG FIX: NLR constructor. Testing for co-linearity. Use outer product
  JdM    13-10-02   Add xfmInv()
  JdM    04-11-02   Made UEuler a friend of ULinTran
  JdM    29-11-02   Added a ULinTran()-based constructor
  JdM    12-02-03   Added operator!=()
  JdM    04-07-03   PrintMatrix(). Changed format.
  JdM    19-12-03   bug fix: WriteXDR() nspace=2 (not 3)
  JdM    17-10-04   Added Error messages in file constructor
  JdM    26-08-05   Added another SetRotMatrix()
  JdM    04-09-09   Added SetShift()
  JdM    17-01-10   Added SetRotMatrix().
                    Renamed Inverse() as GetInverse()
  JdM    16-07-10   Added SetNLR_FIFF() and SetNLR_CTF()
  JdM    14-10-10   GetAxis(): new (tested) algorithm.
  JdM    25-06-11   Added another operator*()
  JdM    18-08-12   Added a mirror-contructor
  JdM    19-07-13   Added WriteMatLab
  JdM    25-09-13   Filename constructor. Test for "# AVS" and if not present, read as text file
  JdM    15-07-14   Added new rotation constructor (9 doubles)
  FaB    24-10-14   Added new rotation and translation constructor (12 doubles)
  JdM    28-11-14   Randomize(). Test positivity of arguments.
  FaB    16-12-14   Filename constructor can now read .mat files (transformation matrices created by FSL)
  JdM    04-02-15   Added copy constructor.
  JdM    16-12-15   Added GetTransNoShift()
*/

#include <stdlib.h>
#include <string.h>

#include "Euler.h"
#include "LinTran.h"
#include "Sensor.h"
               
UEuler::UEuler()
/*
    The default UEuler is the unity transform: no rotations and no translations.
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
}

UEuler::UEuler(int dir)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UEuler::UEuler(). Invalid direction parameter, dir = %d .\n", dir);
        return;
    }
    Mirror(dir);
}
UEuler::UEuler(double r00, double r01, double r02, double r10, double r11, double r12, double r20, double r21, double r22)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(SetRotMatrix(UVector3(r00,r01,r02), UVector3(r10,r11,r12), UVector3(r20,r21,r22))!=U_OK)
    {
        CI.AddToLog("ERROR: UEuler::UEuler(). Invalid rotation parameters .\n");
        return;
    }
}

UEuler::UEuler(double r00, double r01, double r02, double r10, double r11, double r12, double r20, double r21, double r22, double tx, double ty, double tz)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] = 0;
    _mat[12] = tx;
    _mat[13] = ty;
    _mat[14] = tz;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(SetRotMatrix(UVector3(r00,r01,r02), UVector3(r10,r11,r12), UVector3(r20,r21,r22))!=U_OK)
    {
        CI.AddToLog("ERROR: UEuler::UEuler(). Invalid rotation parameters .\n");
        return;
    }
}

UEuler::UEuler(double tx, double ty, double tz, double rx, double ry, double rz)
/*
   Set the UEuler transform matrix (16 doubles) for given rotation and 
   translation parameters.

   Note: rotation angles are in radians.
 */
{
    _mat[0]  =  cos(rz)*cos(ry);
    _mat[1]  =  sin(rz)*cos(ry);
    _mat[2]  =  sin(ry);
    _mat[3]  =  0.;
    _mat[4]  = -cos(rz)*sin(ry)*sin(rx)-sin(rz)*cos(rx);
    _mat[5]  = -sin(rz)*sin(ry)*sin(rx)+cos(rx)*cos(rz);
    _mat[6]  =  cos(ry)*sin(rx);  
    _mat[7]  =  0.;
    _mat[8]  = -cos(rz)*sin(ry)*cos(rx)+sin(rz)*sin(rx);
    _mat[9]  = -sin(rz)*sin(ry)*cos(rx)-cos(rz)*sin(rx);
    _mat[10] =  cos(ry)*cos(rx);
    _mat[11] =  0.;
    _mat[12] =  tx;
    _mat[13] =  ty;
    _mat[14] =  tz;
    _mat[15] =  1.;
}

UEuler::UEuler(const UVector3& Axis, double Angle)
/*
    Set the Euler transform consisting of a rotation over Angle radians,
    about the axis Axis
 */
{
    UVector3 n = Axis;      n.Normalize();

    double u   = n.Getx();
    double v   = n.Gety();
    double w   = n.Getz();

    double cf  = cos(Angle);
    double cf1 = 1-cf;
    double sf  = sin(Angle);
    _mat[0]    =    cf + u*u*cf1;
    _mat[1]    =  w*sf + u*v*cf1;
    _mat[2]    = -v*sf + u*w*cf1;
    _mat[3]    =  0.;
    _mat[4]    = -w*sf + v*u*cf1;
    _mat[5]    =    cf + v*v*cf1;
    _mat[6]    =  u*sf + v*w*cf1;  
    _mat[7]    =  0.;
    _mat[8]    =  v*sf + w*u*cf1;
    _mat[9]    = -u*sf + w*v*cf1;
    _mat[10]   =    cf + w*w*cf1;
    _mat[11]   =  0.;  // Shift is 0
    _mat[12]   =  0.;
    _mat[13]   =  0.;
    _mat[14]   =  0.;
    _mat[15]   =  1.;
}

UEuler::UEuler(const UVector3& Shift)
/*
    Create an Euler transform consisting of a pure translation
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    _mat[12] =  Shift.Getx();
    _mat[13] =  Shift.Gety();
    _mat[14] =  Shift.Getz();
}

UEuler::UEuler(const UVector3& Nasion, const UVector3& Left, const UVector3& Right)
{
    if(SetNLR_CTF(Nasion, Left, Right)!=U_OK)
        CI.AddToLog("ERROR: UEuler::UEuler(). co-linear points. \n");
}

UEuler::UEuler(const char* FileName)
/*
    Initialize EulerXfm by reading data from AVS5 .fld-file.
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(FileName==NULL) return;
    FILE *fp=fopen(FileName,"rb");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UEuler::UEuler(). Cannot open: %s \n", FileName);
        return;
    }
    char line[200];
    fread(line, 1, sizeof(line), fp);
    rewind(fp);
    if(!strncmp(line, "# AVS", sizeof("# AVS")-1))
    {
        char cp1 = getc(fp);
        char cp2 = getc(fp);
        while(cp1!=12 || cp2!=12)
        {
            cp1 = cp2;
            cp2 = char(getc(fp));
            if(cp2==EOF)
            {
                CI.AddToLog("ERROR: UEuler::UEuler(). Erroneous xdr-file : %s",FileName);
                return;
            }
        }

        if(INTEL_PROCESSOR()==true)
        {
            for(int k=0; k<16; k++)
            {
                unsigned char sw[4], dum;
                fread((void*)sw, 4, 1, fp);
                dum     = sw[3];
                sw[3]   = sw[0];
                sw[0]   = dum;
                dum     = sw[2];
                sw[2]   = sw[1];
                sw[1]   = dum;
                _mat[k] = *(float*)sw;
            }
        }
        else
        {
            for(int k=0; k<16; k++)
            {
                float elem;
                fread(&elem, 1, 4, fp);
                _mat[k] = elem;
            }
        }
        fclose(fp);
        return;
    }

    bool      CaseSense = true;
    if(UFileName(FileName).HasExtension("mat", CaseSense)) // FSL .mat files
    {
        ErrorType E  = U_OK;

        for(int i=0; i<3; i++)
        {
            GetLine(line, sizeof(line)-1, fp);
            UString S(line);
            for(int j=0, off=0; j<4; j++)
            {
                int       nc   = 0;
                double    Elem = S.GetDouble(off, 1000., &E, &nc);                
                if( (j<3 && fabs(Elem)>1.) || E!=U_OK)
                {
                    CI.AddToLog("ERROR: UEuler::UEuler(). Reading transform as text file (i=%d, j=%d, elem=%f)\n", i, j, Elem);
                    break;
                }
                off += nc;
                if (j<3)   _mat[4*j+i] = Elem;
                else       _mat[4*j+i] = Elem/10.;
            }
            if(E!=U_OK) break;
        }
    }
    else /* Read as text file */
    {
        ErrorType E  = U_OK;
        for(int i=0; i<3; i++)
        {
            GetLine(line, sizeof(line)-1, fp);
            UString S(line);
            for(int j=0, off=0; j<4; j++)
            {
                int       nc   = 0;
                double    Elem = S.GetDouble(off, 1000., &E, &nc);                
                if( (j<3 && fabs(Elem)>1.) || E!=U_OK)
                {
                    CI.AddToLog("ERROR: UEuler::UEuler(). Reading transform as text file (i=%d, j=%d, elem=%f)\n", i, j, Elem);
                    break;
                }
                off += nc;
                _mat[4*i+j] = Elem;
            }
            if(E!=U_OK) break;
        }
    }
    fclose(fp);
}

UEuler::UEuler(double SkewNess)
/*
    Create a skewness transform, used for CT gantry tilts.
    Note, with this constructor, the UEuler is not a pure combination
          of rotations and translations!
 */
{
    _mat[ 0] =  cos(SkewNess);
    _mat[ 1] = -sin(SkewNess);
    _mat[ 2] = 0.;
    _mat[ 3] = 0.;
    _mat[ 4] = 0.;
    _mat[ 5] = 1.;
    _mat[ 6] = 0.;
    _mat[ 7] = 0.;
    _mat[ 8] = 0.;
    _mat[ 9] = 0.;
    _mat[10] = 1.;
    _mat[11] = 0.;
    _mat[12] = 0.;
    _mat[13] = 0.;
    _mat[14] = 0.;
    _mat[15] = 1.;
}

UEuler::UEuler(const UEuler& E)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
    if(&E==NULL) return;
    for(int k=0; k<16; k++) _mat[k] = E._mat[k];
}

UEuler::UEuler(const ULinTran& L)
/*
    Copy the matrix part of L to *this.

    Note: The use of this constructor may yield inconsistencies,
          when L does not consist of pure rotations and translations.
          However, matrix multiplicatio and inversion as well as the
          transformations of UVector3() objects remain valid.
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
    if(&L==NULL) return;
    for(int k=0; k<16; k++) _mat[k] = L._mat[k];
}

ErrorType UEuler::Mirror(int idir)
/* 
    Mirror the transformation in the direction idir
 */
{
    switch(idir)
    {
    case 0:
        _mat[ 0] = -_mat[ 0];
        _mat[ 4] = -_mat[ 4];
        _mat[ 8] = -_mat[ 8];
        _mat[12] = -_mat[12];
        return U_OK;
    case 1:
        _mat[ 1] = -_mat[ 1];
        _mat[ 5] = -_mat[ 5];
        _mat[ 9] = -_mat[ 9];
        _mat[13] = -_mat[13];
        return U_OK;
    case 2:
        _mat[ 2] = -_mat[ 2];
        _mat[ 6] = -_mat[ 6];
        _mat[10] = -_mat[10];
        _mat[14] = -_mat[14];
        return U_OK;
    }    
    CI.AddToLog("ERROR: UEuler::Mirror(). Erroneous input parameter (%d) .\n",idir);
    return U_ERROR;
}


UEuler UEuler::operator*(const UEuler& b) const
/*   
     Return *this *  b
 */
{
    UEuler result;

    int ij=0;
    for(int i=0; i<4; i++)
        for(int j=0; j<4; j++,ij++)
        {
            result._mat[ij] = 0;
            for(int k=0;k<4;k++) result._mat[4*i+j] += _mat[4*k+j]*b._mat[4*i+k];
        }

    return result;
}

ULinTran UEuler::operator*(const ULinTran& l) const
/*   
     Return *this *  b
 */
{
    ULinTran result;

    int ij=0;
    for(int i=0; i<4; i++)
        for(int j=0; j<4; j++,ij++)
        {
            result._mat[ij] = 0;
            for(int k=0;k<4;k++) result._mat[4*i+j] += _mat[4*k+j]*l._mat[4*i+k];
        }

    return result;
}

UEuler& UEuler::operator=(const UEuler& e)
{
    for(int k=0; k<16; k++) _mat[k] = e._mat[k];
    return *this;
}

bool UEuler::operator==(const UEuler& e) const
{
    const double TOL = 1.e-6;
    for(int ij=0; ij<16; ij++) 
        if(fabs(_mat[ij]-e._mat[ij])>TOL) return false;

    return true;
}

bool UEuler::operator!=(const UEuler& e) const
{
    if(*this == e) return false;
    else           return true;
}

ErrorType UEuler::SetNLR_CTF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right)
/*
     Set the Euler transform in such a way that it transforms a point to the Nasion-Left-Right
     system. In that system, the origin lays halfway between left and right ears, the x-axis points
     to the nasion and the left ear points, as good as possible in the direction of the y-axis.
     The z-axis is perpendicular to these axes.
 */
{
    if(this==NULL) return U_ERROR;
    
    if(fabs( ((Left-Nasion)^(Right-Nasion)).GetNorm()) <1.e-6) // Co-linear points
    {
        _mat[ 1] = _mat[ 2] = _mat[ 3] =
        _mat[ 4] = _mat[ 6] = _mat[ 7] =
        _mat[ 8] = _mat[ 9] = _mat[11] =
        _mat[12] = _mat[13] = _mat[14] = 0;
        _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
        CI.AddToLog("ERROR: UEuler::SetNLR_CTF(). Co-linear points. \n");
        return U_ERROR;
    }

    UVector3 Origin = .5*(Left + Right);
    UVector3 x = Nasion-Origin; 
    UVector3 y = x^(x^(Right-Origin)); 
    
    x.Normalize();
    y.Normalize();
    UVector3 z = x^y;

    _mat[0]  =  x.Getx();
    _mat[1]  =  y.Getx();
    _mat[2]  =  z.Getx();
    _mat[3]  =  0.;
    _mat[4]  =  x.Gety();     
    _mat[5]  =  y.Gety();     
    _mat[6]  =  z.Gety();     
    _mat[7]  =  0.;
    _mat[8]  =  x.Getz();  
    _mat[9]  =  y.Getz();  
    _mat[10] =  z.Getz();  
    _mat[11] =  0.;

    _mat[12] =  -Origin.Getx() *_mat[0] - Origin.Gety() *_mat[4] - Origin.Getz() *_mat[ 8]; 
    _mat[13] =  -Origin.Getx() *_mat[1] - Origin.Gety() *_mat[5] - Origin.Getz() *_mat[ 9]; 
    _mat[14] =  -Origin.Getx() *_mat[2] - Origin.Gety() *_mat[6] - Origin.Getz() *_mat[10]; 
    _mat[15] =  1.;    

    return U_OK;
}
ErrorType UEuler::SetNLR_FIFF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right)
{
    if(this==NULL) return U_ERROR;
    
    if(fabs( ((Left-Nasion)^(Right-Nasion)).GetNorm()) <1.e-6) // Co-linear points
    {
        _mat[ 1] = _mat[ 2] = _mat[ 3] =
        _mat[ 4] = _mat[ 6] = _mat[ 7] =
        _mat[ 8] = _mat[ 9] = _mat[11] =
        _mat[12] = _mat[13] = _mat[14] = 0;
        _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
        CI.AddToLog("ERROR: UEuler::SetNLR_FIFF(). Co-linear points. \n");
        return U_ERROR;
    }

    UVector3 x =  Right-Left               ; x.Normalize();
    UVector3 z = (Right-Left)^(Nasion-Left); z.Normalize();
    UVector3 y = z^x;

    double   Lamda  = (Nasion-Left)&x;
    UVector3 Origin = Left + Lamda*x;


    _mat[0]  =  x.Getx();
    _mat[1]  =  y.Getx();
    _mat[2]  =  z.Getx();
    _mat[3]  =  0.;
    _mat[4]  =  x.Gety();     
    _mat[5]  =  y.Gety();     
    _mat[6]  =  z.Gety();     
    _mat[7]  =  0.;
    _mat[8]  =  x.Getz();  
    _mat[9]  =  y.Getz();  
    _mat[10] =  z.Getz();  
    _mat[11] =  0.;

    _mat[12] =  -Origin.Getx() *_mat[0] - Origin.Gety() *_mat[4] - Origin.Getz() *_mat[ 8]; 
    _mat[13] =  -Origin.Getx() *_mat[1] - Origin.Gety() *_mat[5] - Origin.Getz() *_mat[ 9]; 
    _mat[14] =  -Origin.Getx() *_mat[2] - Origin.Gety() *_mat[6] - Origin.Getz() *_mat[10]; 
    _mat[15] =  1.;  
    
    return U_OK;
}

ErrorType UEuler::SetShift(UVector3 S)
{
    if(this==NULL) return U_ERROR;
    _mat[12] =  S.Getx();
    _mat[13] =  S.Gety();
    _mat[14] =  S.Getz();
    return U_OK;
}
UEuler UEuler::GetTransNoShift() const
{
    UEuler NoS = *this;
    NoS._mat[12] = NoS._mat[13] = NoS._mat[14] = 0;
    return NoS;
}
ErrorType UEuler::SetRotMatrix(UVector3 Ex, UVector3 Ey, UVector3 Ez)
/*
   Set rotation matrix such that xfm(1,0,0) == Ex, xfm(0,1,0) == Ey and xfm(0,0,1) == Ez
 */
{
    const double EPS  = 1.E-3;
    const double EPS4 = 1.E-12;
    if(this==NULL) return U_ERROR;
    
    if(Ex.Normalize()<EPS4 || Ey.Normalize()<EPS4 || Ez.Normalize()<EPS4)
    {
        CI.AddToLog("ERROR: UEuler::SetRotMatrix(). null vector argument. \n");
        return U_ERROR;
    }
    double xy = Ex&Ey;
    double yz = Ey&Ez;
    double zx = Ez&Ex;
    if( fabs(xy)>EPS || fabs(yz)>EPS || fabs(zx)>EPS)
        CI.AddToLog("WARNING: UEuler::SetRotMatrix(). Vector arguments not ortogonal. \n");
    
    _mat[ 0] = Ex.Getx();
    _mat[ 1] = Ex.Gety();
    _mat[ 2] = Ex.Getz();
    _mat[ 4] = Ey.Getx();
    _mat[ 5] = Ey.Gety();
    _mat[ 6] = Ey.Getz();
    _mat[ 8] = Ez.Getx();
    _mat[ 9] = Ez.Gety();
    _mat[10] = Ez.Getz();

    return U_OK;
}
ErrorType UEuler::SetRotMatrix(const float* Ex, const float* Ey, const float* Ez)
{
    if(this==NULL) return U_ERROR;
    if(Ex==NULL || Ey==NULL || Ez==NULL)
    {
        CI.AddToLog("ERROR: UEuler::SetRotMatrix(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    return SetRotMatrix(UVector3(Ex), UVector3(Ey), UVector3(Ez));
}
ErrorType UEuler::SetRotMatrix(const double* Ex, const double* Ey, const double* Ez)
{
    if(this==NULL) return U_ERROR;
    if(Ex==NULL || Ey==NULL || Ez==NULL)
    {
        CI.AddToLog("ERROR: UEuler::SetRotMatrix(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    return SetRotMatrix(UVector3(Ex), UVector3(Ey), UVector3(Ez));
}

ErrorType UEuler::SetRotMatrix(const double* r)
{
    if(this==NULL) return U_ERROR;
    if(r==NULL) 
    {
        CI.AddToLog("ERROR: UEuler::SetRotMatrix(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }

    _mat[0]  =  r[0];
    _mat[1]  =  r[1];
    _mat[2]  =  r[2];
    _mat[4]  =  r[3];
    _mat[5]  =  r[4];
    _mat[6]  =  r[5];
    _mat[8]  =  r[6];
    _mat[9]  =  r[7];
    _mat[10] =  r[8];
    return U_OK;
}

ErrorType UEuler::SetRotMatrix(const float* r)
{
    if(this==NULL) return U_ERROR;
    if(r==NULL) 
    {
        CI.AddToLog("ERROR: UEuler::SetRotMatrix(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }

    _mat[0]  =  r[0];
    _mat[1]  =  r[1];
    _mat[2]  =  r[2];
    _mat[4]  =  r[3];;     
    _mat[5]  =  r[4];
    _mat[6]  =  r[5];
    _mat[8]  =  r[6];
    _mat[9]  =  r[7];
    _mat[10] =  r[8];
    return U_OK;
}

double UEuler::TotalTrans()
/*
     return the modulus of the total translation vector.
 */
{
    return sqrt(_mat[12]*_mat[12] + _mat[13]*_mat[13] + _mat[14]*_mat[14]);
}

double UEuler::TotalRot(bool radian) const
/*
     return the total rotation angle (about the symmetry line)
 */
{
    double cosin = (_mat[0] + _mat[5] + _mat[10] -1.)/2.;

    if(cosin<=-1.) cosin = -1.;
    if(cosin>= 1.) cosin =  1.;

    if(radian)
        return acos(cosin);
    else
        return 180*acos(cosin)/PI;
}

UEuler UEuler::GetInverse(void) const
/* 
    return the inverse of *this
 */
{
    UEuler Inv = *this;
    Inv.Invert();
    return Inv;
}

UEuler UEuler::Invert(void)
/*
     Replace the Euler transform by its inverse, return *this.
 */
{
    double det = _mat[ 0]*_mat[ 5]*_mat[10] + _mat[ 4]*_mat[ 9]*_mat[ 2] + _mat[ 8]*_mat[ 1]*_mat[ 6] 
               - _mat[ 0]*_mat[ 9]*_mat[ 6] - _mat[ 4]*_mat[ 1]*_mat[10] - _mat[ 8]*_mat[ 5]*_mat[ 2];

    if(fabs(det)<1.e-10) det = 1;

    double inv[16];
    inv[ 0] = ( _mat[ 5]*_mat[10] - _mat[ 9]*_mat[ 6])/det;
    inv[ 1] = ( _mat[ 9]*_mat[ 2] - _mat[ 1]*_mat[10])/det;
    inv[ 2] = ( _mat[ 1]*_mat[ 6] - _mat[ 5]*_mat[ 2])/det;
    inv[ 3] = 0.;
    inv[ 4] = ( _mat[ 6]*_mat[ 8] - _mat[10]*_mat[ 4])/det;
    inv[ 5] = ( _mat[10]*_mat[ 0] - _mat[ 2]*_mat[ 8])/det;
    inv[ 6] = ( _mat[ 2]*_mat[ 4] - _mat[ 0]*_mat[ 6])/det;
    inv[ 7] = 0.;
    inv[ 8] = ( _mat[ 4]*_mat[ 9] - _mat[ 8]*_mat[ 5])/det;
    inv[ 9] = ( _mat[ 8]*_mat[ 1] - _mat[ 0]*_mat[ 9])/det;
    inv[10] = ( _mat[ 0]*_mat[ 5] - _mat[ 4]*_mat[ 1])/det;
    inv[11] = 0.;
    inv[12] =-( inv[ 0]*_mat[12] + inv[ 4]*_mat[13] + inv[ 8]*_mat[14] );
    inv[13] =-( inv[ 1]*_mat[12] + inv[ 5]*_mat[13] + inv[ 9]*_mat[14] );
    inv[14] =-( inv[ 2]*_mat[12] + inv[ 6]*_mat[13] + inv[10]*_mat[14] );
    inv[15] = 1.;

    for(int k=0; k<16; k++) _mat[k] = inv[k];
    return *this;
}

UEuler UEuler::Randomize(double Maxtrans, double MaxRot)
/*
    Return a random Euler transformation with maximum translation MaxTrans,
    and maximum rotation MaxRot.
 */
{
    double tx=0, ty=0, tz=0, rx=0, ry=0, rz=0;

    if(Maxtrans>0)
        while(1)
        {
            tx = Maxtrans*( -1.+ 2.*rand()/(double) RAND_MAX );
            ty = Maxtrans*( -1.+ 2.*rand()/(double) RAND_MAX );
            tz = Maxtrans*( -1.+ 2.*rand()/(double) RAND_MAX );
            if(tx*tx + ty*ty + tz*tz < Maxtrans*Maxtrans) break;
        }
    
    if(MaxRot>0)
        while(1)
        {                    
            rx = MaxRot*( -1.+ 2.*rand()/(double) RAND_MAX );
            ry = MaxRot*( -1.+ 2.*rand()/(double) RAND_MAX );
            rz = MaxRot*( -1.+ 2.*rand()/(double) RAND_MAX );

            _mat[0]  =  cos(rz)*cos(ry);                            //diagonal elements
            _mat[5]  = -sin(rz)*sin(ry)*sin(rx)+cos(rx)*cos(rz);
            _mat[10] =  cos(ry)*cos(rx);

            double omeg  =  fabs( acos (.5*(_mat[0]+_mat[5]+_mat[10] -1.)));
            if(omeg>PI) omeg = PI-omeg;
            if(omeg<MaxRot) break;
        }

    _mat[1]  =  sin(rz)*cos(ry);
    _mat[2]  =  sin(ry);
    _mat[3]  =  0.;
    _mat[4]  = -cos(rz)*sin(ry)*sin(rx)-sin(rz)*cos(rx);
    _mat[6]  =  cos(ry)*sin(rx);  
    _mat[7]  =  0.;
    _mat[8]  = -cos(rz)*sin(ry)*cos(rx)+sin(rz)*sin(rx);
    _mat[9]  = -sin(rz)*sin(ry)*cos(rx)-cos(rz)*sin(rx);
    _mat[11] =  0.;
    _mat[12] =  tx;
    _mat[13] =  ty;
    _mat[14] =  tz;
    _mat[15] =  1.;

    return *this;
}


USensor UEuler::xfm(const USensor &v) const
/*
     return a transformed sensor.
 */
{
    USensor s = v;
    s.Setx( xfm(v.Getx()      ));
    s.Setc( xfm(v.Getc()      ));
    s.Setn( xfm(v.Getn(), true));

    s.SetStype(v.GetStype());
    s.SetName(v.GetName());

    return s;
}

UVector3 UEuler::xfm(const UVector3 &v, bool Notrans) const
/*
     return a transformed vector.
 */
{
    double xa,ya,za;
    if(Notrans==true)
    {
        xa = v.Getx() *_mat[0] +  v.Gety() *_mat[4] +  v.Getz() *_mat[ 8];
        ya = v.Getx() *_mat[1] +  v.Gety() *_mat[5] +  v.Getz() *_mat[ 9];
        za = v.Getx() *_mat[2] +  v.Gety() *_mat[6] +  v.Getz() *_mat[10];
    }
    else
    {
        xa = v.Getx() *_mat[0] +  v.Gety() *_mat[4] +  v.Getz() *_mat[ 8] + _mat[12];
        ya = v.Getx() *_mat[1] +  v.Gety() *_mat[5] +  v.Getz() *_mat[ 9] + _mat[13];
        za = v.Getx() *_mat[2] +  v.Gety() *_mat[6] +  v.Getz() *_mat[10] + _mat[14];
    }
    
    return UVector3(xa,ya,za);
}

UVector3 UEuler::xfmInv(const UVector3 &v, bool Notrans) const
/*
   Return the inverse of *this applied to v.
 */
{
    UEuler INV = this->GetInverse();
    return INV.xfm(v, Notrans);
}

ErrorType UEuler::GetParameters(double *par) const
/*
    Export the current values of the Euler transform parameters in the
    double array par[] (six values).
    If there are no pure rotations and translations return U_ERROR 
    else return U_OK

    Note: rotation angles are in radians.
          the order of the parameters is: tx, ty, tz, rx, ry, rz

 */
{
    if(par==NULL) return U_ERROR;

    const double TOL=5.e-4;

    double rx,ry,rz;
  
    if(_mat[0]==0. && _mat[1]==0.)
    {
        if(_mat[2]>0) ry =  PI/2.;  // BUG fix 22-10-2001 test _mat[2]
        else          ry = -PI/2.;

        rx = 0.;     /* arbitrary value. */
        if(_mat[4]==0. && _mat[5]==0.) return U_ERROR;
        rz = atan2(-_mat[4],_mat[5]);
    }
    else
    {
        rz = atan2(_mat[1],_mat[0]);
        if(_mat[6]==0. && _mat[10]==0.) return U_ERROR;
       
        rx = atan2(_mat[6],_mat[10]);
        
        if(fabs(cos(rz))<.7071)
            ry = atan2(_mat[2],_mat[1]/sin(rz));        
        else
            ry = atan2(_mat[2],_mat[0]/cos(rz));        
    }
        
/* take smallest possible angles */
    if(rx >  PI) rx -= 2*PI;
    if(ry >  PI) ry -= 2*PI;
    if(rz >  PI) rz -= 2*PI;
    if(rx < -PI) rx += 2*PI;
    if(ry < -PI) ry += 2*PI;
    if(rz < -PI) rz += 2*PI;
        
    if(fabs(rx   )+fabs(ry   )+fabs(rz   ) >
       fabs(rx-PI)+fabs(PI-ry)+fabs(rz-PI) )
    {
       rx = rx-PI;
       ry = PI-ry;
       rz = rz-PI;
    }
    
    if(rx >  PI) rx -= 2*PI;
    if(ry >  PI) ry -= 2*PI;
    if(rz >  PI) rz -= 2*PI;
    if(rx < -PI) rx += 2*PI;
    if(ry < -PI) ry += 2*PI;
    if(rz < -PI) rz += 2*PI;

/* Test the result:*/
    double cx = cos(rx); 
    double sx = sin(rx); 
    double cy = cos(ry); 
    double sy = sin(ry); 
    double cz = cos(rz); 
    double sz = sin(rz); 
    if( fabs(  cz*cy          -_mat[ 0]) > TOL)  return U_ERROR;
    if( fabs(  sz*cy          -_mat[ 1]) > TOL)  return U_ERROR;
    if( fabs(  sy             -_mat[ 2]) > TOL)  return U_ERROR;
    if( fabs( -cz*sy*sx-sz*cx -_mat[ 4]) > TOL)  return U_ERROR;
    if( fabs( -sz*sy*sx+cx*cz -_mat[ 5]) > TOL)  return U_ERROR;
    if( fabs(  cy*sx          -_mat[ 6]) > TOL)  return U_ERROR;
    if( fabs( -cz*sy*cx+sz*sx -_mat[ 8]) > TOL)  return U_ERROR;
    if( fabs( -sz*sy*cx-cz*sx -_mat[ 9]) > TOL)  return U_ERROR;
    if( fabs(  cy*cx          -_mat[10]) > TOL)  return U_ERROR;

    par[0] = _mat[12];
    par[1] = _mat[13];
    par[2] = _mat[14];
    par[3] = rx;
    par[4] = ry;
    par[5] = rz;
    return U_OK;
}

const char*  UEuler::PrintParameters(void) const
/*
    Export the current properties in text format.
 */
{
    static char line[200];
    memset(line, 0, sizeof(line));

    double par[6];
    if(GetParameters(par)==U_OK)
    {
        par[3] = 180*par[3]/PI;
        par[4] = 180*par[4]/PI;
        par[5] = 180*par[5]/PI;
        sprintf(line,"(rx,ry,rz) = (%8.3f,%8.3f,%8.3f) (tx,ty,tz) = (%8.3f,%8.3f,%8.3f) ", par[3],par[4],par[5],par[0],par[1],par[2]);
    }
    else
        sprintf(line,"ERROR: UEuler::PrintParameters(void). No pure rotations and translations.");

    return line;
}

#define MAXPROPERTIES 200
const char* UEuler::GetProperties(const char* Comment) const
{
    static char Properties[MAXPROPERTIES];
    char Begin[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,15);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties,0,MAXPROPERTIES);

    UVector3 Axi = GetAxis();
    double   Ang = TotalRot(false);

    int nc = 0;
    nc += sprintf(Properties+nc,"%s %s%c",Begin,PrintParameters(),End);    
    nc += sprintf(Properties+nc,"%s RotationAxis = %s; RotationAngle = %f%c",Begin,Axi.GetProperties(),Ang,End);
    
    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: UEuler::GetProperties(). Array overflow: nc=%d .\n",nc);

    return Properties;
}
#undef MAXPROPERTIES

const char*  UEuler::PrintMatrix(void) const
{
    static char line[200];
    memset(line, 0, sizeof(line));
    
    sprintf(line,"Rotation             Translation\n"
                 "%7.4f,%7.4f,%7.4f, %7.3f\n"
                 "%7.4f,%7.4f,%7.4f, %7.3f\n"
                 "%7.4f,%7.4f,%7.4f, %7.3f\n",
        _mat[0],_mat[4],_mat[ 8],_mat[12],
        _mat[1],_mat[5],_mat[ 9],_mat[13],
        _mat[2],_mat[6],_mat[10],_mat[14]);
    return line;
}

ErrorType UEuler::WriteMatLab(const char *FileName) const
{
    if(this==NULL || _mat==NULL)
    {
        CI.AddToLog("ERROR: UEuler::WriteMatLab(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(FileName==NULL)
    {
        CI.AddToLog("ERROR: UEuler::WriteMatLab(). Argument NULL.\n");
        return U_ERROR;
    }

    FILE* fp = fopen(FileName, "wt");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UEuler::WriteMatLab(). File cannot be opened: %s.\n", FileName);
        return U_ERROR;
    }

// Rotation, translation
    fprintf(fp,"%9.5f\t",_mat[0]);fprintf(fp,"%9.5f\t",_mat[4]);fprintf(fp,"%9.5f\t",_mat[ 8]);fprintf(fp,"%9.5f\n",_mat[12]);
    fprintf(fp,"%9.5f\t",_mat[1]);fprintf(fp,"%9.5f\t",_mat[5]);fprintf(fp,"%9.5f\t",_mat[ 9]);fprintf(fp,"%9.5f\n",_mat[13]);
    fprintf(fp,"%9.5f\t",_mat[2]);fprintf(fp,"%9.5f\t",_mat[6]);fprintf(fp,"%9.5f\t",_mat[10]);fprintf(fp,"%9.5f\n",_mat[14]);

    fclose(fp);
    return U_OK;
}


ErrorType UEuler::WriteXDR(const char *FileName) const
/*
      Export the Euler transform in AVS  xdr-format.
 */
{
    FILE *fp=fopen(FileName,"wb");
    if(fp==NULL) return U_ERROR;

    UVector3 Axi = GetAxis();
    double   Ang = TotalRot(false);
    fprintf(fp,"# AVS File created by an UEuler-object.\n");
    fprintf(fp,"%s",CI.GetProperties("# "));
    fprintf(fp,"# \n");
    fprintf(fp,"# %s\n",PrintParameters());
    fprintf(fp,"# RotationAxis = %s; RotationAngle = %f\n",Axi.GetProperties(),Ang);
    fprintf(fp,"# \n");
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 0],  _mat[ 1],  _mat[ 2],  _mat[ 3]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 4],  _mat[ 5],  _mat[ 6],  _mat[ 7]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 8],  _mat[ 9],  _mat[10],  _mat[11]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[12],  _mat[13],  _mat[14],  _mat[15]);
    fprintf(fp,"# \n");
    fprintf(fp,"ndim=2          # number of dimensions in the field\n");
    fprintf(fp,"dim1=4          # dimension of axis 1\n");
    fprintf(fp,"dim2=4          # dimension of axis 2\n");
    fprintf(fp,"nspace=2        # number of physical coordinates per point\n");
    fprintf(fp,"veclen=1        # number of components at each point\n");
    fprintf(fp,"data=xdr_float  # portable data format\n");
    fprintf(fp,"field=uniform   # field type (uniform, rectilinear, irregular)\n");
    fprintf(fp,"%c%c",12,12);


    if(INTEL_PROCESSOR()==true)
    {
        for(int k=0; k<16; k++) 
        {
            unsigned char sw[4], dum;
            float elem = float(_mat[k]);
            memcpy(sw, &elem , 4);
            dum     = sw[3];
            sw[3]   = sw[0];
            sw[0]   = dum;
            dum     = sw[2];
            sw[2]   = sw[1];
            sw[1]   = dum;
            fwrite((void*)sw, 4, 1, fp);
        }
    }
    else
    {
        for(int k=0; k<16; k++) 
        {
            float elem = float(_mat[k]);
            fwrite(&elem, 1, 4, fp);
        }
    }
    for(int k=0; k<6; k++) fwrite((void*)&k, 4, 1, fp);  // Coordinate information has no meaning, but must be present
    fclose(fp);

    return U_OK;
}

UVector3 UEuler::GetAxis(void) const
/*
     Return the rotation axis of the rotation part of the Euler transformation
     (= Eigen vector with eigenvalue 1).

     On error, return UVector3(0.,0.,0.)
 */
{
    double det = (_mat[ 0]-1)*(_mat[ 5]-1)*(_mat[10]-1) + _mat[ 4]*_mat[ 9]* _mat[ 2]    + _mat[ 8]* _mat[ 1]   *_mat[ 6] 
               - (_mat[ 0]-1)* _mat[ 9]    *_mat[ 6]    - _mat[ 4]*_mat[ 1]*(_mat[10]-1) - _mat[ 8]*(_mat[ 5]-1)*_mat[ 2];
 
    if(fabs(det)>1.e-5) 
    {
        CI.AddToLog("ERROR: UEuler::GetAxis(). Eigenvalue test failed (det = %f (should be 0.))\n", det);
        return UVector3(0.,0.,0.);  // There is no eigenvalue == 1.
    }

    double Som = sin(TotalRot(true));
    if(fabs(Som)<1.e-8) return UVector3(1.,0.,0.);
    
    double P[9] = { 0.            ,_mat[4]-_mat[1], _mat[8]-_mat[2],
                   _mat[1]-_mat[4], 0.            , _mat[9]-_mat[6],
                   _mat[2]-_mat[8],_mat[6]-_mat[9], 0.             };

    UVector3 Ax(-P[5]/(2*Som),P[2]/(2*Som),-P[1]/(2*Som));
        
    return Ax;
}

double UEuler::RotCompare(UEuler E) const
/*
    return the sum of squared differences between the rotation components
    of this transform and the transform E.
 */
{
    double result = 0.;
    for(int k=0; k<11; k++)
    {
        if(k==3 || k==7) continue;
        result += (_mat[k]-E._mat[k])*(_mat[k]-E._mat[k]);
    }
    return result;
}