#ifndef _EULER_INCLUDED
#define _EULER_INCLUDED

#include "MatVec.h"

class UDipole;
class USensor;
class ULinTran;

class DLL_IO UEuler
{
    friend class ULinTran;

public:
    UEuler();
    UEuler(int dir);
    UEuler(double tx, double ty, double tz, double rx, double ry, double rz);
    UEuler(double r00, double r01, double r02, double r10, double r11, double r12, double r20, double r21, double r22);
    UEuler(double r00, double r01, double r02, double r10, double r11, double r12, double r20, double r21, double r22, double tx, double ty, double tz);
    UEuler(const UVector3& Axis, double Angle);
    UEuler(const UVector3& Shift);
    UEuler(const UVector3& Nasion, const UVector3& Left, const UVector3& Right);
    UEuler(const char* FileName);
    UEuler(double SkewNess);
    UEuler(const UEuler& E);
    UEuler(const ULinTran& L);

    UEuler&          operator=(const UEuler& e);
    UEuler           operator*(const UEuler& e) const;
    ULinTran         operator*(const ULinTran& l) const;
    bool             operator==(const UEuler& e) const; 
    bool             operator!=(const UEuler& e) const; 

    double           TotalTrans();
    double           TotalRot(bool radian=true) const;
    ErrorType        GetParameters(double *par) const;

    ErrorType        Mirror(int idir);
    UEuler           GetInverse(void) const;
    UEuler           Invert(void);
    ErrorType        SetNLR_CTF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right);
    ErrorType        SetNLR_FIFF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right);

    ErrorType        SetRotMatrix(UVector3 Ex     , UVector3 Ey     , UVector3 Ez     );
    ErrorType        SetRotMatrix(const double* Ex, const double* Ey, const double* Ez);
    ErrorType        SetRotMatrix(const float * Ex, const float * Ey, const float * Ez);
    ErrorType        SetRotMatrix(const double* r);
    ErrorType        SetRotMatrix(const float*  r);
    ErrorType        SetShift(UVector3 S);
    UEuler           GetTransNoShift() const;

    USensor          xfm(const USensor &v) const;    
    UDipole          xfm(const UDipole &d) const;    
    UVector3         xfm(const UVector3 &v, bool Notrans=false) const;    
    UVector3         xfmInv(const UVector3 &v, bool Notrans=false) const;    
    
    const char*      PrintParameters(void) const;
    const char*      GetProperties(const char* Comment) const;
    const char*      PrintMatrix(void) const;
    ErrorType        WriteXDR(const char *FileName) const;
    ErrorType        WriteMatLab(const char *FileName) const;
    UEuler           Randomize(double Maxtrans, double MaxRot);
    UVector3         GetAxis(void) const;
    UVector3         GetTranslation(void) const {return UVector3(_mat[12], _mat[13], _mat[14]);}
    double           RotCompare(UEuler E) const;

private:
    double           _mat[16];
};
#endif// _EULER_INCLUDED
