/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*   Module to create and change an event, which is a single time point in a     */
/*   data file, with a certain trial number and sample number.                   */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    05-03-99   Creation
  JdM    16-03-99   Changed interface to GetNsamples().
  JdM    09-04-99   Added Center()
  JdM    16-04-99   Bug Fix in GetNsamples(), older versions did not work when Begin==End
  JdM    06-05-99   Bug Fix in ShiftEvent(), set correct trial and sample for negative absolute times
  JdM    12-08-99   Added operator==() and operator!=()
  JdM    27-08-99   Added IsOverlapping()
  JdM    06-10-00   Added IsEnclosing(), MergeOverlapping() and IsInEpoch()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    09-04-15   Renamed ShiftEvent() as GetShiftedEvent() and GetAbsSample() as GetAbsSample()
*/

#include "Event.h"

UEvent::UEvent()
{
    trial  = 0;
    sample = 0;
}

UEvent::UEvent(int it, int is)
{
    trial  = it;
    sample = is;
}

UEvent& UEvent::operator=(const UEvent &ev)
{
    trial  = ev.trial;
    sample = ev.sample;
    return *this;
}

bool UEvent::operator==(const UEvent &ev)
{
    if(trial==ev.trial && sample==ev.sample) return true;
    return false;
}

bool UEvent::operator!=(const UEvent &ev)
{
    if((*this==(ev)) == true) return false;
    return true;
}

UEvent UEvent::GetShiftedEvent(int Nshift, int NsampPTrial) const
/*
     return a UEvent-object, which is shifted Nshift samples w.r.t. *this.

      NsampPTrial is the number is samples per trial.
*/
{
    if(NsampPTrial<=0) return UEvent(-1,-1);

    int newtime  = GetAbsSample(NsampPTrial) + Nshift;  // The "absolute sample number"
    int newtrial = newtime/NsampPTrial;
    int newsamp  = newtime%NsampPTrial;
    if(newtime<0)
    {
        newtrial -= 1;
        newsamp  += NsampPTrial;
    }

    return UEvent(newtrial, newsamp);
}

int GetNsamples(UEvent Begin, UEvent End, int NsampPTrial)
/*
      return the number of samples between the events Begin and End.
      This number includes the sample corresponding to Begin and to End.
      If End occurs earlier than Begin, return minus the number of samples
      between End and Begin;

      NsampPTrial is the number is samples per trial, necessary to determine
      the number of samples, when Begin and End correspond to different trials.
 */
{
    int ib = Begin.GetAbsSample(NsampPTrial);
    int ie = End  .GetAbsSample(NsampPTrial);

    if(ib<=ie)  return  ie-ib+1;
    else        return-(ib-ie+1);
}

UEvent Center(UEvent Begin, UEvent End, int NsampPTrial)
/*
     Return the event which is positioned exactly between the Begin and End event.
 */
{
    int ib = Begin.GetAbsSample(NsampPTrial);
    int ie = End.GetAbsSample(NsampPTrial);
    int ic = (ib+ie)/2;

    return UEvent(ic/NsampPTrial, ic%NsampPTrial);
}

bool  IsOverlapping(UEvent B1, UEvent E1, UEvent B2, UEvent E2, int Nsamp)
/*
     Return true iff the interval (B1,E1) has an overlap with the interval (B2,E2)

     Note: It is not chequed, but implicitely assumed that, B1<=E1 and B2<=E2
 */
{
    if(E1.GetAbsSample(Nsamp)<B2.GetAbsSample(Nsamp)) return false;
    if(E2.GetAbsSample(Nsamp)<B1.GetAbsSample(Nsamp)) return false;

    return true;
}

bool  IsEnclosing(UEvent B1, UEvent E1, UEvent B2, UEvent E2, int Nsamp)
/*
     Return true iff the interval (B1,E1) encloses the interval (B2,E2)

     Note: It is not chequed, but implicitely assumed, that B1<=E1 and B2<=E2
 */
{
    if(B2.GetAbsSample(Nsamp)<B1.GetAbsSample(Nsamp) ) return false;
    if(E2.GetAbsSample(Nsamp)>E1.GetAbsSample(Nsamp) ) return false;

    return true;
}

bool   MergeOverlapping(UEvent* B1, UEvent* E1, UEvent* B2, UEvent* E2, int Nsamp)
/*
     if the intervals (*B1,*E1) and (*B2,*E2) overlap
        - replace both (*B1,*E1) and (*B2,*E2) with the merged intervals
        - return true
     else
        - do not change the intervals
        - return false
 */
{
    int sb1 = B1->GetAbsSample(Nsamp);
    int se1 = E1->GetAbsSample(Nsamp);
    int sb2 = B2->GetAbsSample(Nsamp);
    int se2 = E2->GetAbsSample(Nsamp);

    if(se1<sb2) return false;
    if(se2<sb1) return false;

    int sb = MIN(sb1,sb2);
    int se = MAX(se1,se2);
    *B1 = *B2 = UEvent(sb/Nsamp,sb%Nsamp);
    *E1 = *E2 = UEvent(se/Nsamp,se%Nsamp);

    return true;
}

bool   IsInEpoch(UEvent Begin, UEvent End, UEvent TestEvent, int Nsamp)
/*
    Return true iff the TestEvent is inside the epoch (Begin, End)
 */
{
    int sb = Begin.GetAbsSample(Nsamp);
    int se = End.GetAbsSample(Nsamp);
    int st = TestEvent.GetAbsSample(Nsamp);

    if(sb<=st && st<=se) return true;

    return false;
}

