#ifndef _EVENT_INCLUDED
#define _EVENT_INCLUDED

#include "BasicInclude.h"

class DLL_IO UEvent
{
public:
    UEvent();                            
    UEvent(int it, int is);              
    UEvent& operator=(const UEvent &ev); 

    bool     operator==(const UEvent &ev);
    bool     operator!=(const UEvent &ev);
    UEvent   GetShiftedEvent(int Nshift, int NsampPTrial)  const;
    int      GetAbsSample(int NsampPTrial)               const {return trial*NsampPTrial+sample;}
    
// public data members
    int      trial;    // The trial number of the event
    int      sample;   // The sample number of the event
};

int    DLL_IO GetNsamples(UEvent Begin, UEvent End, int NsampPTrial);
UEvent DLL_IO Center(UEvent Begin, UEvent End, int NsampPTrial);
bool   DLL_IO IsOverlapping(UEvent B1, UEvent E1, UEvent B2, UEvent E2, int Nsamp);
bool   DLL_IO IsEnclosing(UEvent B1, UEvent E1, UEvent B2, UEvent E2, int Nsamp);
bool   DLL_IO MergeOverlapping(UEvent* B1, UEvent* E1, UEvent* B2, UEvent* E2, int Nsamp);
bool   DLL_IO IsInEpoch(UEvent Begin, UEvent End, UEvent TestEvent, int Nsamp);

#endif //_EVENT_INCLUDED

