/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*   Module to manage an array of events, carrying the same name.                */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    18-12-00   Creation
  JdM    12-04-02   Added GetAbsSample()
  JdM    25-02-03   Add AddEvent() and the data member nEventsAlloc
  JdM    26-02-03   Add GetFirstEvent()
  JdM/SG 04-03-03   Added SetName()
  JdM    16-11-03   Added RedistributeTrials()
  JdM    05-12-03   RedistributeTrials(): Remove events with negative trial numbers
                    Added new RedistributeTrials()
  JdM    16-01-04   Add DeleteEvent()
  JdM    17-01-04   Added AddEquiDistantEvents()
SG/JdM   19-01-04   AddEquiDistantEvents(): sort the events after inserting new events
  JdM    12-02-04   Bug Fix: RedistributeTrials(). Testing whether all epochs are equal (true instead of U_OK)
  JdM    21-02-04   Added: DeleteEvents() and DeleteMiddleEvents()
  JdM    04-04-04   Added: GetFirstEventTime(), GetLastEventTime(), GetAverageTimeInterval()
  JdM    22-06-04   Added: SelectEvent()
  JdM    22-06-04   Added: GetIndex()
  JdM    03-11-04   Added: GetIntervalsText()
  JdM    06-11-04   Added: GetIntervalsSinCos() and AreEventsSortedIncr()
  JdM    20-11-04   Added: GetMinInterval()
  JdM    27-11-04   Added: GetMaxInterval() and GetProperties()
  JdM    29-01-04   Added: CopyToAllEpochs()
  JdM    06-04-05   Added  GetBeginShortestInterval(void) and GetBeginLongestInterval(void)
  JdM    07-04-05   Added GetShiftedEvent(), ShiftAllEvents() and StretchEvents()
  JdM    17-04-05   Added GetNMatchPerEpoch()
  JdM    01-05-05   Added operator==()
  FB     03-05-05   Added argument NSingleMatch in GetNMatchPerEpoch()
  JdM    08-11-05   Added another DeleteEvents(), based on BAD events
  JdM    10-11-05   Added Merge(), Made EventName a UString-object
  JdM    01-12-05   Added another GetIntervalsSinCos()
                    GetMinInterval(), GetMaxInterval(): copy *this, in case events are not sorted.
  JdM    20-12-05   Added DownSample()
  JdM    04-04-06   Added GetIntervalsEpoch()
  JdM    10-10-06   Added GetMedianInterval()
  JdM    11-10-06   GetProperties(), added GetMedianInterval()
                    Added: GetBeginDeviatingIntervals(), SetAllMembersDefault() and DeleteAllMembers();
  JdM    26-11-06   Added (new version of) DeleteEvents() and DeleteEventsEpoch()
                    Several functions return UFieldGraph, i.s.o. UField
                    Two parameters added to GetIntervalsEpoch().
  JdM    27-01-07   GetProperties(). Use static UString Properties
  JdM    18-02-07   Added CopyAllEventsToAllEpochs()
  JdM    23-06-07   Added SetEquiDistant()
                    Bug fix operator=() and copy-constructor. Test for NULL address argument.
  JdM    08-09-07   Added GetTimesFirstInEpoch()
  JdM    05-10-07   GetIntervalsEpoch(): added parameter
  JdM    23-05-08   Added GetName() (==GetEventName());
                    GetIntervalsSinCos() added NSegment parameter
  JdM    17-06-08   Bug fix GetIntervalsSinCos(). Make midsample a true mid sample (adding 0.5 to is)
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    17-09-08   Added GetEndShortestInterval() and GetEndLongestInterval()
  JdM    18-09-08   Added GetMaxIntervalChange() and GetLargestIntervalChange()
  JdM    21-10-08   Added GetIntervalsSeries()
  JdM    22-11-08   Added GetCrossMatrix()
  JdM    22-12-08   Added GetInEpochArray()
  JdM    23-12-08   Added GetCrossingBlockArray() and GetCrossingArray()
  JdM    03-01-09   Added ResampleData()
  JdM    20-01-09   Bug fix: GetCrossingBlockArray(). Assure symmetry
  JdM    29-08-09   Added another (FieldGraph selective) GetAverageTimeInterval()
  JdM    22-09-09   Added AddEvent()
  JdM    14-12-11   Bug FIX: GetMedianInterval(). Take samples from (sorted!) ThisCopy. 
  JdM    21-12-11   Added new version of GetMedianInterval(), with SubSet argument
  JdM    11-01-12   UEventArray::UEventArray(). Remove (char)12 and (char)13 from name
  JdM    29-02-12   GetIntervalsSinCos(). Use iharm==0 to compute phases (skip sin/cos)
  JdM    07-08-12   Added RedistributeTrials()
  JdM    08-11-13   Added PrependName()
  JdM    18-11-13   Bug Fix: RedistributeTrials(const UEpochs*, double, double). Set new nSampTrial = int( NewEpochs->GetNsamp(0) * (SRateNew/SRateOld) );
  JdM    19-01-14   GetIntervalsSinCos(), GetIntervalsEpoch(), GetIntervalsSeries(), GetTimesFirstInEpoch(): Changed label name.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    21-02-15   Added SelectEventsAbsSamp()
  JdM    27-03-15   Added GetCrossingBlockMatrix()
  JdM    06-04-15   Let GetCrossingBlockMatrix() return UMatrixSymmetric*
  JdM    09-04-15   Added SelectEventsEpoch()
  JdM    10-04-15   DeleteEvents(). Allow negative arguments.
  JdM    04-08-15   BUG Fix: DeleteEvents(). Testing negative arguments (zeroness was tested instead).
  JdM    18-02-16   Added SaveMatLab().
  JdM    28-03-16   Added AddEquiWidthEvents()
 */

#include<string.h>
#include<stdlib.h>
#include<math.h>

#include "EventArray.h"
#include "SortSemiSort.h"
#include "Epochs.h"
#include "FieldGraph.h"
#include "MatrixSymmetric.h"


static int StaticNsampPerTrial = 0;
static int SortEvent(const void *elem1, const void *elem2)
{
    const UEvent* E1 = (UEvent*)elem1;
    const UEvent* E2 = (UEvent*)elem2;

    int s1 = E1->GetAbsSample(StaticNsampPerTrial);
    int s2 = E2->GetAbsSample(StaticNsampPerTrial);
    if(s1 < s2) return -1;
    if(s1 > s2) return  1;

    return 0;
}

UString      UEventArray::Properties = UString();

void UEventArray::SetAllMembersDefault(void)
{
    EventName    = UString();
    nEvents      = 0;
    nEventsAlloc = 0;
    error        = U_OK;
    Events       = NULL;
    nSampTrial   = 0;
}

void UEventArray::DeleteAllMembers(ErrorType E)
{
    delete[] Events;
    SetAllMembersDefault();
    error = E;
}


UEventArray::UEventArray()
{
    SetAllMembersDefault();
}

UEventArray::UEventArray(const char *name, int nEp, int NsampPTrial)
/*
    Create nEp epochs with empty (or nonsense) contents)
 */
{
    SetAllMembersDefault();
    if(nEp<0 || NsampPTrial<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEventArray::UEventArray(). Invalid parameter arguments(s): nEp = %d, NsampPTrial=%d  .\n",nEp,NsampPTrial);
        return;
    }
    if(nEp==0)
    {
        Events       = new UEvent[1];
        nEventsAlloc = 1;
    }
    else
    {
        Events       = new UEvent[nEp];
        nEventsAlloc = nEp;
    }
    nEvents      = nEp;
    if(Events==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEventArray::UEventArray(). Memory allocation. nEp = %d\n",nEp);
        return;
    }
    EventName    = UString(name);
    EventName.RemoveChar((char)12);
    EventName.RemoveChar((char)13);
    nSampTrial   = NsampPTrial;
}

UEventArray::UEventArray(const UEventArray& eps)
{
    SetAllMembersDefault();
    if(&eps==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEventArray::UEventArray(). Invalid NULL address in argment. \n");
        return;
    }
    *this = eps;
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::UEventArray(). Copying argument.\n");
        return;
    }
}

UEventArray::~UEventArray()
{
    DeleteAllMembers(U_OK);
}

UEventArray& UEventArray::operator=(const UEventArray &Evar)
{
    if(this==NULL)
    {
        static UEventArray E; E.error = U_ERROR;
        CI.AddToLog("ERROR: UEventArray::operator=(). this==NULL  . \n");
        return E;
    }
    if(&Evar==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEventArray::operator=(). Invalid NULL address in argument. \n");
        return *this;
    }
    if(this==&Evar) return *this;
    DeleteAllMembers(U_OK);

    error        = Evar.error;
    nEvents      = Evar.nEvents;
    nSampTrial   = Evar.nSampTrial;
    if(Evar.nEventsAlloc<=0) nEventsAlloc = 1;
    else                     nEventsAlloc = Evar.nEventsAlloc;


    Events = new UEvent[Evar.nEventsAlloc];

    if(Events==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UEventArray::operator=(). Memory allocation. Evar.nEventsAlloc = %d\n",Evar.nEventsAlloc);
        return *this;
    }
    if(Evar.Events)
        for(int n=0; n<nEvents; n++) Events[n] = Evar.Events[n];
    EventName    = Evar.EventName;
    Properties   = Evar.Properties;
    return *this;
}

bool UEventArray::operator==(const UEventArray &E) const
{
    if(this==NULL && &E==NULL) return true;
    if(this==&E)               return true;
    if(this==NULL || &E==NULL) return false;

    if(EventName    != E.EventName   ) return false;
    if(nEvents      != E.nEvents     ) return false;
    if(nSampTrial   != E.nSampTrial  ) return false;
    if(Events==NULL && E.Events      ) return false;
    if(Events       && E.Events==NULL) return false;
    if(Events==NULL && E.Events==NULL) return true;

    for(int iev=0; iev<nEvents; iev++)
        if(Events[iev].trial  != E.Events[iev].trial  ||
           Events[iev].sample != E.Events[iev].sample) return false;
    return true;
}

ErrorType UEventArray::SaveMatLab(UFileName F) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::SaveMatLab(). No events set. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(F, "wt");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SaveMatLab(). Creating text file: %s \n", (const char*)F);
        return U_ERROR;
    }

    for(int iev=0; iev<nEvents; iev++)
    {
        int it = 1+Events[iev].GetAbsSample(nSampTrial);
        fprintf(fp, "%d \n",it);
    }
    fclose(fp);

    return U_OK;
}

ErrorType UEventArray::SetName(const char* Name)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    EventName = UString(Name);
    return U_OK;
}
ErrorType UEventArray::PrependName(const char* Prep)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    EventName.Prepend(Prep);
    return U_OK;
}
ErrorType UEventArray::SetnEvents(int nEv)
{
    if(nEv<0)
    {
        CI.AddToLog("ERROR: UEventArray::SetnEpochs(). Argument nEp = %d\n",nEv);
        return U_ERROR;
    }
    UEvent* NewEvent = new UEvent[nEv];
    if(NewEvent==NULL)
    {
        delete[] NewEvent; NewEvent = NULL;
        CI.AddToLog("ERROR: UEventArray::SetnEpochs(). Memory allocation. nEp=%d\n",nEv);
        return U_ERROR;
    }
    for(int n=0; n<MIN(nEvents,nEv); n++)
        NewEvent[n] = Events[n];

    delete[] Events;  Events = NewEvent;
    nEvents      = nEv;
    nEventsAlloc = nEv;
    return U_OK;
}

UEvent UEventArray::GetFirstEvent(void) const
/*
    Return the event with the smallest absolute sample value
 */
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetFirstEvent(). Events array not set.\n");
        return UEvent();
    }
    int ifirst = 0;
    int first  = this->GetAbsSample(0);
    for(int n=1; n<nEvents; n++)
    {
        int test = this->GetAbsSample(n);
        if(test<first)
        {
            ifirst = n;
            first  = test;
        }
    }
    return Events[ifirst];
}

double UEventArray::GetFirstEventTime(double SampleTime) const
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetFirstEventTime(). Events array not set.\n");
        return 0.;
    }
    int ifirst = 0;
    int first  = this->GetAbsSample(0);
    for(int n=1; n<nEvents; n++)
    {
        int test = this->GetAbsSample(n);
        if(test<first)
        {
            ifirst = n;
            first  = test;
        }
    }
    return this->GetAbsSample(ifirst)*SampleTime;
}

double UEventArray::GetLastEventTime(double SampleTime) const
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetLastEventTime(). Events array not set.\n");
        return 0.;
    }
    int ilast = 0;
    int last  = this->GetAbsSample(0);
    for(int n=1; n<nEvents; n++)
    {
        int test = this->GetAbsSample(n);
        if(test>last)
        {
            ilast = n;
            last  = test;
        }
    }
    return this->GetAbsSample(ilast)*SampleTime;
}

double UEventArray::GetMaxIntervalChange(void) const
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMaxIntervalChange(). Events array not set.\n");
        return 0;
    }
    if(AreEventsSortedIncr()==false)
    {
        UEventArray ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetMaxIntervalChange(). Copying *this. \n");
            return 0;
        }
        ThisCopy.SortEvents();
        return ThisCopy.GetMaxIntervalChange();
    }
    if(nEvents<=2)
    {
        CI.AddToLog("WARNING: UEventArray::GetMaxIntervalChange(). Too few events (nEvents = %d).\n", nEvents);
        return 0;
    }

    double MaxChange = -1;
    for(int iev=1; iev<nEvents-1; iev++)
    {
        int interval1 = abs( GetAbsSample(iev-1) - GetAbsSample(iev) );
        int interval2 = abs( GetAbsSample(iev) - GetAbsSample(iev+1) );
        double Ratio  = 0;
        if(interval1>0 && interval2>0)
        {
            if(interval1>interval2) Ratio = double(interval1)/double(interval2);
            else                    Ratio = double(interval2)/double(interval1);
        }
        if(MaxChange<=Ratio) MaxChange = Ratio;
    }
    return MaxChange;
}

int UEventArray::GetMaxInterval(void) const
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMaxInterval(). Events array not set.\n");
        return 0;
    }
    if(AreEventsSortedIncr()==false)
    {
        UEventArray ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetMaxInterval(). Copying *this. \n");
            return 0;
        }
        ThisCopy.SortEvents();
        return ThisCopy.GetMaxInterval();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetMaxInterval(). Too few events (nEvents = %d).\n", nEvents);
        return 0;
    }

    int MaxInterval = abs( GetAbsSample(1) - GetAbsSample(0) );
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval>MaxInterval) MaxInterval = interval;
    }
    return MaxInterval;
}

int UEventArray::GetMinInterval(void) const
{
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMinInterval(). Events array not set.\n");
        return 0;
    }
    if(AreEventsSortedIncr()==false)
    {
        UEventArray ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetMinInterval(). Copying *this. \n");
            return 0;
        }
        ThisCopy.SortEvents();
        return ThisCopy.GetMinInterval();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetMinInterval(). Too few events (nEvents = %d).\n", nEvents);
        return 0;
    }

    int MinInterval = abs( GetAbsSample(1) - GetAbsSample(0) );
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval<MinInterval) MinInterval = interval;
    }
    return MinInterval;
}

int UEventArray::GetMedianInterval(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Erroneous object.\n");
        return 0;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Events array not set.\n");
        return 0;
    }
    UEventArray CopyThis(*this);
    if(CopyThis.GetError()!=U_OK || CopyThis.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Copying *this or sorting. \n");
        return 0;
    }
    int NInterval = CopyThis.nEvents-1;
    if(NInterval<=0)
    {
        CI.AddToLog("WARNING: UEventArray::GetMedianInterval(). Too few events (NInterval = %d).\n", NInterval);
        return 0;
    }
    int* IntervalArray = new int[NInterval];
    if(IntervalArray==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Memory allocation: NInterval = %d).\n", NInterval);
        return 0;
    }
    for(int iev=0; iev<NInterval; iev++)
        IntervalArray[iev] = abs( CopyThis.GetAbsSample(iev+1) - CopyThis.GetAbsSample(iev) );

    int Median = GetMedian(IntervalArray, NInterval);
    delete[] IntervalArray;
    return Median;
}
int UEventArray::GetMedianInterval(const UEventArray* SubSetEvents) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Erroneous object.\n");
        return 0;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Events array not set.\n");
        return 0;
    }
    if(SubSetEvents==NULL || SubSetEvents->GetError()!=U_OK || SubSetEvents->GetnEvents()<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). SubSetEvents erroneous or not properly set.\n");
        return 0;
    }
    UEventArray CopyThis(*this);
    if(CopyThis.GetError()!=U_OK || CopyThis.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Copying *this or sorting. \n");
        return 0;
    }
    UEventArray CopySub(*SubSetEvents);
    if(CopySub.GetError()!=U_OK || CopySub.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Copying *SubSetEvents or sorting. \n");
        return 0;
    }

    int NIntervalMax = 2*CopySub.nEvents;
    if(NIntervalMax<=0)
    {
        CI.AddToLog("WARNING: UEventArray::GetMedianInterval(). Too few events (NIntervalMax = %d).\n", NIntervalMax);
        return 0;
    }
    int* IntervalArray = new int[NIntervalMax];
    if(IntervalArray==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Memory allocation: NInterval = %d).\n", NIntervalMax);
        return 0;
    }
    for(int i=0; i<NIntervalMax; i++) IntervalArray[i] = 0;

    int NInterval = 0;
    int iev       = 0;
    int iabsiev   = CopyThis.GetAbsSample(iev);
    for(int isub=0; isub<CopySub.GetnEvents(); isub++)
    {
        int iabsub = CopySub.GetAbsSample(isub);
        for(;iev<nEvents;iev++)
        {
            iabsiev   = CopyThis.GetAbsSample(iev);
            if(iabsiev>=iabsub) break;
        }
        if(iabsub<iabsiev)
        {
            delete[] IntervalArray;
            CI.AddToLog("ERROR: UEventArray::GetMedianInterval(). Event[%d] = (%d,%d) of subset not found.\n", isub, CopySub.Events[isub].trial, CopySub.Events[isub].sample);
            return 0;
        }
        else if(iabsub==iabsiev)
        {
            if(iev>0        ) IntervalArray[NInterval++] = abs( CopyThis.GetAbsSample(iev-1) - CopyThis.GetAbsSample(iev) );
            if(iev<nEvents-1) IntervalArray[NInterval++] = abs( CopyThis.GetAbsSample(iev+1) - CopyThis.GetAbsSample(iev) );
        }
    }
    int Median = GetMedian(IntervalArray, NInterval);
    delete[] IntervalArray;
    return Median;
}

UEvent UEventArray::GetLargestIntervalChange(int *ievent, double* Ratio) const
{
    if(ievent  ) *ievent   = -1;
    if(Ratio   ) *Ratio    = -1;

    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetLargestIntervalChange(). Events array not set.\n");
        return UEvent();
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetLargestIntervalChange(). Events not sorted in time. \n");
        return UEvent();
    }
    if(nEvents<=2)
    {
        CI.AddToLog("WARNING: UEventArray::GetLargestIntervalChange(). Too few events (nEvents = %d).\n", nEvents);
        return UEvent();
    }
    double MaxIntervalChange = GetMaxIntervalChange();

/* Find first interval of size MinInterval */
    for(int iev=1; iev<nEvents-1; iev++)
    {
        int interval1 = abs( GetAbsSample(iev-1) - GetAbsSample(iev) );
        int interval2 = abs( GetAbsSample(iev) - GetAbsSample(iev+1) );
        double Rat    = 0;
        if(interval1>0 && interval2>0)
        {
            if(interval1>interval2) Rat = double(interval1)/double(interval2);
            else                    Rat = double(interval2)/double(interval1);
        }
        if(MaxIntervalChange<=Rat)
        {
            if(ievent) *ievent = iev;
            if(Ratio ) *Ratio  = Rat;
            return Events[iev];
        }
    }
    CI.AddToLog("WARNING: UEventArray::GetLargestIntervalChange(). Interval change of size %f not found.\n", MaxIntervalChange);
    return UEvent();
}


UEvent UEventArray::GetBeginShortestInterval(int *ievent, int* Interval) const
{
    if(ievent  ) *ievent   = -1;
    if(Interval) *Interval = -1;

    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginShortestInterval(). Events array not set.\n");
        return UEvent();
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginShortestInterval(). Events not sorted in time. \n");
        return UEvent();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetBeginShortestInterval(). Too few events (nEvents = %d).\n", nEvents);
        return UEvent();
    }
    int MinInterval = GetMinInterval();
    if(MinInterval<=0)
        CI.AddToLog("WARNING: UEventArray::GetBeginShortestInterval(). Minimum interval has only %d points.\n", MinInterval);

/* Find first interval of size MinInterval */
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval==MinInterval)
        {
            if(ievent)   *ievent   = iev;
            if(Interval) *Interval = interval;
            return Events[iev];
        }
    }
    CI.AddToLog("WARNING: UEventArray::GetBeginShortestInterval(). Interval of size %d not found.\n", MinInterval);
    return UEvent();
}
UEvent UEventArray::GetEndShortestInterval(int *ievent, int* Interval) const
{
    if(ievent  ) *ievent   = -1;
    if(Interval) *Interval = -1;

    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetEndShortestInterval(). Events array not set.\n");
        return UEvent();
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetEndShortestInterval(). Events not sorted in time. \n");
        return UEvent();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetEndShortestInterval(). Too few events (nEvents = %d).\n", nEvents);
        return UEvent();
    }
    int MinInterval = GetMinInterval();
    if(MinInterval<=0)
        CI.AddToLog("WARNING: UEventArray::GetEndShortestInterval(). Minimum interval has only %d points.\n", MinInterval);

/* Find first interval of size MinInterval */
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval==MinInterval)
        {
            if(ievent)   *ievent   = iev+1;
            if(Interval) *Interval = interval;
            return Events[iev+1];
        }
    }
    CI.AddToLog("WARNING: UEventArray::GetEndShortestInterval(). Interval of size %d not found.\n", MinInterval);
    return UEvent();
}

UEvent UEventArray::GetBeginLongestInterval(int *ievent, int* Interval) const
{
    if(ievent  ) *ievent   = -1;
    if(Interval) *Interval = -1;
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginLongestInterval(). Events array not set.\n");
        return UEvent();
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginLongestInterval(). Events not sorted in time. \n");
        return UEvent();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetBeginLongestInterval(). Too few events (nEvents = %d).\n", nEvents);
        return UEvent();
    }
    int MaxInterval = GetMaxInterval();
    if(MaxInterval<=0)
        CI.AddToLog("WARNING: UEventArray::GetBeginLongestInterval(). Maximum interval has only %d points.\n", MaxInterval);

/* Find first interval of size MaxInterval */
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval==MaxInterval)
        {
            if(ievent)   *ievent   = iev;
            if(Interval) *Interval = interval;
            return Events[iev];
        }
    }
    CI.AddToLog("WARNING: UEventArray::GetBeginLongestInterval(). Interval of size %d not found.\n", MaxInterval);
    return UEvent();
}
UEvent UEventArray::GetEndLongestInterval(int *ievent, int* Interval) const
{
    if(ievent  ) *ievent   = -1;
    if(Interval) *Interval = -1;
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetEndLongestInterval(). Events array not set.\n");
        return UEvent();
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetEndLongestInterval(). Events not sorted in time. \n");
        return UEvent();
    }
    if(nEvents<=1)
    {
        CI.AddToLog("WARNING: UEventArray::GetEndLongestInterval(). Too few events (nEvents = %d).\n", nEvents);
        return UEvent();
    }
    int MaxInterval = GetMaxInterval();
    if(MaxInterval<=0)
        CI.AddToLog("WARNING: UEventArray::GetEndLongestInterval(). Maximum interval has only %d points.\n", MaxInterval);

/* Find first interval of size MaxInterval */
    for(int iev=0; iev<nEvents-1; iev++)
    {
        int interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(interval==MaxInterval)
        {
            if(ievent)   *ievent   = iev+1;
            if(Interval) *Interval = interval;
            return Events[iev+1];
        }
    }
    CI.AddToLog("WARNING: UEventArray::GetEndLongestInterval(). Interval of size %d not found.\n", MaxInterval);
    return UEvent();
}


UEventArray*  UEventArray::GetBeginDeviatingIntervals(int Threshold, bool ShortIntervals, bool LongIntervals) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). NULL or erroneous object..\n");
        return NULL;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). Events array not set.\n");
        return NULL;
    }
    if(Threshold<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). Invalid threshold parameter (%d).\n", Threshold);
        return NULL;
    }
    if(ShortIntervals==false && LongIntervals==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). Both ShortIntervals and LongIntervals.are false\n");
        return NULL;
    }

    int MedianInterval = GetMedianInterval();
    if(MedianInterval<=0)
    {
        CI.AddToLog("WARNING: UEventArray::GetBeginDeviatingIntervals(). MedianInterval = %d).\n", MedianInterval);
        return NULL;
    }

    UEventArray ThisCopy(*this);
    if(ThisCopy.GetError()!=U_OK || ThisCopy.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). Copying *this or sorting. \n");
        return NULL;
    }
    UString Name = EventName;
    if(ShortIntervals==true  && LongIntervals==false) Name += UString(Threshold,"_Short_%d");
    if(ShortIntervals==false && LongIntervals==true ) Name += UString(Threshold,"_Long_%d");
    else                                              Name += UString(Threshold,"_Deviation_%d");

    UEventArray* DeviationEvents = new UEventArray((const char*) Name, 0, nSampTrial);
    if(DeviationEvents==NULL || DeviationEvents->GetError()!=U_OK)
    {
        delete DeviationEvents;
        CI.AddToLog("ERROR: UEventArray::GetBeginDeviatingIntervals(). Copying *this or sorting. \n");
        return NULL;
    }

    for(int iev=0; iev<nEvents-1; iev++)
    {
        int Interval = abs( GetAbsSample(iev+1) - GetAbsSample(iev) );
        if(ShortIntervals==true && Interval<MedianInterval-Threshold)   DeviationEvents->AddEvent(Events[iev]);
        if(LongIntervals ==true && Interval>MedianInterval+Threshold)   DeviationEvents->AddEvent(Events[iev]);
    }
    return DeviationEvents;
}

int* UEventArray::GetInEpochArray(const UEpochs* Epochs, int* NEpochsIn) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetInEpochArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetInEpochArray(). Events array not set.\n");
        return NULL;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetInEpochArray(). NULL or erroneous epochs array. \n");
        return NULL;
    }

    int  Nep      = Epochs->GetnEpochs();
    int* EpochArr = new int[Nep];
    if(EpochArr==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetInEpochArray(). Memory allocation error, Nep = %d. \n", Nep);
        return NULL;
    }

    int Nin = 0;
    for(int n=0; n<Nep; n++)
    {
        for(int iev=0; iev<nEvents; iev++)
        {
            if(Epochs->IsInEpoch(n,Events[iev])==false) continue;

            bool NewEp = true;
            for(int k=0; k<Nin; k++)
                if(n==EpochArr[k]) {NewEp = false; break;}
            if(NewEp==false) continue;

            EpochArr[Nin++] = n;
        }
    }
    if(NEpochsIn) *NEpochsIn = Nin;
    return EpochArr;
}

int* UEventArray::GetNMatchPerEpoch(const UEpochs* Epochs, int* NtotMatch, int* NSingleMatch) const
/*
This routine calculates the number of times this Event is present in all epochs of Epochs.
The returned int array contains these numbers for all epochs.
On return NtotMatch equals the number of epochs that in which this Event is at least once
present.
On return NSingleMatch equals the number of epochs that in which this Event is exactly once
present.

*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetNMatchPerEpoch(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetNMatchPerEpoch(). Events array not set.\n");
        return NULL;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetNMatchPerEpoch(). NULL or erroneous epochs array. \n");
        return NULL;
    }

    int  Nep     = Epochs->GetnEpochs();
    int* MatchEp = new int[Nep];
    if(MatchEp==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetNMatchPerEpoch(). Memory allocation error, Nep = %d. \n", Nep);
        return NULL;
    }
    for(int n=0; n<Nep; n++)
    {
        MatchEp[n] = 0;
        for(int iev=0; iev<nEvents; iev++)
            if(Epochs->IsInEpoch(n, Events[iev])==true)
            {
                MatchEp[n]++;
                break;
            }
    }

    if(NtotMatch && NSingleMatch)
    {
        *NtotMatch    = 0;
        *NSingleMatch = 0;
        for(int n=0; n<Nep; n++)
        {
            if(MatchEp[n])    (*NtotMatch)++;
            if(MatchEp[n]==1) (*NSingleMatch)++;
        }
    }
    else if(NtotMatch)
    {
        *NtotMatch = 0;
        for(int n=0; n<Nep; n++)
        {
            if(MatchEp[n]) (*NtotMatch)++;
        }
    }
    else if(NSingleMatch)
    {
        *NSingleMatch = 0;
        for(int n=0; n<Nep; n++)
        {
            if(MatchEp[n]==1) (*NSingleMatch)++;
        }
    }

    return MatchEp;
}

double UEventArray::GetAverageTimeInterval(double SampleTime) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Events array not set.\n");
        return 0.;
    }

    double First = GetFirstEventTime(SampleTime);
    double Last  = GetLastEventTime(SampleTime);
    if(nEvents<=1) return 0.;

    return (Last-First) / (nEvents-1);
}
double UEventArray::GetAverageTimeInterval(const UFieldGraph* FG, int Level, double SampleTime) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Events array not set.\n");
        return 0.;
    }
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). UFieldGraph argument NULL or erroneous.\n");
        return 0.;
    }
    if(FG->GetVeclen()!=1 || FG->Getndim()!=1 || (FG->GetFType()!=UField::U_UNIFORM && FG->GetFType()!=UField::U_RECTILINEAR))
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). UFieldGraph argument of wrong type (%s).\n", (const char*)FG->GetProperties(""));
        return 0.;
    }
    if(SampleTime<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Sample time out of range (%f) .\n", SampleTime);
        return 0.;
    }
    if(AreEventsSortedIncr()==false)
    {
        UEventArray ThisCopy(*this);
        if(ThisCopy.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Copying *this. \n");
            return 0;
        }
        ThisCopy.SortEvents();
        return ThisCopy.GetAverageTimeInterval(FG, Level, SampleTime);
    }

    int    NInter   = 0;
    double TimeOver = 0.;
    int    iLevel   = 0;
    while(1)
    {
        double StartTime =  0.;
        double EndTime   = -1.;
        if(FG->GetLevelRange(Level, iLevel, &StartTime, &EndTime) )
        {
            CI.AddToLog("ERROR: UEventArray::GetAverageTimeInterval(). Getting level range (iLevel=%d)\n", iLevel);
            return 0.;
        }
        if(StartTime>EndTime) break;

        int    ievFirst = -1;
        for(int iev=0; iev<nEvents; iev++)
        {
            if(Events[iev].GetAbsSample(nSampTrial)*SampleTime >= StartTime)
            {
                ievFirst = MAX(0, iev-1);
                break;
            }
        }
        if(ievFirst<0) break;

        for(int iev=ievFirst+1; iev<nEvents; iev++)
        {
            if(Events[iev].GetAbsSample(nSampTrial)*SampleTime > EndTime) break;
            NInter++;
            TimeOver += (Events[iev].GetAbsSample(nSampTrial)-Events[iev-1].GetAbsSample(nSampTrial))*SampleTime;
        }
        iLevel++;
    }
    if(NInter>0) return TimeOver/NInter;
    return 0.;
}


UFieldGraph* UEventArray::GetIntervalsSinCos(const UEpochs* Epo, double Stime, int Harm, bool Sin, int NSegment) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<=1)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Events not sorted in time. \n");
        return NULL;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK || Epo->GetnEpochs()<=1||Epo->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Invalid UEpochs argument, (e.g. less than 2 epochs) .\n");
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Sample time out of range: Stime = %f .\n", Stime);
        return NULL;
    }
    if(Harm<0)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Harmonic out of range (Harm =%d) .\n", Harm);
        return NULL;
    }
    if(NSegment<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). NSegment out of range (NSegment =%d) .\n", NSegment);
        return NULL;
    }

    double First = Stime * Epo->GetBeginSample(Epo->GetFirstEpoch(true));
    double Last  = Stime * Epo->GetBeginSample(Epo->GetLastEpoch(true));
    if(Last<=First)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Last event before first event. First = %f, Last = %f  ,\n", First, Last);
        return NULL;
    }

    int Npoints = Epo->GetnEpochs();
    UFieldGraph* FieldGr = new UFieldGraph((float)First, (float)Last, Npoints, UField::U_DOUBLE, NSegment);
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetDdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Creating UField object. \n");
        return NULL;
    }
    UString Label = UString("_Phase"); 
    if(Harm>0)
    {
        if(Sin) Label = UString(Harm, "_Sin%d");
        else    Label = UString(Harm, "_Cos%d");
    }
    Label   = EventName+Label;
    FieldGr ->SetLabel(Label);
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);
    if(NSegment>1)
        FieldGr ->SetComponentsDataType(U_COMPDAT_SLICEPROPER);
    UString Comment = UString("MarkerName    =")+ EventName + UString(" \n") +
                      UString(Harm           , "Harm          = %d \n") +
                      UString(BoolAsText(Sin), "Sin           = %s \n") +
                      UString(NSegment       , "NSegment      = %d \n");
    FieldGr ->AddFileComments(Comment);

    double* Func = FieldGr->GetDdata();

    for(int k=0; k<Npoints; k++)
    {
        int firstsamp = Epo->GetBeginSample(k);
        if(firstsamp<0)
        {
            delete FieldGr;
            CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Invalid epoch, k=%d .\n", k);
            return NULL;
        }
        int NSampEp = Epo->GetNsamp(k);

        for(int is=0; is<NSegment; is++)
        {
            int midsamp = firstsamp + int(  ((is+0.5)*NSampEp)/NSegment );
            Func[k*NSegment+is] = 0.;
            for(int j=0; j<nEvents-1; j++)
            {
                if(GetAbsSample(j+1)<midsamp) continue;
                if(GetAbsSample(j  )>midsamp) break;

                int interval = GetAbsSample(j+1)-GetAbsSample(j);
                if(interval<=0) continue;

                double phase = PI2*(midsamp-GetAbsSample(j))/(double) interval;
                if(Harm==0)
                {
                    Func[k*NSegment+is] = phase;
                }
                else
                {
                    if(Sin) Func[k*NSegment+is] = sin(Harm*phase);
                    else    Func[k*NSegment+is] = cos(Harm*phase);
                }
                break;
            }
        }
    }
    return FieldGr;
}

UFieldGraph* UEventArray::GetIntervalsSinCos(double Stime, double Shift, double DownSample, int Harm, bool Sin) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<=1)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Events not sorted in time. \n");
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Sample time out of range: Stime = %f .\n", Stime);
        return NULL;
    }
    if(DownSample<Stime)
    {
        CI.AddToLog("WARNING: UEventArray::GetIntervalsSinCos(). Downsample time (%f) smaller than sample time (%f). Downsample time set to sample time.\n", DownSample, Stime);
        DownSample=Stime;
    }
    if(Harm<0)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Harmonic out of range (Harm =%d) .\n", Harm);
        return NULL;
    }

    double First = GetFirstEventTime(Stime);
    double Last  = GetLastEventTime(Stime);
    if(Last<=First)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Last event before first event. First = %f, Last = %f  ,\n", First, Last);
        return NULL;
    }
    int Npoints = 1     + int(floor( (Last-First-Shift)/DownSample  ));
    Last        = First + (Npoints-1)*DownSample;

    UFieldGraph* FieldGr = new UFieldGraph((float)First, (float)Last, Npoints, UField::U_DOUBLE, 1);
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetDdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSinCos(). Creating UField object. \n");
        return NULL;
    }
    UString Label = UString("_Phase"); 
    if(Harm>0)
    {
        if(Sin) Label = UString(Harm, "_Sin%d");
        else    Label = UString(Harm, "_Cos%d");
    }
    Label   = EventName+Label;
    FieldGr ->SetLabel(Label);
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);
    UString Comment = UString("MarkerName    =")+ EventName + UString(" \n") +
                      UString(Harm           , "Harm          = %d \n") +
                      UString(BoolAsText(Sin), "Sin           = %s \n");
    FieldGr ->AddFileComments(Comment);

    double* Func = FieldGr->GetDdata();

    double T0     = Stime*GetAbsSample(0);
    int    ipoint = 0;
    for(int n=0; n<nEvents-1; n++)
    {
        double Time = ipoint*DownSample + Shift;
        double Beg  = Stime*GetAbsSample(n  )-T0;
        double End  = Stime*GetAbsSample(n+1)-T0;
        if   (Time< Beg) continue;
        while(Time<=End)
        {
            if(ipoint>=Npoints)
            {
                delete FieldGr;
                CI.AddToLog("ERROR: UEpochs::GetIntervalsSinCos(). point out of range: ipoint = %d, Npoints=%d  .\n", ipoint, Npoints);
                return NULL;
            }
            double phase = 0.;
            if(End>Beg) phase = PI2 * (Time-Beg) / (End-Beg);
            if(Harm==0)
            {
                Func[ipoint++] = phase;
            }
            else
            {
                if(Sin) Func[ipoint++] = sin(Harm*phase);
                else    Func[ipoint++] = cos(Harm*phase);
            }
            Time = ipoint*DownSample + Shift;
        }
    }
    if(ipoint!=Npoints)
        CI.AddToLog("WARNING: UEpochs::GetEventsPerEpochAsField(). Too few points: ipoint = %d, Npoints=%d  .\n", ipoint, Npoints);

    return FieldGr;
}

UFieldGraph* UEventArray::GetIntervalsEpoch(const UEpochs* Epo, double Stime, int NSegment, double DeadTimeBeg_s, double DeadTimeEnd_s, double IntervalWindow_s, bool ComputeSD) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<=1)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Events not sorted in time. \n");
        return NULL;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK || Epo->GetnEpochs()<=1||Epo->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Invalid UEpochs argument, (e.g. less than 2 epochs) .\n");
        return NULL;
    }
    if(Epo->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Epoch times not equal.\n");
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Sample time out of range: Stime = %f .\n", Stime);
        return NULL;
    }
    if(NSegment<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Number of segments out of range (NSegment = %d ). \n", NSegment);
        return NULL;
    }
    double EpochLen = Epo->GetNsamp(0)*Stime;
    if(DeadTimeBeg_s<0 || DeadTimeBeg_s>=EpochLen)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Dead Time out of range (DeadTimeBeg_s=%f). \n", DeadTimeBeg_s);
        return NULL;
    }
    if(DeadTimeEnd_s<0 || DeadTimeEnd_s+DeadTimeBeg_s>=EpochLen)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Dead Time out of range (DeadTimeEnd_s=%f). \n", DeadTimeEnd_s);
        return NULL;
    }
    if(IntervalWindow_s<=0.)
        IntervalWindow_s = (EpochLen-DeadTimeBeg_s-DeadTimeEnd_s)/NSegment;

    double First = Stime * Epo->GetBeginSample(Epo->GetFirstEpoch(true));
    double Last  = Stime * Epo->GetBeginSample(Epo->GetLastEpoch(true));
    if(Last<=First)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Last event before first event. First = %f, Last = %f  ,\n", First, Last);
        return NULL;
    }
    int Npoints = Epo->GetnEpochs();
    UFieldGraph* FieldGr = new UFieldGraph((float)First, (float)Last, Npoints, UField::U_DOUBLE, NSegment);
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetDdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Creating UField object. \n");
        return NULL;
    }
    FieldGr ->SetLabel( UString(EventName + "_Interval"));
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);
    if(NSegment>1)   FieldGr ->SetComponentsDataType(U_COMPDAT_SLICEPROPER);

    UString Comment = UString("MarkerName    =")+ EventName + UString(" \n")     +
                      UString(NSegment        , "NSegment         = %d \n")      +
                      UString(DeadTimeBeg_s   , "DeadTimeBeg_s    = %f // [s]\n")+
                      UString(DeadTimeEnd_s   , "DeadTimeEnd_s    = %f // [s]\n")+
                      UString(IntervalWindow_s, "IntervalWindow_s = %f // [s]\n");

    FieldGr ->AddFileComments(Comment);
    double* Func = FieldGr->GetDdata();

    for(int kseg=0; kseg<NSegment; kseg++)
    {
        for(int k=0; k<Npoints; k++)
        {
            double beg_s    = Epo->GetBegin(k).GetAbsSample(nSampTrial)*Stime+DeadTimeBeg_s;
            double end_s    = Epo->GetEnd  (k).GetAbsSample(nSampTrial)*Stime-DeadTimeEnd_s;
            double begseg_s = beg_s    +  kseg   * (end_s-beg_s)/NSegment;
            double endseg_s = begseg_s + IntervalWindow_s;

            if(endseg_s<=begseg_s)
            {
                delete FieldGr;
                CI.AddToLog("ERROR: UEventArray::GetIntervalsEpoch(). Dead Time out of range (DeadTimeEnd_s=%f), epoch = %d. \n", DeadTimeEnd_s, k);
                return NULL;
            }
            double Value    = 0.;
            double Value2   = 0.;
            int    Nev      = 0;
            for(int j=0; j<nEvents-1; j++)
            {
                if(GetAbsSample(j+1)*Stime< begseg_s) continue;
                if(GetAbsSample(j  )*Stime>=endseg_s) break;

                double interval = (GetAbsSample(j+1)-GetAbsSample(j))*Stime;
                if(interval<=0.) continue;

                Value  += interval;
                Value2 += interval*interval;
                Nev++;
            }
            if(Nev)
            {
                Value  /= Nev;
                Value2 /= Nev;
            }
            if(ComputeSD==false)  Func[k*NSegment+kseg] = Value;
            else                  Func[k*NSegment+kseg] = sqrt(fabs(Value2 - Value*Value));
        }
    }
    return FieldGr;
}

UFieldGraph* UEventArray::GetIntervalsSeries(double Stime, bool Uniform) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSeries(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<2)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSeries(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSeries(). Sample time out of range: Stime = %f .\n", Stime);
        return NULL;
    }
    double First = Stime * GetAbsSample(0);
    double Last  = Stime * GetAbsSample(nEvents-2);
    if(Last<=First)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSeries(). Last event before first event. First = %f, Last = %f  ,\n", First, Last);
        return NULL;
    }
    int Npoints = nEvents-1;
    UFieldGraph* FieldGr = NULL;
    if(Uniform)
    {
        FieldGr = new UFieldGraph((float)First, (float)Last, Npoints, UField::U_DOUBLE, 1);
    }
    else
    {
        float* points = new float[Npoints];
        if(points)
        {
            for(int k=0; k<Npoints; k++) points[k] = float(Stime * GetAbsSample(k));
            FieldGr = new UFieldGraph(points, Npoints, UField::U_DOUBLE, 1);
            delete[] points;
        }
    }
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetDdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEventArray::GetIntervalsSeries(). Creating UField object. \n");
        return NULL;
    }
    FieldGr ->SetLabel( EventName + UString("_IntervalSeries") );
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);

    UString Comment = UString("MarkerName    =")+ EventName + UString(" \n");

    FieldGr ->AddFileComments(Comment);
    double* Func = FieldGr->GetDdata();
    for(int k=0; k<Npoints; k++) Func[k] = Stime * (GetAbsSample(k+1) -  GetAbsSample(k));
    FieldGr->UpdateMinMax();

    return FieldGr;
}

UFieldGraph* UEventArray::GetTimesFirstInEpoch(const UEpochs* Epo, double Stime) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<0)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK || Epo->GetnEpochs()<=1||Epo->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Invalid UEpochs argument, (e.g. less than 2 epochs) .\n");
        return NULL;
    }
    if(Epo->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Epoch times not equal.\n");
        return NULL;
    }
    if(Stime<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Sample time out of range: Stime = %f .\n", Stime);
        return NULL;
    }

    double First = Stime * Epo->GetBeginSample(Epo->GetFirstEpoch(true));
    double Last  = Stime * Epo->GetBeginSample(Epo->GetLastEpoch(true));
    if(Last<=First)
    {
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Last event before first event. First = %f, Last = %f  ,\n", First, Last);
        return NULL;
    }
    int Npoints = Epo->GetnEpochs();
    UFieldGraph* FieldGr = new UFieldGraph((float)First, (float)Last, Npoints, UField::U_DOUBLE, 1);
    if(FieldGr==NULL || FieldGr->GetError()!=U_OK || FieldGr->GetDdata()==NULL)
    {
        delete FieldGr;
        CI.AddToLog("ERROR: UEventArray::GetTimesFirstInEpoch(). Creating UField object. \n");
        return NULL;
    }
    FieldGr ->SetLabel( EventName + UString("_FirstTimeIn") );
    FieldGr ->SetDatTypeHor(U_GDAT_TIME_S);

    UString Comment = UString("MarkerName    =")+ EventName + UString(" \n");

    FieldGr ->AddFileComments(Comment);
    double* Func = FieldGr->GetDdata();
    for(int iep=0; iep<Epo->GetnEpochs(); iep++)
    {
        Func[iep] = -1.;
        for(int iev=0; iev<nEvents; iev++)
        {
            if(Epo->IsInEpoch(iep, Events[iev]) == false) continue;
            double Time = Stime* (GetAbsSample(iev) - Epo->GetBeginSample(iep));

            if(Func[iep]<0 || Time<Func[iep]) Func[iep] = Time;
        }
    }
    FieldGr->UpdateMinMax();
    return FieldGr;
}

UString UEventArray::GetIntervalsText(double Stime) const
{
    if(Events==NULL || nEvents<=1)
    {
        CI.AddToLog("ERROR: UEventArray::GetIntervalsText(). Events array not set or too small (nEvents=%d).\n", nEvents);
        return UString();
    }
    if(Stime<=0) Stime = 1.;

    UString Text("Event \tTime \tInterval \n");
    for(int iev=0; iev<nEvents-1; iev++)
    {
        double  Inter = Stime* (  GetAbsSample(iev+1) - GetAbsSample(iev)  );
        double  Time  = Stime*    GetAbsSample(iev);
        UString Line  = UString(iev, "%d  \t") + UString(Time, "%f  \t") + UString(Inter, "%f  \n");
        if(Text.Append(Line)!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetIntervalsText(). Appending line: %s \n", (const char*)Line);
            return UString();
        }
    }
    return Text;
}

int UEventArray::GetIndex(UEvent E) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetIndex(). Events array not set.\n");
        return -1;
    }
    for(int iev=0;iev<nEvents; iev++)
    {
        if(Events[iev].sample!=E.sample) continue;
        if(Events[iev].trial !=E.trial ) continue;
        return iev;
    }
    return -1;
}

UEvent UEventArray::GetEvent(int iev) const
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetEvent(). Events array not set.\n");
        return UEvent();
    }
    if(iev<0 || iev>=nEvents)
    {
        CI.AddToLog("ERROR: UEventArray::GetEvent(). Argument out of range (%d), nEvents = %d\n",iev,nEvents);
        return UEvent();
    }
    return Events[iev];
}

int UEventArray::GetAbsSample(int iev) const
{
    return GetEvent(iev).GetAbsSample(nSampTrial);
}

ErrorType UEventArray::SetEvent(int iev, UEvent ev)
{
    if(iev<0 || iev>=nEvents)
    {
        CI.AddToLog("ERROR: UEventArray::SetEvent(). Argument out of range (%d), nEvents = %d\n",iev,nEvents);
        return U_ERROR;
    }
    Events[iev] = ev;
    return U_OK;
}

ErrorType UEventArray::Merge(const UEventArray* EvAr)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::Merge(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(EvAr==NULL || EvAr->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::Merge(). Argument NULL or erroneous. \n");
        return U_ERROR;
    }
    if(nSampTrial != EvAr->GetnSampTrial())
    {
        CI.AddToLog("ERROR: UEventArray::Merge(). Number of samples per trial (%d) not compatible with argument (%d).\n", nSampTrial, EvAr->GetnSampTrial());
        return U_ERROR;
    }

/* Allocate memory if required */
    if(nEventsAlloc<nEvents+EvAr->GetnEvents())
    {
        int NewAlloc = nEvents+EvAr->GetnEvents()+20;
        if(NewAlloc<100) NewAlloc  = 150;

        UEvent* NewEvent = new UEvent[NewAlloc];
        if(NewEvent==NULL)
        {
            delete[] NewEvent; NewEvent = NULL;
            CI.AddToLog("ERROR: UEventArray::Merge(). Memory allocation. NewAlloc=%d\n",NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEvents; n++) NewEvent[n] = Events[n];

        delete[] Events;  Events = NewEvent;
        nEventsAlloc = NewAlloc;
    }

/* Merge events */
    for(int n=nEvents; n<nEvents+EvAr->GetnEvents(); n++) Events[n] = EvAr->Events[n-nEvents];
    nEvents   += EvAr->GetnEvents();
    EventName += UString("+") + EvAr->EventName;

    return U_OK;
}

ErrorType UEventArray::AddEvent(UEvent ev)
/*
    Add the event ev at the end of the Events[] array. Allocate more memory when required.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::AddEvent(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(nEvents+1>nEventsAlloc)
    {
        int NewAlloc = nEvents+1;
        if(nEvents<100) NewAlloc  = 150;
        else            NewAlloc *= 2;

        UEvent* NewEvent = new UEvent[NewAlloc];
        if(NewEvent==NULL)
        {
            delete[] NewEvent; NewEvent = NULL;
            CI.AddToLog("ERROR: UEventArray::AddEvent(). Memory allocation. NewAlloc=%d\n",NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEvents; n++)
            NewEvent[n] = Events[n];

        delete[] Events;  Events = NewEvent;
        nEventsAlloc = NewAlloc;
    }
    Events[nEvents] = ev;
    nEvents++;
    return U_OK;
}

ErrorType UEventArray::AddEvent(int AbsSamp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::AddEvent(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(nSampTrial<=0)
    {
        CI.AddToLog("ERROR: UEventArray::AddEvent(). nSampTrial (=%d) is out of range. \n");
        return U_ERROR;
    }
    if(AbsSamp<0)
    {
        CI.AddToLog("ERROR: UEventArray::AddEvent(). Argument out of range (AbsSamp = %d). \n", AbsSamp);
        return U_ERROR;
    }
    return AddEvent(UEvent(AbsSamp/nSampTrial, AbsSamp%nSampTrial));
}


ErrorType UEventArray::SetEquiDistant(double Interval, double SampleTime, int* Remainder)
{
    if(Interval<=0. || SampleTime<=0. || Interval<SampleTime)
    {
        CI.AddToLog("ERROR: UEventArray::SetEquiDistant(). Argument(s) out of range: Interval=%f, SampleTime=%f   . \n", Interval, SampleTime);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SetEquiDistant(). Object properly not set.\n");
        return U_ERROR;
    }
    if(nEvents<=1)
    {
        CI.AddToLog("ERROR: UEventArray::SetEquiDistant(). nEvents (=%d) < 2.\n", nEvents);
        return U_ERROR;
    }
    double AbsFirst = SampleTime*Events[0        ].GetAbsSample(nSampTrial);
    double AbsLast  = SampleTime*Events[nEvents-1].GetAbsSample(nSampTrial);
    int    Nnew     = int(floor((AbsLast-AbsFirst)/Interval + 1));
    if(Nnew<2) Nnew = 2;

    if(Nnew>nEventsAlloc)
    {
        int NewAlloc = Nnew;
        if(NewAlloc<100) NewAlloc  = 150;
        else             NewAlloc *= 2;

        UEvent* NewEvent = new UEvent[NewAlloc];
        if(NewEvent==NULL)
        {
            delete[] NewEvent; NewEvent = NULL;
            CI.AddToLog("ERROR: UEventArray::SetEquiDistant(). Memory allocation. NewAlloc=%d\n",NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEvents; n++)
            NewEvent[n] = Events[n];

        delete[] Events;  Events = NewEvent;
        nEventsAlloc = NewAlloc;
    }


    int AbsLastSamp = Events[nEvents-1].GetAbsSample(nSampTrial);
    for(int n=0; n<Nnew; n++)
    {
        int samp  = int( floor( (AbsFirst + n*Interval)/SampleTime ) );
        Events[n] = UEvent(samp/nSampTrial, samp%nSampTrial);
    }
    if(Nnew>2)
    {
        double AbsLastNew0  = SampleTime*Events[Nnew-1].GetAbsSample(nSampTrial);
        double AbsLastNew1  = SampleTime*Events[Nnew-2].GetAbsSample(nSampTrial);
        if(fabs(AbsLastNew1-AbsLast) < fabs(AbsLastNew0-AbsLast)) Nnew -= 1;
    }
    nEvents = Nnew;

    if(Remainder)
        *Remainder = AbsLastSamp - Events[nEvents-1].GetAbsSample(nSampTrial);

    return U_OK;
}

ErrorType UEventArray::AddEquiDistantEvents(int ievFrom, int ievTo, int nevAdd)
{
    if(ievFrom<0      || ievFrom>=nEvents ||
       ievTo  <0      || ievTo  >=nEvents ||
       ievFrom>=ievTo || nevAdd <=0)
    {
        CI.AddToLog("ERROR: UEventArray::AddEquiDistantEvents(). Argument(s) out of range: ievFrom=%d, ievTo%d, nevAdd%d   . \n",ievFrom, ievTo, nevAdd);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::AddEquiDistantEvents(). Object properly not set.\n");
        return U_ERROR;
    }

    if(nEvents+nevAdd>nEventsAlloc)
    {
        int NewAlloc = nEvents+nevAdd;
        if(NewAlloc<100) NewAlloc  = 150;
        else             NewAlloc *= 2;

        UEvent* NewEvent = new UEvent[NewAlloc];
        if(NewEvent==NULL)
        {
            delete[] NewEvent; NewEvent = NULL;
            CI.AddToLog("ERROR: UEventArray::AddEquiDistantEvents(). Memory allocation. NewAlloc=%d\n",NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEvents; n++)
            NewEvent[n] = Events[n];

        delete[] Events;  Events = NewEvent;
        nEventsAlloc = NewAlloc;
    }
    double AbsSampFrom = Events[ievFrom].GetAbsSample(nSampTrial);
    double AbsSampTo   = Events[ievTo  ].GetAbsSample(nSampTrial);
    double Dist        = (AbsSampTo-AbsSampFrom)/(nevAdd+1);
    for(int n=0; n<nevAdd; n++)
    {
        int NewAbs        = int( floor( .5 + AbsSampFrom + (n+1)*Dist ));
        Events[nEvents+n] = UEvent(NewAbs/nSampTrial, NewAbs%nSampTrial);
    }
    nEvents += nevAdd;
    return SortEvents();
}
ErrorType UEventArray::AddEquiWidthEvents(int ievFrom, int ievTo, int Width)
{
    if(ievFrom<0      || ievFrom>=nEvents ||
       ievTo  <0      || ievTo  >=nEvents ||
       ievFrom>=ievTo || Width <=1)
    {
        CI.AddToLog("ERROR: UEventArray::AddEquiWidthEvents(). Argument(s) out of range: ievFrom=%d, ievTo%d, Width%d   . \n",ievFrom, ievTo, Width);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::AddEquiWidthEvents(). Object properly not set.\n");
        return U_ERROR;
    }

    int AbsSampFrom = GetAbsSample(ievFrom);
    int AbsSampTo   = GetAbsSample(ievTo);

    if(AbsSampTo <= AbsSampFrom)
    {
        CI.AddToLog("ERROR: UEventArray::AddEquiWidthEvents(). Events not properly sorted: AbsSampFrom = %d, AbsSampTo = %d.\n", AbsSampFrom, AbsSampTo);
        return U_ERROR;
    }
    int nevAdd = (AbsSampTo - AbsSampFrom)/Width;

    if(nEvents+nevAdd>nEventsAlloc)
    {
        int NewAlloc = nEvents+nevAdd;
        if(NewAlloc<100) NewAlloc  = 150;
        else             NewAlloc *= 2;

        UEvent* NewEvent = new UEvent[NewAlloc];
        if(NewEvent==NULL)
        {
            delete[] NewEvent; NewEvent = NULL;
            CI.AddToLog("ERROR: UEventArray::AddEquiWidthEvents(). Memory allocation. NewAlloc=%d\n",NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<nEvents; n++)
            NewEvent[n] = Events[n];

        delete[] Events;  Events = NewEvent;
        nEventsAlloc = NewAlloc;
    }
    int Nadded = 0;
    for(int n=0; n<nevAdd; n++)
    {
        int NewAbs        = AbsSampFrom + (n+1)*Width;
        if(NewAbs+Width>AbsSampTo) break;
        Events[nEvents+n] = UEvent(NewAbs/nSampTrial, NewAbs%nSampTrial);
        Nadded++;
    }
    if(Nadded<=0)
    {
        CI.AddToLog("WARNING: UEventArray::AddEquiWidthEvents(). Events too close to fit epochs of width %d: ievFrom = %d, ievTo = %d.\n", Width, GetAbsSample(ievFrom), GetAbsSample(ievTo));
        return U_OK;
    }

    nEvents += Nadded;
    return SortEvents();
}

ErrorType UEventArray::DeleteEvent(int iev)
{
    if(iev<0 || iev>=nEvents)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvent(). Argument out of range (%d), nEvents = %d\n",iev,nEvents);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvent(). Object properly not set.\n");
        return U_ERROR;
    }

    for(int k=iev; k<nEvents-1; k++)
        Events[k] = Events[k+1];
    nEvents--;
    return U_OK;
}

ErrorType UEventArray::DeleteEvents(int ievFrom, int ievTo)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(ievFrom<0) ievFrom = nEvents-1;
    if(ievTo  <0) ievTo   = nEvents-1;
    if(ievFrom>=nEvents || ievTo  >=nEvents || ievFrom>ievTo)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Argument(s) out of range: ievFrom=%d, ievTo%d  . \n",ievFrom, ievTo);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Object properly not set.\n");
        return U_ERROR;
    }

    int Nremove = ievTo-ievFrom+1;
    for(int k=ievFrom; k<nEvents-Nremove; k++)
        Events[k] = Events[k+Nremove];
    nEvents-=Nremove;
    return U_OK;
}

ErrorType UEventArray::DeleteEvents(const UEventArray* BadEvents, int Distance)
{
    if(BadEvents==NULL || BadEvents->GetError()!=U_OK || BadEvents->Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). NULL or erroneous BadEvents argument.\n");
        return U_ERROR;
    }
    if(Distance<0)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Invalid Distance parameter (Distance = %d) \n", Distance);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Object properly not set.\n");
        return U_ERROR;
    }
    if(nSampTrial!=BadEvents->nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Incompatible number of samples per trial: nSampTrial=%d and BadEvents->nSampTrial=%d   .\n", nSampTrial, BadEvents->nSampTrial);
        return U_ERROR;
    }

    for(int k=0; k<nEvents; k++)
    {
        for(int kBad=0; kBad<BadEvents->nEvents; kBad++)
        {
            int Nsamp = GetAbsSample(k)-BadEvents->GetAbsSample(kBad);
            if(abs(Nsamp) <= Distance)
            {
                DeleteEvent(k);
                k--;
                break;
            }
        }
    }
    return U_OK;
}

ErrorType UEventArray::DeleteEvents(const UEventArray* BadEvents, int From, int To)
{
    if(BadEvents==NULL || BadEvents->GetError()!=U_OK || BadEvents->Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). NULL or erroneous BadEvents argument.\n");
        return U_ERROR;
    }
    if(From>To)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Invalid range parameter (From = %d, To = %d) \n", From, To);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Object properly not set.\n");
        return U_ERROR;
    }
    if(nSampTrial!=BadEvents->nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEvents(). Incompatible number of samples per trial: nSampTrial=%d and BadEvents->nSampTrial=%d   .\n", nSampTrial, BadEvents->nSampTrial);
        return U_ERROR;
    }

    for(int k=0; k<nEvents; k++)
    {
        for(int kBad=0; kBad<BadEvents->nEvents; kBad++)
        {
            int Nsamp = GetAbsSample(k)-BadEvents->GetAbsSample(kBad);
            if(From<=Nsamp && Nsamp<=To)
            {
                DeleteEvent(k);
                k--;
                break;
            }
        }
    }
    return U_OK;
}

ErrorType UEventArray::DeleteEventsEpoch(const UEpochs* Epo, const UEventArray* BadEvents)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(nEvents==0) return U_OK;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). Object properly not set.\n");
        return U_ERROR;
    }

    if(Epo==NULL || Epo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). NULL or erroneous UEpochs argument.\n");
        return U_ERROR;
    }
    if(Epo->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). Number of samples per trial of UEpochs (%d) does not match nSampTrial (%d).\n", Epo->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(BadEvents==NULL || BadEvents->GetError()!=U_OK || BadEvents->Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). NULL or erroneous BadEvents argument.\n");
        return U_ERROR;
    }
    if(nSampTrial!=BadEvents->nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::DeleteEventsEpoch(). Incompatible number of samples per trial: nSampTrial=%d and BadEvents->nSampTrial=%d   .\n", nSampTrial, BadEvents->nSampTrial);
        return U_ERROR;
    }

    for(int k=0; k<nEvents; k++)
    {
        int kEpo = Epo->GetEpochIndex(Events[k]);
        if(kEpo<0) continue;

        for(int kBad=0; kBad<BadEvents->nEvents; kBad++)
        {
            int kEpoBad = Epo->GetEpochIndex(BadEvents->Events[kBad]);
            if(kEpoBad<0) continue;

            if(kEpo==kEpoBad)
            {
                DeleteEvent(k);
                k--;
                break;
            }
        }
    }
    return U_OK;
}
ErrorType UEventArray::SelectEventsEpoch(const UEpochs* Epo, int BegWin, int EndWin)
/*
    Select those events such that the windows from BegWin to EndWin completely fall inside the Epo windows (there are no gaps).
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsEpoch(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(nEvents==0) return U_OK;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsEpoch(). Object properly not set.\n");
        return U_ERROR;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsEpoch(). NULL or erroneous UEpochs argument.\n");
        return U_ERROR;
    }
    if(Epo->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsEpoch(). Number of samples per trial of UEpochs (%d) does not match nSampTrial (%d).\n", Epo->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(BegWin>EndWin)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsEpoch(). Invalid window argument (BegWin, EndWin) = (%d, %d).\n", BegWin, EndWin);
        return U_ERROR;
    }

    for(int k=0; k<nEvents; k++)
    {
        UEvent B = Events[k].GetShiftedEvent(BegWin, nSampTrial);
        UEvent E = Events[k].GetShiftedEvent(EndWin, nSampTrial);
        
        if(Epo->DoEpochsHaveGaps(B, E)==true)
        {
            DeleteEvent(k);
            k--;
            break;
        }
    }
    return U_OK;
}

ErrorType UEventArray::DeleteMiddleEvents()
{
    return DeleteEvents(1, nEvents-2);
}

ErrorType UEventArray::SelectEvent(int iev)
/*
   Delete all events, except iev.
   if(iev is out of range) delete all events
 */
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEvent(). Object properly not set.\n");
        return U_ERROR;
    }
    if(iev<0      || iev>=nEvents)
    {
        nEvents = 0;
        CI.AddToLog("ERROR: UEventArray::SelectEvent(). Argument out of range, delete all events, iev=%d  \n", iev);
        return U_ERROR;
    }

    Events[0] = Events[iev];
    nEvents = 1;
    return U_OK;
}
ErrorType UEventArray::SelectEventsAbsSamp(int SampBeg, int SampEnd)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsAbsSamp(). Object properly not set.\n");
        return U_ERROR;
    }
    if(SampBeg>SampEnd && SampEnd>=0)
    {
        CI.AddToLog("ERROR: UEventArray::SelectEventsAbsSamp(). Invaild arguments: (SampBeg, SampEnd) = (%d, %d).\n", SampBeg, SampEnd);
        return U_ERROR;
    }

    int Nkeep = 0;
    for(int iev=0; iev<nEvents; iev++)
    {
        int samp = GetAbsSample(iev);
        if(SampBeg>=0 && samp<SampBeg) continue;
        if(SampEnd>=0 && SampEnd<samp) continue;

        Events[Nkeep++] = Events[iev];
    }
    nEvents = Nkeep;
    return U_OK;
}

ErrorType UEventArray::ShiftEvent(int iev, int NShift) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(NShift==0   ) return U_OK;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::ShiftEvent(). Object properly not set.\n");
        return U_ERROR;
    }
    if(iev<0 || iev>=nEvents)
    {
        CI.AddToLog("ERROR: UEventArray::ShiftEvent(). Argument out of range, iev=%d  \n", iev);
        return U_ERROR;
    }
    UEvent E = Events[iev].GetShiftedEvent(NShift, nSampTrial);
    if(E.trial<0) E = UEvent();
    Events[iev] = E;
    return U_OK;
}

ErrorType UEventArray::ShiftAllEvents(int NShift) const
{
    if(NShift==0   ) return U_OK;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::ShiftAllEvents(). Object properly not set.\n");
        return U_ERROR;
    }
    for(int iev=0; iev<nEvents; iev++)
        if(ShiftEvent(iev, NShift)!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::ShiftAllEvents(). Shifting event %d .\n", iev);
            return U_ERROR;
        }
    return U_OK;
}

ErrorType UEventArray::DownSample(int DownSamp, int Phase)
{
    if(DownSamp==1) return U_OK;
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::DownSample(). Object properly not set.\n");
        return U_ERROR;
    }

    if(DownSamp<=0 || Phase<0)
    {
        CI.AddToLog("ERROR: UEventArray::DownSample(). Parameters out of range: DownSamp=%d, Phase=%d.\n", DownSamp, Phase);
        return U_ERROR;
    }
    if(AreEventsSortedIncr()==false)
    {
        CI.AddToLog("ERROR: UEventArray::DownSample(). Events not sorted. \n");
        return U_ERROR;
    }
    if(Phase>=DownSamp) Phase= Phase%DownSamp;

    int Nev = Phase;
    int iev = 0;
    for(; iev<nEvents && Nev<nEvents; iev++, Nev+=DownSamp)
    {
        Events[iev] = Events[Nev];
    }
    nEvents = iev;
    return U_OK;
}

ErrorType UEventArray::StretchEvents(int ievRef, int ievShift, int NShift) const
{
    if(NShift==0   ) return U_OK;
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::StretchEvents(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::StretchEvents(). Object properly not set.\n");
        return U_ERROR;
    }
    if(nEvents<2)
    {
        CI.AddToLog("ERROR: UEventArray::StretchEvents(). Too small numbr of events: nEvents=%d  .\n", nEvents);
        return U_ERROR;
    }
    if(ievRef  <0 || ievRef  >=nEvents ||
       ievShift<0 || ievShift>=nEvents ||
       ievRef==ievShift)
    {
        CI.AddToLog("ERROR: UEventArray::StretchEvents(). Events out of range: ievRef=%d, ievShift=%d  .\n", ievRef, ievShift);
        return U_ERROR;
    }
    double tRef = this->GetAbsSample(ievRef  );
    double tShi = this->GetAbsSample(ievShift);
    if(tRef==tShi)
    {
        CI.AddToLog("ERROR: UEventArray::StretchEvents(). Events coincide: ievRef=%d, ievShift=%d  .\n", ievRef, ievShift);
        return U_ERROR;
    }

/* Compute the stretch */
    for(int iev=0; iev<nEvents; iev++)
    {
        int Shift = int( floor(.5 + NShift * (this->GetAbsSample(iev)-tRef) / (tShi-tRef) ) );
        if(ShiftEvent(iev, Shift)!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::ShiftAllEvents(). Shifting event %d .\n", iev);
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UEventArray::SortEvents(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::SortEvents(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::SortEvents(). Object properly not set.\n");
        return U_ERROR;
    }
    StaticNsampPerTrial = nSampTrial;
    qsort(Events, nEvents, sizeof(Events[0]), SortEvent);
    return U_OK;
}

bool UEventArray::AreEventsSortedIncr(void) const
{
    if(this==NULL || Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::AreEventsSortedIncr(). Events not set. return false\n");
        return false;
    }

    for(int n=0; n<nEvents-1; n++)
        if(GetAbsSample(n)>GetAbsSample(n+1)) return false;
    return true;
}

const UString& UEventArray::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMarker-object\n");
        return Properties;
    }

    Properties = UString();

    Properties += UString(EventName,    "EventsName    = %s \n");
    Properties += UString(nEvents,      "nEvents       = %d \n");
    Properties += UString(nEventsAlloc, "nEventsAlloc  = %d \n");
    Properties += UString(nSampTrial,   "nSampTrial    = %d \n");
    Properties += UString(BoolAsText(AreEventsSortedIncr()), "EventsSortedInc = %s \n");

    if(nEvents>1)
    {
        Properties += UString(GetMinInterval(),   "MinInterval    = %d \n");
        Properties += UString(GetMedianInterval(),"MedianInterval = %d \n");
        Properties += UString(GetMaxInterval(),   "MaxInterval    = %d \n");
    }
    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);
    return Properties;
}


ErrorType UEventArray::LogProperties(void) const
/*
    Add properties to standard .log file
 */
{
    CI.AddToLog("EventsName = %s\n", EventName);
    CI.AddToLog("nEvents = %d\n", nEvents);
    CI.AddToLog("Event(t,s)  \tAbsSample \n");
    for(int n=0; n<nEvents; n++)
        CI.AddToLog(" %d \t%d  \t%d \n",Events[n].trial,Events[n].sample, Events[n].GetAbsSample(nSampTrial));
    return U_OK;
}

ErrorType UEventArray::ResampleData(int NewNSampTrial)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::ResampleData(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(Events==NULL) return U_OK;
    if(NewNSampTrial==nSampTrial) return U_OK;

    if(NewNSampTrial<=0 || nSampTrial<=0)
    {
        CI.AddToLog("ERROR: UEventArray::ResampleData(). Invalid argument (NewNSampTrial=%d, nSampTrial=%d).\n", NewNSampTrial, nSampTrial);
        return U_ERROR;
    }
    double StretchFactor = NewNSampTrial/double(nSampTrial);

    for(int n=0; n<nEvents; n++)
    {
        int isamp = int( Events[n].sample * StretchFactor );
        Events[n].sample = isamp;
    }
    nSampTrial = NewNSampTrial;
    return U_OK;
}

ErrorType UEventArray::RedistributeTrials(int SkipSamples, int NewSamplesTrial)
/*
    Redistribute all the events by redistributing the trials over the raw data set.
    This is done by skipping the first SkipSamples in the file, and then making trials
    of NewSamplesTrial samples each.

    Remove events with negative trial number
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NewSamplesTrial<=0)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). NewSamplesTrial (=%d) out pf range. \n", NewSamplesTrial);
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Events array not set.\n");
        return U_ERROR;
    }

    int nEvInRange = 0;
    for(int n=0; n<nEvents; n++)
    {
        int AbsSamp = this->GetAbsSample(n);
        if(AbsSamp<SkipSamples) continue;

        int trial              = (AbsSamp-SkipSamples)/NewSamplesTrial;
        int samp               = (AbsSamp-SkipSamples)%NewSamplesTrial;
        Events[nEvInRange++]   = UEvent(trial, samp);
    }
    nEvents    = nEvInRange;
    nSampTrial = NewSamplesTrial;

    return U_OK;
}

ErrorType UEventArray::RedistributeTrials(const UEpochs* NewEpochs)
/*
    Redistribute all the events by redistributing the trials over the raw data set.
    This is done by determining in which epoch(s) of NewEpochs each
    event is residing, and setting the trial number equal to that (those) epochs. The
    new sample number will be set equal to the sample of the fitting epoch.
    If an event fits in multiple epochs, that event is copied, with different
    sample and trial numbers.

    Remove events with that are outside all of the epochs in NewEpochs.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Events not set. \n");
        return U_ERROR;
    }
    if(NewEpochs==NULL || NewEpochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(NewEpochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Epoch times are not equal. \n");
        return U_ERROR;
    }
    if(NewEpochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", NewEpochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }

    UEventArray* NewEvents = new UEventArray(*this);
    if(NewEvents==NULL || NewEvents->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Copying epochs. \n");
        return U_ERROR;
    }

    NewEvents->SetnEvents(0);
    for(int n=0; n<nEvents; n++)
    {
        int absamp = Events[n].GetAbsSample(nSampTrial);
        for(int iep=0; iep<NewEpochs->GetnEpochs(); iep++)
        {
            if(NewEpochs->IsInEpoch(iep, Events[n])==false) continue;
            UEvent E(iep, absamp-NewEpochs->GetBegin(iep).GetAbsSample(nSampTrial));
            if(NewEvents->AddEvent(E)!=U_OK)
            {
                delete NewEvents;
                CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Adding event. \n");
                return U_ERROR;
            }
        }
    }

    *this      = *NewEvents;
    nSampTrial = NewEpochs->GetNsamp(0);
    delete NewEvents;
    return error;
}
ErrorType UEventArray::RedistributeTrials(const UEpochs* NewEpochs, double SRateOld, double SRateNew)
/*
    Redistribute all the events by redistributing the trials over the raw data set.
    This is done by determining in which epoch(s) of NewEpochs each
    event is residing, and setting the trial number equal to that (those) epochs. The
    new sample number will be set equal to the sample of the fitting epoch.
    If an event fits in multiple epochs, that event is copied, with different
    sample and trial numbers.

    Remove events with that are outside all of the epochs in NewEpochs.
    Account for ratio of old and new sampling rate (SRateOld, resp. SRateNew)
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Events not set. \n");
        return U_ERROR;
    }
    if(NewEpochs==NULL || NewEpochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(NewEpochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Epoch times are not equal. \n");
        return U_ERROR;
    }
    if(NewEpochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", NewEpochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(SRateOld<=0. || SRateNew<=0.)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Sampling rage parameter(s) out of range (SRateOld=%f, SRateNew=%f). \n", SRateOld, SRateNew);
        return U_ERROR;
    }

    UEventArray* NewEvents = new UEventArray(*this);
    if(NewEvents==NULL || NewEvents->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Copying epochs. \n");
        return U_ERROR;
    }

    int nSampEpochNew = int( NewEpochs->GetNsamp(0) * (SRateNew/SRateOld) );

    NewEvents->SetnEvents(0);
    for(int n=0; n<nEvents; n++)
    {
        int    absamp  = Events[n].GetAbsSample(nSampTrial);
        double abstime = absamp * SRateOld;
        for(int iep=0; iep<NewEpochs->GetnEpochs(); iep++)
        {
            double TimeB = NewEpochs->GetBeginSample(iep) * SRateOld;
            double TimeE = NewEpochs->GetEndSample(iep)   * SRateOld;

            if(TimeB<=abstime && abstime<TimeE)
            {
                int newtrial = iep;
                int newsamp  = absamp-NewEpochs->GetBegin(iep).GetAbsSample(nSampTrial);
                newsamp      = int(newsamp * (SRateNew/SRateOld));
                if(newsamp>=0 && newsamp<nSampEpochNew)
                {
                    UEvent E(newtrial, newsamp);
                    if(NewEvents->AddEvent(E)!=U_OK)
                    {
                        delete NewEvents;
                        CI.AddToLog("ERROR: UEventArray::RedistributeTrials(). Adding event. \n");
                        return U_ERROR;
                    }
                }
            }
        }
    }

    *this      = *NewEvents;
    nSampTrial = nSampEpochNew;
    delete NewEvents;
    return error;
}

ErrorType UEventArray::CopyToAllEpochs(int iev, const UEpochs* Epochs)
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::CopyToAllEpochs(). Events not set. \n");
        return U_ERROR;
    }
    if(iev<0 || iev>= nEvents)
    {
        CI.AddToLog("ERROR: UEventArray::CopyToAllEpochs(). Event out of range, iev=%d   . \n", iev);
        return U_ERROR;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::CopyToAllEpochs(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(Epochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::CopyToAllEpochs(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", Epochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    int Shift = 0;
    int Iep   = Epochs->GetEpochIndex(GetEvent(iev), &Shift);
    if(Iep<0)
    {
        CI.AddToLog("ERROR: UEventArray::CopyToAllEpochs(). Sample event does not belong to any epoch, iev=%d. \n", iev);
        return U_ERROR;
    }
    for(int n=0; n<Epochs->GetnEpochs(); n++)
    {
        if(n==Iep) continue;

        UEvent E = Epochs->GetBegin(n);
        AddEvent(E.GetShiftedEvent(Shift, nSampTrial));
    }
    return U_OK;
}

ErrorType UEventArray::CopyAllEventsToAllEpochs(int iep, const UEpochs* Epochs)
{
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::CopyAllEventsToAllEpochs(). Events not set. \n");
        return U_ERROR;
    }
    if(Epochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UEventArray::CopyAllEventsToAllEpochs(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", Epochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(iep<0 || iep>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UEventArray::CopyAllEventsToAllEpochs(). Epoch out of range, iep = %d .\n",iep);
        return U_ERROR;
    }

/* Copy events of epoch iep to seperate UEventArray */
    ErrorType E = U_OK;
    UEventArray EpochEvents("NoName", 0, nSampTrial);
    for(int iev=0; iev<nEvents; iev++)
        if(Epochs->IsInEpoch(iep, Events[iev])==true)
            if(E==U_OK) E = EpochEvents.AddEvent(Events[iev]);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::CopyAllEventsToAllEpochs(). Copying subset of events. \n");
        return U_ERROR;
    }


    for(int n=0; n<Epochs->GetnEpochs(); n++)
    {
        if(n==iep) continue;

        UEvent BeginEpoch = Epochs->GetBegin(n);
        for(int i=0; i<EpochEvents.GetnEvents(); i++)
        {
            int Shift = 0;
            int Iep   = Epochs->GetEpochIndex(EpochEvents.GetEvent(i), &Shift);
            if(Iep<0) continue;

            AddEvent(BeginEpoch.GetShiftedEvent(Shift, nSampTrial));
        }
    }
    return U_OK;
}

double* UEventArray::GetCrossMatrix(int NLeft, int NRight, int Ntrial) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossMatrix(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossMatrix(). Events not set.\n");
        return NULL;
    }
    int MatDim = NRight+NLeft+1;
    if(MatDim<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossMatrix(). Invalid arguments (NLeft=%d, NRight=%d).\n", NLeft, NRight);
        return NULL;
    }
    UEventArray EventSort(*this);
    if(EventSort.GetError()!=U_OK || EventSort.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossMatrix(). Copying or sorting events. \n");
        return NULL;
    }

    double* Matrix = new double[MatDim*MatDim];
    if(Matrix==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossMatrix(). Memory allocation (NLeft=%d, NRight=%d, MatDim=%d).\n", NLeft, NRight, MatDim);
        return NULL;
    }
    for(int ii=0; ii<MatDim*MatDim; ii++) Matrix[ii] = 0.;


    int MaxSamp = Ntrial*nSampTrial;
    for(int iev1=0; iev1<EventSort.nEvents; iev1++)
    {
        int isamp1 = EventSort.GetAbsSample(iev1);
        int b1     = isamp1-NLeft;
        int e1     = isamp1+NRight;
        if(b1>=MaxSamp || e1<0) continue;
        for(int iev2=0; iev2<EventSort.nEvents; iev2++)
        {
            int isamp2 = EventSort.GetAbsSample(iev2);
            int b2     = isamp2-NLeft;
            int e2     = isamp2+NRight;
            if(b2>=MaxSamp || e1<0) continue;

            if(e1<b2) break;
            if(e2<b1) continue;

            int diff = isamp1-isamp2;
            if(diff>=0) for(int k= diff; k<MatDim; k++) Matrix[MatDim*(k-diff)+k     ]++;
            else        for(int k=-diff; k<MatDim; k++) Matrix[MatDim* k      +k+diff]++;
        }
    }
    return Matrix;
}
double* UEventArray::GetCrossingArray(int NLeft, int NRight, int Ntrial) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Events==NULL || nEvents<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingArray(). Events not set.\n");
        return NULL;
    }
    int ArrDim = NRight+NLeft+1;
    if(ArrDim<=0)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingArray(). Invalid arguments (NLeft=%d, NRight=%d).\n", NLeft, NRight);
        return NULL;
    }
    UEventArray EventSort(*this);
    if(EventSort.GetError()!=U_OK || EventSort.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingArray(). Copying or sorting events. \n");
        return NULL;
    }

    double* Array = new double[ArrDim];
    if(Array==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingArray(). Memory allocation (NLeft=%d, NRight=%d, ArrDim=%d).\n", NLeft, NRight, ArrDim);
        return NULL;
    }
    for(int ii=0; ii<ArrDim; ii++) Array[ii] = 0.;


    int MaxSamp = Ntrial*nSampTrial;
    for(int iev1=0; iev1<EventSort.nEvents; iev1++)
    {
        int isamp1 = EventSort.GetAbsSample(iev1);
        int b1     = isamp1-NLeft;
        int e1     = isamp1+NRight;
        if(b1>=MaxSamp || e1<0) continue;
        for(int iev2=iev1; iev2<EventSort.nEvents; iev2++)
        {
            int isamp2 = EventSort.GetAbsSample(iev2);
            int b2     = isamp2-NLeft;
            int e2     = isamp2+NRight;
            if(b2>=MaxSamp || e1<0) continue;

            if(e1<b2) break;
            if(e2<b1) continue;

            int diff = isamp2-isamp1;
            Array[diff]++;
        }
    }
    return Array;
}

UMatrixSymmetric* UEventArray::GetCrossingBlockMatrix(int NLeft, int NRight, int Ntrial) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Events array not set.\n");
        return NULL;
    }
    if(nEvents<0)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Too few events (nEvents = %d ).\n", nEvents);
        return NULL;
    }
    if(AreEventsSortedIncr()==false)
    {
        UEventArray ECopy(*this);
        if(ECopy.GetError()!=U_OK || ECopy.SortEvents()!=U_OK)
        {
            CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Copying or sorting unsorted events. \n");
            return NULL;
        }
        return ECopy.GetCrossingBlockMatrix(NLeft, NRight, Ntrial);
    }

    int NWindow = NRight+NLeft+1;
    int MaxSamp = Ntrial*nSampTrial;
    UMatrix M(DNULL, NWindow, NWindow);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Creating coincidence matrix, NWindow = %d .\n", NWindow);
        return NULL;
    }

    double* Data = M.Data;
    for(int iev1=0; iev1<nEvents; iev1++)
    {
        int isamp1 = GetAbsSample(iev1);
        int b1     = isamp1-NLeft;
        int e1     = isamp1+NRight;
        if(b1>=MaxSamp || e1<0) continue;

        for(int iev2=0; iev2<nEvents; iev2++)
        {
            int isamp2 = GetAbsSample(iev2);
            int b2     = isamp2-NLeft;
            int e2     = isamp2+NRight;
            if(b2>=MaxSamp || e2<0) continue;
            
            if(e2<b1 || b2>e1) continue; // No overlap with win1

            for(int j=MAX(b1,b2); j<=MIN(e1,e2); j++)
            {
                if(j<0       ) continue; 
                if(MaxSamp<=j) break;
                int k1 = j - b1;
                int k2 = j - b2;
                if(k1>=NWindow || k2>=NWindow) break;
                Data[k1 *NWindow + k2] += 1.;
            }
        }
    }

    UMatrixSymmetric* pMS = new UMatrixSymmetric(M);
    if(pMS==NULL || pMS->GetError()!=U_OK)
    {
        delete   pMS;
        CI.AddToLog("ERROR: UEventArray::GetCrossingBlockMatrix(). Creating UMatrixSymmetric from full coincidence matrix.\n");
        return NULL;
    }
    return pMS;
}

double* GetCrossingBlockArray(const UEventArray* const* Evar, int NEvar, int NLeft, int NRight, int Ntrial)
{
    if(Evar==NULL || NEvar<=0)
    {
        CI.AddToLog("ERROR: GetCrossingBlockArray(). Invalid NULL pointer argument, or erroneous NEvar (=%d) .\n", NEvar);
        return NULL;
    }

    UEventArray** EvSort = new UEventArray*[NEvar];
    if(EvSort==NULL)
    {
        CI.AddToLog("ERROR: GetCrossingBlockArray(). Memory allocation, NEvar =%d .\n", NEvar);
        return NULL;
    }
    for(int im=0; im<NEvar; im++) EvSort[im] = NULL;

    int nSampTrial = 0;
    for(int im=0; im<NEvar; im++)
    {
        if(Evar[im]==NULL || Evar[im]->GetError()!=U_OK || Evar[im]->GetnEvents()<=0)
        {
            CI.AddToLog("ERROR: GetCrossingBlockArray(). Event array [%d] NULL, erroneous or empty. \n", im);
            return NULL;
        }
        EvSort[im] = new UEventArray(*(Evar[im]));
        if(EvSort[im]==NULL || EvSort[im]->GetError()!=U_OK || EvSort[im]->SortEvents()!=U_OK)
        {
            CI.AddToLog("ERROR: GetCrossingBlockArray(). Copying or sorting UEventArray [%d] . \n", im);
            for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
            return NULL;
        }
        if(im==0)
        {
            nSampTrial = Evar[0]->GetnSampTrial();
            continue;
        }
        if(nSampTrial != Evar[im]->GetnSampTrial())
        {
            CI.AddToLog("ERROR: GetCrossingBlockArray(). nSampTrial (%d) not constant ever array elements. \n", Evar[im]->GetnSampTrial());
            for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
            return NULL;
        }
    }
    if(nSampTrial<=0)
    {
        CI.AddToLog("ERROR: GetCrossingBlockArray(). Invalid nSampTrial (= %d) .\n", nSampTrial);
        for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
        return NULL;
    }

    int NWindow = NRight+NLeft+1;
    int ArrDim  = NEvar*NEvar*2*NWindow;
    if(ArrDim<=0)
    {
        CI.AddToLog("ERROR: GetCrossingBlockArray(). Invalid arguments (NLeft=%d, NRight=%d).\n", NLeft, NRight);
        for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
        return NULL;
    }

    double* ColRowArray = new double[ArrDim];
    if(ColRowArray==NULL)
    {
        CI.AddToLog("ERROR: GetCrossingBlockArray(). Memory allocation (NLeft=%d, NRight=%d, ArrDim=%d).\n", NLeft, NRight, ArrDim);
        for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
        return NULL;
    }
    for(int kk=0; kk<ArrDim; kk++) ColRowArray[kk] = 0.;

    int MaxSamp = Ntrial*nSampTrial;

    for(int im1=0; im1<NEvar; im1++)
    {
        for(int iev1=0; iev1<EvSort[im1]->GetnEvents(); iev1++)
        {
            int isamp1 = EvSort[im1]->GetAbsSample(iev1);
            int b1     = isamp1-NLeft;
            int e1     = isamp1+NRight;
            if(b1>=MaxSamp || e1<0) continue;

            for(int im2=0; im2<NEvar; im2++)
            {
                for(int iev2=0; iev2<EvSort[im2]->GetnEvents(); iev2++)
                {
                    int isamp2 = EvSort[im2]->GetAbsSample(iev2);
                    int b2     = isamp2-NLeft;
                    if(b2>=MaxSamp || e1<0) continue;

                    int     diff   = isamp2-isamp1;
                    if(abs(diff)>=NWindow) continue;

                    double* ColRow = ColRowArray+(im1*NEvar+im2)*2*NWindow;
                    if(diff>=0) ColRow[        diff] += 1;   // First collumn
                    if(diff<=0) ColRow[NWindow-diff] += 1;   // First row
                }
            }
        }
    }
    for(int im=0; im<NEvar; im++) delete EvSort[im]; delete[] EvSort;
    return ColRowArray;
}
