#ifndef _EVENTARRAY_INCLUDED
#define _EVENTARRAY_INCLUDED

#include "Event.h"
#include "String.h"


class UEpochs;
class UField;
class UFieldGraph;
class UMatrixSymmetric;

class DLL_IO UEventArray 
{
public:
    UEventArray();
    UEventArray(const char *name, int nEv, int NsampPTrial);
    UEventArray(const UEventArray& evar);
    virtual ~UEventArray();

    UEventArray&        operator=(const UEventArray &Evar);
    bool                operator==(const UEventArray &E) const;
    bool                operator!=(const UEventArray &E) const {return NOT(operator==(E));}

    ErrorType           GetError(void)      const {return error;}
    const UString&      GetProperties(UString Comment) const;

    int                 GetnEvents(void)    const {if(this) return nEvents;    return 0;} 
    const char*         GetName(void)       const {if(this) return EventName;  return NULL;}
    const char*         GetEventName(void)  const {if(this) return EventName;  return NULL;}
    int                 GetnSampTrial(void) const {if(this) return nSampTrial; return 0;}

    UEvent              GetEvent(int iev) const;
    int                 GetIndex(UEvent E) const;
    UEvent              GetFirstEvent(void) const;
    double              GetFirstEventTime(double SampleTime) const;
    double              GetLastEventTime(double SampleTime) const;
    double              GetAverageTimeInterval(double SampleTime) const;
    double              GetAverageTimeInterval(const UFieldGraph* FG, int Level, double SampleTime) const;

    int                 GetMaxInterval(void) const;
    int                 GetMinInterval(void) const;
    int                 GetMedianInterval(void) const;
    int                 GetMedianInterval(const UEventArray* SubSetEvents) const;
    double              GetMaxIntervalChange(void) const;

    UString             GetIntervalsText(double Stime) const;
    UFieldGraph*        GetIntervalsSinCos(double Stime, double Shift, double DownSample, int Harm, bool Sin) const;
    UFieldGraph*        GetIntervalsSinCos(const UEpochs* Epo, double Stime, int Harm, bool Sin, int NSegment) const;
    UFieldGraph*        GetIntervalsEpoch(const UEpochs* Epo, double Stime, int NSegment, double DeadTimeBeg_s, double DeadTimeEnd_s, double IntervalWindow_s, bool ComputeSD) const;
    UFieldGraph*        GetIntervalsSeries(double Stime, bool Uniform) const;
    UFieldGraph*        GetTimesFirstInEpoch(const UEpochs* Epo, double Stime) const;

    UMatrixSymmetric*   GetCrossingBlockMatrix(int NLeft, int NRight, int Ntrial) const;

    UEvent              GetBeginShortestInterval(int *ievent, int* Interval) const;
    UEvent              GetEndShortestInterval(int *ievent, int* Interval) const;
    UEvent              GetBeginLongestInterval(int *ievent, int* Interval) const;
    UEvent              GetEndLongestInterval(int *ievent, int* Interval) const;
    UEvent              GetLargestIntervalChange(int *ievent, double* Ratio) const;
    UEventArray*        GetBeginDeviatingIntervals(int Threshold, bool ShortIntervals, bool LongIntervals) const;
    int*                GetNMatchPerEpoch(const UEpochs* Epochs, int* NtotMatch, int* NSingleMatch) const;
    int*                GetInEpochArray(const UEpochs* Epochs, int* NEpochs) const;

    ErrorType           SetnEvents(int nEv);
    ErrorType           SetEvent(int iev, UEvent ev);
    ErrorType           AddEvent(UEvent ev);
    ErrorType           AddEvent(int AbsSamp);
    ErrorType           AddEquiDistantEvents(int ievFrom, int ievTo, int nevAdd);
    ErrorType           AddEquiWidthEvents(int ievFrom, int ievTo, int Width);
    ErrorType           SetEquiDistant(double Interval, double SampleTime, int* Remainder);
    ErrorType           DeleteEvent(int iev);
    ErrorType           DeleteEvents(int ievFrom, int ievTo);
    ErrorType           DeleteEvents(const UEventArray* BadEvents, int Distance);
    ErrorType           DeleteEvents(const UEventArray* BadEvents, int From, int To);
    ErrorType           DeleteEventsEpoch(const UEpochs* Epo, const UEventArray* BadEvents);
    ErrorType           DeleteMiddleEvents();
    ErrorType           SelectEvent(int iev);
    ErrorType           SelectEventsAbsSamp(int SampBeg, int SampEnd);
    ErrorType           SelectEventsEpoch(const UEpochs* Epo, int BegWin, int EndWin);

    ErrorType           ShiftEvent(int NShift, int ievent) const;
    ErrorType           ShiftAllEvents(int NShift) const;
    ErrorType           StretchEvents(int ievRef, int ievShift, int NShift) const;
    ErrorType           DownSample(int DownSamp, int Phase);
    
    ErrorType           SortEvents(void);
    bool                AreEventsSortedIncr(void) const;
    int                 GetAbsSample(int iev) const;
    ErrorType           SetName(const char* Name);
    ErrorType           PrependName(const char* Prep);

    ErrorType           Merge(const UEventArray* EvAr);

    ErrorType           LogProperties(void) const;
    ErrorType           ResampleData(int NewNSampTrial);
    ErrorType           RedistributeTrials(int SkipSamples, int NewSamplesTrial);
    ErrorType           RedistributeTrials(const UEpochs* NewEpochs);
    ErrorType           RedistributeTrials(const UEpochs* NewEpochs, double SRateOld, double SRateNew);
    ErrorType           CopyToAllEpochs(int iev, const UEpochs* Epochs);
    ErrorType           CopyAllEventsToAllEpochs(int iep, const UEpochs* Epochs);

    double*             GetCrossMatrix(int NLeft, int NRight, int Ntrial) const;
    double*             GetCrossingArray(int NLeft, int NRight, int Ntrial) const;

    ErrorType           SaveMatLab(UFileName F) const;
protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;                    // General ERROR flag
    static UString      Properties;               // General properties string

    UString             EventName;                // Name of the events
    int                 nEvents;                  // Number of events
    int                 nEventsAlloc;             // Number of evevts for which memory is allocated
    UEvent              *Events;                  // The Array of events 
    int                 nSampTrial;               // The number of samples per trial 
};

PMT_DP DLL_IO GetCrossingBlockArray(const UEventArray* const* Evar, int NEvar, int NLeft, int NRight, int Ntrial);

#endif //_EVENTARRAY_INCLUDED
