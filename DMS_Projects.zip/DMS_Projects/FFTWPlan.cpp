/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Module to keep a list of pointers to FFT-plans, each of a certain number of */
/*   points. The goal of this object is to be used a a global object, so that    */
/*   plans can be kept available for any part in the program.                    */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    12-06-03   Creation, copied part of EpochStatistics
  JdM    20-06-03   GetPlan(). Wrong testing in case of Forward==false, ManyFFT==false
  JdM    07-07-04   Added wisdom
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM/SG 10-11-04   BUG Fix: GetPlan(). If there are more than MAX_FFTW_PLAN plans, only delete either forward or inverse plan
                    Increased MAX_FFTW_PLAN to 512
  JdM    19-01-05   Added ::ShiftDataFFT()
  JdM    08-04-05   Added SetWisdomDir() to store wisdom file in pre-defined directory
  JdM    05-06-05   Bug fix: saving wisdom file. Avoid using static UFileName (is deleted before FFTW destructor is called)
  JdM    25-10-05   Added DoesPlanExist()
  JdM    29-05-09   Renamed DoesPlanExist() and GetPlan() into DoesRealPlanExist() and GetRealPlan()
                    Added DoesComplexPlanExist() and GetComplexPlan() and HilbertTransform()
  JdM    30-05-09   Added SaveWisdom()
  JdM    03-03-18   Set default Wisdom dir in constructor UFFTWPlan()
*/


#include <math.h>
#include <string.h>

#include "BasicInclude.h"
#include "FFTWPlan.h"
#include "Directory.h"
#include "FileName.h"

#define DEFAULTWISDOMFILE "FFTWisdom.txt"    
char UFFTWPlan::WisdomFile[] = DEFAULTWISDOMFILE;


UFFTWPlan::UFFTWPlan()
{
    for(int k=0; k<MAX_REAL_FFTW_PLAN; k++)
    {
        RPlanArray[k].NFFT  = 0;
        RPlanArray[k].pForw = NULL;
        RPlanArray[k].pBack = NULL;
    }
    for(int k=0; k<MAX_COMPLEX_FFTW_PLAN; k++)
    {
        CPlanArray[k].NFFT  = 0;
        CPlanArray[k].pForw = NULL;
        CPlanArray[k].pBack = NULL;
    }


#if defined(__WIN32__) || defined(WIN32) || defined(WIN64) || defined(MSVC_2017)
    FFTW.SetWisdomDir("C:\\TempQt");
#else
    FFTW.SetWisdomDir("~/TempQt");
#endif

    FILE *fp = fopen(WisdomFile, "r");
    if(fp==NULL) 
    {
        CI.AddToLog("WARNING: UFFTWPlan::UFFTWPlan(). Cannot open file for reading: %s \n", WisdomFile);
        return;
    }
    fftw_import_wisdom_from_file(fp);
    fclose(fp);
}

UFFTWPlan::~UFFTWPlan()
{
    for(int k=0; k<MAX_REAL_FFTW_PLAN; k++)
    {
        if(RPlanArray[k].pForw) rfftw_destroy_plan(RPlanArray[k].pForw);
        if(RPlanArray[k].pBack) rfftw_destroy_plan(RPlanArray[k].pBack);
    }
    for(int k=0; k<MAX_COMPLEX_FFTW_PLAN; k++)
    {
        if(CPlanArray[k].pForw) fftw_destroy_plan(CPlanArray[k].pForw);
        if(CPlanArray[k].pBack) fftw_destroy_plan(CPlanArray[k].pBack);
    }
    SaveWisdom();
}
void UFFTWPlan::SaveWisdom() const
{
    FILE *fp = fopen(WisdomFile, "w", false);
    if(fp==NULL)
    {
        CI.AddToLog("WARNING: UFFTWPlan::SaveWisdom(). Cannot open file for writing: %s \n", WisdomFile);
        return;
    }
    fftw_export_wisdom_to_file(fp);
    fclose(fp);
}

void UFFTWPlan::SetWisdomDir(const char* DefDir)
{
    if(DefDir==NULL)
    {
        strcpy(WisdomFile, DEFAULTWISDOMFILE);
        return;
    }

    UDirectory D(DefDir, false);
    D.CompletePath();
    if(D.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UFFTWPlan::SetWisdomDir(). Cannot create FFTW Wisdom directory: %s \n", DefDir);
        return;
    }
    UFileName  FWisdom = UFileName(DefDir, DEFAULTWISDOMFILE);
    strncpy(WisdomFile, (const char*)FWisdom, MAX_WISDOM_FILENAME-1);

    FILE *fp = fopen(FWisdom, "r", true);
    if(fp==NULL) return;
    fftw_import_wisdom_from_file(fp);
    fclose(fp);
}

bool UFFTWPlan::DoesRealPlanExist(int Nsamples, bool Forward) const
{
    for(int k=0; k<MAX_REAL_FFTW_PLAN; k++)
    {
        if(Nsamples==RPlanArray[k].NFFT)
        {
            if(Forward==true  && RPlanArray[k].pForw!=NULL) return true;
            if(Forward==false && RPlanArray[k].pBack!=NULL) return true;
        }
    }
    return false;
}
const rfftw_plan UFFTWPlan::GetRealPlan(int Nsamples, bool Forward, bool ManyFFT)
/*
     Return an existing plan if there exists one, else create a new plan and
     keep a copy (of its pointer).
 */
{
    if(Nsamples<=0)
    {
        CI.AddToLog("ERROR: UFFTWPlan::GetRealPlan(). Nsamples = %d out of range.\n",Nsamples);
        return NULL;
    }
#ifdef MSVC_2017
    ManyFFT = false;
#endif // MSVC_2017

    for(int k=0; k<MAX_REAL_FFTW_PLAN; k++)
    {
        if(Nsamples==RPlanArray[k].NFFT)
        {
            if(Forward==true  && RPlanArray[k].pForw!=NULL) return RPlanArray[k].pForw;
            if(Forward==false && RPlanArray[k].pBack!=NULL) return RPlanArray[k].pBack;
        }
    }

/* Search for and empty slot*/
    int iplan = -1;
    for(int k=0; k<MAX_REAL_FFTW_PLAN; k++)
        if(RPlanArray[k].NFFT==0) {iplan=k; break;}
    
    if(iplan<0)
    {
        iplan = 0;
        if(Forward==true)
        {
            if(RPlanArray[0].pForw) rfftw_destroy_plan(RPlanArray[0].pForw);
            RPlanArray[0].pForw = NULL;
        }
        else
        {
            if(RPlanArray[0].pBack) rfftw_destroy_plan(RPlanArray[0].pBack);
            RPlanArray[0].pBack = NULL;
        }
    }

/* and create new one */
    if(Forward==true)  CI.AddToLog("Note: UFFTWPlan::GetRealPlan(). Create a new forward FFTW-plan in slot %d with %d samples.\n",iplan, Nsamples);
    else               CI.AddToLog("Note: UFFTWPlan::GetRealPlan(). Create a new inverse FFTW-plan in slot %d with %d samples.\n",iplan, Nsamples);

    RPlanArray[iplan].NFFT = Nsamples;
    if(Forward==true)
    {
        if(ManyFFT==true)
            RPlanArray[iplan].pForw = rfftw_create_plan(Nsamples, FFTW_REAL_TO_COMPLEX, FFTW_MEASURE | FFTW_USE_WISDOM);
        else
            RPlanArray[iplan].pForw = rfftw_create_plan(Nsamples, FFTW_REAL_TO_COMPLEX, FFTW_ESTIMATE| FFTW_USE_WISDOM);
        SaveWisdom();

        if(RPlanArray[iplan].pForw==NULL)
            CI.AddToLog("ERROR: UFFTWPlan::GetRealPlan(). Creating forward plan with Nsamples = %d .\n",Nsamples);
        return RPlanArray[iplan].pForw;
    }
    else
    {
        if(ManyFFT==true)
            RPlanArray[iplan].pBack = rfftw_create_plan(Nsamples, FFTW_COMPLEX_TO_REAL, FFTW_MEASURE | FFTW_USE_WISDOM);
        else
            RPlanArray[iplan].pBack = rfftw_create_plan(Nsamples, FFTW_COMPLEX_TO_REAL, FFTW_ESTIMATE| FFTW_USE_WISDOM);
        SaveWisdom();

        if(RPlanArray[iplan].pBack==NULL)
            CI.AddToLog("ERROR: UFFTWPlan::GetRealPlan(). Creating inverse plan with Nsamples = %d .\n",Nsamples);
        return RPlanArray[iplan].pBack;
    }
    return NULL;
}

bool UFFTWPlan::DoesComplexPlanExist(int Nsamples, bool Forward) const
{
    for(int k=0; k<MAX_COMPLEX_FFTW_PLAN; k++)
    {
        if(Nsamples==CPlanArray[k].NFFT)
        {
            if(Forward==true  && CPlanArray[k].pForw!=NULL) return true;
            if(Forward==false && CPlanArray[k].pBack!=NULL) return true;
        }
    }
    return false;
}
const fftw_plan UFFTWPlan::GetComplexPlan(int Nsamples, bool Forward, bool ManyFFT)
/*
     Return an existing plan if there exists one, else create a new plan and
     keep a copy (of itst pointer).
 */
{
    if(Nsamples<=0)
    {
        CI.AddToLog("ERROR: UFFTWPlan::GetComplexPlan(). Nsamples = %d out of range.\n",Nsamples);
        return NULL;
    }

    for(int k=0; k<MAX_COMPLEX_FFTW_PLAN; k++)
    {
        if(Nsamples==CPlanArray[k].NFFT)
        {
            if(Forward==true  && CPlanArray[k].pForw!=NULL) return CPlanArray[k].pForw;
            if(Forward==false && CPlanArray[k].pBack!=NULL) return CPlanArray[k].pBack;
        }
    }

/* Search for and empty slot*/
    int iplan = -1;
    for(int k=0; k<MAX_COMPLEX_FFTW_PLAN; k++)
        if(CPlanArray[k].NFFT==0) {iplan=k; break;}
    
    if(iplan<0)
    {
        iplan = 0;
        if(Forward==true)
        {
            if(CPlanArray[0].pForw) fftw_destroy_plan(CPlanArray[0].pForw);
            CPlanArray[0].pForw = NULL;
        }
        else
        {
            if(CPlanArray[0].pBack) fftw_destroy_plan(CPlanArray[0].pBack);
            CPlanArray[0].pBack = NULL;
        }
    }

/* and create new one */
    if(Forward==true)  CI.AddToLog("Note: UFFTWPlan::GetComplexPlan(). Create a new forward FFTW-plan in slot %d with %d samples.\n",iplan, Nsamples);
    else               CI.AddToLog("Note: UFFTWPlan::GetComplexPlan(). Create a new inverse FFTW-plan in slot %d with %d samples.\n",iplan, Nsamples);

    CPlanArray[iplan].NFFT = Nsamples;
    if(Forward==true)
    {
        if(ManyFFT==true)
            CPlanArray[iplan].pForw = fftw_create_plan(Nsamples, FFTW_FORWARD, FFTW_MEASURE | FFTW_USE_WISDOM);
        else
            CPlanArray[iplan].pForw = fftw_create_plan(Nsamples, FFTW_FORWARD, FFTW_ESTIMATE| FFTW_USE_WISDOM);
        SaveWisdom();

        if(CPlanArray[iplan].pForw==NULL)
            CI.AddToLog("ERROR: UFFTWPlan::GetComplexPlan(). Creating forward plan with Nsamples = %d .\n",Nsamples);
        return CPlanArray[iplan].pForw;
    }
    else
    {
        if(ManyFFT==true)
            CPlanArray[iplan].pBack = fftw_create_plan(Nsamples, FFTW_BACKWARD, FFTW_MEASURE | FFTW_USE_WISDOM);
        else
            CPlanArray[iplan].pBack = fftw_create_plan(Nsamples, FFTW_BACKWARD, FFTW_ESTIMATE| FFTW_USE_WISDOM);
        SaveWisdom();

        if(CPlanArray[iplan].pBack==NULL)
            CI.AddToLog("ERROR: UFFTWPlan::GetComplexPlan(). Creating inverse plan with Nsamples = %d .\n",Nsamples);
        return CPlanArray[iplan].pBack;
    }
    return NULL;
}

ErrorType ShiftDataFFT(double* Data, double* Buffer, double Delta, int Nsamp, double Shift)
/*
    Shift the equidistantly sampled data array Data[], with sampling interval Delta
    and Nsamp points, with the amount Shift (same units as Delta).
    Buffer[] is a general purpose buffer with Nsamp double elements.
 */
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR ShiftDataFFT(). Invalid Data NULL pointer. \n");
        return U_ERROR;
    }
    if(Buffer==NULL)
    {
        CI.AddToLog("ERROR ShiftDataFFT(). Invalid Buffer NULL pointer. \n");
        return U_ERROR;
    }
    if(Delta<=0.)
    {
        CI.AddToLog("ERROR ShiftDataFFT(). Invalid sample time (Delta = %f). \n", Delta);
        return U_ERROR;
    }
    if(Nsamp<=0)
    {
        CI.AddToLog("ERROR ShiftDataFFT(). Invalid Nsamp (=%d). \n", Nsamp);
        return U_ERROR;
    }
    if(Shift==0.) return U_OK;
    if(Nsamp==1 ) return U_OK;

    const rfftw_plan Pforw = FFTW.GetRealPlan(Nsamp, true);
    const rfftw_plan Pback = FFTW.GetRealPlan(Nsamp, false);
    if(Pforw==NULL || Pback==NULL)
    {
        CI.AddToLog("ERROR ShiftDataFFT(). Creating FFT plans. \n");
        return U_ERROR;
    }

/* Remove offset */
    double Trend = (Data[Nsamp-1] - Data[0])/(Nsamp-1);
    for(int k=0; k<Nsamp; k++) Data[k] -= k*Trend;

/* FFT shifting */
    double cf = cos(PI2*Shift/(Nsamp*Delta));
    double sf = sin(PI2*Shift/(Nsamp*Delta));

    rfftw_one(Pforw, Data, Buffer);
    double Ref  = cf/Nsamp;  // (cf + i sf)**k
    double Imf  = sf/Nsamp;
    Buffer[0]  /=    Nsamp;  
    for(int k=1; k<(Nsamp+1)/2; k++)
    {
        double ReBuf    = Buffer[k]*Ref - Buffer[Nsamp-k]*Imf;
        double ImBuf    = Buffer[k]*Imf + Buffer[Nsamp-k]*Ref;
        Buffer[k]       = ReBuf;
        Buffer[Nsamp-k] = ImBuf;

        double RePow    = Ref*cf - Imf*sf;
        double ImPow    = Ref*sf + Imf*cf;
        Ref = RePow;
        Imf = ImPow;
    }
    if(Nsamp%2==0) Buffer[Nsamp/2] *= Ref; // Nsamp even
    rfftw_one(Pback, Buffer, Data);      
    
/* Add shifted offset */
    double OffSet = Trend*Shift/Delta;
    for(int k=0; k<Nsamp; k++) 
        Data[k]  += OffSet + k*Trend;

    return U_OK;
}

ErrorType HilbertTransform(const double *Data, double *HilbertImag, int Nsamp)
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR HilbertTransform(). Invalid Data NULL pointer. \n");
        return U_ERROR;
    }
    if(HilbertImag==NULL)
    {
        CI.AddToLog("ERROR HilbertTransform(). Invalid output pointer. \n");
        return U_ERROR;
    }
    if(Nsamp<=0)
    {
        CI.AddToLog("ERROR HilbertTransform(). Invalid Nsamp (=%d). \n", Nsamp);
        return U_ERROR;
    }

    const fftw_plan Pforw = FFTW.GetComplexPlan(Nsamp, true);
    const fftw_plan Pback = FFTW.GetComplexPlan(Nsamp, false);
    if(Pforw==NULL || Pback==NULL)
    {
        CI.AddToLog("ERROR HilbertTransform(). Creating FFT plans. \n");
        return U_ERROR;
    }

    fftw_complex *h = new fftw_complex[Nsamp];
    fftw_complex *H = new fftw_complex[Nsamp];
    if(h==NULL || H==NULL)
    {
        delete[] h;
        delete[] H;
        CI.AddToLog("ERROR HilbertTransform(). Memory allocation. \n");
        return U_ERROR;
    }

    for(int i = 0; i < Nsamp; i++) 
    {
        h[i].re = Data[i];
        h[i].im = 0.;
    }
    fftw_one(Pforw, h, H); // h -> H 

//  Hilbert transform. The upper half-circle gets multiplied by
//  two, and the lower half-circle gets set to zero.  The real axis
//  is left alone. 

    for(int i = 1; i<Nsamp/2; i++) 
    {
        H[i].re *= 2.;
        H[i].im *= 2.;
    }
    for(int i = Nsamp/2+1; i<Nsamp; i++) 
    {
        H[i].re = 0.;
        H[i].im = 0.;
    }
    fftw_one(Pback, H, h); // H -> h 

    for(int i = 0; i < Nsamp; i++) 
        HilbertImag[i] = h[i].im / Nsamp;

    delete[] h;
    delete[] H;

    return U_OK;
}

