#ifndef _FFTWPLANARRAY_INCLUDED
#define _FFTWPLANARRAY_INCLUDED

#include "BasicInclude.h"
#include "DLLio.h"
#include "PMTTypeDefines.h"
#include "Fftw/rfftw/rfftw.h"

#define MAX_REAL_FFTW_PLAN      512
#define MAX_COMPLEX_FFTW_PLAN    64
#define MAX_WISDOM_FILENAME    1000

class DLL_IO UFFTWPlan 
{
public:
    UFFTWPlan();
    ~UFFTWPlan();
    void             SetWisdomDir(const char* DefDir);
    const rfftw_plan GetRealPlan(int Nsamples, bool Forward=true, bool ManyFFT=true);
    bool             DoesRealPlanExist(int Nsamples, bool Forward) const;

    const fftw_plan  GetComplexPlan(int Nsamples, bool Forward=true, bool ManyFFT=true);
    bool             DoesComplexPlanExist(int Nsamples, bool Forward) const;
private:
    static char      WisdomFile[MAX_WISDOM_FILENAME];
    void             SaveWisdom() const;
    
    typedef struct
    {
        int        NFFT;
        rfftw_plan pForw;
        rfftw_plan pBack;
    } RFFTWplan;
    RFFTWplan RPlanArray[MAX_REAL_FFTW_PLAN];

    typedef struct
    {
        int       NFFT;
        fftw_plan pForw;
        fftw_plan pBack;
    } CFFTWplan;
    CFFTWplan CPlanArray[MAX_COMPLEX_FFTW_PLAN];
};


ErrorType DLL_IO ShiftDataFFT(double* Data, double* Buffer, double Delta, int Nsamp, double Shift);
ErrorType DLL_IO HilbertTransform(const double *Data, double *HilbertImag, int Nsamp);

#endif//_FFTWPLANARRAY_INCLUDED
