#ifndef _UFIELD_INCLUDED
#define _UFIELD_INCLUDED

#include "Euler.h"
#include "LinTran.h"
#include "String.h"

#ifndef QT4
#if defined(_MSC_VER) && defined(_DEBUG)
    #define _CRTDBG_MAP_ALLOC
    #include <stdlib.h>
    #include <crtdbg.h>
    #define DEBUG_NEW new( _NORMAL_BLOCK, __FILE__, __LINE__ )
    #define new DEBUG_NEW
#endif
#endif

class UFileName;
class UDipole;
class USurface;
class UDistribution;
class UField;
class UProjector;
class UString;
class UFieldGraph;

#define MAX_FIELD_DIMENSIONS     4
#define MAXFIELDPROPERTIES    1000


/* Compatibility with the AVSfield type: */
#define UNIFORM       0
#define RECTILINEAR   1
#define IRREGULAR     3
#define AVSerror(a)   CI.AddToLog(a)

typedef struct 
{
    int            uniform;     // FieldType
    int            veclen;      // Number of values per pixel (4 bytes is color)
    int            ndim;        // Number of dimensions
    int            nspace;      // Number of space coordinates for each voxel (can be larger than ndim, for e.g. a curved surface in 3D)
    int            dimensions[MAX_FIELD_DIMENSIONS];  // Number of pixels in x- y- z-direction
    float*         points;      // coordinate arrays
} AVSfield;

enum Interpolate3DType
{
    U_INTERPOL3D_NNEIGH = 0,
    U_INTERPOL3D_LIN1   = 1,
    U_INTERPOL3D_LIN2   = 2,
    U_INTERPOL3D_CUB    = 3,
    U_INTERPOL3D_BEZ    = 4,
    U_INTERPOL3D_CATMUL = 5,
    U_INTERPOL3D_SINC   =11,
    U_INTERPOL3D_UNKNOWN
};

enum LevelType            // Precise mode of constructing USurface object from UField, using UMarchingCubes algorithm
{
    U_LEVEL_SMALLER,
    U_LEVEL_SMALLEREQUAL,
    U_LEVEL_EQUAL,
    U_LEVEL_NOTEQUAL,
    U_LEVEL_LARGER,
    U_LEVEL_LARGEREQUAL,
    U_LEVEL_UNKNOWN
};
PMT_CCP     DLL_IO GetLevelTypeText(LevelType LT);


enum CompDatType            // Indicates physical meaning of individual components if veclen>1
{
    U_COMPDAT_AVERSTAN,     // veclen=2: average and standard deviation
    U_COMPDAT_CORPFDR,      // veclen=3: correlation, p-value, False Detection Rate
    U_COMPDAT_SLICEPROPER,  // veclen>0: each component corresponds to a different "slice"
    U_COMPDAT_UNKNOWN       // Unknown
};
PMT_CCP     DLL_IO GetCompDatTypeText(CompDatType CDT);
CompDatType DLL_IO GetCompDatType(int itype);
CompDatType DLL_IO GetCompDatType(const char* typestring);

enum GraphDatType           // Data type used in a (1D) graph on (hor) axis
{
    U_GDAT_TIME_S,          // Time in s.
    U_GDAT_FREQ_HZ,         // Frequency in Hz.
    U_GDAT_FREQ_mHZ,        // Frequency in mHz.
    U_GDAT_DIST_CM,         // Distance in cm
    U_GDAT_UNKNOWN          // Unknown
};
PMT_CCP      DLL_IO GetGraphDatTypeText(GraphDatType GFT);
GraphDatType DLL_IO GetGraphDatType(int itype);
GraphDatType DLL_IO GetGraphDatType(const char* typestring);

enum SliceViewType          // Mode in which a scan is shown
{
    U_SLICEVIEW_SINGLE,     // Single slice (axial, coronal or sagital)
    U_SLICEVIEW_MULTI,      // Multiple slices
    U_SLICEVIEW_SURFREN,    // Surface rendering
    U_SLICEVIEW_UNKNOWN
};
PMT_CCP        DLL_IO GetSliceViewTypeText(SliceViewType SVT);
SliceViewType  DLL_IO GetSliceViewType(int itype);
SliceViewType  DLL_IO GetSliceViewType(const char* typestring);

enum ProjectionType         // Mode to project data from curved to flad 2D surface
{
    U_PROJECT_FLAT,         // From infinity
    U_PROJECT_MERCATOR,     // Mercator
    U_PROJECT_CYLINDRICAL,  // Cylindrical
    U_PROJECT_UNKNOWN
};
PMT_CCP        DLL_IO GetProjectionTypeText(ProjectionType PT);
ProjectionType DLL_IO GetProjectionType(int itype);
ProjectionType DLL_IO GetProjectionType(const char* typestring);

enum OrientType             // Scan orienation
{            
    U_ORI_AXIAL,            // Axial
    U_ORI_CORONAL,          // Coronal
    U_ORI_SAGITAL,          // Sagital
    U_ORI_UNKNOWN           // Unknown
};
PMT_CCP      DLL_IO GetOrientTypeText(OrientType OT);
OrientType   DLL_IO GetOrientType(int itype);
OrientType   DLL_IO GetOrientType(const char* typestring);

enum SliceOrderType         // Order in which slices are scanned
{
    U_SLI_TB,               // Axial,   from top to bottom
    U_SLI_BT,               // Axial,   from bottom to top
    U_SLI_FP,               // Coronal, from frontal to posterior
    U_SLI_PF,               // Coronal, from posterior to frontal
    U_SLI_LR,               // Sagital, from left to right
    U_SLI_RL,               // Sagital, from right to left
    U_SLI_ALLATONCE,        // whole volume scanned at once
    U_SLI_INTERLEAVED,      // Interleaved, determined by UScan::SliceIndex[]
    U_SLI_UNKNOWN           // Unknown
};
PMT_CCP        DLL_IO GetSliceOrderTypeText(SliceOrderType SOT);
SliceOrderType DLL_IO GetSliceOrderType(int itype);
SliceOrderType DLL_IO GetSliceOrderType(const char* typestring);


enum ModalityType           // Scan modality
{
    U_MOD_UNKNOWN,          // Unknown
    U_MOD_MR,               // MRI
    U_MOD_fMRI,             // fMRI
    U_MOD_CT,               // CT
    U_MOD_PET,              // PET
    U_MOD_SPECT,            // SPECT
    U_MOD_MEG,              // MEG
    U_MOD_FILTERED          // Pixels thresholded, filtered, etc
};
PMT_CCP      DLL_IO GetModalityTypeText(ModalityType MT);
ModalityType DLL_IO GetModalityType(int itype);
ModalityType DLL_IO GetModalityType(const char* typestring);


enum FileType               // File format where the original data is read from
{
    U_FIL_UNKNOWN,          // Unknown
    U_FIL_SCANXDR,          // scan.xdr file Conquest .Patient tree (.scan directory)
    U_FIL_SCAN4DXDR,        // scan4D.xdr file Conquest .Patient tree, extra dimension (.scan4D directory)
    U_FIL_2DXDR,            // AVS XDR-file, 2D (Ndim==2)
    U_FIL_3DXDR,            // AVS XDR-file, without .Patient tree dir structure
    U_FIL_4DXDR,            // AVS XDR-file, with extra time dimension (4D)
    U_FIL_DICOM,            // DICOM file
    U_FIL_MATRIX,           // Matrix (PET scannner)
    U_FIL_AFNI,             // AFNI file (.HEAD or .BRIK) used for fMRI 
    U_FIL_ANALYZE,          // Analyze format
    U_FIL_ANALYZELIST,      // List of numbered analyze files
    U_FIL_NIFTI,            // Nifti format
    U_FIL_CART,             // CadPlan files
    U_FIL_PHILIPS,          // Philips files
    U_FIL_CTFSAM,           // CTF SAM image file
    U_FIL_CTFMRI,           // CTF MRI image file
    U_FIL_FIFF,             // Elekta FIFF format
    U_FIL_BPM,              // Bitmap image file
    U_FIL_TIFF,             // Tiff image file
    U_FIL_INTERFILE,        // Interfile
    U_DIR_DICOM,            // DICOM directory
    U_DIR_SCANXDR,          // Scan.xdr directory Conquest .Patient tree
    U_DIR_SCAN4DXDR         // 4D Scan.xdr directory Conquest .Patient tree, extra dimension
};
PMT_CCP     DLL_IO GetScanDataFormatText(FileType FT);

enum UFieldCenterType // Determines the way of deriving centers in GetConnectComponentsCenters() 
{
    U_FIELDCENTER_GRAVITY,
    U_FIELDCENTER_MININTENS,
    U_FIELDCENTER_MAXINTENS
};

enum UDetectExtremeType            // Determines what kind of extremum to detect
{
    U_DETEXT_LOCMIN,               // local minimum
    U_DETEXT_ABSMIN,               // absolute minimum
    U_DETEXT_LOCMAX,               // local maximum
    U_DETEXT_ABSMAX,               // absolute maximum
    U_DETEXT_MAXJUMP               // maximum jump
};

enum ShiftType{
    U_SHIFT_ZERO,  // Set first (last) point to zero
    U_SHIFT_COPY,  // Copy first (last) point
    U_SHIFT_CYCLE  // Make the signal cyclic
};

enum SpatFilterType
{
    U_SPATFILT_SMOOTH    =  0,
    U_SPATFILT_UNSMOOTH  =  1,
    U_SPATFILT_LOCMIN    =  2,
    U_SPATFILT_LOCMAX    =  3,
    U_SPATFILT_OPEN      =  4,
    U_SPATFILT_CLOSE     =  5,
    U_SPATFILT_TOPHAT    =  6,
    U_SPATFILT_REVTOPHAT =  7,
    U_SPATFILT_EDGEIN    = 11,
    U_SPATFILT_EDGEOUT   = 12,
    U_SPATFILT_UNKNOWN   = 14
};
PMT_CCP     DLL_IO GetFilterTypeText(SpatFilterType FT);

typedef struct 
{
    char         ScanName[256];  // (default) scan name
    UField*      Scan;
    ModalityType Modality;       // Modality
    OrientType   Orientation;    // Scan orientation 
    double       GantryTilt;     
    int          slicedim;       // dimension of slices (usefull if Scan==NULL)
    int          nslices;        // number of slices (usefull if Scan==NULL)
    char*        Comment;        // General comment string
} ScanInfo;

enum TiffType
{
    U_TIFF_BYTE      = 1,
    U_TIFF_ASCII     = 2,
    U_TIFF_SHORT     = 3,
    U_TIFF_LONG      = 4,
    U_TIFF_RATIONAL  = 5,
    U_TIFF_NTYPE
};

class DLL_IO UField
{
public:
    enum FieldType{U_UNIFORM, U_RECTILINEAR, U_IRREGULAR};
    enum DataType{U_BYTE, U_SHORT, U_INTEGER, U_FLOAT, U_DOUBLE};

    enum DatConvertType{          // How to convert data to byte?
            U_DCONVERT_MINMAX,    // Use the minimum and and maximum in data
            U_DCONVERT_RIGHTMAX2, // Use right maximum in histogram
            U_DCONVERT_98PROC,    // Use maximum, such that 98% of the lowest grey values are linearly scaled
            U_DCONVERT_BRAIN,     // Use 'optimal' visibility of the brain fron (f)MR
            U_DCONVERT_OTSU,      // Use 'Otsu' algorithm to derive optimal contrast from pixel histogram
            U_DCONVERT_BOOL       // 0 gets 0  and !0 gets 1
            };
    UField();
    UField(const UField &f, bool nodata=false);
    UField(UFileName Fname);
    UField(const char* FileName);
    UField(FILE* fpIn);
    UField(const double* Array, int N1, int N2, int N3=-1);
    UField(const short* Array, int N1, int N2, int N3=-1);
    UField(const int* Array, int N1, int N2, int N3=-1);
    UField(double Voxel, UVector3 Min, UVector3 Max, DataType DT=U_BYTE);
    UField(UVector3 Min, UVector3 Max, const int *dims, DataType DT, int vecl=1);
    UField(UVector2 Min, UVector2 Max, const int *dims, DataType DT, int vecl=1);
    UField(float    Min, float    Max, int dims, DataType DT, int vecl=1);
    UField(const float* cornercoords, int ndimensions, const int *dims, DataType DT, int vecl=1);
    UField(const float* xcoords, const float* ycoords, const float* zcoords, const int *dims, DataType DT, int vecl=1);
    UField(const double* cornercoords, int ndimensions, const int *dims, DataType DT, int vecl=1);
    UField(const double* xcoords, const double* ycoords, const double* zcoords, const int *dims, DataType DT, int vecl=1);
    UField(UDipole *Diparray, int Ndipoles);
    UField(const UVector2 *Points, int Npoints, int nbytes=0);
    UField(const UVector3 *Points, int Npoints, int nbytes=0);
    UField(const int *Index, int Npoints, int Ncomp, bool AddDummyComp);
    UField(const UField* const* SliceArr, int NSlices, int Nhor, int Nver);
    UField(const UField* Slice, int NSlice, double Smin, double Smax);
    UField(const UField* const* SliceArr, int NSlices, double Smin, double Smax);

    virtual ~UField();  
    UField& operator =(const UField& f);
    UField& operator&=(const UField& f);
    UField& operator|=(const UField& f);
    UField& operator*=(const UField& f);
    UField& operator-=(const UField& f);
    UField& operator+=(const UField& f);
    UField  operator+ (const UField& f) const;
    UField  operator- (const UField& f) const;
    UField  operator-(void) const;
    UField& operator*=(int fac);
    UField& operator*=(double fac);
    UField  operator* (int fac) const;
    UField  operator* (double fac) const;
    UField  operator* (const UField& f) const;
    UField& operator+=(int term);
    UField& operator+=(double term);

    virtual const UString& GetProperties(UString Comment) const;
    const UString&    GetExtents(UString Comment) const;
    
/* Functions for 3D images  (U_UNIFORM fields)*/
    UField*           Project(int index) const;
    ErrorType         DuplicateSingleSlice(void);
    virtual ErrorType Convert2Dto3D(void);
    ErrorType         Convert3Dto4D(void);
    ErrorType         Convert3Dto2D(void);
    
/* Functions for point lists (U_RECTILINEAR fields)*/
    virtual ErrorType ForceUniform(double Tol);

/* Functions for point lists (U_IRREGULAR fields)*/
    ErrorType         MergePoints(const UField* Points);
    ErrorType         AddPoints(const UVector3* NewPts, int N);
    UVector3*         GetPoints(void) const;
    ErrorType         SetPointData(int ipoint, const char *data);
    ErrorType         SubSample(double MaxDistance);
    ErrorType         xfm(const UEuler& XFM);
    ErrorType         Transform(const UEuler& XFM);
    ErrorType         Transform(const ULinTran& XFM);
    ErrorType         RandomizePoints(double StDev, int seed=1);

/* General functions */
    ErrorType         GetError(void)  const  {if(this==NULL) return U_ERROR; return error;}
    int               GetVeclen(void) const  {if(this==NULL) return 0;       return veclen;}
    unsigned char*    GetBdata(void)  const  {if(this==NULL) return NULL;    return Bdata;}
    short*            GetSdata(void)  const  {if(this==NULL) return NULL;    return Sdata;}
    int*              GetIdata(void)  const  {if(this==NULL) return NULL;    return Idata;}
    float*            GetFdata(void)  const  {if(this==NULL) return NULL;    return Fdata;}
    double*           GetDdata(void)  const  {if(this==NULL) return NULL;    return Ddata;}
    void*             GetData(void)   const;  
    int               Getndim(void)   const  {if(this==NULL) return 0;         return ndim;}
    DataType          GetDType(void)  const  {if(this==NULL) return U_BYTE;    return DType;}
    FieldType         GetFType(void)  const  {if(this==NULL) return U_UNIFORM; return FType;}
    int               GetNspace(void) const  {if(this==NULL) return 0;         return nspace;}
    int               GetNpoints(void) const;
    int               GetNpoints(double Xmin, double Xmax) const;
    ErrorType         GetRangeIndices(double Xmin, double Xmax, int* IndMin, int* IndMax) const;
    int               GetNLevelPoints(int Level, LevelType LevT, int icomp) const;
    int               GetNLevelPoints(double Level, LevelType LevT, int icomp) const;
    int               GetNLevelPoints(int Level, int icomp) const;
    int               GetNLevelPoints(double Level, int icomp) const;
    bool              AreDimensionsCompatible(const UField* F) const;
    bool              IsGeometryCompatible(const UField* F) const;
    bool              IsGeometryCompatibleRectilinear(const UField* F) const;
    virtual ErrorType SetGeometry(const UField* F);

    int               GetDataSize(void) const;
    int               GetDataSize(DataType OtherData) const;
    int               GetDimensions(int dir) const;
    double            GetPixelSize(int dir) const;

/* Functions acting on data */
    ErrorType         Gradient(void);
    ErrorType         LogicNot(void);
    ErrorType         Logarithm(void);
    ErrorType         Square(void);
    ErrorType         SquareRoot(void);
    ErrorType         Invert(void);
    ErrorType         AbsValue(void);
    ErrorType         SetGaussianProfile(double StanDev, int DerOrder, bool Normalize);
    ErrorType         SetGaussianProfile(double StanDev_x, double Standev_y, int DerOrder_x, int DerOrder_y, bool Normalize);

    ErrorType         SetPointValue(UVector3 x, int value);
    ErrorType         SetPointValue(UVector3 x, double value);
    ErrorType         AddPointValue(UVector3 x, int value);
    ErrorType         AddPointValue(UVector3 x, double value);
    int               GetPointValue(UVector3 x, int icomp) const;
    double            GetPointValue_d(UVector3 x, int icomp) const;

    bool              CanBeConvertedRGB2Gray(void) const;
    ErrorType         ConvertRGB2Gray(bool MakeShort);
    UField*           GetComponent(int icomp) const;
    ErrorType         SetComponent(int icomp);
    ErrorType         SetComponent(int icomp, const UField* Ficomp);
    double            GetRMSData(int icomp=-1, const UField* Selector=NULL) const;
    int               GetMedian_i(int icomp=-1) const;
    double            GetMedian_d(int icomp=-1) const;
    int               GetUpperQuantile_i(double Fraction, int SkipDiagWidth, int icoorx, int icoory) const;
    double            GetUpperQuantile_d(double Fraction, int SkipDiagWidth, int icoorx, int icoory) const;    
    double            GetAverageData(int icomp=-1) const;
    ErrorType         GetAverageStandDev(int icomp, const UField* Selector, double* Aver, double* Standev) const;

    ErrorType         GetMinMaxData(int *MinDat, int* MaxDat, int icomp=-1) const;
    ErrorType         GetMinMaxData(double *MinDat, double* MaxDat, int icomp=-1) const;
    ErrorType         GetMinMaxData(int *MinDat, int* MaxDat, int* MinRma, int* MaxRma, int* MinC98, int* MaxC98, int* MinBra, int* MaxBra, int* MinOts, int* MaxOts, int icomp=0) const;
    int               GetNearestData(UVector3 v) const;
    double            GetNearestData_d(UVector3 v) const;
    double            GetAverageData_d(UVector3 P, double Rad, int icomp) const;

    UField*           GetGlobalMaxAsField(int icomp) const;
    UField*           GetGlobalMinAsField(int icomp) const;
    UField*           GetLocalMaxAsField(bool ApplyThresh, double Thresh, int icomp) const;
    UField*           GetLocalMinAsField(bool ApplyThresh, double Thresh, int icomp) const;

    int               GetNNeigbours(int ip, int* NeighbourIndices) const;
    ErrorType         GetNeighbourPoints(UVector3* Xp, UVector3* Xn, UVector3* Yp, UVector3* Yn, UVector3* Zp, UVector3* Zn, int ip) const;
    ErrorType         GetNeighbourData(int *ixp, int* ixn, int *iyp, int *iyn, int *izp,  int *izn, int ip) const;
    int               GetNThreshNeigbors(UVector3 x, double Rad, double Thresh, int icomp, bool SubTr, int** IndexList) const;
    UVector3          GetLocalExtreme(UVector3 P, double Rad, const UField* Selector, int icomp, bool GetMin, int* ExtPoint) const;

    ErrorType         ClearData(void) const;
    ErrorType         SetData(const unsigned char* data, int veclen=1);
    ErrorType         SetData(const short* data, int veclen=1);
    ErrorType         SetData(const int* data, int veclen=1);
    ErrorType         SetData(const float* data, int veclen=1);
    ErrorType         SetData(const double* data, int veclen=1);
    ErrorType         SetData(const UField* F);
    ErrorType         SetDataByte(const unsigned char data) const;
    ErrorType         SetDataDouble(const double data) const;
    ErrorType         SetDataDiagonal(int DiagWidth, int    DataDiag) const;
    ErrorType         SetDataDiagonal(int DiagWidth, double DataDiag) const;
    ErrorType         SetDataInverse(const UField* Data, double InvThresh) const;

    virtual ErrorType SetVeclen(int NewVeclen);
    ErrorType         NormalizeData(bool UseMinMax, bool PerComponent) const;
    ErrorType         AddData(const UField*F) const;
    ErrorType         AddData2(const UField*F) const;
    virtual ErrorType ReplaceValues(const int* Old, const int* New, int Ntab); 
    ErrorType         ConvertDataToByte(bool LogScale, bool Symmetric, int* ConversionTable);
    ErrorType         ConvertDataToByte(bool LogScale, bool Symmetric, double* ConversionTable);
    ErrorType         ConvertDataToByte(bool LogScale, bool Symmetric, int pmin, int pmax, int* ConversionTable);
    ErrorType         ConvertDataToByte(bool LogScale, bool Symmetric, double pmin, double pmax, double* ConversionTable);
    ErrorType         ConvertDataToByte(int pixmin, int pixmax);
    ErrorType         ConvertDataToByte(double pixmin, double pixmax);
    ErrorType         ConvertDataToByte(DatConvertType DatCon, int pixmin, int pixmax);
    ErrorType         ConvertDataToByte(DatConvertType DatCon, int* pixmin, int* pixmax);
    ErrorType         ConvertColorsToByte(void);
    virtual ErrorType ConvertData(DataType NewType, double Scale=1.);
    ErrorType         ScaleData(int inMin, int inMax, int outMin, int outMax);
    ErrorType         InvertData(void);
    ErrorType         MinusData(void);
    virtual ErrorType ReverseData(int dir, bool ReverseCoord);
    ErrorType         ReverseCoords(int dir);
    ErrorType         ReverseCoords(bool dirX, bool dirY, bool dirZ);
    ErrorType         SwapDirections(int dir1, int dir2);
    ErrorType         SwapDirections();

    UField*           GetSegmentation(double Thresh, int icomp) const;
    virtual ErrorType Segment(int Imin, int Imax, bool MinToBack, bool RangeToBack, bool MaxToBack, bool BinaryOutput, int icomp);
    virtual ErrorType Segment(double Dmin, double Dmax, bool MinToBack, bool RangeToBack, bool MaxToBack, bool BinaryOutput, int icomp);
    virtual ErrorType Segment(LevelType LT, int Level, int icomp);
    virtual ErrorType Segment(LevelType LT, double Level, int icomp);
    virtual ErrorType Segment(const UField* YField, const UEuler& YtoX, double Xmin, double Xmax, double Ymin, double Ymax);
    unsigned char*    GetBitArray(int value) const;

    double            GetHistogramThreshold(int icomp) const;
    ErrorType         EqualizeHistogram(int xmin, int xmax, int ymin, int ymax, bool ApplyToROIonly);
    ErrorType         EqualizeHistogram(const int* kernel);
    ErrorType         EqualizeHistogram(void);
    ErrorType         ThresholdHead(double HeadRadius=9., bool AddToLog=false);
    ErrorType         ThresholdRelative(double Min, double Max, int NewVal);
    ErrorType         ThresholdAbsolute(int Min, int Max, int NewVal);
    ErrorType         ThresholdAbsolute(double Min, double Max, double NewVal);
    ErrorType         SetSubThresholdZero(double AbsThresh, int icompSource, int icompTarget);
    ErrorType         SetSuperThresholdZero(double AbsThresh, int icompSource, int icompTarget);
    bool              IsDataSubThreshold(int    Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    bool              IsDataSubThreshold(double Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    bool              IsDataSuperThreshold(int    Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    bool              IsDataSuperThreshold(double Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    bool              DoesDataVanish(int icomp, const UField* Selector) const;
    int               GetNDataSubThreshold(  int    Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    int               GetNDataSubThreshold(  double Threshold, int icomp, const UField* Selector=NULL, bool DataAbsVal=false) const;    
    int               GetNDataSuperThreshold(int    Threshold, int icomp, const UField* Selector, bool DataAbsVal) const;
    int               GetNDataSuperThreshold(double Threshold, int icomp, const UField* Selector, bool DataAbsVal) const;    
    int               GetNDataSuperThreshold(double Threshold, int SkipDiagWidth, int icoorx, int icoory, const UField* Selector) const;    
    bool*             GetSelectionArray(int icomp=0) const;

    ErrorType         EdgeDetect(bool OUTSIDE);
    ErrorType         EdgeDetect(const UField* Flevel);
            ErrorType Detrend(int Order, int    Threshold);
    virtual ErrorType Smooth(int Ntimes);
    virtual ErrorType Smooth(double StanDev_X, double StanDev_Y, double StanDev_Z, int NorderDerX, int NorderDerY, int NorderDerZ);
    virtual ErrorType SmoothLaplacian(double StanDev_X, double StanDev_Y, double StanDev_Z);
    virtual ErrorType SmoothNormGradient(double StanDev_X, double StanDev_Y, double StanDev_Z);
    virtual ErrorType SmoothHessian(double StanDev_X, double StanDev_Y, double StanDev_Z);
            ErrorType ComputeTubeness(const double* Scales, int NScale, double Alpha, double Beta, double Gamma, bool BrightTubes);
    virtual ErrorType SpatialFilterField(SpatFilterType SFT, int KernelSize, bool ScaleExtends);
            UField*   GetSpatialFilteredField(SpatFilterType SFT, int KernelSize, bool ScaleExtends) const;
            UField*   GetLocalAverageField(int KerRadius, int dir, bool CompSumOnly) const;
            UField*   GetLocalAverageField(const int* KerRadii) const;
            UField*   GetSauvolaFilteredField(const int* KerRadii, int Pixmin, int Pixmax, double par1=0., double par2=0., bool Invert=false) const;
    ErrorType         ApplySauvolaFilter(const int* KerRadii, int Pixmin, int Pixmax, double par1=0., double par2=0., bool Invert=false);
            UField*   GetWatershedField(void) const; 
    ErrorType         ApplyWatershedFilter(int Pixmin, int Pixmax); 

    ErrorType         PutSphere(UVector3 xC, double InRad, double OutRad, int value);
    ErrorType         DrawLineSegment(UVector3 PBegin, UVector3 PEnd, double Thickness, int value);
    UField*           GetPointsAsUniformScan(const UField* Points, double Sigma, double AmpFact, bool MaxPoints) const;
    UField*           GetTemplateMatch(const UField* Temp, const UField* Select, int NuisOrder) const;
    UProjector*       GetNuisanceProjector(int NuisOrder) const;
    UProjector*       GetNuisanceProjector1D(int NuisOrder, int dir) const;
    UField*           GetProjection(const UProjector* Px, const UProjector* Py) const; 
    UField*           GetSampleGrid(int stepX, int stepY, int stepZ, int Thresh, bool TakeLargest) const;
    UField*           GetSampleProjection(const UField* FSampGrid, int NuisOrder) const; 

    virtual ErrorType TakeZeroes(const UField* Data);
    virtual ErrorType MaskData(const UField* Mask, int MaskVal=0, int NewVal=0);
    int               GetNZeroes(int icomp) const;
    int               GetNNonZeroes(int icomp) const;
    virtual int       GetNonZeroes(int icomp=-1, int** Index=NULL) const;
    int               GetFirstNonZeroSlice(int dir) const;
    int               GetLastNonZeroSlice(int dir) const;

    int*              GetIndicator(int *NNonZero) const;
    ErrorType         SkipSamples(const UField* Selector, int *NSelected=NULL);
    ErrorType         SkipSamples(const bool* Selector, int *NSelected=NULL);

    UField*           GetGrid(const int* NewDims, DataType DT=U_BYTE) const;
    ErrorType         DistanceXFM(bool scale_extents=true, bool ir_slices=true, int kernel=1, int clip=-1);
    ErrorType         EuclideanDistanceTransform(void);
    ErrorType         EuclideanDistance2Transform(bool Init);

    ErrorType         ConvertToSlice(void);
    ErrorType         SetSlice(int dir, int slice, const UField* Slice);
    UField*           GetSlice(int dir, int slice, bool NoData=false, int icomp=0) const;
    UField*           GetSlice(UEuler XFM, const UField* Grid, int interpolate, int dir, int slice, int outside, int icomp=0) const;
    UField*           GetZbuffer(UEuler XFM, const UField* Slice, double Threshold, int inter) const;
    UField*           GetVolRender(UVector3 LightSourcePos) const;
    UField*           ResampleField(UEuler XFM, const UField* Grid=NULL, int interpolate=1, int OutValue=0, bool Logging=true, int icomp=0) const;
    UField*           ResampleField(ULinTran XFM, const UField* Grid=NULL, int interpolate=1, int OutValue=0, bool Logging=true, int icomp=0) const;
    UField*           ResampleField(const UField* Grid=NULL, int interpolate=1, int OutValue=0, bool Logging=true, int icomp=0) const;
    UField*           ResampleField(const int *NewDims) const;
    UField*           ResampleFieldFFTW(UEuler XFM) const;

    UField*           GetMaxIntensProj(int dir) const;

    ErrorType         ShiftData(double Shift);
    ErrorType         ShiftData(int NShift, ShiftType ST);
    ErrorType         ShiftZeroes(int NShiftFrom, int NShiftTo, ShiftType ST);

    USurface*         GetFitSurfaceToScan(const USurface* Surf, double RangeMin, double RangeMax, UDetectExtremeType DetEx) const;
    ErrorType         IsInSurface(const USurface* S);
    ErrorType         MarkInSurfaceStand(const USurface* S, int Mark, bool AddMark);
    ErrorType         MarkInSurface(const USurface* S, int Mark, bool AddMark);
    ErrorType         IsInSphere(UVector3 Centre, double Radius);

    bool              HasBorder(int value) const;
    ErrorType         AddBorder(int dir, int npix, int value);
    ErrorType         AddBorder(int dir, int npix, double value);
    ErrorType         AddBorderCyclic(int Widthx, int Widthy, int Widthz, bool mirror);
    ErrorType         SetMarker(int dir, double coord, int value);
    ErrorType         SetMarker(int dir, double coord, double value);

    ErrorType         MoveLineToEnd(int dir, int icoor, int* Index) const;
    ErrorType         RemoveLine(int dir, int icoor);
    UField*           GetLine(int dir, int icoor) const;
    UField*           GetLine(int dir, int icoor0, int icoor1) const;
    ErrorType         SetLine(const UField* F1, int dir, int icoor0);
    ErrorType         SetLine(const UField* F1, int dir, int icoor0, int icoor1);
    UField*           GetAverageLine(int dir, double CoordFrom, double CoordTo) const;
    UFieldGraph*      GetAverageLine(int dir, double CoordFrom, double CoordTo, const UString& Label, GraphDatType DTypeCoor=U_GDAT_UNKNOWN) const;
    UField*           GetMaxDataProfile(int dir, int icomp) const;
    UField*           GetPowerSpectrum(double SmoothWidth, double ScaleCoordUnit, bool remOffset, bool remTrend) const;

    UField*           ConnectComponents(int* Ncomp, int dir) const;
    UField*           ConnectComponents(int* Ncomp) const;
    UField*           GetConnectComponentsCenters(const UField* Intensity, int iveccomp, int Ncomp, int** Size, UFieldCenterType FCT, bool SkipBackground=false) const;
    UField*           GetConnectComponentsSelection(int Ncomp, int MinSize, int MaxSize) const;
    ErrorType         SelectLargestComponent(void);
    ErrorType         FillCavities(int* Nfilled);
    ErrorType         CorrectTopology(int* Nfilled, int* Nemptied, bool BackGround);

/* Functions acting on coordinates */
    UVector3          GetVoxel(void) const;
    ErrorType         SetVoxel(double voxelsize, bool Center=false);
    ErrorType         SetVoxel(double VoxelsizeX, double VoxelsizeY, bool Center=false);
    ErrorType         SetVoxel(double VoxelsizeX, double VoxelsizeY, double VoxelsizeZ, bool Center=false);
    UVector3          GetMinx(void) const;
    UVector3          GetMaxx(void) const;
    UVector2          GetMinx2(void) const;
    UVector2          GetMaxx2(void) const;
    double            GetMinx1(void) const;
    double            GetMaxx1(void) const;
    UVector3          GetFirstx(void) const;
    UVector3          GetLastx(void) const;
    UVector2          GetFirstx2(void) const;
    UVector2          GetLastx2(void) const;
    double            GetFirstx1(void) const;
    double            GetLastx1(void) const;
    ErrorType         SetCoorRange(double MinX, double MaxX);

    int               GetFirstPointIndex(double Min, double Max) const;
    ErrorType         GetCoordRange(UVector3 Dir, double* FirstZ, double* LastZ) const;
    
    UVector3          GetCenter(bool PixelWeight, int ThreshMin = 0, int ThreshMax=-1) const;
    UVector3          GetLargestCrossSection(int ThreshMin = 0, int ThreshMax=-1) const;
    virtual ErrorType ShiftCoords(double v);
    virtual ErrorType ShiftCoords(UVector2 v);
    virtual ErrorType ShiftCoords(UVector3 v);
    virtual ErrorType ScaleCoordinates(double SxFactor, double SyFactor, double SzFactor, bool Center);

    UField*           GetCroppedField(UVector3 Min, UVector3 Max, bool Extend) const;
            ErrorType Crop(int NremFirstX, int NremLastX, int NremFirstY, int NremLastY);
            ErrorType Crop(int NremFirst, int NremLast);
            ErrorType Crop(UVector2 Min, UVector2 Max, bool Extend=false);
    virtual ErrorType Crop(UVector3 Min, UVector3 Max, bool Extend=false);
    virtual ErrorType CropSlices(int NremFirst, int NremLast);
    UField*           GetSubField(int Xoff, int Yoff, const int* dims) const;

    ErrorType         LocalMinimum(int Left, int Right);
    ErrorType         LocalMaximum(int Left, int Right);

    ErrorType         Fuse(const UField* F);
    UVector3          GetNextPoint(bool init=false) const;
    double            GetNextPoint1(bool init=false) const;
    UVector2          GetNextPoint2(bool init=false) const;
    UVector3          GetNextPoint3(bool init=false) const {return GetNextPoint(init);}
    UVector3          GetNextNonZeroPoint(bool init=false) const;
    UField*           GetNonZeroesAsIrregular(void) const;
    UField*           GetNonZeroesAsIrregular(int dir, int slice) const;
    bool              IsInnerPoint(int ip) const;
    bool              IsInBox(const UField* F) const;
    UVector3          GetPoint(int ip) const;
    UVector3          GetPoint3(int ip) const {return GetPoint(ip);}
    UVector2          GetPoint2(int ip) const;
    double            GetPoint1(int ip) const;
    UVector3          GetPoint(int x, int y, int slice, int dir) const;
    UVector3          GetPoint(int x, int y, int z) const;
    UVector2          GetPoint(int x, int y) const;
    double            GetCoord(int dir, int index) const;
    int               GetLineIndex(int dir, UVector2 P) const;
    int               GetSliceIndex(int dir, UVector3 P) const;
    int               GetSliceIndex(int dir, int ipoint) const;
    int               GetPointIndex(UVector3 P) const;
    int               GetPointIndex(int dir, double coord) const;
    ErrorType         GetPointIndex(double P, int* x) const;
    ErrorType         GetPointIndices(UVector2 P, int* x, int*y) const;
    ErrorType         GetPointIndices(UVector3 P, int* x, int*y, int*z) const;
    virtual ErrorType DownSampleCube(bool RemoveFirstWhenNumSlices);
    virtual ErrorType UpSampleCube(void);
    ErrorType         GetCubePoints(int x, int y, int z, UVector3* CubePoints) const;
    ErrorType         GetCubeData(int x, int y, int z, int* Cube, int icomp) const;
    ErrorType         GetCubeData(int x, int y, int z, double* Cube, int icomp) const;
    int               GetNNeighbours(int ip, int* NeigList) const;
    double*           GetRectilinearCoords(int dir) const;

    AVSfield          GetAVSfield(void) const;
    ErrorType         MirrorCoordinates(int icoord);
    ErrorType         MirrorCoordinates(bool dirX, bool dirY, bool dirZ);
    ErrorType         DownSample(int* NewDims);
    UField*           GetDownSample(int* NewDims) const;
    ErrorType         DownSample(int downx, int downy, int downz);
    UField*           GetDownSample(int downx, int downy, int downz) const;
    ErrorType         SmoothDownSample(int DownFactor, int DownPhase);
    virtual ErrorType CenterCoords(bool centx, bool centy, bool centz);
   
// Specific for DICOM fMRI data in stamp format
    ErrorType         StampUnpack(int ndimStamp, double slicethickness, bool RemoveZeroSlices);
   
    UDistribution*    GetLineRMSHistogram(int dir, double DataMax) const;
    UDistribution*    GetDataHistogram(int NsubSample, int icomp=-1) const;
    unsigned int*     GetDataHistogramAsInt(int icomp) const;
    unsigned int*     GetDataHistogramAsInt(int imin, int imax, int Nbin, int Nmax, int NsubSample, bool LogScale, int icomp) const;
    unsigned int*     GetDataHistogramAsInt(double dmin, double dmax, int Nbin, int Nmax, int NsubSample, bool LogScale, int icomp) const;
    UField*           GetDataHistogramAsField2D(int imin, int imax, int Nbin, int Nmax, int NsubSample, bool LogScale, int icomp) const;
    UField*           GetDataHistogramAsField2D(double dmin, double dmax, int Nbin, int Nmax, int NsubSample, bool LogScale, int icomp) const;
    UField*           GetCrossHistogramAsField2D(double Xmin, double Xmax, double Ymin, double Ymax, const UField* YField, int iycomp, const UEuler& YtoX, int Nbin, int NsubSample, int ixcomp) const;

/* Import/Export*/   
    virtual ErrorType WriteBinary(FILE* fpOut, const char* AddComment = NULL) const;
    ErrorType         WriteBitMap(UFileName Fname, const unsigned char* RGBtab=NULL) const;
    ErrorType         WriteXDR(UFileName Fname, const char* Comment=NULL, const char*Comment2=NULL) const;
    ErrorType         WriteXDR(const char* FileOut, const char* Comment=NULL, const char*Comment2=NULL) const;
    ErrorType         Write1D_AsText(UFileName Fname, const char* Comment=NULL, const char*Comment2=NULL) const;
    ErrorType         Write1D_AsText(const char* FileName, const char* Comment=NULL, const char*Comment2=NULL) const;
    ErrorType         Write1D(UFileName Fname) const;
    ErrorType         Write1D(const char* FileName) const;
    ErrorType         WritePointsText(const char* FileName, bool Sorted) const;
    ErrorType         WritePointsText(UFileName FileName, bool Sorted) const;
    ErrorType         ExportRawSlices(const char* FileOut, int dir, const char* Comment=NULL) const;
   
    ErrorType         ReadAsBitMap(FILE* fpBitMap);
    ErrorType         ReadAsBitMap(const char* FileBitMap);
    ErrorType         ReadAsTiff(FILE* fpTiff);
    ErrorType         ReadAsTiff(const char* FileTiff);
    ErrorType         ReadComments(FILE* fpIn);
    ErrorType         ReadComments(const char* FileName);
    ErrorType         ReadComments(UFileName FileName);
    UString           GetFileComments(void) const {return FileComments;}
    ErrorType         SetFileComments(const char* Comment1, const char* Comment2=NULL);
    ErrorType         AddFileComments(const char* Comment1, const char* Comment2=NULL);

    ErrorType         PlotTriangle(UVector2 q0, UVector2 q1, UVector2 q2, const double* ZZ, bool NearestNeig);
    ErrorType         PlotTriangle(UVector2 q0, UVector2 q1, UVector2 q2, double ZZ);


/********* Andy **************/
    ErrorType         GetDirectNeighbors3D(int iLocation,int x, int y, int z, int* neighbors);
////    ErrorType         GetForwardNeighbors3D(int x, int y, int z, int* neighbors);
    ErrorType         GetBackwardNeighbors3D(int iLocation, int x, int y, int z, int* neighbors);
////    UField*           GenerateOneLevelSet3D();
    double            GetCurveLengthByLocation3D(int x, int y, int z, int iLocation);
    ErrorType         FastAlgorithmForLevelSetBasedOptimization3D(UField* originImage, double lambda1, double lambda2, double coef);
    ErrorType         FastGrayscaleReconstructionByDilation(UField* imageDataMarker);
////    ErrorType         RegionMinma();
////    ErrorType         RegionMaxima();
////    ErrorType         GetExtendedMin(int iH);
////    ErrorType         GetExtendedMax(int iH);
////    ErrorType         FastGrayscaleReconstructionByErosion(UField* pImageDataMarker);

/********* Andy **************/

protected:
    FieldType         FType;       // The coordinate type of the field
    DataType          DType;       // The data type: byte (=unsigned char), short, or integer
    int               veclen;      // Number of values per pixel (4 bytes is color)
    int               ndim;        // Number of dimensions
    int               nspace;      // Number of space coordinates for each voxel (can be larger than ndim, for e.g. a curved surface in 3D)
    int               dimensions[MAX_FIELD_DIMENSIONS];  // Number of pixels in x- y- z-direction
    unsigned char*    Bdata;       // Byte data pointer    NOTE: only one of these pointer is set
    short*            Sdata;       // Short data pointer
    int*              Idata;       // Integer data pointer
    float*            Fdata;       // float data pointer
    double*           Ddata;       // double data pointer
    float*            points;      // coordinate arrays
    
    UString           FileComments;// optional pointer containing the comments in and XDR-file, in case Ufield() was created from file.
    void              SetAllMembersDefault(void);
    void              DeleteAllMembers(ErrorType E);

private:
    ErrorType         error;       // General error flag
    static UString    Properties;
    static UString    Extends;

    ErrorType         CoordsFromTifName(UFileName TFile);
    int               GetNcoords(void) const;
    int               GetIndx(UVector3 x) const;
    int               GetIndy(UVector3 x) const;
    int               GetIndz(UVector3 x) const;
};

double  DLL_IO Correlate(const UField* F1, const UField* F2, const UField* Selector, double *pValue);
PMT_DP  DLL_IO GetDistanceTable(const UField* F1, const UField* F2);
PMT_DP  DLL_IO GetDistanceTable2(const UField* F1, const UField* F2);
double  DLL_IO GetDataPowerDif(const UField* F1, const UField* F2);

#endif //_UFIELD_INCLUDED
