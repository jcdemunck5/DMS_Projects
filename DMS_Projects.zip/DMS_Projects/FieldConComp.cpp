/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck   (adapted from Avs_coco.cpp, F. Verster 144, AvL/NKI       */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    25-04-02   creation, adapted from Avs_coc.cpp
  JdM    29-04-02   Bug fix: use qsort_func_low_to_high() instead of qsort_func_high_to_low
                             *Ncomp = Ngroup+1
  JdM    08-09-04   Added GetConnectComponentsCenters()
  JdM    13-09-04   Bug fix: ConnectComponents() set veclen =1 (not 0),
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    18-03-05   Bug Fix GetConnectComponentsCenters() (initializing min and max, omitting abs/fabs,  etc)
  JdM    10-04-06   GetConnectComponentsCenters(). Allow Intensity->veclen >1
  JdM    16-07-10   ConnectComponents(). Added slice specific version.
  JdM    19-07-10   Added GetConnectComponentsSelection()
  JdM    28-10-10   Changed (int) into (long int)
  JdM    13-05-11   Replaced UDebug::UDebug() by UDebug::ReplaceClassFunction()
  JdM    23-01-12   GetConnectComponentsCenters(). Allow nspace!=3 and/or Intensity==NULL (if FCT==U_FIELDCENTER_GRAVITY)
  JdM    08-10-12   GetConnectComponentsCenters(). Added parameter to skip background
  JdM    03-08-13   Changed order of include files
  JdM    28-12-13   Bug FIX: ConnectComponents(). Treat hist_ptr[] as a pointer pointer instead of as a long int. In 64 bits version old code did not work.
  JdM    21-04-14   Bug Fix: GetConnectComponentsCenters(). Set FCenter->nspace=nspace. Set FCenter->dimensions[0]=Ncomp (if background is skipped)
  JdM    01-12-14   Added FillCavities()
  JdM    03-12-14   Added SelectLargestComponent(void);
*/

#include <string.h>

#include "Field.h"
#include "Debug.h"

#define MAXINT32 0x7FFFFFFF


/* compare for stdlib qsort, sorts from low to high */
static int qsort_func_low_to_high(const void *a, const void *b)
{ 
    if (**(int**)a <  **(int**)b) return -1;
    if (**(int**)a == **(int**)b) return 0;
    return 1;
}

/* compare for stdlib qsort, sorts from high to low */
static int qsort_func_high_to_low(const void *a, const void *b)
{ 
    if (**(int**)a <  **(int**)b) return 1;
    if (**(int**)a == **(int**)b) return 0;
    return -1;
}

UField* UField::ConnectComponents(int* Ncomp, int dir) const
{
    AUTODEBUG.AddClassFunction("UField", "ConnectComponents()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(DType!=U_BYTE && DType!=U_SHORT && DType!=U_INTEGER)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Erroneous data type: DType = %d .\n",DType);
        return NULL;
    }
    if(veclen!=1)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Invalid veclen (=%d) .\n", veclen);
        return NULL;
    }
    if(dir< 0) return ConnectComponents(Ncomp);

    if(dir>=3)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Invalid dir (=%d) parameter.\n", dir);
        return NULL;
    }
    if(ndim!=3 || (FType!=U_UNIFORM && FType!=U_RECTILINEAR) )
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Invalid UField type (%s) .\n", (const char*)GetProperties(""));
        return NULL;
    }
    UField* Fout = new UField(*this);
    if(Fout==NULL || Fout->GetError()!=U_OK || Fout->ConvertData(UField::U_INTEGER, 1)!=U_OK)
    {
        delete Fout;
        CI.AddToLog("ERROR: UField::ConnectComponents(). Copying *this. \n");
        return NULL;
    }

    int NC = 0;
    for(int k=0; k<dimensions[dir]; k++)
    {
        UField* SL  = GetSlice(dir, k);
        if(SL==NULL || SL->GetError()!=U_OK)
        {
            delete Fout; delete SL;
            CI.AddToLog("ERROR: UField::ConnectComponents(). Getting slice %d. \n", k);
            return NULL;
        }
        int     NCs    = 0;
        UField* SLcmp  = SL->ConnectComponents(&NCs);
        if(SLcmp==NULL || SLcmp->GetError()!=U_OK || SLcmp->Idata==NULL)
        {
            delete Fout; delete SL; delete SLcmp;
            CI.AddToLog("ERROR: UField::ConnectComponents(). Getting connected component from slice %d. \n", k);
            return NULL;

        }

        if(NC>0)
        {
            int NPs = SLcmp->GetNpoints(); // Make component number unique and contigeous
            for(int s=0; s<NPs; s++)
            {
                if(SLcmp->Idata[s]==0) continue;
                SLcmp->Idata[s] += NC;
            }
        }
        NC += (NCs-1);

        if(Fout->SetSlice(dir, k, SLcmp)!=U_OK)
        {
            delete Fout; delete SL; delete SLcmp;
            CI.AddToLog("ERROR: UField::ConnectComponents(). Setting new output slice (k=%d).\n", k);
            return NULL;
        }
        delete SL; delete SLcmp;
    }
    if(Ncomp) *Ncomp = NC;
    return Fout;
}

UField* UField::ConnectComponents(int* Ncomp) const
/*
   Return a new UField of type int, with the same geometry as *this, such that
   (indirectly) orthogonally connected pixels get the same group number. This group
   number represents the relative size of the connected component.
   So, 0 reprsents the background, 1 the largest component, 2 the second largest
   component, etc.
   input pixels are considered as background when equal to 0, and as data when unequal to 0

   if(Ncomp) *Ncomp will be set equal to the number of connected components

   Adapted from AVS_coco.cpp by Frans Verster.
 */
{
    AUTODEBUG.AddClassFunction("UField", "ConnectComponents()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(DType!=U_BYTE && DType!=U_SHORT && DType!=U_INTEGER)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Erroneous data type: DType = %d .\n",DType);
        return NULL;
    }
    if(veclen!=1)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Invalid veclen (=%d) .\n", veclen);
        return NULL;
    }

    int xsize = 1;
    int ysize = 1;
    int zsize = 1;
    switch(ndim)
    {
    case 3: zsize = dimensions[2];
    case 2: ysize = dimensions[1];
    case 1: xsize = dimensions[0]; break;
    default:
        CI.AddToLog("ERROR: UField::ConnectComponents(). Invalid ndim (=%d) .\n", ndim);
        return NULL;
    }

    UField* Fout = new UField(*this,true);
    if(Fout==NULL || Fout->GetError()!=U_OK)
    {
        delete Fout;
        CI.AddToLog("ERROR: UField::ConnectComponents(). Creating output UField .\n");
        return NULL;
    }
    Fout->DType  = U_INTEGER;
    Fout->veclen = 1;
    Fout->Idata  = new int[xsize*ysize*zsize];
    if(Fout->Idata==NULL)
    {
        delete Fout;
        CI.AddToLog("ERROR: UField::ConnectComponents(). Allocating integer data for output: xsize=%d, ysize=%d, zsize=%d .\n",xsize, ysize, zsize);
        return NULL;
    }

    int*            pIdataOut = Fout->Idata;
    unsigned char*  pBdataIn  = Bdata;
    short*          pSdataIn  = Sdata;
    int*            pIdataIn  = Idata;

/* init output and do x-dim, input data type dependent */
    int x=0,y=0,z=0, i=0;
    int group = 0;   // first group written will be 1

    switch(DType)
    {
    case U_BYTE:
        for(z=0; z<zsize; z++)
        {
            for(y=0; y<ysize; y++)
            {
                unsigned char old = 0;
                for(x=0; x<xsize; x++)
                {
                    if(*pBdataIn)
                        if(old&& (old== *pBdataIn)) *pIdataOut++ =   group; /* current group */
                        else                        *pIdataOut++ = ++group; /* new group */
                    else
                        *pIdataOut++ = 0; /* no data */
                    old = *pBdataIn++;
                }
            }
        }
        break;

    case U_SHORT:
        for (z=0; z<zsize; z++)
        {
            for(y=0; y<ysize; y++)
            {
                short old = 0;
                for(x=0; x<xsize; x++)
                {
                    if(*pSdataIn)
                        if(old&&(old== *pSdataIn)) *pIdataOut++ = group; /* current group */
                        else                       *pIdataOut++ = ++group; /* new group */
                    else
                        *pIdataOut++ = 0; /* no data */
                    old = *pSdataIn++;
                }
            }
      }
      break;

    case U_INTEGER:
        for (z=0; z<zsize; z++)
        {
            for(y=0; y<ysize; y++)
            {
                int old = 0;
                for(x=0; x<xsize; x++)
                {
                    if(*pIdataIn)
                        if(old&&(old== *pIdataIn)) *pIdataOut++ = group; /* current group */
                        else                       *pIdataOut++ = ++group; /* new group */
                    else
                        *pIdataOut++ = 0; /* no data */
                    old = *pIdataIn++;
                }
            }
        }
        break;

    default:
        delete Fout;
        CI.AddToLog("ERROR: UField::ConnectComponents(). Erroneous data type: DType = %d .\n",DType);
        return NULL;
    }
    group++; /* from now on counts group 0 as a group */

/* Y-dim, this version uses only a linear chained table */
    if((ndim==2) || (ndim==3))
    {
        pIdataOut  = Fout->Idata;
        int* table = new int[group];
        if(table==NULL)
        {
            delete Fout;
            CI.AddToLog("ERROR: UField::ConnectComponents(). Memory allocation for Y-dimension -table (group=%d). \n",group);
            return NULL;
        }
        for(i=0; i<group; i++) table[i] = i;


/* make y-dim group table */
        switch(DType)
        {
        case U_BYTE:
            pBdataIn  = Bdata;
            for(z=0; z<zsize; z++)
            {
                for(x=0; x<xsize; x++)
                {
                    int*           out_ptr     = pIdataOut + x + z*xsize*ysize; /* out_ptr=&pIdataOut[z,0,x] */
                    unsigned char* in_ptr_byte = pBdataIn  + x + z*xsize*ysize; /* in_ptr=&in_data[z,0,x] */
                    int            old         = 0;
                    unsigned char  old_in      = 0;
                    for(y=0; y<ysize; y++)
                    {
                        int            new_data = *out_ptr;
                        unsigned char  new_in   = *in_ptr_byte;
                        if(new_data && old && new_in==old_in)  /* join these groups */
                        {
                            while(new_data != table[new_data]) new_data = table[new_data];
                            while(old      != table[old])      old      = table[old];
                            if(new_data<old) table[old     ] = new_data;
                            else             table[new_data] = old;
                        }
                        old          = *out_ptr;
                        out_ptr     += xsize; /* advance pointer for next y */
                        old_in       = new_in;
                        in_ptr_byte += xsize;
                    }
                }
            }
            break;

        case U_SHORT:
            pSdataIn  = Sdata;
            for(z=0; z<zsize; z++)
            {
                for (x=0; x<xsize; x++)
                {
                    int*   out_ptr      = pIdataOut  + x + z*xsize*ysize; /* out_ptr=&pIdataOut[z,0,x] */
                    short* in_ptr_short = pSdataIn   + x + z*xsize*ysize; /* in_ptr=&in_data[z,0,x] */
                    int    old          = 0;
                    short  old_in       = 0;
                    for(y=0; y<ysize; y++)
                    {
                        int   new_data = *out_ptr;
                        short new_in   = *in_ptr_short;
                        if(new_data && old && new_in==old_in) /* join these groups */
                        {
                            while (new_data != table[new_data]) new_data = table[new_data];
                            while (old      != table[old])      old      = table[old];
                            if(new_data<old) table[old]      = new_data;
                            else             table[new_data] = old;
                        }
                        old           = *out_ptr;
                        out_ptr      += xsize; /* advance pointer for next y */
                        old_in        = new_in;
                        in_ptr_short += xsize;
                    }
                }
            }
            break;

        case U_INTEGER:
            pIdataIn = Idata;
            for(z=0; z<zsize; z++)
            {
                for(x=0; x<xsize; x++)
                {
                    int* out_ptr    = pIdataOut + x + z*xsize*ysize; /* out_ptr=&pIdataOut[z,0,x] */
                    int* in_ptr_int = pIdataIn  + x + z*xsize*ysize; /* in_ptr=&in_data[z,0,x] */
                    int  old        = 0;
                    int  old_in     = 0;
                    for(y=0; y<ysize; y++)
                    {
                        int  new_data = *out_ptr;
                        int  new_in   = *in_ptr_int;
                        if(new_data && old && new_in==old_in) /* join these groups */
                        {
                            while (new_data != table[new_data]) new_data = table[new_data];
                            while (old      != table[old     ]) old      = table[old];
                            if(new_data<old) table[old     ] = new_data;
                            else             table[new_data] = old;
                        }
                        old         = *out_ptr;
                        out_ptr    += xsize; /* advance pointer for next y */
                        old_in      = new_in;
                        in_ptr_int += xsize;
                    }
                }
            }
            break;
        } /* all input data types done */

/* reorder group table: give every entry the end of chain (=lowest) groupnr */
        for(i=0; i<group; i++)
        {
            int old = table[i];
            while(old != table[old]) old = table[old];
            table[i] = old;
        }

/* join y-dim groups */
        pIdataOut = Fout->Idata;
        for(i=0; i<GetNpoints(); i++)
        {
            *pIdataOut = table[*pIdataOut];
            pIdataOut++;
        }

        delete[] table;
    } /* y-dim lin table processed */

/* Z-dim, this version uses only a linear chained table */
    if(ndim==3)
    {
        pIdataOut  = Fout->Idata;
        int* table = new int[group];
        if(table==NULL)
        {
            delete Fout;
            CI.AddToLog("ERROR: UField::ConnectComponents(). Memory allocation for Z-dimension -table (group=%d). \n",group);
            return NULL;
        }
        for(i=0; i<group; i++) table[i] = i;


/* make z-dim group table */
        switch(DType)
        {
        case U_BYTE:
            pBdataIn  = Bdata;
            for(y=0; y<ysize; y++)
            {
                for(x=0; x<xsize; x++)
                {
                    int*           out_ptr     = pIdataOut + x;
                    unsigned char* in_ptr_byte = pBdataIn  + x;
                    int           old    = 0;
                    unsigned char old_in = 0;
                    for(z=0; z<zsize; z++)
                    {
                        int           new_data = *out_ptr;
                        unsigned char new_in   = *in_ptr_byte;
                        if(new_data && old && new_in==old_in) /* join these groups */
                        {
                            while (new_data != table[new_data]) new_data = table[new_data];
                            while (old      != table[old     ]) old      = table[old];
                            if(new_data<old) table[old     ] = new_data;
                            else             table[new_data] = old;
                        }
                        old          =  *out_ptr;
                        out_ptr     += (xsize * ysize); /* advance pointer for next z */
                        old_in       =  new_in;
                        in_ptr_byte += (xsize * ysize);
                    }
                }
                pIdataOut += xsize; /* next y */
                pBdataIn  += xsize;
            }
            break;

        case U_SHORT:
            pSdataIn = Sdata;
            for(y=0; y<ysize; y++)
            {
                for(x=0; x<xsize; x++)
                {
                    int*     out_ptr      = pIdataOut + x;
                    short*   in_ptr_short = pSdataIn  + x;
                    int      old    = 0;
                    short    old_in = 0;
                    for(z=0; z<zsize; z++)
                    {
                        int   new_data = *out_ptr;
                        short new_in   = *in_ptr_short;
                        if(new_data && old && new_in==old_in) /* join these groups */
                        {
                            while (new_data != table[new_data]) new_data = table[new_data];
                            while (old      != table[old     ]) old      = table[old];
                            if(new_data < old) table[old     ] = new_data;
                            else               table[new_data] = old;
                        }
                        old           =  *out_ptr;
                        out_ptr      += (xsize * ysize); /* advance pointer for next z */
                        old_in        =  new_in;
                        in_ptr_short += (xsize * ysize);
                    }
                }
                pIdataOut += xsize; /* next y */
                pSdataIn  += xsize;
            }
            break;

        case U_INTEGER:
            pIdataIn = Idata;
            for(y=0; y<ysize; y++)
            {
                for (x=0; x<xsize; x++)
                {
                    int* out_ptr    = pIdataOut + x;
                    int* in_ptr_int = pIdataIn  + x;
                    int old    = 0;
                    int old_in = 0;
                    for(z=0; z<zsize; z++)
                    {
                        int new_data = *out_ptr;
                        int new_in   = *in_ptr_int;
                        if(new_data && old && new_in==old_in) /* join these groups */
                        {
                            while(new_data != table[new_data]) new_data = table[new_data];
                            while(old      != table[old     ]) old      = table[old];
                            if(new_data<old) table[old     ] = new_data;
                            else             table[new_data] = old;
                        }
                        old         = *out_ptr;
                        out_ptr    += (xsize * ysize); /* advance pointer for next z */
                        old_in      =  new_in;
                        in_ptr_int += (xsize * ysize);
                    }
                }
                pIdataOut += xsize; /* next y */
                pIdataIn  += xsize;
            }
            break;
        } /* all input data types done */

/* reorder group table: give every entry the end of chain (=lowest) groupnr */
        for(i=0; i<group; i++)
        {
            int old = table[i];
            while (old != table[old]) old = table[old];
            table[i] = old;
        }
/* join z-dim groups */
        pIdataOut   = Fout->Idata;
        for(i=0; i<GetNpoints(); i++)
        {
            *pIdataOut = table[*pIdataOut];
            pIdataOut++;
        }
        delete[] table;
    } /* z-dim lin table processed */

/* build histogram of output groupnr */
    pIdataOut      = Fout->Idata;
    int*  table    = new int[group];
    int** hist_ptr = new int*[group];
    if((table==NULL) || (hist_ptr==NULL))
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Memory allocation for table and histogram (group=%d). \n",group);
        delete[] table;
        delete[] hist_ptr;
        delete   Fout;
        return NULL;
    }
    for(i=0; i<group; i++) table[i]    = 0;         /* reset before ++ */
    for(i=0; i<group; i++) hist_ptr[i] = table + i; /* address */
    for(i=0; i<GetNpoints(); i++) table[*pIdataOut++]++;

/* pixel count now all pixels */
    table[0] = 0; /* let the background disappear */

/* sort hist_ptr from high to low with qsort, and convert ptr to indices */
    table[0] = MAXINT32; /* group 0 isnt a real group, but ensure its nr 0 */
    qsort(hist_ptr, group, sizeof(hist_ptr[0]), qsort_func_low_to_high);

/* delete the smallest mingroup number and the highest maxgroup number,
   the remaining groups in table are given subsequent numbers. table is
   now a lookup table for the output */

    for(    i=0; i<group && *hist_ptr[i] == 0; i++);

    for(int j=0; i<group; j++, i++) *hist_ptr[i] = j;

    int Ngroup = 0;
    for(i=0; i<group; i++)
        if(Ngroup < *hist_ptr[i]) Ngroup = *hist_ptr[i];

    if(Ncomp) *Ncomp = Ngroup+1;


    pIdataOut = Fout->Idata;
    for(i=0; i<GetNpoints(); i++)
    {
        *pIdataOut = Ngroup - table[*pIdataOut];
        pIdataOut++;
    }

/* free data */
    delete[] table;
    delete[] hist_ptr;

/* should be OK now, bye bye */
    return Fout;
}

UField* UField::GetConnectComponentsCenters(const UField* Intensity, int iveccomp, int Ncomp, int** Size, UFieldCenterType FCT, bool SkipBackGround) const
{
    AUTODEBUG.AddClassFunction("UField", "GetConnectComponentsCenters()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::ConnectComponents(). Object NULL or erroneous. \n");
        return NULL;
    }

    if(Ncomp<=0)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Ncomp out of range: Ncomp = %d.\n", Ncomp);
        return NULL;
    }
    if(nspace!=ndim || DType!=U_INTEGER || Idata==NULL || veclen!=1)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Incompatible properties (%s).\n", (const char*)GetProperties(""));
        return NULL;
    }

    if(FCT==U_FIELDCENTER_MININTENS || FCT==U_FIELDCENTER_MAXINTENS)
    {
        if(Intensity==NULL || Intensity->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). NULL or erroneous Intensity UField argument  .\n");
            return NULL;
        }
        if(iveccomp<0 || iveccomp>=Intensity->GetVeclen())
        {
            CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Wrong vector component (iveccomp=%d)  .\n", iveccomp);
            return NULL;
        }
        if(Intensity->nspace!=Intensity->ndim)
        {
            CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Intensity of wrong type (%s).\n", (const char*)Intensity->GetProperties(""));
            return NULL;
        }
        for(int id=0; id<ndim; id++)
        {
            if(dimensions[id]!=Intensity->dimensions[id])
            {
                CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Incompatible dimensions[%d] (%d and %d).\n", id, dimensions[id], Intensity->dimensions[id]);
                return NULL;
            }
        }
    }
    else if(FCT==U_FIELDCENTER_GRAVITY) 
    {
        if(Size==NULL) 
        {
            CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Size-parameter==NULL .\n");
            return NULL;
        }
    }
    else 
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Upsupported UFieldCenterType-parameter, FTC = %d .\n", FCT);
        return NULL;
    }

    UField* FCenter = new UField();
    if(FCenter)
    {
        FCenter->FType         = U_IRREGULAR;
        FCenter->nspace        = nspace;
        FCenter->ndim          = 1;
        FCenter->dimensions[0] = SkipBackGround ? Ncomp : Ncomp+1;
        if(FCT==U_FIELDCENTER_GRAVITY)
        {
            FCenter->veclen    = 0;
            FCenter->DType     = U_BYTE;
        }
        else
        {
            FCenter->veclen    = 2;
            FCenter->DType     = Intensity->DType;
        }
        FCenter->points        = new float[FCenter->nspace * FCenter->dimensions[0]];
        if(FCenter->points==NULL) FCenter->error = U_ERROR;
        
        if(FCT!=U_FIELDCENTER_GRAVITY)
        {
            switch(Intensity->DType)
            {
            case U_BYTE:
                FCenter->Bdata = new unsigned char[FCenter->veclen * FCenter->dimensions[0]];
                if(FCenter->Bdata==NULL)
                    FCenter->error = U_ERROR;
                else
                {
                    for(int k=0; k<FCenter->dimensions[0]; k++)
                    {
                        FCenter->Bdata[k                       ] = 255;
                        FCenter->Bdata[k+FCenter->dimensions[0]] =   0;
                    }
                }
                break;
            case U_SHORT:
                FCenter->Sdata = new short        [FCenter->veclen * FCenter->dimensions[0]];
                if(FCenter->Sdata==NULL)
                    FCenter->error = U_ERROR;
                else
                    for(int k=0; k<FCenter->dimensions[0]; k++)
                    {
                        FCenter->Sdata[k                       ] = 32767;
                        FCenter->Sdata[k+FCenter->dimensions[0]] =-32767;
                    }
                break;
            case U_INTEGER:
                FCenter->Idata = new int          [FCenter->veclen * FCenter->dimensions[0]];
                if(FCenter->Idata==NULL)
                    FCenter->error = U_ERROR;
                else
                    for(int k=0; k<FCenter->dimensions[0]; k++)
                    {
                        FCenter->Idata[k                       ] = 2147483647;
                        FCenter->Idata[k+FCenter->dimensions[0]] =-2147483647;
                    }
                break;
            case U_FLOAT:
                FCenter->Fdata = new float        [FCenter->veclen * FCenter->dimensions[0]];
                if(FCenter->Fdata==NULL)
                    FCenter->error = U_ERROR;
                else
                    for(int k=0; k<FCenter->dimensions[0]; k++)
                    {
                        FCenter->Fdata[k                       ] = 1.e20F;
                        FCenter->Fdata[k+FCenter->dimensions[0]] =-1.e20F;
                    }
                break;
            case U_DOUBLE:
                FCenter->Ddata = new double       [FCenter->veclen * FCenter->dimensions[0]];
                if(FCenter->Ddata==NULL)
                    FCenter->error = U_ERROR;
                else
                    for(int k=0; k<FCenter->dimensions[0]; k++)
                    {
                        FCenter->Ddata[k                       ] = 1.e200;
                        FCenter->Ddata[k+FCenter->dimensions[0]] =-1.e200;
                    }
                break;
            default:        
                FCenter->error = U_ERROR;
            }
        }
    }
    if(FCenter==NULL || FCenter->error!=U_OK)
    {
        delete FCenter;
        CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Memory allocation in return UField-object. Ncomp = %d \n", Ncomp);
        return NULL;
    }

    if(Size)    *Size = new int     [Ncomp+1];
    UVector3*    Pnt  = new UVector3[Ncomp+1];
    const int*   co   = Idata;
    if((Size&&!(*Size)) || Pnt==NULL || co==NULL)
    {
        if(Size) delete[] *Size;
        delete[] Pnt;

        delete FCenter;
        CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). Memory allocation in intermadiate arrays. Ncomp = %d \n", Ncomp);
        return NULL;
    }
    if(Size)
        for(int n=0; n<Ncomp+1; n++) {(*Size)[n] = 0;}

    int NV = 0;  if(Intensity) NV = Intensity->GetVeclen();
    int NP = GetNpoints();
    for(int n=0; n<NP; n++)
    {
        int index = co[n];
        if(SkipBackGround && index==0) continue;
        if(SkipBackGround) index--;
        if(index<0 || index>=Ncomp+1)
        {
            if(Size) {delete[] *Size; *Size=NULL;}
            delete[] Pnt;
            delete   FCenter;
            CI.AddToLog("ERROR: UField::GetConnectComponentsCenters(). index (%d) out of range. Ncomp = %d \n", index, Ncomp);
            return NULL;
        }
        if(Size) (*Size)[index]++;
        if(FCT==U_FIELDCENTER_GRAVITY) 
        {
            Pnt[index] += GetPoint(n);
            continue;
        }
        switch(Intensity->DType)
        {
        case U_BYTE:
            {
                unsigned char  dat  = Intensity->Bdata[n*NV+iveccomp];
                unsigned char* MiMa = FCenter  ->Bdata;
                if(dat<MiMa[index])
                {
                    MiMa[index] = dat;
                    if(FCT==U_FIELDCENTER_MININTENS) Pnt[index] = GetPoint(n);
                }
                if(dat>MiMa[FCenter->dimensions[0]+index])
                {
                    MiMa[FCenter->dimensions[0]+index] = dat;
                    if(FCT==U_FIELDCENTER_MAXINTENS) Pnt[index] = GetPoint(n);
                }
                break;
            }
        case U_SHORT:
            {
                short  dat  = Intensity->Sdata[n*NV+iveccomp];
                short* MiMa = FCenter  ->Sdata;
                if(dat<MiMa[index])
                {
                    MiMa[index] = dat;
                    if(FCT==U_FIELDCENTER_MININTENS) Pnt[index] = GetPoint(n);
                }
                if(dat>MiMa[FCenter->dimensions[0]+index])
                {
                    MiMa[FCenter->dimensions[0]+index] = dat;
                    if(FCT==U_FIELDCENTER_MAXINTENS) Pnt[index] = GetPoint(n);
                }
                break;
            }
        case U_INTEGER:
            {
                int  dat  = Intensity->Idata[n*NV+iveccomp];
                int* MiMa = FCenter  ->Idata;
                if(dat<MiMa[index])
                {
                    MiMa[index] = dat;
                    if(FCT==U_FIELDCENTER_MININTENS) Pnt[index] = GetPoint(n);
                }
                if(dat>MiMa[FCenter->dimensions[0]+index])
                {
                    MiMa[FCenter->dimensions[0]+index] = dat;
                    if(FCT==U_FIELDCENTER_MAXINTENS) Pnt[index] = GetPoint(n);
                }
                break;
            }
        case U_FLOAT:
            {
                float  dat  = Intensity->Fdata[n*NV+iveccomp];
                float* MiMa = FCenter  ->Fdata;
                if(dat<MiMa[index])
                {
                    MiMa[index] = dat;
                    if(FCT==U_FIELDCENTER_MININTENS) Pnt[index] = GetPoint(n);
                }
                if(dat>MiMa[FCenter->dimensions[0]+index])
                {
                    MiMa[FCenter->dimensions[0]+index] = dat;
                    if(FCT==U_FIELDCENTER_MAXINTENS) Pnt[index] = GetPoint(n);
                }
                break;
            }
        case U_DOUBLE:
            {
                double  dat  = Intensity->Ddata[n*NV+iveccomp];
                double* MiMa = FCenter  ->Ddata;
                if(dat<MiMa[index])
                {
                    MiMa[index] = dat;
                    if(FCT==U_FIELDCENTER_MININTENS) Pnt[index] = GetPoint(n);
                }
                if(dat>MiMa[FCenter->dimensions[0]+index])
                {
                    MiMa[FCenter->dimensions[0]+index] = dat;
                    if(FCT==U_FIELDCENTER_MAXINTENS) Pnt[index] = GetPoint(n);
                }
                break;
            }
        }
    }
    if(FCT==U_FIELDCENTER_GRAVITY && Size)
        for(int n=0; n<Ncomp+1; n++) if((*Size)[n]) Pnt[n] = Pnt[n] * 1./ double( (*Size)[n] );

    for(int n=0; n<FCenter->dimensions[0]; n++)
    {
        if(nspace>=1) FCenter->points[                          n] = float(Pnt[n].Getx());
        if(nspace>=2) FCenter->points[  FCenter->dimensions[0] +n] = float(Pnt[n].Gety());
        if(nspace>=3) FCenter->points[2*FCenter->dimensions[0] +n] = float(Pnt[n].Getz());
    }
    delete[] Pnt;

    return FCenter;
}
UField* UField::GetConnectComponentsSelection(int Ncomp, int MinSize, int MaxSize) const
{
    AUTODEBUG.AddClassFunction("UField", "GetConnectComponentsSelection()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(veclen!=1 || DType!=U_INTEGER || Idata==NULL)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). Object of wrong type (%s) .\n", (const char*)GetProperties(""));
        return NULL;
    }
    int NPoints = GetNpoints();
    if(MinSize<0) MinSize = 0;
    if(MaxSize<0) MaxSize = 1+NPoints;

    if(MinSize>MaxSize)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). Invalid size parameters, MinSize=%d, MaxSize=%d .\n", MinSize, MaxSize);
        return NULL;
    }
    if(Ncomp<=0)
    {
        CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). Invalid Ncomp (=%d) .\n", Ncomp);
        return NULL;
    }
    UField* Fout = new UField(*this, true);
    if(Fout && Fout->GetError()==U_OK)
    {
        Fout->SetVeclen(1);
        Fout->DType = U_BYTE;
        Fout->Idata = NULL;
        Fout->Bdata = new unsigned char[GetNpoints()];
        if(Fout->Bdata) memset(Fout->Bdata, 0, GetNpoints());
    }
    int* Size = new int[Ncomp+1];
    if(Size==NULL || Fout==NULL || Fout->GetError()!=U_OK || Fout->GetBdata()==NULL)
    {
        delete[] Size; delete Fout;
        CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). Creating output UField-object or memory allocation, Ncomp =%d. \n", Ncomp);
        return NULL;
    }
    for(int k=0; k<Ncomp+1; k++) Size[k] = 0;

    for(int n=0; n<NPoints; n++)
    {
        int index = Idata[n];
        if(index<0 || index>=Ncomp+1)
        {
            delete[] Size; delete Fout;
            CI.AddToLog("ERROR: UField::GetConnectComponentsSelection(). index (%d) out of range. Ncomp = %d \n", index, Ncomp);
            return NULL;
        }
        Size[index]++;
    }
    for(int k=0; k<Ncomp+1; k++)
    {
        if(Size[k]<MinSize || Size[k]>MaxSize) Size[k]=0;
        else                                   Size[k]=1;
    }

    for(int n=0; n<NPoints; n++)
        Fout->Bdata[n] = Size[Idata[n]];

    delete[] Size;
    return Fout;
}

ErrorType UField::SelectLargestComponent(void)
{
    AUTODEBUG.AddClassFunction("UField", "SelectLargestComponent()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::SelectLargestComponent(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DType!=U_BYTE && DType!=U_SHORT && DType!=U_INTEGER)
    {
        CI.AddToLog("ERROR: UField::SelectLargestComponent(). Erroneous data type: DType = %d .\n",DType);
        return U_ERROR;
    }
    if(veclen!=1)
    {
        CI.AddToLog("ERROR: UField::SelectLargestComponent(). Invalid veclen (=%d) .\n", veclen);
        return U_ERROR;
    }
    int     Ncmp = 0;
    UField* Coco = this->ConnectComponents(&Ncmp);
    if(Coco==NULL || Coco->GetError()!=U_OK || Coco->GetIdata()==NULL)
    {
        delete Coco;
        CI.AddToLog("ERROR: UField::SelectLargestComponent(). Getting connected components from complement.\n");
        return U_ERROR;
    }

    int NP = GetNpoints();
    switch(DType)
    {
    case U_BYTE:    for(int n=0; n<NP; n++) Bdata[n] = (Coco->Idata[n]==1); break;
    case U_SHORT:   for(int n=0; n<NP; n++) Sdata[n] = (Coco->Idata[n]==1); break;
    case U_INTEGER: for(int n=0; n<NP; n++) Idata[n] = (Coco->Idata[n]==1); break;
    }
    delete[] Coco;

    return U_OK;
}

ErrorType UField::FillCavities(int* Nfilled)
{
    AUTODEBUG.AddClassFunction("UField", "FillCavities()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::FillCavities(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DType!=U_BYTE && DType!=U_SHORT && DType!=U_INTEGER)
    {
        CI.AddToLog("ERROR: UField::FillCavities(). Erroneous data type: DType = %d .\n",DType);
        return U_ERROR;
    }
    if(veclen!=1)
    {
        CI.AddToLog("ERROR: UField::FillCavities(). Invalid veclen (=%d) .\n", veclen);
        return U_ERROR;
    }
    if(HasBorder(0)==false)
    {
        CI.AddToLog("ERROR: UField::FillCavities(). Field should have zero boundary .\n");
        return U_ERROR;
    }
    if(LogicNot()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::FillCavities(). Applying (first) logical NOT.\n");
        return U_ERROR;
    }
    
    if(Nfilled) *Nfilled = 0;
    int     Ncmp = 0;
    UField* Coco = this->ConnectComponents(&Ncmp);
    if(Coco==NULL || Coco->GetError()!=U_OK || Coco->GetIdata()==NULL)
    {
        delete Coco;
        CI.AddToLog("ERROR: UField::FillCavities(). Getting connected components from complement.\n");
        return U_ERROR;
    }
    if(Ncmp<=1) 
    {
        delete Coco;
        return U_OK;
    }
    if(Nfilled) *Nfilled = Ncmp-1;

    int NP = GetNpoints();
    switch(DType)
    {
    case U_BYTE:    for(int n=0; n<NP; n++) Bdata[n] = !Bdata[n] | (Coco->Idata[n]>1); break;
    case U_SHORT:   for(int n=0; n<NP; n++) Sdata[n] = !Sdata[n] | (Coco->Idata[n]>1); break;
    case U_INTEGER: for(int n=0; n<NP; n++) Idata[n] = !Idata[n] | (Coco->Idata[n]>1); break;
    }
    delete Coco;

    return U_OK;
}

