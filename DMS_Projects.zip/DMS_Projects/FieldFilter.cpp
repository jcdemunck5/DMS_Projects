/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck   (adapted from Avs_ops.cpp, MB v Herk:                     */
/*                      from 16-03-92 to 19980202), AvL/NKI                      */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    21-03-08   creation, adapted from Avs_ops.cpp
  JdM    03-08-13   Changed order of include files
  JdM    25-03-13   use #ifdef WIN64 to define somes ints as __int64 in order to avoid compiler warnings
  JdM    21-11-14   BUG FIX: RunBasicFilter(). In first pass, pointer was uncorrectly updated. As a result, filter was not applied in fastest direction.
  JdM    23-12-15   GetSpatialFilteredField(). renamed U_SPATFILT_EDGE as U_SPATFILT_EDGEIN (inner edge) and added U_SPATFILT_EDGEOUT (outer edge)
*/

#include <string.h>

#include "Field.h"



#define LARGEINT 1000000000             /* almost 2^31 (seed for max) */
#define SMALL    0.00000001             /* zero tolerance             */
#define MAXS     2048                   /* maximum dimension          */

#define FILT_SMTH  0                    /* basic filter operations    */
#define FILT_MIN   1
#define FILT_MAX   2


static void bfastmax(unsigned char *array, unsigned char *temp1, int cnt, int ksize, int bsize, int step)
{ 
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif
    unsigned char *p     = temp1;
    unsigned char *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;

    while(count--) *p++ = 0;                     /* left guard             */

    if(step==1)                                  /* copy of input          */
    { 
        memcpy(p, array, cnt);
        p += cnt;
    } 
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = 0;         /* right guard (one less) */

    size   = p - temp1;                           /* size of guarded array  */
    memcpy(temp2, temp1, size);                   /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */
    p      = temp1;                               /* forwards pass */

    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if((int)(*p) > val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if((int)*p > val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
        if(*temp1 > *temp2) *array++ = *temp1++, temp2++;
        else                *array++ = *temp2++, temp1++;
    }
    else
    {
        while(count--)
        if(*temp1 > *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

static void bfastmin(unsigned char *array, unsigned char *temp1, int cnt, int ksize, int bsize, int step)
{ 
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif

    unsigned char *p     = temp1;
    unsigned char *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;
    while(count--) *p++ = 255;                   /* left guard             */

    if(step==1)                                  /* copy of input          */
    { 
        memcpy(p, array, cnt);
        p += cnt;
    }
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = 255;        /* right guard (one less) */
    size   = p - temp1;                           /* size of guarded array */
    memcpy(temp2, temp1, size);                   /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */
    p      = temp1;                               /* forwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if((int)(*p) < val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if((int)(*p) < val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
        if(*temp1 < *temp2) *array++ = *temp1++, temp2++;
        else                *array++ = *temp2++, temp1++;
    }
    else
    { 
        while(count--)
        if(*temp1 < *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

static void bfastsmth(unsigned char *array, unsigned char *temp, int cnt, int ksize, int step)
{ 
    int size, scale, halfk, halfk1;
    int sum=0;                            /* note: make sum and ltemp long */
    int *ltemp = (int *) temp;            /*       for 16 bit machines     */
    unsigned char *p = array;
    int count, distance;

    if(ksize > cnt/2) ksize = cnt/2;
    if(ksize <= 1 || cnt<=1) return;

    halfk  = (ksize+1)/2;
    halfk1 = (ksize+2)/2;

  /* First we sum the first (ksize+1)/2 pixels of array (in 32 bits) */

    count=halfk;
    if(step == 1)
        while(count--) sum += *p++;
    else
        while(count--) sum += *p, p += step;

  /* Now we calculate the propagating 32 bit sum for the first
     (ksize+2)/2 pixels.
  */

    count=halfk1;
    if(step == 1)
        while(count--) *ltemp++ = sum, sum += *p++;
    else
        while(count--) *ltemp++ = sum, sum += *p, p += step;

  /* Next process pixels that are not within (ksize + 1 or 2)/2
     of the boundaries.
  */

    size     = cnt - halfk - halfk1;
    count    = size;
    distance = (-ksize-1) * step;

    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p, p += step;

  /* process the last (ksize+1)/2 pixels */

    count=halfk;
    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, p += step;

  /* scale the long array and correct edge effects */

    ltemp = (int *) temp;
    p     = array;
    scale = halfk1;

    count = halfk1;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale++;
    else
        while(count--) *p = *ltemp++ / scale++, p += step;

    count = cnt - 2*halfk;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / ksize;
    else
        while(count--) *p = *ltemp++ / ksize, p += step;

    count = halfk1;
    scale = ksize;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale--;
    else
        while(count--) *p = *ltemp++ / scale--, p += step;
}
static void sfastmax(short int *array, short int *temp1, int cnt, int ksize, int bsize, int step)
{ 
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif

    short *p     = temp1;
    short *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;

    while(count--) *p++ = -32768;                /* left guard             */

    if(step==1)                                  /* copy of input          */
    { 
        memcpy(p, array, cnt * sizeof(short));
        p += cnt;
    }
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = -32768;    /* right guard (one less) */

    size = p - temp1;                             /* size of guarded array  */
    memcpy(temp2, temp1, size * sizeof(short));   /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */
    p      = temp1;                               /* forwards pass */

    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if((int)(*p) > val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if((int)*p > val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
            if(*temp1 > *temp2) *array++ = *temp1++, temp2++;
            else                *array++ = *temp2++, temp1++;
    }
    else
    { 
        while(count--)
        if(*temp1 > *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

static void sfastmin(short int *array, short int *temp1, int cnt, int ksize, int bsize, int step)
{ 
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif
    short *p     = temp1;
    short *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;
    while(count--) *p++ = 32767;                 /* left guard             */

    if(step==1)                                  /* copy of input          */
    { 
        memcpy(p, array, cnt * sizeof(short));
        p += cnt;
    }
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = 32767;     /* right guard (one less) */

    size = p - temp1;                             /* size of guarded array */
    memcpy(temp2, temp1, size * sizeof(short));   /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */
    p = temp1;                                    /* forwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if((int)(*p) < val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if((int)(*p) < val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
        if(*temp1 < *temp2) *array++ = *temp1++, temp2++;
        else                *array++ = *temp2++, temp1++;
    }
    else
    { 
        while(count--)
        if(*temp1 < *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

static void sfastsmth(short int *array, short int *temp, int cnt, int ksize, int step)
{ 
    int size, scale, halfk, halfk1;
    int sum=0;                            /* note: make sum and ltemp long */
    int *ltemp = (int *) temp;            /*       for 16 bit machines     */
    short *p = array;
    int count, distance;

    if(ksize > cnt/2) ksize = cnt/2;
    if(ksize <= 1 || cnt<=1) return;

    halfk  = (ksize+1)/2;
    halfk1 = (ksize+2)/2;

  /* First we sum the first (ksize+1)/2 pixels of array (in 32 bits) */

    count=halfk;
    if(step == 1)
        while(count--) sum += *p++;
    else
        while(count--) sum += *p, p += step;

  /* Now we calculate the propagating 32 bit sum for the first
     (ksize+2)/2 pixels.
  */

    count=halfk1;
    if(step == 1)
        while(count--) *ltemp++ = sum, sum += *p++;
    else
        while(count--) *ltemp++ = sum, sum += *p, p += step;

  /* Next process pixels that are not within (ksize + 1 or 2)/2
     of the boundaries.
  */

    size     = cnt - halfk - halfk1;
    count    = size;
    distance = (-ksize-1) * step;

    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p, p += step;

  /* process the last (ksize+1)/2 pixels */

    count=halfk;
    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, p += step;

  /* scale the long array and correct edge effects */

    ltemp = (int *) temp;
    p     = array;
    scale = halfk1;

    count = halfk1;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale++;
    else
        while(count--) *p = *ltemp++ / scale++, p += step;

    count = cnt - 2*halfk;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / ksize;
    else
        while(count--) *p = *ltemp++ / ksize, p += step;

    count = halfk1;
    scale = ksize;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale--;
    else
        while(count--) *p = *ltemp++ / scale--, p += step;
}
static void wfastmax(int *array, int *temp1, int cnt, int ksize, int bsize, int step)
{
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif

    int *p     = temp1;
    int *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;
    while(count--) *p++ = -LARGEINT;            /* left guard             */

    if(step == 1)                               /* copy of input          */
    { 
        memcpy(p, array, cnt*sizeof(int));
        p += cnt;
    }
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = -LARGEINT; /* right guard (one less) */

    size   = p - temp1;                           /* size of guarded array  */
    memcpy(temp2, temp1, size*sizeof(int));       /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */
    p      = temp1;                               /* forwards pass */

    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if(*p > val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if(*p > val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
        if(*temp1 > *temp2) *array++ = *temp1++, temp2++;
        else                *array++ = *temp2++, temp1++;
    }
    else
    { 
        while(count--)
        if(*temp1 > *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

static void wfastmin(int *array, int *temp1, int cnt, int ksize, int bsize, int step)
{ 
    int i, val, count;
#ifdef WIN64
    __int64  size, blocks;
#else
    unsigned int  size, blocks;
#endif

    int *p     = temp1;
    int *temp2 = temp1 + 2*bsize;

    if(ksize <= 1 || ksize > bsize/2) return;

    count = ksize/2;
    while(count--) *p++ = LARGEINT;              /* left guard    */

    if(step==1)                                  /* copy of input          */
    { 
        memcpy(p, array, cnt*sizeof(int));
        p += cnt;
    }
    else
        for(i=0; i<cnt; i++) *p++ = array[i*step];

    for(i=1; i<3*ksize/2; i++) *p++ = LARGEINT;   /* right guard (one less) */

    size   = p - temp1;                           /* size of guarded array */
    memcpy(temp2, temp1, size*sizeof(int));       /* duplicate guarded array */
    blocks = size / ksize;                        /* blocks to process */

    p = temp1;                                    /* forwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p++;
        count = ksize;
        while(--count) if(*p < val) val = *p++; else *p++ = val;
    }

    p = temp2 + ksize * blocks - 1;               /* backwards pass */
    for(i=0; i<blocks; i++)
    { 
        val   = *p--;
        count = ksize;
        while(--count) if(*p < val) val = *p--; else *p-- = val;
    }

    temp1 += ksize & ~1;                          /* 1/2 ksize r. from guard */
    count = cnt;
    if(step==1)
    { 
        while(count--)                             /* combine with 1/2 ksize l.*/
        if(*temp1 < *temp2) *array++ = *temp1++, temp2++;
        else                *array++ = *temp2++, temp1++;
    }
    else
    { 
        while(count--)
        if(*temp1 < *temp2) *array = *temp1++, temp2++, array+=step;
        else                *array = *temp2++, temp1++, array+=step;
    }
}

/***********************************************************************/
/* void wfastsmth(int *array, int *temp, int size, int ksize, int step)

   This subroutine performs fast a unweighted moving average filter.
   The input/output is the int array[size]. The array temp[size] is
   required for temporary data. The size is given by size. The value
   ksize gives the size of the kernel. ksize is made smaller than size/2.
   Use step != 1 to process columns of arrays.
*/

static void wfastsmth(int *array, int *temp, int cnt, int ksize, int step)
{ 
    int size, scale, halfk, halfk1;
    int sum=0;                            /* note: make sum and ltemp long */
    int *ltemp = (int *) temp;            /*       for 16 bit machines     */
    int *p = array;
    int count, distance;

    if(ksize > cnt/2) ksize = cnt/2;
    if(ksize <= 1 || cnt<=1) return;

    halfk  = (ksize+1)/2;
    halfk1 = (ksize+2)/2;

  /* First we sum the first (ksize+1)/2 pixels of array (in 32 bits) */

    count=halfk;
    if(step == 1)
        while(count--) sum += *p++;
    else
        while(count--) sum += *p, p += step;

  /* Now we calculate the propagating 32 bit sum for the first
     (ksize+2)/2 pixels.
  */

    count=halfk1;
    if(step == 1)
        while(count--) *ltemp++ = sum, sum += *p++;
    else
        while(count--) *ltemp++ = sum, sum += *p, p += step;

  /* Next process pixels that are not within (ksize + 1 or 2)/2
     of the boundaries.
  */

    size     = cnt - halfk - halfk1;
    count    = size;
    distance = (-ksize-1) * step;

    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, sum += *p, p += step;

  /* process the last (ksize+1)/2 pixels */

    count=halfk;
    if(step == 1)
        while(count--) sum -= p[distance], *ltemp++ = sum, p++;
    else
        while(count--) sum -= p[distance], *ltemp++ = sum, p += step;

  /* scale the long array and correct edge effects */

    ltemp = (int *) temp;
    p     = array;
    scale = halfk1;

    count = halfk1;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale++;
    else
        while(count--) *p = *ltemp++ / scale++, p += step;

    count = cnt - 2*halfk;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / ksize;
    else
        while(count--) *p = *ltemp++ / ksize, p += step;

    count = halfk1;
    scale = ksize;
    if(step == 1)
        while(count--) *p++ = *ltemp++ / scale--;
    else
        while(count--) *p = *ltemp++ / scale--, p += step;
}

static ErrorType RunBasicFilter(UField* F, int* Kernels, int type)
{
    if(F==NULL || F->GetError()!=U_OK || Kernels==NULL || type<0 || type>2)
    {
        CI.AddToLog("ERROR: RunBasicFilter(). Invalid argument(s). \n");
        return U_ERROR;
    }
    for(int dim=0; dim<F->Getndim(); dim++)
    { 
        if(F->GetDimensions(dim)>MAXS)
        { 
            CI.AddToLog("ERROR: RunBasicFilter().  dimension %d is larger than %d pixels (%d)\n", dim, MAXS, F->GetDimensions(dim));
            return U_ERROR;
        }
    }
    int* Temp = new int[4*MAXS];
    if(Temp==NULL)
    {
        CI.AddToLog("ERROR: RunBasicFilter(). Memory allocation. \n");
        return U_ERROR;
    }

    int cdim = F->GetDimensions(0);
    switch(F->GetDType())
    {
    case UField::U_BYTE:
        {
            unsigned char* q = F->GetBdata();
            int       kernel = Kernels[0];
            int       step   = 1; 
            int       rest   = 1;
            for(int dim=1; dim < F->Getndim(); dim++) rest *= F->GetDimensions(dim);

            for(int i=0; i<rest; i++)
            { 
                switch(type)
                { 
                case FILT_MIN:  bfastmin  (q, (unsigned char*)Temp, cdim, kernel, MAXS, step); break;
                case FILT_MAX:  bfastmax  (q, (unsigned char*)Temp, cdim, kernel, MAXS, step); break;
                case FILT_SMTH: bfastsmth (q, (unsigned char*)Temp, cdim, kernel,       step); break;
                }
                q += cdim;
            }

            for(int dim=1; dim < F->Getndim(); dim++) /* process the other dimensions */
            { 
                cdim   = F->GetDimensions(dim  );
                step  *= F->GetDimensions(dim-1);;
                rest  /= cdim;
                kernel = Kernels[dim];
        
                if(kernel<=1) continue; /* skip computations if possible */

                /* run over pages and columns */
                for(int i=0; i < rest; i++)                  /* # pages */
                { 
                    for(int j=0; j < step; j++)                  /* # columns */
                    { 
                        q     = F->GetBdata() + i*step*cdim + j;
                        switch(type)
                        { 
                        case FILT_MIN:  bfastmin  (q, (unsigned char*)Temp, cdim, kernel, MAXS, step); break;
                        case FILT_MAX:  bfastmax  (q, (unsigned char*)Temp, cdim, kernel, MAXS, step); break;
                        case FILT_SMTH: bfastsmth (q, (unsigned char*)Temp, cdim, kernel,       step); break;
                        }
                    }
                }                
            }
        }
        break;
    case UField::U_SHORT:
        {
            short* q    = F->GetSdata();
            int  kernel = Kernels[0];
            int  step   = 1; 
            int  rest   = 1;
            for(int dim=1; dim < F->Getndim(); dim++) rest *= F->GetDimensions(dim);

            for(int i=0; i<rest; i++)
            { 
                switch(type)
                { 
                case FILT_MIN:  sfastmin  (q, (short*)Temp, cdim, kernel, MAXS, step); break;
                case FILT_MAX:  sfastmax  (q, (short*)Temp, cdim, kernel, MAXS, step); break;
                case FILT_SMTH: sfastsmth (q, (short*)Temp, cdim, kernel,       step); break;
                }
                q += cdim;
            }

            for(int dim=1; dim < F->Getndim(); dim++) /* process the other dimensions */
            { 
                cdim   = F->GetDimensions(dim  );
                step  *= F->GetDimensions(dim-1);;
                rest  /= cdim;
                kernel = Kernels[dim];
        
                if(kernel<=1) continue; /* skip computations if possible */

                /* run over pages and columns */
                for(int i=0; i < rest; i++)                  /* # pages */
                { 
                    for(int j=0; j < step; j++)                  /* # columns */
                    { 
                        q     = F->GetSdata() + i*step*cdim + j;
                        switch(type)
                        { 
                        case FILT_MIN:  sfastmin  (q, (short*)Temp, cdim, kernel, MAXS, step); break;
                        case FILT_MAX:  sfastmax  (q, (short*)Temp, cdim, kernel, MAXS, step); break;
                        case FILT_SMTH: sfastsmth (q, (short*)Temp, cdim, kernel,       step); break;
                        }
                    }
                }                
            }
        }
        break;

    case UField::U_INTEGER:
        {
            int* q      = F->GetIdata();
            int  kernel = Kernels[0];
            int  step   = 1; 
            int  rest   = 1;
            for(int dim=1; dim < F->Getndim(); dim++) rest *= F->GetDimensions(dim);

            for(int i=0; i<rest; i++)
            { 
                switch(type)
                { 
                case FILT_MIN:  wfastmin  (q, Temp, cdim, kernel, MAXS, step); break;
                case FILT_MAX:  wfastmax  (q, Temp, cdim, kernel, MAXS, step); break;
                case FILT_SMTH: wfastsmth (q, Temp, cdim, kernel,       step); break;
                }
                q += cdim;
            }

            for(int dim=1; dim < F->Getndim(); dim++) /* process the other dimensions */
            { 
                cdim   = F->GetDimensions(dim  );
                step  *= F->GetDimensions(dim-1);;
                rest  /= cdim;
                kernel = Kernels[dim];
        
                if(kernel<=1) continue; /* skip computations if possible */

                /* run over pages and columns */
                for(int i=0; i < rest; i++)                  /* # pages */
                { 
                    for(int j=0; j < step; j++)                  /* # columns */
                    { 
                        q     = F->GetIdata() + i*step*cdim + j;
                        switch(type)
                        { 
                        case FILT_MIN:  wfastmin  (q, Temp, cdim, kernel, MAXS, step); break;
                        case FILT_MAX:  wfastmax  (q, Temp, cdim, kernel, MAXS, step); break;
                        case FILT_SMTH: wfastsmth (q, Temp, cdim, kernel,       step); break;
                        }
                    }
                }                
            }
        }
        break;
    default:
        delete[] Temp;
        CI.AddToLog("ERROR: RunBasicFilter(). Invalid data type: DType = %d. \n", F->GetDType());
        return U_ERROR;
    }
    delete[] Temp;

    return U_OK;
}


UField* UField::GetSpatialFilteredField(SpatFilterType SFT, int KernelSize, bool ScaleExtends) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(DType!=U_BYTE && DType!=U_SHORT && DType!=U_INTEGER)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Erroneous data type: DType = %d .\n",DType);
        return NULL;
    }
    if(FType!=U_UNIFORM)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Coordinate type is not UNIFORM. \n");
        return NULL;
    }
    if(veclen!=1)
    { 
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Invalid veclen (=%d) .\n", veclen);
        return NULL;
    }
    if(ndim<=0 || ndim>3)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Invalid ndim (=%d) .\n", ndim);
        return NULL;
    }
    if(KernelSize<=0)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Invalid KernelSize (=%d) .\n", KernelSize);
        return NULL;
    }

    double Steps[3] = {fabs(GetPixelSize(0)), fabs(GetPixelSize(1)), fabs(GetPixelSize(2))};
    double MinStep  = LARGEINT;
    for(int dim=0; dim<ndim; dim++)
        if(Steps[dim]<MinStep && Steps[dim]>SMALL) MinStep = Steps[dim];

    int Kernels[3] = {KernelSize, KernelSize, KernelSize};
    if(ScaleExtends)
    {
        for(int dim=0; dim<ndim; dim++)
        { 
            if(Steps[dim]>SMALL)
                Kernels[dim] = (int)(KernelSize * MinStep / Steps[dim] / 2.0);
            else
                Kernels[dim] = 0;

            Kernels[dim] = Kernels[dim] * 2 + 1;
            if(Kernels[dim]<1) Kernels[dim] = 1;
        }
    }


    UField* Fout = new UField(*this);
    if(Fout==NULL || Fout->GetError()!=U_OK)
    {
        delete Fout;
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Creating output UField .\n");
        return NULL;
    }

    ErrorType E = U_ERROR;
    switch(SFT)
    { 
    case U_SPATFILT_SMOOTH:                       /* smooth and unsharp mask */
    case U_SPATFILT_UNSMOOTH:
        E = RunBasicFilter(Fout, Kernels, FILT_SMTH);
        break;

    case U_SPATFILT_LOCMIN:                       /* local minimum */
    case U_SPATFILT_EDGEIN:
        E = RunBasicFilter(Fout, Kernels, FILT_MIN);
        break;

    case U_SPATFILT_LOCMAX:                       /* local maximum */
    case U_SPATFILT_EDGEOUT:
        E = RunBasicFilter(Fout, Kernels, FILT_MAX);
        break;

    case U_SPATFILT_OPEN:                         /* morphologic opening and tophat */
    case U_SPATFILT_TOPHAT:
        E             = RunBasicFilter(Fout, Kernels, FILT_MIN);
        if(E==U_OK) E = RunBasicFilter(Fout, Kernels, FILT_MAX);
        break;

    case U_SPATFILT_CLOSE:                        /* closing and reverse tophat */
    case U_SPATFILT_REVTOPHAT:
        E             = RunBasicFilter(Fout, Kernels, FILT_MAX);
        if(E==U_OK) E = RunBasicFilter(Fout, Kernels, FILT_MIN);
        break;

    default:
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Invalid Filter type: SFT=%d .\n", SFT);
        delete Fout;
        return NULL;
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetSpatialFilteredField(). Applying basic filter .\n", SFT);
        delete Fout;
        return NULL;
    }

    if(SFT==U_SPATFILT_UNSMOOTH    || 
       SFT==U_SPATFILT_TOPHAT      || 
       SFT==U_SPATFILT_EDGEIN)
    { 
        *Fout  = *this - *Fout;
    }
    else if(SFT==U_SPATFILT_EDGEOUT)
    {
        *Fout  = *Fout - *this;
    }
    else if(SFT==U_SPATFILT_REVTOPHAT)
    {
        *Fout -= *this;  // Mind U_BYTE....
    }
    return Fout;
}
