/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    04-06-05   creation, Qt independent part of UQFieldGraph
  JdM    05-09-05   Added new constructor, based on UField argugument.
  JdM    08-09-05   Added default constructor
  JdM    05-01-06   Added CompDatType member, added component argument to GetXYarray()
  JdM    03-02-06   bug fix: SaveGraphs(). Saving header in .txt format
  JdM    17-02-06   SaveGraphs(). .txt format, export standard deviations
  JdM    20-04-06   Use static UString for properties, added SetAllMembersDefault() and DeleteAllMembers()
                    Added operator=() and filename constructor
  JdM    28-04-06   Added constructor
  JdM    21-05-06   Added two parameters to GetXYarray()
  JdM    21-06-06   Bug fix: GetProperties(). print Xmin i.s.o. Xmax
  JdM    04-08-06   Added OutsideScan and set Point = OutsideScan in SetAllMembersDefault()
  JdM    22-08-06   Added WriteAsText()
  JdM    25-08-06   Added WriteXDR()
                    Bug Fix: SaveGraphs(). Skip NULL pointers.
  JdM    26-11-06   Added new constructor
  JdM    27-11-06   Added GetComponent()
  JdM    28-11-06   bug fix: operator=(). Copy DatTypeHor.
  SG     23-05-07   Added DetectOutLiers()
  SG/JdM 23-05-07   Named DetectOutLiers() as DetectOutLiersAbsMinMed()
  JdM    15-08-07   Added virtual SetVeclen()
  JdM    05-04-07   Added GetDataWeigtedX()
  JdM    29-05-07   Added another (reference &) UField constructor and a UFileName constructor
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    21-10-08   Added UpdateMinMax() and GetInterpolationFFT()
  JdM    22-10-08   Added GetPointsInRange() and GetInterpolationLin()
  JdM    02-12-08   Added ConvolveStandardHRF(), InterpolateFFT() and InterpolateLin()
                    Bug Fix: GetInterpolationFFT() and GetInterpolationLin(). Swap use of this and Grid in call to GetPointsInRange()
  JdM    05-12-08   Added GetAaverage().
  JdM    02-09-09   Added GetInterpolationCon() and InterpolateCon()
                    InterpolateLin(). Remove (obsolete?) U_UNIFORM test
  JdM    03-09-09   Added GetLevelRange()
  JdM    13-10-09   Added SetStandardHRF() and GetStandardHRF()
  JdM    09-12-09   Bug Fix: GetAaverage(). Computing standard deviation (e.g. omitting sqrt())
  JdM    28-10-10   Added GetInterpolationLin()
  JdM    13-05-11   Replaced AUTODEBUG.AddClassFunction() by UDebug::ReplaceClassFunction()
  JdM    15-12-11   Added GetPWidthFullMaximum()
  JdM    12-01-12   Added GetWidthFullMaximumAbs()
  JdM    12-08-15   WriteAsText(). Use Label in collumn caption
*/

#include <string.h>

#include "Debug.h"
#include "FieldGraph.h"
#include "Interpolate.h"
#include "Convolve.h"

      UString  UFieldGraph::Properties  = UString();
const UString  UFieldGraph::DefaultName = UString("No Name");
const UVector3 UFieldGraph::OutsideScan = UVector3(10000., 10000., 10000.);

const  double  UFieldGraph::HRF_d1      =   1.26;
const  double  UFieldGraph::HRF_b1      =   4.20;
const  double  UFieldGraph::HRF_c       =   1.70;
const  double  UFieldGraph::HRF_d2      =   2.82;
const  double  UFieldGraph::HRF_b2      =   2.56;


void UFieldGraph::SetAllMembersDefault(void)
{
    error         = U_OK;
    Properties    = UString();
    Label         = DefaultName;

    Xmin          = 0.;
    Xmax          = 1.;
    Ymin          = 0.;
    Ymax          = 1.;
    Yoffset       = 0.;
    Radius        = 0.;
    DatTypeHor    = U_GDAT_UNKNOWN;
    Components    = U_COMPDAT_UNKNOWN;
    Point         = OutsideScan;
}
void UFieldGraph::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault(); // Nothing to delete
    error = E;
}

UFieldGraph::UFieldGraph() : UField()
{
    SetAllMembersDefault();
}

UFieldGraph::UFieldGraph(UFileName FileName) : UField()///: UField((const char*)FileName)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();
    *this = UFieldGraph((const char*)FileName);
}

UFieldGraph::UFieldGraph(const char* FileName) : UField(FileName)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();

    if(UField::GetError()!=U_OK || UFieldGraph::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UQFieldGraph::UFieldGraph(). Setting base class. \n");
        return;
    }

/* Test arguments*/
    if( UField::Getndim()!=1 ||
       (UField::GetFType()!=UField::U_UNIFORM && UField::GetFType()!=UField::U_RECTILINEAR) )
    {
        CI.AddToLog("ERROR: UFieldGraph::UQFieldGraph(). UField argument of wrong coordinate type: %s.\n", (const char*)UField::GetProperties(""));
        return;
    }

    UString Prop(UField::GetFileComments());
    Label         = Prop.GetIdentifierIsString("Name", DefaultName, false, NULL, false);
    Radius        = Prop.GetIdentifierIsDouble("Radius", 0., false, NULL);
    Point         = Prop.GetIdentifierIsVector3("Point", UVector3(), false, NULL);

    UString SDT   = Prop.GetIdentifierIsString("HorAxis"   ,   UString(), false, NULL, false);
    UString SCO   = Prop.GetIdentifierIsString("Components",   UString(), false, NULL, false);

    DatTypeHor    = GetGraphDatType(SDT);
    Components    = GetCompDatType(SCO);

    UFileName F(FileName);
    if(F.HasExtension("xdr"))
    {
        UFileName Base = F.GetBaseName();
        Base.ReplaceExtension(NULL);
        Label = UString((const char*)Base);
    }
}

UFieldGraph::UFieldGraph(const UField *F, const UString& Lab, UVector3 P, double Rad, GraphDatType DTypeHor, CompDatType Comp) :
    UField(*F)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();

/* Test arguments*/
    if(F==NULL || F->GetError()!=U_OK)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Erroneous UField argument. \n");
        return;
    }
    if(UField::GetError()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Setting UField base class. \n");
        return;
    }

    if( F->Getndim()!=1 ||
       (F->GetFType()!=UField::U_UNIFORM && F->GetFType()!=UField::U_RECTILINEAR) )
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). UField argument of wrong coordinate type: %s.\n", (const char*)F->GetProperties(""));
        return;
    }

/* Compute minimum and maximum*/
    if(UpdateMinMax()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Updating data range.\n");
        return;
    }
    Yoffset       = UField::GetAverageData();
    Point         = P;
    Radius        = Rad;
    if(&Lab==NULL || Lab.IsEmpty()) Label = UString(P.GetProperties());
    else                            Label = Lab;
    DatTypeHor    = DTypeHor;
    Components    = Comp;
    if(Components==U_COMPDAT_AVERSTAN && veclen!=2)
        CI.AddToLog("WARNING: UFieldGraph::UFieldGraph(). Components==U_COMPDAT_AVERSTAN, veclen =%d, Lab=%s   .\n", veclen, (const char*)Label);
    if(Components==U_COMPDAT_CORPFDR && veclen!=3)
        CI.AddToLog("WARNING: UFieldGraph::UFieldGraph(). Components==U_COMPDAT_CORPFDR, veclen =%d, Lab=%s   .\n", veclen, (const char*)Label);
}

UFieldGraph::UFieldGraph(const UFieldGraph& FG) : UField((UField)FG)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();
    *this = FG;
}

UFieldGraph::UFieldGraph(const UField& F) :   UField(F)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();
    *this = UFieldGraph(&F);
}

UFieldGraph::UFieldGraph(const UField *F) :   UField(*F)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();

/* Test arguments*/
    if(F==NULL || F->GetError()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Erroneous UField argument. \n");
        return;
    }
    if(UField::GetError()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Setting UField base class. \n");
        return;
    }

    if( UField::Getndim()!=1 ||
       (UField::GetFType()!=UField::U_UNIFORM && UField::GetFType()!=UField::U_RECTILINEAR) )
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). UField argument of wrong coordinate type: %s.\n", (const char*)UField::GetProperties(""));
        return;
    }

/* Compute minimum and maximum*/
    if(UpdateMinMax()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Updating data range.\n");
        return;
    }
}

UFieldGraph::UFieldGraph(float    Min, float    Max, int dims, DataType DT, int vecl) :
    UField(Min, Max, dims, DT, vecl)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();

/* Test arguments*/
    if(UField::GetError()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Setting UField base class. \n");
        return;
    }

    if( UField::Getndim()!=1 ||
       (UField::GetFType()!=UField::U_UNIFORM && UField::GetFType()!=UField::U_RECTILINEAR) )
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). UField argument of wrong coordinate type: %s.\n", (const char*)UField::GetProperties(""));
        return;
    }

    if(UpdateMinMax()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Updating data range.\n");
        return;
    }
}
UFieldGraph::UFieldGraph(const float* points, const int dims, DataType DT, int vecl):
    UField(points, NULL, NULL, &dims, DT, vecl)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UFieldGraph()");
    SetAllMembersDefault();

/* Test arguments*/
    if(UField::GetError()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Setting UField base class. \n");
        return;
    }

    if( UField::Getndim()!=1 ||
       (UField::GetFType()!=UField::U_UNIFORM && UField::GetFType()!=UField::U_RECTILINEAR) )
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). UField argument of wrong coordinate type: %s.\n", (const char*)UField::GetProperties(""));
        return;
    }

/* Compute minimum and maximum*/
    if(UpdateMinMax()!=U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::UFieldGraph(). Updating data range.\n");
        return;
    }
}

UFieldGraph::~UFieldGraph()
{
    DeleteAllMembers(U_OK);
}

UFieldGraph& UFieldGraph::operator=(const UFieldGraph& FG)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "operator=()");
    if(this==NULL)
    {
        static UFieldGraph F; F.error=U_ERROR;
        CI.AddToLog("ERROR: UFieldGraph::operator=(). this = NULL\n");
        return F;
    }
    if(&FG==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&FG) return *this;

    UField::operator=(FG);
    if(UField::GetError() != U_OK)
    {
        UField::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFieldGraph::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    Label         = FG.Label;
    Xmin          = FG.Xmin;
    Xmax          = FG.Xmax;
    Ymin          = FG.Ymin;
    Ymax          = FG.Ymax;
    Yoffset       = FG.Yoffset;
    Point         = FG.Point;
    Radius        = FG.Radius;
    DatTypeHor    = FG.DatTypeHor;
    Components    = FG.Components;

    return *this;
}

double UFieldGraph::GetPWidthFullMaximum(double P, int icomp, double* DatMaxFabs) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetPWidthFullMaximum()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPWidthFullMaximum(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(P<0 || P>1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPWidthFullMaximum(). P-parameter out of range (P=%f).\n", P);
        return 0.;
    }
    if(icomp<0 || icomp>=veclen)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPWidthFullMaximum(). icomp (=%d) out of range. \n", icomp);
        return 0.;
    }
    int    ipmax   = -1;
    double MaxIp   =  0.;
    int    NPoints = GetNpoints();
    for(int ip=0; ip<NPoints; ip++)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>MaxIp) 
        {
            MaxIp = DD;
            ipmax = ip;
        }
    }
    if(ipmax<0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPWidthFullMaximum(). Maximum not found.\n");
        return 0.;
    }

    if(DatMaxFabs) *DatMaxFabs = MaxIp;
    int ip1 = ipmax;
    for(int ip=0; ip<ipmax; ip++)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>=P*MaxIp) 
        {
            ip1 = ip;
            break;
        }
    }
    int ip2 = ipmax;
    for(int ip=NPoints-1; ip>ipmax; ip--)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>=P*MaxIp) 
        {
            ip2 = ip;
            break;
        }
    }
    return fabs( GetPoint1(ip1) - GetPoint1(ip2) );
}
double UFieldGraph::GetWidthFullMaximumAbs(double DataLevel, int icomp, double* DatMaxFabs) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetWidthFullMaximumAbs()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetWidthFullMaximumAbs(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(DataLevel<0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetWidthFullMaximumAbs(). parameter out of range (DataLevel=%f).\n", DataLevel);
        return 0.;
    }
    if(icomp<0 || icomp>=veclen)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetWidthFullMaximumAbs(). icomp (=%d) out of range. \n", icomp);
        return 0.;
    }
    int    ipmax   = -1;
    double MaxIp   =  0.;
    int    NPoints = GetNpoints();
    for(int ip=0; ip<NPoints; ip++)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>MaxIp) 
        {
            MaxIp = DD;
            ipmax = ip;
        }
    }
    if(ipmax<0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetWidthFullMaximumAbs(). Maximum not found.\n");
        return 0.;
    }

    if(DatMaxFabs) *DatMaxFabs = MaxIp;
    int ip1 = ipmax;
    for(int ip=0; ip<ipmax; ip++)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>=DataLevel) 
        {
            ip1 = ip;
            break;
        }
    }
    int ip2 = ipmax;
    for(int ip=NPoints-1; ip>ipmax; ip--)
    {
        double DD  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) DD= abs(Bdata[ip*veclen+icomp]); break;
        case U_SHORT:    if(Sdata) DD= abs(Sdata[ip*veclen+icomp]); break;
        case U_INTEGER:  if(Idata) DD= abs(Idata[ip*veclen+icomp]); break;
        case U_FLOAT:    if(Fdata) DD=fabs(Fdata[ip*veclen+icomp]); break;
        case U_DOUBLE:   if(Ddata) DD=fabs(Ddata[ip*veclen+icomp]); break;
        }
        if(DD>=DataLevel) 
        {
            ip2 = ip;
            break;
        }
    }
    return fabs( GetPoint1(ip1) - GetPoint1(ip2) );
}

double UFieldGraph::GetDataWeigtedX(int icomp) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetDataWeigtedX()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetDataWeigtedX(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(icomp<0 || icomp>=veclen)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetDataWeigtedX(). icomp (=%d) out of range. \n", icomp);
        return 0.;
    }
    double SumWX   = 0;
    double SumW    = 0;
    int    NPoints = GetNpoints();
    for(int ip=0; ip<NPoints; ip++)
    {
        double W  = 0;
        switch(DType)
        {
        case U_BYTE:     if(Bdata) W=Bdata[ip*veclen+icomp]; break;
        case U_SHORT:    if(Sdata) W=Sdata[ip*veclen+icomp]; break;
        case U_INTEGER:  if(Idata) W=Idata[ip*veclen+icomp]; break;
        case U_FLOAT:    if(Fdata) W=Fdata[ip*veclen+icomp]; break;
        case U_DOUBLE:   if(Ddata) W=Ddata[ip*veclen+icomp]; break;
        }
        W      = fabs(W);
        SumWX += W*GetPoint1(ip);
        SumW  += W;
    }
    if(SumW>0) return SumWX/SumW;
    return 0;
}

ErrorType UFieldGraph::SetVeclen(int NewVeclen)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "SetVeclen()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::SetVeclen(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(UField::SetVeclen(NewVeclen)!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::SetVeclen(). Calling base class function. \n");
        return U_ERROR;
    }
    Components = U_COMPDAT_UNKNOWN;
    return U_OK;
}

UFieldGraph* UFieldGraph::GetComponent(int icomp) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetComponent()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetComponent(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(icomp<0 || icomp>=veclen)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetComponent(). Component out of range: icomp = %d. \n", icomp);
        return NULL;
    }
    UField* Cmp = UField::GetComponent(icomp);
    if(Cmp==NULL || Cmp->GetError()!=NULL)
    {
        delete Cmp;
        CI.AddToLog("ERROR: UFieldGraph::GetComponent(). Getting component from base class. \n");
        return NULL;
    }

    UString CompLab = UString(icomp,"Comp%d_") + Label;
    UFieldGraph* FGcomp = new UFieldGraph(Cmp, CompLab, Point, Radius, DatTypeHor, U_COMPDAT_UNKNOWN);
    delete Cmp;
    if(FGcomp==NULL || FGcomp->GetError()!=NULL)
    {
        delete FGcomp;
        CI.AddToLog("ERROR: UFieldGraph::GetComponent(). Creating UFieldGraph* from extracted component. \n");
        return NULL;
    }
    return FGcomp;
}
ErrorType UFieldGraph::GetLevelRange(int Level, int iLevel, double* StartCoord, double* EndCoord) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetLevelRange()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(ndim!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). UFieldGraph not 1D (%s). \n", UField::GetProperties(""));
        return U_ERROR;
    }
    if(veclen!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). Veclen must be 1. \n", UField::GetProperties(""));
        return U_ERROR;
    }
    double Dx = GetPixelSize(0);
    if(Dx<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). Negative pixel size (Dx=%f). \n", Dx);
        return U_ERROR;
    }
    if(iLevel<0 || StartCoord==NULL || EndCoord==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). Invalid or NULL argument (iLevel=%d). \n", iLevel);
        return U_ERROR;
    }
    UField F(*(const UField*)this);
    if(F.GetError()!=U_OK || F.ConvertData(UField::U_INTEGER)!=U_OK || F.GetIdata()==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetLevelRange(). Converting data to int.\n");
        return U_ERROR;
    }
    *StartCoord =  0.;
    *EndCoord   = -1.;

    int    ip   = 0;
    int    Np   = GetNpoints();
    double Beg  = F.GetPoint1(0);
    bool   Up   = (F.GetIdata()[0]==Level);
    int    NLev = 0;
    while(ip<Np-1)
    {
        if(Up && F.GetIdata()[ip+1]!=Level)
        {
            if(NLev==iLevel)
            {
                *StartCoord =  Beg;
                *EndCoord   =  F.GetPoint1(ip+1);
                return U_OK;
            }
            NLev++;
            Up = false;
        }
        if(NOT(Up) && F.GetIdata()[ip+1]==Level)
        {
            Beg = F.GetPoint1(ip+1);
            Up  = true;
        }
        ip++;
    }
    if(Up && NLev==iLevel)
    {
        *StartCoord =  Beg;
        *EndCoord   =  F.GetPoint1(ip);
        return U_OK;
    }
    *StartCoord =  0.;
    *EndCoord   = -1.;
    return U_OK;
}

ErrorType UFieldGraph::GetPointsInRange(const UFieldGraph* Grid, int* NFirstOutRange, int*NInRange) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetPointsInRange()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPointsInRange(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(ndim!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPointsInRange(). UFieldGraph not 1D (%s). \n", UField::GetProperties(""));
        return U_ERROR;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK||Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPointsInRange(). Grid argument==NULL, erroneous or non-uniform. \n");
        return U_ERROR;
    }
    if(NFirstOutRange==NULL || NInRange==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetPointsInRange(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }

    double XoutMin = Grid->GetMinx1();
    double XoutMax = Grid->GetMaxx1();
    int    NSkipIn = 0;
    int    NSampIn = 0;
    if(points[0]<points[1])
    {
        for(int k=0; k<dimensions[0]; k++)
        {
            double X = GetCoord(0, k);
            if(X<XoutMin)       {NSkipIn++; continue;}
            else if(X<=XoutMax) {NSampIn++;}
            else                {break;}
        }
    }
    else
    {
        for(int k=0; k<dimensions[0]; k++)
        {
            double X = GetCoord(0, k);
            if(X>XoutMax)       {continue;}
            else if(X>=XoutMin) {NSampIn++;}
            else                {NSkipIn++;}
        }
    }
    if(NFirstOutRange) *NFirstOutRange = NSkipIn;
    if(NInRange      ) *NInRange       = NSampIn;

    return U_OK;
}

UFieldGraph* UFieldGraph::GetInterpolationCon(const UFieldGraph* Grid) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetInterpolationCon()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). NULL or erroneous object. \n");
        return NULL;
    }
    if(ndim>1 || veclen!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return NULL;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK||Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). Grid argument==NULL, erroneous or non-uniform. \n");
        return NULL;
    }

/* Determine points to skip */
    int    NSkipOut = 0;
    int    NSampOut = 0;
    if(Grid->GetPointsInRange(this, &NSkipOut, &NSampOut)!=U_OK || NSampOut<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). No overlap between Grid and selected points from *this . \n");
        return NULL;
    }

/* Copy *this and interpolate  */
    UFieldGraph* FGout = new UFieldGraph(*Grid);
    if(FGout==NULL||FGout->GetError()!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). Creating output UFieldGraph. \n");
        return NULL;
    }
    if(FGout->ConvertData(DType)!=U_OK || FGout->SetDataDouble(0)!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationCon(). Converting data to input type. \n");
        return NULL;
    }

    for(int j=NSkipOut; j<NSkipOut+NSampOut; j++)
    {
        double Xout = FGout->GetCoord(0, j);
        for(int jj=0; jj<dimensions[0]; jj++)
        {
            if(jj==dimensions[0]-1)
            {
                double Xin0 = GetCoord(0, jj  );
                if(Xin0==Xout)
                {
                    switch(DType)
                    {
                    case U_BYTE   : FGout->GetBdata()[j] = Bdata[jj  ]; break;
                    case U_SHORT  : FGout->GetSdata()[j] = Sdata[jj  ]; break;
                    case U_INTEGER: FGout->GetIdata()[j] = Idata[jj  ]; break;
                    case U_FLOAT:   FGout->GetFdata()[j] = Fdata[jj  ]; break;
                    case U_DOUBLE:  FGout->GetDdata()[j] = Ddata[jj  ]; break;
                    }
                }
                continue;
            }
            double Xin0 = GetCoord(0, jj  );
            double Xin1 = GetCoord(0, jj+1);
            if( (Xin0<=Xout && Xout<=Xin1) ||
                (Xin0>=Xout && Xout>=Xin1))
            {
                int jtake = jj;
                if(fabs(Xin1-Xout)<fabs(Xout-Xin0)) jtake = jj+1;

                switch(DType)
                {
                case U_BYTE   : FGout->GetBdata()[j] = Bdata[jtake]; break;
                case U_SHORT  : FGout->GetSdata()[j] = Sdata[jtake]; break;
                case U_INTEGER: FGout->GetIdata()[j] = Idata[jtake]; break;
                case U_FLOAT:   FGout->GetFdata()[j] = Fdata[jtake]; break;
                case U_DOUBLE:  FGout->GetDdata()[j] = Ddata[jtake]; break;
                }
                break;
            }
        }
    }
    return FGout;
}
UFieldGraph* UFieldGraph::GetInterpolationLin(const UFieldGraph* Grid) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetInterpolationLin()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). NULL or erroneous object. \n");
        return NULL;
    }
    if(ndim>1 || veclen!=1 || DType!=U_DOUBLE)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return NULL;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK||Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). Grid argument==NULL, erroneous or non-uniform. \n");
        return NULL;
    }

/* Determine points to skip */
    int    NSkipOut = 0;
    int    NSampOut = 0;
    if(Grid->GetPointsInRange(this, &NSkipOut, &NSampOut)!=U_OK || NSampOut<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). No overlap between Grid and selected points from *this . \n");
        return NULL;
    }

/* Copy *this and interpolate  */
    UFieldGraph* FGout = new UFieldGraph(*Grid);
    if(FGout==NULL||FGout->GetError()!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). Creating output UFieldGraph. \n");
        return NULL;
    }
    if(FGout->ConvertData(U_DOUBLE)!=U_OK || FGout->SetDataDouble(0.)!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). Converting data to double. \n");
        return NULL;
    }

    for(int j=NSkipOut; j<NSkipOut+NSampOut; j++)
    {
        double Xout = FGout->GetCoord(0, j);
        for(int jj=0; jj<dimensions[0]; jj++)
        {
            if(jj==dimensions[0]-1)
            {
                double Xin0 = GetCoord(0, jj  );
                if(Xin0==Xout) FGout->GetDdata()[j] = Ddata[jj  ];
                continue;
            }
            double Xin0 = GetCoord(0, jj  );
            double Xin1 = GetCoord(0, jj+1);
            if( (Xin0<=Xout && Xout<=Xin1) ||
                (Xin0>=Xout && Xout>=Xin1))
            {
                double D0 = Ddata[jj  ];
                double D1 = Ddata[jj+1];

                FGout->GetDdata()[j] = ((Xin0-Xout)*D1 + (Xout-Xin1)*D0) / (Xin0-Xin1);
                break;
            }
        }
    }
    return FGout;
}
double UFieldGraph::GetInterpolationLin(double Xval) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetInterpolationLin()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). NULL or erroneous object. \n");
        return NULL;
    }
    if(ndim>1 || veclen!=1 || DType!=U_DOUBLE)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationLin(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return NULL;
    }

    if(Xval<=GetMinx1()) Xval = GetMinx1();
    if(Xval>=GetMaxx1()) Xval = GetMaxx1();

/* Interpolate  */
    for(int jj=0; jj<dimensions[0]-1; jj++)
    {
        double Xin0 = GetCoord(0, jj  );
        double Xin1 = GetCoord(0, jj+1);
        if( (Xin0<=Xval && Xval<=Xin1) ||
            (Xin0>=Xval && Xval>=Xin1))
        {
            double D0 = Ddata[jj  ];
            double D1 = Ddata[jj+1];

            return ((Xin0-Xval)*D1 + (Xval-Xin1)*D0) / (Xin0-Xin1);
        }
    }
    return  Ddata[dimensions[0]-1];
}
UFieldGraph* UFieldGraph::GetInterpolationFFT(const UFieldGraph* Grid) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetInterpolationFFT()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). NULL or erroneous object. \n");
        return NULL;
    }
    if(ndim>1 || veclen!=1 || FType!=U_UNIFORM || DType!=U_DOUBLE)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return NULL;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK||Grid->GetFType()!=U_UNIFORM || Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). Grid argument==NULL, erroneous or non-uniform. \n");
        return NULL;
    }

/* Determine points to skip */
    int    NSkipIn = 0;
    int    NSampIn = 0;
    if(this->GetPointsInRange(Grid, &NSkipIn, &NSampIn)!=U_OK || NSampIn<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). No overlap between Grid and selected points from *this . \n");
        return NULL;
    }
    int    NSkipOut = 0;
    int    NSampOut = 0;
    if(Grid->GetPointsInRange(this, &NSkipOut, &NSampOut)!=U_OK || NSampOut<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). No overlap between Grid and selected points from *this . \n");
        return NULL;
    }

/* Copy *this and interpolate  */
    UFieldGraph* FGout = new UFieldGraph(*Grid);
    if(FGout==NULL||FGout->GetError()!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). Creating output UFieldGraph. \n");
        return NULL;
    }
    if(FGout->ConvertData(U_DOUBLE)!=U_OK || FGout->SetDataDouble(0.)!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). Converting data to double. \n");
        return NULL;
    }

    UInterpolate Inter(NSampIn, NSampOut, U_INTERPOL_FFT);
    if(Inter.Resample(GetDdata()+NSkipIn, FGout->GetDdata()+NSkipOut)!=U_OK)
    {
        delete FGout;
        CI.AddToLog("ERROR: UFieldGraph::GetInterpolationFFT(). Interpolating data. \n");
        return NULL;
    }
    return FGout;
}
ErrorType UFieldGraph::InterpolateCon(const UFieldGraph* Grid)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "InterpolateCon()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateCon(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(ndim>1 || veclen!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateCon(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return U_ERROR;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK || Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateCon(). Grid argument==NULL, erroneous or non-uniform. \n");
        return U_ERROR;
    }
    UFieldGraph* FG = GetInterpolationCon(Grid);
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        delete FG;
        CI.AddToLog("ERROR: UFieldGraph::InterpolateCon(). Getting interploated graph. \n");
        return U_ERROR;
    }
    *this = *FG;
    delete FG;
    return error;
}
ErrorType UFieldGraph::InterpolateLin(const UFieldGraph* Grid)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "InterpolateLin()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateLin(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(ndim>1 || veclen!=1 || DType!=U_DOUBLE)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateLin(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return U_ERROR;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK || Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateLin(). Grid argument==NULL, erroneous or non-uniform. \n");
        return U_ERROR;
    }
    UFieldGraph* FG = GetInterpolationLin(Grid);
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        delete FG;
        CI.AddToLog("ERROR: UFieldGraph::InterpolateLin(). Getting interploated graph. \n");
        return U_ERROR;
    }
    *this = *FG;
    delete FG;
    return error;
}
ErrorType UFieldGraph::InterpolateFFT(const UFieldGraph* Grid)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "InterpolateFFT()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateFFT(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(ndim>1 || veclen!=1 || FType!=U_UNIFORM || DType!=U_DOUBLE)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateFFT(). UFieldGraph is not uni-dimensional, veclen!1, or data not uniform or not double (%s). \n", UField::GetProperties(""));
        return U_ERROR;
    }
    if(Grid==NULL||Grid->GetError()!=U_OK||Grid->GetFType()!=U_UNIFORM || Grid->Getndim()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::InterpolateFFT(). Grid argument==NULL, erroneous or non-uniform. \n");
        return U_ERROR;
    }
    UFieldGraph* FG = GetInterpolationFFT(Grid);
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        delete FG;
        CI.AddToLog("ERROR: UFieldGraph::InterpolateFFT(). Getting interploated graph. \n");
        return U_ERROR;
    }
    *this = *FG;
    delete FG;
    return error;
}


UFieldGraph* UFieldGraph::DetectOutLiersAbsMinMed(double MinMedThresh) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "DetectOutLiersAbsMinMed()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::DetectOutLiersAbsMinMed(). NULL or erroneous object. \n");
        return NULL;
    }
    if(ndim>1 || veclen>1)
    {
        CI.AddToLog("ERROR: DetectOutLiersAbsMinMed(). UFieldGraph is NULL, erroneous, not unidimensional or veclen>1. \n");
        return NULL;
    }


    UFieldGraph* OutliersFG = NULL;

    if(MinMedThresh<=0)
    {
        CI.AddToLog("ERROR: DetectOutLiersAbsMinMed(). Negative or null input argument (%f).\n", MinMedThresh);
        return OutliersFG;
    }

    int NTime = GetNpoints();

    UField   FAbs(0, 1, NTime, U_DOUBLE, 1);

    OutliersFG = new UFieldGraph(*this);

    if(OutliersFG==NULL ||OutliersFG->GetError()!=U_OK || OutliersFG->ConvertData(UField::U_DOUBLE)!=U_OK)
    {
        delete OutliersFG;
        CI.AddToLog("ERROR: DetectOutLiersAbsMinMed(). Creating output UFieldGraph() object, or converting it to U_DOUBLE. \n");
        return NULL;
    }
    OutliersFG->SetLabel(UString("Outliers_")+Label);
    OutliersFG->SetPoint(OutsideScan);
    OutliersFG->SetRadius(0.);

    OutliersFG->AbsValue();

    double Median  = OutliersFG->GetMedian_d();
    double Min     = 0.;
    double Max     = 0.;
    OutliersFG->GetMinMaxData(&Min, &Max);

    for(int i=0; i<NTime; i++)
    {
        if(fabs(OutliersFG->GetDdata()[i]-Median)>=MinMedThresh*(Median-Min))
            OutliersFG->GetDdata()[i]=1;
        else
            OutliersFG->GetDdata()[i]=0;
    }
    return OutliersFG;
}

ErrorType UFieldGraph::ShiftCoords(double Shift)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "ShiftCoords()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::ShiftCoords(). NULL or erroneous object. \n");
        return U_ERROR;
    }

    if(UField::ShiftCoords(Shift)!=U_OK) return U_ERROR;
    Xmin += Shift;
    Xmax += Shift;
    return U_OK;
}

void UFieldGraph::GetMinMax(double* XMI, double* XMA, double* YMI, double* YMA, bool RemoveOffset) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetMinMax()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetMinMax(). NULL or erroneous object. \n");
        return;
    }
    if(XMI) *XMI = Xmin;
    if(XMA) *XMA = Xmax;
    if(YMI)
    {
        *YMI = Ymin;
        if(RemoveOffset==true) *YMI -= Yoffset;
    }
    if(YMA)
    {
        *YMA = Ymax;
        if(RemoveOffset==true) *YMA -= Yoffset;
    }
}

ErrorType UFieldGraph::UpdateMinMax(void)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "UpdateMinMax()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::UpdateMinMax(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    Xmin = UField::GetMinx1();
    Xmax = UField::GetMaxx1();
    if(UField::GetDType()==UField::U_BYTE    ||
       UField::GetDType()==UField::U_SHORT   ||
       UField::GetDType()==UField::U_INTEGER)
    {
        int iminy = 0;
        int imaxy = 1;
        UField::GetMinMaxData(&iminy, &imaxy, -1);
        Ymin = iminy;
        Ymax = imaxy;
    }
    else if(UField::GetDType()==UField::U_FLOAT ||
            UField::GetDType()==UField::U_DOUBLE)
    {
        UField::GetMinMaxData(&Ymin, &Ymax, -1);
    }
    else
    {
        CI.AddToLog("ERROR: UFieldGraph::UpdateMinMax(). Invalid data type (%d). \n", UField::GetDType());
        return U_ERROR;
    }
    return U_OK;
}


double* UFieldGraph::GetXYarray(bool IgnoreTimeScale, int icomp, int* NPSelected, const UField* Selector) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetXYarray()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::GetXYarray(). NULL or erroneous object. \n");
        return NULL;
    }

    if(icomp<0 || icomp>=veclen)
    {
        if(NPSelected) *NPSelected = 0;
        CI.AddToLog("ERROR: UFieldGraph::GetXYarray(). Component parameter out of range: icomp=%d, veclen=%d .\n", icomp, veclen);
        return NULL;
    }
    if(Selector)
    {
        UFieldGraph Copy(*this);
        if(Copy.GetError()!=U_OK)
        {
            if(NPSelected) *NPSelected = 0;
            CI.AddToLog("ERROR: UFieldGraph::GetXYarray(). Copying *this .\n");
            return NULL;
        }
        if(Copy.SkipSamples(Selector, NPSelected)!=U_OK)
        {
            if(NPSelected) *NPSelected = 0;
            CI.AddToLog("ERROR: UFieldGraph::GetXYarray(). Selecting points. \n");
            return NULL;
        }
        return Copy.GetXYarray(IgnoreTimeScale, icomp);
    }
    int     NP  = UField::GetNpoints();
    double* XY  = new double[2*NP];
    if(XY==NULL)
    {
        if(NPSelected) *NPSelected = 0;
        CI.AddToLog("ERROR: UFieldGraph::GetXYarray(). Memory allocation: NP=%d .\n", NP);
        return NULL;
    }

    UField::GetNextPoint1(true);
    for(int n=0; n<NP; n++)
    {
        double x = UField::GetNextPoint1(false);
        double y = 0.;

        double h = .5;
        switch(UField::GetDType())
        {
        case UField::U_BYTE:    y = UField::GetBdata()[n*veclen+icomp];         break;
        case UField::U_SHORT:   y = UField::GetSdata()[n*veclen+icomp];         break;
        case UField::U_INTEGER: y = UField::GetIdata()[n*veclen+icomp];         break;
        case UField::U_FLOAT:   y = UField::GetFdata()[n*veclen+icomp]; h = 0.; break;
        case UField::U_DOUBLE:  y = UField::GetDdata()[n*veclen+icomp]; h = 0.; break;
        }
        if(IgnoreTimeScale==true) XY[2*n  ] = n;
        else                      XY[2*n  ] = h + x;
        XY[2*n+1] = h + y;
    }
    if(NPSelected) *NPSelected = NP;
    return XY;
}

const UString& UFieldGraph::GetProperties(UString Comment) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "GetProperties()");
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UFieldGraph-object\n");
        return Properties;
    }
    Properties  = UString();

    Properties += UString(" Name       = ") + Label + UString(" \n");
    Properties += UString(Point.GetProperties()          , " Point      = %s \n");
    Properties += UString(GetGraphDatTypeText(DatTypeHor), " HorAxis    = %s \n");
    Properties += UString(GetCompDatTypeText(Components) , " Components = %s \n");

    Properties += UString(Xmin   , " Xmin       = %g \n");
    Properties += UString(Xmax   , " Xmax       = %g \n");
    Properties += UString(Ymin   , " Ymin       = %g \n");
    Properties += UString(Ymax   , " Ymax       = %g \n");
    Properties += UString(Yoffset, " Yoffset    = %g \n");
    Properties += UString(Radius , " Radius     = %f \n");

    Properties += UString("\n\n");
    Properties += UString(" BaseClass: \n");
    Properties += UField::GetProperties("  ");
    Properties += UField::GetExtents("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UFieldGraph::WriteXDR(UFileName Fout) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "WriteXDR()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::WriteXDR(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    UString Text = GetProperties(" ");
    return UField::WriteXDR(Fout,(const char*)Text);
}

ErrorType UFieldGraph::WriteAsText(UFileName Fout) const
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "WriteAsText()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::WriteAsText(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(Fout, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::WriteAsText(). Cannot open or create %s \n", (const char*) Fout);
        return U_ERROR;
    }

    fprintf(fp, "%s", CI.GetProperties("//  "));
    fprintf(fp, "//    \n");
    fprintf(fp, "//    \n");
    fprintf(fp, "%s", (const char*)this->GetProperties("//  "));
    fprintf(fp, "//    \n");
    fprintf(fp, "//    \n");

/* Collumn captions */
    fprintf(fp, "t    \t");
    if(veclen==2 && GetComponentsDataType()==U_COMPDAT_AVERSTAN)
    {
        fprintf(fp, "%s", GetName());
        fprintf(fp, "Sigma\t \n");
    }
    else
    {
        for(int k=0; k<veclen; k++)
        {
            UString Name = Label;
            if(veclen>1) Name += UString(k, "_%d");
            fprintf(fp, "%s",(const char*)Name);
            if(k<veclen-1) fprintf(fp, "\t");
        }
        fprintf(fp, "\n");
    }

    GetNextPoint1(true);
    for(int n=0; n<GetNpoints(); n++)
    {
        double X = GetNextPoint1(false);
        fprintf(fp, "%12.5g \t", X);
        for(int k=0; k<veclen; k++)
        {
            switch(GetDType())
            {
            case U_BYTE   : fprintf(fp, "%d \t", Bdata[n*veclen+k]); break;
            case U_SHORT  : fprintf(fp, "%d \t", Sdata[n*veclen+k]); break;
            case U_INTEGER: fprintf(fp, "%d \t", Idata[n*veclen+k]); break;
            case U_FLOAT  : fprintf(fp, "%12.5g \t", Fdata[n*veclen+k]); break;
            case U_DOUBLE : fprintf(fp, "%12.5g \t", Ddata[n*veclen+k]); break;
            }
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
    return U_OK;
}

ErrorType SaveGraphs(const UFieldGraph* const*GraphAr, const bool* Selection, int NGraph, bool IgnoreTimeScale, UFileName Fout)
{
    if(GraphAr==NULL || NGraph<=0)
    {
        CI.AddToLog("ERROR: SaveGraphs(). Invalid NULL pointer. NGraph=%d \n", NGraph);
        return U_ERROR;
    }

    if(IsStringCompatible(Fout.GetExtension(),"*1D",false)==true)
    {
        for(int n=0; n<NGraph; n++)
        {
            if(Selection && Selection[n]==false) continue;
            if(GraphAr[n]==NULL || GraphAr[n]->GetError()!=U_OK)
            {
                CI.AddToLog("WARNING: SaveGraphs(). Graph[%d] NULL or erroneous. Skip it. \n", n);
                continue;
            }

            UFileName Fn = Fout;
            if(NGraph>1) Fn.InsertFileNumber(n,3);
            if(GraphAr[n]->Write1D(Fn)!=U_OK)
            {
                CI.AddToLog("ERROR: SaveGraphs(). Saving graph %s in file %s\n", GraphAr[n]->GetName(), Fn.GetFullFileName());
                return U_ERROR;
            }
        }
        return U_OK;
    }
    else if(IsStringCompatible(Fout.GetExtension(),"*txt",false)==true)
    {
        FILE* fp =  fopen(Fout, "wt", false);
        if(fp==NULL)
        {
            CI.AddToLog("ERROR: SaveGraphs(). Cannot open file : %s \n", Fout.GetFullFileName());
            return U_ERROR;
        }

        fprintf(fp, "%s", CI.GetProperties("//  "));
        fprintf(fp, "//    \n");

/* Collumn captions */
        bool First  = true;
        int  MaxTim = 0;
        for(int n=0,nprev=0; n<NGraph; n++)
        {
            if(Selection && Selection[n]==false) continue;
            if(GraphAr[n]==NULL || GraphAr[n]->GetError()!=U_OK)
            {
                CI.AddToLog("WARNING: SaveGraphs(). Graph[%d] NULL or erroneous. Skip it. \n", n);
                continue;
            }

            int Np = GraphAr[n]->GetNpoints();
            if(Np>MaxTim) MaxTim = Np;

            if(First==true || GraphAr[n]->IsGeometryCompatible( GraphAr[nprev] )==false)
            {
                if(First==true)
                {
                    if(GraphAr[n]->GetFileComments())
                    {
                        UString Text = UString("First plot: \n") + UString(GraphAr[n]->GetFileComments()) + GraphAr[n]->GetProperties("//  ");
                        Text.InsertAtEachLine("//   ");
                        fprintf(fp, "%s", (const char*)Text);
                    }
                    fprintf(fp, "//    \n");
                }
                fprintf(fp, "%s \t", GetGraphDatTypeText(GraphAr[n]->GetDatTypeHor()));
                nprev = n;
                First = false;
            }

            fprintf(fp, "%s\t", GraphAr[n]->GetName());
            if(GraphAr[n]->GetVeclen()==2)
            {
                if(GraphAr[n]->GetComponentsDataType()==U_COMPDAT_AVERSTAN)  fprintf(fp, "Sigma \t");
                else                                                         fprintf(fp, "Comp2 \t");
            }
        }
        fprintf(fp, "\n");

/* Print data by collumn */
        for(int j=0; j<MaxTim; j++)
        {
            First  = true;
            for(int n=0,nprev=0; n<NGraph; n++)
            {
                if(Selection && Selection[n]==false) continue;
                if(GraphAr[n]==NULL || GraphAr[n]->GetError()!=U_OK) continue;

                double* XY = GraphAr[n]->GetXYarray(IgnoreTimeScale, 0);
                if(XY==NULL)
                {
                    CI.AddToLog("ERROR: SaveGraphs(). Getting XY-plot from graph %d \n", n);
                    return U_ERROR;
                }
                double* XYdelta = NULL;
                if(GraphAr[n]->GetVeclen()==2)
                {
                    XYdelta = GraphAr[n]->GetXYarray(IgnoreTimeScale, 1);
                    if(XYdelta==NULL)
                        CI.AddToLog("WARNING: SaveGraphs(). Getting standard deviation from XY-plot from graph %d \n", n);
                }
                int Np     = GraphAr[n]->GetNpoints();
                if(First==true || GraphAr[n]->IsGeometryCompatible( GraphAr[nprev] )==false)
                {
                    if(j>=Np) fprintf(fp, " \t");
                    else      fprintf(fp, "%12.5g \t",XY[2*j  ]);
                    nprev = n;
                    First = false;
                }
                if(j>=Np) fprintf(fp, " \t");
                else
                {
                    fprintf(fp, "%12.5g \t",XY[2*j+1]);
                    if(XYdelta) fprintf(fp, "%12.5g \t",XYdelta[2*j+1]);
                }
                delete[] XY;
                delete[] XYdelta;
            }
            fprintf(fp, " \n");
        }
        fclose(fp);
        return U_OK;
    }
    else if(IsStringCompatible(Fout.GetExtension(),"*xdr",false)==true)
    {
        ErrorType E = U_OK;
        for(int n=0; n<NGraph; n++)
        {
            if(Selection && Selection[n]==false) continue;
            if(GraphAr[n]==NULL || GraphAr[n]->GetError()!=U_OK)
            {
                CI.AddToLog("WARNING: SaveGraphs(). Graph[%d] NULL or erroneous. Skip it. \n", n);
                continue;
            }

            UFileName Fxdr = Fout;
            if(NGraph>1)
            {
                Fxdr.ReplaceBaseName(GraphAr[n]->GetName());
                CI.AddToLog("Note: SaveGraphs(). Saving graph %d as %s \n", n, (const char*)Fxdr);
            }
            Fxdr.ReplaceExtension(".xdr");
            if(GraphAr[n]->WriteXDR(Fxdr)!=U_OK)
            {
                E=U_ERROR;
                CI.AddToLog("ERROR: SaveGraphs(). Writing to .xdr file %s .\n",(const char*)Fout);
            }
        }
        return E;
    }
    CI.AddToLog("WARNING: SaveGraphs(). .txt extension added. \n");
    Fout.ReplaceExtension(".txt");
    return SaveGraphs(GraphAr, Selection, NGraph, IgnoreTimeScale, Fout);
}

ErrorType UFieldGraph::SetStandardHRF(double Tsamp, int StartSamp, int EndSamp)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "SetStandardHRF()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::SetStandardHRF(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    int Npoints = EndSamp-StartSamp+1;
    if(Tsamp<=0 || Npoints<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::SetStandardHRF(). Invalid input parameters (Tsamp=%f, Npoints=%d). \n", Tsamp, Npoints);
        return U_ERROR;
    }
    UField Base(float(0.), float((Npoints-1)*Tsamp), Npoints, U_DOUBLE);
    *this = Base;
    if(UField::GetError()!=U_OK || Ddata==NULL || Npoints!=GetNpoints())
    {
        CI.AddToLog("ERROR: UFieldGraph::SetStandardHRF(). Setting base class. \n");
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    for(int k=StartSamp; k<=EndSamp; k++)
    {
        int    i = k-StartSamp;
        double t = k*Tsamp;
        Ddata[i] = GetStandardHRF(t);
    }
    NormalizeData(true, true);
    UpdateMinMax();
    Label      = UString("Standard HRF");
    DatTypeHor = U_GDAT_TIME_S;

    UString Comment =  UString("Convolved with Canonical HRF: \n")
                    +  UString(HRF_b1, " b1 = %f \n")
                    +  UString(HRF_d1, " d1 = %f \n")
                    +  UString(HRF_c , " c  = %f \n")
                    +  UString(HRF_b2, " b2 = %f \n")
                    +  UString(HRF_d2, " d2 = %f \n");
    AddFileComments(Comment);
    return U_OK;
}

ErrorType UFieldGraph::ConvolveStandardHRF(void)
{
    AUTODEBUG.AddClassFunction("UFieldGraph", "ConvolveStandardHRF()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(this->Getndim()!=1 || this->GetVeclen()!=1)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). UField base class of wring type (%s). \n", (const char*)GetProperties(""));
        return U_ERROR;
    }
    if(this->GetFType()!=UField::U_UNIFORM)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). Graph not uniformly sampled in time (%s). \n", (const char*)GetProperties(""));
        return U_ERROR;
    }
    double tsamp = this->GetPixelSize(0);
    if(tsamp<=0)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). Sample Time out of range (tsamp=%f) .\n", tsamp);
        return U_ERROR;
    }
    if(ConvertData(UField::U_DOUBLE)!=U_OK || GetDdata()==NULL)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). Converting data to double . \n");
        return U_ERROR;
    }

#define NHDR 200
    double HDR[NHDR];

    double Sum2 = 0;
    for(int j=0; j<NHDR; j++)
    {
        double t = (j-NHDR/2)*tsamp;
        HDR[j]   = GetStandardHRF(t);
        Sum2 += HDR[j]*HDR[j];
    }
    if(Sum2>0.)
    {
        Sum2 = sqrt( Sum2 );
        for(int j=0; j<NHDR; j++) HDR[j] /= Sum2;
    }
    UConvolve ConHDR(HDR, NHDR);
    ConHDR.SetManyFFT(false);
    if(ConHDR.ComputeConv(GetDdata(),GetNpoints())!=U_OK)
    {
        CI.AddToLog("ERROR: UFieldGraph::ConvolveStandardHRF(). Computing convolution. \n");
        return U_ERROR;
    }
    UpdateMinMax();
    UString Comment =  UString("Convolved with Canonical HRF: \n")
                    +  UString(HRF_b1, " b1 = %f \n")
                    +  UString(HRF_d1, " d1 = %f \n")
                    +  UString(HRF_c , " c  = %f \n")
                    +  UString(HRF_b2, " b2 = %f \n")
                    +  UString(HRF_d2, " d2 = %f \n");
    AddFileComments(Comment);
    return U_OK;
}
double UFieldGraph::GetStandardHRF(double t)
{
    if(t<=0) return 0;

    return    pow( t/HRF_d1, HRF_b1) * exp(-t/HRF_d1) - HRF_c*pow( t/HRF_d2, HRF_b2) * exp(-t/HRF_d2);
}


UFieldGraph* GetAaverage(const UFieldGraph* const*FGarr, int NGraph, bool *Select, int* Naver, bool SDWeight)
{
    if(FGarr==NULL || NGraph<=0)
    {
        CI.AddToLog("ERROR: GetAaverage(). Invalid NULL argument or invalid number of graphs (NGraph=%d) .\n", NGraph);
        return NULL;
    }
    UFieldGraph* FGA = NULL;
    int NV           = 0;
    int NP           = 0;
    int NSel         = 0;
    for(int n=0; n<NGraph; n++)
    {
        if(Select && Select[n]==false) continue;

        if(FGarr[n]==NULL || FGarr[n]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: GetAaverage(). Graph (%d) NULL or erroneous (%d). \n", n);
            return NULL;
        }
        if(FGarr[n]->Getndim()!=1)
        {
            CI.AddToLog("ERROR: GetAaverage(). Graph (%d) is of wrong type. \n", n);
            return NULL;
        }
        if(FGarr[n]->GetDdata()==NULL || FGarr[n]->GetDType()!=UField::U_DOUBLE)
        {
            CI.AddToLog("ERROR: GetAaverage(). Data type should be UField::U_DOUBLE (graph %d) .\n", n);
            return NULL;
        }
        if(NSel==0)
        {
            NV  = FGarr[n]->GetVeclen();
            NP  = FGarr[n]->GetNpoints();
            FGA = new UFieldGraph(*(FGarr[n]));
            if(FGA==NULL || FGA->GetError()!=U_OK)
            {
                delete FGA;
                CI.AddToLog("ERROR: GetAaverage(). Creating average template. \n");
                return NULL;
            }
            FGA->SetVeclen(2);
            FGA->SetComponentsDataType(U_COMPDAT_AVERSTAN);
            FGA->SetDataDouble(0.);
            FGA->SetLabel("Aver");
        }
        else
        {
            if(NV!=FGarr[n]->GetVeclen() || NP!=FGarr[n]->GetNpoints())
            {
                delete FGA;
                CI.AddToLog("ERROR: GetAaverage(). Veclen or Npoints of graph (%d) is not equal to first (NP=%d, NV=%d). \n", n, NP, NV);
                return NULL;
            }
        }
        NSel++;
    }
    if(NSel<=0 || NP<=0 || NV<=0 || NV>2)
    {
        delete FGA;
        CI.AddToLog("ERROR: GetAaverage(). No graphs selected (%d) or Veclen or Npoints out of range (NP=%d, NV=%d). \n", NSel, NP, NV);
        return NULL;
    }
    if( (    SDWeight  && NV!=2) ||
        (NOT(SDWeight) && NV!=1)    )
    {
        delete FGA;
        CI.AddToLog("ERROR: GetAaverage(). Weighting (SDWeight = %s) not consistent with veclen (NV=%d) \n", BoolAsText(SDWeight), NV);
        return NULL;
    }

    double* W2 = new double[NGraph];
    if(W2==NULL)
    {
        delete FGA;
        CI.AddToLog("ERROR: GetAaverage(). Memory allocation (NGraph=%d) .\n", NGraph);
        return NULL;
    }
    for(int n=0; n<NGraph; n++) W2[n] = 1.;

    for(int j=0; j<NP; j++)
    {
        double SumW = 0.;
        if(SDWeight)
        {
            for(int n=0; n<NGraph; n++)
            {
                if(Select && Select[n]==false) continue;

                double SD = FGarr[n]->GetDdata()[2*j+1];
                if(SD<=0.)
                {
                    if(SD<0) // Could be interpolation error
                    {
                        CI.AddToLog("WARNING: GetAaverage(). Invalid SD at graph %d, point %d. Abs value is taken. \n", n, j);
                        SD = fabs(SD);
                    }
                    else
                    {
                        delete[] W2;
                        delete   FGA;
                        CI.AddToLog("ERROR: GetAaverage(). Invalid SD at graph %d, point %d \n", n, j);
                        return NULL;
                    }
                }
                W2[n]  = 1./(SD*SD);
                SumW  += W2[n];
            }
        }
        else
            SumW = NSel;

/* Compute (weighted) average in first vector component of output */
        for(int n=0; n<NGraph; n++)
        {
            if(Select && Select[n]==false) continue;

            FGA->GetDdata()[2*j+0] += FGarr[n]->GetDdata()[2*j+0]*W2[n];
        }
        FGA->GetDdata()[2*j+0] /= SumW;

/* Compute SD of the mean*/
        for(int n=0; n<NGraph; n++)
        {
            if(Select && Select[n]==false) continue;

            double Theta = FGA->GetDdata()[2*j+0];
            double Dat   = FGarr[n]->GetDdata()[2*j+0];

            FGA->GetDdata()[2*j+1] += (Theta-Dat)*(Theta-Dat)*W2[n];
        }
        FGA->GetDdata()[2*j+1] /= (SumW*NSel);
        FGA->GetDdata()[2*j+1]  = sqrt(fabs(FGA->GetDdata()[2*j+1]));
    }
    delete[] W2;

    if(Naver) *Naver = NSel;
    return FGA;
}
