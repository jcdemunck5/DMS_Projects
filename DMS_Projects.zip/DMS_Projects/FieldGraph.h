#ifndef UFIELDGRAPH_H
#define UFIELDGRAPH_H

#include "Field.h"
#include "FileName.h"
#include "String.h"


class DLL_IO UFieldGraph : public UField
{
public:
    UFieldGraph();
    UFieldGraph(const char* FileName);
    UFieldGraph(UFileName FileName);
    UFieldGraph(const UField *F, const UString& Label, UVector3 P, double Rad, GraphDatType DTypeHor, CompDatType Comp=U_COMPDAT_UNKNOWN);
    UFieldGraph(const UFieldGraph& FG);
    UFieldGraph(const UField *F);
    UFieldGraph(const UField& F);
    UFieldGraph(float    Min, float    Max, int dims, DataType DT, int vecl=1);
    UFieldGraph(const float* points, const int dims, DataType DT, int vecl=1);
    virtual ~UFieldGraph(void);

    UFieldGraph& operator =(const UFieldGraph& FG);

    ErrorType              GetError(void) const              {return error;}
    virtual const UString& GetProperties(UString Comment) const;
                
    void                   SetLabel(const UString& Lab)      {Label=Lab;}
    const UString&         GetLabel(void) const              {return Label;}
    const char*            GetName(void) const               {return (const char*) Label;}

    void                   GetMinMax(double* XMI, double* XMA, double* YMI, double* YMA, bool RemoveOffset) const;
    ErrorType              UpdateMinMax(void);
    double*                GetXYarray(bool IgnoreTimeScale, int icomp, int* NPSelected=NULL, const UField* Selector=NULL) const; 

    UVector3               GetPoint(void) const              {return Point;}
    void                   SetPoint(UVector3 P)              {Point  = P;}
    double                 GetRadius(void) const             {return Radius;}
    void                   SetRadius(double Rad)             {Radius = Rad;}
    GraphDatType           GetDatTypeHor(void) const         {return DatTypeHor;}        
    void                   SetDatTypeHor(GraphDatType GDT)   {DatTypeHor = GDT ;}        
    
    CompDatType            GetComponentsDataType(void) const {return Components;}
    void                   SetComponentsDataType(CompDatType Comp) {Components = Comp;}

    double                 GetPWidthFullMaximum(double P, int icomp, double* DatMaxFabs) const;
    double                 GetWidthFullMaximumAbs(double DataLevel, int icomp, double* DatMaxFabs) const;
    double                 GetDataWeigtedX(int icomp) const;
    UFieldGraph*           GetComponent(int icomp) const;
    virtual ErrorType      ShiftCoords(double Shift);
    virtual ErrorType      SetVeclen(int NewVeclen);

    ErrorType              WriteAsText(UFileName Fout) const;
    ErrorType              WriteXDR(UFileName Fout) const;

    ErrorType              GetLevelRange(int Level, int iLevel, double* StartCoord, double* EndCoord) const;
    ErrorType              GetPointsInRange(const UFieldGraph* Grid, int* NFirstOutRange, int*NInRange) const;
    UFieldGraph*           GetInterpolationCon(const UFieldGraph* Grid) const;
    UFieldGraph*           GetInterpolationLin(const UFieldGraph* Grid) const;
    UFieldGraph*           GetInterpolationFFT(const UFieldGraph* Grid) const;
    double                 GetInterpolationLin(double Xval) const;

    ErrorType              InterpolateCon(const UFieldGraph* Grid);
    ErrorType              InterpolateLin(const UFieldGraph* Grid);
    ErrorType              InterpolateFFT(const UFieldGraph* Grid);
    UFieldGraph*           DetectOutLiersAbsMinMed(double MinMedThresh) const;

    ErrorType              SetStandardHRF(double Tsamp, int StartSamp, int EndSamp);
    ErrorType              ConvolveStandardHRF(void);

    const static UString   DefaultName;
    static const UVector3  OutsideScan;

protected:
    double                 Yoffset;
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    static const double    HRF_d1;  
    static const double    HRF_b1;  
    static const double    HRF_c ;  
    static const double    HRF_d2;  
    static const double    HRF_b2;  

    ErrorType              error;
    UString                Label;

    double                 Xmin;            // Extends in UField coordinates 
    double                 Xmax;
    double                 Ymin;            // over all veclen components
    double                 Ymax;
    double                 Radius;

    GraphDatType           DatTypeHor; 
    CompDatType            Components;      // meaning of components
    UVector3               Point;

    static double          GetStandardHRF(double time);
};

ErrorType        DLL_IO SaveGraphs(const UFieldGraph* const*GraphAr, const bool* Selection, int NGraph, bool IgnoreTimeScale, UFileName Fout);
PMT_UFIELDGRAPHP DLL_IO GetAaverage(const UFieldGraph* const*FGarr, int NGraph, bool *Select, int* Naver, bool SDWeight);

#endif // UQFIELDGRAPH_H
