/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     A. de Jongh / J.C. de Munck                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    31-05-00   Creation, by simply splitting oof some special functions from Field.cpp
                    In this way, much fewer functions need to be linked in many applications.
  JdM    22-08-00   IsInSurface(). extend to other data types.
  JdM    22-11-00   BUG FIX: IsInSurface(). Find the correct corner points enclosing the surface
  JdM    16-12-00   ThresholdRelative() : Skip many points when computing histogram
  JdM    16-02-01   ThresholdRelative() : Apply threshold in GetRightMax()
  JdM    07-10-01   Compatibility with U_FLOAT and U_DOUBLE data types
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    20-05-03   Added MarkInSurface()
  JdM    24-07-03   Added data member FileComments[]
  JdM    06-08-05   Added GetLineRMSHistogram()
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    30-08-08   Added parameter to DeleteAllMembers()
                    Tested this==NULL and added Debug()-option
  JdM    30-10-08   MarkInSurface() and IsInSurface(). Used improved USurface::InSurface() method
  JdM    31-10-08   MarkInSurface() and IsInSurface(). Use inner and outer sphere radii as pre-selector
  JdM    12-12-09   Added GetFitSurfaceToScan()
  JdM    02-03-10   Renamed UDataPrism3 into UDataPrism3
  JdM    05-01-11   Added argument to MarkInSurface()
  JdM    26-01-11   MarkInSurface() and IsInSurface(). Use points of randomized copy of input surface.
  JdM    11-05-11   MarkInSurface(). Implemented much faster algorithm, treating x-crossings line by line.
                    Call this algorithm in IsInSurface()
  JdM    13-05-11   Replaced AUTODEBUG.AddClassFunction() by UDebug::ReplaceClassFunction()
  JdM    19-09-13   Added ComputeTubeness()
  JdM    17-03-14   GetDataHistogram(). Changed default ranges for U_SHORT and U_INTEGER
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    01-04-15   BUG FIX: IsInSurface(). Set bytes to zero in Fcopy. This part was erroneously skipped, because && was used instead of || in the test line.
  JdM    14-05-15   GetDataHistogram(). Added implementation for U_FLOAT and U_DOUBLE.
  JdM    31-05-15   MarkInSurface(): Speed up innermost loop.
*/

#include <string.h>
#include "Field.h"
#include "Debug.h"

#include "SortSemiSort.h"
#include "Random.h"
#include "Distribution.h"
#include "AnalyzeLineExt.h"

#include "Surface.h"
#include "DataPrism3.h"
#include "DecompHermitian.h"

UField::UField(UDipole *DipArray, int Ndipoles)
/*
     Create an irregular field, of which the coordinates correspond to the
     DipArray[]. No data is present at these points.
 */ 
{
    AUTODEBUG.AddClassFunction("UField", "UField()");
    SetAllMembersDefault();

    if(DipArray==NULL || Ndipoles<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UField::UField(). Invalid argument(s), Ndipoles=%d \n", Ndipoles);
        return;
    }
    FType        = U_IRREGULAR;
    DType        = U_BYTE;

    veclen       = 0;
    ndim         = 1;
    nspace       = 3;
    dimensions[0] = Ndipoles;

    points     = new float[nspace*dimensions[0]];
    if(points==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UField::UField(). Memory allocation (%d). \n", Ndipoles);
        return;
    }
    for(int k=0;k<dimensions[0]; k++)
    {
        points[                  k] = (float)DipArray[k].Getx().Getx();
        points[  dimensions[0] + k] = (float)DipArray[k].Getx().Gety();
        points[2*dimensions[0] + k] = (float)DipArray[k].Getx().Getz();
    }
}

ErrorType UField::ComputeTubeness(const double* Scales, int NScale, double Alpha, double Beta, double Gamma, bool BrightTubes)
{
    AUTODEBUG.AddClassFunction("UField", "GetTubeness()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetTubeness(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(FType  != U_UNIFORM ||
       veclen != 1         || 
       ndim   != 3 )
    {
        CI.AddToLog("ERROR: UField::GetTubeness(). Incompatible field-type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(Scales==0 || NScale<=0)
    {
        CI.AddToLog("ERROR: UField::GetTubeness(). Arguments out of range: NScale=%d   . \n", NScale);
        return U_ERROR;
    }
    for(int k=0; k<NScale; k++)
    {
        if(Scales[k]>0.) continue;
        CI.AddToLog("ERROR: UField::GetTubeness(). Scales[%d] out of range: %f   . \n", k, Scales[k]);
        return U_ERROR;
    }
    if(Alpha<=0. || Beta<=0. || Gamma<=0.)
    {
        CI.AddToLog("ERROR: UField::GetTubeness(). Arguments out of range: Alpha=%f, Beta=%f, Gamma=%f   . \n", Alpha, Beta, Gamma);
        return U_ERROR;
    }

    int            Npoints = GetNpoints();
    unsigned char* BTube = new unsigned char[Npoints];
    if(BTube==NULL)
    {
        delete[] BTube;
        CI.AddToLog("ERROR: UField::GetTubeness(). Creating output data array. NPoints = %d . \n", Npoints);
        return U_ERROR;
    }
    for(int i=0; i<Npoints; i++) BTube[i] = 0;

    UDecompHermitian DecHerm;
    double Alpha2  = 2*Alpha*Alpha;
    double Beta2   = 2*Beta *Beta ;
    double Gamma2  = 2*Gamma*Gamma;
    for(int kscale=0; kscale<NScale; kscale++)
    {
        UField FHess = *this;
        if(FHess.SmoothHessian(Scales[kscale], Scales[kscale], Scales[kscale])!=U_OK)
        {
            delete[] BTube;
            CI.AddToLog("ERROR: UField::GetTubeness(). Creating Hessian. kcale = %d . \n", kscale);
            return U_ERROR;
        }
        for(int i=0, i6=0; i<Npoints; i++, i6+=6)
        {
            double H[9] = {0.,0.,0., 0.,0.,0., 0.,0.,0.};
            switch(DType)
            {
            case U_BYTE   : {const unsigned char* pB = Bdata + i6;H[0]=pB[0]; H[1]=pB[1]; H[4]=pB[2]; H[2]=pB[3]; H[5]=pB[4]; H[8]=pB[5];} break;
            case U_SHORT  : {const short*         pS = Sdata + i6;H[0]=pS[0]; H[1]=pS[1]; H[4]=pS[2]; H[2]=pS[3]; H[5]=pS[4]; H[8]=pS[5];} break;
            case U_INTEGER: {const int*           pI = Idata + i6;H[0]=pI[0]; H[1]=pI[1]; H[4]=pI[2]; H[2]=pI[3]; H[5]=pI[4]; H[8]=pI[5];} break;
            case U_FLOAT  : {const float*         pF = Fdata + i6;H[0]=pF[0]; H[1]=pF[1]; H[4]=pF[2]; H[2]=pF[3]; H[5]=pF[4]; H[8]=pF[5];} break;
            case U_DOUBLE : {const double*        pD = Ddata + i6;H[0]=pD[0]; H[1]=pD[1]; H[4]=pD[2]; H[2]=pD[3]; H[5]=pD[4]; H[8]=pD[5];} break;
            }
            H[3] = H[1]; H[6] = H[2]; H[7] = H[5];

            double* E = DecHerm.GetEigenValues(3, H);
            if(E==NULL)
            {
                delete[] BTube;
                return U_ERROR;
            }
            unsigned char Tube = 0;
            if( (    BrightTubes  && E[1]<0. && E[2]<0.)   || 
                (NOT(BrightTubes) && E[1]>0. && E[2]>0.))
            {
                double RA2 =  E[1]*E[1] /    (E[2]*E[2]);        // Deviation from plate-like structure
                double RB2 =  E[0]*E[0] /fabs(E[1]*E[2]);        // Similarity to blob-like structure
                double SS2 =  E[2]*E[2]+E[1]*E[1]+E[0]*E[0];     // Frob. Norm.

                double TT  = (1.-exp(-RA2/Alpha2)) * exp(-RB2/Beta2) * (1-exp(-SS2/Gamma2));

                Tube       = (unsigned char) floor(0.499 + 255 * TT);
            }
            delete[] E;
            if(BTube[i]<Tube) BTube[i] = Tube;
        }
    }
    SetData(BTube, 1);
    delete[] BTube;
    return U_OK;
}

ErrorType UField::ThresholdRelative(double Min, double Max, int NewVal)
/*
    Determine two thresholds (min and max) from the given numbers Min and Max by
    considering Min and Max as percentages of the "Right Maximum" (see UDistribution)
    of the pixel value histogram.

    All pixel outside the range (min,max) are set to zero. Pixels inside this range are
    set to NewVal (>0) or to their old value if NewVal<0.
    
    if(Max==-1) Max is ignored, and the only the lower threshold parameter is accounted for
 */
{
    AUTODEBUG.AddClassFunction("UField", "ThresholdRelative()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::ThresholdRelative(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Max>0&&Max<Min) 
    {
        CI.AddToLog("ERROR: UField::ThresholdRelative(), Erroneous input parameters: Min=%d, Max=%d\n",Min,Max);
        return U_ERROR;
    }
    if(DType!=U_BYTE)     
    {
        CI.AddToLog("ERROR: UField::ThresholdRelative(), Incompatible field-type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }        

    int his[256];
    memset(his, 0, 256*sizeof(int));

    int NP   = GetNpoints();
    int skip = 1+NP/50000;
    for(int n=0; n<NP; n+=skip) his[Bdata[n]]++;

    UDistribution Dist(256, his);
    if(Dist.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::ThresholdRelative(). Cannot determine distribution.");
        return U_ERROR;
    }
    Dist.Smooth(2.0);

    CI.AddToLog((const char*)Dist.GetDistributionText(" ", true, false, false));
    
    double RightMax = Dist.GetRightMax(5);
    int    imin     = int(floor(Min*RightMax/100.));
    int    imax     = int(floor(Max*RightMax/100.));
    if(Max<0) imax  = 256;
    CI.AddToLog("Note: UField::ThresholdRelative():\n");
    CI.AddToLog("%s",Dist.GetProperties("Note: "));
    CI.AddToLog("Note:  RightMax = %f\n",RightMax);
    CI.AddToLog("Note:  imin,imax = %d,%d\n",imin,imax);

    return ThresholdAbsolute(imin, imax, NewVal);
}

UDistribution* UField::GetLineRMSHistogram(int dir, double DataMax) const
{
    AUTODEBUG.AddClassFunction("UField", "GetLineRMSHistogram()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetLineRMSHistogram(). Object NULL or erroneous. \n");
        return NULL;
    }

    if(veclen!=1 || ndim!=2) 
    {
        CI.AddToLog("ERROR: UField::GetLineRMSHistogram(), Incompatible field-type %s\n",(const char*)GetProperties(""));
        return NULL;
    }
    if(dir<0 || dir>=2)
    {
        CI.AddToLog("ERROR: UField::GetLineRMSHistogram(), dir out of range: dir = %d   . \n", dir);
        return NULL;
    }

    int Nbin = dimensions[dir];

    UDistribution* Dist = new UDistribution(Nbin, 0., DataMax);
    if(Dist==NULL || Dist->GetError()!=U_OK) 
    {
        delete Dist;
        CI.AddToLog("ERROR: UField::GetLineRMSHistogram(). Cannot create UDistribution()\n");
        return NULL;
    }

    for(int k=0; k<Nbin; k++)
    {
        UField* pF = this->GetLine(dir, k);
        if(pF==NULL || pF->GetError()!=U_OK)
        {
            delete pF;
            delete Dist;
            CI.AddToLog("ERROR: UField::GetLineRMSHistogram(). Getting line data in direction %d, coord %d \n", dir, k);
            return NULL;
        }
        double Val = pF->GetRMSData();
        Dist->AddValue(Val);
        delete pF;
    }
    return Dist;
}

UDistribution* UField::GetDataHistogram(int Nsubsample, int icomp) const
{
    AUTODEBUG.AddClassFunction("UField", "GetDataHistogram()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetDataHistogram(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(GetData()==NULL)
    {
        CI.AddToLog("ERROR: UField::GetDataHistogram(). Data not set. \n");
        return NULL;
    }
    if(veclen<=0) 
    {
        CI.AddToLog("ERROR: UField::GetDataHistogram(), Incompatible field-type %s\n",(const char*)GetProperties(""));
        return NULL;
    }
    if(icomp>=veclen)
    {
        CI.AddToLog("ERROR: UField::GetDataHistogram(), Invalid icomp (=%d).\n",icomp);
        return NULL;
    }
    int Npoints    = veclen*GetNpoints();
    int icompStart = 0;
    int icompStep  = 1;
    if(icomp>=0)
    {
        icompStart = icomp;
        icompStep  = veclen;
    }

    UDistribution* Dist = NULL;
    switch(DType)
    {
    case U_BYTE:     Dist = new UDistribution( 255, 0.,   255.); break;
    case U_SHORT:    Dist = new UDistribution(2000, 0., 10000.); break;
    case U_INTEGER:  Dist = new UDistribution(4000, 0., 80000.); break;
    case U_FLOAT:  
    case U_DOUBLE:
        {
            double Dmin= 0.;
            double Dmax=-1.;
            GetMinMaxData(&Dmin, &Dmax);
            Dist = new UDistribution(10000, Dmin, Dmax);
        }
        break;
    default:
        CI.AddToLog("ERROR: UField::GetDataHistogram(), Unsupported data type: %d \n", DType);
        return NULL;
    }
        

    if(Dist==NULL || Dist->GetError()!=U_OK) 
    {
        delete Dist;
        CI.AddToLog("ERROR: UField::GetDataHistogram(). Cannot create UDistribution() \n");
        return NULL;
    }

    if(Nsubsample<=0) Nsubsample = 1;
    Nsubsample *= icompStep;
    switch(DType)
    {
    case U_BYTE:
        {
            if(Bdata==NULL) break;
            for(int k=icompStart; k<Npoints; k+=Nsubsample) Dist->AddValue((double)Bdata[k]);
            return Dist;
        }
    case U_SHORT:
        {
            if(Sdata==NULL) break;
            for(int k=icompStart; k<Npoints; k+=Nsubsample) Dist->AddValue((double)Sdata[k]);
            return Dist;
        }
    case U_INTEGER:
        {
            if(Idata==NULL) break;
            for(int k=icompStart; k<Npoints; k+=Nsubsample) Dist->AddValue((double)Idata[k]);
            return Dist;
        }
    case U_FLOAT:
        {
            if(Fdata==NULL) break;
            for(int k=icompStart; k<Npoints; k+=Nsubsample) Dist->AddValue((double)Fdata[k]);
            return Dist;
        }
    case U_DOUBLE:
        {
            if(Ddata==NULL) break;
            for(int k=icompStart; k<Npoints; k+=Nsubsample) Dist->AddValue(        Ddata[k]);
            return Dist;
        }
    }
    delete Dist;
    return NULL;
}

ErrorType UField::RandomizePoints(double StDev, int seed)
/*
    Randomly desturn the coordinates of an irregular field, with a Gaussian
    distribution with a standard deviation of StDev cm. Initialize the random 
    generator with the seed seed.
 */
{
    AUTODEBUG.AddClassFunction("UField", "RandomizePoints()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::RandomizePoints(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(FType!=U_IRREGULAR) 
    {
        CI.AddToLog("ERROR: UField::RandomizePoints(), Incompatible field-type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }

    int NP   = GetNpoints()*GetNspace();
    UGaussian G(StDev,0.,seed);
    for(int n=0; n<NP; n++) 
        points[n] += float( G.GetGaussian() );

    return U_OK;
}

ErrorType UField::IsInSurface(const USurface* S)
/*
    Assign a value of 0 to all points that are OUTSIDE the USurface *S. Leave 
    the data of all other points untouched.
 */
{
    AUTODEBUG.AddClassFunction("UField", "IsInSurface()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(veclen != 1) 
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). Incompatible veclen %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(ndim!=3 || nspace!=3)
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). Incompatible space or dimensions %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(FType!=U_UNIFORM && FType!=U_RECTILINEAR)
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). Incompatible coordinate type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(S==NULL || S->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). NULL or erroneous USurface argument. \n");
        return U_ERROR;
    }
    USurface Scopy = *S;
    if(Scopy.GetError()!=U_OK || Scopy.IsClosedSurface()!=true)
    {
        CI.AddToLog("ERROR: UField::IsInSurface(). Copying USurface or copied USurface is not closed. \n");
        return U_ERROR;
    }
    UField* Fcopy = new UField(*this);
    if(Fcopy==NULL || Fcopy->GetError()!=U_OK)
    {
        delete Fcopy;
        CI.AddToLog("ERROR: UField::IsInSurface(). Copying this. \n");
        return U_ERROR;
    }
    if(Fcopy->ConvertData(U_BYTE, 1.)!=U_OK || Fcopy->SetDataByte(0)!=U_OK)
    {
        delete Fcopy;
        CI.AddToLog("ERROR: UField::IsInSurface(). Converting copy to byte. \n");
        return U_ERROR;
    }
    if(Fcopy->MarkInSurface(&Scopy, 1, true)!=U_OK)// Mark inside as 1, leave outide points as 0,
    {
        delete Fcopy;
        CI.AddToLog("ERROR: UField::IsInSurface(). Marking points in surface. \n");
        return U_ERROR;
    }
    this->operator&=(*Fcopy);

    delete Fcopy;
    return U_OK;
}

ErrorType UField::MarkInSurfaceStand(const USurface* S, int Mark, bool AddMark)
/*
Assign or add a value of Mark to all points that are INSIDE the USurface *S.
Leave the data of all other points untouched. The value Mark is added iff(AddMark==true)
*/
{
    AUTODEBUG.AddClassFunction("UField", "MarkInSurfaceStand()");
    if (this == NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if (veclen != 1)
    {
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Incompatible veclen %s\n", (const char*)GetProperties(""));
        return U_ERROR;
    }
    if (ndim != 3 || nspace != 3)
    {
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Incompatible space or dimensions %s\n", (const char*)GetProperties(""));
        return U_ERROR;
    }
    if (FType != U_UNIFORM && FType != U_RECTILINEAR)
    {
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Incompatible coordinate type %s\n", (const char*)GetProperties(""));
        return U_ERROR;
    }
    if (S == NULL || S->IsClosedSurfaceStand() != true)
    {
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Invalid USurface. \n");
        return U_ERROR;
    }
    USurface* Scopy = new USurface(*S);
    if (Scopy == NULL || Scopy->GetError() != U_OK)
    {
        delete Scopy;
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Copying USurface argument. \n");
        return U_ERROR;
    }
    UVector3 Vox = GetVoxel();
    double   Sig = 0.00001*(fabs(Vox[0]) + fabs(Vox[1]) + fabs(Vox[2])) / 3.;
    if (Scopy->RandomizePoints(Sig, 34) != U_OK)
    {
        delete Scopy;
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Randomizing points from USurface copy. \n");
        return U_ERROR;
    }
    UVector3* pMin = Scopy->GetMinTri();
    UVector3* pMax = Scopy->GetMaxTri();
    if (pMin == NULL || pMax == NULL)
    {
        delete   Scopy;
        delete[] pMin;
        delete[] pMax;
        CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Getting triangle ranges. \n");
        return U_ERROR;
    }

    UVector3 MinP, MaxP;
    Scopy->ComputeMinMax(&MinP, &MaxP);

    for (int z = 0; z<dimensions[2]; z++)
    {
        double Z = GetCoord(2, z);
        if (Z<MinP[2] || Z>MaxP[2]) continue;

        for (int y = 0; y<dimensions[1]; y++)
        {
            double Y = GetCoord(1, y);
            if (Y<MinP[1] || Y>MaxP[1]) continue;

            int     NCross = 0;
            double* CrossX = Scopy->GetCrossings(UVector3(0., Y, Z), 0, &NCross, pMin, pMax);
            if (CrossX == NULL) continue;

            if (Vox.Getx()<0)
            {
                for (int k = 0; k<NCross / 2; k++)
                {
                    double Dum = CrossX[k];
                    CrossX[k] = -CrossX[NCross - k - 1];
                    CrossX[NCross - k - 1] = -Dum;
                }
            }
            double   X = GetCoord(0, 0);  if (Vox.Getx()<0) X = -X;
            int      ic = SearchIndex(X, CrossX, NCross);
            if (ic<0 || ic >= NCross) continue;

            for (int x = 0; x<dimensions[0]; x++)
            {
                X = GetCoord(0, x); if (Vox.Getx()<0) X = -X;
                if (X >= CrossX[ic])
                    ic = SearchIndex(X, CrossX, NCross);

                if (ic<0 || ic >= NCross) break;

                if ((ic % 2) == 0) continue;

                int ip = (z*dimensions[1] + y)*dimensions[0] + x;
                switch (DType)
                {
                case U_BYTE:
                    if (!Bdata) continue;
                    {
                        unsigned char Newd = (unsigned char)Mark;
                        if (AddMark)   Newd += Bdata[ip];
                        Bdata[ip] = Newd;
                    }
                    break;

                case U_SHORT:
                    if (!Sdata) continue;
                    {
                        short       Newd = (short)Mark;
                        if (AddMark) Newd += Sdata[ip];
                        Sdata[ip] = Newd;
                    }
                    break;

                case U_INTEGER:
                    if (!Idata) continue;
                    {
                        int         Newd = Mark;
                        if (AddMark) Newd += Idata[ip];
                        Idata[ip] = Newd;
                    }
                    break;

                case U_FLOAT:
                    if (!Fdata) continue;
                    {
                        float       Newd = (float)Mark;
                        if (AddMark) Newd += Fdata[ip];
                        Fdata[ip] = Newd;
                    }
                    break;

                case U_DOUBLE:
                    if (!Ddata) continue;
                    {
                        double      Newd = (double)Mark;
                        if (AddMark) Newd += Ddata[ip];
                        Ddata[ip] = Newd;
                    }
                    break;

                default:
                    CI.AddToLog("ERROR: UField::MarkInSurfaceStand(). Unsupported data type : %d \n", DType);
                    delete   Scopy;
                    delete[] pMin;
                    delete[] pMax;
                    delete[] CrossX;
                    return U_ERROR;
                }
            }
            delete[] CrossX;
        }
    }
    delete   Scopy;
    delete[] pMin;
    delete[] pMax;
    return U_OK;
}
ErrorType UField::MarkInSurface(const USurface* S, int Mark, bool AddMark)
/*
    Assign or add a value of Mark to all points that are INSIDE the USurface *S. 
    Leave the data of all other points untouched. The value Mark is added iff(AddMark==true)
 */
{
    AUTODEBUG.AddClassFunction("UField", "MarkInSurface()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(veclen != 1) 
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Incompatible veclen %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(ndim!=3 || nspace!=3)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Incompatible space or dimensions %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(FType!=U_UNIFORM && FType!=U_RECTILINEAR)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Incompatible coordinate type %s\n",(const char*)GetProperties(""));
        return U_ERROR;
    }
    if(S==NULL || S->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). NULL or erroneous USurface argument. \n");
        return U_ERROR;
    }
    USurface Scopy = USurface(*S);
    if(Scopy.GetError()!=U_OK || Scopy.IsClosedSurface()!=true)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Copying USurface argument, or copied argument is not closed. \n");
        return U_ERROR;
    }
    UVector3 Vox   = GetVoxel();
    double   Sig   = 0.00001*(fabs(Vox[0])+fabs(Vox[1])+fabs(Vox[2]))/3.;
    if(Scopy.RandomizePoints(Sig, 34)!=U_OK)
    {
        CI.AddToLog("ERROR: UField::MarkInSurface(). Randomizing points from USurface copy. \n");
        return U_ERROR;
    }

    unsigned char Bark = (unsigned char)Mark; 
    short         Sark = (short        )Mark; 
    float         Fark = (float        )Mark; 
    double        Dark = (double       )Mark; 

    UVector3 MinP = Scopy.GetMinx();
    UVector3 MaxP = Scopy.GetMaxx();

    for(int z=0; z<dimensions[2]; z++)
    {
        double Z = GetCoord(2, z);
        if(Z<MinP[2] || Z>MaxP[2]) continue;

        for(int y=0; y<dimensions[1]; y++)
        {
            double Y = GetCoord(1, y);
            if(Y<MinP[1] || Y>MaxP[1]) continue;

            int     NCross = 0;
            double* CrossX = Scopy.GetSortedCrossings(UVector3(0.,Y,Z), 0, &NCross, Vox.Getx()<0.);
            if(CrossX==NULL) continue;

            if(Vox.Getx()<0) for(int k=0; k<NCross; k++) CrossX[k] =-CrossX[k];
            double   X   = (Vox.Getx()<0.) ? -GetCoord(0, 0) : GetCoord(0, 0);
            int      ic  = SearchIndex(X, CrossX, NCross);
            if(ic<0 || ic>=NCross) continue;

            for(int x=0; x<dimensions[0]; x++)
            {
                X   = (Vox.Getx()<0.) ? -GetCoord(0, x) : GetCoord(0, x);
                if(X>=CrossX[ic])
                    ic = SearchIndex(X, CrossX, NCross);
                
                if(ic<0 || ic>=NCross) break;
                if((ic%2)==0) continue; 

                int ip = (z*dimensions[1]+y)*dimensions[0]+x;
                switch(DType)
                {
                case U_BYTE:    if(Bdata) {Bdata[ip] = (AddMark) ? Bdata[ip]+Bark : Bark; break;}
                case U_SHORT:   if(Sdata) {Sdata[ip] = (AddMark) ? Sdata[ip]+Sark : Sark; break;}
                case U_INTEGER: if(Idata) {Idata[ip] = (AddMark) ? Idata[ip]+Mark : Mark; break;}
                case U_FLOAT:   if(Fdata) {Fdata[ip] = (AddMark) ? Fdata[ip]+Fark : Fark; break;}
                case U_DOUBLE:  if(Ddata) {Ddata[ip] = (AddMark) ? Ddata[ip]+Dark : Dark; break;}
                default:
                    CI.AddToLog("ERROR: UField::MarkInSurface(). Unsupported data type : %d, or data not set.\n",DType);
                    delete[] CrossX;
                    return U_ERROR;
                }
            }
            delete[] CrossX;
        }
    }
    return U_OK;
}

USurface* UField::GetFitSurfaceToScan(const USurface* Surf, double RangeMin, double RangeMax, UDetectExtremeType DetExt) const
{
    const double RESEL = 0.1; // resolution in mm

    AUTODEBUG.AddClassFunction("UField", "GetFitSurfaceToScan()");
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(ndim!=3 || nspace!=3 || veclen!=1 || (FType!=U_UNIFORM && FType!=U_RECTILINEAR))
    {
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). UField of wrong type (%s). \n",(const char*)this->GetProperties(""));
        return NULL;
    }
    if(Surf==NULL || Surf->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). Surface pointer NULL or erroneous. \n");
        return NULL;
    }
    if(RangeMin==RangeMax)
    {
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). Invalid range (RangeMin=%f, RangeMax%f). \n", RangeMin, RangeMax);
        return NULL;
    }
    if(RangeMin>RangeMax)
    {
        double Dum = RangeMin;
        RangeMin   = RangeMax;
        RangeMax   = Dum;
    }
    int    NStep   = MIN(20, MAX(1, int(fabs(RangeMax-RangeMin)/RESEL) )); 
    
    int       Ntri      = Surf->GetNtri();
    UVector3* NewPoints = new UVector3[Ntri];
    double*   Weights   = new double[Ntri];
    if(NewPoints==NULL)
    {
        delete[] NewPoints;
        delete[] Weights;
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). Memory allocation (Ntri=%d). \n", Ntri);
        return NULL;
    }
    UVector3   Center  = Surf->GetCenter();
    const int* Tril    = Surf->GetTriList();
    int        Inter   = 1;
    for(int it=0; it<Ntri; it++)
    {
        UVector3   P0  = ((UPointList*) Surf)->GetPoint(Tril[3*it+0]);
        UVector3   P1  = ((UPointList*) Surf)->GetPoint(Tril[3*it+1]);
        UVector3   P2  = ((UPointList*) Surf)->GetPoint(Tril[3*it+2]);
        UDataPrism3 T   = UDataPrism3(P0, P1, P2);

        double  Side   = T.GetMaxSide();
        int     NSub   = MIN(10, MAX(1, int(Side/RESEL) )); 

        T.SetSubSample(NSub);
        bool AverProf = true;
        NewPoints[it] = T.GetJumpPoint(this, Inter, Center, RangeMin, RESEL, NStep, AverProf, DetExt);
        Weights[it]   = 1.;
    }
    USurface* SNew = new USurface(NewPoints, Weights, Ntri, Surf->GetNpoints());
    delete[] NewPoints;
    delete[] Weights;
    if(SNew==NULL || SNew->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UField::GetFitSurfaceToScan(). Creating new surface. \n");
        return NULL;
    }
    return SNew;
}
