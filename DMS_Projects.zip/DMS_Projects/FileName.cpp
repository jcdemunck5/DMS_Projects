/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     The goal if this object is to manipulate file names: adding, testing      */
/*     and inserting extensions, testing status, allocating memory, etc.         */
/*                                                                               */
/*     NOTE:                                                                     */
/*     This object also works under UNIX, using forward instead of back slash.   */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    21-02-01   creation
  JdM    03-03-01   added new constructors
  JdM    06-03-00   Added IsFileNameCompatible()
  JdM    26-03-01   Added new constructor
  JdM    11-05-01   Added IsBaseFileNameCompatible() (== former IsFileNameCompatible())
                    Added IsFileFullNameCompatible(): test compatibility of complete file name
  JdM    16-05-01   Use IsStringCompatible() from BasicInclude.cpp in IsFileFullNameCompatible() and IsBaseFileNameCompatible()
  JdM    28-05-01   InsertBeforeExtension(). Add argument.
  JdM    01-06-01   Added DoesFileExist()
  JdM    25-06-01   UFileName(const char *DirName, const char*BaseName, const char *Ext). Avoid first SLASH.
  JdM    12-07-01   Added MergeFileName()
  JdM    30-08-01   bug fix operator=(). Testing when the operator is applied upon itself
  JdM    14-11-01   Added GetFileSize()
  JdM    12-01-02   Added DoesFileExist()
  JdM    17-01-02   Added GetRelDir()
  JdM    24-05-03   Added ReplaceBaseName()
  JdM    23-11-03   Added GetSiblingFileName()
  JdM    03-07-04   Added operator==() and operator!=()
  JdM    02-10-04   Bug fix: UpdateStatus(). close file before returning
  JdM    30-10-04   Added type cast operator to const char*
  JdM    28-02-05   Added GetNumberBeforeExtension() and ReplaceNumberBeforeExtension()
  JdM    25-04-05   Bug Fix. HasExtension(). Testing case that given extension is empty
  JdM    20-03-06   Added IsEmpty()
  JdM    11-08-06   ReplaceNumberBeforeExtension(). Added format parameter.
  JdM    13-08-06   Added GetNDigitBeforeExtension()
  JdM    22-08-07   Added DoesBaseFileNameEndWith()
  JdM    27-12-07   Added RemoveDirectory()
  JdM    01-03-09   Added HasAnyExtension()
  JdM    10-04-09   HasExtension(). Avoid non-standard stricmp()
  JdM    22-09-09   Added DoesBaseFileNameStartWith()
  JdM    09-05-10   Added SetExtension() and AddExtension()
  JdM    25-06-10   Added RemoveExtension()
  JdM    01-08-13   Added CopyFile(). Eliminate some warnings occuring for win64 compitation (replaced int by size_t)
  JdM    30-09-13   Use UDirFileName::IsSlash() from newly created base class i.s.o. *SLASH
  JdM    01-10-13   Bug Fix: GetBaseName(), AddExtension(), GetExtensionOffset(), GetBaseNameOffset(), GetRelDir(), UFileName(Directory,Filename,Extension) constructor. 
                             The use of size_t instead of int leads to erroneous results when testing for negative values
  JdM    19-01-14   Added GetFileNameOrder()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
                    bug fix (const char*, const char*, const char*) constructor. Case directory name consists of single symbol
  JdM    12-11-14   Bug Fix: GetExtension(). return NULL when no �.� or �/� has been found.
                    BUG Fix: DoesBaseFileNameEndWith(). Add wild char (*) before testing string compatibility.
  JdM    25-05-15   Added HasFileHeader()
  JdM    03-03-18   Added GetNLines()
  JdM    27-04-18   IsFullFileNameCompatible(). Replace all "/" by "\\"
  JdM    27-04-18   Added CopyFile()
*/

#include <string.h>
#include"FileName.h"
#include"String.h"

UFileName::UFileName()
{
    FullFileName    = new char[4];
    if(FullFileName)
    {
        FullFileName[0] = 0;
        FullFileName[1] = 0;
    }
}

UFileName::UFileName(const char *FileName)
{
    if(FileName==NULL)
    {

        FullFileName    = new char[4];
        if(FullFileName)
        {
            FullFileName[0] = 0;
            FullFileName[1] = 0;
        }
        return;
    }

    size_t nbytes   = strlen(FileName) + 4;
    FullFileName    = new char[nbytes];
    if(FullFileName==NULL) return;

    memset(FullFileName, 0, nbytes);
    strcpy(FullFileName, FileName);
}

UFileName::UFileName(const char *DirName, const char*BaseName, const char *Ext)
{
    size_t       nbytes  = 0;
    if(DirName)  nbytes += strlen(DirName)+3;
    if(BaseName) nbytes += strlen(BaseName)+3;
    if(Ext)      nbytes += strlen(Ext)+3;

    if(nbytes==0)
    {

        FullFileName    = new char[4];
        if(FullFileName)
        {
            FullFileName[0] = 0;
            FullFileName[1] = 0;
        }
        return;
    }

    FullFileName = new char[nbytes];
    if(FullFileName==NULL) return;

    memset(FullFileName, 0, nbytes);
    if((!BaseName || UFileName(BaseName).IsPureFile()==true)  && DirName!=NULL )
        strcpy(FullFileName, DirName);

    if(BaseName)
    {
        size_t lastchar = strlen(FullFileName); // Do not subtract 1
        if(lastchar>0 && IsSlash(FullFileName[lastchar-1])==false)            // 30-07-14 changed lastchar>1 into lastchar>0
                                             strcat(FullFileName, SLASH);
        if(IsSlash(BaseName[0]) == false)    strcat(FullFileName, BaseName);
        else                                 strcat(FullFileName, BaseName+1);
    }
    if(Ext) ReplaceExtension(Ext);
}

UFileName::UFileName(const UDirectory& Dir, const char*BaseName, const char *Ext)
{
    FullFileName = NULL;
    *this = UFileName(&Dir, BaseName, Ext);
}

UFileName::UFileName(const UDirectory* Dir, const char*BaseName, const char *Ext)
{
    FullFileName = NULL;
    const char* DirName = NULL;
    if(Dir)     DirName = Dir->GetDirectoryName();
    *this = UFileName(DirName, BaseName, Ext);
}

UFileName::UFileName(const UDirectory& Dir, const UFileName& Fnam)
{
    FullFileName = NULL;
    *this = UFileName(&Dir, Fnam.GetFullFileName());
}

UFileName::UFileName(const UFileName* Fnam, const char*BaseName, const char *Ext)
{
    FullFileName = NULL;
    *this = UFileName(Fnam->GetFullFileName(), BaseName, Ext);
}

UFileName::UFileName(const UFileName& Fnam, const char*BaseName, const char *Ext)
{
    FullFileName = NULL;
    *this = UFileName(Fnam.GetFullFileName(), BaseName, Ext);
}

UFileName::UFileName(const UFileName& F)
{
    FullFileName = NULL;
    *this        = F;
}

UFileName::~UFileName()
{
    delete[] FullFileName;
}

UFileName& UFileName::operator=(const UFileName &F)
{
    if(&F==NULL)
    {
        CI.AddToLog("ERROR: UFileName::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&F) return *this;  // Nothing to do

    delete[] FullFileName;
    FullFileName    = new char[4];
    if(FullFileName)
    {
        FullFileName[0] = 0;
        FullFileName[1] = 0;
    }
    if(F.FullFileName==NULL) return *this;

    size_t nbytes   = strlen(F.FullFileName) + 4;
    FullFileName    = new char[nbytes];
    if(FullFileName==NULL) return *this;

    memset(FullFileName, 0, nbytes);
    strcpy(FullFileName, F.FullFileName);

    return *this;
}

bool UFileName::operator==(const UFileName &F) const
{
    if(this==NULL || &F==NULL) return false;

    if(FullFileName == F.FullFileName) return true;
    if(  FullFileName == NULL ||
       F.FullFileName == NULL) return false;

    size_t l1 = strlen(  FullFileName);
    size_t l2 = strlen(F.FullFileName);
    if(l1!=l2) return false;

    for(int n=0; n<l1; n++)
    {
        if(FullFileName[n] == '\\' || FullFileName[n] == '/') continue;
        if(FullFileName[n] != F.FullFileName[n]) return false;
    }
    return true;
}

bool UFileName::operator!=(const UFileName &F) const
{
    if(*this==F) return false;
    return true;
}

const char* UFileName::GetBaseName(void) const
{
    if(this==NULL || FullFileName==NULL) return NULL;

    for(size_t k=strlen(FullFileName); k>0; k--) // Do not substract 1
        if(IsSlash(FullFileName[k-1])) return FullFileName+k;

    return FullFileName;
}

const char* UFileName::GetExtension(void) const
{
    if(this==NULL || FullFileName==NULL) return NULL;

    static const char defName[1] = {0};
    for(size_t k=strlen(FullFileName); k>0; k--) // Do not substract 1
    {
        if(IsSlash(FullFileName[k-1])) return defName;
        if(FullFileName[k-1]==    '.') return FullFileName+k;
    }
    return defName;
}

UDirectory  UFileName::GetDirectory(void) const
{
    return UDirectory(FullFileName, CNULL).Parent();
}

UFileName UFileName::GetSiblingFileName(const char* BaseName) const
{
    UDirectory Dir(GetDirectory());
    return UFileName(Dir.GetDirectoryName(), BaseName);
}

ErrorType UFileName::RemoveDirectory(const UDirectory& Dir)
{
    if(this==NULL || FullFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RemoveDirectory(). this==NULL .\n");
        return U_ERROR;
    }
    if(&Dir==NULL || Dir.GetDirectoryName()==NULL)
    {
        CI.AddToLog("ERROR: UFileName::RemoveDirectory(). Dir==NULL .\n");
        return U_ERROR;
    }
    size_t      LenF = strlen(FullFileName);
    const char* DirN = Dir.GetDirectoryName();
    size_t      LenD = strlen(DirN);

    size_t    kstart = LenF;
    for(int k=0; k<LenF; k++)
    {
        if(k==LenD)
        {
            kstart = k;
            if(IsSlash(FullFileName[k])) kstart++;
            break;
        }
        char chF = ToUpperCase(FullFileName[k]);
        char chD = ToUpperCase(DirN[k]);

        if(chF!=chD)
        {
            if(k==LenD-1 && IsSlash(chF))
            {
                kstart = k+1;
                break;
            }
            CI.AddToLog("ERROR: UFileName::RemoveDirectory(). Directory (%s) not part of FileName (%s) .\n", DirN, FullFileName);
            return U_ERROR;
        }
    }
    if(kstart>=LenF)
    {
        CI.AddToLog("ERROR: UFileName::RemoveDirectory(). Directory (%s) not part of FileName (%s) .\n", DirN, FullFileName);
        return U_ERROR;
    }
    for(size_t k=kstart; k<=LenF; k++)
    {
        FullFileName[k-kstart] = FullFileName[k];
    }
    return U_OK;
}

ErrorType UFileName::InsertBeforeExtension(const char* Insert, const char* Insert2)
{
    if( (Insert ==NULL || Insert [0]==0) &&
        (Insert2==NULL || Insert2[0]==0)) return U_OK;

    if(FullFileName==NULL)
    {
        *this = UFileName(Insert);
        if(FullFileName) return U_OK;
        return U_ERROR;
    }

    size_t      nbytes  = strlen(FullFileName);
    if(Insert ) nbytes += strlen(Insert ) + 4;
    if(Insert2) nbytes += strlen(Insert2) + 4;

    char *NewFileName = new char[nbytes];
    if(NewFileName==NULL) return U_ERROR;
    memset(NewFileName, 0, nbytes);
    strcat(NewFileName, FullFileName);

    int ioff = GetExtensionOffset();
    if(ioff>0)
    {
        NewFileName[ioff] = 0;
        if(Insert ) strcat(NewFileName, Insert );
        if(Insert2) strcat(NewFileName, Insert2);

        size_t      Ninsert  = 0;
        if(Insert ) Ninsert += strlen(Insert);
        if(Insert2) Ninsert += strlen(Insert2);

        for(size_t kk=ioff; kk<strlen(FullFileName); kk++) NewFileName[kk+Ninsert] = FullFileName[kk];
    }
    else
    {
        if(Insert ) strcat(NewFileName, Insert);
        if(Insert2) strcat(NewFileName, Insert2);
    }

    delete[] FullFileName;
    FullFileName = NewFileName;
    return U_OK;
}

ErrorType UFileName::InsertFileNumber(int Number, int Ndigits)
{
    if(Ndigits<0) Ndigits = -Ndigits;
    if(Ndigits>9) Ndigits = 9;

    char format[20];
    sprintf(format,"_%c%d.%d%c",'%',Ndigits,Ndigits,'d');
    char string[20];
    sprintf(string,format,Number);
    return InsertBeforeExtension(string);
}

ErrorType UFileName::ReplaceBaseName(const char* NewBaseName)
{
    if(FullFileName==NULL)
    {
        *this = UFileName(NewBaseName);
        if(FullFileName) return U_OK;
        return U_ERROR;
    }

    int ioff = GetBaseNameOffset();
    if(NewBaseName==NULL || NewBaseName[0]==0)
    {
        if(ioff>0) FullFileName[ioff] = 0;
        return U_OK;
    }

    size_t nbytes     = strlen(FullFileName) + strlen(NewBaseName) + 4;

    char *NewFileName = new char[nbytes];
    if(NewFileName==NULL) return U_ERROR;
    memset(NewFileName, 0, nbytes);
    strcat(NewFileName, FullFileName);

    if(ioff>0) NewFileName[ioff] = 0;

    if(IsSlash(NewBaseName[0])==false) strcat(NewFileName, SLASH);
    strcat(NewFileName, NewBaseName);

    delete[] FullFileName;
    FullFileName = NewFileName;
    return U_OK;
}


ErrorType UFileName::ReplaceExtension(const char* Ext)
{
    if(this==NULL) return U_ERROR;
    if(FullFileName==NULL)
    {
        *this = UFileName(Ext);
        if(FullFileName) return U_OK;
        return U_ERROR;
    }

    int ioff = GetExtensionOffset();
    if(Ext==NULL || Ext[0]==0)
    {
        if(ioff>0) FullFileName[ioff] = 0;
        return U_OK;
    }

    size_t nbytes     = strlen(FullFileName) + strlen(Ext) + 4;

    char *NewFileName = new char[nbytes];
    if(NewFileName==NULL) return U_ERROR;
    memset(NewFileName, 0, nbytes);
    strcat(NewFileName, FullFileName);

    if(ioff>0) NewFileName[ioff] = 0;

    if(Ext[0]!='.') strcat(NewFileName, ".");
    strcat(NewFileName, Ext);

    delete[] FullFileName;
    FullFileName = NewFileName;
    return U_OK;
}

ErrorType UFileName::AddExtension(const char* Ext)
{
    if(this==NULL) return U_ERROR;
    if(Ext==NULL || Ext[0]==0) return U_OK;

    if(FullFileName==NULL)
    {
        *this = UFileName(Ext);
        if(FullFileName) return U_OK;
        return U_ERROR;
    }

    size_t nbytes     = strlen(FullFileName) + strlen(Ext) + 4;

    char *NewFileName = new char[nbytes];
    if(NewFileName==NULL) return U_ERROR;
    memset(NewFileName, 0, nbytes);
    strcat(NewFileName, FullFileName);

    size_t   lastchar = strlen(FullFileName);  // Do not substract 1
    if(NewFileName[lastchar+1] != '.') NewFileName[lastchar] = '.';
    if(Ext[0]                  != '.') strcat(NewFileName, Ext);
    else                               strcat(NewFileName, Ext+1);

    delete[] FullFileName;
    FullFileName = NewFileName;
    return U_OK;
}

ErrorType UFileName::MergeFileName(const char* FileName)
{
    if(this==NULL) return U_ERROR;
    if(FileName==NULL || FileName[0]==0) return U_OK;

    if(FullFileName==NULL)
    {
        *this = UFileName(FileName);
        if(FullFileName) return U_OK;
        return U_ERROR;
    }

    size_t nbytes     = strlen(FullFileName) + strlen(FileName) + 4;

    char *NewFileName = new char[nbytes];
    if(NewFileName==NULL) return U_ERROR;
    memset(NewFileName, 0, nbytes);
    strcat(NewFileName, FullFileName);

    size_t lastchar = strlen(FullFileName); // Dot not substract 1
    if(IsSlash(NewFileName[lastchar-1])==false) strcat(NewFileName, SLASH);
    if(IsSlash(FileName[0]            )==false) strcat(NewFileName, FileName);
    else                                        strcat(NewFileName, FileName+1);

    delete[] FullFileName;
    FullFileName = NewFileName;
    return U_OK;
}

bool UFileName::HasAnyExtension(void) const
{
    if(this==NULL)         return false;
    if(FullFileName==NULL) return false;
    int ioff = GetExtensionOffset();
    if(ioff<=0) return false;
    if(FullFileName[ioff+1]==0) return false;
    return true;
}

bool UFileName::HasExtension(const char* Ext, bool CaseSensitive) const
{
    if(FullFileName==NULL) return false;

    int ioff = GetExtensionOffset();
    if(ioff<=0)
    {
        if(Ext==NULL || Ext[0]==0 || (Ext[0]=='.'&&Ext[1]==0)) return true;
        return false;
    }

    if(Ext[0]=='.') Ext++;
    return IsStringCompatible(Ext, FullFileName+ioff+1, CaseSensitive);
}

int UFileName::GetNDigitBeforeExtension(void) const
{
    if(FullFileName==NULL) return 0;
    int NDigitUsed   = 0;
    for(int k=-1+GetExtensionOffset(); k>=0; k--)
    {
        if('0'<=FullFileName[k] && FullFileName[k]<='9')
        {
            NDigitUsed++;
            continue;
        }
        break;
    }
    return NDigitUsed;
}

int UFileName::GetNumberBeforeExtension(int DefNum) const
{
    if(FullFileName==NULL) return DefNum;
    int ioff = GetExtensionOffset();
    if(ioff<=1) return DefNum;

    int NDigit = 0;
    for(int k=ioff-1; k>=0; k--)
    {
        if(FullFileName[k]<'0' || '9'<FullFileName[k]) break;
        NDigit++;
    }
    if(NDigit<=0) return DefNum;

    return atoi(FullFileName+ioff-NDigit);
}

ErrorType UFileName::ReplaceNumberBeforeExtension(int Number, int NDigit)
{
    if(FullFileName==NULL || GetNumberBeforeExtension(-10)<0)
    {
        CI.AddToLog("ERROR: UFileName::ReplaceNumberBeforeExtension(). File is not numbered: %s \n", FullFileName);
        return U_ERROR;
    }
    if(Number<0)
    {
        CI.AddToLog("ERROR: UFileName::ReplaceNumberBeforeExtension(). Number must be non-negative, Number = %d . \n", Number);
        return U_ERROR;
    }
    int NumOffset    = GetExtensionOffset();
    int NDigitUsed   = 0;
    for(int k=NumOffset-1; k>=0; k--)
    {
        if('0'<=FullFileName[k] && FullFileName[k]<='9')
        {
            NDigitUsed++;
            continue;
        }
        NumOffset = k+1;
        break;
    }

    if(NDigit<0) NDigit = NDigitUsed;
    char format[20];
    if(NDigit==0)       sprintf(format,"%c%c"     ,'%','d');
    else                sprintf(format,"%c%d.%d%c",'%',NDigit,NDigit,'d');

    char NumString[200];
    int   NDigitOut  = sprintf(NumString,format,Number);
    size_t   nbytes  = 2 + NDigitOut  + strlen(FullFileName);
    char* NewName    = new char[nbytes];

    if(NewName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::ReplaceNumberBeforeExtension(). Memory allocation (nbytes=%d). \n", int(nbytes));
        return U_ERROR;
    }
    memset(NewName, 0, nbytes);

    for(int k=        0; k<NumOffset          ; k++) NewName[k] = FullFileName[k];
    for(int k=NumOffset; k<NumOffset+NDigitOut; k++) NewName[k] = NumString[k-NumOffset];
    strcat(NewName, ".");
    strcat(NewName, GetExtension());
    delete[] FullFileName;  FullFileName = NewName;

    return U_OK;
}


bool UFileName::IsPureFile(void) const
/*
    Return true iff FullFileName does not contain any slashes and the second character
    is not equal to ':'
 */
{
    if(FullFileName==NULL) return true;

    if(FullFileName[1]==':') return false;
    for(unsigned int k=0; k<strlen(FullFileName); k++)
        if(IsSlash(FullFileName[k])) return false;

    return true;
}

bool UFileName::IsEmpty(void) const
{
    if(FullFileName==NULL) return true;
    if(FullFileName[0]==0) return true;
    return false;
}

bool UFileName::IsFullFileNameCompatible(const char* FileDescr) const
/*
     Return true iff FullFileName is compatible with the file description FileDescr[]
 */
{
    if(FullFileName==NULL || FileDescr==NULL) return true;

    UString S1(FullFileName);
    UString S2(FileDescr);
    S1.ReplaceAll('/','\\');
    S2.ReplaceAll('/','\\');
    return IsStringCompatible(S1, S2, false);
}

bool UFileName::IsBaseFileNameCompatible(const char* FileDescr) const
/*
     Return true iff FullFileName is compatible with the file description FileDescr[]
 */
{
    if(FullFileName==NULL || FileDescr==NULL) return true;

    return IsStringCompatible(GetBaseName(), FileDescr, false);
}

bool UFileName::DoesBaseFileNameEndWith(const char* FileEnd) const
{
    if(this==NULL) return false;
    if(FullFileName==NULL || FileEnd==NULL) return false;

    const char* Base = GetBaseName();
    size_t      LenB = strlen(Base);
    size_t      LenE = strlen(FileEnd);
    size_t      LenX = 0;
    if(GetExtension()) LenX = strlen(GetExtension())+1;
    if(LenE>LenB) return false;

    size_t   Nbyte       = strlen(FileEnd)+2;
    char*    FileEndWild = new char[Nbyte];
    if(FileEndWild==NULL) return false;

    memset(FileEndWild, 0, Nbyte);
    strcat(FileEndWild, FileEnd);
    strcat(FileEndWild, "*");

    bool Ends = IsStringCompatible(Base+LenB-LenE-LenX, FileEndWild, false);
    delete[] FileEndWild;

    return Ends;
}
bool UFileName::DoesBaseFileNameStartWith(const char* FileStart) const
{
    if(this==NULL) return false;
    if(FullFileName==NULL || FileStart==NULL) return false;

    const char* Base = GetBaseName();
    return IsStringBeginning(Base, FileStart, false);
}

bool UFileName::DoesFileExist(void) const
/*
     Returns true iff FileName[] exists and can be opened.
 */
{
    if(this==NULL || FullFileName==NULL) return false;
    if(FullFileName[0]==0)               return false;

    FILE* fp = fopen(FullFileName,"rb");
    if(!fp) return false;
    fclose(fp);
    return true;
}
bool UFileName::HasFileHeader(const char* HeaderTest) const
{
    if(this==NULL || FullFileName==NULL) return false;
    if(FullFileName[0]==0)               return false;
    if(HeaderTest==NULL)                 return false;

    FILE* fp = fopen(FullFileName,"rb");
    if(!fp) return false;

    size_t NB = strlen(HeaderTest);
    for(int n=0; n<NB; n++) 
    {
        char c = 0; fread(&c,1,1,fp);
        if(c!=HeaderTest[n]) 
        {
            fclose(fp);
            return false;
        }
    }
    fclose(fp);
    return true;
}

// private functions


UFileName::FileStat UFileName::UpdateStatus(void) const
{
    if(FullFileName==NULL || FullFileName[0]==0) return U_FILE_NOSTAT;

    FILE* fp = fopen(FullFileName,"rb");
    if(fp)
    {
        fclose(fp);
        return U_FILE_CANBEREAD;
    }
    fp = fopen(FullFileName,"w");
    if(fp)
    {
        fclose(fp);
        return U_FILE_CANBECREATED;
    }
    return U_FILE_CANNOTBECREATED;
}

int UFileName::GetExtensionOffset(void) const
{
    if(this==NULL || FullFileName==NULL) return -1;

    if(strlen(FullFileName)==0) return -1;

    for(size_t k=strlen(FullFileName); k>0; k--)  // Do not substract 1
    {
        if(IsSlash(FullFileName[k-1])) return -1;
        if(FullFileName[k-1]==   '.' ) return  int(k-1);
    }
    return -1;
}

int UFileName::GetBaseNameOffset(void) const
{
    if(this==NULL || FullFileName==NULL) return -1;

    if(strlen(FullFileName)==0) return -1;

    for(size_t k=strlen(FullFileName); k>0; k--)
        if(IsSlash(FullFileName[k-1])) return int(k-1);

    return -1;
}

UDirectory UFileName::GetRelDir(const UDirectory *Dir) const
/*
    Return a pointer to that part of the FullFileName string, that is
    unequal to the directory name of Dir.

    The default UDirectory is returned on error, or
    the directory name of *Dir is not equal to the first characters of FullFileName[]
 */
{
    if(Dir==NULL) return UDirectory();
    if(FullFileName==NULL) return UDirectory();

    const char* DirName = Dir->GetDirectoryName();
    size_t     len      = strlen(DirName);
    if(len>strlen(FullFileName)) return UDirectory();

    if(len>0)  // Do not substract 1 if len==0
    {
        for(size_t k=0; k<len-1; k++) 
        {
            if(IsSlash(FullFileName[k]) && IsSlash(DirName[k])) continue;
            if(FullFileName[k]!=DirName[k]) return UDirectory();
        }
    }
    UFileName F(FullFileName+len);
    return F.GetDirectory();
}

ErrorType UFileName::CopyFile(const char* NewFileName) const
{
    if(this==NULL || FullFileName==NULL || FullFileName[0]==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CopyFile(). File name NULL or erroneous .\n");
        return U_ERROR;
    }
    if(this->DoesFileExist()!=true)
    {
        CI.AddToLog("ERROR: UFileName::CopyFile(). File does not exist %s .\n", FullFileName);
        return U_ERROR;
    }
    if(NewFileName==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CopyFile(). Invalid NULL argument.\n");
        return U_ERROR;
    }
    FILE* fpOut = fopen(NewFileName, "wb");
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UFileName::CopyFile(). File cannot be created: %s.\n", NewFileName);
        return U_ERROR;
    }
    const int BUFFERSIZE = 5000;
    char* Buffer = new char[BUFFERSIZE];
    if(Buffer==NULL)
    {
        fclose(fpOut);
        CI.AddToLog("ERROR: UFileName::CopyFile(). Memory allocation (BUFFERSIZE = %d) .\n", BUFFERSIZE);
        return U_ERROR;
    }
    FILE* fpIn = fopen(FullFileName, "rb");
    if(fpIn==NULL)
    {
        fclose(fpOut);
        delete[] Buffer;
        CI.AddToLog("ERROR: UFileName::CopyFile(). File cannot be opened: %s\n", FullFileName);
        return U_ERROR;
    }
    unsigned int Size  = GetFileSize();
    unsigned int NTodo = Size;
    while(1)
    {
        if(NTodo<=BUFFERSIZE)
        {
            fread (Buffer, 1, NTodo, fpIn );
            fwrite(Buffer, 1, NTodo, fpOut);
            break;
        }
        fread (Buffer, 1, BUFFERSIZE, fpIn );
        fwrite(Buffer, 1, BUFFERSIZE, fpOut);
        NTodo -= BUFFERSIZE;
    }
    fclose(fpIn );
    fclose(fpOut);
    delete[] Buffer;

    return U_OK;
}

unsigned int UFileName::GetFileSize(void) const
/*
    Return the size of the file in bytes. Return -1 iof the file cannot be opened
 */
{
    FILE *fp = fopen(*this, "rb", false);
    if(fp==NULL) return -1;

    unsigned int Size = ::GetFileSize(fp);
    fclose(fp);
    return Size;
}

FILE* fopen(UFileName F, const char* mode, bool LogError)
{
    if(F.GetFullFileName()==NULL)
    {
        if(LogError==true)
            CI.AddToLog("ERROR: fopen(): Cannot open NULL file.\n");
        return NULL;
    }
    if(*(F.GetFullFileName())==0)
    {
        if(LogError==true)
            CI.AddToLog("ERROR: fopen(): Cannot open Empty file name.\n");
        return NULL;
    }
    FILE *fp = fopen(F.GetFullFileName(), mode);
    if(fp==NULL && LogError==true)
    {
        CI.AddToLog("ERROR: fopen(): Cannot open file: %s:", F.GetFullFileName());

        switch(F.GetStatus())
        {
        case UFileName::U_FILE_NOSTAT:
            CI.AddToLog("cause unknown. \n");
            break;
        case UFileName::U_FILE_CANBEREAD:
            CI.AddToLog("file can be read. \n");
            break;
        case UFileName::U_FILE_CANBECREATED:
            CI.AddToLog("file can be created. \n");
            break;
        case UFileName::U_FILE_CANNOTBECREATED:
            CI.AddToLog("file can not be created. \n");
            break;
        }
    }
    return fp;
}

bool  DoesFileExist(UFileName F)
{
    return DoesFileExist(F.GetFullFileName());
}

int GetFileNameOrder(const UFileName* F1, const UFileName* F2)
{
    if(F1==NULL && F2==NULL) return  0;
    if(F1==NULL)             return -1;
    if(F2==NULL)             return  1;
    if(F1->FullFileName==NULL && F2->FullFileName==NULL) return  0;
    if(F1->FullFileName==NULL                          ) return -1;
    if(F2->FullFileName==NULL                          ) return  1;

    size_t N1 = strlen(F1->FullFileName);
    size_t N2 = strlen(F2->FullFileName);
    size_t N = MIN(N1, N2);

    for(size_t k=0; k<N; k++)
    {
        char C1 = F1->FullFileName[k];
        char C2 = F2->FullFileName[k];
        if(UFileName::IsSlash(C1) &&     UFileName::IsSlash(C2) )  continue;
        if(UFileName::IsSlash(C1) && NOT(UFileName::IsSlash(C2))) -1;
        if(UFileName::IsSlash(C2) && NOT(UFileName::IsSlash(C1)))  1;

        C1 = UFileName::ToLowerCase(C1);
        C2 = UFileName::ToLowerCase(C2);
        if(C1==C2) continue;
        if(C1 <C2) return -1;
        if(C1 >C2) return  1;
    }
    if(N1<N2) return -1;
    if(N1>N2) return  1;

    return 0;
}

int UFileName::GetNLines(void) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetNLines(). this==NULL.\n");
        return 0;
    }
    FILE* fp = fopen(FullFileName, "rb", false);
    if (fp == NULL)
    {
        CI.AddToLog("ERROR: UFileName::GetNLines(). File does not exist: %s .\n", FullFileName?FullFileName:"NULL");
        return 0;
    }
    int NLines = ::GetNLines(fp);
    fclose(fp);
    return NLines;
}

ErrorType DLL_IO CopyFile(UFileName Ffrom, UFileName Fto)
{
    if(DoesFileExist(Ffrom)==false)
    {
        CI.AddToLog("ERROR: CopyFile(). File does not exists (%s). \n", PMT_CCP(Ffrom));
        return U_ERROR;
    }
    if(DoesFileExist(Fto)==true)
        CI.AddToLog("WARNING: CopyFile(). File already exists (%s). File replaced by %s \n", PMT_CCP(Fto), PMT_CCP(Ffrom));
    
    FILE* fpin = fopen(Ffrom, "rb");
    FILE* fpot = fopen(Fto, "wb");
    if(fpin==NULL||fpot==NULL)
    {
        if(fpin) fclose(fpin);
        if(fpot) fclose(fpot);
        CI.AddToLog("ERROR: CopyFile(). Creating output file:  %s. \n", PMT_CCP(Fto));
        return U_ERROR;
    }

    int   NB  = GetFileSize(fpin);
    char* Buf = new char[MAX(1, NB)];
    if(Buf==NULL)
    {
        fclose(fpin); fclose(fpot);
        CI.AddToLog("ERROR: CopyFile(). Memory allocation, NB = %d. \n", NB);
        return U_ERROR;
    }
    if(NB>0)  fread(Buf, 1, NB, fpin);
    if(NB>0)  fwrite(Buf, 1, NB, fpot);
    delete[] Buf;
    fclose(fpot);
    fclose(fpin);
    return U_OK;
}

