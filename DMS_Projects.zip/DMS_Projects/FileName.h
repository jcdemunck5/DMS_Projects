#ifndef _FILENAM_INCLUDED
#define _FILENAM_INCLUDED

#include"BasicInclude.h"
#include"Directory.h"

class DLL_IO UFileName : public UDirFileName
{
friend int DLL_IO GetFileNameOrder(const UFileName*, const UFileName*);
public:
    enum FileStat  {U_FILE_NOSTAT,          // Status can not be determined, or error
                    U_FILE_CANBEREAD,       // File can be read
                    U_FILE_CANBECREATED,    // File can be created
                    U_FILE_CANNOTBECREATED};// File can not be created
                    
    UFileName();
    UFileName(const UFileName* Fnam, const char*BaseName, const char *Ext=NULL);
    UFileName(const UFileName& Fnam, const char*BaseName, const char *Ext=NULL);
    UFileName(const UDirectory* Dir, const char*BaseName, const char *Ext=NULL);
    UFileName(const UDirectory& Dir, const char*BaseName, const char *Ext=NULL);
    UFileName(const UDirectory& Dir, const UFileName& Fnam);
    UFileName(const char *DirName, const char*BaseName, const char *Ext=NULL);
    UFileName(const char *FileName);
    UFileName(const UFileName& F);

    ~UFileName();

    UFileName& operator=(const UFileName &F);
    bool       operator==(const UFileName &F) const; 
    bool       operator!=(const UFileName &F) const; 
    operator const char*() const {return FullFileName;}

    ErrorType          RemoveFile(void) const;
    ErrorType          RenameFile(const char* NewFileName) const;
    ErrorType          CopyFile(const char* NewFileName) const;
    FileStat           GetStatus(void)        const {return UpdateStatus(); }
    unsigned int       GetFileSize(void)      const;
    const char*        GetFullFileName(void)  const {return FullFileName; }
    const char*        GetBaseName(void)      const;
    const char*        GetExtension(void)     const;
    
    UDirectory         GetDirectory(void)     const;
    UDirectory         GetRelDir(const UDirectory *Dir) const;

    UFileName          GetSiblingFileName(const char* BaseName) const;

    ErrorType          InsertBeforeExtension(const char* Insert, const char* Insert2=NULL);
    ErrorType          InsertFileNumber(int Number, int Ndigits);
    ErrorType          MergeFileName(const char* FileName);
    ErrorType          ReplaceBaseName(const char* NewBaseName);
    ErrorType          ReplaceNumberBeforeExtension(int Number, int NDigit);
    ErrorType          RemoveDirectory(const UDirectory& Dir);

    bool               HasAnyExtension(void) const;
    ErrorType          ReplaceExtension(const char* Ext);
    ErrorType          SetExtension(const char* Ext) {return ReplaceExtension(Ext);}
    ErrorType          RemoveExtension(void)         {return ReplaceExtension(NULL);}

    ErrorType          AddExtension(const char* Ext);
    bool               HasExtension(const char* Ext, bool CaseSensitive=true) const;
    int                GetNumberBeforeExtension(int DefNum=-1) const;
    int                GetNDigitBeforeExtension(void) const;

    bool               IsEmpty(void) const;
    bool               IsPureFile(void) const;
    bool               IsFullFileNameCompatible(const char* FileDescr) const;
    bool               IsBaseFileNameCompatible(const char* FileDescr) const;
    bool               DoesBaseFileNameEndWith(const char* FileEnd) const;
    bool               DoesBaseFileNameStartWith(const char* FileStart) const;
    bool               DoesFileExist(void) const;
    bool               HasFileHeader(const char* HeaderTest) const;
    int                GetNLines(void) const;

private:
    char               *FullFileName;           // Full name of the file, including drive and directory
    
    FileStat           UpdateStatus() const;
    int                GetExtensionOffset(void) const;
    int                GetBaseNameOffset(void) const;
};

PMT_FILEP DLL_IO fopen(UFileName F,const char* mode, bool LogError);
bool      DLL_IO DoesFileExist(UFileName F);
int       DLL_IO GetFileNameOrder(const UFileName* F1, const UFileName* F2);
ErrorType DLL_IO CopyFile(UFileName Ffrom, UFileName Fto);

#endif// _FILENAM_INCLUDED
