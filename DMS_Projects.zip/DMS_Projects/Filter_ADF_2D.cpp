/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**
Date 17-06-2016
**/


#include "BasicInclude.h"
#include<string.h>

////#include "stdafx.h"
#define _USE_MATH_DEFINES // for C++
#include <cmath>
#include "float.h"

#define FILTER_MEAN               1
#define FILTER_VARIANCE           2
////enum ErrorType    {U_OK=0,U_ERROR=-1};  // General OK/ERROR flag.

void InitialBuffer_Int(int* buffer, int iValue, int iLength)
{
	if (buffer == NULL)
	{
		return;
	}
	for (int i = 0; i < iLength; i++)
	{
		buffer[i] = iValue;
	}
}


ErrorType GetNeighbors2D(int x, int y, int rx, int ry, int iHeight, int iWidth, int* neighbors)
{
	if (neighbors == NULL)
	{
		return U_ERROR;
	}
	//the zLength, height and width of the neighborhood
	int iHeightOut = 2 * ry + 1, iWidthOut = 2 * rx + 1;
	//the boundary and interior of the image to be copy
	int iXMin = x - rx;
	int iXMax = iXMin + iWidthOut;
	int iYMin = y - ry;
	int iYMax = iYMin + iHeightOut;

	//copy data
	for (int vIndex = iYMin, iyNeighbor = 0; vIndex <= iYMax - 1; vIndex++, iyNeighbor++)
	{
		int iOffsetY = vIndex * iWidth;
		int iOffsetYOut = iyNeighbor * iWidthOut;
		for (int hIndex = iXMin, ixNeighbor = 0; hIndex <= iXMax - 1; hIndex++, ixNeighbor++)
		{
			if (vIndex < 0 || hIndex < 0 || vIndex >= iHeight || hIndex >= iWidth)
			{
				neighbors[iOffsetYOut + ixNeighbor] = -1;
			}
			else
			{
				neighbors[iOffsetYOut + ixNeighbor] = iOffsetY + hIndex;
			}

		}
	}

	return U_OK;
}


ErrorType ConvertToCertainLevel_Float(float* pImageData, int iLength, float iMin, float iMax)
{
	if (pImageData == NULL || iMin >= iMax)
	{
		return U_ERROR;
	}
	double tmpMax = pImageData[0];
	double tmpMin = pImageData[0];
	for (int i = 0; i < iLength; i++)
	{
		if (pImageData[i] < tmpMin)
		{
			tmpMin = pImageData[i];
		}
		if (pImageData[i] > tmpMax)
		{
			tmpMax = pImageData[i];
		}
	}

	//convert
	for (int i = 0; i < iLength; i++)
	{
		pImageData[i] = (float)((pImageData[i] - tmpMin) * (iMax - iMin) / (tmpMax - tmpMin) + iMin);
	}

	return U_OK;
}

ErrorType getLineSums(float* cache, int kRadius, int xCache0, double* sums)
{     
    if(sums==NULL)
    {
        return U_ERROR;
    }
    double sum=0, sum2=0;          
    for (int x=xCache0-kRadius, iCache=x; x<=xCache0+kRadius; x++, iCache++) 
    {                 
        float v = cache[iCache];                 
        sum += v;                
        sum2 += v*v;             
    }         
           
    sums[0] = sum;         
    sums[1] = sum2;         
    return U_OK;     
} 

/** Add all values and values squared at the right border inside minus at the left border outside the kernal line.      
 *  Output is added or subtracted to/from array sums[0] += sum; sums[1] += sum of squares  when at       
 *  the right border, minus when at the left border */     
ErrorType addLineSideSums(float* cache, int kRadius, int xCache0, double* sums) 
{     
    if(sums==NULL)
    {
        return U_ERROR;
    }
    double sum=0, sum2=0;              
    int iCache0 = xCache0;//the center of the neighborhood        
    float v = cache[iCache0 + kRadius];             
    sum += v;             
    sum2 += v*v;             
    v = cache[iCache0 - kRadius - 1];         
    sum -= v;             
    sum2 -= v*v;             
    sums[0] += sum;         
    sums[1] += sum2;         
    return U_OK;
}  


ErrorType doFiltering1D(int kRadius, int filterType, float* dataIn, int dir, int iWidth, int iHeight, int iZLength, bool bMean, int NPoint) 
{
	if(dataIn==NULL)
	{
		return U_ERROR;
	}         
	bool sumFilter = filterType == FILTER_MEAN || filterType == FILTER_VARIANCE;
	double sums[2] = {0.0 ,0.0}; 
	// output pixel array;
	int iLength = iWidth * iHeight * iZLength;
	int xyLength = iWidth * iHeight;
	float* pixels2 = new float[iLength];
	memset(pixels2, 0, sizeof(float) * iLength);
	// input pixel array 
	float* pixels1 = dataIn;        
	if (pixels1==NULL) pixels1 = pixels2;
	//the size of the padded image
	int iMin = 0 - kRadius;         
	int iEnd = iWidth;
	switch(dir)
	{
	case 0 :
		iEnd = iWidth;
		break;
	case 1 : 
		iEnd = iHeight;
		break;
	case 2 : 
		iEnd = iZLength;
		break;
	default:
		break;
	}
	int iMax = iEnd + kRadius;
	//the size of the neighborhood
	int kSize = 2*kRadius + 1;
	int cacheWidth = iMax - iMin;             
	bool smallKernel = kRadius < 2;
	switch(dir)
	{
	case 0 : 
		for(int z=0; z<iZLength; z++)
		{
			for (int y=0; y<iHeight; y++) 
			{                                                               
				bool fullCalculation = true;//to control the initial step, important
				float* cache = new float[cacheWidth]; //one line
				for(int x=iMin, iCache=0; x<iMax; x++, iCache++)
				{
					int iTmp = x<0?0:x>=iWidth?iWidth-1:x;             
					cache[iCache]=pixels1[z*xyLength+y*iWidth+iTmp];
				}
				for (int x=0, p=x+y*iWidth+z*xyLength, xCache0=kRadius;  x<iEnd; x++, p++, xCache0++) 
				{  
					if (fullCalculation) 
					{                     
						fullCalculation = smallKernel;  //for small kernel, always use the full area, not incremental algorithm                     
						if (sumFilter)                         
							getLineSums(cache, kRadius , xCache0, sums);              
					} 
					else 
					{
						if (sumFilter)                         
							addLineSideSums(cache, kRadius, xCache0, sums);                 
					}                          
					if (sumFilter) 
					{                     
						if (filterType == FILTER_MEAN)
							pixels2[p] = bMean ? (float)(sums[0]/NPoint) : (float)(sums[0]);
						else 
							pixels2[p] = (float)(sums[1]);
					}             
				} // for x
				delete[] cache;
				cache = NULL;
			} // for y 
		} //for z
		break;
	case 1 : 
		for(int z=0; z<iZLength; z++)
		{
			for (int x=0; x<iWidth; x++) 
			{                                                               
				bool fullCalculation = true;//to control the initial step, important
				float* cache = new float[cacheWidth]; //one line
				for(int y=iMin, iCache=0; y<iMax; y++, iCache++)
				{
					int iTmp = y<0?0:y>=iHeight?iHeight-1:y;             
					cache[iCache]=pixels1[z*xyLength+iTmp*iWidth+x];
				}
				for (int y=0, p=x+y*iWidth+z*xyLength, yCache0=kRadius;  y<iEnd; y++, p = p + iWidth, yCache0++) 
				{  
					if (fullCalculation) 
					{                     
						fullCalculation = smallKernel;  //for small kernel, always use the full area, not incremental algorithm                     
						if (sumFilter)                         
							getLineSums(cache, kRadius , yCache0, sums);              
					} 
					else 
					{
						if (sumFilter)                         
							addLineSideSums(cache, kRadius, yCache0, sums);                 
					}                          
					if (sumFilter) 
					{                     
						if (filterType == FILTER_MEAN)
							pixels2[p] = bMean ? (float)(sums[0]/NPoint) : (float)(sums[0]);
						else 
							pixels2[p] = (float)(sums[1]);
					}             
				} // for x
				delete[] cache;
				cache = NULL;
			} // for y 
		} //for z
		break;
	case 2 : 
		for (int y=0; y<iHeight; y++) 
		{
			for (int x=0; x<iWidth; x++) 
			{                                                               
				bool fullCalculation = true;//to control the initial step, important
				float* cache = new float[cacheWidth]; //one line
				for(int z=iMin, iCache=0; z<iMax; z++, iCache++)
				{
					int iTmp = z<0?0:z>=iZLength?iZLength-1:z;             
					cache[iCache]=pixels1[iTmp*xyLength+y*iWidth+x];
				}
				for (int z=0, p=x+y*iWidth+z*xyLength, zCache0=kRadius;  z<iEnd; z++, p = p + xyLength, zCache0++) 
				{  
					if (fullCalculation) 
					{                     
						fullCalculation = smallKernel;  //for small kernel, always use the full area, not incremental algorithm                     
						if (sumFilter)                         
							getLineSums(cache, kRadius , zCache0, sums);              
					} 
					else 
					{
						if (sumFilter)                         
							addLineSideSums(cache, kRadius, zCache0, sums);                 
					}                          
					if (sumFilter) 
					{                     
						if (filterType == FILTER_MEAN)
							pixels2[p] = bMean ? (float)(sums[0]/NPoint) : (float)(sums[0]);
						else 
							pixels2[p] = (float)(sums[1]);
					}             
				} // for x
				delete[] cache;
				cache = NULL;
			} // for y 
		} //for z
		break;
	default:break;
	}

	memcpy(dataIn, pixels2, sizeof(float) * iLength);
	delete[] pixels2;
	pixels2 = NULL;
	return U_OK;
} 

ErrorType Mean_Filtering2D(int xRadius, int yRadius, float* dataIn, int iWidth, int iHeight) 
{
	int nPoint = (xRadius * 2 + 1) * (yRadius * 2 + 1);
	if(doFiltering1D(xRadius, FILTER_MEAN, dataIn, 0, iWidth, iHeight, 1, false, 1) == U_ERROR)
	{
		return U_ERROR;
	}
	if(doFiltering1D(yRadius, FILTER_MEAN, dataIn, 1, iWidth, iHeight, 1, true, nPoint) == U_ERROR)
	{
		return U_ERROR;
	}
	return U_OK;
}

//higher order statistics
ErrorType CalculateHOS_2D(float* diffusedImage, int iHeight, int iWidth, int n, int iRadius)
{
	ErrorType eResult = U_ERROR;
	if (diffusedImage == NULL || iRadius <= 0)
	{
		return eResult;
	}
	int iLength = iHeight * iWidth;

	float* mean = new float[iLength];
	memcpy(mean, diffusedImage, sizeof(float) * iLength);

	Mean_Filtering2D(iRadius, iRadius, mean, iWidth, iHeight);

	int iLengthNeighbor = iRadius * 2 + 1;
	iLengthNeighbor = iLengthNeighbor * iLengthNeighbor;
	int* neighbor = new int[iLengthNeighbor];
	double iDiff = 0.0;
	for (int i = 0; i < iLength; i++)
	{
		int x = i % iWidth;
		int y = i / iWidth;
		InitialBuffer_Int(neighbor, -1, iLengthNeighbor);
		GetNeighbors2D(x, y, iRadius, iRadius, iHeight, iWidth, neighbor);
		iDiff = 0; 
		for (int j = 0; j < iLengthNeighbor; j++)
		{
			if (neighbor[j] < 0)
			{
				continue;
			}
			double iDiffTmp = abs(diffusedImage[neighbor[j]] - mean[i]);
			iDiff += pow(iDiffTmp, n);
		}
		iDiff /= iLengthNeighbor;
		mean[i] = (float) iDiff;
	}

	delete[] neighbor;
	neighbor = NULL;
	memcpy(diffusedImage, mean, sizeof(float) * iLength);
	delete[] mean;
	mean = NULL;
	return eResult;
}


void convolveLine(float* input, int length, float* pixels, float** kernel, int kRadius, int point0, int pointInc) 
{
	float first = input[0];                 //out-of-edge pixels are replaced by nearest edge pixels
	float last = input[length-1];
	float* kern = kernel[0];               //the kernel itself
	float kern0 = kern[0];
	float* kernSum = kernel[1];            //the running sum over the kernel
	int firstPart = kRadius < length ? kRadius : length;
	int p = point0;
	int i = 0;
	for (; i<firstPart; i++,p+=pointInc) {  //while the sum would include pixels < 0
		float result = input[i]*kern0;
		result += kernSum[i]*first;
		if (i+kRadius>length) result += kernSum[length-i-1]*last;
		for (int k=1; k<kRadius; k++) {
			float v = 0;
			if (i-k >= 0) v += input[i-k];
			if (i+k<length) v+= input[i+k];
			result += kern[k] * v;
		}
		pixels[p] = result;
	}
	int iEndInside = length-kRadius;
	for (;i<iEndInside;i++,p+=pointInc) {   //while only pixels within the line are be addressed (the easy case)
		float result = input[i]*kern0;
		for (int k=1; k<kRadius; k++)
			result += kern[k] * (input[i-k] + input[i+k]);
		pixels[p] = result;
	}
	for (; i<length; i++,p+=pointInc) {    //while the sum would include pixels >= length 
		float result = input[i]*kern0;
		if (i<kRadius) result += kernSum[i]*first;
		if (i+kRadius>=length) result += kernSum[length-i-1]*last;
		for (int k=1; k<kRadius; k++) {
			float v = 0;
			if (i-k >= 0) v += input[i-k];
			if (i+k<length) v+= input[i+k];
			result += kern[k] * v;
		}
		pixels[p] = result;
	}
}

float** makeGaussianKernel(double sigma, double accuracy, int maxRadius, int* iGaussKernelLength) 
{
	int kRadius = (int)ceil(sigma*sqrt(-2*log(accuracy)))+1;
	if (maxRadius < 50) maxRadius = 50;         // too small maxRadius would result in inaccurate sum.
	if (kRadius > maxRadius) kRadius = maxRadius;
	*iGaussKernelLength = kRadius;
	float** kernel = new float*[2];
	for (int i = 0; i < 2; i ++)
	{
		kernel[i] = new float[kRadius];
	}
	for (int i=0; i<kRadius; i++)               // Gaussian function
	{
		kernel[0][i] = (float)(exp(-0.5*i*i/sigma/sigma));
	}
	if (kRadius < maxRadius && kRadius > 3) {   // edge correction
		double sqrtSlope = DBL_MAX;
		int r = kRadius;
		while (r > kRadius/2) {
			r--;
			double a = sqrt(kernel[0][r])/(kRadius-r);
			if (a < sqrtSlope)
				sqrtSlope = a;
			else
				break;
		}
		for (int r1 = r+2; r1 < kRadius; r1++)
			kernel[0][r1] = (float)((kRadius-r1)*(kRadius-r1)*sqrtSlope*sqrtSlope);
	}
	double sum;                                 // sum over all kernel elements for normalization
	if (kRadius < maxRadius) {
		sum = kernel[0][0];
		for (int i=1; i<kRadius; i++)
			sum += 2*kernel[0][i];
	} else
		sum = sigma * sqrt(2 * M_PI);

	double rsum = 0.5 + 0.5*kernel[0][0]/sum;
	for (int i=0; i<kRadius; i++) {
		double v = (kernel[0][i]/sum);
		kernel[0][i] = (float)v;
		rsum -= v;
		kernel[1][i] = (float)rsum;
	}
	return kernel;
}


ErrorType GaussianBlur1D(float* pixels, int width, int height, double sigma, double accuracy, bool xDirection)
{      
	int UPSCALE_K_RADIUS = 2;                     //number of pixels to add for upscaling
	if (pixels == NULL)
	{
		return U_ERROR;
	}
	int length = xDirection ? width : height;     //number of points per line (line can be a row or column)
	int pointInc = xDirection ? 1 : width;        //increment of the pixels array index to the next point in a line
	int lineInc = xDirection ? width : 1;         //increment of the pixels array index to the next line
	int lineFrom = 0;//the first line to process
	int lineTo = xDirection ? height : width; //the last line+1 to process
	int writeFrom = xDirection? 0 : 0;    //first point of a line that needs to be written
	int writeTo = xDirection ? width : height;

	int numThreads = lineTo-lineFrom;

	int maxLength = length; //downscaled line can't be longer

	int iGaussKernelLength = 0;
	float** gaussKernel = makeGaussianKernel(sigma, accuracy, maxLength, &iGaussKernelLength);
	int kRadius = iGaussKernelLength;
	int readFrom = 0;
	int readTo = length;    

	for ( int t = 0; t < numThreads; ++t ) 
	{
		float* cache1 = new float[length];  //holds data before convolution
		int pixel0 = (lineFrom+t)*lineInc;
		int p = pixel0 + readFrom*pointInc;
		for (int i=readFrom; i<readTo; i++ ,p+=pointInc)
			cache1[i] = pixels[p];
		convolveLine(cache1, length, pixels, gaussKernel, iGaussKernelLength, pixel0, pointInc);
		delete[] cache1;
		cache1 = NULL;
	}   

	//to delete gaussKernel
	for(int i = 0; i < 2; i++)
	{
		delete[] gaussKernel[i];
		gaussKernel[i] = NULL;
	}
	delete[] gaussKernel;
	gaussKernel = NULL;
	return U_OK;
}


ErrorType GaussianBlur2D(float* imageData, int iWidth, int iHeight, double sigmaX, double sigmaY, double accuracy) 
{
	if (imageData == NULL)
	{
		return U_ERROR;
	}
	if (sigmaX > 0)
	{
		if(GaussianBlur1D(imageData, iWidth, iHeight, sigmaX, accuracy, true) == U_ERROR)
		{           
			return U_ERROR;
		}
	}
	if (sigmaY > 0)
	{
		if(GaussianBlur1D(imageData, iWidth, iHeight, sigmaY, accuracy, false) == U_ERROR)
		{
			return U_ERROR;
		}
	}
	return U_OK;
}


ErrorType GradientVector2D_Center(float* imageDataIn, float** gradient, int iHeight, int iWidth)
{
	if (imageDataIn == NULL || gradient == NULL)
	{
		return U_ERROR;
	}
	float* imageX = gradient[0];
	float* imageY = gradient[1];

	if (imageX == NULL || imageY == NULL)
	{
		return U_ERROR;
	}

	for (int y = 0; y < iHeight; y++ )
	{
		int offsetY = y * iWidth;
		for (int x = 0; x < iWidth; x++)
		{
			int offsetX = x + offsetY;
			imageX[offsetX] = (imageDataIn[x == iWidth - 1 ? offsetX : offsetX + 1] - imageDataIn[x == 0 ? offsetX : offsetX - 1]) / 2.0f;
			imageY[offsetX] = (imageDataIn[y == iHeight - 1 ? offsetX : offsetX + iWidth] - imageDataIn[y == 0 ? offsetX : offsetX - iWidth]) / 2.0f;
		}
	}

	return U_OK;
}

ErrorType CalculateHOSDiff(float* HOSnew, float* HOSold, int iLength, double &diff)
{
	if (HOSnew == NULL || HOSold == NULL || iLength <= 0)
	{
		return U_ERROR;
	}
	diff = 0.0;

	for (int i = 0; i < iLength; i++)
	{
		diff += abs(HOSold[i] - HOSnew[i]);
	}

	diff /= iLength;

	return U_OK;
}

//eigenvalue and eigenvector 2 by 2 matrix//http://www.math.harvard.edu/archive/21b_fall_04/exhibits/2dmatrices/index.html
ErrorType EigenCompostition2by2_ForStructureTensor(double A[2][2], double Q[2][2], double w[2])
{
	double a, b, c, d;
	a = A[0][0];
	b = c = A[0][1];
	d = A[1][1];
	double T = a + d;//trace
	double D = a * d - b * c;//the determinant of the matrix
	w[0] = T / 2 + sqrt(T * T / 4 - D);
	w[1] = T - w[0];
	if (b == 0)
	{
		Q[0][0] = 1;
		Q[1][0] = 0;
		Q[0][1] = 0;
		Q[1][1] = 1;

	}
	else
	{
		Q[0][0] = b;
		Q[1][0] = w[0] - a;
		Q[0][1] = b;
		Q[1][1] = w[1] - a;
		//normalize
		double q1 = sqrt(Q[0][0] * Q[0][0] + Q[1][0] * Q[1][0]);
		double q2 = sqrt(Q[0][1] * Q[0][1] + Q[1][1] * Q[1][1]);
		Q[0][0] /= q1;
		Q[1][0] /= q1;
		Q[0][1] /= q2;
		Q[1][1] /= q2;
	}

	return U_OK;
}

float DifferentialOperation_2thOrder(float** tensor, float* u, int iLocation, int i, int j, int x, int y, int z, int iZLength, int iHeight, int iWidth)
/**************************************************************************************************************
    tensor    : 2D -> 3 images, 3D-> 6 images (IxIx, IxIy, IxIz, IyIy, IyIz, IzIz)
    u         : input image
    iLocation : pixel location
    x, y, z   : should be consistent with iLocation
    i         : first tensor index (1, 2, 3) -> (x, y, z) direction
    j         : second tensor index (1, 2, 3) -> (x, y, z) direction
   
   see Weickert (1999), Int J of Comp Vision 31(2/3), 111-127
 **************************************************************************************************************/
{
	float dResult = 0.0f;
	float* dMatrix = NULL;
	int iOffset = iWidth * iHeight;

	if (i == 1 && j == 1)
	{
		dMatrix = tensor[0];
		//int iP1 = (x >= iWidth - 1 ? x : x + 1) + y * iWidth + z * iOffset;
		//int iM1 = (x == 0 ? x : x - 1)  + y * iWidth + z * iOffset;
		//dResult = (dMatrix[iP1] * (u[iP1] - u[iLocation]) - dMatrix[iM1] * (u[iLocation] - u[iM1])) / 4.0f;
		if (x == 0)
		{
			dResult = (dMatrix[iLocation + 1] + dMatrix[iLocation]) * (u[iLocation + 1] - u[iLocation]) / 2.0f;
		}
		else if(x == iWidth - 1)
		{
			dResult = (dMatrix[iLocation - 1] + dMatrix[iLocation]) * (u[iLocation - 1] - u[iLocation]) / 2.0f;
		}
		else
		{
			dResult = ((dMatrix[iLocation + 1] + dMatrix[iLocation]) * (u[iLocation + 1] - u[iLocation]) + (dMatrix[iLocation - 1] + dMatrix[iLocation]) * (u[iLocation - 1] - u[iLocation])) / 2.0f;
		}

	}
	else if(i == 1 && j == 2)
	{
		dMatrix = tensor[1];
		int iP1 = x >= iWidth - 1 ? x : x + 1;
		int iM1 = x == 0 ? x : x - 1;
		int jP1 = y >= iHeight - 1 ? y : y + 1;
		int jM1 = y == 0 ? y : y - 1;

		dResult = (dMatrix[iP1 + y * iWidth + z * iOffset] * (u[iP1 + jP1 * iWidth + z * iOffset] - u[iP1 + jM1 * iWidth + z * iOffset]) - 
			dMatrix[iM1 + y * iWidth + z * iOffset] * (u[iM1 + jP1 * iWidth + z * iOffset] - u[iM1 + jM1 * iWidth + z * iOffset]))/4.0f;

	}
	else if (i == 2 && j == 1)
	{
		dMatrix = tensor[1];
		int iP1 = x >= iWidth - 1 ? x : x + 1;
		int iM1 = x == 0 ? x : x - 1;
		int jP1 = y >= iHeight - 1 ? y : y + 1;
		int jM1 = y == 0 ? y : y - 1;

		dResult = (dMatrix[x + jP1 * iWidth + z * iOffset] * (u[iP1 + jP1 * iWidth + z * iOffset] - u[iM1 + jP1 * iWidth + z * iOffset]) - 
			dMatrix[x + jM1 * iWidth + z * iOffset] * (u[iP1 + jM1 * iWidth + z * iOffset] - u[iM1 + jM1 * iWidth + z * iOffset]))/4.0f;
	}
	else if (i == 1 && j == 3)
	{
		dMatrix = tensor[2];
		int iP1 = x >= iWidth - 1 ? x : x + 1;
		int iM1 = x == 0 ? x : x - 1;
		int kP1 = z >= iZLength - 1 ? z : z + 1;
		int kM1 = z == 0 ? z : z - 1;

		dResult = (dMatrix[iP1 + y * iWidth + z * iOffset] * (u[iP1 + y * iWidth + kP1 * iOffset] - u[iP1 + y * iWidth + kM1 * iOffset]) - 
			dMatrix[iM1 + y * iWidth + z * iOffset] * (u[iM1 + y * iWidth + kP1 * iOffset] - u[iM1 + y * iWidth + kM1 * iOffset]))/4.0f;
	}
	else if (i == 3 && j == 1)
	{
		dMatrix = tensor[2];
		int iP1 = x >= iWidth - 1 ? x : x + 1;
		int iM1 = x == 0 ? x : x - 1;
		int kP1 = z >= iZLength - 1 ? z : z + 1;
		int kM1 = z == 0 ? z : z - 1;

		dResult = (dMatrix[x + y * iWidth + kP1 * iOffset] * (u[iP1 + y * iWidth + kP1 * iOffset] - u[iM1 + y * iWidth + kP1 * iOffset]) - 
			dMatrix[x + y * iWidth + kM1 * iOffset] * (u[iP1 + y * iWidth + kM1 * iOffset] - u[iM1 + y * iWidth + kM1 * iOffset]))/4.0f;
	}
	else if (i == 2 && j == 2)
	{
		dMatrix = tensor[3];
		//int jP1 = (y >= iHeight - 1 ? y : y + 1) * iWidth + x + z * iOffset;
		//int jM1 = (y == 0 ? y : y - 1) * iWidth + x + z * iOffset;
		//dResult = (dMatrix[jP1] * (u[jP1] - u[iLocation]) - dMatrix[jM1] * (u[iLocation] - u[jM1])) / 4.0f;
		if (y == 0)
		{
			dResult = (dMatrix[iLocation + iWidth] + dMatrix[iLocation]) * (u[iLocation + iWidth] - u[iLocation]) / 2.0f;
		}
		else if(y == iHeight - 1)
		{
			dResult = (dMatrix[iLocation - iWidth] + dMatrix[iLocation]) * (u[iLocation - iWidth] - u[iLocation]) / 2.0f;
		}
		else
		{
			dResult = ((dMatrix[iLocation + iWidth] + dMatrix[iLocation]) * (u[iLocation + iWidth] - u[iLocation]) + (dMatrix[iLocation - iWidth] + dMatrix[iLocation]) * (u[iLocation - iWidth] - u[iLocation])) / 2.0f;
		}
	}
	else if (i == 2 && j == 3)
	{
		dMatrix = tensor[4];
		int jP1 = y >= iHeight - 1 ? y : y + 1;
		int jM1 = y == 0 ? y : y - 1;
		int kP1 = z >= iZLength - 1 ? z : z + 1;
		int kM1 = z == 0 ? z : z - 1;

		dResult = (dMatrix[x + jP1 * iWidth + z * iOffset] * (u[x + jP1 * iWidth + kP1 * iOffset] - u[x + jP1 * iWidth + kM1 * iOffset]) - 
			dMatrix[x + jM1 * iWidth + z * iOffset] * (u[x + jM1 * iWidth + kP1 * iOffset] - u[x + jM1 * iWidth + kM1 * iOffset]))/4.0f;
	}
	else if(i == 3 && j == 2)
	{
		dMatrix = tensor[4];
		int jP1 = y >= iHeight - 1 ? y : y + 1;
		int jM1 = y == 0 ? y : y - 1;
		int kP1 = z >= iZLength - 1 ? z : z + 1;
		int kM1 = z == 0 ? z : z - 1;

		dResult = (dMatrix[x + y * iWidth + kP1 * iOffset] * (u[x + jP1 * iWidth + kP1 * iOffset] - u[x + jM1 * iWidth + kP1 * iOffset]) - 
			dMatrix[x + y * iWidth + kM1 * iOffset] * (u[x + jP1 * iWidth + kM1 * iOffset] - u[x + jM1 * iWidth + kM1 * iOffset]))/4.0f;

	}
	else if (i == 3 && j == 3)
	{
		dMatrix = tensor[5];
		//int kP1 = (z >= iZLength - 1 ? z : z + 1) * iOffset + y * iWidth + x;
		//int kM1 = (z == 0 ? z : z - 1) * iOffset  + y * iWidth + x;
		//dResult = (dMatrix[kP1] * (u[kP1] - u[iLocation]) - dMatrix[kM1] * (u[iLocation] - u[kM1])) / 4.0f;
		if (z == 0)
		{
			dResult = (dMatrix[iLocation + iOffset] + dMatrix[iLocation]) * (u[iLocation + iOffset] - u[iLocation]) / 2.0f;
		}
		else if(z == iZLength - 1)
		{
			dResult = (dMatrix[iLocation - iOffset] + dMatrix[iLocation]) * (u[iLocation - iOffset] - u[iLocation]) / 2.0f;
		}
		else
		{
			dResult = ((dMatrix[iLocation + iOffset] + dMatrix[iLocation]) * (u[iLocation + iOffset] - u[iLocation]) + (dMatrix[iLocation - iOffset] + dMatrix[iLocation]) * (u[iLocation - iOffset] - u[iLocation])) / 2.0f;
		}
	}
	else
	{
		dMatrix = NULL;
		return dResult;
	}


	return dResult;
}


//Efficient and Reliable Schemes for Nonlinear Diffusion Filtering
ErrorType Sovle_LR_ThomasAlgorithm(float* L, float* R, float* diag, float* d, int n)
/*************************************************************************
  See Weickert et a (1998), IEEE TMI 7(3): 398-410
 *************************************************************************/
{
	if (L == NULL || R == NULL || diag == NULL || d == NULL)
	{
		return U_ERROR;
	}


	int n1 = n - 1;
	//calculate L, R, the length of L, R is n - 1
	for (int i = 0; i < n1; i++)
	{
		if (diag[i] == 0)
		{
			diag[i] += 0.001f;
		}
		L[i] = L[i] / diag[i];
		diag[i + 1] = diag[i + 1] - (L[i] * R[i]);
	}

	//solve LRu=d for u
	//forward substitution, let y = Ru, solve Ly=d for y, y is stored in d

	for (int i = 1; i <= n1; i++)
	{
		d[i] = d[i] - (L[i - 1] * d[i - 1]);
	}

	//Backward substitution, solve Ru = y for u. u is stored in d
	if (diag[n1] == 0)
	{
		diag[n1] += 0.001f;
	}
	d[n1] = d[n1] / diag[n1];

	for (int i = n1 - 1; i >= 0; i--)
	{
		if (diag[i] == 0)
		{
			diag[i] += 0.001f;
		}
		d[i] = (d[i] - R[i] * d[i + 1])/diag[i];
	}

	return U_OK;

}

ErrorType ADF_2DHOS(float* imageData, int iHeight, int iWidth, int iter_n, double sigma, double rho, 
	float deltaT, float h, int iOrder, float* HOS, double* diffArray, double diffStop)
/***********************************************************************************
    float* imageData    Input image (2D) (also used as output)
    int iHeight         dimensions
    int iWidth          dimensions
    int iter_n          Max N iterations (50)
    double sigma        See paper (in number of pixels) (1)
    double rho          See paper (in number of pixels) (2)
    float deltaT        Time step (0.2)
    float h             Parameter used to set new eigenvalues (1). High h results in less edges (only the sharpest are kept)
    int iOrder          Order of HOS (1 or 2 or 3)
    float* HOS          output image of HOS, 
    double* diffArray   output trend of error as function of iteration
    double diffStop     Stopping criterion (0.01) (for real image)

    see Weickert (1999), Int J of Comp Vision 31(2/3), 111-127
 ***********************************************************************************/
{
	ErrorType eResult = U_OK;
	if (imageData == NULL)
	{
		eResult = U_ERROR;
		return eResult;
	}

	int iLength = iHeight * iWidth;
	double accuracy = 0.0002;
	//use imageData to store the n + 1th image, oldImageData to store the nth image
	float* oldImageData = new float[iLength];
	memcpy(oldImageData, imageData, sizeof(float) * iLength);
	int iIterCount = 0;
	memset(HOS, 0, sizeof(float) * iLength);
	float* HOSold = new float[iLength];
	memset(HOSold, 0, sizeof(float) * iLength);

	while(iIterCount < iter_n)
	{
		//calculate HOS
		memcpy(HOSold, HOS, sizeof(float) * iLength);
		memcpy(HOS, imageData, sizeof(float) * iLength);
		ConvertToCertainLevel_Float(HOS, iLength, 0.0f, 255.0f);
		CalculateHOS_2D(HOS, iHeight, iWidth, iOrder, 1);

		ConvertToCertainLevel_Float(HOS, iLength, 0.0f, 255.0f);

		//convolute with a Gaussian kernel
		float* gradientGaussian = new float[iLength];
		memcpy(gradientGaussian, oldImageData, sizeof(float) * iLength);
		GaussianBlur2D(gradientGaussian, iWidth, iHeight, sigma, sigma, accuracy);

		//calculate gradient
		float** gradientVector = new float* [2];
		for (int i = 0; i < 2; i++)
		{
			gradientVector[i] = new float[iLength];
			memset(gradientVector[i], 0, sizeof(float) * iLength);
		}
		GradientVector2D_Center(gradientGaussian, gradientVector, iHeight, iWidth);
		//delete
		delete[] gradientGaussian;
		gradientGaussian = NULL;
		//calculate tensor product
		float** tensor = new float* [3];
		for (int i = 0; i < 3; i++)
		{
			tensor[i] = new float[iLength];
			memset(tensor[i], 0, sizeof(float) * iLength);
		}

		for (int i = 0; i < iLength; i++)
		{
			tensor[0][i] = gradientVector[0][i] * gradientVector[0][i];
			tensor[1][i] = gradientVector[0][i] * gradientVector[1][i];
			tensor[2][i] = gradientVector[1][i] * gradientVector[1][i];
		}

		//delete gradient
		for (int i = 0; i < 2; i++)
		{
			delete[] gradientVector[i];
			gradientVector[i] = NULL;
		}
		delete[] gradientVector;
		gradientVector = NULL;

		//threads for Gaussian smoothing
		//smooth every component of the tensor by a Gaussian filter
		for (int i = 0; i < 3; i++)
		{
			GaussianBlur2D(tensor[i], iWidth, iHeight, rho, rho, accuracy);
		}


		double diff = 0.0;
		CalculateHOSDiff(HOS, HOSold, iLength, diff);
		diffArray[iIterCount] = diff;

		for (int i = 0; i < iLength; i++)
		{
			double A[2][2];
			double Q[2][2];
			double w[2];
			A[0][0] = tensor[0][i];
			A[0][1] = A[1][0] = tensor[1][i];
			A[1][1] = tensor[2][i];
			EigenCompostition2by2_ForStructureTensor(A, Q, w);

			for (int t = 0; t < 2; t++)
			{
				w[t] = abs(w[t]);
			}

			//sort the values of eigenvalues
			int iMaxIndex = 0, iMinIndex = 1;
			if (w[0] < w[1])
			{
				iMaxIndex = 1;
				iMinIndex = 0;
			}

			A[0][0] = Q[0][iMaxIndex];
			A[1][0] = Q[1][iMaxIndex];
			A[0][1] = Q[0][iMinIndex];
			A[1][1] = Q[1][iMinIndex];

			//determine the diffusion coefficients
			float mu1 = 0.0f;
			float mu2 = 0.0f;


			float h2 = h * h;
			mu1 = exp(-HOS[i] * HOS[i] / h2);
			mu2 = 1;			

			tensor[0][i] = (float)(A[0][0] * A[0][0] * mu1 + A[0][1] * A[0][1] * mu2);
			tensor[1][i] = (float)(A[0][0] * A[1][0] * mu1 + A[0][1] * A[1][1] * mu2);
			tensor[2][i] = (float)(A[1][0] * A[1][0] * mu1 + A[1][1] * A[1][1] * mu2);
		}

		//calculate V, store in imageDataNew
		for (int i = 0; i < iLength; i++)
		{
			int x = i % iWidth;
			int y = i / iWidth;

			imageData[i] = (oldImageData[i] + deltaT * (
				  DifferentialOperation_2thOrder(tensor, oldImageData, i, 1, 2, x, y, 0, 0, iHeight, iWidth)  // 0,0: 2D image
				+ DifferentialOperation_2thOrder(tensor, oldImageData, i, 2, 1, x, y, 0, 0, iHeight, iWidth)
				));

		}

		//delete tensor production L12
		delete[] tensor[1];
		tensor[1] = NULL;

		//calculate L11
		float mDeltaT = 2 * deltaT;
		float* diag = new float[iLength];
		memset(diag, 0, sizeof(float) * iLength);
		float* L = new float[iLength];
		memset(L, 0, sizeof(float) * iLength);
		float* R = new float[iLength];
		memset(R, 0, sizeof(float) * iLength);

		float* dMatrix = tensor[0];

		for (int i = 0; i < iLength; i++) // Tri-diagonal matrix (L, diag, R)  (x-direction)
		{
			float tmp = mDeltaT / 2.0f;
			if (i % iWidth == 0)
			{
				diag[i] = 1 + tmp * (dMatrix[i] + dMatrix[i + 1]);
				R[i] = -tmp * (dMatrix[i] + dMatrix[i + 1]);
			}
			else if (i % iWidth == iWidth - 1)
			{
				diag[i] = 1 + tmp * (dMatrix[i] + dMatrix[i - 1]);
				L[i - 1] = -tmp * (dMatrix[i] + dMatrix[i - 1]);
			}
			else
			{
				diag[i] = 1 + tmp * (dMatrix[i + 1] + dMatrix[i - 1] + 2 * dMatrix[i]);
				L[i - 1] = -tmp * (dMatrix[i] + dMatrix[i - 1]);
				R[i] = -tmp * (dMatrix[i] + dMatrix[i + 1]);
			}
		}

		//calculate w1, store tensor[0];
		memcpy(tensor[0], imageData, sizeof(float) * iLength);
		Sovle_LR_ThomasAlgorithm(L, R, diag, tensor[0], iLength);

		//calculate w2, store in tensor[2]
		dMatrix = tensor[2];
		//pixel numbering, switch x, y
		int iWidthNew = iHeight;
		int iHeightNew = iWidth;
		memcpy(diag, imageData, sizeof(float) * iLength);
		memcpy(L, dMatrix, sizeof(float) * iLength);
		for (int y = 0; y < iHeightNew; y++)
		{
			for (int x = 0; x < iWidthNew; x++)
			{
				imageData[x + y * iWidthNew] = diag[y + x * iWidth];
				dMatrix[x + y * iWidthNew] = L[y + x * iWidth];
			}
		}
		memset(diag, 0, sizeof(float) * iLength);
		memset(L, 0, sizeof(float) * iLength);
		memset(R, 0, sizeof(float) * iLength);

		for (int i = 0; i < iLength; i++)
		{
			float tmp = mDeltaT / 2.0f;
			if (i % iWidthNew == 0)
			{
				diag[i] = 1 + tmp * (dMatrix[i] + dMatrix[i + 1]);
				R[i] = -tmp * (dMatrix[i] + dMatrix[i + 1]);
			}
			else if (i % iWidthNew == iWidthNew - 1)
			{
				diag[i] = 1 + tmp * (dMatrix[i] + dMatrix[i - 1]);
				L[i - 1] = -tmp * (dMatrix[i] + dMatrix[i - 1]);
			}
			else
			{
				diag[i] = 1 + tmp * (dMatrix[i + 1] + dMatrix[i - 1] + 2 * dMatrix[i]);
				L[i - 1] = -tmp * (dMatrix[i] + dMatrix[i - 1]);
				R[i] = -tmp * (dMatrix[i] + dMatrix[i + 1]);
			}
		}

		memcpy(tensor[2], imageData, sizeof(float) * iLength);
		Sovle_LR_ThomasAlgorithm(L, R, diag, tensor[2], iLength);

		//pixel numbering, switch x, y
		memcpy(diag, imageData, sizeof(float) * iLength);
		memcpy(L, tensor[2], sizeof(float) * iLength);
		for (int y = 0; y < iHeight; y++)
		{
			for (int x = 0; x < iWidth; x++)
			{
				imageData[x + y * iWidth] = diag[y + x * iWidthNew];
				tensor[2][x + y * iWidth] = L[y + x * iWidthNew];
			}
		}


		delete[] diag;
		diag = NULL;
		delete[] L;
		L = NULL;
		delete[] R;
		R = NULL;

		//calculate U k+1
		for (int i = 0; i < iLength; i++)
		{
			imageData[i] = (tensor[0][i] + tensor[2][i]) / 2.0f; 
		}

		ConvertToCertainLevel_Float(imageData, iLength, 0.0f, 255.0f);
		memcpy(oldImageData, imageData, sizeof(float) * iLength);

		//delete tensor product 0, 2
		delete[] tensor[0];
		tensor[0] = NULL;
		delete[] tensor[2];
		tensor[2] = NULL;
		delete[] tensor;
		tensor = NULL;
		iIterCount++;
		if (diff <= diffStop)
		{
			break;
		}

	}

	//release
	delete[] oldImageData;
	oldImageData = NULL;
	delete[] HOSold;
	HOSold = NULL;

	return eResult;
}

//double diffArray [200];
//memset(diffArray, 0, sizeof(double) * 200);

//ConvertToCertainLevel_Float(pFData, iLength, 0.0f, 255.0f);
//AnisotropicDiffusion_2DHOS(pFData, iHeight, iWidth, 50, 1.0, 2.0, 0.2f, 4.0f, 2, HOS->GetImageDataFloat(), diffArray, 0.01);
//
////PrintfArray(diffArray, 200, "C:\\Users\\Administrator\\Desktop\\array1.txt");
//ConvertToCertainLevel_Float(pFData, iLength, 0.0f, 255.0f);