/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Module to set the condition parameters for dipole fitting                   */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    16-03-99   Creation, derived from FitDipoles.cpp and older version of LocCoil.cpp
  JdM    31-03-99   Added the parameter bool HelmetCoords to ExportResults().
  JdM    06-05-99   Make functions compatible for arbitrary number of ADC channels (>=0)
  JdM    18-05-99   Computation and output of best fitting euler transforms
  JdM    06-06-99   BUG Fix: Computation of the average translation and rotation w.r.t. the average Euler
  JdM    08-08-99   Use global CI-object.
  JdM    11-08-99   Incorporate changes caused by UStartDipole() updates
  JdM    20-08-99   Detect (almost) coinciding points
  JdM    14-12-99   Add parameter to ComputeCoils() to set the number of grid points for the initial guess
  JdM    21-12-99   Add parameter to ComputeCoils() to set the type of the search region for global search
  JdM    31-01-00   Export best fitting sphere to output file.
  JdM    01-02-00   Anticipate on updates of UDipoleList() dd 25-01-00
  JdM    23-05-00   New features in output file (in ExportResults())
  JdM    04-12-00   ExportResults(): Export changeHeadPos command.
  JdM    19-08-01   ComputeCoils(): pass information to ULocCoils to adapt forward model
GdV/Jdm  25-03-02   Include GridFit.h
  JdM    09-07-02   Added two parameters to constructor, to force good or bad channels
GdV/JdM  01-11-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    06-09-05   Bug fix: ComputeCoils(), CType==U_ITERATIVE, reset ipNADC, each loop over epochs
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    05-01-07   Derive UFitDipoles from UMEEGDataEpochs iso obsolete UDataEpochs
  JdM    23-05-07   ComputeCoils(). Added parameter to ULC.ComputeCoils()
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
 */


#include <stdio.h>
#include <string.h>

#include "FitCoils.h"
#include "GridFit.h"
#include "Epochs.h"

#define MAXITER 10 // The maximum number of iterations applied in the ierative mode of coil callibration

void UFitCoils::SetAllMembersDefault(void)
{
    error          = U_OK;
    DataStatistics = NULL;
    ErrorString    = NULL;
    Properties     = NULL;
    DipList        = NULL;
    MAXSTRING      = ULocCoil::MAXSTRING;
}
void UFitCoils::DeleteAllMembers(ErrorType E)
{
    delete[] Properties;
    delete[] DataStatistics;
    delete[] ErrorString;
    delete   DipList;

    SetAllMembersDefault();
    error = E;
}

UFitCoils::UFitCoils(char* DSName,  const char* GoodChan, const char* BadChan, const UCostminimize& cst):
    UMEEGDataEpochs(DSName, GoodChan, BadChan), cost(cst)
{
    SetAllMembersDefault();
    error = UMEEGDataEpochs::GetError();
}

UFitCoils::~UFitCoils()
{
    DeleteAllMembers(U_OK);
}

ErrorType UFitCoils::GetError(void) const
{
    if(this==NULL)                        return U_ERROR;
    if(UMEEGDataEpochs::GetError()!=U_OK) return U_ERROR;
    else                                  return error;
}

ErrorType UFitCoils::ComputeCoils(UVector3 Start, bool AdFordMod, UStartDipole::StartType SType,
                                  double BadThreshold, CalibType CType, double* calib, int Ngrd, UMeshPoints::RegionType GlobalSRegion)
{
/* Test the arguments */
    if(CType==U_NOCALIB) return U_ERROR;
    if(CType==U_CONSTANT && calib==NULL) return U_ERROR;

/* Test whether data is read and epochs are set.*/
    if(Data==NULL   || Data->GetError()!=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK )
    {
        CI.AddToLog("ERROR: UFitCoils(). Data or Epochs not (properly) set)\n");
        return U_ERROR;
    }
    int nADC        = Data->GetNADC();
    int nEpochs     = Epochs->GetnEpochs();
    int NsampPTrial = Data->GetNsampTrial();
    if(nADC<=0 || nEpochs<=0 || NsampPTrial<=0)
    {
        CI.AddToLog("ERROR: UFitCoils(). nADC = %d; nEpochs = %d; NsampPTrial = %d \n",nADC, nEpochs, NsampPTrial);
        return U_ERROR;
    }

    ReReferenceType     ReRefForw = U_REF_RAW;
    if(AdFordMod==true) ReRefForw = GetMEGForwardBalancing();

    DipList         = new UDipoleList(nADC*nEpochs, UDipole::Magnetic);
    DataStatistics  = new char[nEpochs*MAXSTRING];
    ErrorString     = new char[nEpochs*MAXSTRING];

    ULocCoil  ULC(cost, ReRefForw, Data);
    if(ULC.GetError()!=U_OK || DipList==NULL || DataStatistics==NULL || ErrorString==NULL)
    {
        delete[] DataStatistics; DataStatistics = NULL;
        delete[] ErrorString;    ErrorString    = NULL;
        delete   DipList;        DipList        = NULL;

        CI.AddToLog("ERROR: UFitCoils(). Memory allocation error or error creating ULocCoil() object. \n");
        return U_ERROR;
    }
    memset(DataStatistics, 0, nEpochs*MAXSTRING);
    UDipole *Dipoles = DipList->GetDipoles();

    ULC.ResetCoilCalibration(calib);
    if(Dipoles)
    {
        for(int k=0; k<nADC; k++)
        {
            Dipoles[k].Setx(Start + UVector3(0.,0.,k));
            Dipoles[k].SetDipoleType(UDipole::Magnetic);
        }
    }
    if(!Dipoles || ULC.UStartDipole::InitStart(SType, Dipoles, nADC, Ngrd, GlobalSRegion) !=U_OK)
    {
        delete[] Dipoles;
        delete[] DataStatistics; DataStatistics = NULL;
        delete[] ErrorString;    ErrorString    = NULL;
        delete   DipList;        DipList        = NULL;
        return U_ERROR;
    }

/* Get an estimate of the dipole positions and moments, thereby letting the
   callibrations (dipoles strengths) free in magnitude, except when CType == U_CONSTANT
*/
    CI.AddToLog("\n\nThere are %d coils to be fitted.\n\n",nEpochs);

    int ipNADC = 0;
    for(int m=0; m<nEpochs; m++, ipNADC+=nADC)
    {
        CI.AddToLog("%3d \t",m);

/* Get the data corresponding to the Epochs */

        double  *MEGDataEp = GetFilteredData(m, U_DAT_MEG);
        double  *ADCDataEp = GetFilteredData(m, U_DAT_ADC);

        int     NsampEp    = Epochs->GetNsamp(m);
        RemoveOffset(MEGDataEp, NsampEp, Data->GetNmeg());
        RemoveOffset(ADCDataEp, NsampEp, nADC);
        if(ULC.InitCompute(MEGDataEp, ADCDataEp, NsampEp, BadThreshold)!=U_OK)
        {
            memcpy(DataStatistics+m*MAXSTRING,ULC.GetDataStatistics(),MAXSTRING);
            memcpy(ErrorString   +m*MAXSTRING,ULC.GetErrorString()   ,MAXSTRING);
            delete[] MEGDataEp;
            delete[] ADCDataEp;
            continue;
        }
        delete[] MEGDataEp;
        delete[] ADCDataEp;

/* Copy start parameters*/
        if(m>0) for(int k=0; k<nADC; k++) Dipoles[ipNADC+k] = Dipoles[ipNADC-nADC+k];

        double ResErrorPerc = 100.;
        if(CType==U_CONSTANT)
            ULC.ComputeCoils(Dipoles+ipNADC, ULocCoil::FIXED_STRENGTH, &ResErrorPerc);
        else
            ULC.ComputeCoils(Dipoles+ipNADC, ULocCoil::FREE_STRENGTH, &ResErrorPerc);

        ULC.UpdateCoilCalibration(Dipoles+ipNADC);
        memcpy(DataStatistics+m*MAXSTRING,ULC.GetDataStatistics(),MAXSTRING);
        memcpy(ErrorString   +m*MAXSTRING,ULC.GetErrorString()   ,MAXSTRING);

        for(int k=0; k<nADC; k++) DipList->SetDipole(ipNADC+k, Dipoles[ipNADC+k]);

        CI.AddToLog("%f [%%]\n",ResErrorPerc);
    }
    CI.AddToLog("\n");

/* Compute the optimum coil callibrations*/
    ULC.ComputeCoilCalibration();

    if(CType==U_ITERATIVE)
    {
        for(int iter=0; iter<MAXITER; iter++)
        {
            fprintf(stderr,"Iteration %3d\n",iter);
            ULC.ResetCoilCalibration();
            int ipNADC = 0;
            for(int m=0; m<nEpochs; m++, ipNADC+=nADC)
            {
                fprintf(stderr,"%3d",m);

                double  *MEGDataEp = GetFilteredData(m, U_DAT_MEG);
                double  *ADCDataEp = GetFilteredData(m, U_DAT_ADC);

                int     NsampEp    = Epochs->GetNsamp(m);


                RemoveOffset(MEGDataEp, NsampEp, Data->GetNmeg());
                RemoveOffset(ADCDataEp, NsampEp, nADC);
                if(ULC.InitCompute(MEGDataEp, ADCDataEp, NsampEp, BadThreshold)!=U_OK)
                {
                    delete[] MEGDataEp;
                    delete[] ADCDataEp;
                    continue;
                }
                delete[] MEGDataEp;
                delete[] ADCDataEp;

                double ResErrorPerc = 100.;
                ULC.ComputeCoils(Dipoles+ipNADC, ULocCoil::FIXED_STRENGTH, &ResErrorPerc);
                ULC.UpdateCoilCalibration(Dipoles+ipNADC);

                strncpy(DataStatistics+m*MAXSTRING,ULC.GetDataStatistics(),MAXSTRING-1);
                strncpy(ErrorString   +m*MAXSTRING,ULC.GetErrorString()   ,MAXSTRING-1);
            }
            ULC.ComputeCoilCalibration();
        }
    }
    delete[] Properties;
    Properties = new char[3*MAXSTRING];
    if(Properties)
    {
        memset(Properties,0,3*MAXSTRING);
        int nc  =  sprintf(Properties   ,"//   Bad Channel Threshold %8.0f %% \n",BadThreshold);
        if(nc<2*MAXSTRING) nc +=  sprintf(Properties+nc,"%s",(const char*)ULC.UStartDipole::GetProperties("//  "));
    }
    delete[] Dipoles;
    return U_OK;
}

ErrorType UFitCoils::ExportResults(char *FileName, double TipLength, bool HelmetCoords, double DetectDistance)
/*
   Export the fitted coils to an ASCII file, named FileName[].

   TipLength    : Tiplength correction applied to the fourth coil
   HelmetCoords : If this is true, convert some intermediate results to CTF helmet coordinates
*/
{
    if(FileName==NULL)  return U_ERROR;
    if(Data    ==NULL)  return U_ERROR;

/* Generate Warnings/Error messages */
    UpdateErrorString();

/* Translate the dipole list into electrode positions w.r.t. Nasion Ear System */
    int    nADC            = Data->GetNADC();
    int    Npoints         = DipList->GetNdip()/nADC;
    char*  PointStatistics = new char[Npoints*MAXSTRING];
    UVector3  NLR[3];
    UVector3* PointList = DipList->GetPointsNLR(NLR, nADC, PointStatistics, MAXSTRING, TipLength);
    if(PointList==NULL)
    {
        delete[] PointStatistics;
        CI.AddToLog("ERROR UFitCoils : Converting dipoles to points \n");
        return U_ERROR;
    }

/*Export Results to file*/
    UFileName FNamBase(FileName);
    UFileName OutputFileName = GetData()->GetDataFileName().GetSiblingFileName(FNamBase.GetBaseName());
    FILE      *fpOUT         = fopen(OutputFileName,"wt",false);
    if(fpOUT==NULL)
    {
        delete[] PointList;
        delete[] PointStatistics;
        CI.AddToLog("ERROR UFitCoils : Opening output filename. %s\n", OutputFileName);
        return U_ERROR;
    }
    else
        fprintf(stderr,"\nOutput file created: %s.\n", (const char*)OutputFileName);


    fprintf(fpOUT,"%s",CI.GetProperties("//  "));
    fprintf(fpOUT,"//\n// DATA:\n");
    fprintf(fpOUT,"%s",(const char*)Data->GetProperties("//  "));
    fprintf(fpOUT,"//\n// EPOCHS:\n");
    fprintf(fpOUT,"%s",(const char*)UMEEGDataEpochs::GetProperties("//  "));
    fprintf(fpOUT,"//\n// FIND COILS:\n");
    fprintf(fpOUT,"%s",Properties);
    fprintf(fpOUT,"//   TipLength = %f \n",TipLength);
    fprintf(fpOUT,"//   %s \n",cost.GetParameterString());

/* Detect coinciding points:*/
    fprintf(fpOUT,"// \n");
    if(DetectDistance>=0.)
    {
        fprintf(fpOUT,"// (Almost) coinciding points, distance smaller than %f:\n",DetectDistance);
        for(int n1=0; n1<Npoints; n1++)
            for(int n2=n1+1; n2<Npoints; n2++)
            {
                double dist = (PointList[n1]-PointList[n2]).GetNorm();
                if(dist<DetectDistance)
                    fprintf(fpOUT,"// WARNING: Distance between Point[%d] and Point[%d] is %f cm. \n", n1, n2, dist);
            }
    }
    fprintf(fpOUT,"// \n");
    fprintf(fpOUT,"// \n");
    {
        UPointList PL(PointList, Npoints);
        double     Radius, Error;
        bool       UseL1norm = false;
        UVector3   SP = PL.FitSphere(&Radius, &Error, UseL1norm);
        fprintf(fpOUT,"//  BestFittingSphere = %s\n", SP.GetProperties());
        fprintf(fpOUT,"//  Radius  = %f \n", Radius);
        fprintf(fpOUT,"//  Error   = %f \n", Error);
    }
    fprintf(fpOUT,"// \n");
    fprintf(fpOUT,"// \n");

/* The final results*/
    fprintf(fpOUT,"//\n// The points: \n//\n");
    int n=0;
    for(   ; n<Npoints; n++)
        fprintf(fpOUT,"%d \t%d \t%s   \t//%s\n",n,n,PointList[n].GetProperties(),ErrorString+n*MAXSTRING);

    fprintf(fpOUT,"Nas \t%d \t%s \n", n+0, NLR[0].GetProperties());
    fprintf(fpOUT,"Lef \t%d \t%s \n", n+1, NLR[1].GetProperties());
    fprintf(fpOUT,"Rig \t%d \t%s \n", n+2, NLR[2].GetProperties());

    UDipole* Dipoles = DipList->GetDipoles();
    UEuler   H2D     = (Data->GetDewar2NLR()).Invert();
    if(HelmetCoords==true)
        fprintf(fpOUT,"//\n// Full Results in Helmet coordinates\n//\n");
    else if(nADC>=3)
        fprintf(fpOUT,"//\n// Full Results Nasion-Ear coorndinates\n//\n");
    else
        fprintf(fpOUT,"//\n// Full Results in CTF derived Nasion-Ear coorndinates\n//\n");

    for(n=0; n < Npoints; n++)
    {
        fprintf(fpOUT,"// %d ", n);
        char line[100];
        for(int k=0; k<nADC; k++)
        {
            if(HelmetCoords==true)
            {
                UDipole Dip = Dipoles[n*nADC+k];
                Dip.Transform(H2D);
                Dip.PrintParameters(line,100);
            }
            else
                Dipoles[n*nADC+k].PrintParameters(line,100);
            fprintf(fpOUT,"%d:%s ",k,line);
        }
        fprintf(fpOUT,"\n");
    }
    fprintf(fpOUT,"//\n// Statistics \n//\n");
    for(n=0; n < Npoints; n++)
        fprintf(fpOUT,"// %d  %s; %s \n", n,PointStatistics+n*MAXSTRING, DataStatistics+n*MAXSTRING);

    delete[] PointStatistics;
    delete[] PointList;

    if(nADC>=3)
    {
        UEuler*  EUArray = DipList->GetEulerArray(nADC);
        UGridFit Gr      = *(Data->GetGridMEG());
        if(EUArray==NULL || Gr.GetError()!=U_OK)
        {
            delete[] EUArray;
            fclose(fpOUT);
            return U_ERROR;
        }

        fprintf(fpOUT,"//\n// Head movement with respect to first NLR measurement: \n");
        fprintf(fpOUT,"// Rotation axis, Rotation angle (deg). Translation [cm]\n");

        UEuler First = EUArray[0].GetInverse();
        for(n=0; n<Npoints; n++)
        {
            UEuler   Mov = First*EUArray[n];
            UVector3 Ax  = Mov.GetAxis();
            double   Rot = Mov.TotalRot(false);
            UVector3 Tr  = Mov.GetTranslation();
            fprintf(fpOUT,"// %i \t%s \t%8.3f    \t",n,Ax.GetProperties(),Rot);
            fprintf(fpOUT,"%s \n",Tr.GetProperties());
        }

        double residual;
        UEuler AvEul = Gr.FitGridEuler(EUArray, Npoints, &residual);

        fprintf(fpOUT,"//\n// Head movement with respect to 'average' head position: \n");
        fprintf(fpOUT,"// Euler fit Error = %f [cm]\n", residual);
        fprintf(fpOUT,"// Rotation [deg] and translation [cm] w.r.t. best fitting euler. \n//\n");
        AvEul.Invert();
        for(n=0; n<Npoints; n++)
        {
            EUArray[n] = AvEul*EUArray[n];
            double Rot = EUArray[n].TotalRot(false);
            double Tra = EUArray[n].TotalTrans();
            fprintf(fpOUT,"// %i \t %8.3f \t %8.3f \n",n,Rot,Tra);
        }

/* Export changeHeadPos command, using average NLR positions in dewar coordinates. */
        UEuler   AveHead2Dewar = H2D * ( EUArray[0].GetInverse() );
        UVector3 AverNasionDew = AveHead2Dewar.xfm(Dipoles[0].Getx());
        UVector3 AverLeftDew   = AveHead2Dewar.xfm(Dipoles[1].Getx());
        UVector3 AverRightDew  = AveHead2Dewar.xfm(Dipoles[2].Getx());

        fprintf(fpOUT,"// changeHeadPos -na %f %f %f -le %f %f %f -re %f %f %f \n",
                       AverNasionDew.Getx(),
                       AverNasionDew.Gety(),
                       AverNasionDew.Getz(),
                       AverLeftDew.Getx(),
                       AverLeftDew.Gety(),
                       AverLeftDew.Getz(),
                       AverRightDew.Getx(),
                       AverRightDew.Gety(),
                       AverRightDew.Getz());
        delete[] EUArray;
    }
    delete[] Dipoles;

    fclose(fpOUT);
    return U_OK;
}

void UFitCoils::RemoveOffset(double *data, int Nsamp, int Nkan) const
{
    if(data==NULL) return;

    for(int i=0; i<Nkan; i++)
    {
        double  offset = 0;
        for(int j=0; j<Nsamp; j++) offset += data[i*Nsamp+j];
        offset /= Nsamp;
        for(int j=0; j<Nsamp; j++) data[i*Nsamp+j]-=offset;
    }
}

void UFitCoils::UpdateErrorString(void)
/*
     Test for each coil, whether the average calibration deviates too much from
     the average (of all coils). Do the same for the distances.
 */
{
    int nADC    = Data->GetNADC();
    int Npoints = DipList->GetNdip()/nADC;
    if(nADC<3) return;

/* Compute average callibration and average distances*/
    double d01_Ave = 0;
    double d12_Ave = 0;
    double d20_Ave = 0;

    double* C_Ave   = new double[nADC];
    if(C_Ave==NULL) return;

    for(int k=0; k<nADC; k++) C_Ave[k] = 0.;
    UDipole* Dipoles = DipList->GetDipoles();

    int NpointsOK  = 0;
    for(int ipoint=0,ipNADC=0; ipoint < Npoints; ipoint++,ipNADC+=nADC)
    {
        if(Dipoles[ipNADC+0].Getx().GetNorm() < 1.e-8 &&
           Dipoles[ipNADC+1].Getx().GetNorm() < 1.e-8 &&
           Dipoles[ipNADC+2].Getx().GetNorm() < 1.e-8)  continue;  // Erroneous point


        d01_Ave += (Dipoles[ipNADC+0].Getx()-Dipoles[ipNADC+1].Getx()).GetNorm();
        d12_Ave += (Dipoles[ipNADC+1].Getx()-Dipoles[ipNADC+2].Getx()).GetNorm();
        d20_Ave += (Dipoles[ipNADC+2].Getx()-Dipoles[ipNADC+0].Getx()).GetNorm();

        for(int k=0; k<nADC; k++) C_Ave[k] += Dipoles[ipNADC+k].Getd().GetNorm();
        NpointsOK++;
    }
    d01_Ave /= NpointsOK;
    d12_Ave /= NpointsOK;
    d20_Ave /= NpointsOK;
    for(int k=0; k<nADC; k++) C_Ave[k] /= NpointsOK;

    for(int ipoint=0,ipNADC=0; ipoint < Npoints; ipoint++,ipNADC+=nADC)
    {
        if(Dipoles[ipNADC+0].Getx().GetNorm() < 1.e-8 &&
           Dipoles[ipNADC+1].Getx().GetNorm() < 1.e-8 &&
           Dipoles[ipNADC+2].Getx().GetNorm() < 1.e-8)  continue;  // Erroneous point

        double d01   = (Dipoles[ipNADC+0].Getx()-Dipoles[ipNADC+1].Getx()).GetNorm();
        double d12   = (Dipoles[ipNADC+1].Getx()-Dipoles[ipNADC+2].Getx()).GetNorm();
        double d20   = (Dipoles[ipNADC+2].Getx()-Dipoles[ipNADC+0].Getx()).GetNorm();

        double test  = (fabs(d01-d01_Ave) + fabs(d12-d12_Ave) + fabs(d20-d20_Ave) )/3;

        size_t nc    = strlen(ErrorString+ipoint*MAXSTRING);
        char *Offset = ErrorString+ipoint*MAXSTRING+nc;
        if(test>1.)
        {
            strncpy(Offset," ERROR: Nasion-Ear error>1 cm;",MAXSTRING-nc-1);
        }
        else if(test>.5)
        {
            strncpy(Offset," WARNING: Nasion-Ear error> .5 cm;",MAXSTRING-nc-1);
        }

        nc      = strlen(ErrorString+ipoint*MAXSTRING);
        Offset  = ErrorString+ipoint*MAXSTRING+nc;
        test    = 0;
        for(int k=0; k<nADC; k++) test += 100.*fabs(Dipoles[ipNADC+k].Getd().GetNorm()-C_Ave[k])/(C_Ave[k]*nADC);
        if(test>10.)
        {
            strncpy(Offset," ERROR: Callibration error >10.%;",MAXSTRING-nc-1);
        }
        else if(test>2.)
        {
            strncpy(Offset," WARNING: Callibration error >2.%;",MAXSTRING-nc-1);
        }

        nc = strlen(ErrorString+ipoint*MAXSTRING);
        if(nc==0) strcpy(ErrorString+ipoint*MAXSTRING,"OK");
    }
    delete[] C_Ave;
    delete[] Dipoles;
}

