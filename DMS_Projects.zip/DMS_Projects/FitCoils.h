#ifndef _FITCOILS_INCLUDED
#define _FITCOILS_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "DipoleList.h"
#include "LocCoil.h"
#include "MEEGDataEpochs.h"

class UFitCoils : public UMEEGDataEpochs
{
public:
    UFitCoils(char* DataSetName, const char* GoodChan, const char* BadChan, const UCostminimize& cst);
    ~UFitCoils();

    ErrorType       GetError(void) const;
    ErrorType       ComputeCoils(UVector3 Start, bool AdFordMod, UStartDipole::StartType SType, 
                                 double BadThreshold, CalibType CType, double* calib, int Ngrd, UMeshPoints::RegionType GlobalSRegion);
    ErrorType       ExportResults(char *FileName, double TipLength, bool HelmetCoords, double DetectDistance);

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;         // A General Error Flag
    UCostminimize   cost;          // An object containing the conditions under which the coils are localized
    int             MAXSTRING;     // The maxmumum number of characters used to export results in text-format

    char*           Properties;    // A string with the general properties of the object in text format
    char*           DataStatistics;// A description of the statistics for each epoch
    char*           ErrorString;   // A warning/error text for each epoch
    UDipoleList*    DipList;       // A list of all fitted dipoles

// Functions
    void RemoveOffset(double *data, int Nsamp, int Nkan) const;
    void UpdateErrorString(void);
};
#endif// _FITCOILS_INCLUDED
