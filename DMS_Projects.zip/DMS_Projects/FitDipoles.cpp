/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Module to set the condition parameters for dipole fitting                   */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    23-09-98   Creation
  JdM    01-10-98   separated include-files
  JdM    08-10-98   use new and delete[] instead of malloc() and free()
  JdM    19-10-98   Update Compiler to Visual C/C++ version 5.0
  Jdm    13-11-98   compatibility with HP CC Compiler  
  Jdm    23-11-98   Implemented markers with half-width
  Jdm    25-11-98   Split up object into UEpochArray and the rest.
Jdm/AdJ  22-12-98   Added option to store output in one File
  Jdm    02-02-99   Export more details in Comment header
  Jdm    03-03-99   Export Data Power on each time sample
  JdM    05-03-99   Use Updated UEpoch-object
  JdM    16-03-99   Changed interface to constructor
  JdM    15-04-99   Print MEG Fiducials in outputfile
  JdM    16-04-99   Added the option to read head model from a file.
  JdM    18-04-99   Export channel in Start()
  JdM    20-04-99   Export Filtered data in Start() i.s.o. raw data
  JdM    28-04-99   Bug fix in printing collumn header
  JdM    07-08-99   Remove *AppName and use CI-object instead.
  JdM    11-08-99   Incorporate changes caused by UStartDipole() updates
  JdM    14-12-99   Added parameter to Start() (=MaxStartError)
  JdM    06-01-00   Export standard deviation, as an additional collumn
  JdM    29-01-00   Export number of cost evaluations for each epoch
  JdM    07-02-00   Add option to set the output format
  JdM    10-02-00   Use UDistribution object to get the data power characteristics
                    Export Average data power instead of total data power
                    Export SEM instead of standard deviation.
  JdM    16-03-00   Export power data distribution in standard file names, adapt default range parameters
  JdM    27-03-00   remove HModel from data list. (obsolete).
  JdM    06-04-00   Redistribute the power in 256 bins of the histogram.
  JdM    01-05-00   Export sample number or time always in absolute sense (w.r.t. first time sample in file)
  JdM    28-06-00   Start(). Return without computations when headmodel file does not exist.
  JdM    08-08-00   Make the object appropriate for fitting stationary dipoles.
  JdM    04-09-00   Added option to append new data to existing files, using OutType
  JdM    06-10-00   Incorporate changes made in UEpochs()-object dd 06-10-00.
  JdM    19-10-00   FitStationaryDipoles(). Several bug fixes, for the case of multiple epochs.
  JdM    22-02-01   Use the UFileName object to manipulate filenames.
                    FitMovingDipoles() new meaning of ConfidenceLimits.
  JdM    19-03-01   Always compute confidence intervals assuming unscaled covariance matrix. 
  JdM    30-03-01   Allow epochs to be averaged
  Jdm    31-05-01   Move FitStationaryDipoles() to LocStatDip.cpp and FitMovingDipoles() to LocMovDip.cpp
  JdM    01-06-01   SetHeadModel(): Use UFileName() object
  JdM    25-06-01   Bug fix: Constructor. Test whether OutputFile[] is pure file.
  JdM    14-11-02   Add parameter to GetDataChannel() to return (filtered) ADC data
  JdM    09-11-04   Added CostType (From ULocMovDip)
  JdM    05-01-07   Derive UFitDipoles from UMEEGDataEpochs iso obsolete UDataEpochs
  JdM    01-11-07   Renamed SetHeadModel() as GetHeadModel()
  JdM    07-03-08   Bug Fix: SetDataThresold(). Printing output histograms (use of UString-objects)
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    02-06-14   Replaced UCovariance class by (new) UCovarianceModel class
  JdM    12-06-15   Added new constructor
*/


#include <stdio.h>
#include <string.h>

#include "FitDipoles.h"
#include "Distribution.h"

void UFitDipoles::SetAllMembersDefault(void)
{
    error         = U_OK;

    FileNameOut   = UFileName();
    OneFile       = true;
    AllDipoles    = true;
    TimeInMs      = false;
    OutType       = U_DELETE;

    cost          = UCostminimize();
    DType         = UDipole::Current;
    MinDataPowMEG = -1.;
    MinDataPowEEG = -1.;
    PowerDistMEG  = NULL;
    PowerDistEEG  = NULL;
}
void UFitDipoles::DeleteAllMembers(ErrorType E)
{
    delete   PowerDistMEG; 
    delete   PowerDistEEG; 

    SetAllMembersDefault();
    error = E;
}

UFitDipoles::UFitDipoles(const char* DSName, const char* forceGoodCh, const char* forceBadCh, const char* OutputFile, 
              const UCostminimize& cst, OutputFormat OF, OutputType OT,
              UDipole::DipoleType DT):
    UMEEGDataEpochs(DSName, forceGoodCh, forceBadCh)
{        
    SetAllMembersDefault();
    if(UMEEGDataEpochs::GetError()!=U_OK || GetData()==NULL || GetData()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::UFitDipoles(). Creating base class.\n");
        UMEEGDataEpochs::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

    if(OF==U_OF_ALL_SAMP || OF==U_OF_ALL_MS || OF==U_OF_SKIP_SAMP || OF==U_OF_SKIP_MS)
        OneFile    = true;
    else
        OneFile    = false;

    if(OF==U_OF_ALL_SAMP || OF==U_OF_ALL_MS || OF==U_SF_ALL_SAMP || OF==U_SF_ALL_MS)
        AllDipoles = true;
    else
        AllDipoles = false;

    if(OF==U_OF_ALL_MS || OF==U_OF_SKIP_MS || OF==U_SF_ALL_MS || OF==U_SF_SKIP_MS)
        TimeInMs = true;
    else
        TimeInMs = false;

    
    OutType = OT;    
    FileNameOut = UFileName((char*)NULL, OutputFile, ".txt");
    if(FileNameOut.IsPureFile()==true)
        FileNameOut = GetData()->GetDataFileName().GetSiblingFileName(FileNameOut);

    DType         = DT;
    cost          = cst;
}
UFitDipoles::UFitDipoles(const UMEEGDataEpochs& DatEp, const char* OutputFile, const UCostminimize& cst, OutputFormat OF, OutputType OT,
            UDipole::DipoleType DT) : 
    UMEEGDataEpochs(DatEp)
{
    SetAllMembersDefault();

    if(UMEEGDataEpochs::GetError()!=U_OK || GetData()==NULL || GetData()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::UFitDipoles(). Creating base class, or Data not properly set.\n");
        UMEEGDataEpochs::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

    if(OF==U_OF_ALL_SAMP || OF==U_OF_ALL_MS || OF==U_OF_SKIP_SAMP || OF==U_OF_SKIP_MS)
        OneFile    = true;
    else
        OneFile    = false;

    if(OF==U_OF_ALL_SAMP || OF==U_OF_ALL_MS || OF==U_SF_ALL_SAMP || OF==U_SF_ALL_MS)
        AllDipoles = true;
    else
        AllDipoles = false;

    if(OF==U_OF_ALL_MS || OF==U_OF_SKIP_MS || OF==U_SF_ALL_MS || OF==U_SF_SKIP_MS)
        TimeInMs = true;
    else
        TimeInMs = false;
    
    OutType = OT;    
    FileNameOut = UFileName((char*)NULL, OutputFile, ".txt");
    if(FileNameOut.IsPureFile()==true)
        FileNameOut = GetData()->GetDataFileName().GetSiblingFileName(FileNameOut);

    DType         = DT;
    cost          = cst;
}


UFitDipoles::~UFitDipoles()
{
    DeleteAllMembers(U_OK);
}

ErrorType UFitDipoles::SetDataThresold(double MinFactor, FitDataType FDT)
/*
    Determine the minimum data power on a sample, required to be considered for
    dipole fitting. Samples with a power lower than the threshold are disregarded.

    MinDataPower = Median[over all filtered epochs]*MinFactor
 */
{
    if(Data==NULL || Epochs==NULL) return U_ERROR;

    if(MinFactor<0) return U_OK; // Nothing to do

    const int    NBIN        = 10000;
    const double MaxPowerMEG = 1000000;
    const double MaxPowerEEG = 10000;

    if(FDT==U_MEG_ONLY || FDT==U_MEG_AND_EEG)
    {
        delete PowerDistMEG;
        PowerDistMEG   = GetAverPowerHistogram(NBIN, MaxPowerMEG , U_DAT_MEG);
        if(PowerDistMEG==NULL || PowerDistMEG->GetError()!=U_OK) return U_ERROR;
        PowerDistMEG->ReDistribute(0.,5*PowerDistMEG->GetMedian(),256);

        MinDataPowMEG          = MinFactor*PowerDistMEG->GetMedian()*Data->GetGridMEG()->GetNpoints();
        UFileName FileDistrOut = GetData()->GetDataFileName().GetSiblingFileName("MEGdistr.txt");
        FILE* fp = fopen(FileDistrOut, "wt",false);
        if(fp)
        {
            UString Prop = PowerDistMEG->GetProperties("// ");
            UString Dist = PowerDistMEG->GetDistributionText(" ", true, false, false);
            fprintf(fp,"//  Distribution of MEG-data power in fT**2 \n");
            Prop.WriteText(fp);
            Dist.WriteText(fp);
            fclose(fp);
        }
    }
    if(FDT==U_EEG_ONLY || FDT==U_MEG_AND_EEG)
    {
        delete PowerDistEEG;
        PowerDistEEG   = GetAverPowerHistogram(NBIN, MaxPowerEEG, U_DAT_EEG);
        if(PowerDistEEG==NULL || PowerDistEEG->GetError()!=U_OK) return U_ERROR;
        PowerDistEEG->ReDistribute(0.,10*PowerDistEEG->GetMedian(),256);
    
        MinDataPowEEG          = MinFactor*PowerDistEEG->GetMedian()*Data->GetGridEEG()->GetNpoints();
        UFileName FileDistrOut = GetData()->GetDataFileName().GetSiblingFileName("EEGdistr.txt");
            
        FILE* fp = fopen(FileDistrOut, "wt",false);
        if(fp)
        {
            UString Prop = PowerDistEEG->GetProperties("// ");
            UString Dist = PowerDistEEG->GetDistributionText(" ", true, false, false);
            fprintf(fp,"//  Distribution of EEG-data power in uV**2 \n");
            Prop.WriteText(fp);
            Dist.WriteText(fp);
            fclose(fp);
        }
    }
    return U_OK;
}


UHeadModel* UFitDipoles::GetHeadModel(UFileName HeadModelFileName, FitDataType FDT) const
{
    if(this==NULL || this->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::GetHeadModel(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data==NULL||Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::GetHeadModel(). Data not (properly) set.\n");
        return NULL;
    }
    
    double   DefHRad   = 10;
    UVector3 DefCenter = UVector3(0.,0.,4.);
    Data->GetEEGSphere(&DefCenter, &DefHRad);
    UHeadModel* HModel = NULL;

    if(HeadModelFileName.GetFullFileName()==NULL || HeadModelFileName.GetFullFileName()[0]==0)
    {
        HModel = new UHeadModel(DefCenter, DefHRad);
    }
    else
    {
        UFileName FullFileName(HeadModelFileName);
        if(FullFileName.IsPureFile()==true) 
            FullFileName = GetData()->GetDataFileName().GetSiblingFileName(HeadModelFileName.GetBaseName());
            
        if(FullFileName.DoesFileExist()==true)
        {
            HModel = new UHeadModel(FullFileName);
            if(HModel==NULL || HModel->GetError()!=U_OK) 
            {
                delete HModel;
                CI.AddToLog("ERROR: UFitDipoles::GetHeadModel() : Headmodel file exists, but UHeadModel()-object cannot be created.\n");
                return NULL;
            }
        }
        else
        {
            HModel = new UHeadModel(DefCenter, DefHRad);
            if(HModel && HModel->GetError()==U_OK) 
            {
                if(FDT!=U_MEG_ONLY && HModel->GetCondModelType()==U_CONDMOD_SPHERE)  HModel->SetThreeSphereModel(DefCenter, DefHRad);
                
                if(HeadModelFileName.HasExtension("txt"))
                {
                    HModel->WriteHeadModelFileTxt(FullFileName);
                    CI.AddToLog("ERROR: UFitDipoles::GetHeadModel() : Headmodel file does not exist. File with default parameters created: %s.\n",FullFileName.GetFullFileName());
                }
            }
            else
            {
                CI.AddToLog("ERROR: UFitDipoles::GetHeadModel(). Headmodel file does not exist. Cannot create UHeadModel-object\n");
            }
            delete HModel;
            return NULL;
        }
    }

    if(HModel==NULL || HModel->GetError()!=U_OK) 
    {
        delete HModel;
        return NULL;
    }
    if(FDT!=U_MEG_ONLY && HModel->GetCondModelType()==U_CONDMOD_SPHERE) 
        HModel->SetHomogeneousModel();

    return HModel;
}

const double* UFitDipoles::GetDataChannel(const double* DataEpMEG, const double* DataEpEEG, const double* DataEpADC, int NsampEp, const char* ChanName) const
{
    DataType DTchan = U_DAT_UNKNOWN;
    int ichan       = Data->GetChanAndType(ChanName, &DTchan);
    if(ichan>=0)
    {
        if(DTchan==U_DAT_MEG && DataEpMEG) return DataEpMEG+ichan*NsampEp;
        if(DTchan==U_DAT_EEG && DataEpEEG) return DataEpEEG+ichan*NsampEp;
        if(DTchan==U_DAT_ADC && DataEpADC) return DataEpADC+ichan*NsampEp;
    }
    CI.AddToLog("ERROR: UFitDipoles::GetDataChannel(). Cannot find channel number of channel %s \n", ChanName);
    return NULL;
}