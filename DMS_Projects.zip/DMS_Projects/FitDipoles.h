#ifndef _FITDIP_INCLUDED
#define _FITDIP_INCLUDED

#include "StartStatDip.h"
#include "LocStatDip.h"
#include "LocCodeDip.h"
#include "LocMovDip.h"

#include "FileName.h"
#include "MEEGDataEpochs.h"


class UFitDipoles : public UMEEGDataEpochs
{
public:
    enum CostType
    {
        U_ABS, 
        U_SQUARE, 
        U_WEIGHTED_OLS,
        U_THECOV,
        U_FILECOV  
    };
    enum FitDataType
    {
        U_MEG_AND_EEG,
        U_MEG_ONLY,
        U_EEG_ONLY
    };
    enum OutputFormat
    {
        U_OF_ALL_SAMP,  // one file, export all dipoles, time in samples
        U_OF_ALL_MS,    // one file, export all dipoles, time in ms
        U_OF_SKIP_SAMP, // one file, export low error dipoles only, time in samples
        U_OF_SKIP_MS,   // one file, export low error dipoles only, time in ms
        U_SF_ALL_SAMP,  // separate files, export all dipoles, time in samples 
        U_SF_ALL_MS,    // separate files, export all dipoles, time in ms 
        U_SF_SKIP_SAMP, // separate files, export low error dipoles only, time in samples
        U_SF_SKIP_MS,   // separate files, export low error dipoles only, time in ms
    };
    enum OutputType
    {
        U_SKIP,         // Skip writing if file exists
        U_DELETE,       // Delete and overwrite old results
        U_APPEND        // Append new results, when given file already exists
    };

    UFitDipoles(const char* DataSetName, const char* forceGoodCh, const char* forceBadCh, const char* OutputFile, 
                const UCostminimize& cst, OutputFormat OF, OutputType OT,
                UDipole::DipoleType DT = UDipole::Current);
    UFitDipoles(const UMEEGDataEpochs& DatEp, const char* OutputFile, const UCostminimize& cst, OutputFormat OF, OutputType OT,
                UDipole::DipoleType DT = UDipole::Current);

    virtual ~UFitDipoles();
    ErrorType GetError(void) const {if(UMEEGDataEpochs::GetError()!=U_OK) return U_ERROR; 
                                    else                                  return error;}

    ErrorType FitCodeDipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocCodeDip::CostType CT, bool AdFordMod, FitDataType FDT, UCodeManager::CodeType CdT); 
    ErrorType FitMovingDipoles(UFileName HeadModelFileName, const char* ChanName, UStartDipole::StartType ST, int Npts, UFitDipoles::CostType CT, bool AdFordMod, bool UseOldUnits, double MaxStartError, FitDataType FDT, double MinPowFact, bool ConfidenceLimits, double AmatThreshold, bool ManyDigits);
    ErrorType FitStationaryDipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocStatDip::CostType CT, bool AdFordMod, bool UseOldUnits, FitDataType FDT);
    ErrorType FitGMANOVADipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocCodeDip::CostType CT, bool AdFordMod, FitDataType FDT, int nDipoles, int nBasicSTF);

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;        // General error flag
    UFileName               FileNameOut;  // Name of output file 
    bool                    OneFile;      // Parameters determining the output file format
    bool                    AllDipoles;
    bool                    TimeInMs;
    OutputType              OutType;      // How to deal with existing file?

    UCostminimize           cost;         // Parameters determing the minimization method

/* Parameters for the moving dipole model:*/    
    UDipole::DipoleType     DType;        // Dipole type: current, symmetric, etc
    double                  MinDataPowMEG;// Skip all samples with data power lower than MinDataPowMEG
    double                  MinDataPowEEG;// and lower than MinDataPowEEG

    ErrorType               SetDataThresold(double MinFactor, FitDataType FDT);
    UDistribution*          PowerDistMEG; // Power distribution of the MEG/EEG
    UDistribution*          PowerDistEEG;
/* Parameters for the stationary dipole model:*/

/* Functions*/
    UHeadModel*             GetHeadModel(UFileName HeadModelFileName, FitDataType FDT) const;
    const double*           GetDataChannel(const double* DataEpMEG, const double* DataEpEEG, const double* DataEpADC, int NsampEp, const char* ChanName) const;
};
#endif// _FITDIP_INCLUDED
