#ifndef _FREESURFERDATA_INCLUDED
#define _FREESURFERDATA_INCLUDED

#include "Field.h"
#include "FileName.h"


#define UNUSED_SPACE_SIZE 256
#define USED_SPACE_SIZE   (3*sizeof(float)+4*3*sizeof(float))

#define MGH_VERSION       1


class DLL_IO UFreeSurferData
{
public:
    UFreeSurferData(UFileName FileName);
    ~UFreeSurferData();  

    ErrorType           GetError(void) const {if(this) return error; return U_ERROR;}
    UField*             GetField(void) const;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;
    ErrorType           error;
};

#endif //_FREESURFERDATA_INCLUDED
