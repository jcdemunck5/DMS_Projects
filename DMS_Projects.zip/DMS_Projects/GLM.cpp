/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*                                                                                */
/*     Object to compute parameters using the General Linear Model.               */
/*                                                                                */
/*     Data = parInterest * regInterest + parConfounders * refConfounders + noise */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    11-04-06   creation
  JdM    30-11-06   bug fix operator=(): DeleteAllMembers() iso SetAllMembersDefault()
  JdM    25-01-07   BUG FIX Correlate(). Pre-whiten copy of data, instead of data itself
FB/JdM   19-02-07   BUG FIX: Correlate()
                             Erroneous argument of betai(). (Ntime-NDistr-NRef)/2. instead of (Ntime-NDistr-1)/2.
JdM/SG   28-02-07   BUG FIX Correlate(): Accounting for round-off error in testing SumPalfa-SumP1
  JdM    15-11-07   Added GetParamCovarianceAsField()
  JdM    16-11-07   bug fix GetParamCovarianceAsField(). account for Norm[]
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    01-12-08   Correlate(). Added data variance pointer parameter
  JdM    05-04-09   BUG FIX: UFieldGraph** constructor. Norm[] was wrongly computed in case of Selector!=0.
                    As a consequence, if references contained large outliers at non-selected points, estimated parameters and covariances were WRONG!
                    Ratio of estimated parameters and SD were OK, p-values were OK as well.
                    Added GetParamCovarianceAsJacobi()
  JdM    13-10-09   Added GetDetectionPower() and GetEfficiency()
  JdM    14-10-09   Added GetDetectionPower() and GetEfficiency()
JdM/PvH  19-10-09   Bug fix: GetEfficiency(). return 1./Efficiency
  JdM    20-10-09   Bug fix: GetMaxDetectionPower(). invert order of HRF elements
  JdM    12-11-09   Added RefNames and ConfNames data members.
  JdM    17-01-14   Replaced GetParamCovarianceAsJacobi() by GetParamCovarianceMatrix() and made private, in order to eliminate the obsolete UJacobi object.
                    GetMaxDetectionPower(). Eliminate obsolete UJacobi object
                    IsDataSubThreshold(), DoesProjectedDataVanish(), Correlate(). Eliminate UJacobi base class function MultiplyAWmat() of UCovariance, use UMatrix argument (instead of UField)
  JdM    26-01-15   Eliminate double* arrays as much as possible. Use UMatrix objects instead.
  JdM    28-01-15   Renamed many variables according to De Munck et al (2007), NeuroImage
                    Completed the process set in on 26-01-15. Made Norm a local variable in the constructor
 */

#include "GLM.h"
#include "FieldGraph.h"
#include "Statistics.h"
#include "MatrixSymmetric.h"

UString UGLM::Properties = UString();

void UGLM::SetAllMembersDefault(void)
{
    error         = U_OK;
    Properties    = UString();

    RefNames      = UString();
    ConfNames     = UString();

    Ndata         = 0;
    NdataSel      = 0;
    Ninter        = 0;
    Nconfo        = 0;

    Selector      = NULL;
    Plam          = UProjector();
    PS            = UProjector();
    CovSel        = UCovariance();

    PRMatInv      = UMatrix();
    CovParPattern = UMatrixSymmetric();
}

void UGLM::DeleteAllMembers(ErrorType E)
{
    delete   Selector;
    SetAllMembersDefault();
    error = E;
}

UGLM::UGLM()
{
    SetAllMembersDefault();
}
UGLM::UGLM(const UGLM& GLM)
{
    SetAllMembersDefault();
    *this = GLM;
}

UGLM::~UGLM()
{
    DeleteAllMembers(U_OK);
}

UGLM& UGLM::operator=(const UGLM& GLM)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UGLM::operator=(). this==NULL  . \n");
        static UGLM Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&GLM==NULL)
    {
        CI.AddToLog("ERROR: UGLM::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&GLM) return *this;

    DeleteAllMembers(U_OK);

    error       = GLM.error;
    Properties  = GLM.Properties;
    RefNames    = GLM.RefNames;
    ConfNames   = GLM.ConfNames;

    Ndata       = GLM.Ndata;
    NdataSel    = GLM.NdataSel;
    Ninter      = GLM.Ninter;
    Nconfo      = GLM.Nconfo;
    if(GLM.Selector)
    {
        Selector = new bool[Ndata];
        if(Selector==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::operator=().  Copying selector.\n");
            return *this;
        }
        for(int k=0; k<Ndata; k++) Selector[k] = GLM.Selector[k];
    }
    Plam          = GLM.Plam;
    PS            = GLM.PS;
    CovSel        = GLM.CovSel;
    PRMatInv      = GLM.PRMatInv;
    CovParPattern = GLM.CovParPattern;

    if(Plam.GetError()!=U_OK || PS.GetError()!=U_OK || CovSel.GetError()!=U_OK || PRMatInv.GetError()!=U_OK || CovParPattern.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::operator=().  Copying projectors, covariance matrix or help arrays.\n");
        return *this;
    }

    return *this;
}

const UString& UGLM::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UGLM-object\n");
        return Properties;
    }
    Properties =  UString();
    Properties += UString(Ndata   , "Ndata           = %d \n"); 
    Properties += UString(NdataSel, "NdataSel        = %d \n"); 
    Properties += UString(Ninter  , "Ninter          = %d \n"); 
    Properties += UString(Nconfo  , "Nconfo          = %d \n"); 
    Properties += UString(BoolAsText(Selector!=NULL),"SelectorApplied = %s \n"); 
    Properties += UString("References      = ") + RefNames  + "\n";
    Properties += UString("Confounders     = ") + ConfNames + "\n";

    Properties += UString("\nPlam: \n"); 
    Properties += Plam.GetProperties("  ");
    Properties += UString("\nPS: \n"); 
    Properties += PS.GetProperties("  ");
    Properties += UString("\nCovar: \n"); 
    Properties += UString(CovSel.GetProperties("  "));

    if(Comment.IsNULL() || Comment.IsEmpty())     Properties.ReplaceAll('\n', ';');  
    else                                          Properties.InsertAtEachLine(Comment);

    return Properties;
}

UGLM::UGLM(const UFieldGraph* const* Field1DRef, int NRef, const UFieldGraph* const* Field1DDistr, int NDistr,
           const UField* FSelect, const UCovariance* Cov)
{
    SetAllMembersDefault();

/* Test (first) references */
    if(Field1DRef==NULL|| NRef<=0 || Field1DRef[0]==NULL || Field1DRef[0]->GetError()!=U_OK ||
                                     Field1DRef[0]->GetNpoints()<=0) 
    {
        CI.AddToLog("ERROR: UGLM::UGLM(). Input Reference UFieldGraph array is NULL or invalid NRef.\n");
        DeleteAllMembers(U_ERROR);
        return;
    }
/* Create selection array */
    if(FSelect)
    {
        Selector = FSelect->GetSelectionArray(0);
        if(Selector==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Creating selection array. \n");
            return;
        }
    }

    bool StoCollumns = true;
    Ndata            = Field1DRef[0]->GetNpoints();
    NdataSel         = UMatrix::GetNSelect(Selector, Ndata);
    Ninter           = NRef;
    Nconfo           = NDistr;

/* Create UMatrix of normalized references */
    UMatrix RSelNorm      = UMatrix((const UField*const*)Field1DRef, NRef, StoCollumns, Selector);
    UMatrixSymmetric Norm = RSelNorm.GetFrobNormColDiag();
    if(RSelNorm.GetError()!=U_OK || RSelNorm.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Converting UFieldGraps to UMatrix or computing norms. \n");
        return;
    }
    for(int k=0; k<Ninter; k++)
        if(Norm.GetElement(k,k) < 1.e-18)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Norm of reference %d is 0. \n", k);
            return;
        }

/* Normalize References */
    UMatrixSymmetric NormIn = Norm.GetInverse();
    RSelNorm                = RSelNorm * NormIn;

/* Create UMatrix of distractors */
    UMatrix SSel= UMatrix((const UField*const*)Field1DDistr, NDistr, StoCollumns, Selector);
    if(SSel.GetError()!=U_OK || SSel.GetNrow()!=RSelNorm.GetNrow()) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Creating UMatrix with distractors or length of distractors does not match that of references.\n");
        return; 
    }

/* Test Covariance */
    if(Cov)
    {
        if(Cov->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Erroneous UCovariance argument.\n");
            return;
        }
        if(Cov->GetNdim()!=Ndata)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). UCovariance argument has wrong dimensions (Ndim=%d), Ndata=%d.\n",Cov->GetNdim(),Ndata);
            return;
        }
        CovSel = UCovariance(*Cov);
        if(CovSel.GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Copying UCovariance object. \n");
            return;
        }
        if(Selector && CovSel.SelectRowCol(Selector)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Selecting samples from UCovariance object. \n");
            return;
        }
    }
    else
    {
        CovSel = UCovariance(NdataSel);
    }
    if(CovSel.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Setting or down-sampling Covariance .\n");
        return;
    }

    UProjector Pref(RSelNorm, StoCollumns, &CovSel, "Regressors of Interest");
    if(Pref.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Creating Projector from reference functions. \n");
        return;
    }

    RefNames  = UString(); for(int n=0; n<NRef;   n++) RefNames  += Field1DRef[n]  ->GetLabel() + UString(" ,"); RefNames .RemoveNewLines(false);
    ConfNames = UString(); for(int n=0; n<NDistr; n++) ConfNames += Field1DDistr[n]->GetLabel() + UString(" ,"); ConfNames.RemoveNewLines(false);

/* Compute projectors. PS = I - S (St S)inv St */
    PS = UProjector(SSel, StoCollumns, &CovSel, "Regressors of Nuisance");
    if(PS.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Creating Projector from distractor functions. \n");
        return; 
    }
    if(Nconfo>0)
    {
        PS.SetComplement(true);
        if(PS.ProjectCols(&RSelNorm)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLM::UGLM(). Computing projection of references onto NULL space of distractors. \n");
            return; 
        }
    }
    Plam = UProjector(RSelNorm, StoCollumns, "Plam"); /* Plam = R' (R't R')inv R't  with R' = PS R */
    if(Plam.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Creating Plam. \n");
        return; 
    }

/* CovParPattern[] = ((PS * RefNorm)T * (PS * RefNorm))inv   */
    CovParPattern = UMatrixSymmetric(RSelNorm.GetMTM()).GetInverse();
    if(CovParPattern.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Computing inverse of parameter covariance matrix. \n");
        return; 
    }

/* Computute help array PRMatInv ==  ( (R'tR')Inv  * R't )�   Last transpose to make it into col vector.*/
    PRMatInv = GetMatMul(RSelNorm, false, CovParPattern, false);
    if(PRMatInv.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLM::UGLM(). Computing help array. \n");
        return; 
    }

    CovParPattern = CovParPattern.GetAMAT(NormIn, false);
    PRMatInv      = PRMatInv * NormIn;
}

bool UGLM::IsDataSubThreshold(const UMatrix* Data, double Threshold) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::IsDataSubThreshold(). NULL or erroneous argument. \n");
        return true;
    }
    if(Data->GetNrow()!=Ndata || Data->GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UGLM::IsDataSubThreshold(). Matrix wronly sized (Nrow=%d, Ncol=%d). \n", Data->GetNrow(), Data->GetNcol());
        return true;
    }
    int    irow = -1;
    bool   Fabs = false;
    double DMax = Data->GetColMax(0, Fabs, Selector, &irow);
    if(DMax<=Threshold || irow<0) return true;
    return false;
}

bool UGLM::DoesSelectedDataVanish(const UMatrix* Data) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::DoesSelectedDataVanish(). NULL or erroneous argument. \n");
        return true;
    }
    if(Data->GetNrow()!=Ndata || Data->GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UGLM::DoesSelectedDataVanish(). Matrix wronly sized (Nrow=%d, Ncol=%d). \n", Data->GetNrow(), Data->GetNcol());
        return true;
    }
    int    irow = -1;
    bool   Fabs = true;
    double DMax = Data->GetColMax(0, Fabs, Selector, &irow);
    if(DMax==0. || irow<0) return true;
    return false;
}

UMatrixSymmetric UGLM::GetParamCovarianceMatrix(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetParamCovarianceMatrix(). NULL or erroneous object. \n");
        return NULL;
    }
    return CovParPattern;
}

UField* UGLM::GetParamCovarianceAsField(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetParamCovarianceAsField(). NULL or erroneous object. \n");
        return NULL;
    }
    if(CovParPattern.GetError()!=U_OK || Ninter<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetParamCovarianceAsField(). Object not properly set (Ninter=%d). \n", Ninter);
        return NULL;
    }

    UVector2 PMin(0.       ,0.       );
    UVector2 PMax(Ninter-1.,Ninter-1.);
    int      dims[2]     = {Ninter, Ninter};
    UField*  CovPatField = new UField(PMin, PMax, dims, UField::U_DOUBLE, 1);

    if(CovPatField==NULL || CovPatField->GetError()!=U_OK || CovPatField->GetDdata()==NULL)
    {
        delete CovPatField;
        CI.AddToLog("ERROR: UGLM::GetParamCovarianceAsField(). Creating UField-object. \n");
        return NULL;
    }
    UMatrixSymmetric Pat = GetParamCovarianceMatrix();
    CovPatField->SetData(Pat.GetMatrixArray());

    CovPatField->AddBorder(0, 1, 0);
    CovPatField->AddBorder(1, 1, 0);
    return CovPatField;
}

ErrorType UGLM::Correlate(const UMatrix* Data, double* Cor, double* pVal, double* Par, double* StanDev, double* VarData)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(PRMatInv.GetError()!=U_OK || CovParPattern.GetError()!=U_OK || Ndata==0 || NdataSel==0 ||
       Plam.GetError()!=U_OK || PS.GetError()!=U_OK || CovSel.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). Object not properly initialized. \n");
        return U_ERROR;
    }                   
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). NULL or erroneous argument. \n");
        return U_ERROR;
    }
    if(Data->GetNrow()!=Ndata || Data->GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). Data argument of wrong type (%s). \n", (const char*)Data->GetProperties(""));
        return U_ERROR;
    }
    if(Par==NULL && StanDev!=NULL)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). Cannot compute standard deviations without computing parametes. \n");
        return U_ERROR;
    }
    
    UMatrix DatVect(*Data, Selector, NULL);
    if(DatVect.GetError()!=U_OK || DatVect.GetNrow()!=NdataSel)
    {
        CI.AddToLog("ERROR: UGLM::Correlate(). Copying argument. \n");
        return U_ERROR;
    }
    DatVect      = CovSel.GetPreWhitened(DatVect);
    double        SumPlam    = Plam   .WeightedNorm(DatVect);
    double        SumPS = PS.WeightedNorm(DatVect);    
    if(Nconfo==0) SumPS = DatVect.GetFrobNorm2();

    if(SumPlam<=0. || SumPS<=0. || SumPS-SumPlam<-1.e-12 * SumPS )
    {
        CI.AddToLog("WARNING: UGLM::Correlate(). Invalid SumPlam (=%f) or SumPS (=%f)  .\n", SumPlam, SumPS);
        return U_ERROR;
    }
    
    double Correlation = sqrt(SumPlam/SumPS);
    if(Correlation>1.)
    {
        Correlation = 1.; 
        CI.AddToLog("WARNING: UGLM::Correlate(). Correlation set to 1. \n");
    }
    if(Ninter==1)
    {
        double covar = GetColProduct(PRMatInv, 0, DatVect, 0);
        if(covar<0) Correlation = -Correlation;
    }        
    if(Cor)     *Cor     = Correlation;
    if(VarData) *VarData = (SumPS-SumPlam)/NdataSel;
        
    if(Par)
    {
        for(int k=0; k<Ninter; k++)
        {
            Par[k] = GetColProduct(PRMatInv, k, DatVect, 0);
            if(StanDev)
            {
                double VarD = (SumPS-SumPlam)/NdataSel;
                if(VarD<=0) StanDev[k] = 0.;
                else        StanDev[k] = sqrt(VarD*CovParPattern.GetElement(k,k));
            }
        }
    }

/* Computation of p-value */
    if(pVal)  *pVal = 1. - betai(Ninter/2., (NdataSel-Nconfo-Ninter)/2., Correlation*Correlation);
    return U_OK;
}

double UGLM::GetEfficiency(double Variance) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetEfficiency(). NULL or erroneous object. \n");
        return 0.;
    }
    if(Variance<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetEfficiency(). Invalid Variance argument (%f). \n", Variance);
        return 0;
    }

    UMatrixSymmetric ParCo = this->GetParamCovarianceMatrix();
    if(ParCo.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). Getting parameter covariance matrix. \n");
        return 0.;
    }
    ParCo *= Variance;
    double Efficiency = ParCo.GetTrace();
    if(Efficiency<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). Invalid trace of covariance matrix. \n");
        return 0;
    }
    return 1./Efficiency;
}

double UGLM::GetDetectionPower(const UField* Shape) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). NULL or erroneous object. \n");
        return 0.;
    }
    if(Shape==NULL || Shape->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). Invalid (NULL) argument. \n");
        return 0;
    }
    if(Shape->Getndim()!=1 || Shape->GetVeclen()!=1 || Shape->GetDdata()==NULL)
    {
        UString Prop = Shape->GetProperties("");
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). UField argument of wrong type (%s). \n", (const char*)Prop);
        return 0.;
    }
    if(Shape->GetNpoints()!=Ninter)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). UField argument has wrong number of points (%d) instead of %d . \n", Shape->GetNpoints(), Ninter);
        return 0.;
    }

    UMatrix Svect(Shape->GetDdata(), Ninter, 1);
    double  Norm2 = Svect.GetFrobNorm2();
    if(Norm2<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). UField argument non-positive norm2. \n");
        return 0.;
    }
   
    UMatrixSymmetric ParCo = CovParPattern;
    if(ParCo.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). Copying parameter covariance matrix. \n");
        return 0.;
    }
    UMatrix DetectPower = ParCo.GetATMA(Svect, true);
    return DetectPower.GetElement(0)/Norm2;
}

double UGLM::GetMaxDetectionPower(const UField* Shape, int NNonCausal, UFieldGraph** BestDesign) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). NULL or erroneous object. \n");
        return 0.;
    }
    if(NdataSel<=0 || Ndata<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). NdataSel = %d, Ndata=%d. \n", NdataSel, Ndata);
        return 0.;
    }
    if(Shape==NULL || Shape->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). Invalid (NULL) argument. \n");
        return 0;
    }
    if(Shape->Getndim()!=1 || Shape->GetVeclen()!=1 || Shape->GetDdata()==NULL)
    {
        UString Prop = Shape->GetProperties("");
        CI.AddToLog("ERROR: UGLM::GetDetectionPower(). UField argument of wrong type (%s). \n", (const char*)Prop);
        return 0.;
    }
    UMatrix Smat  = UMatrix(Shape->GetDdata(), Shape->GetNpoints(), 1);
    double  Norm2 = Smat.GetFrobNorm2();
    if(Norm2<=0)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). UField argument non-positive norm2. \n");
        return 0.;
    }
    if(NNonCausal<0 || NNonCausal>Shape->GetNpoints())
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). NNonCausal = %d out of range (Npoints = %d).\n", NNonCausal, Shape->GetNpoints());
        return 0.;
    }
    int  NCausal = Smat.GetNrow()-NNonCausal;
    
    UMatrix Hmat(DNULL, NdataSel, Ndata);
    if(Hmat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). Memory allocation error (NdataSel=%d). \n", NdataSel);
        return 0.;
    }
    for(int j=0,jsel=0; j<Ndata; j++)
    {
        if(Selector && Selector[j]==false) continue; 

        for(int n=0; n<Ndata; n++)
        {
            int ip = j-n+NCausal-1;
            if(ip<-NNonCausal || ip>=NCausal) continue;
            Hmat.SetElement(jsel, n, Smat.GetElement(ip+NNonCausal));
        }
        jsel++;
    }

    UMatrixSymmetric Matrix = PS.GetATPA(Hmat);
    if(Matrix.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). Computing Ht PS H . \n");
        return 0.;
    }
    Matrix /= Norm2;

    double MaxDetection = Matrix.GetEigen(0);
    if(BestDesign)
    {
        delete *BestDesign; *BestDesign = NULL;
        UMatrix Vect = Matrix.GetEigenVector(0);
        *BestDesign  = new UFieldGraph((float)0.,float((Ndata-1)), Ndata, UField::U_DOUBLE);
        if(Vect.GetError()!=U_OK || *BestDesign==NULL || (*BestDesign)->GetError()!=U_OK)
        {
            delete   *BestDesign; *BestDesign = NULL;
            CI.AddToLog("ERROR: UGLM::GetMaxDetectionPower(). Getting first eigenvector or creating best design vector . \n");
        }
        (*BestDesign)->SetData(Vect.GetMatrixArray());
        (*BestDesign)->NormalizeData(false, true);
    }
    return MaxDetection;
}

