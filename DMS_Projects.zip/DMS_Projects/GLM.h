#ifndef _GLMODEL_INCLUDED
#define _GLMODEL_INCLUDED

#include "Covariance.h"
#include "Projector.h"
#include "String.h"

class UFieldGraph;
class UField;

class DLL_IO UGLM
{
public:
    UGLM();
    UGLM(const UGLM& GLM);
    UGLM(const UFieldGraph* const* Field1DRef, int NRef, const UFieldGraph* const* Field1DDistr, int NDistr,
         const UField* FSelect, const UCovariance* Cov);
    ~UGLM();  

    UGLM&                   operator=(const UGLM& GLM);
    ErrorType               GetError(void)     const {if(this) return error;    return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
    int                     GetNdata(void)     const {if(this) return Ndata;    return 0;}
    int                     GetNInterest(void) const {if(this) return Ninter;   return 0;}

    bool                    IsDataSubThreshold(const UMatrix* Data, double Threshold) const;
    bool                    DoesSelectedDataVanish(const UMatrix* Data) const;
    ErrorType               Correlate(const UMatrix* Data, double* Cor, double* pVal, double* Par, double* StanDev, double* VarData);

    UField*                 GetParamCovarianceAsField(void) const;

    double                  GetEfficiency(double Variance) const;
    double                  GetDetectionPower(const UField* Shape) const;
    double                  GetMaxDetectionPower(const UField* Shape, int NNonCausal, UFieldGraph** BestDesign) const;

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;            // General error flag
    static UString          Properties;
    UString                 RefNames;
    UString                 ConfNames;

    int                     Ndata;            // Number of data points
    int                     NdataSel;         // Number of selected data points
    int                     Ninter;           // Number of regressors of interest
    int                     Nconfo;           // Number of confounders, distractors

    bool*                   Selector;         // Indicator of selected data points (array of Ndata bools)
    UMatrix                 PRMatInv;         // = (R'tR')Inv  * R't, where R' = PS R, R is selected regressors

    UProjector              Plam;             // Plam  = R' (R't R')inv R't  with R' = PS R, with R ref (old name: P1)
    UProjector              PS;               // PS    = I - S (St S)inv St                             (old name: Palpha)
    UCovariance             CovSel;           // Covariance matrix of selected points

    UMatrixSymmetric        CovParPattern;    // Covariance pattern of parameters of interest. To get parameter covariance, multiply with data variance
    UMatrixSymmetric        GetParamCovarianceMatrix(void) const;
};

#endif //_GLMODEL_INCLUDED
