/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*                                                                                */
/*     Object to compute parameters using the General Linear Model.               */
/*                                                                                */
/*     Data = parInterest * regInterest + parConfounders * refConfounders + noise */
/*                                                                                */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    11-04-06   creation
  JdM    15-11-07   Added GetParamCovarianceAsScan()
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    01-12-08   Correlate(). Added data variance pointer parameter
  JdM    05-04-09   Added GetParamCovarianceAsJacobi()
  JdM    13-10-09   Added GetDetectionPower() and GetEfficiency()
  JdM    14-10-09   Added GetMaxDetectionPower()
  JdM    17-01-14   Removed (obsolete) GetParamCovarianceAsJacobi().
  JdM    18-01-14   IsDataSubThreshold(), DoesProjectedDataVanish(), Correlate(). Use UMatrix argument (instead of UField).
*/

#include "GLMArray.h"
#include "FieldGraph.h"
#include "Scan.h"
#include "Statistics.h"

UString UGLMArray::Properties = UString();

void UGLMArray::SetAllMembersDefault(void)
{
    error         = U_OK;
    Properties    = UString();

    NGLM          = 0;
    GLMArray      = NULL;
}

void UGLMArray::DeleteAllMembers(ErrorType E)
{
    if(GLMArray)
        for(int el=0; el<NGLM; el++) delete GLMArray[el];

    delete[] GLMArray;
    SetAllMembersDefault();
    error = E;
}


UGLMArray::UGLMArray()
{
    SetAllMembersDefault();
}
UGLMArray::UGLMArray(const UGLM& GLM)
{
    SetAllMembersDefault();
    if(&GLM==NULL || GLM.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Invalid NULL or erroneous UGLM argument  . \n");
        return;
    }
    NGLM = 1;
    GLMArray = new UGLM*[1];
    if(GLMArray==NULL) 
    { 
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Memory allocation. \n");
        return;
    }
    GLMArray[0] = new UGLM(GLM);
    if(GLMArray[0]==NULL || GLMArray[0]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Copying UGLM argument to array. \n");
        return;
    }
}

UGLMArray::UGLMArray(const UGLMArray& GLMA)
{
    SetAllMembersDefault();
    *this = GLMA;
}

UGLMArray::~UGLMArray()
{
    DeleteAllMembers(U_OK);
}

UGLMArray& UGLMArray::operator=(const UGLMArray& GLMA)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::operator=(). this==NULL  . \n");
        static UGLMArray Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&GLMA==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&GLMA) return *this;

    DeleteAllMembers(U_OK);

    error       = GLMA.error;
    Properties  = GLMA.Properties;

    NGLM        = GLMA.NGLM;
    if(GLMA.GLMArray)
    {
        GLMArray    = new UGLM*[GLMA.NGLM];
        if(GLMArray==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLMArray::operator=(). Creating array of %d points. \n",GLMA.NGLM);
            return *this;
        }
        for(int el=0; el<GLMA.NGLM; el++) GLMArray[el] = NULL;
        for(int el=0; el<GLMA.NGLM; el++)
        {
            GLMArray[el] = new UGLM(*GLMA.GLMArray[el]);
            if(GLMArray[el]==NULL || GLMArray[el]->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGLMArray::operator=(). copying element %d . \n",el);
                return *this;
            }
        }
    }
    return *this;
}

int UGLMArray::GetNdata() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetNdata(). Object NULL or not properly set. \n");
        return 0;
    }
    if(GLMArray==NULL || NGLM<=0 || GLMArray[0]==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::GetNdata(). GLMArray NULL or no GLMs set. \n");
        return 0;
    }
    return GLMArray[0]->GetNdata();
}

bool UGLMArray::IsNInterestConstant(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::IsNInterestConstant(). Object NULL or not properly set. \n");
        return false;
    }
    if(GLMArray==NULL || NGLM==0) return false;

    int NI = GLMArray[0]->GetNInterest();
    for(int el=1;el<NGLM; el++)
        if(NI!=GetNInterest(el)) return false;
    return true;
}
int UGLMArray::GetNInterest(int elem) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetNInterest(). Object NULL or not properly set. \n");
        return 0;
    }
    if(GLMArray==NULL || NGLM==0)
    {
        CI.AddToLog("ERROR: UGLMArray::GetNInterest(). GLMArray NULL or no GLMs set. \n");
        return 0;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::GetNInterest(). elem (%d) out of range (NGLM=%d). \n", elem, NGLM);
        return 0;
    }
    return GLMArray[elem]->GetNInterest();
}

const UString& UGLMArray::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UGLMArray-object\n");
        return Properties;
    }
    Properties =  UString();
    

    Properties += UString(NGLM    , "NGLM            = %d \n"); 
    if(NGLM>0)
    {
        Properties += UString("\nFirst Element: \n"); 
        if(GLMArray==NULL || GLMArray[0]==NULL)
        {
            Properties += UString("FirstElement   = NULL\n");
        }
        else
        {
            Properties += UString(GLMArray[0]->GetProperties(Comment+UString("  ")));
        }
    }
    if(Comment.IsNULL() || Comment.IsEmpty())     Properties.ReplaceAll('\n', ';');  
    else                                          Properties.InsertAtEachLine(Comment);

    return Properties;
}

UGLMArray::UGLMArray(const UFieldGraph* const* Field1DRef, int NRef, 
           const UFieldGraph* const* Field1DDistr, int NDistr,
           const UField* Select, const UCovariance* Cov)
{
    SetAllMembersDefault();

/* Test (first) references */
    if(Field1DRef==NULL|| NRef<=0) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Input Reference UFieldGraph array is NULL or invalid NRef (=%d).\n", NRef);
        return;
    }
    if(Field1DDistr==NULL||NDistr<=0) // To facilitate testing of pointers, assume at least one distractor
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Input Distractor UFieldGraph array is NULL or invalid NDistr (=%d).\n", NDistr);
        return;
    }

/* Test consisteny of veclen */
    NGLM = 1;
    for(int iref=0; iref<NRef; iref++)
    {
        if(Field1DRef[iref]==NULL || Field1DRef[iref]->GetError()!=U_OK ||
                                     Field1DRef[iref]->GetNpoints()<=0)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Reference function %d is NULL or erroneous.\n", iref);
            return;
        }
        int VecLen = Field1DRef[iref]->GetVeclen();
        if(VecLen!=1)
        {
            if(NGLM==1) NGLM = VecLen;
            else if(NGLM!=VecLen)
            {
                CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Reference function %d has inconsistent veclen (%d) NGLM = %d.\n", iref, VecLen, NGLM);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }
    }
    for(int idis=0; idis<NDistr; idis++)
    {
        if(Field1DDistr[idis]==NULL || Field1DDistr[idis]->GetError()!=U_OK ||
                                       Field1DDistr[idis]->GetNpoints()<=0)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Distractor function %d is NULL or erroneous.\n", idis);
            return;
        }
        int VecLen = Field1DDistr[idis]->GetVeclen();
        if(VecLen!=1)
        {
            if(NGLM==1) NGLM = VecLen;
            else if(NGLM!=VecLen)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Distractor function %d has inconsistent veclen (%d) NGLM = %d.\n", idis, VecLen, NGLM);
                return;
            }
        }
    }

/* Build array of GLMs*/
    GLMArray              = new UGLM*[NGLM];
    UFieldGraph** FRefComp= new UFieldGraph*[NRef  ];
    UFieldGraph** FDisComp= new UFieldGraph*[NDistr];
    if(GLMArray==NULL || FRefComp==NULL || FDisComp==NULL)
    {
        delete[] FRefComp;
        delete[] FDisComp;
        CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Memory allocation: NGLM = %d.\n", NGLM);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int el  =0; el  <NGLM;     el++) GLMArray[el  ] = NULL;
    for(int iref=0; iref<NRef  ; iref++) FRefComp[iref] = NULL;
    for(int idis=0; idis<NDistr; idis++) FDisComp[idis] = NULL;
    for(int el=0; el<NGLM; el++)
    {
/* Copy selected component to regressor */ 
        for(int iref=0; iref<NRef; iref++) 
        {
            int icomp = 0; if(Field1DRef[iref]->GetVeclen()>1) icomp = el;
            FRefComp[iref] = Field1DRef[iref]->GetComponent(icomp);
            if(FRefComp[iref]==NULL ||  FRefComp[iref]->GetError()!=U_OK)
            {
                for(int ir=0; ir<NRef  ; ir++) {delete FRefComp[ir]; FRefComp[ir]=NULL;}
                for(int id=0; id<NDistr; id++) {delete FDisComp[id]; FDisComp[id]=NULL;}
                delete[] FRefComp;
                delete[] FDisComp;
                CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Getting component %d from reference %d.\n", icomp, iref);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }
        for(int idis=0; idis<NDistr; idis++) 
        {
            int icomp = 0; if(Field1DDistr[idis]->GetVeclen()>1) icomp = el;
            FDisComp[idis] = Field1DDistr[idis]->GetComponent(icomp);
            if(FDisComp[idis]==NULL ||  FDisComp[idis]->GetError()!=U_OK)
            {
                for(int ir=0; ir<NRef  ; ir++) {delete FRefComp[ir]; FRefComp[ir]=NULL;}
                for(int id=0; id<NDistr; id++) {delete FDisComp[id]; FDisComp[id]=NULL;}
                delete[] FRefComp;
                delete[] FDisComp;
                CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Getting component %d from distractor %d.\n", icomp, idis);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }

/* Create element */ 
        GLMArray[el] = new UGLM(FRefComp, NRef, FDisComp, NDistr, Select, Cov);
        for(int iref=0; iref<NRef  ; iref++) {delete FRefComp[iref]; FRefComp[iref]=NULL;}
        for(int idis=0; idis<NDistr; idis++) {delete FDisComp[idis]; FDisComp[idis]=NULL;}

        if(GLMArray[el]==NULL || GLMArray[el]->GetError()!=U_OK)
        {
            delete[] FRefComp;
            delete[] FDisComp;
            CI.AddToLog("ERROR: UGLMArray::UGLMArray(). Creating GLM-object number = %d.\n", el);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    delete[] FRefComp;
    delete[] FDisComp;
}
bool UGLMArray::IsDataSubThreshold(int elem, const UMatrix* Data, double Threshold) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::IsDataSubThreshold(). Object NULL or erroneous. \n");
        return true;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::IsDataSubThreshold(). element out of range (elem=%d). \n", elem);
        return true;
    }
    if(GLMArray==NULL || GLMArray[elem]==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::IsDataSubThreshold(). Object not properly set (elem=%d). \n", elem);
        return true;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::IsDataSubThreshold(). NULL or erroneous argument. \n");
        return true;
    }
    return  GLMArray[elem]->IsDataSubThreshold(Data, Threshold);    
}

bool UGLMArray::DoesSelectedDataVanish(int elem, const UMatrix* Data) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::DoesSelectedDataVanish(). Object NULL or erroneous. \n");
        return true;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::DoesSelectedDataVanish(). element out of range (elem=%d). \n", elem);
        return true;
    }
    if(GLMArray==NULL || GLMArray[elem]==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::DoesSelectedDataVanish(). Object not properly set (elem=%d). \n", elem);
        return true;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::DoesSelectedDataVanish(). NULL or erroneous argument. \n");
        return true;
    }
    return GLMArray[elem]->DoesSelectedDataVanish(Data);
}

UScan* UGLMArray::GetParamCovarianceAsScan(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). NULL or erroneous object. \n");
        return NULL;
    }
    if(GLMArray==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). GLMArray==NULL or erroneous object. \n");
        return NULL;
    }
    UField** SliceArray = new UField*[NGLM];
    if(SliceArray==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). Memory allocation for SliceAarray (NGLM=%d) .\n", NGLM);
        return NULL;
    }
    for(int n=0; n<NGLM; n++)                 SliceArray[n] = NULL;
    for(int n=0; n<NGLM; n++) if(GLMArray[n]) SliceArray[n] = GLMArray[n]->GetParamCovarianceAsField();
    for(int n=0; n<NGLM; n++)
        if(SliceArray[n]==NULL || SliceArray[n]->GetError()!=U_OK)
        {
            for(int nn=0; nn<NGLM; nn++) delete SliceArray[nn]; delete[] SliceArray;

            CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). Creating Slice %d \n", n);
            return NULL;
        }


    UField F(SliceArray, NGLM, 0., NGLM-1.);
    for(int nn=0; nn<NGLM; nn++) delete SliceArray[nn]; delete[] SliceArray;
    if(F.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). Creating template UField-object. \n");
        return NULL;
    }
    if(NGLM==1) F.DuplicateSingleSlice();

    UScan* ParamCovarianceScan = new UScan(F);
    if(ParamCovarianceScan==NULL || ParamCovarianceScan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetParamCovarianceAsScan(). Creating output UScan-object. \n");
        delete ParamCovarianceScan;
        return NULL;
    }
    ParamCovarianceScan->SetOrientation(U_ORI_AXIAL);
    ParamCovarianceScan->ShiftCoords(-ParamCovarianceScan->GetCenter(false));
    ParamCovarianceScan->SetScanName("ParaCovariance");

    return ParamCovarianceScan;
}

ErrorType UGLMArray::Correlate(int elem, const UMatrix* Data, double* Cor, double* pVal, double* Par, double* StanDev, double* VarData) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::Correlate(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::Correlate(). element out of range (elem=%d). \n", elem);
        return U_ERROR;
    }
    if(GLMArray==NULL || GLMArray[elem]==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::Correlate(). Object not properly set (elem=%d). \n", elem);
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::Correlate(). NULL or erroneous Data argument. \n");
        return U_ERROR;
    }
    return GLMArray[elem]->Correlate(Data, Cor, pVal, Par, StanDev, VarData);
}
double UGLMArray::GetMaxDetectionPower(int elem, const UField* Shape, int NNonCausal, UFieldGraph** BestDesign) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::MaxGetDetectionPower(). NULL or erroneous object. \n");
        return 0.;
    }
    if(GLMArray==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::MaxGetDetectionPower(). GLMArray==NULL. \n");
        return 0.;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::MaxGetDetectionPower(). element out of range (elem=%d). \n", elem);
        return 0.;
    }
    if(Shape==NULL || Shape->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::MaxGetDetectionPower(). Invalid (NULL) argument. \n");
        return 0;
    }
    if(Shape->Getndim()!=1 || Shape->GetVeclen()!=1 || Shape->GetDdata()==NULL)
    {
        UString Prop = Shape->GetProperties("");
        CI.AddToLog("ERROR: UGLMArray::MaxGetDetectionPower(). UField argument of wrong type (%s). \n", (const char*)Prop);
        return 0.;
    }
    return GLMArray[elem]->GetMaxDetectionPower(Shape, NNonCausal, BestDesign);
}

double UGLMArray::GetDetectionPower(int elem, const UField* Shape) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetDetectionPower(). NULL or erroneous object. \n");
        return 0.;
    }
    if(GLMArray==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::GetDetectionPower(). GLMArray==NULL. \n");
        return 0.;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::GetDetectionPower(). element out of range (elem=%d). \n", elem);
        return 0.;
    }
    if(Shape==NULL || Shape->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetDetectionPower(). Invalid (NULL) argument. \n");
        return 0;
    }
    if(Shape->Getndim()!=1 || Shape->GetVeclen()!=1 || Shape->GetDdata()==NULL)
    {
        UString Prop = Shape->GetProperties("");
        CI.AddToLog("ERROR: UGLMArray::GetDetectionPower(). UField argument of wrong type (%s). \n", (const char*)Prop);
        return 0.;
    }
    return GLMArray[elem]->GetDetectionPower(Shape);
}
double UGLMArray::GetEfficiency(int elem, double Variance) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGLMArray::GetEfficiency(). NULL or erroneous object. \n");
        return 0.;
    }
    if(GLMArray==NULL)
    {
        CI.AddToLog("ERROR: UGLMArray::GetEfficiency(). GLMArray==NULL. \n");
        return 0.;
    }
    if(elem<0 || elem>=NGLM)
    {
        CI.AddToLog("ERROR: UGLMArray::GetEfficiency(). element out of range (elem=%d). \n", elem);
        return 0.;
    }
    if(Variance<=0)
    {
        CI.AddToLog("ERROR: UGLMArray::GetEfficiency(). Invalid Variance argument (%f). \n", Variance);
        return 0;
    }
    return GLMArray[elem]->GetEfficiency(Variance);
}
