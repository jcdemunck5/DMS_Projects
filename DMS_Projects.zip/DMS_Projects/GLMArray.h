#ifndef _GLMARRAY_INCLUDED
#define _GLMARRAY_INCLUDED

#include "GLM.h"

class UScan;
class DLL_IO UGLMArray
{
public:
    UGLMArray();
    UGLMArray(const UGLM& GLM);
    UGLMArray(const UGLMArray& GLMA);
    UGLMArray(const UFieldGraph* const* Field1DRef, int NRef, 
         const UFieldGraph* const* Field1DDistr, int NDistr,
         const UField* Select, const UCovariance* Cov);
    ~UGLMArray();  

    UGLMArray&              operator=(const UGLMArray& GLMA);
    ErrorType               GetError(void) const {return error;}
    const UString&          GetProperties(UString Comment) const;
    
    int                     GetNGLM(void)  const {return NGLM;}
    int                     GetNdata() const;
    int                     GetNInterest(int elem) const;
    bool                    IsNInterestConstant(void) const;

    bool                    IsDataSubThreshold(int elem, const UMatrix* Data, double Threshold) const;
    bool                    DoesSelectedDataVanish(int elem, const UMatrix* Data) const;
    ErrorType               Correlate(int elem, const UMatrix* Data, double* Cor, double* pVal, double* Par, double* StanDev, double* VarData) const;

    UScan*                  GetParamCovarianceAsScan(void) const;
    double                  GetDetectionPower(int elem, const UField* Shape) const;
    double                  GetMaxDetectionPower(int elem, const UField* Shape, int NNonCausal, UFieldGraph** BestDesign) const;
    double                  GetEfficiency(int elem, double Variance) const;
protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;            // General error flag
    static UString          Properties;
    
    int                     NGLM;
    UGLM**                  GLMArray;
};

#endif //_GLMARRAY_INCLUDED


