/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Module to generate spatially and temporally correlated noise of              */
/*     E/MEG data trials. It is assumed that the spatial-temporal correlation is    */
/*     the Kronecker product of a spatial and a temporal part.                      */
/*                                                                                  */
/*     The UCovariance object is used to create the spatial and temporal covriances */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history

  Who    When       What
  JdM    29-06-00   creation.
  JdM    03-07-00   Test results and include random dipole model for spatial covariane
  JdM    05-09-00   Added operator=() and default constructor
  JdM    03-12-00   Few minor bug fixes in GetProperties()
  JdM    20-08-01   Export seed point of base class in GetProperties()
  JdM    26-10-04   Add new constructor, replace include files
                    GetSpaceTime(): More strict test on parameters, add RMS parameter
  JdM    02-11-04   GetSpaceTime(): Test whether covariance matrix is inverted, or not.
  JdM    20-07-06   Added constructor based on UMEEGDataBase
  JdM    05-01-07   Removed constructor referring to (obsolete) UCTFData
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    20-07-14   Completely restructured object. Use UMatrixSymmetric and store its inv sqrt
*/


#include <string.h>

#include "GaussNoise.h"
#include "MatrixSymmetric.h"

/* Inititalize static (const) parameters. */
UString UGaussNoise::Properties = UString();

void UGaussNoise::SetAllMembersDefault()
{
    error      = U_OK;
    PrewXX     = UMatrix();
    PrewTT     = UMatrix();
}

void UGaussNoise::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UGaussNoise::UGaussNoise() : UGaussian(1.,0.)
{
    SetAllMembersDefault();
}


UGaussNoise::UGaussNoise(const UMatrixSymmetric& XCov, const UMatrixSymmetric& TCov) :
    UGaussian(1.,0.,1) // Seed point
{
    SetAllMembersDefault();

    if(&XCov==NULL || XCov.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGaussNoise::UGaussNoise(). Erroneous spatial covariance argument.\n");
        return;
    }
    if(&TCov==NULL || TCov.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGaussNoise::UGaussNoise(). Erroneous temporal covariance argument.\n");
        return;
    }

    UMatrixSymmetric XX = XCov; PrewXX = XX.GetInvertSqrt();
    UMatrixSymmetric TT = TCov; PrewTT = TT.GetInvertSqrt();
    if(PrewXX.GetError()!=U_OK || PrewTT.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGaussNoise::UGaussNoise(). Copying argument(s).\n");
        return;
    }
}


UGaussNoise::~UGaussNoise()
{
    DeleteAllMembers(U_OK);
}

UGaussNoise& UGaussNoise::operator=(const UGaussNoise& g)
{
    if(this==&g) return *this;

    UGaussian::operator=(g);

    DeleteAllMembers(U_OK);

    error       = g.error;
    PrewXX      = g.PrewXX;
    PrewTT      = g.PrewTT;
    if(PrewXX.GetError()!=U_OK || PrewTT.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGaussNoise::operator=(). Copying whitening argument(s).\n");
        return *this;
    }
    return *this;
}

double* UGaussNoise::GetSpaceTime(int nX, int nT, double RMS)
{
    if(this==NULL || error!=U_OK) return NULL;

    if(RMS<=0.)
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Invalid RMS value (RMS=%f). \n", RMS);
        return NULL;
    }
    if(nX != PrewXX.GetNrow())
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Number of requested channels (%d ) not compatible with XX-object (Ndim=%d). \n",nX, PrewXX.GetNrow());
        return NULL;
    }
    if(nT != PrewTT.GetNrow())
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Number of requested samples (%d ) not compatible with TT-object (Ndim=%d). \n",nT, PrewTT.GetNrow());
        return NULL;
    }

    double* NoiseData  = new double[nX*nT];
    if(NoiseData==NULL)
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Memory allocation (nTime=%d, nKan=%d)\n",nT,nX);
        return NULL;
    }
    UMatrix       N    = GetSpaceTime(RMS);
    const double* DatN = N.GetMatrixArray();

    for(int k=0; k<nX*nT; k++) NoiseData[k] = DatN[k];

    return NoiseData;
}
UMatrix UGaussNoise::GetSpaceTime(double RMS)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(RMS<=0.)
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Invalid RMS value (RMS=%f). \n", RMS);
        return UMatrix(U_ERROR);
    }
    int     NX         = PrewXX.GetNrow();
    int     NT         = PrewTT.GetNcol();
    double* NoiseData  = new double[NX*NT];
    if(NoiseData==NULL)
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Memory allocation (NX=%d, NT=%d)\n", NX, NT);
        return UMatrix(U_ERROR);
    }

    for(int k=0; k<NX*NT; k++) NoiseData[k] = GetGaussian();

    UMatrix N(NoiseData, PrewXX.GetNcol(), PrewTT.GetNrow());
    delete[] NoiseData;
    if(N.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGaussNoise::GetSpaceTime(). Creating Output matrix.\n");
        return UMatrix(U_ERROR);
    }
    
    UMatrix XXN     = GetMatMul(PrewXX, true , N,      false);
    UMatrix XXNTT   = GetMatMul(XXN   , false, PrewTT, false);

    double TrueRMS  = XXNTT.GetFrobNorm() / sqrt( double(NX*NT) );
    XXNTT          *= RMS/TrueRMS;

    return XXNTT;
}

const UString& UGaussNoise::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UGaussNoise() object.");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(UGaussian::GetSeedPoint() , "Seed          = %d \n");
    Properties += UString("PrewXX: \n");
    Properties += PrewXX.GetProperties(UString("   ")+Comment);
    Properties += UString("PrewTT: \n");
    Properties += PrewTT.GetProperties(UString("   ")+Comment);

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}
