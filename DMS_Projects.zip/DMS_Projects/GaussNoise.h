#ifndef _GAUSSNOISE_INCLUDED
#define _GAUSSNOISE_INCLUDED

#include "Random.h"
#include "Matrix.h"

class UMatrixSymmetric;
class DLL_IO UGaussNoise : public UGaussian
{
public:
    UGaussNoise();
    UGaussNoise(const UMatrixSymmetric& CovX, const UMatrixSymmetric& CovT);
    ~UGaussNoise();
    UGaussNoise&        operator=(const UGaussNoise& g);

    ErrorType           GetError(void) const {return error;}
    const UString&      GetProperties(UString Comment) const;

    double*             GetSpaceTime(int nX, int nT, double RMS);
    UMatrix             GetSpaceTime(double RMS);

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;
    static UString      Properties;
    
    UMatrix             PrewXX;  // PrewXX * PrewXX� = CovX inv
    UMatrix             PrewTT;  // PrewTT * PrewTT� = CovT inv
};
#endif  // _GAUSSNOISE_INCLUDED
