/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for generating gauusian noise.                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    27-02-00   creation 
*/

#include<time.h>
#include<stdlib.h>
#include<math.h>

#include"Gaussian.h"

UGaussian::UGaussian(int seed)
{
    if(seed==0) 
    {
        time_t long_time;
        time( &long_time );
        SeedPoint = int(long_time);
    }
    else 
        SeedPoint = seed;
    srand(SeedPoint);
}

UGaussian& UGaussian::operator=(const UGaussian& g) 
{
    SeedPoint = g.SeedPoint; 
    return *this;
}


void UGaussian::SetSeedPoint(int seed)
/*
   Set the seed point equal to seed and reset the random generator.
 */
{
    if(seed==0) 
    {
        time_t long_time;
        time( &long_time );
        SeedPoint = int(long_time);
    }
    else 
        SeedPoint = seed;
    srand(SeedPoint);
}


double UGaussian::GetGaussian(double StDev) const
{
    static int    iset=0;
    static double gset;
    double fac,rsq,v1,v2;

    if(iset==0) 
    {
        do
        {
            v1  = -1.+ 2.*rand()/(double) RAND_MAX;
            v2  = -1.+ 2.*rand()/(double) RAND_MAX;
            rsq = v1*v1+v2*v2;
        } 
        while(rsq >= 1.0 || rsq == 0.0);
        
        fac  = StDev*sqrt(-2.0*log(rsq)/rsq);
        gset = v1*fac;
        iset = 1;
        return v2*fac;
    } 
    else 
    {
        iset=0;
        return gset;
    }
}