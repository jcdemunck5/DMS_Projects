#ifndef _GAUSSIAN_INCLUDED
#define _GAUSSIAN_INCLUDED

#include"BasicInclude.h"

class DLL_IO UGaussian
{
public:
    UGaussian(int seed = 0);
    UGaussian& operator=(const UGaussian& g); 

    double GetGaussian(double StDev) const;

    void   SetSeedPoint(int seed);
    int    GetSeedPoint(void) const {return SeedPoint;}

private:
    int SeedPoint;

};
#endif //_GAUSSIAN_INCLUDED
