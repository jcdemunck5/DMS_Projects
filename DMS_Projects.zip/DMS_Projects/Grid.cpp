/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a grid with EEG/MEG sensor positions, C++ version. */
/*     Each of the sensors can be of its own type: EEG, magnetometer,            */
/*     gradiometer, see USensor                                                  */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    20-02-97   creation
  Jdm    05-03-98   removed bug in operator=() (free memory)
  Jdm    30-03-98   New interface: use class USensor() instead of struct SENSOR
  Jdm    24-04-98   New constructor for UGrid, using a .xyz-file
  Jdm    01-07-98   BUG IsSeparator(): SPACE (=32) IS a separator.
  Jdm    24-07-98   BUG IsSeparator(): 'a' (=97) IS NO separator.
  Jdm    11-09-98   Move IsSeparator() to include file: grid.h.
  Jdm    29-09-98   Consider lines starting with either %%, // or CC as comment lines in UGrid-constructors
  JdM    08-10-98   separated include-files
  Jdm    14-10-98   Use the UAnalyzeLine -object to read ASCII=files
  Jdm    16-11-98   Added SubSample()
  JdM    28-12-98   Added more detailed comments
  JdM    24-02-99   Added default constructor
  JdM    27-07-99   Commented some functions in order to reduce the amount of source files
  Jdm    01-12-99   Set the names of the sensors to the index in one of the constructors.
  JdM    27-03-00   operator==() : Test whether this==&g
  JdM    14-06-00   Added  GetChannum()
JdM/SG   10-10-00   Skip empty lines when reading .xyz files
  JdM    06-06-01   Added AreLabelsCompatible()
  JdM    19-07-01   Added new constructor, based on default EEG electrode labels
  JdM    14-08-01   Added RemoveSensor() and RemoveDoubleSensors()
  JdM    29-08-01   Added default MEG sensor positions
  JdM    01-10-01   Added AddGrid(). Remove TriList;
  JdM    15-11-01   Bug fix in default labels: CP -> CP5
  JdM    27-11-01   Added new constructor using default MEG/EEG sensors
                    Added default MEG sensor "MLO41", by mirroring "MRO41" in y=0 -plane
  JdM    18-07-02   Added RemoveSensors()
  JdM    26-07-02   Added triangulation of sensors.
  JdM    29-08-02   Bug FIx copy constructor. Probably due to changes on 26-07-02.
  JdM    09-07-02   Bug fix: TriangulateGrid(). No triangulation possible with fewer than 3 points
  JdM    18-09-02   Added parameter SkipTriangulation to one of the constructors
JdM/SG   13-02-03   Bug fix in constructor using .xyz-file (_error!=U_OK, before triangulation)
  JdM    27-03-03   TriangulateGrid(). Set MAXEDGE_REL=0.8 (i.s.o .4)
  SG     05-06-03   Bug Fix: Copy Constructor. When copying the sensors, set loop upper limit to g._npoints.
  JdM    17-06-03   Added operator==() and operator!=()
  JdM    27-03-03   TriangulateGrid(). Set MAXEDGE_REL=1.1 (i.s.o .8)
  JdM    11-07-03   Bug fix in constructor using electrode labels (_error!=U_OK, before triangulation)
  JdM    31-10-03   Added AddSensor() and a mechanism to allocate more memory for sensors then there are (using new member _npointsAlloc)
  JdM    03-11-03   Bug fix in constructors, in relation to 31-10-03
  JdM    05-11-03   Added AreSensorLabelsEqual()
  JdM    15-11-03   Added IsStandardEEGLabel()
  JdM    21-11-03   Addded GetDefaultSensor()
  JdM    22-02-04   BUG FIX: changed default electrode coordinates into NLR (inverting x and y)
 JdM/TM  02-03-04   bug fix: UGrid::UGrid(GridType GT). The parameter _error was not properly set in case of error condition
  JdM    02-07-04   Copy constructor: test NULL address
  JdM    05-07-04   TriangulateGrid(): continue until no isolated sensors are left
  JdM    28-12-04   Added four default electrodes: PO9, PO10, I1 and I2
  JdM    30-12-04   bug fix: AddGrid(). Update _npointsAlloc
                    IsStandardEEGLabel() and GetDefaultSensor(). Ignore first character if it is '_' or '-'
  JdM    17-01-05   Added GetNDoubleSensors(). AddGrid(): do not triangulate if GetNDoubleSensors()>20
  JdM    10-02-05   (Re-)implemented SubSample()
  JdM    25-02-05   Adeed new FileName constructor. Remove default arguments from old version (with the dummy label)
  JdM    14-03-05   Bug Fix: AddGrid(). Set _Tri=NULL after deleting it
  JdM    08-05-05   GetDefaultSensor(). Extend algorithm to case that '-' or '_' appears in the middle of the label
  JdM    07-06-05   Added IsStandardMEGLabel()
  JdM    03-08-05   Added GetGridType()
  JdM    08-08-05   Added GetDistance()
  JdM    26-08-05   Added WriteXYZ()
  JdM    15-09-05   Bug fix GetDefaultSensor(). strlen(Name) i.s.o. strlen(NameCopy)
  JdM    16-09-05   GetChannum(): Test case insensitive match, and skip first dummy char
  JdM    27-12-05   Added UGroup-object to keep track of all sensor group numbers
                    Added SetAllMembersDefault() and DeleteAllMembers()
  JdM    16-01-06   Added UGroup::UpdateGroups() and UGroup::GetUnusedGroupNumber(), UGrid::UpdateGroups()
  JdM    26-01-06   Added PutSensorTypesInDifferentGroups()
  JdM    26-02-06   Added SetSensorGroup() and SetCTFSensorGroups()
  JdM    28-03-06   Added GetSensorIndex() and GetHomologueSensorIndex()
  JdM    29-03-06   Added GetLeftHomologueIndex() and GetRightHomologueIndex()
  JdM    10-05-06   Bug fix: UGroup::UpdateGroups(). Avoid memory leaks (reset ElemArray only when NItemAlloc is increased)
  JdM    18-05-06   Bug fix: UGroup::UpdateGroups(). Setting NItem, in case that NItemAlloc<N (Set NItem in final stage)
  JdM    08-06-06   Added SelectSensors()
  JdM    11-08-06   Extended algorithm for IsStandardEEGLabel()
  JdM    23-09-06   Extended algorithm for IsStandardEEGLabel() and GetDefaultSensor() (allow leading '^')
  JdM    25-09-06   Added MakeLabelsUnique()
  JdM    23-11-06   Test for #define PUBLIC_SOURCES to make "more public sources"
  JdM    31-01-07   WritXYZ(). Added line "XYZFile1.0"
  JdM    05-02-07   Added ProjectSphere()
  JdM    10-04-07   Split off UGroup. _sensors is made double pointer.
  JdM    04-06-07   BUG Fixes. Destructor:                        delete elements of _sensors
                               GetNDoubleSensors().               compare contents of pointers i.s.o. pointers
                               RemoveSensor(), RemoveSensors().   delete removed sensor
  JdM    18-06-07   bug fix: SubSample(), case (iclose<0) (should not happen...)
  JdM    26-10-07   Added WriteBinary() and FILE* constructor to UGrid
  JdM    21-11-07   Added ConvertGradioToMagneto()
  JdM    22-11-07   Added ShiftSensors()
  JdM    23-11-07   Points[] constructor: normalize orientation, set compensation coil
  JdM    27-01-08   Added RemoveZeroSensors() and GetSubGridIndices() and IsSubGrid()
  JdM    31-01-08   Added GetGroupName()
  JdM    13-03-08   Bug fix: PutSensorTypesInDifferentGroups(). Determination of range (this was always 2)
                    Added PutSamePositionsInSameGroup()
  JdM    21-05-08   Bug Fix: XYZ-file constructor: test for "XYZFile1.0" in first line
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    22-12-08   Renamed GroupNumber to GroupID, in functions and dat members
  JdM    04-05-09   Added GetNeighbouringSensorIndices()
  JdM    11-01-10   Added three "standard" EEG electrodes
  JdM    05-02-10   Added IsCTFGrid()
  JdM    13-02-10   Added GetSensorTypeIndices() and new GetSubGrid()
  JdM    03-03-10   Added sensor type specific Transform()
  JdM    03-11-10   Added Transform() with ULinTran argument
  JdM    27-11-10   Structured initialization of structure constants
  JdM    21-03-12   Added GetCommonSensors() and GetIndexFromName()
  JdM    01-12-12   Constructor: also read .elc files
  JdM    21-12-12   GetDefaultSensor(). Remove WARNING for unresolved electrode label. 
                                        Set default type U_SEN_POINT (instead of U_SEN_EEG)
  JdM    23-12-12   Added GetMinDistance()
  JdM    26-12-12   Changed the algorithm of SubSample()  JdM    21-05-13   Added .lay data file format
  JdM    24-07-13   MakeLabelsUnique(). return U_OK when no sensors are set.
  JdM    08-09-13   BUG Fix: PutSensorTypesInDifferentGroups(). Computing range. As a consequence, groups of different sensor types may overlap.
  JdM    31-10-13   Bug Fix: AddGrid(). Updating Group when _ntri == NULL (Changed order).
  JdM    23-11-13   Added GetSubGridFirst()
  JdM    09-01-14   Bug FIX: UGrid(UFileName). Testing for .elc or .lay extension
  JdM    01-02-14   Bug fix: Lowered default position of T7 and T8 because it coincided with T4 and T3. 
                    UGrid(GridType ): Skip double labels A1, A2, T6 and T5
  JdM    03-02-14   Changed positions of Iz, Nz, T9 and T10 to bring them on a sphere of radius 10.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    22-11-14   Added tolerance argument to RemoveDoubleSensors()
  JdM    18-01-15   Added const bool* based SelectSensors()
  JdM    22-02-15   BUG Fix: RemoveDoubleSensors(). Explore ALL combinations of sensors. Old code left pairs od sensors closer than tolerance.
  JdM    04-03-15   Reading .xyz file: replace \n in identifier. Skip (0.,0.,0.) sensors.
                    WriteXYZ(). Added channel selection parameter.
  JdM    13-06-15   Bug Fix: WriteBinary(). Writing triangulation was erroneous.
  JdM    20-06-15   Reading .xyz file: Keep electrode labels starting with CC
  JdM    19-09-15   Moved DEFAULTelectrode and DEFAULTgradiometer to Sensor.h
  JdM    28-09-15   Added ReorderSensors()
  JdM    02-10-15   Added GetSensorNameOrder()
  JdM    29-03-16   IsStandardEEGLabel() and GetDefaultSensor(). Treat � � equal as �^�
  JdM    09-09-16   TriangulateGrid(). Remove MAXEDGE_REL. Add MaxEdgeRel as argument with default value 1.1 (as before)
  JdM    09-09-16   Added CopyIDsFromNames()
  JdM    11-09-16   IsStandardEEGLabelRefLay() and IsStandardREFLabelRefLay()
  JdM    14-09-16   Added GetGroupNameOrder()
  JdM    12-02-17   Added WriteTxt()
  JdM    26-03-18   Added GetSensorClosestToAxis()
  JdM    01-06-18   Added new (UString based) SelectSensors().
  JdM    03-06-18   TriangulateGrid(). Randomize sensor positions in case of overlap.
  JdM    13-09-18   Bug Fix: SelectSensors(UString* ). Update _npointsAlloc
 */

#include <string.h>

#include "Grid.h"
#include "GridFit.h"
#include "Group.h"
#include "AnalyzeLine.h"
#include "SortSemiSort.h"
#include "Random.h"

const char*  UGrid::HEADERBEGIN = "Grid1.0";
const char*  UGrid::HEADEREND   = "GridEnd";

#define NDEFELECT 90
static DEFAULTelectrode DefArrayE[NDEFELECT] =
{{"Cz\0   ",  0.    ,  0.    , 10.    },
 {"CPz\0  ", -3.2557,  0.    ,  9.4552},
 {"C2\0   ",  0.    , -3.2557,  9.4552},
 {"FCz\0  ",  3.2557,  0.    ,  9.4552},
 {"C1\0   ",  0.    ,  3.2557,  9.4552},
 {"CP2\0  ", -3.3197, -3.3197,  8.8295},
 {"FC2\0  ",  3.3197, -3.3197,  8.8295},
 {"FC1\0  ",  3.3197,  3.3197,  8.8295},
 {"CP1\0  ", -3.3197,  3.3197,  8.8295},
 {"Pz\0   ", -6.5606,  0.    ,  7.5471},
 {"C4\0   ",  0.    , -6.5606,  7.5471},
 {"Fz\0   ",  6.5606,  0.    ,  7.5471},
 {"C3\0   ",  0.    ,  6.5606,  7.5471},
 {"P2\0   ", -7.2803, -3.0156,  6.1566},
 {"CP4\0  ", -3.0156, -7.2803,  6.1566},
 {"FC4\0  ",  3.0156, -7.2803,  6.1566},
 {"F2\0   ",  7.2803, -3.0156,  6.1566},
 {"F1\0   ",  7.2803,  3.0156,  6.1566},
 {"FC3\0  ",  3.0156,  7.2803,  6.1566},
 {"CP3\0  ", -3.0156,  7.2803,  6.1566},
 {"P1\0   ", -7.2803,  3.0156,  6.1566},
 {"P4\0   ", -5.6472, -5.6472,  6.0182},
 {"F4\0   ",  5.6472, -5.6472,  6.0182},
 {"F3\0   ",  5.6472,  5.6472,  6.0182},
 {"P3\0   ", -5.6472,  5.6472,  6.0182},
 {"POz\0  ", -9.2388,  0.    ,  3.8268},
 {"PO4\0  ", -8.5355, -3.5355,  3.8268},
 {"P6\0   ", -6.5328, -6.5328,  3.8268},
 {"CP6\0  ", -3.5355, -8.5355,  3.8268},
 {"C6\0   ",  0.    , -9.2388,  3.8268},
 {"FC6\0  ",  3.4609, -8.5661,  3.8268},
 {"F6\0   ",  6.5328, -6.5328,  3.8268},
 {"AF4\0  ",  8.5355, -3.5355,  3.8268},
 {"AFz\0  ",  9.2388,  0     ,  3.8268},
 {"AF3\0  ",  8.5355,  3.5355,  3.8268},
 {"F5\0   ",  6.5328,  6.5328,  3.8268},
 {"FC5\0  ",  3.4609,  8.5661,  3.8268},
 {"C5\0   ",  0.    ,  9.2388,  3.8268},
 {"CP5\0  ", -3.5355,  8.5355,  3.8268},
 {"P5\0   ", -6.5328,  6.5328,  3.8268},
 {"PO3\0  ", -8.5355,  3.5355,  3.8268},
 {"Oz\0   ",-10.    ,  0.    ,  0.},
 {"O2\0   ", -9.5106, -3.0902,  0.},
 {"PO8\0  ", -8.0902, -5.8779,  0.},
 {"P8\0   ", -5.8779, -8.0902,  0.},
 {"TP8\0  ", -3.0902, -9.5106,  0.},
 {"T8\0   ",  0.    , -9.7980, -2.},
 {"FT8\0  ",  3.0902, -9.5106,  0.},
 {"F8\0   ",  5.8779, -8.0902,  0.},
 {"AF8\0  ",  8.0902, -5.8779,  0.},
 {"FP2\0  ",  9.5106, -3.0902,  0.},
 {"FPz\0  ", 10     ,  0.    ,  0.},
 {"FP1\0  ",  9.5106,  3.0902,  0.},
 {"AF7\0  ",  8.0902,  5.8779,  0.},
 {"F7\0   ",  5.8779,  8.0902,  0.},
 {"FT7\0  ",  3.0902,  9.5106,  0.},
 {"T7\0   ",  0.    ,  9.7980, -2.},
 {"TP7\0  ", -3.0902,  9.5106,  0.},
 {"P7\0   ", -5.8779,  8.0902,  0.},
 {"PO7\0  ", -8.0902,  5.8779,  0.},
 {"O1\0   ", -9.5106,  3.0902,  0.},
 {"Iz\0   ", -9.0631,  0.    , -4.2261},
 {"T10\0  ",  2.4824, -9.0631, -3.4202},
 {"Nz\0   ",  9.0631,  0.    , -4.2261},
 {"T9\0   ",  2.4824,  9.0631, -3.4202},
 {"F9\0   ",  4.8398,  8.0547, -3.4202},
 {"FT9\0  ",  2.1138,  9.1561, -3.4202},
 {"TP9\0  ", -2.9038,  8.9370, -3.4202},
 {"P9\0   ", -5.5234,  7.6023, -3.4202},
 {"PI1\0  ", -8.5845,  3.8221, -3.4202},
 {"PI2\0  ", -8.5845, -3.8221, -3.4202},
 {"P10\0  ", -5.5234, -7.6023, -3.4202},
 {"TP10\0 ", -2.9038, -8.937 , -3.4202},
 {"FT10\0 ",  2.1138, -9.1561, -3.4202},
 {"F10\0  ",  4.8398, -8.0547, -3.4202},
 {"PO9\0  ", -7.0000,  6.2691, -3.4202},
 {"PO10\0 ", -7.0000, -6.2691, -3.4202},
 {"I1\0   ", -9.2764,  1.5000, -3.4202},
 {"I2\0   ", -9.2764, -1.5000, -3.4202},
 {"M1\0   ",  0.    ,  8.3867, -5.4464},
 {"M2\0   ",  0.    , -8.3867, -5.4464},
 {"T3\0   ",  0.    , 10.    , 0.},
 {"T4\0   ",  0.    ,-10.    , 0.},
 {"AF3F5\0",  7.659628330, 5.117991805, 3.890533862},
 {"PO4P2\0", -7.980811386,-3.305750798, 5.037723820},
 {"P5PO3\0", -7.659628330, 5.117991805, 3.890533862},
 {"A2\0   ",  0.    , -8.3867, -5.4464},
 {"A1\0   ",  0.    ,  8.3867, -5.4464},
 {"T5\0   ", -5.8779,  8.0902, 0.},
 {"T6\0   ", -5.8779, -8.0902, 0.}};

#define NDEFELECT_REFLAY 58
static DEFAULTelectrode DefArrayRefLay[NDEFELECT_REFLAY] =
{{"1R\0   ",  9.5106,  3.0902,  0.    },  // FP1
 {"1S\0   ",  9.5106,  3.0902,  0.    },  // FP1
 {"2R\0   ",  9.5106, -3.0902,  0.    },  // FP2
 {"2S\0   ",  9.5106, -3.0902,  0.    },  // FP2
 {"3R\0   ",  9.2388,  0     ,  3.8268},  // AFz
 {"3S\0   ",  9.2388,  0     ,  3.8268},  // AFz
 {"4R\0   ",  8.0902,  5.8779,  0.    },  // AF7
 {"4S\0   ",  8.0902,  5.8779,  0.    },  // AF7
 {"5R\0   ",  5.6472,  5.6472,  6.0182},  // F3
 {"5S\0   ",  5.6472,  5.6472,  6.0182},  // F3
 {"6R\0   ",  6.5606,  0.    ,  7.5471},  // Fz
 {"6S\0   ",  6.5606,  0.    ,  7.5471},  // Fz
 {"7R\0   ",  5.6472, -5.6472,  6.0182},  // F4
 {"7S\0   ",  5.6472, -5.6472,  6.0182},  // F4
 {"8R\0   ",  6.5328, -6.5328,  3.8268},  // F6
 {"8S\0   ",  6.5328, -6.5328,  3.8268},  // F6
 {"9R\0   ",  3.4609,  8.5661,  3.8268},  // FC5
 {"9S\0   ",  3.4609,  8.5661,  3.8268},  // FC5
 {"10R\0  ",  3.3197,  3.3197,  8.8295},  // FC1
 {"10S\0  ",  3.3197,  3.3197,  8.8295},  // FC1
 {"11R\0  ",  3.3197, -3.3197,  8.8295},  // FC2
 {"11S\0  ",  3.3197, -3.3197,  8.8295},  // FC2
 {"12R\0  ",  3.4609, -8.5661,  3.8268},  // FC6
 {"12S\0  ",  3.4609, -8.5661,  3.8268},  // FC6
 {"13R\0  ",  0.    ,  9.7980, -2.    },  // T7
 {"13S\0  ",  0.    ,  9.7980, -2.    },  // T7
 {"14R\0  ",  0.    ,  6.5606,  7.5471},  // C3
 {"14S\0  ",  0.    ,  6.5606,  7.5471},  // C3
 {"15R\0  ",  0.    ,  0.    , 10.    },  // Cz
 {"15S\0  ",  0.    ,  0.    , 10.    },  // Cz
 {"16R\0  ",  0.    , -6.5606,  7.5471},  // C4
 {"16S\0  ",  0.    , -6.5606,  7.5471},  // C4
 {"17R\0  ",  0.    , -9.7980,     -2.},  // T8
 {"17S\0  ",  0.    , -9.7980,     -2.},  // T8
 {"18R\0  ", -3.5355,  8.5355,  3.8268},  // CP5
 {"18S\0  ", -3.5355,  8.5355,  3.8268},  // CP5
 {"19R\0  ", -3.3197,  3.3197,  8.8295},  // CP1
 {"19S\0  ", -3.3197,  3.3197,  8.8295},  // CP1
 {"20R\0  ", -3.3197, -3.3197,  8.8295},  // CP2
 {"20S\0  ", -3.3197, -3.3197,  8.8295},  // CP2
 {"21R\0  ", -3.5355, -8.5355,  3.8268},  // CP6
 {"21S\0  ", -3.5355, -8.5355,  3.8268},  // CP6
 {"22R\0  ", -5.8779,  8.0902,  0.    },  // P7
 {"22S\0  ", -5.8779,  8.0902,  0.    },  // P7
 {"23R\0  ", -5.6472,  5.6472,  6.0182},  // P3
 {"23S\0  ", -5.6472,  5.6472,  6.0182},  // P3
 {"24R\0  ", -6.5606,  0.    ,  7.5471},  // Pz
 {"24S\0  ", -6.5606,  0.    ,  7.5471},  // Pz
 {"25R\0  ", -5.6472, -5.6472,  6.0182},  // P4
 {"25S\0  ", -5.6472, -5.6472,  6.0182},  // P4
 {"26R\0  ", -5.8779, -8.0902,  0.    },  // P8
 {"26S\0  ", -5.8779, -8.0902,  0.    },  // P8
 {"27R\0  ", -9.2388,  0.    ,  3.8268},  // POz
 {"27S\0  ", -9.2388,  0.    ,  3.8268},  // POz
 {"28R\0   ", -9.5106,  3.0902,  0.   },  // O1
 {"28S\0   ", -9.5106,  3.0902,  0.   },  // O1
 {"29R\0   ", -9.5106, -3.0902,  0.   },  // O2
 {"29S\0   ", -9.5106, -3.0902,  0.   }}; // O2

#define NDEFMAGN 151
static DEFAULTgradiometer DefArrayM[NDEFMAGN]  =
{
 {"MLC11\0",   4.8560,   1.4624,  16.3687,   6.5681,   1.7579,  21.0585,   0.3423,   0.0591,   0.9377},
 {"MLC12\0",   4.3083,   4.0502,  16.0529,   5.8425,   5.5314,  20.5767,   0.3068,   0.2962,   0.9045},
 {"MLC13\0",   3.5316,   7.3473,  14.4834,   4.9667,  10.6385,  17.9649,   0.2870,   0.6581,   0.6961},
 {"MLC14\0",   1.2885,   9.0081,  13.1160,   1.7713,  13.3398,  15.5688,   0.0965,   0.8661,   0.4904},
 {"MLC15\0",  -0.9730,   9.8464,  11.0795,  -1.1887,  14.6987,  12.2717,  -0.0431,   0.9702,   0.2384},
 {"MLC21\0",   2.0235,   2.7732,  17.0221,   3.3199,   3.6122,  21.7790,   0.2592,   0.1678,   0.9511},
 {"MLC22\0",   2.0718,   5.5988,  16.1857,   3.1698,   7.6295,  20.6223,   0.2196,   0.4060,   0.8871},
 {"MLC23\0",   0.1461,   7.3525,  15.3546,   0.5807,  10.5861,  19.1451,   0.0869,   0.6466,   0.7579},
 {"MLC24\0",  -1.7747,   8.7589,  13.7525,  -1.9694,  13.0156,  16.3708,  -0.0389,   0.8511,   0.5235},
 {"MLC31\0",  -0.3832,   4.3896,  17.1043,   0.2319,   6.0061,  21.7970,   0.1230,   0.3232,   0.9383},
 {"MLC32\0",  -2.4706,   6.3118,  16.2933,  -2.7736,   9.0878,  20.4424,  -0.0606,   0.5551,   0.8296},
 {"MLC33\0",  -4.9981,   4.7272,  16.7100,  -6.5616,   6.7321,  21.0168,  -0.3126,   0.4009,   0.8611},
 {"MLC41\0",  -0.2558,   1.4128,  17.6573,   0.5244,   1.9085,  22.5724,   0.1560,   0.0991,   0.9828},
 {"MLC42\0",  -2.8485,   3.0133,  17.6199,  -3.1585,   3.9707,  22.5189,  -0.0620,   0.1914,   0.9795},
 {"MLC43\0",  -5.5569,   1.4618,  17.3310,  -7.4326,   2.0523,  21.9295,  -0.3750,   0.1181,   0.9195},
 {"MLF11\0",  12.0228,   3.0638,   6.2371,  16.7686,   4.6275,   6.4481,   0.9489,   0.3127,   0.0422},
 {"MLF12\0",  10.6266,   5.8510,   5.6991,  14.7098,   8.7335,   5.8756,   0.8164,   0.5764,   0.0353},
 {"MLF21\0",  12.1466,   1.4378,   9.0415,  16.9813,   2.3270,   9.9624,   0.9667,   0.1778,   0.1841},
 {"MLF22\0",  11.1212,   4.5622,   8.8447,  15.4940,   6.8739,   9.5842,   0.8744,   0.4622,   0.1479},
 {"MLF23\0",   9.3363,   7.0866,   8.0010,  12.5477,  10.9117,   8.2604,   0.6421,   0.7648,   0.0519},
 {"MLF31\0",  10.7934,   3.2122,  11.5899,  14.9835,   4.7512,  13.8455,   0.8378,   0.3077,   0.4510},
 {"MLF32\0",   9.3811,   6.1134,  11.0440,  12.9253,   9.1328,  12.8702,   0.7087,   0.6037,   0.3652},
 {"MLF33\0",   7.2872,   8.1163,   9.9303,   9.4648,  12.5162,  10.8851,   0.4354,   0.8797,   0.1909},
 {"MLF34\0",   4.9150,   9.2627,   8.9920,   6.7570,  13.9001,   9.3313,   0.3683,   0.9272,   0.0678},
 {"MLF41\0",   9.5872,   1.4064,  13.7655,  13.0114,   1.9050,  17.3764,   0.6847,   0.0997,   0.7220},
 {"MLF42\0",   8.6627,   4.6322,  13.4602,  11.7982,   6.6054,  16.8199,   0.6269,   0.3945,   0.6718},
 {"MLF43\0",   6.7292,   7.3362,  12.5844,   8.9191,  11.1257,  15.0045,   0.4379,   0.7577,   0.4839},
 {"MLF44\0",   4.2945,   8.8256,  11.9302,   6.0845,  13.0678,  13.8828,   0.3579,   0.8482,   0.3904},
 {"MLF45\0",   2.0204,   9.9591,  10.2465,   2.6435,  14.8278,  11.2057,   0.1246,   0.9735,   0.1918},
 {"MLF51\0",   7.1042,   2.8957,  15.2546,   9.4568,   3.8611,  19.5611,   0.4704,   0.1930,   0.8611},
 {"MLF52\0",   5.9393,   5.6902,  14.7053,   7.8353,   8.2268,  18.5762,   0.3791,   0.5072,   0.7740},
 {"MLO11\0", -11.9997,   1.4972,   9.0119, -16.8443,   2.2338,  10.0118,  -0.9687,   0.1473,   0.1999},
 {"MLO12\0", -10.8477,   5.0091,   9.2074, -15.2212,   7.1989,  10.2514,  -0.8745,   0.4378,   0.2087},
 {"MLO21\0", -11.9285,   3.4199,   6.5022, -16.6637,   5.0128,   6.7322,  -0.9468,   0.3185,   0.0460},
 {"MLO22\0", -10.3269,   6.3860,   6.5281, -14.2319,   9.5039,   6.7341,  -0.7808,   0.6234,   0.0412},
 {"MLO31\0", -12.4758,   1.5110,   3.6309, -17.4339,   2.1582,   3.7389,  -0.9914,   0.1294,   0.0216},
 {"MLO32\0", -11.4501,   4.8214,   3.8394, -15.8803,   7.1391,   3.9594,  -0.8858,   0.4634,   0.0240},
 {"MLO33\0",  -9.4072,   7.4844,   3.7841, -12.8519,  11.1079,   3.9171,  -0.6888,   0.7245,   0.0266},
 {"MLO41\0", -12.2011,   3.2555,   1.0701, -16.9950,   4.6777,   1.1661,  -0.9585,   0.2844,   0.0192},
 {"MLO42\0", -10.6478,   6.2312,   1.0087, -14.6701,   9.2011,   1.1247,  -0.8043,   0.5938,   0.0232},
 {"MLO43\0",  -8.2634,   8.5089,   0.9702, -11.1184,  12.6129,   1.1082,  -0.5709,   0.8206,   0.0276},
 {"MLP11\0",  -7.4886,   3.0230,  15.9350, -10.5673,   4.2741,  19.6725,  -0.6156,   0.2502,   0.7473},
 {"MLP12\0",  -6.9269,   6.1414,  14.7368,  -9.6217,   8.8540,  17.9606,  -0.5388,   0.5424,   0.6446},
 {"MLP13\0",  -4.4984,   7.7361,  14.5972,  -5.6797,  11.5054,  17.6647,  -0.2362,   0.7537,   0.6134},
 {"MLP21\0",  -9.7575,   1.4969,  13.8597, -13.8014,   2.0512,  16.7497,  -0.8086,   0.1108,   0.5779},
 {"MLP22\0",  -9.0621,   4.2842,  13.7773, -12.8453,   5.8842,  16.6305,  -0.7564,   0.3199,   0.5705},
 {"MLP31\0", -10.7553,   3.1664,  11.5438, -15.2006,   4.4264,  13.4582,  -0.8888,   0.2519,   0.3828},
 {"MLP32\0",  -9.1676,   6.2931,  11.7606, -12.9477,   8.9792,  13.6338,  -0.7558,   0.5371,   0.3745},
 {"MLP33\0",  -6.7867,   8.1668,  12.3010,  -9.2340,  12.1026,  14.1806,  -0.4893,   0.7870,   0.3758},
 {"MLP34\0",  -3.9943,   9.4114,  11.7758,  -4.8830,  14.1186,  13.2131,  -0.1777,   0.9412,   0.2874},
 {"MLT11\0",   6.9308,   8.5700,   6.8372,   8.9327,  13.1485,   7.0422,   0.4003,   0.9155,   0.0410},
 {"MLT12\0",   2.8887,  10.0154,   7.2736,   4.0068,  14.8869,   7.4496,   0.2235,   0.9741,   0.0352},
 {"MLT13\0",  -0.1261,  10.2415,   8.1673,  -0.3315,  15.2342,   8.3758,  -0.0411,   0.9983,   0.0417},
 {"MLT14\0",  -3.1401,  10.3755,   8.8430,  -3.7342,  15.3394,   8.9840,  -0.1188,   0.9925,   0.0282},
 {"MLT15\0",  -6.1664,   9.3805,   9.3138,  -7.9669,  14.0266,   9.7434,  -0.3600,   0.9290,   0.0859},
 {"MLT16\0",  -8.8029,   7.6725,   9.2541, -12.0271,  11.4479,   9.8573,  -0.6447,   0.7549,   0.1206},
 {"MLT21\0",   8.5787,   7.8211,   4.3527,  11.2311,  12.0574,   4.5302,   0.5303,   0.8470,   0.0355},
 {"MLT22\0",   4.8735,   9.4758,   5.0170,   6.6176,  14.1606,   5.1690,   0.3487,   0.9367,   0.0304},
 {"MLT23\0",   0.9189,  10.9775,   5.3195,   1.0728,  15.9748,   5.4445,   0.0308,   0.9992,   0.0250},
 {"MLT24\0",  -2.1432,  11.0442,   5.8891,  -2.4569,  16.0332,   6.0441,  -0.0627,   0.9975,   0.0310},
 {"MLT25\0",  -5.2470,  10.7329,   6.4048,  -6.6287,  15.5378,   6.5313,  -0.2763,   0.9607,   0.0253},
 {"MLT26\0",  -7.8577,   8.5460,   6.5039, -10.5516,  12.7572,   6.6519,  -0.5386,   0.8420,   0.0296},
 {"MLT31\0",   6.4038,   8.9698,   2.4034,   8.2962,  13.5959,   2.5774,   0.3784,   0.9250,   0.0348},
 {"MLT32\0",   2.8260,  10.2209,   2.9540,   3.8420,  15.1147,   3.1330,   0.2031,   0.9785,   0.0358},
 {"MLT33\0",  -0.6677,  11.1339,   2.9700,  -0.8157,  16.1312,   3.1035,  -0.0296,   0.9992,   0.0267},
 {"MLT34\0",  -3.8725,  11.1387,   3.4430,  -4.6686,  16.0753,   3.5390,  -0.1592,   0.9871,   0.0192},
 {"MLT35\0",  -6.9207,   9.7809,   3.6986,  -9.0183,  14.3186,   3.8466,  -0.4194,   0.9073,   0.0296},
 {"MLT41\0",   4.2953,   9.8549,   0.3680,   5.9474,  14.5732,   0.5125,   0.3303,   0.9434,   0.0289},
 {"MLT42\0",   1.1241,  11.3555,   0.3720,   1.2959,  16.3491,   0.5895,   0.0344,   0.9985,   0.0435},
 {"MLT43\0",  -2.1848,  11.2443,   0.5311,  -2.5874,  16.2279,   0.6506,  -0.0805,   0.9965,   0.0239},
 {"MLT44\0",  -5.5413,  10.8305,   0.8106,  -6.9448,  15.6280,   0.9736,  -0.2806,   0.9593,   0.0326},
 {"MRC11\0",   4.8759,  -1.4163,  16.3477,   6.5196,  -1.8190,  21.0539,   0.3287,  -0.0805,   0.9410},
 {"MRC12\0",   4.2567,  -4.0485,  16.0562,   5.8312,  -5.5339,  20.5648,   0.3148,  -0.2970,   0.9015},
 {"MRC13\0",   3.4102,  -7.3500,  14.4724,   4.9405, -10.5903,  17.9611,   0.3060,  -0.6479,   0.6976},
 {"MRC14\0",   1.2458,  -8.9564,  13.1622,   1.6508, -13.3221,  15.5683,   0.0810,  -0.8729,   0.4811},
 {"MRC15\0",  -1.0452,  -9.8156,  11.1084,  -1.2879, -14.6667,  12.3001,  -0.0485,  -0.9700,   0.2383},
 {"MRC21\0",   2.0372,  -2.7660,  17.0003,   3.2507,  -3.5929,  21.7811,   0.2426,  -0.1653,   0.9559},
 {"MRC22\0",   1.9577,  -5.5153,  16.1444,   3.1666,  -7.6159,  20.5192,   0.2417,  -0.4200,   0.8747},
 {"MRC23\0",  -0.0067,  -7.2797,  15.3921,   0.6057, -10.5794,  19.1002,   0.1224,  -0.6598,   0.7414},
 {"MRC24\0",  -1.8423,  -8.6913,  13.7900,  -2.0442, -12.9749,  16.3635,  -0.0404,  -0.8565,   0.5146},
 {"MRC31\0",  -0.4322,  -4.3802,  17.0981,   0.2143,  -5.9575,  21.7999,   0.1293,  -0.3154,   0.9401},
 {"MRC32\0",  -2.5081,  -6.2534,  16.2991,  -2.8396,  -9.0399,  20.4389,  -0.0663,  -0.5572,   0.8278},
 {"MRC33\0",  -5.0137,  -4.7174,  16.6909,  -6.6204,  -6.5840,  21.0437,  -0.3213,  -0.3732,   0.8703},
 {"MRC41\0",  -0.2735,  -1.4268,  17.6564,   0.5188,  -1.8354,  22.5776,   0.1584,  -0.0817,   0.9840},
 {"MRC42\0",  -2.8622,  -2.9239,  17.6217,  -3.1908,  -3.9611,  22.5032,  -0.0657,  -0.2074,   0.9760},
 {"MRC43\0",  -5.5661,  -1.3962,  17.3230,  -7.4422,  -1.9699,  21.9234,  -0.3751,  -0.1147,   0.9198},
 {"MRF11\0",  11.9467,  -3.1366,   6.2379,  16.6924,  -4.6993,   6.4594,   0.9489,  -0.3125,   0.0443},
 {"MRF12\0",  10.5391,  -5.8785,   5.6804,  14.5967,  -8.7929,   5.9149,   0.8113,  -0.5827,   0.0469},
 {"MRF21\0",  12.1271,  -1.5028,   9.0624,  16.9618,  -2.4206,   9.9543,   0.9667,  -0.1835,   0.1783},
 {"MRF22\0",  11.0599,  -4.6259,   8.8543,  15.4308,  -6.9416,   9.5923,   0.8740,  -0.4630,   0.1476},
 {"MRF23\0",   9.2372,  -7.1275,   7.9998,  12.4706, -10.9315,   8.2957,   0.6465,  -0.7606,   0.0592},
 {"MRF31\0",  10.7530,  -3.2661,  11.5997,  14.9359,  -4.8263,  13.8540,   0.8364,  -0.3120,   0.4507},
 {"MRF32\0",   9.3067,  -6.1354,  11.0651,  12.8296,  -9.1904,  12.8732,   0.7044,  -0.6109,   0.3615},
 {"MRF33\0",   7.2029,  -8.1114,   9.9286,   9.3671, -12.5060,  10.9364,   0.4327,  -0.8787,   0.2015},
 {"MRF34\0",   4.8080,  -9.2642,   9.0085,   6.6863, -13.8847,   9.3772,   0.3756,  -0.9239,   0.0737},
 {"MRF41\0",   9.5651,  -1.4506,  13.7636,  12.9975,  -1.9553,  17.3659,   0.6863,  -0.1009,   0.7203},
 {"MRF42\0",   8.5788,  -4.6385,  13.5024,  11.7793,  -6.6638,  16.7684,   0.6399,  -0.4050,   0.6530},
 {"MRF43\0",   6.6964,  -7.3050,  12.6136,   8.7994, -11.1656,  14.9981,   0.4205,  -0.7719,   0.4768},
 {"MRF44\0",   4.2222,  -8.7937,  11.9923,   5.9772, -13.0938,  13.8474,   0.3509,  -0.8598,   0.3709},
 {"MRF45\0",   1.9358,  -9.9303,  10.2942,   2.5499, -14.8059,  11.2240,   0.1228,  -0.9749,   0.1859},
 {"MRF51\0",   7.0895,  -2.9018,  15.2702,   9.4271,  -3.9018,  19.5770,   0.4674,  -0.1999,   0.8611},
 {"MRF52\0",   5.8895,  -5.7110,  14.6696,   7.7578,  -8.1939,  18.5885,   0.3736,  -0.4964,   0.7836},
 {"MRO11\0", -12.0290,  -1.4220,   8.9907, -16.8660,  -2.1130,  10.0577,  -0.9672,  -0.1382,   0.2133},
 {"MRO12\0", -10.8720,  -4.9307,   9.2166, -15.2561,  -7.0963,  10.2665,  -0.8766,  -0.4330,   0.2099},
 {"MRO21\0", -11.9629,  -3.3516,   6.5071, -16.7079,  -4.9140,   6.7451,  -0.9488,  -0.3124,   0.0476},
 {"MRO22\0", -10.3240,  -6.3184,   6.5648, -14.2833,  -9.3697,   6.7263,  -0.7917,  -0.6101,   0.0323},
 {"MRO31\0", -12.5086,  -1.4305,   3.6178, -17.4660,  -2.0771,   3.7573,  -0.9912,  -0.1293,   0.0279},
 {"MRO32\0", -11.4776,  -4.7972,   3.8566, -15.9549,  -7.0232,   3.9631,  -0.8952,  -0.4451,   0.0213},
 {"MRO33\0",  -9.4395,  -7.4081,   3.7942, -12.8890, -11.0258,   3.9537,  -0.6897,  -0.7234,   0.0319},
 {"MRO41\0", -12.2011,  -3.2555,   1.0701, -16.9950,  -4.6777,   1.1661,  -0.9585,  -0.2844,   0.0192},
 {"MRO42\0", -10.6626,  -6.1572,   1.0067, -14.6925,  -9.1152,   1.1577,  -0.8058,  -0.5915,   0.0302},
 {"MRO43\0",  -8.2727,  -8.4349,   0.9851, -11.1594, -12.5162,   1.1371,  -0.5772,  -0.8160,   0.0304},
 {"MRP11\0",  -7.4796,  -3.0461,  15.9207, -10.6031,  -4.0524,  19.6948,  -0.6245,  -0.2012,   0.7546},
 {"MRP12\0",  -6.9656,  -6.0798,  14.7461,  -9.6786,  -8.7498,  17.9901,  -0.5425,  -0.5339,   0.6486},
 {"MRP13\0",  -4.5111,  -7.7028,  14.5734,  -5.7916, -11.3801,  17.7119,  -0.2560,  -0.7353,   0.6275},
 {"MRP21\0",  -9.7523,  -1.4076,  13.8629, -13.8033,  -1.9458,  16.7460,  -0.8100,  -0.1076,   0.5765},
 {"MRP22\0",  -9.0718,  -4.2084,  13.8130, -12.9092,  -5.7773,  16.6104,  -0.7673,  -0.3137,   0.5593},
 {"MRP31\0", -10.7921,  -3.0970,  11.4992, -15.2119,  -4.2831,  13.5170,  -0.8837,  -0.2372,   0.4035},
 {"MRP32\0",  -9.2085,  -6.2032,  11.7792, -12.9958,  -8.8836,  13.6459,  -0.7573,  -0.5359,   0.3732},
 {"MRP33\0",  -6.8117,  -8.0984,  12.3249,  -9.3292, -11.9976,  14.1879,  -0.5034,  -0.7797,   0.3725},
 {"MRP34\0",  -4.0323,  -9.3683,  11.7883,  -5.0102, -14.0502,  13.2500,  -0.1955,  -0.9361,   0.2923},
 {"MRT11\0",   6.8435,  -8.5571,   6.8624,   8.8289, -13.1427,   7.0694,   0.3970,  -0.9169,   0.0414},
 {"MRT12\0",   2.8126,  -9.9886,   7.3237,   3.8943, -14.8692,   7.4722,   0.2163,  -0.9759,   0.0297},
 {"MRT13\0",  -0.1994, -10.2057,   8.1886,  -0.4246, -15.1962,   8.4256,  -0.0450,  -0.9979,   0.0474},
 {"MRT14\0",  -3.2016, -10.3169,   8.8687,  -3.8367, -15.2753,   9.0237,  -0.1270,  -0.9914,   0.0310},
 {"MRT15\0",  -6.1731,  -9.3047,   9.3574,  -8.0807, -13.9113,   9.7486,  -0.3814,  -0.9211,   0.0782},
 {"MRT16\0",  -8.8375,  -7.6009,   9.2380, -12.0912, -11.3384,   9.9141,  -0.6506,  -0.7473,   0.1352},
 {"MRT21\0",   8.4566,  -7.8372,   4.4100,  11.1447, -12.0532,   4.5215,   0.5375,  -0.8430,   0.0223},
 {"MRT22\0",   4.7633,  -9.4257,   5.0539,   6.4981, -14.1142,   5.1979,   0.3469,  -0.9375,   0.0288},
 {"MRT23\0",   0.8809, -10.9583,   5.3583,   0.9144, -15.9580,   5.4803,   0.0067,  -0.9997,   0.0244},
 {"MRT24\0",  -2.1756, -11.2706,   5.9436,  -2.7309, -16.2400,   6.0441,  -0.1110,  -0.9936,   0.0201},
 {"MRT25\0",  -5.3256, -10.6714,   6.4141,  -6.6540, -15.4882,   6.6306,  -0.2656,  -0.9631,   0.0433},
 {"MRT26\0",  -7.9012,  -8.4697,   6.5167, -10.6203, -12.6637,   6.6887,  -0.5437,  -0.8386,   0.0344},
 {"MRT31\0",   6.3257,  -8.9240,   2.4349,   8.1504, -13.5774,   2.6079,   0.3648,  -0.9304,   0.0346},
 {"MRT32\0",   2.7173, -10.1303,   2.9957,   3.7506, -15.0214,   3.1437,   0.2066,  -0.9780,   0.0296},
 {"MRT33\0",  -0.7261, -11.0864,   3.0110,  -0.9276, -16.0817,   3.1470,  -0.0403,  -0.9988,   0.0272},
 {"MRT34\0",  -3.9344, -11.1057,   3.4515,  -4.7684, -16.0352,   3.5850,  -0.1668,  -0.9856,   0.0267},
 {"MRT35\0",  -6.9663,  -9.6642,   3.7297,  -9.0351, -14.2158,   3.8567,  -0.4136,  -0.9101,   0.0254},
 {"MRT41\0",   4.1881,  -9.7813,   0.3915,   5.8222, -14.5056,   0.5450,   0.3267,  -0.9446,   0.0307},
 {"MRT42\0",   1.0207, -11.0288,   0.4152,   1.2241, -16.0233,   0.5792,   0.0407,  -0.9986,   0.0328},
 {"MRT43\0",  -2.2456, -11.1972,   0.5720,  -2.6806, -16.1781,   0.6900,  -0.0870,  -0.9959,   0.0236},
 {"MRT44\0",  -5.5672, -10.7497,   0.8473,  -7.0442, -15.5262,   0.9768,  -0.2953,  -0.9550,   0.0259},
 {"MZC01\0",   2.3209,   0.0018,  17.1701,   3.6138,   0.0064,  22.0013,   0.2585,   0.0009,   0.9660},
 {"MZC02\0",  -2.8951,  -0.0056,  17.9272,  -3.1628,   0.0593,  22.9209,  -0.0535,   0.0130,   0.9985},
 {"MZF01\0",  12.5000,  -0.0266,   6.4841,  17.4999,  -0.0751,   6.5891,   0.9997,  -0.0097,   0.0210},
 {"MZF02\0",  11.2971,  -0.0151,  11.6899,  15.6468,  -0.0555,  14.1580,   0.8697,  -0.0081,   0.4935},
 {"MZF03\0",   7.3893,  -0.0042,  15.3499,   9.7619,  -0.0277,  19.7525,   0.4744,  -0.0047,   0.8803},
 {"MZO01\0", -12.4579,   0.0288,   6.5261, -17.4507,   0.0688,   6.8135,  -0.9983,   0.0080,   0.0575},
 {"MZO02\0", -12.6527,   0.0092,   1.2844, -17.6530,   0.0747,   1.3584,  -0.9998,   0.0131,   0.0148},
 {"MZP01\0",  -7.9413,  -0.0104,  15.9875, -11.1999,   0.1070,  19.7796,  -0.6516,   0.0235,   0.7582},
 {"MZP02\0", -11.1832,   0.0237,  11.7247, -15.6903,   0.0855,  13.8915,  -0.9012,   0.0124,   0.4333},
};

void UGrid::SetAllMembersDefault(void)
{
    _error        = U_OK;
    _npoints      = 0;
    _npointsAlloc = 0;
    _sensors      = NULL;
    _ntri         = 0;
    _Tri          = NULL;
    Group         = NULL;
}
void UGrid::DeleteAllMembers(ErrorType E)
{
    if(_npointsAlloc) for(int i=0; i<_npointsAlloc; i++) delete _sensors[i];
    delete[] _sensors;
    delete[] _Tri;
    delete   Group;
    SetAllMembersDefault();
    _error = E;
}

const UString&  UGrid::GetGroupProperties(UString Comment)
{
    if(Group) return Group->GetGroupProperties(Comment);

    static UString Default("Group properties not set.");
    return Default;
}

UGrid::UGrid()
/*
    The default constructor.
 */
{
    SetAllMembersDefault();
}

UGrid::UGrid(GridType GT)
/*
    Use all default MEG or EEG sensors
 */
{
    SetAllMembersDefault();
    if(GT!=U_GRD_MEG && GT!=U_GRD_EEG)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: Ugrid::UGrid(). Invalid input grid type parameter: GT = %d .\n",GT);
        return;
    }

    if(GT==U_GRD_MEG) /* Gradiometer array*/
    {
        _sensors = new USensor*[NDEFMAGN];
        if(_sensors==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: Ugrid::UGrid(). Memory allocation error. GT = %d .\n",GT);
            return;
        }
        _npoints      = NDEFMAGN;
        _npointsAlloc = NDEFMAGN;

        for(int i=0; i<_npoints; i++) _sensors[i] = NULL;
        for(int i=0; i<_npoints; i++)
        {
            UVector3  x(DefArrayM[i].x,  DefArrayM[i].y,  DefArrayM[i].z );
            UVector3 cx(DefArrayM[i].cx, DefArrayM[i].cy, DefArrayM[i].cz);
            UVector3 nx(DefArrayM[i].nx, DefArrayM[i].ny, DefArrayM[i].nz);

            _sensors[i] = new USensor(x, nx, cx, USensor::U_SEN_GRAD, DefArrayM[i].Name);
            if(_sensors[i]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: Ugrid::UGrid(). Memory allocation error, creating MEG sensor %d .\n",i);
                return;
            }
        }

    }
    else if(GT==U_GRD_EEG) /*Electrodes*/
    {
        _sensors = new USensor*[NDEFELECT];
        if(_sensors==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: Ugrid::UGrid(). Memory allocation error. GT = %d .\n",GT);
            return;
        }
        for(int i=0; i<NDEFELECT; i++) _sensors[i] = NULL;
        _npoints      = NDEFELECT-4; // Skip last four (double positions)
        _npointsAlloc = NDEFELECT;

        for(int i=0; i<_npoints; i++)
        {
            UVector3 x(DefArrayE[i].x, DefArrayE[i].y, DefArrayE[i].z);
            UVector3 cx;
            UVector3 nx(0.,0.,1.);

            _sensors[i] = new USensor(x, nx, cx, USensor::U_SEN_EEG, DefArrayE[i].Name);
            if(_sensors[i]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: Ugrid::UGrid(). Memory allocation error, creating EEG sensor %d .\n",i);
                return;
            }
        }
    }

/* Triangulate and Group */
    _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. GT = %d .\n",GT);
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem*const*) _sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(const char** EEGlab, int nEEG, bool SkipTriangulation)
/*
   Create an EEG grid from electrode labels
 */
{
    SetAllMembersDefault();

    if(EEGlab==NULL || nEEG<=0)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: Ugrid::UGrid(). Invalid input parameters: nEEG = %d .\n",nEEG);
        return;
    }
    _sensors = new USensor*[nEEG];
    if(_sensors==NULL)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: Ugrid::UGrid(). Memory allocation error: nEEG = %d .\n",nEEG);
        return;
    }
    _npoints      = nEEG;
    _npointsAlloc = nEEG;

    for(int is=0;is<_npoints;is++) _sensors[is] = NULL;
    for(int is=0;is<_npoints;is++)
    {
        if(EEGlab[is]==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: Ugrid::UGrid(). NULL label at elelectrode %d \n",is);
            return;
        }
        _sensors[is] = new USensor(GetDefaultSensor(EEGlab[is]));
        if(_sensors[is]==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: Ugrid::UGrid(). Creating USensor at elelectrode %d \n",is);
            return;
        }
    }

    if(SkipTriangulation==false) _error = TriangulateGrid();
    else                         _error = U_OK;
    if(_error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. \n");
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}
UGrid::UGrid(const char* TextFile_XYZ_ELC)
{
    SetAllMembersDefault();
    if(TextFile_XYZ_ELC==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("UGrid::UGrid(). Invalid NULL argument. \n");
        return;
    }
    *this = UGrid(UFileName(TextFile_XYZ_ELC));
}

UGrid::UGrid(UFileName TextFile_XYZ_ELC)
/*
     Create a grid by reading an xyz-file an .elc-file or a .lay-file
     The format of the xyz-file is:
     Label, Xnlr, Ynlr, Znlr

     if identifier wrong, try to read as .elc file
 */
{
    SetAllMembersDefault();

/* Open the file and determine the number of points.*/
    FILE* fp = fopen(TextFile_XYZ_ELC,"rt");
    if(fp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). File does not exist: %s .\n", (const char*)TextFile_XYZ_ELC);
        return;
    }
    char line[256];
    GetLine(line, sizeof(line), fp);
    if(line[strlen(line)-1]==10) line[strlen(line)-1]=0;
    if(IsStringCompatible(line, "XYZfile1.0", false)==false)
    {
        if(TextFile_XYZ_ELC.HasExtension("elc", false)==false && 
           TextFile_XYZ_ELC.HasExtension("lay", false)==false)
        {
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGrid::UGrid(). File neither in .xyz nor in .elc, nor in .lay format: %s .\n", (const char*)TextFile_XYZ_ELC);
            return;
        }
        rewind(fp);
        if(TextFile_XYZ_ELC.HasExtension("elc", false)==true)
        {
            bool DistInMM = false;
            while(GetLine(line, sizeof(line), fp))
            {
                UAnalyzeLine AA(line, sizeof(line));
                if(AA.IsComment() || AA.IsEmptyLine()) continue;
                if(AA.IsIdentifierIsInLine("NumberPositions",true)==true)
                {
                    _npoints = AA.GetNextInt(-1);
                    if(_npoints<=0)
                    {
                        fclose(fp);
                        DeleteAllMembers(U_ERROR);
                        CI.AddToLog("ERROR: UGrid::UGrid(). Too few electrodes: %s .\n", line);
                        return;
                    }
                    GetLine(line, sizeof(line), fp);
                    if(AA.IsIdentifierInLine("UnitPosition") && 
                       AA.IsIdentifierInLine("mm")) DistInMM = true;
                    break;
                }
            }
            _sensors = new USensor*[_npoints];
            if(_sensors)
            {
                for(int i=0; i<_npoints; i++) _sensors[i] = NULL;
                for(int i=0; i<_npoints; i++) 
                {
                    _sensors[i] = new USensor();
                    if(_sensors[i]==NULL)
                    {
                        for(int ii=0; ii<_npoints; ii++) delete _sensors[ii];
                        delete[] _sensors; _sensors = NULL;
                        break;
                    }
                }
            }
            if(_sensors==NULL)
            {
                fclose(fp);
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation, _npoints = %d .\n", _npoints);
                return;
            }
            UAnalyzeLine AA(line, sizeof(line));
            while(AA.IsIdentifierInLine("Positions")==false &&
                  GetLine(line, sizeof(line), fp)) AA = UAnalyzeLine(line, sizeof(line));
            for(int i=0; i<_npoints; i++)
            {
                if(!GetLine(line, sizeof(line), fp))
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UGrid::UGrid(). Not all electrodes found (last = %d).\n", i);
                    return;
                }
                for(int k=0; k<sizeof(line); k++) if(line[k]==':') line[k]=' ';
                bool CC = (line[0]=='C') && (line[1]=='C');
                UAnalyzeLine AA = CC ? UAnalyzeLine(line+2, sizeof(line)-2) : UAnalyzeLine(line, sizeof(line));
                if(AA.IsComment() || AA.IsEmptyLine()) 
                {
                    i--;
                    continue;
                }
                UString Name(AA.GetNextString(sizeof(line)-10, NULL));
                if(CC) Name.Prepend("CC");
                double x = AA.GetNextDouble(0.);
                double y = AA.GetNextDouble(0.);
                double z = AA.GetNextDouble(0.);
                if(x==0. && y==0. && z==0.)
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UGrid::UGrid(). Invalid electrode postion, (i = %d).\n", i);
                    return;
                }
                _sensors[i]->SetName(Name);
                if(DistInMM)  _sensors[i]->Setx(UVector3(x/10, y/10, z/10));
                else          _sensors[i]->Setx(UVector3(x   , y   , z   ));
                _sensors[i]->SetStype(USensor::U_SEN_EEG);
            }
            fclose(fp);
        }
        else
        {
            _npoints      = 0;
            _npointsAlloc = 0;
            
            int iline     = 0;
            while(GetLine(line, sizeof(line), fp))
            {
                iline++;
                UAnalyzeLine AA(line, sizeof(line));
                if(AA.IsComment() || AA.IsEmptyLine()) continue;
                
                if(AA.GetNCollumn()!=6)
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UGrid::UGrid(). Invalid number of collumns in line %d .\n", iline);
                    return;
                }
                AA.MoveToCollumn(1);
                double     Xpl   = AA.GetNextDouble(1000.);
                double     Ypl   = AA.GetNextDouble(1000.);
                
                AA.MoveToCollumn(5);
                const char* Nam = AA.GetNextString(10, NULL);
                if(Nam==NULL || Xpl>500. || Ypl>500.)
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UGrid::UGrid(). Name not found in .lay file, line %d or erroneous coordinates.\n", iline);
                    return;
                }
                double The = sqrt(fabs(Xpl*Xpl + Ypl*Ypl));
                double Fi  = 0;
                if(fabs(Xpl)>1.e-6 || fabs(Ypl)>1.e-6) Fi = atan2(-Xpl, Ypl); // Order tested!
                UVector3 x = 10.*UVector3(The, Fi);
                USensor  S(x, UVector3(), UVector3(), USensor::U_SEN_EEG, Nam);
                if(AddSensor(S)!=U_OK)
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UGrid::UGrid(). Adding sensor from .lay-file, Label = %f .\n", Nam);
                    return;
                }
            }
            fclose(fp);
        }
    }
    else // try .xyz file
    {
        while(GetLine(line, sizeof(line), fp))
        {
            UAnalyzeLine AA(line, sizeof(line));
            if(AA.IsEmptyLine()==false) _npoints++;
        }

/* Other tests*/
        if(_npoints>0)  _sensors = new USensor*[_npoints];
        if(_npoints<=0 || !_sensors)
        {
            CI.AddToLog("ERROR: UGrid::UGrid(). _npoints = %d .\n", _npoints);
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
        _npointsAlloc = _npoints;
        for(int is=0; is<_npointsAlloc; is++) _sensors[is] = NULL;

/* Read the file.*/
        rewind(fp);
        GetLine(line, sizeof(line), fp);

        _npoints =0;
        memset(line, 0, sizeof(line));
        while(GetLine(line, sizeof(line), fp))
        {
            bool CC = (line[0]=='C') && (line[1]=='C');
            UAnalyzeLine AA = CC ? UAnalyzeLine(line+2, sizeof(line)-2) : UAnalyzeLine(line, sizeof(line));
            if(AA.IsComment() || AA.IsEmptyLine()) continue;
            
            UString Name(AA.GetNextString(USensor::MAXLABELSIZE));
            if(CC) Name.Prepend("CC");
            USensor S;
            S.SetName(Name);
            double x = AA.GetNextDouble(0.);
            double y = AA.GetNextDouble(0.);
            double z = AA.GetNextDouble(0.);

            if(x==0. && y==0. && z==0.) continue;

            S.Setx(UVector3(x,y,z));
            S.SetStype(USensor::U_SEN_EEG);

            _sensors[_npoints] = new USensor(S);
            if(_sensors[_npoints]) _npoints++;
            if(_npoints>=_npointsAlloc) break;
        }
        fclose(fp);
    }
/* Triangulate and Group */
    _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. TextFile = %s .\n",(const char*)TextFile_XYZ_ELC);
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(const char *TextFile_XYZ, int nEEG, char *NewLabel)
{
    SetAllMembersDefault();
    if(TextFile_XYZ==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("UGrid::UGrid(). Invalid NULL argument. \n");
        return;
    }
    *this = UGrid(UFileName(TextFile_XYZ), nEEG, NewLabel);
}

UGrid::UGrid(UFileName TextFile_XYZ, int nEEG, char *NewLabel)
/*
     Create a grid by reading and xyz-file.
     The format is:
     Label, DummyLabel, Xnlr, Ynlr, Znlr

     Read the .xyz-file *xyzDumLabFile.
     Store electrodes inside _sensors[]

     if(nEEG>0)   Cheque whether its number of electrodes equal nEEG
     if(NewLabel) Store the new labels in NewLabel[]
 */
{
    SetAllMembersDefault();

/* Open the file and determine the number of points.*/
    FILE *fp = fopen(TextFile_XYZ,"rt");
    if(fp==NULL)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: UGrid::UGrid(). File does not exist: %s .\n", (const char*)TextFile_XYZ);
        return;
    }
    char line[256];
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsComment()==false && AA.IsEmptyLine()==false) _npoints++;
    }

/* Test whether the number of electrodes is OK*/
    if(nEEG>0)
    {
        if(_npoints !=nEEG)
        {
            CI.AddToLog("ERROR: UGrid::UGrid(). _npoints = %d, nEEG = %d  .\n", _npoints, nEEG);
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }

/* Other tests*/
    if(_npoints>0)  _sensors = new USensor*[_npoints];
    if(_npoints<=0 || !_sensors)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). _npoints = %d, nEEG = %d  .\n", _npoints, nEEG);
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }
    _npointsAlloc = _npoints;
    for(int is=0; is<_npointsAlloc; is++) _sensors[is] = NULL;

/* Read the file.*/
    rewind(fp);
    if(NewLabel) memset(NewLabel,0,USensor::MAXLABELSIZE*_npoints);

    int is =0;
    memset(line, 0, sizeof(line));
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsComment()==false && AA.IsEmptyLine()==false)
        {
            USensor S;
            double x=0., y=0., z=0.;

            S.SetName(AA.GetNextString(USensor::MAXLABELSIZE));
            const char *strptr = AA.GetNextString(USensor::MAXLABELSIZE);

            x = AA.GetNextDouble(0.);
            y = AA.GetNextDouble(0.);
            z = AA.GetNextDouble(0.);

            S.Setx(UVector3(x,y,z));
            S.SetStype(USensor::U_SEN_EEG);

            _sensors[is] = new USensor(S);
            if(_sensors[is])
            {
                is++;
                if(NewLabel)
                    memcpy(NewLabel+is*USensor::MAXLABELSIZE, strptr, USensor::MAXLABELSIZE);
            }
            else
            {
                CI.AddToLog("WARNING: UGrid::UGrid(). Creating USensor %s\n", S.GetName());
            }
        }
    }
    fclose(fp);

/* Triangulate and Group */
    _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. File = %s \n",(const char*)TextFile_XYZ);
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(const UVector3* Points, int npoints, USensor::SensorType ST)
/*
    Create an UGrid of npoints points with USensors of type ST. The sensor positions
    are taken from the UVector3 array Points.
 */
{
    SetAllMembersDefault();

    if(npoints<0 || Points==NULL)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid NULL argument. npoints = %d. \n", npoints);
        return;
    }
    if(npoints==0) return;

    _sensors = new USensor*[npoints];

    if(!_sensors)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation: npoints = %d. \n", npoints);
        return;
    }
    _npoints      = npoints;
    _npointsAlloc = npoints;
    for(int is=0;is<_npointsAlloc;is++) _sensors[is] = NULL;
    for(int is=0;is<_npoints;is++)
    {
        UVector3 xx = Points[is];
        UVector3 nn = Points[is]/xx.GetNorm();
        UVector3 cc = Points[is] + 5. * nn;
        _sensors[is] = new USensor(xx,nn,cc,ST,"NoName");
        if(_sensors[is]==NULL) _error = U_ERROR;
    }
    if(_error==U_OK)
        _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. npoints = %d \n",npoints);

        DeleteAllMembers(U_ERROR);
        return;
    }

    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(const USensor* sensor)
{
    SetAllMembersDefault();

    if(sensor==NULL)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid NULL pointer argument. \n");
        _error=U_ERROR;
        return;
    }
    _npoints      = 1;
    _npointsAlloc = 1;
    _sensors      = new USensor*[_npoints];
    if(!_sensors)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. Number of sensors = %d \n",_npoints);
        return;
    }
    _sensors[0] = new USensor( *sensor );
    if(_sensors[0]==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Copying single sensor. \n");
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*) _sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(int npoints, const USensor** sensors)
/*
    Create an UGrid of npoints points with default USensors if sensors==NULL
    If(sensors!=NULL) copy the sensors to the grid.
 */
{
    SetAllMembersDefault();

    if(npoints<0)
    {
        _error = U_ERROR;
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid argument. npoints = %d. \n", npoints);
        return;
    }
    if(npoints==0) return;

    _sensors      = new USensor*[npoints];
    if(!_sensors)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. Number of sensors = %d \n",npoints);
        return;
    }
    _npoints      = npoints;
    _npointsAlloc = npoints;
    for(int is=0;is<_npointsAlloc;is++) _sensors[is] = NULL;

    if(!sensors)
    {
        for(int is=0;is<_npoints;is++)
        {
            _sensors[is] = new USensor();
            if(_sensors[is]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. Creating default sensor (is=%d). \n", is);
                return;
            }
        }
    }
    else
    {
        for(int is=0;is<npoints;is++)
        {
            if(sensors[is]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). Invalid NULL sensor, is  = %d \n",is);
                return;
            }
            _sensors[is] = new USensor(*(sensors[is]));
            if(_sensors[is]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. Copying sensor, is  = %d \n",is);
                return;
            }
        }
/* Triangulate ... */
        _error = TriangulateGrid();
        if(_error!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. npoints = %d   .\n",npoints);
            return;
        }
    }
/* ... and Group */
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
    }
}

UGrid::UGrid(int nx, double deltax, int ny, double deltay)
/*
    Make a rectangular grid.
 */
{
    SetAllMembersDefault();
    if(nx<=0 || ny<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid arguments. nx = %d, ny = %d \n",nx, ny);
        return;
    }
    _npoints      = nx*ny;
    _sensors      = new USensor*[_npoints];

    if(!_sensors)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. nx = %d, ny = %d \n",nx, ny);
        return;
    }
    _npointsAlloc = _npoints;
    for(int is=0;is<_npointsAlloc;is++) _sensors[is] = NULL;

    int i=0;
    for(int y=0; y<ny; y++)
        for(int x=0; x<nx; x++,i++)
        {
            USensor S;
            S.Setx(x*deltax, y*deltay, 0.);
            S.SetStype(USensor::U_SEN_POINT);
            S.SetName(i);
            _sensors[i] = new USensor(S);
            if(_sensors[i]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). copying sensor. \n");
                return;
            }
    }

    if(_error==U_OK)
        _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. nx = %d, ny = %d . \n", nx, ny);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(double radius, int nx, double deltax, int ny, double deltay)
/*
    Make a "rectangular" grid on a cylinder with radius radius.
 */
{
    SetAllMembersDefault();
    if(nx<=0 || ny<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid arguments. nx = %d, ny = %d \n",nx, ny);
        return;
    }
    _npoints      = nx*ny;
    _sensors      = new USensor*[_npoints];
    if(!_sensors)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Memory allocation. Number of sensors = %d \n",_npoints);
        return;
    }
    _npointsAlloc = _npoints;
    for(int i=0; i<_npointsAlloc; i++) _sensors[i] = NULL;

    int i=0;
    for(int y=0; y<ny; y++)
        for(int x=0; x<nx; x++,i++)
        {
            double fi = y*deltay/radius;
            USensor S;
            S.Setx(radius*cos(fi), radius*sin(fi), x*deltax);
            S.SetStype(USensor::U_SEN_POINT);
            _sensors[i] = new USensor(S);
            if(_sensors[i]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::UGrid(). Copying senors  %d \n",i);
                return;
            }
        }

    _error = TriangulateGrid();
    if(_error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid. nx = %d, ny = %d . \n", nx, ny);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Setting UGroup object. \n");
        return;
    }
}

UGrid::UGrid(const UGrid &g )
/*
    The copy constructor.
 */
{
/* Set defaults*/
    SetAllMembersDefault();
    *this = g;
}

UGrid::UGrid(FILE* fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid NULL pointer. \n");
        return;
    }

    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UGrid::UGrid(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }
    _npoints = ::ReadBinaryInt(DefaultIntelData, fpIn);
    if(_npoints<0)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid number of sensors  (_npoints = %d). \n", _npoints);
        return;
    }
    _npointsAlloc = _npoints + 10;
    _sensors      = new USensor*[_npointsAlloc];
    if(_sensors==NULL)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UGrid::UGrid(). Allocating memory for sensor pointers (_npointsAlloc = %d). \n", _npointsAlloc);
        return;
    }
    for(int i=0; i<_npointsAlloc; i++) _sensors[i] = NULL;
    for(int i=0; i<_npoints;      i++)
    {
        _sensors[i] = new USensor(fpIn);
        if(_sensors[i]==NULL)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UGrid::UGrid(). Reading sensor %d .\n", i);
            return;
        }
    }
    _ntri = ::ReadBinaryInt(DefaultIntelData, fpIn);
    if(_ntri<0)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UGrid::UGrid(). Invalid number of triangles  (_ntri = %d). \n", _ntri);
        return;
    }
    if(_ntri>0)
    {
        _Tri = new int[3*_ntri];
        if(_Tri==NULL)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            CI.AddToLog("ERROR: UGrid::UGrid(). Allocating memory for triangles (_ntri = %d). \n", _ntri);
            return;
        }
        for(int ii=0; ii<3*_ntri; ii++) _Tri[ii] = ::ReadBinaryInt(DefaultIntelData, fpIn);
    }
    else
    {
        _error = TriangulateGrid();
        if(_error!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            _error = U_ERROR;
            CI.AddToLog("ERROR: UGrid::UGrid(). Triangulating grid.\n");
            return;
        }
    }
    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: UGrid::UGrid(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }

    Group = new UGroup(_npoints, (UGroupElem*const*)_sensors);
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::UGrid(). Creating UGroup-object from sensors read from binary file. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
}
ErrorType UGrid::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(_npoints<0 || _ntri<0)
    {
        CI.AddToLog("ERROR: UGrid::WriteBinary().  _npoints (=%d) or _ntri (=%d) invalid \n", _npoints, _ntri);
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UGrid::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(_npoints, DefaultIntelData, fpOut);

    for(int i=0; i<_npoints; i++)
        if(_sensors[i]->WriteBinary(fpOut)!=U_OK)
        {
            CI.AddToLog("ERROR: UGrid::WriteBinary(). Writing sensor[%d]  . \n", i);
            return U_ERROR;
        }

    ::WriteBinary(_ntri, DefaultIntelData, fpOut);
    if(_ntri>0)
        for(int ii=0; ii<3*_ntri; ii++) ::WriteBinary(_Tri[ii], DefaultIntelData, fpOut);

    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UGrid& UGrid::operator=(const UGrid &g)
/*
    The assigment operator.
 */
{
    if(this==NULL)
    {
        static UGrid G; G._error = U_ERROR;
        return G;
    }
    if(&g==NULL)
    {
        CI.AddToLog("ERROR: UGrid::operator=(). Invalid NULL address in argument.\n");
        return *this;
    }
    if(this==&g) return *this;

    DeleteAllMembers(U_OK);
    _error   = g._error;

    if(g._sensors)
    {
        _sensors = new USensor*[g._npoints];
        if(_sensors==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGrid::operator=(). Copying %d sensors.\n", g._npoints);
            return *this;
        }
        for(int is=0; is<g._npoints; is++)
        {
            if(g._sensors[is]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UGrid::operator=(). Sensor %d of argument UGrid ==NULL.\n", is);
                return *this;
            }
            _sensors[is] = new USensor(*(g._sensors[is]));
            if(_sensors[is]==NULL)
            {
                DeleteAllMembers(U_ERROR);
                _error = U_ERROR;
                CI.AddToLog("ERROR: UGrid::operator=(). Copying senor %d.\n", is);
                return *this;
            }
        }
    }
    _npoints      = g._npoints;
    _npointsAlloc = g._npoints;

    if(g._Tri)
    {
        _Tri = new int[3*g._ntri];
        if(_Tri==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGrid::operator=(). Copying %d triangles.\n", g._ntri);
            return *this;
        }
        for(int it=0; it<3*_ntri; it++) _Tri[it] = g._Tri[it];
    }
    _ntri = g._ntri;

    if(g.Group)
    {
        Group = new UGroup(_npoints, (UGroupElem*const*)_sensors);
        if(Group==NULL || Group->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UGrid::operator=(). Copying UGroup object.\n");
            return *this;
        }
    }
    return *this;
}

UGrid::~UGrid()
{
    DeleteAllMembers(U_OK);
}

bool UGrid::operator==(const UGrid &g) const
{
    if(this==&g) return true;
    if(this==NULL || &g==NULL) return false;

    if(_npoints != g._npoints) return false;
    for(int n=0; n<_npoints; n++)
        if(*(_sensors[n]) != *(g._sensors[n]) ) return false;

    return true;
}

bool UGrid::operator!=(const UGrid &g) const
{
    if(*this==g) return false;
    return true;
}

UGrid::GridType UGrid::GetGridType(void) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetGridType(). Object not properly set. \n");
        return U_GRD_NOTYPE;
    }

    GridType GT = U_GRD_NOTYPE;
    if(_sensors[0]->GetStype()==USensor::U_SEN_MAG ) GT = U_GRD_MEG;
    if(_sensors[0]->GetStype()==USensor::U_SEN_GRAD) GT = U_GRD_MEG;
    if(_sensors[0]->GetStype()==USensor::U_SEN_EEG ) GT = U_GRD_EEG;
    if(GT!=U_GRD_MEG && GT!=U_GRD_EEG) return U_GRD_NOTYPE;

    for(int i=1; i<_npoints; i++)
    {
        if(GT==U_GRD_MEG)
        {
            if(_sensors[i]->GetStype()==USensor::U_SEN_MAG ) continue;
            if(_sensors[i]->GetStype()==USensor::U_SEN_GRAD) continue;
        }
        if(GT==U_GRD_EEG)
        {
            if(_sensors[i]->GetStype()==USensor::U_SEN_EEG ) continue;
        }
        return U_GRD_NOTYPE;
    }
    return GT;
}

USensor UGrid::GetDefaultSensor(const char* Name)
{
    USensor Sens;
    if(Name==NULL)
    {
        CI.AddToLog("WARNING: Ugrid::GetDefaultSensor(). NULL electrode label. \n");
        Sens.SetStype(USensor::U_SEN_EEG);
        Sens.SetName("NoName");
        return Sens;
    }
    if(IsStandardEEGLabelRefLay(Name)==true)
    {
        for(int i=0; i<NDEFELECT_REFLAY; i++)
            if(!stricmp(Name, DefArrayRefLay[i].Name)) return USensor(DefArrayRefLay[i]);
    }
    if(IsStandardREFLabelRefLay(Name)==true)
    {
        for(int i=0; i<NDEFELECT_REFLAY; i++)
            if(!stricmp(Name, DefArrayRefLay[i].Name))
            {
                Sens = USensor(DefArrayRefLay[i]);
                Sens.Setx(Sens.Getx()*1.1);
                return Sens;
            }
    }

    bool elFound = false;
    for(int i=0; i<NDEFELECT; i++)
    {
        if(IsStringCompatible(DefArrayE[i].Name, Name, false)==false) continue;
        UVector3 x(DefArrayE[i].x, DefArrayE[i].y, DefArrayE[i].z);
        Sens.Setx(x);
        Sens.SetStype(USensor::U_SEN_EEG);
        Sens.SetName(Name);
        elFound = true;
        break;
    }
    if(elFound==false && (Name[0]==' ' || Name[0]=='-' || Name[0]=='_'|| Name[0]=='^')) // Try skipping first '-' or '_' char
    {
        for(int i=0; i<NDEFELECT; i++)
        {
            if(IsStringCompatible(DefArrayE[i].Name, Name+1, false)==false) continue;
            UVector3 x(DefArrayE[i].x, DefArrayE[i].y, DefArrayE[i].z);
            Sens.Setx(x);
            Sens.SetStype(USensor::U_SEN_EEG);
            Sens.SetName(Name);
            elFound = true;
            break;
        }
    }
    if(elFound==false) // Try gradiometer
    {
        for(int i=0; i<NDEFMAGN; i++)
        {
            if(IsStringCompatible(Name, DefArrayM[i].Name, false)==false) continue;
            UVector3  x(DefArrayM[i].x,  DefArrayM[i].y,  DefArrayM[i].z );
            UVector3 cx(DefArrayM[i].cx, DefArrayM[i].cy, DefArrayM[i].cz);
            UVector3 nx(DefArrayM[i].nx, DefArrayM[i].ny, DefArrayM[i].nz);
            Sens.Setx(x);
            Sens.Setc(cx);
            Sens.Setn(nx);
            Sens.SetStype(USensor::U_SEN_GRAD);
            Sens.SetName(Name);
            elFound = true;
        }
    }
    if(elFound==false)
    {
        Sens.SetStype(USensor::U_SEN_POINT);
        Sens.SetName(Name);
    }
    return Sens;
}

const USensor* UGrid::GetSensorPointer(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorPointer(). Object NULL or not properly set.\n");
        return NULL;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorPointer(). Indices out of range: is=%d .\n", is);
        return NULL;
    }
    return _sensors[is];
}
USensor UGrid::GetSensor(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSensor(). Object NULL or not properly set.\n");
        return USensor();
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetSensor(). Indices out of range: is=%d .\n", is);
        return USensor();
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensor(). Erroneous sensor, is=%d .\n", is);
        return USensor();
    }
    return *(_sensors[is]);
}
UVector3 UGrid::GetPosition(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetPosition(). Object NULL or not properly set.\n");
        return UVector3();
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetPosition(). Indices out of range: is=%d .\n", is);
        return UVector3();
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetPosition(). Erroneous sensor, is=%d .\n", is);
        return UVector3();
    }
    return _sensors[is]->Getx();
}
UVector3 UGrid::GetPositionCompCoil(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetPositionCompCoil(). Object NULL or not properly set.\n");
        return UVector3();
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetPositionCompCoil(). Indices out of range: is=%d .\n", is);
        return UVector3();
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetPositionCompCoil(). Erroneous sensor, is=%d .\n", is);
        return UVector3();
    }
    return _sensors[is]->Getc();
}
UVector3 UGrid::GetOrientation(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetOrientation(). Object NULL or not properly set.\n");
        return UVector3();
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetOrientation(). Indices out of range: is=%d .\n", is);
        return UVector3();
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetOrientation(). Erroneous sensor, is=%d .\n", is);
        return UVector3();
    }
    return _sensors[is]->Getn();
}
const USensor * UGrid::GetSensorClosestToAxis(int dir, bool PosAx, int*isens) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorClosestToAxis(). Object NULL or not properly set.\n");
        return NULL;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorClosestToAxis(). dir out of range: dir=%d .\n", dir);
        return NULL;
    }
    
    int    is  = -1;
    double Dis = 1.e100;
    for(int i=0; i<_npoints; i++)
    {
        UVector3  X = _sensors[i]->Getx();
        if( (X[dir]>0. && NOT(PosAx) ) || X[dir]<0. && PosAx) continue;

        double Test = X.Project(dir).GetNorm();
        if(Test>=Dis) continue;
        is  = i;
        Dis = Test;
    }
    if(is<0)
    {
        CI.AddToLog("WARNING: UGrid::GetSensorClosestToAxis(). sensor not found along dir=%d in requested hemisphere.\n", dir);
        for(int i=0; i<_npoints; i++)
        {
            double Test = _sensors[i]->Getx().Project(dir).GetNorm();
            if(Test>=Dis) continue;
            is  = i;
            Dis = Test;
        }
    }
    if(isens) *isens = is;
    return _sensors[MAX(0,is)];
}
double UGrid::Getx(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::Getx(). Object NULL or not properly set.\n");
        return 0.;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::Getx(). Indices out of range: is=%d .\n", is);
        return 0.;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Getx(). Erroneous sensor, is=%d .\n", is);
        return 0.;
    }
    return _sensors[is]->Getx().Getx();
}
double UGrid::Gety(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::Gety(). Object NULL or not properly set.\n");
        return 0.;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::Gety(). Indices out of range: is=%d .\n", is);
        return 0.;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Gety(). Erroneous sensor, is=%d .\n", is);
        return 0.;
    }
    return _sensors[is]->Getx().Gety();
}
double UGrid::Getz(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::Getz(). Object NULL or not properly set.\n");
        return 0.;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::Getz(). Indices out of range: is=%d .\n", is);
        return 0.;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Getz(). Erroneous sensor, is=%d .\n", is);
        return 0.;
    }
    return _sensors[is]->Getx().Getz();
}
const char* UGrid::GetName(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetName(). Object NULL or not properly set.\n");
        return NULL;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetName(). Indices out of range: is=%d .\n", is);
        return NULL;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetName(). Erroneous sensor, is=%d .\n", is);
        return NULL;
    }
    return _sensors[is]->GetName();
}
int UGrid::GetIndexFromName(const char* Name, bool CaseSens) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetIndexFromName(). Object NULL or not properly set.\n");
        return -1;
    }
    if(_sensors==NULL && _npoints==0) return -1;
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetIndexFromName(). Sensors not properly set.\n");
        return -1;
    }
    if(Name==NULL) return -1;

    for(int is=0; is<_npoints; is++)
    {
        if(_sensors[is]==NULL) continue;
        const char* NameIn = _sensors[is]->GetName();
        if(IsStringCompatible(NameIn, Name, CaseSens)==true) return is;
    }
    return -1;
}

USensor::SensorType UGrid::GetSensorType(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorType(). Object NULL or not properly set.\n");
        return USensor::U_SEN_NOTYPE;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorType(). Indices out of range: is=%d .\n", is);
        return USensor::U_SEN_NOTYPE;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorType(). Erroneous sensor, is=%d .\n", is);
        return USensor::U_SEN_NOTYPE;
    }
    return _sensors[is]->GetStype();
}
int UGrid::GetGroupID(int is) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupID(). Object NULL or not properly set.\n");
        return -1;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupID(). Indices out of range: is=%d .\n", is);
        return -1;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupID(). Erroneous sensor, is=%d .\n", is);
        return -1;
    }
    return _sensors[is]->GetGroupID();
}
double UGrid::GetMinDistance(int* is1, int* is2) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetMinDistance(). Object NULL or not properly set.\n");
        return 0.;
    }

    double  Dist = -1;
    for(int i1=0; i1<_npoints; i1++)
    {
        if(_sensors[i1]==NULL) continue;
        for(int i2=i1+1; i2<_npoints; i2++)
        {
            if(_sensors[i2]==NULL) continue;

            double Test = GetDistance(i1, i2);
            if(Dist<0 || Test<Dist)
            {
                Dist = Test;
                if(is1) *is1 = i1;
                if(is2) *is2 = i2;
            }
        }
    }
    if(Dist<0.)
    {
        CI.AddToLog("ERROR: UGrid::GetMinDistance(). No valid sensors.\n");
        return 0.;
    }
    return Dist;
}

double UGrid::GetDistance(int is1, int is2) const
{
    if(this==NULL || _sensors==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetDistance(). Object NULL or not properly set.\n");
        return 0.;
    }
    if(is1<0 || is1>=_npoints || is2<0 || is2>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetDistance(). Indices out of range: is1=%d, is2=%d   .\n", is1, is2);
        return 0.;
    }
    if(_sensors[is1]==NULL || _sensors[is2]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetDistance(). Sensors NULL is1=%d, or is2=%d   .\n", is1, is2);
        return 0.;
    }
    return (_sensors[is1]->Getx()-_sensors[is2]->Getx()).GetNorm();
}
ErrorType UGrid::SetSensor(const USensor* sens, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensor(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(sens==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensor(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetSensor(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }

    USensor* pNew = new USensor(*sens);
    if(pNew==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensor(). Copying sensor, is = %d .\n", is);
        return U_ERROR;
    }
    delete _sensors[is]; _sensors[is] = pNew;
    delete[] _Tri; _Tri = NULL;

    if(Group) return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    return U_OK;
}
ErrorType UGrid::ReorderSensors(const int* NewIndex, int Nindex)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::ReorderSensors(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(NewIndex==NULL || Nindex==0 || Nindex>_npoints)
    {
        CI.AddToLog("ERROR: UGrid::ReorderSensors(). Invalid (NULL) argument(s), Nindex = %d. \n", Nindex);
        return U_ERROR;
    }
    for(int k=0; k<Nindex; k++)
    {
        if(NewIndex[k]>=0 && NewIndex[k]<Nindex) continue;
        CI.AddToLog("ERROR: UGrid::ReorderSensors(). Index out of range: NewIndex[%d] = %d. \n", k, NewIndex[k]);
        return U_ERROR;
    }
    USensor**  NewSensors = new USensor*[_npointsAlloc];
    if(NewSensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::ReorderSensors(). Memory allocation: _npointsAlloc= %d. \n", _npointsAlloc);
        return U_ERROR;
    }
    for(int i=0;      i<Nindex       ; i++) NewSensors[i] = NULL;
    for(int i=Nindex; i<_npointsAlloc; i++) NewSensors[i] = _sensors[i];
    for(int i=0;      i<Nindex       ; i++) NewSensors[i] = _sensors[NewIndex[i]];
    
    delete[] _sensors; _sensors = NewSensors;
    if(Group) return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);

    return U_OK;
}
int* UGrid::GetSensorNameOrder(bool HighFirst) const
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorNameOrder(). Object NULL or invalid _sensors pointer. \n");
        return NULL;
    }
    if(_npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorNameOrder(). Invalid number of sensors: %d. \n", _npoints);
        return NULL;
    }

    PMT_CCP* NameArr = new PMT_CCP[_npoints];
    if(NameArr==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorNameOrder(). Memory allocation: _npoints=%d. \n", _npoints);
        return NULL;
    }
    for(int i=0; i<_npoints; i++) NameArr[i] = _sensors[i]->GetName();

    int* Index = ::GetOrderIndexArray(NameArr, _npoints, HighFirst);
    if(Index==NULL)
    {
        delete[] NameArr;
        CI.AddToLog("ERROR: UGrid::GetSensorNameOrder(). Sorting sensor names. \n");
        return NULL;
    }
    delete[] NameArr;

    return Index;
}
int* UGrid::GetGroupNameOrder(bool HighFirst) const
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupNameOrder(). Object NULL or invalid _sensors pointer. \n");
        return NULL;
    }
    if(_npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupNameOrder(). Invalid number of sensors: %d. \n", _npoints);
        return NULL;
    }
    if(Group==NULL || Group->GetNGroup()<=1)
    {
        if(Group->GetNGroup()!=1) CI.AddToLog("WARNING: UGrid::GetGroupNameOrder(). Groups not set. \n");
        return GetSensorNameOrder(HighFirst);
    }

    PMT_CCP* NameArr = new PMT_CCP[_npoints];
    int*     Index   = new int[_npoints];
    if(NameArr==NULL || Index==NULL)
    {
        delete[] NameArr; delete[] Index;
        CI.AddToLog("ERROR: UGrid::GetGroupNameOrder(). Memory allocation: _npoints=%d. \n", _npoints);
        return NULL;
    }

    int NG     = Group->GetNGroup();
    int NelTot = 0;
    for(int ig=0; ig<NG; ig++)
    {
        int Nel = Group->GetNElem(ig);
        if(Nel==NULL) continue;

        for(int ie=0; ie<Nel; ie++) 
        {
            int is = GetGroup()->GetElem(ig, ie);
            if(is<0||is>=_npoints)
            {
                delete[] NameArr; delete[] Index;
                CI.AddToLog("ERROR: UGrid::GetGroupNameOrder(). Erroneous index, %d: (ig,ie) = (%d,%d). \n", is, ig,ie);
                return NULL;
            }
            NameArr[ie] = _sensors[is]->GetName();
        }
        int* SubIndex = ::GetOrderIndexArray(NameArr, Nel, HighFirst);
        if(SubIndex==NULL)
        {
            delete[] NameArr; delete[] Index;
            CI.AddToLog("ERROR: UGrid::GetGroupNameOrder(). Sorting sensor names of group %d. \n", ig);
            return NULL;
        }
        for(int ie=0; ie<Nel; ie++)  Index[NelTot+ie] = GetGroup()->GetElem(ig, SubIndex[ie]);
        delete[] SubIndex;

        NelTot += Nel;
    }
    delete[] NameArr;
    return Index;
}

ErrorType UGrid::SetPosition(UVector3 x, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetPosition(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetPosition(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetPosition(). Sensor[%d]==NULL. \n", is);
        return U_ERROR;
    }
    _sensors[is]->Setx(x);
    return U_OK;
}
ErrorType UGrid::SetOrientation(UVector3 n, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetOrientation(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetOrientation(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetOrientation(). Sensor[%d]==NULL. \n", is);
        return U_ERROR;
    }
    _sensors[is]->Setn(n);
    return U_OK;
}
ErrorType UGrid::SetName(const char* Name, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetName(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetName(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetName(). Sensor[%d]==NULL. \n", is);
        return U_ERROR;
    }
    return _sensors[is]->SetName(Name);
}
ErrorType UGrid::SetSensorType(USensor::SensorType ST, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensorType(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetSensorType(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensorType(). Sensor[%d]==NULL. \n", is);
        return U_ERROR;
    }
    _sensors[is]->SetStype(ST);
    return U_OK;
}
ErrorType UGrid::SetGroupID(int GroupID, int is)
{
    if(this==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetGroupID(). Object NULL or invalid _sensors pointer. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SetGroupID(). Invalid index: is = %d .\n", is);
        return U_ERROR;
    }
    if(_sensors[is]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetGroupID(). Sensor[%d]==NULL. \n", is);
        return U_ERROR;
    }
    _sensors[is]->SetGroupID(GroupID);
    return U_OK;
}
int UGrid::ConvertGradioToMagneto(void)
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::ConvertGradioToMagneto(). Object NULL or invalid _sensors pointer. \n");
        return -1;
    }
    if(_sensors==NULL) return 0;

    int NConvert = 0;
    for(int is=0; is<_npoints; is++)
    {
        if(_sensors[is]==NULL || _sensors[is]->GetStype()!=USensor::U_SEN_GRAD) continue;

        _sensors[is]->SetStype(USensor::U_SEN_MAG);
        NConvert++;
    }
    return NConvert;
}

bool UGrid::AreSensorLabelsEqual(const UGrid &g) const
{
    if(this==&g) return true;
    if(this==NULL || &g==NULL) return false;

    if(_npoints != g._npoints) return false;
    for(int n=0; n<_npoints; n++)
    {
        if(_sensors[n]==NULL || g._sensors[n]==NULL) return false;
        if(strncmp(_sensors[n]->GetName(), g._sensors[n]->GetName(), USensor::MAXLABELSIZE)) return false;
    }
    return true;
}

UString UGrid::GetGroupName(int igroup) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupName(). Object NULL or erroneous. \n");
        return UString(igroup,"ERROR_%d");
    }
    if(Group==NULL || Group->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetGroupName(). Groups not set. \n");
        return UString(igroup,"ERROR_%d");
    }
    return Group->GetGroupName(igroup);
}

UVector3 UGrid::GetCenter(void) const
{
    UVector3 Center(0.,0.,0.);
    if(_npoints<=0) return Center;

    for(int i=0; i<_npoints; i++)
        if(_sensors[i])
            Center += _sensors[i]->Getx();

    return Center/(double)_npoints;
}

#ifndef PUBLIC_SOURCES

ErrorType UGrid::ProjectSphere(UVector3 Center, double Radius, bool AlignOrientation)
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::ProjectSphere(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::ProjectSphere(). sensors not set.\n");
        return U_ERROR;
    }
    if(Radius<=0)
    {
        CI.AddToLog("ERROR: UGrid::ProjectSphere(). Radius out of range: Radius = %f .\n", Radius);
        return U_ERROR;
    }
    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL) continue;
        UVector3 Base = _sensors[i]->Getc()-_sensors[i]->Getx();
        UVector3 Pos  = _sensors[i]->Getx()-Center;
        Pos.Normalize();
        Pos = Pos* Radius;
        _sensors[i]->Setx(Pos);
        if(AlignOrientation==true)
        {
            _sensors[i]->Setn(Pos/Radius);
            _sensors[i]->Setc(Pos+Base);
        }
    }
    return U_OK;
}

ErrorType UGrid::SubSample(int Nnew)
/*
     Creatre a new Grid, by sub-sampling *this grid in such a way that Nnew equi-distant
     sensors remain. It is assumed that the sensors of *this are located approximately on
     a sphere.
 */
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SubSample(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SubSample(). sensors not set.\n");
        return U_ERROR;
    }

    if(Nnew>=_npoints)  return U_OK;
    if(Nnew<=0       )  return U_ERROR;

    UGrid    Gnew(Nnew);
    UGridFit Gold(*this);
    if(Gnew.GetError()!=U_OK || Gold.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SubSample(). Copying *this  .\n");
        return U_ERROR;
    }
    UVector3 Center;
    double   rad;
    Gold.FitSphere(Center,&rad);

    double thmax = 0;
    for(int n=0; n<_npoints; n++)
    {
        if(_sensors[n]==NULL) continue;
        double test = (Gold._sensors[n]->Getx()-Center).GetTheta();
        if(test>thmax) thmax = test;
    }
    thmax *= 1.1;

/* Count the number of theta values nth*/
    int NTh = 2;
    for(int nth = 2; nth<_npoints; nth++)
    {
        int ntot = 0;
        for(int ith=0;ith<nth;ith++)
        {
            int nfi = int(floor( (nth/thmax)* PI2*sin(ith*thmax/nth)));
            ntot   += nfi;
        }
        if(ntot<Nnew) continue;
        NTh = nth;
        break;
    }

    double ThetaStep = thmax/NTh;
    int    inew      = 0;
    for(int ith=0; ith<=NTh; ith++)
    {
        int nfi = int(floor((PI2/ThetaStep) *sin(ith*ThetaStep)));
        for(int ifi=0; ifi<nfi; ifi++)
        {
            UVector3 y = Center + rad*UVector3(ith*thmax/NTh, 1000.*ith + ifi*PI2/nfi);

/* Select the point of Gold which is closest to y.*/
            double Distance2 = 1.e6*rad*rad;
            int    iclose    = -1;
            for(int i=0; i<_npoints; i++)
            {
                if(Gold._sensors[i]==NULL) continue;
                UVector3 x = (Gold._sensors[i])->Getx();
                if(x==UVector3()) continue;             // Skip invalidated

                double test = (x-y).GetNorm2();
                if( test <Distance2 )
                {
                    Distance2 = test;
                    iclose    = i;
                }
            }
            if(iclose<0)
            {
                CI.AddToLog("ERROR: UGrid::SubSample(). Not all points found.  .\n");
                *this = Gnew;
                return U_ERROR;
            }
            Gnew.SetSensor(Gold._sensors[iclose], inew++);
            (Gold._sensors[iclose])->Setx(UVector3()); // Invalidate

            if(inew>=Nnew)
            {
                *this = Gnew;
                return _error;
            }
        }
    }
    *this = Gnew;
    return _error;
}
#endif //// PUBLIC_SOURCES

ErrorType UGrid::UpdateGroups(void)
{
    if(this==NULL || _error!=U_OK || Group==NULL || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::UpdateGroups(). Object not properly set. \n");
        return U_ERROR;
    }
    return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
}
int UGrid::GetNSensors(USensor::SensorType ST) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetNSensors(). NULL or erroneous object.\n");
        return 0;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetNSensors(). sensors not set.\n");
        return 0;
    }

    int Nsens = 0;
    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL)           continue;
        if(_sensors[i]->GetStype()==ST) Nsens++;
    }
    return Nsens;
}
UGrid* UGrid::GetSubGrid(const int* Indices, int NSens) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). NULL or erroneous object.\n");
        return NULL;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). sensors not set.\n");
        return NULL;
    }
    if(Indices==NULL || NSens<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). Invalid (NULL) argument(s). NSens = %d.\n", NSens);
        return NULL;
    }
    for(int is=0; is<NSens; is++)
        if(Indices[is]<0 || Indices[is]>=_npoints)
        {
            CI.AddToLog("ERROR: UGrid::GetSubGrid(). Invalid sensor index: Indices[%d] = %d .  \n", is, Indices[is]);
            return NULL;
        }

    UGrid* Gsub = new UGrid(NSens);
    if(Gsub==NULL || Gsub->GetError()!=U_OK)
    {
        delete Gsub;
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). Creating sub-grid.\n");
        return NULL;
    }

    for(int isub=0; isub<NSens; isub++)
        Gsub->SetSensor(_sensors[Indices[isub]], isub);

    return Gsub;
}

UGrid* UGrid::GetSubGridFirst(int NFirst) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridFirst(). NULL or erroneous object.\n");
        return NULL;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridFirst(). sensors not set.\n");
        return NULL;
    }
    if(NFirst<0 || NFirst>=_npoints) return new UGrid(*this);

    if(NFirst==0)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridFirst(). Invalid (NULL) argument(s). NFirst = %d.\n", NFirst);
        return NULL;
    }

    UGrid* Gsub = new UGrid(NFirst);
    if(Gsub==NULL || Gsub->GetError()!=U_OK)
    {
        delete Gsub;
        CI.AddToLog("ERROR: UGrid::GetSubGridFirst(). Creating sub-grid.\n");
        return NULL;
    }

    for(int is=0; is<NFirst; is++)
        Gsub->SetSensor(_sensors[is], is);

    return Gsub;
}

UGrid* UGrid::GetSubGrid(USensor::SensorType ST) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). NULL or erroneous object.\n");
        return NULL;
    }
    if(_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). sensors not set.\n");
        return NULL;
    }

    int Nsens = this->GetNSensors(ST);
    if(Nsens<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). No sensors of type ST (=%d), Nsens = %d.\n", ST, Nsens);
        return NULL;
    }
    UGrid* Gsub = new UGrid(Nsens);
    if(Gsub==NULL || Gsub->GetError()!=U_OK)
    {
        delete Gsub;
        CI.AddToLog("ERROR: UGrid::GetSubGrid(). Creating sub-grid.\n");
        return NULL;
    }

    for(int i=0,isub=0; i<_npoints && isub<Nsens; i++)
    {
        if(_sensors[i]            ==NULL) continue;
        if(_sensors[i]->GetStype()!=ST  ) continue;
        Gsub->SetSensor(_sensors[i], isub++);
    }
    return Gsub;
}
bool UGrid::IsSubGrid(const UGrid* SubGrid) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::IsSubGrid(). Object NULL, erroneous or sensors not set.\n");
        return false;
    }
    if(SubGrid==NULL || SubGrid->GetError()!=U_OK || SubGrid->_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::IsSubGrid(). NULL, erroneous UGrid argument.\n");
        return false;
    }

    int NSub = SubGrid->GetNpoints();
    if(NSub>_npoints) return false;

    for(int is=0; is<NSub; is++)
    {
        bool    Found = false;
        USensor Ssub  = SubGrid->GetSensor(is);
        for(int i=0; i<_npoints; i++)
        {
            USensor S = GetSensor(i);
            S.SetGroupID(Ssub.GetGroupID());
            if(S!=Ssub) continue;

            Found = true;
            break;
        }
        if(Found==false)
        {
            CI.AddToLog("Note: UGrid::IsSubGrid().  Sensor not found: %s .\n", Ssub.GetName());
            return false;
        }
    }
    return true;
}

int* UGrid::GetSensorTypeIndices(USensor::SensorType ST, int* NSens) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorTypeIndices(). Object NULL, erroneous or sensors not set.\n");
        return NULL;
    }
    int NST = GetNSensors(ST);
    if(NST<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorTypeIndices(). No sensors of type %d present .\n", ST);
        return NULL;
    }
    int* Indices = new int[NST];
    if(Indices==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorTypeIndices(). Memory allocation, NST = %d  .\n", NST);
        return NULL;
    }
    for(int is=0, ind=0; is<_npoints; is++)
    {
        if(_sensors[is]->GetStype()!=ST) continue;
        if(ind>=NST)
        {
            delete[] Indices;
            CI.AddToLog("ERROR: UGrid::GetSensorTypeIndices(). ind out of range (ind=%d), NST = %d  .\n", ind, NST);
            return NULL;
        }
        Indices[ind] = is;
        ind++;
    }
    if(NSens) *NSens = NST;
    return Indices;
}
int* UGrid::GetSubGridIndices(const UGrid* SubGrid) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridIndices(). Object NULL, erroneous or sensors not set.\n");
        return NULL;
    }
    if(SubGrid==NULL || SubGrid->GetError()!=U_OK || SubGrid->_sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridIndices(). NULL, erroneous UGrid argument.\n");
        return NULL;
    }
    if(IsSubGrid(SubGrid)==false)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridIndices().  UGrid argument is not a sub-grid of this.\n");
        return NULL;
    }
    int  NSub  = SubGrid->GetNpoints();
    int* Index = new int[NSub];
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSubGridIndices().  Memory allocation, NSub = %d .\n", NSub);
        return NULL;
    }
    for(int is=0; is<NSub; is++)
    {
        bool    Found = false;
        USensor Ssub  = SubGrid->GetSensor(is);
        for(int i=0; i<_npoints; i++)
        {
            USensor S = GetSensor(i);
            S.SetGroupID(Ssub.GetGroupID());
            if(S!=Ssub) continue;

            Found = true;
            Index[is] = i;
            break;
        }
        if(Found==false)
        {
            delete[] Index;
            CI.AddToLog("ERROR: UGrid::GetSubGridIndices().  Sensor not found: %s .\n", Ssub.GetName());
            return NULL;
        }
    }
    return Index;
}

ErrorType UGrid::ShiftSensors(UVector3 Shift)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::ShiftSensors(). Object NULL, erroneous or sensors not set.\n");
        return U_ERROR;
    }
    return Transform(UEuler(Shift));
}

ErrorType UGrid::Transform(const UEuler& xfm)
/*
     Transform the UGrid using the Euler transform matrix *xfm.
 */
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Transform(). Object NULL, erroneous or sensors not set.\n");
        return U_ERROR;
    }
    for(int i=0;i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;
        _sensors[i]->Transform(xfm);
    }
    return U_OK;
}
ErrorType UGrid::Transform(const ULinTran& xfm)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Transform(). Object NULL, erroneous or sensors not set.\n");
        return U_ERROR;
    }
    for(int i=0;i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;
        _sensors[i]->Transform(xfm);
    }
    return U_OK;
}
ErrorType UGrid::Transform(const UEuler& xfm, USensor::SensorType ST)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Transform(). Object NULL, erroneous or sensors not set.\n");
        return U_ERROR;
    }
    for(int i=0;i<_npoints;i++)
    {
        if(_sensors[i]==NULL || _sensors[i]->GetStype()!=ST) continue;
        _sensors[i]->Transform(xfm);
    }
    return U_OK;
}
ErrorType UGrid::Transform(const ULinTran& xfm, USensor::SensorType ST)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::Transform(). Object NULL, erroneous or sensors not set.\n");
        return U_ERROR;
    }
    for(int i=0;i<_npoints;i++)
    {
        if(_sensors[i]==NULL || _sensors[i]->GetStype()!=ST) continue;
        _sensors[i]->Transform(xfm);
    }
    return U_OK;
}

ErrorType UGrid::CopyIDsFromNames(const UGrid* G)
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::CopyIDsFromNames(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Group==NULL)
    {
        CI.AddToLog("ERROR: UGrid::CopyIDsFromNames(). Group not set. \n");
        return U_ERROR;
    }
    if(G==NULL || G->_error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::CopyIDsFromNames(). Argument NULL or erroneous. \n");
        return U_ERROR;
    }
    if(G->Group==NULL)
    {
        CI.AddToLog("ERROR: UGrid::CopyIDsFromNames(). Argumeny Group not set. \n");
        return U_ERROR;
    }
    return Group->CopyIDsFromNames(G->Group);
}

ErrorType UGrid::MakeLabelsUnique(void)
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::MakeLabelsUnique(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(_sensors==NULL)
    {
        if(_npoints==NULL) return U_OK;
        CI.AddToLog("ERROR: UGrid::MakeLabelsUnique(). _sensors not set. \n");
        return U_ERROR;
    }
    if(Group)
    {
        if(Group->MakeLabelsUnique()!=U_OK)
        {
            CI.AddToLog("ERROR: UGrid::MakeLabelsUnique(). Making names of GroupElements unique. \n");
            return U_ERROR;
        }
        for(int i=0; i<_npoints; i++)
        {
            const UGroupElem* E = Group->GetElement(i);
            if(E==NULL || _sensors[i]==NULL) continue;

            _sensors[i]->SetName(E->GetName());
        }
        return U_OK;
    }

    UGroup G(_npoints, (UGroupElem* const*) _sensors);
    if(G.GetError()!=U_OK || G.MakeLabelsUnique()!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::MakeLabelsUnique(). Making names of copied GroupElements unique. \n");
        return U_ERROR;
    }
    for(int i=0; i<_npoints; i++)
    {
        const UGroupElem* E = G.GetElement(i);
        if(E==NULL || _sensors[i]==NULL) continue;

        _sensors[i]->SetName(E->GetName());
    }
    return U_OK;
}

int UGrid::GetChannum(const char* Label) const
/*
     Return the index of the sensor with name Label[]. If Label[] is not
     in the sensor array return -1.
 */
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetChannum(). this==NULL or erroneous, or _sensors==NULL  .\n");
        return -1;
    }
    if(Label==NULL) return -1;

/* Try case sensitive */
    for(int i=0; i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;
        if(!strncmp(_sensors[i]->GetName(), Label, USensor::MAXLABELSIZE)) return i;
    }
/* Try case in-sensitive */
    for(int i=0; i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;
        if(IsStringCompatible(_sensors[i]->GetName(), Label, false)==true) return i;
    }
/* Skip first dummy char of _sensors[i] */
    for(int i=0; i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;

        if(_sensors[i]->GetName()==NULL || strlen(_sensors[i]->GetName())<=1) continue;
        if(_sensors[i]->GetName()[0]!='-' &&
           _sensors[i]->GetName()[0]!='_' &&
           _sensors[i]->GetName()[0]!=' ') continue;
        if(IsStringCompatible(_sensors[i]->GetName()+1, Label, false)==true) return i;
    }

/* Skip first dummy char of Label[] */
    if(strlen(Label)<=1) return -1;
    if(Label[0]!='-' && Label[0]!='_' && Label[0]!=' ') return -1;

    for(int i=0; i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;

        if(IsStringCompatible(_sensors[i]->GetName(), Label+1, false)==true) return i;
    }
/* Skip first dummy char of _sensors[i] and Label[] */
    for(int i=0; i<_npoints;i++)
    {
        if(_sensors[i]==NULL) continue;

        if(_sensors[i]->GetName()==NULL || strlen(_sensors[i]->GetName())<=1) continue;
        if(_sensors[i]->GetName()[0]!='-' &&
           _sensors[i]->GetName()[0]!='_' &&
           _sensors[i]->GetName()[0]!=' ') continue;
        if(IsStringCompatible(_sensors[i]->GetName()+1, Label+1, false)==true) return i;
    }

    return -1;
}

ErrorType UGrid::RemoveSensors(int first, int last)
{
    if(_error!=U_OK || this==NULL || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensors(). Invalid grid. \n");
        return U_ERROR;
    }
    if(first>last) return U_OK;

    first = MAX(0, MIN(_npoints-1, first));
    last  = MAX(0, MIN(_npoints-1, last ));

    int nrem = last-first+1;
    if(nrem<=0) return U_OK;

    for(int i=first; i<_npoints-nrem; i++)
    {
        delete _sensors[i];
        _sensors[i] = _sensors[i+nrem];
    }
    _npoints -= nrem;
    for(int i=_npoints; i<_npointsAlloc; i++) _sensors[i] = NULL;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensors(). Updating sensor groups.\n");
        return U_ERROR;
    }
    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensors(). Triangulating sensors. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UGrid::RemoveSensor(int is)
{
    if(_error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensor(). Invalid grid. \n");
        return U_ERROR;
    }
    if(is<0 || is>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensor(). Requested sensor out of range: is = %d  \n",is);
        return U_ERROR;
    }

    delete _sensors[is];
    for(int i=is; i<_npoints-1; i++)        _sensors[i] = _sensors[i+1];
    _npoints -= 1;
    for(int i=_npoints; i<_npointsAlloc; i++) _sensors[i] = NULL;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensor(). Updating sensor groups.\n");
        return U_ERROR;
    }
    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::RemoveSensor(). Triangulating sensors. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UGrid::SelectSensors(const bool* Select)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Invalid grid. \n");
        return U_ERROR;
    }
    if(Select==NULL) return U_OK;

    int Nrem  = 0;
    int ntake = 0;
    for(int n=0; n<_npoints; n++)
    {
        if(_sensors[n]==NULL) continue;
        if(Select[n]==true)
        {
            delete _sensors[ntake];
            _sensors[ntake] = _sensors[n];
            ntake++;
        }
        else
            Nrem++;
    }

    _npoints -= Nrem;
    for(int i=_npoints; i<_npointsAlloc; i++) _sensors[i] = NULL;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Updating sensor groups.\n");
        return U_ERROR;
    }
    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Triangulating sensors (_npoints=%d). \n", _npoints);
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UGrid::SelectSensors(const char* Labels)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Invalid grid. \n");
        return U_ERROR;
    }
    if(Labels==NULL || Labels[0]==0) return U_OK;

    int Nrem  = 0;
    int ntake = 0;
    for(int n=0; n<_npoints; n++)
    {
        if(_sensors[n]==NULL) continue;
        if(IsStringCompatible(_sensors[n]->GetName(), Labels, false)==true)
        {
            delete _sensors[ntake];
            _sensors[ntake] = _sensors[n];
            ntake++;
        }
        else
            Nrem++;
    }

    _npoints -= Nrem;
    for(int i=_npoints; i<_npointsAlloc; i++) _sensors[i] = NULL;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Updating sensor groups.\n");
        return U_ERROR;
    }
    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Triangulating sensors (_npoints=%d). \n", _npoints);
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UGrid::SelectSensors(const UString* Labels, int NLab)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Invalid grid. \n");
        return U_ERROR;
    }
    if(Labels==NULL || NLab<=0 || NLab>_npoints)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Parameter out of range NLab = %d. \n", NLab);
        return U_ERROR;
    }

    USensor**  NewSensors = new USensor*[NLab];
    if(NewSensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Memory allocation, NLab = %d. \n", NLab);
        return U_ERROR;
    }
    for(int n=0; n<NLab; n++) NewSensors[n] = NULL;

    bool CaseSense     =false;
    bool IgnoreBlanks =  true;
    for(int n=0; n<NLab; n++)
    { 
        bool LabFound = false;
        for(int i=0; i<_npoints; i++)
        {
            if(_sensors[i]==NULL) continue;
            UString Nam(_sensors[i]->GetName());
            if(Labels[n].IsEqual(Nam, CaseSense, IgnoreBlanks))
            {
                NewSensors[n] = new USensor(*_sensors[i]);
                LabFound = true;
                break;
            }
        }
        if(LabFound==false)
        {
            for(int m=0; m<NLab; m++) delete NewSensors[n]; delete[] NewSensors;
            CI.AddToLog("ERROR: UGrid::SelectSensors(). Label not found: %s. \n", (const char*)Labels[n]);
            return U_ERROR;
        }
    }
    delete[] _sensors; _sensors = NewSensors;
    _npoints      = NLab;
    _npointsAlloc = NLab;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Updating sensor groups.\n");
        return U_ERROR;
    }
    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SelectSensors(). Triangulating sensors (_npoints=%d). \n", _npoints);
        return U_ERROR;
    }
    return U_OK;
}

int UGrid::RemoveDoubleSensors(double Tolerance)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::RemoveDoubleSensors(). Invalid grid. \n");
        return 0;
    }

    int  Nremove    = 0;
    bool SensRemove = true;
    while(SensRemove==true)
    {
        for(int i1=0; i1<_npoints; i1++)
        {
            for(int i2=i1+1; i2<_npoints; i2++)
            {
                if(Tolerance<=0)
                {
                    if((*_sensors[i1])==(*_sensors[i2]))
                    {
                        Nremove++;
                        RemoveSensor(i2);
                        i2--;
                    }
                }
                else
                {
                    if( ((*_sensors[i1]).GetStype()==(*_sensors[i2]).GetStype())            &&
                        ((*_sensors[i1]).Getx()-(*_sensors[i2]).Getx()).GetNorm()<Tolerance)
                    {
                        Nremove++;
                        RemoveSensor(i2);
                        i2--;
                    }
                }
            }
        }
        SensRemove = false;
    }
    if(Nremove>0)
    {
        if(TriangulateGrid()!=U_OK)
        {
            delete _Tri; _Tri = NULL;
            _ntri = 0;
            CI.AddToLog("WARNING: UGrid::RemoveDoubleSensors(). Updating triangulation. \n");
        }
        if(Group)
        {
            if(Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors)!=U_OK)
            {
                delete Group; Group = NULL;
                CI.AddToLog("WARNING: UGrid::RemoveDoubleSensors(). Updating UGroup-object \n");
            }
        }
    }
    return Nremove;
}

int UGrid::RemoveZeroSensors(void)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::RemoveZeroSensors(). Invalid grid. \n");
        return 0;
    }

    int  Nremove    = 0;
    for(int i1=0; i1<_npoints; i1++)
    {
        if(_sensors[i1]==NULL || _sensors[i1]->Getx()==UVector3())
        {
            Nremove++;
            RemoveSensor(i1);
            i1--;
        }
    }
    return Nremove;
}

int UGrid::GetNDoubleSensors(void) const
{
    if(_error!=U_OK || _sensors==NULL || _npoints<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetNDoubleSensors(). Invalid grid. \n");
        return 0;
    }

    int  NDouble    = 0;
    for(int i1=0; i1<_npoints; i1++)
        for(int i2=i1+1; i2<_npoints; i2++)
        {
            if(*(_sensors[i1])==*(_sensors[i2]))
            {
                NDouble++;
                break;
            }
        }
    return NDouble;
}

ErrorType UGrid::AddGrid(const UGrid* g)
{
    if(g==NULL || g->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::AddGrid(). Invalid argument. \n");
        return U_ERROR;
    }
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::AddGrid(). Invalid UGrid object. \n");
        return U_ERROR;
    }

    int NewPoints = _npoints + g->GetNpoints();
    USensor** NewS = new USensor*[NewPoints];

    if(NewS==NULL)
    {
        CI.AddToLog("ERROR: UGrid::AddGrid(). Memory allocation, NewPoints = %d. \n", NewPoints);
        return U_ERROR;
    }

    for(int is=0; is<NewPoints; is++)
    {
        if(is<_npoints)  NewS[is] = _sensors[is];
        else             NewS[is] = new USensor(*(g->_sensors[is-_npoints]));
    }

    delete[] _sensors;
    _sensors      = NewS;
    _npoints      = NewPoints;
    _npointsAlloc = NewPoints;

    ErrorType E = U_OK;
    if(Group) E = Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::AddGrid(). Updating sensor groups.\n");
        return U_ERROR;
    }

    if(_ntri==0 || _Tri==NULL || GetNDoubleSensors()>20)
    {
        delete[] _Tri; _Tri = NULL;
        _ntri = 0;
        return U_OK;
    }

    E = TriangulateGrid();
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::AddGrid(). Triangulating sensors. \n");
        return U_ERROR;
    }
    return U_OK;
}

bool AreLabelsCompatible(const UGrid* G1, const UGrid* G2, bool AddToLog)
{
    if(G1==NULL || G2==NULL)
    {
        if(AddToLog==true)
            CI.AddToLog("Note: AreLabelsCompatible(). NULL pointers. \n");
        return false;
    }

    int N1 = G1->GetNpoints();
    int N2 = G2->GetNpoints();
    if(N1 != N2)
    {
        if(AddToLog==true)
            CI.AddToLog("Note:  AreLabelsCompatible(). Different number of sensors: %d and %d. \n", N1, N2);
        return false;
    }
    for(int i=0; i<N1; i++)
    {
        if(G1->GetName(i)==NULL && G2->GetName(i)==NULL) continue;
        if(G1->GetName(i)==NULL || G2->GetName(i)==NULL)
        {
            if(AddToLog==true)
                CI.AddToLog("Note:  AreLabelsCompatible(). Different NULL labels at sensor  %d : \n", i);
            return false;
        }
        if(strcmp(G1->GetName(i), G2->GetName(i)) )
        {
            if(AddToLog==true)
            {
                CI.AddToLog("Note:  AreLabelsCompatible(). Different labels at sensor  %d : ", i);
                CI.AddToLog("%s and %s . \n", G1->GetName(i), G2->GetName(i));
            }
            return false;
        }
    }
    return true;
}
UGrid* GetCommonSensors(const UGrid* G1, const UGrid* G2)
{
    if(G1==NULL || G2==NULL || G1->GetError()!=U_OK || G2->GetError()!=U_OK)
    {
        CI.AddToLog("Note: GetCommonSensors(). NULL pointer(s) argments or erroneous UGrid(s). \n");
        return NULL;
    }
    UGrid* G = new UGrid();
    if(G==NULL || G->GetError()!=U_OK)
    {
        delete G;
        CI.AddToLog("Note: GetCommonSensors(). Creating empty grid. \n");
        return NULL;
    }
    int N1 = G1->GetNpoints();
    int N2 = G2->GetNpoints();
    for(int i1=0; i1<N1; i1++)
    {
        const char* Name1 = G1->GetName(i1);
        if(Name1==NULL) continue;
        
        bool Found     = false;
        bool CaseSense = true;
        for(int i2=0; i2<N2; i2++)
        {
            const char* Name2 = G2->GetName(i2);
            if(Name2==NULL) continue;
            if(G2->GetIndexFromName(Name1, CaseSense) <0) continue;
            Found = true;
            break;
        }
        if(Found==false)
        {
            CaseSense = false;
            for(int i2=0; i2<N2; i2++)
            {
                const char* Name2 = G2->GetName(i2);
                if(Name2==NULL) continue;
                if(G2->GetIndexFromName(Name1, CaseSense) <0) continue;
                Found = true;
                break;
            }
        }
        if(Found && G->AddSensor(G1->GetSensor(i1))!=U_OK)
        {
            delete G;
            CI.AddToLog("Note: GetCommonSensors(). Adding sensor. \n");
            return NULL;
        }
    }
    return G;
}


int* UGrid::GetNeighbouringSensorIndices(int isens, int* NNeigh) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(_Tri==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Triangle index array is NULL. \n");
        return NULL;
    }
    if(isens<0 || isens>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Sensor index out of range: isens = %d \n", isens);
        return NULL;
    }
    if(NNeigh==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Invalid NULL pointer NNeigh.\n");
        return NULL;
    }
    int NNmax = 0;
    for(int it=0, it3=0; it<_ntri; it++,it3+=3)
    {
        if(_Tri[it3  ]==isens) {NNmax+=2; continue;}
        if(_Tri[it3+1]==isens) {NNmax+=2; continue;}
        if(_Tri[it3+2]==isens) {NNmax+=2; continue;}
    }
    if(NNmax<=0)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Sensor has no neighbours: isens = %d \n", isens);
        return NULL;
    }
    int* Neig = new int[NNmax];
    if(Neig==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetNeighbouringSensorIndices(). Memory allocation, NNmax=%d  .\n", NNmax);
        return NULL;
    }
    int NN = 0;
    for(int it=0, it3=0; it<_ntri; it++,it3+=3)
    {
        bool New   = true;
        int  Index = _Tri[it3+1];
        if(_Tri[it3+0]==isens)
        {
            New   = true;
            Index = _Tri[it3+1];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            New   = true;
            Index = _Tri[it3+2];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            continue;
        }
        if(_Tri[it3+1]==isens)
        {
            New   = true;
            Index = _Tri[it3+2];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            New   = true;
            Index = _Tri[it3+0];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            continue;
        }
        if(_Tri[it3+2]==isens)
        {
            New   = true;
            Index = _Tri[it3+0];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            New   = true;
            Index = _Tri[it3+1];
            for(int nn=0; nn<NN; nn++) if(Neig[nn]==Index) {New=false; break;}
            if(New==true) {Neig[NN++]=Index;}
            continue;
        }
    }
    *NNeigh = NN;
    return Neig;
}

ErrorType UGrid::GetTriangleIndices(int it, int* is0, int* is1, int* is2) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::GetTriangleIndices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(_Tri==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetTriangleIndices(). Triangle index array is NULL. \n");
        return U_ERROR;
    }
    if(it<0 || it>=_ntri)
    {
        CI.AddToLog("ERROR: UGrid::GetTriangleIndices(). Triangle index out of range: it = %d \n", it);
        return U_ERROR;
    }
    if(is0) *is0 = _Tri[3*it  ];
    if(is1) *is1 = _Tri[3*it+1];
    if(is2) *is2 = _Tri[3*it+2];

    return U_OK;
}

ErrorType UGrid::TriangulateGrid(double MaxEdgeRel)
{
    if(this==NULL) return U_ERROR;

    if( _error!=U_OK ||
        _npoints<0   ||
      (_npoints && !_sensors) )
    {
        CI.AddToLog("ERROR: UGrid::TriangulateGrid(). Invalid UGrid. _npoints %d.\n",_npoints);
        return U_ERROR;
    }
    if(_npoints<=2)
    {
        delete[] _Tri; _Tri=NULL;
        return U_OK;
    }
/* Sanity check*/
    bool NoCoin = false;
    for(int k=0; k<10; k++)
    {
        int     i1       = -1;
        int     i2       = -1;
        double  MinDis   = GetMinDistance(&i1, &i2);
    
        if(MinDis>1.E-7) {NoCoin=true; break;}
        CI.AddToLog("WARNING: UGrid::TriangulateGrid(). Sensors %s and %s (almost) coincide. Randomize position.\n",GetName(i1), GetName(i2));
        UGaussian G(0.01,0.);
        UVector3 x = _sensors[i1]->Getx() + UVector3(G.GetRandDoub(), G.GetRandDoub(), G.GetRandDoub());
        _sensors[i1]->Setx(x);
    }
    if(NoCoin==false)
    {
        CI.AddToLog("ERROR: UGrid::TriangulateGrid(). Sensorpositions stay coincident.\n");
        return U_ERROR;
    }
    double* xyz     = new double[3*_npoints];
    if(!xyz)
    {
        CI.AddToLog("ERROR: UGrid::TriangulateGrid(). Memory allocation. _npoints = %d.\n",_npoints);
        return U_ERROR;
    }

    int*     tmpList = NULL;
    double*  coor    = xyz;
    UVector3 Center  = GetCenter();
    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL)
        {
            delete[] xyz;
            CI.AddToLog("ERROR: UGrid::TriangulateGrid(). Invalid NULL sensor at i = %d.\n",i);
            return U_ERROR;
        }
        *coor++ = _sensors[i]->Getx().Getx() - Center.Getx();
        *coor++ = _sensors[i]->Getx().Gety() - Center.Gety();
        *coor++ = _sensors[i]->Getx().Getz() - Center.Getz();
    }

    double MaxEdgeLen = MaxEdgeRel;
    for(int Nloop=0; Nloop<10; Nloop++)
    {
        if(TriangulateSphere(xyz, _npoints, &tmpList, &_ntri, MaxEdgeLen)!=0)
        {
            delete[] xyz;
            if(tmpList) free(tmpList);
            CI.AddToLog("ERROR: UGrid::TriangulateGrid(). TriangulateSphere() failed. \n");
            return U_ERROR;
        }
        delete[] _Tri;  _Tri = new int[3*_ntri];
        if(_Tri==NULL)
        {
            delete[] xyz;
            if(tmpList) free(tmpList);
            CI.AddToLog("ERROR: UGrid::TriangulateGrid(). Memory allocation. _ntri = %d .\n",_ntri);
            return U_ERROR;
        }
        for(int k=0; k<3*_ntri;  k++) _Tri[k] = tmpList[k];
        free(tmpList); tmpList = NULL;

        if(MaxEdgeLen<=0. || GetNIsolatedSensors()==0) break;
        MaxEdgeLen *= 1.2;
    }
    delete[] xyz;
    return U_OK;
}

ErrorType UGrid::AddSensor(USensor S)
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::AddSensor(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(_sensors==NULL || _npointsAlloc-_npoints<1) // Allocate new memory for points
    {
        int                                  NewAlloc = 2*_npointsAlloc+2;
        if(NewAlloc<100 || _sensors==NULL)   NewAlloc = 100;
        if(NewAlloc>10000)                   NewAlloc = _npointsAlloc+10000;
        USensor** _sensorsNew = new USensor*[NewAlloc];
        if(_sensorsNew==NULL)
        {
            CI.AddToLog("ERROR: UGrid::AddSensor(). Memory allocation. _npointsAlloc = %d, NewAlloc = %d  .\n", _npointsAlloc, NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<NewAlloc; n++) _sensorsNew[n] = NULL;
        if(_sensors)
            for(int n=0; n<_npoints; n++) _sensorsNew[n] = _sensors[n];
        delete[] _sensors;
        _sensors      = _sensorsNew;
        _npointsAlloc = NewAlloc;
    }

    _sensors[_npoints++]   = new USensor(S);
    if(_sensors[_npoints-1]==NULL)
    {
        CI.AddToLog("ERROR: UGrid::AddSensor(). Copying sensor, _points = %d .\n", _npoints);
        return U_ERROR;
    }

    if(Group) return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    else if(_npoints==1)
    {
        Group = new UGroup(_npoints, (UGroupElem* const*)_sensors);
        if(Group==NULL || Group->GetError()!=U_OK)
        {
            delete Group; Group=NULL;
            CI.AddToLog("ERROR: UGrid::AddSensor(). Updating Uroup(). \n");
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UGrid::ReAllocateMemory(void)
/*
    Reduce the amount of allocated memory,
    such that on return _npoints == _npointsAlloc
*/
{
    if(_npointsAlloc==_npoints) return U_OK;

    USensor** _sensorsNew = new USensor*[_npoints];
    if(_sensorsNew==NULL)
    {
        CI.AddToLog("WARNING: UGrid::ReAllocateMemory(). Re-allocating memory, _npointsAlloc = %d, _npoints = %d  .\n", _npointsAlloc, _npoints);
        return U_ERROR;
    }

    for(int n=0; n<_npoints; n++) _sensorsNew[n] = _sensors[n];
    delete[] _sensors;    _sensors  = _sensorsNew;
    _npointsAlloc = _npoints;

    return U_OK;
}

bool UGrid::IsStandardEEGLabel(const char* Label) // static member
{
    if(Label==NULL) return false;
    for(int i=0; i<NDEFELECT; i++)
        if(IsStringCompatible(DefArrayE[i].Name , Label, false)==true) return true;

    if(Label[0]==' ' || Label[0]=='_' || Label[0]=='-' || Label[0]=='^')
        for(int i=0; i<NDEFELECT; i++)
            if(IsStringCompatible(DefArrayE[i].Name , Label+1, false)==true) return true;

    return false;
}
bool UGrid::IsStandardEEGLabelRefLay(const char* Label)
{
    if(Label==NULL || Label[0]==0 || Label[1]==0) return false;
    if(Label[1]=='S' || Label[1]=='s')
    {
        if(Label[2]) return false;
        return '1'<=Label[0] && Label[0]<='9';
    }
    if(Label[2]=='S' || Label[2]=='s')
    {
        if(Label[3]     ) return false;
        if(Label[0]=='1') return '0'<=Label[1] && Label[1]<='9';
        if(Label[0]=='2') return '0'<=Label[1] && Label[1]<='9';
    }
    return false;
}
bool UGrid::IsStandardREFLabelRefLay(const char* Label)
{
    if(Label==NULL || Label[0]==0 || Label[1]==0) return false;
    if(Label[1]=='R' || Label[1]=='r')
    {
        if(Label[2]) return false;
        return '1'<=Label[0] && Label[0]<='9';
    }
    if(Label[2]=='R' || Label[2]=='r')
    {
        if(Label[3]     ) return false;
        if(Label[0]=='1') return '0'<=Label[1] && Label[1]<='9';
        if(Label[0]=='2') return '0'<=Label[1] && Label[1]<='9';
    }
    return false;
}

bool UGrid::IsStandardMEGLabel(const char* Label) // static member
{
    if(Label==NULL) return false;
    for(int i=0; i<NDEFMAGN; i++)
        if(IsStringCompatible(DefArrayM[i].Name , Label, false)==true) return true;

    if(Label[0]=='_' || Label[0]=='-')
        for(int i=0; i<NDEFMAGN; i++)
            if(IsStringCompatible(DefArrayM[i].Name , Label+1, false)==true) return true;

    return false;
}

int UGrid::GetNIsolatedSensors(void) const
{
    if(_Tri==NULL || _sensors==NULL) return 0;

    int Niso = 0;
    for(int i=0;i<_npoints; i++)
    {
        bool Isolated = true;
        for(int k=0; k<3*_ntri; k++)
            if(_Tri[k]==i)
            {
                Isolated=false;
                break;
            }
        if(Isolated==true) Niso++;
    }
    return Niso;
}

ErrorType UGrid::PutSamePositionsInSameGroup(void)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::PutSamePositionsInSameGroup(). Object NULL, or not properly set. \n");
        return U_ERROR;
    }
    int* GroupNo = new int[_npoints];
    if(GroupNo==NULL)
    {
        CI.AddToLog("ERROR: UGrid::PutSamePositionsInSameGroup(). Memory allocation. \n");
        return U_ERROR;
    }

    for(int i=0; i<_npoints; i++) GroupNo[i] = i;
    for(int i=0; i<_npoints; i++)
    {
        for(int ii=i+1; ii<_npoints; ii++)
        {
            if(GroupNo[ii]==GroupNo[i]) continue;
            if(this->GetDistance(i, ii)==0.) GroupNo[ii] = GroupNo[i];
        }
    }
    if(this->SetSensorGroups(GroupNo)!=U_OK)
    {
        delete[] GroupNo;
        CI.AddToLog("ERROR: UGrid::PutSamePositionsInSameGroup(). Setting updated sensor groups. \n");
        return U_ERROR;
    }
    delete[] GroupNo;
    return U_OK;
}

ErrorType UGrid::PutSensorTypesInDifferentGroups(void)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::PutSensorTypesInDifferentGroups(). Object NULL, or not properly set. \n");
        return U_ERROR;
    }
    int* GroupNo = new int[_npoints];
    if(GroupNo==NULL)
    {
        CI.AddToLog("ERROR: UGrid::PutSensorTypesInDifferentGroups(). Memory allocation. \n");
        return U_ERROR;
    }
    int smallnum = _sensors[0]->GetGroupID();
    int bignum   = _sensors[0]->GetGroupID();
    for(int i=0; i<_npoints; i++)
    {
        smallnum = MIN(smallnum, _sensors[i]->GetGroupID());
        bignum   = MAX(bignum  , _sensors[i]->GetGroupID());
    }
    int range = bignum - smallnum + 1;

    for(int i=0; i<_npoints; i++)
        GroupNo[i] = _sensors[i]->GetGroupID() + range * (int) _sensors[i]->GetStype();

    if(this->SetSensorGroups(GroupNo)!=U_OK)
    {
        delete[] GroupNo;
        CI.AddToLog("ERROR: UGrid::PutSensorTypesInDifferentGroups(). Setting updated sensor groups. \n");
        return U_ERROR;
    }
    delete[] GroupNo;
    return U_OK;
}

ErrorType UGrid::SetSensorGroups(const int* GroupNo)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensorGroups(). Object NULL, or not properly set. \n");
        return U_ERROR;
    }
    for(int i=0; i<_npoints; i++)
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("ERROR: UGrid::SetSensorGroups(). _sensors[%d]==NULL. \n", i);
            return U_ERROR;
        }

    if(GroupNo==NULL)
    {
        for(int i=0; i<_npoints; i++) _sensors[i]->SetGroupID(-1);
    }
    else
    {
        for(int i=0; i<_npoints; i++) _sensors[i]->SetGroupID(GroupNo[i]);
    }
    if(Group) return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    return U_OK;
}
ErrorType UGrid::SetSensorGroup(const char* GroupName)
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetSensorGroup(). Object NULL, or not properly set. \n");
        return U_ERROR;
    }
    for(int i=0; i<_npoints; i++)
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("ERROR: UGrid::SetSensorGroup(). _sensors[%d]==NULL. \n", i);
            return U_ERROR;
        }


    if(GroupName==NULL)
    {
        for(int i=0; i<_npoints; i++) _sensors[i]->SetGroupID(-1);
    }
    else if(Group)
    {
        int NewGroupNo = Group->GetUnusedGroupID();
        for(int i=0; i<_npoints; i++)
        {
            if(IsStringCompatible(_sensors[i]->GetName(), GroupName, false)==true)
                _sensors[i]->SetGroupID(NewGroupNo);
        }
        return Group->UpdateGroups(_npoints, (UGroupElem* const*)_sensors);
    }
    CI.AddToLog("ERROR: SetSensorGroup(). Group object not set.\n");
    return U_ERROR;
}
ErrorType UGrid::SetCTFSensorGroups()
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::SetCTFSensorGroups(). Object NULL, or not properly set. \n");
        return U_ERROR;
    }
    if(SetSensorGroup("MZ*" )!=U_OK   ||
       SetSensorGroup("MLO*")!=U_OK   ||
       SetSensorGroup("MRO*")!=U_OK   ||
       SetSensorGroup("MLP*")!=U_OK   ||
       SetSensorGroup("MRP*")!=U_OK   ||
       SetSensorGroup("MLT*")!=U_OK   ||
       SetSensorGroup("MRT*")!=U_OK   ||
       SetSensorGroup("MLC*")!=U_OK   ||
       SetSensorGroup("MRC*")!=U_OK   ||
       SetSensorGroup("MLF*")!=U_OK   ||
       SetSensorGroup("MRF*")!=U_OK)
    {
        CI.AddToLog("ERROR: UGrid::SetCTFSensorGroups(). Setting one the senor groups. \n");
        return U_ERROR;
    }
    return PutSensorTypesInDifferentGroups();
}
bool UGrid::IsCTFGrid(void) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::IsCTFGrid(). Object NULL, or not properly set. \n");
        return false;
    }

    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]->GetStype()==USensor::U_SEN_MAG ) return false;
        if(_sensors[i]->GetStype()!=USensor::U_SEN_GRAD) continue;
        const char* Name = _sensors[i]->GetName();
        if(IsStringCompatible(Name, "MZ*" , false)==false &&
           IsStringCompatible(Name, "MLO*", false)==false &&
           IsStringCompatible(Name, "MRO*", false)==false &&
           IsStringCompatible(Name, "MLP*", false)==false &&
           IsStringCompatible(Name, "MRP*", false)==false &&
           IsStringCompatible(Name, "MLT*", false)==false &&
           IsStringCompatible(Name, "MRT*", false)==false &&
           IsStringCompatible(Name, "MLC*", false)==false &&
           IsStringCompatible(Name, "MRC*", false)==false &&
           IsStringCompatible(Name, "MLF*", false)==false &&
           IsStringCompatible(Name, "MRF*", false)==false)
        {
            return false;
        }
    }
    return true;
}

ErrorType UGrid::WriteTxt(UFileName F, bool Header) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::WriteTxt(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(F, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UGrid::WriteTxt(). Cannot create/open file (%s) \n", (const char*)F);
        return U_ERROR;
    }
    if(Header) fprintf(fp, "%s", CI.GetProperties("// "));

    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("WARNING: UGrid::WriteTxt(). Skipping NULL _sensor[%d]. \n",i);
            continue;
        }
        USensor S = *(_sensors[i]);
        fprintf(fp, "%s \t%f \t%f \t%f \n", S.GetName(), S.Getx().Getx(), S.Getx().Gety(), S.Getx().Getz());
    }
    fclose(fp);

    return U_OK;
}
ErrorType UGrid::WriteXYZ(UFileName FileOut, const bool* Selection) const
{
    if(this==NULL) return U_ERROR;
    if(_error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::WriteXYZ(). Object not properly set. \n");
        return U_ERROR;
    }

    FILE* fp = fopen(FileOut, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UGrid::WriteXYZ(). File Cannot be created: %s .\n",(const char*) FileOut);
        return U_ERROR;
    }

    fprintf(fp,"XYZFile1.0\n");
    fprintf(fp, "%s",CI.GetProperties("//  "));
    fprintf(fp, "//  \n");
    fprintf(fp, "//  \n");
    for(int i=0; i<_npoints; i++)
    {
        if(Selection && Selection[i]==false) continue;
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("WARNING: UGrid::WriteXYZ(). Skipping NULL _sensor[%d]. \n",i);
            continue;
        }
        USensor S = *(_sensors[i]);
        fprintf(fp, "%s \t%f \t%f \t%f \n", S.GetName(), S.Getx().Getx(), S.Getx().Gety(), S.Getx().Getz());
    }

    fclose(fp);
    return U_OK;
}

int UGrid::GetSensorIndex(const char* Name) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorIndex(). NULL or erroneous object. \n");
        return -1;
    }
    if(Name==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetSensorIndex(). Invalid NULL pointer argument. \n");
        return -1;
    }
    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL) continue;
        if(IsStringCompatible(Name, _sensors[i]->GetName(), false)==true) return i;
    }
    for(int i=0; i<_npoints; i++)
    {
        if(_sensors[i]==NULL) continue;
        if(IsStringCompatible(Name, _sensors[i]->GetName()+1, false)==true) return i;
    }
    if(Name[0] && Name[1])
    {
        for(int i=0; i<_npoints; i++)
        {
            if(_sensors[i]==NULL) continue;
            if(IsStringCompatible(Name+1, _sensors[i]->GetName(), false)==true) return i;
        }
        for(int i=0; i<_npoints; i++)
        {
            if(_sensors[i]==NULL) continue;
            if(IsStringCompatible(Name+1, _sensors[i]->GetName()+1, false)==true) return i;
        }
    }
    return -1;
}

int UGrid::GetLeftHomologueIndex(int IndexRight) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetLeftHomologueIndex(). NULL or erroneous object. \n");
        return -1;
    }
    for(int i=0; i<_npoints; i++)
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("ERROR: UGrid::GetLeftHomologueIndex(). _sensors[%d]==NULL .\n", i);
            return -1;
        }

    if(IndexRight<0 || IndexRight>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetLeftHomologueIndex(). Index out of range (IndexRight = %d). .\n", IndexRight);
        return -1;
    }

    UString Name(_sensors[IndexRight]->GetName());
    if(UGrid::IsStandardEEGLabel((const char*) Name)==true)
    {
        ErrorType E   = U_OK;
        int       Num = Name.GetEndingInt(&E);
        if(Num<0||E!=U_OK) return -1;

        if(Num%2) Name.IncreaseEndingNumber();
        else      return IndexRight;
        return GetSensorIndex((const char*)Name);
    }
    else if(UGrid::IsStandardMEGLabel((const char*) Name)==true)
    {
        if(Name[1]=='R')      Name.SetChar(1,'L');
        else if(Name[1]=='L') return IndexRight;
        else return -1;
        return GetSensorIndex((const char*)Name);
    }
    CI.AddToLog("ERROR: UGrid::GetLeftHomologueIndex().  Sensor has not standard name: %s   .\n", (const char*)Name);
    return -1;
}

int UGrid::GetRightHomologueIndex(int IndexLeft) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetRightHomologueIndex(). NULL or erroneous object. \n");
        return -1;
    }
    for(int i=0; i<_npoints; i++)
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("ERROR: UGrid::GetRightHomologueIndex(). _sensors[%d]==NULL .\n", i);
            return -1;
        }

    if(IndexLeft<0 || IndexLeft>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetRightHomologueIndex(). Index out of range (IndexLeft = %d). .\n", IndexLeft);
        return -1;
    }

    UString Name(_sensors[IndexLeft]->GetName());
    if(UGrid::IsStandardEEGLabel((const char*) Name)==true)
    {
        ErrorType E   = U_OK;
        int       Num = Name.GetEndingInt(&E);
        if(Num<0||E!=U_OK) return -1;

        if(Num%2) return IndexLeft;
        else      Name.DecreaseEndingNumber();
        return GetSensorIndex((const char*)Name);
    }
    else if(UGrid::IsStandardMEGLabel((const char*) Name)==true)
    {
        if(Name[1]=='R')      return IndexLeft;
        else if(Name[1]=='L') Name.SetChar(1,'R');
        else return -1;
        return GetSensorIndex((const char*)Name);
    }
    CI.AddToLog("ERROR: UGrid::GetRightHomologueIndex().  Sensor has not standard name: %s   .\n", (const char*)Name);
    return -1;
}

int UGrid::GetHomologueSensorIndex(int Index) const
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        CI.AddToLog("ERROR: UGrid::GetHomologueSensorIndex(). NULL or erroneous object. \n");
        return -1;
    }
    for(int i=0; i<_npoints; i++)
        if(_sensors[i]==NULL)
        {
            CI.AddToLog("ERROR: UGrid::GetHomologueSensorIndex(). _sensors[%d]==NULL .\n", i);
            return -1;
        }
    if(Index<0 || Index>=_npoints)
    {
        CI.AddToLog("ERROR: UGrid::GetHomologueSensorIndex(). Index out of range (Index = %d). .\n", Index);
        return -1;
    }

    UString Name(_sensors[Index]->GetName());
    if(UGrid::IsStandardEEGLabel((const char*) Name)==true)
    {
        ErrorType E   = U_OK;
        int       Num = Name.GetEndingInt(&E);
        if(Num<0||E!=U_OK) return -1;

        if(Num%2) Name.IncreaseEndingNumber();
        else      Name.DecreaseEndingNumber();
        return GetSensorIndex((const char*)Name);
    }
    else if(UGrid::IsStandardMEGLabel((const char*) Name)==true)
    {
        if(Name[1]=='R') Name.SetChar(1,'L');
        else if(Name[1]=='L') Name.SetChar(1,'R');
        else return -1;
        return GetSensorIndex((const char*)Name);
    }
    CI.AddToLog("ERROR: UGrid::GetHomologueSensorIndex().  Sensor has not standard name: %s   .\n", (const char*)Name);
    return -1;
}

