#ifndef _GRID_INCLUDED
#define _GRID_INCLUDED


#include "Sensor.h"
#include "Euler.h"
#include "LinTran.h"
#include "String.h"
#include "FileName.h"

#define DEF_GRIDMAXEDGEREL 1.1
class UGroup;
class DLL_IO UGrid
{
public:
    enum GridType   {U_GRD_NOTYPE,  // Type not set, not defined
                     U_GRD_MEG,     // Default MEG sensors
                     U_GRD_EEG};    // Default EEG sensors
    
    UGrid();
    UGrid(FILE* fpIn);
    UGrid(GridType GT);
    UGrid(UFileName TextFile_XYZ_ELC);
    UGrid(UFileName TextFile_XYZ, int nEEG, char *NewLabel);
    UGrid(const char* TextFile_XYZ_ELC);
    UGrid(const char*TextFile_XYZ, int nEEG, char *NewLabel);

    UGrid(const UVector3* Points, int npoints, USensor::SensorType ST=USensor::U_SEN_POINT);
    UGrid(int npoints, const USensor** sensors=NULL);
    UGrid(const USensor* sensor);
    UGrid(int nx, double deltax, int ny, double deltay);
    UGrid(double radius, int nx, double deltax, int ny, double deltay);
    UGrid(const char** EEGlab, int nEEG, bool SkipTriangulation=false);
    UGrid(const UGrid &g);
    virtual ~UGrid();

    UGrid&              operator=(const UGrid &g);
    bool                operator==(const UGrid &g) const; 
    bool                operator!=(const UGrid &g) const; 
    ErrorType           GetError(void) const       {return _error;}

    static USensor      GetDefaultSensor(const char* Name);
    static bool         IsStandardEEGLabel(const char* Label);
    static bool         IsStandardEEGLabelRefLay(const char* Label);
    static bool         IsStandardREFLabelRefLay(const char* Label);
    static bool         IsStandardMEGLabel(const char* Label);

/* Groups */
    const UString&      GetGroupProperties(UString Comment);
    const UGroup*       GetGroup(void) const {return Group;}
    ErrorType           UpdateGroups(void);
    UString             GetGroupName(int igroup) const;
    ErrorType           PutSamePositionsInSameGroup(void);
    ErrorType           PutSensorTypesInDifferentGroups(void);  
    ErrorType           SetSensorGroups(const int* GroupNo);
    ErrorType           SetSensorGroup(const char* GroupName);
    ErrorType           SetCTFSensorGroups(void);

/* Sub-sets */
    bool                AreSensorLabelsEqual(const UGrid &g) const; 
    GridType            GetGridType(void) const;
    bool                IsCTFGrid(void) const;

    ErrorType           SubSample(int Nnew);
    bool                IsSubGrid(const UGrid* SubGrid) const;
    UGrid*              GetSubGrid(USensor::SensorType ST) const;
    UGrid*              GetSubGrid(const int* Indices, int NSens) const;
    UGrid*              GetSubGridFirst(int NFirst) const;
    int*                GetSubGridIndices(const UGrid* SubGrid) const;
    int*                GetSensorTypeIndices(USensor::SensorType ST, int* NSens) const;
    int                 GetNSensors(USensor::SensorType ST) const;

/* Sensor properties */
    int                 GetNpoints(void) const     {return _npoints;}
    const USensor*      GetSensorPointer(int is) const;
    USensor             GetSensor(int is) const;
    UVector3            GetPosition(int is) const;
    UVector3            GetPositionCompCoil(int is) const;
    UVector3            GetOrientation(int is) const;
    const USensor*      GetSensorClosestToAxis(int dir, bool PosAx, int*isens=NULL) const;
    double              Getx(int is) const;
    double              Gety(int is) const;
    double              Getz(int is) const;
    const char*         GetName(int is) const;
    int                 GetIndexFromName(const char* Name, bool CaseSens) const;
    USensor::SensorType GetSensorType(int is) const;
    int                 GetGroupID(int is) const;
    double              GetDistance(int is1, int is2) const;
    double              GetMinDistance(int* is1, int* is2) const;

    ErrorType           SetSensor(const USensor* sens, int is);
    ErrorType           SetPosition(UVector3 x, int is);
    ErrorType           SetOrientation(UVector3 n, int is);
    ErrorType           SetName(const char* Name, int is);
    ErrorType           SetSensorType(USensor::SensorType ST, int is);
    ErrorType           SetGroupID(int GroupID, int is);
    int                 ConvertGradioToMagneto(void);

    ErrorType           ReorderSensors(const int* NewIndex, int Nindex);
    int*                GetSensorNameOrder(bool HighFirst) const;
    int*                GetGroupNameOrder(bool HighFirst) const;

/* Manipulate sensor positions */    
    ErrorType           ProjectSphere(UVector3 Center, double Radius, bool AlignOrientation=true);
    UVector3            GetCenter(void) const;
    int                 GetSensorIndex(const char* Name) const;
    int                 GetHomologueSensorIndex(int Index) const;
    int                 GetLeftHomologueIndex(int IndexRight) const;
    int                 GetRightHomologueIndex(int IndexLeft) const;
    ErrorType           Transform(const UEuler& euler);
    ErrorType           Transform(const ULinTran& lintran);
    ErrorType           Transform(const UEuler& euler, USensor::SensorType ST);
    ErrorType           Transform(const ULinTran& lintran, USensor::SensorType ST);
    ErrorType           ShiftSensors(UVector3 Shift);

    ErrorType           CopyIDsFromNames(const UGrid* G);
    ErrorType           MakeLabelsUnique(void);
    int                 GetChannum(const char* Label) const;
    ErrorType           SelectSensors(const bool* Select);
    ErrorType           SelectSensors(const char* Labels);
    ErrorType           SelectSensors(const UString* Labels, int NLab);

    ErrorType           RemoveSensor(int is);
    ErrorType           RemoveSensors(int first, int last);
    int                 RemoveDoubleSensors(double Tolerance =-1.);
    int                 RemoveZeroSensors(void);
    ErrorType           AddGrid(const UGrid* g);
    ErrorType           AddSensor(USensor S);
    int                 GetNDoubleSensors(void) const;

/* Triangulation */
    int                 GetNTriangle(void) const  {return _ntri;}
    int*                GetNeighbouringSensorIndices(int isens, int* NNeigh) const;
    ErrorType           GetTriangleIndices(int it, int* is0, int* is1, int* is2) const;
    ErrorType           TriangulateGrid(double MaxEdgeRel=DEF_GRIDMAXEDGEREL);

/* Writing */
    ErrorType           WriteXYZ(UFileName FileOut, const bool* Selection) const;
    ErrorType           WriteTxt(UFileName F, bool Header) const;
    ErrorType           WriteBinary(FILE* fpOut) const;

protected:
    ErrorType           _error;
    int                 _npoints;  
    int                 _npointsAlloc;
    USensor**           _sensors;
    ErrorType           ReAllocateMemory(void);
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static const char*  HEADERBEGIN;
    static const char*  HEADEREND;
    int                 _ntri;
    int*                _Tri;
    UGroup*             Group;
    int                 GetNIsolatedSensors(void) const;
};

bool AreLabelsCompatible(const UGrid* G1, const UGrid* G2, bool AddToLog);
UGrid* GetCommonSensors(const UGrid* G1, const UGrid* G2);

#endif // _GRID_INCLUDED
