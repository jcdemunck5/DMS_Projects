/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for fitting objects to a grid.                                     */
/*     UGridFit can be used e.g. to fit one grid onto another (yielding the      */
/*     optimal UEuler-object), to fit a sphere onto a grid.                      */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    05-09-97   creation
  Jdm    27-01-98   added the fit tof another grid and changed name from GridSphere to GridFit
  Jdm    19-02-98   removed some bugs.
  Jdm    20-03-98   Added the Tip calibration function.Some other minor changes.
  Jdm    30-03-98   New interface: use class USensor() instead of struct SENSOR
  Jdm    26-05-98   small BUG in FitEuler(): Compute EulerXfm in accordance to documentation
  Jdm    29-05-98   small BUG in FitEuler(): Do NOT skip NULL labels.
  Jdm    10-05-98   BUG in FitSphere(): mixed up some of the parameters in cost function
  JdM    08-10-98   separated include-files
  JdM    12-11-98	reduce some compiler warnings for UNIX CPP compiler
  JdM    16-11-98   added operator=(), Small adaptation in FitSphere(), rpick and rcomp may be NULL
  JdM    28-12-98	Added more detailed comments
  JdM    14-02-99   Major revision: each fit function now has its private dedicated object.
                    The interfaces of the functions CallibrateTip are slightly changed.
                    The working of FitSphere is slightly adapted
  JdM    24-02-99   Added another variant of FitEuler()
  JdM    16-04-99   MAJOR BUG-FIX in UGridFit::UFitSphere::ComputeCost() (The gradiometer positition 
                    was always taken into account, i.s.o. selective, dependent on the value of FitOuterSphere)
  JdM    18-06-99   Added new constructor, remove (obsolete) ErrorTreshold argument,
                    return fiterror in FitSphere(), instead of ErrorType.
  JdM    27-03-00   operator==() : Test whether this==&d
  JdM    26-06-00   Use AreLabelsEqual() to compare sensors, i.s.o. operator==()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    27-11-01   Added new constructors using default MEG/EEG sensors
  JdM    26-08-02   Add parameter to FitEuler
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
                    Made Fit-functions const
  JdM    03-11-10   Renamed FitEuler() into FitGridEuler()
                    Added FitGridLinTran()
*/

#include <string.h>
#include "GridFit.h"

/* Inititalize static const parameters. */
const double UGridFit::DIS2ANG = .2;

UGridFit::UGridFit() :  UGrid()
/* The default constructor.
 */
{
}

UGridFit::UGridFit(GridType GT) : UGrid(GT)
{
}

UGridFit::UGridFit(const char** EEGlab, int nEEG) : UGrid(EEGlab, nEEG)
{
}


UGridFit::UGridFit(int npoints, const USensor** sensors) : 
    UGrid(npoints, sensors)
{
}

UGridFit::UGridFit(const UGrid &g) : 
    UGrid(g)
{
}

UGridFit::UGridFit(UVector3* Points, int npoints, USensor::SensorType ST) :
    UGrid(Points, npoints, ST)
{
}


UGridFit& UGridFit::operator=(const UGridFit &g)
/*
    The asignment operator
 */
{
    if(this==&g) return *this;

    UGrid::operator=(g);
    return *this;
}

UGridFit::~UGridFit() 
{
}

/////////////////// FitSphere() ////////////////////////////////////////

double UGridFit::FitSphere(UVector3& Spos, double *r1, double *r2) const
{
    double x,y,z;  
    double E = FitSphere(&x,&y,&z,r1,r2); 
    Spos     = UVector3(x,y,z); 
    return E;
}

double UGridFit::FitSphere(double *x, double *y, double *z, double *rpick, double *rcomp) const
/*
    Fit a sphere with into the grid. Determine the optimal sphere position (*x, *y, *z) and
    radius *rpick. During the fitting procedure, also take into account the best fitting 
    radius of the (concentric) sphere fitting the compensation coils.

    if(rpick) export the optimal radius of the inner sphere,
    if(rcomp) 
        determine and export the optimal radius of the outer sphere
    else
        do not determine and do not export the the outer sphere radius

    Return the fit error of the optimal fitted sphere in cm.
    On error, return -1.
 */
{
    if(this==NULL || _error!=U_OK || _sensors==NULL)
    {
        return -1;
    }
/* Compute starting values*/
    double par[5];
    par[0] = 0.;
    par[1] = 0.;
    par[2] = 0.;
    par[3] = 0.;
    par[4] = 0.;
    int i = 0;
    for(     ;i<_npoints;i++)
    {
        par[0] += Getx(i);
        par[1] += Gety(i);
        par[2] += Getz(i);
    }
    par[0] /= _npoints;
    par[1] /= _npoints;
    par[2] /= _npoints;
    i = 0;
    for( ;i<_npoints;i++) 
    {
        double x = Getx(i) - par[0];
        double y = Gety(i) - par[1];
        double z = Getz(i) - par[2];
        par[3]  += sqrt(x*x+y*y+z*z);
    }
    par[3] /= _npoints;
    par[4] = par[3]+4.;

/* Set object function and iterate*/
    bool FitOuterSphere;
    if(rcomp==NULL) FitOuterSphere = false;
    else            FitOuterSphere = true;
    
    UFitSphere FS(this, FitOuterSphere);
    if( (FitOuterSphere==true  && FS.Iterate(par, 5, 6.) != U_OK)  ||
        (FitOuterSphere==false && FS.Iterate(par, 4, 6.) != U_OK)  )  return U_ERROR;

/* Copy result to output */
    *x     = par[0];
    *y     = par[1];
    *z     = par[2];
    if(rpick) *rpick = par[3];
    if(rcomp) *rcomp = par[4];

    return FS.ComputeCost(par,-1)/_npoints;
}

double UGridFit::UFitSphere::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    double  cost = 0.;
    for(int i=0;i<Grid->GetNpoints();i++)
    {
        USensor  S  = Grid->GetSensor(i);
        UVector3 x  = S.Getx() - UVector3(par[0],par[1],par[2]);
        cost       += fabs(x.GetNorm()-par[3]);

        if(FitOuterSphere==true && S.GetStype()==USensor::U_SEN_GRAD)
        {
            UVector3 x  = S.Getc() - UVector3(par[0],par[1],par[2]);
            cost       += fabs(x.GetNorm()-par[4]);
        }
    }
    return cost;
}

/////////////////// FitGridEuler() ////////////////////////////////////////

UEuler UGridFit::FitGridEuler(const UGrid *GridRef, double *residual, double *start) const
/*
   The Euler transform is returned that determines best fitting transformation of 
   the current grid onto gr. Here corresponding labels are matched.

   The array start[] contains the starting parameters: three translations [cm] 
   and three rotations [radians]
 */
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridEuler(). Object NULL or erroneous.\n");
        return UEuler();
    }
    if(GridRef==NULL || GridRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridEuler(). UGrid argument NULL or erroneous.\n");
        return UEuler();
    }
    double par[6]={0.,0.,0.,0.,0.,0.};
    if(start)
    {
        par[0] = start[0];
        par[1] = start[1];
        par[2] = start[2];
        par[3] = start[3]/DIS2ANG;
        par[4] = start[4]/DIS2ANG;
        par[5] = start[5]/DIS2ANG;
    }
    UFitEuler FE(this, GridRef);
    if(FE.GetError()!=U_OK  || FE.Iterate(par,6,6.) != U_OK)
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

/* No errors detected*/    
    if(residual && FE.GetNtake()>0) 
        *residual = FE.ComputeCost(par,0) / FE.GetNtake();

    return UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);
}

UEuler UGridFit::FitGridEuler(const UGrid *GridRef, const int* IndexXFmtoRef, double *residual, double *start) const
/*
   The Euler transform is returned that determines best fitting transformation of 
   the current grid onto gr. Here corresponding labels are matched.

   The array start[] contains the starting parameters: three translations [cm] 
   and three rotations [radians]
 */
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridEuler(). Object NULL or erroneous.\n");
        return UEuler();
    }
    if(GridRef==NULL || GridRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridEuler(). UGrid argument NULL or erroneous.\n");
        return UEuler();
    }
    double par[6]={0.,0.,0.,0.,0.,0.};
    if(start)
    {
        par[0] = start[0];
        par[1] = start[1];
        par[2] = start[2];
        par[3] = start[3]/DIS2ANG;
        par[4] = start[4]/DIS2ANG;
        par[5] = start[5]/DIS2ANG;
    }
    UFitEuler FE(this, GridRef, IndexXFmtoRef);
    if(FE.GetError()!=U_OK  || FE.Iterate(par,6,6.) != U_OK)
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

/* No errors detected*/    
    if(residual && FE.GetNtake()>0) 
        *residual = FE.ComputeCost(par,0) / FE.GetNtake();

    return UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);
}

UGridFit::UFitEuler::UFitEuler(const UGrid* Gxfm, const UGrid* Gref, const int* IndexXFmtoRef) : 
    Uminimize(UCostminimize()) 
/*
     Compare the labels of Grid1 and Grid2. If they are equal, then take[i] refers to the
     sensor of Grid2 that corresponds to the i-th sensor in Grid1.
 */
{
    error = U_ERROR;
    Grid1 = Gxfm;
    Grid2 = Gref; 
    if(!Grid1 || !Grid2) return;
    
    int NP1 = Grid1->GetNpoints();
    int NP2 = Grid2->GetNpoints();
    take    = new int[NP1];
    if(take==NULL)  
    {
        CI.AddToLog("ERROR: UGridFit::UFitEuler::UFitEuler(). Memory allocation: NP1 = %d \n", NP1);
        return;
    }
    for(int i=0; i<NP1; i++) take[i] = -1; // skip by default
    
    Ntake = 0;
    for(int i=0; i<NP1; i++) 
    {
        if(IndexXFmtoRef)
        {
            take[i] = IndexXFmtoRef[i];
            if(take[i]>=0) Ntake++;
        }        
        else
        {
            if(Grid1->GetName(i)==NULL) continue;

            for(int j=0; j<NP2; j++)
            {
                if(Grid2->GetName(j)==NULL) continue;

                if(!strcmp(Grid1->GetName(i), Grid2->GetName(j)))
                {
                    take[i] = j;
                    Ntake++;
                    break;
                }
            }            
        }
    }
    if(Ntake<4) 
    {
        CI.AddToLog("ERROR: UGridFit::UFitEuler::UFitEuler(). Too few corresponding labels (ntake=%d)\n", Ntake);
        return;
    }
    error = U_OK;
}

double UGridFit::UFitEuler::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    double   cost = 0.;
    UEuler eupar(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);

    for(int i=0;i<Grid1->GetNpoints();i++)
    {
        if(take[i]<0) continue;
        cost += ( Grid2->GetPosition(take[i]) - eupar.xfm( Grid1->GetPosition(i)) ).GetNorm();
    }
    return cost;
}

/////////////////// FitGridLinTran() ////////////////////////////////////////

ULinTran UGridFit::FitGridLinTran(const UGrid *GridRef, double *residual, double *start) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridLinTran(). Object NULL or erroneous.\n");
        return UEuler();
    }
    if(GridRef==NULL || GridRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridLinTran(). UGrid argument NULL or erroneous.\n");
        return UEuler();
    }
    double par[9]={0.,0.,0.,0.,0.,0.,0.,0.,0.};
    if(start)
    {
        par[0] = start[0];
        par[1] = start[1];
        par[2] = start[2];
        par[3] = start[3]/DIS2ANG;
        par[4] = start[4]/DIS2ANG;
        par[5] = start[5]/DIS2ANG;
        par[6] = 100.*log(0.000001+fabs(start[6]));
        par[7] = 100.*log(0.000001+fabs(start[7]));
        par[8] = 100.*log(0.000001+fabs(start[8]));
    }
    UFitLinTran FLT(this, GridRef);
    if(FLT.GetError()!=U_OK  || FLT.Iterate(par,9,6.) != U_OK)
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

/* No errors detected*/    
    if(residual && FLT.GetNtake()>0) 
        *residual = FLT.ComputeCost(par,0) / FLT.GetNtake();

    return FLT.GetLinTran(par);
}

ULinTran UGridFit::FitGridLinTran(const UGrid *GridRef, const int* IndexXFmtoRef, double *residual, double *start) const
{
    if(this==NULL || _error!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridLinTran(). Object NULL or erroneous.\n");
        return UEuler();
    }
    if(GridRef==NULL || GridRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGridFit::FitGridLinTran(). UGrid argument NULL or erroneous.\n");
        return UEuler();
    }
    double par[9]={0.,0.,0.,0.,0.,0.,0.,0.,0.};
    if(start)
    {
        par[0] = start[0];
        par[1] = start[1];
        par[2] = start[2];
        par[3] = start[3]/DIS2ANG;
        par[4] = start[4]/DIS2ANG;
        par[5] = start[5]/DIS2ANG;
        par[6] = 100.*log(0.000001+fabs(start[6]));
        par[7] = 100.*log(0.000001+fabs(start[7]));
        par[8] = 100.*log(0.000001+fabs(start[8]));
    }
    UFitLinTran FLT(this, GridRef, IndexXFmtoRef);
    if(FLT.GetError()!=U_OK  || FLT.Iterate(par,9,6.) != U_OK)
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

/* No errors detected*/    
    if(residual && FLT.GetNtake()>0) 
        *residual = FLT.ComputeCost(par,0) / FLT.GetNtake();

    return FLT.GetLinTran(par);
}

ULinTran UGridFit::UFitLinTran::GetLinTran(const double*par) const
{
    double Sx = exp(par[6]/100.);
    double Sy = exp(par[7]/100.);
    double Sz = exp(par[8]/100.);
    return ULinTran(UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]), Sx, Sy, Sz);
}
UGridFit::UFitLinTran::UFitLinTran(const UGrid* Gxfm, const UGrid* Gref, const int* IndexXFmtoRef) : 
    Uminimize(UCostminimize()) 
/*
     Compare the labels of Grid1 and Grid2. If they are equal, then take[i] refers to the
     sensor of Grid2 that corresponds to the i-th sensor in Grid1.
 */
{
    error = U_ERROR;
    Grid1 = Gxfm;
    Grid2 = Gref; 
    if(!Grid1 || !Grid2) return;
    
    int NP1 = Grid1->GetNpoints();
    int NP2 = Grid2->GetNpoints();
    take    = new int[NP1];
    if(take==NULL)  
    {
        CI.AddToLog("ERROR: UGridFit::UFitEuler::UFitLinTran(). Memory allocation: NP1 = %d \n", NP1);
        return;
    }
    for(int i=0; i<NP1; i++) take[i] = -1; // skip by default
    
    Ntake = 0;
    for(int i=0; i<NP1; i++) 
    {
        if(IndexXFmtoRef)
        {
            take[i] = IndexXFmtoRef[i];
            if(take[i]>=0  ) Ntake++;
            if(take[i]>=NP2)
            {
                CI.AddToLog("ERROR: UGridFit::UFitEuler::UFitLinTran(). Index out of range  = take[%d]=%d .\n", i, take[i]);
                return;
            }
        }        
        else
        {
            if(Grid1->GetName(i)==NULL) continue;

            for(int j=0; j<NP2; j++)
            {
                if(Grid2->GetName(j)==NULL) continue;

                if(!strcmp(Grid1->GetName(i), Grid2->GetName(j)))
                {
                    take[i] = j;
                    Ntake++;
                    break;
                }
            }            
        }
    }
    if(Ntake<4) 
    {
        CI.AddToLog("ERROR: UGridFit::UFitEuler::UFitLinTran(). Too few corresponding labels (ntake=%d)\n", Ntake);
        return;
    }
    error = U_OK;
}


double UGridFit::UFitLinTran::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    double   cost  = 0.;
    ULinTran ltpar = GetLinTran(par);

    for(int i=0;i<Grid1->GetNpoints();i++)
    {
        if(take[i]<0) continue;
        cost += ( Grid2->GetPosition(take[i]) - ltpar.xfm( Grid1->GetPosition(i)) ).GetNorm();
    }
    return cost;
}
/////////////////// FitEuler() (Array) ////////////////////////////////////////

UEuler UGridFit::FitGridEuler(UEuler* EulerArray, int Neuler, double* residual, const UGrid* GrDef) const
/*
    The aim of this object is to compute the optimal "average" Euler transform. For this
    purpose the given grid (of MEG sensors) is transformed over the given array of 
    Euler transforms. This yields a cloud of points in the neighbourhood of each sensor, 
    The optimum Euler is the one that minimizes the sum of distances between the opimally
    transformed grid and the clouds of points. 

    if(GrDef) no optimizations are done, but the UEuler is computed (and *residual is computed)
              as if GrDef were the best possible grid.
*/
{
    double par[6]={0.,0.,0.,0.,0.,0.};

    if(GrDef)
    {
        if(GrDef->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UGridFit::FitEuler(). Default grid is invalid. \n");
            if(residual) *residual = -1.;
            return UEuler();
        }
/* Compute parameters when fitting this to GrDef. */        
        UEuler ThisToDef = FitGridEuler(GrDef);
/* Compute residual error */
        if(residual) 
        {
            ThisToDef.GetParameters(par);
            UFitEulerArray FEA(this, EulerArray, Neuler);
            *residual = FEA.ComputeCost(par,0);
        }
        return ThisToDef;
    }
    else
    {
        for(int n=0; n<Neuler; n++)
        {
            double p[6];
            EulerArray[n].GetParameters(p);
            for(int k=0; k<6; k++) par[k] += p[k]/Neuler;
        }
        par[3] /= DIS2ANG;
        par[4] /= DIS2ANG;
        par[5] /= DIS2ANG;

        UFitEulerArray FEA(this, EulerArray, Neuler);
        if(FEA.GetError()!=U_OK  || FEA.Iterate(par,6,3.) != U_OK)
        {
            CI.AddToLog("ERROR: UGridFit::FitEuler(). Error in fitting. \n");
            if(residual) *residual = -1.;
            return UEuler();
        }
        if(residual) *residual = FEA.ComputeCost(par,0);

        return UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);    
    }
    return UEuler(); // This should never happen
}

UGridFit::UFitEulerArray::UFitEulerArray(const UGrid* G, const UEuler* E, int N) : Uminimize(UCostminimize()) 
/*
    The aim of this object is to compute the optimal "average" Euler transform. For this
    purpose the given grid (of MEG sensors) is transformed over the given array of 
    Euler transforms. This yields a cloud of points in the neighbourhood of each sensor, 
    The optimum Euler is the one that minimizes the sum of distances between the opimally
    transformed grid and the clouds of points. 
 */
{
    error  = U_ERROR;
    Grid   = G;
    EulArr = E; 
    nEuler = N;
    if(!Grid || !EulArr || !nEuler) return;

    error  = U_OK;
}

double UGridFit::UFitEulerArray::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    double   cost = 0.;
    UEuler eupar(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);

    for(int i=0;i<Grid->GetNpoints();i++)
    {
        UVector3 x = Grid->GetPosition(i);
        UVector3 y = eupar.xfm(x);
        for(int k=0; k<nEuler; k++) cost += ( EulArr[k].xfm(x) - y ).GetNorm();
    }
    return cost/(nEuler*Grid->GetNpoints());
}

/////////////////// CallibrateTip() ////////////////////////////////////////

UVector3 UGridFit::CallibrateTip(double* Tip, double MinPosError, double *residual) const
/* 
    Determine the optimal Tiplenght of the sensors, by minimizing the distance between
    the "tip-corrected" sensors and a sphere. The optimal sphere position is returned.

 */
{

/* Compute starting point for calibration */
    UCallibrateTip CT(this, MinPosError);
    if(CT.GetError())
    {
        if(residual) *residual = -1;
        return UVector3();
    }

    double par[4];    
    par[0] = par[1] = par[2] = par[3] = 0;

    for(int i=0; i < _npoints; i++)
    {
        par[0] += Getx(i);
        par[1] += Gety(i);
        par[2] += Getz(i);
    }
    
    par[0] /= CT.GetNtake();
    par[1] /= CT.GetNtake();
    par[2] /= CT.GetNtake();

    if(CT.Iterate(par, 4, 2.)!=U_OK)
    {
        if(residual) *residual = -1;
        return UVector3();
    }

    if(residual) *residual = CT.ComputeCost(par,0) / CT.GetNtake();

    *Tip = par[3];

    return UVector3(par[0], par[1], par[2]);
}

UGridFit::UCallibrateTip::UCallibrateTip(const UGrid* G, double MinPosError) : Uminimize(UCostminimize()) 
/*
    Mark the sensors with a position error smaller than MinPosError
 */
{
    error = U_ERROR;
    Grid  = G;
    if(!Grid) return;
    

    if(!(take = new char[Grid->GetNpoints()]))  return;

    ntake = 0;
    for(int i=0; i < Grid->GetNpoints(); i++)
    {
        take[i] = 1;///(Sen[i].GetPosError() < MinPosError);
        if(take[i]) ntake++;
    }
    if(ntake<=0) return;
    
    error = U_OK;
}

double UGridFit::UCallibrateTip::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    double  cost = 0.;
    for(int i=0;i<Grid->GetNpoints();i++)
    {
        if(take[i]==0) continue;
        USensor S  = Grid->GetSensor(i);
        cost      += ( UVector3(par[0],par[1],par[2]) - S.GetCorrectTipx(par[3]) ).GetNorm();        
    }
    return cost;
}

/////////////////// CallibrateTip() ////////////////////////////////////////

UEuler UGridFit::CallibrateTip(double *Tip, const UGrid &gr, double MinPosError, double *residual) const
/*
    Fit an Euler transform and a tip length onto the grid gr. The label names are not matched; 
    it is assumed instead that the points of gr and the private _sensors appear in the same order.
    Private sensors of the type U_SEN_NOTYPE are skipped.

    *Tip will be the optimal tip length.
    if(Tip==NULL) only Euler transform is optimized, no tip correction;
    The optimal Euler transform is returned.
 */
{
    bool VaryTip;
    if(Tip==NULL) VaryTip = false;
    else          VaryTip = true;
    UCallibrateTipGrid CTG(this, &gr, MinPosError, VaryTip);

    if(CTG.GetError()!=U_OK) 
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

    double par[7]={0.,0.,0.,0.,0.,0.,0.};

    for(int i=0; i<_npoints; i++) 
    {
        if(/****(_sensors[i].GetPosError()  < MinPosError) && ***/
           (_sensors[i]->GetStype()!=USensor::U_SEN_NOTYPE))
        {
            par[0] += gr.Getx(i)-Getx(i);
            par[1] += gr.Gety(i)-Gety(i);
            par[2] += gr.Getz(i)-Getz(i);
        }
    }
    par[0] /= CTG.GetNtake();
    par[1] /= CTG.GetNtake();
    par[2] /= CTG.GetNtake();
    
    if( (VaryTip==true  && CTG.Iterate(par,7)!= U_OK) ||
        (VaryTip==false && CTG.Iterate(par,6)!= U_OK) )
    {
        if(residual) *residual = -1.;
        return UEuler();
    }

    if(residual) *residual = CTG.ComputeCost(par,0) / CTG.GetNtake();

    if(Tip) *Tip = par[6];
    return UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);
}


UGridFit::UCallibrateTipGrid::UCallibrateTipGrid(const UGrid* G1, const UGrid* G2, double MinPosError, bool VT) : Uminimize(UCostminimize()) 
/*
    The label names are not matched. Instead, it is assumed instead that the points of G1
    and G2 appear in the same order. Sensors of G1 with a posstion error larger than 
    MinPosError are skipped. Also, sensors of the type U_SEN_NOTYPE are skipped.

    if(VT==true) the tip-length is varied, else it is kept constant
 */
{
    VaryTip = VT;
    error   = U_ERROR;
    Grid1   = G1;
    Grid2   = G2; 
    if(!Grid1 || !Grid2)       return;

    if(!(take = new char[Grid1->GetNpoints()]))  return;
    ntake = 0;
    for(int i=0; i<Grid1->GetNpoints(); i++)
    {
        USensor S = Grid1->GetSensor(i);
        take[i]   = /****(Sen1[i].GetPosError() < MinPosError) && ***/
                    (S.GetStype()   != USensor::U_SEN_NOTYPE);
        if(take[i]) ntake++;
    }
    if(ntake<=6) return;

    error = U_OK;
}

double UGridFit::UCallibrateTipGrid::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    if(status) *status = 0;

    if(fabs(par[6])>5.) 
    {
//        if(status) *status = -1;
        return 1000+par[6];
    }

    double cost = 0.;    
    UEuler eupar(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);

    if(VaryTip==true)
    {
        for(int i=0;i<Grid1->GetNpoints();i++)
        {
            if(take[i]==0) continue;       
            USensor S1 = Grid1->GetSensor(i);
            cost += ( Grid2->GetPosition(i) - eupar.xfm( S1.GetCorrectTipx(par[6]) )).GetNorm();
        }
    }
    else
    {
        for(int i=0;i<Grid1->GetNpoints();i++)
        {
            if(take[i]==0) continue;                
            cost += ( Grid2->GetPosition(i) - eupar.xfm( Grid1->GetPosition(i) )).GetNorm();
        }
    }
    return cost;
}






