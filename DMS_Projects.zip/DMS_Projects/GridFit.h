#ifndef _GRID_FIT_INCLUDED
#define _GRID_FIT_INCLUDED

#include "Grid.h"
#include "Minimize.h"

class DLL_IO UGridFit   :  public UGrid
{
public:
    static const double DIS2ANG;

    UGridFit();
    UGridFit(GridType GT);
    UGridFit(const char** EEGlab, int nEEG);

    UGridFit(int npoints, const USensor** sensors);
    UGridFit(UVector3* Points, int npoints, USensor::SensorType ST=USensor::U_SEN_POINT);
    UGridFit(const UGrid &g);
    virtual ~UGridFit();
    UGridFit& operator=(const UGridFit &g);

    double      FitSphere(UVector3& Spos, double *r1=NULL, double *r2=NULL) const;
    double      FitSphere(double *x, double *y, double *z, double *r1=NULL, double *r2=NULL) const;
    UEuler      FitGridEuler(UEuler* EulerArray, int Neuler, double* residual=NULL, const UGrid* GrDef=NULL) const;
    UEuler      FitGridEuler(const UGrid* GridRef, double *residual=NULL, double *start=NULL) const;
    UEuler      FitGridEuler(const UGrid* GridRef, const int* IndexThisToRef, double *residual=NULL, double *start=NULL) const;
    ULinTran    FitGridLinTran(const UGrid* GridRef, double *residual=NULL, double *start=NULL) const;
    ULinTran    FitGridLinTran(const UGrid* GridRef, const int* IndexThisToRef, double *residual=NULL, double *start=NULL) const;
    
    UVector3    CallibrateTip(double *Tip, double MinPosError, double *residual=NULL) const;
    UEuler      CallibrateTip(double *Tip, const UGrid &gr, double MinPosError, double *residual=NULL) const;

private:
    class UCallibrateTipGrid : public Uminimize // Object to fit a tip to a predefined grid
    {
    public:
        UCallibrateTipGrid(const UGrid* G1, const UGrid* G2, double MinPosError, bool VT);
        ~UCallibrateTipGrid()      {delete[] take;}
        ErrorType GetError() const {return  error;}
        int       GetNtake() const {return  ntake;}
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
    private:
        ErrorType    error;
        const UGrid* Grid1;
        const UGrid* Grid2;
        char*        take;
        int          ntake;
        bool         VaryTip;
    };

    class UCallibrateTip : public Uminimize // Object to fit a tip to one single point
    {
    public:
        UCallibrateTip(const UGrid* G, double MinPosError);
        ~UCallibrateTip()          {delete[] take;}
        ErrorType GetError() const {return  error;}
        int       GetNtake() const {return  ntake;}
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
    private:
        ErrorType    error;
        const UGrid* Grid;
        char*        take;
        int          ntake;
    };

    class UFitEuler : public Uminimize   // Object to fit the optimal Euler transform between to Grids
    {
    public:
        UFitEuler(const UGrid* Gxfm, const UGrid* Gref, const int* IndexXFmtoRef=NULL);
        ~UFitEuler()               {delete[] take;}
        ErrorType GetError() const {return  error;}
        int       GetNtake() const {return  Ntake;}
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
    private:
        ErrorType    error;
        const UGrid* Grid1;
        const UGrid* Grid2;
        int          Ntake;
        int*         take;
    };
    class UFitLinTran : public Uminimize   // Object to fit the optimal linear transformation between to Grids
    {
    public:
        UFitLinTran(const UGrid* Gxfm, const UGrid* Gref, const int* IndexXFmtoRef=NULL);
        ~UFitLinTran()               {delete[] take;}
        ErrorType GetError() const {return  error;}
        int       GetNtake() const {return  Ntake;}
        ULinTran  GetLinTran(const double*par) const;
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
    private:
        ErrorType    error;
        const UGrid* Grid1;
        const UGrid* Grid2;
        int          Ntake;
        int*         take;
    };

    class UFitEulerArray : public Uminimize   // Object to fit the "average" Euler transform
    {
    public:
        UFitEulerArray(const UGrid* G, const UEuler* E, int N);
        ErrorType GetError() const {return  error;}
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
    private:
        ErrorType     error;
        const UGrid*  Grid;
        const UEuler* EulArr;
        int           nEuler;
    };

    class UFitSphere : public Uminimize   // Object used to fit a sphere
    {
    public:
        UFitSphere(const UGrid* G, bool FOS) : Uminimize(UCostminimize()) {Grid=G; FitOuterSphere=FOS;}
        double ComputeCost(double *par, int iter, int *status)
        {
            return ComputeCost(par, iter, status, NULL, NULL);
        }
        double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);    
    private:
        bool  FitOuterSphere;
        const UGrid* Grid;
    };
};

#endif // _GRID_FIT_INCLUDED
