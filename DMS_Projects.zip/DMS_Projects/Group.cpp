/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining group memberships of named elements, derived from  */
/*     UGroupElem.                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  Jdm    10-04-07   creation, separated from Grid.cpp
                    use (new) UGroupElem i.s.o. USensor
                    ArrayElem is a SHALLOW copy of the array of derived pointers.
  JdM    26-10-07   Added WriteBinary() and FILE* constructor to UGroupElem
  JdM    31-01-08   Added GetGroupName()
  JdM    18-12-08   Added parameter to UGroup::DeleteAllMembers()
  JdM    19-12-08   Added WriteAsPartitionFile()
  JdM    22-12-08   Renamed GroupNumber to GroupID, in functions and dat members
                    Added GetSortedElements()
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
AW/JdM   19-05-11   UGroupElem::SetName(const char* nam, int nc). Eliminated ambiguous call to SetName() using cast to (const char*)NULL.
  JdM    02-11-11   Added UGroup::GetNGroupLarge() and UGroup::GetIndexLarge()
  JdM    28-01-11   Added GetMembersAsFieldGraphArray()
  JdM    17-07-13   BUG FIX: GetSortedElements(). Do range test if(el>=NElem) BEFORE increasing el.
  JdM    24-07-13   BUG FIX: MakeLabelsUnique(). There was an array range overwrite (cs[] should end with 0) and the test should be strncmp() (iso !strncmp())
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    07-04-16   GetIndexLarge(). Removed ERROR message, when group was not found
  JdM    09-09-16   Added CopyIDsFromNames()
*/


#include <string.h>
#include "Group.h"
#include "FieldGraph.h"

const char*  UGroupElem::HEADERBEGIN = "GElem1.0";
const char*  UGroupElem::HEADEREND   = "GElemEnd";
const char*  UGroup::PARTHEADERBEGIN = "Partition1.0";

UGroupElem::UGroupElem()
{
    GroupIndex  =  0;
    GroupID     = -1;
    memset(Name, 0, MAXGROUPELEMENTNAME);
}
UGroupElem::UGroupElem(FILE* fpIn)
{
    GroupIndex  =  0;
    GroupID     = -1;
    memset(Name, 0, MAXGROUPELEMENTNAME);

    if(fpIn==NULL) return;

    unsigned int ioff   = ftell(fpIn);
    size_t       NHead  = strlen(HEADERBEGIN);
    char     Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        fseek(fpIn, ioff, SEEK_SET);    
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        fseek(fpIn, ioff, SEEK_SET);    
        CI.AddToLog("ERROR: UGroupElem::UGroupElem(). Wrong header (%s). \n", Buffer);
        return;
    }

    GroupIndex  = ::ReadBinaryInt(DefaultIntelData, fpIn);
    GroupID     = ::ReadBinaryInt(DefaultIntelData, fpIn);
    fread(Name,1,MAXGROUPELEMENTNAME,fpIn);

    fread(Buffer,1,strlen(HEADEREND),fpIn);
} 
ErrorType UGroupElem::WriteBinary(FILE* fpOut) const
{
    if(this==NULL)  return U_ERROR;
    if(fpOut==NULL) return U_ERROR;
    
    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;
    
    ::WriteBinary(GroupIndex, DefaultIntelData, fpOut);
    ::WriteBinary(GroupID   , DefaultIntelData, fpOut);
    fwrite(Name, 1, MAXGROUPELEMENTNAME, fpOut);
    
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

UGroupElem::UGroupElem(int Groupid, const char* nam)
{
    GroupIndex  =  0;
    GroupID     =  Groupid;
    memset(Name, 0, MAXGROUPELEMENTNAME);
    if(nam)
        strncpy(Name, nam, MAXGROUPELEMENTNAME-1);
}
UGroupElem::UGroupElem(const UGroupElem& E)
{
    GroupIndex  =  0;
    GroupID     = -1;
    memset(Name, 0, MAXGROUPELEMENTNAME);
    if(&E==NULL) return;

    GroupID     = E.GroupID;
    GroupIndex  = E.GroupIndex ;
    memcpy(Name, E.Name, MAXGROUPELEMENTNAME-1);
}
UGroupElem& UGroupElem::operator=(const UGroupElem &E)
{
    if(this==NULL) 
    {
        static UGroupElem Edef;
        return Edef;
    }
    if(&E==NULL) return *this;
    GroupID     = E.GroupID;
    GroupIndex  = E.GroupIndex ;
    memcpy(Name, E.Name, MAXGROUPELEMENTNAME-1);
    return *this;
}
bool UGroupElem::operator==(const UGroupElem &E) const  //// GroupIndex might be different, when                                                
{                                                       //// elements originate from different arrays
    if(&E==NULL&&this==NULL) return true;
    if(&E==NULL||this==NULL) return false;

    if(GroupID  !=E.GroupID) return false;
    if(strncmp(Name, E.Name, MAXGROUPELEMENTNAME)) return false;

    return true;
}
bool UGroupElem::operator!=(const UGroupElem &E) const
{
    return NOT( *this==E);
}

const char* UGroupElem::GetName(void) const
{
    if(this==NULL) return "NULL";
    return Name;
}
ErrorType UGroupElem::SetName(const char* nam)
{
    if(this==NULL) return U_ERROR;
    if(nam==NULL)
    {
        memset(Name, 0, MAXGROUPELEMENTNAME);
        return U_OK;
    }
    strncpy(Name, nam, MAXGROUPELEMENTNAME-1);
    return U_OK;
}
ErrorType UGroupElem::SetName(const char* nam, int nc)
{ 
    if(this==NULL) return U_ERROR;
    if(nam==NULL) return UGroupElem::SetName((const char*)NULL);

    if(nc<0) nc = int(strlen(nam));
    if(nc>=MAXGROUPELEMENTNAME) nc = MAXGROUPELEMENTNAME-1;
    
    strncpy(Name,nam,nc);
    return U_OK;
}

ErrorType UGroupElem::SetName(int number)  
{     
    if(this==NULL) return U_ERROR;
    sprintf(Name,"%d",number);
    return U_OK;
}

ErrorType UGroupElem::AddToName(const char* NameExt)
{
    if(this==NULL) return U_ERROR;

    if(NameExt==NULL) return U_OK;
    size_t  last = strlen(Name);
    size_t  k    = last;
    for(; k<MIN( last+strlen(NameExt), MAXGROUPELEMENTNAME-1); k++) Name[k] = NameExt[k-last];
    Name[k] = 0;

    return U_OK;
}

int UGroupElem::GetGroupID(void) const
{
    if(this==NULL) return -1;
    return GroupID;
}
ErrorType UGroupElem::SetGroupID(int Groupid)
{
    if(this==NULL) return U_ERROR;
    GroupID = Groupid;
    return U_OK;
}
int UGroupElem::GetGroupIndex(void) const 
{
    if(this==NULL) return 0;
    return GroupIndex;
}
ErrorType UGroupElem::SetGroupIndex(int Index)  
{
    if(this==NULL) return U_ERROR;
    GroupIndex = Index;
    return U_OK;
} 


void UGroup::SetAllMembersDefault(void)
{
    error      = U_OK;
    NElem      = 0;
    NElemAlloc = 0;

    NGroup     = 0;
    NElemGroup = NULL;
    ElemArr    = NULL;
    Properties = UString();
}

void UGroup::DeleteAllMembers(ErrorType E)
{
    delete[] NElemGroup;
    SetAllMembersDefault();
    error = E;
}
const UString&  UGroup::GetGroupProperties(UString Comment)
{
    if(error!=U_OK || this==NULL)
    {
        Properties = UString(" ERROR in UGroup-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(NElem,         " NElem           = %d     \n") +
                  UString(NElemAlloc,    " NElemAlloc      = %d     \n") +
                  UString(NGroup,        " NGroup          = %d     \n");

    for(int ig=0; ig<NGroup; ig++)
    {
        Properties += UString(ig, "%d  \t") + UString(NElemGroup[ig], "%d  :\t");
        for(int elem=0; elem<NElemGroup[ig]; elem++)
        {
            int index = GetElem(ig, elem);
            if(index<0 || index>NElem || ElemArr[index]==NULL)
            {
                CI.AddToLog("ERROR: UGroup::GetGroupProperties(). Getting index ig=%d, elem=%d .\n", ig, elem);
                Properties = UString(" ERROR in UGroup-object");
                return Properties;
            }
            Properties += UString(ElemArr[index]->GetName(), "%s \t");
        }
        Properties += UString(" \n");
    }

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

UString UGroup::GetGroupLabels(int igroup) const
{
    UString Labels;
    if(igroup<0 || igroup>=NGroup)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupLabels(). argument out of range: igroup=%d  .\n", igroup);
        return Labels;
    }
    for(int elem=0; elem<NElemGroup[igroup]; elem++)
    {
        int index = GetElem(igroup, elem);
        if(index<0 || index>NElem || ElemArr[index]==NULL)
        {
            CI.AddToLog("ERROR: UGroup::GetGroupLabels(). Getting index ig=%d, elem=%d .\n", igroup, elem);
            return Labels;
        }
        Labels += UString(ElemArr[index]->GetName(), "%s \t");
    }
    return Labels;
}
UString UGroup::GetGroupName(int igroup) const
{
    if(this==NULL || error!=U_OK || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupName(). Object NULL or erroneous. \n");
        return UString(igroup,"ERROR_%d");
    }
    if(igroup<0 || igroup>=NGroup)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupName(). argument out of range: igroup=%d  .\n", igroup);
        return UString(igroup,"ERROR_%d");
    }
    int index = GetElem(igroup, 0);
    if(index<0 || index>NElem || ElemArr[index]==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupName(). Getting index ig=%d, elem=%d .\n", igroup, 0);
        return UString(igroup,"ERROR_%d");
    }
    return UString("Group_") + UString(ElemArr[index]->GetName());
}

UGroup::UGroup()
{
    SetAllMembersDefault();
}
UGroup::UGroup(int N, UGroupElem* const* Elems)
{
    SetAllMembersDefault();
    error = UpdateGroups(N, Elems);
}
UGroup::UGroup(const UGroup& G)
{
    SetAllMembersDefault();
    *this = G;
}
UGroup& UGroup::operator=(const UGroup &G)
{
    if(&G==NULL)
    {
        CI.AddToLog("ERROR: UGroup::operator=(). Invalid NULL address in argument.\n");
        return *this;
    }
    if(this==&G) return *this;

    DeleteAllMembers(U_OK);
    error      = G.error;

    NElem      = G.NElem;
    NElemAlloc = G.NElemAlloc;

    NGroup     = G.NGroup;
    ElemArr    = G.ElemArr;
    Properties = G.Properties;
    NElemGroup = new int[NElemAlloc];

    if(NElemGroup==NULL)
    {
        CI.AddToLog("ERROR: UGroup::operator=(). Memory alocation, NElemAlloc=%d  .\n", NElemAlloc);
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    for(int i=0; i<NElemAlloc; i++) 
        NElemGroup[i] = G.NElemGroup[i];

    return *this;
}
UGroup::~UGroup()
{
    DeleteAllMembers(U_OK);
}
ErrorType UGroup::WriteAsPartitionFile(const UFileName& FileText) const
{
    if(this==NULL || error!=U_OK || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::WriteAsPartitionFile(). Object NULL or erroneous or ElemArr==NULL\n");
        return U_ERROR;
    }
    if(&FileText==NULL)
    {
        CI.AddToLog("ERROR: UGroup::WriteAsPartitionFile(). Invalid NULL address of UFileName argument. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(FileText, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UGroup::WriteAsPartitionFile(). File cannot be created (%s). \n", (const char*)FileText);
        return U_ERROR;
    }
    fprintf(fp, "%s\n",PARTHEADERBEGIN);
    fprintf(fp, "// \n");
    fprintf(fp, "%s",(const char*)CI.GetProperties("// "));
    fprintf(fp, "// \n");
    fprintf(fp, "NElem    = %d \n", NElem );
    fprintf(fp, "NGroup   = %d \n", NGroup);
    fprintf(fp, "// \n");
    fprintf(fp, "// \n");
    for(int ig=0; ig<NGroup; ig++)
    {
        fprintf(fp, "Group        = %d \n", ig);
        fprintf(fp, "GroupID      = %d \n", GetGroupID(ig));
        fprintf(fp, "NElemGroup   = %d \n", NElemGroup[ig]);
        fprintf(fp, "Elements \n");
        for(int elem=0; elem<NElemGroup[ig]; elem++)
            fprintf(fp, "%d \n", GetElem(ig, elem));
        fprintf(fp, "// \n");
    }

    fclose(fp);
    return U_OK;
}
UFieldGraph** UGroup::GetMembersAsFieldGraphArray(int* NGraph) const
{
    if(this==NULL || error!=U_OK || ElemArr==NULL || NGroup<=0)
    {
        CI.AddToLog("ERROR: UGroup::GetMembersAsFieldGraphArray(). Object NULL or erroneous or ElemArr==NULL\n");
        return NULL;
    }
    if(NGraph==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetMembersAsFieldGraphArray(). Invalid NULL pointer argument.\n");
        return NULL;
    }

    UFieldGraph** FGArr = new UFieldGraph*[NGroup];
    if(FGArr)
    {
        for(int k=0; k<NGroup; k++) FGArr[k] = NULL;
        for(int k=0; k<NGroup; k++)
        {
            FGArr[k] = new UFieldGraph(float(0), float(NElem-1), NElem, UField::U_BYTE);
            if(FGArr[k]==NULL || FGArr[k]->GetError()!=U_OK)
            {
                for(int kk=0; kk<NGroup; kk++) delete FGArr[kk]; 
                delete[] FGArr; FGArr=NULL;
                break;
            }
            FGArr[k]->SetDataByte((unsigned char)0);
        }
    }
    if(FGArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetMembersAsFieldGraphArray(). Memory allocation error.\n");
        return NULL;
    }
    for(int j=0; j<NElem; j++)
    {
        int ig = ElemArr[j]->GetGroupIndex();
        if(ig<0 || ig>=NGroup)
        {
            CI.AddToLog("ERROR: UGroup::GetMembersAsFieldGraphArray(). Invalid group index (%d).\n", ig);
            for(int kk=0; kk<NGroup; kk++) delete FGArr[kk]; delete[] FGArr;
            return NULL;
        }
        FGArr[ig]->GetBdata()[j] = 1;
    }
    for(int k=0; k<NGroup; k++) FGArr[k]->SetLabel(GetGroupName(k));
    *NGraph = NGroup;

    return FGArr;
}

const UGroupElem* UGroup::GetElement(int index) const
{
    if(this==NULL || error!=U_OK || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetElement(). Object NULL or ElemArr==NULL\n");
        return NULL;
    }
    if(index<0 || index>=NElem)
    {
        CI.AddToLog("ERROR: UGroup::GetElement(). index =%d is out of range. \n", index);
        return NULL;
    }
    if(ElemArr[index]==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetElement(). ElemArr[%d] == NULL. \n", index);
        return NULL;
    }
    return ElemArr[index];
}
ErrorType UGroup::CopyIDsFromNames(const UGroup* G)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::CopyIDsFromNames(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(G==NULL||G->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::CopyIDsFromNames(). Argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(G->NElem<NElem)
    {
        CI.AddToLog("ERROR: UGroup::CopyIDsFromNames(). Argument has fewer elements than this: %d versus %d.\n", G->NElem, NElem);
        return U_ERROR;
    }
    int* IndexG = new int[NElem];
    if(IndexG==NULL)
    {
        CI.AddToLog("ERROR: UGroup::CopyIDsFromNames(). Memory allocation, NElem = %d.\n", NElem);
        return U_ERROR;
    }
    for(int n=0; n<NElem; n++) IndexG[n]=-1;
    for(int n=0; n<NElem; n++)
    {
        for(int m=0; m<G->NElem; m++)
        {
            if(stricmp(ElemArr[n]->GetName(), G->ElemArr[m]->GetName())) continue;
            IndexG[n] = m;
            break;
        }
        if(IndexG[n]<0)
        {
            CI.AddToLog("ERROR: UGroup::CopyIDsFromNames(). Label not found: %s.\n", ElemArr[n]->GetName());
            delete[] IndexG;
            return U_ERROR;
        }
    }
    for(int n=0; n<NElem; n++) ElemArr[n]->SetGroupID(G->ElemArr[IndexG[n]]->GetGroupID());
    delete[] IndexG;

    return UpdateGroups();
}

ErrorType UGroup::UpdateGroups(int N, UGroupElem* const* Elems)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::UpdateGroups(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(N==0 && Elems==NULL) 
    {
        DeleteAllMembers(U_OK);
        return U_OK;
    }
    if(N<0 || Elems==NULL)
    {
        CI.AddToLog("ERROR: UGroup::UpdateGroups(). Invalid argument(s), N=%d  .\n", N);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    for(int n=0; n<N; n++) 
        if(Elems[n]==NULL)
        {
            CI.AddToLog("ERROR: UGroup::UpdateGroups(). Elemt[%d] ==NULL .\n", n);
            DeleteAllMembers(U_ERROR);
            return U_ERROR;
        }

    if(NElemAlloc<N)
    {
        DeleteAllMembers(U_OK);
        NElemAlloc = 2*N+1;
        NElemGroup = new int[NElemAlloc];

/* Test and reset */
        if(NElemGroup==NULL)
        {
            CI.AddToLog("ERROR: UGroup::UpdateGroups(). Memory alocation, NElemAlloc=%d  .\n", NElemAlloc);
            DeleteAllMembers(U_ERROR);
            return U_ERROR;
        }
        for(int i=0; i<NElemAlloc; i++) NElemGroup[i] =  0;
    }
    NElem   = N;
    ElemArr = Elems;

    return UpdateGroups();
}

ErrorType UGroup::UpdateGroups(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::UpdateGroups(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(NElem==0) return U_OK;

    if(NElemGroup==NULL || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::UpdateGroups(). Object not properly set. \n");
        return U_ERROR;
    }
    for(int i=0; i<NElemAlloc; i++) NElemGroup[i] =  0;

/* Update groups*/
    NGroup = 0;
    for(int i1=0; i1<NElem; i1++)
    {
        bool NewElem = true;
        int  igroup  = NGroup;
        for(int i2=0; i2<i1; i2++)
        {
            if((ElemArr[i1])->GetGroupID()==(ElemArr[i2])->GetGroupID())
            {
                NewElem = false;
                igroup  = ElemArr[i2]->GetGroupIndex();
                break;
            }
        }
        if(NewElem==true) NGroup++;

        ElemArr[i1]->SetGroupIndex(igroup);
        NElemGroup[igroup]++;
    }
    return U_OK;
}

int UGroup::GetIndexLarge(int SizeThreshold, int igroup) const
{
    if(this==NULL || NElemGroup==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetIndexLarge(). Object not properly set, return 0.\n");
        return 0;
    }
    int igLarge = 0;
    for(int ig=0; ig<NGroup; ig++)
        if(NElemGroup[ig]>=SizeThreshold) 
        {
            if(igLarge==igroup) return ig;
            igLarge++;
        }

    return 0;
}

int UGroup::GetNGroupLarge(int SizeThreshold) const
{
    if(this==NULL || NElemGroup==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetNGroupLarge(). Object not properly set, return 0.\n");
        return 0;
    }
    int NLarge = 0;
    for(int ig=0; ig<NGroup; ig++)
        if(NElemGroup[ig]>=SizeThreshold) NLarge++;
    return NLarge;        
}

int UGroup::GetNElem(int igroup) const
{
    if(this==NULL || NElemGroup==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetNElem(). Object not properly set, return 0.\n");
        return 0;
    }
    if(igroup<0 || igroup>=NGroup)
    {
        CI.AddToLog("ERROR: UGroup::GetNElem(). igroup (=%d) out of range, NGroup = %d. return 0.\n", igroup, NGroup);
        return 0;
    }
    return NElemGroup[igroup];
}

int UGroup::GetElem(int igroup, int elem) const
{
    if(ElemArr==NULL || NElemGroup==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetElem(). Object not properly set, return -1.\n");
        return -1;
    }
    if(igroup<0 || igroup>=NGroup)
    {
        CI.AddToLog("ERROR: UGroup::GetElem(). igroup (=%d) out of range, NGroup = %d. return -1.\n", igroup, NGroup);
        return -1;
    }
    if(elem<0 || elem>=NElemGroup[igroup])
    {
        CI.AddToLog("ERROR: UGroup::GetElem(). elem (=%d) out of range, NElemGroup = %d. return -1.\n", elem, NElemGroup[igroup]);
        return -1;
    }

    int el = 0;
    for(int i=0; i<NElem; i++)
    {
        if(ElemArr[i]->GetGroupIndex()!=igroup) continue;
        if(el==elem) return i;
        el++;
    }
    CI.AddToLog("ERROR: UGroup::GetElem(). Element not found, igroup = %d, elem = %d  .\n", igroup, elem);
    return -1;
}

int UGroup::GetGroupID(int igroup) const
{
    if(NElemGroup==NULL || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupID(). Object not properly set, return -1.\n");
        return -1;
    }
    if(igroup<0 || igroup>=NGroup)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupID(). igroup (=%d) out of range, NGroup = %d. return -1.\n", igroup, NGroup);
        return -1;
    }
    int FirstElem = this->GetElem(igroup, 0);
    if(FirstElem<0 || FirstElem>=NElem)
    {
        CI.AddToLog("ERROR: UGroup::GetGroupID(). FirstElem out of range: FirstElem = %d  .\n",FirstElem);
        return -1;
    }
    return (ElemArr[FirstElem])->GetGroupID();
}

int UGroup::GetUnusedGroupID(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::GetUnusedGroupID(). Object NULL or erroneous, return -1.\n");
        return -1;
    }
    if(NElemGroup==NULL || ElemArr==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetUnusedGroupID(). Object not properly set, return -1.\n");
        return -1;
    }
    for(int index=0; index<NElem; index++)
    {
        bool used = false;
        for(int i=0; i<NElem; i++)
        {
            if(ElemArr[i]->GetGroupID()==index)
            {
                used = true;
                break;
            }
        }
        if(used==false) return index;
    }
    return NElem;
}
int* UGroup::GetSortedElements(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::GetSortedElements(). this==NULL or erroneous. \n");
        return NULL;
    }
    if(ElemArr==NULL && NElem<=0) 
    {
        CI.AddToLog("ERROR: UGroup::GetSortedElements(). No elements (NElem = %d). \n", NElem);
        return NULL;
    }
    int* Sort = new int[NElem];
    if(Sort==NULL)
    {
        CI.AddToLog("ERROR: UGroup::GetSortedElements(). Memory allocation (NElem = %d). \n", NElem);
        return NULL;
    }

    int el = 0;
    for(int ig=0; ig<NGroup; ig++)
    {
        for(int m=0; m<NElemGroup[ig]; m++)
        {
            if(el>=NElem)
            {
                delete[] Sort;
                CI.AddToLog("ERROR: UGroup::GetSortedElements(). Indexing error. \n");
                return NULL;
            }
            Sort[el++] = GetElem(ig, m);
        }
    }
    return Sort;
}

ErrorType UGroup::MakeLabelsUnique(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UGroup::MakeLabelsUnique(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(ElemArr==NULL && NElem==0) return U_OK;
    if(ElemArr==NULL || NElem<0)
    {
        CI.AddToLog("ERROR: UGroup::MakeLabelsUnique(). ElemArr==NULL. \n");
        return U_ERROR;
    }
    for(int i1=0; i1<NElem; i1++)
        if(ElemArr[i1]==NULL)
        {
            CI.AddToLog("ERROR: UGroup::MakeLabelsUnique(). Element %d ==NULL. \n", i1);
            return U_ERROR;
        }


    for(int i1=0; i1<NElem; i1++)
    {
        if(ElemArr[i1]->GetName()==NULL)
        {
            CI.AddToLog("ERROR: UGroup::MakeLabelsUnique(). ElemArr[%d].Name==NULL. \n", i1);
            return U_ERROR;
        }
        for(int i2=0; i2<i1; i2++)
        {
            if(strncmp(ElemArr[i1]->GetName(), ElemArr[i2]->GetName(), MAXGROUPELEMENTNAME)) continue;
                
            char cs[2] = {(char)(65+i2%26), 0};
            ElemArr[i1]->AddToName(cs);
        }
    }
    for(int i1=0; i1<NElem; i1++)
    {
        for(int i2=0; i2<i1; i2++)
        {
            if(strncmp(ElemArr[i1]->GetName(), ElemArr[i2]->GetName(), MAXGROUPELEMENTNAME)) continue;
                
            char cs[2] = {(char)(65+(i2+1)%26), 0};
            ElemArr[i1]->AddToName(cs);
        }
    }
    return U_OK;
}
