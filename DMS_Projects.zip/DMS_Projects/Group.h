#ifndef _GROUP_INCLUDED
#define _GROUP_INCLUDED


#include "String.h"
#include "FileName.h"

#define MAXGROUPELEMENTNAME 64

class DLL_IO UGroupElem
{
public:
    UGroupElem();
    UGroupElem(FILE* fpIn);
    UGroupElem(int GroupID, const char* nam);
    UGroupElem(const UGroupElem& E);
    UGroupElem&              operator=(const UGroupElem &E);
    virtual bool             operator==(const UGroupElem &E) const; 
    virtual bool             operator!=(const UGroupElem &E) const; 

    const char*              GetName(void) const;
    ErrorType                SetName(const char* nam);
    ErrorType                SetName(const char* nam, int nc);
    ErrorType                SetName(int number);  
    ErrorType                AddToName(const char* NameExt);

    int                      GetGroupID(void) const;
    ErrorType                SetGroupID(int GroupID);
    int                      GetGroupIndex(void) const;
    ErrorType                SetGroupIndex(int Index);

    ErrorType                WriteBinary(FILE* fpOut) const;

private:
    static const char*       HEADERBEGIN;
    static const char*       HEADEREND;

    char                     Name[MAXGROUPELEMENTNAME];
    int                      GroupID;        // Group number, unique for each group
    int                      GroupIndex;     // Index running from 0 to NGroup-1
};

class UFieldGraph;
class DLL_IO UGroup
{
public:
    UGroup();
    UGroup(int N, UGroupElem* const* Elems);
    UGroup(const UGroup& G);
    ~UGroup();
    UGroup&                  operator=(const UGroup &G);

    ErrorType                GetError() const {return error;}
    const UString&           GetGroupProperties(UString Comment);
    UString                  GetGroupLabels(int igroup) const;
    ErrorType                CopyIDsFromNames(const UGroup* G);

    ErrorType                UpdateGroups(int N, UGroupElem* const* Elems);
    ErrorType                UpdateGroups(void);

    const UGroupElem*        GetElement(int index) const;

    int                      GetIndexLarge(int SizeThreshold, int igroup) const;
    int                      GetNGroupLarge(int SizeThreshold) const;
    int                      GetNGroup() const {return NGroup;}
    int                      GetNElem(int igroup) const;
    int                      GetElem(int igroup, int elem) const;
    int                      GetGroupID(int igroup) const;
    int                      GetUnusedGroupID(void) const;
    int*                     GetSortedElements(void) const;

    ErrorType                MakeLabelsUnique(void);
    UString                  GetGroupName(int igroup) const;

    UFieldGraph**            GetMembersAsFieldGraphArray(int* NGraph) const;         
    ErrorType                WriteAsPartitionFile(const UFileName& FileText) const;

protected:
    static const char*       PARTHEADERBEGIN;
    ErrorType                error;
    int                      NElem;
    int                      NElemAlloc;
    void                     SetAllMembersDefault(void);
    void                     DeleteAllMembers(ErrorType E);

private:
    int                      NGroup;
    int*                     NElemGroup;
    UGroupElem* const*       ElemArr;
    UString                  Properties;
};
#endif // _GROUP_INCLUDED
