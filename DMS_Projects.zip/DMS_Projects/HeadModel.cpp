/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL                                                                   */
/*     Module for maintaining the data concerning the headmodel used.            */
/*                                                                               */
/*                                                                               */
/*     NOTES                                                                     */
/*     All coordinates are given in the head coordinate system:                  */
/*     nasion-left-right.                                                        */
/*                                                                               */
/*     USAGE                                                                     */
/*     A UHeadModel-object can be created by one of the constructors. A pointer  */
/*     of that object can be passed to the constructor of an UEMfield-object (to */
/*     compute electric and magnetic fields). The UEMfield object calls for the  */
/*     updates of the tables and coefficients when needed in the multi-sphere    */
/*     models.                                                                   */
/*     Realistic model are treated by the base class of the UEMfield object.     */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    11-09-98   creation
  Jdm    01-10-98   Added multi-sphere model
  JdM    08-10-98   separated include-files
  Jdm    24-10-98   Use the UAnalyzeLine-object to read head model parameters from a string
  Jdm    29-12-98   Added more comments.
  Jdm    15-04-99   MAJOR UPDATE: Added ReadHeadModelFile() and HeadHeadModelFile(), etc.
  Jdm    17-04-99   Added name to shells
  GdV    06-05-99   Case sensitivity changed in order to compile it with gcc
  JdM    06-06-99   Added the possibility get info on realistic models,
                    preparations for the derivatives in the multi-sphere model.
  JdM    14-06-99   More comments in the default head model file,
  JdM    01-07-99   Allow ELEC_RADIUS = ... in the HeadModelFile, i.e. subsurface electrodes
  JdM    27-07-99   Some bug fixes for multi-sphere model
  JdM    08-08-99   Use CI-object to write errors to .log-file
  JdM    19-11-99   Added static WriteHeadModel() member function
  JdM    11-01-00   Perform more tests for the existence of files. Print errors to log file.
  JdM    18-01-00   UpdateRadialCoefficients() now returns ErrorType instead of void
  JdM    19-01-00   Added the MR2wld transform to perform a match between the surfaces, the MR and the MR markers.
  JdM    21-01-00   Removed the conceptually false MR2wld
  JdM    16-02-00   Tested for fatal input errors.
  JdM    17-02-00   Added BEM computation parameters.
  JdM    21-02-00   Bug fix in 16-02-00: Test for Ns<0 in case of U_SPHERE
  JdM    06-03-00   Bug fix in reading strings from (updated) head model file.
  JdM    27-03-00   Added SetSigma()
 SG/JdM  04-04-00   Bug fix in SetSigma() (testing the right model)
  JdM    18-05-00   Added parameter SinterIndex to set the degree of triangle sub-division
  JdM    22-05-00   Split off the cumpute functions for the multi-sphere model. The newly
                    created object UMultiSphereModel() replaces this part
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    12-10-00   Added Error/Warning messages for the mis-use of several functions.
  JdM    07-11-00   Added Comment[] parameter to WriteHeadModel()
                    Added SetThreeSphereModel() and operator=()
  JdM    08-11-00   SetRealistic()
  JdM    28-11-00   WriteHeadModelFileTxt(). Export more parameters in case of realistic models
  JdM    03-03-01   Added compatibility with the UFileName() object
  JdM    29-05-01   Added WriteAsRealistic()
JdM/SG   25-06-01   Bug Fix: operator=(). updating MR_Markers[]
  JdM    26-06-01   Bug Fix: GetProperties(). Smoothing and No Smoothing were mixed up.
  JdM    22-05-02   GetProperties(). Do not print sphere pos and radius for realistic models
  JdM    13-06-02   Added MRtoWld to deal with situation of non-sagital MR scans with realistic models.
  JdM    10-02-03   ReadHeadModelFile(). return U_ERROR when MR_DIRECTORY is not set in case of realistic models
                    WriteHeadModelFileTxt(). Add MR_directory parameter
  JdM    21-04-03   Add parameter to SetRealistic()
  JdM    22-08-03   Added the conductivity units to be used in input and output. Added notes on conductities in example output file.
  JdM    22-07-04   Added and used SetAllMembersDefault(), DeleteAllMembers() and copy constructor
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    24-11-04   Bug Fix: Multi-sphere constructor: copying sphere position.
  JdM    07-01-05   GetProperties(): made it a const function
  JdM    26-02-05   WriteHeadModelFileTxt() write directory/file names inside quotes
  JdM    10-06-05   BUG FIX UHeadModel(UVector3 Spos, double Hrad) constructor. Function arguments not used. Default model is used instead!!!
  JdM    11-11-06   added output of "ELEC_RADIUS" in head model file
  JdM    23-11-06   Test for #define PUBLIC_SOURCES to make "more public sources"
  JdM    20-11-07   Defined ModelType externally, and renamed to CondModelType. Added U_CONDMOD_INFINITEMEDIUM 
  JdM    21-11-07   Use UString for Properties
                    Added GetCondModelType() and GetCondModelTypeText()
  JdM    02-01-08   Bug fix: TestConsistency() in case U_CONDMOD_SPHERE
  JdM    07-03-08   ReadHeadModelFile(). Test for existence of Surface directories
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    22-03-11   ReadMRmarkers(). Skip empty lines.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    22-02-15   Removed (obsolete) SurfInterPolType and SinterIndex data members
  JdM    21-05-15   MAJOR UPDATE: removed obsolete data and functions. All required coord transformations are performed by UHeadModel.
                    For realistic BEM models, use GetNestedSurfaceNLR() to get the surfaces
  JdM    03-03-18   Added GetTriFileName() and GetRef2NLR()
  JdM    01-06-18   BUG FIX. UFileName() constructor. Testing either/or whether "MR_DIRECTORY" or "MR_TOWORLD" have been read (not both need to be true)
*/

#include <string.h>
#include <stdio.h>

#include "HeadModel.h"
#include "AnalyzeLineExt.h"
#include "NestedSurface.h"
#include "BemMatrix3.h"

#define MAXSURFACE_NAME 32   // Maximum number of characters read from file

/* Inititalize static (const) parameters. */
UString UHeadModel::Properties = UString();


void UHeadModel::SetAllMembersDefault(void)
{
    error              = U_OK;
    MRtoWld            = UEuler();
    Properties         = UString();

    SpherePos          = UVector3();
    HeadRadius         = 10.;
    Model              = U_CONDMOD_UNKNOWN;
    Ns                 = 0;
    relec              = 1.;

    for(int k=0; k<MAXSURFACE; k++) 
    {
        rs[k] = eps[k] = eht[k] = 0;
        Name[k]        = UString();
        TriFileName[k] = UFileName();
    }
    Pinter             = U_POTINTER_CONSTANT;
    Smooth             = U_SMOOTH_RAW;

    FileNamesValid     = true;
    for(int k=0; k<MAXSURFACE; k++) SurfaceArrNLR[k] = NULL;
}

void UHeadModel::DeleteAllMembers(ErrorType E)
{
    for(int k=0; k<MAXSURFACE; k++) delete SurfaceArrNLR[k];

    SetAllMembersDefault();
    error = E;
}

UHeadModel::UHeadModel()
{
    SetAllMembersDefault();
} 

UHeadModel::UHeadModel(const UHeadModel& HM)
{
    SetAllMembersDefault();
    *this = HM;
}


UHeadModel::UHeadModel(CondModelType Mod)
{
    SetAllMembersDefault();
    if(Mod!=U_CONDMOD_INFINITEMEDIUM)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("UHeadModel::UHeadModel(). Invalid modeltype argument (%d)\n", Mod);
        return;
    }
    Model  = Mod;
    eps[0] = 1.;
    eht[0] = 1.;

    if(TestConsistency()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}
UHeadModel::UHeadModel(UVector3 Spos, double Hrad)
/*   
      Initialize the head model for the model U_CONDMOD_SPHERE (to be used with MEG). 
 */
{    
    SetAllMembersDefault();

    SpherePos   = Spos;
    HeadRadius  = Hrad;
    Model       = U_CONDMOD_SPHERE;

    if(TestConsistency() !=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}
UHeadModel::UHeadModel(double cond, UVector3 Spos, double Hrad)
/*   
      Initialize the head model for the model U_CONDMOD_HOMSPHERE. This model can be used
      for both MEG and EEG. 
      Note: it is assumed that the electrodes are on the outer surface of the head.
 */
{
    SetAllMembersDefault();

    SpherePos   = Spos;
    HeadRadius  = Hrad;
    Model       = U_CONDMOD_HOMSPHERE;
    Ns          = 1;
    relec       = 1;

    rs[0]       = 1;
    eps[0]      = eht[0] = cond;
    Name[0]     = UString("Head");
 
    if(TestConsistency() !=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}

UHeadModel::UHeadModel(double c1, double c2, double f1, double f2, UVector3 Spos, double Hrad)
/*   
      Initialize the head model for the model U_CONDMOD_THREESPHERE. This model can be used
      for both MEG and EEG.
      c1 : conductivity of the skull   [1/(Ohm cm)]
      c2 : conductivity of the skin and brain [1/(Ohm cm)]
      f1 : relative outer radius of the skull 
      f2 : relative inner radius of the skull
 */
{
    SetAllMembersDefault();
    SpherePos   = Spos;
    HeadRadius  = Hrad;
    Model       = U_CONDMOD_THREESPHERE;
    Ns          = 3;
    relec       = 1;

    rs[0]       =  1;
    rs[1]       =  f1;
    rs[2]       =  f2;
    eps[0]      =  eht[0] = c2;
    eps[1]      =  eht[1] = c1;
    eps[2]      =  eht[2] = c2;
    Name[0]     =  UString("Skin");
    Name[1]     =  UString("Skull");
    Name[2]     =  UString("Brain");

    if(TestConsistency() !=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}

UHeadModel::UHeadModel(const double* r, const double* ep, const double* eh, int ns, UVector3 Spos, double R_elec)
/*   
      Initialize the head model for the model U_CONDMOD_MULTISPHERE. This model can be used
      for both MEG and EEG.

      r[]    - the radii of the concentric spheres, expressed in cm,
               So, r[0] is thehead radius in cm.
      ep[]   - the radial conductivities of the shells, expressed in SI.
      eh[]   - the tangential conductivities of the shells, expressed in SI.
      ns     - the number of shells
      Spos   - the position of the best fitting sphere w.r.t. the nasion-ear system.
      R_elec _ the radial coordinate of the electrode(s) in cm.
 */
{
    SetAllMembersDefault();

    if(ns<0 || ns>=MAXSURFACE || eps==NULL || r==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Invalid NULL argument(s) or Nsurf out of range (ns=%d).\n", ns);
        return;
    }

    SpherePos   = Spos;
    Model       = U_CONDMOD_MULTISPHERE;
    Ns          = ns;
    relec       = 1;

    HeadRadius  = r[0];
    if(HeadRadius==0 || R_elec>HeadRadius || R_elec<=0) HeadRadius=-1.;  // Consistency test will fail
    relec       = R_elec/HeadRadius;

    for(int j=0; j<MIN(MAXSURFACE,ns); j++)
    {
        rs[j]    = r[j]/HeadRadius;
        eps[j]   = ep[j];
        eht[j]   = eh ? eh[j] : ep[j];
        Name[j]  = UString(j,"Shell_%d");
    }

    if(TestConsistency() !=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}

UHeadModel::UHeadModel(int Nsurf, UFileName* TriFiles, UString* SurfNames, UEuler MR2W, const UVector3* NLR_MRI,
                            const double* cond, PotInterPolType PIP, BEMSmoothType SM)
{
    SetAllMembersDefault();

    if(Nsurf<0 || Nsurf>=MAXSURFACE || TriFiles==NULL || NLR_MRI==NULL || cond==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Invalid NULL argument(s) or Nsurf out of range (Nsurf=%d).\n", Nsurf);
        return;
    }

    Model         =  U_CONDMOD_BEM;
    Ns            =  Nsurf;
    MRtoWld       =  MR2W;
    MR_Markers[0] =  NLR_MRI[0];
    MR_Markers[1] =  NLR_MRI[1];
    MR_Markers[2] =  NLR_MRI[2];
    Pinter        =  PIP;
    Smooth        =  SM;

    for(int k=0; k<Ns; k++) 
    {
        TriFileName[k] = TriFiles[k];
        Name[k]        = SurfNames ? SurfNames[k] : UString(TriFiles[k].GetBaseName());
        eps[k]         = cond[k];
        eht[k]         = cond[k];
    }

    if((error = TestConsistency()) !=U_OK) 
    {
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}
UHeadModel::UHeadModel(int Nsurf, const UNestedSurface* const*SurfArrMRI, UEuler MR2W, const UVector3* NLR_MRI, PotInterPolType PIP, BEMSmoothType SM)
{
    SetAllMembersDefault();
    if(Nsurf<0 || Nsurf>=MAXSURFACE)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Nsurf out of range (%d)\n", Nsurf);
        return;
    }
    if(Nsurf==0) return;

    if(SurfArrMRI==NULL || NLR_MRI==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Invalid NULL argument(s).\n");
        return;
    }
    MRtoWld            =  MR2W;
    MR_Markers[0]      =  NLR_MRI[0];
    MR_Markers[1]      =  NLR_MRI[1];
    MR_Markers[2]      =  NLR_MRI[2];
    Model              =  U_CONDMOD_BEM;
    Ns                 =  Nsurf;
    Pinter             =  PIP;
    Smooth             =  SM;
    FileNamesValid     =  false;

    UEuler MRItoNLR(MR_Markers[0], MR_Markers[1], MR_Markers[2]);
    for(int k=0; k<Nsurf; k++) 
    {
        if(SurfArrMRI[k]==NULL || SurfArrMRI[k]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Invalid or NULL UNestedSurface[%d]).\n", k);
            return;
        }
        UNestedSurface* SN = new UNestedSurface(*SurfArrMRI[k]);
        if(SN==NULL || SN->GetError()!=U_OK)
        {
            delete SN;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Copying UNestedSurface[%d]).\n", k);
            return;
        }
        SN->Transform(MRItoNLR);

        SurfaceArrNLR[k] = SN;
        eps[k] = eht[k]  = SN->GetInnerCond();
        Name[k]          = SN->GetName();
        TriFileName[k]   = UFileName();
    }
}

UHeadModel::UHeadModel(UFileName FileName)
/*
     Create a head model by reading parameters from the file named FileName.
 */
{
    SetAllMembersDefault();

    if(FileName.HasFileHeader(UBemMatrix3::GetFileHeader())==true)
    {
        FileNamesValid     = false;

        FILE* fp = fopen(FileName, "rb");
        UBemMatrix3 BEM(fp);
        fclose(fp);
        if(BEM.GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Reading file %s as binary BEM file.\n", (const char*)FileName);
            return;
        }
        Ns            = BEM.GetNsurfaces();
        Model         = U_CONDMOD_BEM;
        Pinter        = BEM.GetPotInterPol();
        Smooth        = BEM.GetSmoothElemA();
        MRtoWld       = UEuler();
        MR_Markers[0] = UVector3(10.,  0.,0.);  // Assume that surfaces are already in NLR coords
        MR_Markers[1] = UVector3( 0., 10.,0.);
        MR_Markers[2] = UVector3( 0.,-10.,0.);

        if(Ns<0 || Ns>=MAXSURFACE)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Number of surfaces out of range (%d).\n", Ns);
            return;
        }
        
        for(int k=0; k<Ns; k++)
        {
            const UNestedSurface* NS = BEM.GetSurface(k);
            if(NS==NULL || NS->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Getting UNestedSurface[%d] from BEM object.\n", k);
                return;
            }

            eps[k] = eht[k]  = NS->GetInnerCond();
            Name[k]          = NS->GetName();
            TriFileName[k]   = UFileName();
            SurfaceArrNLR[k] = new UNestedSurface(*NS);
            if(SurfaceArrNLR[k]==NULL || SurfaceArrNLR[k]->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Copying UNestedSurface[%d] from BEM object.\n", k);
                return;
            }
        }
    }
    else
    {
        FileNamesValid     = true;
        FILE* fp = fopen(FileName,"rt");
        if(fp==NULL) 
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UHeadModel::UHeadModel(). File can not be opened: %s \n", (const char*)FileName);
            return;
        }

/* Set Deafults*/
        for(int k=0; k<MAXSURFACE; k++) Name[k] = UString(k,"Surface%d");

        MR_Markers[2]  = MR_Markers[1] = MR_Markers[0] = UVector3();
        bool ToWldRead = false;
        bool MRdirRead = false;
        Model          = U_CONDMOD_UNKNOWN;
        Ns             = -1;
        double R_elec  = -1;
        char   line[500];
        while(GetLine(line, sizeof(line), fp)!=NULL)
        {
            UAnalyzeLineExt AA(line, sizeof(line));
            if(AA.IsComment()==true) continue;

            if(AA.IsIdentifierIs("MODEL")==true)
            {
                const char *Str = AA.GetNextString(sizeof("CONCENTRIC_SPHERES"));

                if     (Str && !stricmp(Str,"SPHERE"))              Model = U_CONDMOD_UNKNOWN;
                else if(Str && !stricmp(Str,"CONCENTRIC_SPHERES"))  Model = U_CONDMOD_HOMSPHERE;
                else if(Str && !stricmp(Str,"REALISTIC_MODEL"))     Model = U_CONDMOD_BEM;            
                else    CI.AddToLog("WARNING: UHeadModel::UHeadModel(). Undefined string following 'MODEL=' .\n");
                continue;
            }
            if(AA.IsIdentifierIs("SPHERE_POS")==true)  
            {
                SpherePos  = AA.GetNextVector3();
                continue;
            }
            if(AA.IsIdentifierIs("HEAD_RADIUS")==true) 
            {
                HeadRadius = AA.GetNextDouble();
                continue;
            } 
            if(AA.IsIdentifierIs("ELEC_RADIUS")==true) 
            {
                R_elec     = AA.GetNextDouble();
                continue;
            }
            if(AA.IsIdentifierIs("N_SHELL")==true || AA.IsIdentifierIs("N_SURFACE")==true)
            {
                Ns         = AA.GetNextInt(-1);
                continue;
            }
            if(AA.IsIdentifierIs("MR_MARKERFILE")==true)
            {
                UFileName CoorMRIfile;
                const char*  str = AA.GetNextFileName(sizeof(line));
                if(str==NULL) continue;
                CoorMRIfile = UFileName(str);
                ReadMRmarkers(CoorMRIfile);
                continue;
            }
            if(AA.IsIdentifierIs("MR_NASION")==true)
            {
                MR_Markers[0]  = AA.GetNextVector3();
                continue;
            }
            if(AA.IsIdentifierIs("MR_LEFT")==true)
            {
                MR_Markers[1]  = AA.GetNextVector3();
                continue;
            }
            if(AA.IsIdentifierIs("MR_RIGHT")==true)
            {
                MR_Markers[2]  = AA.GetNextVector3();
                continue;
            }
            if(AA.IsIdentifierIs("MR_DIRECTORY")==true)
            {
                const char*  str = AA.GetNextFileName(sizeof(line));
                if(str==NULL) continue;

                UPatTree Pat(str);
                if(Pat.GetStatus()!=UDirectory::U_EXIST)
                {
                    fclose(fp);
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UHeadModel::UHeadModel(). MR directory does not exist: %s .\n",Pat.GetDirectoryName());
                    return;
                }
                MRtoWld   = Pat.GetToWld(); // scan_to_wld.xdr or match_scan_to_wld.xdr
                MRdirRead = true;
                continue;
            }
            if(AA.IsIdentifierIs("MR_TOWORLD")==true)
            {
                double Tx = AA.GetNextDouble();
                double Ty = AA.GetNextDouble();
                double Tz = AA.GetNextDouble();
                double Rx = AA.GetNextDouble();
                double Ry = AA.GetNextDouble();
                double Rz = AA.GetNextDouble();
                MRtoWld   = UEuler(Tx, Ty, Tz, Rx, Ry, Rz);
                ToWldRead = true;
            }
            if(AA.IsIdentifierIs("INTERPOLATION")==true)
            {
                const char *Str = AA.GetNextString(20,NULL);
                if     (Str && !stricmp(Str,"CONSTANT")) Pinter = U_POTINTER_CONSTANT;
                else if(Str && !stricmp(Str,"LINEAR"  )) Pinter = U_POTINTER_LINEAR;
                else    CI.AddToLog("WARNING: UHeadModel::UHeadModel(). Undefined string following 'INTERPOLATION=' .\n");
                continue;
            }
            if(AA.IsIdentifierIs("ELEMENT_SMOOTH")==true)
            {
                const char *Str = AA.GetNextString(20,NULL);
                if     (Str && !stricmp(Str,"SMOOTH"  )) Smooth = U_SMOOTH_SMOOTH;
                else if(Str && !stricmp(Str,"NOSMOOTH")) Smooth = U_SMOOTH_RAW;
                else    CI.AddToLog("WARNING: UHeadModel::UHeadModel(). Undefined string following 'ELEMENT_SMOOTH='  .\n");
                continue;
            }
            for(int k=-1; k<MAXSURFACE;k++)
            {
                char STRING[32];
                memset(STRING, 0, sizeof(STRING));
                int k0 = MAX(0,k);
                if(k>=0) sprintf(STRING,"RADIUS%d",k);
                else     sprintf(STRING,"RADIUS");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    rs[k0]  = AA.GetNextDouble();
                    break;
                }
                        
                if(k>=0) sprintf(STRING,"RADIAL_COND%d",k);
                else     sprintf(STRING,"RADIAL_COND");
                if(AA.IsIdentifierIs(STRING)==true)
                {
                    eps[k0] = AA.GetNextDouble();
                    break;
                }
            
                if(k>=0) sprintf(STRING,"TANGENTIAL_COND%d",k);
                else     sprintf(STRING,"TANGENTIAL_COND");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    eht[k0] = AA.GetNextDouble();
                    break;
                }
                        
                if(k>=0) sprintf(STRING,"CONDUCTIVITY%d",k);
                else     sprintf(STRING,"CONDUCTIVITY");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    eht[k0] = eps[k0] = AA.GetNextDouble();
                    break;
                }
            
                if(k>=0) sprintf(STRING,"SURFACE_NAME%d",k);
                else     sprintf(STRING,"SURFACE_NAME");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    Name[k0] = AA.GetNextString(MAXSURFACE_NAME);
                    Name[k0].RemoveBlanks(false);
                    break;
                }
            
                if(k>=0) sprintf(STRING,"TRIANGLE_DIR%d",k);
                else     sprintf(STRING,"TRIANGLE_DIR");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    const char* Fname  = AA.GetNextFileName(sizeof(line));
                    TriFileName[k0] = UFileName(Fname);
                    UDirectory Dir  = UDirectory(Fname);

                    if(TriFileName[k0].DoesFileExist()==false && Dir.GetStatus()!=UDirectory::U_EXIST)
                    {
                        fclose(fp);
                        DeleteAllMembers(U_ERROR);
                        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Surface file or directory does not exist: %s .\n",(const char*)TriFileName[k0]);
                        return;
                    }
                    break;
                }
                if(k>=0) sprintf(STRING,"TRIANGLE_FILE%d",k);
                else     sprintf(STRING,"TRIANGLE_FILE");
                if(AA.IsIdentifierIs(STRING)==true) 
                {
                    const char* Fname  = AA.GetNextFileName(sizeof(line));
                    TriFileName[k0] = UFileName(Fname);
                    UDirectory Dir  = UDirectory(Fname);

                    if(TriFileName[k0].DoesFileExist()==false && Dir.GetStatus()!=UDirectory::U_EXIST)
                    {
                        fclose(fp);
                        DeleteAllMembers(U_ERROR);
                        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Surface file or directory does not exist: %s .\n",(const char*)TriFileName[k0]);
                        return;
                    }
                    break;
                }
            }
        }
        fclose(fp);
        if(Model==U_CONDMOD_UNKNOWN) Ns = 0;

        if(Model==U_CONDMOD_BEM)
        {
            if(MRdirRead==false && ToWldRead==false) 
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UHeadModel::UHeadModel(). MODEL = REALISTIC_MODEL, but MR_DIRECTORY= , or MR_TOWORLD=  is not set.\n");
                return;
            }
            if(MR_Markers[0]==UVector3()||MR_Markers[1]==UVector3()||MR_Markers[2]==UVector3())
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UHeadModel::UHeadModel().   MR_NASION=, or MR_LEFT=, or MR_RIGHT= is not set.\n");
                return;
            }
        }
        if(Model==U_CONDMOD_HOMSPHERE)
        {
            if(rs[0] >0.)  HeadRadius = rs[0];
            if(R_elec>0.)  relec      = MIN(1., R_elec/HeadRadius);

            for(int k=0; k<Ns;k++) 
            {
                rs[k]         /= HeadRadius;
                if(eht[k]==0.) eht[k] = eps[k];
            }
            if(Ns >1 || relec< 1.) Model = U_CONDMOD_MULTISPHERE;
            if(relec==1. && Ns==3 && eps[0]==eps[2])
            {
                int k = 0;
                for(     ; k<Ns;k++) 
                    if(eps[k] != eht[k]) break;
                if(k==3) Model = U_CONDMOD_THREESPHERE;
            }
        }
    }
/* Test for fatal errors: */
    if(Ns<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Number of shells or surfaces not or improperly read: %d. See N_SHELL= or N_SURFACE=\n",Ns);
        return;
    }
    if(Model==U_CONDMOD_UNKNOWN)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UHeadModel::UHeadModel(). Head model not or improperly read. See MODEL=\n");
        return;
    }
    if(TestConsistency()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UHeadModel::UHeadModel(). Inconsistent model.\n");
        return;
    }
}

UHeadModel::~UHeadModel() 
{
    DeleteAllMembers(U_OK);
}

UHeadModel& UHeadModel::operator=(const UHeadModel& hm)
{
    if(this==NULL)
    {
        static UHeadModel H; H.error = U_ERROR;
        return H;
    }
    if(&hm==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UHeadModel::operator=(). Invalid NULL address \n");
        return *this;
    }
    if(this==&hm) return *this;

    DeleteAllMembers(U_OK);

    SpherePos      =  hm.SpherePos;
    HeadRadius     =  hm.HeadRadius;
    Model          =  hm.Model;
    Ns             =  hm.Ns;
    relec          =  hm.relec;

    MR_Markers[0]  =  hm.MR_Markers[0];
    MR_Markers[1]  =  hm.MR_Markers[1];
    MR_Markers[2]  =  hm.MR_Markers[2];
    MRtoWld        =  hm.MRtoWld;
    Pinter         =  hm.Pinter;
    Smooth         =  hm.Smooth;
    FileNamesValid =  hm.FileNamesValid;

    for(int k=0; k<MAXSURFACE; k++) 
    {
        rs[k]          = hm.rs[k];
        eps[k]         = hm.eps[k];
        eht[k]         = hm.eht[k];
        Name[k]        = hm.Name[k];
        TriFileName[k] = hm.TriFileName[k];
        if(hm.SurfaceArrNLR[k])
        {
            SurfaceArrNLR[k] = new UNestedSurface(*hm.SurfaceArrNLR[k]);
            if(SurfaceArrNLR[k]==NULL || SurfaceArrNLR[k]->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UHeadModel::operator=(). Copying surface %d \n", k);
                return *this;
            }
        }
        else
        {
            SurfaceArrNLR[k] = NULL;
        }
    }
    return *this;
}

ErrorType UHeadModel::ReadMRmarkers(UFileName FileName)
{
    if(this==NULL) return U_ERROR;

    MR_Markers[0] = MR_Markers[1] = MR_Markers[2] = UVector3();

    FILE* fp = fopen(FileName, "rt");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UHeadModel::ReadMRmarkers(). Can not open the file %s \n",FileName);
        return U_ERROR;
    }
    
    int k=0;
    char line[256];
    while(GetLine(line, sizeof(line), fp)!=NULL && k<3)
    {
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;        
        if(AA.IsEmptyLine()==true) continue;        
        MR_Markers[k++] = AA.GetNextVector3();
    }
    fclose(fp);
    return U_OK;
}

ErrorType UHeadModel::CreateNestedSurfacesBEM(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::CreateNestedSurfacesBEM(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Model != U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR: UHeadModel::CreateNestedSurfacesBEM(). Object not set as BEM model. \n");
        return U_ERROR;
    }
    if(FileNamesValid==false)
    {
        for(int j=0; j<Ns; j++)
        {
            if(SurfaceArrNLR[j]==NULL || SurfaceArrNLR[j]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UHeadModel::CreateNestedSurfacesBEM(). Surface %d (out of %d) erroneous. \n", j, Ns);
                return U_ERROR;
            }
        }
        return U_OK;
    }
    for(int j=0; j<Ns; j++)
    {
        UNestedSurface* NS = GetNestedSurfaceNLR(j);
        if(NS==NULL || NS->GetError()!=U_OK)
        {
            delete NS;
            CI.AddToLog("ERROR: UHeadModel::CreateNestedSurfacesBEM(). Reading surface %d (out of %d) from file. \n", j, Ns);
            return U_ERROR;
        }
        delete SurfaceArrNLR[j]; SurfaceArrNLR[j] = NS;
    }
    FileNamesValid=false;
    return U_OK;
}
UNestedSurface* UHeadModel::GetNestedSurfaceNLR(int j) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::GetNestedSurfaceNLR(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Model != U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR: UHeadModel::GetNestedSurfaceNLR(). Object not set as BEM model. \n");
        return NULL;
    }
    if(j<0 || j>=Ns)
    {
        CI.AddToLog("ERROR: UHeadModel::GetNestedSurfaceNLR(). Argument out of range (j=%d). \n", j);
        return NULL;
    }

    UNestedSurface* NS = NULL;
    if(FileNamesValid)
    {
        NS = new UNestedSurface(TriFileName[j], eps[j]);
        if(NS==NULL || NS->GetError()!=U_OK)
        {
            delete NS;
            CI.AddToLog("ERROR: UHeadModel::GetNestedSurfaceNLR(). Reading USurface from file: %s. \n", (const char*)TriFileName[j]);
            return NULL;
        }

        UEuler ToNLR;

        if(TriFileName[j].HasExtension("xdr", false)==true || TriFileName[j].HasExtension("structure", false)==true)
        {
            ToNLR = UEuler(MR_Markers[0], MR_Markers[1], MR_Markers[2]) * MRtoWld.GetInverse();
        }
        else
        {
            ToNLR = UEuler(MR_Markers[0], MR_Markers[1], MR_Markers[2]);
        }
        NS->Transform(ToNLR);
    }
    else
    {
        NS = new UNestedSurface(*SurfaceArrNLR[j]);
        if(NS==NULL || NS->GetError()!=U_OK)
        {
            delete NS; NS = NULL;
            CI.AddToLog("ERROR: UHeadModel::GetNestedSurfaceNLR(). Copying UNestedSurface %d \n",j);
        }
    }
    return NS;
}

UString UHeadModel::GetSurfaceName(int j) const 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::GetSurfaceName(). Object NULL or erroneously set.\n");
        return UString();
    }
    if(j<0 || j>=Ns) 
    {
        CI.AddToLog("ERROR: UHeadModel::GetSurfaceName(). Shell parameter out of range (j=%d, Ns=%d).\n", j, Ns);
        return UString();
    }    
    return Name[j];
}

ErrorType UHeadModel::SetHomogeneousModel(void)   
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UHeadModel::SetHomogeneousModel(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    *this = UHeadModel(1., UVector3(), 10.);
    return error;
}

ErrorType UHeadModel::SetThreeSphereModel(UVector3 Spos, double Hrad)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UHeadModel::SetThreeSphereModel(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    *this = UHeadModel(.0125,1,.92,.87, Spos, Hrad);
    return error;
}

const UString& UHeadModel::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UHeadModel-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(GetCondModelTypeText(Model),         " ModelType        = %s  \n");

    if(Model != U_CONDMOD_UNKNOWN)
    {
        if(Model!=U_CONDMOD_INFINITEMEDIUM && Model!=U_CONDMOD_BEM)
        {
            Properties += UString(SpherePos.GetProperties(),    " SpherePosition   = %s  \n");
            Properties += UString(HeadRadius,                   " SphereRadius     = %7.2f // [cm]  \n");
        }
        if(Model==U_CONDMOD_BEM)
        {
            Properties += UString(MR_Markers[0].GetProperties()," Nasion_MRI       = %s  // [cm] \n");
            Properties += UString(MR_Markers[1].GetProperties()," Left_MRI         = %s  // [cm] \n");
            Properties += UString(MR_Markers[2].GetProperties()," Right_MRI        = %s  // [cm] \n");
            Properties += UString(MRtoWld.GetProperties(NULL)  ," MRtoWld          = %s   \n");
        }        
        Properties += UString(" \n");
        Properties += UString(Ns,                  " NShell           = %d  \n");
        if(Model!=U_CONDMOD_INFINITEMEDIUM && Model!=U_CONDMOD_BEM)
        {
            for(int n=0; n<Ns; n++)  
            {
                Properties += UString(n," Surface_%d        = ") + Name[n] + UString("  \n");
                Properties += UString(n," Radius_%d         = ") + UString(rs [n], " %9.5f  // fraction \n");
                Properties += UString(n," Eps_%d            = ") + UString(eps[n], " %9.5f  // [1/(Ohm cm)] \n");
                Properties += UString(n," Eht_%d            = ") + UString(eht[n], " %9.5f  // [1/(Ohm cm)] \n");
                Properties += UString(" \n");
            }
        }
        else
        {
            Properties += UString(BoolAsText(FileNamesValid)," FileNamesValid   = %s  \n");
            
            int Ndim = 0;
            for(int n=0; n<Ns; n++)
            {
                Properties += UString(n," Surface_%d        = ") + Name[n] + UString("  \n");
                if(FileNamesValid)
                    Properties += UString(n," TriFile_%d        = ") + UString(TriFileName[n]) + UString("  \n");
                else if(SurfaceArrNLR[n] && SurfaceArrNLR[n]->GetError()==U_OK)
                {
                    Properties += UString(SurfaceArrNLR[n]->GetNpoints()," Npoints          = %d  \n");
                    Properties += UString(SurfaceArrNLR[n]->GetNtri()   ," Ntri             = %d  \n");
                }
                Properties += UString(n," Eps_%d            = ") + UString(eps[n], " %9.5f  // [1/(Ohm cm)] \n");
                Properties += UString(" \n");
            
                if(Pinter==U_POTINTER_LINEAR) Ndim += SurfaceArrNLR[n]->GetNpoints(); 
                else                          Ndim += SurfaceArrNLR[n]->GetNtri();
            }
            Properties += UString(Ndim                        ," MatrixDimension  = %d  \n");
            Properties += UString(GetPotInterTypeText(Pinter) ," PotInterpolation = %s  \n");
            Properties += UString(GetBEMSmoothTypeText(Smooth)," ElementSmoothing = %s  \n");
        }
    }

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType  UHeadModel::TestConsistency(void) const
/*
    Test the consistency the the (multi-sphere) model arguments. If they are
    not constent, set private variables to defaults and return U_ERROR;
    Otherwise, return U_OK;

    Print Set the error message (when applicable) to the .log file.
 */
{
    if(Ns<0 || Ns>MAXSURFACE) 
    {
        CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous number of shells [Ns=%d].\n",Ns);
        return U_ERROR;
    }
    switch(Model)
    {
    case U_CONDMOD_INFINITEMEDIUM:
        {
            if(eps[0] <= 0) 
            {
                CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous conductivity: eps[0]<0. \n");
                return U_ERROR;
            }
            return U_OK;
        }
    case U_CONDMOD_UNKNOWN:
    case U_CONDMOD_SPHERE:
    case U_CONDMOD_HOMSPHERE:
    case U_CONDMOD_THREESPHERE:
    case U_CONDMOD_MULTISPHERE:
        break;

    case U_CONDMOD_BEM:
        if(MR_Markers[0]==UVector3() && MR_Markers[1]==UVector3() && MR_Markers[2]==UVector3())
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous MR-markers.\n");
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Nasion = %s.\n", MR_Markers[0].GetProperties());
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Left   = %s.\n", MR_Markers[1].GetProperties());
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Right  = %s.\n", MR_Markers[2].GetProperties());
            return U_ERROR;
        }
        if(FileNamesValid==true && UPatTree::GetScanOrientation(MRtoWld)==U_ORI_UNKNOWN)
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Unrecognizable MR orientation. MRtoWld : %s  .\n",MRtoWld.GetProperties(NULL));
            return U_ERROR;
        }
        if(NOT(FileNamesValid)) // Filenames do not need to exist at creation of UHeadModel, but surfaces do.
        {
            for(int k=0; k<Ns; k++) 
            {
                if(SurfaceArrNLR[k]==NULL || SurfaceArrNLR[k]->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Surface number %d not (properly) set.\n");
                    return U_ERROR;
                }
            }
        }
        break;

    default:
        CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous head model (not supported).\n");
        return U_ERROR;
    }
    
    for(int j=0; j<Ns; j++)
    {
        if(rs[j]  <= 0 && Model!=U_CONDMOD_BEM) 
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous Radius r[%d]<0.\n",j);
            return U_ERROR;
        }
        if(eps[j] <= 0) 
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous conductivity: eps[%d]<0. \n",j);
            return U_ERROR;
        }
        if(eht[j] <= 0 && Model!=U_CONDMOD_BEM)
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous conductivity: eht[%d]<0. \n",j);
            return U_ERROR;
        }
        if(j==0) continue;

        if(rs[j] > rs[j-1] && Model!=U_CONDMOD_BEM)
        {
            CI.AddToLog("ERROR: UHeadModel::TestConsistency(). Erroneous Radii: r[%d]>r[%d]. \n",j,j-1);
            return U_ERROR;
        }            
    }
    return U_OK;
}

ErrorType UHeadModel::SetMRIMarkers(const UVector3* MR_NLR) 
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MR_NLR==NULL)              return U_ERROR;

    if(MR_NLR[0]==UVector3() || MR_NLR[1]==UVector3() || MR_NLR[2]==UVector3())
    {
        CI.AddToLog("ERROR: UHeadModel::SetMRIMarkers(). Invalid argument(s): Nasion = %s.\n", MR_NLR[0].GetProperties());
        CI.AddToLog("ERROR: UHeadModel::SetMRIMarkers(). Invalid argument(s): Left   = %s.\n", MR_NLR[1].GetProperties());
        CI.AddToLog("ERROR: UHeadModel::SetMRIMarkers(). Invalid argument(s): Right  = %s.\n", MR_NLR[2].GetProperties());
        return U_ERROR;
    }
    MR_Markers[0] = MR_NLR[0];
    MR_Markers[1] = MR_NLR[1];
    MR_Markers[2] = MR_NLR[2];
    return U_OK;
}

ErrorType UHeadModel::WriteHeadModelFileBin(UFileName FName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Object NULL or erroneous. \n"); 
        return U_ERROR;
    }
    if(Model!=U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Object not properly set for writing BEM binary files. \n"); 
        return U_ERROR;
    }
    
    UConductor3 C;
    for(int k=0; k<Ns; k++)
    {
        UNestedSurface* NS = GetNestedSurfaceNLR(k);
        if(NS==NULL || NS->GetError()!=U_OK)
        {
            delete NS;
            CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Getting surface %d. \n", k); 
            return U_ERROR;
        }
        if(C.AddSurface(NS)!=U_OK)
        {
            delete NS;
            CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Adding surface %d  to UConductor3 .\n",k);
            return U_ERROR;
        }
        delete NS;
    }
    bool UseMonoLayer = false;
    UBemMatrix3 BEM(C, Pinter, Smooth, UseMonoLayer);
    if(BEM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Creating BEM object.\n");
        return U_ERROR;
    }
    FILE* fp = fopen(FName,"wb");
    if(BEM.WriteBinary(fp)!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileBin(). Writing as binary file .\n");
        fclose(fp);
        return U_ERROR;
    }
    fclose(fp);
    return U_OK;
}

ErrorType UHeadModel::WriteHeadModelFileTxt(UFileName FileName, const char* Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileTxt(). Object NULL or erroneous. \n"); 
        return U_ERROR;
    }
    if(FileNamesValid==false && Model==U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileTxt(). Object not properly set for writing BEM text files. \n"); 
        return U_ERROR;
    }

    FILE* fp = fopen(FileName,"wt");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileTxt(). Cannot open %s \n",(const char*)FileName); 
        return U_ERROR;
    }

    fprintf(fp,"// Origin: \n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"// \n");
    fprintf(fp,"// The MODEL-parameter can be SPHERE (MEG only), CONCENTRIC_SPHERES or REALISTIC_MODEL.\n");
    fprintf(fp,"// When CONCENTRIC_SPHERES is specifified, one should also give the number of shells,\n");
    fprintf(fp,"// their radii and conductivities (radial and tangential) and their names (optionally).\n");
    fprintf(fp,"// When REALISTIC_MODEL is specified, one should also give the number of surfaces,\n");
    fprintf(fp,"// their conductivitities, their triangle files and their names (optionally)\n");
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"//    MODEL        = SPHERE/CONCENTRIC_SPHERES/REALISTIC_MODEL // (Choose one)\n");
    fprintf(fp,"// \n");
    fprintf(fp,"// In case of SPHERE or CONCENTRIC_SPHERES: \n");
    fprintf(fp,"//    SPHERE_POS   = (x, y, z)        // Posision of the best fitting sphere w.r.t. NLR system \n");
    fprintf(fp,"//    HEAD_RADIUS  =  r               // Radius of the best fitting sphere [cm] through head boundary\n");
    fprintf(fp,"//    ELEC_RADIUS  =  r               // Radius of the best fitting sphere [cm] through electrodes (can be smaller than head radius for sub=surface electrodes). Default is surface electrodes.");
    fprintf(fp,"// \n");
    fprintf(fp,"// In case of CONCENTRIC_SPHERES: \n");
    fprintf(fp,"//    N_SHELL = n                     // Number of concentric spherical shells \n");
    fprintf(fp,"//    for each shell specify: (i from 0 to n-1)\n");
    fprintf(fp,"//       RADIUSi          = r         // radius in [cm] \n");
    fprintf(fp,"//       RADIAL_CONDi     = eps       // radial conductivity [1/(Ohm cm)] \n");
    fprintf(fp,"//       TANGENTIAL_CONDi = eht       // tangential conductivity [1/(Ohm cm)] \n");
    fprintf(fp,"//       SURFACE_NAMEi    = name      // (OPTIONAL) e.g. Brain, Skull, etc. \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// In case of REALISTIC_MODEL: \n");
    fprintf(fp,"//    either: \n");
    fprintf(fp,"//       MR_NASION        = (x, y, z) // Nasion position in MRI (reference) coordinates [cm] \n");
    fprintf(fp,"//       MR_LEFT          = (x, y, z) // Left ear position in MRI (reference) coordinates [cm] \n");
    fprintf(fp,"//       MR_RIGHT         = (x, y, z) // Right ear position in MRI (reference) coordinates [cm] \n");
    fprintf(fp,"//    or: \n");
    fprintf(fp,"//       MR_MARKERFILE    = coor.mri  // Path and file name of the file containing the MRI NLR coordinates \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// The scan_to_wld.xdr transformation is used to rotate/translate BEM surfaces from world to MRI, in case of Patient Tree surfaces.\n");
    fprintf(fp,"// For other surfaces, that are already in MR coordinates, this transformation can be omitted, or set as MR_TOWORLD = 0.,0.,0.,0.,0.,0.\n");
    fprintf(fp,"// Otherwise, \n");
    fprintf(fp,"//    either: \n");
    fprintf(fp,"//       MR_DIRECTORY     = D:\\Data\\Pat.Patient\\MR.scan  // The mr directory containing the scan_to_wld.xdr -file. \n");
    fprintf(fp,"//    or: \n");
    fprintf(fp,"//       MR_TOWORLD       = Tx, Ty, Tz, Rx, Ry, Rz          // Translation [cm] and rotation [RAD] from MRI to World.\n");
    fprintf(fp,"// \n");
    fprintf(fp,"//    INTERPOLATION       = CONSTANT/LINEAR // Potential interpolation method \n");
    fprintf(fp,"//    ELEMENT_SMOOTH      = SMOOTH/NOSMOOTH // Smoothing of the matrix elements \n");    
    fprintf(fp,"//    N_SURFACE           = n         // Number of spherical shells/compartments \n");
    fprintf(fp,"//    for each compartment i specify: (i from 0 to n-1)\n");
    fprintf(fp,"//       TRIANGLE_DIRi    = Directory // Name of of the Conquest directory containing the triangulated head surface\n");
    fprintf(fp,"//       CONDUCTIVITYi    = cond      // conductivity just inside this compartment [1/(Ohm cm)]\n");
    fprintf(fp,"//       SURFACE_NAMEi    = name      // (OPTIONAL) e.g. Brain, Skull, etc. \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// Note:\n");
    fprintf(fp,"// For spherical models, \n");
    fprintf(fp,"// a typical value for skin and brain conductivity is: 0.0032   [1./(Ohm cm)] \n");
    fprintf(fp,"// and a typical value for skull conductivity is:      0.000049 [1./(Ohm cm)] \n");
    fprintf(fp,"// assuming a skull thickness of:                      0.45     [cm]. \n");
    fprintf(fp,"// See S.I. Gon�alves, J.C. de Munck, J.P.A. Verbunt, R.M. Heethaar and F.H. Lopes da Silva \n");
    fprintf(fp,"// In vivo measurement of brain and skull resistivities using an EIT based method and \n");
    fprintf(fp,"// the combined analysis of SEP/SEF data (2003), IEEE Trans Biomed Eng, accepted.\n");
    fprintf(fp,"// \n");
    fprintf(fp,"// For realistic models, \n");
    fprintf(fp,"// a typical value for skin and brain conductivity is: 0.0033   [1./(Ohm cm)] \n");
    fprintf(fp,"// and a typical value for skull conductivity is:      0.000082 [1./(Ohm cm)] \n");
    fprintf(fp,"// See S.I. Gon�alves, J.C. de Munck, J.P.A. Verbunt, F. Bijma, R.M. Heethaar and F.H. Lopes da Silva.\n");
    fprintf(fp,"// In vivo measurement of the Brain and Skull resistivities using an EIT based method and realistic\n"); 
    fprintf(fp,"// models for the head (2003), IEEE Trans. Biomed. Eng,.BME-50(6):754-767. \n");
    fprintf(fp,"// \n");
    fprintf(fp,"// \n");
    if(Comment) 
    {
        UString C(Comment);
        C.InsertAtEachLine("//  ");
        C.WriteText(fp);
    }
    switch(Model)
    {
    case U_CONDMOD_UNKNOWN:
    case U_CONDMOD_SPHERE:
        fprintf(fp,"MODEL       = SPHERE\n");
        fprintf(fp,"SPHERE_POS  = %s\n",SpherePos.GetProperties());
        fprintf(fp,"HEAD_RADIUS = %7.3f   //[cm]\n",HeadRadius);
        break;
    case U_CONDMOD_HOMSPHERE:
    case U_CONDMOD_THREESPHERE:
    case U_CONDMOD_MULTISPHERE:
        fprintf(fp,"MODEL       = CONCENTRIC_SPHERES \n");
        fprintf(fp,"SPHERE_POS  = %s // Position of the best fitting sphere w.r.t. NLR system\n",SpherePos.GetProperties());
        fprintf(fp,"N_SHELL     = %d \n",Ns);
        fprintf(fp,"HEAD_RADIUS = %7.3f   //[cm]\n",HeadRadius);
        fprintf(fp,"ELEC_RADIUS = %7.3f   //[cm]\n",HeadRadius*relec);

        if(MR_Markers[0]!=UVector3() && MR_Markers[1]!=UVector3() && MR_Markers[2]!=UVector3())
        {
            fprintf(fp,"MR_NASION   = %s\n",MR_Markers[0].GetProperties());
            fprintf(fp,"MR_LEFT     = %s\n",MR_Markers[1].GetProperties());
            fprintf(fp,"MR_RIGHT    = %s\n",MR_Markers[2].GetProperties());
        }
        fprintf(fp,"// \n");
        fprintf(fp,"// Notes: RADIUS2< RADIUS1< RADIUS0=HEAD_RADIUS, etc.\n");
        fprintf(fp,"//        The tangential conductivity is optional.\n");
        for(int k=0; k<Ns; k++)
        {
            fprintf(fp,"SURFACE_NAME%d     = %s      \n",k,(const char*)Name[k]);
            fprintf(fp,"RADIUS%d           = %7.3f    // [cm] \n",k,rs[k]*HeadRadius);
            fprintf(fp,"RADIAL_COND%d      = %12.7f   // [1/(Ohm cm)] \n",k,eps[k]);
            fprintf(fp,"TANGENTIAL_COND%d  = %12.7f   // [1/(Ohm cm)]\n",k,eht[k]);
        }
        break;

    case U_CONDMOD_BEM:
        fprintf(fp,"MODEL            = REALISTIC_MODEL \n");
        fprintf(fp,"MR_NASION        = %s\n",MR_Markers[0].GetProperties());
        fprintf(fp,"MR_LEFT          = %s\n",MR_Markers[1].GetProperties());
        fprintf(fp,"MR_RIGHT         = %s\n",MR_Markers[2].GetProperties());
        {
        double par[6] = {0.,0.,0.,0.,0.,0.};
        if(MRtoWld.GetParameters(par)!=U_OK)
        {
            CI.AddToLog("ERROR: UHeadModel::WriteHeadModelFileTxt(). MRtoWld is no pure rotation/translation. \n"); 
            par[5] = par[4] = par[3] = par[2] = par[1] = par[0] = 0.;
        }
        fprintf(fp,"MR_TOWORLD       = %f, %f, %f, %f, %f, %f \n", par[0],par[1],par[2],par[3],par[4],par[5]);
        }
        switch(Pinter)
        {
        case U_POTINTER_CONSTANT:fprintf(fp,"INTERPOLATION    = CONSTANT\n"); break;
        case U_POTINTER_LINEAR:  fprintf(fp,"INTERPOLATION    = LINEAR\n");   break;
        }
        switch(Smooth)
        {
        case U_SMOOTH_SMOOTH:   fprintf(fp,"ELEMENT_SMOOTH   = SMOOTH\n");   break;
        case U_SMOOTH_RAW:      fprintf(fp,"ELEMENT_SMOOTH   = NOSMOOTH\n"); break;
        }
        
        fprintf(fp,"N_SURFACE        = %d \n",Ns);
        for(int k=0; k<Ns; k++)
        {
            fprintf(fp,"CONDUCTIVITY%d    = %12.7f   [1/(Ohm cm)] \n",k,eps[k]);
            fprintf(fp,"SURFACE_NAME%d    = %c%s%c \n",k,'"',(const char*)Name[k],'"');
            fprintf(fp,"TRIANGLE_FILE%d   = %c%s%c \n",k,'"',(const char*)TriFileName[k],'"');
        }
        break;

    default:
        fclose(fp);
        return U_ERROR; // Not yet supported
    }

    fclose(fp);
    return U_OK;
}

/* (Multi) sphere model*/
UVector3 UHeadModel::GetSpherePos(void) const 
{
    if(this==NULL || error!=U_OK) return UVector3();
    if(Model==U_CONDMOD_UNKNOWN || Model==U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetSpherePos(). Object of wrong type (%d). Return values has no meaning\n",Model);
    return SpherePos;
}

double UHeadModel::GetHeadRadius(void) const
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Model==U_CONDMOD_UNKNOWN || Model==U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetHeadRadius(). Object of wrong type (%d). Return values has no meaning\n",Model);
    return HeadRadius;
}

double UHeadModel::GetRelElecRad(void) const
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Model!=U_CONDMOD_MULTISPHERE)
        CI.AddToLog("WARNING: UHeadModel::GetRelElecRad(). Object of wrong type (%d). Return values has no meaning\n",Model);
    return relec;
}
double UHeadModel::GetEps(int j) const    
{
    if(this==NULL || error!=U_OK) return -1.;

    if(Model==U_CONDMOD_UNKNOWN || Model==U_CONDMOD_SPHERE)
        CI.AddToLog("WARNING: UHeadModel::GetEps(). Object of wrong type (%d). Return values has no meaning\n",Model);
    if(j<0 || j>=Ns) 
    {
        CI.AddToLog("EROR: UHeadModel::GetEps(). Index out of range (%d). \n",j);
        return -1;
    }
    return eps[j];
}
ErrorType UHeadModel::SetEps(double ep, int j)
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("WARNING: UHeadModel::SetEps(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(ep<=0.)
    {
        CI.AddToLog("EROR: UHeadModel::SetEps(). Conductivity out of range (%d). \n",ep);
        return U_ERROR;;
    }
    if(j<0 || j>=Ns) 
    {
        CI.AddToLog("EROR: UHeadModel::SetEps(). Index out of range (%d). \n",j);
        return U_ERROR;;
    }
    eps[j] = ep;
    if( Model==U_CONDMOD_HOMSPHERE) eht[j] = ep;
    if( Model==U_CONDMOD_THREESPHERE)
    {
        if(j==0 || j==2) eht[0] = eht[2] = eps[0] = eps[2] = ep;
        else             eps[j] = eps[j] = ep;
    }
    if(SurfaceArrNLR[j] && SurfaceArrNLR[j]->GetError()==U_OK)
    {
        SurfaceArrNLR[j]->SetInnerCond(ep);
        for(int k=0; k<Ns; k++)
        {
            if(SurfaceArrNLR[k]==NULL || SurfaceArrNLR[j]->GetError()!=U_OK) continue;
            if(SurfaceArrNLR[k]->GetParent()==j) SurfaceArrNLR[k]->SetOuterCond(ep);
        }
    }
    return U_OK;
}

double UHeadModel::GetEht(int j) const    
{
    if(this==NULL || error!=U_OK) return -1.;

    if(Model==U_CONDMOD_UNKNOWN || Model==U_CONDMOD_SPHERE || Model==U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetEht(). Object of wrong type (%d). Return values has no meaning\n",Model);
    if(j<0 || j>=Ns) 
    {
        CI.AddToLog("EROR: UHeadModel::GetEht(). Index out of range (%d). \n",j);
        return -1;
    }
    return eht[j];
}

double UHeadModel::GetRs(int j) const    
{
    if(this==NULL || error!=U_OK) return -1.;

    if(Model==U_CONDMOD_UNKNOWN || Model==U_CONDMOD_SPHERE || Model==U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetRs(). Object of wrong type (%d). Return values has no meaning\n",Model);
    if(j<0 || j>=Ns) 
    {
        CI.AddToLog("EROR: UHeadModel::GetRs(). Index out of range (%d). \n",j);
        return -1;
    }
    return rs[j];
}

/* Realistic models*/
UFileName UHeadModel::GetTriFileName(int isurf) const
{
    if (this == NULL || error != U_OK) return UFileName();

    if (Model != U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR:  UHeadModel::GetTriFileName() Model (%d) not a BEM model.\n", int(Model));
        return UFileName();
    }
    if (isurf < 0 || isurf >= Ns)
    {
        CI.AddToLog("ERROR:  UHeadModel::GetTriFileName() Parameter out of range (isurf =%d) Ns=%d   .\n", isurf, Ns);
        return UFileName();
    }
    return UFileName(TriFileName[isurf]);
}
UEuler UHeadModel::GetRef2NLR() const
{
    if (this == NULL || error != U_OK) return UEuler();

    if (Model != U_CONDMOD_BEM)
    {
        CI.AddToLog("ERROR:  UHeadModel::GetTriFileName() Model (%d) not a BEM model.\n", int(Model));
        return UEuler();
    }

    return UEuler(MR_Markers[0], MR_Markers[1], MR_Markers[2]);
}

UVector3 UHeadModel::GetMRmarker(int j) const
{
    if(this==NULL || error!=U_OK) return UVector3();

    if(Model!=U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetMRmarker(). Object of wrong type (%d). Return values has no meaning\n",Model);

    if(j<0||j>=3) 
    {
        CI.AddToLog("ERROR: UHeadModel::GetMRmarker(). Index out of range (%d).\n",j);
        return UVector3();
    }
    return MR_Markers[j];
} 

PotInterPolType UHeadModel::GetPotentalInterpolation() const 
{
    if(Model!=U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetPotentalInterpolation(). Object of wrong type (%d). Return values has no meaning\n",Model);

    return Pinter;
}

BEMSmoothType UHeadModel::GetMatrixSmoothing() const       
{
    if(Model!=U_CONDMOD_BEM)
        CI.AddToLog("WARNING: UHeadModel::GetMatrixSmoothing(). Object of wrong type (%d). Return values has no meaning\n",Model);

    return Smooth;
}
