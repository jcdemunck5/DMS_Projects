#ifndef _HMODEL_INCLUDED
#define _HMODEL_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#define MAXSURFACE      10

#include "Dipole.h"
#include "FileName.h"
#include "Directory.h"
#include "PatTree.h"
#include "String.h"

class UNestedSurface;
class DLL_IO UHeadModel
{
public:
    UHeadModel();     
    UHeadModel(CondModelType Mod);     
    UHeadModel(const UHeadModel& HM);     
    UHeadModel(UVector3 Spos, double Hrad=10.);                                                            // U_CONDMOD_SPHERE
    UHeadModel(double cond, UVector3 Spos, double Hrad=10.);                                               // U_CONDMOD_HOMSPHERE
    UHeadModel(double c1, double c2, double f1, double f2, UVector3 Spos, double Hrad=10.);                // U_CONDMOD_THREESPHERE
    UHeadModel(const double* r, const double* ep, const double* eh, int ns, UVector3 Spos, double R_elec); // U_CONDMOD_MULTISPHERE
    UHeadModel(int Nsurf, UFileName* TriFiles, UString* SurfNames, UEuler MR2W, const UVector3* NLR_MRI,   // U_CONDMOD_BEM
                            const double* cond, PotInterPolType PIP, BEMSmoothType SM);
    UHeadModel(int Nsurf, const UNestedSurface* const*SurfArrMRI, UEuler MR2W, const UVector3* NLR_MRI,    // U_CONDMOD_BEM
                            PotInterPolType PIP, BEMSmoothType SM);

    UHeadModel(UFileName FileNam);                                                                         // General

    virtual ~UHeadModel();
    UHeadModel& operator=(const UHeadModel& HM);

/* General*/
    ErrorType                  GetError(void) const         {if(this) return error; return U_ERROR;}
    const UString&             GetProperties(UString Comment) const;

    CondModelType              GetCondModelType(void) const {if(this) return Model; return U_CONDMOD_UNKNOWN;}
    int                        GetNshell(void) const        {if(this) return Ns;    return 0;}
    UString                    GetSurfaceName(int j) const;

    ErrorType                  WriteHeadModelFileBin(UFileName FName) const;
    ErrorType                  WriteHeadModelFileTxt(UFileName FName, const char* Comment=NULL) const;

    ErrorType                  SetHomogeneousModel(void);
    ErrorType                  SetThreeSphereModel(UVector3 Spos, double Hrad);

/* (Multi) sphere model*/
    UVector3                   GetSpherePos(void) const; 
    double                     GetHeadRadius(void) const;
    double                     GetRelElecRad(void) const;
    double                     GetEps(int j=0) const;    
    ErrorType                  SetEps(double ep, int j);
    double                     GetEht(int j=0) const;    
    double                     GetRs(int j=0) const;  
    const double*              GetEpsArray(void) const {return eps;}

/* Realistic models*/
    ErrorType                  CreateNestedSurfacesBEM(void); // Reads and stores BEM files and sets FileNamesValid=false
    PotInterPolType            GetPotInterPol(void) const           {if(this) return Pinter; return U_POTINTER_UNKNOWN;}
    BEMSmoothType              GetSmoothElem(void) const            {if(this) return Smooth; return U_SMOOTH_UNKNOWN;}
    ErrorType                  SetPotInterPol(PotInterPolType PIPT) {if(this) {Pinter=PIPT; return U_OK;} return U_ERROR;}
    ErrorType                  SetSmoothElem(BEMSmoothType BST)     {if(this) {Smooth=BST ; return U_OK;} return U_ERROR;}

    PotInterPolType            GetPotentalInterpolation() const; 
    BEMSmoothType              GetMatrixSmoothing() const;       
    UNestedSurface*            GetNestedSurfaceNLR(int j) const;
    ErrorType                  SetMRIMarkers(const UVector3* MR_NLR);

    UEuler                     GetMRtoWld(void) const {if(this) return MRtoWld; return UEuler();} // Only used in UDipFileHeader
    UVector3                   GetMRmarker(int j) const;                                          // Only used in UDipFileHeader

    UFileName                  GetTriFileName(int isurf) const;
    UEuler                     GetRef2NLR() const;

protected:
    void                       SetAllMembersDefault(void);
    void                       DeleteAllMembers(ErrorType E);

private:
    ErrorType                  error;           // General error flag
    static UString             Properties;
    
    double                     rs[MAXSURFACE];  // relative sphere radii (fractions of HeadRadius)
    double                     eps[MAXSURFACE]; // radial conductivities
    double                     eht[MAXSURFACE]; // tangential conductivities

//// Multi sphere models
    CondModelType              Model;           // The headmodel catagory
    UVector3                   SpherePos;       // The position of the best fitting sphere of the head w.r.t.NLR
    double                     HeadRadius;      // The radius of the best fitting sphere
    double                     relec;           // the relative radial coordinate of the electrode grid

    int                        Ns;              // number of concentric spheres, compartments, surfaces
    UString                    Name[MAXSURFACE]; // Name of each shell (optinal)

//// The realistic BEM models
    bool                       FileNamesValid;           // If true TriFileName[] and eps[] arrays are valid for BEM, otherwise these values are to be taken from SurfaceArrNLR[]
    UVector3                   MR_Markers[3];            // Coordinates of the Nasion, Left Ear and Right Ear in the MR coordinate system
    UEuler                     MRtoWld;                  // scan_to_wld.xdr of the MR used to define MR markers. Default is UEuler()
    UFileName                  TriFileName[MAXSURFACE];  // Directory names where the realistic triangulations can be found. 
    UNestedSurface*            SurfaceArrNLR[MAXSURFACE];// Array with nested surfaces in NLR coordinates as alternative BEM representation

    PotInterPolType            Pinter;
    BEMSmoothType              Smooth;

    ErrorType                  ReadMRmarkers(UFileName FileName);

//// General
    ErrorType                  TestConsistency(void) const;
};

#endif // _HMODEL_INCLUDED
