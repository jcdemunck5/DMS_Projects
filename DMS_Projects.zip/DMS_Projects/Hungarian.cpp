/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     This class solves the optimal ICostMat assign probem using the Hungarian  */
/*     method,                                                                   */
/*                                                                               */
/*     TO DO: Testing with numerical tolerance in case of double                 */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  Jdm    30-10-10   Creation, adaptation of code libhungarian by Cyrill Stachniss, 2004
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include <stdio.h>
#include <stdlib.h>
#include "Hungarian.h"


#define INF  (0x7FFFFFFF)
#define DINF  1.79769e+308

#define HUNGARIAN_NOT_ASSIGNED 0 
#define HUNGARIAN_ASSIGNED     1


#define verbose (0)

void UHungarian::SetAllMembersDefault(void)
{
    error           = U_OK;
    Nrowcol         = 0;
    ICostMat        = NULL;
    DCostMat        = NULL;
    AssignmentArray = NULL;
    MinMax          = MMTYPE_MINIMIZE;
}

void UHungarian::DeleteAllMembers(ErrorType E)
{
    if(ICostMat && Nrowcol>0) for(int i=0; i<Nrowcol; i++) delete[] ICostMat[i];
    if(DCostMat && Nrowcol>0) for(int i=0; i<Nrowcol; i++) delete[] DCostMat[i];

    delete[] ICostMat;
    delete[] DCostMat;
    delete[] AssignmentArray;
    SetAllMembersDefault();
    error = E;
}

UHungarian::UHungarian()
{
    SetAllMembersDefault();
}
UHungarian::~UHungarian()
{
    DeleteAllMembers(U_OK);
}

UHungarian::UHungarian(int** CostMatrix, int nrow, int ncol, MMType Mode)
{
    SetAllMembersDefault();

    if(CostMatrix==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nrow<=0 || ncol<=0)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid nrow (=%d) or ncol (=%d) argument. \n", nrow, ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Mode!=MMTYPE_MINIMIZE && Mode!=MMTYPE_MAXIMIZE) 
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid Mode-parameter (Mode = %d). \n", Mode);
        DeleteAllMembers(U_ERROR);
        return;
    }
    MinMax          = Mode;
    Nrowcol         = MAX(nrow, ncol);
    ICostMat        = new int*[Nrowcol];
    AssignmentArray = new int [Nrowcol];
    if(ICostMat==NULL || AssignmentArray==NULL)
    {
        delete[] ICostMat;   ICostMat = NULL;
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation, Nrowcol = %d \n", Nrowcol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int i=0; i<Nrowcol; i++) ICostMat[i] = NULL;
    for(int i=0; i<Nrowcol; i++) 
    {
        AssignmentArray[i] = -1;
        ICostMat[i]        = new int[Nrowcol];
        if(ICostMat[i]==NULL)
        {
            CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation error in row %d. \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int j=0; j<Nrowcol; j++) ICostMat[i][j] = 0;
        if(i<nrow)
        {
            if(CostMatrix[i]==NULL)
            {
                CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer in CostMatrix at row %d. \n", i);
                DeleteAllMembers(U_ERROR);
                return;
            }
            for(int j=0; j<ncol; j++) 
            {
                if(CostMatrix[i][j]<0)
                {
                    CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid (negative) cost matrix element: Cost[%d,%d] = %d . \n", i,j,CostMatrix[i][j]);
                    DeleteAllMembers(U_ERROR);
                    return;
                }
                ICostMat[i][j] = CostMatrix[i][j];
            }
        }
    }
}
UHungarian::UHungarian(const int* CostMatrix, int nrow, int ncol, MMType Mode)
{
    SetAllMembersDefault();

    if(CostMatrix==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nrow<=0 || ncol<=0)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid nrow (=%d) or ncol (=%d) argument. \n", nrow, ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Mode!=MMTYPE_MINIMIZE && Mode!=MMTYPE_MAXIMIZE) 
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid Mode-parameter (Mode = %d). \n", Mode);
        DeleteAllMembers(U_ERROR);
        return;
    }
    MinMax          = Mode;
    Nrowcol         = MAX(nrow, ncol);
    ICostMat        = new int*[Nrowcol];
    AssignmentArray = new int [Nrowcol];
    if(ICostMat==NULL || AssignmentArray==NULL)
    {
        delete[] ICostMat;   ICostMat = NULL;
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation, Nrowcol = %d \n", Nrowcol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int i=0; i<Nrowcol; i++) ICostMat[i] = NULL;
    for(int i=0; i<Nrowcol; i++) 
    {
        AssignmentArray[i] = -1;
        ICostMat[i]        = new int[Nrowcol];
        if(ICostMat[i]==NULL)
        {
            CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation error in row %d. \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int j=0; j<Nrowcol; j++) ICostMat[i][j] = 0;
        if(i<nrow)
        {
            for(int j=0; j<ncol; j++) 
            {
                if(CostMatrix[i*ncol+j]<0)
                {
                    CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid (negative) cost matrix element: Cost[%d,%d] = %d . \n", i,j,CostMatrix[i*ncol+j]);
                    DeleteAllMembers(U_ERROR);
                    return;
                }
                ICostMat[i][j] = CostMatrix[i*ncol+j];
            }
        }
    }
}

UHungarian::UHungarian(double** CostMatrix, int nrow, int ncol, MMType Mode)
{
    SetAllMembersDefault();

    if(CostMatrix==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nrow<=0 || ncol<=0)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid nrow (=%d) or ncol (=%d) argument. \n", nrow, ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Mode!=MMTYPE_MINIMIZE && Mode!=MMTYPE_MAXIMIZE) 
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid Mode-parameter (Mode = %d). \n", Mode);
        DeleteAllMembers(U_ERROR);
        return;
    }
    MinMax          = Mode;
    Nrowcol         = MAX(nrow, ncol);
    DCostMat        = new double*[Nrowcol];
    AssignmentArray = new int    [Nrowcol];
    if(DCostMat==NULL || AssignmentArray==NULL)
    {
        delete[] DCostMat;   DCostMat = NULL;
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation, Nrowcol = %d \n", Nrowcol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int i=0; i<Nrowcol; i++) DCostMat[i] = NULL;
    for(int i=0; i<Nrowcol; i++) 
    {
        AssignmentArray[i] = -1;
        DCostMat[i]        = new double[Nrowcol];
        if(DCostMat[i]==NULL)
        {
            CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation error in row %d. \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int j=0; j<Nrowcol; j++) DCostMat[i][j] = 0.;
        if(i<nrow)
        {
            if(CostMatrix[i]==NULL)
            {
                CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer in CostMatrix at row %d. \n", i);
                DeleteAllMembers(U_ERROR);
                return;
            }
            for(int j=0; j<ncol; j++) 
            {
                if(CostMatrix[i][j]<0.)
                {
                    CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid (negative) cost matrix element: Cost[%d,%d] = %f . \n", i,j,CostMatrix[i][j]);
                    DeleteAllMembers(U_ERROR);
                    return;
                }
                DCostMat[i][j] = CostMatrix[i][j];
            }
        }
    }
}
UHungarian::UHungarian(const double* CostMatrix, int nrow, int ncol, MMType Mode)
{
    SetAllMembersDefault();

    if(CostMatrix==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(nrow<=0 || ncol<=0)
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid nrow (=%d) or ncol (=%d) argument. \n", nrow, ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Mode!=MMTYPE_MINIMIZE && Mode!=MMTYPE_MAXIMIZE) 
    {
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid Mode-parameter (Mode = %d). \n", Mode);
        DeleteAllMembers(U_ERROR);
        return;
    }
    MinMax          = Mode;
    Nrowcol         = MAX(nrow, ncol);
    DCostMat        = new double*[Nrowcol];
    AssignmentArray = new int    [Nrowcol];
    if(DCostMat==NULL || AssignmentArray==NULL)
    {
        delete[] DCostMat;   DCostMat = NULL;
        CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation, Nrowcol = %d \n", Nrowcol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int i=0; i<Nrowcol; i++) DCostMat[i] = NULL;
    for(int i=0; i<Nrowcol; i++) 
    {
        AssignmentArray[i] = -1;
        DCostMat[i]        = new double[Nrowcol];
        if(DCostMat[i]==NULL)
        {
            CI.AddToLog("ERROR: UHungarian::UHungarian(). Memory allocation error in row %d. \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int j=0; j<Nrowcol; j++) DCostMat[i][j] = 0.;
        if(i<nrow)
        {
            for(int j=0; j<ncol; j++) 
            {
                if(CostMatrix[i*ncol+j]<0.)
                {
                    CI.AddToLog("ERROR: UHungarian::UHungarian(). Invalid (negative) cost matrix element: Cost[%d,%d] = %f . \n", i,j,CostMatrix[i*ncol+j]);
                    DeleteAllMembers(U_ERROR);
                    return;
                }
                DCostMat[i][j] = CostMatrix[i*ncol+j];
            }
        }
    }
}

const int* UHungarian::GetAssignment(int* BestCost) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Nrowcol<=0 || ICostMat==NULL || AssignmentArray==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Object not properly set (Nrowcol=%d). \n", Nrowcol);
        return NULL;
    }

    int* col_mate     = new int[Nrowcol];
    int* row_mate     = new int[Nrowcol];
    int* unchosen_row = new int[Nrowcol];
    int* parent_row   = new int[Nrowcol];    
    int* slack_row    = new int[Nrowcol];

    int* slack        = new int[Nrowcol];    
    int* row_dec      = new int[Nrowcol];
    int* col_inc      = new int[Nrowcol];
    int* CostTemp     = new int[Nrowcol*Nrowcol];

    if(CostTemp)
    {
        for(int i=0,ij=0;i<Nrowcol;i++)    
            for(int j=0;j<Nrowcol;j++, ij++) CostTemp[ij] = ICostMat[i][j];
    }
    else
    {
        CI.AddToLog("WARNING: UHungarian::GetAssignment(). Not enough memory to restore ICostMat[] (Nrowcol=%d)  \n", Nrowcol);
    }
    if(col_mate==NULL || row_mate==NULL || unchosen_row==NULL || parent_row==NULL || slack_row==NULL ||
       slack   ==NULL || row_dec ==NULL || col_inc     ==NULL)
    {
        delete[] CostTemp;
        delete[] col_mate; delete[] row_mate; delete[] unchosen_row; delete[] parent_row; delete[] slack_row;        
        delete[] row_dec;  delete[] col_inc;  delete[] slack;
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Memory allocation: Nrowcol=%d  \n", Nrowcol);
        return NULL;
    }
    for(int i=0;i<Nrowcol;i++) col_mate[i] = row_mate[i] = unchosen_row[i] = parent_row[i] = slack_row[i] = 0;
    for(int j=0;j<Nrowcol;j++) slack[j]    = row_dec[j]  = col_inc[j] = 0;

    if(MinMax!=MMTYPE_MINIMIZE)
    {
        int Cmax = 0;
        for(int i=0,ij=0;i<Nrowcol;i++)    
            for(int j=0;j<Nrowcol;j++, ij++) if(Cmax<ICostMat[i][j]) Cmax = ICostMat[i][j];

        for(int i=0; i<Nrowcol; i++) 
            for(int j=0; j<Nrowcol; j++) ICostMat[i][j] =  Cmax-ICostMat[i][j];
    }
// Begin subtract column minima in order to start with lots of zeroes 12
    if(verbose)  CI.AddToLog("Note: Using heuristic\n");

    int unmatched = 0;
    int Cost      = 0;
    for(int l=0;l<Nrowcol;l++)
    {
        int s=ICostMat[0][l];
        for(int k=1;k<Nrowcol;k++) if(ICostMat[k][l]<s) s=ICostMat[k][l];
        Cost+=s;
        for(int k=0;k<Nrowcol;k++)    ICostMat[k][l]-=s;
    }
// End subtract column minima in order to start with lots of zeroes 12

// Begin initial state 16
    int t=0;
    for(int l=0;l<Nrowcol;l++)
    {
        row_mate[l]   = -1;
        parent_row[l] = -1;
        col_inc[l]    =  0;
        slack[l]      =  INF;
    }
    for(int k=0;k<Nrowcol;k++)
    {
        int s=ICostMat[k][0];
        for(int l=1;l<Nrowcol;l++) if(ICostMat[k][l]<s) s=ICostMat[k][l];
        row_dec[k] = s;
        bool Break = false;
        for(int l=0;l<Nrowcol;l++)
        {
            if(s==ICostMat[k][l] && row_mate[l]<0)
            {
                col_mate[k]=l;
                row_mate[l]=k;
                if(verbose) CI.AddToLog("Note: matching col %d==row %d\n",l,k);
                Break = true;
                break;
            }
        }
        if(Break==true) continue;

        col_mate[k]= -1;
        if(verbose)  CI.AddToLog("Note: node %d: unmatched row %d\n",t,k);
        unchosen_row[t++]=k;
    }
// End initial state 16
 
// Begin Hungarian algorithm 18
    if(t==0) goto done;
    
    int k, l;
    unmatched=t;
    while(1)
    {
        if(verbose) CI.AddToLog("Note: Matched %d rows.\n",Nrowcol-t);
        int q = 0;
        while(1)
        {
            while(q<t)
            {    // Begin explore node q of the forest 19
                k=unchosen_row[q];
                int s=row_dec[k];
                for(l=0;l<Nrowcol;l++)
                {
                    if(slack[l])
                    {
                        int del = ICostMat[k][l]-s+col_inc[l];
                        if(del<slack[l])
                        {
                            if(del==0)
                            {
                                if(row_mate[l]<0)  goto breakthru;

                                slack[l]     =0;
                                parent_row[l]=k;
                                if(verbose) CI.AddToLog("Note: node %d: row %d==col %d--row %d\n", t,row_mate[l],l,k);
                                unchosen_row[t++]=row_mate[l];
                            }
                            else
                            {
                                slack[l]    = del;
                                slack_row[l]= k;
                            }
                        }
                    } 
                }
                q++; // End explore node q of the forest 19
            }
 
            // Begin introduce a new zero into the matrix 21
            int s=INF;
            for(l=0;l<Nrowcol;l++) if(slack[l] && slack[l]<s)   s=slack[l];
            for(q=0;q<t      ;q++) row_dec[unchosen_row[q]]+=s;
            for(l=0;l<Nrowcol;l++)
            {
                if(slack[l])
                {
                    slack[l]-=s;
                    if(slack[l]==0)
                    {        // Begin look at a new zero 22            
                        k=slack_row[l];
                        if(verbose) CI.AddToLog("Note: Decreasing uncovered elements by %d produces zero at [%d,%d]\n", s,k,l);
                        if(row_mate[l]<0)
                        {
                            for(int j=l+1;j<Nrowcol;j++) if(slack[j]==0) col_inc[j]+=s;
                            goto breakthru;
                        }
                        else
                        {
                            parent_row[l]=k;
                            if(verbose) CI.AddToLog("Note: node %d: row %d==col %d--row %d\n",t,row_mate[l],l,k);
                            unchosen_row[t++]=row_mate[l];
                        } // End look at a new zero 22
                    } 
                }
                else
                    col_inc[l]+=s;
            }
            // End introduce a new zero into the matrix 21
        }

breakthru:
      // Begin update the matching 20
        if(verbose)  CI.AddToLog("Note: Breakthrough at node %d of %d!\n",q,t);
        while(1)
        {
            int j=col_mate[k];
            col_mate[k]=l;
            row_mate[l]=k;
            if(verbose) CI.AddToLog("Note: rematching col %d==row %d\n",l,k);
            if(j<0)  break;
            k=parent_row[j];
            l=j;
        }
      // End update the matching 20
      
        if(--unmatched==0)goto done;
      // Begin get ready for another stage 17
        t=0;
        for(l=0;l<Nrowcol;l++)
        {
            parent_row[l]= -1;
            slack[l]=INF;
        }
        for(k=0;k<Nrowcol;k++)
            if(col_mate[k]<0)
            {
                if(verbose) CI.AddToLog("Note: node %d: unmatched row %d\n",t,k);
                unchosen_row[t++]=k;
            } 
      // End get ready for another stage 17
    }


 done:

// Begin doublecheck the solution 23
    ErrorType E = U_OK;
    for(int k=0;k<Nrowcol;k++)
        for(int l=0;l<Nrowcol;l++)
            if(ICostMat[k][l]<row_dec[k]-col_inc[l]) E=U_ERROR;

    if(E==U_OK)
    {
        for(int k=0;k<Nrowcol;k++)
        {
            int l=col_mate[k];
            if(l<0 || ICostMat[k][l]!=row_dec[k]-col_inc[l]) E=U_ERROR;
        }
        if(E==U_OK)
        {
            int k=0; for(int l=0;l<Nrowcol;l++) if(col_inc[l]) k++;                
            if(k>Nrowcol) E=U_ERROR;
        }
    }
// End doublecheck the solution 23
// End Hungarian algorithm 18

    if(E==U_OK)
    {
        for(int i=0;i<Nrowcol;++i) AssignmentArray[i] = col_mate[i];
        for(int k=0;k<Nrowcol;++k)
            for(int l=0;l<Nrowcol;++l)
                ICostMat[k][l]=ICostMat[k][l]-row_dec[k]+col_inc[l];

        for(int i=0;i<Nrowcol;i++) Cost+=row_dec[i];
        for(int i=0;i<Nrowcol;i++) Cost-=col_inc[i];

        if(verbose) CI.AddToLog("Note: Cost is %d\n",Cost);

        if(CostTemp)
        {
            for(int i=0,ij=0;i<Nrowcol;i++)    
                for(int j=0;j<Nrowcol;j++, ij++) 
                    ICostMat[i][j] = CostTemp[ij];
        }    
    }
    delete[] CostTemp;
    delete[] col_mate; delete[] row_mate; delete[] unchosen_row; delete[] parent_row; delete[] slack_row;        
    delete[] row_dec;  delete[] col_inc;  delete[] slack;

    if(E!=U_OK) return NULL;

    if(BestCost) *BestCost = Cost;
////    {
////        int C = 0;
////        for(int i=0; i<Nrowcol; i++) C+=ICostMat[i][AssignmentArray[i]];
////        *BestCost = C;
////    }
    return AssignmentArray;
}

const int* UHungarian::GetAssignment(double* BestCost) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Nrowcol<=0 || DCostMat==NULL || AssignmentArray==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Object not properly set (Nrowcol=%d). \n", Nrowcol);
        return NULL;
    }

    int* col_mate     = new int[Nrowcol];
    int* row_mate     = new int[Nrowcol];
    int* unchosen_row = new int[Nrowcol];
    int* parent_row   = new int[Nrowcol];    
    int* slack_row    = new int[Nrowcol];

    double* slack     = new double[Nrowcol];    
    double* row_dec   = new double[Nrowcol];
    double* col_inc   = new double[Nrowcol];
    double* CostTemp  = new double[Nrowcol*Nrowcol];

    if(CostTemp)
    {
        for(int i=0,ij=0;i<Nrowcol;i++)    
            for(int j=0;j<Nrowcol;j++, ij++) CostTemp[ij] = DCostMat[i][j];
    }
    else
    {
        CI.AddToLog("WARNING: UHungarian::GetAssignment(). Not enough memory to restore DCostMat[] (Nrowcol=%d)  \n", Nrowcol);
    }
    if(col_mate==NULL || row_mate==NULL || unchosen_row==NULL || parent_row==NULL || slack_row==NULL ||
       slack   ==NULL || row_dec ==NULL || col_inc     ==NULL)
    {
        delete[] CostTemp;
        delete[] col_mate; delete[] row_mate; delete[] unchosen_row; delete[] parent_row; delete[] slack_row;        
        delete[] row_dec;  delete[] col_inc;  delete[] slack;
        CI.AddToLog("ERROR: UHungarian::GetAssignment(). Memory allocation: Nrowcol=%d  \n", Nrowcol);
        return NULL;
    }
    for(int i=0;i<Nrowcol;i++) col_mate[i] = row_mate[i] = unchosen_row[i] = parent_row[i] = slack_row[i] = 0;
    for(int j=0;j<Nrowcol;j++) slack[j]    = row_dec[j]  = col_inc[j] = 0.;

    if(MinMax!=MMTYPE_MINIMIZE)
    {
        double Cmax = 0;
        for(int i=0,ij=0;i<Nrowcol;i++)    
            for(int j=0;j<Nrowcol;j++, ij++) if(Cmax<DCostMat[i][j]) Cmax = DCostMat[i][j];

        for(int i=0; i<Nrowcol; i++) 
            for(int j=0; j<Nrowcol; j++) DCostMat[i][j] =  Cmax-DCostMat[i][j];
    }
// Begin subtract column minima in order to start with lots of zeroes 12
    if(verbose)  CI.AddToLog("Note: Using heuristic\n");

    int    unmatched = 0;
    double Cost      = 0;
    for(int l=0;l<Nrowcol;l++)
    {
        double s = DCostMat[0][l];
        for(int k=1;k<Nrowcol;k++) if(DCostMat[k][l]<s) s=DCostMat[k][l];
        Cost += s;
        for(int k=0;k<Nrowcol;k++)    DCostMat[k][l]-=s;
    }
// End subtract column minima in order to start with lots of zeroes 12

// Begin initial state 16
    int t=0;
    for(int l=0;l<Nrowcol;l++)
    {
        row_mate[l]   = -1;
        parent_row[l] = -1;
        col_inc[l]    =  0.;
        slack[l]      =  DINF;
    }
    for(int k=0;k<Nrowcol;k++)
    {
        double s = DCostMat[k][0];
        for(int l=1;l<Nrowcol;l++) if(DCostMat[k][l]<s) s=DCostMat[k][l];
        row_dec[k] = s;
        bool Break = false;
        for(int l=0;l<Nrowcol;l++)
        {
            if(s==DCostMat[k][l] && row_mate[l]<0)
            {
                col_mate[k]=l;
                row_mate[l]=k;
                if(verbose) CI.AddToLog("Note: matching col %d==row %d\n",l,k);
                Break = true;
                break;
            }
        }
        if(Break==true) continue;

        col_mate[k]= -1;
        if(verbose)  CI.AddToLog("Note: node %d: unmatched row %d\n",t,k);
        unchosen_row[t++]=k;
    }
// End initial state 16
 
// Begin Hungarian algorithm 18
    if(t==0) goto done;
    
    int  k, l;
    unmatched=t;
    while(1)
    {
        if(verbose) CI.AddToLog("Note: Matched %d rows.\n",Nrowcol-t);
        int q = 0;
        while(1)
        {
            while(q<t)
            {    // Begin explore node q of the forest 19
                k=unchosen_row[q];
                double s=row_dec[k];
                for(l=0;l<Nrowcol;l++)
                {
                    if(slack[l]!=0.)
                    {
                        double del = DCostMat[k][l]-s+col_inc[l];
                        if(del<slack[l]) //// Tolerance ???
                        {
                            if(del==0.)  //// Tolerance ???
                            {
                                if(row_mate[l]<0)  goto breakthru;

                                slack[l]     =0;
                                parent_row[l]=k;
                                if(verbose) CI.AddToLog("Note: node %d: row %d==col %d--row %d\n", t,row_mate[l],l,k);
                                unchosen_row[t++]=row_mate[l];
                            }
                            else
                            {
                                slack[l]    = del;
                                slack_row[l]= k;
                            }
                        }
                    } 
                }
                q++; // End explore node q of the forest 19
            }
 
            // Begin introduce a new zero into the matrix 21
            double s=DINF;
            for(l=0;l<Nrowcol;l++) if(slack[l]!=0. && slack[l]<s) s=slack[l]; //// Tolerance ???
            for(q=0;q<t      ;q++) row_dec[unchosen_row[q]]+=s;
            for(l=0;l<Nrowcol;l++)
            {
                if(slack[l]!=0.)            //// Tolerance ???
                {
                    slack[l]-=s;
                    if(slack[l]==0.)        //// Tolerance ???
                    {        // Begin look at a new zero 22            
                        k=slack_row[l];
                        if(verbose) CI.AddToLog("Note: Decreasing uncovered elements by %d produces zero at [%d,%d]\n", s,k,l);
                        if(row_mate[l]<0)   
                        {
                            for(int j=l+1;j<Nrowcol;j++) if(slack[j]==0.) col_inc[j]+=s; //// Tolerance ???
                            goto breakthru;
                        }
                        else
                        {
                            parent_row[l]=k;
                            if(verbose) CI.AddToLog("Note: node %d: row %d==col %d--row %d\n",t,row_mate[l],l,k);
                            unchosen_row[t++]=row_mate[l];
                        } // End look at a new zero 22
                    } 
                }
                else
                    col_inc[l]+=s;
            }
            // End introduce a new zero into the matrix 21
        }

breakthru:
      // Begin update the matching 20
        if(verbose)  CI.AddToLog("Note: Breakthrough at node %d of %d!\n",q,t);
        while(1)
        {
            int j=col_mate[k];
            col_mate[k]=l;
            row_mate[l]=k;
            if(verbose) CI.AddToLog("Note: rematching col %d==row %d\n",l,k);
            if(j<0)  break;
            k=parent_row[j];
            l=j;
        }
      // End update the matching 20
      
        if(--unmatched==0)goto done;
      // Begin get ready for another stage 17
        t=0;
        for(l=0;l<Nrowcol;l++)
        {
            parent_row[l]= -1;
            slack[l]=INF;
        }
        for(k=0;k<Nrowcol;k++)
            if(col_mate[k]<0)
            {
                if(verbose) CI.AddToLog("Note: node %d: unmatched row %d\n",t,k);
                unchosen_row[t++]=k;
            } 
      // End get ready for another stage 17
    }


 done:

// Begin doublecheck the solution 23
    const double EPS = 1.e-12;
    ErrorType    E   = U_OK;
    for(int k=0;k<Nrowcol;k++)
        for(int l=0;l<Nrowcol;l++)
            if((DCostMat[k][l] - (row_dec[k]-col_inc[l])) < -EPS)  E=U_ERROR;

    if(E==U_OK)
    {
        for(int k=0;k<Nrowcol;k++)
        {
            int l=col_mate[k];
            if(l<0 || (DCostMat[k][l] - (row_dec[k]-col_inc[l])>EPS)) E=U_ERROR;
        }
        if(E==U_OK)
        {
            int k=0; for(int l=0;l<Nrowcol;l++) if(col_inc[l]) k++;                
            if(k>Nrowcol) E=U_ERROR;
        }
    }
// End doublecheck the solution 23
// End Hungarian algorithm 18

    if(E==U_OK)
    {
        for(int i=0;i<Nrowcol;++i) AssignmentArray[i] = col_mate[i];
        for(int k=0;k<Nrowcol;++k)
            for(int l=0;l<Nrowcol;++l)
                DCostMat[k][l] = DCostMat[k][l]-row_dec[k]+col_inc[l];

        for(int i=0;i<Nrowcol;i++) Cost+=row_dec[i];
        for(int i=0;i<Nrowcol;i++) Cost-=col_inc[i];

        if(verbose) CI.AddToLog("Note: Cost is %d\n",Cost);

        if(CostTemp)
        {
            for(int i=0,ij=0;i<Nrowcol;i++)    
                for(int j=0;j<Nrowcol;j++, ij++) 
                    DCostMat[i][j] = CostTemp[ij];
        }    
    }
    delete[] CostTemp;
    delete[] col_mate; delete[] row_mate; delete[] unchosen_row; delete[] parent_row; delete[] slack_row;        
    delete[] row_dec;  delete[] col_inc;  delete[] slack;

    if(E!=U_OK) return NULL;

    if(BestCost) *BestCost = Cost;
////    {
////        int C = 0;
////        for(int i=0; i<Nrowcol; i++) C+=DCostMat[i][AssignmentArray[i]];
////        *BestCost = C;
////    }
    return AssignmentArray;
}

int UHungarian::GetICost(int ir, int ic)
{
    if(this==NULL || error!=U_OK || ICostMat==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::GetICost(). Object NULL or erroneously set.\n");
        return 0;
    }
    if(ir<0 || ir>=Nrowcol || ic<0 || ic>=Nrowcol)
    {
        CI.AddToLog("ERROR: UHungarian::GetICost(). Argument(s) out of range: ir=%d, ic = %d.\n", ir, ic);
        return 0;
    }
    return ICostMat[ir][ic];
}
double UHungarian::GetDCost(int ir, int ic)
{
    if(this==NULL || error!=U_OK || DCostMat==NULL)
    {
        CI.AddToLog("ERROR: UHungarian::GetDCost(). Object NULL or erroneously set.\n");
        return 0;
    }
    if(ir<0 || ir>=Nrowcol || ic<0 || ic>=Nrowcol)
    {
        CI.AddToLog("ERROR: UHungarian::GetDCost(). Argument(s) out of range: ir=%d, ic = %d.\n", ir, ic);
        return 0;
    }
    return DCostMat[ir][ic];
}

int* FindOptimalPath(unsigned char* Points, int Veclen, int Npoints)
{
    if(Points==NULL)
    {
        CI.AddToLog("ERROR: FindOptimalPath(). Invalid NULL pointer argument. \n");
        return NULL;
    }
    if(Veclen<=0 || Npoints<=0)
    {
        CI.AddToLog("ERROR: FindOptimalPath(). Invalid argument(s): Veclen=%d, Npoints=%d . \n", Veclen, Npoints);
        return NULL;
    }
    
    int* CostMatrix = new int[Npoints*Npoints];
    int* Path       = new int[Npoints];
    if(CostMatrix==NULL || Path==NULL)
    {
        delete[] CostMatrix;
        delete[] Path;
        CI.AddToLog("ERROR: FindOptimalPath(). Memory allocation,  Npoints=%d . \n", Npoints);
        return NULL;
    }
    for(int i2=0; i2<Npoints; i2++)
    {
        Path[i2] = 0;
        for(int i1=0; i1<Npoints; i1++)
        {
            if(i1<i2)
            {
                CostMatrix[i2*Npoints+i1] = CostMatrix[i1*Npoints+i2];
            }
            else if(i1==i2)
            {
                CostMatrix[i2*Npoints+i1] = INF;
            }
            else
            {
                int Cost = 0;
                for(int k=0; k<Veclen; k++) 
                    Cost = abs(Points[i1*Veclen+k]-Points[i2*Veclen+k]);
                CostMatrix[i2*Npoints+i1] = Cost;
            }
        }
    }

    UHungarian Hun(CostMatrix, Npoints, Npoints, MMTYPE_MINIMIZE);
    delete[] CostMatrix;
    if(Hun.GetError()!=U_OK)
    {
        delete[] Path;
        CI.AddToLog("ERROR: FindOptimalPath(). Creating UHungarian-object.\n");
        return NULL;
    }
    int        BestCost = 0;
    const int* Assign   = Hun.GetAssignment(&BestCost);    
    if(Assign==NULL)
    {
        delete[] Path;
        CI.AddToLog("ERROR: FindOptimalPath(). Running Hungarian-algorithm.\n");
        return NULL;
    }

/* Compute path */
    for(int i=0; i<Npoints; i++) Path[i] = -1;

    int ip   = 0;
    int is   = 0;  // Start at first point    
    Path[ip] = is; 
    int in   = Assign[Path[ip]];
    ip++;
    while(ip<Npoints)
    {
        while(in!=is && ip<Npoints) 
        {
            Path[ip] = in;
            in       = Assign[Path[ip]];
            ip++;
        }
        if(ip>=Npoints) break;

        int ICostMin = Hun.GetICost(ip-1, ip-1);
        for(int k=0; k<Npoints; k++) 
        {
            if(Path[k]>=0) continue; 
            if(Hun.GetICost(ip-1, k)>=ICostMin) continue;
            is       = k;
            ICostMin = Hun.GetICost(ip-1, k);
        }
        Path[ip] = is;
        in       = Assign[Path[ip]];
        ip++;
    }
    return Path;
}
