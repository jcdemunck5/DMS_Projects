#ifndef HUNGARIAN_H
#define HUNGARIAN_H

#include "BasicInclude.h"
  
#define HUNGARIAN_MODE_MINIMIZE_COST   0
#define HUNGARIAN_MODE_MAXIMIZE_UTIL   1

enum MMType
{
    MMTYPE_MINIMIZE,
    MMTYPE_MAXIMIZE
};

class DLL_IO UHungarian
{
public:
    UHungarian();
    UHungarian(int**         CostMatrix, int nrow, int ncol, MMType Mode=MMTYPE_MINIMIZE);
    UHungarian(const int*    CostMatrix, int nrow, int ncol, MMType Mode=MMTYPE_MINIMIZE);
    UHungarian(double**      CostMatrix, int nrow, int ncol, MMType Mode=MMTYPE_MINIMIZE);
    UHungarian(const double* CostMatrix, int nrow, int ncol, MMType Mode=MMTYPE_MINIMIZE);
    ~UHungarian();

    ErrorType   GetError(void) const {if(this) return error; return U_ERROR;}
    const int*  GetAssignment(int* BestCost) const;
    const int*  GetAssignment(double* BestCost) const;

    int         GetICost(int ir, int ic);
    double      GetDCost(int ir, int ic);
protected:
    void        SetAllMembersDefault(void);
    void        DeleteAllMembers(ErrorType E);

private:
    ErrorType   error;
    int         Nrowcol;
    int**       ICostMat;
    double**    DCostMat;
    int*        AssignmentArray;
    MMType      MinMax;
};

int* FindOptimalPath(unsigned char* Points, int Veclen, int Npoints);

#endif // HUNGARIAN_H
