/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    15-05-14   creation, adapted from Elmar Wiedemeijer
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    15-02-18   Added GetDeMixingMatrixML()
*/


#include "ICAfast.h"
#include "MatrixSquare.h"


//contrast functions used for FastICA algorithm
PMT_CCP DLL_IO GetICATypeText(ICAType IT)
{
    switch(IT)
    {
    case U_ICA_TANH:        return "Tanh_ICAContrast";
    case U_ICA_POW4:        return "Pow4_ICAContrast"; 
    case U_ICA_LOGCOSH:     return "LogCosh_ICAContrast";
    case U_ICA_NTYPE:       return "Undefined_ICAContrast";
    }
    return "Unkown_ICAContrast";
}

static const double a = 1.;     //constant used in functions, 1<=a<=2 according to Hyv�rinen
static double G_MinTanh   (double x) {return (-tanh(x));}
static double G_Tanh      (double x) {return(tanh(a*x)/a);}
static double G_TanhDer   (double x) {return(1-SQR(tanh(a*x)));}
static double G_Pow4      (double x) {double x2 = SQR(a*x);return SQR(x2)/a;}
static double G_Pow4Der   (double x) {double ax =a*x; return 4*ax*SQR(ax);}
static double G_LogCosh   (double x) {return(log(cosh(a*x))/a);}
static double G_LogCoshDer(double x) {return(tanh(a*x));}


UString UICAfast::Properties = UString();


void UICAfast::SetAllMembersDefault(void)
{
    DataPreWhitened = false;
    PreWhiteMat     = UMatrix();
    Nrow            = 0;
    Ntrial          = 0;
    NtotCol         = 0;
    data            = NULL;
    Ncomp           = 0;
    ICAContrast     = U_ICA_TANH;
    MaxIter         = 100;
    Precission      = 0.9999;

    error           = U_OK;
    Properties      = UString();
}
void UICAfast::DeleteAllMembers(ErrorType E)
{
    if(data) for(int k=0; k<Ntrial; k++) delete data[k];
    delete[] data;
    SetAllMembersDefault();
    error = E;
}

UICAfast::UICAfast()
{
    SetAllMembersDefault();
}
UICAfast::UICAfast(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UICAfast::UICAfast(const UICAfast& ICA)
{
    SetAllMembersDefault();
    *this = ICA;
}
UICAfast::UICAfast(int NewNtrial)
{
    SetAllMembersDefault();
    error = SetNTrial(NewNtrial);
    if(error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::UICAfast(). Setting Ntrial to %d \n", NewNtrial);
        DeleteAllMembers(U_ERROR);
    }
}
UICAfast::~UICAfast()
{
    DeleteAllMembers(U_OK);
}

UICAfast& UICAfast::operator=(const UICAfast& ICA)
{
    if(this==NULL)
    {
        static UICAfast I(U_ERROR);
        CI.AddToLog("ERROR: UICAfast::operator=(). Object NULL.\n");
        return I;
    }
    if(&ICA==NULL || ICA.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UICAfast::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }

    if(this==&ICA) return *this;

    DeleteAllMembers(U_OK);

    DataPreWhitened = ICA.DataPreWhitened;
    PreWhiteMat     = ICA.PreWhiteMat;
    Nrow            = ICA.Nrow;
    Ntrial          = MAX(0, ICA.Ntrial);
    NtotCol         = MAX(0, ICA.NtotCol);
    if(ICA.data)
    {
        data        = new UMatrix*[Ntrial];
        if(!data)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: ICAfast::operator=(). Memory allocation: Ntrial=%d .\n",Ntrial);
            return *this;
        }
        for(int k=0; k<Ntrial; k++) data[k] = NULL;
        for(int k=0; k<Ntrial; k++) 
        {
            data[k] = new UMatrix(*(ICA.data[k]));
            if(data[k]==NULL || data[k]->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: ICAfast::operator=(). Copying data from array element %d .\n",k);
                return *this;
            }
            if(data[k]->GetNrow()!=Nrow)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: ICAfast::operator=(). Nrow in trial %d should be %d.\n", k, Nrow);
                return *this;
            }
        }
    }
    Ncomp       = ICA.Ncomp       ;
    ICAContrast = ICA.ICAContrast ;
    MaxIter     = ICA.MaxIter     ;
    Precission  = ICA.Precission  ;
    
    return *this;
}

const UString& UICAfast::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UICAfast() object.");
        return Properties;
    }
    Properties = UString();

    Properties += UString(Nrow      , "Nrow          = %d \n");
    Properties += UString(Ntrial    , "Ntrial        = %d \n");
    Properties += UString(NtotCol   , "NtotCol       = %d \n");
    Properties += UString(Ncomp     , "Ncomp         = %d \n");
    Properties += UString(            "ICAContrast   = ") + GetICATypeText(ICAContrast) + " \n";
    Properties += UString(MaxIter   , "MaxIter       = %d \n");
    Properties += UString(Precission, "Precission    = %f \n");
    Properties += UString(            "DataWhitened  = ") + BoolAsText(DataPreWhitened) + " \n";

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UICAfast::SetNTrial(int NewNtrial)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::SetNTrial(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(NewNtrial<0)
    {
        CI.AddToLog("ERROR: UICAfast::SetNTrial(). Argument out of range: NewNtrial = %d .\n", NewNtrial);
        return U_ERROR;
    }

    DataPreWhitened = false;
    PreWhiteMat     = UMatrix();
    NtotCol         = 0;
    Ncomp           = 0;
    Nrow            = 0;
    Ncomp           = 0;
    if(data) for(int k=0; k<Ntrial; k++) delete[] data[k];
    delete[] data;
    data = NewNtrial >0 ? new UMatrix*[NewNtrial] : NULL;
    if(NewNtrial >0 && data==NULL)
    {
        Ntrial  = 0;
        CI.AddToLog("ERROR: UICAfast::SetNTrial(). Memory allocation, NewNtrial = %d .\n", NewNtrial);
        return U_ERROR;
    }
    for(int k=0; k<NewNtrial; k++) data[k]=NULL;
    Ntrial = NewNtrial;

    return U_OK;
}

ErrorType UICAfast::SetNcomp(int components)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Ncomp = MAX(0, components);
    return U_OK;
}
ErrorType UICAfast::SetMaxIter(int maxiter)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(maxiter<=0)
    {
        CI.AddToLog("ERROR: SetMaxIter(). Argument out of range: maxiter=%d \n", maxiter);
        return U_ERROR;
    }
    MaxIter = maxiter;
    return U_OK;
}
ErrorType UICAfast::SetPrecission(double prec)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(prec<=0.||prec>1.)
    {
        CI.AddToLog("ERROR: UICAfast::SetPrecission(). Argument out of range: prec=%f \n", prec);
        return U_ERROR;
    }
    Precission = prec;
    return U_OK;
}

ErrorType UICAfast::SetICAContrast(ICAType IT)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(IT==U_ICA_TANH || IT==U_ICA_POW4 || IT==U_ICA_LOGCOSH)
    {
        ICAContrast = IT;
        return U_OK;
    }
    CI.AddToLog("ERROR: UICAfast::SetICAContrast(). Argument ot of range: IT=%d \n", IT);
    return U_ERROR;
}

ErrorType UICAfast::SetTrial(UMatrix& newdata, int itrial)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). UMatrix array not set.\n");
        return U_ERROR;
    }
    if(&newdata==NULL || newdata.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(DataPreWhitened==true)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). Data already pre-whitened.\n");
        return U_ERROR;
    }
    if(itrial<0 || itrial>=Ntrial)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). Argument out of range: itrial = %d .\n", itrial);
        return U_ERROR;
    }

// Copy data to slot itrial and keep old element
    UMatrix* OldElem = data[itrial];
    data[itrial] = new UMatrix(newdata);
    if(data[itrial]==NULL || data[itrial]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::SetTrial(). Copying data, itrial = %d .\n", itrial);
        delete data[itrial]; data[itrial]=OldElem;
        return U_ERROR;
    }

// Test if numbers of rows is consistent with earlier set trials
    bool FirstMat = true;
    for(int k=0; k<Ntrial; k++)
    {
        if(data[k]==NULL) continue;
        if(k==itrial)     continue;

        FirstMat=false;
        if(newdata.GetNrow()!=data[k]->GetNrow())
        {
            CI.AddToLog("ERROR: UICAfast::SetTrial(). Nrow out of range: newdata.GetNrow() = %d, data[%d]->GetNrow()=%d .\n", newdata.GetNrow(), k, data[k]->GetNrow());
            
            delete data[itrial]; data[itrial]=OldElem;
            return U_ERROR;
        }
    }

// if so, delete old element and update Nrow
    delete OldElem;
    if(FirstMat) Nrow = newdata.GetNrow();
    Ncomp = MIN(Ncomp, Nrow);

    NtotCol = 0;
    for(int k=0; k<Ntrial; k++) if(data[k])  NtotCol += data[k]->GetNcol();

    return U_OK;
}
UMatrix UICAfast::GetTrial(int itrial, bool Prew) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetTrial(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::GetTrial(). UMatrix array not set.\n");
        return UMatrix(U_ERROR);
    }
    if(itrial<0 || itrial>=Ntrial)
    {
        CI.AddToLog("ERROR: UICAfast::GetTrial(). Argument out of range: itrial = %d .\n", itrial);
        return UMatrix(U_ERROR);
    }
    if(data[itrial]==NULL || data[itrial]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetTrial(). Matrix not or erroneously set at itrial %d .\n", itrial);
        return UMatrix(U_ERROR);
    }
    if(Prew==false && DataPreWhitened==true)
    {
        CI.AddToLog("ERROR: UICAfast::GetTrial(). Only pre-whitened data available.\n");
        return UMatrix(U_ERROR);
    }
    if(Prew==DataPreWhitened) return UMatrix(*(data[itrial]));

    return PreWhiteMat*UMatrix(*(data[itrial]));
}
UMatrixSymmetric UICAfast::GetCovariance() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetCovariance(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::GetCovariance(). UMatrix array not set.\n");
        return UMatrix(U_ERROR);
    }
    if(NtotCol<=0)
    {
        CI.AddToLog("ERROR: UICAfast::GetCovariance(). All matrix slots empty.\n");
        return UMatrix(U_ERROR);
    }
    if(DataPreWhitened==true)
    {
        CI.AddToLog("ERROR: UICAfast::GetCovariance(). Data already pre-whitened.\n");
        return UMatrix(U_ERROR);
    }

    UMatrixSymmetric Covar(NULL, Nrow, Nrow);
    for(int k=0; k<Ntrial; k++)
    {
        if(data[k]==NULL || data[k]->GetError()!=U_OK) continue;
        Covar   += data[k]->GetMMT();
    }
    Covar/=double(NtotCol);

    return Covar;
}

UMatrix UICAfast::GetPreWhitenMatrix(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenMatrix(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenMatrix(). UMatrix array not set.\n");
        return UMatrix(U_ERROR);
    }
    if(NtotCol<=0)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenMatrix(). All matrix slots empty.\n");
        return UMatrix(U_ERROR);
    }
    if(DataPreWhitened==true) return PreWhiteMat;

    UMatrixSymmetric Covar = this->GetCovariance();
    if(Covar.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenMatrix(). Computing covariance matrix.\n");
        return UMatrix(U_ERROR);
    }
    int         NPos  = MIN((Ncomp==0?Nrow:Ncomp), Covar.GetNPosEig(0.));
    PreWhiteMat       = Covar.GetInvertSqrt(NPos).GetTranspose();
    if(PreWhiteMat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenMatrix(). Computing whithening matrix.\n");
        return UMatrix(U_ERROR);
    }
/////
/////    PreWhiteMat = UMatrix(PreWhiteMat.GetNcol());
/////
    return PreWhiteMat;
}

ErrorType UICAfast::PreWhitenData(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::PreWhitenData(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::PreWhitenData(). UMatrix array not set.\n");
        return U_ERROR;
    }
    if(NtotCol<=0)
    {
        CI.AddToLog("ERROR: UICAfast::GetPreWhitenData(). All matrix slots empty.\n");
        return U_ERROR;
    }
    if(DataPreWhitened==true)
    {
        CI.AddToLog("ERROR: UICAfast::PreWhitenData(). Data already pre-whitened.\n");
        return U_ERROR;
    }

    PreWhiteMat = GetPreWhitenMatrix();
    if(PreWhiteMat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::PreWhitenData(). Computing pre-whitening matrix.\n");
        return U_ERROR;
    }

    if(PreWhiteMat.GetNcol()!=Nrow)
    {
        CI.AddToLog("ERROR: UICAfast::PreWhitenData().  PreW.Ncol (= %d) should be equal to Nrow (=%d).\n", PreWhiteMat.GetNcol(), Nrow);
        return U_ERROR;
    }
    for(int k=0; k<Ntrial; k++)
    {
        if(data[k]==NULL || data[k]->GetError()!=U_OK) continue;

        *(data[k]) = PreWhiteMat * (*(data[k]));
    }
    Nrow            = PreWhiteMat.GetNrow();
    DataPreWhitened = true;

    return U_OK;
}

UMatrix UICAfast::GetDeMixingMatrix()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). data array not set.\n");
        return UMatrix(U_ERROR);
    }
    if(NtotCol<=0)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). All matrix slots empty.\n");
        return UMatrix(U_ERROR);
    }

    if(DataPreWhitened==false && PreWhitenData()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Applying pre-whitening matrix.\n");
        return UMatrix(U_ERROR);
    }

    int ncmp = (Ncomp==0)? Nrow : Ncomp;

    UMatrix w   ((double*)NULL, ncmp, Nrow);
    UMatrix wnew((double*)NULL, ncmp, Nrow);
    w.SetDataRandom();
    w = w.GetGramSchmidtRows();
    if(w.GetError()!=U_OK || w.NormalizeRows()!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Setting random orthogonal matrix.\n");
        return UMatrix(U_ERROR);
    }
    
    bool   converged = false;
    int    iter      = 0;
    for(iter=0; iter<MaxIter && NOT(converged); iter++)
    {
        ShowStatus("Note: UICAfast::GetDeMixingMatrix(). Running ICA over all samples, iteration %d of max %d\n",iter,MaxIter);
        UMatrix term1sum;
        UMatrix term2sum;

        for(int k=0; k<Ntrial; k++)
        {
            if(k%10==0)  ShowStatus(".");

            UMatrix Datak = GetTrial(k, true);
            if(Datak.GetError()!=U_OK)
            {
                CI.AddToLog("\n");
                CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Getting data from trial %d.\n", k);
                return UMatrix(U_ERROR);
            }
            UMatrix term1=w*Datak;        //calculate w^T*x for all t in trial
            UMatrix term2=term1;

            switch(ICAContrast)
            {
            case U_ICA_TANH:
                term1.ApplyFunction(&G_Tanh);     //apply function G to all elements to get term1=x*GXXX(w^T*x) for all w and t
                term2.ApplyFunction(&G_TanhDer);  //and it's derivative too, yielding term2=GXXXDer(w^T*x) for all w and t
                break;
            case U_ICA_POW4:
                term1.ApplyFunction(&G_Pow4);
                term2.ApplyFunction(&G_Pow4Der);
                break;
            case U_ICA_LOGCOSH:
                term1.ApplyFunction(&G_LogCosh);
                term2.ApplyFunction(&G_LogCoshDer);
                break;
            }

            term1sum         += GetMatMul(term1, false, Datak, true);  //add x*term1^T to the term 1 sum 
            term2sum         += term2.GetRowSum();                     //(effectively summing x*G(w^T*x) over all t in trial)
        }
        ShowStatus("\n");

        term1sum/= double(NtotCol);                     //scale to calculate expectation values, the term 1 sum gives the first term
        term2sum/= double(NtotCol);                     //term 2 sum gives the scaling of the columns of w for the second term
        
        wnew   =  w;                                    //calculate the second term
        UMatrix wDiag(term2sum.GetMatrixArray(), Ncomp);
        wnew   = wDiag*wnew;
        wnew  *= (-1.);
        wnew  += term1sum;                              //add first term, decorrelate columns of w^T and nomalize
        wnew   = wnew.GetGramSchmidtRows();
        if(wnew.GetError()!=U_OK || wnew.NormalizeRows()!=U_OK)
        {
            CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Orthogonalizing new w-matrix.\n");
            return UMatrix(U_ERROR);
        }
        
        //calculate/print inner products of rows, check for convergence
        converged         = true;
        double productrms = 0;
        for(int i=0;i<w.GetNrow();i++)                  //calculate inner product of rows of w and wnew
        {
            double product = GetRowProduct(w, i, wnew, i);
            UString Text(product, "%f");
            ShowStatus((const char*)Text);;
            productrms += product*product;
            if ((fabs(product) > Precission)) ShowStatus(" (in convergence radius)");
            else                             converged = false;
            ShowStatus("\n");
        }
        UString Text(sqrt(productrms/w.GetNrow()), "%f (RMS) \n");
        ShowStatus((const char*)Text);;
        w = wnew;
    }
    UString Text = converged ? UString(iter+1, "\nICA converged after %d iterations!\n\n") :
                               UString(iter  , "\nICA did not converge after %d iterations!\n\n");
    ShowStatus((const char*)Text);

    return w*PreWhiteMat;
}
UMatrix UICAfast::GetDeMixingMatrixML()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrixML(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrixML(). data array not set.\n");
        return UMatrix(U_ERROR);
    }
    if(NtotCol<=0)
    {
        CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrixML(). All matrix slots empty.\n");
        return UMatrix(U_ERROR);
    }

    //if(DataPreWhitened==false && PreWhitenData()!=U_OK)
    //{
    //    CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrixML(). Applying pre-whitening matrix.\n");
    //    return UMatrix(U_ERROR);
    //}

    int ncmp = (Ncomp==0)? Nrow : Ncomp;

    UMatrixSquare W = UMatrixSquare(GetPreWhitenMatrix().GetNcol());
    
    bool   converged = false;
    int    iter      = 0;
    for(iter=0; iter<MaxIter && NOT(converged); iter++)
    {
        UMatrix WinvT = W.GetInverse().GetTranspose();
        if(WinvT.GetError()!=U_OK)
        {
            CI.AddToLog("\n");
            CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Matrix inversion at iteration %d.\n", iter);
            return UMatrix(U_ERROR);
        }

        UMatrix Cov;
////        UMatrix WTW = W.GetMTM();
        for(int k=0; k<Ntrial; k++)
        {
            if((k+1)%10==0)  ShowStatus(".");

            UMatrix X = GetTrial(k, true);
            if(X.GetError()!=U_OK)
            {
                CI.AddToLog("\n");
                CI.AddToLog("ERROR: UICAfast::GetDeMixingMatrix(). Getting data from trial %d.\n", k);
                return UMatrix(U_ERROR);
            }
            UMatrix A = W*X;
            UMatrix Z = A; Z.ApplyFunction(&G_MinTanh);

            Cov += GetMatMul(Z, false, X, true);
////            Cov += GetMatMul(Z, false, WTW*X, true);
        }
        Cov              /= double(NtotCol);
        UMatrix    Wdelta = (WinvT + Cov)*1.01;

/////        UMatrix    Wdelta = (W + Cov)*0.02;

        W                += Wdelta;
        double     eps    = Wdelta.GetFrobNorm()/Nrow;
        converged         = eps<Precission/100;

        UString Text(iter,MaxIter,"Iteration %d of max %d\t");

        Text +=UString(eps, "%f (RMS) ") + UString(GetLogP(W), "\t LogP = %f\n");
        ShowStatus(Text);
    }
    UString Text = converged ? UString(iter+1, "\nICA converged after %d iterations!\n\n") :
                               UString(iter  , "\nICA did not converge after %d iterations!\n\n");
    ShowStatus((const char*)Text);

    return W;///*PreWhiteMat;
}

double UICAfast::GetLogP(UMatrixSquare& DeMix) const
{
    double LogP = 0.;

    for(int k=0; k<Ntrial; k++)
    {
        UMatrix WX = DeMix*GetTrial(k, true);
        for(int i=0; i<WX.GetNrow(); i++)
            for(int j=0; j<WX.GetNcol(); j++) LogP -= log(PI*cosh(MAX(-200,MIN(200,WX.GetElement(i,j)))));
    }
    LogP /= double(NtotCol);
    LogP += DeMix.GetLogAbsDet();

    return LogP;
}

void UICAfast::ShowStatus(const char* Status)
{
    if(this==NULL || error!=U_OK) return;
    if(Status==NULL) return;

    CI.AddToLog(Status);
}
void UICAfast::ShowStatus(const char* Status, int istep, int Nstep) 
{
    if(this==NULL || error!=U_OK) return;
    if(Status==NULL || istep<0 || Nstep<=0) return;

    CI.AddToLog(Status, istep, Nstep);
}

