#ifndef __ICAFAST_INCLUDED
#define __ICAFAST_INCLUDED

#include "Matrix.h"
#include "MatrixSymmetric.h"

enum ICAType {U_ICA_TANH,      
              U_ICA_POW4,      
              U_ICA_LOGCOSH,   
              U_ICA_NTYPE};   

PMT_CCP DLL_IO GetICATypeText(ICAType IT);

class DLL_IO UICAfast
{
public:
    UICAfast();
    UICAfast(ErrorType E);
    UICAfast(int NewNtrial);
    UICAfast(const UICAfast& data2);
    virtual ~UICAfast();
    UICAfast&               operator=(const UICAfast& ICA);

    ErrorType               GetError(void) const {if(this) return error; return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
    ErrorType               SetNcomp(int components);
    ErrorType               SetMaxIter(int maxiter);
    ErrorType               SetPrecission(double prec);
    ErrorType               SetICAContrast(ICAType IT);

    ErrorType               SetNTrial(int NewNtrial);
    int                     GetNTrial(void) const {if(this) return Ntrial; return 0;};
    int                     GetNrow(void)   const {if(this) return Nrow  ; return 0;};

    ErrorType               SetTrial(UMatrix& newdata, int itrial);
    UMatrix                 GetTrial(int itrial, bool Prew) const;
    UMatrixSymmetric        GetCovariance() const;
    UMatrix                 GetPreWhitenMatrix(void); // also update PreWhiteMat
    UMatrix                 GetDeMixingMatrix(void);
    UMatrix                 GetDeMixingMatrixML(void);

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);
    virtual void            ShowStatus(const char* Status);
    virtual void            ShowStatus(const char* Status, int istep, int Nstep);

private:
    static UString          Properties;         // General property string.
    ErrorType               error;              // General error flag
    bool                    DataPreWhitened;
    UMatrix                 PreWhiteMat;
    int                     Nrow;
    int                     Ntrial;
    int                     NtotCol;            // Number of all collumns, summed over all trials
    UMatrix**               data;
    ICAType                 ICAContrast;
    int                     Ncomp;
    int                     MaxIter;
    double                  Precission;

    ErrorType               PreWhitenData(void);

public:
    double                  GetLogP(UMatrixSquare& DeMix) const;
};

#endif //#define __ICAFAST_INCLUDED

