/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for computing integrals over triangles                             */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who      When       What
  Jdm    17-07-98   creation  
  Jdm    21-07-98   Transform it into a C++ object
  Jdm    22-07-98   Tested Weights and Absices, for n<6
  Jdm    19-10-98   Added Vector function on triangle, tested for large n
  Jdm    04-05-99   Added IntegrateCross()
  Jdm    13-06-99   Added SetNcomp(), in order to integrate several components of
                      the IntegrandScalar() virtual function.
  Jdm    29-07-99   Renamed IntegrandScalar() to IntegrandScalars() and use
                      IntegrandScalar() to integrate a single component
  GdV    13-10-04   Declared some undeclared identifiers (for g++-compatibility)
  JdM    01-11-10   UIntegTri::SetOrder(): Made cnst1 and cnst2 double instead of float, to avoid warings.
  JdM    19-11-10   Added SetAllMembersDefault() and default constructor
  JdM    20-11-14   Added operator=(), copy constructor and DeleteAllMembers()
  JdM    22-11-14   Removed obsolete IntegrateCross()
  JdM    23-11-14   IntegrateLinear() and IntegrateScalars(). return const double* (instead of double)
  JdM    14-02-15   Remove obsolete IntegrateNormal() and IntegrateLocal()
  JdM    15-02-15   Re-organized the whole algorithm. Separated the setting of weights and points. This should make it much faster.
*/

#include <math.h>
#include <stdio.h>

#include "IntegrateTriangle.h"

void UIntegTri::SetAllMembersDefault()
{
    Absc   = NULL;
    Weig   = NULL;
    Norder = 0;

    c0 = c1 = c2 = UVector3();
    Normal = UVector3();
    Area   = 0.;
    Det    = 0.;
    W      = NULL;
    X      = NULL;
    LinW   = NULL;

    Ncomp  = 0;
    Result = NULL;
    error  = U_OK;
}
void UIntegTri::DeleteAllMembers(ErrorType E)
{
    delete[] Absc;
    delete[] Weig;
    delete[] W;
    delete[] X;
    delete[] LinW;
    delete[] Result;
    SetAllMembersDefault();
    error = E;
}

UIntegTri::UIntegTri()
{
    SetAllMembersDefault();
}
UIntegTri::UIntegTri(const UIntegTri& IT)
{
    SetAllMembersDefault();
    *this = IT;
}
UIntegTri::UIntegTri(int n, int ncomp)
{
    SetAllMembersDefault();

    if(error==U_OK) error = SetNcomp(ncomp<=0? 1 : ncomp);
    if(error==U_OK) error = SetOrder(n);

    if(error!=U_OK)
        CI.AddToLog("ERROR: UIntegTri::UIntegTri(). Initializing object. \n");
}

UIntegTri::UIntegTri(UVector3 x0, UVector3 x1, UVector3 x2, int n, int ncomp)
{
    SetAllMembersDefault();

    if(error==U_OK) error = SetNcomp(ncomp<=0? 1 : ncomp);
    if(error==U_OK) error = SetOrder(n);
    if(error==U_OK) error = SetCorners(x0, x1, x2);

    if(error!=U_OK)
        CI.AddToLog("ERROR: UIntegTri::UIntegTri(). Initializing object. \n");
}

UIntegTri::~UIntegTri()
{
    DeleteAllMembers(U_OK);
}

UIntegTri& UIntegTri::operator=(const UIntegTri &IT)
{
    if(this==NULL || &IT==NULL)
    {
        if(this==NULL)
        {
            static UIntegTri TT; TT.error = U_ERROR;
            CI.AddToLog("ERROR: UIntegTri::operator=(). this==NULL. \n");
            return TT;
        }
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UIntegTri::operator=(). this==NULL. \n");
        return *this;
    }
    if(this==&IT) return *this;

    DeleteAllMembers(U_OK);

    Norder = IT.Norder;
    if(IT.Absc  ) Absc   = new double[Norder/2+2];
    if(IT.Weig  ) Weig   = new double[Norder/2+2];

    c0     = IT.c0;
    c1     = IT.c1;
    c2     = IT.c2;
    Normal = IT.Normal;
    Area   = IT.Area;
    Det    = IT.Det;
    if(IT.W     ) W    = new double[Norder*Norder];
    if(IT.X     ) X    = new UVector3[Norder*Norder];
    if(IT.LinW  ) LinW = new double[3*Norder*Norder];

    Ncomp  = IT.Ncomp;
    if(IT.Result) Result = new double[3*Ncomp];

    if( (IT.Absc && !Absc) || (IT.Weig && !Weig) || (IT.W && !W) || (IT.W && !W) || (IT.LinW && !LinW) || (IT.Result && !Result))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UIntegTri::operator=(). Memory allocation. \n");
        return *this;
    }

    if(Absc  ) for(int kk=0; kk<Norder/2+2     ; kk++) Absc[kk]   = IT.Absc[kk];
    if(Weig  ) for(int kk=0; kk<Norder/2+2     ; kk++) Weig[kk]   = IT.Weig[kk];
    if(W     ) for(int kk=0; kk<Norder*Norder  ; kk++) W[kk]      = IT.W[kk];
    if(X     ) for(int kk=0; kk<Norder*Norder  ; kk++) X[kk]      = IT.X[kk];
    if(LinW  ) for(int kk=0; kk<3*Norder*Norder; kk++) LinW[kk]   = IT.LinW[kk];
    if(Result) for(int kk=0; kk<3*Ncomp        ; kk++) Result[kk] = IT.Result[kk];

    return*this;
}

ErrorType UIntegTri::SetNcomp(int n) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UIntegTri::SetNcomp(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(n<=0) 
    {
        CI.AddToLog("ERROR: UIntegTri::SetNcomp(). Invalid n (=%d). \n", n);
        return U_ERROR; 
    }
    if(Ncomp==n) return U_OK;

    Ncomp = n; 

    delete[] Result; Result = new double[3*Ncomp];
    
    if(Result==NULL) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UIntegTri::SetNcomp(). Memory allocation. \n");
        return U_ERROR;
    }

    for(int kk=0; kk<3*Ncomp; kk++) Result[kk] = 0.;
    return U_OK;
};

ErrorType UIntegTri::SetOrder(int n)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UIntegTri::SetOrder(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(n<=0) 
    {
        CI.AddToLog("ERROR: UIntegTri::SetOrder(). Invalid n (=%d). \n", n);
        return U_ERROR; 
    }
    if(Norder==n) return U_OK;

    Norder = n;

    delete[] Absc; Absc = new double[Norder/2+2];
    delete[] Weig; Weig = new double[Norder/2+2];

    if(Absc==NULL || Weig==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UIntegTri::SetOrder(). Memory allocation (Norder = %d). \n", Norder);
        return U_ERROR;
    }
    const double bzero = 2.4048256;

    switch(Norder)
    {
    case 1:
        Absc[1] = 0.;
        Weig[1] = 2.;
        return U_OK;
    case 2:
        Absc[1] = sqrt(3.)/3.;
        Weig[1] = 2.;
        return U_OK;
    case 3:
        Absc[1] = sqrt(15.)/5.;
        Absc[2] = 0;
        Weig[1] = 5./9.;
        Weig[2] = 8./9.;
        return U_OK;
    }

    double epsmch=1;
    while(1.+epsmch != 1.) epsmch /= 2.;

    int mlast  = Norder/2;
    int nm1    = Norder-1;
    int npoint = Norder/3;

    double float1 =  Norder*Norder+Norder;
    double float2 = 5.*float1;
    double c1     = (3.+float1)/3.;
    double c2     = (1.+float1)/3.;
    double c3     = (6.+float2)/6.;
    double c4     = (4.+float2)/6.;
    double c5     = 4.*atan(1.)/(4.*Norder+2.);

    double cnst1  = 1.-0.125*(1.-1./double(Norder))/double(Norder*Norder);
    double cnst2  = 1./pow(double(Norder),4.)/384.;

    double alphan = float1+1./3. ;
    double angle  = (bzero/sqrt(alphan))*(1.-(bzero*bzero-2.)/(360.*alphan*alphan));

    double xnm    = cos(angle);

    double vnm;
    double factor;
    double pnm1, pnm2, xnmsq, dnom, xpnm1, pn, u, v, onemx, tempx, epslon, term1, term2, prod;
    int mzero, klast;
    for(int m=1; m<=mlast; m++)
    {
        int itr=0;

        if(m!=1)
        {
            vnm    = double(4*m-1)*c5;
            factor = 0.;
            if(m<=npoint) factor=39.-28./(sin(vnm)*sin(vnm));
            xnm = (cnst1-cnst2*factor)*cos(vnm);
        }
a100:   pnm2  = 1.;
        pnm1  = xnm;
        xnmsq = xnm*xnm;
        dnom  = 1.+3.*xnmsq ;
        for(int k=2; k<=nm1; k++)
        {
            xpnm1 = xnm*pnm1;
            pn    = xpnm1+xpnm1-pnm2-(xpnm1-pnm2)/double(k);
            dnom  = dnom+double(k+k+1)*pn*pn ;
            pnm2  = pnm1;
            pnm1  = pn ;
        }
        xpnm1  = xnm*pnm1;
        pn     = xpnm1+xpnm1-pnm2-(xpnm1-pnm2)/double(Norder) ;

        v      = pn/(pnm1-xnm*pn)/double(Norder);
        onemx  =  1.-xnm;
        tempx  = (1.-onemx)-xnm;
        onemx  = onemx+tempx;
        u      = onemx*(1.+xnm)*v ;
        epslon = 2.*fabs(xnm)*epsmch;
        if(fabs(u)>epslon)
        {
            itr=itr+1;
            if(itr<2)
            {
                term1 = c1*xnmsq-c2;
                term2 = (c3*xnmsq-c4)*xnm;
                xnm   = xnm-u*(1.+v*(xnm+v*(term1+v*term2)));
                goto a100;
            }
        }
        Absc[m]  = xnm;
        Weig[m]  = 2./dnom;
    }

    int nsave = Norder%2;
    if(nsave!=0)
    {
        mzero    = mlast+1;
        Absc[mzero] = 0;
        klast    = mlast-1;
        prod     = 2./double(Norder);
        for(int k=1; k<=klast; k++) prod *= double(k+k+2)/double(k+k+1);
        Weig[mzero] = 2.*prod*prod ;
    }

    double sumxsq = 0.;
    double sumw   = 0.;
    npoint = mlast+1;
    for(int k=1; k<=mlast; k++)
    {
        int kk  = npoint-k;
        sumxsq += Absc[kk]*Absc[kk];
        sumw   += Weig[k];
    }
    if(nsave>0) sumw += 0.5*Weig[mzero];
////    diffw  = fabs(sumw-1.);
////    diffx  = fabs(double(4*Norder-2)/double(Norder*Norder-Norder)*sumxsq-1.);

    return U_OK;
}
ErrorType UIntegTri::SetCorners(UVector3 x0, UVector3 x1, UVector3 x2)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UIntegTri::SetCorners(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Ncomp<=0 || Norder<=0)
    {
        CI.AddToLog("ERROR: UIntegTri::SetCorners(). Invalid Ncomp (%d) or Norder (%d). \n", Ncomp, Norder);
        return U_ERROR;
    }
    if(Absc==NULL || Weig==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::SetCorners(). 1D abscices or weights not set. \n");
        return U_ERROR;
    }
    delete[] W; W = new double  [Norder*Norder];
    delete[] X; X = new UVector3[Norder*Norder];
    if(W==NULL || X==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::SetCorners(). Memory allocation (Norder = %d). \n", Norder);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }

    c0 = x0; c1 = x1; c2 = x2;
    Normal = (c0^c1) + (c1^c2) + (c2^c0);
    Area   = Area = Normal.GetNorm()/2.;
    Det    = Normal & c2;
    Normal.Normalize();

// Compute arguments and weights
    double hold1,hold2;

    UVector3 x10  = (x1-x0)/2;
    UVector3 x20  = (x2-x0)/4;

    int ip = 0;
    for(int l=1; l<=Norder; l++)
    {
        int i = 0;
        if(l>(Norder+1)/2) 
        {
            i     = Norder+1 - l;
            hold1 = -Absc[i];
        }
        else
        {
            i     = l;
            hold1 = Absc[i];
        }
        double   save1 = 1. + hold1;
        double   save2 = 1. - hold1;
        UVector3 v     = x20*save1;
        double   save5 = save1*Weig[i];
        UVector3 xx    = x10*save2 + x0;

        double temp = 0.;
        for(int m=1;m<=Norder;m++)
        {
            int j=0;
            if(m>(Norder+1)/2)
            {
                j = Norder+1 - m;
                hold2 = -Absc[j];
            }
            else
            {
                j = m;
                hold2 = Absc[j];
            }
            double save6 = 1. - hold2;

            W[ip] = Weig[j]*save5;
            X[ip] = xx  + v*save6;
            ip++;
        }
    }

    delete[] LinW; LinW = NULL;
    if(fabs(Det)>1.e-16)
    {
        LinW = new double[3*Norder*Norder];
        if(LinW==NULL)
        {
            CI.AddToLog("ERROR: UIntegTri::SetCorners(). Memory allocation for lineair weights (Norder = %d). \n", Norder);
            DeleteAllMembers(U_ERROR);
            return U_ERROR;
        }
        for(int ip=0; ip<Norder*Norder; ip++)
        {
            LinW[ip*3  ] = W[ip] * ((X[ip]^c1)&c2) / Det;
            LinW[ip*3+1] = W[ip] * ((c0^X[ip])&c2) / Det;
            LinW[ip*3+2] = W[ip] * ((c0^c1)&X[ip]) / Det;
        }
    }

    return U_OK;
}

//double UIntegTri::IntegrateLocal(double u1,double v1,double u2,double v2,double u3,double v3)
///*
//    Integrate the function IntegrandLocal(), which is expressed in local coordinates,
//    over the triangle with corner coordinates (u1,v1), (u2,v2) and (u3,v3).
// */
//{
//    if(this==NULL || error!=U_OK) return 0.;
//
//    double save1,save2,save3,save4,save5,save6,x,y,xx,yy,temp,hold1,hold2;
//
//    double u21 = u2 - u1 ;
//    double v21 = v2 - v1 ;
//    double u31 = u3 - u1 ;
//    double v31 = v3 - v1 ;
//    double absjac = fabs(u21*v31 - v21*u31);
//
//    u21 /= 2;
//    v21 /= 2;
//    u31 /= 4;
//    v31 /= 4;
//
//    int    nn    = Norder;
//    int    nnp1  = nn + 1 ;
//    int    itest = nnp1/2;
//    double aprox = 0.;
//
//    int i;
//    for(int l=1; l<=nn; l++)
//    {
//        if(l>itest) 
//        {
//            i = nnp1 - l;
//            hold1 = -Absc[i];
//        }
//        else
//        {
//            i = l;
//            hold1 = Absc[i];
//        }
//        save1 = 1. + hold1;
//        save2 = 1. - hold1;
//        save3 = u31*save1;
//        save4 = v31*save1;
//        save5 = save1*Weig[i];
//        xx    = u21*save2 + u1;
//        yy    = v21*save2 + v1;
//        temp  = 0.;
//        int j;
//        for(int m=1;m<=nn;m++)
//        {
//            if(m>itest)
//            {
//                j = nnp1 - m;
//                hold2 = -Absc[j];
//            }
//            else
//            {
//                j = m;
//                hold2 = Absc[j];
//            }
//            save6 = 1. - hold2;
//            x     = xx + save3*save6;
//            y     = yy + save4*save6;
//            temp  = temp + Weig[j]* IntegrandLocal(x,y);
//        }
//        aprox += save5*temp;
//    }
//
//    aprox *= absjac/8;
//    return aprox;
//}

double UIntegTri::IntegrateScalar(void) 
/*
    Integrate the function IntegrandScalar() over the triangle with corners x0, x1 and x2.
    
    Return that integral.
 */
{
    if(this==NULL || error!=U_OK) return 0.;
    if(X==NULL || W==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::IntegrateScalar(). Integration points and/or weights not set.\n");
        return 0;
    }

    int Npoints = Norder*Norder;
    double Sum  = 0.;
    for(int ip=0; ip<Npoints; ip++) Sum += W[ip] * IntegrandScalar(X[ip]);

    return Sum * Area/4;
}

const double* UIntegTri::IntegrateScalars(void)
/*
    Integrate the function IntegrandScalars() over the triangle with corners x0, x1 and x2.
    
    Return the integral over all components of  IntegrandScalars();
 */
{
    if(this==NULL || error!=U_OK) return NULL;
    if(X==NULL || W==NULL || Result==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::IntegrateScalars(). Integration points and/or weights not set.\n");
        return 0;
    }

    int Npoints = Norder*Norder;
    for(int k=0; k<Ncomp; k++) Result[k] = 0.;
    for(int ip=0; ip<Npoints; ip++) 
    {
        const double* I = IntegrandScalars(X[ip]);
        for(int k=0; k<Ncomp; k++) Result[k] += W[ip] * I[k];
    }
    for(int k=0; k<Ncomp; k++) Result[k] *= (Area/4);

    return Result;
}

const double* UIntegTri::IntegrateLinear(void)
/*
    Integrate the function IntegrandScalars() over the triangle with corners x0, x1 and x2.
    For each component, compute three integrals, where each integrand is multiplied with a 
    function that varies linearly from zero to one.
 */
{
    if(this==NULL || error!=U_OK) return NULL;
    if(X==NULL || W==NULL || Result==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::IntegrateLinear(). Integration points and/or weights not set.\n");
        return NULL;
    }
    if(LinW==NULL)
    {
        CI.AddToLog("ERROR: UIntegTri::IntegrateLinear(). Linear weights not set. Triangle degenerated (Det = %g)? \n", Det);
        return NULL;
    }

    int Npoints = Norder*Norder;
    for(int k=0; k<3*Ncomp; k++) Result[k] = 0.;
    for(int ip=0; ip<Npoints; ip++) 
    {
        const double* I = IntegrandScalars(X[ip]);
        for(int k=0; k<Ncomp; k++) 
        {
            Result[k*3  ] += LinW[ip*3  ] * I[k];
            Result[k*3+1] += LinW[ip*3+1] * I[k];
            Result[k*3+2] += LinW[ip*3+2] * I[k];
        }
    }
    for(int k=0; k<3*Ncomp; k++) Result[k] *= (Area/4);

    return Result;
}
