#ifndef _INTEGRATETRIANGLE_INCLUDED
#define _INTEGRATETRIANGLE_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "MatVec.h"

class DLL_IO UIntegTri
{
public: 
    UIntegTri();
    UIntegTri(int n, int ncomp = 1);
    UIntegTri(UVector3 x0, UVector3 x1, UVector3 x2, int n, int ncomp = 1);
    UIntegTri(const UIntegTri& IT);
    virtual  ~UIntegTri();
    UIntegTri&            operator=(const UIntegTri &IT);
    ErrorType             GetError() const {if(this) return error; return U_ERROR;}

    ErrorType             SetNcomp(int n);
    ErrorType             SetOrder(int n);
    ErrorType             SetCorners(UVector3 x0, UVector3 x1, UVector3 x2);

protected:
    double                IntegrateScalar(void);
    const double*         IntegrateScalars(void);
    const double*         IntegrateLinear(void);

    void                  SetAllMembersDefault();
    void                  DeleteAllMembers(ErrorType E);
    ErrorType             error;
    UVector3              Normal;      // triangle normal
    double                Area;        // triangle area
    double                Det;

private:
    virtual double        IntegrandScalar(const UVector3& x)   {if(x==UVector3()) return 0.;         return 0.;}
    virtual const double* IntegrandScalars(const UVector3& x)  {if(x==UVector3()) return NULL;       return NULL;}

    int                   Norder;
    double                *Absc;       // Norder/2+2  scaled 1D coords, FORTRAN based
    double                *Weig;       // Norder/2+2  1D weights,       FORTRAN based

    UVector3              c0, c1, c2;  // Corners
    double*               W;           // Norder*Norder integrand weights
    UVector3*             X;           // Norder*Norder integrand points
    double*               LinW;        // 3*Norder*Norder Tri-linear weigts (only computed iff fabs(Det)>1.e-16 ).

    int                   Ncomp;       // The number components of the integrand IntegrandScalar() that are integrated simultaneously.
    double*               Result;      // 3*Ncomp Array containing the results of IntegrateScalar() and IntegrateLinear()
};

#endif// _INTEGRATETRIANGLE_INCLUDED
