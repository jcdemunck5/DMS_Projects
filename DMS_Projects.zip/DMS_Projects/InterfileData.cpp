/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     Object to read scans in Interfile data format                                */
/*                                                                                  */
/*                                                                                  */
/*     AUTHOR:                                                                      */
/*     Jan C. de Munck                                                              */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    30-03-13   Creation
*/

#include<string.h>
#include<stdlib.h>

#include "InterfileData.h"
#include "Euler.h"
#include "Field.h"
#include "FileName.h"
#include "String.h"

/* Inititalize static const parameters. */

void UInterfileData::SetAllMembersDefault(void)
{
    error          = U_OK;

    HeaderFileName = UFileName();
    ScanFileName   = UFileName();
    NSlice         = 0;
    Ndimx          = 0;
    Ndimy          = 0;
    LittleEndian   = true;
    PixX           = 0.;
    PixY           = 0.;
    SDist          = 0.;
}
void UInterfileData::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UInterfileData::UInterfileData(UFileName FileName)
{
    SetAllMembersDefault();
    
    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: UInterfileData::UInterfileData(). Cannot open:  %s \n", (const char*)FileName);
        DeleteAllMembers(U_ERROR);
        return;
    }
    UString Header(FileName);

    if(Header.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterfileData::UInterfileData(). Creating header. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(strncmp((const char*)Header, "!INTERFILE", sizeof("!INTERFILE")-1))
    {
        CI.AddToLog("ERROR: UInterfileData::UInterfileData(). File is not Interfile. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }

    HeaderFileName = FileName;

    ErrorType    E = U_OK;
    UString      S = Header.GetIdentifierIsString("!name of data file", UString(""), false, &E);
    ScanFileName   = HeaderFileName.GetSiblingFileName((const char*)S);
    if(E!=U_OK) 
    {
        ScanFileName = HeaderFileName; 
        ScanFileName.SetExtension("I00");
    }
    if(DoesFileExist(ScanFileName)==false)
    {
        CI.AddToLog("ERROR: UInterfileData::UInterfileData(). ScanFile does not exist: %s \n", (const char*)ScanFileName);
        DeleteAllMembers(U_ERROR);
        return;
    }
    E              = U_OK;
    if(E==U_OK) NSlice = Header.GetIdentifierIsInt("!number of slices", -1, false, &E);
    if(E==U_OK) Ndimx  = Header.GetIdentifierIsInt("!matrix size [1]", -1, false, &E);
    if(E==U_OK) Ndimy  = Header.GetIdentifierIsInt("!matrix size [2]", -1, false, &E);
    if(E==U_OK) PixX   = Header.GetIdentifierIsDouble("!scaling factor (mm/pixel) [1]", -1., false, &E);
    if(E==U_OK) PixY   = Header.GetIdentifierIsDouble("!scaling factor (mm/pixel) [2]", -1., false, &E);
    if(E==U_OK) SDist  = Header.GetIdentifierIsDouble("centre-centre slice separation (pixels)", -1., false, &E);

    if(E!=U_OK || NSlice<=0 || Ndimx<=0 || Ndimy<=0 || PixX<=0. || PixY<=0. || SDist<=0.)
    {
        CI.AddToLog("ERROR: UInterfileData::UInterfileData(). Not all required header parameters can be found. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }

    S              = Header.GetIdentifierIsString("imagedata byte order", UString(""), false, &E);
    LittleEndian   = IsStringCompatible(S, "LITTLEENDIAN", false);

    PixX  /= 10.;
    PixY  /= 10.;
    SDist *= PixX;
}
    
UInterfileData::~UInterfileData()
{
    DeleteAllMembers(U_OK);
}

UField* UInterfileData::GetField(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UInterfileData::GetField(). Object NULL ot erroneous. \n");
        return NULL;
    }
    UVector3 Min     = UVector3(PixX*Ndimx/2,SDist*NSlice/2,-PixY*Ndimy/2);
    UVector3 Max     = Min + UVector3(PixX*(Ndimx-1),SDist*(NSlice-1),-PixY*(Ndimy-1));
    int      dims[3] = {Ndimx,NSlice,Ndimy};

    UField* F = new UField(Min, Max, dims, UField::U_SHORT);
    if(F==NULL || F->GetError()!=U_OK || F->GetSdata()==NULL)
    {
        CI.AddToLog("ERROR: UInterfileData::GetField(). Creating UField object. \n");
        delete F;
    }

    FILE* fp = fopen(ScanFileName, "rb");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UInterfileData::GetField(). ScanFile does not exist: %s \n", (const char*)ScanFileName);
        return NULL;
    }

    short* SD = F->GetSdata();
    for(int y=NSlice-1; y>=0; y--)
        for(int x=Ndimx-1; x>=0; x--)
            for(int z=Ndimy-1; z>=0; z--)
                SD[(z*NSlice+y)*Ndimx+x] = ReadBinaryShort(LittleEndian, fp);

    fclose(fp);
    return F;
}
