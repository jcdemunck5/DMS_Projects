#ifndef _INTERFILEDATA_INCLUDED
#define _INTERFILEDATA_INCLUDED

#include "FileName.h"

 
class UField;

class DLL_IO UInterfileData
{
public:
    UInterfileData(UFileName FileName);
    ~UInterfileData();  

    ErrorType             GetError(void)  const {return error;}

    UField*               GetField(void) const;

    UFileName             GetHeaderFileName(void) const {return HeaderFileName;}
    UFileName             GetScanFileName(void) const {return ScanFileName;}

protected:
    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    ErrorType             error;       // General error flag

    UFileName             HeaderFileName;
    UFileName             ScanFileName;
    int                   NSlice;
    int                   Ndimx;
    int                   Ndimy;
    bool                  LittleEndian;
    double                PixX;
    double                PixY;
    double                SDist;
};

#endif //_INTERFILEDATA_INCLUDED
