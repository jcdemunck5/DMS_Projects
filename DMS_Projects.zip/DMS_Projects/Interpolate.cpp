/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL                                                                    */
/*     Module for handling interpolations in time, from one sample frequency      */
/*     to another.                                                                */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    12-03-06   Creation (Former UInterpolate object is now called UInterpolateSensors)
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    03-01-09   Added operator=() and copy constructor
  JdM    24-04-12   Resample(). Separately treat the trivial case (Ninput==Noutput) 
*/

#include <string.h>
#include <math.h>

#include "Interpolate.h"
UString UInterpolate::Properties = UString();

void UInterpolate::SetAllMembersDefault(void)
{
    Properties  = UString();
    error       = U_OK;
    InterT      = U_INTERPOL_UNKNOWN;

    Ninput      = 0;
    Noutput     = 0;
    InterMatrix = NULL;
    Weigh       = NULL;
    Index       = NULL;
}
void UInterpolate::DeleteAllMembers(ErrorType E)
{
    delete[] InterMatrix;
    delete[] Weigh;
    delete[] Index;
    SetAllMembersDefault();
    error = E;
}

UInterpolate::UInterpolate()
{
    SetAllMembersDefault();
}
UInterpolate::UInterpolate(const UInterpolate& Inter)
{
    SetAllMembersDefault();
    *this = Inter;
}

UInterpolate::UInterpolate(int NsampIn, int NsampOut, InterpolateType INT)
{
    SetAllMembersDefault();
    if(NsampIn<=1 || NsampOut<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolate::UInterpolate(). Invalid input parameters: NsampIn=%d, NsampOut=%d  .\n", NsampIn, NsampOut);
        return;
    }
    InterT  = INT;
    Ninput  = NsampIn;
    Noutput = NsampOut;

/* Only treat the non-trivial case */
    if(Ninput!=Noutput)
    {
        switch(INT)
        {
        case U_INTERPOL_LIN:
            {
                Index = new int[Noutput];
                Weigh = new double[Noutput];
                if(Index==NULL || Weigh==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UInterpolate::UInterpolate(). Memory allocation: Noutput=%d  .\n", Noutput);
                    return;
                }
                for(int k=0; k<Noutput; k++)  
                {
                    Index[k] = int( floor(0.5+k*(Ninput-1.)/(Noutput-1.)) );
                    Weigh[k] = 1. - (Ninput-1.)*k/(Noutput-1.) + Index[k];
                }
            }
            return;
        
        case U_INTERPOL_FFT:
            {
                InterMatrix = new double[NsampOut*NsampIn];
                if(InterMatrix==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UInterpolate::UInterpolate(). Memory allocation: NsampIn=%d, NsampOut=%d  .\n", NsampIn, NsampOut);
                    return;
                }

                double  Rat          = (double)Ninput/Noutput;
                double* pInterMatrix = InterMatrix;
                for(int k=0; k<Noutput; k++)
                    for(int n=0; n<Ninput; n++, pInterMatrix++)
                    {
                        double Arg = PI*(Rat*k-n);
                        if(fabs(Arg)<1.e-7) *pInterMatrix = 1.;
                        else                *pInterMatrix = sin(Arg)/Arg;
                    }
            }
            return;
        default:
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolate::UInterpolate(). Invalid interpolation type (%s).\n", GetInterpolateTypeText(INT));
        }
    }
}
UInterpolate::~UInterpolate()
{
    DeleteAllMembers(U_OK);
}

UInterpolate& UInterpolate::operator=(const UInterpolate& Inter)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::operator=(). this==NULL  . \n");
        static UInterpolate Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&Inter==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Inter) return *this;

    DeleteAllMembers(U_OK);

    error       = Inter.error;
    InterT      = Inter.InterT;
    Properties  = Inter.Properties;
    Ninput      = Inter.Ninput;
    Noutput     = Inter.Noutput;
    if(Inter.InterMatrix)
    {
        InterMatrix = new double[Inter.Ninput * Inter.Noutput];
        if(InterMatrix==NULL)
        {
            CI.AddToLog("ERROR: UInterpolate::operator=(). Memory allocation (Ninput=%d, Noutput=%d). \n", Inter.Ninput, Inter.Noutput);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int k=0; k<Inter.Ninput * Inter.Noutput; k++) InterMatrix[k] = Inter.InterMatrix[k];
    }
    if(Inter.Weigh)
    {
        Weigh = new double[Inter.Noutput];
        if(Index==NULL)
        {
            CI.AddToLog("ERROR: UInterpolate::operator=(). Memory allocation for Weigh[] (Noutput=%d). \n", Inter.Noutput);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int k=0; k<Inter.Noutput; k++) Weigh[k] = Inter.Weigh[k];
    }
    if(Inter.Index)
    {
        Index = new int[Inter.Noutput];
        if(Index==NULL)
        {
            CI.AddToLog("ERROR: UInterpolate::operator=(). Memory allocation for Index[] (Noutput=%d). \n", Inter.Noutput);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int k=0; k<Inter.Noutput; k++) Index[k] = Inter.Index[k];
    }
    return *this;
}

const UString& UInterpolate::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK) 
    {
        Properties = UString("ERROR in parameters of UInterpolate() object.");
        return Properties;
    }
    Properties = UString();

    Properties += UString(GetInterpolateTypeText(InterT), "InterpolationType  = %s \n");
    Properties += UString(Ninput   , "Ninput             = %d \n");
    Properties += UString(Noutput  , "Noutput            = %d \n");    

    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');  
    else                                        Properties.InsertAtEachLine(Comment);
    
    return Properties;
}
ErrorType UInterpolate::Resample(const double* DataIn, double* DataOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolate::Resample(). Object NULL or not properly set. \n");
        return U_ERROR;
    }
    if(DataIn==NULL || DataOut==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::Resample(). Erronous NULL argument(s). \n");
        return U_ERROR;
    }
    if(Ninput!=Noutput)
    {
        switch(InterT)
        {
        case U_INTERPOL_LIN: return ResampleLin(DataIn, DataOut);
        case U_INTERPOL_FFT: return ResampleFFT(DataIn, DataOut);
        }
        CI.AddToLog("ERROR: UInterpolate::Resample(). Unsupported interpolation type (%s). \n", GetInterpolateTypeText(InterT));
        return U_ERROR;
    }
    for(int j=0; j<Noutput; j++) DataOut[j] = DataIn[j];
    return U_OK;
}

ErrorType UInterpolate::ResampleFFT(const double* DataIn, double* DataOut) const
{
    if(this==NULL || error!=U_OK || InterMatrix==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::ResampleFFT(). Object NULL or not properly set. \n");
        return U_ERROR;
    }
    if(DataIn==NULL || DataOut==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::ResampleFFT(). Erronous NULL argument(s). \n");
        return U_ERROR;
    }
    double D0 =  DataIn[0];
    double D1 = (DataIn[Ninput-1]-DataIn[0])/(Ninput -1);
    double D2 = (DataIn[Ninput-1]-DataIn[0])/(Noutput-1);
    
    double* DataInCopy = new double[Ninput];
    if(DataInCopy==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::ResampleFFT(). Memory allocation. \n");
        return U_ERROR;
    }
    for(int n=0; n<Ninput; n++) DataInCopy[n] = DataIn[n]-D0-n*D1;

    const double* pInterMatrix = InterMatrix;
    for(int k=0; k<Noutput; k++)
    {
        DataOut[k] = D0 + k*D2;
        const double* pDatIn = DataInCopy;
        for(int n=0; n<Ninput; n++, pInterMatrix++, pDatIn++)
            DataOut[k] += *pDatIn * *pInterMatrix;
    }
    delete[] DataInCopy;
    return U_OK;
}

ErrorType UInterpolate::ResampleLin(const double* DataIn, double* DataOut) const
{
    if(this==NULL || error!=U_OK || Weigh==NULL || Index==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::ResampleLin(). Object NULL or not properly set. \n");
        return U_ERROR;
    }
    if(DataIn==NULL || DataOut==NULL)
    {
        CI.AddToLog("ERROR: UInterpolate::ResampleLin(). Erronous NULL argument(s). \n");
        return U_ERROR;
    }

    for(int k=0; k<Noutput-1; k++)
        DataOut[k] = Weigh[k] * DataIn[Index[k]] + (1.-Weigh[k])*DataIn[Index[k]+1];
    DataOut[Noutput-1] = DataIn[Ninput-1];

    return U_OK;
}


