#ifndef _INTERPOL_INCLUDED
#define _INTERPOL_INCLUDED

#include "String.h"

class DLL_IO UInterpolate 
{
public:
    UInterpolate();
    UInterpolate(const UInterpolate& Inter);
    UInterpolate(int NsampIn, int NsampOut, InterpolateType INT);
    ~UInterpolate();

    UInterpolate&         operator=(const UInterpolate& Inter);
    ErrorType             GetError(void) const {if(this) return error; return U_ERROR;}
    const UString&        GetProperties(UString Comment) const;
    int                   GetNsampInput(void) const {return Ninput;}
    int                   GetNsampOutput(void) const {return Noutput;}
    ErrorType             Resample(const double* DatIn, double* DataOut) const;

protected:
    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    static UString        Properties;
    ErrorType             error;             // General error flag
    InterpolateType       InterT;

    int                   Ninput;
    int                   Noutput;
    double*               InterMatrix;
    double*               Weigh;
    int*                  Index;

    ErrorType             ResampleFFT(const double* DataIn, double* DataOut) const;
    ErrorType             ResampleLin(const double* DataIn, double* DataOut) const;
};

#endif //_INTERPOL_INCLUDED
