/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL                                                                    */
/*     Module for handling interpolations on a contour. Input data is stored      */
/*     inside object. This object is prefered when same data is interpolated      */
/*     at different samples.                                                      */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-04-16   Creation (based on UInterpolate)
  JdM    27-09-16   Bug Fix ReversePoints(). Cumulative distances were wrongly computed.
*/

#include <string.h>
#include <math.h>

#include "InterpolateCircle.h"
#include "SortSemiSort.h"
UString UInterpolateCircle::Properties = UString();


void UInterpolateCircle::SetAllMembersDefault(void)
{
    Properties  = UString();
    error       = U_OK;
    InputData   = UMatrix();
    NValue      = 0;
    SortedDist  = NULL;
}
void UInterpolateCircle::DeleteAllMembers(ErrorType E)
{
    delete[] SortedDist;
    SetAllMembersDefault();
    error = E;
}

UInterpolateCircle::UInterpolateCircle()
{
    SetAllMembersDefault();
}
UInterpolateCircle::UInterpolateCircle(const UInterpolateCircle& IC)
{
    SetAllMembersDefault();
    *this = IC;
}
UInterpolateCircle::UInterpolateCircle(const UVector2* Xarr, int NP, bool RevPoints)
{
    SetAllMembersDefault();
    if(Xarr==NULL || NP<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Invalid NULL argument, or invalid NP (=%d).\n", NP);
        return;
    }
    for(int n=NP-1; n>0; n--) if(Xarr[0]==Xarr[n]) NP--; else break; // Remove copies of first point, from end of list

    NValue = 1;
    for(int n=1; n<NP; n++) if(Xarr[n-1]!=Xarr[n]) NValue++;
    if(NValue<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Too few unique points: NValue = %d.\n", NValue);
        return;
    }

    InputData = UMatrix(DNULL, 2, NValue);
    if(InputData.GetError()!=U_OK || InputData.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Creating Input matrix.\n");
        return;
    }
    SortedDist = new double[NValue+1];
    if(SortedDist==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Creating Distance array, NP = %d.\n", NP);
        return;
    }

    SortedDist[0] = 0.;
    UVector2 Xold = Xarr[0];
    for(int n=0,m=0; n<NP; n++)
    {
        if(n!=0 && Xarr[n-1]==Xarr[n]) continue;

        InputData.Data[         m] = Xarr[n].Getx();
        InputData.Data[  NValue+m] = Xarr[n].Gety();
        if(m) SortedDist[m]        = SortedDist[m-1] + (Xarr[n]-Xold).GetNorm();
        Xold                       = Xarr[n];
        m++;
    }
    SortedDist[NValue] = SortedDist[NValue-1] + (Xarr[0]-Xold).GetNorm();

    if(RevPoints && ReversePoints()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Reverseing points.\n");
        return;
    }
}
UInterpolateCircle::UInterpolateCircle(const UVector3* Xarr, int NP, bool RevPoints)
{
    SetAllMembersDefault();
    if(Xarr==NULL || NP<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Invalid NULL argument, or invalid NP (=%d).\n", NP);
        return;
    }
    for(int n=NP-1; n>0; n--) if(Xarr[0]==Xarr[n]) NP--; else break; // Remove copies of first point, from end of list

    NValue = 1;
    for(int n=1; n<NP; n++) if(Xarr[n-1]!=Xarr[n]) NValue++;
    if(NValue<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Too few unique points: NValue = %d.\n", NValue);
        return;
    }

    InputData = UMatrix(DNULL, 3, NValue);
    if(InputData.GetError()!=U_OK || InputData.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Creating Input matrix.\n");
        return;
    }
    SortedDist = new double[NValue+1];
    if(SortedDist==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Creating Distance array, NP = %d.\n", NP);
        return;
    }

    SortedDist[0] = 0.;
    UVector3 Xold = Xarr[0];
    for(int n=0,m=0; n<NP; n++)
    {
        if(n!=0 && Xarr[n-1]==Xarr[n]) continue;

        InputData.Data[         m] = Xarr[n].Getx();
        InputData.Data[  NValue+m] = Xarr[n].Gety();
        InputData.Data[2*NValue+m] = Xarr[n].Getz();
        if(m) SortedDist[m]        = SortedDist[m-1] + (Xarr[n]-Xold).GetNorm();
        Xold                       = Xarr[n];
        m++;
    }
    SortedDist[NValue] = SortedDist[NValue-1] + (Xarr[0]-Xold).GetNorm();

    if(RevPoints && ReversePoints()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::UInterpolateCircle(). Reverseing points.\n");
        return;
    }
}
UInterpolateCircle::~UInterpolateCircle()
{
    DeleteAllMembers(U_OK);
}

UInterpolateCircle&   UInterpolateCircle::operator=(const UInterpolateCircle& IC)
{
    if(this==NULL)
    {
        static UInterpolateCircle M; M.error = U_ERROR;
        CI.AddToLog("ERROR: UInterpolateCircle::operator=(). Object NULL.\n");
        return M;
    }
    if(&IC==NULL || IC.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(IC.InputData.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateCircle::operator=(). Matrix of input argument erroneous.\n");
        return *this;
    }
    if(this==&IC) return *this;

    DeleteAllMembers(U_OK);
    NValue    = IC.NValue;
    if(IC.SortedDist)
    {
        SortedDist = new double[NValue+1];
        if(SortedDist==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateCircle::operator=(). Memory allocation, NValue = %d.\n", NValue);
            return *this;
        }
        for(int n=0; n<NValue+1; n++) SortedDist[n] = IC.SortedDist[n];
    }
    InputData = IC.InputData;
    error     = IC.error;
    return *this;
}
const UString& UInterpolateCircle::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UInterpolateCircle() object.");
        return Properties;
    }
    Properties = UString();

    Properties += UString(InputData.Nrow , "Nrow          = %d \n");
    Properties += UString(InputData.Ncol , "NValue        = %d \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}
ErrorType UInterpolateCircle::ReversePoints(void)
{
    if(this==NULL || error!=U_OK)              return U_ERROR;
    if(SortedDist==NULL)                       return U_ERROR;
    
    double* NewSort = new double[NValue+1];
    if(NewSort==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::ReversePoints(). Memory allocation, NValue = %d.\n", NValue);
        return U_ERROR;
    }

    if(InputData.ReverseCols()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::ReversePoints(). Reversing collumns.\n");
        return U_ERROR;
    }
    for(int n=0; n<NValue; n++) NewSort[n] = SortedDist[NValue-1]-SortedDist[NValue-n-1];
    NewSort[NValue] = SortedDist[NValue];
    delete[] SortedDist; SortedDist = NewSort;
    return U_OK;
}

double UInterpolateCircle::GetMaxLamda(const double* Olds, const double* Deltas, int NP)
{
    if(this==NULL || error!=U_OK)              return 0.;
    if(InputData.Nrow<=0 || InputData.Ncol<=1) return 0.;
    if(SortedDist==NULL)                       return 0.;

    if(Olds==NULL || Deltas==NULL || NP<=1)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetMaxLamda(). Invalid (NULL) argument(s), NP = %d \n", NP);
        return 0.;
    }
    for(int n=0; n<NP; n++)
    {
        if(Olds[n]<0 || Olds[n]>1.)
        {
            CI.AddToLog("ERROR: UInterpolateCircle::GetMaxLamda(). Olds[%d] coord out of range (=%f) \n", n, Olds[n]);
            return 0.;
        }
        if(n<NP-1 && Olds[n]>=Olds[n+1])
        {
            CI.AddToLog("ERROR: UInterpolateCircle::GetMaxLamda(). Olds[%d] =%f not sorted, %f  \n", n, Olds[n], Olds[n+1]);
            return 0.;
        }
    }

    double LamMax =  0.; 
    int    nmax   = -1;
    for(int n=0; n<NP; n++)
    {
        int nn = (n+1)%NP;
        if(Deltas[nn]-Deltas[n]>-1.e-5) continue;

        double DOld    = (n==NP-1) ? 1.+Olds[0]-Olds[n] : Olds[nn]-Olds[n];
        double LamTest = -DOld/(Deltas[nn]-Deltas[n]);
        if(LamTest<0                ) continue; // Crossing occurs for negative Lamba
        if(nmax>=0 && LamTest>LamMax) continue;
        nmax   = n; 
        LamMax = LamTest;
    }
    return LamMax;
}

ErrorType UInterpolateCircle::ComputeInterpar(double s, int* Im, int* Ip, double* W) const
{
    if(this==NULL || error!=U_OK)              return U_ERROR;
    if(InputData.Nrow<=0 || InputData.Ncol<=1) return U_ERROR;
    if(SortedDist==NULL)                       return U_ERROR;
    if(Im==NULL || Ip==NULL)                   return U_ERROR;

    s = s -floor(s);
    s = s - int(s);
    s = MIN(1.,MAX(0.,s));

    double Dist = s*SortedDist[NValue];
    *Im         =  SearchIndex(Dist, SortedDist, NValue+1);
    *Im         = ( MAX(0, (*Im)-1)     ) % NValue;
    *Ip         = (        (*Im)+1      ) % NValue;

    if(W) *W    = (SortedDist[(*Im)+1] - Dist)/( SortedDist[(*Im)+1] - SortedDist[(*Im)]);
    return U_OK;
}

double UInterpolateCircle::GetInterpolValue(double s, int icomp) const
{
    if(this==NULL || error!=U_OK) return 0.;
    if(icomp<0 || icomp>=InputData.Nrow)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetInterpolValue(). Argument out of range (icomp=%d)\n", icomp);
        return 0.;
    }

    int    Im = 0;
    int    Ip = 1;
    double W  = 1.;
    if(ComputeInterpar(s, &Im, &Ip, &W)!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetInterpolValue(). Computing interpolation parameters. \n");
        return 0.;
    }
    return W*InputData.Data[icomp*InputData.Ncol+Im] + (1.-W)*InputData.Data[icomp*InputData.Ncol+Ip];
}
UVector2 UInterpolateCircle::GetInterpolVector2(double s) const
{
    if(this==NULL || error!=U_OK) return UVector2();
    if(InputData.Nrow!=2)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetInterpolValue(). Nrow should be 2, it is %d\n", InputData.Nrow);
        return UVector2();
    }
    return UVector2(GetInterpolValue(s,0), GetInterpolValue(s,1));
}
UVector3 UInterpolateCircle::GetInterpolVector3(double s) const
{
    if(this==NULL || error!=U_OK) return UVector3();
    if(InputData.Nrow!=3)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetInterpolValue(). Nrow should be 3, it is %d\n", InputData.Nrow);
        return UVector3();
    }
    return UVector3(GetInterpolValue(s,0), GetInterpolValue(s,1), GetInterpolValue(s,2));
}
UVector2 UInterpolateCircle::GetTangent2(double s) const
{
    if(this==NULL || error!=U_OK) return UVector2();
    if(InputData.Nrow!=2)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetTangent2(). Nrow should be 2, it is %d\n", InputData.Nrow);
        return UVector2();
    }
    int    Im = 0;
    int    Ip = 1;
    if(ComputeInterpar(s, &Im, &Ip)!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetTangent2(). Computing interpolation parameters. \n");
        return UVector2();
    }
    UVector2 T(InputData.Data[0*InputData.Ncol+Ip]-InputData.Data[0*InputData.Ncol+Im], 
               InputData.Data[1*InputData.Ncol+Ip]-InputData.Data[1*InputData.Ncol+Im]);
    T.Normalize();
    return T;
}
UVector3 UInterpolateCircle::GetTangent3(double s) const
{
    if(this==NULL || error!=U_OK) return UVector3();
    if(InputData.Nrow!=3)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetTangent3(). Nrow should be 3, it is %d\n", InputData.Nrow);
        return UVector3();
    }
    int    Im = 0;
    int    Ip = 1;
    if(ComputeInterpar(s, &Im, &Ip)!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateCircle::GetTangent3(). Computing interpolation parameters. \n");
        return UVector3();
    }
    UVector3 T(InputData.Data[0*InputData.Ncol+Ip]-InputData.Data[0*InputData.Ncol+Im], 
               InputData.Data[1*InputData.Ncol+Ip]-InputData.Data[1*InputData.Ncol+Im],
               InputData.Data[2*InputData.Ncol+Ip]-InputData.Data[2*InputData.Ncol+Im]);
    T.Normalize();
    return T;
}

