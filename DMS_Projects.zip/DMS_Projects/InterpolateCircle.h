#ifndef _INTERPOLCIRCLE_INCLUDED
#define _INTERPOLCIRCLE_INCLUDED

#include "Matrix.h"

class DLL_IO UInterpolateCircle 
{
public:
    UInterpolateCircle();
    UInterpolateCircle(const UInterpolateCircle& Inter);
    UInterpolateCircle(const UVector2* Xarr, int NP, bool RevPoints);
    UInterpolateCircle(const UVector3* Xarr, int NP, bool RevPoints);
    ~UInterpolateCircle();

    UInterpolateCircle&   operator=(const UInterpolateCircle& IC);
    ErrorType             GetError(void) const {if(this) return error; return U_ERROR;}
    const UString&        GetProperties(UString Comment) const;

    ErrorType             ReversePoints(void);
    double                GetMaxLamda(const double* Olds, const double* Deltas, int NP);

    double                GetInterpolValue(double s, int icomp) const;
    UVector2              GetInterpolVector2(double s) const;
    UVector3              GetInterpolVector3(double s) const;
    UVector2              GetTangent2(double s) const;
    UVector3              GetTangent3(double s) const;

protected:
    void                  SetAllMembersDefault(void);
    void                  DeleteAllMembers(ErrorType E);

private:
    static UString        Properties;
    ErrorType             error;             // General error flag

    UMatrix               InputData;
    int                   NValue;            // Copy of InputData.Nrow
    double*               SortedDist;        // NValue +1 Distances from first point 
    ErrorType             ComputeInterpar(double s, int* Im, int* Ip, double* W=NULL) const;
};

#endif //_INTERPOLCIRCLE_INCLUDED
