/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL                                                                    */
/*     Module for handling interpolations from one grid to another.               */
/*     C++ version.                                                               */
/*                                                                                */
/*     METHODS                                                                    */
/*     The method is based on the computation of a minimum norm distributed       */
/*     source, corresponding to the data to be interpolated. Then using this      */
/*     source, the magnetic field is computed in the new grid. In the             */
/*     compuatation of the minimum norm sources a smoothing parameter (threshold) */
/*     can be set. The advantage of this method is that the interpolated          */
/*     extrapolated field automatically satisfies  divB=0 and curlB=0.            */
/*                                                                                */
/*     USAGE                                                                      */
/*     The computation of the sources and the corresponding field is stored in    */ 
/*     one big inter/extrapolation matrix, which is a private variable of the     */
/*     UInterpol object. This matrix has to be computed first, (using             */
/*     ComputeMatrix() ), before interpolations can be carried out. Then,         */
/*     the inter/extrapolation can be performed with the functions ComputeField().*/
/*                                                                                */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    11-12-96   creation
  Jdm    21-02-97   derived from C-version.
  Jdm    04-03-98   changed order of parameters in ComputeField()
  Jdm    02-06-98   Take into account that the position of the sphere on which the
                    minimum norm solution is projected may be shifted w.r.t. the gradiometers.
  Jdm    02-06-98   Test distance between grid2 and sphere radius.
  Jdm    02-07-98   BUG fix: ComputeMatrix() did not work if _nP1<_nP2 because no sufficient
                    memory was allocated for col[].
  JdM    08-10-98   separated include-files
  Jdm    03-01-99   Added more comments.
  JdM    25-01-01   General upgrade
  JdM    01-10-01   Rename UInterpol to UInterpolateSensors and derive it from UJacobi
                    Added SetSpherePos()
  JdM    14-03-05   Disable MS-language extensions, correct for loops
  JdM    12-03-06   Renamed object as UInterpolateSensorsSensors
  JdM    10-04-07   Use UString in GetProperties()
                    Store input and output UGrid as data members in object
                    Several updates. e.g. added GetInterpolatedMultiChan(), 
                    removed SetSpherePos() (now included in ComputeMatrix())
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-04-09   Bug fix: GetProperties(): adding base class properties.
  JdM    03-11-10   Various changes in interfacing constructor.
                    Account for compensation colis in computing matrix elements
                    Added operator=() and default constructor
  JdM    29-01-13   BUG FIX. ComputeField(). Addressing subset of Bf1[] array.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    30-07-14   Eliminate use of UJacobi object. Use UMatrix and UMatrixSymmetric instead. Remove UInterpolateSensors base class
*/

#include <string.h>

#include "InterpolateSensors.h"
#include "MultiChan.h"
#include "MatrixSymmetric.h"
#include "GridFit.h"

UString UInterpolateSensors::Properties = UString();

void UInterpolateSensors::SetAllMembersDefault()
{
    error           = U_OK;
    Properties      = UString();
    Spos            = UVector3();
    r0              = 0.; 
    EigenThreshold  = 0.;
    NEigenUsed      = 0;
    Matrix          = UMatrix(); 
    GFrom           = NULL;
    GTo             = NULL;
}

void UInterpolateSensors::DeleteAllMembers(ErrorType E)
{
    delete   GFrom;
    delete   GTo;
    SetAllMembersDefault();
    error = E;
}

UInterpolateSensors::UInterpolateSensors()
{
    SetAllMembersDefault();
}
UInterpolateSensors::UInterpolateSensors(const UInterpolateSensors& IS)
{
    SetAllMembersDefault();
    *this = IS;
}
UInterpolateSensors::UInterpolateSensors(const UGrid* GridFrom, const UGrid* GridTo, double R0, double ET) 
/*
    Initiatialize the objects as follows:
    r0   - The radius of the sphere on which the distributed minimum norm 
           source is computed [cm].
    ET   - The trucation parameter: all eigenvalues smaller than ET are ignored.
    Spos - Position of the sphere on which the distributed minimum norm 
           source is computed [cm].
 */
{ 
    SetAllMembersDefault();
    if(GridFrom==NULL || GridFrom->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::UInterpolateSensors(): Erroneous GridFrom argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(GridTo==NULL || GridTo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::UInterpolateSensors(): Erroneous GridTo argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(R0<1.)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::UInterpolateSensors(): Invalid R0 (=%f) .\n", R0);
        DeleteAllMembers(U_ERROR);
        return;
    }
    r0              = R0; 
    EigenThreshold  = MAX(0.,ET);

    if(ComputeMatrix(GridFrom, GridTo, EigenThreshold)!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::UInterpolateSensors(): Setting interpolation matrix.\n");
        DeleteAllMembers(U_ERROR);
        return;
    }
}

UInterpolateSensors::~UInterpolateSensors()
{
    DeleteAllMembers(U_OK);
}

UInterpolateSensors& UInterpolateSensors::operator=(const UInterpolateSensors& IS)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::operator=(). this==NULL  . \n");
        static UInterpolateSensors Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&IS==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&IS) return *this;

    DeleteAllMembers(U_OK);

    error           = IS.error;
    Properties      = IS.Properties;
    Spos            = IS.Spos;
    r0              = IS.r0; 
    EigenThreshold  = IS.EigenThreshold;
    NEigenUsed      = IS.NEigenUsed;
    
    if(IS.GFrom)
    {
        GFrom = new UGrid(*IS.GFrom);
        if(GFrom==NULL || GFrom->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateSensors::operator=(). Copying GFrom-grid. \n");
            return *this;
        }
    }
    if(IS.GTo)
    {
        GTo = new UGrid(*IS.GTo);
        if(GTo==NULL || GTo->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateSensors::operator=(). Copying GTo-grid. \n");
            return *this;
        }
    }
    Matrix = IS.Matrix;
    if(Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSensors::operator=(). Copying Matrix object. \n");
        return *this;
    }
    return *this;
}

ErrorType UInterpolateSensors::ComputeMatrix(const UGrid *GridFrom, const UGrid *GridTo, double ET)
/*
    Compute matrix to interpolate MEG data recorded on GridFrom to MEG data 
    defined on GridTo
 */
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(r0<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(). Source radius not properly set (r0=%f).\n", r0);
        return U_ERROR;
    }
    if(GridFrom==NULL || GridFrom->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Erroneous GridFrom argument. \n");
        return U_ERROR;
    }
    if(GridTo==NULL || GridTo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Erroneous GridTo argument. \n");
        return U_ERROR;
    }

    UGridFit G12(*GridFrom);
    if(G12.AddGrid(GridTo)!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Building combined grid. \n");
        return U_ERROR;
    }

    double Rdum = 0;
    if(G12.FitSphere(Spos, &Rdum)<0.)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Fitting sphere to combined grid. \n");
        return U_ERROR;
    }
    delete GFrom;   GFrom = new UGrid(*GridFrom);
    delete GTo;     GTo   = new UGrid(*GridTo  );
    if(GFrom==NULL || GFrom->GetError()!=U_OK || GFrom->GetNpoints()<=0 ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK || GTo  ->GetNpoints()<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Copying sensor grids.  \n");
        return U_ERROR;
    }

    for(int i=0; i<GTo->GetNpoints(); i++)
    {
        if( (GTo->GetPosition(i) - Spos).GetNorm() - r0 <1. )
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(). Sensor %d closer than 1 cm. to sphere surface. \n",i);
            return U_ERROR;
        }
    }

    int nP1 = GFrom->GetNpoints();
    int nP2 = GTo  ->GetNpoints();
    

/* Create and fill UMatrix objects */
    UMatrixSymmetric FromFrom((double*)NULL, nP1, nP1);
    UMatrix          ToFrom  ((double*)NULL, nP2, nP1);
    Matrix = ToFrom;

    for(int i1=0;i1<nP1;i1++)
    {
        for(int i2=i1;i2<nP1;i2++) FromFrom.SetElement(i1,i2, GetMatrixElem(GFrom->GetSensorPointer(i1), GFrom->GetSensorPointer(i2)));
        for(int i2= 0;i2<nP2;i2++)   ToFrom.SetElement(i2,i1, GetMatrixElem(GTo  ->GetSensorPointer(i2), GFrom->GetSensorPointer(i1)));
    }

    NEigenUsed = FromFrom.GetNPosEig(ET);
    if(FromFrom.GetError()!=U_OK || NEigenUsed<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeMatrix(): Decomposition of the system matrix or setting number of posivive eigen values used (Npos=%d).\n", NEigenUsed);
        return U_ERROR;
    }

    Matrix   = ToFrom * FromFrom.GetInverse(NEigenUsed, 0);

    return U_OK;
}
const UString& UInterpolateSensors::GetProperties(UString Comment) const
{    
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UInterpolateSensors-object");
        return Properties;
    }
    Properties  = UString(" Matrix: \n")
                + Matrix.GetProperties(UString("   "));

    Properties += UString(Spos.GetProperties(), " SpherePos      = %s  \n") 
                + UString(r0                  , " SourceRadius   = %f  \n") 
                + UString(EigenThreshold      , " EigenThreshold = %f  \n") 
                + UString(NEigenUsed          , " NEigenUsed     = %d  \n");
    
    if(GFrom)  Properties += UString(GFrom->GetNpoints()," NPointsFrom    = %d \n");
    if(GTo)    Properties += UString(GTo  ->GetNpoints()," NPointsTo      = %d \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');  
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

UVector3 UInterpolateSensors::GetSphere(void) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetSphere(). NULL or erroneous object.\n");
        return UVector3();
    }
    return Spos;
}
const UGrid* UInterpolateSensors::GetGridFrom(void) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetGridFrom(). NULL or erroneous object.\n");
        return NULL;
    }
    return GFrom;
}
const UGrid* UInterpolateSensors::GetGridTo(void) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetGridTo(). NULL or erroneous object.\n");
        return NULL;
    }
    return GTo;
}

UMultiChan* UInterpolateSensors::GetInterpolatedMultiChan(const UMultiChan* MCfrom) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). NULL or erroneous object.\n");
        return NULL;
    }
    if(GFrom==NULL || GFrom->GetError()!=U_OK ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). NULL or erroneous sensor grids.\n");
        return NULL;
    }
    if(Matrix.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Matrix NULL or not set.\n");
        return NULL;
    }
    if(MCfrom==NULL || MCfrom->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Erroneous NULL argument(s).\n");
        return NULL;
    }
    if(MCfrom->GetNChan()<=0 || MCfrom->GetNtime()<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Invalid number of time samples of channels.\n");
        return NULL;
    }
    int* SubIndices = NULL;
    int  NSub       = 0;
    if(*GFrom != *MCfrom->GetSensorGrid())
    {
        if(GFrom->IsSubGrid(MCfrom->GetSensorGrid())==false)
        {
            CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Requested sensor grid is not a sub-grid of interpolation object sensor grid.\n");
            return NULL;
        }

        SubIndices =  GFrom->GetSubGridIndices(MCfrom->GetSensorGrid());
        if(SubIndices==NULL)
        {
            CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Getting sub-grid indices. \n");
            return NULL;
        }
        NSub = MCfrom->GetSensorGrid()->GetNpoints();
    }
    double*     Data = new double[GTo->GetNpoints()*MCfrom->GetNtime()];
    if(Data==NULL)
    {
        delete[] Data; delete[] SubIndices;
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Memory allocation. Nsensors = %d, Ntime = %d   .\n", GTo->GetNpoints(), MCfrom->GetNtime());
        return NULL;
    }
    if(ComputeField(MCfrom->GetData(), SubIndices, NSub, Data, MCfrom->GetNtime())!=U_OK) 
    {
        delete[] Data; delete[] SubIndices;
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Interpolating data .\n");
        return NULL;
    }

    UMultiChan* MC = new UMultiChan(Data, GTo, MCfrom->GetNtime(), MCfrom->GetSampTime());
    delete[] Data; delete[] SubIndices;

    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UInterpolateSensors::GetInterpolatedMultiChan(). Creating UMultiChan-object.\n");
        return NULL;
    }
    return MC;
}

// private funtions:
ErrorType UInterpolateSensors::ComputeField(const double *Bfield1, double *Bfield2, int nsamp) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GFrom==NULL || GFrom->GetError()!=U_OK ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous sensor grids.\n");
        return U_ERROR;
    }
    if(Matrix.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Matrix NULL or not set.\n");
        return U_ERROR;
    }
    if(Bfield1==NULL || Bfield2==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Erroneous NULL argument(s).\n");
        return U_ERROR;
    }
    if(nsamp<0)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). nsamp = %d .\n", nsamp);
        return U_ERROR;
    }
    return ComputeField(Bfield1, NULL, 0, Bfield2, nsamp);
}

ErrorType UInterpolateSensors::ComputeField(const double *Bfield1, const int* SubIn, int NSub, double *Bfield2, int nsamp) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GFrom==NULL || GFrom->GetError()!=U_OK ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous sensor grids.\n");
        return U_ERROR;
    }
    if(Matrix.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Matrix NULL or not set.\n");
        return U_ERROR;
    }
    if(Bfield1==NULL || Bfield2==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Erroneous NULL argument(s).\n");
        return U_ERROR;
    }
    if(nsamp<0)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). nsamp = %d .\n", nsamp);
        return U_ERROR;
    }
    if(SubIn)
    {
        if(NSub<0 || NSub>= GFrom->GetNpoints())
        {
            CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Invalid number of sub-samples, NSub = %d .\n", NSub);
            return U_ERROR;
        }
    }

    int nP1 = GFrom->GetNpoints();
    int nP2 = GTo  ->GetNpoints();

    for(int n=0; n<nsamp; n++)
    {
        const double* mat  = Matrix.GetMatrixArray();
        for(int i2=0;i2<nP2;i2++)
        {
            const double* Bf1 = Bfield1+n;
            double*       Bf2 = Bfield2+i2*nsamp+n;
            *Bf2 = 0.;

            if(SubIn)
            {
                for(int i1=0;i1<NSub;i1++,Bf1+=nsamp) *Bf2 += mat[SubIn[i1]]  *  *Bf1;
                mat += nP1;
            }
            else
            {
                for(int i1=0;i1<nP1;i1++,mat++,Bf1+=nsamp)
                    *Bf2 += *mat * *Bf1;
            }
        }
    }
    return U_OK;
}

ErrorType UInterpolateSensors::ComputeField(const double *Bfield1, double *Bfield2) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GFrom==NULL || GFrom->GetError()!=U_OK ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous sensor grids.\n");
        return U_ERROR;
    }
    if(Matrix.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Matrix NULL or not set.\n");
        return U_ERROR;
    }
    if(Bfield1==NULL || Bfield2==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Erroneous NULL argument(s).\n");
        return U_ERROR;
    }
    return ComputeField(Bfield1, NULL, 0, Bfield2);
}
ErrorType UInterpolateSensors::ComputeField(const double *Bfield1, const int* SubIn, int NSub, double *Bfield2) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GFrom==NULL || GFrom->GetError()!=U_OK ||
       GTo  ==NULL || GTo  ->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). NULL or erroneous sensor grids.\n");
        return U_ERROR;
    }
    if(Matrix.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Matrix NULL or not set.\n");
        return U_ERROR;
    }
    if(Bfield1==NULL || Bfield2==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Erroneous NULL argument(s).\n");
        return U_ERROR;
    }
    if(SubIn)
    {
        if(NSub<0 || NSub>= GFrom->GetNpoints())
        {
            CI.AddToLog("ERROR: UInterpolateSensors::ComputeField(). Invalid number of sub-samples, NSub = %d .\n", NSub);
            return U_ERROR;
        }
    }

    int nP1 = GFrom->GetNpoints();
    int nP2 = GTo  ->GetNpoints();

    if(SubIn)
    {
        const double* mat = Matrix.GetMatrixArray();
        for(int i=0;i<nP2;i++,Bfield2++)
        {
            const double* Bf1 = Bfield1;
            *Bfield2          = 0;
            for(int j=0;j<NSub;j++)  *Bfield2 += mat[SubIn[j]] * Bf1[SubIn[j]];
            mat += nP1;
        }
    }
    else
    {
        const double* mat = Matrix.GetMatrixArray();
        for(int i=0;i<nP2;i++,Bfield2++)
        {
            const double* Bf1 = Bfield1;
            *Bfield2          = 0;
            for(int j=0;j<nP1;j++)  *Bfield2 += *mat++ * *Bf1++;
        }
    }
    return U_OK;
}

double UInterpolateSensors::GetMatrixElem(const USensor* S1, const USensor* S2) const
/*
    Compute the innerproduct between the sensor sens1 of grid1 and
    sensor sens2 of grid2.
 */
{
    if(S1==NULL || S2==NULL) return 0.;
    
    UVector3 x1   = S1->Getx() - Spos;
    UVector3 n1   = S1->Getn();

    UVector3 x2   = S2->Getx() - Spos;
    UVector3 n2   = S2->Getn();
        
    double   Sum  = GetMatrixElem(x1, n1, x2, n2);
    if(S1->GetStype()==USensor::U_SEN_GRAD)
    {
        UVector3 x1c  = S1->Getc() - Spos;
        Sum          -= GetMatrixElem(x1c, n1, x2, n2);
    }
    if(S2->GetStype()==USensor::U_SEN_GRAD)
    {
        UVector3 x2c  = S2->Getc() - Spos;
        Sum          -= GetMatrixElem(x1, n1, x2c, n2);
    }
    if(S1->GetStype()==USensor::U_SEN_GRAD && S2->GetStype()==USensor::U_SEN_GRAD)
    {
        UVector3 x1c  = S1->Getc() - Spos;
        UVector3 x2c  = S2->Getc() - Spos;
        Sum          += GetMatrixElem(x1c, n1, x2c, n2);
    }
    return Sum;
}
double UInterpolateSensors::GetMatrixElem(const UVector3& X1, const UVector3& n1, const UVector3& X2, const UVector3& n2) const
{
    double   r1   = X1.GetNorm(); 
    double   r2   = X2.GetNorm();

    if(r1<=0. || r2<=0.) return 0.;

    UVector3 x1   = X1/r1;
    UVector3 x2   = X2/r2;
 
// Compute the geometrical factors g1, g2, g3 and g4
    UVector3 x1x2 = x1^x2;
    UVector3 n1x1 = n1^x1;
    UVector3 n2x2 = n2^x2;

    double   g1   = (n1&x1)*(n2&x2);
    double   g2   =  x1x2&(((n2&x2)*n1x1)-((n1&x1)*n2x2));
    double   g3   = -n1x1&(x1^(x2^n2x2));
    double   g4   = -(x1x2&n1x1)*(x1x2&n2x2);

// Compute the Legendre series 
    double s1=0,s2=0,s3=0,s4=0;             // Sums of Legendre functions
    
    Legendre( x1&x2, r0*r0/(r1*r2), &s1, &s2, &s3, &s4);
    return 10.e6*(g1*s1+g2*s2+g3*s3+g4*s4)/(r1*r1*r2*r2);
}

            
#define MAXTER 200 // Maximum number of terms in Legendre series
void UInterpolateSensors::Legendre(double cosom, double lam, double *s1, double *s2, double *s3, double *s4) const
/*
    Compute the Legendre series necessary in the lead field inner product computations.
 */
{
    int    n,n2,n3;
    double Pn ,Pna, Pnaa;  // Legendre Polynomials, first and second derivative
    double Pn1,Pn1a,Pn1aa; // The same for n-1
    double lamn,h;
    double dis,dis1,dis2,dis3,dislam;

    dis    =  sqrt(1.-2*lam*cosom+lam*lam);
    dis1   =  1./dis;
    dis2   =  dis*dis;
    dis3   =  dis*dis2;
    dislam =  1.-lam*cosom+dis;

    *s1    = -1. + (1.-lam*lam)/dis3;
    *s2    =  lam/dis3;
    *s3    =  lam*(1+dis1)/dislam;
    *s4    =  (lam*lam)*(dislam/dis3 + (1+dis1)*(1+dis1) )/(dislam*dislam);
    lamn   = lam;
    Pn     = cosom; // n=1
    Pn1    = 1.;    // n=0
    Pn1a   = 0.;
    Pn1aa  = 0.;

    n2     = 3;
    n3     = 4;
    for(n=1; n<MAXTER && lamn>1.e-6 ;n++,n2+=2,n3+=3) 
    {
        Pna   =  n   *Pn1  + cosom*Pn1a;   //  first derivative
        Pnaa  = (n+1)*Pn1a + cosom*Pn1aa;  // second derivative

        h     = lamn/n2;

        *s1  -= h*Pn;
        *s2  -= h*Pna;
        h    /= n*(n+1);
        *s3  -= n3*h*Pna;
        *s4  -= n3*h*Pnaa;

        lamn *= lam;
        h     = Pn;
        Pn    = (n2*cosom*Pn-n*Pn1)/(n+1);
        Pn1   = h;
        Pn1a  = Pna;
        Pn1aa = Pnaa;
    }
    *s1 /= 4;
    *s2 /= 2;
    *s3 /= 2;
    *s4 /= 2;
}

