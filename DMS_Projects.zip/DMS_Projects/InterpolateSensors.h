#ifndef _INTERPOLSENSORS_INCLUDED
#define _INTERPOLSENSORS_INCLUDED

#include "String.h"
#include "Matrix.h"

class UMultiChan;
class UGrid;
class USensor;

class DLL_IO UInterpolateSensors
{
public:
    UInterpolateSensors();
    UInterpolateSensors(const UInterpolateSensors& IS);
    UInterpolateSensors(const UGrid* GridFrom, const UGrid* GridTo, double R0, double ET= 1.e-7);
    ~UInterpolateSensors();
    UInterpolateSensors&  operator=(const UInterpolateSensors& IS);

    UMultiChan*    GetInterpolatedMultiChan(const UMultiChan* MCfrom) const;
    ErrorType      ComputeField(const double *Bfield1, double *Bfield2) const;
    ErrorType      ComputeField(const double *Bfield1, const int* SubIn, int NSub, double *Bfield2) const;
    ErrorType      ComputeField(const double *Bfield1, double *Bfield2, int nsamp) const;
    ErrorType      ComputeField(const double *Bfield1, const int* SubIn, int NSub, double *Bfield2, int nsamp) const;

    const UString& GetProperties(UString Comment) const;
    ErrorType      GetError(void) const {return error;}

    UVector3       GetSphere(void) const;
    const UGrid*   GetGridFrom(void) const;
    const UGrid*   GetGridTo(void) const;

protected:
    void           SetAllMembersDefault(void);
    void           DeleteAllMembers(ErrorType E);

private:
    static UString Properties;
    ErrorType      error;             // General error flag

    UVector3       Spos;              // Position of the best fitting sphere wrt to gradiometer
    UMatrix        Matrix;            // Matrix used to transfer measured fields of one grid into interplated values of another grid
    UGrid*         GFrom;             // Sensor grid to interpolate from 
    UGrid*         GTo;               // Sensor grid to interpolate to 
    double         r0;                // Integration surface radius
    double         EigenThreshold;    // All eigenvalues smaller than the largest times EigenThreshhold are set to zero
    int            NEigenUsed;        // Number of eigenvalues used with EigenThreshold

    ErrorType      ComputeMatrix(const UGrid *Grid1, const UGrid *Grid2, double ET);
    double         GetMatrixElem(const USensor* S1, const USensor* S2) const;
    double         GetMatrixElem(const UVector3& x1, const UVector3& n1, const UVector3& x2, const UVector3& n2) const;
    void           Legendre(double cosom, double lam, double *s1, double *s2, double *s3, double *s4) const;
};

#endif //_INTERPOLSENSORS_INCLUDED
