/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     GENERAL                                                                    */
/*     Module for handling interpolations for data on a sphere.                   */
/*                                                                                */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    27-01-08   creation, derived from InterpolateSensors.cpp
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    29-01-14   Bug Fix: GetProperties(). Reset Properties before adding text.
  JdM    21-12-14   Major update of algorithm. Use UMatrix and UMatrixSymmetric instead of UJacobi
*/

#include <string.h>

#include "InterpolateSphere.h"
#include "MultiChan.h"
#include "GridFit.h"
#include "MatrixSymmetric.h"

UString UInterpolateSphere::Properties = UString();

void UInterpolateSphere::SetAllMembersDefault()
{
    error           = U_OK;
    Properties      = UString();
    Spos            = UVector3();
    Morder          = 4;
    NEigenUsed      = 0;
    GridPot         = NULL;
    Pot2Lap         = UMatrix(); 
}

void UInterpolateSphere::DeleteAllMembers(ErrorType E)
{
    delete   GridPot;
    SetAllMembersDefault();
    error = E;
}

UInterpolateSphere::UInterpolateSphere()
{
    SetAllMembersDefault();
}
UInterpolateSphere::UInterpolateSphere(const UInterpolateSphere &IS)
{
    SetAllMembersDefault();
    *this = IS;
}

UInterpolateSphere::UInterpolateSphere(const UGrid* GridEEG, int Mord)  
{ 
    SetAllMembersDefault();
    if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::UInterpolateSphere(). Erroneous UGrid argument. \n");
        return;
    }
    if(Mord<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::UInterpolateSphere(). Erroneous Morder (%d)  \n", Mord);
        return;
    }
    GridPot = new UGridFit(*GridEEG);    
    if(GridPot==NULL || GridPot->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::UInterpolateSphere(). Copying UGrid. \n");
        return;
    }
    int NRem = GridPot->RemoveZeroSensors();
    if(NRem>0)
        CI.AddToLog("WARNING: UInterpolateSphere::UInterpolateSphere(). %d zero sensors (at origin) removed .\n", NRem);

    double Rad = 0;
    if(GridPot->FitSphere(Spos, &Rad)<0.)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::UInterpolateSphere(). Fitting sphere through sensors. \n");
        return;
    }

    Morder          = Mord;

    if(ComputePot2LapMatrix()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::UInterpolateSphere(). Computing interpolation matrix. \n");
        return;
    }
}

UInterpolateSphere::~UInterpolateSphere()                     
{
    DeleteAllMembers(U_OK);
}

UInterpolateSphere& UInterpolateSphere::operator=(const UInterpolateSphere &IS)
{
    if(this==NULL || &IS==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::operator=(). this==NULL or invalid NULL Address argument. \n");
        if(this) 
        {
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        static UInterpolateSphere ISDef;
        ISDef.error = U_ERROR;
        return ISDef;
    }
    if(this==&IS) return *this;

    DeleteAllMembers(U_OK);

    Spos            = IS.Spos;
    Morder          = IS.Morder;
    NEigenUsed      = IS.NEigenUsed;
    if(IS.GridPot)
    {
        GridPot = new UGridFit(*IS.GridPot);
        if(GridPot==NULL || GridPot->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateSphere::operator=(). Copying GridPot. \n");
            return *this;
        }
        Pot2Lap = IS.Pot2Lap;
        if(Pot2Lap.GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UInterpolateSphere::operator=(). Copying Pot2Lap. \n");
            return *this;
        }
    }
    return *this;
}

const UString& UInterpolateSphere::GetProperties(UString Comment) const
{    
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UInterpolateSphere-object");
        return Properties;
    }

    Properties  = UString();
    Properties += UString(Spos.GetProperties(), " SpherePos      = %s  \n") 
                + UString(Morder              , " Morder         = %d  \n")
                + UString(NEigenUsed          , " NEigenUsed     = %d  \n");
    if(GridPot)
        Properties += UString(GridPot->GetNpoints(), " Npoints         = %d  \n");

    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');  
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}

int UInterpolateSphere::GetNEigenUsed(void) const
{
    if(this==NULL || error!=U_OK) return 0;
    return NEigenUsed;
}
UVector3 UInterpolateSphere::GetSpherePos(void) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSpherePos(). NULL or erroneous object.\n");
        return UVector3();
    }
    return Spos;
}

ErrorType UInterpolateSphere::ComputePot2LapMatrix(void)
/*
    Compute matrix to interpolate MEG data recorded on GridFrom to MEG data 
    defined on GridTo
 */
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputePot2LapMatrix(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GridPot==NULL || GridPot->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputePot2LapMatrix(): Erroneous GridPot argument. \n");
        return U_ERROR;
    }
    int NP   = GridPot->GetNpoints();
    Pot2Lap  = UMatrix((double*)NULL, NP, NP);
    UMatrixSymmetric G((double*)NULL, NP, NP);

    for(int i1=0;i1<NP;i1++)
    {  
        USensor S1 = GridPot->GetSensor(i1);
        for(int i2=0;i2<NP;i2++)
        {
            USensor S2 = GridPot->GetSensor(i2);
            if(i2>=i1)
            {
                G      .SetElement(i1, i2, MatrixElem(S1.Getx(),S2.Getx(), Morder, false));
                Pot2Lap.SetElement(i1, i2, MatrixElem(S1.Getx(),S2.Getx(), Morder, true ));
            }
            else
                Pot2Lap.SetElement(i1, i2, Pot2Lap.GetElement(i2, i1));
        }
    }

/* Create UJacobi base object*/
    NEigenUsed = G.GetNPosEig(1.e-4);
    if(NEigenUsed<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::ComputePot2LapMatrix(). NEigenUsed (=%d) eigenvalues of thresholded system matrix.\n", NEigenUsed);
        return U_ERROR;
    }

    G = G.GetInverse(NEigenUsed, 0);
    if(G.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UInterpolateSphere::ComputePot2LapMatrix(): Getting pseudo inverse.\n");
        return U_ERROR;
    }
    UMatrix E((double*)NULL, NP, 1);
    E.SetData(1.);
    UMatrix GinvE = G * E;
    double  k     = GetTraceM1M2T(GinvE, E);
    if(fabs(k)<=1.e-12)
        CI.AddToLog("WARNING: UInterpolateSphere::ComputePot2LapMatrix(): G matrix degenerated.\n");

    UMatrix P = (fabs(k)<=1.e-12) ? G : G - GinvE.GetMMT()*(1./k);
    Pot2Lap  *= P;

    return U_OK;
}

double UInterpolateSphere::MatrixElem(UVector3 SenPos1, UVector3 SenPos2, int Mord, bool Laplacian) const
{  
    if(Mord<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::MatrixElem(). Invalid order parameter (Mord = %d).\n", Mord);
        return 0.;
    }
    const int MAXTERM = 5000;

    UVector3 x1  = SenPos1 - Spos;
    UVector3 x2  = SenPos2 - Spos;
        
    double   r1  =  x1.GetNorm(); 
    double   r2  =  x2.GetNorm();
    if(r1<=0 || r2<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::MatrixElem(). Sensors at origin.\n");
        return 0.;
    }
    double cosom =  (x1&x2)/(r1*r2);
    double h     = 0.;

    int    Ntest = 0;
    double Sum   = 0.;    // n=0
    double Pn1   = 1.;    // n=0
    double Pn    = cosom; // n=1
    for(int n=1, n2=3; n<MAXTERM; n++, n2+=2)
    {
        double term = n2 * Pn;
        double fact = 1./(n*(n+1.));
        for(int k=1; k<Mord; k++) term *= fact;
        if(Laplacian==true)       term *= n*(n+1);

        Sum  += term;

        if(n2*fact<1.e-10) 
        {
            Ntest = n;
            break;
        }
        h     = Pn;
        Pn    = (n2*cosom*Pn-n*Pn1)/(n+1);
        Pn1   = h;
    }
    return Sum;
}

ErrorType UInterpolateSphere::ComputeSmoothedLaplacian(const UGrid* GrEEG, double* Data, int Ntime) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). NULL or erroneous object.\n");
        return U_ERROR;
    }
    if(GridPot==NULL || GridPot->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). NULL or erroneous sensor grids.\n");
        return U_ERROR;
    }
    if(GrEEG==NULL || GrEEG->GetError()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). Erroneous NULL argument(s).\n");
        return U_ERROR;
    }
    if(GrEEG->GetNpoints()<=0 || Ntime<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). Invalid number of time samples of channels.\n");
        return U_ERROR;
    }
    int  NSub  = GrEEG->GetNpoints();
    int* Index = GridPot->GetSubGridIndices(GrEEG);
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). GrEEG does not have a sub-grid of GridPot .\n");
        return U_ERROR;
    }
    const double* P2L = Pot2Lap.GetMatrixArray();
    double*    DatLap = new double[NSub];
    if(DatLap==NULL || P2L==NULL)
    {
        delete[] DatLap;
        delete[] Index;
        CI.AddToLog("ERROR: UInterpolateSphere::ComputeSmoothedLaplacian(). Memory allocation. Nsensors = %d, Ntime = %d   (or Pot2Lap not set).\n", NSub, Ntime);
        return U_ERROR;
    }

    int Npot = GridPot->GetNpoints();

    for(int j=0; j<Ntime; j++)
    {
        double* DLj = DatLap;
        for(int k1=0; k1<NSub; k1++,DLj++)
        {
            int           i1NPot = Index[k1]*Npot;
            double        DL     = 0;
            const double* Dj     = Data+j;
            for(int k2=0; k2<NSub; k2++, Dj+=Ntime)
                DL    += P2L[i1NPot+Index[k2]] * *Dj;

            *DLj = DL;
        }

// Copy result to input array.
        double* Dj  = Data+j;
                DLj = DatLap;
        for(int k1=0; k1<NSub; k1++, Dj+=Ntime, DLj++) *Dj = *DLj;
    }    
    delete[] DatLap;
    delete[] Index;

    return U_OK;
}

UMultiChan* UInterpolateSphere::GetSmoothedLaplacian(const UMultiChan* MC) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). NULL or erroneous object.\n");
        return NULL;
    }
    if(GridPot==NULL || GridPot->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). NULL or erroneous sensor grids.\n");
        return NULL;
    }
    if(Pot2Lap.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). Pot2Lap NULL or not set.\n");
        return NULL;
    }
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). Erroneous NULL argument(s).\n");
        return NULL;
    }
    if(MC->GetNChan()<=0 || MC->GetNtime()<=0)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). Invalid number of time samples of channels.\n");
        return NULL;
    }
    int  NTime = MC->GetNtime();
    int  NSub  = MC->GetNChan();
    int* Index = GridPot->GetSubGridIndices(MC->GetSensorGrid());
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). UMultiChan does not have a sub-grid of GridPot .\n");
        return NULL;
    }
    double*       DataLap = new double[NSub*NTime];
    const double* Data    = MC->GetData();
    const double* P2L     = Pot2Lap.GetMatrixArray();
    if(DataLap==NULL || Data==NULL || P2L==NULL)
    {
        delete[] DataLap;
        delete[] Index;
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). Memory allocation. Nsensors = %d, Ntime = %d  (or Pot2Lap not properly set) .\n", NSub, NTime);
        return NULL;
    }

    int Npot = GridPot->GetNpoints();
    for(int j=0; j<NTime; j++)
    {
        double* DLj = DataLap+j;
        for(int k1=0; k1<NSub; k1++,DLj+=NTime)
        {
            int           i1NPot = Index[k1]*Npot;
            double        DL     = 0;
            const double* Dj     = Data+j;
            for(int k2=0; k2<NSub; k2++, Dj+=NTime)
                DL    += P2L[i1NPot+Index[k2]] * *Dj;

            *DLj = DL;
        }
    }    
    delete[] Index;

    UMultiChan* MClap = new UMultiChan(DataLap, MC->GetSensorGrid(), NTime, MC->GetSampTime());
    delete[] DataLap;
    if(MClap==NULL || MClap->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UInterpolateSphere::GetSmoothedLaplacian(). Creating UMultiChan-object.\n");
        return NULL;
    }
    return MClap;
}