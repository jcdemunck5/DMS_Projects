#ifndef _INTERPOLSPHERE_INCLUDED
#define _INTERPOLSPHERE_INCLUDED

#include "String.h"
#include "Matrix.h"

class UMultiChan;
class UGrid;
class UGridFit;

class DLL_IO UInterpolateSphere 
{
public:
    UInterpolateSphere();
    UInterpolateSphere(const UInterpolateSphere &IS);
    UInterpolateSphere(const UGrid* GridEEG, int Mord);
    ~UInterpolateSphere();
    UInterpolateSphere& operator=(const UInterpolateSphere &IS);

    UVector3            GetSpherePos(void) const;
    int                 GetNEigenUsed(void) const;

    UMultiChan*         GetSmoothedLaplacian(const UMultiChan* MC) const;
    ErrorType           ComputeSmoothedLaplacian(const UGrid* GrEEG, double* Data, int Ntime) const;

    const UString&      GetProperties(UString Comment) const;
    ErrorType           GetError(void) const {return error;}

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;
    ErrorType           error;             // General error flag

    UGridFit*           GridPot;           // Input sensors
    UVector3            Spos;              // Position of the best fitting sphere wrt to gradiometer
    UMatrix             Pot2Lap;           // Matrix used to convert potentials to Laplacians
    int                 Morder;            // Order of interpolation (Morder>=3)
    int                 NEigenUsed;

    ErrorType           ComputePot2LapMatrix(void);
    double              MatrixElem(UVector3 SenPos1, UVector3 SenPos2, int Mord, bool Laplacian) const;
};

#endif //_INTERPOLSPHERE_INCLUDED
