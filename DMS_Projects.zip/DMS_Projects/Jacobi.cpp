/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     The purpose of this object is to perform a Jacobi decomposition of a      */
/*     square symmetric matrix, and to perform various computations (weighted    */
/*     inner products) efficiently, assuming that the weighting matrix           */
/*     non-negative.                                                             */
/*     More specifically, the input matrix (of which a copy, Matrix[] is stored  */
/*     inside the object UJacobi) is decomposed as:                              */
/*                                                                               */
/*     Matrix = U * Eigen * UT,                                                  */
/*                                                                               */
/*     where U[] is an orthonormal matrix and Eigen[] is a diagonal matrix with  */
/*     non-negative eigen values.                                                */
/*     Inside the object, not U, but Wmat is stored where                        */
/*                                                                               */
/*     either Wmat = U*sqrt(Eigen) or Wmat = U*sqrt(Eigen)INV,                   */
/*                                                                               */
/*     The choice for Wmat depends on the Invert parameter, and this choice is   */
/*     made by the user, dependent on the type of computations he wishes to make.*/
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    25-12-99   creation
  JdM    29-03-00   Added Solve()
  JdM    30-03-00   New constructor
  JdM    03-05-00   MultiplyWTA()  ->  MultiplyWA  and
                    MultiplyAW()   ->  MultiplyAWT
  JdM    09-06-00   Added and tested ComputeJVec()
                    Added and tested AddA1TJA2(), and some float versions
                    Store a copy of the input matrix inside the object
  JdM    03-07-00   Tested and optimized MultiplyWA() and MultiplyAWT()
  JdM    03-08-00   Added default constructor and operator=()
  JdM    06-08-00   Seperate implementations of compute functions for sub-types: U_JACMAT_DIAGCONST and UGENERAL.
                    Rename MultiplyWA() -> MultiplyWmatA(), MultiplyAWT() -> MultiplyAWmatT()
                    Add documentation on each function.
                    Added GetProperties()
  JdM    07-08-00   Added new version of Solve()
  JdM    29-08-00   Added SetInvert()
  JdM    30-08-00   Bug Fix in operator=() (dealing with Properties[])
  JdM    01-09-00   Tested MultiplyWmatTA() and MultiplyAWmat()
  JdM    05-09-00   Added a copy constuctor
  JdM    16-10-00   More detailed error messages
  JdM    17-10-00   More detailed properties, SetMatrix() returns U_ERROR for negative eigenvalues
  JdM    20-11-00   Added PseudoInverse()
  JdM    24-11-00   Added RescaleDiagonal() and GetAverageDiag()
  JdM    26-11-00   SetEigenTreshold(). Treating the case Thresh==0.
                    BUG FIX: AddAJAT(), case of MType == U_JACMAT_DIAGCONST
  JdM    01-12-00   BUG FIX: AddATJA(), AddAJAT(), case of MType == U_JACMAT_DIAGCONST
  JdM    02-12-00   Added PseudoInverseElem()
                    BUG FIX: AddA1TJA2(), case of MType == U_JACMAT_DIAGCONST
  JdM    03-12-00   Added SetEigenValueOffset() and the eigenvalues offset mechanism
  JdM    11-12-00   WmatTAT(), WmatTA(), MultiplyAWmat(), MultiplyWmatTA() : Add zeroes to
                    fill the last (N-Neig) rows or collums.
  JdM    12-12-00   Implemented the U_JACMAT_DIAGONAL type for all functions.
  JdM    17-12-00   BUG FIX in U_JACMAT_DIAGONAL type, in combination with Neig<N (account for eigenvalue ordering!!)
FB/JdM   08-06-01   bug fix: SetEigenTreshold(). Skipping negative eigenvalues
  JdM    15-07-01   Added new constructor
  JdM    28-11-01   Added GetEigenIndex(double Thresh)
  JdM    26-02-02   Added GetNormalEigen() and GetNormalEigen2()
  JdM    27-02-02   Added GetEigenVector(). Made a safer GetEigen()
  JdM    02-07-02   Add parameter on GetEigenVector()
  JdM    14-11-03   Added WeightedNorm()
  JdM    14-03-04   Added and used SetAllMembersDefault() and DeleteAllMembers()
  JdM    16-03-04   Added constructor in the for of a projector.
  JdM    23-03-04   Initializr Properties[] with 0
  FB     30-06-04   Added private member NnegEig for symmetric matrices with negative eigenvalues
                    and adjust all existing routines. Nondefinite matrices are allways of type U_JACMAT_GENERAL
  JdM    13-07-04   Added dummy int parameter on one of the constructors (dd 16-03-04)
  FB     14-07-04   Allow indefinite matrices in this object by private members Nneg and NnegEig. NnegEig
                    can be adapted in SetTreshold().
  FB     14-07-04   Adapted GetEigenIndex(), made  Added GetThresholdedMatrix().
  FB     23-08-04   Normalized test for symmetry in Decompose()
  FB     31-08-04   Improve test for symmetry in Decompose(), made dependent on relative magnitude of eigenvalue
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    23-10-04   Time Series constructor: -Changed dummy int argument into double Relative Eigen Threshold
                                             -Allow matrix with pure zeroes
                                             -Bug Fix: Increased Neig by 1 in case of lin dep.
  JdM    31-10-04   Added SkipSamples()
  JdM    04-11-04   TestJacobi() made argument const
  JdM    11-11-04   Bug fix operator=(), in case of MType==U_JACMAT_DIAGONAL (copy only first N elements of Wmat
  JdM    13-11-04   Bug fix: SetInvert(). In case MType==U_JACMAT_DIAGONAL, replace Wmat by 1./Wmat.
  JdM    30-01-07   bug fix: UJacobi(const double*Mat,...), Use SVD on the regressors only, instead of on NxN matrix
                    New code give same results, but is a lot faster
  JdM    14-08-07   Test indepence of constructor input functions. Launch (additional) warning at level of 1.e-10
  JdM    31-01-08   Added SetEigenTresholdMaxJump()
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    02-07-09   GetProperties(). Use UString()
  JdM    01-09-09   Bug GetProperties(). Test if(Eigen) ... to prevent crashes
  JdM    14-10-09   Added GetAJAT() and GetATJA(). More consistingcy testing in AddAJAT() and AddATJA()
  JdM    06-08-12   Added GetDiagElem(), MultiplyJA() and MultiplyAJ()
  JdM    21-12-12   Added operator+=() and operator*=()
  JdM    14-12-13   Added ForceGeneral()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
 */


#include<string.h>
#include<math.h>

#include"Jacobi.h"
#include"Field.h"

const char* GetJacMatTypeText(JacMatType MT)
{
    switch(MT)
    {
    case U_JACMAT_UNKNOWN:          return "Unknown";
    case U_JACMAT_DIAGCONST:        return "ConstantDiagonal";
    case U_JACMAT_DIAGONAL:         return "GeneralDiaginal";
    case U_JACMAT_GENERAL:          return "General";
    }
    return "UnknownMatType";
};

/* Inititalize static const parameters. */
UString UJacobi::Properties       = UString();

void UJacobi::SetAllMembersDefault(void)
{
    MType      = U_JACMAT_UNKNOWN;
    Wconst     = 1.;
    error      = U_OK;
    N          = 0;
    Neig       = 0;
    Nneg       = 0;
    NnegEig    = 0;
    Invert     = false;
    Wmat       = NULL;
    Eigen      = NULL;
    EigInd     = NULL;
    Matrix     = NULL;
    EigOffset2 = 0.;
    Properties = UString();
}

void UJacobi::DeleteAllMembers(ErrorType E)
{
    delete[] Wmat;
    delete[] Eigen;
    delete[] EigInd;
    delete[] Matrix;
    SetAllMembersDefault();
    error = E;
}

UJacobi::UJacobi()
/*
    Default costructor. Resulting object not appropriate for computations.
 */
{
    SetAllMembersDefault();
}

UJacobi::UJacobi(int n, double Var, bool Inv)
/*
    Matrix is diaginal matrix with Var on all diagonal elements.
 */
{
    SetAllMembersDefault();

    MType  = U_JACMAT_DIAGCONST;
    if(Var<=0)  Wconst = 1.;
    else        Wconst = sqrt(fabs(Var));
    if(Inv)     Wconst = 1./Wconst;
    N          = n;
    Neig       = n;
    Invert     = Inv;
}

UJacobi::UJacobi(int N1, int N2, double RelN2variance, bool Inv)
/*
   The matrix is a diagonal one with N1+N2 elements, of which the first N1 are 1,
   and the last N2 are RelN2variance.
   Inv determines whether the matrix is inverted.
 */
{
    SetAllMembersDefault();
    if(N1<0 || N2<0 || N1+N2<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid dimensions: N1=%d, N2=%d .\n", N1,N2);
        return;
    }
    if(RelN2variance<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid relative variance parameter: RelN2variance = %f .\n", RelN2variance);
        return;
    }

    MType      = U_JACMAT_DIAGONAL;
    Wconst     = 1;

    Invert     = Inv;
    N          = N1+N2;
    Neig       = N1+N2;

    Wmat       = new double[N];
    Eigen      = new double[N];
    EigInd     = new int[N];
    if(!Wmat || !Eigen || !EigInd)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Memory allocation: n=%d\n",N);
        return;
    }

    for(int k=0; k<N; k++)
    {
        if(k<N1)
        {
            Eigen[k]  = 1;
            Wmat[k]   = 1;
        }
        else
        {
            Eigen[k]  = RelN2variance;
            Wmat[k]   = sqrt(Eigen[k]);
            if(Invert==true) Wmat[k] = 1./Wmat[k];
        }
    }
    indexx(N, Eigen, EigInd);
    for(int i=0; i<N-1; i++)
        if(Eigen[EigInd[i]]<Eigen[EigInd[i+1]])
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UJacobi::UJacobi(). Sorting eigenvalues. (?). \n");
        }
}

UJacobi::UJacobi(const double*Mat, int n, bool Inv, bool AllowNegEig)
/*
    Matrix is general (symmetric and positive) matrix.
    Wmat[] and Eigen[] are computed with SVD algorithm.
    In case Matrix is not positive definite, but has both
    positive and negative eigenvalues, NnegEig will become >1
    and the negative values are stored in NegEigen[].
 */
{
    SetAllMembersDefault();

    if(Mat==NULL || n<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid (NULL) argument(s). n=%d .\n", n);
        return;
    }
    MType      = U_JACMAT_GENERAL;
    Wmat       = new double[n*n];
    Matrix     = new double[n*n];
    Eigen      = new double[n];

    if(Wmat==NULL || Eigen==NULL || Matrix==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Memory allocation: n=%d\n",n);
        return;
    }
    N      = n;
    Neig   = N;

    if(Decompose(Mat, Inv, AllowNegEig)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Decomposing matrix. \n");
        return;
    }
}

UJacobi::UJacobi(const double*Mat, int nFunc, int nDim, double RelEigenThreshold)
/*
    Create a projector, based on the nFunc * nDim matrix Mat[].
 */
{
    SetAllMembersDefault();
    if(Mat==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid NULL pointer. \n");
        return;
    }
    if(nFunc<=0 || nDim<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid arguments: nFunc = %d, nDim = %d. \n", nFunc, nDim);
        return;
    }
    if(RelEigenThreshold<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Invalid Eigen treshold: RelEigenThreshold = %f. \n", RelEigenThreshold);
        return;
    }
    if(RelEigenThreshold==0. || RelEigenThreshold>=0.1)
        CI.AddToLog("WARNING: UJacobi::UJacobi(). Eigen treshold should be tiny positive, RelEigenThreshold = %f. \n", RelEigenThreshold);


    Wmat       = new double[nDim*nDim];
    Matrix     = new double[nDim*nDim];
    Eigen      = new double[nDim];
    EigInd     = NULL;

    if(Wmat==NULL || Eigen==NULL || Matrix==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Memory allocation: n=%d\n",nDim);
        return;
    }

    MType      = U_JACMAT_GENERAL;
    Wconst     = 1.;
    N          = nDim;
    Neig       = MIN(nDim, nFunc);
    Invert     = false;
    EigOffset2 = 0.;
    for(int k=0; k<N*N; k++)
    {
        Wmat[k] = 0;
        if(k<N)      Eigen[k]  = 0.;
        if(k<N*Neig) Matrix[k] = Mat[k];
        else         Matrix[k] = 0.;
    }

    int svderror = svdcmp_d(Matrix, Neig, N, Eigen, Wmat);
    if(svderror)
    {
        CI.AddToLog("ERROR: UJacobi::UJacobi(). SVD failed. ");
        switch(svderror)
        {
        case 1:  CI.AddToLog("Memory allocation. \n");   break;
        case 2:  CI.AddToLog("Too many iterations. \n"); break;
        default: CI.AddToLog("\n");
        }
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Eigen[0]<0.)
    {
        CI.AddToLog("ERROR: UJacobi::UJacobi(). Largest eigen value is %f. \n", Eigen[0]);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Eigen[0]==0.)
        CI.AddToLog("WARNING: UJacobi::UJacobi(). Largest eigen value is 0.0. \n");

/* Set all eigenvalues to either 0. or 1. */
    for(int k=0; k<N; k++)
    {
        if(k<Neig)
        {
            if(Eigen[k]<0)
            {
                CI.AddToLog("ERROR: UJacobi::UJacobi(). Eigen[%d]=%e <0.! \n",k,Eigen[k]);
                DeleteAllMembers(U_ERROR);
                return;
            }
            if(Eigen[k]*Eigen[k]<=1.e-10*Eigen[0]*Eigen[0])
                CI.AddToLog("WARNING: UJacobi::UJacobi(). Functions may be linearly dependent. k=%d .\n", k);

            if(Eigen[k]*Eigen[k]<=RelEigenThreshold*Eigen[0]*Eigen[0])
            {
                Eigen[k] = 0.;
                Neig     = k ; // JdM 23-10-2004 changed from k-1 into k
                CI.AddToLog("WARNING: UJacobi::UJacobi(). Functions linearly dependent. Truncated %d given functions to %d independent ones. \n", nFunc, Neig);
                break;
            }
            Eigen[k] = 1.;
        }
        else
            Eigen[k] = 0.;
    }

/* Store Matrix[] as Rt*(R*Rt)inv * R  (== WWt) */
    for(int i1=0; i1<N; i1++)
    {
        for(int i2=0; i2<N; i2++)
        {
            if(i1<=i2)
            {
                double Elem = 0;
                for(int k=0; k<Neig; k++) Elem += Wmat[i1*N+k]*Wmat[i2*N+k];
                Matrix[i1*N+i2] = Elem;
            }
            else
                Matrix[i1*N+i2] = Matrix[i2*N+i1];
        }
    }
}

UJacobi::UJacobi(const UJacobi& Jac)
{
    SetAllMembersDefault();
    *this = Jac;
}

UJacobi::~UJacobi()
{
    DeleteAllMembers(U_OK);
}

UJacobi& UJacobi::operator=(const UJacobi& Jac)
{
    if(this==NULL)
    {
        static UJacobi J; J.error = U_ERROR;
        return J;
    }
    if(&Jac==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::operator=(). Invalid NULL address in argument. \n");
        return *this;
    }
    if(this==&Jac) return *this;
    DeleteAllMembers(U_OK);

    MType      = Jac.MType;
    Wconst     = Jac.Wconst;

    N          = Jac.N;
    Neig       = Jac.Neig;
    Nneg       = Jac.Nneg;
    NnegEig    = Jac.NnegEig;
    Invert     = Jac.Invert;
    EigOffset2 = Jac.EigOffset2;

    if(Jac.Wmat      )
    {
        if(Jac.MType==U_JACMAT_DIAGONAL)  Wmat = new double[N];
        else                              Wmat = new double[N*N];
    }
    if(Jac.Eigen     ) Eigen      = new double[N];
    if(Jac.EigInd    ) EigInd     = new int[N];
    if(Jac.Matrix    ) Matrix     = new double[N*N];
    if( (!Wmat       && Jac.Wmat)   ||
        (!Eigen      && Jac.Eigen)  ||
        (!EigInd     && Jac.EigInd) ||
        (!Matrix     && Jac.Matrix))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::operator=(). Memory allocation: N=%d\n",Jac.N);
        return *this;
    }

    if(Jac.Wmat  )
    {
        if(Jac.MType==U_JACMAT_DIAGONAL)  for(int k=0; k<N  ; k++) Wmat[k]   = Jac.Wmat[k];
        else                              for(int k=0; k<N*N; k++) Wmat[k]   = Jac.Wmat[k];
    }

    if(Jac.Eigen )     for(int k=0; k<N;   k++) Eigen[k]  = Jac.Eigen[k];
    if(Jac.EigInd)     for(int k=0; k<N;   k++) EigInd[k] = Jac.EigInd[k];
    if(Jac.Matrix)     for(int k=0; k<N*N; k++) Matrix[k] = Jac.Matrix[k];

    error  = Jac.error;

    return *this;
}

UJacobi& UJacobi::operator+=(const UJacobi& Jac)
{
    static UJacobi DumDat; DumDat.error = U_ERROR;
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::operator+=(). this has NULL address. \n");
        return DumDat;
    }
    if(&Jac==NULL || Jac.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::operator+=(). Argument has NULL address or is erroneous. \n");
        return DumDat;
    }

    if(MType!=U_JACMAT_UNKNOWN && Jac.MType!=MType)
    {
        CI.AddToLog("ERROR: UJacobi::operator+=(). Terms of different types (Jac.MType = %d and MType=%d) .\n", Jac.MType, MType);
        return DumDat;
    }

    if(MType!=U_JACMAT_UNKNOWN && Jac.N!=N)
    {
        CI.AddToLog("ERROR: UJacobi::operator+=(). Terms of different sizes (Jac.N = %d and N=%d) .\n", Jac.N, N);
        return DumDat;
    }
    if(MType!=U_JACMAT_UNKNOWN && Jac.Invert!=Invert)
    {
        CI.AddToLog("ERROR: UJacobi::operator+=(). Terms of different Invert types. \n");
        return DumDat;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        {
            *this = Jac;
            return *this;
        }
    case U_JACMAT_DIAGCONST:
        {
            double TempW1 =     Wconst; 
            double TempW2 = Jac.Wconst; 

            if(Invert) 
            {
                if(TempW1>0.)TempW1 = 1./TempW1; else TempW1 = 0.;
                if(TempW2>0.)TempW2 = 1./TempW2; else TempW2 = 0.;
            }

            Wconst = sqrt( TempW1*TempW1 + TempW2*TempW2);
            if(Invert) {if(Wconst>0.) Wconst = 1./Wconst; else Wconst =0.;}
            return *this;
        }
    case U_JACMAT_DIAGONAL:
        {
            if(Wmat  ==NULL || Jac.Wmat  ==NULL ||
               Eigen ==NULL || Jac.Eigen ==NULL ||
               EigInd==NULL || Jac.EigInd==NULL)
            {
                CI.AddToLog("ERROR:  UJacobi::operator+=(). Invalid NULL member(s)\n",N);
                return DumDat;
            }
            for(int k=0; k<N; k++)
            {
                double TempW1 =     Wmat[k]; 
                double TempW2 = Jac.Wmat[k]; 

                if(Invert) 
                {
                    if(TempW1>0.)TempW1 = 1./TempW1; else TempW1 = 0.;
                    if(TempW2>0.)TempW2 = 1./TempW2; else TempW2 = 0.;
                }

                Eigen[k] = TempW1*TempW1 + TempW2*TempW2;
                Wmat[k]  = sqrt(Eigen[k]);
                if(Invert) {if(Wmat[k]>0.) Wmat[k] = 1./Wmat[k]; else Wmat[k]=0.;}
            }
            indexx(N, Eigen, EigInd);
            return *this;
        }
    case U_JACMAT_GENERAL:
        {
            if(Wmat  ==NULL || Jac.Wmat  ==NULL ||
               Eigen ==NULL || Jac.Eigen ==NULL ||
               Matrix==NULL || Jac.Matrix==NULL)
            {
                CI.AddToLog("ERROR:  UJacobi::operator+=(). Invalid NULL member(s)\n",N);
                return DumDat;
            }
            double* Sum = new double[N*N];
            if(Sum==NULL)
            {
                CI.AddToLog("ERROR:  UJacobi::operator+=(). Memory allocation, N=%d .\n",N);
                return DumDat;
            }
            for(int k=0; k<N*N; k++) Sum [k]  = Matrix[k] + Jac.Matrix[k];
            for(int k=0; k<N*N; k++) Wmat[k]  = 0.;
            for(int k=0; k<  N; k++) Eigen[k] = 0.;
        
            if(Decompose(Sum, Invert, false)!=U_OK)
            {
                delete[] Sum;
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UJacobi::operator+=(). Decomposing matrix. \n");
                return DumDat;
            }
            delete[] Sum;
            return *this;
        }
    }
    CI.AddToLog("ERROR: UJacobi::operator+=(). Object of unknown type (MType = %d) .\n", MType);
    return DumDat;
}
UJacobi& UJacobi::operator*=(double fac)
{
    static UJacobi DumDat; DumDat.error = U_ERROR;
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::operator*=(). this has NULL address. \n");
        return DumDat;
    }
    if(fac<=0)
    {
        CI.AddToLog("ERROR: UJacobi::operator*=(). Argument out of range (fac = %f). \n", fac);
        return DumDat;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        {
            CI.AddToLog("ERROR: UJacobi::operator*=(). Object of unknown type (MType=%d) .\n",MType);
            return DumDat;
        }
    case U_JACMAT_DIAGCONST:
        {
            double TempW1 =     Wconst; 
            if(Invert) {if(TempW1>0.) TempW1 = 1./TempW1; else TempW1 = 0.;}
            Wconst *= sqrt(fabs(fac));
            if(Invert) {if(Wconst>0.) Wconst = 1./Wconst; else Wconst = 0.;}
            return *this;
        }
    case U_JACMAT_DIAGONAL:
        {
            if(Wmat  ==NULL || Eigen==NULL)
            {
                CI.AddToLog("ERROR:  UJacobi::operator*=(). Invalid NULL member(s)\n",N);
                return DumDat;
            }
            for(int k=0; k<N; k++)
            {
                double TempW1 =     Wmat[k]; 
                if(Invert) {if(TempW1>0.) TempW1 = 1./TempW1; else TempW1 = 0.;}
                Wmat[k] *= sqrt(fabs(fac));
                if(Invert) {if(Wmat[k]>0.) Wmat[k] = 1./Wmat[k]; else Wmat[k] = 0.;}
                Eigen[k] *= fabs(fac);
            }
            return *this;
        }
    case U_JACMAT_GENERAL:
        {
            if(Wmat  ==NULL || Eigen ==NULL || Matrix==NULL)
            {
                CI.AddToLog("ERROR:  UJacobi::operator*=(). Invalid NULL member(s)\n",N);
                return DumDat;
            }
            double wfac = sqrt(fac); if(Invert) wfac = 1./wfac;
            for(int k=0; k<N*N; k++) Matrix[k] *= fac;
            for(int k=0; k<N*N; k++) Wmat[k]   *= wfac;
            for(int k=0; k<  N; k++) Eigen[k]  *= fac;

            return *this;
        }
    }
    CI.AddToLog("ERROR: UJacobi::operator*=(). Object of unknown type (MType = %d) .\n", MType);
    return DumDat;
}

ErrorType UJacobi::SetDiagonal(const double* Diag, int n, bool Inv)
/*
    Replace the current contents of the object by a diagonal matrix.
 */
{
    if(Diag==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::SetDiagonal(). NULL argument. \n");
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    MType      = U_JACMAT_DIAGONAL;
    N          = n;
    Neig       = n;
    Invert     = Inv;

    Wmat       = new double[N];
    Eigen      = new double[N];
    EigInd     = new int[N];
    if(!Wmat || !Eigen || !EigInd)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::SetDiagonal(). Memory allocation: n=%d\n",n);
        return U_ERROR;
    }

    for(int k=0; k<N; k++)
    {
        Eigen[k]  = Diag[k];
        if(Eigen[k]<0)
        {
            CI.AddToLog("WARNING: UJacobi::SetDiagonal(). Eigen[%d]=%e <0.! \n",k,Eigen[k]);
            Wmat[k] = 0;
        }
        else
        {
            Wmat[k] = sqrt(Eigen[k]);
            if(Invert==true && Wmat[k]>0)
                Wmat[k] = 1./Wmat[k];
        }
    }
    indexx(N, Eigen, EigInd);
    for(int i=0; i<N-1; i++)
        if(Eigen[EigInd[i]]<Eigen[EigInd[i+1]])
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("FATAL PROGRAMMING ERROR: UJacobi::SetDiagonal(). Sorting eigenvalues.\n");
        }

    return error  = U_OK;
}

ErrorType UJacobi::SkipSamples(const UField* Selector, int *NSelected, char** Selection)
/*
   Assuming that *Selector are 1D fields, shift elements of *this to the left as
   soon as the corresponding element of *Selector is 0. Update the number of points.
   In this way, all "used" points are arranged contiguously in the data array.

   If(Selector==NULL) return immediately with U_OK;
   If(NSelected), *NSelected will contain the numer of selected elements
   If(Selection), a new array will be created at *Selection, containing a string with all selected indeces.
 */
{
    if(this==NULL || error!=U_OK || N<=0)
    {
        CI.AddToLog("ERROR: UJacobi::SkipSamples(). this==NULL or error!=U_OK or N<=0 \n");
        return U_ERROR;
    }

    if(MType!=U_JACMAT_DIAGCONST &&
       MType!=U_JACMAT_DIAGONAL  &&
       MType!=U_JACMAT_GENERAL)
    {
        CI.AddToLog("ERROR: UJacobi::SkipSamples(). Invalid matrix type. MType = %d   . \n", MType);
        return U_ERROR;
    }

    if(Selector==NULL)
    {
        if(NSelected) *NSelected = N;
        return U_OK;
    }
    if(Selector->GetError()!=U_OK || Selector->Getndim()!=1 || Selector->GetVeclen()!=1 ||
       Selector->GetDimensions(0) != N)
    {
        CI.AddToLog("ERROR: UJacobi::SkipSamples(). Selector (%s) not compatible with this (%s). \n", (const char*)Selector->GetProperties(""), GetProperties("// "));
        return U_ERROR;
    }

/* Determine selected points */
    int* Sel = new int[N];
    if(Sel==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::SkipSamples(). Memory allocation. \n");
        return U_ERROR;
    }
    for(int kk=0; kk<N; kk++) Sel[kk]=0;

    int Nsel = 0;
    switch(Selector->GetDType())
    {
    case UField::U_BYTE:    if(Selector->GetBdata()) for(int k=0; k<N; k++) if(Selector->GetBdata()[k]) {Sel[k] = 1; Nsel++;} break;
    case UField::U_SHORT:   if(Selector->GetSdata()) for(int k=0; k<N; k++) if(Selector->GetSdata()[k]) {Sel[k] = 1; Nsel++;} break;
    case UField::U_INTEGER: if(Selector->GetIdata()) for(int k=0; k<N; k++) if(Selector->GetIdata()[k]) {Sel[k] = 1; Nsel++;} break;
    case UField::U_FLOAT:   if(Selector->GetFdata()) for(int k=0; k<N; k++) if(Selector->GetFdata()[k]) {Sel[k] = 1; Nsel++;} break;
    case UField::U_DOUBLE:  if(Selector->GetDdata()) for(int k=0; k<N; k++) if(Selector->GetDdata()[k]) {Sel[k] = 1; Nsel++;} break;
    }
    if(Nsel==0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UJacobi::SkipSamples(). Not any sample selected. \n");
        if(NSelected) *NSelected = 0;
        if(Selection)
        {
            *Selection = new char[24];
            if(*Selection) 
            {
                memset(Selection, 24, 1);
                strncpy(*Selection, "Selection: ", 20);
            }
        }
        delete[] Sel;
        return   U_ERROR;
    }

/* Set selection on data */
    if(MType==U_JACMAT_DIAGCONST)
    {
        N          = Nsel;
        Neig       = Nsel;
    }
    else if(MType==U_JACMAT_DIAGONAL)
    {
        int ksel = 0;
        for(int k=0; k<N; k++)
        {
            if(Sel[k])
            {
                Wmat[ksel]  = Wmat[k];
                Eigen[ksel] = Eigen[k];
                ksel++;
            }
        }
        N          = Nsel;
        Neig       = MIN(Neig, Nsel);
        indexx(N, Eigen, EigInd);
    }
    else if(MType==U_JACMAT_GENERAL)
    {
        double* Buffer = new double[Nsel*Nsel];
        if(Buffer==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UJacobi::SkipSamples(). Memory allocation. Nsel=%d. \n", Nsel);
            if(NSelected) *NSelected = 0;
            if(Selection)
            {
                *Selection = new char[24];
                if(*Selection) strncpy(*Selection, "Selection: ", 20);
            }
            delete[] Sel;
            return   U_ERROR;
        }
        int ksel = 0;
        for(int k=0; k<N; k++) // Shift rows
            if(Sel[k])
            {
                memcpy(Matrix+ksel*N, Matrix+k*N, N*sizeof(Matrix[0]));
                ksel++;
            }
        ksel = 0;
        for(int k=0; k<N; k++) // Shift collumns
            if(Sel[k])
            {
                for(int kr=0; kr<Nsel; kr++) Matrix[kr*N+ksel] = Matrix[kr*N+ksel];
                ksel++;
            }
        memcpy(Buffer, Matrix, Nsel*Nsel*sizeof(Matrix[0]));
        N      = Nsel;
        error  = Decompose(Buffer, Invert);
        SetEigenTreshold(MIN(Neig, Nsel));
        delete[] Buffer;
    }

/* Use Sel[] now to store indices */
    int ksel = 0;
    for(int k=0; k<N; k++) if(Sel[k]) Sel[ksel++] = k;

    N = Nsel;
    if(NSelected) *NSelected = Nsel;

    if(Selection)
    {
        int nbytes = 21+Nsel*20;
        *Selection = new char[nbytes];
        if(*Selection)
        {
            int nc = sprintf(*Selection, "Selection: ");
            for(int k=0; k<Nsel; k++)
                nc+=sprintf((*Selection)+nc," %d, ",Sel[k]);
            if(nc>=nbytes)
                CI.AddToLog("ERROR: UJacobi::SkipSamples(). Array boundaryes, nc = %d, nbytes = %d .\n", nc, nbytes);
        }
    }

    delete[] Sel;
    return U_OK;
}

double UJacobi::GetDiagElem(int k) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(k<0 || k>=N)
    {
        CI.AddToLog("ERROR: UJacobi::GetDiagElem(). argument (%d) out of range. N=%d.\n",k,N);
        return 0;
    }
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:              return 0.;
    case U_JACMAT_DIAGCONST:            return Wconst*Wconst;
    case U_JACMAT_DIAGONAL: if(Eigen)   return Eigen[k];      else return 0;
    case U_JACMAT_GENERAL:  if(Matrix)  return Matrix[k*N+k]; else return 0.;
    }
    return 0.;
}
double UJacobi::GetElem(int k1, int k2) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(k1<0 || k2<0 || k1>=N || k2>=N)
    {
        CI.AddToLog("ERROR: UJacobi::GetElem(). arguments (%d,%d) out of range. N=%d.\n",k1,k2,N);
        return 0;
    }
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return 0.;
    case U_JACMAT_DIAGCONST:
        if(k1==k2)          return Wconst*Wconst;
        else                return 0;
    case U_JACMAT_DIAGONAL:
        if(k1==k2 && Eigen) return Eigen[k1];
        else                return 0;
    case U_JACMAT_GENERAL:
        if(Matrix)          return Matrix[k1*N+k2];
        else                return 0.;
    }
    return 0.;
}

ErrorType UJacobi::RescaleDiagonal(double AveDiag)
/*
     Rescale the matrix and its derived quantities in such a way that the
     the average diagonal equals AveDiag.
*/
{
    if(AveDiag<=0) return U_ERROR;
    if(Nneg >0 || NnegEig >0)
    {
        CI.AddToLog("ERROR: UJacobi::RescaleDiagonal() Not implemented for nondefinite matrices. \n");
        return U_ERROR;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        if(Invert==true)
        {
            Wconst = 1./sqrt(AveDiag);
        }
        else
        {
            Wconst = sqrt(AveDiag);
        }
        return U_OK;

    case U_JACMAT_DIAGONAL:
        if(Eigen==NULL || Wmat==NULL || EigInd==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::RescaleDiagonal(). Eigen, Wmat or EigInd is NULL.\n");
            return U_ERROR;
        }
        {
            double Ave = GetAverageDiag();
            if(Ave<=0) return U_ERROR;

            double MultFact = AveDiag/Ave;
            for(int n=0; n<N;   n++) Eigen[n]  *= MultFact;

            if(Invert==true) MultFact = 1./sqrt(MultFact);
            else             MultFact =    sqrt(MultFact);
            for(int n=0; n<N; n++) Wmat[n] *= MultFact;
        }
        return U_OK;

    case U_JACMAT_GENERAL:
        if(Matrix==NULL || Eigen==NULL || Wmat==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::RescaleDiagonal(). Matrix, Eigen or Wmat is NULL.\n");
            return U_ERROR;
        }
        double Ave = GetAverageDiag();
        if(Ave<=0) return U_ERROR;

        double MultFact = AveDiag/Ave;
        for(int n=0; n<N*N; n++) Matrix[n] *= MultFact;
        for(int n=0; n<N;   n++) Eigen[n]  *= MultFact;

        if(Invert==true) MultFact = 1./sqrt(MultFact);
        else             MultFact =    sqrt(MultFact);

        for(int n=0; n<N*N; n++) Wmat[n] *= MultFact;
        return U_OK;
    }
    return U_ERROR;
}

double UJacobi::GetAverageDiag(void) const
{
    int    n    = 0;
    double Aver = 0;
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return 0;

    case U_JACMAT_DIAGCONST:
        if(Invert==true) return 1./(Wconst*Wconst);
        return Wconst*Wconst;

    case U_JACMAT_DIAGONAL:
        if(Eigen==NULL) return 0.;

        for(n=0; n<N; n++) Aver += Eigen[n];
        return Aver/N;

    case U_JACMAT_GENERAL:
        if(Matrix==NULL) return 0.;

        for(n=0; n<N; n++) Aver += Matrix[n*(N+1)];
        return Aver/N;
    }
    return 0;
}

const double* UJacobi::GetMatrixArray(void) const      
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::GetMatrixArray(). Object NULL or erroneous. \n", MType);
        return NULL;
    }
    if(MType!=U_JACMAT_GENERAL)
    {
        CI.AddToLog("ERROR: UJacobi::GetMatrixArray(). Object of wrong type (%d)\n", MType);
        return NULL;
    }
    if(Matrix==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetMatrixArray(). Matrix not set.\n");
        return NULL;
    }
    return Matrix;
}

ErrorType UJacobi::ForceGeneral(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(N<=0)
    {
        CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Invalid N (=%d).\n", N);
        return U_ERROR;
    }
    if(MType==U_JACMAT_GENERAL) return U_OK;

    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Not implemented for nondefinite matrices.\n");
        return U_ERROR;
    }

    double* NewWmat   = new double[N*N];
    double* NewMatrix = new double[N*N];
    double* NewEigen  = new double[N];
    if(NewWmat==NULL || NewMatrix==NULL || NewEigen==NULL)
    {
        delete[] NewWmat;  
        delete[] NewEigen; 
        delete[] NewMatrix;
        CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Memory allocation, N =%d  .\n", N);
        return U_ERROR;
    }
    
    for(int n=0; n<N*N; n++) NewWmat[n]  = NewMatrix[n] = n%(N+1) ? 0. : 1.;
    for(int n=0; n<  N; n++) NewEigen[n] = 0.;

    switch(MType)
    {
    case U_JACMAT_DIAGCONST:
        for(int n=0, nn=0; n<  N; n++, nn+=(N+1)) 
        {
            NewMatrix[nn] = NewEigen[n] = Wconst*Wconst;
            NewWmat  [nn] = Wconst;
        }
        break;

    case U_JACMAT_DIAGONAL:
        if(Eigen==NULL || Wmat==NULL)
        {
            delete[] NewWmat;  
            delete[] NewEigen; 
            delete[] NewMatrix;
            CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Eigen or Wmat NULL.\n");
            return U_ERROR;
        }

        for(int n=0, nn=0; n<  N; n++, nn+=(N+1)) 
        {
            NewMatrix[nn] = NewEigen[n] = Wmat[n]*Wmat[n];
            NewWmat  [nn] = Wmat[n];
        }
        break;

    default:
        delete[] NewWmat;  
        delete[] NewEigen; 
        delete[] NewMatrix;
        if(MType!=U_JACMAT_GENERAL) CI.AddToLog("ERROR: UJacobi::ForceGeneral(). Matrix of wrong type: MType = %d.\n", MType);
        return U_ERROR;
    }

    MType=U_JACMAT_GENERAL;
    delete[] Wmat;   Wmat   = NewWmat; 
    delete[] Eigen;  Eigen  = NewEigen;
    delete[] Matrix; Matrix = NewMatrix;

    return U_OK;
}

ErrorType UJacobi::SetMatrix(const double*Mat, int n, bool Inv)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::SetMatrix(). Object NULL or erroneous.\n");
        return U_ERROR;
    }

    delete[] EigInd; EigInd = NULL;
    if(n!=N || MType!=U_JACMAT_GENERAL)
    {
        N      = 0;
        delete[] Wmat;      Wmat   = new double[n*n];
        delete[] Matrix;    Matrix = new double[n*n];
        delete[] Eigen;     Eigen  = new double[n];
        
        if(Wmat==NULL || Eigen==NULL || Matrix==NULL)
        {
            delete[] Wmat;   Wmat  = NULL;
            delete[] Matrix; Matrix= NULL;
            delete[] Eigen;  Eigen = NULL;
            CI.AddToLog("ERROR: UJacobi::SetMatrix(). Memory allocation: n=%d\n",n);
            return U_ERROR;
        }
        N = n;
    }
    Neig   = N;
    Wconst = 1;
    MType  = U_JACMAT_GENERAL;
    return Decompose(Mat, Inv);
}

double* UJacobi::GetThresholdedMatrix(void)
/*
This routine returns the matrix based on only those eigenvalues (both positive and
negative) that exceed the threshold for eigenvalues
*/
{
    if(MType != U_JACMAT_GENERAL) return NULL;

    double* ThresMat = new double[N*N];
    if(ThresMat==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetThresholdedMatrix(). Memory allocation, N=%d \n", N);
        return NULL;
    }
    if(Invert==true)
    {
        for(int k=0;k<N;k++)
            for(int i=0;i<N;i++) Wmat[i*N+k] *= Eigen[k];
    }


    for(int i1=0; i1<N; i1++)
        for(int i2=0; i2<N; i2++)
        {
            ThresMat[i1*N+i2]=0;
            for(int k=0; k<Neig;    k++) ThresMat[i1*N+i2] += Wmat[i1*N+k  ]*Wmat[i2*N+k  ];
            for(int k=0; k<NnegEig; k++) ThresMat[i1*N+i2] -= Wmat[i1*N+N-k]*Wmat[i2*N+N-k];
        }

    if(Invert==true)
    {
        for(int k=0;k<N;k++)
            if(Eigen[k]>0)
            {
                for(int i=0;i<N;i++) Wmat[i*N+k] /= Eigen[k];
            }
            else
            {
                for(int i=0;i<N;i++) Wmat[i*N+k]  = 0.;
            }
    }
    return ThresMat;
}


ErrorType UJacobi::SetEigenValueOffset(double RelOffset)
/*
     Update the SquareRoot matrix Wmat[] in such a way that it is consistent with
     an offset of EigOffset2 times the Indentity to the original matrix Matrix[].

     Herewith, EigOffset2 is computed as the fraction of the sum of the eigenvalues.

     The purpose of this function is to "smooth" the (pseude)inverse of Matrix[],
     when some of its eigen values are close to zero.

     If(MType!=U_JACMAT_GENERAL) return without changes.

 */
{
    if(Nneg>0 || NnegEig>0 )
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenValueOffset. Not implemented for nondefinite matrices.\n");
        return U_ERROR;
    }
    if(MType!=U_JACMAT_GENERAL) return U_OK;

    if(RelOffset<0)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenValueOffset().RelOffset=%g<0.\n",RelOffset);
        return U_ERROR;
    }
    if(Eigen==NULL || Wmat==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenValueOffset(). Eigen or Wmat are NULL.\n");
        return U_ERROR;
    }

    double sum = 0;
    for(int k=0; k<N; k++) sum += Eigen[k]*Eigen[k];

    double NewEigOffset2 = RelOffset*sum;

    if(Invert==true)
    {
        for(int k=0;k<N;k++)
        {
            double fact = sqrt( (1.+Eigen[k]*NewEigOffset2)/(1.+Eigen[k]*EigOffset2));
            for(int i=0;i<N;i++)
                Wmat[i*N+k] *= fact;
        }
    }
    else
    {
        for(int k=0;k<N;k++)
        {
            double fact = sqrt( (Eigen[k]+NewEigOffset2)/(Eigen[k]+EigOffset2));
            for(int i=0;i<N;i++)
                Wmat[i*N+k] *= fact;
        }
    }

    EigOffset2 = NewEigOffset2;
    if(EigOffset2>0) Neig = N;

    return U_OK;
}

ErrorType UJacobi::SetInvert(bool Inv)
/*
     Update the SquareRoot matrix Wmat[] in such a way that it is consistent with Inv.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::SetInvert(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Nneg>0 || NnegEig>0 )
    {
        CI.AddToLog("ERROR: UJacobi::SetInvert(). Not implemented for nondefinite matrices.\n");
        return U_ERROR;
    }
    if(Invert==Inv) return U_OK; // Nothing to do

    switch(MType)
    {
    case U_JACMAT_DIAGCONST:
        Invert = Inv;
        if(Wconst>0.) Wconst = 1./Wconst;
        return U_OK;

    case U_JACMAT_DIAGONAL:
        if(Eigen==NULL || Wmat==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::SetInvert(). Function not implemented for MType==U_JACMAT_DIAGONAL.\n");
            return U_ERROR;
        }
        else
        {
            for(int k=0; k<N  ; k++) if(Wmat[k]>0) Wmat[k] = 1./Wmat[k];
        }
        Invert = Inv;
        return U_OK;

    case U_JACMAT_GENERAL:
        if(Eigen==NULL || Wmat==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::SetInvert(). Eigen or Wmat are NULL.\n");
            return U_ERROR;
        }

        if(EigOffset2>0.)
        {
            CI.AddToLog("ERROR: UJacobi::SetInvert(). Not yet implemented for the case of EigOffset2>0. EigOffset2=%g\n",EigOffset2);
            return U_ERROR;
        }
        Invert = Inv;
        if(Invert==true)
        {
            for(int k=0;k<N;k++)
                if(Eigen[k]>0)
                {
                    for(int i=0;i<N;i++) Wmat[i*N+k] /= Eigen[k];
                }
                else
                {
                    for(int i=0;i<N;i++) Wmat[i*N+k]  = 0.;
                }
        }
        else
        {
            for(int k=0;k<N;k++)
                for(int i=0;i<N;i++) Wmat[i*N+k] *= Eigen[k];
        }
        return U_OK;
    }

    CI.AddToLog("ERROR: UJacobi::SetInvert(). Matrix of wrong type: MType = %d.\n", MType);
    return U_ERROR;
}

ErrorType UJacobi::Decompose(const double *Mat, bool Inv, bool AllowNegEig)
/*
   Copy the matrix Mat to Matrix and decompose it.

   In case of NEGATIVE eigenvalues and AllowNegEig==true:

   Neig    =  # positive eigenvalues exceeding the threshold
   Nneg    =  # negative eigenvalues
   NnegEig =  # negative eigenvalues exceeding the threshold
   Eigen[] =  [pos eigval,0...0, neg eigval] The pos eigval are in decreasing magnitude,
                                             the neg eigval are stored with POSITIVE sign in increasing magnitude

   Wmat    =  [W1           , W2           ]
   columns:   [0....N-Nneg-1, N-Nneg...N-1]

   W1 columns: sqrt(eigval)*eigenvector for pos and zero eigval (N-Nneg columns)
   W2 columns: sqrt(-eigval)*eigenvector for neg eigval (Nneg columns)

   such that Matrix = W1 W1^t - W2 W2^t.
*/
{
    for(int k=0; k<N*N; k++) Matrix[k] = Mat[k];
    int svderror = svdcmp_d(Matrix, N, N, Eigen, Wmat);
    if(svderror)
    {
        CI.AddToLog("ERROR: UJacobi::Decompose(). SVD failed. ");
        switch(svderror)
        {
        case 1: CI.AddToLog("Memory allocation. \n"); break;
        case 2: CI.AddToLog("Too many iterations. \n"); break;
        default: CI.AddToLog("\n");
        }
        for(int k=0; k<N*N; k++) Matrix[k] = Mat[k];
        return U_ERROR;
    }

    if(AllowNegEig==false)
    {
        for(int k=0; k<N*N; k++) Matrix[k] = Mat[k];

        Invert  = Inv;
        Nneg    = 0;
        NnegEig = 0;

        ErrorType ErrorDecompose = U_OK;
        for(int k=0; k<N;k++)
        {
            double SqEig = 0;
            if(Eigen[k]<0)
            {
                CI.AddToLog("WARNING: UJacobi::Decompose(). Eigen[%d]=%e <0.! \n",k,Eigen[k]);
                int Nerror = 0;
                for(int i1=0; i1<N; i1++)
                    for(int i2=i1+1; i2<N; i2++)
                    {
                        if(fabs( Matrix[i1*N+i2]-Matrix[i2*N+i1] )>1.e-8)
                        {
                            if(Nerror>10) break;
                            Nerror++;
                            CI.AddToLog("ERROR: UJacobi::Decompose(). Matrix not symmetric in element (%d,%d) := ",i1,i2);
                            CI.AddToLog(" (%f,%f) \n",Matrix[i1*N+i2],Matrix[i2*N+i1]);
                        }
                    }
                if(Nerror==0)
                    CI.AddToLog("Note: UJacobi::Decompose(). Matrix symmetric, but not positive.\n");
                ErrorDecompose = U_ERROR;
            }
            else
                SqEig = sqrt(Eigen[k]);

            if(Invert== true)
            {
                if(SqEig>0)
                    for(int i=0;i<N;i++) Wmat[i*N+k] /= SqEig;
                else
                    for(int i=0;i<N;i++) Wmat[i*N+k] = 0;
            }
            else
                for(int i=0;i<N;i++) Wmat[i*N+k] *= SqEig;

        }
        return ErrorDecompose;
    }
    else // AllowNegEig==true
    {
        Invert             = Inv;
        Nneg               = 0;
        NnegEig            = 0;
        int     kPos       = 0;             // kPos = k-Nneg is the position in OrderEigen
        double* OrderEigen = new double[N]; // OrderEigen = (pos eigvals, 0,..,0,neg eigvals) in case of neg eigval

        ErrorType ErrorDecompose = U_OK;

    /* Check for each eigenvalue whether it is pos or neg, and check whether the matrix Mat is really symmetric */
        for(int k=0;k<N;k++) //loop over eigenvalues
        {
            double SqEig=0.;
            if(Eigen[k]<0) // indicates an error in the SVD output!
            {
                CI.AddToLog("ERROR: UJacobi::Decompose(). SVD yields Eigen[%d]=%e <0.! \n",k,Eigen[k]);
                ErrorDecompose = U_ERROR;
            }
            else
            {
                kPos = k-Nneg;
                OrderEigen[kPos]=Eigen[k];

                SqEig = sqrt(Eigen[k]);

            /* Check for each i whether Wmat(i,k) == Matrix(i,k) or Wmat(i,k) == -Matrix(i,k) or whether these are assymmetric
               Equality is checked by computing the relative difference and comparing this relative difference with
               a threshold that depends on the relative magnitude of the corresponding eigenvalue:
                    if Eigen[k] > 1.e-7  * Eigen[0], threshold = 1.e-4
               else if Eigen[k] > 1.e-9  * Eigen[0], threshold = 1.e-3
               else if Eigen[k] > 1.e-11 * Eigen[0], threshold = 1.e-2
               else                                  threshold = 1.e-1
                */

                int i =0;
                for(    ;i<N;i++)
                {
                    if(fabs(Wmat[i*N+kPos])>1.e-10)
                    {
                        if(fabs(Eigen[k]/Eigen[0])>1e-07)
                        {
                            if(fabs(Wmat[i*N+kPos]-Matrix[i*N+k])/fabs(Wmat[i*N+kPos]) > 1.e-4)
                                break;
                        }
                        else if(fabs(Eigen[k]/Eigen[0])>1e-09)
                        {
                            if(fabs(Wmat[i*N+kPos]-Matrix[i*N+k])/fabs(Wmat[i*N+kPos]) > 1.e-3)
                                break;
                        }
                        else if(fabs(Eigen[k]/Eigen[0])>1e-11)
                        {
                            if(fabs(Wmat[i*N+kPos]-Matrix[i*N+k])/fabs(Wmat[i*N+kPos]) > 1.e-2)
                                break;
                        }
                        else if(fabs(Wmat[i*N+kPos]-Matrix[i*N+k])/fabs(Wmat[i*N+kPos]) > 1.e-1)
                            break;
                    }
                    else if(fabs(Wmat[i*N+kPos]-Matrix[i*N+k]) > 1.e-6)
                        break;
                }
                if (i==0) // probably the k^th eigenvalue is negative, and the k^th columns of Wmat and Matrix are opposite
                {
                    int ii=0;
                    for(    ;ii<N;ii++)
                    {
                        if(fabs(Wmat[ii*N+kPos])>1.e-10)
                        {
                            if(fabs(Eigen[k]/Eigen[0])>1e-07)
                            {
                                if(fabs(Wmat[ii*N+kPos]+Matrix[ii*N+k])/fabs(Wmat[ii*N+kPos])>1.e-4)
                                    break;
                            }
                            else if(fabs(Eigen[k]/Eigen[0])>1e-09)
                            {
                                if(fabs(Wmat[ii*N+kPos]+Matrix[ii*N+k])/fabs(Wmat[ii*N+kPos])>1.e-3)
                                    break;
                            }
                            else if(fabs(Eigen[k]/Eigen[0])>1e-11)
                            {
                                if(fabs(Wmat[ii*N+kPos]+Matrix[ii*N+k])/fabs(Wmat[ii*N+kPos])>1.e-2)
                                    break;
                            }
                            else if(fabs(Wmat[ii*N+kPos]+Matrix[ii*N+k])/fabs(Wmat[ii*N+kPos])>1.e-1)
                                    break;
                        }
                        if(fabs(Wmat[ii*N+kPos]+Matrix[ii*N+k])>1.e-6)
                            break;
                    }
                    if(ii<N) // The columns are not entirely equal or opposite -> asymmetry!
                    {
                        CI.AddToLog("ERROR: UJacobi::Decompose(). Matrix not symmetric!\n");
                        ErrorDecompose = U_ERROR;
                    }
                    else  //the singular vectors for the k-th singular value have opposite signs
                    {
                        Nneg++;
                        Neig--;
                        OrderEigen[N-Nneg]=Eigen[k];

                    /* Sort Wmat, such that eigenvectors corresponding to neg eigval are at the end */
                        double* Wcol = new double[N];
                        for(int j=0;j<N;j++) Wcol[j]=Wmat[j*N+kPos]; // Wcol is the column to be placed at the end

                        for(int j=kPos; j<N-Nneg;j++)
                            for(int l=0;l<N;l++)   // shift columns in Wmat one position to the left
                                Wmat[l*N+j] = Wmat[l*N+j+1];
                        kPos= N-Nneg;
                        for(int j=0;j<N;j++)       // place current column at beginning of end columns
                            Wmat[j*N+kPos] = Wcol[j];
                        delete[] Wcol;
                    }
                }
                else if(i<N) // The columns are partly though not entirely equal -> asymmetry!
                {
                    CI.AddToLog("ERROR: UJacobi::Decompose(). Matrix not symmetric!\n");
                    ErrorDecompose = U_ERROR;
                }
            }

            if(Invert==true)
            {
                if(SqEig>0)
                    for(int i=0;i<N;i++) Wmat[i*N+kPos] /= SqEig;
                else
                    for(int i=0;i<N;i++) Wmat[i*N+kPos] = 0;
            }
            else
                for(int i=0;i<N;i++) Wmat[i*N+kPos] *= SqEig;
        }
        for(int k=0; k<N*N; k++) Matrix[k] = Mat[k];
        delete[] Eigen;
        Eigen = OrderEigen;
        NnegEig = Nneg;

        return ErrorDecompose;
    }
}

double UJacobi::WeightedNorm(const double* v) const
/*
     Return the (weighed) norm of the vector v[]
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::WeightedNorm(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::WeightedNorm(). Not implemented for nondefinite matrices.\n");
        return 0.;
    }
    if(v==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::WeightedNorm(). Invalid NULL argument(s). \n");
        return 0.;
    }

/* Compute inner product*/
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return 0.;

    case U_JACMAT_DIAGCONST:
        {
            double        Imp = 0;
            const double  *pv = v;
            for(int k=0; k<Neig; k++, pv++) Imp += *pv * *pv;
            return Imp*Wconst*Wconst;
        }

    case U_JACMAT_DIAGONAL:
        {
            double        Imp = 0;
            const double  *pv = v;
            if(Invert==true)
            {
                for(int k=0; k<N; k++, pv++)
                    if(EigInd[k]<Neig && Eigen[k]>0)
                        Imp += *pv * *pv/ Eigen[k];
            }
            else
            {
                for(int k=0; k<N; k++, pv++)
                    if(EigInd[k]<Neig && Eigen[k]>0)
                        Imp += *pv * *pv* Eigen[k];
            }
            return Imp*Wconst*Wconst;
        }

    case U_JACMAT_GENERAL:
        {
            double Imp = 0;
            for(int k=0; k<Neig; k++)
            {
                double       temp = 0;
                const double *pv  = v;
                for(int n=0; n<N; n++, pv++)
                    temp += Wmat[n*N+k] * *pv;

                Imp += temp*temp;
            }
            return Imp;
        }
    }
    return 0;
}

double UJacobi::Improd(const double* v1, const double* v2, int inc) const
/*
     Return the (weighed) inner product between v1[] and v2[]:
     v1T * J * v2   (or  v1T * Jinv * v2)
 */
{
    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::Improd(). Not implemented for nondefinite matrices");
        return 0.;
    }

/* Test arguments */
    if(v1==NULL || v2==NULL || inc<=0)
    {
        CI.AddToLog("ERROR: UJacobi::Improd(). Invalid (NULL) argument, inc = %d .\n", inc);
        return 0.;
    }
/* Compute inner product*/
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return 0.;

    case U_JACMAT_DIAGCONST:
        {
            double        Imp = 0;
            const double *pv1 = v1;
            const double *pv2 = v2;
            for(int k=0; k<Neig; k++, pv1+=inc, pv2+=inc) Imp += *pv1 * *pv2;
            return Imp*Wconst*Wconst;
        }

    case U_JACMAT_DIAGONAL:
        {
            double        Imp = 0;
            const double *pv1 = v1;
            const double *pv2 = v2;
            if(Invert==true)
            {
                for(int k=0; k<N; k++, pv1+=inc, pv2+=inc)
                    if(EigInd[k]<Neig && Eigen[k]>0)
                        Imp += *pv1 * *pv2/ Eigen[k];
            }
            else
            {
                for(int k=0; k<N; k++, pv1+=inc, pv2+=inc)
                    if(EigInd[k]<Neig && Eigen[k]>0)
                        Imp += *pv1 * *pv2* Eigen[k];
            }
            return Imp*Wconst*Wconst;
        }

    case U_JACMAT_GENERAL:
        {
            double Imp = 0;
            for(int k=0; k<Neig; k++)
            {
                double temp1 = 0;
                double temp2 = 0;
                for(int n=0; n<N; n++)
                {
                    temp1 += Wmat[n*N+k] * v1[n*inc];
                    temp2 += Wmat[n*N+k] * v2[n*inc];
                }
                Imp += temp1*temp2;
            }
            return Imp;
        }
    }
    return 0;
}

double* UJacobi::WmatTAT(const double* A, int Nrow) const
/*
      Return a new array, of N rows and Nrow columns, with

      NewArray = WmatT * AT. The last N-Neig rows of NewArray are filled with zeroes
      if only positive eigenvalues occur. In case of negative eigenvalues, the last
      columns are not filled with zeroes.
*/
{
/* Test arguments */
    if(A   ==NULL) return NULL;

/* Compute matrix product */

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return NULL;

    case U_JACMAT_DIAGCONST:
        {
            double *WmatTAT = new double[N*Nrow];
            if(WmatTAT==NULL) return NULL;

            double *pWmatTAT = WmatTAT;
            for(int k=0; k<Neig; k++)
                for(int i=0; i<Nrow; i++)
                    *pWmatTAT++ = Wconst * A[i*N+k];

            for(int k=Neig*Nrow; k<N*Nrow; k++) *pWmatTAT++ = 0;
            return WmatTAT;
        }
    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::WmatTAT(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return NULL;
            }
            double *WmatTAT = new double[N*Nrow];
            if(WmatTAT==NULL) return NULL;

            double *pWmatTAT = WmatTAT;
            for(int k=0; k<Neig; k++)
                for(int i=0; i<Nrow; i++)
                    *pWmatTAT++ = Wmat[k] * A[i*N+k];

            for(int k=Neig*Nrow; k<N*Nrow; k++) *pWmatTAT++ = 0;
            return WmatTAT;
        }
    case U_JACMAT_GENERAL:
        {
            if(Wmat==NULL) return NULL;

            double *WmatTAT = new double[N*Nrow];
            if(WmatTAT==NULL) return NULL;

            double *pWmatTAT = WmatTAT;

            if(Nneg==0)
            {
                int k=0;
                for(   ; k<Neig; k++)
                    for(int i=0; i<Nrow; i++, pWmatTAT++)
                    {
                        const double *pA = A   +i*N;
                        double    *pWmat = Wmat+k;
                        *pWmatTAT     = 0;
                        for(int j=0; j<N; j++, pWmat+=N) *pWmatTAT += *pWmat * *pA++;
                    }
                k= Neig*Nrow;
                for(        ; k<N*Nrow; k++) *pWmatTAT++ = 0;
            }
            else // if Nneg>0, do not fill the last columns with zeroes
            {
                for(int k=0; k<N; k++)
                    for(int i=0; i<Nrow; i++, pWmatTAT++)
                    {
                        const double *pA = A   +i*N;
                        double    *pWmat = Wmat+k;
                        *pWmatTAT     = 0;
                        for(int j=0; j<N; j++, pWmat+=N) *pWmatTAT += *pWmat * *pA++;
                    }
            }
            return WmatTAT;
        }
    }
    return NULL;
}

double* UJacobi::WmatTA(const double* A, int Ncol) const
/*
      Return a new array, of N rows and Ncol columns, with

      NewArray = WmatT * A. The last N-Neig rows of NewArray are filled with zeroes
      if only positive eigenvalues occur. In case of negative eigenvalues, the last
      columns are not filled with zeroes.
 */
{
    if(MType==U_JACMAT_UNKNOWN) return NULL;

    double *WmatTA = new double[N*Ncol];
    if(WmatTA==NULL) return NULL;

    double *pWmatTA  = WmatTA;
    const double *pA = A;
    for(int k=0; k<N*Ncol; k++) *pWmatTA++ = *pA++;

    if(MultiplyWmatTA(WmatTA, Ncol)!=U_OK)
    {
        delete[] WmatTA;
        return NULL;
    }

    return WmatTA;
}

double* UJacobi::WmatTA(const float* A, int Ncol) const
/*
      Return a new array, of N rows and Ncol columns, with

      NewArray = WmatT * A. The last N-Neig rows of NewArray are filled with zeroes
      if only positive eigenvalues occur. In case of negative eigenvalues, the last
      columns are not filled with zeroes.

      Note: input array is float[], output type is double[]
 */
{
/* Test arguments */
    if(A   ==NULL) return NULL;

/* Compute matrix product */

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return NULL;

    case U_JACMAT_DIAGCONST:
        {
            double *WmatTA = new double[N*Ncol];
            if(WmatTA==NULL) return NULL;

            double *pWmatTA  = WmatTA;
            const float  *pA = A;
            for(int k=0; k<Neig*Ncol; k++) *pWmatTA++ = Wconst * *pA++;

            for(int k=Neig*Ncol; k<N*Ncol; k++) *pWmatTA++ = 0;
            return WmatTA;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::WmatTA(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return NULL;
            }
            double *WmatTA = new double[N*Ncol];
            if(WmatTA==NULL) return NULL;

            double *pWmatTA  = WmatTA;
            const float  *pA = A;
            for(int k=0; k<Neig; k++)
                for(int i=0; i<Ncol; i++)
                    *pWmatTA++ = Wmat[k] * *pA++;

            for(int k=Neig*Ncol; k<N*Ncol; k++) *pWmatTA++ = 0;
            return WmatTA;
        }

    case U_JACMAT_GENERAL:
        {
            if(Wmat==NULL) return NULL;

            double *WmatTA = new double[N*Ncol];
            if(WmatTA==NULL) return NULL;

            double *pWmatTA = WmatTA;
            if(Nneg==0)
            {
                for(int k=0; k<Neig; k++)
                    for(int j=0; j<Ncol; j++, pWmatTA++)
                    {
                        const float *pA = A   +j;
                        double *pWmat   = Wmat+k;
                        *pWmatTA = 0;
                        for(int i=0; i<N; i++, pWmat+=N, pA+=Ncol) *pWmatTA += *pWmat * *pA;
                    }

                for(int k=Neig*Ncol; k<N*Ncol; k++) *pWmatTA++ = 0;
            }
            else // do not fill the last rows with zeroes
            {
                for(int k=0; k<N; k++)
                    for(int j=0; j<Ncol; j++, pWmatTA++)
                    {
                        const float *pA = A   +j;
                        double *pWmat   = Wmat+k;
                        *pWmatTA = 0;
                        for(int i=0; i<N; i++, pWmat+=N, pA+=Ncol) *pWmatTA += *pWmat * *pA;
                    }
            }
            return WmatTA;
        }
    }
    return NULL;
}

double* UJacobi::GetAJAT(const double* A, int Nrow) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::GetAJAT(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(A==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetAJAT(). Invalid NULL argument(s). \n");
        return NULL;
    }
    if(Nrow<=0)
    {
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Nrow = %d out of range. \n", Nrow);
        return NULL;
    }
    double* Sum = new double[Nrow*Nrow];
    if(Sum==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Memory allocation. Nrow = %d  . \n", Nrow);
        return NULL;
    }
    for(int kk=0; kk<Nrow*Nrow; kk++) Sum[kk]=0.;
    if(AddAJAT(Sum, A, Nrow, false)!=U_OK)
    {
        delete Sum;
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Adding AJAT . \n");
        return NULL;
    }
    return Sum;
}

ErrorType UJacobi::AddAJAT(double *Sum, const double* A, int Nrow, bool UpperOnly) const
/*
    Add A*J*AT  (or A*Jinv*AT) to the Nrow*Nrow matrix Sum. The number of rows of
    A is Nrow; its number of columns is N).

    If(UpperOnly==true), then only the part on and upper the diagonal of Sum[] is updated.

    Note: it is assumed that Sum[] is symmetric on entering the function.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Sum==NULL||A==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(Nrow<=0)
    {
        CI.AddToLog("ERROR: UJacobi::AddAJAT(). Nrow = %d out of range. \n", Nrow);
        return U_ERROR;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double factor = Wconst*Wconst;
            for(int i1=0; i1<Nrow; i1++)
            {
                for(int i2=0; i2<Nrow; i2++)
                {
                    if(i2>=i1)
                    {
                        double  Improd   = 0.;
                        const double* M1 = A+i1*N;
                        const double* M2 = A+i2*N;

                        for(int k=0; k<Neig; k++) Improd += *M1++ * *M2++;
                        Sum[i1*Nrow+i2] += factor*Improd;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[i1*Nrow+i2]  = Sum[i2*Nrow+i1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(EigInd==NULL || Eigen==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddAJAT(). Eigen==NULL or EigInd==NULL. \n");
                return U_ERROR;
            }
            for(int i1=0; i1<Nrow; i1++)
            {
                for(int i2=0; i2<Nrow; i2++)
                {
                    if(i2>=i1)
                    {
                        double  Imp   = 0.;
                        const double* M1 = A+i1*N;
                        const double* M2 = A+i2*N;

                        if(Invert==true)
                        {
                            for(int k=0; k<N; k++)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1++ * *M2++/ Eigen[k];
                        }
                        else
                        {
                            for(int k=0; k<N; k++)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1++ * *M2++* Eigen[k];
                        }
                        Sum[i1*Nrow+i2] += Imp;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[i1*Nrow+i2]  = Sum[i2*Nrow+i1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* pWmatTAT = WmatTAT(A, Nrow);
            if(pWmatTAT==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddAJAT(). Memory allocation.\n");
                return U_ERROR;
            }

            for(int i1=0; i1<Nrow; i1++)
            {
                for(int i2=0; i2<Nrow; i2++)
                {
                    if(i2>=i1)
                    {
                        double Improd = 0.;
                        for(int k=0; k<Neig; k++)    Improd    += pWmatTAT[k*Nrow+i1]*pWmatTAT[k*Nrow+i2];
                        double ImprodNeg = 0.;
                        for(int k=0; k<NnegEig; k++) ImprodNeg += pWmatTAT[(N-1-k)*Nrow+i1]*pWmatTAT[(N-1-k)*Nrow+i2];
                        Sum[i1*Nrow+i2] += (Improd-ImprodNeg);
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[i1*Nrow+i2]  = Sum[i2*Nrow+i1];
                    }
                }
            }
            delete[] pWmatTAT;
            return U_OK;
        }
    }
    return U_ERROR;
}

double* UJacobi::GetATJA(const double* A, int Ncol) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::GetATJA(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(A==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetATJA(). Invalid NULL argument(s). \n");
        return NULL;
    }
    if(Ncol<=0)
    {
        CI.AddToLog("ERROR: UJacobi::GetATJA(). Ncol = %d out of range. \n", Ncol);
        return NULL;
    }
    double* Sum = new double[Ncol*Ncol];
    if(Sum==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetATJA(). Memory allocation. Ncol = %d  . \n", Ncol);
        return NULL;
    }
    for(int kk=0; kk<Ncol*Ncol; kk++) Sum[kk]=0.;
    if(AddATJA(Sum, A, Ncol, false)!=U_OK)
    {
        delete Sum;
        CI.AddToLog("ERROR: UJacobi::GetATJA(). Adding ATJA . \n");
        return NULL;
    }
    return Sum;
}

ErrorType UJacobi::AddATJA(double *Sum, const double* A, int Ncol, bool UpperOnly) const
/*
    Add AT*J*A  (or AT*Jinv*A) to the Ncol*Ncol matrix Sum. The number of rows of
    A is N; its number of columns is Ncol).

    If(UpperOnly==true), then only the part on and upper the diagonal of Sum[] is updated.

    Note: it is assumed that Sum[] is symmetric on entering the function.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Sum==NULL||A==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(Ncol<=0)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA(). Ncol = %d out of range. \n", Ncol);
        return U_ERROR;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double factor = Wconst*Wconst;
            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double  Imp   = 0.;
                        const double* M1 = A+j1;
                        const double* M2 = A+j2;
                        for(int k=0; k<Neig; k++,M1+=Ncol,M2+=Ncol)
                            Imp += *M1 * *M2;

                        Sum[j1*Ncol+j2] += factor*Imp;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(EigInd==NULL || Eigen==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddATJA(). Eigen==NULL or EigInd==NULL. \n");
                return U_ERROR;
            }
            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double  Imp   = 0.;
                        const double* M1 = A+j1;
                        const double* M2 = A+j2;
                        if(Invert==true)
                        {
                            for(int k=0; k<N; k++,M1+=Ncol,M2+=Ncol)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1 * *M2/ Eigen[k];
                        }
                        else
                        {
                            for(int k=0; k<N; k++,M1+=Ncol,M2+=Ncol)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1 * *M2* Eigen[k];
                        }
                        Sum[j1*Ncol+j2] += Imp;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* WmatA = WmatTA(A, Ncol);
            if(WmatA==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddATJA(). Memory allocation.\n");
                return U_ERROR;
            }

            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double Imp = 0.;
                        for(int k=0; k<Neig; k++)    Imp    += WmatA[k*Ncol+j1]*WmatA[k*Ncol+j2];
                        double ImpNeg = 0.;
                        for(int k=0; k<NnegEig; k++) ImpNeg += WmatA[(N-1-k)*Ncol+j1]*WmatA[(N-1-k)*Ncol+j2];
                        Sum[j1*Ncol+j2] += (Imp-ImpNeg);
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            delete[] WmatA;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::AddATJA(double *Sum, const float* A, int Ncol, bool UpperOnly) const
/*
    Add AT*J*A  (or AT*Jinv*A) to the Ncol*Ncol matrix Sum. The number of rows of
    A is N; its number of columns is Ncol).

    If(UpperOnly==true), then only the part on and upper the diagonal of Sum[] is updated.

    Note: it is assumed that Sum[] is symmetric on entering the function.
    Note: A is of type float[]
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA()f. Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Sum==NULL||A==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA()f. Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(Ncol<=0)
    {
        CI.AddToLog("ERROR: UJacobi::AddATJA()f. Ncol = %d out of range. \n", Ncol);
        return U_ERROR;
    }


    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double factor = Wconst*Wconst;
            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double Imp   = 0.;
                        const float* M1 = A+j1;
                        const float* M2 = A+j2;
                        for(int k=0; k<Neig; k++,M1+=Ncol,M2+=Ncol)
                            Imp += *M1 * *M2;

                        Sum[j1*Ncol+j2] += factor*Imp;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(EigInd==NULL || Eigen==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddATJA()f. Eigen==NULL or EigInd==NULL. \n");
                return U_ERROR;
            }
            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double Imp   = 0.;
                        const float* M1 = A+j1;
                        const float* M2 = A+j2;
                        if(Invert==true)
                        {
                            for(int k=0; k<N; k++,M1+=Ncol,M2+=Ncol)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1 * *M2 /Eigen[k];
                        }
                        else
                        {
                            for(int k=0; k<N; k++,M1+=Ncol,M2+=Ncol)
                                if(EigInd[k]<Neig && Eigen[k]>0)
                                    Imp += *M1 * *M2 *Eigen[k];
                        }
                        Sum[j1*Ncol+j2] += Imp;
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* WmatA = WmatTA(A, Ncol);
            if(WmatA==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddATJA(). Memory allocation.\n");
                return U_ERROR;
            }

            for(int j1=0; j1<Ncol; j1++)
            {
                for(int j2=0; j2<Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double Improd = 0.;
                        for(int k=0; k<Neig; k++)    Improd    += WmatA[k*Ncol+j1]*WmatA[k*Ncol+j2];
                        double ImprodNeg = 0.;
                        for(int k=0; k<NnegEig; k++) ImprodNeg += WmatA[(N-k-1)*Ncol+j1]*WmatA[(N-k-1)*Ncol+j2];
                        Sum[j1*Ncol+j2] += (Improd-ImprodNeg);
                    }
                    else if(UpperOnly==false)
                    {
                        Sum[j1*Ncol+j2] = Sum[j2*Ncol+j1];
                    }
                }
            }
            delete[] WmatA;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::AddA1TJA2(double *Sum, const double* A1, int Ncol1, const double* A2, int Ncol2) const
/*
    Add A1T*J*A2  (or A1T*Jinv*A2) to the Ncol1*Ncol2 matrix Sum.

    The number of rows of A1 is N; its number of columns is Ncol1).
    The number of rows of A2 is N; its number of columns is Ncol2).
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR:UJacobi::AddA1TJA2(). Not implemented for nondefinite matrices.\n");
        return U_ERROR;
    }
    if(Sum==NULL || A1==NULL || A2==NULL) return U_ERROR;
    if(Ncol1<=0 || Ncol2<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double fact = Wconst*Wconst;
            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double    Imp = 0.;
                    const double* M1 = A1+j1;
                    const double* M2 = A2+j2;
                    for(int k=0; k<Neig; k++,M1+=Ncol1,M2+=Ncol2)
                        Imp += *M1 * *M2;

                    Sum[j1*Ncol2+j2] += fact*Imp;
                }
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double    Imp = 0.;
                    const double* M1 = A1+j1;
                    const double* M2 = A2+j2;
                    if(Invert==true)
                    {
                        for(int k=0; k<N; k++,M1+=Ncol1,M2+=Ncol2)
                            if(EigInd[k]<Neig && Eigen[k]>0)
                                Imp += *M1 * *M2 / Eigen[k];
                    }
                    else
                    {
                        for(int k=0; k<N; k++,M1+=Ncol1,M2+=Ncol2)
                            if(EigInd[k]<Neig && Eigen[k]>0)
                                Imp += *M1 * *M2 * Eigen[k];
                    }
                    Sum[j1*Ncol2+j2] += Imp;
                }
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* WmatA1 = WmatTA(A1, Ncol1);
            if(WmatA1==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddA1TJA2(). Memory allocation.\n");
                return U_ERROR;
            }
            double* WmatA2 = WmatTA(A2, Ncol2);
            if(WmatA2==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddA1TJA2(). Memory allocation.\n");
                return U_ERROR;
            }

            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double Imp = 0.;
                    for(int k=0; k<Neig; k++) Imp += WmatA1[k*Ncol1+j1]*WmatA2[k*Ncol2+j2];
                    Sum[j1*Ncol2+j2] += Imp;
                }
            }
            delete[] WmatA1;
            delete[] WmatA2;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::AddA1TJA2(double *Sum, const float* A1, int Ncol1, const double* A2, int Ncol2) const
/*
    Add A1T*J*A2  (or A1T*Jinv*A2) to the Ncol1*Ncol2 matrix Sum.

    The number of rows of A1 is N; its number of columns is Ncol1).
    The number of rows of A2 is N; its number of columns is Ncol2).

    Note: A1 is of type float[], A2 is of type double[].
 */
{
    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("ERROR:UJacobi::AddA1TJA2(). Not implemented for nondefinite matrices.\n");
        return U_ERROR;
    }
    if(Sum==NULL || A1==NULL || A2==NULL) return U_ERROR;
    if(Ncol1<=0 || Ncol2<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double fact = Wconst*Wconst;
            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double    Improd = 0.;
                    const float*  M1 = A1+j1;
                    const double* M2 = A2+j2;
                    for(int k=0; k<Neig; k++,M1+=Ncol1,M2+=Ncol2)
                        Improd += *M1 * *M2;

                    Sum[j1*Ncol2+j2] += fact*Improd;
                }
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double    Imp = 0.;
                    const float*  M1 = A1+j1;
                    const double* M2 = A2+j2;
                    if(Invert==true)
                    {
                        for(int k=0; k<N; k++,M1+=Ncol1,M2+=Ncol2)
                            if(EigInd[k]<Neig && Eigen[k]>0)
                                Imp += *M1 * *M2 /Eigen[k];
                    }
                    else
                    {
                        for(int k=0; k<N; k++,M1+=Ncol1,M2+=Ncol2)
                            if(EigInd[k]<Neig && Eigen[k]>0)
                                Imp += *M1 * *M2 *Eigen[k];
                    }
                    Sum[j1*Ncol2+j2] += Imp;
                }
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* WmatA1 = WmatTA(A1, Ncol1);
            if(WmatA1==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddA1TJA2(). Memory allocation.\n");
                return U_ERROR;
            }
            double* WmatA2 = WmatTA(A2, Ncol2);
            if(WmatA2==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::AddA1TJA2(). Memory allocation.\n");
                return U_ERROR;
            }

            for(int j1=0; j1<Ncol1; j1++)
            {
                for(int j2=0; j2<Ncol2; j2++)
                {
                    double Improd = 0.;
                    for(int k=0; k<Neig; k++) Improd += WmatA1[k*Ncol1+j1]*WmatA2[k*Ncol2+j2];
                    Sum[j1*Ncol2+j2] += Improd;
                }
            }
            delete[] WmatA1;
            delete[] WmatA2;
            return U_OK;
        }
    }
    return U_ERROR;
}
ErrorType UJacobi::MultiplyJA(double* A, int Ncol) const
/*
     Replace the matrix A by:  J * A

     Note: If Nneg==0, the last N-Neig rows are filled with zeroes.
     if Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    
    if(A==NULL || Ncol<=0) return U_ERROR;

/* Compute matrix product */
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double *pA = A;

            double W2 = Wconst*Wconst;
            if(W2!=1.)
                for(int k=0; k<Neig*Ncol; k++) *pA++ *= W2;

            for(int k=Neig*Ncol; k<N*Ncol; k++) *pA++ = 0;
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyJA(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<N; i++)
                for(int j=0; j<Ncol; j++) *pA++ *= Eigen[i];

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            if(NOT(Invert)&&Matrix&&Neig>N/2)
            {
                double* Col = new double[N];
                if(Col==NULL)
                {
                    CI.AddToLog("ERROR: UJacobi::MultiplyJA(). Memory allocation. N=%d\n",N);
                    return U_ERROR;
                }

                for(int j=0; j<Ncol; j++)
                {
                    double *pMat  = Matrix;
                    for(int i=0; i<N; i++)  // Loop over rows
                    {
                        double  cl    = 0;
                        double *pA    = A     +j;
                        for(int k=0; k<N; k++,pA+=Ncol) cl += *pMat++ * *pA;
                        Col[i] = cl;
                    }
                    double *pA    = A     +j;
                    double *pC    = Col;
                    for(int i=0; i<N; i++,pA+=Ncol) *pA = *pC++;
                }

                delete[] Col;
                return U_OK;
            }
            else
            {
                if(MultiplyWmatTA(A, Ncol)!=U_OK ||
                   MultiplyWmatA (A, Ncol)!=U_OK)     
                {
                    CI.AddToLog("ERROR UJacobi::MultiplyJA(). Applying MultiplyWmatTA() or MultiplyWmatA().\n");
                    return U_ERROR;
                }
            }
            return U_OK;
        }
    }
    return U_ERROR;
}
ErrorType UJacobi::MultiplyAJ(double* A, int Nrow) const
/*
     Replace the matrix A by:  A * J.
     If Nneg==0, the last N-Neig collumns are filled with zeroes.
     In case Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(A==NULL) return U_ERROR;
    if(Nrow<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            if(Wconst==1. && Neig==N) return U_OK;

            double* pA = A;
            double  W2 = Wconst;
            for(int i=0; i<Nrow; i++)
            {
                for(int k=0;    k<Neig; k++) *pA++ *= W2;
                for(int k=Neig; k<N   ; k++) *pA++ = 0;
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyAJ(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<Nrow; i++)
            {
                for(int k=0;    k<Neig; k++) *pA++ *= Eigen[k];
                for(int k=Neig; k<N   ; k++) *pA++ = 0;
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            if(NOT(Invert)&&Matrix&&Neig>N/2)
            {
                double* Row = new double[N];
                if(Row==NULL)
                {
                    CI.AddToLog("ERROR: UJacobi::MultiplyAJ(). Memory allocation. N=%d\n",N);
                    return U_ERROR;
                }

                double *pA    = A;
                for(int i=0; i<Nrow; i++)
                {
                    for(int j=0; j<N; j++) // loop over collumns
                    {
                        double  rw    = 0;
                        double *pMat  = Matrix+j;
                        for(int k=0; k<N; k++, pMat+=N) rw += *pA++ * *pMat;
                        pA    -= N;
                        Row[j] = rw;
                    }
                    double* pR = Row;
                    for(int j=0; j<N; j++) *pA++ = *pR++;
                }

                delete[] Row;
                return U_OK;
            }
            else
            {
                if(MultiplyAWmat (A, Nrow)!=U_OK || 
                   MultiplyAWmatT(A, Nrow)!=U_OK)
                {
                    CI.AddToLog("ERROR UJacobi::MultiplyAJ(). Applying MultiplyAWmat() or MultiplyAWmatT(). \n");
                    return U_ERROR;
                }
            }
            return U_OK;
        }
    }
    return U_ERROR;
}
ErrorType UJacobi::MultiplyWmatA(double* A, int Ncol) const
/*
     Replace the matrix A by: Wmat * A.
     In case Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(A==NULL) return U_ERROR;
    if(Ncol<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            if(Wconst==1.) return U_OK;

            double* pA = A;
            for(int k=0; k<Ncol*N; k++) *pA++ *= Wconst;
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyWmatA(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<N; i++)
                for(int j=0; j<Ncol; j++) *pA++ *= Wmat[i];

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* Col = new double[N];
            if(Col==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::MultiplyWA(). Memory allocation. N=%d\n",N);
                return U_ERROR;
            }

            for(int j=0; j<Ncol; j++)
            {
                for(int i=0; i<N; i++)
                {
                    double  cl    = 0;
                    double *pWmat = Wmat+i*N;
                    double *pA    = A   +j;
                    if(Nneg==0)
                        for(int k=0; k<Neig; k++,pA+=Ncol) cl += *pWmat++ * *pA;
                    else
                        for(int k=0; k<N; k++,pA+=Ncol) cl += *pWmat++ * *pA;
                    Col[i] = cl;
                }
                for(int i=0; i<N; i++) A[i*Ncol+j] = Col[i];
            }

            delete[] Col;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::MultiplyAWmatT(double* A, int Nrow) const
/*
     Replace the matrix A by: A*WmatT.
     In case Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(A==NULL) return U_ERROR;
    if(Nrow<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            if(Wconst==1.) return U_OK;

            double* pA = A;
            for(int k=0; k<Nrow*N; k++) *pA++ *= Wconst;
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyAWmatT(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<N; j++) *pA++ *= Wmat[j];

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* Row = new double[N];
            if(Row==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::MultiplyAWT(). Memory allocation. N=%d\n",N);
                return U_ERROR;
            }

            for(int i=0; i<Nrow; i++)
            {
                for(int j=0; j<N; j++)
                {
                    double  rw    =        0;
                    double *pA    =    A+i*N;
                    double *pWmat = Wmat+j*N;
                    if(Nneg==0)
                        for(int k=0; k<Neig; k++) rw += *pA++ * *pWmat++;
                    else
                        for(int k=0; k<N; k++) rw += *pA++ * *pWmat++;
                    Row[j] = rw;
                }
                for(int j=0; j<N; j++) A[i*N+j] = Row[j];
            }

            delete[] Row;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::MultiplyAWmat(double* A, int Nrow) const
/*
     Replace the matrix A by:  A * Wmat.
     If Nneg==0, the last N-Neig collumns are filled with zeroes.
     In case Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(A==NULL) return U_ERROR;
    if(Nrow<=0) return U_ERROR;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            if(Wconst==1. && Neig==N) return U_OK;

            double* pA = A;
            for(int i=0; i<Nrow; i++)
            {
                for(int k=0;    k<Neig; k++) *pA++ *= Wconst;
                for(int k=Neig; k<N   ; k++) *pA++ = 0;
            }
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyAWmat(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<Nrow; i++)
            {
                for(int k=0;    k<Neig; k++) *pA++ *= Wmat[k];
                for(int k=Neig; k<N   ; k++) *pA++ = 0;
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* Row = new double[N];
            if(Row==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::MultiplyAWmat(). Memory allocation. N=%d\n",N);
                return U_ERROR;
            }

            for(int j=0; j<Nrow; j++)
            {
                for(int i=0; i<N; i++)
                {
                    if(Nneg==0)
                    {
                        if(i<Neig)
                        {
                            double  rw    = 0;
                            double *pA    = A   +j*N;
                            double *pWmat = Wmat+i;
                            for(int k=0; k<N; k++,pWmat+=N) rw += *pA++ * *pWmat;
                            Row[i] = rw;
                        }
                        else
                            Row[i] = 0;
                    }
                    else
                    {
                        double  rw    = 0;
                        double *pA    = A   +j*N;
                        double *pWmat = Wmat+i;
                        for(int k=0; k<N; k++,pWmat+=N) rw += *pA++ * *pWmat;
                        Row[i] = rw;
                    }
                }
                for(int i=0; i<N; i++) A[j*N+i] = Row[i];
            }

            delete[] Row;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::MultiplyWmatTA(double* A, int Ncol) const
/*
     Replace the matrix A by:  WmatT * A

     Note: If Nneg==0, the last N-Neig rows are filled with zeroes.
     if Nneg>0, all eigenvalues are taken into account.
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    
    if(A==NULL || Ncol<=0) return U_ERROR;

/* Compute matrix product */
    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double *pA = A;

            if(Wconst!=1.)
                for(int k=0; k<Neig*Ncol; k++) *pA++ *= Wconst;

            for(int k=Neig*Ncol; k<N*Ncol; k++) *pA++ = 0;
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            if(N!=Neig)
            {
                CI.AddToLog("ERROR UJacobi::MultiplyWmatTA(). Function not yet implemented for U_JACMAT_DIAGONAL in combination with Neig<N\n");
                return U_ERROR;
            }
            double* pA = A;
            for(int i=0; i<N; i++)
                for(int j=0; j<Ncol; j++) *pA++ *= Wmat[i];

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double *Col = new double[N];
            if(Col==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::MultiplyWmatTA(). Memory allocation. N=%d\n",N);
                return U_ERROR;
            }

            for(int j=0; j<Ncol; j++)
            {
                for(int k=0; k<N; k++)
                {
                    if(Nneg==0)
                    {
                        if(k<Neig)
                        {
                            double  cl       = 0;
                            double* pWmat    = Wmat+k;
                            const double* pA = A+j;

                            for(int i=0; i<N; i++, pWmat+=N, pA+=Ncol) cl += *pWmat * *pA;
                            Col[k] = cl;
                        }
                        else
                            Col[k]=0;
                    }
                    else
                    {
                        double  cl       = 0;
                        double* pWmat    = Wmat+k;
                        const double* pA = A+j;

                        for(int i=0; i<N; i++, pWmat+=N, pA+=Ncol) cl += *pWmat * *pA;
                        Col[k] = cl;
                    }
                }
                for(int k=0; k<N; k++) A[k*Ncol+j] = Col[k];
            }
            delete[] Col;
            return U_OK;
        }
    }
    return U_ERROR;
}

int UJacobi::GetEigenIndex(double Thresh)
/*
    Return the index of the smallest eigenvalue passing the
    threshold test.
 */
{
    if(MType!=U_JACMAT_GENERAL) return N;
    if(Eigen==NULL)      return 0;
    if(Thresh<0)         return N;

    double sum = 0;
    int    k   = 0;
    for(           ; k<N; k++) sum += Eigen[k]*Eigen[k];

    if(Nneg==0)
    {
        double Err = 0.;
        k = N - 1;
        for(     ; k>=0; k--)
        {
            if(Eigen[k]>0) Err += Eigen[k]*Eigen[k];
            if(Err>Thresh*sum) return k+1;
        }
        return 1;
    }
    else
    {
        double Err = 0.;
        int kPos = N-Nneg-1;
        int kNeg = N-Nneg;

        while(kNeg<N && kPos>=0)
        {
            if(Eigen[kPos]<Eigen[kNeg])
            {
                Err+=Eigen[kPos]*Eigen[kPos];
                if(Err>Thresh*sum) break;
                kPos--;
            }
            else
            {
                Err+=Eigen[kNeg]*Eigen[kNeg];
                if(Err>Thresh*sum) break;
                kNeg++;
            }
        }
        NnegEig = N-kNeg;
        Neig    = kPos+1;

        if(Neig==0)
            Neig=1;

        return Neig;
    }
    return 1;
}
int UJacobi::SetEigenTresholdMaxJump(double MinFactor)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenTresholdMaxJump(). NULL or erroneous object \n");
        return 0;
    }
    if(MType!=U_JACMAT_GENERAL) return Neig=N;
    if(Eigen==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenTresholdMaxJump(). Eigen Array not set. \n");
        return 0;
    }
    if(MinFactor<1.)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenTresholdMaxJump(). MinFactor (=%f) should be more than 1 . \n", MinFactor);
        return Neig;
    }

    if(Eigen[0]<=0)
    {
        CI.AddToLog("ERROR: UJacobi::SetEigenTresholdMaxJump(). First Eigen-value out of range (= %f). \n", Eigen[0]);
        return SetEigenTreshold(0);
    }

    double MaxFactor =   1;
    int    iJump     = N-1;
    for(int i=N-1; i>0; i--)
    {
        if(Eigen[i]<=0)
        {
            iJump = i-1;
            continue;
        }
        double fact = Eigen[i-1]/Eigen[i];
        if(fact<=MinFactor) continue;

        if(fact>=MaxFactor)
        {
            MaxFactor = fact;
            iJump     = i-1;
        }
    }
    return SetEigenTreshold(iJump);
}

int UJacobi::SetEigenTreshold(double Thresh)
{
    if(MType!=U_JACMAT_GENERAL) return Neig=N;
    if(Eigen==NULL)      return 0;
    if(Thresh<0)         return Neig=N;

    return Neig = GetEigenIndex(Thresh);
}

int UJacobi::SetEigenTreshold(int Nei)
{
    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("WARNING: UJacobi::SetEigenTreshold(Neigen) called for nondefinite matrix. IGNORED\n");
        return N;
    }
    if(MType!=U_JACMAT_GENERAL) return Neig=N;
    if(Eigen==NULL)      return 0;

    Neig = MIN(N,MAX(0,Nei));
    return Neig;
}

int UJacobi::SetNegEigenTreshold(int Nei)
{
    if(MType!=U_JACMAT_GENERAL) return Neig=N;
    if(Eigen==NULL)      return 0;

    NnegEig = MIN(MAX(0,Nei),Nneg);
    return NnegEig;
}

ErrorType UJacobi::ComputeJVec(double* ResultVec, const double* Vec) const
/*
    Compute ResultVec = WWT * Vec, thereby ignoring the small eigenvalues.
 */
{
    if(Nneg>0 || NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::ComputeJVec(). Not implemented for nondefinite matrix.\n");
        return U_ERROR;
    }
    if(ResultVec==NULL || Vec==NULL) return U_ERROR;


    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double fac = Wconst*Wconst;
            for(int k=0; k<N; k++) *ResultVec++ = fac * *Vec++;
            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            double* pEig = Eigen;
            if(Invert==true)
            {
                for(int k=0; k<N; k++)
                    if(EigInd[k]<Neig && *pEig>0)
                        *ResultVec++ = *Vec++ / *pEig++;
            }
            else
            {
                for(int k=0; k<N; k++)
                    if(EigInd[k]<Neig && *pEig>0)
                        *ResultVec++ = *Vec++ * *pEig++;
            }
            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            double* temp = new double[Neig];
            if(temp==NULL) return U_ERROR;

/* Compute temp = Wmat T * Vec */
            for(int k=0; k<Neig; k++)
            {
                double        tmp = 0.;
                double*       WM  = Wmat+k;
                const double* Ve  = Vec;
                for(int i=0; i<N; i++,WM+=N) tmp += *WM* *Ve++;
                temp[k] = tmp;
            }

/* Compute ResultVec = Wmat * temp */
            for(int i=0; i<N; i++)
            {
                double  tmp = 0.;
                double* WM  = Wmat+i*N;
                double* Te  = temp;
                for(int k=0; k<Neig; k++) tmp += *WM++ * *Te++;
                ResultVec[i] = tmp;
            }
            delete[] temp;
            return U_OK;
        }
    }
    return U_ERROR;
}

double* UJacobi::Solve(const double* b) const
/*
     Solve Ax = b, where it is assumed that the Jacobi decomposition of A is stored in *this.
     For that purpose, Decompose() should be called prior to Solve(), with Inv==true.

     A new pointer to x[] is returned.
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::Solve(b). Not implemented for nondefinite matrix.\n");
        return NULL;
    }

    double* x=new double[N];

    if(Solve(x,b)==U_OK) return x;

    delete[] x;
    return NULL;
}

ErrorType UJacobi::Solve(double* x, const double* b) const
/*
     Solve Ax = b, where it is assumed that the Jacobi decomposition of A is stored in *this.
     For that purpose, Decompose() should be called prior to Solve(), with Inv==true.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::Solve(x,b). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::Solve(x,b). Not implemented for nondefinite matrix.\n");
        return U_ERROR;
    }

    if(x==NULL || b==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::Solve(). NULL arguments.\n");
        return U_ERROR;
    }
    if(Invert==false)
    {
        CI.AddToLog("ERROR: UJacobi::Solve(). Object should be set at Invert.\n");
        return U_ERROR;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double fac = Wconst*Wconst;
            for(int k=0; k<N; k++) x[k] = fac*b[k];

            return U_OK;
        }

    case U_JACMAT_DIAGONAL:
        {
            for(int k=0; k<N; k++)
                if(EigInd[k]<Neig && Eigen[k]>0) x[k] = b[k]/Eigen[k];
                else                             x[k] = 0;

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        if(Wmat==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::Solve(). Wmat==NULL.\n");
            return U_ERROR;
        }
        {
            double *WmatTb = new double[Neig];
            if(WmatTb==NULL) return U_ERROR;

            double *pWmatTb = WmatTb;
            for(int k=0; k<Neig; k++, pWmatTb++)
            {
                const double *pb = b;
                double *pWmat    = Wmat+k;
                *pWmatTb         = 0;
                for(int j=0; j<N; j++, pWmat+=N) *pWmatTb += *pWmat * *pb++;
            }

            double* px = x;
            for(int i=0; i<N; i++,px++)
            {
                double* pWmat   = Wmat+i*N;
                        pWmatTb = WmatTb;
                        *px     = 0;
                for(int k=0; k<Neig; k++) *px +=  *pWmat++ * *pWmatTb++;
            }

            delete[] WmatTb;
            return U_OK;
        }
    }
    return U_ERROR;
}

ErrorType UJacobi::PseudoInverse(double* AmatInv) const
/*
    Compute the (psudo) inverse of the matrix Amat[]. Store the result in AmatInv[]
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverse(). Not yet implemented for nondefinite matrix.\n");
        return U_ERROR;
    }

    if(AmatInv==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverse(). NULL pointer as argument. \n");
        return U_ERROR;
    }
    if(Invert==false)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverse(). Object should be set at Invert.\n");
        return U_ERROR;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return U_ERROR;

    case U_JACMAT_DIAGCONST:
        {
            double fac = Wconst*Wconst;
            for(int k=0; k<N*N; k++) AmatInv[k] = Matrix[k]/fac;

            return U_OK;
        }

    case U_JACMAT_GENERAL:
        {
            if(Wmat==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::PseudoInverse(). Wmat==NULL.\n");
                return U_ERROR;
            }
            if(Neig==0)
            {
                for(int k=0; k<N*N; k++) AmatInv[k] = 0.;
                return U_OK;
            }

            for(int i1=0; i1<N; i1++)
            {
                for(int i2=0; i2<N; i2++)
                {
                    if(i2>=i1)
                    {
                        AmatInv[i1*N+i2] = 0;
                        for(int k=0; k<Neig; k++)
                            AmatInv[i1*N+i2] += Wmat[i1*N+k]*Wmat[i2*N+k];
                    }
                    else
                        AmatInv[i1*N+i2] = AmatInv[i2*N+i1];
                }
            }
            return U_OK;
        }
    }
    return U_ERROR;
}

double UJacobi::PseudoInverseElem(int i1, int i2) const
/*
    Return the (i1, i2) matrix element of the (pseudo) inverse of the matrix Amat[].
    On ERROR return 0;
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverseElem(). Not yet implemented for nondefinite matrix.\n");
        return 0;
    }


    if(i1<0 || i1>=N ||
       i2<0 || i2>=N)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverseElem(). Matrix element out of range (%d,%d). \n", i1, i2);
        return 0;
    }
    if(Invert==false)
    {
        CI.AddToLog("ERROR: UJacobi::PseudoInverseElem(). Object should be set at Invert.\n");
        return 0;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        return 0;

    case U_JACMAT_DIAGCONST:
        if(i1!=i2 || i1>=Neig) return 0.;
        return Wconst*Wconst;

    case U_JACMAT_DIAGONAL:
        if(i1!=i2 || EigInd[i1]>=Neig || Eigen[i1]<=0) return 0.;
        return Eigen[i1];

    case U_JACMAT_GENERAL:
        {
            if(Wmat==NULL)
            {
                CI.AddToLog("ERROR: UJacobi::PseudoInverseElem(). Wmat==NULL.\n");
                return 0;
            }
            if(Neig==0)  return 0;

            double InvElem = 0;
            for(int k=0; k<Neig; k++)
                InvElem += Wmat[i1*N+k]*Wmat[i2*N+k];

            return InvElem;
        }
    }
    return 0;
}

double UJacobi::TestJacobi(const double *a)
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::TestJacobi(). Not yet implemented for nondefinite matrix.\n");
        return 0;
    }

    if(a==NULL)          return -1;
    if(MType!=U_JACMAT_GENERAL) return -1;

    if(Invert==true)
    {
        for(int k=0;k<N;k++)
            for(int i=0;i<N;i++) Wmat[i*N+k] *= Eigen[k];
    }

    double Err = 0;
    double Nor = 0;
    for(int i1=0; i1<N; i1++)
        for(int i2=i1; i2<N; i2++)
        {
            double A=0;
            for(int k=0; k<N; k++) A += Wmat[i1*N+k]*Wmat[i2*N+k];

            Err += (A - a[i1*N+i2])*(A - a[i1*N+i2]);
            Nor += A*A;
            if(i1!=i2)
            {
                Err += (A - a[i2*N+i1])*(A - a[i2*N+i1]);
                Nor += A*A;
            }
        }

    if(Invert==true)
    {
        for(int k=0;k<N;k++)
            if(Eigen[k]>0)
            {
                for(int i=0;i<N;i++) Wmat[i*N+k] /= Eigen[k];
            }
            else
            {
                for(int i=0;i<N;i++) Wmat[i*N+k]  = 0.;
            }
    }
    return sqrt( Err/Nor );
}

double UJacobi::GetEigen(int i) const
{
    if(i<0||i>=N)
    {
        CI.AddToLog("ERROR: UJacobi::GetEigen(). Index out of range (i=%d). \n",i);
        return 0.;
    }

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        CI.AddToLog("ERROR: UJacobi::GetEigen(). Matrix type unknown. \n");
        return 0;

    case U_JACMAT_DIAGCONST:
        return Wconst*Wconst;

    case U_JACMAT_DIAGONAL:
    case U_JACMAT_GENERAL:
        if(Eigen==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::GetEigen(). Eigen==NULL. \n");
            return 0;
        }
        return Eigen[i];
    }
    CI.AddToLog("ERROR: UJacobi::GetEigen(). Matrix type unknown. MType = %d\n",MType);
    return 0;
}

double* UJacobi::GetEigenVector(int i, bool ForcePos) const
/*
    Return a new double array, containing i-th eigen vector.
    if(ForcePos==true) determine the sign of the eigenvector such
                       that the sum of the elements is positieve.
 */
{
    if(i<0||i>=N)
    {
        CI.AddToLog("ERROR: UJacobi::GetEigenVector(). Index out of range (i=%d). \n",i);
        return NULL;
    }

    double* Evect = new double[N];
    if(Evect==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetEigenVector(). Memory allocation. N=%d \n", N);
        return NULL;
    }
    int k = 0;
    for(     ; k<N; k++) Evect[k] = 0.;

    switch(MType)
    {
    case U_JACMAT_UNKNOWN:
        CI.AddToLog("ERROR: UJacobi::GetEigenVector(). Matrix type unknown. \n");
        return Evect;

    case U_JACMAT_DIAGCONST:
    case U_JACMAT_DIAGONAL:
        Evect[i] = 1;
        break;

    case U_JACMAT_GENERAL:
        if(Eigen==NULL || Wmat==NULL)
        {
            CI.AddToLog("ERROR: UJacobi::GetEigenVector(). Eigen==NULL || Wmat==NULL. \n");
            return Evect;
        }
        if(Invert==true)
        {
            double sqeig = Eigen[i];
            if(sqeig>0) sqeig = sqrt(sqeig);
            for(int k=0; k<N; k++) Evect[k] = Wmat[k*N+i]*sqeig;
        }
        else
        {
            double sqeig = Eigen[i];
            if(sqeig>0) sqeig = 1./sqrt(sqeig);
            for(int k=0; k<N; k++) Evect[k] = Wmat[k*N+i]*sqeig;
        }
        break;

    default:
        CI.AddToLog("ERROR: UJacobi::GetEigenVector(). Matrix type unknown. MType = %d\n",MType);
        return NULL;
    }
    double sum=0;
    k = 0;
    for( ; k<N; k++) sum +=Evect[k];
    if(ForcePos==true && sum<0)
        for(int k=0; k<N; k++) Evect[k] =-Evect[k];

    return Evect;
}


double* UJacobi::GetNormalEigen(void) const
/*
    Return a new double array, containing the normalized the eigen values.
    The sum of these egeinvalues equals 1.0
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::GetNormalEigen(). Not yet implemented for nondefinite matrices\n");
        return NULL;
    }
    double* NormalEigen = new double[N];
    if(NormalEigen==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetNormalEigen(). Memory allocation. N=%d \n", N);
        return NULL;
    }

    double Norm = 0.;
    for(int k=0; k<N; k++)  Norm += GetEigen(k);

    if(Norm>0)
        for(int k=0; k<N; k++) NormalEigen[k] = Eigen[k] / Norm;
    else
        for(int k=0; k<N; k++) NormalEigen[k] = 0.;

    return NormalEigen;
}

double* UJacobi::GetNormalEigen2(void) const
/*
    Return a new double array, containing the normalized squares of the eigen values.
    The sum of these squares equals 1.0
 */
{
    if(Nneg>0||NnegEig>0)
    {
        CI.AddToLog("ERROR: UJacobi::GetNormalEigen2(). Not yet implemented for nondefinite matrices\n");
        return NULL;
    }
    double* NormalEigen2 = new double[N];
    if(NormalEigen2==NULL)
    {
        CI.AddToLog("ERROR: UJacobi::GetNormalEigen2(). Memory allocation. N=%d \n", N);
        return NULL;
    }

    double Norm = 0.;
    for(int k=0; k<N; k++)
    {
        double E = GetEigen(k);
        Norm += E*E;
    }

    if(Norm>0)
        for(int k=0; k<N; k++) NormalEigen2[k] = Eigen[k]*Eigen[k] / Norm;
    else
        for(int k=0; k<N; k++) NormalEigen2[k] = 0.;

    return NormalEigen2;
}

double UJacobi::GetTrace(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UJacobi::GetTrace(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(MType!=U_JACMAT_DIAGCONST && MType!=U_JACMAT_DIAGONAL && MType!=U_JACMAT_GENERAL)
    {
        CI.AddToLog("ERROR: UJacobi::GetTrace(). Matrix type unknown (%d). \n", MType);
        return 0.;
    }
    double Trace = 0;
    for(int k=0; k<N; k++) Trace += GetEigen(k);
    return Trace;
}


const UString& UJacobi::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UJacobi-object\n");
        return Properties;
    }

    Properties  = UString();
    Properties += UString(GetJacMatTypeText(MType),"JacobiMatrixType   = %s \n");
    Properties += UString(BoolAsText(Invert)      ,"InvertMat          = %s \n");
    Properties += UString(N                       ,"N                  = %d \n");
    Properties += UString(Neig                    ,"Neigen             = %d \n");
    Properties += UString(Nneg                    ,"NeigenNeg          = %d \n");
    if(Eigen)
    {
        Properties += UString(Eigen[0]                ,"LargestEigenvalue  = %f \n");
        Properties += UString(Eigen[Neig-1]           ,"SmallestEigenvalue = %f \n");
        Properties += UString(Eigen[N-1]              ,"Eigen[N-1]         = %f \n");
        Properties += UString(GetAverageDiag()        ,"AverageDiagonal    = %f \n");
    }
    Properties += UString(EigOffset2              ,"EigenValueOffset   = %f \n");

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;

ErrorType UJacobi::indexx(int n, const double* arr, int* index)
{
    if(Nneg>0||NnegEig>0) return U_ERROR;

    static const int M      = 7;
    static const int MSTACK = 50;

    int i,indxt,ir=n-1,itemp,j,k,l=0;
    int jstack=0;
    double  a;

    int istack[MSTACK];


    for(j=0;j<n;j++) index[j]=j;

    while(1)
    {
        if(ir-l < M)
        {
            for(j=l+1;j<=ir;j++)
            {
                indxt = index[j];
                a     = arr[indxt];
                for(i=j-1;i>=0;i--)
                {
                    if(arr[index[i]]>= a) break;
                    index[i+1] = index[i];
                }
                index[i+1] = indxt;
            }
            if(jstack == 0) break;

            ir = istack[jstack--];
            l  = istack[jstack--];
        }
        else
        {
            k=(l+ir) >> 1;
            SWAP(index[k],index[l+1]);
            if(arr[index[l+1]] < arr[index[ir]])
            {
                SWAP(index[l+1],index[ir])
            }
            if(arr[index[l]] < arr[index[ir]])
            {
                SWAP(index[l],index[ir])
            }
            if(arr[index[l+1]] < arr[index[l]])
            {
                SWAP(index[l+1],index[l])
            }
            i=l+1;
            j=ir;
            indxt = index[l];
            a     = arr[indxt];
            while(1)
            {
                do i++; while (arr[index[i]] > a);
                do j--; while (arr[index[j]] < a);
                if (j < i) break;
                SWAP(index[i],index[j])
            }
            index[l]=index[j];
            index[j]=indxt;
            jstack += 2;
            if(jstack>=MSTACK)
            {
                CI.AddToLog("ERROR: MSTACK (%d) too small in iindexx.\n",MSTACK);
                for(j=0;j<n;j++) index[j]=j;
                return U_ERROR;
            }
            if(ir-i+1 >= j-l)
            {
                istack[jstack  ]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            }
            else
            {
                istack[jstack  ]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
    return U_OK;
}
#undef SWAP

