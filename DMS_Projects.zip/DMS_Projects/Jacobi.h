#ifndef _JACOBI_INCLUDED
#define _JACOBI_INCLUDED

#include "String.h"
enum JacMatType
{
    U_JACMAT_UNKNOWN,         // Unknown type (used in default constructor)
    U_JACMAT_DIAGCONST,       // Constant diagonal matrix
    U_JACMAT_DIAGONAL,        // Diagonal matrix, with varying diagonal elements
    U_JACMAT_GENERAL          // General symmetric matrix
};
PMT_CCP DLL_IO GetJacMatTypeText(JacMatType MT);

class UField;
class DLL_IO UJacobi
{
public:
    UJacobi();
    UJacobi(int n, double Var=1., bool Inv=true);
    UJacobi(int N1, int N2, double RelN2variance, bool Inv=true);
    UJacobi(const double*Mat, int n, bool Inv=true, bool AllowNegEig=false);    
    UJacobi(const double*Mat, int nFunc, int nDim, double RelEigenThreshold);
    UJacobi(const UJacobi& Jac);
    virtual ~UJacobi();
    UJacobi& operator=(const UJacobi& Jac);
    UJacobi& operator+=(const UJacobi& Jac);
    UJacobi& operator*=(double fac);

    ErrorType       RescaleDiagonal(double SqrtAveDiag);
    double          GetAverageDiag(void) const;

    ErrorType       GetError()   const {return error;}
    double          TestJacobi(const double *a);
    const UString&  GetProperties(UString Comment) const;

    int             GetNdim()    const {return N;}
    int             GetNeig()    const {return Neig;}
    int             GetNneg()    const {return Nneg;}
    int             GetNnegEig() const {return NnegEig;}
    double          GetEigen( int i) const;
    const double*   GetEigen(void) const       {return Eigen;}
    double*         GetNormalEigen(void) const;
    double*         GetNormalEigen2(void) const;
    double*         GetEigenVector(int i, bool ForcePos=false) const;
    double          GetTrace(void) const;

    ErrorType       SetDiagonal(const double* Diag, int n, bool Inv=true);
    ErrorType       SetMatrix(const double*Mat, int n, bool Inv=true);
    const double*   GetMatrixArray(void) const;
    ErrorType       ForceGeneral(void);
    double*         GetThresholdedMatrix(void);
    const double*   GetWmatArray(void) const      {if(this) return Wmat;   return NULL;}
    bool            GetInvert(void)    const      {if(this) return Invert; return false;}

    int             GetEigenIndex(double Thresh);
    int             SetEigenTresholdMaxJump(double MinFactor);
    int             SetEigenTreshold(double Thresh);
    int             SetEigenTreshold(int Ngn);
    int             SetNegEigenTreshold(int Ngn);
    double          GetElem(int k1, int k2) const;
    double          GetDiagElem(int k) const;
    ErrorType       SetInvert(bool Inv);
    ErrorType       SetEigenValueOffset(double Offset);

    ErrorType       SkipSamples(const UField* Selector, int *NSelected, char** Selection);

    double          WeightedNorm(const double* v) const;
    double          Improd(const double* v1, const double* v2, int inc) const;
    double*         WmatTAT(const double* A, int Nrow) const;
    double*         WmatTA(const double* A, int Ncol) const;
    double*         WmatTA(const float*  A, int Ncol) const;    

    double*         GetAJAT(const double* A, int Nrow) const;
    double*         GetATJA(const double* A, int Ncol) const;
    ErrorType       AddAJAT(double *Sum, const double* A, int Nrow, bool UpperOnly=false) const;
    ErrorType       AddATJA(double *Sum, const double* A, int Ncol, bool UpperOnly=false) const;
    ErrorType       AddATJA(double *Sum, const float* A, int Ncol, bool UpperOnly=false) const;
                  
    ErrorType       AddA1TJA2(double *Sum, const double* A1, int Ncol1, const double* A2, int Ncol2) const;
    ErrorType       AddA1TJA2(double *Sum, const float*  A1, int Ncol1, const double* A2, int Ncol2) const;

////                                                              These functions are called in:
//    ErrorType       MultiplyAWmat(double* A, int Nrow) const;   UGLM, ULocCodeDip, ULocStatDip, UProjector
//    ErrorType       MultiplyWmatTA(double* A, int Ncol) const;  ULocCodeDip, ULocStatDip, UMultiChan
//    ErrorType       MultiplyAWmatT(double* A, int Nrow) const;  ULocCodeDip, ULocStatDip, UMultiChan

    ErrorType       MultiplyWmatA(double* A, int Ncol) const;
    ErrorType       MultiplyAWmatT(double* A, int Nrow) const;
                  
    ErrorType       MultiplyAWmat(double* A, int Nrow) const;
    ErrorType       MultiplyWmatTA(double* A, int Ncol) const;

    ErrorType       MultiplyJA(double* A, int Ncol) const;
    ErrorType       MultiplyAJ(double* A, int Nrow) const;

    ErrorType       PseudoInverse(double* AmatInv) const;
    double          PseudoInverseElem(int i1, int i2) const;

    ErrorType       ComputeJVec(double* ResultVec, const double* Vec) const;
    double*         Solve(const double* b) const;
    ErrorType       Solve(double* x, const double* b) const;

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

    double*         Wmat;  // The input matrix is decomposed as: A=(U) Eigen UT, where U is orthonormal
                           // and Eigen is diagonal. Wmat is either U*sqrt(Eigen), or U*sqrt(Eigen)-1
                           // In case A is indefinite, the decomposition is
                           // A = U1*EigenPos*(U1)^T - U2*EigenNeg*(U2)^T. In this case the array Eigen 
                           // contains first the EigenPos values, followed by the EigenNeg values. Wmat 
                           // contains (U1*Sqrt(EigenPos) , U2*Sqrt(EigneNeg)). The number of negative
                           // eigenvalues is stored in Nneg, and is equal to the number of columns in U2.    

private:
    static UString    Properties;
    ErrorType         error;      // General error flag
    JacMatType        MType;      // Type of the matrix, determines whether simplifications are possible
    double            Wconst;     // Constant used in case of Mtype==U_DIAGCONST
    int               N;          // The dimension of the matrix to be decomposed
    double*           Matrix;     // A copy of the input matrix (NOT inverted, even if Invert==true)
    double*           Eigen;      // array with eigenvalues in decreasing order
    int*              EigInd;     // Index array, used for sorting eigen values, in case of U_DIAGONAL
    bool              Invert;     // Determines the contents of Wmat
    int               Neig;       // The number of eigenvalues taken into account in matrix products
    int               Nneg;       // The number of negative eigenvalues, in case of non definite matrices
    int               NnegEig;    // The number of negative eigenvalues taken into account in matrix products
    double            EigOffset2; // (Small) Non-negative number added to the eigenvalues, to smooth matrix operations

    ErrorType         Decompose(const double *A, bool Inv, bool AllowNegEig = false);    
    ErrorType         indexx(int N, const double* arr, int* index);
};
#endif // _JACOBI_INCLUDED
