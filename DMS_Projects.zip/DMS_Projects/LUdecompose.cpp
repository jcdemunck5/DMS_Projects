/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     LU-decomposiation and back-substitution according to Numerical Recipes.   */
/*     The array to be decomposed is stored as a private variable inside the     */
/*     object, and deleted by its destructor. The array can be filled by calling */
/*     GetLUArray() after constructing the object.                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    01-08-98   creation
  Jdm    12-06-99   Allow "paralell" components in the back-substitution lubksb_d()
  Jdm    26-08-99   Add lubksbTrans_d(), the transposed version of lubksb_d()
  Jdm    27-08-99   Made a c++ object of it
  JdM    01-09-99   BUG fix in lubksbTrans_d(), reordering of output vector
  JdM    13-10-00   Major update. The decomposed array is now deleted by the object
                    and filled outside it.
  JdM    01-11-00   Update interface to ludcmp(); initialize matrix in constructor
  JdM    22-11-00   Launch an error message when matrix is not decomposed yet
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    21-03-05   Added SetAllMembersDefault(), DeleteAllMembers(), operator=(),
                    default constructor and copy constructor
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    06-03-13   Added matrix constructor
  JdM    08-01-13   ludcmp(). Compute det instead of sign(det).
  JdM    13-06-15   Added WriteBinary() and FILE* constructor to UBemField
  JdM    20-08-15   lubksbTrans(). Added ncomp parameter
  JdM    29-08-15   Added IsEmpty()
  JdM    15-03-16   Renamed ludcmp() as ComputeLUDecomposition(). 
                    Renamed lubksb() and lubksbTrans() as ComputeAxIsB() and ComputeATxIsB()
                    Added LUBackSubstitute() which uses UMatrix as argument). 
  JdM    16-03-16   Added UMatrix constructor. 
  JdM    17-03-16   ComputeAxIsB() and ComputeATxIsB(). Define all variables local. BUG FIX (?) set ii=-1 in each k-loop
  JdM    16-04-16   ComputeAxIsB(). Tested for multiple collumns (Transpose==false). Allow any UMatrix type (apply ForceGeneralType())
  JdM    30-01-17   Renamed GetMatrix() as GetLUArray(), Added GetMatrix()
  JdM    31-01-17   BUG FIX ??? ComputeLUDecomposition(). replaced N by N-1. It does not matter, and therefore skip test altogether
  JdM    02-02-17   BUG FIX. ComputeATxIsB(). Swapping order of final solution should be reversed. Therefore old code was sometimes correct, sometimes swapped.
*/

#include <string.h>
#include <math.h>
#include "LUdecompose.h"
#include "Matrix.h"

#define TINY 1.0e-20;
const char*  ULUdecompose::HEADERBEGIN = "LUdecompose1.0";
const char*  ULUdecompose::HEADEREND   = "LUdecomposeEnd";

void ULUdecompose::SetAllMembersDefault(void)
{
    error      = U_OK;
    DecompDone = false;
    N          = 0;
    index      = NULL;
    LUmat      = NULL;
}
void ULUdecompose::DeleteAllMembers(ErrorType E)
{
    delete[] index;
    delete[] LUmat;
    SetAllMembersDefault();
    error = E;
}

ULUdecompose::ULUdecompose()
{
    SetAllMembersDefault();
}
ULUdecompose::ULUdecompose(int n)
{
    SetAllMembersDefault();
    if(n<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Invalid argment: n = %d \n", n);
        return;
    }
    N          = n;
    index      = new int[N];
    LUmat      = new double[N*N];
    if(index==NULL || LUmat==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Memory allocation,  N = %d  .\n",N);
        return;
    }
    for(int k12=0; k12<N*N; k12++) LUmat[k12] = 0;
    for(int k=0  ; k<N;     k++  ) LUmat[k*(N+1)] = index[k] = 1;
}
ULUdecompose::ULUdecompose(int n, const double* matrix)
{
    SetAllMembersDefault();
    if(n<=0 || matrix==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Invalid (NULL) argment(s),  n = %d \n", n);
        return;
    }
    N          = n;
    index      = new int[N];
    LUmat      = new double[N*N];
    if(index==NULL || LUmat==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Memory allocation,  N = %d  .\n",N);
        return;
    }
    for(int nn=0; nn<N*N; nn++) LUmat[nn] = matrix[nn];

    if(ComputeLUDecomposition(NULL)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Performing LU-decomposition.\n");
        return;
    }
}
ULUdecompose::ULUdecompose(const UMatrix& M)
{
    SetAllMembersDefault();
    if(&M==NULL || M.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). NULL or erroneous UMatrix argument.\n");
        return;
    }
    int n = M.GetNrow();
    if(M.GetNcol()!=n || M.GetNelem()!=n*n)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). UMatrix argument of wrong type.\n");
        return;
    }

    const double* matrix = M.GetMatrixArray();
    if(n<=0 || matrix==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Matrix has NULL data or,  n = %d \n", n);
        return;
    }
    N          = n;
    index      = new int[N];
    LUmat      = new double[N*N];
    if(index==NULL || LUmat==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Memory allocation,  n = %d  .\n",N);
        return;
    }
    for(int nn=0; nn<N*N; nn++) LUmat[nn] = matrix[nn];

    if(ComputeLUDecomposition(NULL)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Performing LU-decomposition of matrix.\n");
        return;
    }
}

ULUdecompose::ULUdecompose(const ULUdecompose &L)
{
    SetAllMembersDefault();
    *this = L;
}

ULUdecompose::ULUdecompose(FILE* fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Invalid NULL pointer. \n");
        return;
    }
    unsigned int ioffOld = ftell(fpIn);
    if(HasIDAtOffset(fpIn, HEADERBEGIN, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Wrong header (should be %s). \n", HEADERBEGIN);
        return;
    }
    DecompDone     =::ReadBinaryBool(DefaultIntelData, fpIn);
    N              =::ReadBinaryInt (DefaultIntelData, fpIn);

    if(N>0)
    {
        index = new int[N];
        LUmat = new double[N*N];
        if(index==NULL || LUmat==NULL)
        {
            CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Memory allocation, N=%d. \n", N);
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            return;
        }
        if(::ReadBinaryIntArray   (index, N  , DefaultIntelData, fpIn)!=U_OK ||
           ::ReadBinaryDoubleArray(LUmat, N*N, DefaultIntelData, fpIn)!=U_OK)
        {
            CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Reading indices or decomposed matrix. \n");
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioffOld, SEEK_SET);
            return;
        }
    }
    if(HasIDAtOffset(fpIn, HEADEREND, -1)==false)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioffOld, SEEK_SET);
        CI.AddToLog("ERROR: ULUdecompose::ULUdecompose(). Wrong END header (should be %s). \n", HEADEREND);
        return;
    }
}
ErrorType ULUdecompose::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: ULUdecompose::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(N<0 || (N==0 && (index||LUmat)) || (N>0 && (!index||!LUmat)))
    {
        CI.AddToLog("ERROR: ULUdecompose::WriteBinary(). Arrays inconsistent with N (=%d). \n", N);
        return U_ERROR;
    }

    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

    ::WriteBinary(DecompDone        , DefaultIntelData, fpOut);
    ::WriteBinary(N                 , DefaultIntelData, fpOut);
    if(N>0) ::WriteBinary(index, N  , DefaultIntelData, fpOut);
    if(N>0) ::WriteBinary(LUmat, N*N, DefaultIntelData, fpOut);

    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

ULUdecompose::~ULUdecompose()
{
    DeleteAllMembers(U_OK);
}

ULUdecompose& ULUdecompose::operator=(const ULUdecompose &L)
{
    if(this==NULL || &L==NULL)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: ULUdecompose::operator=(). this==NULL or &L==NULL .\n");
        static ULUdecompose Def; Def.error = U_ERROR;
        return Def;
    }
    if(this==&L) return *this;

    DeleteAllMembers(U_OK);
    error      = L.error;
    DecompDone = L.DecompDone;
    N          = L.N;
    if(L.index)
    {
        index = new int[N];
        if(index)
        {
            for(int k=0; k<N; k++) index[k] = L.index[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: ULUdecompose::operator=(). Memory allocation index, L.N = %d .\n", L.N);
            return *this;
        }
    }
    if(L.LUmat)
    {
        LUmat = new double[N*N];
        if(LUmat)
        {
            for(int k=0; k<N*N; k++) LUmat[k] = L.LUmat[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: ULUdecompose::operator=(). Memory allocation LUmat, L.N = %d .\n", L.N);
            return *this;
        }
    }
    return *this;
}

UMatrix ULUdecompose::GetMatrix(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: ULUdecompose::GetMatrix(). Object NULL or erroneous .\n");
        return UMatrix(U_ERROR);
    }
    if(N<0 || (LUmat==NULL && N!=0))
    {
        CI.AddToLog("ERROR: ULUdecompose::GetMatrix(). Object not properly set, N=%d .\n", N);
        return UMatrix(U_ERROR);
    }
    if(N==0 || LUmat==NULL) return UMatrix();

    UMatrix A(DNULL, N, N);
    if(A.GetError()!=U_OK || A.Data==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::GetMatrix(). Creating output matrix, N=%d .\n", N);
        return UMatrix(U_ERROR);
    }
    if(DecompDone==false)
    {
        for(int k=0; k<N*N; k++) A.Data[k] = LUmat[k];
        return A;
    }
    int* NewRow = new int[N];
    if(NewRow==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::GetMatrix(). Creating index array, N=%d .\n", N);
        return UMatrix(U_ERROR);
    }
    for(int i=0; i<N; i++) NewRow[i] = i;
    for(int i=0; i<N; i++)
    {
        if(index==NULL || index[i]==i) continue;
        int idum  = NewRow[i]; NewRow[i] = NewRow[index[i]]; NewRow[index[i]] = idum;
    }

    for(int i=0; i<N; i++)
    {
        int ip = NewRow[i];
        for(int j=0; j<N; j++)
        {
            int           kmax = (i<=j) ? MIN(i,j)     : (MIN(i,j)+1);
            double        sum  = (i<=j) ? LUmat[i*N+j] : 0.;
            const double* palf = LUmat+i*N;
            const double* pbet = LUmat+  j;
            
            for(int k=0; k<kmax  ; k++,palf++,pbet+=N) sum += *palf * *pbet;
            A.Data[ip*N+j] = sum;
        }
    }
    delete[] NewRow;
    return A;
}

ErrorType ULUdecompose::ComputeLUDecomposition(double *det) 
/*
   LU decomposition of a matrix a, adapted from Numerical Recipes, p46-47

   return 0 iff OK

*/
{
    int    i,imax,j,k;
    double big,dum,sum,temp;

    double* vv = new double[N];
    if(!vv) 
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeLUDecomposition(). Memory allocation. N=%d\n",N);
        return U_ERROR;
    }

    double SignDet = 1.;
    for(i=0;i<N;i++) 
    {
        big=0.0;
        for(j=0;j<N;j++) if((temp=fabs(LUmat[i*N+j])) > big) big=temp;

        if(big == 0.0)  //Singular matrix in routine ComputeLUDecomposition
        {
            delete[] vv; 
            CI.AddToLog("ERROR: ULUdecompose::ComputeLUDecomposition(). Matrix is singular. i=%d\n",i);
            return U_ERROR;
        }
        vv[i]=1.0/big;
    }
    
    for(j=0;j<N;j++) 
    {
        for(i=0;i<j;i++) 
        {
            sum      = LUmat[i*N+j];
            for(k=0;k<i;k++) sum -= LUmat[i*N+k]*LUmat[k*N+j];
            LUmat[i*N+j] = sum;
        }
        big=0.0;
        
        for(i=j;i<N;i++) 
        {
            sum      = LUmat[i*N+j];
            for(k=0;k<j;k++) sum -= LUmat[i*N+k]*LUmat[k*N+j];
            LUmat[i*N+j] = sum;
            if( (dum=vv[i]*fabs(sum)) >= big) 
            {
                big  = dum;
                imax = i; // imax>=j
            }
        }
        if(j != imax) 
        {
            for(k=0;k<N;k++)
            {
                dum             = LUmat[imax*N+k];
                LUmat[imax*N+k] = LUmat[j*N+k];
                LUmat[j*N+k]    = dum;
            }
            SignDet = -SignDet;
            vv[imax]=vv[j];
        }
        index[j]=imax;
        if(LUmat[j*N+j] == 0.0) LUmat[j*N+j]=TINY;

        dum = 1.0/LUmat[j*N+j];
        for(i=j+1;i<N;i++) LUmat[i*N+j] *= dum;
    }
    delete[] vv;

    if(det) 
    {
        *det = SignDet;
        for(int i=0; i<N; i++) *det *= LUmat[i*N+i];
    }

    DecompDone = true;

    return U_OK;
}

ErrorType ULUdecompose::ComputeAxIsB(UMatrix* Bmat, bool Transpose) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    
    if(Bmat==NULL || Bmat->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). Bmat argumen NULL or erroneous.\n");
        return U_ERROR;
    }
    if(N!=Bmat->GetNrow())
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). Bmat->Nrow (=%d) does not match N (=%d).\n",Bmat->Nrow, N);
        return U_ERROR;
    }
    if(Bmat->ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). Forcing Bmat to general type.\n");
        return U_ERROR;
    }
    
    if(Transpose) 
        return ComputeATxIsB(Bmat->Data, Bmat->Ncol);
    return ComputeAxIsB(Bmat->Data, Bmat->Ncol);
}

ErrorType ULUdecompose::ComputeAxIsB(double *b, int ncomp) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(b==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). NULL argument.\n");
        return U_ERROR;
    }
    if(ncomp<=0 || ncomp>N)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). Parameter out of range: ncomp=%d .\n", ncomp);
        return U_ERROR;
    }
    if(DecompDone==false)
        CI.AddToLog("ERROR: ULUdecompose::ComputeAxIsB(). Matrix not yet decomposed.\n");

    for(int k=0; k<ncomp; k++)
    {
        int ii=-1;
        for(int i=0;i<N;i++) 
        {
            int    ip     = index[i];
            double sum    = b[ncomp*ip+k];
            b[ncomp*ip+k] = b[ncomp*i +k];
            if(ii!=-1)
                for(int j=ii;j<i;j++) sum -= LUmat[i*N+j]*b[ncomp*j+k];
            else
                if(sum) ii=i;
            b[ncomp*i +k]  = sum;
        }

        for(int i=N-1;i>=0;i--) 
        {
            double sum  = b[ncomp*i +k];
            for(int j=i+1;j<N;j++) sum -= LUmat[i*N+j]*b[ncomp*j+k];

            b[ncomp*i +k] = sum/LUmat[i*N+i];
        }
    }
    return U_OK;
}

ErrorType ULUdecompose::ComputeATxIsB(double *b, int ncomp) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(b==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeATxIsB(). NULL argument.\n");
        return U_ERROR;
    }
    if(ncomp<=0 || ncomp>N)
    {
        CI.AddToLog("ERROR: ULUdecompose::ComputeATxIsB(). Parameter out of range: ncomp=%d .\n", ncomp);
        return U_ERROR;
    }
    if(DecompDone==false)
        CI.AddToLog("ERROR: ULUdecompose::ComputeATxIsB(). Matrix not yet decomposed.\n");

    for(int k=0; k<ncomp; k++)
    {
        int ii = -1;
        for(int i=0;i<N;i++) 
        {
            double sum = b[ncomp*i+k];
            if(ii!=-1)
                for(int j=ii;j<i;j++) sum -= LUmat[j*N+i]*b[ncomp*j+k];
            else 
                if(sum) ii=i;
            b[ncomp*i+k]  = sum/LUmat[i*N+i];
        }
        for(int i=N-1;i>=0;i--) 
        {
            double sum  = b[i*ncomp+k];
            for(int j=i+1;j<N;j++) sum -= LUmat[j*N+i]*b[j*ncomp+k];

            b[i*ncomp+k] = sum;
        }
    }

/* Tested re-ordering of matrix elements on 02-02-17, (swapping order should be reverserd) */
    for(int i=N-1; i>=0; i--)
    {
        for(int k=0; k<ncomp; k++)
        {
            double sum          = b[i*ncomp+k];
            b[i*ncomp+k]        = b[index[i]*ncomp+k];
            b[index[i]*ncomp+k] = sum;
        }
    }
    return U_OK;
}

ErrorType ULUdecompose::mprove(double *a, double* b, double* x) const
{
    if(a==NULL || b==NULL || x==NULL)
    {
        CI.AddToLog("ERROR: ULUdecompose::mprove(). NULL argument.\n");
        return U_ERROR;
    }
    if(DecompDone==false)
        CI.AddToLog("ERROR: ULUdecompose::mprove(). Matrix not yet decomposed.\n");

    int    j,i;
    double sdp;

    double *r = new double[N];
    if(!r) 
    {
        CI.AddToLog("ERROR: ULUdecompose::mprove(). Memory allocation.\n");
        return U_ERROR;
    }
    for(i=0;i<N;i++) 
    {
        sdp = -b[i];
        for(j=0;j<N;j++) sdp += LUmat[i*N+j]*x[j];
        r[i]=sdp; 
    }
    ComputeAxIsB(r,1);
    for(i=0;i<N;i++) x[i] -= r[i];
    
    delete[] r;
    return U_OK;
}

