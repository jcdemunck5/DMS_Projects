#ifndef _LUDECOMPOSE_INCLUDED
#define _LUDECOMPOSE_INCLUDED

#include "BasicInclude.h"

class UMatrix;
class DLL_IO ULUdecompose
{
public:
    ULUdecompose();
    ULUdecompose(FILE* fpIn);
    ULUdecompose(int n);
    ULUdecompose(int n, const double* matrix);
    ULUdecompose(const UMatrix& M);
    ULUdecompose(const ULUdecompose &L);    
    virtual ~ULUdecompose();
    ULUdecompose& operator=(const ULUdecompose &L);
    ErrorType              GetError() const {if(this) return error; return U_ERROR;}

    double* const          GetLUArray(void)  {if(this) {DecompDone = false; return LUmat;} return NULL;}
    UMatrix                GetMatrix(void) const;
    bool                   IsEmpty(void) const {if(this) return (N<=0); return true;}
    int                    GetN(void) const {if(this) return N; return 0;}

    ErrorType              ComputeLUDecomposition(double *det=NULL);
    ErrorType              ComputeAxIsB(UMatrix* Bmat, bool Transpose) const;
    ErrorType              ComputeAxIsB(double *b, int ncomp=1) const;
    ErrorType              ComputeATxIsB(double *b, int ncomp=1) const;

    ErrorType              WriteBinary(FILE* fpOut) const;
protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

    ErrorType              mprove(double *a, double* b, double* x) const;
private:
    static const char*     HEADERBEGIN;
    static const char*     HEADEREND;
    ErrorType              error;      // General error flag
    bool                   DecompDone; // TRUE iff ludcmp() is run
    int                    N;          // The dimension of the matrix to be decomposed
    int*                   index;      // A list of indices, used in pivoting
    double*                LUmat;      // A pointer to the matrix to be decomposed.
};
#endif // _LUDECOMPOSE_INCLUDED
