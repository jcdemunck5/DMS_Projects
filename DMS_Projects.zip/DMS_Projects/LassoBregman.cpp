/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for minimizing the following functional using                      */
/*     split Bregman iterations:                                                 */
/*                                                                               */
/*     H(u) = |PHI(u)|   +  Mu (z-u)T * M * (z-u)                                */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    05-06-16   creation
*/
 

#include "LassoBregman.h"
#include "SortSemiSort.h"

/* Inititalize static const parameters. */
UString ULassoBregman::Properties = UString();

void ULassoBregman::SetAllMembersDefault(void)
{
    Properties   = UString();
    error        = U_OK;

    Mu           = 1.;
    Ndim         = 0;
    Ncomp        = 0;
    Lamda        = 1.;

    MaxBregIter  = 2000;
    Tolerance    = 1.e-6;
}
void ULassoBregman::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
ULassoBregman::ULassoBregman()
{
    SetAllMembersDefault();
}

ULassoBregman::ULassoBregman(const ULassoBregman& LB)
{
    SetAllMembersDefault();
    *this = LB;
}

ULassoBregman::ULassoBregman(int N, double mu, double lam, double Tol, int MaxIter)
{
    SetAllMembersDefault();
    if(N<=0)
    {
        CI.AddToLog("ERROR: ULassoBregman::ULassoBregman(). Invalid argument, N=%d\n", N);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(mu<=0. || lam<=0.)
    {
        CI.AddToLog("ERROR: ULassoBregman::ULassoBregman(). Invalid argument(s): mu = %f, lam = %f .\n", mu, lam);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(MaxIter<0 || Tol<=0.)
    {
        CI.AddToLog("ERROR: ULassoBregman::ULassoBregman(). Invalid stopping parameter(s): MaxIter = %d, Tol = %f .\n", MaxIter, Tol);
        DeleteAllMembers(U_ERROR);
        return;
    }

    Ndim        = N;
    Mu          = mu;
    Lamda       = lam;

    MaxBregIter = MaxIter;
    Tolerance   = Tol;
}

ULassoBregman::~ULassoBregman()
{
    DeleteAllMembers(U_OK);
}
ULassoBregman& ULassoBregman::operator=(const ULassoBregman &LB)
{
    if(&LB==NULL)
    {
        CI.AddToLog("ERROR: ULassoBregman::operator=(). Argument has NULL address. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&LB) return *this;

    DeleteAllMembers(U_OK);

    error       = LB.error;
    Mu          = LB.Mu;
    Ndim        = LB.Ndim;
    Ncomp       = LB.Ncomp;
    Lamda       = LB.Lamda;
    MaxBregIter = LB.MaxBregIter;
    Tolerance   = LB.Tolerance;

    return *this;
}
ErrorType ULassoBregman::SetMaxIter(int MaxIter)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MaxIter<=0)                return U_ERROR;
    MaxBregIter = MaxIter;
    return U_OK;
}
const UString& ULassoBregman::GetProperties(UString Comment) const
{
    return Properties;
}

double ULassoBregman::GetCost(UMatrix& Yvec) const
{
    if(this ==NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetCost(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(&Yvec==NULL || Yvec.GetError() != U_OK)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetCost(). Argument NULL or erroneous.\n");
        return 0.;
    }
    if(Yvec.GetNrow()!=Ndim || Yvec.GetNcol()!=Ncomp)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetCost(). Argument not properly dimensioned.\n");
        return 0.;
    }
    CI.AddToLog("ERROR: ULassoBregman::GetCost(). Virtual function not implemented in derived class.\n");
    return 0.;
}
double ULassoBregman::GetPseudoCost(UMatrix& Yvec, UMatrix& Dvec, UMatrix& Bvec)
{
    if(this ==NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetPseudoCost(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(&Yvec==NULL || Yvec.GetError() != U_OK || &Dvec==NULL || Dvec.GetError() != U_OK || &Bvec==NULL || Bvec.GetError() != U_OK)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetPseudoCost(). Argument NULL or erroneous.\n");
        return 0.;
    }
    if(Yvec.GetNrow()!=Ndim || Yvec.GetNcol()!=Ncomp || Dvec.GetNrow()!=Ndim || Dvec.GetNcol()!=Ncomp || Bvec.GetNrow()!=Ndim || Bvec.GetNcol()!=Ncomp)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetPseudoCost(). Argument not properly dimensioned.\n");
        return 0.;
    }
    CI.AddToLog("ERROR: ULassoBregman::GetPseudoCost(). Virtual function not implemented in derived class.\n");
    return 0.;
}

UMatrix ULassoBregman::GetMinimum(void)
{
    if(this ==NULL || error != U_OK) return UMatrix(U_ERROR);

    UMatrix Xold(DNULL, Ndim, Ncomp);
    UMatrix Xmin(DNULL, Ndim, Ncomp);
    UMatrix Dk = GetPHIVec(Xmin);  Dk.SetData(0.);
    UMatrix Bk = GetPHIVec(Xmin);  Bk.SetData(0.);

    int        NZ     = 0;
    ErrorType  E      = U_OK;
    int        itbreg = 0;
    for(; itbreg<MaxBregIter; itbreg++)
    {
        Xmin             = SolveXVec(Dk-Bk);
        UMatrix PHIXmin  = GetPHIVec(Xmin);
        if(E==U_OK)    E =    Xmin.GetError();
        if(E==U_OK)    E = PHIXmin.GetError();
        if(E!=U_OK || (GetFrobNormDifference(Xmin, Xold)<Tolerance*Xmin.GetFrobNorm() && itbreg>4)) break;
        Xold  = Xmin;
        Dk    = PHIXmin+Bk;
        Dk.ShrinkRows(2./Lamda, &NZ);
        Bk   += PHIXmin - Dk;
////////
        double C1 = GetCost(Xmin);
        CI.AddToLog("iter = %d \tNZ = %d \tCOST1 = %f \n", itbreg, NZ, C1);
////////
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: ULassoBregman::GetMinimum(). Solving linear system in iteration %d.\n", itbreg);
        return UMatrix(U_ERROR);
    }
    return Xmin;
}

#include "MatrixSparse.h"

void UFitShapeLasso::SetAllMembersDefault(void)
{
    error = U_OK;
}
void UFitShapeLasso::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UFitShapeLasso::UFitShapeLasso(int NPoints, const int* IBound, int NBound, const UMatrixSparse& Lapla, double mu) :
    ULassoBregman(NPoints, mu, 1./(mu*mu))  // Lamda =  1./(mu*mu)
{
    SetAllMembersDefault();
    if(ULassoBregman::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::UFitShapeLasso(). Setting base class.\n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(IBound==NULL || Lapla.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::UFitShapeLasso(). Erroneous or invalid NULL argument(s).\n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(NPoints<NBound || NBound<=1)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::UFitShapeLasso(). Invalid parameter(s). NPoints=%d, NBound=%d \n", NPoints, NBound);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(NPoints!=Lapla.GetNcol() || NPoints!=Lapla.GetNrow())
    {
        CI.AddToLog("ERROR: UFitShapeLasso::UFitShapeLasso(). NPoints=%d does not fit matrix size, Nrow=%d, Ncol=%d \n", NPoints, Lapla.GetNrow(), Lapla.GetNcol());
        DeleteAllMembers(U_ERROR);
        return;
    }
    Ncomp         = 3;
    MSlamMu2      = Lapla;
    if(MSlamMu2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::UFitShapeLasso(). Copying sparse matrix. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }

    DiagPHI   = UMatrix(DNULL, NPoints);
    for(int n=0; n<NPoints;  n++)  DiagPHI.SetElement(n, n, 0.);
    for(int k=0; k<NBound;  k++) 
    {
        int n = IBound[k];
        MSlamMu2.AddElement(n, n, Mu*Mu*Lamda);
        DiagPHI.SetElement(n, n, 1.);
    }
}
UFitShapeLasso::~UFitShapeLasso()
{
    DeleteAllMembers(U_OK);
}
double UFitShapeLasso::GetCost(UMatrix& Yvec) const
{
    if(this ==NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetCost(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(MSlamMu2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetCost(). Sparse matrix not properly set.\n");
        return 0.;
    }
    if(&Yvec==NULL || Yvec.GetError() != U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetCost(). Argument NULL or erroneous.\n");
        return 0.;
    }
    if(Yvec.GetNrow()!=Ndim || Yvec.GetNcol()!=3)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetCost(). Argument not properly dimensioned.\n");
        return 0.;
    }

    UMatrix Xvec = Yvec+Bxyz;
    double  Cost = GetPHIVec(Yvec).GetMixedRowNorm();
    for(int ic=0; ic<3;ic++)
    {
        UMatrix Col = Xvec.GetCollumn(ic);
        Cost       += MSlamMu2.GetVTMV(Col) - DiagPHI.GetVTMV(Col)*Mu*Mu*Lamda ;
    }
    return Cost;
}
double UFitShapeLasso::GetPseudoCost(UMatrix& Yvec, UMatrix& Dvec, UMatrix& Bvec)
{
    if(this ==NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetPseudoCost(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(&Yvec==NULL || Yvec.GetError() != U_OK || &Dvec==NULL || Dvec.GetError() != U_OK || &Bvec==NULL || Bvec.GetError() != U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetPseudoCost(). Argument NULL or erroneous.\n");
        return 0.;
    }
    if(Yvec.GetNrow()!=Ndim || Yvec.GetNcol()!=3 || Dvec.GetNrow()!=Ndim || Dvec.GetNcol()!=3 || Bvec.GetNrow()!=Ndim || Bvec.GetNcol()!=3)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::GetPseudoCost(). Argument not properly dimensioned.\n");
        return 0.;
    }

    UMatrix Xvec = Yvec+Bxyz;
    double  Cost = Dvec.GetMixedRowNorm();
    for(int ic=0; ic<3;ic++)
    {
        UMatrix Col = Xvec.GetCollumn(ic);
        Cost       += MSlamMu2.GetVTMV(Col) - DiagPHI.GetVTMV(Col)*Mu*Mu*Lamda ;
    }
    Cost += Lamda*(GetPHIVec(Yvec)-Dvec+Bvec).GetFrobNorm2();
    return Cost;
}
ErrorType UFitShapeLasso::MinimizeLasso(double* Xv, double* Yv, double* Zv)
{
    if(this==NULL || error              !=U_OK) return U_ERROR;
    if(              MSlamMu2.GetError()!=U_OK) return U_ERROR;
    if(Xv  ==NULL                             ) return U_ERROR;
    if(Yv  ==NULL                             ) return U_ERROR;
    if(Zv  ==NULL                             ) return U_ERROR;

    int NPoints = MSlamMu2.GetNrow();
    UMatrix XYZ(Xv, NPoints, 1);
    XYZ.MergeCols(NULL, Yv, Zv, NPoints);

    Bxyz     = DiagPHI*XYZ;
    MSBxyz   = MSlamMu2* Bxyz -DiagPHI*(Bxyz*(Lamda*Mu*Mu));
    if(Bxyz.GetError()!=U_OK || MSBxyz.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::MinimizeLasso(). Memory allocation, NPoints = %d .\n", NPoints);
        return U_ERROR;
    }

    UMatrix Yxyz = ULassoBregman::GetMinimum();
    if(Yxyz.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitShapeLasso::MinimizeLasso(). Computing Lasso .\n");
        return U_ERROR;
    }
    for(int i=0, i3=0; i<NPoints; i++, i3+=3) 
    {
        Xv[i] = Yxyz[i3  ]+Bxyz[i3  ];
        Yv[i] = Yxyz[i3+1]+Bxyz[i3+1];
        Zv[i] = Yxyz[i3+2]+Bxyz[i3+2];
    }
    return U_OK;
}
UMatrix UFitShapeLasso::SolveXVec(const UMatrix& DBvec)
{
    if(this==NULL             || error               !=U_OK) return UMatrix(U_ERROR);
    if(                          MSlamMu2.GetError() !=U_OK) return UMatrix(U_ERROR);
    if(DBvec.GetError()!=U_OK || DBvec.GetNcol()     !=3   ) return UMatrix(U_ERROR);

    UMatrix RHS    = (DiagPHI*DBvec)*(Lamda*Mu)  - MSBxyz;
    return MSlamMu2.GetAxIsB(RHS);
}
UMatrix UFitShapeLasso::GetPHIVec(const UMatrix& Yvec) const
{
    if(this==NULL             || error               !=U_OK) return UMatrix(U_ERROR);
    if(                          MSlamMu2.GetError() !=U_OK) return UMatrix(U_ERROR);
    if(Yvec.GetError()!=U_OK  || Yvec.GetNcol()      !=3   ) return UMatrix(U_ERROR);

    return DiagPHI*(Mu*Yvec);
}
