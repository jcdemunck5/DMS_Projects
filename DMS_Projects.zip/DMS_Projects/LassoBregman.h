#ifndef _LASSOBREGMAN_INCLUDED
#define _LASSOBREGMAN_INCLUDED

#include"PreConBiConGrad.h"
#include"MatrixSparse.h"

class DLL_IO ULassoBregman
{
public:
    ULassoBregman();
    ULassoBregman(const ULassoBregman& LB);
    ULassoBregman(int N, double mu, double lam, double Tol=1.e-5, int MaxIter=200);
   
    virtual ~ULassoBregman();
    ULassoBregman& operator=(const ULassoBregman &LB);

    const UString&      GetProperties(UString Comment) const;
    ErrorType           GetError() const            {if(this) return error; return U_ERROR;}

    UMatrix             GetMinimum(void);   // Minimize funxtional F(x) = Mu |PHI(x)|  +  H(x), where H(x) is quatratic in x
    ErrorType           SetMaxIter(int Niter);

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

    virtual UMatrix     SolveXVec(const UMatrix& DBvec) = 0;
    virtual UMatrix     GetPHIVec(const UMatrix& Xvec) const = 0;
    virtual double      GetCost(UMatrix& Yvec) const;
    virtual double      GetPseudoCost(UMatrix& Yvec, UMatrix& Dvec, UMatrix& Bvec);

    double              Mu;                 // Weight on L1 term
    double              Lamda;              // penalty to set constraint d = PHI(x)
    int                 Ndim;               // Matrix dimensions
    int                 Ncomp;              // Number of vector components

private:    
    static UString      Properties;
    ErrorType           error;              // General error flag

    int                 MaxBregIter;
    double              Tolerance;
};

class UFitShapeLasso : public ULassoBregman
{
public:
    UFitShapeLasso(int NPoints, const int* IBound, int NBound, const UMatrixSparse& Lapla, double mu);
    ~UFitShapeLasso();
    ErrorType           GetError() const {if(this) return error; return U_ERROR;}

    ErrorType           MinimizeLasso(double* Xvec, double* Yvec, double* Zvec);
protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

    double              GetCost(UMatrix& Yvec) const;
    double              GetPseudoCost(UMatrix& Yvec, UMatrix& Dvec, UMatrix& Bvec);
private:
    ErrorType           error;
    UMatrixSparse       MSlamMu2;
    UMatrix             Bxyz;       // Boundary points, interleaved with zeroes
    UMatrix             MSBxyz;     // MS * Bxyz
    UMatrix             DiagPHI;    // Diagonal matrix with 1. at fixed points, and zero elsewhere

    virtual UMatrix     SolveXVec(const UMatrix& DBvec);
    virtual UMatrix     GetPHIVec(const UMatrix& Yvec) const;
};

#endif// _LASSOBREGMAN_INCLUDED
