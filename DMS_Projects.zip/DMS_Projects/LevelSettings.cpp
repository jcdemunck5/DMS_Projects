/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Module for manipulating Level & Window settings for ULevelSettings.       */
/*                                                                               */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history
  
  Who    When       What
  JdM    17-07-11   creation
  JdM    13-08-11   Added Max() and operator==()
  JdM    11-01-12   Modifications in default settings in UScan* constructor
  JdM    10-05-12   Added GetScaleType() GetProperties() and UString& constructor
  JdM    23-02-13   Completely updated AutoScale(). It sets all range parameters, based on given data min and max
                    Bug Fix. SetScaleType(). In case of U_SCALE_LOG do not force minima at 0.
  JdM    08-03-13   Bug Fix. AutoScale(). Maximum integer is 1<<30
  JdM    28-06-13   Renamed UpdateRangeActual() -> SetRangeActual() and UpdateActual() -> SetActual(...) and added parameter.
  JdM    26-09-13   BUG fixes: SetPalette(). ReverPal -argument not used
                             : AutoScale(). Scale not reversed when max<min (Dum not used)
  JdM    14-01-14   Bug Fix: ULevelSettings(const UScan* Scan, int icomp). Setting ImaxActual
  JdM    14-01-14   ULevelSettings::ULevelSettings(const UScan*,). Set several default pallettes equal to U_PALETTE_HOTCOLD
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    14-05-15   Added ConvertToByteRange()
 */

#include <math.h>
#include <string.h> 

#include "LevelSettings.h"
#include "Scan.h"

/* Inititalize static (const) parameters. */
UString     ULevelSettings::Properties  = UString();
const char* ULevelSettings::LevSetBegin = "LEVELSETTINGS";
const char* ULevelSettings::LevSetEnd   = "LEVELSETTINGS_END";

ScaleType GetScaleType(int itype)
{
    switch(itype)
    {
    case U_SCALE_LIN: return U_SCALE_LIN; 
    case U_SCALE_LOG: return U_SCALE_LOG; 
    case U_SCALE_SYM: return U_SCALE_SYM; 
    case U_SCALE_ASY: return U_SCALE_ASY; 
    }
    CI.AddToLog("ERROR: GetScaleType(). invalid index (itype=%d)  .\n", itype);
    return U_SCALE_LIN;
}

void ULevelSettings::SetAllMembersDefault(void)
{
    error           = U_OK;
    DoubleScale     = false;

    DminPhys        = 0.  ;
    DmaxPhys        = 100.;
    DminRange       = 0.  ;
    DmaxRange       = 100.;     
    DminActual      = 0.  ;
    DmaxActual      = 100.;

    IminPhys        = 0  ;
    ImaxPhys        = 255;
    IminRange       = 0  ;
    ImaxRange       = 255;
    IminActual      = 0  ;
    ImaxActual      = 255;
    
    ST              = U_SCALE_LIN;
    PT              = U_PALETTE_GREY;
    ReversePalette  = false;
    MaxAsBackground = false;
}
void ULevelSettings::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

ULevelSettings::ULevelSettings()
{
    SetAllMembersDefault();
}
ULevelSettings::ULevelSettings(const ULevelSettings& Lev)
{
    SetAllMembersDefault();
    *this = Lev;
}
ULevelSettings::ULevelSettings(const UString& Prop, UString Comment)
{
    SetAllMembersDefault();

    if(&Prop==NULL || Prop.IsNULL()==true || Prop.IsEmpty()==true)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Empty property string. \n");
        return;
    }
    if(SetLevelSettings(Prop, Comment)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Setting properties. \n");
        return;
    }
}

ULevelSettings::ULevelSettings(double DMinPhys, double DMaxPhys, double DMinRange, double DMaxRange, double DMinActual, double DMaxActual, ScaleType Scale, PaletteType Palette, bool ReversePal, bool MaxB)
{
    SetAllMembersDefault();
    if(DMinPhys>=DMaxPhys)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid physical range (%f-%f) .\n", DMinPhys, DMaxPhys);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(DMinRange>=DMaxRange)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid range (%f-%f) .\n", DMinRange, DMaxRange);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(DMinActual>=DMaxActual)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid actual range (%f-%f) .\n", DMinActual, DMaxActual);
        DeleteAllMembers(U_ERROR);
        return;
    }
    
    DoubleScale    = true;

    DminPhys       = MIN(MIN(DMinPhys, DMinRange), DMinActual);
    DmaxPhys       = MAX(MAX(DMaxPhys, DMaxRange), DMaxActual);
    DminRange      = MIN(              DMinRange , DMinActual);
    DmaxRange      = MAX(              DMaxRange , DMaxActual);
    DminActual     = DMinActual;
    DmaxActual     = DMaxActual;
    
    if(DminPhys>0)      DminPhys = DownScalePosValue(DminPhys);
    else if(DminPhys<0) DminPhys = -UpScalePosValue(-DminPhys);

    if(DmaxPhys>0)      DmaxPhys =  UpScalePosValue(DmaxPhys);
    else if(DmaxPhys<0) DmaxPhys = -DownScalePosValue(-DmaxPhys);

    ST              = Scale;
    PT              = Palette;
    ReversePalette  = ReversePal;
    MaxAsBackground = MaxB;
}
ULevelSettings::ULevelSettings(int IMinPhys, int IMaxPhys, int IMinRange, int IMaxRange, int IMinActual, int IMaxActual, ScaleType Scale, PaletteType Palette, bool ReversePal, bool MaxB)
{
    SetAllMembersDefault();

    if(IMinPhys>=IMaxPhys)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid physical range (%d-%d) .\n", IMinPhys, IMaxPhys);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(IMinRange>=IMaxRange)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid range (%d-%d) .\n", IMinRange, IMaxRange);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(IMinActual>=IMaxActual)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid actual range (%d-%d) .\n", IMinActual, IMaxActual);
        DeleteAllMembers(U_ERROR);
        return;
    }
    
    DoubleScale    = false;

    IminPhys       = MIN(MIN(IMinPhys, IMinRange), IMinActual);
    ImaxPhys       = MAX(MAX(IMaxPhys, IMaxRange), IMaxActual);
    IminRange      = MIN(              IMinRange , IMinActual);
    ImaxRange      = MAX(              IMaxRange , IMaxActual);
    IminActual     = IMinActual;
    ImaxActual     = IMaxActual;
    
    if(IminPhys>0)      IminPhys = int(DownScalePosValue(IminPhys));
    else if(IminPhys<0) IminPhys = -int(UpScalePosValue(-IminPhys));

    if(ImaxPhys>0)      ImaxPhys =  int(UpScalePosValue(ImaxPhys));
    else if(ImaxPhys<0) ImaxPhys = -int(DownScalePosValue(-ImaxPhys));

    ST              = Scale;
    PT              = Palette;
    ReversePalette  = ReversePal;
    MaxAsBackground = MaxB;
}
ULevelSettings::ULevelSettings(const UScan* Scan, int icomp)
{
    SetAllMembersDefault();

    if(Scan==NULL || Scan->GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). NULL or erroneous UScan argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(icomp>=Scan->GetVeclen())
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). icomp argument out of range (icomp=%d).\n", icomp);
        DeleteAllMembers(U_ERROR);
        return;
    }

    double DMinDat =   0;
    double DMaxDat = 100;
    int    IMinDat =   0;
    int    IMaxDat = 255;
    if(Scan->GetDType()==UField::U_FLOAT || 
       Scan->GetDType()==UField::U_DOUBLE)
    {
        DoubleScale = true;
        if(Scan->GetMinMaxData(&DMinDat, &DMaxDat, icomp)!=U_OK)
        {
            CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Get minimum and maximum data values. \n");
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    else if(Scan->GetDType()==UField::U_BYTE  || 
            Scan->GetDType()==UField::U_SHORT || 
            Scan->GetDType()==UField::U_INTEGER)
    {
        DoubleScale = false;
        if(Scan->GetDType()==UField::U_BYTE && Scan->GetVeclen()==3)
        {
            AutoScale(0., 100., 0, 255);
            PT = U_PALETTE_GREY;
            return;
        }
        if(Scan->GetMinMaxData(&IMinDat, &IMaxDat, icomp)!=U_OK)
        {
            CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Get minimum and maximum data values. \n");
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    else
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Scan is of invalid data typ.\n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    double F = MAX(fabs(DMinDat),fabs(DMaxDat));
    int    I = MAX( abs(IMinDat), abs(IMaxDat));

    if(Scan->GetComponentsDataType()==U_COMPDAT_AVERSTAN && Scan->GetVeclen()==2)
    {
        if(DoubleScale)
        {
            DmaxPhys   =  DmaxRange  =  UpScalePosValue(1.001*F);
            DminPhys   =  DminRange  = -DmaxRange;     
            DminActual = -F;     
            DmaxActual =  F;
        }
        else
        {
            IminPhys   = ImaxRange  =  int(UpScalePosValue(1.001*I));
            ImaxPhys   = IminRange  = -ImaxRange;     
            IminActual = -I;     
            ImaxActual =  I;
        }
        ST       = U_SCALE_SYM;
        PT       = U_PALETTE_HOTCOLD;
    }
    else if(Scan->GetComponentsDataType()==U_COMPDAT_CORPFDR && Scan->GetVeclen()==3)
    {
        if(DoubleScale)
        {
            DmaxPhys   =   1;
            DminPhys   =  -1;
            if(DMinDat>=0)
            {
                DmaxRange  =  MIN(1., UpScalePosValue(1.001*F));
                DminRange  =  0;     
                DminActual =  F/2;    
                DmaxActual =  F;
                PT         =  U_PALETTE_HOT;
                ST         =  U_SCALE_LIN;
            }
            else
            {
                DmaxRange  =   MIN(1., UpScalePosValue(1.001*F));
                DminRange  =  -DmaxRange;     
                DminActual =  -F/2;    
                DmaxActual =   F/2;
                PT         =   U_PALETTE_HOTCOLD;
                ST         =   U_SCALE_ASY;
            }
        }
        else /// This will not happen...
        {
            ImaxPhys   =  ImaxRange  =  int(UpScalePosValue(1.001*I));
            IminPhys   =  IminRange  = -ImaxRange;     
            IminActual = -I;   
            ImaxActual =  I;
            PT         =  U_PALETTE_HOTCOLD;
            ST         =  U_SCALE_SYM;
        }
    }
    else
    {
        switch(Scan->GetModality())
        {
        case U_MOD_MR:
        case U_MOD_fMRI:
        case U_MOD_CT:
            if( (DMinDat>=0. && DoubleScale==true ) ||
                (IMinDat>=0  && DoubleScale==false))
            {
                if(DoubleScale==true)
                {
                    DmaxPhys   = 100000;
                    DminPhys   =      0;
                    DmaxRange  = MIN(DmaxPhys, UpScalePosValue(1.001*F));
                    DminRange  =      0;     
                    DminActual =     30;    
                    DmaxActual =   1000;
                    if(DmaxRange<DmaxActual) {double dum = DmaxRange; DmaxRange = DmaxActual; DmaxActual = dum;}
                }
                else
                {
                    ImaxPhys   = 100000;
                    IminPhys   =      0;
                    ImaxRange  =  MIN(ImaxPhys, int(UpScalePosValue(1.001*I)));
                    IminRange  =     0;     
                    IminActual =    30; if(I>10000) IminActual =  100;
                    ImaxActual =  1000; if(I>10000) ImaxActual = 3000;
                    if(ImaxRange<ImaxActual) {int dum = ImaxRange; ImaxRange = ImaxActual; ImaxActual = dum;}
                }
                PT       = U_PALETTE_GREY;
                ST       = U_SCALE_LOG;
            }
            else // This may happen when Scan represents fMRI-clusters
            {
                if(DoubleScale==true)
                {
                    DmaxPhys   = 100*F;
                    DminPhys   =-DmaxPhys;
                    DmaxRange  = MIN(DmaxPhys, UpScalePosValue(1.001*F));
                    DminRange  =-DmaxRange;     
                    DminActual = DMinDat;    
                    DmaxActual = DMaxDat;
                }
                else
                {
                    ImaxPhys   = 100*I;
                    IminPhys   =-ImaxPhys;
                    ImaxRange  = MIN(ImaxPhys, int(UpScalePosValue(1.001*I)));
                    IminRange  =-ImaxRange;     
                    IminActual = IMinDat;    
                    ImaxActual = IMaxDat;
                }
                PT       = U_PALETTE_3;
                ST       = U_SCALE_LIN;
            }
            break;

        case U_MOD_PET:
        case U_MOD_SPECT:
            if(DoubleScale==true)
            {
                DmaxPhys   =     UpScalePosValue(1.001*F);
                DminPhys   =     0;
                if(DMinDat<0) DminPhys = -UpScalePosValue(-1.001*DMinDat);
                DmaxRange  =     DmaxPhys;
                DminRange  =     0;     
                DminActual =   100;    
                DmaxActual =  1000;
            }
            else
            {
                ImaxPhys   =  int(UpScalePosValue(1.001*I));
                IminPhys   =     0;
                if(IMinDat<0) IminPhys = -int(UpScalePosValue(-1.001*IMinDat));
                ImaxRange  =  IMaxDat;
                IminRange  =     0;     
                IminActual =   100;    
                ImaxActual =  6000;
            }

            PT       = U_PALETTE_HOT;
            if(Scan->GetModality()==U_MOD_PET) ST = U_SCALE_LOG;
            else                               ST = U_SCALE_LIN;
            break;

        case U_MOD_MEG:
            if( (DoubleScale==true &&DMinDat>=0.) || 
                (DoubleScale==false&&IMinDat>=0 ))        
            {
                if(DoubleScale==true)
                {
                    DmaxPhys   =  UpScalePosValue(1.001*DMaxDat);
                    DminPhys   = -DmaxPhys;
                    DmaxRange  =  DmaxPhys;
                    DminRange  =  0;     
                    DminActual =  DMinDat;    
                    DmaxActual =  DMaxDat;
                }
                else
                {
                    ImaxPhys   = int(UpScalePosValue(1.001*I));
                    IminPhys   =-ImaxPhys;
                    ImaxRange  = ImaxPhys; 
                    IminRange  = 0;     
                    IminActual = IMinDat;
                    ImaxActual = IMaxDat;
                }
                PT       = U_PALETTE_HOT;
                ST       = U_SCALE_LIN;
            }
            else
            {
                if(DoubleScale)
                {
                    DmaxPhys   =  DmaxRange  =  UpScalePosValue(1.001*F);
                    DminPhys   =  DminRange  = -DmaxRange;     
                    DminActual = -F/2;
                    DmaxActual =  F/2;
                }
                else
                {
                    ImaxPhys   =  ImaxRange  =  int(UpScalePosValue(1.001*I));
                    IminPhys   =  IminRange  = -ImaxRange;     
                    IminActual = -I/2 +1;
                    ImaxActual =  I/2 +1;
                }
                PT       = U_PALETTE_HOTCOLD;
                ST       = U_SCALE_ASY;
            }
            break;
        default:
            {
                AutoScale(DMinDat, DMaxDat, IMinDat, IMaxDat);
                if((     DoubleScale &&DminActual<0) || 
                    (NOT(DoubleScale)&&IminActual<0))
                {
                    PT = U_PALETTE_4;
                    ST = U_SCALE_LIN;
                }
                else
                {
                    if(DoubleScale) PT = U_PALETTE_HOT;
                    else            PT = U_PALETTE_GREY;
                    ST = U_SCALE_LIN;
                }
            }
        }
    }
    if(Scan->GetDType()==UField::U_BYTE)
    {
        ImaxPhys   = 255;
        IminPhys   =   0;
        ImaxRange  =   MIN(255, MAX(I, 10));
        IminRange  =   0;
        ImaxActual =   MIN(I,ImaxRange);
        IminActual =   0;

        if(Scan->GetModality()!=U_MOD_MR   && 
           Scan->GetModality()!=U_MOD_fMRI && 
           Scan->GetModality()!=U_MOD_CT)      PT = U_PALETTE_4;
        ST         = U_SCALE_LIN;

        if(Scan->Getndim()==3) PT = U_PALETTE_GREY;
    }
}

ULevelSettings::~ULevelSettings() {}

ULevelSettings& ULevelSettings::operator=(const ULevelSettings& Lev)
{
    if(this==NULL)
    {
        static ULevelSettings Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: ULevelSettings::operator=(). this==NULL. \n");
        return Def;
    }
    if(&Lev==NULL)
    {
        CI.AddToLog("ERROR: ULevelSettings::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Lev) return *this;

    if(Lev.TestRanges(false)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULevelSettings::operator=(). Argument has invalid ranges.\n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    DoubleScale    = Lev.DoubleScale   ;

    DminPhys       = Lev.DminPhys      ;
    DmaxPhys       = Lev.DmaxPhys      ;
    DminRange      = Lev.DminRange     ;
    DmaxRange      = Lev.DmaxRange     ;
    DminActual     = Lev.DminActual    ;
    DmaxActual     = Lev.DmaxActual    ;

    IminPhys       = Lev.IminPhys      ;
    ImaxPhys       = Lev.ImaxPhys      ;
    IminRange      = Lev.IminRange     ;
    ImaxRange      = Lev.ImaxRange     ;
    IminActual     = Lev.IminActual    ;
    ImaxActual     = Lev.ImaxActual    ;
    
    ST             = Lev.ST             ;
    PT             = Lev.PT             ;
    ReversePalette = Lev.ReversePalette ;
    MaxAsBackground= Lev.MaxAsBackground;
    return *this;
}

bool ULevelSettings::operator==(const ULevelSettings& Lev) const
{
    if(this==&Lev) return true;
    if(this==NULL)
    {
        CI.AddToLog("ERROR: ULevelSettings::operator==(). this==NULL. \n");
        return false;
    }
    if(&Lev==NULL)
    {
        CI.AddToLog("ERROR: ULevelSettings::operator==(). Argument has NULL address. \n");
        return false;
    }
    if(ST            != Lev.ST            ) return false;
    if(PT            != Lev.PT            ) return false;
    if(ReversePalette!= Lev.ReversePalette) return false;
    if(DoubleScale   != Lev.DoubleScale   ) return false;
    
    if(DoubleScale==true)
    {
        if(DminPhys   != Lev.DminPhys  )  return false;
        if(DmaxPhys   != Lev.DmaxPhys  )  return false;
        if(DminRange  != Lev.DminRange )  return false;
        if(DmaxRange  != Lev.DmaxRange )  return false;
        if(DminActual != Lev.DminActual)  return false;
        if(DmaxActual != Lev.DmaxActual)  return false;

        return true;
    }
    if(IminPhys   != Lev.IminPhys  )  return false;
    if(ImaxPhys   != Lev.ImaxPhys  )  return false;
    if(IminRange  != Lev.IminRange )  return false;
    if(ImaxRange  != Lev.ImaxRange )  return false;
    if(IminActual != Lev.IminActual)  return false;
    if(ImaxActual != Lev.ImaxActual)  return false;

    return true;
}

ErrorType ULevelSettings::SetLevelSettings(const UString& Prop, UString Comment)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetLevelSettings(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Prop==NULL || Prop.IsNULL()==true || Prop.IsEmpty()==true)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetLevelSettings(). Empty property string. \n");
        return U_ERROR;
    }
    UString Set = Prop.GetTextInterval(UString(LevSetBegin), UString(LevSetEnd), false);
    if(Set.RemoveEmptyLines()!=U_OK || Set.RemoveFromEachLine(Comment)!=U_OK)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetLevelSettings(). Removing empty lines or comments. \n");
        return U_ERROR;
    }
    if(Prop.IsEmpty()==true) 
    {
        CI.AddToLog("ERROR: ULevelSettings::SetLevelSettings(). LevelSettings not found in UString argument. \n");
        return U_ERROR;
    }
    bool       SkipCom   = false;
    ErrorType  E         = U_OK;
    ReversePalette       = Set.GetIdentifierIsBool("ReversePalette",ReversePalette,SkipCom, &E);
    DoubleScale          = Set.GetIdentifierIsBool("DoubleScale"   ,DoubleScale   ,SkipCom, &E);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Cannot find ReversePalette or DoubleScale parameter(s). Set = %s\n", (const char*)Set);
        return U_ERROR;
    }

    int ScaleInt = -1;
    int PallInt  = -1;
    if(E==U_OK) ScaleInt = Set.GetIdentifierIsInt("ScaleType"   , -1, SkipCom, &E);
    if(E==U_OK) PallInt  = Set.GetIdentifierIsInt("PalletteType", -1, SkipCom, &E);
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Cannot find ReversePalette or DoubleScale parameter(s). Set = %s\n", (const char*)Set);
        return U_ERROR;
    }
    ST = ::GetScaleType(ScaleInt);
    PT = ::GetPaletteType(MAX(1,PallInt));
    if(DoubleScale)
    {
        if(E==U_OK) DminPhys    = Set.GetIdentifierIsDouble("DminPhys"   , DminPhys  , SkipCom, &E);
        if(E==U_OK) DmaxPhys    = Set.GetIdentifierIsDouble("DmaxPhys"   , DmaxPhys  , SkipCom, &E);
        if(E==U_OK) DminRange   = Set.GetIdentifierIsDouble("DminRange"  , DminRange , SkipCom, &E);
        if(E==U_OK) DmaxRange   = Set.GetIdentifierIsDouble("DmaxRange"  , DmaxRange , SkipCom, &E);
        if(E==U_OK) DminActual  = Set.GetIdentifierIsDouble("DminActual" , DminActual, SkipCom, &E);
        if(E==U_OK) DmaxActual  = Set.GetIdentifierIsDouble("DmaxActual" , DmaxActual, SkipCom, &E);
        if(E!=U_OK || 
           DminPhys>=DmaxPhys  || DminRange >=DmaxRange || DminActual>=DmaxActual ||
           DminPhys> DminRange || DminRange > DminActual||
           DmaxPhys< DmaxRange || DmaxRange < DmaxActual)
        {
            CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid (double) range parameter(s). Set = %s\n", (const char*)Set);
            return U_ERROR;
        }          
    }
    else
    {
        if(E==U_OK) IminPhys    = Set.GetIdentifierIsInt("IminPhys"   , IminPhys  , SkipCom, &E);
        if(E==U_OK) ImaxPhys    = Set.GetIdentifierIsInt("ImaxPhys"   , ImaxPhys  , SkipCom, &E);
        if(E==U_OK) IminRange   = Set.GetIdentifierIsInt("IminRange"  , IminRange , SkipCom, &E);
        if(E==U_OK) ImaxRange   = Set.GetIdentifierIsInt("ImaxRange"  , ImaxRange , SkipCom, &E);
        if(E==U_OK) IminActual  = Set.GetIdentifierIsInt("IminActual" , IminActual, SkipCom, &E);
        if(E==U_OK) ImaxActual  = Set.GetIdentifierIsInt("ImaxActual" , ImaxActual, SkipCom, &E);
        if(E!=U_OK || 
           IminPhys>=ImaxPhys  || IminRange >=ImaxRange || IminActual>=ImaxActual ||
           IminPhys> IminRange || IminRange > IminActual||
           ImaxPhys< ImaxRange || ImaxRange < ImaxActual)
        {
            CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid (int) range parameter(s). Set = %s\n", (const char*)Set);
            return U_ERROR;
        }          
    }
    return U_OK;
}
UString   ULevelSettings::GetLevelSettings(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: ULevelSettings::GetLevelSettings(). Object NULL or erroneous.\n");
        return UString();
    }
    UString Set;
    if(Comment.IsEmpty()==false) Set += Comment;
    Set    += UString(LevSetBegin, "%s \n");
    Set    += GetProperties(Comment);
    if(Comment.IsEmpty()==false) Set += Comment;
    Set    += UString(LevSetEnd,   "%s \n");

    return Set;
}

const UString& ULevelSettings::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in ULevelSettings-object \n");
        if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
        else                                       Properties.InsertAtEachLine(Comment);
        return Properties;
    }

    Properties     = UString();

    Properties    += UString(ST," ScaleType       = %d \n");
    Properties    += UString(PT," PalletteType    = %d \n");
    Properties    += UString(BoolAsText(ReversePalette )," ReversePallette = %s \n");
    Properties    += UString(BoolAsText(MaxAsBackground)," MaxAsBackground = %s \n");
        
    Properties    += UString(BoolAsText(DoubleScale)," DoubleScale     = %s \n");
    if(DoubleScale)
    {
        Properties    += UString(DminPhys  ," DminPhys        = %15.8g \n");
        Properties    += UString(DmaxPhys  ," DmaxPhys        = %15.8g \n");
        Properties    += UString(DminRange ," DminRange       = %15.8g \n");
        Properties    += UString(DmaxRange ," DmaxRange       = %15.8g \n");
        Properties    += UString(DminActual," DminActual      = %15.8g \n");
        Properties    += UString(DmaxActual," DmaxActual      = %15.8g \n");
    }
    else
    {
        Properties    += UString(IminPhys  ," IminPhys        = %d \n");
        Properties    += UString(ImaxPhys  ," ImaxPhys        = %d \n");
        Properties    += UString(IminRange ," IminRange       = %d \n");
        Properties    += UString(ImaxRange ," ImaxRange       = %d \n");
        Properties    += UString(IminActual," IminActual      = %d \n");
        Properties    += UString(ImaxActual," ImaxActual      = %d \n");
    }

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType ULevelSettings::SetPalette(PaletteType Palette, bool ReversePal)
{
    if(this==NULL) return U_ERROR;
    PT             = Palette;      
    ReversePalette = ReversePal;
    return U_OK;
}
ErrorType ULevelSettings::SetPalette(bool ReversePal)
{
    if(this==NULL) return U_ERROR;
    ReversePalette = ReversePal;
    return U_OK;
}
ErrorType ULevelSettings::SetPalette(int Index)
{
    if(this==NULL) return U_ERROR;
    if(Index<0 || Index>2*U_PALETTE_NUMPALTYPE) 
    {
        CI.AddToLog("ERROR: ULevelSettings::SetPalette(). Index (=%d) out of range. \n", Index);
        return U_ERROR;
    }
    ReversePalette = ((Index%2)==1) ;
    PT             = UBitMap::ConvertToPalType(Index/2);
    return U_OK;
}
int ULevelSettings::GetPaletteIndex(void) const
{
    if(this==NULL) return 0;

    int Index = 2* int(PT);
    if(ReversePalette) Index += 1;
    return Index;
}

ErrorType ULevelSettings::TestRanges(bool ErrorsToLog) const
{
    if(this==NULL)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::TestRanges(). this==NULL .\n");
        return U_ERROR;
    }
    if(DoubleScale)
    {
        if(DminPhys>=DmaxPhys)
        {
            if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid physical range (%f-%f) .\n", DminPhys, DmaxPhys);
            return U_ERROR;
        }
        if(DminRange>=DmaxRange)
        {
            if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid range (%f-%f) .\n", DminRange, DmaxRange);
            return U_ERROR;
        }
        if(DminActual>=DmaxActual)
        {
            if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid actual range (%f-%f) .\n", DminActual, DmaxActual);
            return U_ERROR;
        }
        if(DminActual<DminRange || DminRange<DminPhys)
        {
            if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid min ranges (%f<%f<%f ??) .\n", DminPhys, DminRange, DminActual);
            return U_ERROR;
        }
        if(DmaxActual>DmaxRange || DmaxRange>DmaxPhys)
        {
            if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid max ranges (%f>%f>%f ??) .\n", DmaxPhys, DmaxRange, DmaxActual);
            return U_ERROR;
        }
        return U_OK;
    }
    if(IminPhys>=ImaxPhys)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid physical range (%d-%d) .\n", IminPhys, ImaxPhys);
        return U_ERROR;
    }
    if(IminRange>=ImaxRange)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid range (%d-%d) .\n", IminRange, ImaxRange);
        return U_ERROR;
    }
    if(IminActual>=ImaxActual)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid actual range (%d-%d) .\n", IminActual, ImaxActual);
        return U_ERROR;
    }
    if(IminActual<IminRange || IminRange<IminPhys)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid min ranges (%d<%d<%d ??) .\n", IminPhys, IminRange, IminActual);
        return U_ERROR;
    }
    if(ImaxActual>ImaxRange || ImaxRange>ImaxPhys)
    {
        if(ErrorsToLog) CI.AddToLog("ERROR: ULevelSettings::ULevelSettings(). Invalid max ranges (%d>%d>%d ??) .\n", ImaxPhys, ImaxRange, ImaxActual);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType ULevelSettings::AutoScale(double DMinDat, double DMaxDat, int IMinDat, int IMaxDat)
{
    if(this==NULL) return U_ERROR;

    if(DMinDat>DMaxDat){double Dum=DMaxDat; DMaxDat=DMinDat; DMinDat=Dum;}
    if(IMinDat>IMaxDat){int    Dum=IMaxDat; IMaxDat=IMinDat; IMinDat=Dum;}

    if(DMaxDat==DMinDat)
    {
        if(DMaxDat==0.)    {DMinDat = 0.; DMaxDat = 1.;}
        else
        {
            if(DMaxDat>0.) {DMinDat *= 0.9; DMaxDat *= 1.1;}
            if(DMaxDat<0.) {DMaxDat *= 0.9; DMinDat *= 1.1;}
        }
    }
    if(IMaxDat==IMinDat)
    {
        if(IMaxDat==0)    {IMinDat = 0; IMaxDat = 255;}
        else
        {
            if(IMaxDat>0)  IMinDat = 0;
            if(IMaxDat<0)  IMaxDat = 0;
        }
    }

    double F    = MAX(fabs(DMinDat),fabs(DMaxDat));
    int    I    = MAX( abs(IMinDat), abs(IMaxDat));

    DminActual  = DMinDat;
    DmaxActual  = DMaxDat;
    IminActual  = IMinDat;
    ImaxActual  = IMaxDat;

    double Fr   =     UpScalePosValue(1.001*F);
    int    Ir   = int(UpScalePosValue(1.001*I));

    DmaxRange   = (DmaxActual<0) ?  0.  : Fr;
    DminRange   = (DminActual<0) ? -Fr  : 0.;
    ImaxRange   = (ImaxActual<0) ?  0   : Ir;
    IminRange   = (IminActual<0) ? -Ir  : 0 ;

    DmaxPhys    =  1000.*Fr;
    DminPhys    = -DmaxPhys;

    ImaxPhys    =  1<<30; // MaxInt
    IminPhys    = -ImaxPhys;

    return U_OK;
}

ErrorType ULevelSettings::SetScaleType(ScaleType Scale)
{
    if(this==NULL) return U_ERROR;

    DminRange = MIN(DminRange, DminActual);
    DminPhys  = MIN(DminPhys , DminRange );
    DmaxRange = MAX(DmaxRange, DmaxActual);
    DmaxPhys  = MAX(DmaxPhys , DmaxRange );
    IminRange = MIN(IminRange, IminActual);
    IminPhys  = MIN(IminPhys , IminRange );
    ImaxRange = MAX(ImaxRange, ImaxActual);
    ImaxPhys  = MAX(ImaxPhys , ImaxRange );
    switch(Scale)
    {
    case U_SCALE_LIN:
        break;
    case U_SCALE_LOG:
        if(DoubleScale)
        {
            DminActual = MAX(0.,DminActual);
            DminRange  = MAX(0.,DminRange );
            DminPhys   = MAX(0.,DminPhys  );
            if(DmaxActual<=0) DmaxPhys = DmaxRange = DmaxActual = 100.;
        }
        else
        {
            IminActual = MAX(0,IminActual);
            IminRange  = MAX(0,IminRange );
            IminPhys   = MAX(0,IminPhys  );
            if(ImaxActual<=0) ImaxPhys = ImaxRange = ImaxActual = 255 ;
        }
        break;
    case U_SCALE_SYM:
    case U_SCALE_ASY:
        if(DoubleScale)
        {
            DmaxPhys   = MAX(fabs(DmaxPhys  ), fabs(DminPhys  )); if(DmaxPhys  ==0) DmaxPhys  =100.;
            DminPhys   =-DmaxPhys;
            DmaxRange  = MAX(fabs(DmaxRange ), fabs(DminRange )); if(DmaxRange ==0) DmaxRange =100.;
            DminRange  =-DmaxRange;
            DmaxActual = MAX(fabs(DmaxActual), fabs(DminActual)); if(DmaxActual==0) DmaxActual=100.;
            DminActual =-DmaxActual;
        }
        else
        {
            ImaxPhys   = MAX( abs(ImaxPhys  ),  abs(IminPhys  )); if(ImaxPhys  ==0) ImaxPhys  =100;
            IminPhys   =-ImaxPhys;
            ImaxRange  = MAX( abs(ImaxRange ),  abs(IminRange )); if(ImaxRange ==0) ImaxRange =100;
            IminRange  =-ImaxRange;
            ImaxActual = MAX( abs(ImaxActual),  abs(IminActual)); if(ImaxActual==0) ImaxActual=100;
            IminActual =-ImaxActual;
        }
        break;
    default:
        CI.AddToLog("ERROR: ULevelSettings::SetScaleType(). Invalid ScaleType (%d) \n", Scale);
    }
    ST = Scale;
    return U_OK;
}

ErrorType ULevelSettings::SetActual(double NewMinAct, double NewMaxAct, bool SetNiceRange)
{
    if(this==NULL) return U_ERROR;

    if(NewMinAct>=NewMaxAct)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetActual(). Invalid Range parameters:  NewMinAct = %f  NewMaxAct = %f \n", NewMinAct, NewMaxAct);
        return U_ERROR;
    }
    if(DoubleScale)
    {
        DminActual = NewMinAct;
        DmaxActual = NewMaxAct;
        if(SetNiceRange)
        {
            if(DminActual>0)      DminRange = DownScalePosValue( DminActual);
            else if(DminActual<0) DminRange =  -UpScalePosValue(-DminActual);
            else                  DminRange = 0.;
            DminPhys = MIN(DminPhys, DminRange);

            if(DmaxActual>0)      DmaxRange =    UpScalePosValue( DmaxActual);
            else if(DmaxActual<0) DmaxRange = -DownScalePosValue(-DmaxActual);
            else                  DmaxRange = 0.;
            DmaxPhys = MAX(DmaxPhys, DmaxRange);
        }
    }
    else
    {
        return SetActual( int(NewMinAct), int(NewMaxAct), SetNiceRange);
    }
    return SetScaleType(ST);
}
ErrorType ULevelSettings::SetActual(int    NewMinAct, int    NewMaxAct, bool SetNiceRange)
{
    if(this==NULL) return U_ERROR;

    if(NewMinAct>=NewMaxAct)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetActual(). Invalid Range parameters:  NewMinAct = %d  NewMaxAct = %d \n", NewMinAct, NewMaxAct);
        return U_ERROR;
    }
    if(DoubleScale)
    {
        return SetActual( double(NewMinAct), double(NewMaxAct), SetNiceRange);
    }
    else
    {
        IminActual = NewMinAct;
        ImaxActual = NewMaxAct;
        if(SetNiceRange)
        {
            if(IminActual>0)      IminRange =   int(DownScalePosValue( IminActual));
            else if(IminActual<0) IminRange =  -int(UpScalePosValue(-IminActual));
            else                  IminRange = 0;
            IminPhys = MIN(IminPhys, IminRange);

            if(ImaxActual>0)      ImaxRange =  int(UpScalePosValue( ImaxActual));
            else if(ImaxActual<0) ImaxRange = -int(DownScalePosValue(-ImaxActual));
            else                  ImaxRange = 0;
            ImaxPhys = MAX(ImaxPhys, ImaxRange);
        }
    }
    return SetScaleType(ST);
}
ErrorType ULevelSettings::SetRangeActual(double NewMinRan, double NewMaxRan, double NewMinAct, double NewMaxAct)
{
    if(this==NULL) return U_ERROR;

    if(NewMinRan>=NewMaxRan)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetRangeActual(). Invalid Range parameters:  NewMinRan = %f  NewMaxRan = %f \n", NewMinRan, NewMaxRan);
        return U_ERROR;
    }
    if(NewMinAct>=NewMaxAct)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetRangeActual(). Invalid Range parameters:  NewMinAct = %f  NewMaxAct = %f \n", NewMinAct, NewMaxAct);
        return U_ERROR;
    }
    if(DoubleScale)
    {
        DminRange  = NewMinRan;
        DmaxRange  = NewMaxRan;
        DminActual = NewMinAct;
        DmaxActual = NewMaxAct;
    }
    else
    {
        IminRange  = int(NewMinRan);
        ImaxRange  = int(NewMaxRan);
        IminActual = int(NewMinAct);
        ImaxActual = int(NewMaxAct);
    }
    return SetScaleType(ST);
}
ErrorType ULevelSettings::SetRangeActual(int    NewMinRan, int    NewMaxRan, int    NewMinAct, int    NewMaxAct)
{
    if(this==NULL) return U_ERROR;

    if(NewMinRan>=NewMaxRan)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetRangeActual(). Invalid Range parameters:  NewMinRan = %d  NewMaxRan = %d \n", NewMinRan, NewMaxRan);
        return U_ERROR;
    }
    if(NewMinAct>=NewMaxAct)
    {
        CI.AddToLog("ERROR: ULevelSettings::SetRangeActual(). Invalid Range parameters:  NewMinAct = %d  NewMaxAct = %d \n", NewMinAct, NewMaxAct);
        return U_ERROR;
    }
    if(DoubleScale)
    {
        DminRange  = double(NewMinRan);
        DmaxRange  = double(NewMaxRan);
        DminActual = double(NewMinAct);
        DmaxActual = double(NewMaxAct);
    }
    else
    {
        IminRange  = NewMinRan;
        ImaxRange  = NewMaxRan;
        IminActual = NewMinAct;
        ImaxActual = NewMaxAct;
    }
    return SetScaleType(ST);
}

/*****
void ULevelSettings::SetNiceRange(void)
{
    double H = 0.;

    if(DoubleRange==true)
    {
        double DMinRange  = SPD_MinRange->GetDoubleValue();
        double DMaxRange  = SPD_MaxRange->GetDoubleValue();
        double DMin       = 0;
        double DMax       = 1;

        H = exp(log(10.)*ceil(log(fabs(DMaxRange))/log(10.)));
        if(DMaxRange<0) H=-H;

        if(H/5>DMaxRange)      { DMax=H/5.;}
        else if(H/2>DMaxRange) { DMax=H/2.;}
        else                    { DMax=H   ;}

        H = exp(log(10.)*ceil(log(fabs(DMinRange))/log(10.)));
        if(DMinRange<0) H=-H;

        if(H  <DMinRange)      { DMin=H   ;}
        else if(H/2<DMinRange) { DMin=H/2.;}
        else                    { DMin=H/5.;}

        switch(Scale)
        {
        case U_SCALE_LIN: 
            if(DMin!=0. && fabs(DMax/DMin)>10.)
            {
                if(fabs(DMax)>fabs(DMin)) DMin = 0.;
                else                                DMax = 0.;
            }
            break;

        case U_SCALE_LOG: 
            if(DMin<=0 || DMax<=0)
            {
                DMax = MAX(fabs(DMin),fabs(DMax));
                DMin = MIN(1.,(DMax/1000));
            }
            break;

        case U_SCALE_SYM:         
        case U_SCALE_ASY:         
            if(fabs(DMin)>fabs(DMax))
            {
                DMin = -fabs(DMin);
                DMax = -     DMin;
            }
            else
            {
                DMin = -fabs(DMax);
                DMax = -     DMin;
            }        
            break;
        }
        SPD_MinRange->UpdateMinValue(DMin);
        SPD_MinRange->UpdateMaxValue(DMax);
        SPD_MaxRange->UpdateMinValue(DMin);
        SPD_MaxRange->UpdateMaxValue(DMax);
    }
    else
    {
        int IMinRange  = SPD_MinRange->GetIntValue();
        int IMaxRange  = SPD_MaxRange->GetIntValue();
        int IMin       = 0;
        int IMax       = 1;

        H = exp(log(10.)*ceil(log(fabs((double)IMaxRange))/log(10.)));
        if(IMaxRange<0) H=-H;
        H = floor(0.5+H);

        if(H/5>IMaxRange)      { IMax=floor(.5+H/5.);}
        else if(H/2>IMaxRange) { IMax=floor(.5+H/2.);}
        else                    { IMax=floor(.5+H   );}

        H = exp(log(10.)*ceil(log(fabs((double)IMinRange))/log(10.)));
        if(IMinRange<0) H=-H;
        H = floor(0.5+H);

        if(H  <=IMinRange)     { IMin=floor(.5+H   );}
        if(H/2<=IMinRange)     { IMin=floor(.5+H/2.);}
        if(H/5<=IMinRange)     { IMin=floor(.5+H/5.);}

        switch(Scale)
        {
        case U_SCALE_LIN: 
            if(IMin!=0. && fabs((double)IMax)/fabs((double)IMin)>10.)
            {
                if(abs(IMax)>abs(IMin)) IMin = 0;
                else                              IMax = 0;
            }
            break;

        case U_SCALE_LOG: 
            if(IMin<=0 || IMax<=0)
            {
                IMax = MAX(abs(IMin),abs(IMax));
                IMin = MIN(1,floor(.5+IMax/1000.));
            }
            break;

        case U_SCALE_SYM:         
        case U_SCALE_ASY:         
            if(abs(IMin)>abs(IMax))
            {
                IMin = -abs(IMin);
                IMax = -    IMin;
            }
            else
            {
                IMin = -abs(IMax);
                IMax = -    IMin;
            }        
            break;
        }
        SPD_MinRange->UpdateMinValue(IMin);
        SPD_MinRange->UpdateMaxValue(IMax);
        SPD_MaxRange->UpdateMinValue(IMin);
        SPD_MaxRange->UpdateMaxValue(IMax);
    }
}

****/

ULevelSettings Max(const ULevelSettings& a, const ULevelSettings& b)
{
    ULevelSettings MaxSet = a;

    if(a.DoubleScale==true && b.DoubleScale==true)
    {
        MaxSet.DminPhys   = MIN(a.DminPhys  , b.DminPhys  );
        MaxSet.DminRange  = MIN(a.DminRange , b.DminRange );
        MaxSet.DminActual = MIN(a.DminActual, b.DminActual);
        MaxSet.DmaxPhys   = MAX(a.DmaxPhys  , b.DmaxPhys  );
        MaxSet.DmaxRange  = MAX(a.DmaxRange , b.DmaxRange );
        MaxSet.DmaxActual = MAX(a.DmaxActual, b.DmaxActual);
    }
    else if(a.DoubleScale==false && b.DoubleScale==false)
    {
        MaxSet.IminPhys   = MIN(a.IminPhys  , b.IminPhys  );
        MaxSet.IminRange  = MIN(a.IminRange , b.IminRange );
        MaxSet.IminActual = MIN(a.IminActual, b.IminActual);
        MaxSet.ImaxPhys   = MAX(a.ImaxPhys  , b.ImaxPhys  );
        MaxSet.ImaxRange  = MAX(a.ImaxRange , b.ImaxRange );
        MaxSet.ImaxActual = MAX(a.ImaxActual, b.ImaxActual);
    }
    else if(a.DoubleScale==true && b.DoubleScale==false)
    {
        MaxSet.DminPhys   = a.DminPhys  ;
        MaxSet.DminRange  = a.DminRange ;
        MaxSet.DminActual = a.DminActual;
        MaxSet.DmaxPhys   = a.DmaxPhys  ;
        MaxSet.DmaxRange  = a.DmaxRange ;
        MaxSet.DmaxActual = a.DmaxActual;
        MaxSet.IminPhys   = b.IminPhys  ;
        MaxSet.IminRange  = b.IminRange ;
        MaxSet.IminActual = b.IminActual;
        MaxSet.ImaxPhys   = b.ImaxPhys  ;
        MaxSet.ImaxRange  = b.ImaxRange ;
        MaxSet.ImaxActual = b.ImaxActual;
    }
    else if(a.DoubleScale==false && b.DoubleScale==true)
    {
        MaxSet.DminPhys   = b.DminPhys  ;
        MaxSet.DminRange  = b.DminRange ;
        MaxSet.DminActual = b.DminActual;
        MaxSet.DmaxPhys   = b.DmaxPhys  ;
        MaxSet.DmaxRange  = b.DmaxRange ;
        MaxSet.DmaxActual = b.DmaxActual;
        MaxSet.IminPhys   = a.IminPhys  ;
        MaxSet.IminRange  = a.IminRange ;
        MaxSet.IminActual = a.IminActual;
        MaxSet.ImaxPhys   = a.ImaxPhys  ;
        MaxSet.ImaxRange  = a.ImaxRange ;
        MaxSet.ImaxActual = a.ImaxActual;
    }
    return MaxSet;
}

ErrorType ULevelSettings::GetSafeMinMaxActual(double* Pmin, double* Pmax, double* LogPmin, double* LogPmax) const
{
    double pmin = 0.; 
    double pmax = 1.;
    if(DoubleScale==true)
    {
        pmin = DminActual;
        pmax = DmaxActual;
        if(pmin==pmax) pmax = pmin*1.1;
        if(pmin >pmax) {double dum=pmin; pmin=pmax; pmax=dum;}
    }
    else
    {
        pmin = IminActual;
        pmax = ImaxActual;
        if(pmin==pmax) pmax = pmin+255;
        if(pmin >pmax) {double dum=pmin; pmin=pmax; pmax=dum;}
    }

    if(Pmin) *Pmin = pmin;
    if(Pmax) *Pmax = pmax;

    if(LogPmin || LogPmax)
    {
        double lpmin = 0.;
        double lpmax = 1.;
        if(pmin>0.) lpmin = log(1.*pmin);
        if(pmax>0.) lpmax = log(1.*pmax);
        if(lpmin>=lpmax) return U_ERROR;

        if(LogPmin) *LogPmin = lpmin;
        if(LogPmax) *LogPmax = lpmax;
    }
    return U_OK;
}

ErrorType ULevelSettings::ConvertToByteRange(unsigned char* Data, int Npoints) const
{
    if(Data==NULL || Npoints<=0) return U_ERROR;

    unsigned char Table[256];

    double Pmin  = 0.; 
    double Pmax  = 1.;
    double LPmin = 0.;
    double LPmax = 1.;

    if(ST==U_SCALE_LOG)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax, &LPmin, &LPmax) !=U_OK) return U_ERROR;

        for(int k=0; k<256; k++) 
        {
            double Dat = 0;
            if(k) Dat = floor( 255.*(log(1.*k)-LPmin)/(LPmax-LPmin)+.5 );
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Table[k] = (unsigned char)(MIN(255, MAX(0, Dat)));
        }                
    }
    if(ST==U_SCALE_SYM || ST==U_SCALE_LIN)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;

        if(Pmin==Pmax) Pmax = Pmin+1;
        double Scale  =  255./(Pmax-Pmin);
        double Offset = -Pmin*Scale + .5;
        for(int k=0; k<256; k++) 
        {
            double Dat = floor( Scale*k+Offset );
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Table[k]  = (unsigned char)(MIN(255, MAX(0, Dat)));
        }
    }
    if(ST==U_SCALE_ASY)
    {
        double IMaxRange = double(ImaxPhys);

        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;
        
        if(Pmax==IMaxRange) Pmax  = IMaxRange*0.99;
        double              Scale = 127. / (IMaxRange-Pmax);
        int                 Dat   = 0;

        for(int k=0; k<128; k++) 
        {
            int ktab = 127+k;
            if(k<Pmax)
            {
                Table[ktab] = 0;
            }
            else
            {
                Table[ktab] = (unsigned char)(MIN(255, (128.5 + (k-Pmax)*Scale) ));
            }
            if(MaxAsBackground && Table[ktab]>=255) Table[ktab] = 0;
            Table[ktab]  = MIN(255, MAX(0, Dat));
            Table[k   ]  = 256-Table[ktab];
        }
    }
    for(int n=0; n<Npoints; n++) Data[n] = Table[Data[n]];

    return U_OK;
}

ErrorType ULevelSettings::ConvertToByteRange(short*         Data, int Npoints) const
{
    if(Data==NULL || Npoints<=0) return U_ERROR;

    const int NSHORT   =  65536;
    short*        sTab = new short[NSHORT];
    if(sTab==NULL)
    {
        CI.AddToLog("ERROR: ULevelSettings::ConvertToByteRange(). Memory allocation. \n");
        return U_ERROR;
    }
    memset(sTab, 0, NSHORT*sizeof(sTab[0]));
    short* Table      = sTab + NSHORT/2;
    double Pmin       = 0.; 
    double Pmax       = 1.;
    double LPmin      = 0.;
    double LPmax      = 1.;

    if(ST==U_SCALE_LOG)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax, &LPmin, &LPmax) !=U_OK) return U_ERROR;

        for(int k=0; k<NSHORT/2; k++) 
        {
            double Dat = 0;
            if(k>0) Dat = floor( 255.*(log(1.*k)-LPmin)/(LPmax-LPmin)+.5 );
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Table[k] = (short)(MIN(255, MAX(0, Dat)));
        }                
    }
    if(ST==U_SCALE_SYM || ST==U_SCALE_LIN)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;

        if(Pmin==Pmax) Pmax = Pmin+1;
        double Scale  =  255./(Pmax-Pmin);
        double Offset = -Pmin*Scale + .5;
        for(int k=-NSHORT/2; k<NSHORT/2; k++) 
        {
            double Dat = floor( Scale*k+Offset );
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Table[k]   = (short)(MIN(255, MAX(0, Dat)));
        }
    }
    if(ST==U_SCALE_ASY)
    {
        double IMaxRange = double(ImaxPhys);
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;
        
        if(Pmax==IMaxRange) Pmax  = IMaxRange*0.99;
        double              Scale = 127. / (IMaxRange-Pmax);
        double              MAXS  = NSHORT/2.-1;

        for(int k=0; k<NSHORT/2; k++) 
        {
            if(k<Pmax)
            {
                Table[k] = 0;
            }
            else
            {
                Table[k] = short( MIN(MAXS, (128.5 + (k-Pmax)*Scale) ));
            }
            if(MaxAsBackground && Table[k]>=255) Table[k] = 0;
            Table[ k]  = MIN(255, MAX(0, Table[k]));
            Table[-k]  = 256-Table[k];
        }
    }
    for(int n=0; n<Npoints; n++) Data[n] = Table[Data[n]];

    delete[] sTab;
    return U_OK;
}

ErrorType ULevelSettings::ConvertToByteRange(int*           Data, int Npoints) const
{
    if(Data==NULL || Npoints<=0) return U_ERROR;

    double Pmin       = 0.; 
    double Pmax       = 1.;
    double LPmin      = 0.;
    double LPmax      = 1.;

    if(ST==U_SCALE_LOG)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax, &LPmin, &LPmax) !=U_OK) return U_ERROR;

        for(int n=0; n<Npoints; n++) 
        {
            double Dat  = 0;
            if(Data[n]>0) Dat = floor( 255.*(log(1.*Data[n])-LPmin)/(LPmax-LPmin)+.5 );
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Data[n] = (int)(MIN(255, MAX(0, Dat)));
        }
    }

    if(ST==U_SCALE_SYM || ST==U_SCALE_LIN)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax)) return U_ERROR;

        if(Pmin==Pmax) Pmax = Pmin+1;
        double Scale  =  255./(Pmax-Pmin);
        double Offset = -Pmin*Scale + .5;
        for(int n=0; n<Npoints; n++) 
        {
            double Dat = int(floor( Scale*Data[n]+Offset ));
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            Data[n] = (int)(MIN(255, MAX(0, Dat)));
        }
    }
    if(ST==U_SCALE_ASY)
    {
        double IMaxRange = double(ImaxPhys);
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;
        
        if(Pmax==IMaxRange) Pmax  = IMaxRange*0.99;
        double              Scale = 127. / (IMaxRange-Pmax);
        int                 Dat   = 0;
      
        for(int n=0; n<Npoints; n++) 
        {
            int dn = Data[n];
            if(abs(dn)<Pmax) 
            {
                Dat = 0;
            }
            else if(dn>0)
            {
                Dat = int( 128.5 + (dn-Pmax)*Scale );
            }
            else
            {
                Dat = int( 128.5 + (dn+Pmax)*Scale );
                if(Dat<=-IMaxRange) Dat = 1;
            }
            if(MaxAsBackground && (Dat>=255 || Dat<=0)) Dat = 0;
            Data[n] =  MIN(255, MAX(0, Dat));
        }
    }
    return U_OK;
}

ErrorType ULevelSettings::ConvertToByteRange(float*         Data, int Npoints) const 
{
    if(Data==NULL || Npoints<=0) return U_ERROR;

    double Pmin       = 0.; 
    double Pmax       = 1.;
    double LPmin      = 0.;
    double LPmax      = 1.;

    if(ST==U_SCALE_LOG)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax, &LPmin, &LPmax) !=U_OK) return U_ERROR;

        for(int n=0; n<Npoints; n++) 
        {
            double Dat  = 0.;
            if(Data[n]>0) Dat = 255.*(log(1.*Data[n])-LPmin)/(LPmax-LPmin)+.5;
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            if(Dat<0.)          Data[n] = 0.  ;
            else if(Dat>255.)   Data[n] = 255.;
            else                Data[n] = float(floor(Dat+.5));
        }
    }

    if(ST==U_SCALE_SYM || ST==U_SCALE_LIN)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;

        if(Pmin==Pmax) Pmax = Pmin+1;
        double Scale  =  255./(Pmax-Pmin);
        double Offset = -Pmin*Scale + .5;
        for(int n=0; n<Npoints; n++) 
        {
            double Dat = Scale*Data[n]+Offset;
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            if(Dat<0.)          Data[n] = 0.  ;
            else if(Dat>255.)   Data[n] = 255.;
            else                Data[n] = float(floor(Dat));
        }
    }
    if(ST==U_SCALE_ASY)
    {
        double DMaxRange = DmaxPhys;

        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;
        
        if(Pmax==DMaxRange) Pmax  = DMaxRange*0.99;
        double              Scale = 127 / (DMaxRange-Pmax);
        float               Dat   = 0;
      
        for(int n=0; n<Npoints; n++) 
        {
            float dn = Data[n];
            if(fabs(dn)<Pmax) 
            {
                Dat = 0;
            }
            else if(dn>0)
            {
                Dat = float( 128 + (dn-Pmax)*Scale );
            }
            else
            {
                Dat = float( 128 + (dn+Pmax)*Scale );
                if(Dat<=-DMaxRange) Dat = 1.;
            }
            if(MaxAsBackground && (Dat>=255. || Dat<=0.)) Dat = 0;
            Data[n] =  MIN(255, MAX(0, Dat));
        }
    }
    return U_OK;
}

ErrorType ULevelSettings::ConvertToByteRange(double*        Data, int Npoints) const
{
    if(Data==NULL || Npoints<=0) return U_ERROR;

    double Pmin       = 0.; 
    double Pmax       = 1.;
    double LPmin      = 0.;
    double LPmax      = 1.;

    if(ST==U_SCALE_LOG)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax, &LPmin, &LPmax) !=U_OK) return U_ERROR;

        for(int n=0; n<Npoints; n++) 
        {
            double Dat  = 0.;
            if(Data[n]>0) Dat = 255.*(log(1.*Data[n])-LPmin)/(LPmax-LPmin)+.5;
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            if(Dat<0.)          Data[n] = 0.  ;
            else if(Dat>255.)   Data[n] = 255.;
            else                Data[n] = floor(Dat);
        }
    }

    if(ST==U_SCALE_SYM || ST==U_SCALE_LIN)
    {
        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;

        if(Pmin==Pmax) Pmax = Pmin+1;
        double Scale  =  255./(Pmax-Pmin);
        double Offset = -Pmin*Scale + .5;
        for(int n=0; n<Npoints; n++) 
        {
            double Dat = Scale*Data[n]+Offset;
            if(MaxAsBackground && Dat>255.) Dat = 0.;
            if(Dat<0.)          Data[n] = 0.  ;
            else if(Dat>255.)   Data[n] = 255.;
            else                Data[n] = floor(Dat);
        }
    }
    if(ST==U_SCALE_ASY)
    {
        double DMaxRange = DmaxPhys;

        if(GetSafeMinMaxActual(&Pmin, &Pmax) !=U_OK) return U_ERROR;
        
        if(Pmax==DMaxRange) Pmax  = DMaxRange*0.99;
        double              Scale = 127 / (DMaxRange-Pmax);
        double              Dat   = 0;
      
        for(int n=0; n<Npoints; n++) 
        {
            double dn = Data[n];
            if(fabs(dn)<Pmax) 
            {
                Dat = 0;
            }
            else if(dn>0)
            {
                Dat = double( 128 + (dn-Pmax)*Scale );
            }
            else
            {
                Dat = double( 128 + (dn+Pmax)*Scale );
                if(Dat<=-DMaxRange) Dat = 1;
            }
            if(MaxAsBackground && (Dat>=255. || Dat<=0.)) Dat = 0;
            Data[n] =  MIN(255, MAX(0, Dat));
        }
    }
    return U_OK;
}

