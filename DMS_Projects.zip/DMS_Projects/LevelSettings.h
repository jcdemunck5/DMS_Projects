#ifndef _LEVELSETTINGS_INCLUDED
#define _LEVELSETTINGS_INCLUDED

#include "BitMap.h"
#include "String.h"

enum ScaleType
{
    U_SCALE_LIN,
    U_SCALE_LOG,
    U_SCALE_SYM,
    U_SCALE_ASY
};
ScaleType GetScaleType(int itype);

class UScan;
class UField;
class DLL_IO ULevelSettings
{
public:
    friend ULevelSettings DLL_IO Max(const ULevelSettings& a, const ULevelSettings& b);

    ULevelSettings();
    ULevelSettings(const ULevelSettings& Lev);
    ULevelSettings(const UString& Properties, UString Comment);
    ULevelSettings(double DMinPhys, double DMaxPhys, double DMinRange, double DMaxRange, double DMinActual, double DMaxActual, ScaleType Scale, PaletteType Palette, bool ReversePal=false, bool MaxB=false);
    ULevelSettings(int IMinPhys, int IMaxPhys, int IMinRange, int IMaxRange, int IMinActual, int IMaxActual, ScaleType Scale, PaletteType Palette, bool ReversePal=false, bool MaxB=false);
    ULevelSettings(const UScan* S, int icomp=0);

    ~ULevelSettings();

    ULevelSettings&     operator=(const ULevelSettings& Lev);
    bool                operator==(const ULevelSettings& Lev) const;

    ErrorType           GetError(void)      const {if(this) return error;       return U_ERROR;}
    const UString&      GetProperties(UString Comment) const;
    bool                GetDoubleScale(void)const {if(this) return DoubleScale; return false;}
    ErrorType           SetDoubleScale(bool DoubScale) {if(this) {DoubleScale=DoubScale; return U_OK;} return U_ERROR;}

    UString             GetLevelSettings(UString Comment) const;
    ErrorType           SetLevelSettings(const UString& Properties, UString Comment);
    double              GetDminPhys(void)   const {if(DoubleScale) return DminPhys;  else return IminPhys;   }
    double              GetDmaxPhys(void)   const {if(DoubleScale) return DmaxPhys;  else return ImaxPhys;   }
    double              GetDminRange(void)  const {if(DoubleScale) return DminRange; else return IminRange;  }
    double              GetDmaxRange(void)  const {if(DoubleScale) return DmaxRange; else return ImaxRange;  }     
    double              GetDminActual(void) const {if(DoubleScale) return DminActual;else return IminActual; }
    double              GetDmaxActual(void) const {if(DoubleScale) return DmaxActual;else return ImaxActual; }

    int                 GetIminPhys(void)   const {return IminPhys;   }
    int                 GetImaxPhys(void)   const {return ImaxPhys;   }
    int                 GetIminRange(void)  const {return IminRange;  }
    int                 GetImaxRange(void)  const {return ImaxRange;  }
    int                 GetIminActual(void) const {return IminActual; }
    int                 GetImaxActual(void) const {return ImaxActual; }

    ErrorType           SetPalette(PaletteType Palette, bool ReversePal);
    ErrorType           SetPalette(bool ReversePal);
    ErrorType           SetPalette(int Index);
    int                 GetPaletteIndex(void) const;
    PaletteType         GetPaletteType(void) const {return PT;}
    bool                GetReversePalette(void) const {return ReversePalette;}

    ScaleType           GetScaleType(void) const {if(this) return ST; return U_SCALE_LIN;}
    ErrorType           SetScaleType(ScaleType Scale);

    ErrorType           SetActual(double NewMinAct, double NewMaxAct, bool UpdateRange);
    ErrorType           SetActual(int    NewMinAct, int    NewMaxAct, bool UpdateRange);
    ErrorType           SetRangeActual(double NewMinRan, double NewMaxRan, double NewMinAct, double NewMaxAct);
    ErrorType           SetRangeActual(int    NewMinRan, int    NewMaxRan, int    NewMinAct, int    NewMaxAct);

    ErrorType           ConvertToByteRange(unsigned char* Data, int Npoints) const;
    ErrorType           ConvertToByteRange(short*         Data, int Npoints) const;
    ErrorType           ConvertToByteRange(int*           Data, int Npoints) const;
    ErrorType           ConvertToByteRange(float*         Data, int Npoints) const;
    ErrorType           ConvertToByteRange(double*        Data, int Npoints) const;


    static const char*  LevSetBegin;
    static const char*  LevSetEnd;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
    static UString      Properties;

private:
    ErrorType           error;
    bool                DoubleScale;    // double range

    double              DminPhys;       // Physical range
    double              DmaxPhys;       // Physical range
    double              DminRange;      // Chosable range
    double              DmaxRange;     
    double              DminActual;     // Actual range
    double              DmaxActual;

    int                 IminPhys;       // Physical range
    int                 ImaxPhys;       // Physical range
    int                 IminRange;
    int                 ImaxRange;
    int                 IminActual;
    int                 ImaxActual;
    
    ScaleType           ST;             // Scale Type
    PaletteType         PT;
    bool                ReversePalette;
    bool                MaxAsBackground;

    ErrorType           AutoScale(double DMinDat, double DMaxDat, int IMinDat, int IMaxDat);
    ErrorType           TestRanges(bool ErrorsToLog) const;
    ErrorType           GetSafeMinMaxActual(double* Pmin, double* Pmax, double* LogPmin=NULL, double* LogPmax=NULL) const;
};

ULevelSettings DLL_IO Max(const ULevelSettings& a, const ULevelSettings& b);


#endif// _LEVELSETTINGS_INCLUDED


