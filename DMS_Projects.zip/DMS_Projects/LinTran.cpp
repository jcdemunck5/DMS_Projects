/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for maintaining linear transformations from R3 to R3.              */
/*                                                                               */
/*     ULinTran-objects can be created in different ways, multiplied, inverted   */
/*     and the can be used to transform objects like UVector3                    */
/*                                                                               */
/*                                                                               */
/*       ( _mat[0]     _mat[4]     _mat[ 8]  )    (  _mat[12] )                  */
/*  M =  ( _mat[1]     _mat[5]     _mat[ 9]  )  + (  _mat[13] )                  */
/*       ( _mat[2]     _mat[6]     _mat[10]  )    (  _mat[14] )                  */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    04-11-02   creation
  JdM    23-07-03   Added NoShift()
  JdM    04-01-04   bug fix: WriteXDR() nspace=2 (not 3)
  JdM    19-01-05   Implemented GetPropeties()
  JdM    19-11-08   Added GetShift() and ComputeRotScale() and operator+()
  JdM    17-01-10   Renamed Inverse() as GetInverse()
  JdM    24-08-10   Added SetNLR_CTF() and SetNLR_FIFF()
  JdM    09-02-14   Filename constructor. Test for "# AVS" and if not present, read as text file
JdM/Fab  06-01-15   Added FSL constructor (three float pointers and a double scaling)
  JdM    04-02-15   Added SetScaleTransform()
  JdM    04-02-15   Bug Fix: Filename constructor. When read as text file, matrix was transposed. Convert from mm to cm. Use code from UEuler
                    Added copy constructor.
JdM/Fab  18-03-15   Bug Fix: Filename constructor. Skip test whether some matrix elements are bigger than 1. in absolute value
  JdM    16-12-15   Renamed NoShift() as GetTransNoShift()
  JdM    26-12-15   Added SetMaxScalings()
*/

#include <stdlib.h>
#include <string.h>

#include "LinTran.h"
#include "Euler.h"
#include "String.h"

               
ULinTran::ULinTran()
/*
    The default ULinTran is the unity transform: no rotations and no translations.
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
}
ULinTran::ULinTran(const ULinTran& L)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;
    if(&L==NULL) return;

    for(int k=0; k<16; k++) _mat[k] = L._mat[k];
}

ULinTran::ULinTran(const double* par)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(par==NULL) return;

    _mat[ 0] = par[ 0];
    _mat[ 1] = par[ 1];
    _mat[ 2] = par[ 2];
    _mat[ 4] = par[ 3];
    _mat[ 5] = par[ 4];
    _mat[ 6] = par[ 5];
    _mat[ 8] = par[ 6];
    _mat[ 9] = par[ 7];
    _mat[10] = par[ 8];
    _mat[12] = par[ 9];
    _mat[13] = par[10];
    _mat[14] = par[11];
}

ULinTran::ULinTran(const UEuler& E, double Sx, double Sy, double Sz)
/*
   First scaling, then rotation, then translation
 */
{
    for(int k=0; k<16; k++) _mat[k] = E._mat[k];

    _mat[ 0] *= Sx;
    _mat[ 1] *= Sx;
    _mat[ 2] *= Sx;

    _mat[ 4] *= Sy;
    _mat[ 5] *= Sy;
    _mat[ 6] *= Sy;

    _mat[ 8] *= Sz;
    _mat[ 9] *= Sz;
    _mat[10] *= Sz;
}

ULinTran::ULinTran(const char* FileName)
/*
    Initialize EulerXfm by reading data from AVS5 .fld-file.
 */
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(FileName==NULL) return;
    FILE *fp=fopen(FileName,"rb");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: ULinTran::ULinTran(). Cannot open: %s \n", FileName);
        return;
    }
    char line[200];
    fread(line, 1, sizeof(line), fp);
    rewind(fp);
    if(!strncmp(line, "# AVS", sizeof("# AVS")-1))
    {
        char cp1 = getc(fp);
        char cp2 = getc(fp);
        while(cp1!=12 || cp2!=12)
        {
            cp1 = cp2;
            cp2 = char(getc(fp));
            if(cp2==EOF)
            {
                CI.AddToLog("ERROR: ULinTran::ULinTran(). Erroneous xdr-file : %s",FileName);
                return;
            }
        }

        if(INTEL_PROCESSOR()==true)
        {
            for(int k=0; k<16; k++)
            {
                unsigned char sw[4], dum;
                fread((void*)sw, 4, 1, fp);
                dum     = sw[3];
                sw[3]   = sw[0];
                sw[0]   = dum;
                dum     = sw[2];
                sw[2]   = sw[1];
                sw[1]   = dum;
                _mat[k] = *(float*)sw;
            }
        }
        else
        {
            for(int k=0; k<16; k++)
            {
                float elem;
                fread(&elem, 1, 4, fp);
                _mat[k] = elem;
            }
        }
        fclose(fp);
        return;
    }

    bool      CaseSense = true;
    if(UFileName(FileName).HasExtension("mat", CaseSense)) // FSL .mat files
    {
        ErrorType E  = U_OK;

        for(int i=0; i<3; i++)
        {
            GetLine(line, sizeof(line)-1, fp);
            UString S(line);
            for(int j=0, off=0; j<4; j++)
            {
                int       nc   = 0;
                double    Elem = S.GetDouble(off, 1000., &E, &nc);                
                if( E!=U_OK)
                {
                    CI.AddToLog("ERROR: ULinTran::ULinTran(). Reading transform as mat file (i=%d, j=%d, elem=%f)\n", i, j, Elem);
                    break;
                }
                off += nc;
                if (j<3)   _mat[4*j+i] = Elem;
                else       _mat[4*j+i] = Elem/10.;
            }
            if(E!=U_OK) break;
        }
    }
    else /* Read as text file */
    {
        ErrorType E  = U_OK;
        for(int i=0; i<3; i++)
        {
            GetLine(line, sizeof(line)-1, fp);
            UString S(line);
            for(int j=0, off=0; j<4; j++)
            {
                int       nc   = 0;
                double    Elem = S.GetDouble(off, 1000., &E, &nc);                
                if(E!=U_OK)
                {
                    CI.AddToLog("ERROR: ULinTran::ULinTran(). Reading transform as text file (i=%d, j=%d, elem=%f)\n", i, j, Elem);
                    break;
                }
                off += nc;
                _mat[4*i+j] = Elem;
            }
            if(E!=U_OK) break;
        }
    }
    fclose(fp);
}
ULinTran::ULinTran(const float* Sx, const float* Sy, const float* Sz, double DistUnitFactor)
{
    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    if(Sx==NULL || Sy==NULL || Sz==NULL)
    {
        CI.AddToLog("ERROR: ULinTran::ULinTran(). Invalid NULL pointer argument(s) \n");
        return;
    }
    if(DistUnitFactor==0.)
    {
        CI.AddToLog("ERROR: ULinTran::ULinTran(). Invalid 0. argument %f \n", DistUnitFactor);
        return;
    }

    for(int k=0; k<4; k++)
    {
        _mat[k*4  ] = Sx[k]*DistUnitFactor; 
        _mat[k*4+1] = Sy[k]*DistUnitFactor; 
        _mat[k*4+2] = Sz[k]*DistUnitFactor;
    }
}

ErrorType ULinTran::SetScaleTransform(double Sx, double Sy, double Sz)
{
    if(this==NULL) return U_ERROR;

    _mat[ 1] = _mat[ 2] = _mat[ 3] =
    _mat[ 4] = _mat[ 6] = _mat[ 7] =
    _mat[ 8] = _mat[ 9] = _mat[11] =
    _mat[12] = _mat[13] = _mat[14] = 0;
    _mat[ 0] = _mat[ 5] = _mat[10] = _mat[15] = 1;

    _mat[ 0] = Sx;
    _mat[ 5] = Sy;
    _mat[10] = Sz;

    return U_OK;
}
ErrorType ULinTran::SetMaxScalings(double Sx, double Sy, double Sz)
{
    if(this==NULL) return U_ERROR;
    if(Sx<0) {CI.AddToLog("ERROR: ULinTran::SetMaxScalings(). Sx (=%f) out of range. \n", Sx); return U_ERROR;}
    if(Sy<0) {CI.AddToLog("ERROR: ULinTran::SetMaxScalings(). Sy (=%f) out of range. \n", Sy); return U_ERROR;}
    if(Sz<0) {CI.AddToLog("ERROR: ULinTran::SetMaxScalings(). Sz (=%f) out of range. \n", Sz); return U_ERROR;}

    double Mat[9] = {_mat[0],_mat[4],_mat[ 8],
                     _mat[1],_mat[5],_mat[ 9],
                     _mat[2],_mat[6],_mat[10]};
    double Lam[3] = {0.,0.,0.};
    double VV [9] = {0.,0.,0.,0.,0.,0.,0.,0.,0.};

    svdcmp_d(Mat, 3, 3, Lam, VV);
    Lam[0] = MIN(Lam[0], Sx);
    Lam[1] = MIN(Lam[1], Sy);
    Lam[2] = MIN(Lam[2], Sz);

    for(int k=0; k<3; k++)
        for(int i=0; i<3; i++) 
        {
            _mat[k+4*i] = 0.;
            for(int n=0; n<3; n++) _mat[k+4*i] += Lam[n] * Mat[3*k+n] * VV[3*i+n];
        }

    return U_OK;
}

ErrorType ULinTran::SetNLR_CTF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right)
{
    if(this==NULL) return U_ERROR;

    UEuler XFM; XFM.SetNLR_CTF(Nasion, Left, Right);
    *this = XFM;
    return U_OK;
}
ErrorType ULinTran::SetNLR_FIFF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right)
{
    if(this==NULL) return U_ERROR;

    UEuler XFM; XFM.SetNLR_FIFF(Nasion, Left, Right);
    *this = XFM;
    return U_OK;
}

double ULinTran::GetDeterminant(void) const
{
    return   _mat[ 0]*_mat[ 5]*_mat[10] + _mat[ 4]*_mat[ 9]*_mat[ 2] + _mat[ 8]*_mat[ 1]*_mat[ 6] 
           - _mat[ 0]*_mat[ 9]*_mat[ 6] - _mat[ 4]*_mat[ 1]*_mat[10] - _mat[ 8]*_mat[ 5]*_mat[ 2];
}

UVector3 ULinTran::GetShift(void) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: ULinTran::GetShift(). Object NULL or erroneous. \n");
        return UVector3();
    }
    return UVector3(_mat[12], _mat[13], _mat[14]);
}
ErrorType ULinTran::ComputeRotScale(double* MaxR1, double* MaxR2, double* Lam0, double* Lam1, double* Lam2) const
{
    if(this==NULL || _mat==NULL)
    {
        CI.AddToLog("ERROR: ULinTran::ComputeRotScale(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    double Mat[9], V[9], L[3] = {1.,1.,1.};

    Mat[0] = _mat[ 0];   V[0] = 1; 
    Mat[1] = _mat[ 1];   V[1] = 0;
    Mat[2] = _mat[ 2];   V[2] = 0;
    Mat[3] = _mat[ 4];   V[3] = 0;
    Mat[4] = _mat[ 5];   V[4] = 1;
    Mat[5] = _mat[ 6];   V[5] = 0;
    Mat[6] = _mat[ 8];   V[6] = 0;
    Mat[7] = _mat[ 9];   V[7] = 0;
    Mat[8] = _mat[10];   V[8] = 1;

    if(svdcmp_d(Mat, 3, 3, L, V)!=0)
    {
        CI.AddToLog("ERROR: ULinTran::ComputeRotScale(). Computing SVD of transformation matrix. \n");
        return U_ERROR;
    }

    if(MaxR1)
    {
        double Cosom = (Mat[0]+Mat[4]+Mat[8]-1)/2;
        if(Cosom<=-1.) Cosom = -1.;
        if(Cosom>= 1.) Cosom =  1.;

        *MaxR1 = acos(Cosom);
    }
    if(MaxR2)
    {
        double Cosom = (V[0]+V[4]+V[8]-1)/2;
        if(Cosom<=-1.) Cosom = -1.;
        if(Cosom>= 1.) Cosom =  1.;

        *MaxR2 = acos(Cosom);
    }
    if(Lam0) *Lam0 = L[0];
    if(Lam1) *Lam1 = L[1];
    if(Lam2) *Lam2 = L[2];

    return U_OK;
}

ErrorType ULinTran::Mirror(int idir)
/* 
    Mirror the transformation in the direction idir
 */
{
    switch(idir)
    {
    case 0:
        _mat[ 0] = -_mat[ 0];
        _mat[ 4] = -_mat[ 4];
        _mat[ 8] = -_mat[ 8];
        _mat[12] = -_mat[12];
        return U_OK;
    case 1:
        _mat[ 1] = -_mat[ 1];
        _mat[ 5] = -_mat[ 5];
        _mat[ 9] = -_mat[ 9];
        _mat[13] = -_mat[13];
        return U_OK;
    case 2:
        _mat[ 2] = -_mat[ 2];
        _mat[ 6] = -_mat[ 6];
        _mat[10] = -_mat[10];
        _mat[14] = -_mat[14];
        return U_OK;
    }    
    CI.AddToLog("ERROR: ULinTran::Mirror(). Erroneous input parameter (%d) .\n",idir);
    return U_ERROR;
}


ULinTran ULinTran::operator*(const ULinTran& b) const
/*   
     Return *this *  b
 */
{
    ULinTran result;

    int ij=0;
    for(int i=0; i<4; i++)
        for(int j=0; j<4; j++,ij++)
        {
            result._mat[ij] = 0;
            for(int k=0;k<4;k++) result._mat[4*i+j] += _mat[4*k+j]*b._mat[4*i+k];
        }

    return result;
}
ULinTran ULinTran::operator+(const ULinTran& b) const
/*   
     Return *this +  b
 */
{
    ULinTran result;

    for(int ij=0; ij<16; ij++)
        result._mat[ij] = _mat[ij] + b._mat[ij];

    return result;
}


ULinTran ULinTran::operator*(const UEuler& b) const
/*   
     Return *this *  b
 */
{
    ULinTran result;

    int ij=0;
    for(int i=0; i<4; i++)
        for(int j=0; j<4; j++,ij++)
        {
            result._mat[ij] = 0;
            for(int k=0;k<4;k++) result._mat[4*i+j] += _mat[4*k+j]*b._mat[4*i+k];
        }

    return result;
}
ULinTran ULinTran::operator+(const UEuler& b) const
/*   
     Return *this +  b
 */
{
    ULinTran result;

    for(int ij=0; ij<16; ij++)
        result._mat[ij] = _mat[ij] + b._mat[ij];

    return result;
}


ULinTran& ULinTran::operator=(const ULinTran& e)
{
    for(int k=0; k<16; k++) _mat[k] = e._mat[k];
    return *this;
}

bool ULinTran::operator==(const ULinTran& e) const
{
    const double TOL = 1.e-6;
    for(int ij=0; ij<16; ij++) 
        if(fabs(_mat[ij]-e._mat[ij])>TOL) return false;

    return true;
}


ULinTran ULinTran::GetInverse(void) const
/* 
    return the inverse of *this
 */
{
    ULinTran Inv = *this;
    Inv.Invert();
    return Inv;
}

ULinTran ULinTran::Invert(void)
/*
     Replace the Euler transform by its inverse, return *this.
 */
{
    double det = _mat[ 0]*_mat[ 5]*_mat[10] + _mat[ 4]*_mat[ 9]*_mat[ 2] + _mat[ 8]*_mat[ 1]*_mat[ 6] 
               - _mat[ 0]*_mat[ 9]*_mat[ 6] - _mat[ 4]*_mat[ 1]*_mat[10] - _mat[ 8]*_mat[ 5]*_mat[ 2];

    if(fabs(det)<1.e-10) det = 1;

    double inv[16];
    inv[ 0] = ( _mat[ 5]*_mat[10] - _mat[ 9]*_mat[ 6])/det;
    inv[ 1] = ( _mat[ 9]*_mat[ 2] - _mat[ 1]*_mat[10])/det;
    inv[ 2] = ( _mat[ 1]*_mat[ 6] - _mat[ 5]*_mat[ 2])/det;
    inv[ 3] = 0.;
    inv[ 4] = ( _mat[ 6]*_mat[ 8] - _mat[10]*_mat[ 4])/det;
    inv[ 5] = ( _mat[10]*_mat[ 0] - _mat[ 2]*_mat[ 8])/det;
    inv[ 6] = ( _mat[ 2]*_mat[ 4] - _mat[ 0]*_mat[ 6])/det;
    inv[ 7] = 0.;
    inv[ 8] = ( _mat[ 4]*_mat[ 9] - _mat[ 8]*_mat[ 5])/det;
    inv[ 9] = ( _mat[ 8]*_mat[ 1] - _mat[ 0]*_mat[ 9])/det;
    inv[10] = ( _mat[ 0]*_mat[ 5] - _mat[ 4]*_mat[ 1])/det;
    inv[11] = 0.;
    inv[12] =-( inv[ 0]*_mat[12] + inv[ 4]*_mat[13] + inv[ 8]*_mat[14] );
    inv[13] =-( inv[ 1]*_mat[12] + inv[ 5]*_mat[13] + inv[ 9]*_mat[14] );
    inv[14] =-( inv[ 2]*_mat[12] + inv[ 6]*_mat[13] + inv[10]*_mat[14] );
    inv[15] = 1.;

    for(int k=0; k<16; k++) _mat[k] = inv[k];
    return *this;
}

ULinTran ULinTran::GetTransNoShift(void) const
{
    ULinTran NoS = *this;
    NoS._mat[12] = NoS._mat[13] = NoS._mat[14] = 0;
    return NoS;
}

UVector3 ULinTran::xfm(const UVector3 &v, bool Notrans) const
/*
     return a transformed vector.
 */
{
    double xa,ya,za;
    if(Notrans==true)
    {
        xa = v.Getx() *_mat[0] +  v.Gety() *_mat[4] +  v.Getz() *_mat[ 8];
        ya = v.Getx() *_mat[1] +  v.Gety() *_mat[5] +  v.Getz() *_mat[ 9];
        za = v.Getx() *_mat[2] +  v.Gety() *_mat[6] +  v.Getz() *_mat[10];
    }
    else
    {
        xa = v.Getx() *_mat[0] +  v.Gety() *_mat[4] +  v.Getz() *_mat[ 8] + _mat[12];
        ya = v.Getx() *_mat[1] +  v.Gety() *_mat[5] +  v.Getz() *_mat[ 9] + _mat[13];
        za = v.Getx() *_mat[2] +  v.Gety() *_mat[6] +  v.Getz() *_mat[10] + _mat[14];
    }
    
    return UVector3(xa,ya,za);
}

UVector3 ULinTran::xfmInv(const UVector3 &v, bool Notrans) const
/*
   Return the inverse of *this applied to v.
 */
{
    ULinTran INV = this->GetInverse();
    return INV.xfm(v, Notrans);
}

char*  ULinTran::PrintMatrix(void) const
{
    static char line[120];
    memset(line, 0, 100);
    
    sprintf(line,"(%7.4f,%7.4f,%7.4f,   %7.4f) \n(%7.4f,%7.4f,%7.4f,   %7.4f) \n(%7.4f,%7.4f,%7.4f,   %7.4f) \n",
        _mat[0],_mat[4],_mat[ 8],_mat[12],
        _mat[1],_mat[5],_mat[ 9],_mat[13],
        _mat[2],_mat[6],_mat[10],_mat[14]);
    return line;
}

ErrorType ULinTran::PrintParameters(double* par) const
{
    if(par==NULL) 
    {
        CI.AddToLog("ERROR: ULinTran::PrintParameters(). Invalid NULL pointer. ");
        return U_ERROR;
    }

    par[ 0] = _mat[ 0]; 
    par[ 1] = _mat[ 1]; 
    par[ 2] = _mat[ 2]; 
    par[ 3] = _mat[ 4]; 
    par[ 4] = _mat[ 5]; 
    par[ 5] = _mat[ 6]; 
    par[ 6] = _mat[ 8]; 
    par[ 7] = _mat[ 9]; 
    par[ 8] = _mat[10]; 
    par[ 9] = _mat[12]; 
    par[10] = _mat[13]; 
    par[11] = _mat[14]; 

    return U_OK;
}

#define MAXPROPERTIES 400
const char* ULinTran::GetProperties(const char* Comment) const
{
    static char Properties[MAXPROPERTIES];
    char Begin[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    if(Comment) strncpy(Begin, Comment,15);

    char End        = ';';
    if(Comment) End = '\n';
    memset(Properties,0,MAXPROPERTIES);

    int nc = 0;
    nc += sprintf(Properties+nc,"%s Rotation                       Translation%c", Begin, End);
    nc += sprintf(Properties+nc,"%s %f\t %f\t %f\t %f%c", Begin, _mat[ 0],  _mat[ 4],  _mat[ 8],  _mat[12], End);
    nc += sprintf(Properties+nc,"%s %f\t %f\t %f\t %f%c", Begin, _mat[ 1],  _mat[ 5],  _mat[ 9],  _mat[13], End);
    nc += sprintf(Properties+nc,"%s %f\t %f\t %f\t %f%c", Begin, _mat[ 2],  _mat[ 6],  _mat[10],  _mat[14], End);
    nc += sprintf(Properties+nc,"%s %f\t %f\t %f\t %f%c", Begin, _mat[ 3],  _mat[ 7],  _mat[11],  _mat[15], End);
    

    if(nc>=MAXPROPERTIES)
        CI.AddToLog("ERROR: ULinTran::GetProperties(). Array overflow: nc=%d .\n",nc);

    return Properties;
}
#undef MAXPROPERTIES


ErrorType ULinTran::WriteXDR(const char *FileName) const
/*
      Export the Euler transform in AVS  xdr-format.
 */
{
    FILE *fp=fopen(FileName,"wb");
    if(fp==NULL) return U_ERROR;

    fprintf(fp,"# AVS File created by an ULinTran-object.\n");
    fprintf(fp,"%s",CI.GetProperties("# "));
    fprintf(fp,"# \n");
    fprintf(fp,"# \n");
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 0],  _mat[ 1],  _mat[ 2],  _mat[ 3]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 4],  _mat[ 5],  _mat[ 6],  _mat[ 7]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[ 8],  _mat[ 9],  _mat[10],  _mat[11]);
    fprintf(fp,"# %f\t %f\t %f\t %f\n", _mat[12],  _mat[13],  _mat[14],  _mat[15]);
    fprintf(fp,"# \n");
    fprintf(fp,"ndim=2          # number of dimensions in the field\n");
    fprintf(fp,"dim1=4          # dimension of axis 1\n");
    fprintf(fp,"dim2=4          # dimension of axis 2\n");
    fprintf(fp,"nspace=2        # number of physical coordinates per point\n");
    fprintf(fp,"veclen=1        # number of components at each point\n");
    fprintf(fp,"data=xdr_float  # portable data format\n");
    fprintf(fp,"field=uniform   # field type (uniform, rectilinear, irregular)\n");
    fprintf(fp,"%c%c",12,12);


    if(INTEL_PROCESSOR()==true)
    {
        for(int k=0; k<16; k++) 
        {
            unsigned char sw[4], dum;
            float elem = float(_mat[k]);
            memcpy(sw, &elem , 4);
            dum     = sw[3];
            sw[3]   = sw[0];
            sw[0]   = dum;
            dum     = sw[2];
            sw[2]   = sw[1];
            sw[1]   = dum;
            fwrite((void*)sw, 4, 1, fp);
        }
    }
    else
    {
        for(int k=0; k<16; k++) 
        {
            float elem = float(_mat[k]);
            fwrite(&elem, 1, 4, fp);
        }
    }
    for(int k=0; k<6; k++) fwrite((void*)&k, 4, 1, fp);  // Coordinate information has no meaning, but must be present
    fclose(fp);

    return U_OK;
}

