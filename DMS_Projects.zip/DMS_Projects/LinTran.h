#ifndef _LINTRAN_INCLUDED
#define _LINTRAN_INCLUDED

#include "MatVec.h"

class UEuler;

class DLL_IO ULinTran
{
    friend class UEuler;

public:
    ULinTran();
    ULinTran(const ULinTran& e);
    ULinTran(const UEuler& E, double Sx=1.0, double Sy=1.0, double Sz=1.0);
    ULinTran(const float* Sx, const float* Sy, const float* Sz, double DistUnitFactor);
    ULinTran(const char* FileName);
    ULinTran(const double* par);

    ULinTran&        operator=(const ULinTran& e);
    ULinTran         operator*(const ULinTran& b) const;
    ULinTran         operator*(const UEuler& b) const;
    ULinTran         operator+(const ULinTran& b) const;
    ULinTran         operator+(const UEuler& b) const;
    bool             operator==(const ULinTran& e) const; 

    ErrorType        SetNLR_CTF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right);
    ErrorType        SetNLR_FIFF(const UVector3& Nasion, const UVector3& Left, const UVector3& Right);
    ErrorType        SetScaleTransform(double Sx, double Sy, double Sz);
    ErrorType        SetMaxScalings(double Sx, double Sy, double Sz);

    double           GetDeterminant(void) const;
    UVector3         GetShift(void) const;
    ErrorType        ComputeRotScale(double* MaxR1, double* MaxR2, double* Lam0, double* Lam1, double* Lam2) const;

    ErrorType        Mirror(int idir);
    ULinTran         GetInverse(void) const;
    ULinTran         Invert(void);

    ULinTran         GetTransNoShift(void) const;
    UVector3         xfm(const UVector3 &v, bool Notrans=false) const;    
    UVector3         xfmInv(const UVector3 &v, bool Notrans=false) const;    
    const char*      GetProperties(const char* Comment) const;
    char*            PrintMatrix(void) const;
    ErrorType        PrintParameters(double* par) const;

    ErrorType        WriteXDR(const char *FileName) const; 
    void             InitRandom(int init=(unsigned)time( NULL ));
private:
    double           _mat[16];
};
#endif// _LINTRAN_INCLUDED
