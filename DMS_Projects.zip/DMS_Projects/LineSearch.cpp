/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    10-04-16   creation
 */

#include <math.h>
#include"LineSearch.h"


void ULineSearch::SetAllMembersDefault(void)
{
    error   =  U_OK;
    Npar    =  0;
    MaxIter = -1; // No max
    LamMax  =  1.;
}
void ULineSearch::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

ULineSearch::ULineSearch()
{
    SetAllMembersDefault();
}
ULineSearch::ULineSearch(int NP)
{
    SetAllMembersDefault();
    if(NP<=0)
    {
        CI.AddToLog("ERROR: ULineSearch::ULineSearch(). NP = %d.\n", NP);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Npar = NP;
}
ULineSearch::~ULineSearch()
{
    DeleteAllMembers(U_OK);
}
ULineSearch& ULineSearch::operator=(const ULineSearch &LS)
{
    if(this==NULL)
    {
        static ULineSearch L; L.error = U_ERROR;
        CI.AddToLog("ERROR: ULineSearch::operator=(). Object NULL.\n");
        return L;
    }
    if(&LS==NULL || LS.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULineSearch::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }

    if(this==&LS) return *this;

    DeleteAllMembers(U_OK);
    Npar    = LS.Npar;
    MaxIter = LS.MaxIter;
    LamMax  = LS.LamMax;
    return *this;
}
ErrorType ULineSearch::SetMaxIter(int Niter)
{
    if(this==NULL) return U_ERROR;
    MaxIter = Niter;
    return U_OK;
}
ErrorType ULineSearch::SetMaxStep(double Lmax)
{
    if(this==NULL) return U_ERROR;
    if(Lmax<=0.)
    {
        CI.AddToLog("ULineSearch::SetMaxStep(). Invalid argument: Lmax = %f \n", Lmax);
        return U_ERROR;
    }
    LamMax = Lmax;
    return U_OK;
}

double* ULineSearch::GetLineSearch(const double* Par0, double Cost0, const double* Grad0, double* Dir0) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Npar<=0)
    {
        CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Npar = %d.\n", Npar);
        return NULL;
    }
    if(Par0==NULL || Grad0==NULL)
    {
        CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Invalid NULL argument.\n");
        return NULL;
    }
    if(LamMax<=0.)
    {
        CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Invalid argument, LamMax = %f .\n", LamMax);
        return NULL;
    }
    double* Pnew = new double[Npar];
    if(Pnew==NULL)
    {
        CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Memory allocation, Npar = %d .\n", Npar);
        return NULL;
    }
    for(int i=0; i<Npar; i++) Pnew[i] = 0.;
    double* Dir = Dir0;
    if(Dir==NULL)
    {
        Dir = new double[Npar];
        if(Dir==NULL)
        {
            delete[] Pnew; 
            CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Memory allocation. Dir. Npar = %d .\n", Npar);
            return NULL;
        }
        for(int i=0; i<Npar; i++) Dir[i] = -Grad0[i];
    }

    const double ALF  = 1.0e-4;
    const double TOLX = 10.e-14;

    double sum   = 0.0;
    for(int i=0; i<Npar; i++) sum += Dir[i]*Dir[i];
    if(sum>0.)      sum = sqrt(sum);
    
    if(sum>LamMax) for(int i=0; i<Npar; i++) Dir[i] *= LamMax/sum;

    double slope=0.0;
    for(int i=0;i<Npar;i++)    slope += Grad0[i]*Dir [i];
    if(slope >= 0.0)
    {
        delete[] Pnew; if(Dir0==NULL) delete[] Dir;
        CI.AddToLog("ERROR: ULineSearch::GetLineSearch(). Roundoff problem.\n");
        return NULL;
    }
    double test=0.0;
    for(int i=0;i<Npar;i++) 
    {
        double temp = fabs(Dir[i])/MAX(fabs(Par0[i]),1.0);
        if(temp>test) test=temp;
    }

    double alamin = TOLX/test;
    double alam   = 1.0;
    double alam2  = 0.0;
    double tmplam = 0.;
    double Cost2  = 0.;
    for(int iter=0; iter<MaxIter; iter++)
    {
        for(int i=0; i<Npar; i++) Pnew[i] = Par0[i] + alam*Dir[i];
        
        double Cost = ComputeCost(Pnew);
        if(alam<alamin) 
        {
            for(int i=0; i<Npar; i++) Pnew[i] = Par0[i];
            if(Dir0==NULL) delete[] Dir;
            return Pnew;
        } 
        else if(Cost <= Cost0+ALF*alam*slope) 
        {
            if(Dir0==NULL) delete[] Dir;
            return Pnew;
        }
        else 
        {
            if(alam==1.0)
            {
                tmplam = -slope/(2.0*(Cost-Cost0-slope));
            }
            else 
            {
                double rhs1 = Cost  -Cost0-alam *slope;
                double rhs2 = Cost2 -Cost0-alam2*slope;
                double a    =(rhs1/(alam*alam)-rhs2/(alam2*alam2))/(alam-alam2);
                double b    =(-alam2*rhs1/(alam*alam)+alam*rhs2/(alam2*alam2))/(alam-alam2);
                if(a==0.0) 
                {
                    tmplam = -slope/(2.0*b);
                }
                else 
                {
                    double disc=b*b-3.0*a*slope;
                    if     (disc < 0.0) tmplam = 0.5*alam;
                    else if(b   <= 0.0) tmplam = (-b+sqrt(disc))/(3.0*a);
                    else                tmplam =-slope/(b+sqrt(disc));
                }
                if(tmplam>0.5*alam) tmplam=0.5*alam;
            }
        }
        alam2 = alam;
        Cost2 = Cost;
        alam  = MAX(tmplam,0.1*alam);
    }

    for(int i=0; i<Npar; i++) Pnew[i] = Par0[i] + alam*Dir[i];
    if(Dir0==NULL) delete[] Dir;
    return Pnew;
}

double ULineSearch::ComputeCost(const double* Par) const
{
    CI.AddToLog("ERROR: ULineSearch::ComputeCost(). virtual function not implemented in derived class.\n");
    return 0.;
}

