#ifndef _LINESEARCH_INCLUDED
#define _LINESEARCH_INCLUDED

#include"BasicInclude.h"

class DLL_IO ULineSearch
{
public:
    ULineSearch();
    ULineSearch(int NP);
    ~ULineSearch();
    ULineSearch& operator=(const ULineSearch &LS);

    ErrorType               SetMaxIter(int Niter);
    ErrorType               SetMaxStep(double Lmax);
    double*                 GetLineSearch(const double* Par0, double Cost0, const double* Grad0, double* Dir0=NULL) const;

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;
    int                     Npar;
    int                     MaxIter;
    double                  LamMax;

    virtual double          ComputeCost(const double* Par) const;
};

#endif// _LINESEARCH_INCLUDED
