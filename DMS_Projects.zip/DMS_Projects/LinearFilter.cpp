/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for computing filtering data, linearly.                            */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    25-01-99   creation
 JdM/AdJ 11-02-99   BUGfix: make band-paas filter, instead of notch
  ADJ    18-02-99   BUGfix: make band-pass filter filter
  JdM    07-04-99   Added GetProperties() and related parameters
JdM/AdJ  15-06-99   IMPORTANT BUG FIX: in older version the filter frequencies corresponded 
                    to half the frequencies that were applied in practice.
  JdM    15-06-99   Added SVD filter
  JdM    27-06-99   Added cosine window, in combination with EDGE filtering: EDGE_COS
JdM/AdJ  07-09-99   Divide filtered result by window function
  JdM    08-09-99   Use FFTW as Fourier Transforms
  JdM    10-09-99   Added sine-window
  JdM    06-10-99   IMPORTANT BUG FIX: With linear, time invariant filtering, window
                    the impulse response, instead of the data.
  JdM    19-10-99   Increase nFour until it is a product of small prime numbers
                    Added option to pre-process the data (offset and trend-removal)
  JdM    20-10-99   Bug Fix: Skip leading and ending zeroes.
  JdM    29-10-99   Lay out of GetProperties()
  JdM    26-11-99   Bug fix : SVD-filter (Filt-parameter was not set).
                              SVD-filter, renormalizing the data!!! (error + writing out of array boundaries)
  JdM    13-12-99   Bug Fix : Linear Fourier filter: Incorrect loop indices, when nFour == odd.
  JdM    25-01-00   Print out the relative strengths of the singular values, in case of SVD filter.
  JdM    07-02-00   made some members constant
  JdM    11-04-00   Remove some of the output. Test Fmin and Fmax for the band pass filter
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    15-11-00   SetFilter(). Treatment of values that are out of range.
  JdM    24-11-00   Bug Fix in scaling FirstSDVComp[]
  JdM    08-12-00   PreProcess() allow for separate pre-processing window
  JdM    06-04-01   BUG fix: PreProcess(). Trend-removal in case of leading zeroes: correct for jb
 JdM/FB  04-07-01   SetFilter(), add new function, remove default arguments from old SetFilter() functions
 JdM/FB  28-09-01   BUG FIX: PreProcess(). Skipping leading and ending zeroes.
 AdJ/JdM 23-01-02   BUG FIX: PreProcess(). Keeping leading and ending zeroes on zero!!.
  JdM    29-01-02   Made FFTW plans (private) members, such that they can be re-used (use FFTW_MEASURE)
 FB/JdM  11-02-02   BUG FIX: PreProcess(). When pre-process window is different from data window,
                    not all points are pre-processed. In bug fix use new function FindNonZeroes().
  JdM    26-02-02   Made NIMPULS public
  JdM    13-06-02   FindNonZeroes(). export skipped samples
  JdM    20-06-02   operator=(). Dealing with exising FFT plans, deleting and creating FirstSDVComp[]
  JdM    24-06-02   Major update. Derive ULinearFilter from UConvolve (containing all FFT's)
  JdM    05-07-02   Make Himp a local variable of SetFilter()
  JdM    07-07-02   Made NIMPULS a local variable of SetFilter()
  JdM    08-07-02   Allow the removal of the 50 Hz power line noise,
                    Make clear distinction between window function, power line and bandpass filtering.
                    Rename enums.
  JdM    17-09-02   Use certain band width for powerline removal
                    Added public constants: NIMPULS_POWERLINE and NIMPULS_BANDPASS
  JdM    21-11-02   Add AddStopBand()
  JdM    27-11-02   Made Filter lengths adaptive to sample frequency
  JdM    08-05-03   Added InterpolateEpoch()
  JdM    26-01-04   Limited the number of warnings in PreProcess()
  JdM    19-02-04   Added static GetWindowProfile(). Use this function, made enum WindowType global.
  JdM    25-04-04   Added default constructor (f=1 Hz.)
  JdM    04-07-04   Added SetAllMembersDefault(), DeleteAllMembers() and copy constructor 
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
JdM/SG   18-05-05   Bug fix: GetError(). Prevent infinite loop (return UConvolve::GetError())
  JdM    19-06-05   ApplyWindow(). Remove last argument (WindowType), and allow NULL pointer window
  JdM    24-11-05   PreProcess(). Do not return error when pre-processing window is identically zero. Just launch warning.
                    FindNonZeroes(). Do not return error when pre-processing window is identically zero. Remove error messages.
  JdM    12-01-06   PreProcess(). Reduce number of messages.
  JdM    30-01-06   ApplyWindow(), added pre-processing parameter. Defined UFilterType, and UPreProType outside object
  JdM    17-11-06   SetFilter(): Add Window parameter
                    GetProperties(): Use Ustring, update content
  JdM    07-03-07   Bug fix PreProcess(): testing end sample window (nsP instead of nsamp). This fix avoids WARINGS
  JdM    10-12-07   SetPowerLineFilter(). Quadripled PLhWidth, doubled DEFPOWERLINEWIDTH
  JdM    19-12-07   SetPowerFilter(). Added parameter to set the powerlint stopbabf width. 
                    SetPowerLineFilter().  Changed meaning of argument.
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    21-03-15   Moved GetWindowProfile() to BasicInclude.cpp
  JdM    04-08-15   Added UPowerLineType to distinguish between 50. and 60. Hz powerline removal
                    SetFilter(): removed obsolete EpTime_s parameter
*/


#include <string.h>
#include <math.h>

#include "LinearFilter.h"

/* Inititalize static const parameters. */
const double ULinearFilter::ALFA              =   0.54;
const double ULinearFilter::BETA              =   4.; //2.;
const int    ULinearFilter::FIRST_NCOMP_SVD   =   6;
UString      ULinearFilter::Properties        = UString();


#define DEFPOWERLINEWIDTH 4.  // Default Power line half-width in Hz

void ULinearFilter::SetAllMembersDefault(void)
{
    error             = U_OK;
    NIMPULS_POWERLINE = 1023;  // The default values
    NIMPULS_BANDPASS  = 1023;
    NIMPULS_BANDSTOP  = 1023;

    SampleRate        = 1.;
    NStopBand         = 0;
    Filt              = U_FILT_NOTYPE;
    Wind              = U_WIN_BLOCK;
    Prep              = U_PREP_NO;
    PowerLine         = U_POWERLINE_NO;
    Fmin              = 0.;
    Fmax              = 0.;
    Ncomp             = 0;
    PowerLineWidth    = DEFPOWERLINEWIDTH;

    FirstSDVComp      = NULL;
    Properties        = UString();
}

void ULinearFilter::DeleteAllMembers(ErrorType E)
{
    delete[]  FirstSDVComp;
    SetAllMembersDefault();
    error = E;
}

ULinearFilter::ULinearFilter() : UConvolve()
{
    SetAllMembersDefault();
    FirstSDVComp = new double[FIRST_NCOMP_SVD];

    if(FirstSDVComp==NULL)
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::ULinearFilter(). Memory allocation. \n");
        return;
    }

    for(int k=0; k<FIRST_NCOMP_SVD; k++)  FirstSDVComp[k]=0.;
}                

ULinearFilter::ULinearFilter(double sRate) : UConvolve()
{
    SetAllMembersDefault();
    FirstSDVComp = new double[FIRST_NCOMP_SVD];

    if(FirstSDVComp==NULL)
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::ULinearFilter(). Memory allocation. \n");
        return;
    }

    for(int k=0; k<FIRST_NCOMP_SVD; k++)  FirstSDVComp[k]=0.;
  
    SampleRate   = sRate;
    if(SampleRate>0.) 
        SetFilterWindow_s(1.);
}                

ULinearFilter::ULinearFilter(const ULinearFilter& f) : 
    UConvolve((UConvolve) f)
{
    SetAllMembersDefault();
    *this = f;
}

ULinearFilter::~ULinearFilter()
{
    DeleteAllMembers(U_OK);
}                

ULinearFilter& ULinearFilter::operator=(const ULinearFilter& f)
{
    if(this==NULL)
    {
        static ULinearFilter F; F.error = U_ERROR;
        return F;
    }
    if(&f==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&f) return *this;

    UConvolve::operator=((UConvolve)f);  // copy base class
    if( UConvolve::GetError() != U_OK)
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::operator=(). Copying base class.\n");
        return *this;
    }

    SampleRate        = f.SampleRate;
    NStopBand         = f.NStopBand;
    Filt              = f.Filt;  
    Wind              = f.Wind;  
    Prep              = f.Prep;
    PowerLine         = f.PowerLine;
    Fmin              = f.Fmin;      
    Fmax              = f.Fmax;   
    PowerLineWidth    = f.PowerLineWidth;

    Ncomp             = f.Ncomp; 
    NIMPULS_POWERLINE = f.NIMPULS_POWERLINE;
    NIMPULS_BANDPASS  = f.NIMPULS_BANDPASS;
    NIMPULS_BANDSTOP  = f.NIMPULS_BANDSTOP;

    delete[] FirstSDVComp;
    if(f.FirstSDVComp)
    {
        FirstSDVComp = new double[FIRST_NCOMP_SVD];
        if(FirstSDVComp)
            for(int k=0; k<FIRST_NCOMP_SVD; k++) 
                FirstSDVComp[k]=f.FirstSDVComp[k];
    }
    else
        FirstSDVComp = NULL;

    if( (f.FirstSDVComp && !FirstSDVComp))
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::operator=(). Memory allocation.\n");
    }
    return *this;
}

double ULinearFilter::GetFilterWindow_s(void) const
{
    if(SampleRate<=0)
    {
        CI.AddToLog("ERROR: ULinearFilter::GetFilterWindow_s(). Invalid SampleRate (=%f).\n", SampleRate);
        return 0.;
    }
    return NIMPULS_BANDPASS/SampleRate;
}

ErrorType ULinearFilter::SetFilterWindow_s(double FIRWindowSize)
{
    if(this==NULL || UConvolve::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetFilterWindow_s(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(SampleRate<=0.)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetFilterWindow_s(). SampleRate (%f) out of range. \n", SampleRate);
        return U_ERROR;
    }

    int NWindSize = int( 2*floor(FIRWindowSize*SampleRate/2)+1);
    if(NWindSize<=2)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetFilterWindow_s(). Too small window: NWindSize = %d, FIRWindowSize = %f .\n", NWindSize, FIRWindowSize);
        return U_ERROR;
    }
    NIMPULS_POWERLINE = 2*(NWindSize/2) +1;  
    NIMPULS_BANDPASS  = 2*(NWindSize/2) +1;  
    NIMPULS_BANDSTOP  = 2*(NWindSize/2) +1;  
    return U_OK;
}

ErrorType ULinearFilter::AddStopBand(double fmin, double fmax)
/* 
    Add Stop band to current filter settings.

    Previous windowing is first removed, then added on the enlarged impulse response window
 */
{
    if(fmin<0 || fmax<0 || fmin>=fmax)
    {
        CI.AddToLog("ERROR: ULinearFilter::AddStopBand(). Parameters out of range: fmin=%f, fmax=%f. \n",fmin,fmax);
        return U_ERROR;
    }
    double*   Himp    = new double[NIMPULS_BANDSTOP];

    if(Himp==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::AddStopBand(). Memory allocation for impulse response. \n");
        return U_ERROR;
    }
    double Fmid   = (fmin+fmax)/2;
    double FWidth = (fmax-fmin)/2; 

    double omega0 = PI2*Fmid  /SampleRate;  // Scaled center
    double eps    = PI2*FWidth/SampleRate;  // Scaled half bandwidth 
    for(int n=0; n<NIMPULS_BANDSTOP; n++)
    {
        int m = abs((NIMPULS_BANDSTOP-1)/2-n);
        if(m==0) 
        {
            Himp[n] = 1-2*eps/PI;
            if(2*omega0<PI2) Himp[n] -= 2*eps/PI;
        }
        else
        {
            Himp[n] = -2.*cos(omega0*m)*sin(eps*m)/(m*PI);
            if(2*omega0<PI2) Himp[n] -= 2.*cos(2*omega0*m)*sin(eps*m)/(m*PI);
        }
    }
    ErrorType   E = UnSetWindowing();
    if(E==U_OK) E = UConvolve::AddImpulseResponse(Himp, NIMPULS_BANDPASS);
    if(E==U_OK) E = SetWindowing();
    delete[] Himp;

    if(E==U_OK) 
        NStopBand+=1;
    else
        CI.AddToLog("ERROR: ULinearFilter::AddStopBand(). Some error occured in function called by this one. \n");

    return E;
}

ErrorType ULinearFilter::SetFilter(double fmin, double fmax, UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s)
/*
     Set current filter characteristics, cheque validity.
     
     Note: previous windowing is not removed!!!
 */
{
    if(this==NULL || UConvolve::GetError()!=U_OK)
    {
        CI.AddToLog("WARNING: ULinearFilter::SetFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    Filt            = U_FILT_BANDPASS;
    Wind            = U_WIN_KAISER;
    Prep            = PPT;
    PowerLine       = PLine;
    PowerLineWidth  = DEFPOWERLINEWIDTH;

    if(fmin<0 || fmin>SampleRate/2.)
    {
        if(fmin<0)             Fmin = 0;
        if(fmin>SampleRate/2.) Fmin = SampleRate/2.;
        CI.AddToLog("WARNING: ULinearFilter::SetFilter(). fmin=%f out of range. Value set to %f .\n",fmin,Fmin);
    }
    else
        Fmin = fmin;
    if(fmax<0 || fmax>SampleRate/2.)
    {
        Fmax = SampleRate/2.;
        CI.AddToLog("WARNING: ULinearFilter::SetFilter(). fmax=%f out of range. Value set to %f .\n",fmax,Fmax);
    }
    else
        Fmax = fmax;
    
/* Set impulse responses*/
    UConvolve::DeleteAllMembers(U_OK);
    NStopBand     = 0;
    ErrorType   E = U_OK;
    if(FIRWindowSize_s>0) E = SetFilterWindow_s(FIRWindowSize_s);
    else                  E = SetFilterWindow_s(1.);
    if(E==U_OK) E = SetBandPassFilter();
    if(E==U_OK) E = SetPowerLineFilter(PLWidth);
    if(E==U_OK) E = SetWindowing();
    if(E!=U_OK)
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::SetFilter(). Setting Bandpass or power line filter. \n");
    }
    return E;
}


ErrorType ULinearFilter::SetFilter(int ncomp, UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s)
/*
   Set the number of components for the SVD filter type.
 */
{
    if(this==NULL || UConvolve::GetError()!=U_OK)
    {
        CI.AddToLog("WARNING: ULinearFilter::SetFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(ncomp<=0)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetFilter(). Parameter out of range, ncomp = %d \n", ncomp);
        return U_ERROR;
    }

    Filt            = U_FILT_SVD;
    Wind            = U_WIN_KAISER;
    Prep            = PPT;
    PowerLine       = PLine;
    PowerLineWidth  = DEFPOWERLINEWIDTH;
    
    UConvolve::DeleteAllMembers(U_OK);
    NStopBand     = 0;
    ErrorType   E = U_OK;
    if(FIRWindowSize_s>0) E = SetFilterWindow_s(FIRWindowSize_s);
    else                  E = SetFilterWindow_s(1.);
    if(E==U_OK) E = SetPowerLineFilter(PLWidth);
    if(E==U_OK) E = SetWindowing();
    if(E!=U_OK)
    {
        UConvolve::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::SetFilter(). Setting Bandpass or power line filter. \n");
    }
    return E;
}

ErrorType ULinearFilter::SetFilter(UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s)
/*
   Set the preprocessing parameter and reset the filtering parameter to no-filtering.

   Note: previous windowing is not removed!!!
 */
{
    if(this==NULL || UConvolve::GetError()!=U_OK)
    {
        CI.AddToLog("WARNING: ULinearFilter::SetFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    Filt            = U_FILT_NOTYPE;
    Wind            = U_WIN_KAISER;
    Prep            = PPT;
    PowerLine       = PLine;
    PowerLineWidth  = DEFPOWERLINEWIDTH;
    
    UConvolve::DeleteAllMembers(U_OK);
    NStopBand     = 0;
    ErrorType   E = U_OK;
    if(FIRWindowSize_s>0) E = SetFilterWindow_s(FIRWindowSize_s);
    else                  E = SetFilterWindow_s(1.);
    if(E==U_OK) E = SetPowerLineFilter(PLWidth);
    if(E==U_OK) E = SetWindowing();
    if(E!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULinearFilter::SetFilter(). Setting Bandpass or power line filter. \n");
    }
    return E;
}

ErrorType ULinearFilter::ComputeFilter(double* dataPre, int nsampPre, double* data, int nsamp, int nchan) 
/*
     Filter the data with the current characteristics.
 */
{
    if(data==NULL) 
    {
        CI.AddToLog("PRORGAMMING ERROR: ULinearFilter::ComputeFilter(). Invalid pointer, data=NULL  .\n");
        return U_ERROR;
    }
    if(PreProcess(dataPre, nsampPre, data, nsamp, nchan)!=U_OK)
    {
        CI.AddToLog("ERROR: ULinearFilter::ComputeFilter(). Error in pre-processing. \n");
        return U_ERROR;
    }

/* Filter all channels*/
    if(Filt==U_FILT_BANDPASS || PowerLine!=U_POWERLINE_NO || NStopBand>0)
    {
        for(int i=0; i<nchan; i++)
        {
            if(UConvolve::ComputeConv(data+i*nsamp, nsamp)!=U_OK)
            {
                CI.AddToLog("ERROR: ULinearFilter::ComputeFilter(). Error filtering channel %d  .\n",i);
                return U_ERROR;
            }
        }
    }
    if(Filt==U_FILT_SVD)
    {
        double* U        = new double[nchan*nsamp];
        double* Lamda    = new double[      nsamp];
        double* V        = new double[nsamp*nsamp];

        if(!U ||!Lamda || !V) 
        {
            delete[] U;       
            delete[] Lamda;   
            delete[] V;       
            CI.AddToLog("ERROR: ULinearFilter::ComputeFilter(). Memory allocation in SVD filtering. nchan=%d, nsamp=%d \n", nchan, nsamp);
            return U_ERROR;
        }

/* Normalize the data */
        double DataNorm  = 0;
        int k = 0;
        for(     ;k<nchan*nsamp;k++) 
        {
            U[k]      = data[k];
            DataNorm += U[k]*U[k];
        }
        if(DataNorm<=1.e-10)
        {
            delete[] U;       
            delete[] Lamda;    
            delete[] V;        
            return U_OK; // Nothing to do
        }
        double Dnorm2 = sqrt( DataNorm );
        k = 0;
        for( ;k<nchan*nsamp;k++) U[k] /= Dnorm2;

/* Compute SVD */
        svdcmp_d(U, nchan, nsamp, Lamda, V); //U will be overwritten

        int Maxcomp = MIN(Ncomp,MIN(nsamp,nchan));
        k = 0;
        for( ; k<MIN(Maxcomp,FIRST_NCOMP_SVD); k++) 
            FirstSDVComp[k] = Lamda[k]*Lamda[k]*100; // Used in Properties[] string

        for(int i=0,ij=0; i<nchan; i++)
        {
            for(int j=0; j<nsamp; j++, ij++)
            {
                double* pd = data+ij;  *pd=0;
                double* pL = Lamda;
                double* pU = U+i*nsamp;
                double* pV = V+j*nsamp;
                for(int k=0; k<Maxcomp; k++) *pd += *pL++ * *pU++ * *pV++;
                *pd *= Dnorm2;
            }
        }
        delete[] U;       
        delete[] Lamda;    
        delete[] V;        
    }
    return U_OK;
}

ErrorType ULinearFilter::PreProcess(const double* dataPre, int nsampPre, double* data, int nsamp, int nchan) const
/*
     Remove trend and/or offset from the data[] array, consisting of chan channels with nsamp data points each.
     
     if(dataPre!=NULL) trend and offset are computed over the dataPre[]
     else              trend and offset are computed over data[]

     Note:
     Leading and ending zeroes (all channels are zero) are ignored in both data[] and dataPre[]
 */
{
    if(Prep==U_PREP_NO) return U_OK;
    if(data==NULL)
    {
        CI.AddToLog("ERROR ULinearFilter::PreProcess(). invalid NULL pointer for data array. \n");
        return U_ERROR;
    }

/* Get non-zero interval of data window*/
    int jbdata = 0;
    int jedata = 0;
    if(FindNonZeroes(data, nsamp, nchan, &jbdata, &jedata)!=U_OK) return U_ERROR;

    if(jedata-jbdata+1<=0)
    {
        CI.AddToLog("Note: ULinearFilter::PreProcess(). Window identically zero. \n");
        return U_OK;
    }
    if(jbdata!=0      ) 
    {
        static int NWARNING = 10;
        static int nwarning = 0;
        if(nwarning<=NWARNING)
            CI.AddToLog("Note: ULinearFilter::PreProcess(). Skipping first %d samples. \n", jbdata);
        if(nwarning==NWARNING)
            CI.AddToLog("Note: (Last message) \n", jbdata);
        nwarning++;
    }
    if(jedata!=nsamp-1) 
    {
        static int NWARNING = 10;
        static int nwarning = 0;
        if(nwarning<=NWARNING)
            CI.AddToLog("Note: ULinearFilter::PreProcess(). Skipping last %d samples.  \n", nsamp-jedata-1);
        if(nwarning==NWARNING)
            CI.AddToLog("Note: (Last message) \n", jbdata);
        nwarning++;
    }

/* Use preprocessing window when present         */
/* Get non-zero interval of pre-processing window*/
    int jbpre = 0;
    int jepre = 0;
    const double* datP = dataPre;
    int           nsP  = nsampPre;
    if(datP==NULL)
    {
        jbpre = jbdata;
        jepre = jedata;
        datP  = data;
        nsP   = nsamp;
    }
    else
    {
        if(FindNonZeroes(datP, nsP, nchan, &jbpre, &jepre)!=U_OK) return U_ERROR;

        if(jepre-jbpre+1<=0)
        {
            CI.AddToLog("WARNING: ULinearFilter::PreProcess(). Pre-process window identically zero. \n");
            return U_OK;
        }
        if(jbpre!=0      ) 
        {
            static int NWARNING = 10;
            static int nwarning = 0;
            if(nwarning<=NWARNING)
            CI.AddToLog("Note: ULinearFilter::PreProcess(). Skipping first %d samples from pre-process window . \n", jbpre);
            if(nwarning==NWARNING)
                CI.AddToLog("Note: (Last message) \n", jbdata);
            nwarning++;
        }
        if(jepre!=nsP-1) 
        {
            static int NWARNING = 10;
            static int nwarning = 0;
            if(nwarning<=NWARNING)
            CI.AddToLog("Note: ULinearFilter::PreProcess(). Skipping last %d samples from pre-process window.  \n", nsamp-jepre-1);
            if(nwarning==NWARNING)
                CI.AddToLog("Note: (Last message) \n", jbdata);
            nwarning++;
        }
    }
    int nsaPre = jepre-jbpre+1;

    if(Prep==U_PREP_TREND)
    {
        if(nsaPre==1)
        {
            CI.AddToLog("ERROR: ULinearFilter::PreProcess(). Linear trend removal on one single (non-zero) sample. \n");
            return U_ERROR;
        }
        if(dataPre!=NULL && dataPre!=data)
        {
            static int NWarning = 0;
            if(NWarning<20)
                CI.AddToLog("WARNING: ULinearFilter::PreProcess(). Linear trend removal over window which is different from data window. \n");            
            NWarning++;
        }
    }

/* jbdata (resp. jbpre) and jedata (resp. jepre) are the first and the last non-zero sample 
   (that have to be accounted for)  nsa is the number of non-zero samples */   

/* Remove offset*/    
    if(Prep==U_PREP_OFFSET)
    {
        for(int i=0; i<nchan; i++)
        {
            double        offset = 0;
            const double* dat    = datP + i*nsP + jbpre;
            for(int j=0; j<nsaPre; j++) offset += *dat++;
            offset /= nsaPre;
        
            double* datOut      = data + i*nsamp + jbdata;
            for(int j=0; j<jedata-jbdata+1; j++) *datOut++ -= offset;  // Apply pre-processing only over non-zero part
        }
        return U_OK;
    }


/* Remove trend*/
    for(int i=0; i<nchan; i++)
    {
        const double* dat =  datP + i*nsP + jbpre;
        double     offset =  dat[0];
        double     trend  =  (dat[nsaPre-1]-dat[0])/(nsaPre-1);

        double* datOut = data + i*nsamp + jbdata;
        for(int j=0; j<jedata-jbdata+1; j++) *datOut++ += -(offset+j*trend);
    }
    return U_OK;
}

ErrorType ULinearFilter::FindNonZeroes(const double* data, int nsamp, int nchan, int* jb, int* je) const
/*
    Compute the non-zero begin (*jb) and end (*je) point of the data array data[]. The total number of
    non-zero points is *je-*jb+1
 */
{
    if(data==NULL ||nsamp<0 || jb==NULL || je==NULL)
    {
        CI.AddToLog("ERROR ULinearFilter::FindNonZeroes(). Invalid NULL pointer(s). \n");
        return U_ERROR;
    }

    int jbegin = 0;
    int      j = 0;
    for(          ; j<nsamp; j++, jbegin++)
    {
              double  pwj = 0;
        const double* dat = data+j; 
        for(int i=0;i<nchan;i++,dat+=nsamp) pwj += *dat * *dat;
        if(sqrt(pwj)/nchan > 1.e-10)
        {
            jbegin = j;
            break;
        }
    }
    if(jbegin==nsamp) 
    {
        if(jb) *jb = nsamp;
        if(je) *je = nsamp-1;
        return U_OK;
    }
    int jend = nsamp-1;
    j = nsamp - 1;
    for(         ; j>=jbegin; j--, jend--)
    {
              double  pwj = 0;
        const double* dat = data+j;
        for(int i=0;i<nchan;i++,dat+=nsamp) pwj += *dat * *dat;
        if(sqrt(pwj)/nchan > 1.e-10)
        {
            jend = j;
            break;
        }
    }
    if(jend-jbegin+1<=0)
    {
        if(jb) *jb = nsamp;
        if(je) *je = nsamp-1;
        return U_OK;
    }

    if(jb) *jb = jbegin;
    if(je) *je = jend;

    return U_OK;
}

const UString& ULinearFilter::GetProperties(UString Comment) const
{
    if(UConvolve::GetError()!=U_OK)
    {
        Properties = UString(" ERROR in ULinearFilter-object\n");
        return Properties;
    }
    Properties =  UString();
    
    bool OffSet = (Prep==U_PREP_OFFSET || Prep==U_PREP_TREND);
    bool Trend  = (Prep==U_PREP_TREND);
    Properties += UString(BoolAsText(OffSet   )," OFFSET_REMOVAL    = %s \n");
    Properties += UString(BoolAsText(Trend    )," TREND_REMOVAL     = %s \n");
    switch(PowerLine)
    {
    case U_POWERLINE_NO:  Properties += UString(" POWERLINE         = NoSuppress \n"); break;
    case U_POWERLINE_50:  Properties += UString(" POWERLINE         = Suppress_50 \n"); break;
    case U_POWERLINE_60:  Properties += UString(" POWERLINE         = Suppress_60 \n"); break;
    }
    if(PowerLine==U_POWERLINE_50 || PowerLine==U_POWERLINE_60)
    {
        Properties += UString(PowerLineWidth   ," POWERLINE_WIDTH   = %f // [Hz]\n");
        Properties += UString(NIMPULS_POWERLINE," POWERLINE_NPOINTS = %d \n");
    }
    bool SVDFilter = (Filt==U_FILT_SVD     );
    Properties += UString(BoolAsText(SVDFilter)," SVDFILTER         = %s \n");
    if(SVDFilter==true)
    {
        Properties += UString(Ncomp," SVD_NCOMP         = %s \n");
        for(int k=0; k<FIRST_NCOMP_SVD-1; k++) 
            Properties += UString(k,"SVD_COMP%3.3d        ") + UString(FirstSDVComp[k]," %6.2f % \n");
    }    
    bool BPaFilter = (Filt==U_FILT_BANDPASS);
    Properties += UString(BoolAsText(BPaFilter)," BANDPASS          = %s \n");
    if(BPaFilter==true)
    {
        Properties += UString(Fmin             ," BANDPASS_FMIN     = %f \n");
        Properties += UString(Fmax             ," BANDPASS_FMAX     = %f \n");
        Properties += UString(NsampH           ," BANDPASS_NPOINTS  = %d \n");
        Properties += UString(NIMPULS_BANDPASS ," BANDPASS_NSAMPH   = %d \n");
        Properties += UString(NFFT             ," BANDPASS_NFFT     = %d \n");
    }
    Properties += UString(BoolAsText(NStopBand>0)," STOPBAND          = %s \n");
    if(NStopBand>0)
    {
        Properties += UString(NStopBand       ," NSTOPBAND         = %d \n");
        Properties += UString(NIMPULS_BANDSTOP," STOPBAND_NPOINTS  = %d \n");
    }
    if(PowerLine==U_POWERLINE_50 || PowerLine==U_POWERLINE_60 || BPaFilter==true || NStopBand>0)
    {
        switch(Wind)
        {
        case U_WIN_BLOCK:   Properties += UString(" WINDOWTYPE        = WINDOW_BLOCK \n"); break;
        case U_WIN_HAMMING: Properties += UString(" WINDOWTYPE        = WINDOW_HAMMING \n");
                            Properties += UString(ALFA, " WINDOW_ALPHA      = %f \n");     break;
        case U_WIN_KAISER:  Properties += UString(" WINDOWTYPE        = WINDOW_KAISER \n");
                            Properties += UString(BETA, " WINDOW_BETA      = %f \n");      break;
        }
    }
    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');  
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}
ErrorType ULinearFilter::SetPowerLineFilter(double PLWidth)
{
    if(PowerLine!=U_POWERLINE_50 && PowerLine!=U_POWERLINE_60) return U_OK;

    const double Fpow = PowerLine==U_POWERLINE_50 ? 50. : 60.; 
    double*      Himp = new double[NIMPULS_POWERLINE];

    if(Himp==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetPowerLineFilter(). Memory allocation for impulse response. \n");
        return U_ERROR;
    }
    if(PLWidth<=0 || Fpow<=PLWidth) 
    {
        PowerLineWidth = DEFPOWERLINEWIDTH;
        CI.AddToLog("WARNING: ULinearFilter::SetPowerLineFilter(). Power line filter width out of range (%f) set to %f Hz.\n",PLWidth, PowerLineWidth);
    }
    else 
        PowerLineWidth = PLWidth;


    double omega0 = PI2*Fpow          /SampleRate;  // Scaled power line
    double eps    = PI *PowerLineWidth/SampleRate;  // Scaled half bandwidth 
    for(int n=0; n<NIMPULS_POWERLINE; n++)
    {
        int m = abs((NIMPULS_POWERLINE-1)/2-n);
        if(m==0) 
        {
            Himp[n] = 1-2*eps/PI;
            if(2*omega0<PI2) Himp[n] -= 2*eps/PI;
            if(3*omega0<PI2) Himp[n] -= 2*eps/PI;
            if(4*omega0<PI2) Himp[n] -= 2*eps/PI;
        }
        else
        {
            Himp[n] = -2.*cos(omega0*m)*sin(eps*m)/(m*PI);
            if(2*omega0<PI2) Himp[n] -= 2.*cos(2*omega0*m)*sin(eps*m)/(m*PI);
            if(3*omega0<PI2) Himp[n] -= 2.*cos(3*omega0*m)*sin(eps*m)/(m*PI);
            if(4*omega0<PI2) Himp[n] -= 2.*cos(4*omega0*m)*sin(eps*m)/(m*PI);
        }
    }
    ErrorType E = UConvolve::AddImpulseResponse(Himp, NIMPULS_POWERLINE);
    delete[] Himp;
    return E;
}

double* ULinearFilter::GetWindowProfile(WindowType WT, int Nsamp) // static
{
    if( (WT!=U_WIN_HAMMING && WT!=U_WIN_KAISER && WT!=U_WIN_BLOCK) || Nsamp<=0)
    {
        CI.AddToLog("ULinearFilter::GetWindowProfile(). Invalid WindowType (WT=%d) or invalid number of points (Nsamp=%d). \n", WT, Nsamp);
        return NULL;
    }

    double  AlfaBeta = WT==U_WIN_HAMMING ? ALFA : BETA;
    double* Window   = ::GetWindowProfile(WT, Nsamp, AlfaBeta);
    if(Window==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::GetWindowProfile(). Computing window. Nsamp=%d . \n", Nsamp);
        return NULL;
    }
    return Window;
}

ErrorType ULinearFilter::ApplyWindow(double* data, const double* Window, int Nsamp, UPreProType Prep) // static
{
    if(data==NULL)  
    {
        CI.AddToLog("ERROR: ULinearFilter::ApplyWindow(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(Nsamp<=1)      
    {
        CI.AddToLog("ERROR: ULinearFilter::ApplyWindow(). Invalid number of samples (Nsamp=%d). \n", Nsamp);
        return U_ERROR;
    }

    if(Prep==U_PREP_OFFSET)
    {
        double off =  0;
        for(int j=0; j<Nsamp; j++) off += data[j];
        off /= Nsamp;
        for(int j=0; j<Nsamp; j++) data[j] -= off;
    }
    else if(Prep==U_PREP_TREND)
    {
        double off =  data[0      ];
        double slo = (data[Nsamp-1]-off)/(Nsamp-1);
        for(int j=0; j<Nsamp; j++) data[j] -= off+j*slo;
    }

    if(Window)
        for(int j=0; j<Nsamp; j++) data[j] *= Window[j];

    return U_OK;
}

ErrorType ULinearFilter::SetWindowing(void)
{
    if(PowerLine==false && Filt!=U_FILT_BANDPASS) return U_OK;
    if(Wind!=U_WIN_HAMMING && Wind!=U_WIN_KAISER) return U_OK;

    if(NsampH<=0)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetWindowing(). Invalid impulse response length. NsampH=%d . \n", NsampH);
        return U_ERROR;
    }
    double* Window = GetWindowProfile(Wind, NsampH);
    if(Window==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetWindowing(). Computing window function. \n");
        return U_ERROR;
    }

    ErrorType E = UConvolve::WindowImpulseResponse(Window);
    delete[] Window;
    return E;
}

ErrorType ULinearFilter::UnSetWindowing(void)
{
    if(NsampH<=0)                                 return U_OK; // No Impulse response set yet
    if(Wind!=U_WIN_HAMMING && Wind!=U_WIN_KAISER) return U_OK; // Window is 1

    double* Window = GetWindowProfile(Wind, NsampH);
    if(Window==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::UnSetWindowing(). Computing window function.\n");
        return U_ERROR;
    }

    for(int n=0; n<NsampH; n++) 
    {
        if(Window[n]<=0.) 
        {
            CI.AddToLog("WARNING: ULinearFilter::UnSetWindowing(). Window has Zero point. ");
            Window[n] = 0.;
        }
        else Window[n] = 1./Window[n];
    }

    ErrorType E = UConvolve::WindowImpulseResponse(Window);
    delete[] Window;
    return E;
}


ErrorType ULinearFilter::SetBandPassFilter(void)
{
    if(this==NULL || UConvolve::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetBandPassFilter(). This ==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NIMPULS_BANDPASS<=0 || SampleRate<=0)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetBandPassFilter(). Invalid BandPass parameter (NIMPULS_BANDPASS=%d) or SampleRate (=%f) . \n",NIMPULS_BANDPASS,SampleRate);
        return U_ERROR;
    }
    double*   Himp    = new double[NIMPULS_BANDPASS];
    if(Himp==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::SetBandPassFilter(). Memory allocation . \n");
        return U_ERROR;
    }

    double omega1 = PI2*Fmin/SampleRate;  // Scaled Fmin
    double omega2 = PI2*Fmax/SampleRate;  // Scaled Fmax
    for(int n=0; n<NIMPULS_BANDPASS; n++)
    {
        int m = abs((NIMPULS_BANDPASS-1)/2-n);
        if(m==0)     Himp[n] = (omega2-omega1)/PI;
        else         Himp[n] = (sin(omega2*m)-sin(omega1*m))/(m*PI);
    }
    UConvolve::DeleteAllMembers(U_OK);

/* Set impulse response*/
    ErrorType E = UConvolve::AddImpulseResponse(Himp, NIMPULS_BANDPASS);
    delete[] Himp;
    return E;
}


ErrorType ULinearFilter::InterpolateEpoch(double* data, int nsamp, int nkan, int jstart, int jend) const
/*
   Replace the data in array data[] (consisting of nkan samples of nsamp each) by a lineatly 
   interploated version, from jstart to jend (first and last atrifact-free samples).

   This function is typically used for removing sharp artifacts of short duration.
 */
{
    if(data==NULL)
    {
        CI.AddToLog("ERROR: ULinearFilter::InterpolateEpoch(). NULL argument. \n");
        return U_ERROR;
    }

    if((jstart<0 && jend>=nsamp) || jstart>=jend)
    {
        CI.AddToLog("ERROR: ULinearFilter::InterpolateEpoch(). Epoch (%d,%d) out of range, nsamp = %d. \n", jstart, jend, nsamp);
        return U_ERROR;
    }
    if(jend<0 || jstart>=nsamp) return U_OK; // Nothing to do!

    if(jstart<0) // copy first artifact free sample backwards
    {
        for(int i=0; i<nkan; i++)
        {
            for(int j=0; j<jend; j++)
                data[i*nsamp+j] = data[i*nsamp+jend];
        }
        return U_OK;
    }

    if(jend>=nsamp) // copy last artifact free sample forwards
    {
        for(int i=0; i<nkan; i++)
        {
            for(int j=jstart; j<nsamp; j++)
                data[i*nsamp+j] = data[i*nsamp+jstart];
        }
        return U_OK;
    }

/* Interpolate linearly between first and last artifact free samples*/
    for(int i=0; i<nkan; i++)
    {
        double offset =  data[i*nsamp+jstart];
        double slope  = (data[i*nsamp+jend]-data[i*nsamp+jstart]) /(jend-jstart);
        for(int j=jstart+1; j<jend; j++)
            data[i*nsamp+j] = offset + (j-jstart)*slope;
    }
    return U_OK;
}
