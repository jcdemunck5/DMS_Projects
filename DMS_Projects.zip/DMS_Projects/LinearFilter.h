#ifndef _LINEARFILTER_INCLUDED
#define _LINEARFILTER_INCLUDED

#include"Convolve.h"
#include"String.h"

enum UFilterType     // The main filter type of the object
{
    U_FILT_NOTYPE,   // Undefined type
    U_FILT_BANDPASS, // Sharp band pass filter
    U_FILT_SVD       // SVD-filter (passing the largest Ncomp components)
};
enum UPreProType
{
    U_PREP_NO,       // No pre-processing
    U_PREP_OFFSET,   // Off set removal
    U_PREP_TREND     // Off set and trend removal removal
};
enum UPowerLineType
{
    U_POWERLINE_NO,  // No powerline supression
    U_POWERLINE_50,  // 50 Hz powerline suppression
    U_POWERLINE_60   // 60 Hz powerline suppression
};

class DLL_IO ULinearFilter : private UConvolve
{
public:
    ULinearFilter();
    ULinearFilter(double sRate);
    ULinearFilter(const ULinearFilter& f);
    virtual ~ULinearFilter(void);

    ULinearFilter&      operator=(const ULinearFilter& f);

    ErrorType           GetError(void) const {return error;}
    const UString&      GetProperties(UString Comment) const;

    ErrorType           SetManyFFT(bool setMany) {return UConvolve::SetManyFFT(setMany);}
    
    UFilterType         GetFilterType(void) const {return Filt;}
    UPreProType         GetPreProType(void) const {return Prep;}
    WindowType          GetWindowType(void) const {return Wind;}
    bool                GetPowerLine(void)  const {if(this) return NOT(PowerLine==U_POWERLINE_NO); return false;}

    double              GetFmin(void) const {return Fmin;}
    double              GetFmax(void) const {return Fmax;}
    double              GetFilterWindow_s(void) const;

    int                 GetNImpulseResponse(void) const {return UConvolve::NsampH;}
    int                 GetNIMPULS_POWERLINE(void) const {return NIMPULS_POWERLINE;}
    int                 GetNIMPULS_BANDPASS(void)  const {return NIMPULS_BANDPASS; }
    int                 GetNIMPULS_BANDSTOP(void)  const {return NIMPULS_BANDSTOP; }

    ErrorType           SetFilter(double fmin, double fmax, UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s);
    ErrorType           SetFilter(int ncomp, UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s);
    ErrorType           SetFilter(UPreProType PPT, UPowerLineType PLine, double PLWidth, double FIRWindowSize_s);
    ErrorType           AddStopBand(double fmin, double fmax);

    ErrorType           ComputeFilter(double* dataPre, int nsampPre, double* data, int nsamp, int nchan);
    ErrorType           InterpolateEpoch(double* data, int nsamp, int nkan, int jstart, int jend) const;

    static double*      GetWindowProfile(WindowType Win, int Nsamp);
    static ErrorType    ApplyWindow(double* data, const double* Window, int Nsamp, UPreProType Prep);
    static double       GetAlfa(void) {return ALFA;}
    static double       GetBeta(void) {return BETA;}

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static const double ALFA;           // Constant for the Hamming window
    static const double BETA;           // Constant for the Kaiser window
    static const int    FIRST_NCOMP_SVD;// Number of components stored in Properties[]
    static UString      Properties;
    ErrorType           error;

    int                 NIMPULS_POWERLINE;
    int                 NIMPULS_BANDPASS; 
    int                 NIMPULS_BANDSTOP;

    double*             FirstSDVComp;   // The first SVD components strength

// Parameters used with frequency filtering
    double              SampleRate;     // sample frequency, used to sample the data [Hz]
    int                 NStopBand;      // The number of stop bands added
    UFilterType         Filt;           // Current filter type
    WindowType          Wind;           // Window type
    UPreProType         Prep;           // Preprocessing type
    double              Fmin;           // Minimum frequency for band-pass filter. <=0 means ignore
    double              Fmax;           // Maximum frequency for band-pass filter. <=0 means ignore
    UPowerLineType      PowerLine;      // Power line suppression mode
    double              PowerLineWidth; // Width of the powerline filter [Hz] (if applied)

// Parameters used with SVD filtering    
    int                 Ncomp;          // Use this many components
    ErrorType           PreProcess(const double* dataPre, int nsampPre, double* data, int nsamp, int nchan) const;
    ErrorType           FindNonZeroes(const double* data, int nsamp, int nchan, int* jb, int* je) const;

    ErrorType           SetFilterWindow_s(double WindowSize);

    ErrorType           SetBandPassFilter(void);
    ErrorType           SetPowerLineFilter(double PLWidth);
    ErrorType           SetWindowing(void);
    ErrorType           UnSetWindowing(void);
};

#endif //_LINEARFILTER_INCLUDED
