#ifndef LIST_H
#define LIST_H

#include"../../BasicInclude.h"

template <class Type> class UList;

template <class Type> class UListItem 
{           
    friend          UList<Type>;
public:
    UListItem<Type>(const Type* T);           // construct a list item
    UListItem<Type>(const Type& T);           // construct a list item
    virtual ~UListItem<Type>();

    const UListItem<Type>*       GetNext()   const {return nextp;}
    UListItem<Type>*&            GetNext()         {return nextp;}
    const Type*                  GetObject() const {return obj;}
    Type*                        GetObject()       {return obj;}

private:
    Type*                        obj;   // object in list
    UListItem<Type>*             nextp; // next in list
};

template <class Type> UListItem<Type>::UListItem(const Type *T) 
{   
    obj   = new Type(*T);
    nextp = NULL;                       // null for now
}
template <class Type> UListItem<Type>::UListItem(const Type& T) 
{   
    obj   = new Type(T);
    nextp = NULL;                       // null for now
}
template <class Type> UListItem<Type>::~UListItem() 
{   
    delete obj;
}


//////////////////////////////////////////////////////////////////
// A UList<Type> is internally a header structure pointing to a linked list
// of UListItem's of type Type.

// When a list is copied with operator=, we want header to be copied
// but items to be shared (not copied).
// To get that behavior, we do not define "UList &UList(UList &)" or
// "operator=(UList &)" but let them default to memberwise-initialization.
// If you want a completely new copy of a list, use copy() below.


// empties out list, deleting UListItems and the objects themselves

template <class Type>class UList 
{        
public:    
    UList();
    ~UList();
    void                   DeleteList();               // something like a destructor
    int                    GetLength(void) const;      // return length of list

    ErrorType              Prepend(const Type& T);     // prepend item at beginning of list    
    ErrorType              Prepend(const Type* T) {return Prepend(*T);}     
    ErrorType              Append(const Type& T);     // append item to end of list
    ErrorType              Append(const Type* T)  {return Append(*T);}
    ErrorType              Push(const Type& T)    {return Prepend(T);}
    ErrorType              Push(const Type* T)    {return Prepend(T);}
    Type*                  Pop();                      // pop item off stack
    ErrorType              Duplicate();                // duplicate top item
    Type*                  Remove(UListItem<Type>* T); // remove one item from list, return it
    ErrorType              Concat(UList<Type>* L);     // concatenate list on end of this one
    ErrorType              Copy(const UList<Type> &L); // copies list & items (not objects)

    const UListItem<Type>* GetFirst() const       {return firstp;}
    const UListItem<Type>* GetLast() const        {return lastp;}

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    UListItem<Type>*       firstp;                     // first item in list
    UListItem<Type>*       lastp;                      // last item in list
};

template <class Type>
void UList<Type>::SetAllMembersDefault(void)
{
    firstp = NULL;
    lastp  = NULL;
}

template <class Type>
void UList<Type>::DeleteAllMembers(ErrorType E)
{
////    return;  // seg fault from this  -andrewb ???
    Type *x = NULL;
    do
    {
	    x = Pop();
    }
    while(x);
}

template <class Type>
UList<Type>::UList<Type>()
{
    SetAllMembersDefault();
}

template <class Type>
UList<Type>::~UList<Type>()
{
    DeleteAllMembers(U_OK);
}

template <class Type>
void UList<Type>::DeleteList() 
{
    Type *x = NULL;
    do 
    {
        x = Pop();
        delete x;
    } 
    while (x);
}

template <class Type>
int UList<Type>::GetLength() const 
{                
    const UListItem<Type> *p = NULL;
    int count = 0;
    for(p=GetFirst(); p; p=p->GetNext(), count++);
    return count;
}

template <class Type>
ErrorType UList<Type>::Prepend(const Type& T) 
{        
    if(&T==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Prepend(). Argument has NULL address. \n");
        return U_ERROR;
    }
    UListItem<Type> *p = new UListItem<Type>(T);
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Prepend(). Creating UListItem. \n");
        return U_ERROR;
    }
    p->nextp = firstp;
    firstp   = p;
    if(!lastp) lastp = p;

    return U_OK;
}

template <class Type>
ErrorType UList<Type>::Append(const Type& T) 
{
    if(&T==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Append(). Argument has NULL address. \n");
        return U_ERROR;
    }    
    UListItem<Type> *p = new UListItem<Type>(T);
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Append(). Creating UListItem. \n");
        return U_ERROR;
    }
   
    if(firstp)   lastp  = lastp->nextp = p;
    else         firstp = lastp = p;
    p->nextp = NULL;

    return U_OK;
}

template <class Type>
Type* UList<Type>::Pop() 
{
    UListItem<Type> *p = firstp;
    if(!p) return NULL;               // stack empty, can't pop
    
    firstp  = p->GetNext();
    if(!firstp) lastp = NULL;
    Type *x = p->obj;
    delete p;
    return x;
}

template <class Type>
ErrorType UList<Type>::Duplicate() 
{
    if(firstp==NULL) 
    {
        CI.AddToLog("ERROR: UList<Type>::Duplicate(). firstp==NULL . \n");
        return U_ERROR;
    }
    UListItem<Type> *p = new UListItem<Type>(firstp->obj);
    if(p==NULL) 
    {
        CI.AddToLog("ERROR: UList<Type>::Duplicate(). Copying first object from list. \n");
        return U_ERROR;
    }
    return Push(p);
}

template <class Type>
Type* UList<Type>::Remove(UListItem<Type> *q) 
{
    if(q==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Remove(). Invalid NULL argument. \n");
        return NULL;
    }
    UListItem<Type> *p = NULL;
    Type *t = q->obj;
    if(first()==q) 
    {
        firstp = q->nextp;
        if(!firstp) lastp = NULL; // list is now empty
        delete q;
        return t;
    }
    for(p=first(); p; p=p->next())
    {
        if(p->next()==q) // we found the predecessor to q, now splice the list
        {
            p->nextp = q->nextp;
            if(!p->nextp)  //??nuke assert
            {
/***            assert(lastp==q); ***/
                lastp = p;
            }
            delete q;
            return t;
        }
    }
    CI.AddToLog("WARNING: UList<Type>::Remove(). Item not found. \n");
    return t;
}


//////////////////////////////////////////////////////////////////
// Note: be careful calling DeleteList() if you've done any
// list copying or object sharing because there will be multiple pointers
// to the same UListItem or object (aliasing).


template <class Type>
ErrorType UList<Type>::Copy(const UList<Type> &L) 
{
    // copy list L into *this, copying each list item
    // first we empty out the existing list
    
////    DeleteList();
    
    UListItem<Type> *p = NULL;
    for(p=L.firstp; p; p=p->nextp) 
    {
        if(Append(p->obj)!=U_OK)
        {
            CI.AddToLog("EROR:UList<Type>::Copy(). Apping object. \n");
            return U_ERROR;
        }
    }
    return U_OK;
}


template <class Type>
ErrorType UList<Type>::Concat(UList<Type> *L) // concat list a on end of this
{  
    if(L==NULL)
    {
        CI.AddToLog("ERROR: UList<Type>::Concat(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if (firstp) lastp->nextp = L->firstp;
    else        firstp       = L->firstp;
    
    lastp = L->lastp;
    L->firstp = NULL;  // so delete doesn't wipe out the items
    delete L;          // delete the list a itself

    return U_OK;
}

#endif
