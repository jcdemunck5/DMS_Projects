/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for fitting the Coupled Dipole Model or the                        */
/*     Extended Coupled Dipole Model to MEG/EEG data. The CDM, using             */
/*     specially designed coupling matrices is described in: "The Coupled        */
/*     Dipole Model: an integrated model for multiple MEG/EEG data sets",        */
/*     Bijma et al. NeuroImage, 2004.  The ECDM, using entirely estimated        */
/*     coupling matrices is described in: "Simultaneous analysis of multiple     */
/*     MEG data sets and confidence intervals", IEEE Trans.SP, Special Issue     */
/*     on Aspects of Brain Imaging, 2005                                         */
/*                                                                               */
/*                                                                               */
/*     Fetsje Bijma                                                              */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  FB     15-10-02   creation, derived from LocStatDip.cpp
  JdM/FB 25-02-03   Added the function GetCodeManager()
  FB     11-03-03   Improved the Update routines to speed up computation
  FB     12-03-03   Added the parameter FitTest to ComputeCost (WEMdat) to set fit precision
  FB     18-03-03   Added the residualPerCode in ComputeDipoles() and created ComputeResPerCode()
  FB     09-05-03   Bug Fix: computing the datanorm per code per sample in ComputeDipoles()
  FB     05-01-04   Added ComputeCCRB() and TestSignificance()
  FB     22-01-04   Added test per sample in TestSignificance()
  FB     10-03-04   Bug Fix: ComputeDipoles(): update DipArr in pDipMan after inverting orientations
  FB     10-03-04   Added: ComputeParameterCov(), ComputeConfIntervals, Removed TestSignificance() and ComputeCCRB()
  FB     26-04-04   Added Bonferroni correction as default in ComputeConfIntervals() by argument bool Bonf
  FB     03-05-05   Added ComputeDipoles based on UDipoleEdit.
  JdM    05-01-07   Eliminate reference to obsolete UDataEpochs, and use UMEEGDataEpochs
  JdM    17-08-08   Bug Fix: ULocCodeDip::ULocCodeDip(). SetBalancing(): Use UMEEGDataBase::MAXMEG
  JdM    10-04-09   Bug fixes ComputeDipoles(): compilor errors on MSVC2008. Comparing function pointers
  JdM    19-05-11   Use explicit casts to (const char*) of calls to GetProperties()
  JdM    20-05-11   Use UString for GetProperties()
  JdM    17-02-12   Several changes to eliminate WARNINGS with CodeBlock compiler
  JdM    29-12-13   Adapt to new interface to UMatrix-object. No correctness test performed!
  JdM    02-03-14   Used UMatrixSymmetric and UMatrixSquare
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    18-01-15   ComputeConfIntervals(). Use new UCovariance object (derived from UMatrixSymmetric, i.s.o. UJacobi)
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FitDipoles.h"
#include "LocCodeDip.h"
#include "Jacobi.h"
#include "Epochs.h"
#include "MarkerArray.h"
#include "Matrix.h"
#include "MatrixSymmetric.h"
#include "MatrixSquare.h"
#include "Statistics.h"
#include "MEEGDataBase.h"


/* Inititalize static const parameters. */
UString      ULocCodeDip::Properties           = UString();
double const ULocCodeDip::COSTERROR            = 10000;
double const ULocCodeDip::AMAT_THRESHOLD       = 1.e-8;
double const ULocCodeDip::OLS_REL_EEG_VARIANCE = .01;
const int    ULocCodeDip::MAXLINITER           = 50;

int GetSign(double d);


ULocCodeDip::ULocCodeDip(const UCostminimize& cost, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* gridM, const UGrid* gridE, const UHeadModel *Hmod,
             UCovariance* CovarXX, UCovariance* CovarTT, bool GM) :
    Uminimize(cost),
    UStartStatDip(Hmod)
{
    error         = U_OK;
    nSamples      = 0;
    nComp         = 0;
    NtotCost      = 0;

    Bmat          = NULL;
    ULBT          = NULL;

    EMData        = NULL;
    ULamda        = NULL;
    Lamda         = NULL;
    Vmat          = NULL;
    SV            = NULL;
    WmatTfld      = NULL;

    CovXX         = NULL;
    CovTT         = NULL;
    DataNorm      = 0.;
    GMAN          = GM;
    nSets         = 0;
    nBasicSTF     = 0;
    CM            = NULL;
    DataSetNames  = NULL;
    nTrialsPerSet = NULL;
    Properties    = UString();

    GridMEG       = gridM;
    GridEEG       = gridE;
    if(GridMEG && GridEEG)
    {
        nMEG  = GridMEG->GetNpoints();
        nEEG  = GridEEG->GetNpoints();
        Ftype = UEMfield::U_MEGEEG;
    }
    else if(GridMEG)
    {
        nMEG  = GridMEG->GetNpoints();
        nEEG  = 0;
        Ftype = UEMfield::U_MEG;
    }
    else if(GridEEG)
    {
        nMEG  = 0;
        nEEG  = GridEEG->GetNpoints();
        Ftype = UEMfield::U_EEG;
    }
    else
    {
        nMEG  = 0;
        nEEG  = 0;
        Ftype = UEMfield::U_UNKNOWN;
    }
    nKan  = nEEG + nMEG;

    if(nKan<=10 || Ftype==UEMfield::U_UNKNOWN)
    {
        error = U_ERROR;
        CI.AddToLog("ULocCodeDip::ULocCodeDip(). Illegal number of channels: nKan = %d. \n",nKan);
        return;
    }
    WmatTfld    = new double*[MAXDIPOLES];
    if(!WmatTfld) error = U_ERROR;

    if(error==U_OK) error = Emf.GetError();
    if(error==U_OK) error = UStartStatDip::GetError();
    if(error==U_OK && Hmod==NULL) error = U_ERROR;

    if(error==U_OK)
    {
        error     = Emf.SetGrid(gridM, gridE);
        if(error==U_OK && ReRefForw!=U_REF_RAW && gridM)
            error = Emf.SetBalancing(GridR, pBal, UMEEGDataBase::MAXMEG, ReRefForw);

        if(error==U_OK) error = SetCovariance(CovarXX, CovarTT);
    }
    if(error!=U_OK)
    {
        delete    CovXX;       CovXX       = NULL;
        delete    CovTT;       CovTT       = NULL;
        error     = U_ERROR;
        GridMEG   = NULL;
        GridEEG   = NULL;
        nKan      = 0;
        CI.AddToLog("ERROR: ULocCodeDip::ULocCodeDip(): Memory allocation error. \n");
    }
}

ULocCodeDip::~ULocCodeDip()
{
    CI.AddToLog("Note: ULocCodeDip::~ULocCodeDip(). Fit Statistics:\n");
    CI.AddToLog("N_cost_evaluations = %d\n",NtotCost);

    delete[] ULBT;

    delete[] EMData;
    delete[] ULamda;
    delete[] Lamda;
    delete[] Vmat;
    delete[] SV;
    delete[] WmatTfld;
    delete[] DataSetNames;
    delete[] nTrialsPerSet;

    delete   CovXX;
    delete   CovTT;
    delete[] Bmat;
}

UString& ULocCodeDip::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in ULocCodeDip-object\n");
        return Properties;
    }
    Properties =  UString();

    Properties += "BaseClass \n";
    Properties  += UStartStatDip::GetProperties("  ");
    if(CovXX)
    {
        Properties += "Spatial Covariance: \n";
        Properties += CovXX->GetProperties(" ");
    }
    else if(Ftype==UEMfield::U_MEGEEG)
    {
        Properties += "MEEG with OLS weighting\n";
        Properties += UString(OLS_REL_EEG_VARIANCE, "EEGWeightingFactor = %f \n");
    }
    if(CovTT)
    {
        Properties += "Temporal Covariance: \n";
        Properties += CovTT->GetProperties(" ");
    }

    if(SV)
    {
        Properties += UString(nComp, "NComponents    = %d  //// First Singular Values squared of pre-whitened data matrix in %%\n");

        for(int k=0; k<MIN(nSamples,MAX(10,nComp)); k++)
            Properties += UString(SV[k], " %7.2f ,");
        Properties += "\n";
    }
    if(pDipMan)
    {
        if(!GMAN)
        {
            Properties += "Dipole coding: \n";
            Properties += ((UCodeManager*)pDipMan)->GetProperties(" ");
        }
        else
        {
            Properties += "GMANOVA model: \n";
            Properties += UString(pDipMan->GetNDipoles(), "NDipoles             = %d \n");
            Properties += UString(nSets                 , "NDataSets            = %d \n");
            Properties += UString(nBasicSTF             , "NSourceTimeFunctions = %d \n");
            Properties += pDipMan->GetProperties(" ");
        }
    }
    if(GridMEG&&GridEEG) Properties += "DataSource        = MEG/EEG \n";
    else if(GridMEG)     Properties += "DataSource        = MEG \n";
    else if(GridEEG)     Properties += "DataSource        = EEG \n";

    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');
    else                                       Properties.InsertAtEachLine(Comment);

    return Properties;
}

int ULocCodeDip::GetNCodes() const
{
    if(GMAN) return nSets;

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNCodes(). UCodeManager* pDipMan not properly set. \n");
        return 0;
    }
    return ((UCodeManager*) pDipMan)->GetNCodes();
}

int ULocCodeDip::GetNBasicSTF() const
{
    if (GMAN)
        return nBasicSTF;
    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNBasicSTF(). UCodeManager* pDipMan not properly set. \n");
        return 0;
    }
    return ((UCodeManager*) pDipMan)->GetNBasicSTF();
}

const UString* ULocCodeDip::GetCodeNames(int *NNames) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetCodeNames(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(GMAN)
    {
        if(NNames) *NNames = nSets;
        return DataSetNames;
    }
    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetCodeNames(). UCodeManager* pDipMan not properly set. \n");
        return NULL;
    }
    return ((UCodeManager*) pDipMan)->GetCodeNames(NNames);
}

int ULocCodeDip::GetNTrialsPerSet(int q) const
{
    if (GMAN)
        return nTrialsPerSet[q];

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNTrialsPerSet(). UCodeManager* pDipMan not properly set. \n");
        return NULL;
    }
    return ((UCodeManager*) pDipMan)->GetNTrialsCode(q);
}

int ULocCodeDip::GetNFreeSTF() const
{
    if (GMAN)
        return pDipMan->GetNfreeSTF();

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNFreeSTF(). UCodeManager* pDipMan not properly set. \n");
        return NULL;
    }
    return ((UCodeManager*) pDipMan)->GetNFreeSTF();
}

int ULocCodeDip::GetNDipolesInCode(int q) const
{
    if (GMAN) // If GMANOVA is used, all dipoles are present in aal codes with prob. 1
        return pDipMan->GetNDipoles();

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNDipolesInCode(). UCodeManager* pDipMan not properly set. \n");
        return NULL;
    }
    return ((UCodeManager*) pDipMan)->GetNDipolesInCode(q);
}

const double* const* const ULocCodeDip::GetCodeMat() const
{
    if(GMAN)
        return NULL;

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetNDipolesInCode(). UCodeManager* pDipMan not properly set. \n");
        return NULL;
    }
    return ((UCodeManager*) pDipMan)->GetCodeMat();
}

ErrorType ULocCodeDip::GetDipInCodeIndex(int q, int* index) const
{
    if(GMAN)
        return U_ERROR;

    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::GetDipInCodeIndex(). UCodeManager* pDipMan not properly set. \n");
        return U_ERROR;
    }
    return ((UCodeManager*) pDipMan)->GetDipInCodeIndex(q,index);
}

ErrorType ULocCodeDip::ComputeCodeOutput(int q, int& nDipInCode, int* DipInCodeIndex, double* BasicSTF, double* CodeSTF, int nSamp) const
/*
  This routine computes the estimated STFs for each basic source in data set q, i.e.
  on output CodeSTF contains CodeMat[q]*BasicSTF
*/
{
    if(pDipMan==NULL || ((UCodeManager*) pDipMan)->GetError()!=U_OK)
    {
        CI.AddToLog("ULocCodeDip::ComputeCodeOutput(). UCodeManager* pDipMan not properly set. \n");
        return U_ERROR;
    }
    return ((UCodeManager*) pDipMan)->ComputeCodeOutput(q, nDipInCode, DipInCodeIndex, BasicSTF, CodeSTF, nSamp);
}

ErrorType ULocCodeDip::ComputeGMANSetOutput(int q, double* BasicSTF, double* STF) const
/*
  This routine computes the estimated STFs for each basic source in data set q, i.e.
  on output STF contains CM[q]*BasicSTF
*/
{
    if(!STF || !BasicSTF || !GMAN)
    {
        CI.AddToLog("ULocCodeDip::ComputeGMANSetOutput(). Invalid argument or invalid call. \n");
        return U_ERROR;
    }
    //STF = C_q * BasicSTF/sqrt

    int nFreeSTF=pDipMan->GetNfreeSTF();

    for(int p=0; p<nFreeSTF; p++)
        for(int j=0;j<nSamples;j++)
        {
            STF[p*nSamples+j] =0.;
                for(int z=0;z<nBasicSTF;z++)
                    STF[p*nSamples+j]+=CM[(q*nFreeSTF+p)*nBasicSTF+z]*BasicSTF[z*nSamples+j]/sqrt((double)nTrialsPerSet[q]);
        }

    return U_OK;
}

ErrorType ULocCodeDip::SetCovariance(UCovariance* CovNewXX, UCovariance* CovNewTT)
/* This routine can be used to overwrite the existing covariance type and matrices.*/
{
    if(CovNewXX==NULL || CovNewXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCovariance(). Invalid spatial covariance. \n");
        return U_ERROR;
    }
    if(CovNewTT==NULL || CovNewTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCovariance(). Invalid temporal covariance. \n");
        return U_ERROR;
    }

    delete CovXX; CovXX = new UCovariance(*CovNewXX);
    delete CovTT; CovTT = new UCovariance(*CovNewTT);

    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCovariance(). Copying spatial covariance. \n");
        return U_ERROR;
    }
    if(CovTT==NULL || CovTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCovariance(). Copying temporal covariance. \n");
        return U_ERROR;
    }
    nSamples = CovTT->GetNdim();
    return U_OK;
}

ErrorType ULocCodeDip::SetNDipoles(int nDipoles)
{
    return pDipMan->SetNdipoles(nDipoles);
}


ErrorType ULocCodeDip::SetDataAndCode(UCodeManager::CodeType CdT, const UMEEGDataEpochs* DatEpo)
/*
   This routine is used only for the Coupled Dipole Model, ie. when GMAN==false.
   It initializes CodeMat and computes the average data per code after reading the data from
   *DatEpo.
   The precise design of CodeMat is set using UCodeManager::SetCode, in which the exact
   design with zeroes and nonzeroes is implemented. Furthermore, the number of dipoles,
   Ndip in *pDipMan, is set, according to the code type CdT.
*/
{
    if (GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Invalid call to routine. GMANOVA model is used. \n");
        return U_ERROR;
    }

    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). UDipoleManager not properly set. \n");
        return U_ERROR;
    }
    UCodeManager* pCodeMan = new UCodeManager(*pDipMan);
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
    {
        delete pCodeMan;
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Copying UDipoleManager to UCodeManager. \n");
        return U_ERROR;
    }
    delete pDipMan;
    pDipMan = pCodeMan;

    if(DatEpo==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Invalid Argument.\n");
        return U_ERROR;
    }

/* Set UCodeManager-object and Ndip */
    if (SetCode(CdT)!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Error in setting the Code.\n");
        return U_ERROR;
    }

/* Allocate memory for Bmat */
    int nBasSTF = pCodeMan->GetNBasicSTF();
    if(Bmat)     delete[] Bmat;
    Bmat       = new double[nBasSTF*nSamples];
    if(!Bmat)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Memory allocation.\n");

        delete[] Bmat;    Bmat = NULL;
        return U_ERROR;
    }
    for(int k=0; k<nBasSTF*nSamples; k++) Bmat[k] = 0;

    nSets                    = GetNCodes();
    const UString* CodeNames = GetCodeNames(NULL);
    if(CodeNames==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). No CodeNames in CodeManager.\n");
        return U_ERROR;
    }

/* Check CodeNames are amongst MarkerNames */
    int nTrialsPerCode[MAXCODES];
    int q=0;
    for(q=0;q<nSets;q++) nTrialsPerCode[q]=0;
    DatEpo->GetNEpochsPerMarkers(CodeNames, nSets, nTrialsPerCode);
    for(q=0;q<nSets;q++)
        if (nTrialsPerCode[q]==0)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). No epochs with markername %s.\n",CodeNames[q]);
            return U_ERROR;
        }

/* Get average MEG data per code (markername) */
    double** AverCodeDataMEG = new double*[MAXCODES];
    for(q=0;q<nSets;q++) AverCodeDataMEG[q] = NULL;

    for(q=0;q<nSets;q++)
    {
        AverCodeDataMEG[q] = DatEpo->GetAveragedData(U_DAT_MEG, CodeNames[q]);
        if(!AverCodeDataMEG[q])
        {
            for(int qq=0; qq<q;qq++) delete[] AverCodeDataMEG[q];
            delete AverCodeDataMEG;
            CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Memory allocation. \n");
            return U_ERROR;
        }
    }

/* Set averaged data in ULCD */
    if(SetData(AverCodeDataMEG, NULL, nTrialsPerCode, nSets)!=U_OK)
    {
        for(int q=0; q<nSets; q++)
            delete[] AverCodeDataMEG[q];
        delete AverCodeDataMEG;
        CI.AddToLog("ERROR: ULocCodeDip::SetDataAndCode(). Reading/preparing the filtered MEG/EEG data.\n");
        return U_ERROR;
    }
    for(q=0; q<nSets; q++)
        delete[] AverCodeDataMEG[q];
    delete AverCodeDataMEG;

    return U_OK;
}

ErrorType ULocCodeDip::SetData(double **DataMEG, double **DataEEG, int* nTrialsPerCode, int nCodes)
/*
   Store the data as well as allocate the memory for the data help arrays
   and perform as many as possible pre-computations.
*/
{
/* Test arguments and settings of this object */
    if( !DataMEG && !DataEEG)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). No data input: both MEG and EEG data arrays are NULL!.\n");
        return error = U_ERROR;
    }
    if( (DataMEG && !GridMEG) || (!DataMEG && GridMEG) )
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Setting MEG-data while MEG-grid not set, or other way around.\n");
        return error = U_ERROR;
    }
    if( (DataEEG && !GridEEG) || (!DataEEG && GridEEG) )
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Setting EEG-data while EEG-grid not set, or other way around.\n");
        return error = U_ERROR;
    }
    if(nSamples<=0)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Object not properly initialized (Nsamp= %d).\n",nSamples);
        return error = U_ERROR;
    }
    if(nTrialsPerCode==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Invalid Argument nTrialsPerCode.\n");
        return error = U_ERROR;
    }
    if(nCodes<=0 || nCodes > MAXCODES)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Invalid Argument ncodes (=%d).\n",nCodes);
        return error = U_ERROR;
    }

    UCodeManager* pCodeMan = NULL;
    if(!GMAN)
    {
        pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetData(). UCodeManager not properly set. \n");
            return U_ERROR;
        }
    }
    if(CovTT==NULL)
    {
        CovTT = new UCovariance(nSamples, true);
        if(CovTT==NULL || CovTT->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetData(). Setting default temporal covariance matrix. \n");
            return error = U_ERROR;
        }
    }

    int nBasSTF =0 ;
    if(GMAN) nBasSTF = nBasicSTF;
    else     nBasSTF = pCodeMan->GetNBasicSTF();
    if(Bmat)      delete[] Bmat;
    Bmat        = new double[nBasSTF*nSamples];
    if(!Bmat)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Memory allocation.\n");

        delete[] Bmat;    Bmat = NULL;
        return U_ERROR;
    }
    for(int k=0; k<nBasSTF*nSamples; k++) Bmat[k] = 0;

    if(!GMAN)
    {
        pCodeMan->SetNTrialsPerCode(nTrialsPerCode);
        pCodeMan->ScaleCodeMatWithTrials(nTrialsPerCode);
    }

/* Allocate the memory, but first delete the old ones*/

    delete[] EMData;    EMData   = new double[nCodes*nKan*nSamples];
    delete[] ULamda;    ULamda   = new double[nCodes*nKan*nSamples];
    delete[] Lamda;     Lamda    = new double[nSamples];
    delete[] Vmat;      Vmat     = new double[nSamples*nSamples];
    delete[] SV;        SV       = new double[nSamples];

    double* HelpData = new double [nKan*nSamples];

    if(!EMData || !ULamda || !Lamda || !Vmat || !SV || !HelpData)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Memory allocation. nKan=%d, Nsamp=%d\n",nKan,nSamples);
        delete[] EMData;   EMData   = NULL;
        delete[] ULamda;   ULamda   = NULL;
        delete[] Lamda;    Lamda    = NULL;
        delete[] Vmat;     Vmat     = NULL;
        delete[] SV;       SV       = NULL;
        delete[] HelpData; HelpData = NULL;
        return U_ERROR;
    }
    nComp = 0;

/* Compute the stacked matrix with the prewhitened data of all data sets underneath each other */

    for(int q=0; q<nCodes; q++)
    {
        /* Storing Data of code q in HelpData and prewhiten spatially */
        int i=0;
        for(i=0; i<nKan; i++)
        {
            if(i<nMEG)                    // First the MEG data ...
            {
                for(int j=0; j<nSamples; j++)
                    HelpData[i*nSamples+j] = sqrt((double)nTrialsPerCode[q])*DataMEG[q][i*nSamples+j];
            }
            else
            {
                for(int j=0; j<nSamples; j++) // ... then the EEG data
                    HelpData[i*nSamples+j] = sqrt((double)nTrialsPerCode[q])*DataEEG[q][i-nMEG*nSamples+j];
            }
        }
        if(CovXX)
        {
            if(CovXX->MultiplyWmatTA(HelpData, nSamples)!=U_OK)
            {
                CI.AddToLog("ERROR: ULocCodeDip::SetData(). Pre-multiplying data matrix of code %d with spatial covariance. \n",q);
                delete[] HelpData;
                return error = U_ERROR;
            }
        }

        /* Copying the spatially prewhitened data of code q in EMData */
        for(i=0; i<nKan; i++)
        {
            for(int j=0; j<nSamples; j++)
                EMData[(q*nKan+i)*nSamples+j] = HelpData[i*nSamples+j];
        }
    }
    delete[] HelpData;


/* Pre-whiten the data matrix EmData[] */
    if(CovTT)
    {
        if(CovTT->MultiplyAWmat(EMData, nCodes*nKan)!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetData(). Post-multiplying data matrix with temporal covariance. \n");
            return error = U_ERROR;
        }
    }

    int k=0;
    for(k=0; k<nCodes*nKan*nSamples; k++) ULamda[k] = EMData[k];

/* Compute SVD  and normalized singular values. */
    svdcmp_d(ULamda, nCodes*nKan, nSamples, Lamda, Vmat);

    for(int i=0; i<nCodes*nKan; i++)
        for(int j=0; j<nSamples; j++)
            ULamda[i*nSamples+j] *= Lamda[j];

    DataNorm = 0.;
    for(k=0; k<nSamples; k++) DataNorm += Lamda[k]*Lamda[k];
    if(DataNorm<1.e-10)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetData(). Sum of (weighted) squares of data matrix almost vanishes. DataNorm = %e\n",DataNorm);
        return error = U_ERROR;
    }
    for(k=0; k<nSamples; k++) SV[k] = 100*Lamda[k]*Lamda[k]/DataNorm;

    return U_OK;
}

ErrorType ULocCodeDip::SetCode(UCodeManager::CodeType CdT, bool CodeOnly)
/*
   This routine is used only when the Coupled Dipole Model is used, i.e. when GMAN==false.
   The code parameters are set, according to CdT, using the UCodeManager object. In
   UCodeManager::SetCodeParameters() the precise design of zeroes and nonzeroes is
   defined. Memory for Bmat is allocated in this routine.
   The bool CodeOnly==true is used when SetCode() is used i.s.o. SetDataAndCode().
   Default: CodeOnly==false.
*/
{
    if(GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Invalid call. GMANOVA model is used. \n");
        return U_ERROR;
    }

    if(CodeOnly)
    {
        if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetCode(). UDipoleManager not properly set. \n");
            return U_ERROR;
        }
        UCodeManager* pCodeMan = new UCodeManager(*pDipMan);
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
        {
            delete pCodeMan;
            CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Copying UDipoleManager to UCodeManager. \n");
            return U_ERROR;
        }
        delete pDipMan;
        pDipMan = pCodeMan;

        if (pCodeMan->SetCodeParameters(CdT)!=U_OK)
            return U_ERROR;
        int nBasicSTF = pCodeMan->GetNBasicSTF();
        delete[] Bmat;
        Bmat = new double[nBasicSTF*nSamples];
        if(!Bmat)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Memory allocation.\n");

            delete[] Bmat;    Bmat = NULL;
            return U_ERROR;
        }
        for(int k=0; k<nBasicSTF*nSamples; k++) Bmat[k] = 0;
        return U_OK;
    }
    else
    {
        UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetCode(). UCodeManager not properly set. \n");
            return U_ERROR;
        }

        if (pCodeMan->SetCodeParameters(CdT)!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Error in setting code. \n");
            return U_ERROR;
        }
        return U_OK;
    }
}

ErrorType ULocCodeDip::SetCoupleDesign(bool** CoupleMat, char** MarNames, int nCondition, int nBasicSTF, UDipoleEdit* DipEd, int nDipoles)
{
    if (!CoupleMat || !MarNames || nCondition <1 || nBasicSTF <1 || !DipEd || nDipoles <1)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(CoupleMat). Invalid Argument.\n");
        return U_ERROR;
    }

    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(). UDipoleManager not properly set. \n");
        return U_ERROR;
    }
    UCodeManager* pCodeMan = new UCodeManager(*pDipMan);
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
    {
        delete pCodeMan;
        CI.AddToLog("ERROR: ULocCodeDip::SetCode(). Copying UDipoleManager to UCodeManager. \n");
        return U_ERROR;
    }
    delete pDipMan;
    pDipMan = pCodeMan;

    return pCodeMan->SetCoupleDesign(CoupleMat, MarNames, nCondition, nBasicSTF, DipEd, nDipoles);
}


ErrorType ULocCodeDip::SetCM(const double* cm)
/*Overwrite CM with cm*/
{
    if(GMAN==false)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCM(). Invalid call. GMANOVA model is not used. \n");
        return U_ERROR;
    }

    if(cm == NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetCM(). Invalid argument. \n");
        return U_ERROR;
    }

    int nFreeSTF=pDipMan->GetNfreeSTF();
    for(int q=0;q<nSets;q++)
        for(int p=0;p<nFreeSTF;p++)
            for(int z=0;z<nBasicSTF;z++)
            {
                if(!cm[(q*nFreeSTF+p)*nBasicSTF+z])
                {
                    CI.AddToLog("ERROR: ULocCodeDip::SetCM(). Invalid argument. \n");
                    return U_ERROR;
                }
                CM[(q*nFreeSTF+p)*nBasicSTF+z]=cm[(q*nFreeSTF+p)*nBasicSTF+z];
            }

    return U_OK;
}

ErrorType ULocCodeDip::SetECDMDesignAndData(char** MarNames, int nCondition, int nBas, UDipoleEdit* DipEd, int nDipoles, double **DataMEG, double **DataEEG, int* nTrialsPerCode)
/*
This routine initializes the ECDM design and read the data.
*/
{
/* Check arguments */
    if (!MarNames || nCondition <1 || nBas <1 || !DipEd || nDipoles <1 ||
        (DataMEG ==NULL && DataEEG==NULL) || nTrialsPerCode == NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData(CoupleMat). Invalid Argument.\n");
        return U_ERROR;
    }
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData(). UDipoleManager not properly set. \n");
        return U_ERROR;
    }

/* Set number of dipoles in UDipoleManager object */
    int iDip=0;
    for(iDip=0;iDip<nDipoles;iDip++)
    {
        if(DipEd[iDip].GetDipoleType() != DipEd[0].GetDipoleType())
            break;
    }
    if(iDip<nDipoles)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData(). Different dipole types not implemented (yet).\n");
        return U_ERROR;
    }
    if(pDipMan->SetNdipoles(nDipoles)!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData() : Error in setting number of dipoles. \n");
        return U_ERROR;
    }

/* Set the ECDM design parameters */
    nBasicSTF    = nBas;
    nSets        = nCondition;
    int iCond    = 0;
    int nFreeSTF = pDipMan->GetNfreeSTF();
    DataSetNames = new UString[nCondition];
    for(iCond=0;iCond<nSets;iCond++)
        DataSetNames[iCond] = UString(MarNames[iCond]);

/* Allocate memory for Bmat */
    if (CM)  delete[] CM;
    if(Bmat) delete[] Bmat;
    if(nTrialsPerSet) delete[] nTrialsPerSet;
    CM            = new double[nSets*nFreeSTF*nBasicSTF];
    Bmat          = new double[nBasicSTF*nSamples];
    nTrialsPerSet = new int[nCondition];
    if(!CM || !Bmat)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData(). Memory Allocation error.\n");
        return U_ERROR;
    }
    for(int k=0; k<nBasicSTF*nSamples; k++) Bmat[k] = 0.;
    for(int k=0; k<nSets*nFreeSTF*nBasicSTF; k++) CM[k] = 0.;
    for(int k=0; k<nCondition;k++) nTrialsPerSet[k]=nTrialsPerCode[k];

/* Set the data and corresponding arrays */
    if( SetData(DataMEG, DataEEG, nTrialsPerCode, nSets) != U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetECDMDesignAndData() : Error in setting data. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType ULocCodeDip::SetGMANOVAData(int nDip, int nBas, const UMEEGDataEpochs* DatEpo, const double* PushData)
/*
   This routine is only used for the GROM model, i.e. when GMAN ==true
   This routine reads and stores data from DatEpo. The markers set in DatEpo, define the
   different data set names, and nSets. The number of dipoles in the UDipoleManager is set to nDip.
*/
{
    if(GMAN==false)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Invalid call to routine. GMANOVA model is not used.\n");
        return U_ERROR;
    }
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). UDipoleManager not properly set. \n");
        return U_ERROR;
    }
    if(DatEpo==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Invalid Argument.\n");
        return U_ERROR;
    }
    if(nBas <=0 || nDip <=0)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Invalid Argument.\n");
        return U_ERROR;
    }

    DataSetNames = DatEpo->GetUsedMarkerNames(&nSets);

    if (SetNDipoles(nDip)!= U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Setting number of dipoles.\n");
        return U_ERROR;
    }

/* Set GMANOVA variables */
    nSamples  = DatEpo->GetNSampEpoch(0);
    nBasicSTF = nBas;
    int nFreeSTF = pDipMan->GetNfreeSTF();
    if (CM)
    {
        delete[] CM; CM = NULL;
    }
    CM = new double[nSets*nFreeSTF*nBasicSTF];
    if(CM==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Memory Allocation error.\n");
        return U_ERROR;
    }

/* Check DataSetNames are amongst MarkerNames */
    if(nTrialsPerSet) delete[] nTrialsPerSet;
    nTrialsPerSet = new int[MAXCODES];
    int q=0;
    for(q=0;q<MAXCODES;q++) nTrialsPerSet[q]=0;
    DatEpo->GetNEpochsPerMarkers(DataSetNames, nSets, nTrialsPerSet);
    for(q=0;q<nSets;q++)
        if (nTrialsPerSet[q]==0)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). No epochs with markername %s.\n",DataSetNames[q]);
            return U_ERROR;
        }

/* Get average MEG data per data set (markername) */
    double** AverDataSet = new double*[MAXCODES];
    if(AverDataSet == NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Memory allocation. \n");
        return U_ERROR;
    }

    for(q=0;q<nSets;q++) AverDataSet[q] = NULL;

    for(q=0;q<nSets;q++)
    {
        AverDataSet[q] = DatEpo->GetAveragedData(U_DAT_MEG, DataSetNames[q]);
        if(!AverDataSet[q])
        {
            for(int qq=0; qq<q;qq++) delete[] AverDataSet[q];
            delete[] AverDataSet;
            CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Memory allocation. \n");
            return U_ERROR;
        }
    }

    if(CovTT==NULL)
    {
        CovTT = new UCovariance(nSamples, true);
        if(CovTT==NULL || CovTT->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Setting default temporal covariance matrix. \n");
            return error = U_ERROR;
        }
    }
    else if(CovTT->GetNdim()!=nSamples)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Number of samples of data window (%d) is not equal to the number of samples in covariance file (%d). \n",nSamples,CovTT->GetNdim());
        return error = U_ERROR;
    }

/* Allocate the memory, but first delete the old ones*/

    delete[] EMData;    EMData   = new double[nSets*nKan*nSamples];
    delete[] ULamda;    ULamda   = new double[nSets*nKan*nSamples];
    delete[] Lamda;     Lamda    = new double[nSamples];
    delete[] Vmat;      Vmat     = new double[nSamples*nSamples];
    delete[] SV;        SV       = new double[nSamples];

    double* HelpData = new double [nKan*nSamples];

    if(!EMData || !ULamda || !Lamda || !Vmat || !SV || !HelpData)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Memory allocation. nKan=%d, Nsamp=%d\n",nKan,nSamples);
        delete[] EMData;   EMData   = NULL;
        delete[] ULamda;   ULamda   = NULL;
        delete[] Lamda;    Lamda    = NULL;
        delete[] Vmat;     Vmat     = NULL;
        delete[] SV;       SV       = NULL;
        delete[] HelpData; HelpData = NULL;
        return U_ERROR;
    }
    nComp = 0;

/* Compute the matrix R with the prewhitened MEG data of all data sets*/
/* EEG data is not yet implemented */
    if(nKan != nMEG)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Number of MEG channels does not equal total number of channels. \n",q);
        return U_ERROR;
    }

    if(PushData)
    {
        nSets=1;
        nTrialsPerSet[0]=1;
        int i=0;
        for(i=0; i<nKan; i++)
            for(int j=0; j<nSamples; j++)
                HelpData[i*nSamples+j] = PushData[i*nSamples+j];
        if(CovXX)
        {
            if(CovXX->MultiplyWmatTA(HelpData, nSamples)!=U_OK)
            {
                CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Pre-multiplying data matrix of code %d with spatial covariance. \n",q);
                delete[] HelpData;
                return error = U_ERROR;
            }
        }

        /* Copying the spatially prewhitened data of data set q in EMData */
        for(i=0; i<nKan; i++)
        {
            for(int j=0; j<nSamples; j++)
                EMData[i*nSamples+j] = HelpData[i*nSamples+j];
        }
    }

    else
    {
        for(q=0; q<nSets; q++)
        {
            /* Storing Data of code q in HelpData and prewhiten spatially */
            int i=0;
            for(i=0; i<nKan; i++)
                for(int j=0; j<nSamples; j++)
                    HelpData[i*nSamples+j] = sqrt((double)nTrialsPerSet[q])*AverDataSet[q][i*nSamples+j];

            if(CovXX)
            {
                if(CovXX->MultiplyWmatTA(HelpData, nSamples)!=U_OK)
                {
                    CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Pre-multiplying data matrix of code %d with spatial covariance. \n",q);
                    delete[] HelpData;
                    return error = U_ERROR;
                }
            }

            /* Copying the spatially prewhitened data of data set q in EMData */
            for(i=0; i<nKan; i++)
            {
                for(int j=0; j<nSamples; j++)
                    EMData[(q*nKan+i)*nSamples+j] = HelpData[i*nSamples+j];
            }
        }
    }
    delete[] HelpData;


/* Pre-whiten the data matrix EMData[] temporally */
    if(CovTT)
    {
        if(CovTT->MultiplyAWmat(EMData, nSets*nKan)!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Post-multiplying data matrix with temporal covariance. \n");
            return error = U_ERROR;
        }
    }

    int k=0;
    for(k=0; k<nSets*nKan*nSamples; k++) ULamda[k] = EMData[k];

/* Compute SVD and normalized singular values. */
    svdcmp_d(ULamda, nSets*nKan, nSamples, Lamda, Vmat);

    for(int i=0; i<nSets*nKan; i++)
        for(int j=0; j<nSamples; j++)
            ULamda[i*nSamples+j] *= Lamda[j];

    DataNorm = 0.;
    for(k=0; k<nSamples; k++) DataNorm += Lamda[k]*Lamda[k];
    if(DataNorm<1.e-10)
    {
        CI.AddToLog("ERROR: ULocCodeDip::SetGMANOVAData(). Sum of (weighted) squares of data matrix almost vanishes. DataNorm = %e\n",DataNorm);
        return error = U_ERROR;
    }
    for(k=0; k<nSamples; k++) SV[k] = 100*Lamda[k]*Lamda[k]/DataNorm;

    for(q=0; q<nSets; q++)
        delete[] AverDataSet[q];
    delete AverDataSet;

    return U_OK;
}

ErrorType ULocCodeDip::SetNComp(int ncmp, double thres)
/*
This routine sets the number of singular values ofthe data
array (Ncomp) that is taken into account in the parameter
estimation.
IF                 THEN
ncmp>0 and thres<0   nComp = MIN(ncmp,nSamples).
ncmp>0 and thres>0   nComp = MIN(ncmp,nSamples) and thres is ignored.
ncmp<0 and thres>0   nComp is adjusted such that the power
                      in the first nComp singular values of
                      the data array equals at least (1-thres)x100%
                      of the total data power.
                      if thres>=1, then nComp = nSamples.
ncmp<0 and thres<0   nComp = nBasicSTF, the rank of the dipole model
*/
{
    if(ncmp<=0  && thres<0.)
    {
        nComp = GetNBasicSTF();
        return U_OK;
    }
    if(ncmp >0)
    {
        if(ncmp > nSamples)
            nComp = nSamples;
        else
            nComp = ncmp;
        return U_OK;
    }
    if(ncmp <0 && thres >0.)
    {
        if(thres >= 1.)
            nComp = nSamples;
        else
        {
            int    k      = nSamples-1;
            double RelPow = 0.;

            while (k>=0 && RelPow<thres)
            {
                RelPow += Lamda[k]*Lamda[k]/DataNorm;
                k--;
            }
            nComp = k+2;
        }
        return U_OK;
    }
    return U_ERROR;
}



ErrorType ULocCodeDip::ComputeDipoles(UDipoleEdit* DipEd, int Ndip, double *residual, double** DNorm, double *BasicSTF, double *residualPerCode)
{
    ErrorType E = U_ERROR;

/* Check for validity of arguments */
    if(DipEd==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Invalid NULL argument in DipArray. \n");
        return E;
    }
    if(Ndip<=0 || Ndip>=MAXSTATDIP)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Number of dipoles out of range (%d) \n",Ndip);
        return E;
    }

    UDipole* DipAr = new UDipole[pDipMan->GetNDipoles()];
    if(DipAr==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Allocating memory for dipoles in DipEd.\n");
        return E;
    }

    pDipMan->GetAllDipoles(DipAr);
    for(int k=0; k<Ndip; k++)
    {
        if(DipAr[k].GetDipoleType()!=DipEd[k].GetDipoleType())
        {
            CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Dipole types not compatible for dipole %d.\n",k);
            return E;
        }
        if (pDipMan->IsDipoleRotating(k) != DipEd[k].GetRotating() )
        {
            CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Dipole rotation types not compatible for dipole %d.\n",k);
            return E;
        }
    }

/* Compute dipoles in UDipole array */
    E = ComputeDipoles(DipAr,Ndip, residual, DNorm, BasicSTF, residualPerCode);

/* Copy dipoles positions and orientations to UDipoleEdit array */
    for(int k=0; k<Ndip; k++)
    {
        DipEd[k].Setx(DipAr[k].Getx());
        DipEd[k].Setd(DipAr[k].Getd());
        DipEd[k].SetdSym(DipAr[k].GetdSym());
    }

    delete[] DipAr;
    return E;
}


ErrorType ULocCodeDip::ComputeDipoles(UDipole* DipArray, int nDipoles, double *residual, double** DNorm, double *BasicSTF, double *residualPerCode)
/*
    Compute the optimal stationary (basic) dipoles for the data in EMData using
    the Coupled Dipole Mode (GMAN==false) or the GMANOVA model (GMAN==true).
    nDipoles is used only if GMAN==true. For GMAN==false, the number of dipoles is
    already set in SetDataAndCode()
    The Dipoles present in DipArray act as starting values. On return, these
    starting values are replaced by the optimal dipoles.

    If(residual) also compute and store the residual error
    If(DNorm) the datanorm per data set per sample is output in DNorm[dataset][sample]
    If(ResidualPerCode) the residual per data set is output in ResidualPerCode[dataset]
    If(BasicSTF) the basic source time functions are output in BasicSTF[p*nSamples+j]
                 (p=basicSTF index, j=sample index)

    Update NtotCost
*/
{
    UCodeManager* pCodeMan = NULL;
    if (!GMAN)
    {
        pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). UCodeManager not properly set. \n");
            return U_ERROR;
        }
    }

    if(DipArray==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Invalid NULL argument. \n");
        return U_ERROR;
    }

    if( (!GridMEG && !GridEEG) ||
        ( GridMEG &&  GridEEG) ||
          error   != U_OK      ||
          EMData  == NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Data not properly set. \n");
        return U_ERROR;
    }

    int nFreeSTF =0;
    if(GMAN) nFreeSTF = pDipMan->GetNfreeSTF();
    else     nFreeSTF = pCodeMan->GetNfreeSTF();
    if (!GMAN)
    {
         nBasicSTF = pCodeMan->GetNBasicSTF();
         nSets     = pCodeMan->GetNCodes();
    }

/* Allocate some general memory for intermediate arrays */
    delete[] ULBT;
    ULBT   = new double[nKan*nFreeSTF];
    if(ULBT==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Memory allocation: nKan=%d, nFreeSTF=%d \n",nKan,nFreeSTF);
        return U_ERROR;
    }

    if(nComp<=0 || nComp>nSamples || nComp>nKan)
        SetNComp(MIN(nKan,nSamples),-1.);

    if(GetStartDipoles(DipArray, nDipoles, true)!=U_OK)
    {
        delete[] ULBT; ULBT = NULL;
        CI.AddToLog("ERROR: ULocCodeDip::ComputeDipoles(). Getting start dipoles. \n");
        return U_ERROR;
    }

    CI.AddToLog("Note: ULocCodeDip::ComputeDipoles(). Iterate Cost function:\n");
    CI.TimeReset("");
    double Position[3*MAXDIPOLES];
    if(!GMAN)
    {
        pCodeMan->GetPositionArray(Position);
        Iterate(Position, pCodeMan->GetNfreePosPars());
    }
    else
    {
        pDipMan->GetPositionArray(Position);
        Iterate(Position, pDipMan->GetNfreePosPars());
    }
    CI.TimeFlag("\nIterate Costfunction.");

    double ResError = ComputeCost(Position); // Update orientation in any case

    if(!GMAN)
    {
        pCodeMan->GetAllDipoles(DipArray);
        pCodeMan->UpdateIsDipSTFInCode();
        pCodeMan->UpdateCodeMat();
    }
    else
    {
        pDipMan->GetAllDipoles(DipArray);
        *residual = UpdateSTFmatAndCM();
    }

    if(residual || !GMAN) *residual = ResError;

/* Compute pre-whitened power per code (sum of all channels) including the Sqrt(nTrials[q]) factor*/
    if(DNorm)
        for(int q=0;q<nSets;q++)
        {
            for(int j=0; j<nSamples; j++)
            {
                DNorm[q][j] = 0.;
                for(int i=0; i<nKan; i++)
                    DNorm[q][j] += EMData[(q*nKan+i)*nSamples+j]*EMData[(q*nKan+i)*nSamples+j];
            }
        }

   if(DNorm && residualPerCode)
   {
       if(!GMAN)
       {
           if(ComputeResPerCode(residualPerCode, DNorm, residual)!=U_OK)
           {
                CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Computing residuals.\n");
                return U_ERROR;
           }
       }
       else // Compute overall residual and residual per code for GMANOVA model
       {
           if(ComputeGMANOVAResiduals(residual, residualPerCode, DNorm)!=U_OK)
           {
                CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Computing residuals.\n");
                return U_ERROR;
           }
       }

   }

/* Compute source time functions
   if GMAN==false: STF = Bmat * VmatT * Wmatinv = Bmat * VmatT * Lamda * WmatT
   if GMAN==true:  STF = Bmat * Wmatinv         = Bmat * Lamda * WmatT .
   If the estimated source time functions of a particular source is over all
   data sets mainly negative, then the direction is inverted and the corresponding
   entries of all coupling matrices (that is, one row in each matrix) are inverted too.
   If the sign of a basic STF is mainly negative, then the basicSTF is inverted,
   and so are the correspondig entries in all coupling matrices (that is, one column
   in each matrix).
   */

    if(BasicSTF)
    {
        UMatrix Lamda = CovTT->GetLamda();

        int z=0;
        for(z=0; z<nBasicSTF;z++)
            for(int j=0; j<nSamples; j++)
            {
                BasicSTF[z*nSamples+j] = 0;
                if(!GMAN)
                    for(int k=0; k<nComp; k++)
                        BasicSTF[z*nSamples+j] += Bmat[z*nComp+k]*Vmat[j*nSamples+k];
                else
                    BasicSTF[z*nSamples+j] = Bmat[z*nSamples+j];


                if(Lamda.GetError()==U_OK) BasicSTF[z*nSamples+j] *= Lamda.GetElement(j,j);
            }

        if (CovTT->MultiplyAWmatT(BasicSTF, nBasicSTF)!=U_OK)
            return U_ERROR;

/* Check whether basic STFs have mainly positive sign, else invert */
        for (z=0;z<nBasicSTF;z++)
        {
            int sgn=0;
            for (int j=0;j<nSamples;j++)
                sgn += GetSign(BasicSTF[z*nSamples+j]);
            if (sgn<0)
            {
                for(int j=0;j<nSamples;j++) BasicSTF[z*nSamples+j] *= -1;
                InvertBasicSTF(z);
            }
        }

/* Check whether output STFs for each source have mainly positive sign, else invert orientations */
        for(int p=0, istf=0; p<nDipoles; p++)
        {
            bool INV = false;
            if((!GMAN && GetSignOfCodedSTF(p,istf)<0) || (GMAN && GetSignOfSTF(istf, BasicSTF)<0))
            {
                INV = true;
                DipArray[p].Setd(-DipArray[p].Getd());
            }
            if(INV==true && !GMAN) pCodeMan->InvertFreeSTF(istf);
            if(INV==true && GMAN) InvertFreeSTF(istf);
            istf += 1;

            if(DipArray[p].GetDipoleType()==UDipole::SymmetricPos)
            {
                bool INV = false;
                if((!GMAN && GetSignOfCodedSTF(p,istf)<0) || (GMAN && GetSignOfSTF(istf, BasicSTF)<0))
                {
                    INV = true;
                    DipArray[p].SetdSym(-DipArray[p].GetdSym());
                }

                if(INV==true && !GMAN) pCodeMan->InvertFreeSTF(istf);
                if(INV==true && GMAN) InvertFreeSTF(istf);
                istf += 1;
            }
        }
        pDipMan->UpdateFreeDipoles(DipArray);

        return U_OK;
    }
    return error;
}

double* ULocCodeDip::GetPrewGetEMfield(const UDipole* Dip)
/*
    Return the (spatially) pre-whitened forward field for given dipole parameters Dip
*/
{
    double* WmatTfld = Emf.GetEMfield(Dip, D_OriPos10, Ftype); //field der. w.r.t. to orientations
    int     ncmp     = UEMfield::GetNcomp(D_OriPos10, *Dip);

    if(WmatTfld==NULL ||
       CovXX->MultiplyWmatTA(WmatTfld, ncmp)!=U_OK)
    {
        delete[] WmatTfld;
        return NULL;
    }
    return WmatTfld;
}

double ULocCodeDip::ComputeCost(const double* const* WEMdat, double FitTest)
/*
    Compute the cost function, for given forward field WEMdat.
    The argument FitTest is used for the stop criterium in the iteration.
    Default: FitTest = 0.999999.

    The pre-whitened forward fields are stored in WEMdat[0], WEMdat[1], ...
    The dipole moments and the basic STFs (Bmat) are normalized, while the
    coupling parameters (CodePars for GMAN==false or CM for GMAN==true) contain
    the amplitude.

    if GMAN==false:
    loop over {UpdateCodes()} and {loop over UpdateMoments() and UpdateBmat()}

    if GMAN == true:
    loop over {UpdateGMANOVAMoments()} and {Compute CM and Bmat}


    On output, the dipole moments of Dip[] are updated.
 */
{
    if(!GMAN)
    {
        UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return COSTERROR;

        double Cost    = COSTERROR;
        double CostMom = COSTERROR;

        if(pCodeMan->SetFreeDerivField(WEMdat)!=U_OK) // stores prewhitened field in DipMan
            return Cost;

        Cost = UpdateBmat();
        NormalizeBmat();
        Cost = UpdateCodes();
        if(pCodeMan->GetNfreeMoment()==0) return Cost;

        double OldCost    = Cost;
        double OldCostMom = Cost;

    /*Compute the optimal codes, moments and STFs */
        for(int liter1=0; liter1<MAXLINITER; liter1++)
        {
            OldCostMom = Cost;
            for(int liter=0; liter<MAXLINITER; liter++)    // inner loop to update STF and moments
            {
                CostMom = UpdateMoments();
                CostMom = UpdateBmat();
                if(CostMom>FitTest*OldCostMom) break;
                OldCostMom = CostMom;
            }
            Cost=CostMom;
            NormalizeBmat();
            Cost = UpdateCodes();
            if(Cost>FitTest*OldCost) break;  // test whether cost has reached minimum
            OldCost = Cost;
        }
        return Cost;
    }
    else //if GMAN==true
    {
        double Cost = COSTERROR;

        if(pDipMan->SetFreeDerivField(WEMdat)!=U_OK) // stores prewhitened field in DipMan
            return Cost;

        Cost = UpdateSTFmatAndCM();
        if(pDipMan->GetNfreeMoment()==0) return Cost;

        double OldCost = Cost;

 /* Compute the optimal moments and STFmat and CM */
        for(int liter1=0; liter1<MAXLINITER; liter1++)
        {
            UpdateGMANOVAMoments();
            Cost = UpdateSTFmatAndCM();
            if(Cost>FitTest*OldCost) break;  // test whether cost has reached minimum
            OldCost = Cost;
        }

        return Cost;

    }
}

double ULocCodeDip::ComputeCost(double *par, int iter, int *status, double *grad)
/*
    Compute cost function for the given position parameters par[].
    In both cases, the dipole components are stored in the array Directions[].

    if(grad)   compute the MINUS-gradient of the cost
 */
{

    UCodeManager* pCodeMan = NULL;
    if (!GMAN)
    {
        pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK)
            return COSTERROR;

    }

////    if(GridEEG && grad && Emf.GetModel()==UHeadModel::U_HOMSPHERE)
    if(grad)
        return Uminimize::ComputeCost(par, iter, status, grad);

    if(grad)
    {
        for(int l=0; l<pCodeMan->GetNfreePosPars()/3; l++)
        {
            UDipoleFix DipF = pCodeMan->GetFreeDipole(l);
            if(DipF.AreMomentsRotating()==false &&
               DipF.GetDipoleType()==UDipole::SymmetricPos)  // There are still bugs in this case
            {
                return Uminimize::ComputeCost(par, iter, status, grad);
            }
        }
    }

    if(status)
    {
        NtotCost++;     // Only count the number of costs, required by the Non-Linear optimization methods
        *status = 0;
    }

    double Cost  = COSTERROR;
    int NPosPars = 0;
    if(!GMAN) NPosPars = pCodeMan->GetNfreePosPars();
    else      NPosPars = pDipMan->GetNfreePosPars();

    UDipole Dips[MAXDIPOLES];
    if(!GMAN)
    {
        pCodeMan->UpdateDipolePositions(par);
        pCodeMan->GetFreeDipoles(Dips);
    }
    else
    {
        pDipMan->UpdateDipolePositions(par);
        pDipMan->GetFreeDipoles(Dips);
    }

    int l=0;
    for(l=0; l<NPosPars/3; l++)
    {
        WmatTfld[l]  = GetPrewGetEMfield(Dips+l); // Get pre-whitened predicted EM fields
        if(WmatTfld[l]==NULL)
        {
            for(int l2=0; l2<l; l++) delete[] WmatTfld[l2];
            return Cost;
        }
    }

    Cost = ComputeCost(WmatTfld); // stores prewhitened fields in DipMan
    for(l=0; l<NPosPars/3; l++)
         delete[] WmatTfld[l];

    return Cost;

}

ErrorType ULocCodeDip::ComputeResPerCode(double* resPerCode, double** DNorm, double* residual)
/*
This routine calculates the residual error in % datapower per code using
Bmat, CodeMat and the dipole parameters as they have been estimated in
ComputeCost.
*/
{
    if(!resPerCode || !DNorm)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeResPerCode(). Invalid Argument");
        return U_ERROR;
    }

    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return U_ERROR;

    int           nCodes    = pCodeMan->GetNCodes();
    int           nBasicSTF = pCodeMan->GetNBasicSTF();
    int           nFreeSTF  = pCodeMan->GetNfreeSTF();
    const double* WPsiMat   = pCodeMan->GetFieldSTF();
    const double* const* const CodeMat     = pCodeMan->GetCodeMat();

    double res = 0.;
    double pow = 0.;
    for (int q=0;q<nCodes;q++)
    {
        double res_q=0.;
        double pow_q=0.; //power of code q= sum_j DataNorm[q][j]
        int j=0;
        for(j=0;j<nSamples;j++)
            pow_q += DNorm[q][j];

        for(j=0;j<nSamples;j++)
        {
            for(int i=0;i<nKan;i++)
            {
                double data_qij  = EMData[(q*nKan+i)*nSamples+j];
                double model_qij = 0.;
                for(int p=0;p<nFreeSTF;p++)
                    for(int z=0;z<nBasicSTF;z++)
                        for(int jj=0;jj<nComp;jj++)
                            model_qij += WPsiMat[p*nKan+i]*CodeMat[q][p*nBasicSTF+z]*Bmat[z*nComp+jj]*Vmat[j*nSamples+jj];

                res_q += (data_qij-model_qij)*(data_qij-model_qij);
            }
        }
        if(pow_q>0) resPerCode[q]=100*(res_q/pow_q);
        res += res_q;
        pow += pow_q;
    }
    if(pow>0) *residual = 100*res/pow;
    return U_OK;
}

ErrorType ULocCodeDip::ComputeGMANOVAResiduals(double* residual, double* resPerCode, double** DNorm)
/*This routine computes the residual per data set for the GMANOVA model*/
{
    if(!GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeGMANOVAResiduals(). Invalid call, GMANOVA model is not used.\n");
        return U_ERROR;
    }

    if(!residual || !resPerCode || !DNorm)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeGMANOVAResiduals(). Invalid Argument.\n");
        return U_ERROR;
    }

    int nFreeSTF= pDipMan->GetNfreeSTF();

    const double* WPsiMat = pDipMan->GetFieldSTF();
    double totalres =0.;

    for (int q=0;q<nSets;q++)
    {
        double res_q=0.;
        double pow_q=0.; //power of code q= sum_j DataNorm[q][j]

        for(int j=0;j<nSamples;j++)
        {
            pow_q += DNorm[q][j];
            for(int i=0;i<nKan;i++)
            {
                double data_qij  = EMData[(q*nKan+i)*nSamples+j];
                double model_qij = 0.;
                for(int p=0;p<nFreeSTF;p++)
                    for(int z=0;z<nBasicSTF;z++)
                            model_qij += WPsiMat[p*nKan+i]*CM[(q*nFreeSTF+p)*nBasicSTF+z]*Bmat[z*nSamples+j];

                res_q += (data_qij-model_qij)*(data_qij-model_qij);
            }
        }
        if(pow_q>0) resPerCode[q]=100*res_q/pow_q;
        totalres += res_q;
    }
    totalres  = 100*totalres/DataNorm;
    *residual = totalres;

    return U_OK;
}

double ULocCodeDip::UpdateBmat(void)
/*
   This routine is only used for the Coupled Dipole Model
   Estimate the prewhitened source time functions Bmat = F*W_T*V.

   Bmat = (PsiC_super^t * PsiC_super)^(-1) * PsiC_super^t * ULamda
   with PsiC_super   = ((W_X^t Psi C[1])^t,........,(W_X^t Psi C[Q])^t)^t
   and  EMData_super = ULamda*VmatT

   return the cost corresponding to that estimate
*/
{
    if(GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateBmat(). Invalid call, GMANOVA model used.\n");
        return COSTERROR;
    }
    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return COSTERROR;

/* WPsiMat^t =  W_X^t Psi, the nKan*nFreeSTF matrix, ready to be multiplied by Cq's to obtain PsiC_super */
    const double* WPsiMat = pCodeMan->GetFieldSTF();
    if(WPsiMat==NULL) return COSTERROR;

    int      nCodes    = pCodeMan->GetNCodes();
    int      nBasicSTF = pCodeMan->GetNBasicSTF();
    int      nFreeSTF  = pCodeMan->GetNfreeSTF();
    const double* const* const CodeMat     = pCodeMan->GetCodeMat();
    const bool*   const* const BoolCodeMat = pCodeMan->GetBoolCodeMat();

/* Compute PsiC containing all Psi*CodeMat[q] matrices */

    int nCodesnKan = nCodes*nKan;
    double* PsiC = new double[nCodesnKan*nBasicSTF]; // matrix PsiC_super
    double* Mat  = new double[nBasicSTF*nBasicSTF];
    for(int zz=0;zz<nCodesnKan*nBasicSTF; zz++) PsiC[zz]=0.;

    for(int qnK=0, q=0; q<nCodes; q++,qnK+=nKan)
        for(int i=0; i<nKan; i++)
            for(int p=0, pnB=0, pnK=0; p<nFreeSTF; p++,pnB+=nBasicSTF,pnK+=nKan)
                for(int z=0; z<nBasicSTF; z++)
                {
                    if(!BoolCodeMat[q][pnB+z])
                        continue;
                    PsiC[(qnK+i)*nBasicSTF+z] += WPsiMat[pnK+i]*CodeMat[q][pnB+z];
                }

/* Copmute Mat = PsiC^t PsiC */
    for(int z1=0, z1nB=0; z1<nBasicSTF; z1++,z1nB+=nBasicSTF)
        for(int z2=0, z2nB=0; z2<nBasicSTF; z2++,z2nB+=nBasicSTF)
            if(z2>=z1)
            {
                Mat[z1nB+z2] = 0.;
                for(int i=0, inB=0; i<nCodesnKan; i++, inB+=nBasicSTF)
                    Mat[z1nB+z2] += PsiC[inB+z1]*PsiC[inB+z2];
            }
            else
            {
                Mat[z1nB+z2] = Mat[z2nB+z1];
            }

/* Perform SVD on Mat*/
    UJacobi Jamat(Mat, nBasicSTF, true);

/* Set eigenvalue threshold*/
//    int Neigen = pCodeMan->GetNfreeSTFMEG();
//    if(GridEEG) Neigen = Nstf;  //initially for MEG only implemented
    int Neigen = nBasicSTF;
    Jamat.SetEigenTreshold(Neigen);

    if(Jamat.GetEigenIndex(fabs(AMAT_THRESHOLD)) < Neigen && AMAT_THRESHOLD<0)
    {
        delete[] PsiC;
        delete[] Mat;
        return COSTERROR; // Skip dipoles near midline
    }


/* Compute pseudo inverse of Mat, and store this inverse in Mat */
    if(Jamat.PseudoInverse(Mat)!=U_OK)
    {
        static int Nmessage = 0;
        if(Nmessage<10)
            CI.AddToLog("ERROR: ULocStatDip::UpdateBmat(). Computing pseudo-inverse. \n");
        Nmessage++;

        delete[] PsiC;
        delete[] Mat;
        return COSTERROR;
    }

/* Compute PsiC^t*ULambda and store in Bmat, only nComp columns, rest is zero*/
    for(int z=0, znC=0; z<nBasicSTF; z++,znC+=nComp)
    {
        for(int j=0; j<nComp; j++)
        {
            Bmat[znC+j] = 0.;
            for(int i=0, inB=0, inS=0; i<nCodesnKan; i++,inB+=nBasicSTF,inS+=nSamples)
                Bmat[znC+j] += PsiC[inB+z]*ULamda[inS+j];
        }
    }

/* Pre-multiply this matrix with MatINV and compute cost simultaneously */
    double cost = DataNorm;
    for(int j=0;j<nComp;j++)
    {
        double Help[6*MAXCODEDIP];
        for(int zz=0; zz<6*MAXCODEDIP; zz++) Help[zz]=0.;
        for(int z1=0; z1<nBasicSTF; z1++)
        {
            Help[z1] = 0;
            for(int z2=0; z2<nBasicSTF; z2++)
                Help[z1] += Mat[z1*nBasicSTF+z2] * Bmat[z2*nComp+j];
        }

        for(int z2=0; z2<nBasicSTF; z2++)
        {
            cost             -= Bmat[z2*nComp+j]*Help[z2];
            Bmat[z2*nComp+j]  = Help[z2];
        }
    }

    cost *= 100./DataNorm;

    delete[] PsiC;
    delete[] Mat;
    return cost;
}

void ULocCodeDip::NormalizeBmat(void)
/* Normalizes Bmat if Bmat is not zero, or does nothing in case Bmat is zero */
{
    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return;

    int nBasicSTF = pCodeMan->GetNBasicSTF();
    double pow=0.;
    for(int z=0; z<nBasicSTF;z++) //normalize Bmat per STF
    {
        pow=0.;
        for(int j=0; j<nComp; j++)
            pow += Bmat[z*nComp+j]*Bmat[z*nComp+j];
        if(pow>0)
        {
            pow = sqrt(pow);
            for(int j=0; j<nComp; j++) Bmat[z*nComp+j]/=pow;
        }
    }
    return;
}


double ULocCodeDip::UpdateCodes(void)
/*
     This routine is only used for the Coupled Dipole Model
     Estimate the code parameters in Moments by solving

     A.CodePars == b

     with A[y1,y2] = tr{ (FwdField DerCodMat[y1])_super Bmat Bmat^t (FwdField DerCodMat[y2])_super^t}
     and  b[y]     = tr{ Bmat^t (FwdField DerCodMat[y])_super^t ULamda}
     (where FwdField is premultiplied by W_X^t and Bmat is postmultiplied by W_T)

     and return the cost corresponding to that estimate
*/
{
    if(GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateCodes(). Invalid call, GMANOVA model used.\n");
        return COSTERROR;
    }
    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return COSTERROR;

    int       nCodePars = pCodeMan->GetNCodePars();
    int       nBasicSTF = pCodeMan->GetNBasicSTF();
    int       nFreeSTF  = pCodeMan->GetNfreeSTF();
    int       nCodes    = pCodeMan->GetNCodes();
    double*   CodePars  = pCodeMan->GetCodePars();
    double*** DerCodMat     = pCodeMan->GetDerCodMat();
    bool***   BoolDerCodMat = pCodeMan->GetBoolDerCodMat();

    const double* WPsiMat = pCodeMan->GetFieldSTF(); // prewhitened FwdField
    if(WPsiMat==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateCodes Error in pCodeMan->GetFieldSTF().\n");
        return COSTERROR;
    }

/*  Compute BBT (Bmat*Bmat^t) for the source time functions, corresponding to the dipoles with fixed orientations */

    double BBT[4*MAXCODEDIP*MAXCODEDIP];

    for(int z1=0; z1<nBasicSTF; z1++)
    {
        for(int z2=0; z2<nBasicSTF; z2++)
        {
            if(z2>=z1)
            {
                BBT[z1*nBasicSTF+z2] = 0.;
                for(int j=0; j<nComp; j++)
                    BBT[z1*nBasicSTF+z2] += Bmat[z1*nComp+j]*Bmat[z2*nComp+j];
            }
            else
            {
                BBT[z1*nBasicSTF+z2] = BBT[z2*nBasicSTF+z1];
            }
        }
    }

/*
   Amat[y1,y2] = tr{(WPsiMat DerCodMat[y2])_super^t (WPsiMat DerCodMat[y1])_super Bmat Bmat^t}
   Bvec[y]     = tr{Bmat^t (WPsiMat[y]  C)_super^t ULamda}
   for each entry of Amat i.e. for each [y1,y2] the matrix
   (WPsiMat DerCodMat[y2])_super^t (WPsiMat DerCodMat[y1])_super is stored in CPPC
*/
    double* Amat = new double[nCodePars*nCodePars];
    double* Bvec = new double[nCodePars];
    double* CPPC = new double[nBasicSTF*nBasicSTF];

/* GENERAL: indices abbreviated: pnF=p*nFreeSTF, z1nB = z1*nBasicSTF etc.*/

    double* helpPP = new double[nFreeSTF*nFreeSTF];
    for(int p1=0, p1nK=0, p1nF=0; p1<nFreeSTF; p1++,p1nK+=nKan,p1nF+=nFreeSTF)
        for(int p2=0, p2nK=0; p2<nFreeSTF; p2++,p2nK+=nKan)
        {
            helpPP[p1nF+p2]=0;
            if(p2>=p1)
            {
                for(int i=0;i<nKan;i++)
                    helpPP[p1nF+p2]+=WPsiMat[p2nK+i]*WPsiMat[p1nK+i];
            }
            else
                helpPP[p1nF+p2]=helpPP[p2*nFreeSTF+p1];
        }

    for(int y1=0, y1nC=0; y1<nCodePars; y1++,y1nC+=nCodePars)
    {
        for(int y2=0,  y2nC=0; y2<nCodePars; y2++, y2nC+=nCodePars)
        {
            if(y2>=y1)
            {
                Amat[y1nC+y2] = 0.;

                for(int z1=0, z1nB=0; z1<nBasicSTF; z1++, z1nB+=nBasicSTF)
                    for(int z2=0, z2nB=0; z2<nBasicSTF; z2++, z2nB+=nBasicSTF)
                    {
                        CPPC[z1nB+z2]=0.; // Help array to store [(WPsimat C_q[])^t WPsimat C_q[]][z1,z2]

                        for(int q=0;q<nCodes;q++)
                        {
                            const double* pDerMat1     = DerCodMat[q][y2]+z1;
                            const double* pDerMat2     = DerCodMat[q][y1]+z2;
                            const bool*   pBoolDerMat1 = BoolDerCodMat[q][y2]+z1;
                            const bool*   pBoolDerMat2 = BoolDerCodMat[q][y1]+z2;
                            for(int p1=0,p1nB=0,p1nF=0;p1<nFreeSTF;p1++,p1nB+=nBasicSTF,p1nF+=nFreeSTF)
                            {
                                if(!pBoolDerMat2[p1nB])
                                    continue;
                                for(int p2=0,p2nB=0;p2<nFreeSTF;p2++,p2nB+=nBasicSTF)
                                {
                                    if(!pBoolDerMat1[p2nB])
                                        continue;
                                    CPPC[z1nB+z2]+=helpPP[p1nF+p2]*pDerMat1[p2nB]*pDerMat2[p1nB];
                                }
                            }
                        }
                        Amat[y1nC+y2]+=BBT[z1nB+z2]*CPPC[z1nB+z2];
                    }
            }
            else
                Amat[y1nC+y2] = Amat[y2nC+y1];
        }
    }

// Bvec[y]+=WPsiMat[p*nKan+i]*DerCodMat[q][y][p*nBasicSTF+z]*ULamda[(q*nKan+i)*nSamples+j]*Bmat[z*nComp+j];

    double*** helpi = new double**[nComp];
    int j=0;
    for(j=0;j<nComp;j++)
    {
        helpi[j]= new double*[nCodes];
        for(int q=0,qnK=0;q<nCodes;q++,qnK+=nKan)
        {
            helpi[j][q]= new double[nFreeSTF];
            for(int p=0,pnK=0;p<nFreeSTF;p++,pnK+=nKan)
            {
                 helpi[j][q][p] =0.;
                 for(int i=0;i<nKan;i++)
                        helpi[j][q][p] += WPsiMat[pnK+i]*ULamda[(qnK+i)*nSamples+j];
            }
        }
    }

    int y=0;
    for(y=0; y<nCodePars; y++)
    {
        Bvec[y] = 0.;
        for(int j=0;j<nComp;j++)
        {
            double helpz=0.;
            for(int z=0,znC=0;z<nBasicSTF;z++,znC+=nComp)
            {
                double helpq=0.;
                for(int q=0,qnK=0;q<nCodes;q++,qnK+=nKan)
                {
                    double helpp=0.;
                    for(int p=0,pnB=0,pnK=0;p<nFreeSTF;p++,pnB+=nBasicSTF,pnK+=nKan)
                    {
                        if(BoolDerCodMat[q][y][pnB+z])
                            helpp += helpi[j][q][p]*DerCodMat[q][y][pnB+z];
                    }
                    helpq+= helpp;
                }
                helpz+= helpq*Bmat[znC+j];
            }
            Bvec[y]+=helpz;
        }
    }


    for(j=0;j<nComp;j++)
    {
        for(int q=0;q<nCodes;q++)
        {
            delete[] helpi[j][q];
        }
        delete[] helpi[j];
    }
    delete[] helpi;

/* Solve system using truncate eigen value decomposition. */
    UJacobi JA(Amat, nCodePars, true);
    if(JA.GetError()!=U_OK)
    {
        static int Nmessage = 0;
        if(Nmessage<10)
            CI.AddToLog("ERROR: ULocCodeDip::UpdateCodes(). Computing pseudo-inverse. \n");
        Nmessage++;

        delete[] Amat;
        delete[] Bvec;
        delete[] CPPC;
        delete[] helpPP;
        return COSTERROR;
    }

    JA.SetEigenTreshold(nCodePars);
    if(JA.Solve(CodePars, Bvec)!=U_OK)
    {
        delete[] Amat;
        delete[] Bvec;
        delete[] CPPC;
        delete[] helpPP;
        return COSTERROR;
    }

/* Compute cost in %*/
    double cost = DataNorm;
    for(y=0; y<nCodePars; y++) cost -= CodePars[y]*Bvec[y];
    cost *= 100./DataNorm;

    pCodeMan->UpdateCodeMat();

    delete[] Amat;
    delete[] Bvec;
    delete[] CPPC;
    delete[] helpPP;
    return cost;
}


double ULocCodeDip::UpdateMoments(void)
/*
     This routine is only used for the Coupled Dipole Model
     Estimate the moment parameters in Moments by solving

     A.MomentPars == b

     with A[p1,p2] = tr{ (FwdField[p1] CodeMat)_super Bmat Bmat^t (FwdField[p2] CodeMat)_super^t}
     and  b[p]     = tr{ Bmat^t (FwdField[p]  CodeMat)_super^t ULamda}
     (where FwdField is premultiplied by W_X^t and Bmat is postmultiplied by W_T)

     and return the cost corresponding to that estimate
*/
{
    if(GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateMoments(). Invalid call, GMANOVA model used.\n");
        return COSTERROR;
    }
    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return COSTERROR;

    int      nCodes    = pCodeMan->GetNCodes();
    int      nBasicSTF = pCodeMan->GetNBasicSTF();
    int      nDipoles  = pCodeMan->GetNDipoles();
    const double* const* const CodeMat     = pCodeMan->GetCodeMat();
    const bool*   const* const BoolCodeMat = pCodeMan->GetBoolCodeMat();

    int           Nmom    = pCodeMan->GetNfreeMoment();
    const double* WPsiMat = pCodeMan->GetFieldMoment(); // prewhitened FwdField derivatives
    if(Nmom<=0 || WPsiMat==NULL)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateMoments() Error in pCodeMan->GetFieldMoment().\n");
        return COSTERROR;
    }

/*  Sindex[] contains the column indices of WPsiMat (the row indices of CodeMat) corresponding
    to dipoles with free moments, i.e. moments solved by this linear system A m = b */

    int Sindex[3*MAXDIPOLES];
    int k=0;
    int l=0;
    int s=0;
    for(   ;l<nDipoles; l++)
    {
        if(pCodeMan->GetNfreeSTF(l)==1 || pCodeMan->GetNfreeSTF(l)==2)
        {
            Sindex[k] = s;
            k++; s++;
            if(pCodeMan->GetNfreeSTF(l)==2)
            {
                Sindex[k] = s;
                k++; s++;
            }
        }
        else
            s+=pCodeMan->GetNfreeSTF(l);
    }

/*  Compute BBT (Bmat*Bmat^t) for the source time functions, corresponding to the dipoles with fixed orientations */

    double BBT[4*MAXCODEDIP*MAXCODEDIP];

    for(int z1=0; z1<nBasicSTF; z1++)
    {
        for(int z2=0; z2<nBasicSTF; z2++)
        {
            if(z2>=z1)
            {
                BBT[z1*nBasicSTF+z2] = 0.;
                for(int j=0; j<nComp; j++)
                    BBT[z1*nBasicSTF+z2] += Bmat[z1*nComp+j]*Bmat[z2*nComp+j];
            }
            else
            {
                BBT[z1*nBasicSTF+z2] = BBT[z2*nBasicSTF+z1];
            }
        }
    }

/* Substract rotating dipole fields */

/* Amat[m1,m2] = tr{Bmat^t (WPsiMat[m2] C)_super^t (WPsiMat[m1] C)_super Bmat}
   Bvec[m]     = tr{Bmat^t (WPsiMat[m]  C)_super^t ULamda}
   for each entry of Amat i.e. for each [m1,m2] the matrix
   (WPsiMat[m2] C)_super^t (WPsiMat[m1] C)_super is stored in CPPC
*/
    double* Amat = new double[Nmom*Nmom];
    double* Bvec = new double[Nmom];
    double* CPPC = new double[nBasicSTF*nBasicSTF];

/* GENERAL: indices abbreviated: pnF=p*nFreeSTF, z1nB = z1*nBasicSTF etc.*/
    double* helpPP = new double[Nmom*Nmom];
    for(int mm1=0,mm1Nm=0,mm1nK=0; mm1<Nmom; mm1++,mm1Nm+=Nmom,mm1nK+=nKan)
        for(int m2=0,m2nK=0; m2<Nmom; m2++,m2nK+=nKan)
        {
            helpPP[mm1Nm+m2]=0;
            if(m2>=mm1)
            {
                for(int i=0;i<nKan;i++)
                    helpPP[mm1Nm+m2]+=WPsiMat[m2nK+i]*WPsiMat[mm1nK+i];
            }
            else
                helpPP[mm1Nm+m2]=helpPP[m2*Nmom+mm1];
        }

    for(int m1=0,m1Nm=0; m1<Nmom; m1++,m1Nm+=Nmom)
    {
        int s1nB = Sindex[m1/3]*nBasicSTF; //m=Moment, p=m/3=Dipole, s=STF index
        for(int m2=0,m2Nm=0; m2<Nmom; m2++,m2Nm+=Nmom)
        {
            if(m2>=m1)
            {
                int s2nB = Sindex[m2/3]*nBasicSTF; //m=Moment, p=m/3=Dipole,s=STF index
                Amat[m1Nm+m2] = 0.;
                for(int z1=0,z1nB=0; z1<nBasicSTF; z1++,z1nB+=nBasicSTF)
                    for(int z2=0,z2nB=0; z2<nBasicSTF; z2++,z2nB+=nBasicSTF)
                    {
                        CPPC[z1nB+z2]=0.; // Help array to store [(WPsimat C_q[])^t WPsimat C_q[]][z1,z2]
                        double helpCC=0.;
                        for(int q=0;q<nCodes;q++)
                        {
                            if(!BoolCodeMat[q][s2nB+z1] || !BoolCodeMat[q][s1nB+z2])
                                continue;
                            else
                                helpCC+=CodeMat[q][s2nB+z1]*CodeMat[q][s1nB+z2];
                        }
                        if (helpCC==0)
                            continue;
                        else
                            CPPC[z1nB+z2] = helpCC*helpPP[m2Nm+m1];

                        Amat[m1Nm+m2]+=BBT[z1nB+z2]*CPPC[z1nB+z2];
                    }
            }
            else
                Amat[m1Nm+m2] = Amat[m2Nm+m1];
        }
    }

    //Bvec[m] = sum_{z,q,j,i} WPsiMat[m*nKan+i]*CodeMat[q][s*nBasicSTF+z]*ULamda[(q*nKan+i)*nSamples+j]*Bmat[z*nComp+j];
    //        = sum_z(sum_q(sum_j(sum_i WPsiMat[m*nKan+i]*ULamda[(q*nKan+i)*nSamples+j])*Bmat[z*nComp+j])*CodeMat[q][s*nBasicSTF+z])

    for(int m=0,mnK=0; m<Nmom; m++,mnK+=nKan)
    {
        Bvec[m] = 0.;
        int snB = Sindex[m/3]*nBasicSTF;  //m=Moment, p=m/3=Dipole, s=STF index
        for(int z=0,znC=0; z<nBasicSTF; z++,znC+=nComp)
        {
            double helpq=0.;
            for(int q=0,qnK=0;q<nCodes;q++,qnK+=nKan)
            {
                if(!BoolCodeMat[q][snB+z])
                    continue;
                double helpj=0.;
                for(int j=0;j<nComp;j++)
                {
                    double helpi=0.;
                    for(int i=0;i<nKan;i++)
                        helpi+=WPsiMat[mnK+i]*ULamda[(qnK+i)*nSamples+j];
                    helpj+= Bmat[znC+j]*helpi;
                }
                helpq+=CodeMat[q][snB+z]*helpj;
            }
            Bvec[m]+=helpq;
        }
    }

/* Solve system using truncate eigen value decomposition. */
    UJacobi JA(Amat, Nmom, true);
    if(JA.GetError()!=U_OK)
    {
        static int Nmessage = 0;
        if(Nmessage<10)
            CI.AddToLog("ERROR: ULocCodeDip::UpdateMoments(). Computing pseudo-inverse. \n");
        Nmessage++;

        delete[] Amat;
        delete[] Bvec;
        delete[] CPPC;
        delete[] helpPP;
        return COSTERROR;
    }

    int Neigen = pCodeMan->GetNfreeMomentMEG();
    JA.SetEigenTreshold(Neigen);
    double Moments[6*MAXCODEDIP];
    if(JA.Solve(Moments, Bvec)!=U_OK)
    {
        delete[] Amat;
        delete[] Bvec;
        delete[] CPPC;
        delete[] helpPP;
        return COSTERROR;
    }

/* Update moments in dipole manager and normalize*/
    pCodeMan->UpdateDipoleMoments(Moments);

/* Compute cost in %*/
    double cost = DataNorm;
    for(k=0; k<Nmom; k++) cost -= Moments[k]*Bvec[k];
    cost *= 100./DataNorm;

    delete[] Amat;
    delete[] Bvec;
    delete[] CPPC;
    delete[] helpPP;
    return cost;
}


void ULocCodeDip::UpdateGMANOVAMoments(void)
/* This routine is only used when the GMANOVA model is used
it updates the source moments in the GMANOVA model using
the estimator that exploits the linearity of the model in
the moment parameters (see article cited in top of this file)
The cost value is not output, because, the cost value is computer
after Bmat and CM are updated in UpdateSTFMatAndCM().
  */
{
    if(!GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateGMANOVAMoments(). Invalid call, GMANOVA model not used.\n");
        return;
    }

    const double*  Field    = pDipMan->GetFieldMoment();
    int            nFreeSTF = pDipMan->GetNfreeSTF();
    double**       A        = new double*[nSamples];
    int j=0;
    for(j=0;j<nSamples;j++) A[j]= new double[nSets*nKan*3*nFreeSTF];
    double*        Amat     = new double[9*nFreeSTF*nFreeSTF];
    double*        Bvec     = new double[3*nFreeSTF];

    for(j=0;j<nSamples;j++)
    {
        for(int p=0,p3=0;p<nFreeSTF;p++,p3+=3)
            for(int m=0;m<3;m++)
                for(int q=0,qnK=0,qnF=0;q<nSets;q++,qnK+=nKan,qnF+=nFreeSTF)
                    for(int i=0;i<nKan;i++)
                    {
                        A[j][(qnK+i)*3*nFreeSTF+p3+m]=0.;
                        double help =0.;
                        for(int z=0,znS=0;z<nBasicSTF;z++,znS+=nSamples)
                            help+= CM[(qnF+p)*nBasicSTF+z]*Bmat[znS+j];
                        A[j][(qnK+i)*3*nFreeSTF+p3+m] = Field[(p3+m)*nKan+i]*help;
                    }
    }

    int p=0;
    for(p=0;p<9*nFreeSTF*nFreeSTF;p++) Amat[p]=0.;

    int p3nF =0;
    for(p=0,p3nF=0;p<3*nFreeSTF;p++,p3nF+=3*nFreeSTF)
        for(int pp=0;pp<p+1;pp++)
            for(int j=0;j<nSamples;j++)
                for(int q=0,q3nF=0;q<nSets*nKan;q++,q3nF+=3*nFreeSTF)
                    Amat[p3nF+pp]+=A[j][q3nF+p]*A[j][q3nF+pp];

    for(p=0,p3nF=0;p<3*nFreeSTF;p++,p3nF+=3*nFreeSTF)
        for(int pp=p+1,pp3nF=(p+1)*3*nFreeSTF;pp<3*nFreeSTF;pp++,pp3nF+=3*nFreeSTF)
            Amat[p3nF+pp] = Amat[pp3nF+p];

    for(p=0; p<3*nFreeSTF;p++)
    {
        Bvec[p]=0.;
        for(int j=0,jnS=0;j<nSamples;j++,jnS+=nSamples)
            for(int q=0,qnS=0,q3nF=0;q<nSets*nKan;q++,qnS+=nSamples,q3nF+=3*nFreeSTF)
            {
                double help_r=0.;
                for(int jj=0; jj<nComp;jj++)
                    help_r += ULamda[qnS+jj]*Vmat[jnS+jj];
                Bvec[p]+=A[j][q3nF+p]*help_r;
            }
    }

    UJacobi AA(Amat,3*nFreeSTF,true);

    int Neigen = pDipMan->GetNfreeMomentMEG();
    AA.SetEigenTreshold(Neigen);

    double* Moments = new double[3*nFreeSTF];
    AA.Solve(Moments,Bvec);
    pDipMan->UpdateDipoleMoments(Moments);

    delete[] Amat;
    delete[] Bvec;
    if(A)
    {
        for (int j=0;j<nSamples;j++)
            if(A[j]) delete[] A[j];
    }
    delete[] A;
    delete[] Moments;
}

double ULocCodeDip::UpdateSTFmatAndCM(void)
/*
   This routine updates matrices B and C and computes
   the costfunction. The estimators for B anc C are described
   in the paper mentioned on top of this file*/
{
    if(!GMAN)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateSTFmatAndCM(). Invalid call, GMANOVA model not used.\n");
        return COSTERROR;
    }

    const double* Field = pDipMan->GetFieldSTF();

    int nFreeSTF = pDipMan->GetNfreeSTF();
    double* H1 = new double[nFreeSTF*nFreeSTF];   // H1 = Transpose[Field]*Field
    double* H2 = new double[nFreeSTF*nFreeSTF];   // H2 = Inverse[H1]
    double* H3 = new double[nComp*nComp];         // H3 = Transpose[ULamda] {Id(nSets)(x)H5} ULamda
    double* H4 = new double[nSamples*nSamples];   // H4 = Vmat H3 Transpose[Vmat]
    double* H5 = new double[nKan*nKan];           // H5 = Field*H2*Transpose[Field]
    double* H6 = NULL;
    double* H7 = new double[nSets*nFreeSTF*nComp];
    // Bmat = first nBasicSTF rows of U^t in H4 = U D U^t (Jacobi decomposition of H4)
    // CM = {Id(Q) (x) H2*Field}*ULamda*Transpose[Vmat]*Transpose[Bmat]

    if(!H1 || !H2 || !H3 || !H4 || !H5 || !H7)
    {
        CI.AddToLog("ERROR: ULocCodeDip::UpdateSTFmatAndCM() : Memory Allocation error. \n");
        CI.PressReturnExit();
    }

    int p=0;
    int pnF=0;
    int pnK=0;
    for(     ; p<nFreeSTF; p++, pnF+=nFreeSTF, pnK+=nKan)
        for(int pp=0, ppnK=0; pp<p+1; pp++, ppnK+=nKan)
        {
            H1[pnF+pp]=0.;
            for(int i=0; i<nKan; i++)
                H1[pnF+pp] += Field[pnK+i]*Field[ppnK+i];
        }
    for(p=0; p<nFreeSTF; p++)
        for(int pp=p+1; pp<nFreeSTF; pp++)
            H1[p*nFreeSTF+pp] = H1[pp*nFreeSTF+p];

    UJacobi H(H1,nFreeSTF,true);

    H.PseudoInverse(H2);

    int i=0;
    int inK=0;
    for(     ; i<nKan; i++, inK+=nKan)
        for(int ii=0; ii<i+1; ii++)
        {
            H5[inK+ii] =0.;
            for(int p=0, pnK=0, pnF=0; p<nFreeSTF; p++ ,pnK+=nKan, pnF+=nFreeSTF)
                for(int pp=0, ppnK=0; pp<nFreeSTF; pp++, ppnK+=nKan)
                    H5[inK+ii] += Field[pnK+i]*H2[pnF+pp]*Field[ppnK+ii];
        }
    for(i=0, inK=0; i<nKan; i++, inK+=nKan)
        for(int ii=i+1, iinK=(i+1)*nKan; ii<nKan; ii++, iinK+=nKan)
            H5[inK+ii] = H5[iinK+i];

    int z=0;
    int znC=0;
    for(     ; z<nComp; z++, znC+=nComp)
        for(int zz=0; zz<z+1; zz++)
        {
            H3[znC+zz]=0.;
            for(int q=0, qnK=0; q<nSets; q++, qnK+=nKan)
                for(int i=0, inK=0; i<nKan; i++, inK+=nKan)
                    for(int ii=0; ii<nKan; ii++)
                        H3[znC+zz]+=ULamda[(qnK+i)*nSamples+z]*H5[inK+ii]*ULamda[(qnK+ii)*nSamples+zz];
        }
    for(z=0; z<nComp; z++)
        for(int zz=z+1;zz<nComp;zz++)
            H3[z*nComp+zz]=H3[zz*nComp+z];

    int j=0;
    int jnS=0;
    for(     ; j<nSamples; j++, jnS+=nSamples)
        for(int jj=0, jjnS=0; jj<j+1; jj++, jjnS+=nSamples)
        {
            H4[jnS+jj]=0.;
            for(int z=0, znC=0; z<nComp; z++, znC+=nComp)
                for(int zz=0;zz<nComp;zz++)
                    H4[jnS+jj]+=Vmat[jnS+z]*H3[znC+zz]*Vmat[jjnS+zz];
        }
    for(j=0, jnS=0; j<nSamples; j++, jnS+=nSamples)
        for(int jj=j+1, jjnS=(j+1)*nSamples; jj<nSamples; jj++, jjnS+=nSamples)
            H4[jnS+jj]=H4[jjnS+j];

    H.SetMatrix(H4,nSamples,false); // now STFmat is the first nBasicSTF singular vectors of H


/* Update Bmat */
    if(Bmat) delete[] Bmat;

    Bmat = new double[nBasicSTF*nSamples];
    for(int zj=0; zj<nBasicSTF*nSamples;zj++) Bmat[zj]=0.;
    int znS=0;
    for(z=0, znS=0;z<nBasicSTF;z++, znS+=nSamples)
    {
        H6 = H.GetEigenVector(z, true);
        for(int j=0;j<nSamples;j++)
            Bmat[znS+j] = H6[j];
    }

/* Update CM */
    if(CM) delete[] CM;
    CM=new double[nFreeSTF*nSets*nBasicSTF];

    for(p=0, pnF=0;p<nFreeSTF;p++, pnF+=nFreeSTF)
        for(int q=0, qnF=0, qnK=0;q<nSets;q++, qnF+=nFreeSTF,qnK+=nKan)
            for(int z=0;z<nComp;z++)
            {
                H7[(qnF+p)*nComp+z]=0.;
                for(int i=0;i<nKan;i++)
                    for(int pp=0, ppnK=0;pp<nFreeSTF;pp++,ppnK+=nKan)
                        H7[(qnF+p)*nComp+z]+=H2[pnF+pp]*Field[ppnK+i]*ULamda[(qnK+i)*nSamples+z];
            }
    for(p=0, pnF=0;p<nFreeSTF;p++, pnF+=nFreeSTF)
        for(int q=0, qnF=0;q<nSets;q++,qnF+=nFreeSTF)
            for(int z=0,znS=0;z<nBasicSTF;z++,znS+=nSamples)
            {
                CM[(qnF+p)*nBasicSTF+z]=0.;
                for(int j=0, jnS=0;j<nSamples;j++,jnS+=nSamples)
                    for(int zz=0;zz<nComp;zz++)
                        CM[(qnF+p)*nBasicSTF+z]+=H7[(qnF+p)*nComp+zz]*Vmat[jnS+zz]*Bmat[znS+j];
            }

    double cost = 0.;

    for(int q=0, qnK=0,qnF=0;q<nSets;q++,qnK+=nKan,qnF+=nFreeSTF)
        for(int i=0;i<nKan;i++)
            for(int j=0,jnS=0; j<nSamples;j++,jnS+=nSamples)
            {
                double model =0.;
                double data  =0.;
                for(int jj=0; jj<nComp;jj++)
                    data+= ULamda[(qnK+i)*nSamples+jj]*Vmat[jnS+jj];
                for(int p=0,pnK=0;p<nFreeSTF;p++,pnK+=nKan)
                    for(int z=0,znS=0; z<nBasicSTF;z++,znS+=nSamples)
                        model+= Field[pnK+i]*CM[(qnF+p)*nBasicSTF+z]*Bmat[znS+j];
                cost += (model-data)*(model-data);
            }

    cost*= 100./DataNorm;

    delete[] H1;
    delete[] H2;
    delete[] H3;
    delete[] H4;
    delete[] H5;
    delete[] H6;
    delete[] H7;

    return cost;
}

void ULocCodeDip::PrintCodeMat(UFileName FileNameOut,int q,bool Norm) const
{
    if (!GMAN)
    {
        UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return;

        pCodeMan->PrintCodeMat(FileNameOut,q,Norm);
        return;
    }
    else
    {
        FILE* fpOut = NULL;
        fpOut = fopen(FileNameOut,"at", true);
        bool error = false;
        int nFreeSTF = pDipMan->GetNfreeSTF();

        if (Norm==true)
        {
            double norm = GetCMNormalizer();
            if (fabs(norm) == 0.)
                error=true; // print unnormalized codemat
            else
            {
                fprintf(fpOut,"Coupling Matrix %d for Data Set %s (normalized by %f)\n",q,(const char*)DataSetNames[q],norm);
                for(int p=0;p<nFreeSTF;p++)
                {
                    for(int z=0;z<nBasicSTF;z++)
                        fprintf(fpOut,"%f\t",CM[(q*nFreeSTF+p)*nBasicSTF+z]/(norm*sqrt((double)nTrialsPerSet[q])));
                    fprintf(fpOut,"\n");
                }
                fprintf(fpOut,"\n");
            }
        }
        if (Norm==false||error)
        {
            fprintf(fpOut,"CodeMatrix %d for Code %s (unnormalized)\n",q,(const char*)DataSetNames[q]);
            for(int p=0;p<nFreeSTF;p++)
            {
                for(int z=0;z<nBasicSTF;z++)
                    fprintf(fpOut,"%f\t",CM[(q*nFreeSTF+p)*nBasicSTF+z]/sqrt((double)nTrialsPerSet[q]));
                fprintf(fpOut,"\n");
            }
            fprintf(fpOut,"\n");
        }
        fclose(fpOut);
    }
}

double ULocCodeDip::GetCMNormalizer(void) const
/* This routine returns the largest (in absolute value) coupling parameter*/
{
    int index = 0;
    int set   = 0;
    int nFreeSTF = pDipMan->GetNfreeSTF();

    for(int q=0;q<nSets;q++)
        for(int n=0; n<nFreeSTF*nBasicSTF; n++)
            if(fabs(CM[q*nFreeSTF*nBasicSTF+n]/sqrt((double)nTrialsPerSet[q])) >= fabs(CM[set*nFreeSTF*nBasicSTF+index]/sqrt((double)nTrialsPerSet[set])))
            {
                index = n;
                set   = q;
            }
    return fabs(CM[set*nFreeSTF*nBasicSTF+index]/sqrt((double)nTrialsPerSet[set]));
}

void ULocCodeDip::PrintCodePars(UFileName FileNameOut,bool Norm) const
{
    if (GMAN) return;

    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return;

    pCodeMan->PrintCodePars(FileNameOut,Norm);
}

int ULocCodeDip::GetSignOfCodedSTF(int p, int istf) const
/*
    On return:
    a POSITIVE integer is given if the coded STFs corresponding
    to the free STF istf for dipole p are mainly positive i.e. if
        sum_q sum_j sign{(C_q F)[istf,j]}>0
    a zero integer is given if the STF's are zero
    or in case of an error in computing the sign
        sum_q sum_j sign{(C_q F)[istf,j]}=0
    a NEGATIVE integer if the STF's are mainly negative
        sum_q sum_j sign{(C_q F)[istf,j]}<0.
    The dipole index p and the stf index istf are tested
    only for minimum and maximum value, not for
    correspondence. That should be tested before
    calling this routine.
*/
{   if(GMAN) return 0;

    UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
    if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return 0;

    int      nBasicSTF = pCodeMan->GetNBasicSTF();
    int      nFreeSTF  = pCodeMan->GetNfreeSTF();
    const double* const* const CodeMat = pCodeMan->GetCodeMat();
    int      nDipoles  = pCodeMan->GetNDipoles();

    if(p<0||p>=nDipoles||istf<0||istf>=nFreeSTF)
        return 0;
    int sign =0;
    int index[MAXCODES];
    for(int q=0;q<MAXCODES;q++)
        index[q]=0;
    if (pCodeMan->GetCodeInDipIndex(p, index)==U_ERROR)
        return 0;
    else
    {
        for(int q=0;q<pCodeMan->GetNCodesInDipole(p);q++)
                for(int j=0;j<nSamples;j++)
                {
                    double val=0.;
                    for(int z=0;z<nBasicSTF;z++)
                        for(int jj=0;jj<nComp;jj++)
                            val += CodeMat[index[q]][istf*nBasicSTF+z]*Bmat[z*nComp+jj]*Vmat[j*nSamples+jj];
                    sign += GetSign(val);
                }
    }
    if (sign>0)
        return 1;
    else if (sign<0)
        return -1;
    else
        return 0;
}

int ULocCodeDip::GetSignOfSTF(int istf, const double* BasicSTF) const
/*
This routine is the GMANOVA version of GetSignOfCodedSTF(p,istf)
    On return:
    a POSITIVE integer is given if the STFs corresponding
    to the free STF istf  are mainly positive i.e. if
        sum_q sum_j sign{(C_q Basic)[istf,j]}>0
    a ZERO integer is given if the STF's are zero
    or in case of an error in computing the sign
        sum_q sum_j sign{(C_q F)[istf,j]}=0
    a NEGATIVE integer if the STF's are mainly negative
        sum_q sum_j sign{(C_q F)[istf,j]}<0.
    The dipole index p and the stf index istf are tested
    only for minimum and maximum value, not for
    correspondence. That should be tested before
    calling this routine.
*/
{
    if(istf<0 || BasicSTF == NULL || !GMAN) return 0;

    int sign =0;
    int nFreeSTF= pDipMan->GetNfreeSTF();
    for(int q=0;q<nSets; q++)
        for(int j=0;j<nSamples;j++)
                {
                    double val=0.;
                    for(int z=0;z<nBasicSTF;z++)
                        val += CM[(q*nFreeSTF+istf)*nBasicSTF+z]*BasicSTF[z*nSamples+j];
                    sign += GetSign(val);
                }
    if (sign>0)
        return 1;
    else if (sign<0)
        return -1;
    else
        return 0;
}


int GetSign(double d)
{
    if (d>0)
        return 1;
    else if (d<0)
        return -1;
    else
        return 0;

}

void ULocCodeDip::InvertBasicSTF(int istf)
/* This routine inverts (multiply by -1) the istf^th BasicSTF
   and the corresponding column in all coupling matrices
*/
{
    if (!GMAN)
    {
        UCodeManager* pCodeMan = (UCodeManager*)pDipMan;
        if(pCodeMan==NULL || pCodeMan->GetError()!=U_OK) return;

        pCodeMan->InvertBasicSTF(istf);
        for (int j=0;j<nSamples;j++)
            Bmat[istf*nSamples+j]*=-1;
    }
    if(GMAN)
    {
        if(istf<0 || istf >= nBasicSTF)
            return;
        int nFreeSTF = pDipMan->GetNfreeSTF();
        for(int q=0;q<nSets;q++)
            for(int p=0; p<nFreeSTF; p++)
                CM[(q*nFreeSTF+p)*nBasicSTF+istf] *= -1;
        for(int j=0;j<nSamples;j++)
            Bmat[istf*nSamples+j]*=-1;
    }
}

void ULocCodeDip::InvertFreeSTF(int istf)
/* This routine inverts (multiply by -1) the istf^th row
   in all coupling matrices. This corresponds to inverting
   the corresponding moment vector, which is done in ComputeDipoles()
   before calling this routine.
*/
{
    if (!GMAN) return;

    int nFreeSTF = pDipMan->GetNfreeSTF();
    if(istf<0 || istf >= nFreeSTF)
        return;
    for(int q=0;q<nSets;q++)
        for(int z=0; z<nBasicSTF; z++)
            CM[(q*nFreeSTF+istf)*nBasicSTF+z] *= -1;
}


ErrorType ULocCodeDip::ComputeParameterCov(UMatrix& CCRB, int method)
/*
This routine calculates the estimated covariance matrix for
the source parameters and the entries of matrices C and B
in R = ACB for the GMANOVA model.

The order of the parameters is:
source parameters, vec(C), vec(B)
the source parameters are ordered per source:
pos_x,pos_y,pos_z,ori_x,ori_y,ori_z, (orisym_x,orisym_y,orisym_z)
and then the next source etc.

The constraints (necessary for identifiability) are:
- G = Id(nBasicSTF) or B Uz = Id(nBasciSTF)
- tangential dipoles
- normalized orientations
where B = G Uz^t, with  R^tA inv(A^tA) A^tR = U Delta U^t and
Uz are the first nBasicSTF columns of U.

Choice from three different alternatives:
method == 0 Constrained Cramer Rao Bound (by Stoica & Ng, 1988)
method == 1 Augmented information matrix (see Huizenga et al., 1994 Mult.Behav.Res)
else        PseudoInverse of Fisher Information Matrix, taking nPar-nConstraints nonzero eigenvalues into account
*/
{
    int nFreeSTF   = pDipMan->GetNfreeSTF();
    int nDipoles   = pDipMan->GetNDipoles();
    int nSourcePar = pDipMan->GetNfreeMoment()+pDipMan->GetNfreePosPars();

    const double* Psi = pDipMan->GetFieldSTF(); // prewhitened Forward Field nFreeSTF x nKan
    UMatrix PsiMat    = (UMatrix(Psi,nFreeSTF,nKan)).GetTranspose();
    UMatrix IdMat     = UMatrix(nSets);
    UMatrix AMat      = UMatrix(IdMat,PsiMat);
    UMatrix V         = UMatrix(Vmat, nSamples, nSamples);
    UMatrix DataMat;
    DataMat = GetMatMul(UMatrix(ULamda, nSets*nKan,nSamples), false, V, true);  //Data = ULamda*Vmat^t
    if(DataMat.GetError() != U_OK) return U_ERROR;

    UMatrix BMat  = UMatrix(Bmat, nBasicSTF,nSamples);
    UMatrix CMat  = UMatrix(CM, nFreeSTF*nSets,nBasicSTF);
    UMatrix UZMat = BMat.GetTranspose();

/* Compute the derivative of the lead field matrix w.r.t. the source parameters
   The lead field matrix A is Id(nSets) (x) Psi,
   where Psi is pDipMan->GetFieldSTF() and (x) means Kronecker Product
*/

    int DAdim  = nSets*nKan*nSets*nFreeSTF*nSourcePar;
    double* DA = new double[DAdim];
    for(int j=0;j<DAdim;j++) DA[j]=0.;

    UDipole* DipArray = new UDipole[nDipoles];
    pDipMan->GetFreeDipoles(DipArray);
    int p=0;
    int s=0;
    int m=0;
    for(   ;p<nDipoles;p++,s++) // p: dipole-index, s: stf-index, m: parameter-index
    {
        UDipole::DipoleType DT = DipArray[p].GetDipoleType();

        switch(DT)
        {
        case UDipole::Current :
            {
            /* Position derivatives */
            double* bf = Emf.GetBfield(&DipArray[p],D_OriPos01);
            int q=0;
            for(q=0;q<nSets;q++)
                for(int i=0;i<nKan;i++)
                    for(int mm=m;mm<m+3;mm++)
                        DA[((q*nFreeSTF+s)*nSets*nKan+q*nKan+i)*nSourcePar+mm] = bf[i*3+mm-m];
            m+=3;
            delete[] bf;

            /* Orientation derivatives */
            bf = Emf.GetBfield(&DipArray[p],D_OriPos10);
            for(q=0;q<nSets;q++)
                for(int i=0;i<nKan;i++)
                    for(int mm=m;mm<m+3;mm++)
                        DA[((q*nFreeSTF+s)*nSets*nKan+q*nKan+i)*nSourcePar+mm] = bf[i*3+mm-m];
            m+=3;
            delete[] bf;
            break;
            }

        case UDipole::SymmetricPos :
            {
            /* Position derivatives */
            double* bf = Emf.GetBfield(&DipArray[p],D_OriPos11);
            double* PosDer = new double[2*nKan*3];
            double MomentLeft[3]  = {DipArray[p].Getd().Getx(),
                                     DipArray[p].Getd().Gety(),
                                     DipArray[p].Getd().Getz()};
            double MomentRight[3] = {DipArray[p].GetdSym().Getx(),
                                     DipArray[p].GetdSym().Gety(),
                                     DipArray[p].GetdSym().Getz()};
            int i=0;
            for(i=0;i<6*nKan;i++) PosDer[i]=0.;
            for(i=0;i<nKan;i++)
                for(int dx=0;dx<3;dx++)
                    for(int mx=0; mx<3;mx++)
                    {
                        PosDer[i*3+dx]        += bf[i*18+mx*3+dx]*MomentLeft[mx];
                        PosDer[(i+nKan)*3+dx] += bf[i*18+9+mx*3+dx]*MomentRight[mx];
                    }

            int ss=0;
            for(ss=0;ss<2;ss++)
                for(int q=0;q<nSets;q++)
                    for(int i=0;i<nKan;i++)
                        for(int mm=m;mm<m+3;mm++)
                            DA[((q*nFreeSTF+s+ss)*nSets*nKan+q*nKan+i)*nSourcePar+mm] = PosDer[(ss*nKan+i)*3+mm-m];
            m+=3;
            delete[] bf;
            delete[] PosDer;

            /* Orientation derivatives */
            bf = Emf.GetBfield(&DipArray[p],D_OriPos10);
            for(ss=0;ss<2;ss++)
                for(int q=0;q<nSets;q++)
                    for(int i=0;i<nKan;i++)
                        for(int mm=m;mm<m+3;mm++)
                            DA[((q*nFreeSTF+s+ss)*nSets*nKan+q*nKan+i)*nSourcePar+ss*3+mm] = bf[i*6+ss*3+mm-m];
            m+=6;
            s++;
            delete[] bf;
            break;
            }

        case UDipole::Symmetric :
        default:
            {
                CI.AddToLog("ERROR: ULocCodeDip::ComputeParameterCov(). Invalid Dipole Type or not implemented.\n");
                return U_ERROR;
            }
        }
    }
    if(p!=nDipoles || s!= nFreeSTF || m!= nSourcePar)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeParameterCov(). Error in loop for DA.");
        return U_ERROR;
    }
    UMatrix DAMat = UMatrix(DA, nSets*nKan*nSets*nFreeSTF,nSourcePar);

/* Compute the entries of FMat: the derivative matrix of the constraints
   The order of constraints is:
   - nBasicSTF*nBasicSTF constraints for B*U_Z = Id(Z)
   - normalized orientations (# = (pDipMan->GetNfreeMoment())/3 constraints)
   - tangential orientations (# = (pDipMan->GetNfreeMoment())/3 constraints)
*/

    UMatrix Help1,Help2,Help3,Help4;
    UMatrixSymmetric PsiTPsiMat, RARMat;
    PsiTPsiMat = PsiMat.GetMTM();        if(PsiTPsiMat.GetError()!=U_OK) return U_ERROR;
    Help1 = PsiMat.GetProjection(false); if(Help1.GetError()!=U_OK)      return U_ERROR;        //Help1 = Psi inv(Psi^t Psi) Psi^t
    Help2 = PsiMat.GetProjection(true ); if(Help2.GetError()!=U_OK)      return U_ERROR;        //Help2 = Id(nKan) - Psi inv(Psi^t Psi) Psi^t
    Help3 = UMatrix(UMatrix(nSets),Help1);                                                      //Help3 = A inv(A^t A) A^t
    Help4 = UMatrix(UMatrix(nSets),Help2);                                                      //Help4 = Id(nSets*nKan) - A inv(A^t A) A^t
    RARMat= Help3.GetAMAT(DataMat.GetTranspose()); if(RARMat.GetError()!=U_OK) return U_ERROR;  //RARMAT = R^tA inv(A^tA) A^tR

    double* RARSingVal = RARMat.GetSingValuesArray();
    if(RARSingVal==NULL) return U_ERROR;

    int nMoments = pDipMan->GetNfreeMoment();
    int nCMpar   = nFreeSTF*nSets*nBasicSTF;
    int Fdim     = (nBasicSTF*nBasicSTF+2*(nMoments/3))*(nCMpar+nSourcePar+nBasicSTF*nSamples);
    int nPar     = nCMpar+nSourcePar+nBasicSTF*nSamples;
    double* F    = new double[Fdim];
    for(p=0;p<Fdim;p++) F[p]=0.;

  /* Compute derivative of (B_z^t U_zz) w.r.t. m^th SourcePar */
    if(nBasicSTF>1)
    {
        for(m=0;m<nSourcePar;m++)
        {
            double* DAm=new double[nSets*nKan*nSets*nFreeSTF]; //DAm is m^th column of DA, devecced.
            for(int qi=0;qi<nSets*nKan;qi++)
                for(int qs=0;qs<nSets*nFreeSTF;qs++)
                    DAm[qi*nSets*nFreeSTF+qs]=DA[(qs*nSets*nKan+qi)*nSourcePar+m];
            UMatrix DAmMat =UMatrix(DAm,nSets*nKan,nSets*nFreeSTF);

            UMatrix H2,H3;

            UMatrix H1 = PsiTPsiMat.GetInverse();     if(H1.GetError()!=U_OK) return U_ERROR;  //H1= inv(PsiTPsi)
            H2 = GetMatMul(H1, false, PsiMat, true);  if(H2.GetError()!=U_OK) return U_ERROR;  //H2= inv(PsiTPsi)*Psi^t
            H1 = UMatrix(UMatrix(nSets),H2);                                                  //H1= inv(A^tA)*A^t
            H2 = GetMatMul(DAmMat, false, H1, false); if(H2.GetError()!=U_OK) return U_ERROR;  //H2= DAmMat*inv(A^tA)*A^t
            H1 = GetMatMul(Help4, false, H2, false);  if(H1.GetError()!=U_OK) return U_ERROR;  //H1=(I-A inv(A^tA)*A^t)*DAmMat*inv(A^tA)*A^t
            H2 = H1.GetAMAT(DataMat.GetTranspose());  if(H2.GetError()!=U_OK) return U_ERROR;  //H2 = R^t (I-A inv(A^tA)*A^t)*DAmMat*inv(A^tA)*A^t R
            H1 = H2.GetTranspose();
            H3 = H1+H2;

            for(int z=0;z<nBasicSTF;z++)
            {
                double* row = new double[nSamples];
                for(int j=0;j<nSamples;j++)
                    row[j]=Bmat[z*nSamples+j];
                UMatrix BRow=UMatrix(row,1,nSamples);

                for(int zz=0;zz<nBasicSTF;zz++)
                {
                    if(z==zz)   continue;

                    double* column = new double[nSamples];
                    for(int j=0;j<nSamples;j++)    column[j]=UZMat.GetElement(j,zz);
                    UMatrix UColumn=UMatrix(column,nSamples,1);

                    UMatrix H5,H6;
                    UMatrixSymmetric H4;
                    H4 = UMatrix(nSamples)*RARSingVal[zz]-RARMat;                             // F-entry = BRow*psinv(H4)*H3*UColumn
                    H5 = H4.GetPseudoInverse(1e-05); if(H5.GetError() !=U_OK) return U_ERROR; // F-entry = BRow*H5*H3*UColumn
                    H4 = GetMatMul(H5, false, H3, false);        if(H4.GetError() !=U_OK) return U_ERROR;      // F-entry = BRow*H4*UColumn
                    H5 = GetMatMul(BRow, false, H4, false);      if(H5.GetError() !=U_OK) return U_ERROR;      // F-entry = H5*UColumn
                    H4 = GetMatMul(H5, false, UColumn, false);   if(H4.GetError() !=U_OK) return U_ERROR;      // F-entry = H4[0,0]

                    F[(z*nBasicSTF+zz)*nPar+nCMpar+m]=H4.GetElement(0,0);
                    delete[] column;
                }
                delete[] row;
            }
            delete[] DAm;
        }
    }

    /* Compute derivative of (B_z^t U_zz) w.r.t. vec(B) */
    for(int z=0;z<nBasicSTF;z++)
        for(int zz=0;zz<nBasicSTF;zz++)
        {
            for(int j=0;j<nSamples;j++)
            F[(z*nBasicSTF+zz)*nPar+nCMpar+nSourcePar+j*nBasicSTF+z] =UZMat.GetElement(j,zz);
        }

    /* Compute derivative of tangentiality and normality constraints w.r.t. source pars */
    for(p=0,s=0,m=0;p<nDipoles;p++,s++) // p: dipole-index, s: stf-index or constraint index
                                        // m: parameter-index
    {
        UDipole::DipoleType DT = DipArray[p].GetDipoleType();

        switch(DT)
        {
        case UDipole::Current :
            {
         /* Position derivatives of tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+0] = DipArray[p].Getd().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+1] = DipArray[p].Getd().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+2] = DipArray[p].Getd().Getz();
            m+=3;
         /* Orientation derivatives of tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+0] = DipArray[p].Getx().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+1] = DipArray[p].Getx().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+2] = DipArray[p].Getx().Getz();
            s++;
         /* Orientation derivatives of normality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+0] = 2*DipArray[p].Getd().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+1] = 2*DipArray[p].Getd().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+2] = 2*DipArray[p].Getd().Getz();
            m+=3;
            break;
            }

        case UDipole::SymmetricPos :
            {
        /* Position derivatives for Left tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+0] = DipArray[p].Getd().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+1] = DipArray[p].Getd().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+2] = DipArray[p].Getd().Getz();
        /* Orientation derivatives for Left tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+3] = DipArray[p].Getx().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+4] = DipArray[p].Getx().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+5] = DipArray[p].Getx().Getz();
            s++;
        /* Orientation derivatives for Left normality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+3] = 2*DipArray[p].Getd().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+4] = 2*DipArray[p].Getd().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+5] = 2*DipArray[p].Getd().Getz();
            s++;
        /* Position derivatives for Right tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+0] =   DipArray[p].GetdSym().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+1] = -(DipArray[p].GetdSym().Gety());
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+2] =   DipArray[p].GetdSym().Getz();
        /* Orientation derivatives for Right tangentiality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+6] =   DipArray[p].Getx().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+7] = -(DipArray[p].Getx().Gety());
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+8] =   DipArray[p].Getx().Getz();
            s++;
        /* Orientation derivatives for Right normality constraint */
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+6] = 2*DipArray[p].GetdSym().Getx();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+7] = 2*DipArray[p].GetdSym().Gety();
            F[(nBasicSTF*nBasicSTF+s)*nPar+nCMpar+m+8] = 2*DipArray[p].GetdSym().Getz();
            m+=9;
            break;
            }

        case UDipole::Symmetric :
        default:
            {
            CI.AddToLog("ERROR: ULocCodeDip::ComputeParameterCov(). Invalid Dipole Type or not implemented.\n");
            return U_ERROR;
            }
        }
    }

    if(p!=nDipoles || s!= 2*nFreeSTF || m!= nSourcePar)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeParameterCov(). Error in loop for derivatives in F.");
        return U_ERROR;
    }

    UMatrix FMat     = UMatrix(F,nBasicSTF*nBasicSTF+(2*nMoments/3),nPar);
    UMatrix ForthMat = FMat.GetOrthogonalBasis();
    if(ForthMat.GetError()!=U_OK) return U_ERROR;

    UMatrix FTFMat = FMat.GetMTM(); if(FTFMat.GetError() != U_OK) return U_ERROR;
/*
   Compute the Fisher Information Matrix (FIM), in partitions as I_CC, I_BC etc.
   I_SS stands for the information Matrix w.r.t. to the source parameters
*/
    UMatrix BBTMat = BMat.GetMMT(); if(BBTMat.GetError() !=U_OK) return U_ERROR; // BBTMat = BB^t
    UMatrix ATAMat = UMatrix(UMatrix(nSets),PsiTPsiMat);                         // ATAMat = A^tA
    UMatrix I_CC   = UMatrix(BBTMat, ATAMat);                                    // I_CC = BB^t (x) A^tA

    UMatrix I_CB, I_BC, I_BB, I_CS, I_SC, I_SS, I_SB, I_BS;
    Help1 = GetMatMul(ATAMat, false, CMat, false); if(Help1.GetError() !=U_OK) return U_ERROR;  // Help1 = A^tA C
    I_CB  = UMatrix(BMat, Help1);                                            // I_CB  = B (x) A^tA C
    I_BC  = I_CB.GetTranspose();

    Help2 = GetMatMul(CMat, true, Help1, false);   if(Help2.GetError() !=U_OK) return U_ERROR;  // Help2 = C^t A^tA C
    I_BB  = UMatrix(UMatrix(nSamples),Help2);                                // I_BB = Id(nSamples) (x) C^t A^tA C

    Help1 = GetMatMul(BBTMat,false,CMat, true);    if(Help1.GetError()!=U_OK) return U_ERROR;  // Help1 = BB^t C^t
    Help2 = UMatrix(Help1,AMat.GetTranspose());                              // Help2 = BB^t C^t (x) A^t
    I_CS  = GetMatMul(Help2, false, DAMat, false); if(I_CS.GetError() !=U_OK) return U_ERROR;  // I_CS  = {BB^t C^t (x) A^t} DA
    I_SC  = I_CS.GetTranspose();

    Help2 = GetMatMul(CMat, false, Help1, false);  if(Help2.GetError()!=U_OK) return U_ERROR; // Help2 = C BB^t C^t
    Help1 = UMatrix(Help2,UMatrix(nSets*nKan));                                // Help1 = C BB^t C^t (x) Id(nSets*nKan)
    I_SS  = Help1.GetAMAT(DAMat.GetTranspose());   if(I_SS.GetError()!=U_OK) return U_ERROR; 
                                                                               // I_SS = DA^t {C BB^t C^t (x) Id(nSets*nKan)} DA

    Help1 = GetMatMul(CMat, false, BMat, false);   if(Help1.GetError()!=U_OK) return U_ERROR; // Help1 = CB
    Help2 = GetMatMul(AMat, false, CMat, false);   if(Help2.GetError()!=U_OK) return U_ERROR; // Help2 = AC
    Help3 = UMatrix(Help1,Help2);                                              // Help3 = CB (x) AC
    I_SB  = GetMatMul(DAMat, true, Help3, false);    if(I_SB.GetError()!=U_OK) return U_ERROR;  // I_SB  = DA^t {CB (x) AC}
    I_BS  = I_SB.GetTranspose();

    UMatrix Row1,Row2,Row3,FIM;

    Help1 = I_CC .GetConcatRows(I_CC); if(Help1.GetError()!= U_OK) return U_ERROR;
    Row1  = Help1.GetConcatRows(I_CB); if(Row1 .GetError()!= U_OK) return U_ERROR;
    Help1 = I_SC .GetConcatRows(I_SS); if(Help1.GetError()!= U_OK) return U_ERROR;
    Row2  = Help1.GetConcatRows(I_SB); if(Row2 .GetError()!= U_OK) return U_ERROR;
    Help1 = I_BC .GetConcatRows(I_BS); if(Help1.GetError()!= U_OK) return U_ERROR;
    Row3  = Help1.GetConcatRows(I_BB); if(Row3 .GetError()!= U_OK) return U_ERROR;
    
    Help1 = Row1.GetTranspose().GetConcatRows(Row2.GetTranspose()); if(Help1.GetError()!= U_OK) return U_ERROR;
    FIM   = Help1.GetConcatRows(Row3.GetTranspose());               if(FIM  .GetError()!= U_OK) return U_ERROR;
/* Now FIM contains the entire Fisher Information Matrix of all parameters */

/* Alternative 1: CCRB by Stoica : CCRB = V* inv( V^t FIM V) V^t, CCRB manner */
    if(method ==0)
    {
        UMatrixSymmetric Help1 = FIM.GetAMAT(ForthMat.GetTranspose());
        Help2 = Help1.GetInverse();
        CCRB  = Help2.GetAMAT(ForthMat);
        delete[] DA;
        delete[] RARSingVal;
        delete[] F;
        return U_OK;
    }

/* Alternative 2: Augmented Information Matrix by Huizenga
   The FIM is augmented using the derivative matrix of the constraints, that is FMat
*/
    if(method==1)
    {
        UMatrix FIMMat = FIM;
        FIM  += FTFMat;
        Row1  = FIM .GetConcatRows(FMat.GetTranspose() );                           if(Row1 .GetError()!= U_OK) return U_ERROR;
        Row2  = FMat.GetConcatRows(UMatrix(nBasicSTF*nBasicSTF+(2*nMoments/3))*0.); if(Row2 .GetError()!= U_OK) return U_ERROR;
        Help2 = Row1.GetTranspose().GetConcatRows((Row2.GetTranspose()));           if(Help2.GetError()!= U_OK) return U_ERROR;
        UMatrixSquare H2 =Help2;
        Help1 = H2.GetInverse();                                                    if(Help1.GetError()!= U_OK) return U_ERROR;
        CCRB  = Help1.GetBlock(0, 0, nPar, nPar);                                   if(CCRB .GetError()!= U_OK) return U_ERROR;
        delete[] DA;
        delete[] RARSingVal;
        delete[] F;
        return U_OK;
    }

/* Alternative 3: PseudoInverse of Information Matrix, taking nPar-nConstraints eigenvalues into account */
    CCRB = FIM.GetPseudoInverse(nPar-nBasicSTF*nBasicSTF-(2*nMoments/3));
    delete[] DA;
    delete[] RARSingVal;
    delete[] F;
    return U_OK;

}

ErrorType ULocCodeDip::ComputeConfIntervals(double* ConfInt, double* pvalues, const double* BasicSTF, int method, double pval, UMatrix* CCRBmat, bool Bonf)
/*
    GENERAL:
    This routine computes the confidence intervals around the estimated STFs
    (i.e. entries of C*B) of all sources in all data sets in the GMANOVA model R=ACB.
    As covariance matrix of the parameters, the Constrained CRB is used.
    These confidence intervals are output in ConfInt[(q*nFreeSTF+p)*nSamples+j]
    (j= sample, p is freeSTF index, q = data set index)
    In pvalues[q*nFreeSTF+p] the p-value of the estimated amplitude over the
    entire time interval (all samples) is output (p = freeSTF index, q= data set index)
    BasicSTF should contain the unprewhitened BasicSTF, so in general BasicSTF is not
    equal to Bmat.

    OPTIONAL ARGUMENTS:
    method: the method used to compute the Constrained CRB. See
    ULocCodeDip::ComputeParameterCov(), for definition of methods
    CCRBmat: the Constrained CRB of the parameters. The order of the parameters is
    defined in the routine  ULocCodeDip::ComputeParameterCov(), as are the constraints.
    pval: the p-value used for the confidence intervals, default is 0.05, that is 0.025
    on each side.
    Bonf: by default a Bonferroni correction is performed, i.e. the p-values is devided by
    (#samples*#data sets). If Bonf==false, no correction is performed.
*/
{
    UMatrix SigmaMat_C, CCRB;
    if(ComputeParameterCov(CCRB,method)!=U_OK)
    {
        CI.AddToLog("ERROR: ULocCodeDip::ComputeConfIntervals(). Error in ComputeParameterCov().\n");
        return U_ERROR;
    }
    if(CCRBmat)
        *CCRBmat = CCRB;

    CI.AddToLog("NOTE: ULocCodeDip::ComputeConfIntervals() using p-value = %f.\n",pval);

    int nFreeSTF = pDipMan->GetNfreeSTF();

    SigmaMat_C = CCRB.GetBlock(0,0,nFreeSTF*nSets*nBasicSTF,nFreeSTF*nSets*nBasicSTF); if(SigmaMat_C.GetError()!= U_OK) return U_ERROR;

    UMatrix VmatMat  = UMatrix(Vmat,nSamples,nSamples);
    UMatrix DataMat  = UMatrix(EMData,nSets*nKan,nSamples);
    UMatrix FieldMat = UMatrix(pDipMan->GetFieldSTF(),nFreeSTF,nKan);
    FieldMat         = FieldMat.GetTranspose();
    UMatrix AMat     = UMatrix(UMatrix(nSets),FieldMat);
    UMatrix BmatMat  = UMatrix(Bmat,nBasicSTF,nSamples);
    UMatrix CMat     = UMatrix(CM,nSets*nFreeSTF,nBasicSTF);
    UMatrix HelpMod  = GetMatMul(AMat,false, CMat, false);        // HelpMod = AMat.CM
    UMatrix ModelMat = GetMatMul(HelpMod, false, BmatMat, false); // ModelMat = AMat.CM.BmatMat
    UMatrix ResMat   = DataMat - ModelMat;

    const double* Sigma       = SigmaMat_C.GetMatrixArray();
    double*       SigmaSelect = new double[nBasicSTF*nBasicSTF];
    double*       Row         = new double[nBasicSTF];
    UMatrix       CovMatSelect;
    UMatrix       Numerator,Help,RowMat;

    int SigmaDim = SigmaMat_C.GetNrow();

    /* The variables related to the F-test */
    // v1,v2: the degrees of freedom
    double Fvalue; // the value of the numerator in the F-test

    int nSourcePar  = pDipMan->GetNfreeMoment()+pDipMan->GetNfreePosPars();
    double v1       = nBasicSTF;
    double v2       = nKan*nSamples*nSets - nSourcePar - nSets*nFreeSTF*nBasicSTF - nBasicSTF*nSamples+nBasicSTF*nBasicSTF+2*((pDipMan->GetNfreeMoment())/3);
    double reserror = ResMat.GetFrobNorm2();

    double x_bound  = 0.5;
    double x_low    = 0.5;
    double x_up     = 1.0;
    double p_b      = betai(v2/2,0.5,x_bound);
    double p_corval = pval/2;
    if(Bonf) p_corval/=(nSamples*nSets);

    while (fabs(p_b-p_corval)>1e-05)
    {
        if(p_b > p_corval) x_up  = x_bound;
        else               x_low = x_bound;
        x_bound = x_low + (x_up-x_low)/2;
        p_b     = betai(v2/2,0.5,x_bound);
    }
    double Fbound = v2*(1-x_bound)/x_bound;

    for(int q=0, qnF=0; q<nSets; q++,qnF+=nFreeSTF)
    {
        for(int p=0;p<nFreeSTF;p++)
        {
            for(int z=0,znSnF=0;z<nBasicSTF;z++,znSnF+=nSets*nFreeSTF)
            {
                Row[z]=CM[(qnF+p)*nBasicSTF+z];
                for(int zz=0,zznSnF=0;zz<nBasicSTF;zz++,zznSnF+=nSets*nFreeSTF)
                    SigmaSelect[z*nBasicSTF+zz] = Sigma[(znSnF+qnF+p)*SigmaDim+zznSnF+qnF+p];
            }

            UMatrixSymmetric Help = UMatrix(SigmaSelect,nBasicSTF,nBasicSTF);
            CovMatSelect = Help.GetInverse();
            if(CovMatSelect.GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: ULocCodeDip::ComputeConfIntervals(). Error in row p=%d, q=%d.\n",p,q);
                break;
            }
            RowMat    = UMatrix(Row,1,nBasicSTF);
            Numerator = CovMatSelect.GetAMAT(RowMat);
            if(Numerator.GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: ULocCodeDip::ComputeConfIntervals(). Error in row p=%d, q=%d.\n",p,q);
                break;
            }
            Fvalue = (Numerator.GetElement(0,0)/v1)/(reserror/v2);
            pvalues[qnF+p]=betai(v2/2,v1/2,v2/(v2+v1*Fvalue));
        }
    }

    int nFnSnBnSP = nFreeSTF*nSets*nBasicSTF + nSourcePar;
    int dima      = nFreeSTF*nSets*nBasicSTF + nSourcePar+nBasicSTF*nSamples;
    double*    a  = new double[dima];

    UMatrix aRow;
    UMatrix WMat = CovTT->GetSqrt();
    for(int q=0,qnF=0;q<nSets;q++,qnF+=nFreeSTF)
    {
        for(int p=0;p<nFreeSTF;p++)
        {
            for(int j=0;j<nSamples;j++)
            {
                for(int i=0;i<dima;i++) a[i]=0.;
                for(int z=0,znFnS=0;z<nBasicSTF;z++,znFnS+=nFreeSTF*nSets)
                {
                    a[znFnS + qnF+p] = BasicSTF[z*nSamples+j];
                    for(int jj=0;jj<nSamples;jj++)
////                        a[nFnSnBnSP+jj*nBasicSTF+z] = CM[(qnF+p)*nBasicSTF+z]*Eigen[jj]*Wmat[j*nSamples+jj];
                        a[nFnSnBnSP+jj*nBasicSTF+z] = CM[(qnF+p)*nBasicSTF+z]*WMat.GetElement(j, jj);
                }
                aRow       = UMatrix(a,1,dima);
                Numerator  = CCRB.GetAMAT(aRow);
                double cov = Numerator.GetElement(0,0);
                ConfInt[(qnF+p)*nSamples+j]= sqrt(Fbound*cov*(reserror/v2)/nTrialsPerSet[q]);
            }
        }
    }

    delete[] SigmaSelect;
    delete[] Row;
    delete[] a;
    return U_OK;
}


ErrorType UFitDipoles::FitCodeDipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocCodeDip::CostType CT, bool AdFordMod, FitDataType FDT, UCodeManager::CodeType CdT)
{
/* Test whether data is read and epochs are set.*/
    if(Data==NULL || Epochs==NULL) return U_ERROR;

    if( (FDT==U_MEG_AND_EEG || FDT==U_EEG_ONLY) && Data->AreEEGPositionsMeasured()==false)
    {
        CI.AddToLog("WARNING: UFitDipoles::FitCodeDipoles(). EEG dipole fitting is based on default electrode positions. True EEG sensor positions not set.\n");
    }

/* Test whether FitDataType is MEG_ONLY, not yet implemented for EEG data */
    if(FDT!=U_MEG_ONLY)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). FitDataType is not U_MEG_ONLY. Other types not implemented yet. \n");
        return U_ERROR;
    }

/* Test the number of dipoles */
    if(Ndipoles<=0 || Ndipoles > MAXCODEDIP)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Invalid Argument in Ndipoles.\n");
        return U_ERROR;
    }

/* Set head model*/
    UHeadModel* HModel=GetHeadModel(HeadModelFileName, FDT);
    if(HModel==NULL || HModel->GetError()!=U_OK) return U_ERROR;

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdFordMod==true)
        ReRefForw = GetMEGForwardBalancing();

/* Spatial covariance */
    UCovariance CovXX;
    if(CT==ULocCodeDip::U_GLSSPACE||CT==ULocCodeDip::U_GLSSPACETIME)
        CovXX = UCovariance(GetSpatCovarianceFile(), Data->GetGridMEG(), Data->GetGridEEG());
    else
    {
        if(FDT==U_MEG_ONLY && Data->GetGridMEG())
            CovXX = UCovariance(Data->GetGridMEG()->GetNpoints());
        else
        {
            CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Data grids not consistent with requested fit data types. \n");
            return U_ERROR;
        }
    }
    if(CovXX.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Creating Spatial covariance. \n");
        return U_ERROR;
    }

/* Temporal covariance */
    UCovariance CovTT(GetNSampEpoch(0), true);
    if(CT==ULocCodeDip::U_GLSTIME || CT==ULocCodeDip::U_GLSSPACETIME)
    {
        CovTT = UCovariance(GetTempCovarianceFile(), GetNSampEpoch(0));
        if(CovTT.GetError()!=U_OK) 
        {
            CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Creating Spatial covariance. \n");
            return U_ERROR;
        }
    }

/* Set the coupled dipole object*/
    ULocCodeDip* ULCD = new ULocCodeDip(cost, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), Data->GetGridMEG(), NULL, HModel, &CovXX, &CovTT);

    if(ULCD==NULL || ULCD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Cannot create ULocCodeDip-object\n");
        delete ULCD;
        return U_ERROR;
    }

/* Test the size of the windows, should be equal over epochs for any CT*/
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Epoch times should be equal in case of temporal covariance.\n");
        delete ULCD;
        return U_ERROR;
    }

    if(ULCD->InitStart(ST, StartFile, NGlobPoints, Ndipoles, DType, Rdips)!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Initializing start parameters.\n");
        delete ULCD;
        return U_ERROR;
    }

/* Set UCodeManager-object and Data in ULCD */
    if(ULCD->SetDataAndCode(CdT, this)  !=U_OK)
    {
        delete ULCD;
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Error in setting data and code.\n");
        return U_ERROR;
    }

    UDipole  Dipoles[MAXCODEDIP];
    int      nBasicSTF  = ULCD->GetNBasicSTF();
    int      nSamp      = ULCD->GetNSamples();
    int      nCodes     = ULCD->GetNCodes();
    const    UString* CodeNames = ULCD->GetCodeNames(NULL);
    double   Residual   = 0;
    double **DataNorm   = new double*[nCodes];
    double  *BasicSTF   = new double[nBasicSTF*nSamp];
    double  *resPerCode = new double[nCodes];

    if(DataNorm && BasicSTF && resPerCode)
    {
        for(int q=0;q<nCodes; q++)
        {
            DataNorm[q]=new double[nSamp];
            if(!DataNorm[q])
            {
                for(int qq=0;qq<q;qq++)
                    delete[] DataNorm[qq];
                delete[] DataNorm;
                delete[] BasicSTF;
                delete[] resPerCode;
                delete ULCD;
                CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Memory allocation. \n");
                return U_ERROR;
            }
        }
    }
    else
    {
        for(int q=0;q<nCodes; q++)
        {
            if(DataNorm[q])
                delete[] DataNorm[q];
        }
        delete[] DataNorm;
        delete[] BasicSTF;
        delete[] resPerCode;
        delete ULCD;
        CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Memory allocation. \n");
        return U_ERROR;
    }

    int a=0;
    for(a=0;a<nCodes;         a++)
        for(int aa=0;aa<nSamp;aa++) DataNorm[a][aa]  =0.;
    for(a=0;a<nBasicSTF*nSamp;a++ ) BasicSTF[a]  =0.;
    for(a=0;a<nCodes;         a++ ) resPerCode[a]=0.;

/* Fit stationary dipoles on averaged coded data*/
    ULCD->ComputeDipoles(Dipoles, Ndipoles, &Residual, DataNorm, BasicSTF, resPerCode);

/* Export results*/
    UEvent Begin       = Epochs->GetBegin(0);
    UEvent End         = Epochs->GetEnd(0);
    int    nChan       = Data->GetNmeg();
    int    NsampPTrial = Data->GetNsampTrial();
    FILE*  fpOut       = NULL;

    int q=0;
    for(q=0;q<nCodes;q++)
    {
        UFileName FileOut = FileNameOut;
        FileOut.InsertFileNumber(q,3);
        fpOut = fopen(FileOut,"wt", true);
        fprintf(fpOut,"// CODE %s:\n// \n",(const char*)CodeNames[q]);
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"//   Results obtained with\n");
        fprintf(fpOut,"%s",(const char*)CI.GetProperties("//   "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        if(GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",(const char*)GetMarkerArray()->GetProperties("//  "));
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",cost.GetParameterString());
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"%s",(const char*) ULCD->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// HEAD MODEL:\n");
        fprintf(fpOut,"%s",(const char*)HModel->GetProperties("//  "));
        fprintf(fpOut,"//\n");

        const double *DataChannel = NULL;// (not yet implemented for multiple codes)GetDataChannel(DataEpMEG, DataEpEEG, NsampEp, ChanName);
        double *StdErrMean        = NULL;

        int nDipInCode=0;
        int DipInCodeIndex[MAXCODES];
        double* CodeSTF = new double[2*MAXCODEDIP*nSamp];
        for(int pj=0;pj<2*MAXCODEDIP*nSamp;pj++) CodeSTF[pj]=0.;
        if (ULCD->ComputeCodeOutput(q,nDipInCode,DipInCodeIndex,BasicSTF,CodeSTF,nSamp)!=U_OK)
        {
            CI.AddToLog("ERROR: UFitDipoles::FitCodeDipoles(). Error in ComputeCodeOutput() for code %d\n",q);
            for(int q=0;q<nCodes; q++)
            {
                if(DataNorm[q])
                    delete[] DataNorm[q];
            }
            delete[] DataNorm;
            delete[] CodeSTF;
            delete[] BasicSTF;
            delete[] resPerCode;
            delete ULCD;

            return U_ERROR;
        }

        char line[200+100*MAXCODEDIP];
        int  nc=0;

        if(TimeInMs==false)
            nc += sprintf(line,"Samp");
        else
            nc += sprintf(line,"Time");

        int l=0;
        for(l=0; l<nDipInCode; l++)
            nc += Dipoles[DipInCodeIndex[l]].PrintParameters(line+nc,-(200+100*MAXCODEDIP-nc-1),l);

        if(Rdips==false)
        {
            if(DType==UDipole::SymmetricPos)
            {
                for(l=0; l<nDipInCode; l++)
                {
                    nc += sprintf(line+nc,"\tSTF_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_R%d ",l);
                }
            }
            else
            {
                for(l=0; l<nDipInCode; l++)
                    nc += sprintf(line+nc,"\tSTF%d ",l);
            }
        }
        nc += sprintf(line+nc,"\tERROR(%%)");
        nc += sprintf(line+nc,"\tResPerCodePerSample(%%)");
        nc += sprintf(line+nc,"\tAverDataPower");
        if(StdErrMean) nc += sprintf(line+nc,"\tStdErrMean");
        if(DataChannel)
        {
            nc += sprintf(line+nc,"\tChan=%s",ChanName);
        }
        else if(ChanName && ChanName[0]!=0)
        {
            fprintf(fpOut,"// Warning: Required channel %s not in file.\n",ChanName);
        }
        fprintf(fpOut,"%s\n",line);

        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();


        for(int j=0; j<nSamp; j++)
        {
            UEvent E = GetEvent(0, j);
            nc       = 0;
            if(TimeInMs==false)
                nc += sprintf(line,"%6.6d   ",E.GetAbsSample(NsampPTrial));
            else
                nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(NsampPTrial));

            if(Rdips==false)
            {
                for(int l=0; l<nDipInCode; l++)
                    nc += Dipoles[DipInCodeIndex[l]].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
                if(DType==UDipole::SymmetricPos)
                {
                    for(int ll=0; ll<2*nDipInCode; ll++)
                        nc += sprintf(line+nc,"\t%f ",CodeSTF[ll*nSamp+j]);
                }
                else
                {
                    for(int ll=0; ll<nDipInCode; ll++)
                        nc += sprintf(line+nc,"\t%f ",CodeSTF[ll*nSamp+j]);
                }
            }

            nc += sprintf(line+nc,"\t%f",Residual);
            nc += sprintf(line+nc,"\t%f",resPerCode[q]);
            if(nChan)
                nc += sprintf(line+nc,"\t%f",DataNorm[q][j]/(ULCD->GetNTrialsPerSet(q)));
            else
                nc += sprintf(line+nc,"\t0.0");
            if(StdErrMean)  nc += sprintf(line+nc,"\t%f",StdErrMean[j]);
            if(DataChannel) nc += sprintf(line+nc,"\t%f",DataChannel[j]);
            fprintf(fpOut,"%s\n",line);
        }
        delete[] StdErrMean;
        delete[] CodeSTF;
        fclose(fpOut);
    }

/* Print all basic parameters to the general output file */
    FileNameOut.InsertBeforeExtension("BasicOutput");
    fpOut = fopen(FileNameOut,"wt", true);
    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut,"//   Results obtained with\n");
    fprintf(fpOut,"%s",(const char*)CI.GetProperties("//   "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// DATA:\n");
    fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    if(GetMarkerArray())
    {
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA MARKERS:\n");
        fprintf(fpOut,"%s",(const char*)GetMarkerArray()->GetProperties("//  "));
    }
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// EPOCHS:\n");
    if(OneFile==false)
        fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
    else
    {
        if(Epochs->GetnEpochs()<10)
        {
            for(int k=0; k<Epochs->GetnEpochs(); k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
        }
        else
        {
            for(int k=0; k<9; k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            fprintf(fpOut,"//   ..., Etc. \n");
        }
    }
    fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// FITTING:\n");
    fprintf(fpOut,"//   %s\n",cost.GetParameterString());
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"%s", (const char*)ULCD->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// HEAD MODEL:\n");
    fprintf(fpOut,"%s",(const char*)HModel->GetProperties("//  "));
    fprintf(fpOut,"//\n\n");

    char line[200+100*MAXCODEDIP];
    int  nc=0;

    int l=0;
    for(l=0; l<Ndipoles; l++)
        nc += Dipoles[l].PrintParameters(line+nc,-(200+100*MAXCODEDIP-nc-1),l);
    fprintf(fpOut,"%s\n",line);

    nc=0;
    for(l=0; l<Ndipoles; l++)
        nc += Dipoles[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
    fprintf(fpOut,"%s\n\n",line);

    fprintf(fpOut,"Time\t");
    for(int p=0; p<nBasicSTF; p++)
        fprintf(fpOut,"STF%d\t",p);
    fprintf(fpOut,"\n");

    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();
    for(int j=0; j<nSamp; j++)
    {
        UEvent E = GetEvent(0, j);
        nc       = 0;
        if(TimeInMs==false)
            nc += sprintf(line,"%6.6d ",E.GetAbsSample(NsampPTrial));
        else
            nc += sprintf(line,"%f",Stime*E.GetAbsSample(NsampPTrial));

        for(int p=0; p<nBasicSTF; p++)
            nc += sprintf(line+nc,"\t%f",BasicSTF[p*nSamp+j]);

        fprintf(fpOut,"%s\n",line);
    }
    fprintf(fpOut,"\n\n");
    fclose(fpOut);

    for(q=0;q<nCodes;q++)
        ULCD->PrintCodeMat(FileNameOut,q,true);
    ULCD->PrintCodePars(FileNameOut,true);

    for(q=0;q<nCodes; q++)
    {
        if(DataNorm[q])
            delete[] DataNorm[q];
    }
    delete[] DataNorm;
    delete[] BasicSTF;
    delete[] resPerCode;
    delete ULCD;

    return U_OK;
}

ErrorType UFitDipoles::FitGMANOVADipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocCodeDip::CostType CT, bool AdFordMod, FitDataType FDT, int nDipoles, int nBasicSTF)
{
/* Test whether data is read and epochs are set.*/
    if(Data==NULL || Epochs==NULL) return U_ERROR;

    if( (FDT==U_MEG_AND_EEG || FDT==U_EEG_ONLY) && Data->AreEEGPositionsMeasured()==false)
    {
        CI.AddToLog("WARNING: UFitDipoles::FitGMANOVADipoles(). EEG dipole fitting is based on default electrode positions. True EEG sensor positions not set.\n");
    }

/* Test whether FitDataType is MEG_ONLY, not yet implemented for EEG data */
    if(FDT!=U_MEG_ONLY)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). FitDataType is not U_MEG_ONLY. Other types not implemented yet. \n");
        return U_ERROR;
    }

/* Test the number of dipoles */
    if(nDipoles<=0 || nDipoles > MAXCODEDIP)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Invalid Argument in Ndipoles.\n");
        return U_ERROR;
    }

/* Set head model*/
    UHeadModel* HModel=GetHeadModel(HeadModelFileName, FDT);
    if(HModel==NULL || HModel->GetError()!=U_OK) return U_ERROR;

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdFordMod==true)
        ReRefForw = GetMEGForwardBalancing();

/* Spatial covariance */
    UCovariance CovXX;
    if(CT==ULocCodeDip::U_GLSSPACE||CT==ULocCodeDip::U_GLSSPACETIME, true)
        CovXX = UCovariance(GetSpatCovarianceFile(), Data->GetGridMEG(), Data->GetGridEEG());
    else
    {
        if(FDT==U_MEG_ONLY && Data->GetGridMEG())
            CovXX = UCovariance(Data->GetGridMEG()->GetNpoints());
        else
        {
            CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Data grids not consistent with requested fit data types. \n");
            return U_ERROR;
        }
    }
    if(CovXX.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Creating Spatial covariance. \n");
        return U_ERROR;
    }

/* Temporal covariance */
    UCovariance CovTT(GetNSampEpoch(0), true);
    if(CT==ULocCodeDip::U_GLSTIME || CT==ULocCodeDip::U_GLSSPACETIME)
    {
        CovTT = UCovariance(GetTempCovarianceFile(), GetNSampEpoch(0));
        if(CovTT.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Creating Spatial covariance. \n");
            return U_ERROR;
        }
    }

/* Set the stationary dipole object*/
    ULocCodeDip* ULCD = NULL;

    ULCD = new ULocCodeDip(cost, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), Data->GetGridMEG(), NULL, HModel, &CovXX, &CovTT, true);

    if(ULCD==NULL || ULCD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Cannot create ULocCodeDip-object\n");
        delete ULCD;
        return U_ERROR;
    }

/* Test the size of the windows, should be equal over epochs for any CT*/
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Epoch times should be equal in case of temporal covariance.\n");
        delete ULCD;
        return U_ERROR;
    }

    if(ULCD->InitStart(ST, StartFile, NGlobPoints, nDipoles, DType, Rdips)!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Initializing start parameters.\n");
        delete ULCD;
        return U_ERROR;
    }

/* Set Data and nDipoles in ULCD */
    if(ULCD->SetGMANOVAData(nDipoles, nBasicSTF, this) !=U_OK)
    {
        delete ULCD;
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Error in setting data and code.\n");
        return U_ERROR;
    }

    UDipole  Dipoles[MAXCODEDIP];
    int      nSamp      = ULCD->GetNSamples();
    int      nSets      = ULCD->GetNCodes();
    const    UString* CodeNames = ULCD->GetCodeNames(NULL);
    double   Residual   = 0;
    double **DataNorm   = new double*[nSets];
    double  *BasicSTF   = new double[nBasicSTF*nSamp];
    double  *resPerCode = new double[nSets];

    if(DataNorm && BasicSTF && resPerCode)
    {
        for(int q=0;q<nSets; q++)
        {
            DataNorm[q]=new double[nSamp];
            if(!DataNorm[q])
            {
                for(int qq=0;qq<q;qq++)
                    delete[] DataNorm[qq];
                delete[] DataNorm;
                delete[] BasicSTF;
                delete[] resPerCode;
                delete ULCD;
                CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Memory allocation. \n");
                return U_ERROR;
            }
        }
    }
    else
    {
        for(int q=0;q<nSets; q++)
        {
            if(DataNorm[q])
                delete[] DataNorm[q];
        }
        delete[] DataNorm;
        delete[] BasicSTF;
        delete[] resPerCode;
        delete ULCD;
        CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Memory allocation. \n");
        return U_ERROR;
    }

    int a=0;
    for(a=0; a<nSets; a++)
        for(int aa=0; aa<nSamp; aa++)    DataNorm[a][aa] =0.;
    for(a=0; a<nBasicSTF*nSamp; a++ ) BasicSTF[a]     =0.;
    for(a=0; a<nSets; a++)           resPerCode[a]   =0.;

/* Fit stationary dipoles on averaged coded data*/
    ULCD->ComputeDipoles(Dipoles, nDipoles, &Residual, DataNorm, BasicSTF, resPerCode);

    int nFreeSTF = ULCD->GetNFreeSTF();
    double* ConfInt = new double[nSets*nFreeSTF*nSamp];
    double* pvalues = new double[nSets*nFreeSTF];
    for(a =0;a<nSets*nFreeSTF*nSamp;a++) ConfInt[a]=0.;
    for(a =0;a<nSets*nFreeSTF;      a++) pvalues[a]=0.;
    ULCD->ComputeConfIntervals(ConfInt, pvalues, BasicSTF);

/* Export results*/
    UEvent Begin       = Epochs->GetBegin(0);
    UEvent End         = Epochs->GetEnd(0);
    int    nChan       = Data->GetNmeg();
    int    NsampPTrial = Data->GetNsampTrial();
    FILE*  fpOut       = NULL;

    int q=0;
    for(q=0;q<nSets;q++)
    {
        UFileName FileOut = FileNameOut;
        FileOut.InsertFileNumber(q,3);
        fpOut = fopen(FileOut,"wt", true);
        fprintf(fpOut,"// DATA SET %s:\n\n",(const char*)CodeNames[q]);
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"//   Results obtained with\n");
        fprintf(fpOut,"%s",(const char*)CI.GetProperties("//   "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        if(GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",(const char*)GetMarkerArray()->GetProperties("//  "));
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",cost.GetParameterString());
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"%s", (const char*)ULCD->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// HEAD MODEL:\n");
        fprintf(fpOut,"%s",(const char*)HModel->GetProperties("//  "));
        fprintf(fpOut,"//\n");

        const double *DataChannel = NULL;// (not yet implemented for multiple codes)GetDataChannel(DataEpMEG, DataEpEEG, NsampEp, ChanName);
        double *StdErrMean        = NULL;

        double* STF = new double[2*MAXCODEDIP*nSamp];
        for(int pj=0;pj<2*MAXCODEDIP*nSamp;pj++) STF[pj]=0.;

        if(ULCD->ComputeGMANSetOutput(q,BasicSTF,STF)!=U_OK)
        {
            CI.AddToLog("ERROR: UFitDipoles::FitGMANOVADipoles(). Error in ComputeGMANSetOutput() for data set %d\n",q);
            for(int q=0;q<nSets; q++)
            {
                if(DataNorm[q])
                    delete[] DataNorm[q];
            }
            delete[] DataNorm;
            delete[] STF;
            delete[] BasicSTF;
            delete[] resPerCode;
            delete ULCD;


            return U_ERROR;
        }

        char line[200+100*MAXCODEDIP];
        int  nc=0;

        if(TimeInMs==false)
            nc += sprintf(line,"Samp");
        else
            nc += sprintf(line,"Time");


        int l=0;
        for(l=0; l<nDipoles; l++)
            nc += Dipoles[l].PrintParameters(line+nc,-(200+100*MAXCODEDIP-nc-1),l);

        if(Rdips==false)
        {
            if(DType==UDipole::SymmetricPos)
            {
                for(l=0; l<nDipoles; l++)
                {
                    nc += sprintf(line+nc,"\tSTF_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_R%d ",l);
                }
            }
            else
            {
                for(l=0; l<nDipoles; l++)
                    nc += sprintf(line+nc,"\tSTF%d ",l);
            }
        }
        nc += sprintf(line+nc,"\tERROR(%%)");
        nc += sprintf(line+nc,"\tResPerCode(%%)");
        nc += sprintf(line+nc,"\tAverDataPower");
        if(StdErrMean) nc += sprintf(line+nc,"\tStdErrMean");
        if(DataChannel)
        {
            nc += sprintf(line+nc,"\tChan=%s",ChanName);
        }
        else if(ChanName && ChanName[0]!=0)
        {
            fprintf(fpOut,"// Warning: Required channel %s not in file.\n",ChanName);
        }
        if(Rdips==false)
        {
            if(DType==UDipole::SymmetricPos)
            {
                for(l=0; l<nDipoles; l++)nc += sprintf(line+nc,"\tConfInt_L%d ",l);
                for(l=0; l<nDipoles; l++)nc += sprintf(line+nc,"\tConfInt_R%d ",l);
            }
            else
            {
                for(l=0; l<nDipoles; l++)
                    nc += sprintf(line+nc,"\tConfInt%d ",l);
            }
            fprintf(fpOut,"%s\n",line);
        }

        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

        for(int j=0; j<nSamp; j++)
        {
            UEvent E = GetEvent(0, j);
            nc       = 0;
            if(TimeInMs==false)
                nc += sprintf(line,"%6.6d   ",E.GetAbsSample(NsampPTrial));
            else
                nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(NsampPTrial));

            if(Rdips==false)
            {
                for(int l=0; l<nDipoles; l++)
                    nc += Dipoles[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<2*nDipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",STF[l*nSamp+j]);
                }
                else
                {
                    for(int l=0; l<nDipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",STF[l*nSamp+j]);
                }
            }

            nc += sprintf(line+nc,"\t%f",Residual);
            nc += sprintf(line+nc,"\t%f",resPerCode[q]);
            if(nChan)
                nc += sprintf(line+nc,"\t%f",DataNorm[q][j]/(nChan*(ULCD->GetNTrialsPerSet(q))));
            else
                nc += sprintf(line+nc,"\t0.0");
            if(StdErrMean)  nc += sprintf(line+nc,"\t%f",StdErrMean[j]);
            if(DataChannel) nc += sprintf(line+nc,"\t%f",DataChannel[j]);

            if(Rdips==false)
            {
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<2*nDipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",ConfInt[(q*nFreeSTF+l)*nSamp+j]);
                }
                else
                {
                    for(int l=0; l<nDipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",ConfInt[(q*nFreeSTF+l)*nSamp+j]);
                }
            }

            fprintf(fpOut,"%s\n",line);
        }
        delete[] StdErrMean;
        delete[] STF;
        fclose(fpOut);
    }

/* Print all basic parameters to the general output file */
    FileNameOut.InsertBeforeExtension("BasicOutput");
    fpOut = fopen(FileNameOut,"wt", true);
    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut,"//   Results obtained with\n");
    fprintf(fpOut,"%s",(const char*)CI.GetProperties("//   "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// DATA:\n");
    fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// TOTAL DATA SET:\n");
    if(GetMarkerArray())
    {
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA MARKERS:\n");
        fprintf(fpOut,"%s",(const char*)GetMarkerArray()->GetProperties("//  "));
    }
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// EPOCHS:\n");
    if(OneFile==false)
        fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
    else
    {
        if(Epochs->GetnEpochs()<10)
        {
            for(int k=0; k<Epochs->GetnEpochs(); k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
        }
        else
        {
            for(int k=0; k<9; k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            fprintf(fpOut,"//   ..., Etc. \n");
        }
    }
    fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// FITTING:\n");
    fprintf(fpOut,"//   %s\n",cost.GetParameterString());
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"%s", (const char*)ULCD->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// HEAD MODEL:\n");
    fprintf(fpOut,"%s",(const char*)HModel->GetProperties("//  "));
    fprintf(fpOut,"//\n\n");

    char line[200+100*MAXCODEDIP];
    int  nc=0;

    int l=0;
    for(l=0; l<nDipoles; l++)
        nc += Dipoles[l].PrintParameters(line+nc,-(200+100*MAXCODEDIP-nc-1),l);
    fprintf(fpOut,"%s\n",line);

    nc=0;
    for(l=0; l<nDipoles; l++)
        nc += Dipoles[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
    fprintf(fpOut,"%s\n\n",line);

    fprintf(fpOut,"Time\t");
    for(int p=0; p<nBasicSTF; p++)
        fprintf(fpOut,"STF%d\t",p);
    fprintf(fpOut,"\n");

    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();
    for(int j=0; j<nSamp; j++)
    {
        UEvent E = GetEvent(0, j);
        nc       = 0;
        if(TimeInMs==false)
            nc += sprintf(line,"%6.6d ",E.GetAbsSample(NsampPTrial));
        else
            nc += sprintf(line,"%f",Stime*E.GetAbsSample(NsampPTrial));

        for(int p=0; p<nBasicSTF; p++)
            nc += sprintf(line+nc,"\t%f",BasicSTF[p*nSamp+j]);

        fprintf(fpOut,"%s\n",line);
    }
    fprintf(fpOut,"\n\n");
    fclose(fpOut);

    for(q=0;q<nSets;q++)
        ULCD->PrintCodeMat(FileNameOut,q,true);

    fpOut = fopen(FileNameOut,"at", true);
    fprintf(fpOut,"P-values for significance of estimated activity of all source in all data sets:\n");
    for(q=0;q<nSets;q++)
    {
        fprintf(fpOut,"Data set %d: %s\n",q,(const char*)CodeNames[q]);
        for(int p=0; p<nFreeSTF;p++)
            fprintf(fpOut,"Source %d: p-value = %f, log(p) = %f \n",p,pvalues[q*nFreeSTF+p], log(pvalues[q*nFreeSTF+p])/log(10.));
        fprintf(fpOut,"\n");
    }
    fclose(fpOut);

    for(q=0;q<nSets; q++)
    {
        if(DataNorm[q])
            delete[] DataNorm[q];
    }
    delete[] DataNorm;
    delete[] BasicSTF;
    delete[] resPerCode;
    delete[] ConfInt;
    delete[] pvalues;

    if(ULCD) delete ULCD;

    return U_OK;
}
