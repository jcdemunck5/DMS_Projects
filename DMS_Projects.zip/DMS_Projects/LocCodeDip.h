#ifndef _LOCCODEDIP_INCLUDED
#define _LOCCODEDIP_INCLUDED

#include "Matrix.h"
#include "Minimize.h"
#include "StartStatDip.h"
#include "CodeManager.h"
#include "EMfield.h"
#include "DipoleEditList.h"
#include "Covariance.h"

class UMEEGDataEpochs;

class ULocCodeDip : public UStartStatDip, public Uminimize
{
public:
    enum CostType {U_SQUARE, U_GLSSPACE, U_GLSTIME, U_GLSSPACETIME};
      
    ULocCodeDip(const UCostminimize& cost, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* gridM, const UGrid* gridE, const UHeadModel *Hmod, 
        UCovariance* CovXX, UCovariance* CovTT, bool GMAN=false);  
    virtual ~ULocCodeDip();

    ErrorType           GetError() const {return error;}
    UString&            GetProperties(UString Comment) const;
    ErrorType           SetCovariance(UCovariance* CovNewXX, UCovariance* CovNewTT);

    ErrorType           SetDataAndCode(UCodeManager::CodeType CdT, const UMEEGDataEpochs* DatEpo);
    ErrorType           SetData(double **DataMEG, double **DataEEG, int* nTrialsPerCode, int ncodes);
    ErrorType           SetCode(UCodeManager::CodeType CdT, bool CodeOnly=false);
    
    ErrorType           SetCoupleDesign(bool** CoupleMat, char** MarNames, int nCondition, int nBasicSTF, UDipoleEdit* DipEd, int nDipoles);
    ErrorType           SetGMANOVAData(int nDipoles, int nBasicSTF, const UMEEGDataEpochs* DatEpo, const double* PushData=NULL);
    ErrorType           SetECDMDesignAndData(char** MarNames, int nCondition, int nBas, UDipoleEdit* DipEd, int nDipoles, double **DataMEG, double **DataEEG, int* nTrialsPerCode);
    
    ErrorType           SetNComp(int ncmp, double thres);
    ErrorType           SetNDipoles(int nDipoles);
	ErrorType           SetCM(const double* cm);
    void                SetnBasicSTF(int n) {nBasicSTF = n;}
	void                SetnSets(int n)     {nSets = n;}
	void                SetNSamples(int n)  {nSamples = n;}
    

    UCodeManager* const GetCodeManager(void)  const {return (UCodeManager*)pDipMan;}
    const double*       GetSV(void)           const {return SV;}
    const double*       GetCM(void)           const {return CM;}
    const double*       GetBmat(void)         const {return Bmat;}
    int                 GetNSamples()         const {return nSamples;}
    int                 GetNCodes()           const;
    int                 GetNBasicSTF()        const;
    int                 GetNFreeSTF()         const;
    const UString*      GetCodeNames(int *NNames) const;
    const double* const* const GetCodeMat()   const;
    int                 GetNDipolesInCode(int q)                       const;
    ErrorType           GetDipInCodeIndex(int q, int* index)           const;
    int                 GetSignOfCodedSTF(int p, int istf)             const;
    int                 GetSignOfSTF(int istf, const double* BasicSTF) const;
    int                 GetSignOfBasicSTF(int istf)                    const;
    void                InvertBasicSTF(int istf);
	void                InvertFreeSTF(int istf);
    int                 GetNTrialsPerSet(int q) const; 
    double              GetDataNorm(void) const {return DataNorm;}

	double              GetVmat(int j) const {return Vmat[j];}
    
    ErrorType           ComputeCodeOutput(int q, int& nDipInCode, int* DipInCodeIndex, double* BasicSTF, double* CodeSTF, int nSamp) const;
	ErrorType           ComputeGMANSetOutput(int q, double* BasicSTF,double* STF) const;
    void                PrintCodeMat(UFileName FileNameOut,int q, bool Normalize=false) const; 
    void                PrintCodePars(UFileName FileNameOut,bool Normalize=false) const; 

    ErrorType           ComputeDipoles(UDipole* DipArray,  int Ndip, double *residual, double** DataNorm, double *STF, double *residualPerCode=NULL);
    ErrorType           ComputeDipoles(UDipoleEdit* DipEd, int Ndip, double *residual, double** DataNorm, double *STF, double *residualPerCode=NULL);
    int                 GetNtotCost(void) const     {return NtotCost;}
    
    double              ComputeCost(double *par, int iter=0, int *status=NULL, double *grad=NULL);
/* Required (=pure virtual in Uminimize() and in UStartDipole()): */
    double              ComputeCost(double *par, int iter, int *status) 
                        {
                            return ComputeCost(par, iter, status, NULL);
                        }
    ErrorType           CompMatInv(double* AmatInv, double* LeadField) const;
    
    ErrorType           ComputeParameterCov(UMatrix& CCRB, int method =0);  
    ErrorType           ComputeConfIntervals(double* ConfInt, double* pvalues, const double* BasicSTF, int method=0, double pval=0.05, UMatrix* Sigma = NULL, bool Bonf= false);
   
private:
    static const double COSTERROR;
    static const double AMAT_THRESHOLD;
    static const int    MAXLINITER;
    static const double OLS_REL_EEG_VARIANCE;

    static UString      Properties;
    ErrorType           error;        // General error

/* MEG parameters*/
    int                 nMEG ;        // The number of MEG channels == GridMEG->GetNpoints()
    const UGrid*        GridMEG;      // Array of MEG sensors
/* EEG parameters*/
    int                 nEEG ;        // The number of EEG channels == GridEEG->GetNpoints()
    const UGrid*        GridEEG;      // Array of EEG sensors

/* General (EEG/MEG) */ 
    UEMfield::FieldType Ftype;        // Modality used: MEG, EEG or both
    int                 nSamples;     // Number of samples per channel, present in DataMEG/DataEEG
    int                 nComp;        // Number of components used in SVD of data matrix

    CostType            CType;        // Determines the spatio-temporal coviance used
    UCovariance*        CovTT;        // The (theoretical) temporal covariance
    UCovariance*        CovXX;        // The (theoretical) spatial covariance for the MEG/EEG sensors

/* Source Time Functions Help arrays*/    
    double*             Bmat;         // Temporally Prewhitened Basic Source Time Functions: Bmat=F*W_T*V
                                      // In case GMAN == true, Bmat = F*W_T
    double*             ULBT;         // ULamda * BmatT

/* Coupling Matrix in case of GMANOVA model */
	bool                GMAN;         // The boolean indicating whether GMANOVA model is used or the CodeManager
    double*             CM;           // Coupling matrix (nChan*nCodes by nSamples)	
	int                 nSets;        // Number of conditions
	int                 nBasicSTF;    // Number of basic STFs when GMANOVA model is used
	UString*            DataSetNames; // Array with names of all data sets (marker names)
	int*                nTrialsPerSet;// Number of trials per data set    

/* Data Help arrays*/
    double*             EMData;       // Pre-whitened E/MEG data, first MEG then EEG channels, stored in one super matrix  
                                      // EMDataT = [sqrt(nTrials[1])XR_1T,...,sqrt(nTrials[q])XR_qT,...,sqrt(nTrials[Q])XR_QT]
    double*             ULamda;       // SVD-Decomposition of EMData:    
    double*             Lamda;        //    EMData = Umat * Lamda * VmatT = ULamda * VmatT
    double*             Vmat;         // 
    double*             SV;           // Normalize singular values (in % of data power of EMData[])
    double**            WmatTfld;     // General purpose pointer to EM fields of different dipoles

    int                 NtotCost;     // The total number of calls to ComputeCost(), starting from constructor    
    double              DataNorm;     // Sum of (weighted) squares of EMData[]
  	
    double              UpdateBmat(void);
    void                NormalizeBmat(void);
    double              UpdateMoments(void);
    double              UpdateCodes(void);
    void                UpdateCodeMat(void);
	double              UpdateSTFmatAndCM(void);
    void                UpdateGMANOVAMoments(void);
	double              GetCMNormalizer(void) const;
    
    double              ComputeCost(const double* const* WEMdat, double FitTest=0.999999); //FitTest is used when fits need to be less or more precise 
    ErrorType           ComputeResPerCode(double* resPerCode, double** DataNorm, double* res);
    ErrorType           ComputeGMANOVAResiduals( double* residual, double* resPerCode, double** DataNorm);
    double*             GetPrewGetEMfield(const UDipole* Dip);
};

#endif // _LOCCODEDIP_INCLUDED
