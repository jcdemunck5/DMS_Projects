/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading fitting magnetic dipoles, with known time functions.   */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    ??-??-97   creation
  Jdm    23-10-97   include bad-channel test, compute starting value
  Jdm    07-11-97   added computation of derivative of cost function, so that Marquardt's 
                    method can be used.
  Jdm    23-01-98   compute total residual error, and not the errors for each coil.
  Jdm    30-01-98   tested and debugged the computation of the derivative.
  Jdm    18-02-98   compatibility with new grid.h (UCTFData interface)
                    added ComputeGlobalSearch() function
  Jdm    23-03-98   use new and delete, adaptation to grid.h 
  Jdm    26-03-98   rename ULocHead to ULocCoil, Add function ComputeAllCoils()
  Jdm    30-03-98   New interface: use class USensor() instead of struct SENSOR
  Jdm    06-04-98   BUG in ComputeGlobalSearch()
  Jdm    08-04-98   Added option to keep the calibration constant
  Jdm    10-06-98   Use an arbitrary number of ADC channels
  Jdm    22-07-98   Compute the minimum possible residual MinRes in SetTrial();
  Jdm    15-09-98   Compute Meshpositions with a separate object: UMeshPoints
                    Use different types of starting values.
  Jdm    18-09-98   Make use of the StartDipole - object
  JdM    08-10-98   separated include-files
  JdM    09-10-98   splitted ComputeAllCoils() into two different functional parts
  JdM    16-10-98   Added the computation of MaxVariADC
  JdM    20-10-98   Skip conversion to Nasion-Ear system if nADC<3 in ConvertToGrid()
  JdM    18-12-98   BUG FIX: Printing the bad channels.
  JdM    02-02-99   Test whether the number of good channels does not get below MINGOODCHAN
  JdM    11-02-99   Added a time range, outside which the time samples are ignored.
  JdM    14-02-99   BUG fixes in changes of 11-02-99
  JdM    16-02-99   Added the computation of the orthogonality in FitStatistics
  JdM    05-03-99   Added function RemoveOffset() (taken from base class)
  Jdm    16-03-99   Complete revision of the code: split into two parts, one part
                    deals with the localisation of coils on one epoch (this part) and a part
                    responsible for the combination of different epochs (FitCoils.cpp)
  Jdm    31-03-99   Incorporate changes made in UEmfield-object
                    Print bad channels by sensor name, i.s.o. number
  JdM    05-05-99   BUG fix in deleting double pointers (**fld)
  JdM    10-04-99   Made UEmfield a private object
  JdM    10-04-99   BUG FIX: Call Emf.SetGridMEG() in constructor
  JdM    23-05-00   Move UEMfield object to base class: UStartDipole
  JdM    24-05-00   ComputeCost(Uvector3...) return error in %
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    03-10-00   Compatibility with nADC==1
  JdM    10-07-01   Remove UGrid-parameters, and use the ones from UStartDipole. Adapt constructor.
                    Replace Emf.GetEMfield() by Emf.GetBfield()
  JdM    19-08-01   Adapt forward model (UEmfield object) to take balancing information into account
GdV/JdM  01-11-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    05-01-07   Remove reference to obsolete UCTFData object (remove constructor)
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    23-05-07   ComputeCoils() Added ResErrPerc parameter.
  Jdm    17-08-08   Bug Fix: ULocCoil::ULocCoil(). SetBalancing(): Use UMEEGDataBase::MAXMEG
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include <string.h>          
#include "LocCoil.h"

/* Inititalize static const parameters. */
const int    ULocCoil::MINGOODCHAN   =  40;
const int    ULocCoil::MAXSTRING     =  300;
const double ULocCoil::ANG2DIS       =  4.;


void ULocCoil::SetAllMembersDefault(void)
{
    error            = U_OK;
    ErrorString      = NULL;
    BadString        = NULL;
    BadChan          = NULL;
    NBad             = 0;

    nADC             = 0;
    nMEG             = 0;
    Smat             = NULL;
    Ccof             = NULL;
    MinRes           = 0.;
    CostConstant     = 0.;
    MaxVariADC       = NULL;
    Orthogonality    = 0.;
    ResidualError    = 0.;

    CoilNumber       = -1;
    StrFix           = FREE_STRENGTH;
    CalibFact        = NULL;

    Direction        = NULL;
    DataStatistics   = NULL;
}
void ULocCoil::DeleteAllMembers(ErrorType E) 
{
    delete[] Direction;         
    delete[] Smat;              
    delete[] Ccof;              
    delete[] MaxVariADC;        
    delete[] BadChan;           
    delete[] BadString;         
    delete[] DataStatistics;         
    delete[] ErrorString;
    delete[] CalibFact;         

    SetAllMembersDefault();
    error = E;
}

ULocCoil::ULocCoil(const UCostminimize& cost, ReReferenceType ReRefForw, const UMEEGDataBase* Data) : 
    Uminimize(cost), UStartDipole(Data->GetGridMEG(), NULL, NULL)
{      
    SetAllMembersDefault();

    if(UStartDipole::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocCoil::ULocCoil(). Base class constructor UStartDipole. \n");
        return;
    }
    if(Data->GetNADC()<=0 || Data->GetNADC()>UMEEGDataBase::MAXADC)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocCoil::ULocCoil(). Number of ADC channels out of range: nadc = %d . \n", Data->GetNADC());
        return;
    }

    if(Emf.SetGrid(Data->GetGridMEG())!=U_OK)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocCoil::ULocCoil(). Emf.SetGrid() failed. \n");
        return;
    }

    nADC           = Data->GetNADC();
    nMEG           = Data->GetGridMEG()->GetNpoints();

    if(ReRefForw!=U_REF_RAW &&
       Emf.SetBalancing(Data->GetGridREF(), Data->GetpBalancing(), UMEEGDataBase::MAXMEG, ReRefForw)!=U_OK)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocCoil::ULocCoil(). Setting forward balancing failed. \n");
        return;
    }

    Direction      = new double[3*nADC];
    Smat           = new double[nADC*nADC];
    Ccof           = new double[nMEG*nADC];
    MaxVariADC     = new double[nADC];
    BadChan        = new char[nMEG];
    BadString      = new char[MAXSTRING+1];
    DataStatistics = new char[MAXSTRING+1];
    ErrorString    = new char[MAXSTRING+1];
    CalibFact      = new double[nADC*3]; 
    
    if(!Direction || !Smat || !Ccof || !MaxVariADC || !BadChan || !BadString || 
       !DataStatistics || !CalibFact)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocCoil::ULocCoil(). Memory allocation. \n");
        return;
    }   
    
    memset(BadString,0,MAXSTRING+1);
    memset(DataStatistics,0,MAXSTRING+1);
    memset(ErrorString,0,MAXSTRING+1);

    ResetCoilCalibration();
}

ULocCoil::~ULocCoil()
{
    DeleteAllMembers(U_OK);
}

ErrorType ULocCoil::InitCompute(double* DataMEG, double* DataADC, int Nsamp, double BadThreshold)
/*
    -Fill help arrays with cross correlations
    -Determine bad channels
    -Determine Cost constant

     DataMEG[]    : Array with the MEG channel data in fT (offset removed) (channel by channel)
     DataADC[]    : Array with the MEG channel data in fT (offset removed)
     Nsamp        : Number of channles
     BadThreshold : Error criterion to mark a channel as BAD (in %)
 */
{   
    error = U_ERROR;
    NBad  = -1;
    memset(ErrorString,0,MAXSTRING+1);

    if(!DataMEG || !DataADC) 
    {
        sprintf(ErrorString," FATAL ERROR: memory ");
        return error;
    }

/* Fill help arrays...*/
    for(int k1=0; k1<nADC; k1++)
    {
        for(int k2=0; k2<nADC; k2++)
        {
            int k12 = nADC*k1+k2;
            Smat[k12] = 0;
            for(int j=0;j<Nsamp;j++) Smat[k12] += DataADC[k1*Nsamp+j]*DataADC[k2*Nsamp+j];
        }
    }

    for(int k=0; k<nADC; k++)
    {
        for(int i=0; i<nMEG; i++)
        {
            int ki = nMEG*k+i;
            Ccof[ki] = 0;
            for(int j=0;j<Nsamp;j++) Ccof[ki] += DataMEG[i*Nsamp+j]*DataADC[k*Nsamp+j];
        }
    }

/* Determine the bad channels by computing the minimum possible residual per channel*/
    NBad = 0;
    for(int i=0;i<nMEG;i++)
    {
        double normalize = 0;
        for(int j=0;j<Nsamp;j++) normalize += DataMEG[i*Nsamp+j]*DataMEG[i*Nsamp+j];

        double minres = 0;
        for(int k=0; k<nADC; k++)  minres += Ccof[nMEG*k+i]*Ccof[nMEG*k+i]/Smat[nADC*k+k];
        minres = 1.-minres/normalize;
        if(100.*minres>BadThreshold)
        {
            NBad++;
            BadChan[i] = 1;
        }
        else
            BadChan[i] = 0;
    }
    if(nMEG-NBad<MINGOODCHAN) 
    {
        sprintf(ErrorString," ERROR: Too many bad channels: nMEG=%d nBad=%d;", nMEG, NBad);
        return error;
    }

/* Compute Norm of MEG data, over the non-bad channels*/
    CostConstant = 0.;
    for(int k=0,i=0; i<nMEG; i++)
       for(int j=0;j<Nsamp;j++,k++)
       {
           if(!BadChan[i]) 
               CostConstant += DataMEG[k]*DataMEG[k];
       }

/* Compute the maximum explained variance per ADC channel, assuming their source
   time function are orthogonal*/

    for(int k=0; k<nADC; k++) 
    {
        MaxVariADC[k] = 0;
        for(int i=0; i<nMEG; i++)
        {
            if(BadChan[i]) continue;
            int ki = nMEG*k+i;
            MaxVariADC[k] += Ccof[ki]*Ccof[ki]/Smat[k*(nADC+1)];
        }
        if(CostConstant!=0.)  MaxVariADC[k] *= 100./CostConstant;
    }

/* Compute minimum possible residual*/
    double *Sinv = new double[nADC*nADC];
    if(Sinv)
    {
        memcpy(Sinv, Smat, nADC*nADC*sizeof(double));
        if(!dsymin_c(Sinv, nADC, nADC, NULL))
        {
            MinRes = CostConstant;
            for(int i=0; i<nMEG; i++)
            {
                if(BadChan[i]) continue;

                for(int k1=0; k1<nADC; k1++)
                {
                    double Temp = 0;
                    int    ki2  = i;
                    for(int k2=0; k2<nADC; k2++,ki2+=nMEG) Temp += Sinv[nADC*k1+k2]*Ccof[ki2];

                    MinRes -= Ccof[nMEG*k1+i]*Temp;
                }
            }
        }
    }
    if(CostConstant!=0.) MinRes *= 100./CostConstant;
    
/* Compute the "orthogonality" */
    if(nADC==1)
    {
        Orthogonality = 0;
    }
    else
    {
        double MinDiag = fabs(Smat[0]);
        double MaxOff  = fabs(Smat[1]);
        for(int k=0; k<nADC*nADC; k++)
        {
            if(k%(nADC+1))     MaxOff  = MAX(MaxOff, fabs(Smat[k]));
            else               MinDiag = MIN(MinDiag, fabs(Smat[k]));
        }
        Orthogonality = MinDiag/MaxOff;
        if(Orthogonality<10.)
        {
            size_t nc = strlen(ErrorString);
            strncat(ErrorString," WARNING: Orthogonality less than 10;",MAXSTRING-nc-1);
        }
    }

    delete[] Sinv;
    return error=U_OK;    
}

char* ULocCoil::PrintBadChannels(char* str, int nch)
{
    memset(BadString,' ',MAXSTRING);

    int nc = sprintf(BadString,"NBad=%d : ",NBad) ;
    for(int i=0;i<nMEG;i++)
    {
        if(!BadChan[i])   continue;
        if(nc>MIN(nch,MAXSTRING)-(5+USensor::MAXLABELSIZE)) 
        {
            nc+=sprintf(BadString+nc,"...");
            break;
        }
        nc+=sprintf(BadString+nc,"%s,",GridMEG->GetName(i));
    }
    if(str) memcpy(str,BadString,nc);

    return BadString;
}

ErrorType ULocCoil::ComputeCoils(UDipole *Dip, StrengthFixation SF, double* ResError)
/*
    Compute the nADC coil positions and orientations of the current epoch. Positions are
    stored in the array Dip[]. Starting values, which should be present in this array, 
    are overwritten on return.

    Notes:
    -call AnalyzeData() before ComputeCoils() is called.
    -The contents of *residual is expressed in %
    -if(SF==FREE_STRENGTH) the dipoles starting values are computed according UStartDipole::SType,
     else the iterations are started from Dip[]
 */
{
    if(ResError) *ResError = 100.;
    if(!Dip) return U_ERROR;

    StrFix = SF;
    Niter  = 0;
    if(StrFix==FIXED_STRENGTH)
    {
        double *DipPar = new double[5*nADC];
        if(!DipPar) return U_ERROR;

/* Copy parameters and iterate*/
        for(int k=0;k<nADC;k++)
        {
            DipPar[5*k    ] = Dip[k].Getx().Getx();
            DipPar[5*k + 1] = Dip[k].Getx().Gety();
            DipPar[5*k + 2] = Dip[k].Getx().Getz();
            DipPar[5*k + 3] = Dip[k].Getd().GetTheta()*ANG2DIS;
            DipPar[5*k + 4] = Dip[k].Getd().GetFi()   *ANG2DIS;

/* First find each dipole coil, independent of the others */
            CoilNumber = k;
            if(Iterate(DipPar+5*k, 5) != U_OK) return U_ERROR;
            Niter += GetNoIterations();
        }
    
/* Compute cost function for all coils simultaneously */
        CoilNumber    = nADC;
        ResidualError = 100.*ComputeCost(DipPar);

/* Copy updates to input parameters*/
        for(int k=0;k<nADC;k++)
            Dip[k] = UDipole(UVector3(DipPar[5*k  ], DipPar[5*k+1], DipPar[5*k+2]),
                             UVector3(DipPar[5*k+3]/ANG2DIS, DipPar[5*k+4]/ANG2DIS) * CalibFact[k],
                             UDipole::Magnetic);
        delete[] DipPar;
    }
    else
    {
/* Copy parameters and iterate*/
        double *Position = new double[3*nADC];
        double ErrorTot  = 1.;
        if(!Position) return U_ERROR;

        UStartDipole::GetStartDipole(Dip, Ccof);
        for(int k=0;k<nADC;k++)
        {
            Position[3*k    ] = Dip[k].Getx().Getx();
            Position[3*k + 1] = Dip[k].Getx().Gety();
            Position[3*k + 2] = Dip[k].Getx().Getz();

/* First find each dipole coil, independent of the others */
            CoilNumber = k;
            if(Iterate(Position+3*k, 3) != U_OK) return U_ERROR;
            ErrorTot -= (1.-ComputeCost(Position+3*k));
            Niter    += GetNoIterations();
        }
    
/* Compute cost function for all coils simultaneously */
        CoilNumber    = nADC;
        ResidualError = 100.*ComputeCost(Position);

/* Copy updates to input parameters*/
        for(int k=0;k<nADC;k++)
            Dip[k] = UDipole(UVector3(Position[3*k] ,Position[3*k+1] ,Position[3*k+2]),
                             UVector3(Direction[3*k],Direction[3*k+1],Direction[3*k+2]),
                             UDipole::Magnetic);
        delete[] Position;
    }
    if(ResError) *ResError = ResidualError;
    
    if(ResidualError>5.)
    {
        size_t nc = strlen(ErrorString);
        strncat(ErrorString," WARNING: residual error larger than 5%;",MAXSTRING-nc-1);
    }
    return U_OK;
}

char* ULocCoil::GetDataStatistics(void)
/* 
    Archive the data statistics and return a pointer to a string containing
    these statistics in text format.
*/   
{
    memset(DataStatistics,0,MAXSTRING+1);

    if(error==U_OK)
    {
        int nc = 0;
        nc += sprintf(DataStatistics+nc,"Orthogonality = %9.1f;",Orthogonality);
        nc += sprintf(DataStatistics+nc,"ERROR=%9.5f%% Minres=%9.5f%%; Maxvar (",ResidualError,MinRes);

        for(int k=0; k<nADC; k++)
        {
            if(nc>MAXSTRING-15) break;
            nc += sprintf(DataStatistics+nc,"%7.3f%%,",MaxVariADC[k]);
        }
        nc += sprintf(DataStatistics+nc-1,"); Niter=%4d ",Niter);

        PrintBadChannels(DataStatistics+nc-1, MAXSTRING-nc-1);
    }
    else
    {
        sprintf(DataStatistics,"ERROR: Too many bad channels: nMEG=%d nBad=%d ", nMEG, NBad);
    }
    return DataStatistics;
}

double ULocCoil::ComputeCost(double *par, int iter, int *status, double *grad)
/*
    Compute cost function for the given position parameters par[]. The directions of
    the coils are determined by a linear estimate.
    if(grad)   compute the MINUS-gradient of the cost
 */
{
    if(status) *status = 0;
    double const COSTERROR = 1000.;

    double   cost;

    if(CoilNumber<0)    return -1;

    if(StrFix==FIXED_STRENGTH)
    {
/* Compute the cost as if only coil CoilNumber is active. */    
        if(CoilNumber<nADC)
        {
            UDipole Dip(par[0], par[1], par[2], par[3]/ANG2DIS, par[4]/ANG2DIS, UDipole::Magnetic);
            
            double  *fld = Emf.GetBfield(&Dip, D_OriPos10);
            if(!fld)  return COSTERROR;

            double sTh = sin(par[3]/ANG2DIS); 
            double cTh = cos(par[3]/ANG2DIS); 
            double sFi = sin(par[4]/ANG2DIS); 
            double cFi = cos(par[4]/ANG2DIS); 
            double Dir[3];
            Dir[0] = CalibFact[CoilNumber]*sTh*cFi;
            Dir[1] = CalibFact[CoilNumber]*sTh*sFi; 
            Dir[2] = CalibFact[CoilNumber]*cTh;
            
            double *fld00 = new double[nMEG];
            if(!fld00) return COSTERROR;
            for(int i=0; i<nMEG; i++) fld00[i] = fld[3*i]*Dir[0] + fld[3*i+1]*Dir[1] + fld[3*i+2]*Dir[2]; 

           
            cost = 0.;
            for(int i=0;i<nMEG;i++) 
            {
                if(BadChan[i]) continue;
                cost += fld00[i]*fld00[i];                
            }
            cost = CostConstant + Smat[(nADC+1)*CoilNumber]*cost;

            for(int i=0;i<nMEG;i++) 
            {
                if(BadChan[i]) continue;
                cost -= 2*fld00[i]*Ccof[nMEG*CoilNumber+i];
            }
            cost /= CostConstant;

/* Compute gradient, if required. */
            if(grad)
            {
                UDipole Dip(par[0], par[1], par[2], Dir[0], Dir[1], Dir[2], UDipole::Magnetic);
                
                double   *fldder = Emf.GetBfield(&Dip, D_OriPos01);
                if(!fldder)  return COSTERROR;
            
                double d0 = Smat[nADC*CoilNumber+CoilNumber]*Dir[0];
                double d1 = Smat[nADC*CoilNumber+CoilNumber]*Dir[1];
                double d2 = Smat[nADC*CoilNumber+CoilNumber]*Dir[2];
            
                double DirTh[3];
                DirTh[0] = CalibFact[CoilNumber]*cTh*cFi/ANG2DIS;
                DirTh[1] = CalibFact[CoilNumber]*cTh*sFi/ANG2DIS; 
                DirTh[2] =-CalibFact[CoilNumber]*sTh    /ANG2DIS;

                double DirFi[3];
                DirFi[0] =-CalibFact[CoilNumber]*sTh*sFi/ANG2DIS;
                DirFi[1] = CalibFact[CoilNumber]*sTh*cFi/ANG2DIS; 
                DirFi[2] = 0.;

                for(int cm1=0;cm1<5;cm1++)  grad[cm1]  = 0;
                for(int i=0;i<nMEG;i++) 
                {
                    if(BadChan[i]) continue;
                    
                    double faci = d0*fld[3*i] + d1*fld[3*i+1] + d2*fld[3*i+2] - Ccof[nMEG*CoilNumber+i];
                    grad[0] += faci * fldder[3*i  ];
                    grad[1] += faci * fldder[3*i+1];
                    grad[2] += faci * fldder[3*i+2];                
                    grad[3] += faci * (fld[3*i]*DirTh[0]+fld[3*i+1]*DirTh[1]+fld[3*i+2]*DirTh[2]);
                    grad[4] += faci * (fld[3*i]*DirFi[0]+fld[3*i+1]*DirFi[1]);
                }
                for(int cm1=0;cm1<5;cm1++)  grad[cm1]  *= -2/CostConstant;            
                delete[] fldder;
            }
            delete[] fld;
            delete[] fld00;

            return cost;
        }

        if(grad) return COSTERROR; // gradient of multiple sources not yet implemented

/* Compute the magnetic field for each coils*/
        double   **fld00 = new double*[nADC];      
        if(!*fld00) return COSTERROR;
    
        for(int k=0;k<nADC;k++)
        {
            UDipole Dip(UVector3(par+5*k), UVector3(par[5*k+3]/ANG2DIS, par[5*k+4]/ANG2DIS)*CalibFact[k], UDipole::Magnetic);
            fld00[k] = Emf.GetBfield(&Dip, D_OriPos00);
            if(!fld00[k])  
            {
                for(int k1=0; k1<k; k1++) delete[] fld00[k1];
                delete[] fld00; 
                return COSTERROR;
            }
        }

        cost = CostConstant;
        for(int i=0;i<nMEG;i++) 
        {
            if(BadChan[i]) continue;

            for(int k1=0; k1<nADC; k1++)
                for(int k2=0; k2<nADC; k2++)
                    cost += Smat[nADC*k1+k2]*fld00[k1][i]*fld00[k2][i];                
        }

        for(int i=0;i<nMEG;i++) 
        {
            if(BadChan[i]) continue;
            
            for(int k=0; k<nADC; k++)
                cost -= 2*fld00[k][i]*Ccof[nMEG*k+i];
        }
        cost /= CostConstant;

        for(int k1=0; k1<nADC; k1++) delete[] fld00[k1];
        delete[] fld00; 
        return cost;
    }
    else   // Update the Coil calibration factors on each iteration
    {
/* Compute the cost as if only coil CoilNumber is active. */    
        if(CoilNumber<nADC)
        {
            UDipole Dip(par[0], par[1], par[2], 
                Direction[3*CoilNumber+0], Direction[3*CoilNumber+1], Direction[3*CoilNumber+2], UDipole::Magnetic);
            
            double  *fld = Emf.GetBfield(&Dip, D_OriPos10);
            if(!fld)  return COSTERROR;

/* Compute Dipole direction */
            double Amat[9];
            double Bvec[3];
            double Dir[3];
            
            for(int cm1=0;cm1<3;cm1++)
            {
                Bvec[cm1]  = 0;
                for(int i=0;i<nMEG;i++) 
                        if(!BadChan[i]) 
                            Bvec[cm1] += Ccof[nMEG*CoilNumber+i]*fld[3*i+cm1];                    
            
                for(int cm2=0;cm2<3;cm2++)
                {
                    if(cm2>=cm1)
                    {
                        Amat[3*cm1+cm2] = 0;
                        for(int i=0;i<nMEG;i++)
                        {
                            if(BadChan[i]) continue;
                            Amat[3*cm1+cm2] += fld[3*i+cm1]*fld[3*i+cm2];
                        }
                        Amat[3*cm1+cm2] *= Smat[nADC*CoilNumber+CoilNumber];
                    }
                    else
                        Amat[3*cm1+cm2]  = Amat[3*cm2+cm1];
                }
            }

/* by Solving the orientations from a linear system of symmetrical equations.*/
            if(daxisb_c(Amat, Dir, Bvec, 3, 3, NULL))  return COSTERROR;
            
            cost = 0;
            for(int k=0;k<3;k++) cost += Bvec[k]*Dir[k];
            cost = 1.-cost/CostConstant;
            
            for(int k=0;k<3;k++) Direction[3*CoilNumber+k] = Dir[k];

/* Compute gradient, if required. */
            if(grad)
            {
                UDipole Dip(par[0], par[1], par[2], Dir[0], Dir[1], Dir[2], UDipole::Magnetic);
                
                double   *fldder = Emf.GetBfield(&Dip, D_OriPos01);
                if(!fldder)  
                {
                    delete[] fld;
                    return COSTERROR;
                }
            
                for(int cm1=0;cm1<3;cm1++)  grad[cm1]  = 0;
                double d0 = Smat[nADC*CoilNumber+CoilNumber]*Dir[0];
                double d1 = Smat[nADC*CoilNumber+CoilNumber]*Dir[1];
                double d2 = Smat[nADC*CoilNumber+CoilNumber]*Dir[2];
            
                for(int i=0;i<nMEG;i++) 
                {
                    if(BadChan[i]) continue;
                    
                    double faci = d0*fld[3*i] + d1*fld[3*i+1] + d2*fld[3*i+2] - Ccof[nMEG*CoilNumber+i];
                    grad[0] += faci * fldder[3*i  ];
                    grad[1] += faci * fldder[3*i+1];
                    grad[2] += faci * fldder[3*i+2];                
                }
                for(int cm1=0;cm1<3;cm1++)  grad[cm1]  *= -2/CostConstant;
            
                delete[] fldder;
            }
            delete[] fld;
            return cost;
        }

        if(grad) return COSTERROR; // gradient of multiple sources not yet implemented

/* Compute the magnetic field for each coils*/
        double   **fld = new double*[nADC];      
        if(!*fld) return COSTERROR;
    
        for(int k=0;k<nADC;k++)
        {
            UDipole Dip(par[3*k  ], par[3*k+1], par[3*k+2], Direction[3*k ], Direction[3*k+1], Direction[3*k+2], UDipole::Magnetic);
            fld[k] = Emf.GetBfield(&Dip, D_OriPos10);
            if(!fld[k])  
            {
                for(int k1=0; k1<k; k1++) delete[] fld[k1];
                delete[] *fld; 
                return COSTERROR;
            }
        }

/* Compute the linear components (directions) */    

        double *Amat = new double[9*nADC*nADC];
        double *Bvec = new double[3*nADC];

        int Ncomp = 3*nADC;
        for(int lam1=0;lam1<Ncomp;lam1++)
        {
            int k1  = lam1/3;
            int cm1 = lam1%3;
        
            Bvec[lam1]  = 0;
            for(int i=0;i<nMEG;i++) 
            {
                if(BadChan[i]) continue;
                Bvec[lam1] += Ccof[nMEG*k1+i]*fld[k1][3*i+cm1];                    
            }
            for(int lam2=0;lam2<Ncomp;lam2++)
            {
                int k2  = lam2/3;
                int cm2 = lam2%3;
        
                if(lam2>=lam1)
                {
                    Amat[Ncomp*lam1+lam2] = 0;
                    for(int i=0;i<nMEG;i++)
                    {
                        if(BadChan[i]) continue;
                        Amat[Ncomp*lam1+lam2] += fld[k1][3*i+cm1]*fld[k2][3*i+cm2];
                    }
                    Amat[Ncomp*lam1+lam2] *= Smat[nADC*k1+k2];
                }
                else
                    Amat[Ncomp*lam1+lam2]  = Amat[Ncomp*lam2+lam1];
            }
        }

/* by Solving the orientations from a linear system of symmetrical equations,*/
/* and computing the residual using the updated directions. */    
        if(daxisb_c(Amat, Direction, Bvec, Ncomp, Ncomp, NULL))  
        {
            cost = COSTERROR;
        }
        else
        {
            cost = CostConstant;
            for(int k=0;k<Ncomp;k++) 
                cost -= Bvec[k]*Direction[k];
            cost /= CostConstant;
        }
        for(int k1=0; k1<nADC; k1++) delete[] fld[k1];
        delete[] fld; 
        
        delete[] Amat;
        delete[] Bvec;

        return cost;
    }
}

double ULocCoil::ComputeCost(const UVector3 &Point, float *fld, int icoil, double *AmatInv)
/*
    Compute cost function for the given position parameters Point using the pre-calculated
    fields that are present in fld[]. This version can only compute the cost 
    (no derivalieves) at the grid points.

    Note: In this function the coil callibrations are estimated by linear estimation and
          hence they are not kept constant.    
 */
{
    double const COSTERROR = 1000.;

    double   cost = COSTERROR;

    CoilNumber = icoil;
    if(CoilNumber<0 || CoilNumber>=nADC)    return -1;


/* Compute Dipole direction */
    double Amat[9];
    double Bvec[3];
    double Dir[3];
    
    for(int cm1=0;cm1<3;cm1++)
    {    
        Bvec[cm1]  = 0;
        for(int i=0;i<nMEG;i++) 
            if(!BadChan[i]) 
                Bvec[cm1] += Ccof[nMEG*CoilNumber+i]*fld[3*i+cm1];                    

        for(int cm2=0;cm2<3;cm2++)
        {
            if(cm2>=cm1)
            {
                Amat[3*cm1+cm2] = 0;
                for(int i=0;i<nMEG;i++)
                {
                    if(BadChan[i]) continue;
                    Amat[3*cm1+cm2] += fld[3*i+cm1]*fld[3*i+cm2];
                }
                Amat[3*cm1+cm2] *= Smat[nADC*CoilNumber+CoilNumber];
            }
            else
                Amat[3*cm1+cm2]  = Amat[3*cm2+cm1];
        }
    }

/* by Solving the orientations from a linear system of symmetrical equations.*/
    if(daxisb_c(Amat, Dir, Bvec, 3, 3, NULL))  return COSTERROR;
    for(int k=0;k<3;k++) Direction[3*CoilNumber+k] = Dir[k];
    
    cost = 0;
    for(int k=0;k<3;k++) cost += Bvec[k]*Dir[k];
    cost = 1.-cost/CostConstant;
    return 100*cost;    
}

ErrorType ULocCoil::ResetCoilCalibration(double *calib)
/*
    If(calib) initiatialize the calibration factors CalibFact[] with the
    given factors calib[]. These callibration factors are used when the coils
    are localized in the mode MomFix==FIXED_STRENGTH.

 */
{
    for(int k=nADC; k<3*nADC; k++) CalibFact[k] = 0.;
    if(calib) 
        for(int k=0; k<nADC; k++) CalibFact[k] = calib[k];

    return U_OK;
}

void ULocCoil::ComputeCoilCalibration(void)
/*
    Compute the best-fitting coil callibrations, for a set of coil localisation
    experiments, assuming that in each of these experiments the functions 
    UpdateCoilCalibration() has be called.
 */
{
    for(int k=0; k<nADC; k++) 
        CalibFact[k] =  CalibFact[nADC+k] /(Smat[(nADC+1)*k]*CalibFact[2*nADC+k]);
}

void ULocCoil::UpdateCoilCalibration(UDipole *Dip)
/*
    Update some interdiate results, that can be used to compute the best fitting
    coil callibrations using ComputeCoilCalibration()
 */
{
    for(int k=0; k<nADC; k++)
    {
        double  *fld = Emf.GetBfield(Dip, D_OriPos00);

        for(int i=0; i<nMEG; i++)
        {
            if(BadChan[i]) continue;
            
            CalibFact[  nADC+k]  += Ccof[nMEG*k+i]*fld[i];
            CalibFact[2*nADC+k]  += fld[i]*fld[i];
        }

        delete[] fld;
    }
}
