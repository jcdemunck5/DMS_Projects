#ifndef _LOCCOIL_INCLUDED
#define _LOCCOIL_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "Minimize.h"
#include "StartDipole.h"
#include "MEEGDataBase.h"

enum CalibType   
{
    U_NOCALIB,
    U_VARYING,
    U_CONSTANT,
    U_ITERATIVE
};

class UMEEGDataBase;

class ULocCoil : public UStartDipole, public Uminimize
{
public:
    static const int    MAXSTRING;    // The maximum number of characters used to describe the results of an epoch
    static const int    MINGOODCHAN;  // The minimum number of channels that are allowed as not BAD

    enum StrengthFixation{FREE_STRENGTH, FIXED_STRENGTH}; 

    ULocCoil(const UCostminimize& cost, ReReferenceType ReRefForw, const UMEEGDataBase* Data);
    ~ULocCoil(void);
    ErrorType     GetError(void)   {return error;}
    int           GetNBad(void)    {return NBad;}

    ErrorType     InitCompute(double* dataMEG, double* dataADC, int Nsamp, double BadThreshold);
    ErrorType     ComputeCoils(UDipole *Dip, StrengthFixation SF, double* ResError);
    char*         GetDataStatistics(void);
    char*         GetErrorString(void)     const  {return ErrorString;}
    
    ErrorType     ResetCoilCalibration(double *calib=NULL);
    void          ComputeCoilCalibration(void);
    void          UpdateCoilCalibration(UDipole *Dip);

    double        ComputeCost(const UVector3 &Point, float *fld, int icoil, double* AmatInv=NULL);
    const double* GetDirection(void) const {return Direction;}

protected:
    void          SetAllMembersDefault(void);
    void          DeleteAllMembers(ErrorType E);

private:
    static const double ANG2DIS;

    ErrorType    error;            // General error flag
    char*        ErrorString;      // String waring/errors
    char*        BadString;        // String with "bad" channels, in a certain trial
	char*        BadChan;          // bytes that indicate whether channel i is BAD or not
    int          NBad;             // The number of bad channels (as detected by ULocCoil)

    int          nADC;             // The number of ADC channels
    int          nMEG;             // The number of MEG channels

    double*      Smat;             // Help matrix: cross correlations of ADC channels
    double*      Ccof;             //              cross correlations between ADC and MEG
    double       MinRes;           // Minimum possible residual in a trial, for a given set of ADC signals
    double       CostConstant;     // Normalization constant for the residual error
    double*      MaxVariADC;       // The maximum amount of variance that can be explained with each of the ADC channels
    double       Orthogonality;    // The minimum diagonal element, divided by the maximum off-diagonal element, computed over the ADC channel improduct matrix
    double       ResidualError;    // The minimum error after fitting the ADC-dipoles to the data [%]

    StrengthFixation StrFix;       // Determines whether the coil-strengths are kept fixed or may vary over epochs
    double*      CalibFact;        // Calibration factors of all nADC coils, their denominators and numerators
    double*      Direction;        // Current directions of the coils

    int          CoilNumber;       // Index number of the coil that is fitted to the data

    int          Niter;            // Number of iterations (for all nADC coils in a trial added)
    char*        DataStatistics;   // A statistical description of the data, for a certain epoch

    char*        PrintBadChannels(char* str, int nch);
    double       ComputeCost(double *par, int iter=0, int *status=NULL, double *grad=NULL);
    double       ComputeCost(double *par, int iter, int *status)
                 {       
                     return ComputeCost(par, iter, status, NULL);
                 }
////    double       ComputeCost(double *par, int iter  , int *status     , double *grad     , double *gauss);
};

#endif // _LOCCOIL_INCLUDED
