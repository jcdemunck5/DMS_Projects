/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for fitting moving dipoles to MEG/EEG data                         */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    01-10-97   creation
  Jdm    13-03-98   adaptation to new interface, present in grid.h. Include the use
                    of the Marquardt minimization method.
  Jdm    12-06-98   import either map or time course data. Internally, use map-data.
  Jdm    16-06-98   change name from ULocDip into ULocMovDip
  Jdm    01-07-98   added global search function
  Jdm    28-08-98   used table with magnetic fields at grid points, to be used with global search
  Jdm    11-09-98   use a UHeadModel-object instead of SpherePos, to describe the head geometry.
  Jdm    15-09-98   Compute Meshpositions with a separate object: UMeshPoints
  Jdm    17-09-98   Use a UGrid-object, instead of a USensor-object;
                    derive ULocMovDip from UStartDipole
  JdM    01-10-98   separated include-files
  JdM    16-11-98   supress y-component of symmetric dipoles close to the x-z-plane.
  JdM    01-12-98   return COSTERROR when cost<0;
  JdM    03-03-99   added pointer to ComputeDipoles() arguments where power of data can be stored.
  JdM    05-03-99   Remove FirstSample and LastSample from class. Dipoles are now fitted on all give time samples
  JdM    16-03-99   Remove the option to enter U_MAPDATA
  Jdm    31-03-99   Incorporate changes made in UEmfield-object
  JdM    09-04-99   Added argument to PrintProperties()
  JdM    16-04-99   Renamed PrintProperties() into GetProperties() and changed format
  JdM    10-06-99   Made UEmfield a private object
  JdM    14-06-99   Allow realistic models.
  JdM    18-06-99   Update the sphere position of the HeadModel using the best fitting sphere to the outer compartment
Jdm/DvT  21-06-99   Use new StartType U_INPUT
  JdM    06-08-99   BUG Fix in dermination of directions and possibly cost.
                    Now use Jacobi decomposition in CostDirection() to determine dipole directions and Cost
                    This would also work in case of realistic models.
  JdM    07-08-99   Print "No Data!" on the screen for those samples where the data vanishes.
  JdM    09-08-99   Added GetBfieldTab(), used by base class UStartDipole()
  JdM    11-08-99   Incorporate changes caused by UStartDipole() updates
  JdM    30-08-99   Allow the use of minimum abs() differences
  JdM    16-10-99   Allow the use of GLS estimates, using UCovariance() object
  JdM    14-12-99   Added parameter to ComputeDipoles() (=MaxStartError)
  JdM    17-01-00   Put fitted head radius in Headmodel, for realistic head models.
                    Compatibility with (pure) EEG data.
  JdM    21-01-00   Replace jacobi_c() (which possibly contains errors) with svd_d()
  JdM    24-01-00   Bug fix: Replace the criterion to determine the number of eigenvalues in CostDirection(). For EEG the
                    old implementation sometimes yielded Neigen>>Nlcomp!
  JdM    29-01-00   Compute number of cost evaluations for each call to ComputeDipoles()
                    Clean up of code: use virtual ComputeCost to compute second order derivatives
  JdM    07-02-00   Added parameters to skip data point with sub-threshold MEG/EEG data power
  JdM    09-02-00   Remove parameter int* TotNcost from ComputeDipoles(). Export Ncost to .log-file instead.
                    Change default parameters for realistic models Emf-object.
  JdM    21-02-00   To speed up computations, implement pre-computed (Amat[])-Inverse,
                    for each grid point of the global search algorithm.
  JdM    27-03-00   remove HModel from data list. (obsolete).
  JdM    06-04-00   Count the total number of samples analyzed, and the total ncost (start from creation)
  JdM    07-04-00   Count the total number of samples that passes the Power Threshold Test
  JdM    10-04-00   Export fit statistics in descructor.
  JdM    11-04-00   Implement the U_GLOBAL_OR_PREV starting parameters option.
                    GetProperties(): export threshold parameters, put fit statistics in log file, on call of the descructor
  JdM    24-05-00   Remove (obsolete) ComputeCost() to compute Hessian matrix
  JdM    05-06-00   Added UPenalty-object to increase the cost when the dipole moves out of range
  JdM    08-06-00   Constructor: argument testing.
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    22-08-00   Added new start-type: U_GLOBAL_INTERPOL
  JdM    05-09-00   Use R_RANDIP (==8.0) i.s.o. 7. to initialize the theoretical covariance model
  JdM    18-11-00   Added a function that compute the condfidence intervals of the moving dipoles: ComputeConfIntPos()
  JdM    20-11-00   CostDirection() and CompMatInv(). Use UJacobi-object to solve system of equations and to compute pseudo inverse.
  JdM    21-11-00   Create UPenalty object only when required.
  JdM    24-11-00   Added SetNoiseLevel()
  JdM    03-12-00   Tested and bug-fixed ComputeConfIntPos()
                    Added truncation mechanism on the *CovXX, to make GLS more robust
  JdM    12-12-00   Added SetCovariance()
  JdM    17-12-00   Pass PenaltyFactor through Uminimize()-base class object
  JdM    05-01-01   Bug Fix: Account for artificial noise level when comparing actual data power to histogram threshold
  JdM    01-02-01   Allow the trucation parameter of the system matrix of the linear dipole components to be set by the user.
                    For current dipoles, always set the number of eigen values of that matrix to 2.
  JdM    13-02-01   Linear parameters and EEG: adapt truncation algorithm.
                    Keep track of error flag, indicating that something went wrong during computation of cost
  JdM    22-02-01   Confidence intervals can now be computed without a priori knowledge about the noise level.
  JdM    19-03-01   Always compute confidence intervals assuming unscaled covariance matrix.
  JdM    20-04-01   Bug Fix: Memory leackage in ComputeConfIntPos() (cm1<0)
  JdM    31-05-01   Added UFitDipoles::FitMovingDipoles()
  JdM    10-07-01   Remove UGrid-parameters, and use the ones from UStartDipole. Adapt constructor.
  JdM    14-07-01   Allow dipole fitting based on simultaneous MEG and EEG
  JdM    22-08-01   Allow for adaptation of MEG forward model on data gradient order
  JdM    08-11-01   Bug Fix: ComputeDipoles() Possible update of Direction[] in ComputeCost() should occur before copying dipoles to array
                    This bug causes (sometimes) small inconsistencies in the quasi-radial direction
                    FitMovingDipoles(): Add parameter to export dipole parameters in many digits
  JdM    22-03-02   Bug fix: only apply balancing when MEG is selected.
  JdM    19-05-02   FitMovingDipoles(). Changed ERROR on electrdode positions into WARNING
  JdM    10-12-02   Export (filtered) ADC data when requested
  JdM    22-08-03   ULocMovDip::ULocMovDip(), FitMovingDipoles(). Add parameter to set the use of old units (See EMfield.cpp)
  JdM    15-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    09-11-04   ULocMovDip::ULocMovDip(). Define UCovariance outside constructor
                    Remove CostType, use CovXX->GetCovarType() and CostFuncABS instead
  JdM    28-03-05   Update according to changes in UEMField object, dd 28-03-05
  JdM    05-01-07   Eliminate reference to obsolete UDataEpochs, and use UMEEGDataEpochs
  JdM    07-03-08   BUG Fix: FitMovingDipoles(). converting UString to const char*
  Jdm    17-08-08   Bug Fix: ULocMoveDip::ULocMoveDip(). SetBalancing(): Use UMEEGDataBase::MAXMEG
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    23-06-09   GetProperties(): use UString()
  JdM    01-12-12   UPenalty(). Split in spherical and realistic models
  JdM    12-06-14   Removed (obsolete) SetNoiseLevel() and ArtNoiseLevel, made DataMEG and DataEEG const
  JdM    21-12-14   ComputeConfIntPos(), CostDirection() and CompMatInv(). Use UMatrixSymmetric instead of UJacobi
  JdM    13-01-15   Bug fixed 21-12-14 (CostDirection(). Initializing UMatrixSymmetric)
  JdM    26-01-15   Complete revision. Replaced many occurences of double arrays by UMatrix objects. 
                    removed obsolete CompMatInv()
  JdM    13-06-15   Bug Fix. Restored virtual CompMatInv() because it is NOT obsolete!
  JdM    04-10-16   ComputeDipoles(). Only set artificial cost error to 100% if error occured in final step.
  */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LocMovDip.h"
#include "FitDipoles.h"
#include "MatrixSymmetric.h"
#include "Epochs.h"
#include "MarkerArray.h"
#include "Distribution.h"

/* Inititalize static const parameters. */
UString       ULocMovDip::Properties           =  UString();
double const  ULocMovDip::COSTERROR            =  10000;
double const  ULocMovDip::AMAT_THRESHOLD       = .001;
double const  ULocMovDip::OLS_REL_EEG_VARIANCE = .01;
double const  ULocMovDip::COV_THRESHOLD        =  1.e-8;//1.e-6;

#define RAD_to_CM 5.73
#define R_RANDIP  8.00

void ULocMovDip::SetAllMembersDefault(void)
{
    error          = U_OK;
    AmatThreshold  = AMAT_THRESHOLD;
    UseOldUnits    = false;

    MaxStartError  = -1.;
    CompConfInt    = false;
    CostFuncABS    = false;
    CostError      = U_COST_OK;
    DataNorm       = 0;
    DataAbs        = 0;
    Nlcomp         = 3;
    Penalty        = NULL;

    NtotSamp       = 0;
    NtotDatPow     = 0;
    NtotNLsearch   = 0;
    NtotCost       = 0;

    Direction[0]   = Direction[1] = Direction[2] = 0;
    Direction[3]   = Direction[4] = Direction[5] = 0;
    Position[0]    = Position[1]  = Position[2]  = 0;
    Position[3]    = Position[4]  = 0;

    CinvDataMap    = NULL;

    nMEG           = 0;
    nEEG           = 0;

    MCMEG          = NULL;
    MCEEG          = NULL;
    CovXX          = NULL;
}

void ULocMovDip::DeleteAllMembers(ErrorType E)
{
    delete   CovXX;
    delete   Penalty;

    SetAllMembersDefault();
    error = E;
}

ULocMovDip::ULocMovDip(const UCostminimize& cost, bool UseOU, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* gridM, const UGrid* gridE, const UHeadModel *Hmod, bool CTAbs, const UCovariance* SpatCov) :
    Uminimize(cost), UStartDipole(gridM, gridE, Hmod)
{
    SetAllMembersDefault();
    UseOldUnits    = UseOU;
    CostFuncABS    = CTAbs;

    if(UStartDipole::GetError()!=U_OK)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocMovDip::ULocMovDip(). Base class error: UStartDipole(). \n");
        return;
    }
    if(gridM) nMEG = gridM->GetNpoints();
    if(gridE) nEEG = gridE->GetNpoints();

    error = Emf.GetError();
    if(error==U_OK && Hmod==NULL) error = U_ERROR;

    if(error==U_OK)
    {
        Emf.SetUseOldUnits(UseOU);
        error    = Emf.SetGrid(gridM, gridE);

        if(error==U_OK && ReRefForw!=U_REF_RAW && gridM)
            error = Emf.SetBalancing(GridR, pBal, UMEEGDataBase::MAXMEG, ReRefForw);

        if(error==U_OK)
        {
            if(SpatCov==NULL || SpatCov->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: ULocMovDip::ULocMovDip(). Invalid or NULL UCovariance argument.\n");
                error = U_ERROR;
            }
            else if(nKan!=SpatCov->GetNdim())
            {
                CI.AddToLog("ERROR: ULocMovDip::ULocMovDip(). Number of channels (nKan=%d) not equal to dimension of UCovariance (nDim=%d).\n", nKan, SpatCov->GetNdim());
                error = U_ERROR;
            }
            if(SpatCov)
                if(SpatCov->GetCovarType()!=U_COV_CONSTANTVARIANCE &&
                   SpatCov->GetCovarType()!=U_COV_VARIANCE         &&
                   SpatCov->GetCovarType()!=U_COV_RANDIP           &&
                   SpatCov->GetCovarType()!=U_COV_FILE_XX          &&
                   SpatCov->GetCovarType()!=U_COV_DATA_XX          &&
                   SpatCov->GetCovarType()!=U_COV_GEN_XX         )
                {
                    UString Prop = SpatCov->GetProperties("       ");
                    CI.AddToLog("WARNING: ULocMovDip::ULocMovDip(). Covariance not of spatial origin??\n: %s", (const char*)Prop);
                }
            if(error==U_OK)
            {
                CovXX = new UCovariance(*SpatCov);
                if(CovXX==NULL || CovXX->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: ULocMovDip::ULocMovDip(). Copying UCovariance object.\n");
                    error = U_ERROR;
                }
            }
        }
        if(error==U_OK)  error = CovXX->SetNPosEig(ULocMovDip::COV_THRESHOLD);
    }
    if(error!=U_OK)
    {
        UStartDipole::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocMovDip::ULocMovDip(): Memory allocation error. \n");
    }
}

ULocMovDip::~ULocMovDip()
{
    CI.AddToLog("Note: ULocMovDip::~ULocMovDip(). Fit Statistics:\n");
    CI.AddToLog("Nsamples_analyzed  = %d // = 100.00%%\n",NtotSamp);
    if(NtotSamp)
    {
        CI.AddToLog("N_power_threshold  = %d // = %6.2f%%\n",NtotDatPow,  100.*NtotDatPow/(double)NtotSamp);
        CI.AddToLog("N_non-lin_search   = %d // = %6.2f%%\n",NtotNLsearch,100.*NtotNLsearch/(double)NtotSamp);
    }
    CI.AddToLog("N_cost_evaluations = %d\n",NtotCost);

    if(GetSType()==U_GLOBAL_OR_PREV)
    {
        CI.AddToLog("Ncost_tested= %d\n",TC.GetNtest());
        CI.AddToLog("Nprevious   = %d\n",TC.GetNprevious());
    }
    DeleteAllMembers(U_OK);
}

const UString& ULocMovDip::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in ULocMovDip-object\n");
        return Properties;
    }
    Properties  = UString();

    if(CostFuncABS==true)
    {
        Properties += UString(" CostFunction = SUM_OF_ABS_DIFF \n");
    }
    else
    {
        UString Prop = CovXX->GetProperties("");
        switch(CovXX->GetCovarType())
        {
        case U_COV_CONSTANTVARIANCE :
            Properties += UString(" CostFunction = SUM_OF_SQUARE_DIFF \n");
            if(Ftype==UEMfield::U_MEGEEG)
                Properties += UString(OLS_REL_EEG_VARIANCE, "RelEEGVar    = %f \n");
            break;

        case U_COV_VARIANCE         :
            Properties += UString(" CostFunction = WEIGHTED_OLS \n");
            Properties += UString(" CovXX        = {") + Prop + "} \n";
            break;
        default:
            Properties += UString(" CostFunction = GLS \n");
            Properties += UString(" CovXX        = {") + Prop + "} \n";
            break;
        }
    }
    if(Penalty==NULL)  Properties += " PenaltyFactor = 0.\n";
    else               Properties += UString(Uminimize::PenaltyFactor," PenaltyFactor = %f.\n");

    Properties += "\nThreshold parameters:\n";

    if(MinDataPowMEG>0 && nMEG)
        Properties += UString(MinDataPowMEG/nMEG,"    Sample point skipped when average MEG data power is less than %12.8g [fT2]. \n");
    if(MinDataPowEEG>0 && nEEG)
        Properties += UString(MinDataPowEEG/nMEG,"    Sample point skipped when average EEG data power is less than %12.8g [uV2]. \n");

    if(MaxStartError<0)
        Properties += UString("    Non-linear iterations performed on all time samples. \n");
    else
        Properties += UString(MaxStartError,"    Non-linear iterations skipped when initial error is below %8.2f %%. \n");

    if(DipType==UDipole::Symmetric || DipType==UDipole::SymmetricPos)
    {
        Properties += UString(fabs(AmatThreshold),"    Linear component parameter truncation parameter threshold = %f  . \n");
        if(AmatThreshold<0)
            Properties += UString("    Skip (semi-) symmetric dipoles near mid-saggital plane. \n");
    }
    if(CompConfInt==true)
        Properties += UString("    Confidence intervals computed by estimating noise level from data itself.\n");

    Properties += UString(" StartDipole: \n") + UStartDipole::GetProperties(Comment + "    ") + " \n";
    Properties += UString(GetDipoleTypeText(DipType), "DipoleType  = %s \n");
    if(UseOldUnits==true)       Properties += " DipoleStrength = OldUnit \n";
    else                        Properties += " DipoleStrength = nAm*cm \n";

    if(GridMEG&&GridEEG)        Properties += " DataSource     = MEG/EEG\n";
    else if(GridMEG)            Properties += " DataSource     = MEG\n";
    else if(GridEEG)            Properties += " DataSource     = EEG\n";
    else                        Properties += " DataSource     = Unknown\n";

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}


ErrorType ULocMovDip::SetDataMeg(const UMultiChan* MCmeg, double MinPower)
{
    MCMEG         = MCmeg;
    MinDataPowMEG = MinPower;

    return U_OK;
}
ErrorType ULocMovDip::SetDataEeg(const UMultiChan* MCeeg, double MinPower)
{
    MCEEG         = MCeeg;
    MinDataPowEEG = MinPower;

    return U_OK;
}

ErrorType ULocMovDip::SetCovariance(UCovariance* CovNewXX)
{
    if(CovNewXX==NULL)
    {
        CI.AddToLog("ERROR: ULocMovDip::SetCovariance(). NULL Argument. \n");
        return U_ERROR;
    }
    if(CovXX->GetNdim() != CovNewXX->GetNdim())
    {
        CI.AddToLog("ERROR: ULocMovDip::SetCovariance(). Number of dimensions incompatible (%d) != (%d). \n",CovXX->GetNdim(), CovNewXX->GetNdim());
        return U_ERROR;
    }

    delete CovXX;  CovXX = CovNewXX;
    ErrorType E = CovXX->SetNPosEig(ULocMovDip::COV_THRESHOLD);
    if(E==U_OK) CI.AddToLog("Note: ULocMovDip::ULocMovDip()\n%s",CovXX->GetProperties("     "));
    return E;
}
ErrorType ULocMovDip::ComputeDipoles(UDipole* DipArray, double* ConfIntPos, double *residual, double* DataN, double MxStrtErr)
/*
    Compute the optimal dipole on each of the samples present in the array
    DataMeg[]. The Dipoles present in the array of dipoles DipArray act as
    starting values. On return, these starting values are replaced by the optimal dipoles.

    If(residual) also compute and store the residuals of the optimal dipoles
    in the array residual[].
    If(DataN) also return an array with the Powers of the data on each time sample
    in the array DataN[]. These values can be used to compute the absolute errors in fT2 or uV2.

    If the initial residual error (determined by the starting values) is larger than
    MaxStartError, do not iterate, but continue with the next sample.
    If(MaxStartError<0), skip that test and iterate on all samples.

    if(Penalty>0) the cost function will artifically increased when the dipole moves
                  out of range (as determined by Penalty).

    Update NtotSamp, NtotDatPow, NtotNLsearch and NtotCost

    Note: It is assumed that all dipoles are of the same type.
 */
{
    if( ( GridMEG && !MCMEG) ||
        ( GridEEG && !MCEEG) )
    {
        CI.AddToLog("ERROR: ULocMovDip::ComputeDipoles(). Data not properly set. \n");
        return U_ERROR;
    }
    if(!MCMEG && ! MCEEG)
    {
        CI.AddToLog("ERROR: ULocMovDip::ComputeDipoles(). Neither MEG nor EEG data set. \n");
        return U_ERROR;
    }
    if(MCMEG && MCEEG && MCMEG->GetNcol()!=MCEEG->GetNcol())
    {
        CI.AddToLog("ERROR: ULocMovDip::ComputeDipoles(). MEG && EEG data have different number of samples. \n");
        return U_ERROR;
    }
    if(CovXX==NULL || CovXX->GetError()!=U_OK || CovXX->GetNdim()!=nKan)
    {
        CI.AddToLog("ERROR: ULocMovDip::ComputeDipoles(). Spatial covariance matrix not (properly) set. \n");
        return U_ERROR;
    }

    int Nsamples = 0;
    if(MCMEG) Nsamples = MCMEG->GetNcol();
    if(MCEEG) Nsamples = MCEEG->GetNcol();

    if(Uminimize::Penalty==true)
    {
        if(Penalty==NULL)
        {
            Penalty = new UPenalty(&Emf);

            if(Penalty==NULL || Penalty->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: ULocMovDip::ComputeDipoles(). Creating UPenalty object. \n");
                return U_ERROR;
            }
            Penalty->ExportPenaltyField();
        }
    }
    else
    {
        Uminimize::PenaltyFactor = 0.;
    }

    if(ConfIntPos) CompConfInt = true;
    else           CompConfInt = false;
    error         = U_OK;
    MaxStartError = MxStrtErr;

    NtotSamp     += Nsamples;
    for(int sample=0; sample<Nsamples; sample++)
    {
        CostError = U_COST_OK;

/* Get Data */
        DataMap = UMatrix();
        if(MCMEG) DataMap = DataMap.GetConcatCollumns(MCMEG->GetCollumn(sample));
        if(MCEEG) DataMap = DataMap.GetConcatCollumns(MCEEG->GetCollumn(sample));

/* Incorporate covariance into data norm and measurement vector DataMap[] */
        DataAbs     = DataMap.GetAbsNorm();
        DataNorm    = CovXX->GetVTMV(DataMap, true);
        CinvDataMap = CovXX->GetAxIsB(DataMap);

        if(DataN)      DataN     [  sample] = DataNorm;
        if(ConfIntPos) ConfIntPos[3*sample] = ConfIntPos[3*sample+1] = ConfIntPos[3*sample+2] = 0;

/* Do the data power threshold test */
        if((MinDataPowMEG>0 && DataNorm<MinDataPowMEG) ||
           (MinDataPowEEG>0 && DataNorm<MinDataPowEEG))
        {
            DipArray[sample].Setx( UVector3(0.,0.,1.));
            DipArray[sample].Setd( UVector3(0.,0.,0.));
            DipArray[sample].SetdSym( UVector3(0.,0.,0.));
            if(residual) residual[sample] = 100.;

            continue;
        }
        NtotDatPow++;

/* Copy start parameters*/
        if(sample>0 && (GetSType()==U_PREVIOUS||GetSType()==U_BESTOFALL)) DipArray[sample] = DipArray[sample-1];
        UStartDipole::GetStartDipole(DipArray+sample, DataMap.GetMatrixArray());

        Position [0] = DipArray[sample].Getx().Getx();
        Position [1] = DipArray[sample].Getx().Gety();
        Position [2] = DipArray[sample].Getx().Getz();
        Position [3] = DipArray[sample].GetTanAngle(Emf.GetSpherePos())*RAD_to_CM; // Only use with CostFunc=U_ABS

        Direction[0] = DipArray[sample].Getd().Getx();
        Direction[1] = DipArray[sample].Getd().Gety();
        Direction[2] = DipArray[sample].Getd().Getz();
        Direction[3] = DipArray[sample].GetdSym().Getx();
        Direction[4] = DipArray[sample].GetdSym().Gety();
        Direction[5] = DipArray[sample].GetdSym().Getz();

/* Start fitting*/
        if(fabs(DataNorm) >1.e-10)
        {
            double StartCost = ComputeCost(Position);
            if(MaxStartError<0 || StartCost<MaxStartError)
            {
                if((GetSType()==U_GLOBAL_OR_PREV || GetSType()==U_BESTOFALL) && sample>0)
                    TC.TestPrevious(this,DipArray[sample-1].Getx(), StartCost, Position);

                if(CostFuncABS==true)  Iterate(Position, 4);
                else                   Iterate(Position, 3);

                NtotNLsearch++;
            }

            if(residual) // 8/11/1: Possible update of Direction[] in ComputeCost() should occur before copying dipoles to array
            {
                UPenalty* Temp     = Penalty;
                Penalty            = NULL;
                CostFlag TempError = CostError; 
                CostError          = U_COST_OK;
                residual[sample]   = ComputeCost(Position);
                if(CostError!=U_COST_OK) residual[sample] = 100.;
                CostError          = TempError;
                Penalty            = Temp;
            }

            DipArray[sample].Setx( UVector3(Position) );
            DipArray[sample].Setd( UVector3(Direction) );
            if(DipType==UDipole::SymmetricPos)
                DipArray[sample].SetdSym( UVector3(Direction+3) );
            else
                DipArray[sample].SetdSym( UVector3(Direction).GetMirrorY() );

            DipArray[sample].SetSymRight(Emf.GetSpherePos());

            if(ConfIntPos)
                ComputeConfIntPos(DipArray[sample], ConfIntPos+3*sample);

            if((MaxStartError<0 || StartCost<MaxStartError) && residual)
            {
                printf("%3.3d (x,y,z) = %8.3f %8.3f %8.3f E=%f %5.5d\n",sample,Position[0] ,Position[1] ,Position[2], residual[sample], GetNoIterations());
            }
            static int NMESS = 0;
            switch(CostError)
            {
            case U_COST_ERROR_EMFIELD:
                if(NMESS<20) CI.AddToLog("WARNING: ULocMovDip::ComputeDipoles(). At least EM field computation error occured at sample %d.\n",sample);
                break;
            case U_COST_ERROR_DIRECTION:
                if(NMESS<20) CI.AddToLog("WARNING: ULocMovDip::ComputeDipoles(). At least one error in Dipole Moment computation at sample %d.\n",sample);
                break;
            }
            NMESS++;
        }
        else
        {
            DipArray[sample].Setx( UVector3(0.,0.,1.));
            DipArray[sample].Setd( UVector3(0.,0.,0.));
            DipArray[sample].SetdSym( UVector3(0.,0.,0.));
            if(residual) residual[sample] = 100.;
            CI.AddToLog("WARNING : ULocMovDip::ComputeDipoles(). %3.3d : No Data! \n",sample);
        }
    }
    return error;
}

ErrorType ULocMovDip::ComputeConfIntPos(const UDipole& Dip, double* DeltaPos)
/*
    Compute the 95% confidence intervals of the position parameters of dipole Dip.

    Note: In this function it is assumed that the correct variance level is given in
          the spatial covariance object. If this it not the case, the confidence intervals
          are reliable only apart from a certian unknown scaling factor.
 */
{
    if(DeltaPos==NULL)
    {
        CI.AddToLog("ERROR: ULocMovDip::ComputeConfIntPos(). NULL argument.\n");
        return U_ERROR;
    }

    static int FirstErrorMessage = 0;
    if(GridEEG && Emf.GetCondModelType()==U_CONDMOD_HOMSPHERE)
    {
        if(FirstErrorMessage==0)
            CI.AddToLog("WARNING: ULocMovDip::ComputeConfIntPos(). Function does not work for EEG in combination with the homogeneous sphere model.\n");
        FirstErrorMessage = 1;
        return U_ERROR;
    }
    if(CostFuncABS==true)
    {
        if(FirstErrorMessage==0)
            CI.AddToLog("WARNING: ULocMovDip::ComputeConfIntPos(). Function does not work for the abs difference cost function.\n");
        FirstErrorMessage = 1;
        return U_ERROR;
    }


    UMatrix grad, gradH;
    double Hess[81];
    int Ncm = 3+Nlcomp;

/* Compute finite differences of gradients*/
    double Sigma2   = 1;
    const double Hx = .001;
    const double Hd = .001*Dip.Getd().GetNorm();
    for(int cm1=-1; cm1<Ncm; cm1++)
    {
        UDipole DipH(Dip);
        switch(cm1)
        {
        case 0: DipH.Setx(Dip.Getx() + UVector3(Hx,0.,0.)); break;
        case 1: DipH.Setx(Dip.Getx() + UVector3(0.,Hx,0.)); break;
        case 2: DipH.Setx(Dip.Getx() + UVector3(0.,0.,Hx)); break;
        case 3: DipH.Setd(Dip.Getd() + UVector3(Hd,0.,0.)); break;
        case 4: DipH.Setd(Dip.Getd() + UVector3(0.,Hd,0.)); break;
        case 5: DipH.Setd(Dip.Getd() + UVector3(0.,0.,Hd)); break;
        case 6: DipH.SetdSym(Dip.GetdSym() + UVector3(Hd,0.,0.)); break;
        case 7: DipH.SetdSym(Dip.GetdSym() + UVector3(0.,Hd,0.)); break;
        case 8: DipH.SetdSym(Dip.GetdSym() + UVector3(0.,0.,Hd)); break;
        }
        UMatrix fldposH = Emf.GetEMfieldAsMatrix(&DipH, D_OriPos01, Ftype);
        UMatrix fldoriH = Emf.GetEMfieldAsMatrix(&DipH, D_OriPos10, Ftype);

        if(fldposH.GetError()!=U_OK || fldoriH.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR:  ULocMovDip::ComputeConfIntPos(). Failed to compute the magnetic/electric fields.\n");
            return U_ERROR;
        }

        UMatrix Dir;
        if(DipType==UDipole::SymmetricPos) Dir = UMatrix(DipH.Getd(), DipH.GetdSym());
        else                               Dir = UMatrix(DipH.Getd());

        UMatrix diff = fldoriH*Dir - DataMap;
        if(cm1<0)
        {
            Sigma2           = CovXX->GetVTMV(diff, true)/nKan;

            UMatrix gradpos  = CovXX->GetA1TMA2(fldposH, diff, true);
            UMatrix gradori  = CovXX->GetA1TMA2(fldoriH, diff, true);

            grad             = gradpos.GetConcatCollumns(gradori);
        }
        else
        {
            UMatrix gradHpos  = CovXX->GetA1TMA2(fldposH, diff, true);
            UMatrix gradHori  = CovXX->GetA1TMA2(fldoriH, diff, true);

            gradH = gradHpos.GetConcatCollumns(gradHori);

            if(cm1<3)
            {
                for(int cm2=0; cm2<Ncm; cm2++)
                    Hess[cm1*Ncm+cm2] = (gradH.GetMatrixArray()[cm2]-grad.GetMatrixArray()[cm2])/Hx;
            }
            else
            {
                for(int cm2=0; cm2<Ncm; cm2++)
                    Hess[cm1*Ncm+cm2] = (gradH.GetMatrixArray()[cm2]-grad.GetMatrixArray()[cm2])/Hd;
            }
        }
    }

/* Compute scaling factor to increase numerical stability*/
    double Scale = 0;
    for(int cm=3; cm<Ncm; cm++) Scale += Hess[cm*Ncm+cm];
    if(Scale>0) Scale = (Ncm-3)*(Hess[0]+Hess[Ncm+1]+Hess[2*Ncm+2])/(3*Scale);
    if(Scale>0) Scale = sqrt(Scale);

/* Make Hessian symmetric and scale the component part*/
    for(int cm1=0; cm1<Ncm; cm1++)
    {
        for(int cm2=0; cm2<Ncm; cm2++)
        {
            if(cm2>=cm1)
            {
                Hess[cm1*Ncm+cm2] = (Hess[cm2*Ncm+cm1]+Hess[cm1*Ncm+cm2])/2.;
                if(cm1>=3) Hess[cm1*Ncm+cm2]*=Scale;
                if(cm2>=3) Hess[cm1*Ncm+cm2]*=Scale;
            }
            else
                Hess[cm1*Ncm+cm2] =  Hess[cm2*Ncm+cm1];
        }
    }

/* Compute the first three diagonal elements of the inverse of the Hessian matrix*/
    UMatrixSymmetric J(Hess, Ncm, Ncm, false);

    for(int cm=0; cm<3; cm++)
        DeltaPos[cm] = 2*sqrt(Sigma2*J.GetEigen(cm)); // Factor 2 is for 95% confidence level

    return U_OK;
}

double ULocMovDip::ComputeCost(double *par, int iter, int *status, double *grad)
/*
    Compute cost function for the given position parameters par[].
    In case of U_ABS, the directions are compute non-linearly
    Else            , the directions of the dipoles are determined by a linear estimate.
    In both cases, the dipole components are stored in the array Directions[].

    if(grad)   compute the MINUS-gradient of the cost
 */
{
    if(GridEEG && grad && Emf.GetCondModelType()==U_CONDMOD_HOMSPHERE)
        return Uminimize::ComputeCost(par, iter, status, grad);

    if(status)
    {
        NtotCost++;     // Only count the number of costs, required by the Non-Linear optimization methods
        *status = 0;
    }
    double   cost = COSTERROR;
    UDipole Dip(par[0], par[1], par[2], Direction[0], Direction[1], Direction[2], DipType);
    if(DipType==UDipole::SymmetricPos) Dip.SetdSym(UVector3(Direction[3], Direction[4], Direction[5]));

    UMatrix fld  = Emf.GetEMfieldAsMatrix(&Dip, D_OriPos10, Ftype);
    if(fld.GetError()!=U_OK)
    {
        CostError=U_COST_ERROR_EMFIELD;
        return cost;
    }

    if(CostFuncABS==true)
    {
        Dip.Setd(Emf.GetSpherePos(), par[3]/RAD_to_CM, 1.);
        for(int i=0; i<nKan;i++)
        {
            double term  = Dip.Getd()&UVector3(fld.GetMatrixArray()+3*i);
            if(fabs(term)<1.e-20) continue;

            double S     =  DataMap.GetElement(i,0)/term;

            double Ctest = 0;
            for(int ii=0;ii<nKan;ii++)
                Ctest += fabs(DataMap.GetElement(ii,0)-S*(Dip.Getd()&UVector3(fld.GetMatrixArray()+3*ii)));

            Ctest /= DataAbs;
            if(Ctest<cost)
            {
                cost         = Ctest;
                Direction[0] = S*Dip.Getd().Getx();
                Direction[1] = S*Dip.Getd().Gety();
                Direction[2] = S*Dip.Getd().Getz();
            }
        }
        if(Penalty && Uminimize::PenaltyFactor>0.)
            cost += Uminimize::PenaltyFactor * Penalty->GetPenalty(Dip.Getx(), status, grad);

        return 100.*cost;
    }
/* Compute Dipole direction */
    UMatrix          Bvec = GetMatMul(fld, true, CinvDataMap, false);
    UMatrixSymmetric Amat = CovXX->GetATMA(fld, true);

/* by Solving the orientations from a linear system of symmetrical equations.*/
    if(CostDirection(Amat, Bvec, &cost)!=U_OK)
    {
        CostError=U_COST_ERROR_DIRECTION;
        return COSTERROR;
    }

/* Compute gradient, if required. */
    if(grad/*** ||gauss***/)
    {
        UDipole Dip(par[0], par[1], par[2], Direction[0], Direction[1], Direction[2], DipType);
        if(DipType==UDipole::SymmetricPos) Dip.SetdSym(UVector3(Direction[3], Direction[4], Direction[5]));

        UMatrix Dir;
        if(DipType==UDipole::SymmetricPos) Dir = UMatrix(Dip.Getd(), Dip.GetdSym());
        else                               Dir = UMatrix(Dip.Getd());

        UMatrix fldder = Emf.GetEMfieldAsMatrix(&Dip, D_OriPos01, Ftype);

        for(int cm1=0;cm1<3;cm1++)  grad[cm1]  = 0;

        UMatrix diff  = fld * Dir - DataMap; 
        UMatrix grvec = CovXX->GetA1TMA2(fldder, diff, true);
        grad[0] = grvec.GetElement(0,0) * (-200./DataNorm);
        grad[1] = grvec.GetElement(1,0) * (-200./DataNorm);
        grad[2] = grvec.GetElement(2,0) * (-200./DataNorm);

/****
        if(gauss)
        {
            CovXX->ComputeMatTCovinvMat(gauss, fldder, 3);
            for(int cm=0;cm<9;cm++)  gauss[cm]  *= 100./DataNorm;
        }
 *****/
    }

    if(Penalty && Uminimize::PenaltyFactor>0.)
        cost += Uminimize::PenaltyFactor*Penalty->GetPenalty(Dip.Getx(), status, grad);

    return cost;
}

// General Test Code
////       double NumGrad[3];
////       double NumGauss[9];
////       Uminimize::ComputeCost(par, iter, status, NumGrad,NumGauss);
////       printf("%f == %f  DIFF %f\n",gauss[0],NumGauss[0],gauss[0]-NumGauss[0]);
////       printf("%f == %f  DIFF %f\n",gauss[1],NumGauss[1],gauss[1]-NumGauss[1]);
////       printf("%f == %f  DIFF %f\n",gauss[2],NumGauss[2],gauss[2]-NumGauss[2]);
////       printf("%f == %f  DIFF %f\n",gauss[3],NumGauss[3],gauss[3]-NumGauss[3]);
////       printf("%f == %f  DIFF %f\n",gauss[4],NumGauss[4],gauss[4]-NumGauss[4]);
////       printf("%f == %f  DIFF %f\n",gauss[5],NumGauss[5],gauss[5]-NumGauss[5]);
////       printf("%f == %f  DIFF %f\n",gauss[6],NumGauss[6],gauss[6]-NumGauss[6]);
////       printf("%f == %f  DIFF %f\n",gauss[7],NumGauss[7],gauss[7]-NumGauss[7]);
////       printf("%f == %f  DIFF %f\n",gauss[8],NumGauss[8],gauss[8]-NumGauss[8]);
////
////       while(!getchar());
////
////// General Test Code
////        double NumGrad[3];
////        Uminimize::ComputeCost(par, iter, status, NumGrad);
////        printf("%f == %f  DIFF %f\n",grad[0],NumGrad[0],grad[0]-NumGrad[0]);
////        printf("%f == %f  DIFF %f\n",grad[1],NumGrad[1],grad[1]-NumGrad[1]);
////        printf("%f == %f  DIFF %f\n",grad[2],NumGrad[2],grad[2]-NumGrad[2]);
////
////        while(!getchar());
////

double ULocMovDip::ComputeCost(const UVector3 &Point, float *fld, int idum, double* AmatInv)
/*
    Compute cost function for the given position parameters Point using the pre-calculated
    fields that are present in FieldTable[].

 */
{
    double   cost = COSTERROR;

/* by Solving the orientations from a linear system of symmetrical equations.*/
    if(AmatInv==NULL)
    {
        UMatrix          fldMat = UMatrix(fld, nKan, Nlcomp); 
        UMatrix          Bvec   = CinvDataMap * fldMat;
        UMatrixSymmetric Amat   = CovXX->GetATMA(fldMat, true);
        if(CostDirection(Amat, Bvec, &cost)!=U_OK) return COSTERROR;
    }
    else
    {
        double Bvec[6];

/* Cost square with or without covariance:*/
        for(int k=0; k<Nlcomp; k++)
        {
            Bvec[k] = 0.;
            for(int i=0; i<nKan; i++) Bvec[k] += CinvDataMap.GetElement(i)*fld[i*Nlcomp+k];
        }

        for(int cm1=0;cm1<Nlcomp;cm1++)        /* Compute Direction = U * RD*/
        {
            Direction[cm1] = 0.;
            for(int cm2=0;cm2<Nlcomp;cm2++) Direction[cm1] += AmatInv[cm1*Nlcomp+cm2] * Bvec[cm2];
        }

        cost = DataNorm;
        for(int kk=0;kk<Nlcomp;kk++) cost -= Bvec[kk]*Direction[kk];
        cost *= 100./DataNorm;
        if(cost<0) return COSTERROR;
    }
    return cost;
}

ErrorType  ULocMovDip::CostDirection(UMatrixSymmetric& Amat, const UMatrix& Bvec, double* Cost) 
/*
     Compute the dipole direction parameters, represented by Direction[], in such a way
     that (quasi-) radial and opposite symmetric source components are suppressed.
     This is achieved using a eigenvalue decomposition of the matrix Amat[].

     Compute the optimal cost, based on the estimated Direction[] parameters.
 */
{
    *Cost = 1000;

    int NPosEigen = 0;
    switch(DipType)
    {
    case UDipole::Current:
        if(GridEEG)   NPosEigen = 3;
        else          NPosEigen = 2;
        break;

    case UDipole::Magnetic:
        NPosEigen = 3;
        break;

    case UDipole::Symmetric:
        NPosEigen = Amat.GetNPosEig(fabs(AmatThreshold));
        if(GridEEG)
        {
            if(NPosEigen<=2 && AmatThreshold<0) return U_ERROR; // Skip dipoles near midline
        }
        else
        {
            if(NPosEigen<=1 && AmatThreshold<0) return U_ERROR; // Skip dipoles near midline
            if(NPosEigen >2) NPosEigen = 2;
        }
        break;

    case UDipole::SymmetricPos:
        NPosEigen =Amat.GetNPosEig(fabs(AmatThreshold));
        if(GridEEG)
        {
            if(NPosEigen<=3 && AmatThreshold<0) return U_ERROR; // Skip dipoles near midline
        }
        else
        {
            if(NPosEigen<=2 && AmatThreshold<0) return U_ERROR; // Skip dipoles near midline
            if(NPosEigen>4) NPosEigen = 4;
        }
        break;
    }
    UMatrix D = Amat.GetAxIsB(Bvec, NPosEigen, 0);
    if(D.GetMatrixArray()==NULL) return U_ERROR;

    for(int k=0; k<Nlcomp; k++) Direction[k] = D.GetElement(k);

    *Cost = DataNorm - GetTraceM1M2T(Bvec, D);
    if(DataNorm>0.) 
        *Cost *= 100./DataNorm;

    if(*Cost<0) return U_ERROR;

    return U_OK;
}
ErrorType ULocMovDip::CompMatInv(double* AmatInv, const double* LeadField) const
/*
    Compute the pseudo-inverse of the system matrix for the dipole moments.
 */
{
    if(CovXX==NULL) return U_ERROR;

    UMatrix          L    = UMatrix(LeadField, CovXX->GetNdim(), Nlcomp);
    UMatrixSymmetric Amat = CovXX->GetATMA(L, true);

    int NPosEigen = 0;
    switch(DipType)
    {
    case UDipole::Current:
        if(GridEEG) NPosEigen = 3;
        else        NPosEigen = 2;
        break;

    case UDipole::Magnetic:
        NPosEigen = 3;
        break;

    case UDipole::Symmetric:
        NPosEigen = Amat.GetNPosEig(fabs(AmatThreshold));
        if(!GridEEG) NPosEigen = MIN(NPosEigen, 2);
        break;

    case UDipole::SymmetricPos:
        NPosEigen = Amat.GetNPosEig(fabs(AmatThreshold));
        if(!GridEEG) NPosEigen = MIN(NPosEigen, 4);
        break;
    }
    Amat.Invert(NPosEigen, 0);

    const double* pData = Amat.GetMatrixArray();
    if(Amat.GetError()!=U_OK || pData==NULL)
    {
        return U_ERROR;
    }

    for(int k=0; k<Nlcomp*Nlcomp; k++) AmatInv[k] = pData[k];
    return U_OK;
}

bool ULocMovDip::UTestCost::TestPrevious(ULocMovDip* ULMD, UVector3 Xprev, double StartCost, double* StartPos)
/*
   Test whether Xprev yields a lower cost than StartCost.
   If so, replace StartPos[] by Xprev and return true
   else return false
 */
{
    Ntest++;

    double PosPrev[3] = {Xprev.Getx(), Xprev.Gety(), Xprev.Getz()};

    int    status;
    double TestCost   = ULMD->ComputeCost(PosPrev, 0, &status, NULL);
    if(status==0 && TestCost<StartCost)
    {
        StartPos[0] = PosPrev[0];
        StartPos[1] = PosPrev[1];
        StartPos[2] = PosPrev[2];

        Nprevious++;
        return true;
    }
    return false;
}

#define MAXPOINTS 20000
#define SCALE       100.

void ULocMovDip::UPenalty::SetAllMembersDefault(void)
{
    error       = U_OK;
    Domain      = NULL; 

    SphereModel = true;
    SpherePos   = UVector3();
    SphereRad   = 10.;
    Mesh        = 1.;
    dimx        = 0 ;     // dimensions of the mesh
    dimy        = 0 ;
    dimz        = 0;
    dimxy       = 0;
}
void ULocMovDip::UPenalty::DeleteAllMembers(ErrorType E)
{
    delete Domain;
    SetAllMembersDefault();
    error = E;
}

ULocMovDip::UPenalty::UPenalty(UEMfield* Em)
{
    SetAllMembersDefault();
    if(Em==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocMovDip::UPenalty::UPenalty(). Error in arguments\n");
        return;
    }

    switch(Em->GetGrossModelType())
    {
    case U_GMODEL_UNKNOWN:
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocMovDip::UPenalty::UPenalty(). Gross Head Model unknown. \n");
        return;

    case U_GMODEL_SPHERE:
        {
            SphereModel = true;
            SpherePos   = Em->GetSpherePos();
            SphereRad   = Em->GetInnerRadius();
            if(SphereRad<=1)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: ULocMovDip::UPenalty::UPenalty(). Head radius out of range (SphereRad = %f). \n", SphereRad);
                SphereRad = 1;
                return;
            }
        }
        break;

    case U_GMODEL_REALISTIC:
        {
            SphereModel = false;
            const USurface* Brain = Em->GetSurface(Em->GetInnerSurf());
            if(Brain==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: ULocMovDip::UPenalty::UPenalty(). Realistic model invalid. \n");
                return;
            }

            CI.TimeReset("Prepare Penalty object \n");

            UVector3 Lowx, Higx;
            Brain->ComputeMinMax(&Lowx, &Higx);
            double Rad  = pow(fabs((Higx-Lowx).Getx()*(Higx-Lowx).Gety()*(Higx-Lowx).Getz()),1./3.);
            Mesh        = Rad*pow(.5/MAXPOINTS,1./3.);

            Domain      = new UField(Mesh, Lowx-UVector3(1.,1.,1.), Higx+UVector3(1.,1.,1.), UField::U_BYTE);
            if(Domain==NULL || Domain->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: ULocMovDip::UPenalty::UPenalty(). Creating mesh for BEM model. \n");
                return;
            }
            Domain->SetDataByte((unsigned char)1);
            Domain->IsInSurface(Brain);
            CI.TimeFlag("Prepare Penalty object \n");

            dimx  = Domain->GetDimensions(0);
            dimy  = Domain->GetDimensions(1);
            dimz  = Domain->GetDimensions(2);
            dimxy = dimx*dimy;

            Domain->ConvertData(UField::U_SHORT, SCALE);
            Domain->DistanceXFM();
        }
        break;
    }
}

ULocMovDip::UPenalty::~UPenalty()
{
    DeleteAllMembers(U_OK);
}

ErrorType ULocMovDip::UPenalty::ExportPenaltyField() const
{
    if(Domain == NULL || Domain->GetError()!=U_OK) return U_ERROR;

    UPatTree Pat("Penalty.Patient");
    Pat.CreateDir();
    char Fname[20] = "Penalty";
    UPatTree Scan = Pat.Child(Fname, UPatTree::U_SCAN);
    UEuler   XFM(0.,0.,0.,-PI/2.,PI/2.,0.);
    Scan.SetScanToWld(XFM);
    Scan.SetScan(Domain);
    return U_OK;
}

double ULocMovDip::UPenalty::GetPenalty(UVector3 v, int *status, double *grad)
{
    if(SphereModel)
    {
        double Rad = (v-SpherePos).GetNorm();
        if(grad) {grad[0]=grad[1]=grad[2]=0.;}
        if(Rad<SphereRad) return 0.;

        if(grad)
        {
            UVector3 Dif = v-SpherePos;
            grad[0] = 10*Dif.Getx()/Rad;
            grad[1] = 10*Dif.Gety()/Rad;
            grad[2] = 10*Dif.Getz()/Rad;
        }
        return 10*(Rad-SphereRad);
    }
    else
    {
        UVector3 D = v-Domain->GetFirstx();
        int     ix = int(floor(D.Getx()/Mesh));
        int     iy = int(floor(D.Gety()/Mesh));
        int     iz = int(floor(D.Getz()/Mesh));

        double PenalOut   = 0.;
        double GradOut[3] = {0.,0.,0.};
        if(ix<0)
        {
            PenalOut   += SCALE*   -ix;
            GradOut[0] += SCALE;
            ix          = 0;
            D.Setx(0.);
        } else if(ix>=dimx)
        {
            PenalOut   +=  SCALE*    ix-dimx+1;
            GradOut[0] += -SCALE;
            ix          =  dimx-1;
            D.Setx((dimx-1)*Mesh);
        }
        if(iy<0)
        {
            PenalOut   += SCALE*   -iy;
            GradOut[1] += SCALE;
            iy          = 0;
            D.Sety(0.);
        } else if(iy>=dimy)
        {
            PenalOut   +=  SCALE*    iy-dimy+1;
            GradOut[1] += -SCALE;
            iy          =  dimy-1;
            D.Sety((dimy-1)*Mesh);
        }
        if(iz<0)
        {
            PenalOut   += SCALE*   -iz;
            GradOut[2] += SCALE;
            iz          = 0;
            D.Setz(0.);
        } else if(iz>=dimz)
        {
            PenalOut   +=  SCALE*    iz-dimz+1;
            GradOut[2] += -SCALE;
            iz          =  dimz-1;
            D.Setz((dimz-1)*Mesh);
        }

        double xf = D.Getx()/Mesh-ix;               /* fractional part of (x', y', z') */
        double yf = D.Gety()/Mesh-iy;
        double zf = D.Getz()/Mesh-iz;

        short* sp = Domain->GetSdata() + iz*dimxy + iy*dimx + ix; /* pointer to 'cornerstone' */

        short   f3   = sp[dimx+1];
        short   a    = sp[0];
        short   b    = sp[1]            - a;
        short   c    = sp[dimx]         - a;
        short   g    = f3               - a - b - c;
        short   d    = sp[dimxy]        - a;
        short   e    = sp[dimxy + dimx] - a - c - d;
        short   f    = sp[dimxy + 1 ]   - a - b - d;
        short   h    = sp[dimxy + dimx + 1] - f3 - d - e - f;

        double  yzf  = (yf * zf);
        double  xyf  = (xf * yf);
        double  xzf  = (xf * zf);
        double  xyzf = (xf * yzf);

        double  P =  a + b*xf + c*yf + d*zf + e*yzf + f*xzf + g*xyf + h*xyzf;

/////
/////    double Rtest = (v-UVector3(-.545,.1685,4.009)).GetNorm()   - 9.618;
/////

        if(grad)
        {
            grad[0] += (GradOut[0] +  b/Mesh)/SCALE;
            grad[1] += (GradOut[1] +  c/Mesh)/SCALE;
            grad[2] += (GradOut[2] +  d/Mesh)/SCALE;
        }
        double TotalP = (PenalOut + P)/SCALE;

        if(status && TotalP>0.) *status = 1;
        return  TotalP;
    }
}

ErrorType UFitDipoles::FitMovingDipoles(UFileName HeadModelFileName, const char* ChanName, UStartDipole::StartType ST, int Npts, UFitDipoles::CostType CT, bool AdFordMod, bool UseOldUnits, double MaxFitMovingDipolesError, FitDataType FDT, double MinPowFact, bool ConfidenceLimits, double AmatThreshold, bool ManyDigits)
{
/* Test whether data is read and epochs are set.*/
    if(Data==NULL || Epochs==NULL) return U_ERROR;

    UHeadModel* HModel=GetHeadModel(HeadModelFileName, FDT);
    if(HModel==NULL || HModel->GetError()!=U_OK) return U_ERROR;

    if( (FDT==U_MEG_AND_EEG || FDT==U_EEG_ONLY) && Data->AreEEGPositionsMeasured()==false)
    {
        CI.AddToLog("WARNING: UFitDipoles::FitMovingDipoles(). EEG dipole fitting is based on default electrode positions. True EEG sensor positions not set.\n");
    }
/* Set the Power threshold to skip samples on the base of the signal strength. */
    SetDataThresold(MinPowFact, FDT);

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdFordMod==true)
        ReRefForw = GetMEGForwardBalancing();

/* Compute spatial covariance */
    UCovariance* CovXX = NULL;
    int   nMEG         = 0;
    const UGrid* gridM = NULL;
    if((FDT==U_MEG_ONLY||FDT==U_MEG_AND_EEG) && Data->GetGridMEG())
    {
        nMEG  = Data->GetGridMEG()->GetNpoints();
        gridM = Data->GetGridMEG();
    }
    else if(FDT==U_MEG_ONLY||FDT==U_MEG_AND_EEG)
        CI.AddToLog("WARNING: UFitDipoles::FitMovingDipoles(). Required MEG data not present in dataset. \n");

    int   nEEG         = 0;
    const UGrid* gridE = NULL;
    if((FDT==U_EEG_ONLY||FDT==U_MEG_AND_EEG) && Data->GetGridEEG())
    {
        nEEG  = Data->GetGridEEG()->GetNpoints();
        gridE = Data->GetGridEEG();
    }
    else if(FDT==U_EEG_ONLY||FDT==U_MEG_AND_EEG)
        CI.AddToLog("WARNING: UFitDipoles::FitMovingDipoles(). Required EEG data not present in dataset. \n");

    if(nMEG<=0 && nEEG<=0)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Neither MEG nor EEG data channels present or selected. \n");
        return U_ERROR;
    }

    bool CTAbs = false;
    switch(CT)
    {
    case UFitDipoles::U_ABS:    // The global search optimals are filled with the OLS minima
        CTAbs  = true;
    case UFitDipoles::U_SQUARE:
        if(FDT==U_MEG_AND_EEG)
        {
            CovXX = new UCovariance(nMEG, nEEG, ULocMovDip::OLS_REL_EEG_VARIANCE, true);
            break;
        }
    case UFitDipoles::U_WEIGHTED_OLS:
        CovXX = new UCovariance(nMEG+nEEG, gridM, gridE);
        break;
    case UFitDipoles::U_THECOV:
        CovXX = new UCovariance(gridM, gridE, -1, 7., HModel->GetSpherePos());
        break;
    case UFitDipoles::U_FILECOV:
        CovXX = new UCovariance(GetSpatCovarianceFile(), gridM, gridE);
        break;
    }
    if(CovXX==NULL||CovXX->GetError()!=U_OK)
    {
        delete CovXX;
        CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Creating spatial covariance .\n");
        return U_ERROR;
    }

/* Set the moving dipole dipole object*/
    ULocMovDip*  ULMD = new ULocMovDip(cost, UseOldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), gridM, gridE, HModel, CTAbs, CovXX);
    delete CovXX;
    if(ULMD==NULL || ULMD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Cannot create ULocMovDip-object\n");
        delete ULMD;
        return U_ERROR;
    }
    ULMD->SetAmatThreshold(AmatThreshold);

    UDipole DumDip(UVector3(0.,0.,5.), UVector3(1.,1.,1.), DType);
    if(ULMD->InitStart(ST, &DumDip, 1, Npts)!=U_OK) 
    {
        CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Initializing ULocMovDip-object\n");
        delete ULMD;
        return U_ERROR;
    }
    int NsampPTrial  = Data->GetNsampTrial();

    FILE*      fpOut = NULL;
    if(OneFile==true)
    {
        switch(OutType)
        {
        case U_SKIP:
            if(FileNameOut.GetStatus()==UFileName::U_FILE_CANBEREAD)
            {
                CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Output file already exists: %s,\n",FileNameOut.GetFullFileName());
                fpOut = NULL;
            }
            break;
        case U_DELETE:
            fpOut = fopen(FileNameOut,"wt", true);
            break;

        case U_APPEND:
            fpOut = fopen(FileNameOut,"at", true);
            break;
        }
        if(fpOut==NULL)
        {
            CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Cannot open file for writing: %s .\n",FileNameOut.GetFullFileName());
            delete ULMD;
            return U_ERROR;
        }
    }

    UVector3 Spos = HModel->GetSpherePos();
    for(int m=0; m<GetNEpoch(); m++)
    {
        CI.AddToLog("Epoch %d of %d\n",m,GetNEpoch());

/* Allocate Arrays */
        UEvent  Begin       = Epochs->GetBegin(m);
        UEvent  End         = Epochs->GetEnd(m);
        int     NsampEp     = GetNSampEpoch(m);

        UDipole *Dipoles    = new UDipole[NsampEp];
        double  *Residuals  = new double[NsampEp];
        double  *DataNorm   = new double[NsampEp];
        double  *ConfIntPos = NULL;
        if(ConfidenceLimits==true)
            ConfIntPos      = new double[3*NsampEp];

        if(!Residuals || !DataNorm || !Dipoles || (ConfIntPos==NULL && ConfidenceLimits==true))
        {
            delete[] DataNorm;
            delete[] Residuals;
            delete[] Dipoles;
            delete[] ConfIntPos;
            delete ULMD;
            CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Memory allocation. \n");
            if(OneFile==true) fclose(fpOut);
            return U_ERROR;
        }
        for(int n=0; n<NsampEp; n++) Dipoles[n].SetDipoleType(DType);

        Dipoles[0] = UDipole(UVector3(1.,1.,1.)+Spos,UVector3(1.,1.,1.),Dipoles[0].GetDipoleType());

/* Get Data. */
        UMultiChan* MCmeg = NULL;
        UMultiChan* MCeeg = NULL;
        int         nKan  = 0;

        switch(FDT)
        {
        case U_MEG_AND_EEG:
            MCmeg = GetFilteredMultiChan(m, U_DAT_MEG);
            MCeeg = GetFilteredMultiChan(m, U_DAT_EEG);
            nKan  = Data->GetNmeg() + Data->GetNeeg();
            break;

        case U_MEG_ONLY:
            MCmeg = GetFilteredMultiChan(m, U_DAT_MEG);
            nKan  = Data->GetNmeg();
            break;

        case U_EEG_ONLY:
            MCeeg = GetFilteredMultiChan(m, U_DAT_EEG);
            nKan  = Data->GetNeeg();
            break;
        }

        if( (!MCmeg && FDT==U_MEG_AND_EEG) || (!MCmeg && FDT==U_MEG_ONLY) ||
            (!MCeeg && FDT==U_MEG_AND_EEG) || (!MCeeg && FDT==U_EEG_ONLY) )
        {
            delete[] DataNorm;
            delete[] Residuals;
            delete[] ConfIntPos;
            delete[] Dipoles;
            delete   MCmeg;
            delete   MCeeg;
            delete   ULMD;
            CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Reading MEG/EEG data in epoch %d .\n",m);

            if(OneFile==true) fclose(fpOut);
            return U_ERROR;
        }

/* Set Data and compute dipoles*/
        ULMD->SetDataMeg(MCmeg, MinDataPowMEG);
        ULMD->SetDataEeg(MCeeg, MinDataPowEEG);
        ULMD->ComputeDipoles(Dipoles, ConfIntPos, Residuals, DataNorm, MaxFitMovingDipolesError);

/* Export results*/
        if(OneFile==false)
        {
            FileNameOut.InsertFileNumber(m,3);

            switch(OutType)
            {
            case U_SKIP:
                if(FileNameOut.GetStatus()==UFileName::U_FILE_CANBEREAD)
                {
                    CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Output file already exists: %s,\n",FileNameOut.GetFullFileName());
                    fpOut = NULL;
                }
                break;
            case U_DELETE:
                fpOut = fopen(FileNameOut,"wt", true);
                break;

            case U_APPEND:
                fpOut = fopen(FileNameOut,"at", true);
                break;
            }
            if(fpOut==NULL)
            {
                CI.AddToLog("ERROR: UFitDipoles::FitMovingDipoles(). Cannot open file for writing: %s,\n",FileNameOut.GetFullFileName());
                delete[] DataNorm;
                delete[] Residuals;
                delete[] ConfIntPos;
                delete[] Dipoles;
                delete[] MCmeg;
                delete[] MCeeg;
                delete ULMD;
                return U_ERROR;
            }
        }
        if(m==0||OneFile==false)
        {
            UString Prop;

            fprintf(fpOut,"// GENERAL:\n");
            fprintf(fpOut,"%s",CI.GetProperties("//    "));
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA:\n");
            Prop = Data->GetProperties("//  ");
            Prop.WriteText(fpOut);
            if(PowerDistMEG)
            {
                fprintf(fpOut,"//     MEG power distribution:\n");
                Prop = PowerDistMEG->GetProperties("//  ");
                Prop.WriteText(fpOut);
            }
            if(PowerDistEEG)
            {
                fprintf(fpOut,"//     EEG power distribution:\n");
                Prop = PowerDistEEG->GetProperties("//  ");
                Prop.WriteText(fpOut);
            }
            fprintf(fpOut,"//\n");
            if(GetMarkerArray())
            {
                fprintf(fpOut,"//\n");
                fprintf(fpOut,"// DATA MARKERS:\n");
                Prop = GetMarkerArray()->GetProperties("//  ");
                Prop.WriteText(fpOut);
            }
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// EPOCHS:\n");
            if(OneFile==false)
                fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
            else
            {
                if(Epochs->GetnEpochs()<10)
                {
                    for(int k=0; k<Epochs->GetnEpochs(); k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                            k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                               Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                }
                else
                {
                    for(int k=0; k<9; k++)
                            fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                            k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                               Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                    fprintf(fpOut,"//   ..., Etc. \n");
                }
            }
            this->GetProperties("//  ").WriteText(fpOut);
            if((FDT==U_MEG_ONLY || FDT==U_MEG_AND_EEG)&&MinDataPowMEG>0)
            {
                fprintf(fpOut,"//\n");
                fprintf(fpOut,"//   All samples with powers lower than %6.1f times the MEG median have been skipped prior to dipole fitting.\n", MinPowFact);
            }
            if((FDT==U_EEG_ONLY || FDT==U_MEG_AND_EEG)&&MinDataPowEEG>0)
            {
                fprintf(fpOut,"//\n");
                fprintf(fpOut,"//   All samples with powers lower than %6.1f times the EEG median have been skipped prior to dipole fitting.\n", MinPowFact);
            }
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// FITTING:\n");
            fprintf(fpOut,"//   %s\n",cost.GetParameterString());
            ULMD->GetProperties("//  ").WriteText(fpOut);
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// HEAD MODEL:\n");
            Prop = UString(HModel->GetProperties("//  "));
            Prop.WriteText(fpOut);
            fprintf(fpOut,"//\n");
        }
        double       *StdErrMean  = NULL;
        char line[400];
        int  nc=0;
        if(m==0||OneFile==false)
        {
            if(TimeInMs==false) nc += sprintf(line,"Samp");
            else                nc += sprintf(line,"Time");

            nc += Dipoles[0].PrintParameters(line+nc,-(300-nc-1));
            nc += sprintf(line+nc,"\tERROR(%%)");
            if(ConfIntPos)
            {
                nc += sprintf(line+nc,"\tDeltaX ");
                nc += sprintf(line+nc,"\tDeltaY ");
                nc += sprintf(line+nc,"\tDeltaZ ");
            }
            nc += sprintf(line+nc,"\tAverDataPower");
            if(StdErrMean) nc += sprintf(line+nc,"\tStdErrMean");
            if(ChanName && ChanName[0]!=0)
            {
                fprintf(fpOut,"// Warning: Required channel %s not in file.\n",ChanName);
            }
            fprintf(fpOut,"%s\n",line);
        }
        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

        for(int i=0; i<NsampEp; i++)
        {
            if(AllDipoles==false && MaxFitMovingDipolesError>0. && Residuals[i]>MaxFitMovingDipolesError) continue;

            UEvent E = GetEvent(m, i);
            nc       = 0;

            if(TimeInMs==false)
                nc += sprintf(line,"%6.6d   ",E.GetAbsSample(NsampPTrial));
            else
                nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(NsampPTrial));
            nc += Dipoles[i].PrintParameters(line+nc,300-nc-1, -1, ManyDigits);
            nc += sprintf(line+nc,"\t%f",Residuals[i]);
            if(ConfIntPos)
            {
                nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i  ]);
                nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i+1]);
                nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i+2]);
            }

            if(nKan)
                nc += sprintf(line+nc,"\t%f",DataNorm[i]/nKan);
            else
                nc += sprintf(line+nc,"\t0.0");
            if(StdErrMean)  nc += sprintf(line+nc,"\t%f",StdErrMean[i]);
            fprintf(fpOut,"%s\n",line);
        }
        delete[] DataNorm;
        delete[] Residuals;
        delete[] ConfIntPos;
        delete[] Dipoles;
        delete[] MCmeg;
        delete[] MCeeg;
        delete[] StdErrMean;
        if(OneFile==false) fclose(fpOut);
    }
    delete ULMD;
    if(OneFile==true) fclose(fpOut);

    return U_OK;
}
