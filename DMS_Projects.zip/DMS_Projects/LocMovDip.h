#ifndef _LOCMOVDIP_INCLUDED
#define _LOCMOVDIP_INCLUDED

#include "Minimize.h"
#include "StartDipole.h"
#include "MEEGDataBase.h"

class UCovariance;
class UEMfield;
class ULocMovDip : public UStartDipole, public Uminimize
{
public:
    enum CostFlag {U_COST_OK,               // No Errors occured at the computation of the cost at the  current time sample
                   U_COST_ERROR_EMFIELD,    // At least EM field error computation error ocured
                   U_COST_ERROR_DIRECTION}; // At least one error occured in CostDirection()

    ULocMovDip(const UCostminimize& cost, bool UseOU, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* GridM, const UGrid* GridE, const UHeadModel *Hmod, bool CTAbs, 
                         const UCovariance* SpatCov);
    virtual             ~ULocMovDip();

    ErrorType           GetError() const {return error;}
    const UString&      GetProperties(UString Comment) const;

    ErrorType           SetDataMeg(const UMultiChan* MCmeg, double MinPower);
    ErrorType           SetDataEeg(const UMultiChan* MCeeg, double MinPower);
    ErrorType           SetCovariance(UCovariance* CovNewXX);
    void                SetAmatThreshold(double AmTr) {AmatThreshold = AmTr;}

    ErrorType           ComputeDipoles(UDipole* DipArray, double* ConfIntPos, double *residual, double* DataN, double MxStrtEr);
    int                 GetNtotSamp(void) const     {return NtotSamp;}
    int                 GetNtotDatPow(void) const   {return NtotDatPow;}
    int                 GetNtotNLsearch(void) const {return NtotNLsearch;}
    int                 GetNtotCost(void) const     {return NtotCost;}
    
    double              ComputeCost(double *par, int iter=0, int *status=NULL, double *grad=NULL);
/* Required (=pure virtual in Uminimize() and in UStartDipole()): */
    double              ComputeCost(double *par, int iter, int *status) { return ComputeCost(par, iter, status, NULL);}
    const double*       GetDirection(void) const {return Direction;}

    static double const OLS_REL_EEG_VARIANCE;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private: 
    static double const COV_THRESHOLD;
    static double const COSTERROR;
    static double const AMAT_THRESHOLD;
    static UString      Properties;   // Properties in text format

    ErrorType           error;        // General error
    bool                UseOldUnits;  // Use units in dipole strength according UEmfield() // after 22-08-03

/* MEG parameters*/
    int                 nMEG ;        // The number of MEG channels
    const UMultiChan*   MCMEG;        // MEG Data
    double              MinDataPowMEG;// MEG Power threshold used to skip samples

/* EEG parameters*/
    int                 nEEG ;        // The number of EEG channels
    const UMultiChan*   MCEEG;        // EEG Data
    double              MinDataPowEEG;// EEG Power threshold used to skip samples
    
    UCovariance*        CovXX;        // The spatial covariance for the MEG/EEG sensors
    UMatrix             DataMap;      // (map) Data of the current sample (for internal use)
    UMatrix             CinvDataMap;  // CovarianceInverse * DataMap[]
    double              DataNorm;     // Sum of squares of DataMap[]
    double              DataAbs;      // Sum of absolute values of DataMap[]
    
    int                 NtotSamp;     // The total number samples analyzed, starting from construction
    int                 NtotDatPow;   // The total number of times that a samples passes the data-power select threshold
    int                 NtotNLsearch; // The total number of times that a non-linear search is performed,, starting from constructor
    int                 NtotCost;     // The total number of calls to ComputeCost(), starting from constructor
    
    double              Direction[6]; // direction(s) of dipole on current sample
    double              Position[5];  // position of dipole on current sample
                                      // If CostFuncABS==true, position is followed by the tangential angle
    double              AmatThreshold;// Parameter determining the stability of the system matrix, used to compute the dipole components

    bool                CostFuncABS;  // True iff Absolute differences are to be minimized, else OLS or GLS
    CostFlag            CostError;    // Determines whether error occured during cost computation
    double              MaxStartError;// When the error obtained with the optimum starting values are larger than MaxStartError, iterations will be skipped
    bool                CompConfInt;  // If true Compute confidence intervals

    double              ComputeCost(const UVector3 &Point, float *fld, int idum=0, double* AmatInv=NULL);
    ErrorType           CostDirection(UMatrixSymmetric& Amat, const UMatrix& Bvec, double *Cost);
    ErrorType           CompMatInv(double* AmatInv, const double* LeadField) const;
    ErrorType           ComputeConfIntPos(const UDipole& Dip, double* DeltaPos);

    class UTestCost
    {
    public:
        UTestCost() {Ntest = Nprevious = 0;}
        int  GetNtest(void) const     {return Ntest;}
        int  GetNprevious(void) const {return Nprevious;}
        bool TestPrevious(ULocMovDip* LMD, UVector3 Xprev, double StartCost, double* StartPos);

    private:
        int Ntest;
        int Nprevious;
    };
    class UPenalty
    {
    public:
        UPenalty(UEMfield* Em);
        ~UPenalty();
        ErrorType GetError(void) const {return error;}

        double    GetPenalty(UVector3 v, int *status, double *grad);
        ErrorType ExportPenaltyField() const;

    protected:
        void      SetAllMembersDefault(void);
        void      DeleteAllMembers(ErrorType E);
    private:
        ErrorType error;
        UField*   Domain; 
        double    Mesh;     // Nearest neighbour distance of domain grid
        int       dimx;     // dimensions of the mesh
        int       dimy;
        int       dimz;
        int       dimxy;

        bool      SphereModel;
        UVector3  SpherePos;
        double    SphereRad;
    };

    UTestCost    TC;
    UPenalty*    Penalty;   // Mesh to test domain errors.
};

#endif // _LOCMOVDIP_INCLUDED
