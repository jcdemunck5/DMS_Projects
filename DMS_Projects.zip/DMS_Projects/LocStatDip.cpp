/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for fitting stationary dipoles to MEG/EEG data                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    03-08-00   creation, derived from LocStatDip.cpp
  JdM    20-12-00   Added SetCovarianceTT()
  Jdm    31-05-01   Added UFitDipoles::FitStationaryDipoles()
  Jdm    01-06-01   Derive ULocStatDip() from newly created UStartStatDip()
  JdM    05-07-01   Bug fix ComputeDipoles(). Initializing orientation parameters
  JdM    15-07-01   Allow dipole fitting based on simultaneous MEG and EEG
  JdM    27-08-01   Allow for adaptation of MEG forward model on data gradient order
  JdM    21-09-01   Allow rotating dipoles, tested ComputeCost for gradients
  JdM    05-10-01   Test if nKan is smaller than 10 in constructor
  JdM    29-11-01   Major Update. Use the UDipoleManager() to manage dipole parameter constraints
  JdM    02-12-01   Bug fix in position symmetric dipoles
  JdM    04-12-01   Compute derivative of Cost in special case using numerical derivatives
  JdM    22-03-02   Bug fix: only apply balancing when MEG is selected.
  JdM    22-03-02   ComputeDipoles(). Setting Ncomp at max to Nsamples
  JdM    19-05-02   FitStationaryDipoles(). Changed ERROR on electrdode positions into WARNING
  JdM    14-11-02   Export (filtered) ADC data when requested
JdM/FB   10-12-02   Made DipMan a pointer to a UDipoleManager() object
  FB     12-03-03   Added the parameter FitTest to ComputeCost (WEMdat) to set fit precision
FB/JdM   19-03-03   Bug fix in computing Dnorm in ComputeDipoles(), double dividing by nKan
  JdM    22-08-03   ULocStatDip::ULocStatDip(), FitStationaryDipoles(). Add parameter to set the use of old units (See EMfield.cpp)
  JdM    03-09-03   ComputeDipoles() Remove test for simultaneous MEG/EEG (allow it).
  JdM    08-09-03   FitStationaryDipoles(). Return U_ERROR on ULSD->ComputeDipoles() failure
  FB     27-01-04   Added: ComputeConfIntervals() and ComputeCCRB() to compute confidence regions around the estimated stfs.
                    Added GetDataNorm()
  FB     03-02-04   Added: SetCovariance() to overwrite the covariance
  FB     10-02-04   Added UpdateFreeDipoles() for simulations
  JdM    10-03-05   Disable language extensions (for-loops) for compatability with Linux C++
JdM/FB   30-03-05   Remove CType. This affects SetData(), in case of non-constant number of samples per epoch
                    Constructor: Replace filename pointers by pointer to UCovariance-objects
                    Removed SetCovarianceTT()
  FB     06-04-05   Added ComputeDipoles() based on UDipoleEdit
  FB     20-04-05   Adapted ComputeCCRB() such that user can choose from two methods
                    Added parameter Bonfer in ComputeConfIntervalse() for Bonferroni correction
  FB     20-04-05   Added second argument in SetNcomp(int, double)
  JdM    05-01-07   Eliminate reference to obsolete UDataEpochs, and use UMEEGDataEpochs
  JdM    05-01-07   Eliminate reference to obsolete UDataEpochs, and use UMEEGDataEpochs
  Jdm    17-08-08   Bug Fix: ULocStatDip::ULocStatDip(). SetBalancing(): Use UMEEGDataBase::MAXMEG
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    10-04-09   Bug fixes ComputeDipoles(): compilor errors on MSVC2008. Comparing function pointers
  JdM    19-05-11   Use explicit casts to (const char*) of calls to GetProperties()
  JdM    29-12-13   Adapt to new interface to UMatrix-object. No correctness test performed!
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    21-12-14   UpdateDirection() and UpdateBmat(). Replaced UJacobi bu MatrixSymmetric
  JdM    19-01-15   ComputeDipoles() and other places: apply updates in relation to new UCovariance object
                    Disabled ComputeCCRB().
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LocStatDip.h"
#include "FitDipoles.h"
#include "Epochs.h"
#include "MarkerArray.h"
#include "Matrix.h"
#include "MatrixSymmetric.h"
#include "Statistics.h"

/* Inititalize static const parameters. */
UString      ULocStatDip::Properties           = UString();
double const ULocStatDip::COSTERROR            =  10000;
double const ULocStatDip::AMAT_THRESHOLD       = 1.e-8;
double const ULocStatDip::OLS_REL_EEG_VARIANCE = .01;
const int    ULocStatDip::MAXLINITER           = 50;
double const ULocStatDip::COV_THRESHOLD        =  1.e-8;


void ULocStatDip::SetAllMembersDefault(void)
{
    error         = U_OK;
    UseOldUnits   = false;

    GridMEG       = NULL;
    GridEEG       = NULL;
    nMEG          = 0;
    nEEG          = 0;
    Ftype         = UEMfield::U_UNKNOWN;
    Nsamples      = 0;
    Ndipoles      = 0;
    Ncomp         = 0;
    CovXX         = NULL;
    CovTT         = NULL;

    EMData        = NULL;
    ULamda        = NULL;
    Lamda         = NULL;
    Vmat          = NULL;
    SV            = NULL;
    Bmat          = NULL;
    FBT           = NULL;
    WmatTfld      = NULL;

    NtotCost      = 0;
    DataNorm      = 0.;
}

void ULocStatDip::DeleteAllMembers(ErrorType E)
{
    delete[] EMData;
    delete[] ULamda;
    delete[] Lamda;
    delete[] Vmat;
    delete[] SV;
    delete[] Bmat;
    delete[] FBT;
    delete[] WmatTfld;
    delete   CovXX;
    delete   CovTT;

    SetAllMembersDefault();
    error = E;
}

ULocStatDip::ULocStatDip(const UCostminimize& cost, bool UseOU, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* gridM, const UGrid* gridE, const UHeadModel *Hmod,
                         const UCovariance* CovarXX, const UCovariance* CovarTT)   :
    Uminimize(cost),
    UStartStatDip(Hmod)
{
    SetAllMembersDefault();
    UseOldUnits = UseOU;

    GridMEG     = gridM;
    GridEEG     = gridE;
    if(GridMEG && GridEEG)
    {
        nMEG  = GridMEG->GetNpoints();
        nEEG  = GridEEG->GetNpoints();
        Ftype = UEMfield::U_MEGEEG;
    }
    else if(GridMEG)
    {
        nMEG  = GridMEG->GetNpoints();
        nEEG  = 0;
        Ftype = UEMfield::U_MEG;
    }
    else if(GridEEG)
    {
        nMEG  = 0;
        nEEG  = GridEEG->GetNpoints();
        Ftype = UEMfield::U_EEG;
    }
    else
    {
        nMEG  = 0;
        nEEG  = 0;
        Ftype = UEMfield::U_UNKNOWN;
    }
    nKan  = nEEG + nMEG;

    if(nKan<=10 || Ftype==UEMfield::U_UNKNOWN)
    {
        UStartStatDip::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ULocStatDip::ULocStatDip(). Illegal number of channels: nKan = %d. \n",nKan);
        return;
    }
    WmatTfld    = new double*[MAXDIPOLES];
    if(!WmatTfld) error = U_ERROR;

    if(error==U_OK) error = Emf.GetError();
    if(error==U_OK) error = UStartStatDip::GetError();
    if(error==U_OK && Hmod==NULL) error = U_ERROR;

    if(error==U_OK)
    {
        Emf.SetUseOldUnits(UseOU);
        error    = Emf.SetGrid(gridM, gridE);

        if(error==U_OK && ReRefForw!=U_REF_RAW && gridM)
            error = Emf.SetBalancing(GridR, pBal, UMEEGDataBase::MAXMEG, ReRefForw);

        if(error==U_OK) error = SetCovariance(CovarXX, CovarTT);
    }
    if(error!=U_OK)
    {
        UStartStatDip::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: ULocStatDip::ULocStatDip(): Memory allocation error. \n");
    }
}

ULocStatDip::~ULocStatDip()
{
    CI.AddToLog("Note: ULocStatDip::~ULocStatDip(). Fit Statistics:\n");
    CI.AddToLog("N_cost_evaluations = %d\n",NtotCost);

    DeleteAllMembers(U_OK);
}

const UString& ULocStatDip::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in ULocStatDip-object\n");
        return Properties;
    }

    Properties = UString();

    Properties += "BaseClass \n";
    Properties  += UStartStatDip::GetProperties("  ");
    if(CovXX)
    {
        Properties += "Spatial Covariance: \n";
        Properties += CovXX->GetProperties(" ");
    }
    else if(Ftype==UEMfield::U_MEGEEG)
    {
        Properties += "MEEG with OLS weighting\n";
        Properties += UString(OLS_REL_EEG_VARIANCE, "EEGWeightingFactor = %f \n");
    }
    if(CovTT)
    {
        Properties += "Temporal Covariance: \n";
        Properties += CovTT->GetProperties(" ");
    }

    if(SV)
    {
        Properties += UString(Ncomp, "NComponents    = %d  //// First Singular Values squared of pre-whitened data matrix in %%\n");
        
        for(int k=0; k<MIN(Nsamples,MAX(10,Ncomp)); k++)
            Properties += UString(SV[k], " %7.2f ,");
        Properties += "\n";
    }

    if(pDipMan && pDipMan->GetError()==U_OK)
    {
        Properties += "Dipole Properties: \n";
        Properties += pDipMan->GetProperties(Comment);
    }
    if(GridMEG&&GridEEG) Properties += "DataSource        = MEG/EEG \n";
    else if(GridMEG)     Properties += "DataSource        = MEG \n";
    else if(GridEEG)     Properties += "DataSource        = EEG \n";

    if(UseOldUnits==true)     Properties += "DipoleStrengthUnit = OldUnit \n";
    else                      Properties += "DipoleStrengthUnit = nAm*cm \n";

    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);
    return Properties;
}

ErrorType ULocStatDip::SetCovariance(const UCovariance* CovNewXX, const UCovariance* CovNewTT)
/*
This routine can be used to overwrite the existing covariance type and matrices.
*/
{
    if(CovNewXX==NULL || CovNewXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetCovariance(). Invalid spatial covariance. \n");
        return U_ERROR;
    }
    if(CovNewTT==NULL || CovNewTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetCovariance(). Invalid temporal covariance. \n");
        return U_ERROR;
    }

    delete CovXX; CovXX = new UCovariance(*CovNewXX);
    delete CovTT; CovTT = new UCovariance(*CovNewTT);

    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetCovariance(). Copying spatial covariance. \n");
        return U_ERROR;
    }
    if(CovTT==NULL || CovTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetCovariance(). Copying temporal covariance. \n");
        return U_ERROR;
    }
    Nsamples = CovTT->GetNdim();
    return U_OK;
}

ErrorType ULocStatDip::SetData(const double *DataMEG, const double *DataEEG, int nsamp)
/*
    Allocate the memory for the help arrays and perform as many as possible
    pre-computations.
 */
{
/* Test arguments*/
    if( (DataMEG && !GridMEG) || (!DataMEG && GridMEG) )
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Setting MEG-data while MEG-grid not set, or other way around.\n");
        return error = U_ERROR;
    }
    if( (DataEEG && !GridEEG) || (!DataEEG && GridEEG) )
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Setting EEG-data while EEG-grid not set, or other way around.\n");
        return error = U_ERROR;
    }
    if(nsamp<=0)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Invalid nsamp (=%d).\n",nsamp);
        return error = U_ERROR;
    }
    if(CovTT==NULL)
    {
        CovTT = new UCovariance(nsamp);
        if(CovTT==NULL || CovTT->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: ULocStatDip::SetData(). Setting default temporal covariance matrix. \n");
            return U_ERROR;
        }
        Nsamples = nsamp;
    }
    else if(nsamp!=Nsamples)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Number of samnples of data window (%d) is not equal to the number of samples in covariance file (%d). \n",nsamp,Nsamples);
        return U_ERROR;
    }

/* Allocate the memory, but first delete the old ones*/
    delete[] EMData;  EMData = new double[nKan*Nsamples];
    delete[] ULamda;  ULamda = new double[nKan*Nsamples];
    delete[] Lamda;   Lamda  = new double[Nsamples];
    delete[] Vmat;    Vmat   = new double[Nsamples*Nsamples];
    delete[] SV;      SV     = new double[Nsamples];
    delete[] Bmat;    Bmat   = new double[3*MAXSTATDIP*Nsamples];

    if(!EMData || !ULamda || !Lamda || !Vmat || !SV || !Bmat)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Memory allocation. nKan=%d, Nsamp=%d\n",nKan,nsamp);
        delete[] EMData;  EMData = NULL;
        delete[] ULamda;  ULamda = NULL;
        delete[] Lamda;   Lamda  = NULL;
        delete[] Vmat;    Vmat   = NULL;
        delete[] SV;      SV     = NULL;
        delete[] Bmat;    Bmat   = NULL;
        return U_ERROR;
    }
    Ncomp = 0;

/* Set the matrix elements to their defaults*/
    for(int k=0; k<3*MAXSTATDIP*Nsamples; k++) Bmat[k] = 0;

    for(int i=0; i<nKan; i++)
    {
        if(i<nMEG)                    // First the MEG data ...
        {
            for(int j=0; j<Nsamples; j++)
                EMData[i*Nsamples+j] = DataMEG[i*Nsamples+j];
        }
        else
        {
            for(int j=0; j<Nsamples; j++) // ... then the EEG data
                EMData[i*Nsamples+j] = DataEEG[(i-nMEG)*Nsamples+j];
        }
    }

/* Pre-whiten the data matrix EmData[] */
    if(CovTT)
    {
        CovTT->SetNPosEig(ULocStatDip::COV_THRESHOLD);
        if(CovTT->MultiplyAWmat(EMData, nKan)!=U_OK)
        {
            CI.AddToLog("ERROR: ULocStatDip::SetData(). Post-multiplying data matrix with temporal covariance. \n");
            return error = U_ERROR;
        }
    }
    if(CovXX)
    {
        CovXX->SetNPosEig(ULocStatDip::COV_THRESHOLD);
        if(CovXX->MultiplyWmatTA(EMData, Nsamples)!=U_OK)
        {
            CI.AddToLog("ERROR: ULocStatDip::SetData(). Pre-multiplying data matrix with spatial covariance. \n");
            return error = U_ERROR;
        }
    }
    for(int k=0; k<nKan*Nsamples; k++) ULamda[k] = EMData[k];

/* Compute SVD  and normalized sigular values. */
    svdcmp_d(ULamda, nKan, Nsamples, Lamda, Vmat);

    for(int i=0; i<nKan; i++)
        for(int j=0; j<Nsamples; j++)
            ULamda[i*Nsamples+j] *= Lamda[j];

    DataNorm = 0.;
    for(int k=0; k<Nsamples; k++) DataNorm += Lamda[k]*Lamda[k];
    if(DataNorm<1.e-10)
    {
        CI.AddToLog("ERROR: ULocStatDip::SetData(). Sum of (weighed) squares of data matrix almost vanishes. DataNorm = %e\n",DataNorm);
        return error = U_ERROR;
    }
    for(int k=0; k<Nsamples; k++) SV[k]  = 100*Lamda[k]*Lamda[k]/DataNorm;

    return U_OK;
}

ErrorType ULocStatDip::SetNcomp(int ncmp, double thres)
/*
This routine sets the number of singular values ofthe data
array (Ncomp) that is taken into account in the parameter
estimation.
IF                 THEN
ncmp>0 and thres<0   Ncomp = MIN(ncmp,Nsamples).
ncmp>0 and thres>0   Ncomp = MIN(ncmp,Nsamples) and thres is ignored.
ncmp<0 and thres>0   Ncomp is adjusted such that the power
                      in the first Ncomp singular values of
                      the data array equals at least (1-thres)x100%
                      of the total data power.
                      if thres>=1, then Ncomp = Nsamples.
ncmp<0 and thres<0   Ncomp = MIN(Nsamples,nFreeSTF), the rank of the dipole model
*/
{
    if(ncmp<=0  && thres<0.)
    {
        Ncomp = MIN(Nsamples,pDipMan->GetNfreeSTF());
        return U_OK;
    }
    if(ncmp >0)
    {
        if(ncmp > Nsamples)
            Ncomp = Nsamples;
        else
            Ncomp = ncmp;
        return U_OK;
    }
    if(ncmp <0 && thres >0.)
    {
        if(thres >= 1.)
            Ncomp = Nsamples;
        else
        {
            int    k      = Nsamples-1;
            double RelPow = 0.;

            while (k>=0 && RelPow<thres)
            {
                RelPow += Lamda[k]*Lamda[k]/DataNorm;
                k--;
            }
            Ncomp = k+2;
        }
        return U_OK;
    }
    return U_ERROR;
}

ErrorType ULocStatDip::ComputeDipoles(UDipoleEdit* DipEd, int Ndip, double *residual, double* DNorm, double *STF)
{
    ErrorType E = U_ERROR;

/* Check for validity of arguments */
    if(DipEd==NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Invalid NULL argument in DipArray. \n");
        return E;
    }
    if(Ndip<=0 || Ndip>=MAXSTATDIP)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Number of dipoles out of range (%d) \n",Ndip);
        return E;
    }

/* Check compatibility of DipEd with contents of DipoleManager */
/* This check has to be implemented when DipEd is allowed to contain different DipoleTypes*/
/*
    if(Ndip != pDipMan->GetNDipoles())
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Number of dipoles not compatible.\n");
        return E;
    }
*/
    UDipole* DipAr = new UDipole[pDipMan->GetNDipoles()];
    if(DipAr==NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Allocating memory for dipoles in DipEd.\n");
        return E;
    }

    pDipMan->GetAllDipoles(DipAr);
    for(int k=0; k<Ndip; k++)
    {
        if(DipAr[k].GetDipoleType()!=DipEd[k].GetDipoleType())
        {
            CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Dipole types not compatible for dipole %d.\n",k);
            return E;
        }
        if (pDipMan->IsDipoleRotating(k) != DipEd[k].GetRotating() )
        {
            CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Dipole rotation types not compatible for dipole %d.\n",k);
            return E;
        }
    }

/* Compute dipoles in UDipole array */
    E = ComputeDipoles(DipAr,Ndip, residual, DNorm, STF);

/* Copy dipoles positions and orientations to UDipoleEdit array */
    for(int k=0; k<Ndip; k++)
    {
        DipEd[k].Setx(DipAr[k].Getx());
        DipEd[k].Setd(DipAr[k].Getd());
        DipEd[k].SetdSym(DipAr[k].GetdSym());
    }

    delete[] DipAr;
    return E;
}

ErrorType ULocStatDip::ComputeDipoles(UDipole* DipArray, int Ndip, double *residual, double* DNorm, double *STF)
/*
    Compute the optimal stationary Ndip dipoles on the current data window EMData[].
    The Dipoles present in the array of dipoles DipArray act as starting values.
    On return, these starting values are replaced by the optimal dipoles.

    If(residual) also compute and store the residual of the optimal dipoles
    If(STF)      compute source time functions

    Update NtotCost
 */
{
    if(DipArray==NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(Ndip<=0 || Ndip>=MAXSTATDIP)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Number of dipoles outnof range (%d) \n",Ndip);
        return U_ERROR;
    }

    if( (!GridMEG && !GridEEG) ||
          error   != U_OK      ||
          EMData  == NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Data not properly set. \n");
        return U_ERROR;
    }
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). UDipoleManager* pDipMan not properly set. \n");
        return U_ERROR;
    }
    if(pDipMan->SetNdipoles(Ndip)!=U_OK) return U_ERROR;

/* Allocate some general memory for intermediate arrays */
    int NFreeSTF = pDipMan->GetNfreeSTF();
    delete[] FBT;
    FBT   = new double[nKan*NFreeSTF];
    if(FBT==NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Memory allocation: nKan=%d, NFreeSTF=%d \n",nKan,NFreeSTF);
        return U_ERROR;
    }

    Ndipoles = Ndip;
    if(Ncomp<=0 || Ncomp>Nsamples)
        Ncomp = MIN(Nsamples, NFreeSTF);

    if(GetStartDipoles(DipArray, Ndipoles, false)!=U_OK)
    {
        delete[] FBT; FBT = NULL;
        CI.AddToLog("ERROR: ULocStatDip::ComputeDipoles(). Getting start dipoles. \n");
        return U_ERROR;
    }

////
    CI.AddToLog("Note: ULocStatDip::ComputeDipoles(). Iterate Cost function:\n");
    CI.TimeReset("");
////
    double Position[3*MAXDIPOLES];
    pDipMan->GetPositionArray(Position);
    Iterate(Position, pDipMan->GetNfreePosPars());
////
    CI.TimeFlag("\nIterate Costfunction.");
////

    double ResError = ComputeCost(Position); // Update orientation in any case
    pDipMan->GetAllDipoles(DipArray);

    if(residual) *residual = ResError;

/* Compute pre-withened power*/
    if(DNorm)
    {
        for(int j=0; j<Nsamples; j++)
        {
            DNorm[j] = 0;
            for(int i=0; i<nKan; i++) DNorm[j] += EMData[i*Nsamples+j]*EMData[i*Nsamples+j];
        }
    }

/* Compute source time functions:
   STF = Bmat * VmatT * Wmatinv = Bmat * VmatT * Lamda * WmatT*/
    if(STF)
    {
        UMatrix Lamda = CovTT->GetLamda();

/* Rotating dipoles*/
        int l   =0;
        int istf=0;
        for(      ; l<Ndipoles; l++)
        {
            if(pDipMan->IsDipoleRotating(l)==true)
            {
                int ncmp = UEMfield::GetNcomp(D_OriPos10, DipArray[l] );

                for(int kis = istf; kis<istf+ncmp; kis++)
                {
                    for(int j=0; j<Nsamples; j++)
                    {
                        STF[kis*Nsamples+j] = 0;
                        for(int k=0; k<Ncomp; k++)
                            STF[kis*Nsamples+j] += Bmat[kis*Ncomp+k]*Vmat[j*Nsamples+k];

                        STF[kis*Nsamples+j] *= Lamda.GetElement(j,j);
                    }
                }
                istf += ncmp;
            }
            else
            {
                bool INV = false;
                if(DipArray[l].GetRadAngle(Emf.GetSpherePos())>PI/2)
                {
                    INV = true;
                    DipArray[l].Setd(-DipArray[l].Getd());
                }
                for(int j=0; j<Nsamples; j++)
                {
                    STF[istf*Nsamples+j] = 0;
                    for(int k=0; k<Ncomp; k++)
                        STF[istf*Nsamples+j] += Bmat[istf*Ncomp+k]*Vmat[j*Nsamples+k];

                    if(INV==true) STF[istf*Nsamples+j] = -STF[istf*Nsamples+j];

                    STF[istf*Nsamples+j] *= Lamda.GetElement(j,j);
                }
                istf += 1;
                if(DipArray[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    bool INV = false;
                    if(DipArray[l].GetRadAngleSym(Emf.GetSpherePos())>PI/2)
                    {
                        INV = true;
                        DipArray[l].SetdSym(-DipArray[l].GetdSym());
                    }
                    for(int j=0; j<Nsamples; j++)
                    {
                        STF[istf*Nsamples+j] = 0;
                        for(int k=0; k<Ncomp; k++)
                            STF[istf*Nsamples+j] += Bmat[istf*Ncomp+k]*Vmat[j*Nsamples+k];

                        if(INV==true) STF[istf*Nsamples+j] = -STF[istf*Nsamples+j];

                        STF[istf*Nsamples+j] *= Lamda.GetElement(j,j);
                    }
                    istf += 1;
                }
            }
        }
        return CovTT->MultiplyAWmatT(STF, istf);
    }
    return error;
}

double* ULocStatDip::GetPrewGetEMfield(const UDipole* Dip)
/*
    Return the (spatially) pre-whitened forward field for given dipole parameters Dip
 */
{
    double* WmatTfld = Emf.GetEMfield(Dip, D_OriPos10, Ftype);
    int     ncmp     = UEMfield::GetNcomp(D_OriPos10, *Dip);

    if(WmatTfld==NULL ||
       CovXX->MultiplyWmatTA(WmatTfld, ncmp)!=U_OK)
    {
        delete[] WmatTfld;
        return NULL;
    }
    return WmatTfld;
}

double ULocStatDip::ComputeCost(const double* const* WEMdat, double FitTest)
/*
    Compute the cost function, for given dipole positions Dip[].

    The pre-whitened forward fields are stored in WEMdat[0], WEMdat[1], ...
    On output, the dipole moments of Dip[] are updated.
 */
{
    double Cost = COSTERROR;
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCost(). UDipoleManager* pDipMan not properly set. \n");
        return COSTERROR;
    }
    if(pDipMan->SetFreeDerivField(WEMdat)!=U_OK)
        return Cost;

    Cost = UpdateBmat();
    if(pDipMan->GetNfreeMoment()==0) return Cost;

    double OldCost = Cost;

    for(int liter=0; liter<MAXLINITER; liter++)
    {
        Cost = UpdateDirection();
        Cost = UpdateBmat();
        if(Cost>FitTest*OldCost) break;
        OldCost = Cost;
    }
    return Cost;
}

double ULocStatDip::ComputeCost(double *par, int iter, int *status, double *grad)
/*
    Compute cost function for the given position parameters par[].
    In both cases, the dipole components are stored in the array Directions[].

    if(grad)   compute the MINUS-gradient of the cost
 */
{
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCost(). UDipoleManager* pDipMan not properly set. \n");
        return COSTERROR;
    }

    if(GridEEG && grad && Emf.GetCondModelType()==U_CONDMOD_HOMSPHERE)
        return Uminimize::ComputeCost(par, iter, status, grad);

    if(grad)
    {
        for(int l=0; l<pDipMan->GetNfreePosPars()/3; l++)
        {
            UDipoleFix DipF = pDipMan->GetFreeDipole(l);
            if(DipF.AreMomentsRotating()==false &&
               DipF.GetDipoleType()==UDipole::SymmetricPos)  // There are still bugs in this case
            {
                return Uminimize::ComputeCost(par, iter, status, grad);
            }
        }
    }


    if(status)
    {
        NtotCost++;     // Only count the number of costs, required by the Non-Linear optimization methods
        *status = 0;
    }

    double Cost  = COSTERROR;
    int NPosPars = pDipMan->GetNfreePosPars();

    UDipole Dips[MAXDIPOLES];
    pDipMan->UpdateDipolePositions(par);
    pDipMan->GetFreeDipoles(Dips);
    int l=0;
    for(; l<NPosPars/3; l++)
    {
        WmatTfld[l]  = GetPrewGetEMfield(Dips+l); // Get pre-whitened predicted EM fields
        if(WmatTfld[l]==NULL)
        {
            for(int l2=0; l2<l; l++) delete[] WmatTfld[l2];
            return Cost;
        }
    }

    Cost = ComputeCost(WmatTfld);
    l=0;
    for(; l<NPosPars/3; l++)
         delete[] WmatTfld[l];

    pDipMan->GetFreeDipoles(Dips); // Get updated moments

    if(!grad) return Cost;

/* Compute gradient */
    double BBT[36*MAXDIPOLES*MAXDIPOLES];
    int    Nstf = pDipMan->GetNfreeSTF();

    for(int k1=0; k1<Nstf; k1++)
        for(int k2=0; k2<Nstf; k2++)
            if(k2>=k1)
            {
                BBT[k1*Nstf+k2] = 0.;
                for(int j=0; j<Ncomp; j++)
                    BBT[k1*Nstf+k2] += Bmat[k1*Ncomp+j]*Bmat[k2*Ncomp+j];
            }
            else
            {
                BBT[k1*Nstf+k2] = BBT[k2*Nstf+k1];
            }

    int i=0;
    for(; i<nKan; i++)
        for(int k=0; k<Nstf; k++)
        {
            FBT[i*Nstf+k] = 0;
            for(int j=0; j<Ncomp; j++)
                FBT[i*Nstf+k] += ULamda[i*Nsamples+j]*Bmat[k*Ncomp+j];
        }

    const double* WPsiMat = pDipMan->GetFieldSTF();
    double*       WPsiBBT = new double[Nstf*nKan];
    if(WPsiMat==NULL || WPsiBBT==NULL)
    {
        delete[] WPsiBBT;
        return COSTERROR;
    }

/* Post multiply WmatTfld by BBT and store in WPsiBBT*/
    i=0;
    for(; i<nKan; i++)
    {
        for(int k1=0; k1<Nstf; k1++)
        {
            WPsiBBT[i*Nstf+k1] = 0;
            for(int k2=0; k2<Nstf; k2++)
                WPsiBBT[i*Nstf+k1] += WPsiMat[k2*nKan+i] * BBT[k1*Nstf+k2];
        }
    }

/* Compute weighted mixed field derivatives*/
    l=0;
    for(; l<NPosPars/3; l++)
    {
        UDipoleFix DipF = pDipMan->GetFreeDipole(l);
        int        ncmp = 0;
        if(DipF.AreMomentsRotating()==true)
        {
            WmatTfld[l] = Emf.GetEMfield(Dips+l, D_OriPos11, Ftype);
            ncmp        = Emf.GetNcomp(D_OriPos11, Dips[l]);
        }
        else
        {
            if(DipF.GetDipoleType()==UDipole::SymmetricPos)
            {
                WmatTfld[l] = Emf.GetEMfield(Dips+l, D_OriPos11, Ftype);
                ncmp        = 6;

                double d[6] = {DipF.Getd().Getx()   ,DipF.Getd()   .Gety(),DipF.Getd().Getz()   ,
                               DipF.GetdSym().Getx(),DipF.GetdSym().Gety(),DipF.GetdSym().Getz()};

                double*  pl = WmatTfld[l];
                double*  pk = WmatTfld[l];
                for(int i=0; i<nKan; i++, pl+=18, pk+=6)
                {
                    pk[0] = d[0]*pl[0] + d[1]*pl[ 6] + d[2]*pl[12];
                    pk[1] = d[0]*pl[1] + d[1]*pl[ 7] + d[2]*pl[13];
                    pk[2] = d[0]*pl[2] + d[1]*pl[ 8] + d[2]*pl[14];
                    pk[3] = d[3]*pl[3] + d[4]*pl[ 9] + d[5]*pl[15];
                    pk[4] = d[3]*pl[4] + d[4]*pl[10] + d[5]*pl[16];
                    pk[5] = d[3]*pl[5] + d[4]*pl[11] + d[5]*pl[17];
                }
            }
            else
            {
                WmatTfld[l] = Emf.GetEMfield(Dips+l, D_OriPos01, Ftype);
                ncmp        = Emf.GetNcomp(D_OriPos01, Dips[l]);
            }
        }

        if(WmatTfld[l]==NULL ||
           CovXX->MultiplyWmatTA(WmatTfld[l], ncmp)!=U_OK)
        {
            for(int l2=0; l2<=l; l++) delete[] WmatTfld[l2];
            return COSTERROR;
        }
    }

/* Combine all intermediate results to gradient */
    int offset = 0;
    for(int k=0; k<NPosPars; k++)
    {
        grad[k]  = 0.;
        int   l  = k/3;

        UDipoleFix DipF = pDipMan->GetFreeDipole(l);
        if(DipF.AreMomentsRotating()==true)
        {
            int ncmp = Emf.GetNcomp(D_OriPos11, Dips[l]);

            for(int i=0; i<nKan; i++)
            {
                for(int c=0; c<ncmp/3; c++)
                    grad[k] += WmatTfld[l][ncmp*i+3*c+(k%3)]*(FBT[i*Nstf+offset+c]-WPsiBBT[i*Nstf+offset+c]);
            }
            if(!((k+1)%3)) offset += ncmp/3;
        }
        else
        {
            if(DipF.GetDipoleType()==UDipole::SymmetricPos)
            {
                int c   = k%3;
                for(int i=0; i<nKan; i++)
                    grad[k] += WmatTfld[l][6*i+c  ]*(FBT[i*Nstf+offset  ]-WPsiBBT[i*Nstf+offset  ])+
                               WmatTfld[l][6*i+c+3]*(FBT[i*Nstf+offset+1]-WPsiBBT[i*Nstf+offset+1]);

                if(!((k+1)%3)) offset += 2;
            }
            else
            {
                int c   = k%3;
                for(int i=0; i<nKan; i++)
                    grad[k] += WmatTfld[l][3*i+c]*(FBT[i*Nstf+offset]-WPsiBBT[i*Nstf+offset]);

                if(!((k+1)%3)) offset += 1;
            }
        }
    }
    delete[] WPsiBBT;

/* Normalize gradient*/
    l=0;
    for(; l<NPosPars/3; l++)
    {
        delete[] WmatTfld[l];

        grad[3*l+0] *= 200/DataNorm;
        grad[3*l+1] *= 200/DataNorm;
        grad[3*l+2] *= 200/DataNorm;
    }
// General Test Code
/****
        double NumGrad[3];
        Uminimize::ComputeCost(par, iter, status, NumGrad);
        printf("%f == %f  DIFF %f\n",grad[0],NumGrad[0],grad[0]-NumGrad[0]);
        printf("%f == %f  DIFF %f\n",grad[1],NumGrad[1],grad[1]-NumGrad[1]);
        printf("%f == %f  DIFF %f\n",grad[2],NumGrad[2],grad[2]-NumGrad[2]);

        while(!getchar());
/*****/
    return Cost;
}

// General Test Code
////       double NumGrad[3*MAXSTATDIP];
////       double NumGauss[3*MAXSTATDIP*3*MAXSTATDIP];
////       Uminimize::ComputeCost(par, iter, status, NumGrad,NumGauss);
////       printf("%f == %f  DIFF %f\n",gauss[0],NumGauss[0],gauss[0]-NumGauss[0]);
////       printf("%f == %f  DIFF %f\n",gauss[1],NumGauss[1],gauss[1]-NumGauss[1]);
////       printf("%f == %f  DIFF %f\n",gauss[2],NumGauss[2],gauss[2]-NumGauss[2]);
////       printf("%f == %f  DIFF %f\n",gauss[3],NumGauss[3],gauss[3]-NumGauss[3]);
////       printf("%f == %f  DIFF %f\n",gauss[4],NumGauss[4],gauss[4]-NumGauss[4]);
////       printf("%f == %f  DIFF %f\n",gauss[5],NumGauss[5],gauss[5]-NumGauss[5]);
////       printf("%f == %f  DIFF %f\n",gauss[6],NumGauss[6],gauss[6]-NumGauss[6]);
////       printf("%f == %f  DIFF %f\n",gauss[7],NumGauss[7],gauss[7]-NumGauss[7]);
////       printf("%f == %f  DIFF %f\n",gauss[8],NumGauss[8],gauss[8]-NumGauss[8]);
////
////       while(!getchar());
////
////// General Test Code
////        double NumGrad[3];
////        Uminimize::ComputeCost(par, iter, status, NumGrad);
////        printf("%f == %f  DIFF %f\n",grad[0],NumGrad[0],grad[0]-NumGrad[0]);
////        printf("%f == %f  DIFF %f\n",grad[1],NumGrad[1],grad[1]-NumGrad[1]);
////        printf("%f == %f  DIFF %f\n",grad[2],NumGrad[2],grad[2]-NumGrad[2]);
////
////        while(!getchar());
////


double ULocStatDip::UpdateBmat(void) const
/*
     Estimate the 'source time functions' Bmat.

     Bmat = (PsiMatT * CovXInv * PsiMat) Inv * PsiMatT * WX * ULamda

     return the cost corresponding to that estimate
 */
{
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK) return COSTERROR;

    int           Nstf    = pDipMan->GetNfreeSTF();
    const double* WPsiMat = pDipMan->GetFieldSTF();

    if(WPsiMat==NULL) return COSTERROR;


    double Mat[36*MAXSTATDIP*MAXSTATDIP];
    for(int l1=0; l1<Nstf; l1++)
        for(int l2=0; l2<Nstf; l2++)
            if(l2>=l1)
            {
                Mat[l1*Nstf+l2] = 0.;
                for(int i=0; i<nKan; i++)
                    Mat[l1*Nstf+l2] += WPsiMat[l1*nKan+i]*WPsiMat[l2*nKan+i];
            }
            else
            {
                Mat[l1*Nstf+l2] = Mat[l2*Nstf+l1];
            }

/* Set eigenvalue threshold*/
    int NPosEigen = (GridEEG==NULL) ? pDipMan->GetNfreeSTFMEG() : Nstf;
    UMatrixSymmetric Jamat(Mat, Nstf, Nstf);
    if(Jamat.GetNPosEig(fabs(AMAT_THRESHOLD)) < NPosEigen && AMAT_THRESHOLD<0)
    {
        return COSTERROR; // Skip dipoles near midline
    }

    UMatrixSymmetric Jinv = Jamat.GetInverse(NPosEigen, 0);
    if(Jinv.GetError()!=U_OK || Jinv.GetMatrixArray()==NULL)
    {
        static int Nmessage = 0;
        if(Nmessage<10)
            CI.AddToLog("ERROR: ULocStatDip::UpdateBmat(). Computing pseudo-inverse. \n");
        Nmessage++;

        return COSTERROR;
    }

/* Post-multiply with ULamda to obtain PsiT F */
    const double* MatInv = Jinv.GetMatrixArray();
    for(int l=0; l<Nstf; l++)
    {
        for(int j=0; j<Ncomp; j++)
        {
            Bmat[l*Ncomp+j] = 0;
            for(int i=0; i<nKan; i++)
                Bmat[l*Ncomp+j] += WPsiMat[l*nKan+i]*ULamda[i*Nsamples+j];
        }
    }

/* Pre-multiply this matrix with MatInv and compute cost simultaneously */
    double cost = DataNorm;
    for(int j=0; j<Ncomp; j++)
    {
        double Help[6*MAXSTATDIP];
        for(int l1=0; l1<Nstf; l1++)
        {
            Help[l1] = 0;
            for(int l2=0; l2<Nstf; l2++)
                Help[l1] += MatInv[l1*Nstf+l2] * Bmat[l2*Ncomp+j];
        }

        for(int l2=0; l2<Nstf; l2++)
        {
            cost             -= Bmat[l2*Ncomp+j]*Help[l2];
            Bmat[l2*Ncomp+j]  = Help[l2];
        }
    }
    cost *= 100./DataNorm;
    return cost;
}

double ULocStatDip::UpdateDirection(void)
{
    if(pDipMan==NULL || pDipMan->GetError()!=U_OK) return COSTERROR;

    int           Nmom    = pDipMan->GetNfreeMoment();
    const double* WPsiMat = pDipMan->GetFieldMoment();
    if(Nmom<=0 || WPsiMat==NULL)
    {
        return COSTERROR;
    }

    int Nfree = Nmom/3; // Number dipoles with fixed orientations (double counting semi-symmetric)

    int Sindex[3*MAXDIPOLES];
    int l=0;
    int k=0;
    int s=0;
    for( ;l<Ndipoles; l++)
    {
        if(pDipMan->GetNfreeSTF(l)==1 || pDipMan->GetNfreeSTF(l)==2)
        {
            Sindex[k] = s;
            k++; s++;
            if(pDipMan->GetNfreeSTF(l)==2)
            {
                Sindex[k] = s;
                k++; s++;
            }
        }
        else
            s+=pDipMan->GetNfreeSTF(l);
    }

/* Compute BBT for the source time functions, corresponding to the dipoles with fixed orientations*/
    double BBT[4*MAXSTATDIP*MAXSTATDIP];
    for(int k1=0; k1<Nfree; k1++)
    {
        int s1 = Sindex[k1];

        for(int k2=0; k2<Nfree; k2++)
        {
            int s2 = Sindex[k2];

            if(k2>=k1)
            {
                BBT[k1*Nfree+k2] = 0.;
                for(int j=0; j<Ncomp; j++)
                    BBT[k1*Nfree+k2] += Bmat[s1*Ncomp+j]*Bmat[s2*Ncomp+j];
            }
            else
            {
                BBT[k1*Nfree+k2] = BBT[k2*Nfree+k1];
            }
        }
    }

/* Compute FBT for the source time functions, corresponding to the dipoles with fixed orientations*/
    for(int i=0; i<nKan; i++)
        for(int k=0; k<Nfree; k++)
        {
            FBT[i*Nfree+k] = 0;
            int s = Sindex[k];
            for(int j=0; j<Ncomp; j++)
                FBT[i*Nfree+k] += ULamda[i*Nsamples+j]*Bmat[s*Ncomp+j];
        }

/* Substract rotating dipole fields */

    double Amat[6*MAXSTATDIP*6*MAXSTATDIP];
    double Bvec[6*MAXSTATDIP];

    for(int m1=0; m1<Nmom; m1++)
    {
        int k1 = m1/3;
        for(int m2=0; m2<Nmom; m2++)
        {
            if(m2>=m1)
            {
                int k2 = m2/3;
                Amat[m1*Nmom+m2] = 0.;
                for(int i=0; i<nKan; i++)
                    Amat[m1*Nmom+m2] += WPsiMat[m1*nKan+i]*WPsiMat[m2*nKan+i];
                Amat[m1*Nmom+m2] *= BBT[k1*Nfree+k2];
            }
            else
            {
                Amat[m1*Nmom+m2] = Amat[m2*Nmom+m1];
            }
        }
        Bvec[m1] = 0;
        for(int i=0; i<nKan; i++)
            Bvec[m1] += WPsiMat[m1*nKan+i] * FBT[i*Nfree+k1];
    }

/* Solve system using truncate eigen value decomposition. */
    UMatrixSymmetric AA(Amat, Nmom, Nmom, true);
    UMatrix          BB(Bvec, Nmom, 1   );
    if(AA.GetError()!=U_OK || BB.GetError()!=U_OK)
    {
        static int Nmessage = 0;
        if(Nmessage<10)
            CI.AddToLog("ERROR: ULocStatDip::UpdateDirection(). Computing pseudo-inverse. \n");
        Nmessage++;
        return COSTERROR;
    }

    int NPosEigen = (GridEEG==NULL)? pDipMan->GetNfreeMomentMEG() : Nmom;

    UMatrix DD = AA.GetAxIsB(BB, NPosEigen);

/* Update directions in dipole manager*/
    pDipMan->UpdateDipoleMoments(DD.GetMatrixArray());

/* Compute cost in %*/
    double cost = DataNorm - GetTraceM1M2T(DD, BB);
    cost *= 100./DataNorm;

    return cost;
}

ErrorType ULocStatDip::UpdateFreeDipoles(const UDipole* DipoleArray)
/* Update the free dipole positions, using the UpdateFreeDipoles function of UDipoleManager */
{
    if(DipoleArray==NULL)
    {
        CI.AddToLog("ERROR: ULocStatDip::UpdateFreeDipoles(). NULL argument.\n");
        return U_ERROR;
    }
    return pDipMan->UpdateFreeDipoles(DipoleArray);
}

ErrorType ULocStatDip::ComputeCCRB(UMatrix& Sigma, bool StoicaMethod)
/*
This routine calculates the Constained Cramer Rao Bound for the source
parameters and the entries of the matrix S in R = Psi S  for the stationary
dipole model. The method to be used can be chosen from:
 if StoicaMethod == true:
    the method presented in Stoica & Ng 98.
 if StoicaMethod == false:
    augmented Hessian Matrix, as used in Huizenga & Molenaar 1994, equation (7).

NOT YET IMPLEMENTED: EEG data and rotating dipoles
The tangentiality constraints change when EEG data is taken into account.
*/
{
    CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). FUNCTION NOT PROPERLY UPDATED. DOES N O T WORK. \n");
    return U_ERROR;

    if(Ftype!=UEMfield::U_MEG)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Called for EEG data. Not implemented (yet).\n");
        return U_ERROR;
    }

    for(int p=0;p<pDipMan->GetNDipoles();p++)
    {
        if((pDipMan->GetFreeDipole(p)).AreMomentsRotating() == true)
        {
            CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Called for rotating dipoles.Nor implemented (yet).\n");
            return U_ERROR;
        }
    }

    if(StoicaMethod ==true)
        CI.AddToLog("NOTE: Estimate parameter covariance with CCRB from Stoica method.\n");
    else if(StoicaMethod ==false)
        CI.AddToLog("NOTE: Estimate parameter covariance with augmented matrix method.\n");
    else
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Invalid parameter for selecting method for estimation of parameter covariance.\n");
        return U_ERROR;
    }

    int     nFreeSTF   = pDipMan->GetNfreeSTF();
    int     nDipoles   = pDipMan->GetNDipoles();
    int     nSourcePar = pDipMan->GetNfreeMoment()+pDipMan->GetNfreePosPars();
    UMatrix Field      = UMatrix(pDipMan->GetFieldSTF(),nKan,nFreeSTF);

/* Compute the derivative of forward field UMatrix Field w.r.t. source parameters */
/////////////////
/* Adapt for rotating dipoles, then this derivative will change? */
/////////////////
    int     DFieldDim  = nKan*nFreeSTF*nSourcePar;
    double* DField     = new double[DFieldDim];
    for(int j=0;j<DFieldDim;j++) DField[j]=0.;

    UDipole* DipArray = new UDipole[nDipoles];
    pDipMan->GetFreeDipoles(DipArray);
    int p=0;
    int s=0;
    int m=0;
    for( ;p<nDipoles;p++,s++) // p: dipole-index, s: stf-index, m: source parameter-index
    {
        UDipole::DipoleType DT = DipArray[p].GetDipoleType();

        switch(DT)
        {
        case UDipole::Current :
            {
            /* Position derivatives */
            double* bf = Emf.GetBfield(&DipArray[p],D_OriPos01);
            int i=0;
            for(;i<nKan;i++)
                for(int mm=m;mm<m+3;mm++)
                    DField[(s*nKan+i)*nSourcePar+mm] = bf[i*3+mm-m];
            m+=3;
            delete[] bf;

            /* Orientation derivatives */
            bf = Emf.GetBfield(&DipArray[p],D_OriPos10);
            i=0;
            for(;i<nKan;i++)
                for(int mm=m;mm<m+3;mm++)
                    DField[(s*nKan+i)*nSourcePar+mm] = bf[i*3+mm-m];
            m+=3;
            delete[] bf;
            break;
            }

        case UDipole::SymmetricPos :
            {
            /* Position derivatives */
            double* bf = Emf.GetBfield(&DipArray[p],D_OriPos11);
            double* PosDer = new double[2*nKan*3];
            double MomentLeft[3]  = {DipArray[p].Getd().Getx(),
                                     DipArray[p].Getd().Gety(),
                                     DipArray[p].Getd().Getz()};
            double MomentRight[3] = {DipArray[p].GetdSym().Getx(),
                                     DipArray[p].GetdSym().Gety(),
                                     DipArray[p].GetdSym().Getz()};
            int i=0;
            for(;i<6*nKan;i++) PosDer[i]=0.;
            i=0;
            for(;i<nKan;i++)
                for(int dx=0;dx<3;dx++)
                    for(int mx=0; mx<3;mx++)
                    {
                        PosDer[i*3+dx]        += bf[i*18+dx*3+mx]*MomentLeft[mx];
                        PosDer[(i+nKan)*3+dx] += bf[i*18+9+dx*3+mx]*MomentRight[mx];
                    }

            int ss=0;
            for(;ss<2;ss++)
                for(int i=0;i<nKan;i++)
                    for(int mm=m;mm<m+3;mm++)
                        DField[((s+ss)*nKan+i)*nSourcePar+mm] = PosDer[(ss*nKan+i)*3+mm-m];
            m+=3;
            delete[] bf;
            delete[] PosDer;

            /* Orientation derivatives */
            bf = Emf.GetBfield(&DipArray[p],D_OriPos10);
            ss=0;
            for(;ss<2;ss++)
                for(int i=0;i<nKan;i++)
                    for(int mm=m;mm<m+3;mm++)
                        DField[((s+ss)*nKan+i)*nSourcePar+ss*3+mm] = bf[i*6+ss*3+mm-m];
            m+=6;
            s++;
            delete[] bf;
            break;
            }

        case UDipole::Symmetric :
        default:
            {
                CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Invalid Dipole Type or not implemented.\n");
                return U_ERROR;
            }
        }
    }

    if(p!=nDipoles || s!= nFreeSTF || m!= nSourcePar)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Error in loop for DA.");
        return U_ERROR;
    }
    UMatrix DFld = UMatrix(DField, nKan*nFreeSTF,nSourcePar);

/* Compute the derivative of the constraints w.r.t. all parameters in Con(*double)
    and make UMatrix C */
////////////////////
/*Check for rotating dipoles, then nConstraint should be adapted */
/*Check for not "MEG only", the tangentiality constraint vanishes*/
////////////////////

    int     nMoments    = pDipMan->GetNfreeMoment();
    int     nPar        = nSourcePar + nFreeSTF*Nsamples;
    int     nConstraint = 2*nFreeSTF;
    double* Con = new double[nConstraint*nPar];
    p=0;
    for( ;p<nConstraint*nPar;p++) Con[p]=0.;

/* Compute derivative of tangentiality and normality constraint w.r.t. source pars */
    for(p=0,s=0,m=0;p<nDipoles;p++,s++) // p: dipole-index, s: constraint index
                                        // m: source parameter-index
    {
        UDipole::DipoleType DT = DipArray[p].GetDipoleType();
        switch(DT)
        {
        case UDipole::Current :
            {
         /* Position derivatives of tangentiality constraint */
            Con[s*nPar+m+0] = DipArray[p].Getd().Getx();
            Con[s*nPar+m+1] = DipArray[p].Getd().Gety();
            Con[s*nPar+m+2] = DipArray[p].Getd().Getz();
            m+=3;
         /* Orientation derivatives of tangentiality constraint */
            Con[s*nPar+m+0] = DipArray[p].Getx().Getx();
            Con[s*nPar+m+1] = DipArray[p].Getx().Gety();
            Con[s*nPar+m+2] = DipArray[p].Getx().Getz();
            s++;
         /* Orientation derivatives of normality constraint */
            Con[s*nPar+m+0] = 2*DipArray[p].Getd().Getx();
            Con[s*nPar+m+1] = 2*DipArray[p].Getd().Gety();
            Con[s*nPar+m+2] = 2*DipArray[p].Getd().Getz();
            m+=3;
            break;
            }
        case UDipole::SymmetricPos :
            {
        /* Position derivatives for Left tangentiality constraint */
            Con[s*nPar+m+0] = DipArray[p].Getd().Getx();
            Con[s*nPar+m+1] = DipArray[p].Getd().Gety();
            Con[s*nPar+m+2] = DipArray[p].Getd().Getz();
        /* Orientation derivatives for Left tangentiality constraint */
            Con[s*nPar+m+3] = DipArray[p].Getx().Getx();
            Con[s*nPar+m+4] = DipArray[p].Getx().Gety();
            Con[s*nPar+m+5] = DipArray[p].Getx().Getz();
            s++;
        /* Orientation derivatives for Left normality constraint */
            Con[s*nPar+m+3] = 2*DipArray[p].Getd().Getx();
            Con[s*nPar+m+4] = 2*DipArray[p].Getd().Gety();
            Con[s*nPar+m+5] = 2*DipArray[p].Getd().Getz();
            s++;
        /* Position derivatives for Right tangentiality constraint */
            Con[s*nPar+m+0] =   DipArray[p].GetdSym().Getx();
            Con[s*nPar+m+1] = -(DipArray[p].GetdSym().Gety());
            Con[s*nPar+m+2] =   DipArray[p].GetdSym().Getz();
        /* Orientation derivatives for Right tangentiality constraint */
            Con[s*nPar+m+6] =   DipArray[p].Getx().Getx();
            Con[s*nPar+m+7] = -(DipArray[p].Getx().Gety());
            Con[s*nPar+m+8] =   DipArray[p].Getx().Getz();
            s++;
        /* Orientation derivatives for Right normality constraint */
            Con[s*nPar+m+6] = DipArray[p].GetdSym().Getx();
            Con[s*nPar+m+7] = DipArray[p].GetdSym().Gety();
            Con[s*nPar+m+8] = DipArray[p].GetdSym().Getz();
            m+=9;
            break;
            }
        case UDipole::Symmetric :
        default:
            {
            CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Invalid Dipole Type or not implemented.\n");
            return U_ERROR;
            }
        }
    }
    if(p!=nDipoles || s!= nConstraint || m!= nSourcePar)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeCCRB(). Error in loop for derivatives in F.");
        return U_ERROR;
    }
    UMatrix C = UMatrix(Con,nConstraint,nPar);
    delete[] Con;

/* Calculate the estimated source time function matrix S = B * VT * Wmatinv */
    UMatrix H1;
    UMatrix S, B, V, VT;
    UMatrixSymmetric Tinv;

    UMatrix Lamda = CovTT->GetLamda();
    B  = UMatrix(Bmat,nFreeSTF,Ncomp);
    V  = UMatrix(Vmat,Nsamples,Nsamples);
    VT = UMatrix((V.GetTranspose()).GetMatrixArray(),Ncomp,Nsamples);
    S  = B * VT;       //now S = B * VT taking only dimension Ncomp into account in multiplication
    //if(Eigen)
    //{
    //    Tinv = UMatrix(CovTT->GetWmatArray(), Nsamples, Nsamples);
    //    H1   = Tinv.GetInverse();     // H1   = Wmatinv
    //    S    = S * H1;                // S    = B * VT * Wmatinv
    //    Tinv = Tinv.GetMMT();         // Tinv = Wmat * WmatT
    //}
    //else Tinv = UMatrix(Nsamples);    // then T == Identity and Smat is already correct

/* Calculate the Fisher Information Matrix in UMatrix FIM */
    UMatrix FTF, H2, I_SS, I_TT, I_ST, Col1, Col2, FIM; // FIM and help matrices

    FTF  =  Field.GetTranspose() * Field;
    H1   = (S * Tinv) * S.GetTranspose();     //H1= S Tinv S^t
    H1   =  UMatrix(H1,UMatrix(nKan));        //H1= S Tinv S^t (x) Id(nKan)
    I_SS = (DFld.GetTranspose() * H1) * DFld; //I_SS= DFU^t [S Tinv S^t (x) Id(nKan)] DFU is left upper corner
    H2   =  UMatrix(Tinv) * S.GetTranspose();          //H3 = Tinv S^t
    H1   =  UMatrix(H2,Field.GetTranspose()); //H1 = Tinv S^t (x) Psi^t
    I_ST =  H1 * DFld;                        //I_ST is left lower corner
    I_TT =  UMatrix(Tinv,FTF);                //I_TT is right lower corner
    Col1 = I_SS.GetConcatRows(I_ST.GetTranspose()); if(Col1.GetError()!=U_OK) return U_ERROR;
    Col2 = I_ST.GetConcatRows(I_TT               ); if(Col2.GetError()!=U_OK) return U_ERROR;
    Col1.Transpose();
    Col2.Transpose();
    FIM  = Col1.GetConcatRows(Col2);                if(FIM .GetError()!=U_OK) return U_ERROR; //FIM is the Fisher Information Matrix

/* Calculate the Stoica matrix */
    if(StoicaMethod ==true)
    {
    /* Create matrix U with orthogonal columns, such that CU = 0 */
        UMatrix U  = C.GetOrthogonalBasis(); if(U.GetError()!=U_OK) return U_ERROR;  // now U is nSourcePar by (nSourcePar-nConstraint)
        UMatrix UT = U.GetTranspose();

    /* Compute the Constrained Cramer Rao Bound : U*inv(U^t I U)*U^t */
        UMatrixSymmetric H1    = (UT * FIM) * U;
        H2    = H1.GetInverse();
        Sigma = (U * H2) * UT;

        return U_OK;
    }

/* Calculate the augmented CCRBAug, invert in AugInv and select the left upper corner as Sigma */
    else
    {
        UMatrixSymmetric CCRBAug, AugInv;
        UMatrix CTC = C.GetTranspose() * C;

    /* Scale the FMat matrix, such that inversion is numerically stable*/
        double ScaleCTC = CTC.GetSingValue(0);
        double ScaleFIM = FIM.GetSingValue(0);
        if(fabs(ScaleCTC)<1.e-11) return U_ERROR;
        
        CTC*=(ScaleFIM/ScaleCTC);
        C  *=(sqrt(ScaleFIM/ScaleCTC));

    /* Augment the matrix */
        FIM += CTC;
        H1   = FIM.GetConcatRows(C.GetTranspose());                             if(H1.GetError()!=U_OK) return U_ERROR;
        H2   = C  .GetConcatRows(UMatrix((double*)NULL, 2*(nMoments/3),2*(nMoments/3))); if(H2.GetError()!=U_OK) return U_ERROR;
        H1.Transpose();
        CCRBAug = H1.GetConcatRows(H2.GetTranspose());                     if(CCRBAug.GetError()!=U_OK) return U_ERROR;

    /* Invert the augmented matrix */
        AugInv = CCRBAug.GetInverse();

    /* Select upper left corner */
        Sigma = AugInv.GetBlock(0,0,nPar,nPar);                            if(Sigma.GetError()!=U_OK) return U_ERROR;

        return U_OK;
    }
    return U_ERROR;
}

ErrorType ULocStatDip::ComputeConfIntervals(double* ConfInt, bool Bonferroni, double pval, bool StoicaMethod)
/* This routine computes the confidence intervals around all
    estimated source time functions, per sample. The intervals
    are output to the array ConfInt.
    By default pvalue       = 0.05.
    By default StoicaMethod = false.
*/
{
/* Check arguments */
    if(pval<0 || pval>1 || !ConfInt)
    {
        CI.AddToLog("ERROR:ULocStatDip::ComputeConfIntervals(). Invalid argument.\n");
        return U_ERROR;
    }

/* Compute Constrained CRB for all parameters, (source par, vec(S)) */
    UMatrix Sigma;
    if(ComputeCCRB(Sigma,StoicaMethod) != U_OK)
    {
        CI.AddToLog("ERROR: ULocStatDip::ComputeConfIntervals(). Computing CCRB.\n");
        return U_ERROR;
    }

/* Compute the prewhitened residual error */
    int     nFreeSTF  = pDipMan->GetNfreeSTF();

    UMatrix VmatMat, VmatTMat, DataMat,PsiTPsiMat, ModelMat, FieldMat, BmatMat, ResMat;

    VmatMat    =  UMatrix(Vmat,Nsamples,Nsamples);
    VmatTMat   =  UMatrix((VmatMat.GetTranspose()).GetMatrixArray(),Ncomp,Nsamples);
    DataMat    =  UMatrix(EMData, nKan, Nsamples);
    FieldMat   =  UMatrix(pDipMan->GetFieldSTF(),nFreeSTF,nKan);
    FieldMat   =  FieldMat.GetTranspose();
    PsiTPsiMat =  FieldMat.GetMTM(); if(PsiTPsiMat.GetError()!=U_OK) return U_ERROR;
    BmatMat    =  UMatrix(Bmat,nFreeSTF,Ncomp);
    ModelMat   = (FieldMat * BmatMat) * VmatTMat; //ModelMat = FieldMat * Bmat * VmatT, taking only dimension Ncomp in the multiplication
    ResMat     =  DataMat - ModelMat;
    double reserror = ResMat.GetFrobNorm2();

    int nSourcePar = pDipMan->GetNfreeMoment()+pDipMan->GetNfreePosPars();
    double v2 = nKan*Nsamples - nSourcePar - nFreeSTF*Nsamples;

    double p = pval;
    if(Bonferroni)
        p /=(nSourcePar+nFreeSTF*Nsamples);

    double x_bound = 0.5;
    double x_low   = 0.5;
    double x_up    = 1.0;
    double p_b     = betai(v2/2.,0.5,x_bound);


    while (fabs(p_b-p)>1e-05)
    {
        if(p_b > p) x_up  = x_bound;
        else           x_low = x_bound;
        x_bound = x_low + (x_up-x_low)/2;
        p_b = betai(v2/2,0.5,x_bound);
    }
    double Fbound = v2*(1-x_bound)/x_bound;

    for(int p=0;p<nFreeSTF;p++)
    {
        for(int j=0;j<Nsamples;j++)
        {
            double cov            = Sigma.GetElement(nSourcePar+j*nFreeSTF+p,nSourcePar+j*nFreeSTF+p);
            ConfInt[p*Nsamples+j] = sqrt(Fbound*cov*(reserror/v2));
        }
    }
    return U_OK;
}

ErrorType UFitDipoles::FitStationaryDipoles(UFileName HeadModelFileName, const char* ChanName, UStartStatDip::StartType ST, UFileName StartFile, int NGlobPoints, int Ndipoles, UDipole::DipoleType DType, bool Rdips, ULocStatDip::CostType CT, bool AdFordMod, bool UseOldUnits, FitDataType FDT)
{
/* Test whether data is read and epochs are set.*/
    if(Data==NULL || Epochs==NULL)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Data not set.\n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Epoch times not constant.\n");
        return U_ERROR;
    }
    if( (FDT==U_MEG_AND_EEG || FDT==U_EEG_ONLY) && Data->AreEEGPositionsMeasured()==false)
    {
        CI.AddToLog("WARNING: UFitDipoles::FitStationaryDipoles(). EEG dipole fitting is based on default electrode positions. True EEG sensor positions not set.\n");
    }

/* Set head model*/
    UHeadModel* HModel=GetHeadModel(HeadModelFileName, FDT);
    if(HModel==NULL || HModel->GetError()!=U_OK) return U_ERROR;

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdFordMod==true)
        ReRefForw = GetMEGForwardBalancing();

/* Spatial covariance */
    UCovariance CovXX;
    if(CT==ULocStatDip::U_GLSSPACE||CT==ULocStatDip::U_GLSSPACETIME)
        CovXX = UCovariance(GetSpatCovarianceFile(), Data->GetGridMEG(), Data->GetGridEEG());
    else
    {
        if(FDT==U_MEG_AND_EEG && Data->GetGridMEG() && Data->GetGridEEG())
            CovXX = UCovariance(Data->GetGridMEG()->GetNpoints(), Data->GetGridEEG()->GetNpoints(), ULocStatDip::OLS_REL_EEG_VARIANCE);
        else if(FDT==U_MEG_ONLY && Data->GetGridMEG())
            CovXX = UCovariance(Data->GetGridMEG()->GetNpoints());
        else if(FDT==U_EEG_ONLY && Data->GetGridEEG())
            CovXX = UCovariance(Data->GetGridEEG()->GetNpoints());
        else
        {
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Data grids not consistent with requested fit data types. \n");
            return U_ERROR;
        }
    }
    if(CovXX.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Creating Spatial covariance. \n");
        return U_ERROR;
    }

/* Temporal covariance */
    UCovariance CovTT(GetNSampEpoch(0));
    if(CT==ULocStatDip::U_GLSTIME || CT==ULocStatDip::U_GLSSPACETIME)
    {
        CovTT = UCovariance(GetTempCovarianceFile(), GetNSampEpoch(0));
        if(CovTT.GetError()!=U_OK) error = U_ERROR;
        {
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Creating Spatial covariance. \n");
            return U_ERROR;
        }
    }

/* Set the stationary dipole object*/
    ULocStatDip*  ULSD = NULL;
    switch(FDT)
    {
    case U_MEG_AND_EEG:
        if(Data->GetGridMEG()==NULL) CI.AddToLog("WARNING: UFitDipoles::FitStationaryDipoles(). Required MEG data not present in dataset. \n");
        if(Data->GetGridEEG()==NULL) CI.AddToLog("WARNING: UFitDipoles::FitStationaryDipoles(). Required EEG data not present in dataset. \n");
        ULSD = new ULocStatDip(cost, UseOldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), Data->GetGridMEG(), Data->GetGridEEG(), HModel, &CovXX, &CovTT);
        break;
    case U_MEG_ONLY:
        if(Data->GetGridMEG()==NULL) CI.AddToLog("WARNING: UFitDipoles::FitStationaryDipoles(). Required MEG data not present in dataset. \n");
        ULSD = new ULocStatDip(cost, UseOldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), Data->GetGridMEG(), NULL, HModel, &CovXX, &CovTT);
        break;
    case U_EEG_ONLY:
        if(Data->GetGridEEG()==NULL) CI.AddToLog("WARNING: UFitDipoles::FitStationaryDipoles(). Required EEG data not present in dataset. \n");
        ULSD = new ULocStatDip(cost, UseOldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), NULL, Data->GetGridEEG(), HModel, &CovXX, &CovTT);
        break;
    }

    if(ULSD==NULL || ULSD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Cannot create ULocStatDip-object\n");
        delete ULSD;
        return U_ERROR;
    }

/* Test the size of the windows*/
    if(CT!=ULocStatDip::U_SQUARE && CT!=ULocStatDip::U_GLSSPACE)
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Epoch times should be equal in case of temporal covariance.\n");
            delete ULSD;
            return U_ERROR;
        }
    }

    if(ULSD->InitStart(ST, StartFile, NGlobPoints, Ndipoles, DType, Rdips)!=U_OK)
    {
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Initializing start parameters. \n");
        delete ULSD;
        return U_ERROR;
    }

    int NsampPTrial  = Data->GetNsampTrial();
    FILE*      fpOut = NULL;
    if(OneFile==true)  fpOut = fopen(FileNameOut,"wt", true);

/* Fit stationary dipoles on all epochs*/
    for(int m=0; m<GetNEpoch(); m++)
    {
        UEvent   Begin      = Epochs->GetBegin(m);
        UEvent   End        = Epochs->GetEnd(m);
        int      NsampEp    = GetNSampEpoch(m);

        UDipole  Dipoles[MAXSTATDIP];
        double   Residual  = 0;
        double  *DataNorm  = new double[NsampEp];
        int      Nstf      = ULSD->GetNfreeSTF();
        double  *STF       = new double[Nstf*NsampEp];

        if(!DataNorm || !STF)
        {
            delete[] DataNorm;
            delete[] STF;
            delete ULSD;
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Memory allocation. \n");
            if(OneFile==true) fclose(fpOut);
            return U_ERROR;
        }

/* Get Data. */
        double  *DataEpMEG = NULL;
        double  *DataEpEEG = NULL;
        double  *DataEpADC = NULL;
        switch(FDT)
        {
        case U_MEG_AND_EEG:
            DataEpMEG = GetFilteredData(m, U_DAT_MEG);
            DataEpEEG = GetFilteredData(m, U_DAT_EEG);
            break;
        case U_MEG_ONLY:
            DataEpMEG = GetFilteredData(m, U_DAT_MEG);
            break;
        case U_EEG_ONLY:
            DataEpEEG = GetFilteredData(m, U_DAT_EEG);
            break;
        }
        if( ( (!DataEpMEG && FDT==U_MEG_AND_EEG) || (!DataEpMEG && FDT==U_MEG_ONLY) )||
            ( (!DataEpEEG && FDT==U_MEG_AND_EEG) || (!DataEpEEG && FDT==U_EEG_ONLY) )||
            (ULSD->SetData(DataEpMEG, DataEpEEG, NsampEp)!=U_OK) )
        {
            delete[] DataEpMEG;
            delete[] DataEpEEG;
            delete[] DataNorm;
            delete[] STF;
            delete ULSD;
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Reading/preparing the filtered MEG/EEG data in epoch %d .\n",m);

            if(OneFile==true) fclose(fpOut);
            return U_ERROR;
        }
        DataEpADC = GetFilteredData(m, U_DAT_ADC);

/* Compute dipoles*/
        if(ULSD->ComputeDipoles(Dipoles, Ndipoles, &Residual, DataNorm, STF)!=U_OK)
        {
            delete[] DataEpMEG;
            delete[] DataEpEEG;
            delete[] DataNorm;
            delete[] STF;
            delete ULSD;
            CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Computing dipoles in ULSD-object (epoch %d) .\n",m);

            if(OneFile==true) fclose(fpOut);
            return U_ERROR;
        }

        bool Bonferroni = false;
        double* ConfInt = new double[Ndipoles*2*NsampEp];
        double  pvalue  = 0.05;
        if(Rdips==false) ULSD->ComputeConfIntervals(ConfInt,Bonferroni,pvalue);

        int nKan = 0;
        if(FDT==U_MEG_ONLY)         nKan = Data->GetNmeg();
        else if(FDT==U_MEG_AND_EEG) nKan = Data->GetNmeg() + Data->GetNeeg();
        else if(FDT==U_EEG_ONLY)    nKan = Data->GetNeeg();

/* Export results*/
        if(OneFile==false)
        {
            FileNameOut.InsertFileNumber(m,3);
            fpOut = fopen(FileNameOut,"wt", true);
        }
        if(m==0||OneFile==false)
        {
            fprintf(fpOut,"// GENERAL:\n");
            fprintf(fpOut,"//   Results obtained with\n");
            fprintf(fpOut,"%s",(const char*)CI.GetProperties("//   "));
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA:\n");
            fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
            fprintf(fpOut,"//\n");
            if(GetMarkerArray())
            {
                fprintf(fpOut,"//\n");
                fprintf(fpOut,"// DATA MARKERS:\n");
                fprintf(fpOut,"%s",(const char*)GetMarkerArray()->GetProperties("//  "));
            }
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// EPOCHS:\n");
            if(OneFile==false)
                fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
            else
            {
                if(Epochs->GetnEpochs()<10)
                {
                    for(int k=0; k<Epochs->GetnEpochs(); k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                            k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                               Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                }
                else
                {
                    for(int k=0; k<9; k++)
                            fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                            k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                               Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                    fprintf(fpOut,"//   ..., Etc. \n");
                }
            }
            fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// FITTING:\n");
            fprintf(fpOut,"//   %s\n",(const char*)cost.GetParameterString());
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"%s", (const char*)ULSD->GetProperties("//  "));
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// HEAD MODEL:\n");
            fprintf(fpOut,"%s",(const char*)HModel->GetProperties("//  "));
            fprintf(fpOut,"//\n");
            if(ConfInt)
            {
                fprintf(fpOut,"// Confidence intervals computed using p-value = %f.\n",pvalue);
                if(Bonferroni)
                    fprintf(fpOut,"// Bonferroni correction applied: YES.\n");
                else
                    fprintf(fpOut,"// Bonferroni correction applied: NO.\n");
            }
            fprintf(fpOut,"//\n");
        }
        const double *DataChannel = GetDataChannel(DataEpMEG, DataEpEEG, DataEpADC, NsampEp, ChanName);
        double *StdErrMean        = NULL;

        char line[200+100*MAXSTATDIP];
        int  nc=0;
        if(m==0||OneFile==false)
        {
            if(TimeInMs==false) nc += sprintf(line,"Samp");
            else                nc += sprintf(line,"Time");

            for(int l=0; l<Ndipoles; l++)
                nc += Dipoles[l].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

            if(Rdips==false)
            {
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<Ndipoles; l++) nc += sprintf(line+nc,"\tSTF_L%d ",l);
                    for(int l=0; l<Ndipoles; l++) nc += sprintf(line+nc,"\tSTF_R%d ",l);
                }
                else
                {
                    for(int l=0; l<Ndipoles; l++) nc += sprintf(line+nc,"\tSTF%d ",l);
                }
            }

            nc += sprintf(line+nc,"\tERROR(%%)");
            nc += sprintf(line+nc,"\tAverDataPower");
            if(StdErrMean) nc += sprintf(line+nc,"\tStdErrMean");
            if(DataChannel)
            {
                nc += sprintf(line+nc,"\tChan=%s",ChanName);
            }
            else if(ChanName && ChanName[0]!=0)
            {
                fprintf(fpOut,"// Warning: Required channel %s not in file.\n",ChanName);
            }
            if(Rdips==false)
            {
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<Ndipoles; l++)nc += sprintf(line+nc,"\tConfInt_L%d ",l);
                    for(int l=0; l<Ndipoles; l++)nc += sprintf(line+nc,"\tConfInt_R%d ",l);
                }
                else
                {
                    for(int l=0; l<Ndipoles; l++)
                        nc += sprintf(line+nc,"\tConfInt%d ",l);
                }
            }
            fprintf(fpOut,"%s\n",line);
        }
        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

        for(int i=0; i<NsampEp; i++)
        {
            UEvent E = GetEvent(m, i);
            nc       = 0;
            if(TimeInMs==false)
                nc += sprintf(line,"%6.6d   ",E.GetAbsSample(NsampPTrial));
            else
                nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(NsampPTrial));

            if(Rdips==false)
            {
                for(int l=0; l<Ndipoles; l++)
                    nc += Dipoles[l].PrintParameters(line+nc,200+100*MAXSTATDIP-nc-1);
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<2*Ndipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",STF[l*NsampEp+i]);
                }
                else
                {
                    for(int l=0; l<Ndipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",STF[l*NsampEp+i]);
                }
            }
            else
            {
                for(int l=0; l<Ndipoles; l++)
                {
                    UDipole DD    = Dipoles[l];
                    if(DType==UDipole::SymmetricPos)
                    {
                        double  dd[6] = {STF[(6*l  )*NsampEp+i], STF[(6*l+1)*NsampEp+i], STF[(6*l+2)*NsampEp+i],STF[(6*l+3)*NsampEp+i], STF[(6*l+4)*NsampEp+i], STF[(6*l+5)*NsampEp+i]};
                        DD.Setd(UVector3(dd));
                        DD.SetdSym(UVector3(dd+3));
                    }
                    else
                    {
                        double  dd[3] = {STF[(3*l  )*NsampEp+i], STF[(3*l+1)*NsampEp+i], STF[(3*l+2)*NsampEp+i]};
                        DD.Setd(UVector3(dd));
                        dd[1] = -dd[1];
                        DD.SetdSym(UVector3(dd));
                    }
                    nc += DD.PrintParameters(line+nc,200+100*MAXSTATDIP-nc-1);
                }
            }
            nc += sprintf(line+nc,"\t%f",Residual);
            if(nKan)
                nc += sprintf(line+nc,"\t%f",DataNorm[i]/nKan);
            else
                nc += sprintf(line+nc,"\t0.0");
            if(StdErrMean)  nc += sprintf(line+nc,"\t%f",StdErrMean[i]);
            if(DataChannel) nc += sprintf(line+nc,"\t%f",DataChannel[i]);

            if(Rdips==false)
            {
                if(DType==UDipole::SymmetricPos)
                {
                    for(int l=0; l<2*Ndipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",ConfInt[l*NsampEp+i]);
                }
                else
                {
                    for(int l=0; l<Ndipoles; l++)
                        nc += sprintf(line+nc,"\t%f ",ConfInt[l*NsampEp+i]);
                }
            }

            fprintf(fpOut,"%s\n",line);
        }

        delete[] DataNorm;
        delete[] ConfInt;
        delete[] STF;
        delete[] DataEpMEG;
        delete[] DataEpEEG;
        delete[] DataEpADC;
        delete[] StdErrMean;
        if(OneFile==false) fclose(fpOut);
    }
    if(OneFile==true) fclose(fpOut);

    delete ULSD;

    return U_OK;
}

