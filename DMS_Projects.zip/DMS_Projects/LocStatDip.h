#ifndef _LOCSTATDIP_INCLUDED
#define _LOCSTATDIP_INCLUDED

#include "Minimize.h"
#include "Covariance.h"
#include "StartStatDip.h"
#include "EMfield.h"
#include "Matrix.h"
#include "DipoleEditList.h"

#define MAXSTATDIP  6


class ULocStatDip : public UStartStatDip, public Uminimize
{
public:
    enum CostType {U_SQUARE, U_GLSSPACE, U_GLSTIME, U_GLSSPACETIME};
   
    ULocStatDip(const UCostminimize& cost, bool UseOU, ReReferenceType ReRefForw, const UGrid* GridR, const UBalance** pBal, const UGrid* gridM, const UGrid* gridE, const UHeadModel *Hmod, 
        const UCovariance* CovarXX, const UCovariance* CovarTT);

    virtual ~ULocStatDip();
    ErrorType           GetError() const {return error;}
    const UString&      GetProperties(UString Comment) const;

    ErrorType           SetCovariance(const UCovariance* CovNewXX, const UCovariance* CovNewTT);
    ErrorType           SetData(const double *DataMEG, const double *DataEEG, int nsamp);
    const double*       GetSV(void)       const {return SV;}
    double              GetDataNorm(void) const {return DataNorm;}
    ErrorType           SetNcomp(int ncmp, double thres);


    ErrorType           ComputeDipoles(UDipole* DipArray,  int Ndip, double *residual, double* DataNorm, double *STF);
    ErrorType           ComputeDipoles(UDipoleEdit* DipEd, int Ndip, double *residual, double* DataNorm, double *STF);
    int                 GetNtotCost(void) const     {return NtotCost;}
    
    double              ComputeCost(double *par, int iter=0, int *status=NULL, double *grad=NULL);
/* Required (=pure virtual in Uminimize() and in UStartDipole()): */
    double              ComputeCost(double *par, int iter, int *status) 
                        {
                            return ComputeCost(par, iter, status, NULL);
                        }

    ErrorType           CompMatInv(double* AmatInv, double* LeadField) const;
    ErrorType           ComputeConfIntervals(double* ConfInt, bool Bonfer=false, double pval=0.05, bool StoicaMethod=false);
    ErrorType           ComputeCCRB(UMatrix& Sigma_C, bool StoicaMethod=false); 
    
    ErrorType           UpdateFreeDipoles(const UDipole* DipoleArray);

    static const double OLS_REL_EEG_VARIANCE;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;
    static const double COSTERROR;
    static const double AMAT_THRESHOLD;
    static const int    MAXLINITER;
    static const double COV_THRESHOLD;

    ErrorType           error;        // General error
    bool                UseOldUnits;  // Use units in dipole strength according UEmfield() // after 22-08-03

/* MEG parameters*/
    int                 nMEG ;        // The number of MEG channels == GridMEG->GetNpoints()
    const UGrid*        GridMEG;      // Array of MEG sensors
/* EEG parameters*/
    int                 nEEG ;        // The number of EEG channels == GridEEG->GetNpoints()
    const UGrid*        GridEEG;      // Array of EEG sensors

/* General (EEG/MEG) */ 
    UEMfield::FieldType Ftype; // Modality used: MEG, EEG or both
    int                 Nsamples;     // Number of samples per channel, present in DataMEG/DataEEG
    int                 Ndipoles;     // Number of stationary dipoles
    int                 Ncomp;        // Number of components used in SVD of data matrix
    UCovariance*        CovTT;        // The (theoretical) temporal covariance
    UCovariance*        CovXX;        // The (theoretical) spatial covariance for the MEG/EEG sensors

/* Help arrays*/
    double*             EMData;       // Pre-whitened E/MEG data, first MEG then EEG channels
    double*             ULamda;       // SVD-Decomposition of EMData:    
    double*             Lamda;        //    EMData = Umat * Lamda * VmatT = ULamda * VmatT
    double*             Vmat;         // 
    double*             SV;           // Normalize singular values (in % of data power of EMData[])
    double*             Bmat;         // 'Rotated' Source time functions
    double*             FBT;          // ULamda * BmatT
    double**            WmatTfld;     // General purpose pointer to EM fields of different dipoles

    int                 NtotCost;     // The total number of calls to ComputeCost(), starting from constructor    
    double              DataNorm;     // Sum of (weighed) squares of EMData[]

    double              UpdateBmat(void) const;
    double              UpdateDirection(void);

    double              ComputeCost(const double* const* WEMdat, double FitTest=0.999999);
    double*             GetPrewGetEMfield(const UDipole* Dip);    
};

#endif // _LOCSTATDIP_INCLUDED
