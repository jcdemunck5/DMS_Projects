#ifndef _LOCSTATDIP_INCLUDED
#define _LOCSTATDIP_INCLUDED

#include "Minimize.h"
#include "Covariance.h"
#include "StartDipole.h"
#include "EMfield.h"

#define MAXSTATDIP  4


class ULocStatDip : public UStartDipole, public Uminimize
{
public:
    static const int    MAXPROPERTIES;

    ULocStatDip(const UCostminimize& cost, UGrid* gridM, UGrid* gridE, UHeadModel *Hmod, 
               const char* CovarXXFile, const char* CovarTTFile);
    ~ULocStatDip();
    ErrorType      GetError() const {return error;}

    ErrorType      SetData(double *DataMEG, double *DataEEG, int nsamp);
    ErrorType      SetNcomp(int ncmp);
    char*          GetProperties(const char *Comment);

    ErrorType      ComputeDipoles(UDipole* DipArray, int Ndip, double *residual);
    int            GetNtotCost(void) const     {return NtotCost;}
//// necessary for SimulateDipoles
    const double*  GetSV(void) const {return SV;}
////    
    double         ComputeCost(double *par, int iter=0, int *status=NULL, double *grad=NULL);
/* Required (=pure virtual in Uminimize() and in UStartDipole()): */
    double         ComputeCost(double *par, int iter, int *status) 
                   {
                       return ComputeCost(par, iter, status, NULL);
                   }
    ErrorType      CompMatInv(double* AmatInv, double* LeadField) const;
    const double*  GetDirection(void) const {return Direction;}

private:
    static double const COSTERROR;
    static double const AMAT_THRESHOLD;

    ErrorType    error;        // General error
    char*        Properties;   // Properties in text format

/* MEG parameters*/
    UGrid*       GridMEG;      // Array of MEG sensors
    double*      DataMEG;      // MEG Data
/* EEG parameters*/
    UGrid*       GridEEG;      // Array of EEG sensors
    double*      DataEEG;      // EEG Data

/* General (EEG/MEG) */ 
    int          nKan;         // The total number of MEG and EEG channels    
    int          Nsamples;     // Number of samples per channel, present in DataMEG/DataEEG
    int          Ndipoles;     // Number of stationary dipoles
    int          Ncomp;        // Number of components used in SVD of data matrix
    UCovariance* CovTT;        // The (theoretical) temporal covariance
    UCovariance* CovXX;        // The (theoretical) spatial covariance for the MEG/EEG sensors

/* Help arrays*/
    double*      EMData;       // Pre-whitened E/MEG data, first MEG then EEG channels
    double*      Umat;         // SVD-Decomposition of EMData:    
    double*      Lamda;        //    EMData = Umat * Lamda * VmatT
    double*      Vmat;         // 
    double*      SV;           // Normalize singular values (in % of data power of EMData[])
    double*      Bmat;         // 'Rotated' Source time functions

    int          NtotCost;     // The total number of calls to ComputeCost(), starting from constructor    
    double       offset;       // Default parameter step, used in minimization algorithm
    UDipole      Dips[MAXSTATDIP];        // Final dipole parameters, obtained after running ComputeDipoles()
    double       Direction[6*MAXSTATDIP]; // direction(s) of dipole(s) as linear parameters
    double       Position[3*MAXSTATDIP];  // position(s) of dipole(s) as non-linear parameters


    double       ComputeCost(const UVector3 &Point, float *fld, int idum=0, double* AmatInv=NULL);
    ErrorType    CostDirection(double* Amat, double* Bvec, double *Cost);
};

#endif // _LOCSTATDIP_INCLUDED
