/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a ANT data file and taking only the necesssary parts.  */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    12-02-09   creation.
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    26-11-12   GetEpoch_d(). Fill data array with zeroes when data outside file range are requested.
  JdM    14-12-12   Added IsANTLabel() and included ANT labels as EEG
  JdM    06-05-13   IsANTLabel(). Changed brackets
  JdM    13-05-14   BugFix GetEpoch_d(). Changed loop from i<MAXCHAN to i<NchannelTot. Old code caused crash if all channels are U_DAT_UNKNOWN
  JdM    14-05-14   IsANTLabel(). Added 256 more EEG standard labels
  JdM    12-12-14   Added recognition of 64 bits variant of ANT data format
  JdM    14-01-15   Read ANT markers from text file, when not present in .cnt file
  JdM    13-05-17   BUG FIX. GetChannel_d(). GetNsamples() was called with 1 i.s.o. nsamp
  JdM    08-06-18   UFilename constructor: Remove message on the assumption of an ADC channel
 */

#include <string.h>

#include "MEEGDataANT.h"
#include "Grid.h"
#include "MarkerArray.h"


/* Inititalize static const parameters. */
UString UMEEGDataANT::Properties = UString();

static const int Nbytes = 4;

void UMEEGDataANT::SetAllMembersDefault(void)
{
    error = U_OK;
}

void UMEEGDataANT::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataANT::~UMEEGDataANT()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataANT::UMEEGDataANT() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataANT::UMEEGDataANT(UFileName FileName) :
    UMEEGDataBase()
{
    SetAllMembersDefault();

    if(FileName.HasExtension("cnt")==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataANT::UMEEGDataANT(). File has wrong extension. Filename = %s .\n",FileName.GetFullFileName());
        return;
    }
    ANT = UANTData(FileName);
    if(ANT.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataANT::UMEEGDataANT(). Creating UANTData object. \n");
        return;
    }

    ChIn           = new ChanInfo[MAXCHAN];
    GridAll        = new UGrid(MAXCHAN);

    if(!ChIn || !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataANT::UMEEGDataANT(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat     = ANT.IsFormat32bits() ? U_DATFORM_ANT : U_DATFORM_ANT64;
    DataFileName   = FileName;
    ContineousData = true;

    strncpy(PatName,"ANTunknown",sizeof(PatName)-1);
    strncpy(PatID  ,"ANT12345",  sizeof(PatID)-1);

    srate          = ANT.GetSamplingRate();
    nsamp          = ANT.GetNSampTrial();
    ntrial         = ANT.GetNTrial()-1;
    if(ntrial<=0 ||nsamp<1 || srate<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataANT::UMEEGDataANT(). Total number of trials or sample rate out of range: nsampe = %d , srate = %f    .\n", nsamp, srate);
        return;
    }
    NPreTrig       = 0;
    nAver          = 0;
    GeneralComment = ANT.GetProperties("#  ");
    NchannelRaw    = ANT.GetNChan();
    NchannelTot    = NchannelRaw;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"ANT_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true;

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;
    for(int i=0; i<NchannelRaw; i++)
    {
        EEGChanInfo E  =  ANT.GetChannelInfo(i);

        ChIn[i].type     =  U_DAT_UNKNOWN;
        ChIn[i].InGain   =  E.rscale * E.rscale;
        ChIn[i].GainFact = 1.;
        ChIn[i].Offset   = 0.;
        strncpy(ChIn[i].namChannel, E.lab, 10);

        ChIn[i].SkipChannel = false;
        if(UGrid::IsStandardEEGLabel(ChIn[i].namChannel)==true)
        {
            ChIn[i].type = U_DAT_EEG;
            nEEG++;
        }
        else if(IsStringCompatible(ChIn[i].namChannel, "*EKG*", false)==true)  ChIn[i].type = U_DAT_EKG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*ECG*", false)==true)  ChIn[i].type = U_DAT_EKG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*EOG*", false)==true)  ChIn[i].type = U_DAT_EOG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*EMG*", false)==true)  ChIn[i].type = U_DAT_UNKNOWN;
        else if(IsStringCompatible(ChIn[i].namChannel, "*musc*", false)==true) ChIn[i].type = U_DAT_UNKNOWN;
        else if(IsANTLabel(ChIn[i].namChannel))
        {
            ChIn[i].type = U_DAT_EEG;
            nEEG++;
        }
        else
        {
/* "Note: UMEEGDataANT::UMEEGDataANT(). Channel with label %s not recognized (assume ADC). \n" */
            ChIn[i].type = U_DAT_ADC;
        }
        USensor S(UVector3(), UVector3(), UVector3(), USensor::U_SEN_POINT, ChIn[i].namChannel);
        if(ChIn[i].type==U_DAT_EEG || ChIn[i].type==U_DAT_MEG)
        {
            S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
            if(ChIn[i].type==U_DAT_EEG) S.SetStype(USensor::U_SEN_EEG);
        }
        GridAll->SetSensor(&S,i);
    }
    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) )
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataANT::UMEEGDataANT(). Memory allocation for Grid. \n");
        return;
    }

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    Markers = ANT.GetMarkerArray();
    if(Markers==NULL)
    {
        UFileName FT = FileName;
        FT.SetExtension("trg");
        Markers = new UMarkerArray(FT, nsamp, 0, srate);
    }

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataANT::UMEEGDataANT(). Setting new Laplacian reference matrix \n");

    if(error==U_OK)
        CI.AddToLog("Note: UMEEGDataANT::UMEEGDataANT(). Succesfully read file %s \n",FileName.GetFullFileName());
}

UMEEGDataANT::UMEEGDataANT(const UMEEGDataANT& Data) :
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataANT.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataANT& UMEEGDataANT::operator=(const UMEEGDataANT &Data)
{
    if(this==NULL)
    {
        static UMEEGDataANT M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataANT::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    ANT = Data.ANT;

    return *this;
}

bool UMEEGDataANT::IsANTLabel(const char* Lab) const
{
#define NANTLAB 62
    static const char* ANTLab[NANTLAB]  =
    {"TPP9H", "TPP10H","P10AFF1","AFF2" ,"FFC5H","CCP5H" ,"CCP3H","PPO9H" ,
     "FFC3H", "FFC4H" ,"FFC6H"  ,"FCC5H","FCC3H","FCC4H" ,"FCC6H","OI2H"  ,
     "CCP4H", "CCP6H" ,"CPP5H"  ,"CPP3H","CPP4H","CPP6H" ,"PPO1" ,"PPO5H" ,
     "AFP3H", "AFP4H" ,"AFF5H"  ,"AFF6H","FFT7H","FFC1H" ,"PPO2" ,"TTP7H" ,
     "FFC2H", "FFT8H" ,"FTT9H"  ,"FTT7H","FCC1H","FCC2H" ,"FTT8H","FTT10H",
     "CCP1H", "CCP2H" ,"TTP8H"  ,"TPP7H","CPP1H","CPP2H" ,"TPP8H","PPO6H",
     "PPO10H","POO9H" ,"POO3H", "POO4H", "POO10H","OI1H" ,"AFZ",  "PO9",
     "PO10",  "P9",    "I1",    "IZ",    "PO5",   "PO6"};

#define NANTLAB256 256
    static const char* ANTLab256[NANTLAB256]  = {
    "Z1L" ,"Z2L" ,"Z3L" ,"Z4L" ,"Z5L" ,"Z6L" ,"Z7L" ,"Z8L" ,"Z9L" ,"Z10L","Z11L","Z12L","Z13L","Z14L","Z15L","Z16L",
    "Z17L","Z18L","Z19L","L1Z" ,"L2Z" ,"L3Z" ,"L4Z" ,"L5Z" ,"L6Z" ,"L7Z" ,"L8Z" ,"L9Z" ,"L10Z","L11Z","L12Z","L13Z",
    "L14Z","L15Z","L16Z","L17Z","L18Z","L19Z","L20Z","L1L" ,"L2L" ,"L3L" ,"L4L" ,"L5L" ,"L6L" ,"L7L" ,"L8L" ,"L9L" ,
    "L10L","L11L","L12L","L13L","L14L","L15L","L16L","L17L","L18L","L19L","L1A" ,"L2A" ,"L3A" ,"L4A" ,"L5A" ,"L6A" ,
    "L1B" ,"L2B" ,"L3B" ,"L4B" ,"L5B" ,"L6B" ,"L7B" ,"L1C" ,"L2C" ,"L3C" ,"L4C" ,"L5C" ,"L6C" ,"L7C" ,"L8C" ,"L1D" ,
    "L2D" ,"L3D" ,"L4D" ,"L5D" ,"L6D" ,"L7D" ,"L8D" ,"L9D" ,"L1E" ,"L2E" ,"L3E" ,"L4E" ,"L5E" ,"L6E" ,"L7E" ,"L8E" ,
    "L9E" ,"L10E","L1F" ,"L2F" ,"L3F" ,"L4F" ,"L5F" ,"L6F" ,"L7F" ,"L8F" ,"L1G" ,"L2G" ,"L3G" ,"L4G" ,"L5G" ,"L6G" ,
    "L7G" ,"L1H" ,"L2H" ,"L3H" ,"L4H" ,"L5H" ,"Z1Z" ,"Z2Z" ,"Z3Z" ,"Z4Z" ,"Z5Z" ,"Z6Z" ,"Z7Z" ,"Z8Z" ,"Z9Z" ,"Z10Z",
    "Z1R" ,"Z2R" ,"Z3R" ,"Z4R" ,"Z5R" ,"Z6R" ,"Z7R" ,"Z8R" ,"Z9R" ,"Z10R","Z11R","Z12R","Z13R","Z14R","Z15R","Z16R",
    "Z17R","Z18R","Z19R","R1Z" ,"R2Z" ,"R3Z" ,"R4Z" ,"R5Z" ,"R6Z" ,"R7Z" ,"R8Z" ,"R9Z" ,"R10Z","R11Z","R12Z","R13Z",
    "R14Z","R15Z","R16Z","R17Z","R18Z","R19Z","R20Z","R1R" ,"R2R" ,"R3R" ,"R4R" ,"R5R" ,"R6R" ,"R7R" ,"R8R" ,"R9R" ,
    "R10R","R11R","R12R","R13R","R14R","R15R","R16R","R17R","R18R","R19R","R1A" ,"R2A" ,"R3A" ,"R4A" ,"R5A" ,"R6A" ,
    "R1B" ,"R2B" ,"R3B" ,"R4B" ,"R5B" ,"R6B" ,"R7B" ,"R1C" ,"R2C" ,"R3C" ,"R4C" ,"R5C" ,"R6C" ,"R7C" ,"R8C" ,"R1D" ,
    "R2D" ,"R3D" ,"R4D" ,"R5D" ,"R6D" ,"R7D" ,"R8D" ,"R9D" ,"R1E" ,"R2E" ,"R3E" ,"R4E" ,"R5E" ,"R6E" ,"R7E" ,"R8E" ,
    "R9E" ,"R10E","R1F" ,"R2F" ,"R3F" ,"R4F" ,"R5F" ,"R6F" ,"R7F" ,"R8F" ,"R1G" ,"R2G" ,"R3G" ,"R4G" ,"R5G" ,"R6G" ,
    "R7G" ,"R1H" ,"R2H" ,"R3H" ,"R4H" ,"R5H" ,"Z11Z","Z12Z","Z13Z","Z14Z","Z15Z","Z16Z","Z17Z","Z18Z","Z19Z","Z20Z"
    };

    if(Lab==NULL) return false;

    for(int k=0; k<NANTLAB   ; k++)   if(IsStringCompatible(Lab, ANTLab   [k], false)==true) return true;
    for(int k=0; k<NANTLAB256; k++)   if(IsStringCompatible(Lab, ANTLab256[k], false)==true) return true;
    return false;
#undef NANTLAB
#undef NANTLAB256
}

const UString& UMEEGDataANT::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataANT-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

double* UMEEGDataANT::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }
    if(ANT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : UANTData data member not OK.\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }
    int* ChanSel = new int[nKAN];
    if(ChanSel==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : Memory allocation (nKAN=%d).\n", nKAN);
        return NULL;
    }
    int isel = 0;
    for(int i=0; i<NchannelTot; i++)
    {
        if(ChIn[i].SkipChannel==true || ChIn[i].type!=Dtype) continue;
        ChanSel[isel++] = i;
    }
    if(isel!=nKAN)
    {
        delete[] ChanSel;
        CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : Selecting channels (isel = %d, nKAN = %d) .\n", isel, nKAN);
        return NULL;
    }
    UANTData cop = ANT;

    double* data = cop.GetRawData(Begin.GetAbsSample(nsamp), NSamples, ChanSel, nKAN);
    delete[] ChanSel;
    if(data) return data;

    CI.AddToLog("ERROR: UMEEGDataANT::GetEpoch_d() : Getting data from UANTData object . \n");

    return NULL;
}
double* UMEEGDataANT::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }
    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : Invalid NULL label. \n");
        return NULL;
    }
    int isel = -1;
    for(int i=0; i<MAXCHAN; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;
        if(IsStringCompatible(ChIn[i].namChannel, Label, false))
        {
            isel = i;
            break;
        }
    }
    if(isel<0)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : Label not found (or not selected): %s . \n", Label);
        return NULL;
    }

    if(ANT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : UANTData data member not OK.\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    UANTData cop = ANT;

    double* data = cop.GetRawData(Begin.GetAbsSample(nsamp), NSamples, &isel, 1);
    if(data) return data;

    CI.AddToLog("ERROR: UMEEGDataANT::GetChannel_d() : Getting data from UANTData object . \n");
    return NULL;
}

/****
UMarkerArray* UMEEGDataANT::GetMarkersFromFile(FILE*fp, ErrorType* E) const
{
    return NULL;
}
*****/
