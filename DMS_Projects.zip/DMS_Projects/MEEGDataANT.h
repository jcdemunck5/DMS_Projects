#ifndef _MEEGDATAANT_INCLUDED
#define _MEEGDATAANT_INCLUDED

#include "MEEGDataBase.h"
#include "ANTData.h"

class DLL_IO UMEEGDataANT : public UMEEGDataBase
{
public:
    UMEEGDataANT();
    UMEEGDataANT(UFileName FileName);     
    UMEEGDataANT(const UMEEGDataANT& Data); 
    virtual ~UMEEGDataANT();
    UMEEGDataANT&          operator=(const UMEEGDataANT &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;

    bool                   IsANTLabel(const char* Lab) const;
protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    ErrorType              error;
    UANTData               ANT;
};

#endif// _MEEGDATAANT_INCLUDED
