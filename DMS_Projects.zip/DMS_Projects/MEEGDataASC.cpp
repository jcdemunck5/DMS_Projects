/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading an ASCII data file and taking only the                 */
/*     necesssary part.                                                          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-06-04   creation.
  JdM    01-07-04   bug fix: UMEEGDataASC() Setting nchannel.
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    21-04-05   declared some undeclared identifiers (for g++-compatibility)
  JdM    07-06-05   bug fixes. Set error flag directly before returning.
  JdM    15-01-06   Added EEG group-re-reference
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h>

#include "MEEGDataASC.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */

#define MAXLINE 200
#define MAXLABEL 16

UString UMEEGDataASC::Properties = UString();

void UMEEGDataASC::SetAllMembersDefault(void)
{
    Headerfile   = UFileName();
    Datafile     = UFileName();
}

void UMEEGDataASC::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataASC::~UMEEGDataASC()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataASC::UMEEGDataASC() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataASC::UMEEGDataASC(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the Brain products data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();


/* Read first line of data file */    
    FileName.ReplaceExtension("AVR");
    FILE*   fp = fopen(FileName, "rb", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        error = U_ERROR;
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }
    char line[MAXLINE];
    GetLine(line, sizeof(line), fp);
    fclose(fp);
    UAnalyzeLine AA(line);
    if(AA.IsIdentifierIs("Npts")==false)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). String %s not found in: %s \n","Npts", FileName.GetFullFileName());
        return;
    }
    int nsampTot = AA.GetNextInt(); 
    if(nsampTot<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Total number of samples is too small, nsampTot=%d .\n", nsampTot);
        return;
    }
    if(AA.IsIdentifierIsInLine("DI")==false)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Identifier DI is missing in first line: %s    .\n", line);
        return;
    }
    double Stime = 0.001 * AA.GetNextDouble();
    if(Stime<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Invaslid sample time: Stime = %f [s]    .\n", Stime);
        return;
    }
    srate = 1./Stime;

/* Read the header*/
    FileName.ReplaceExtension("ELA");
    fp = fopen(FileName, "rb", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }
    
/* Set gain and type*/
    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    ||
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);

        CI.AddToLog("ERROR UMEEGDataASC::UMEEGDataASC(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_ASCII;
    DataFileName      = FileName;   
    Headerfile        = FileName;   Headerfile.ReplaceExtension("ELA");
    Datafile          = FileName;   Datafile.ReplaceExtension("AVR");

    ContineousData    = true;
    DateTimeRec       = UDateTime();
    nsamp             = 1;
    ntrial            = nsampTot;
    NPreTrig          = 0;
    nAver             = 0;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"ASC_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = true;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

    NchannelRaw = 0;
    NchannelTot = 0;
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        const char*Lab   = AA.GetNextString(MAXLABEL);
        if(Lab)
            strncpy(ChIn[NchannelRaw].namChannel, Lab, MAXLABEL-1);

        USensor S = UGrid::GetDefaultSensor(ChIn[NchannelRaw].namChannel);
        GridAll->SetSensor(&S, NchannelRaw);
        if(UGrid::IsStandardEEGLabel(ChIn[NchannelRaw].namChannel)==true)  
        {
            ChIn[NchannelRaw].type = U_DAT_EEG;
            nEEG++;
        }
        ChIn[NchannelRaw].SkipChannel   = false;
        NchannelRaw++;
    }    
    NchannelTot = NchannelRaw;
    fclose(fp);

    strncpy(PatName,"ASC_NONAME",31);
    strncpy(PatID  ,"ASC1234567890",31);


    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Memory allocation for Grid. \n");
        return;
    }        

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    if(nEEG<=0 || nEEG>MAXEEG)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Number of EEG channels out of range: nEEG = %d.\n", nEEG);
        return;
    }
    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataASC::UMEEGDataASC(). Setting new Laplacian reference matrix \n");
}

UMEEGDataASC::UMEEGDataASC(const UMEEGDataASC& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataASC.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataASC& UMEEGDataASC::operator=(const UMEEGDataASC &Data)
{
    if(this==NULL)
    {
        static UMEEGDataASC M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataASC::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataASC::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    Headerfile   = Data.Headerfile;
    Datafile     = Data.Datafile;
    return *this;
}

const UString& UMEEGDataASC::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataASC-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}


double* UMEEGDataASC::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataASC::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataASC::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataASC::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data = new double[NSamples*nKAN];
    char*   Line = new char[MAXCHAN*30];
    if(!data || !Line)
    {
        delete[] data; delete[] Line;
        CI.AddToLog("ERROR UMEEGDataASC::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }


    FILE* fp = fopen(Datafile, "rb", true);
    if(fp==NULL)
    {
        delete[] data; delete[] Line;
        CI.AddToLog("ERROR: UMEEGDataASC::GetEpoch_d(). Cannot open file: %s  .\n",Datafile.GetFullFileName());
        return NULL;
    }
    GetLine(Line, 30, fp);
    unsigned Offset = ftell(fp);
    
    for(int i=0, ic=0; i<NchannelRaw; i++)
    {
        if(ChIn[i].type!=Dtype) continue;
        if(ChIn[i].SkipChannel==true) continue;

        fseek(fp, Offset+10*(i*ntrial+Begin.GetAbsSample(nsamp)), SEEK_SET);    

        for(int j=0; j<NSamples; j++)
        {
            float Dat;
            fscanf(fp, "%f   ", &Dat);
            data[ic*NSamples+j] = Dat;
        }
        ic++;
    }    
    fclose(fp);

    return data;
}

int* UMEEGDataASC::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataASC::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}
