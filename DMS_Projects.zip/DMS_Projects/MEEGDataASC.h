#ifndef _MEEGDATAASC_INCLUDED
#define _MEEGDATAASC_INCLUDED

#include "MEEGDataBase.h"

class DLL_IO UMEEGDataASC : public UMEEGDataBase
{
public:
    UMEEGDataASC();
    UMEEGDataASC(UFileName FileName);     
    UMEEGDataASC(const UMEEGDataASC& Data); 
    virtual ~UMEEGDataASC();
    UMEEGDataASC&          operator=(const UMEEGDataASC &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    virtual const UString& GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;

/* ASCII data */
    UFileName              Headerfile;   // Filename containing the channel labels
    UFileName              Datafile;     // Filename containg the ACII data
};

#endif// _MEEGDATAASC_INCLUDED
