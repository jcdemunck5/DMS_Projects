/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a Brain Products data file and taking only the         */
/*     necesssary part.                                                          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    25-01-04   creation.
  JdM    07-02-04   Improved ReadMarkers()
  JdM    12-02-04   Bug fix: GetEpoch_d(). Test for channels to skip.
  JdM    01-06-04   GetEpoch_d(). Make consistent with getting common reference data.
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
                    Allow for other data types than two bytes ints
  JdM    23-02-05   Bug fixes using float type
  JdM    21-04-05   declared some undeclared identifiers (for g++-compatibility)
  JdM    15-01-06   Added EEG group-re-reference
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    06-04-08   Added GetChannel_d()
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    27-01-12   UMEEGDataBP::UMEEGDataBP(). Relaxed header test (avoid ambiguite in spaces and commas).
  JdM    28-11-12   Added ASCII and VECTORIZED variants
  JdM    29-11-13   Bug Fix. UMEEGDataBP::UMEEGDataBP(): NTimeSamples was defined locally. In case of Binary files, this resulted in NTimeSamples=0
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    04-09-15   Bug FIX. GetEpoch_d(). Reading binary vectorized data.
*/

#include <string.h>

#include "MEEGDataBP.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataBP::Properties = UString();

#define MAXLINE 200
#define MAXLABEL 16
#define HEADER1  "BrainVisionDataExchangeHeaderFileVersion1.0"
#define MARKER1  "BrainVisionDataExchangeMarkerFileVersion1.0"

void UMEEGDataBP::SetAllMembersDefault(void)
{
    Headerfile     = UFileName();
    Datafile       = UFileName();
    Markerfile     = UFileName();
    DType          = U_BYTE;
    NTimeSamples   = 0;
    BinaryData     = true;
    SkipNLines     = 0;
    SkipNCollumns  = 0;
    VectorizedData = true;
}

void UMEEGDataBP::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataBP::~UMEEGDataBP()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataBP::UMEEGDataBP() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataBP::UMEEGDataBP(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the Brain products data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

    DataFileName      = FileName;
    Headerfile        = FileName;   Headerfile.ReplaceExtension("vhdr");
    Datafile          = FileName;   Datafile.ReplaceExtension("eeg");
    Markerfile        = FileName;   Markerfile.ReplaceExtension("vmrk");
    int NDataPoints   = 0;

/* Read the header*/
    FILE*   fp = fopen(Headerfile, "rb", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }

/* Read the header file*/
    bool CaseSense = false;
    char line[MAXLINE];
    GetLine(line, MAXLINE, fp);
    UString Header(line);
    Header.RemoveChar(' ');
    Header.RemoveChar(',');
    Header.Truncate(sizeof(HEADER1)-1);
    if(Header!=UString(HEADER1))
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous file type. First line = %s .\n",line);
        error = U_ERROR;
        return;
    }

    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsCommentLine(";")==true) continue;
        if(AA.IsEmptyLine()==true) continue;
        if(AA.IsIdentifier("[Channel Infos]")==true) break;
        
        if(AA.IsIdentifierIs("DataFile")==true)
        {
            const char*DF = AA.GetNextString(50);
            Datafile = Headerfile.GetSiblingFileName(DF);
            continue;
        }
        if(AA.IsIdentifierIs("DataFormat")==true) 
        {
            const char*DF = AA.GetNextString(10);
            if(IsStringCompatible(DF, "BINARY", CaseSense)==true)     BinaryData = true;
            else if(IsStringCompatible(DF, "ASCII", CaseSense)==true) BinaryData = false;
            else
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);

                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous data format : %s .\n",DF);
                error = U_ERROR;
                return;
            }
            continue;
        }
        if(AA.IsIdentifierIs("DataOrientation")==true) 
        {
            const char*DM = AA.GetNextString(15);
            if(IsStringCompatible(DM, "VECTORIZED", CaseSense)==true)       VectorizedData = true;
            else if(IsStringCompatible(DM, "MULTIPLEXED", CaseSense)==true) VectorizedData = false;
            else
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);

                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous data orientation : %s .\n",DM);
                error = U_ERROR;
                return;
            }
            continue;
        }
        if(AA.IsIdentifierIs("DataPoints")==true)
        {
            NDataPoints = AA.GetNextInt(-1);
            if(NDataPoints<=0)
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);

                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous number of data points : %d .\n",NDataPoints);
                error = U_ERROR;
                return;
            }
            continue;
        }
        if(AA.IsIdentifierIs("BinaryFormat")==true) 
        {
            const char*BF = AA.GetNextString(10);
            if(!strncmp(BF, "INT_16", sizeof("INT_16")-1))
            {
                DType = U_SHORT;
            }
            else if(!strncmp(BF, "IEEE_FLOA", sizeof("IEEE_FLOA")-1))
            {
                DType = U_FLOAT;
            }
            else
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);

                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous binary format : %s (not yet supported).\n",BF);
                error = U_ERROR;
                return;
            }
            continue;
        }
        if(AA.IsIdentifierIs("SkipLines")==true) 
        {
            SkipNLines = AA.GetNextInt(-1);
            if(SkipNLines<0)
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous number of SkipLines : %d .\n",SkipNLines);
                error = U_ERROR;
                return;
            }
        }
        if(AA.IsIdentifierIs("SkipColumns")==true) 
        {
            SkipNCollumns = AA.GetNextInt(-1);
            if(SkipNLines<0)
            {
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Erroneous number of SkipColumns : %d .\n",SkipNCollumns);
                error = U_ERROR;
                return;
            }
        }
        if(AA.IsIdentifierIs("NumberOfChannels")==true) 
        {
            NchannelRaw = AA.GetNextInt();
            continue;
        }
        if(AA.IsIdentifierIs("SamplingInterval")==true) 
        {
            double Stime = AA.GetNextDouble();
            if(Stime>0) srate  = 1000000./Stime;
            continue;
        }
    }
    NchannelTot = NchannelRaw;
    if(NchannelRaw<=0 || srate<=0.)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);

        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Illegal number of channels: NchannelRaw=%d or sampling rate (srate=%f).\n",NchannelRaw, srate);
        error = U_ERROR;
        return;
    }

/* Set number of samples etc. */
    int size = -1;
    if(DoesFileExist(Datafile)==false || (size=Datafile.GetFileSize())<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);

        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Data file does not exist or has is empty: %s \n", FileName.GetFullFileName());
        error = U_ERROR;
        return;
    }
    if(BinaryData)
    {
        NTimeSamples = size/(2*NchannelRaw);
        if(DType == U_FLOAT)  NTimeSamples /= 2;
    }
    else if(NDataPoints>0)
    {
        NTimeSamples = NDataPoints/NchannelRaw;
    }
    if(NTimeSamples<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);

        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Total number of samples is too small, NTimeSamples=%d .\n", NTimeSamples);
        return;
    }
/* Set gain and type*/
    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    ||  
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);

        CI.AddToLog("ERROR UMEEGDataMM::UMEEGDataMM(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_BRAINPROD;
    ContineousData    = true;
    DateTimeRec       = UDateTime();
    nsamp             = 1;
    ntrial            = NTimeSamples;
    NPreTrig          = 0;
    nAver             = 0;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"BP_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

    int ichan = 0;
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsCommentLine(";")==true) continue;
        if(AA.IsEmptyLine()==true) continue;

        char Chan[8];
        sprintf(Chan,"Ch%d",ichan+1);

        ChIn[ichan].SkipChannel = true;  
        if(AA.IsIdentifier(Chan)==true) 
        {
            const char*Lab   = AA.GetNextString(MAXLABEL);
            strncpy(ChIn[ichan].namChannel, Lab, MAXLABEL-1);

            ChIn[ichan].InGain = AA.GetNextDouble();
            if(ChIn[ichan].InGain==0.)  ChIn[ichan].InGain = 1.;

            USensor S = UGrid::GetDefaultSensor(ChIn[ichan].namChannel);
            GridAll->SetSensor(&S, ichan);
            ChIn[ichan].SkipChannel = false;  
            if(UGrid::IsStandardEEGLabel(ChIn[ichan].namChannel)==true)  
            {
                ChIn[ichan].type = U_DAT_EEG;
                nEEG++;
            }
            ichan++;
            continue;
        }
    }    
    fclose(fp);

    strncpy(PatName,"BP_NONAME",31);
    strncpy(PatID  ,"BP1234567890",31);


    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Memory allocation for Grid. \n");
        error = U_ERROR;
        return;
    }        

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    error = U_OK;

/* Read markers and classes */
    Markers = ReadMarkers(Markerfile);
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("WARNING: UMEEGDataBP::UMEEGDataBP(). Cannot create UMarkerArray()-object. \n");
    }
    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataBP::UMEEGDataBP(). Setting new Laplacian reference matrix \n");
}

UMEEGDataBP::UMEEGDataBP(const UMEEGDataBP& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataBP.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataBP& UMEEGDataBP::operator=(const UMEEGDataBP &Data)
{
    if(this==NULL)
    {
        static UMEEGDataBP M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBP::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataBP::operator=(). Copying base class. \n");
        error = U_ERROR;
        return *this;
    }

    DeleteAllMembers(U_OK);

    Headerfile     = Data.Headerfile;
    Datafile       = Data.Datafile;
    Markerfile     = Data.Markerfile;
    DType          = Data.DType;
    NTimeSamples   = Data.NTimeSamples;
    BinaryData     = Data.BinaryData;
    SkipNLines     = Data.SkipNLines;
    SkipNCollumns  = Data.SkipNCollumns;
    VectorizedData = Data.VectorizedData;

    return *this;
}

const UString& UMEEGDataBP::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties =UString(" ERROR in UMEEGDataBP-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(BoolAsText(VectorizedData)," VectorizedData = %s \n");
    Properties += UString(BoolAsText(BinaryData),    " BinaryFormat   = %s \n");
    if(BinaryData)
    {
        switch(DType)
        {
        case U_BYTE:    Properties += UString(" DataType       = U_BYTE    \n"); break;
        case U_SHORT:   Properties += UString(" DataType       = U_SHORT   \n"); break;
        case U_INTEGER: Properties += UString(" DataType       = U_INTEGER \n"); break;
        case U_FLOAT:   Properties += UString(" DataType       = U_FLOAT   \n"); break;
        case U_DOUBLE:  Properties += UString(" DataType       = U_DOUBLE  \n"); break;
        }
    }
    else
    {
        Properties += UString(SkipNLines   ," SkipNLines     = %d \n");
        Properties += UString(SkipNCollumns," SkipNCollumns  = %d \n");
    }
    Properties += UString(NTimeSamples," NTimeSamples   = %d \n");
    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

double* UMEEGDataBP::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data   = new double[NSamples*nKAN];
    if(!data)
    {
        delete[] data;
        CI.AddToLog("ERROR UMEEGDataBP::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }

    if(BinaryData)
    {
        int Size = 0;
        switch(DType)
        {
        case U_BYTE:    Size = 1; break;
        case U_SHORT:   Size = 2; break;
        case U_INTEGER: Size = 4; break;
        case U_FLOAT:   Size = 4; break;
        case U_DOUBLE:  Size = 8; break;
        }
        if(Size<=0)
        {
            delete[] data;
            CI.AddToLog("ERROR UMEEGDataBP::GetEpoch_d() : Invalid data type: DType = %d    .\n", DType);
            return NULL;
        }
        FILE* fp = fopen(Datafile, "rb", true);
        if(fp==NULL)
        {
            delete[] data;
            CI.AddToLog("ERROR: UMEEGDataBP::GetEpoch_d(). Cannot open file: %s  .\n",Datafile.GetFullFileName());
            return NULL;
        }

        if(VectorizedData)
        {
            char* buffer = new char[NSamples*Size];
            if(buffer==NULL)
            {
                delete[] data;
                CI.AddToLog("ERROR: UMEEGDataBP::GetEpoch_d(). Memory allocation for Buffer (NSamples = %d)\n", NSamples);
                return NULL;
            }
            int itake = 0;
            for(int i=0; i<NchannelRaw; i++)
            {
                unsigned ioff = Size*(Begin.GetAbsSample(nsamp) + i*NTimeSamples);
                fseek(fp, ioff, SEEK_SET);

                if(ChIn[i].type!=Dtype) continue;
                if(ChIn[i].SkipChannel==true) continue;
                size_t    nb = fread(buffer, NSamples, Size, fp);
                char* pbuf = buffer;
                switch(DType)
                {
                case U_BYTE:    for(int j=0; j<NSamples; j++) {data[itake*NSamples+j] = (*((char*  )pbuf))*ChIn[i].InGain; pbuf += Size;} break;
                case U_SHORT:   for(int j=0; j<NSamples; j++) {data[itake*NSamples+j] = (*((short* )pbuf))*ChIn[i].InGain; pbuf += Size;} break;
                case U_INTEGER: for(int j=0; j<NSamples; j++) {data[itake*NSamples+j] = (*((int*   )pbuf))*ChIn[i].InGain; pbuf += Size;} break;
                case U_FLOAT:   for(int j=0; j<NSamples; j++) {data[itake*NSamples+j] = (*((float* )pbuf))*ChIn[i].InGain; pbuf += Size;} break;
                case U_DOUBLE:  for(int j=0; j<NSamples; j++) {data[itake*NSamples+j] = (*((double*)pbuf))*ChIn[i].InGain; pbuf += Size;} break;
                }                
                itake++;
            }
            delete[] buffer;
        }
        else
        {
            unsigned ioff = Size*NchannelRaw*Begin.GetAbsSample(nsamp);
            fseek(fp, ioff, SEEK_SET);
            for(int j=0; j<NSamples; j++)
            {
                int itake = 0;
                for(int i=0; i<NchannelRaw; i++)
                {
                    char  dat[8] = {0,0,0,0,0,0,0,0};
                    size_t    nb = fread(dat, 1, Size, fp);
                    if(ChIn[i].type!=Dtype) continue;
                    if(ChIn[i].SkipChannel==true) continue;
                    if(nb)
                    {
                        switch(DType)
                        {
                        case U_BYTE:    data[itake*NSamples+j] = (*((char*  )dat))*ChIn[i].InGain; break;
                        case U_SHORT:   data[itake*NSamples+j] = (*((short* )dat))*ChIn[i].InGain; break;
                        case U_INTEGER: data[itake*NSamples+j] = (*((int*   )dat))*ChIn[i].InGain; break;
                        case U_FLOAT:   data[itake*NSamples+j] = (*((float* )dat))*ChIn[i].InGain; break;
                        case U_DOUBLE:  data[itake*NSamples+j] = (*((double*)dat))*ChIn[i].InGain; break;
                        }                
                    }
                    else
                        data[itake*NSamples+j] = 0.;
                    itake++;
                }
            }
        }
        fclose(fp);
        return data;
    }
// Read ASCII
    UString SComplete(Datafile);
    if(SComplete.GetError())
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataBP::GetEpoch_d(). Cannot open file: %s  .\n",Datafile.GetFullFileName());
        return NULL;
    }
    int offset = 0;
    int nc     = 0;
    int Jbeg   = Begin.GetAbsSample(nsamp);
    int Jend   = End  .GetAbsSample(nsamp);
    if(VectorizedData)
    {
        int itake  = 0;
        for(int ii=0; ii<NchannelRaw+SkipNLines; ii++)
        {
            for(int jj=0; jj<NTimeSamples+SkipNCollumns; jj++)
            {
                UString S = SComplete.GetString(offset, UString(), NULL, &nc); offset += nc;
                
                int j=jj-SkipNCollumns;
                int i=ii-SkipNLines;
                if(j<Jbeg || j>Jend || i<0) continue;
                if(ChIn[i].type!=Dtype) continue;
                if(ChIn[i].SkipChannel==true) continue;

                data[itake*NSamples+j] = S.GetDouble(0.);
            }
            itake++;
        }
    }
    else
    {
        for(int jj=0; jj<NTimeSamples+SkipNLines; jj++)
        {
            int itake = 0;
            for(int ii=0; ii<NchannelRaw+SkipNCollumns; ii++)
            {
                UString S = SComplete.GetString(offset, UString(), NULL, &nc); offset += nc;
                int j=jj-SkipNLines;
                int i=ii-SkipNCollumns;
                if(j<Jbeg || j>Jend || i<0) continue;
                if(ChIn[i].type!=Dtype) continue;
                if(ChIn[i].SkipChannel==true) continue;

                data[itake*NSamples+j] = S.GetDouble(0.);
            }
            itake++;
        }
    }
    return data;
}

double* UMEEGDataBP::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    if(Label==NULL) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d(). Invalid NULL label.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0; i<NchannelRaw; i++)
        if(IsStringCompatible(Label, ChIn[i].namChannel, false)==true)
        {
            ichan = i;
            break;
        }

    if(ichan<0) 
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d(). Label not found: %d .\n", Label);
        return NULL;
    }
    int nKAN = 1;
    int Size = 0;
    switch(DType)
    {
    case U_BYTE:    Size = 1; break;
    case U_SHORT:   Size = 2; break;
    case U_INTEGER: Size = 4; break;
    case U_FLOAT:   Size = 4; break;
    case U_DOUBLE:  Size = 8; break;
    }
    if(Size<=0)
    {
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d() : Invalid data type: DType = %d    .\n", DType);
        return NULL;
    }

    double *data   = new double[NSamples*nKAN];
    if(!data)
    {
        delete[] data;
        CI.AddToLog("ERROR UMEEGDataBP::GetChannel_d() : memory allocation.\n");
        return NULL;
    }


    FILE* fp = fopen(Datafile, "rb", true);
    if(fp==NULL)
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataBP::GetEpoch_d(). Cannot open file: %s  .\n",Datafile.GetFullFileName());
        return NULL;
    }

    unsigned ioff = Size*(ichan+NchannelRaw*Begin.GetAbsSample(nsamp));
    fseek(fp, ioff, SEEK_SET);
    for(int j=0; j<NSamples; j++)
    {
        unsigned ioff = Size*(ichan+NchannelRaw*(j+Begin.GetAbsSample(nsamp)));
        fseek(fp, ioff, SEEK_SET);
        char  dat[8] = {0,0,0,0,0,0,0,0};
        size_t   nb  = fread(dat, 1, Size, fp);
        if(nb)
        {
            switch(DType)
            {
            case U_BYTE:    data[j] = (*((char*  )dat))*ChIn[ichan].InGain; break;
            case U_SHORT:   data[j] = (*((short* )dat))*ChIn[ichan].InGain; break;
            case U_INTEGER: data[j] = (*((int*   )dat))*ChIn[ichan].InGain; break;
            case U_FLOAT:   data[j] = (*((float* )dat))*ChIn[ichan].InGain; break;
            case U_DOUBLE:  data[j] = (*((double*)dat))*ChIn[ichan].InGain; break;
            }                
        }
        else
            data[j] = 0.;
    }
    fclose(fp);
    return data;
}

int* UMEEGDataBP::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataBP::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}

UMarkerArray* UMEEGDataBP::ReadMarkers(UFileName FileName) const
{
    FILE*   fp = fopen(FileName, "rb", true);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBP::ReadMarkers(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return NULL;
    }

/* Read the header file*/
    char line[MAXLINE];
    GetLine(line, MAXLINE, fp);
    UString Header(line);
    Header.RemoveChar(' ');
    Header.RemoveChar(',');
    Header.Truncate(sizeof(MARKER1)-1);
    if(Header!=UString(MARKER1))
    {
        fclose(fp);
        CI.AddToLog("ERROR: UMEEGDataBP::ReadMarkers(). Erroneous file type. First line = %s .\n",line);
        return NULL;
    }
/****
; Each entry: Mk<Marker number>=<Type>,<Description>,<Position in data points>,
; <Size in data points>, <Channel number (0 = marker is related to all channels)>
; Fields are delimited by commas, some fields might be omitted (empty).
; Commas in type or description text are coded as "\1".
Mk1=New Segment,,1,1,0,20040205024653028833
Mk2=New Segment,,87601,1,0,20040205024808588660
Mk3=Comment,ogen open,831801,1,0
Mk4=Comment,ogen dicht,985001,1,0
Mk5=Comment,ogen open,1136201,1,0
Mk6=Comment,ogen dicht,1287801,1,0
Mk7=Comment,ogen open,1435001,1,0
Mk8=Comment,ogen dicht,1580201,1,0
Mk9=Comment,ogen open,1734601,1,0
Mk10=Comment,ogen dicht,1885401,1,0
Mk11=Comment,ogen open,2035401,1,0
Mk12=Comment,ogen dicht,2182201,1,0
***/

    UMarkerArray* Mar = NULL;

    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsCommentLine(";")==true) continue;
        if(AA.IsEmptyLine()==true) continue;

        int index = AA.GetIdentifierInt("Mk", false, -1);
        if(index==-1) continue;
        char Identifier[20];
        sprintf(Identifier,"Mk%d",index);
        if(AA.IsIdentifierIsInLine(Identifier, false)==false) continue;
        
/* Get Name */
        char Name[100];
        memset(Name, 0, sizeof(Name));
        const char* P0 = AA.GetPointer(); AA.MoveToChar(',');
        const char* P1 = AA.GetPointer(); AA.MoveToChar(',');
        const char* P2 = AA.GetPointer(); 
        int nbytes     = P2-P1;
        if(nbytes<=1) continue;
        
        strncpy(Name,P1,MIN(nbytes, sizeof(Name))-1);

/* Get Event*/
        int abssamp = AA.GetNextInt(-1);
        if(abssamp<0) continue;
        UEvent E(abssamp/nsamp, abssamp%nsamp);

        if(Mar==NULL)
        {
            Mar = new UMarkerArray(1, nsamp, 0, srate);
            if(Mar==NULL || Mar->GetError()!=U_OK)
            {
                delete Mar;
                CI.AddToLog("ERROR: UMEEGDataBP::ReadMarkers(). Creating UMarkerArray object. \n");
                return NULL;
            }
            UMarker M(Name, 1, nsamp, 1, NULL, 1, true);
            M.SetEvent(0, E);
            Mar->SetMarker(M, 0);
        }

/* Put into markerarray */
        int iMarker = Mar->GetMarkerIndex(Name);
        if(iMarker<0)
        {
            UMarker M(Name, 1, nsamp, 1, NULL, 1, true);
            M.SetEvent(0, E);
            Mar->AddNewMarkers(1, &M);
        }
        else
            Mar->AddEvent(iMarker, E);
    }
    fclose(fp);
    return Mar; 
}
