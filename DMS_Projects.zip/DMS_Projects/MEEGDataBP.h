#ifndef _MEEGDATABP_INCLUDED
#define _MEEGDATABP_INCLUDED

#include "MEEGDataBase.h"

class DLL_IO UMEEGDataBP : public UMEEGDataBase
{
public:
    UMEEGDataBP();
    UMEEGDataBP(UFileName FileName);     
    UMEEGDataBP(const UMEEGDataBP& Data); 
    virtual ~UMEEGDataBP();
    UMEEGDataBP&           operator=(const UMEEGDataBP &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    virtual const UString& GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);
    enum                   ElemDataType{
                                U_BYTE, 
                                U_SHORT, 
                                U_INTEGER, 
                                U_FLOAT, 
                                U_DOUBLE};

private:
    static UString         Properties;

/* Brain products data */
    UFileName              Headerfile;   // Filename of the Brain Vision header file
    UFileName              Datafile;     // Filename of the Brain Vision data file
    UFileName              Markerfile;   // Filename of the Brain Vision marker file
    ElemDataType           DType;        // data type used to store EEG data on disk

    UMarkerArray*          ReadMarkers(UFileName FileName) const;

    int                    NTimeSamples;  // Total number of time samples
    bool                   BinaryData;
    int                    SkipNLines;     // only if NOT(Binary)
    int                    SkipNCollumns;
    bool                   VectorizedData; /// channel1 (all samples), channel2 (all samples), etc
};

#endif// _MEEGDATANS_INCLUDED
