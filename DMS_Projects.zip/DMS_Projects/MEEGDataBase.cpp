/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Abstract base class for reading various MEG/EEG data formats.             */
/*     For each data type a new derived class of UMEEGDataBase() has to be       */
/*     implemented.                                                              */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    19-11-03   creation, based on ReadCTFData.cpp
  JdM    29-12-03   Added GetChanInfo(), added GetSensor()
                    Added static GetDataType(), added SelectChannels
  JdM    25-01-04   Added Brain Products data format
  JdM    03-02-04   Added SetMarkerArray()
  JdM    15-02-04   Added GetChannelIndex() and GetSensor()
  SG     04-05-04   Bug fix: operator=(): copying DataFileName and DateTimeRec
  JdM    01-06-04   Added mechanism to read data as common-reference: GetCommonReference()
                    Renamed RemoveAverage() to ComputeAverageReference()
  JdM    24-06-04   Added ASCII format input
  JdM    01-07-04   Added Sonata ECG format input
  JdM    05-07-04   Accept old CTF format as .res4 file
  JdM    07-07-04   Added .txt data formats
  JdM    07-07-04   Added UpdateElectrodePositions()
  JdM    13-07-04   UpdateElectrodePositions(): coords in cm.
  JdM    14-07-07   Added U_DAT_SSP
  JdM    20-07-04   Added GetSelectedGrid()
  JdM    22-07-04   Added GetMEGSphere(), GetEEGSphere()
  JdM    21-08-04   Added another GetEpoch_d() and SelectChannels(), based on UGrid labels
  JdM    16-10-04   Added UpdateDewar2Head()
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    06-01-05   Added NLR[] markers
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    23-02-05   Increased maximum number of MEG sensors
  JdM    25-02-05   Added ReplaceSensorPositions()
  JdM    04-04-05   U_DATFORM_ECG: allow: *.ecg; *.puls; *.resp
  JdM    18-04-05   declared some undeclared identifiers (for g++-compatibility)
                    BUG Fix:    SelectChannels(const UGrid* GridLabels) (use ic i.s.o. i)
  JdM    22-04-05   Added virtual GetBadChannels()
  JdM    03-05-05   Added EDF format
  JdM    07-05-05   Added map format
  JdM    12-07-05   Added ConvertDataType()
  JdM    25-10-05   Bug fix ConvertDataType(). Update GridAll
                    GetChanAndType(). Completed return value for case that DType is not, U_DAT_EEG, U_DAT_MEG, U_DAT_ADC, or U_DAT_MEGREF
  JdM    01-11-05   Added RenameSensor()
  JdM    07-11-05   Bug fix: operator=(), copy NLR[]; SetAllMembersDefault(): Set NLR[] to UVector3() (null-vector)
  JdM    29-12-05   Added UpdateChannelColors() and UpdateChannelGroups()
  JdM    15-01-06   Added GetUnitText(), WriteSensorPositionsXYZ() and WriteChannelConfigTXT()
                    Added U_REF_GROUPAVER (ReReferenceType)
  JdM    26-02-06   Added SetCTFSensorGroups()
  JdM    09-05-06   GetProperties(). GeneralComment: extend Truncate() to 4000 characters
  JdM    21-05-06   GetProperties(). Change format of marker name (MarkerName = iso Name = )
  JdM    04-10-06   RenameSensor(). Copy default sensor EEG position if new name is default EEG label, and old name is not
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    15-05-07   GetEpoch_d(). Added virtual version without ReRef parameter. Treat in UMEEGDataBase base class.
  JdM    11-01-08   Added RemoveChannels()
  JdM    24-01-08   Added new data format type: U_DATFORM_PHILLOG
  JdM    28-01-08   Added UInterpolateSphere* LaplaceRef member
  JdM    12-03-08   SetSSPChannels(), RemoveSSPChannels(). Adapt nchannel according to the number of SSP channels added or removed.
  JdM    13-03-08   Added private members: GridSSP and nSSP (analogeous to GridADC and nADC)
  JdM    18-03-08   Added ReplaceMarker(), MergeMarkerArray() and AddMarker()
  JdM    25-03-08   BUG FIX: In relation to changes dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    08-05-08   Added another SelectChannels()
  JdM    13-05-08   Read files more general first strings (test '(SWID ' iso '(SWID 123')
  JdM    21-05-08   Bug fix. ReplaceSensorPositions(). When replacing sensors, skip those that were not selected.
  JdM    22-05-08   Bug fix. GetDataFormatType(). Testing the right strings for each of the file types.
  JdM    23-05-08   UpdateChannelGroups(). Use the more "liberal" UGrid::GetChannum() to compare sensor names. This is more consistent with ReplaceSensorPositions()
  JdM    27-01-07   Added SetAllMembersDefault() and DeleteAllMembers(), use UString for Properties;
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    31-08-08   GetMEGSphere(), GetEEGSphere(). Test number of sensors.
  JdM    16-09-08   Bug fix: GetMEGSphere(). test GridMEG i.s.o. GridEEG
  JdM    04-01-09   Added virtual RenameDataFiles()
  JdM    07-02-09   Added CopyChannelSelection()
  JdM    11-02-09   Added Another RenameSensor()
  JdM    12-02-09   GetDataFormatType() Added recognition of U_DATFORM_ANT (ANT data format)
  JdM    16-02-09   Made GeneralComment a UString
  JdM    17-02-09   Made GetError() virtual
  JdM    01-03-09   GetDataFormatType(). Added recognition of GE .log files
  JdM    28-09-09   Added GetNsampTotal(). Tested inline functions for this==NULL
  JdM    26-10-09   GetDataFormatType(). Added recognition of U_DATFORM_FIFF (FIFF data format)
  JdM    04-11-09   Increased sizes of MAXMEG, MAXADC and MAXCHAN
  JdM    08-02-10   GetDataFormatType(). Added "MEG42RS" file header
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    08-10-10   Added U_DAT_ANNOT to DataType in order to comply with EDF+
  JdM    10-10-10   Increased UMEEGDataBase::MAXEEG from 100 to 300
  JdM    03-11-10   Added UInterpolateSensors* CTFSensorInter member
  JdM    21-03-11   GetDataFormatType(). To avoid problems with linux, first test whether string is directory, the open it as file
  JdM    08-03-12   Added SaveSensorPositions()
  JdM    21-03-12   Bug Fix: SelectChannels(const UGrid*) do NOT skip labels when they are found
  JdM    12-02-13   GetDataFormatType(). Added recognition of TMSI data format
  JdM    09-09-13   Added SaveSensorPositionsXYZ() (now called by virtual SaveSensorPositions() as default saving of positions)
  JdM    14-01-14   GetDataFormatType(). Relax demands for recognition of GE log type: recognize PPG files, test case insensitive.
  JdM    19-05-14   GetDataFormatType(). Relax demands for recognition of BP files by squeezing out spaces and commas from header string.
  JdM    12-12-14   Added recognition of 64 bits variant of ANT data format (DataFormatType==U_DATFORM_ANT64)
  JdM    21-02-15   Added GetSkipChannelLabelFile()
  JdM    25-02-15   Bug Fix: Recognizing BioSemi Data (edf, with extension bdf).
  JdM    04-03-15   Added GetSensorSelection()
                    SaveSensorPositionsXYZ(). Only save selected sensors.
  JdM    08-03-15   Added GDF data format
  JdM    04-09-15   Bug fix recognizing BrainProducts format: use strlen() instead of sizeof() to truncate UString
  JdM    28-09-15   Added ReorderChannelsSensors()
  JdM    09-09-16   Added CopySensorIDsFromNames()
  JdM    13-05-17   Added GetMarkerTextFile() and ReplaceMarkers()
 */

#include <string.h>

#include "MEEGDataBase.h"
#include "Grid.h"
#include "MarkerArray.h"
#include "Directory.h"
#include "AnalyzeLine.h"
#include "GridFit.h"
#include "InterpolateSphere.h"
#include "InterpolateSensors.h"

/* Inititalize static (const) parameters. */
UString UMEEGDataBase::Properties = UString();

const int    UMEEGDataBase::MAXREF        =   50;
const int    UMEEGDataBase::MAXMEG        =  350;
const int    UMEEGDataBase::MAXEEG        =  300;
const int    UMEEGDataBase::MAXEKG        =   10;
const int    UMEEGDataBase::MAXEOG        =   10;
const int    UMEEGDataBase::MAXADC        =   20;
const int    UMEEGDataBase::MAXSSP        =   20;
const int    UMEEGDataBase::MAXCHAN       =  760;   // This value should be larger than MAXMEG+MAXEEG+ +MAXADC

const char* UMEEGDataBase::FILEID_MICROMED  = "* MICROMED  Brain-Quick file *";
const char* UMEEGDataBase::FILEID_BRAINPROD = "BrainVisionDataExchangeHea";
const char* UMEEGDataBase::FILEID_PHILLOG   = "(SWID ";

const char* UMEEGDataBase::GetDataFormatTypeText(DataFormatType DFT)
{
    switch(DFT)
    {
    case U_DATFORM_UNKNOWN:   return   "Unknown data format";
    case U_DATFORM_CTF:       return   "CTF format";
    case U_DATFORM_NEUROSCAN: return   "NeuroScan format";
    case U_DATFORM_MICROMED:  return   "MicroMed";
    case U_DATFORM_BRAINPROD: return   "BrainProducts";
    case U_DATFORM_EDF:       return   "European Data Format";
    case U_DATFORM_GDF:       return   "General Data Format";
    case U_DATFORM_MAP:       return   "MEG center .map format";
    case U_DATFORM_ASCII:     return   "ASCII format";
    case U_DATFORM_ECG:       return   "Sonata ECG format";
    case U_DATFORM_TXT:       return   "General text format";
    case U_DATFORM_PHILLOG:   return   "Philips fMRI log format";
    case U_DATFORM_GELOG:     return   "GE fMRI log format";
    case U_DATFORM_ANT:       return   "ANT format (32 bits)";
    case U_DATFORM_ANT64:     return   "ANT format (64 bits)";
    case U_DATFORM_FIFF:      return   "FIFF format";
    case U_DATFORM_TMSI:      return   "TMSI format";
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetDataFormatTypeText(). invalid index (DFT=%d)  .\n", DFT);
    return "Invalid format";
};

const char* UMEEGDataBase::GetDataTypeText(DataType DT)
{
    switch(DT)
    {
    case U_DAT_UNKNOWN:       return   "Unknown data type";
    case U_DAT_MEG:           return   "MEG data";
    case U_DAT_MEGREF:        return   "MEG reference data";
    case U_DAT_EEG:           return   "EEG data";
    case U_DAT_EEGREF:        return   "EEG reference data";
    case U_DAT_SSP:           return   "SSP dipole";
    case U_DAT_EKG:           return   "EKG data";
    case U_DAT_EOG:           return   "EOG data";
    case U_DAT_EMG :          return   "EMG data";
    case U_DAT_ADC:           return   "ADC data";
    case U_DAT_STIM:          return   "Trigger/Stimulus data";
    case U_DAT_ANNOT:         return   "Annotation";
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetDataTypeText(). invalid index (DT=%d)  .\n", DT);
    return "Invalid data type";
};

const char* UMEEGDataBase::GetUnitText(DataType DT)
{
    switch(DT)
    {
    case U_DAT_UNKNOWN:       return   "a.u.";
    case U_DAT_MEG:           return   "fT";
    case U_DAT_MEGREF:        return   "fT";
    case U_DAT_EEG:           return   "uV";
    case U_DAT_EEGREF:        return   "uV";
    case U_DAT_SSP:           return   "nAcm";
    case U_DAT_EKG:           return   "uV";
    case U_DAT_EOG:           return   "uV";
    case U_DAT_EMG :          return   "uV";
    case U_DAT_ADC:           return   "V";
    case U_DAT_STIM:          return   "boolean";
    case U_DAT_ANNOT:         return   "a.u.";
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetUnitText(). invalid index (DT=%d)  .\n", DT);
    return "AU";
}
const char* UMEEGDataBase::GetReReferenceText(ReReferenceType RRT)
{
    switch(RRT)
    {
    case U_REF_RAW:           return   "No re-referencing, data raw";
    case U_REF_AVERAGE:       return   "Rereference EEG to average reference";
    case U_REF_GROUPAVER:     return   "Rereference EEG to sub-group average reference";
    case U_REF_COMMON:        return   "Rereference EEG to common reference";
    case U_REF_LAPLACIAN:     return   "Rereference EEG to Laplacian reference";
    case U_REF_UNBALANCED:    return   "Rereference MEG by removing all gradient signals (unbalanced)";
    case U_REF_FIRST:         return   "Rereference MEG to first gradient";
    case U_REF_SECOND:        return   "Rereference MEG to second gradient";
    case U_REF_THIRD:         return   "Rereference MEG to third gradient";
    case U_REF_SECONDFORWARD: return   "Second gradient, forward modeling";
    case U_REF_THIRDFORWARD:  return   "Third gradient, forward modeling";
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetReReferenceText(). invalid index (RRT=%d)  .\n", RRT);
    return "Invalid re-reference type";
};

DataType UMEEGDataBase::GetDataType(int itype)
{
    switch(itype)
    {
    case  0: return  U_DAT_UNKNOWN;
    case  1: return  U_DAT_MEG;
    case  2: return  U_DAT_MEGREF;
    case  3: return  U_DAT_EEG;
    case  4: return  U_DAT_EEGREF;
    case  5: return  U_DAT_SSP;
    case  6: return  U_DAT_EKG;
    case  7: return  U_DAT_EOG;
    case  8: return  U_DAT_EMG;
    case  9: return  U_DAT_ADC;
    case 10: return  U_DAT_STIM;
    case 11: return  U_DAT_ANNOT;
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetDataType(). invalid index (itype=%d)  .\n", itype);
    return U_DAT_UNKNOWN;
}

DataFormatType UMEEGDataBase::GetDataFormatType(UFileName FileName)
{
    UFileName FTest(FileName);
    const char* Ext = FTest.GetExtension();
    if(IsStringCompatible(Ext, "eeg", false)==true)
    {
        FTest.ReplaceExtension("vhdr");
        Ext  = FTest.GetExtension();
    }
    if(IsStringCompatible(Ext, "ds", false)==true)
    {
        UDirectory DS(FTest.GetFullFileName(), CNULL);
        if(DS.GetStatus()==UDirectory::U_EXIST) return U_DATFORM_CTF;
    }

    FILE* fp = fopen(FTest, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetDataFormatType().  File cannot be opened : %s  \n", FTest.GetFullFileName());
        return U_DATFORM_UNKNOWN;
    }
    char FileID[100];
    if(1!=fread(FileID, sizeof(FileID), 1, fp))
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetDataFormatType().  Reading identifier from file : %s  \n", FTest.GetFullFileName());
        return U_DATFORM_UNKNOWN;
    }
    fclose(fp);
    if(!memcmp(FileID,"POLY SAMPLE FILEversion",23)) return U_DATFORM_TMSI;

    if(IsStringCompatible(Ext, "res4", false)==true)
    {
        if(!memcmp(FileID,"MEG4RES",8)) return U_DATFORM_CTF;
        if(!memcmp(FileID,"MEG41RS",8)) return U_DATFORM_CTF;
        if(!memcmp(FileID,"MEG42RS",8)) return U_DATFORM_CTF;
    }
    if(IsStringCompatible(Ext, "meg4", false)==true)
    {
        if(!memcmp(FileID,"MEG42CP",8)) return U_DATFORM_CTF;
        if(!memcmp(FileID,"MEG41CP",8)) return U_DATFORM_CTF;
        if(!memcmp(FileID,"MEG4CPT",8)) return U_DATFORM_CTF;
    }
    if(IsStringCompatible(Ext, "fif", false)==true)
    {
        int kind = FileID[ 3] + 256*FileID[ 2] + 65536*FileID[ 1] + 16777216*FileID[ 0];
        int type = FileID[ 7] + 256*FileID[ 6] + 65536*FileID[ 5] + 16777216*FileID[ 4];
        int size = FileID[11] + 256*FileID[10] + 65536*FileID[ 9] + 16777216*FileID[ 8];

        if(kind==100 && type==31 && size==20) return U_DATFORM_FIFF;
    }
    if(IsStringCompatible(Ext, "map", false)==true)
    {
        if(!memcmp(FileID,"MAPFILE",7)) return U_DATFORM_MAP;
    }
    if(IsStringCompatible(Ext, "TRC", false)==true)
    {
        if(!memcmp(FileID,FILEID_MICROMED,sizeof(FILEID_MICROMED)-1))   return U_DATFORM_MICROMED;
    }
    if(IsStringCompatible(Ext, "vhdr", false)==true)
    {
        UString Header(FileID);
        Header.RemoveChar(' ');
        Header.RemoveChar(',');
        Header.Truncate(int(strlen(FILEID_BRAINPROD)));
        if(Header==UString(FILEID_BRAINPROD)) return U_DATFORM_BRAINPROD;
    }
    if(IsStringCompatible(Ext, "cnt", false)==true)
    {
        if(!memcmp(FileID,"Version 3.0",10)) return U_DATFORM_NEUROSCAN;
        if(!strncmp(FileID,"EEP V2.0",   8)) return U_DATFORM_ANT;
        if(!strncmp(FileID,"RIFF",       4) && !strncmp(FileID+8,"CNT ",  4)) return U_DATFORM_ANT;
        if(!strncmp(FileID,"RF64",       4)                                 ) return U_DATFORM_ANT64;
    }
    if(IsStringCompatible(Ext, "AVR", false)==true || IsStringCompatible(Ext, "ELA", false)==true)
    {
        return U_DATFORM_ASCII;
    }
    if(IsStringCompatible(Ext, "txt", false)==true)
    {
        return U_DATFORM_TXT;
    }
    if(IsStringCompatible(Ext, "log", false)==true)
    {
        if(strstr(FileID, FILEID_PHILLOG))   return U_DATFORM_PHILLOG;
    }
    if(IsStringCompatible(Ext, "ecg", false)==true || IsStringCompatible(Ext, "puls", false)==true || IsStringCompatible(Ext, "resp", false)==true)
    {
        return U_DATFORM_ECG;
    }
    if(IsStringCompatible(Ext, "edf", false)==true || IsStringCompatible(Ext, "bdf", false)==true)
    {
        return U_DATFORM_EDF;
    }
    if(IsStringCompatible(Ext, "gdf", false)==true)
    {
        if(!strncmp(FileID,"GDF", 3)) return U_DATFORM_GDF;
        if(!strncmp(FileID,"gdf", 3)) return U_DATFORM_GDF;
        return U_DATFORM_GDF;
    }
    if(FileName.HasAnyExtension()==false)
    {
        UString F(FileName.GetBaseName());
        bool CaseSense = false;
        if(F.IsBegining("ECG" ,CaseSense))  return U_DATFORM_GELOG;
        if(F.IsBegining("PPG" ,CaseSense))  return U_DATFORM_GELOG;
        if(F.IsBegining("RESP",CaseSense))  return U_DATFORM_GELOG;
    }
    FileID[sizeof(FileID)-10] = 0;
    CI.AddToLog("Note: UMEEGDataBase::GetDataFormatType().  Unrecognized file. FTest = %s, FileID = %s\n", FTest.GetFullFileName(), FileID);

    return U_DATFORM_UNKNOWN;
}

void UMEEGDataBase::SetAllMembersDefault(void)
{
    error          = U_OK;
    DataFormat     = U_DATFORM_UNKNOWN;
    DateTimeRec    = UDateTime(20000101);
    ContineousData = false;
    memset(PatName, 0, sizeof(PatName));
    memset(PatID,   0, sizeof(PatID));
    srate          = 0.;
    nsamp          = 0;
    ntrial         = 0;
    NPreTrig       = 0;
    nAver          = 0;
    GeneralComment = UString();

    NchannelRaw    = 0;
    NchannelTot    = 0;
    ChIn           = NULL;
    GridAll        = NULL;

    nREF           = 0;
    GridREF        = NULL;
    nMEG           = 0;
    GridMEG        = NULL;
    nEEG           = 0;
    GridEEG        = NULL;
    NewCommonRef   = -1;
    EEGposTrue     = false;
    EEGlabelTrue   = false;

    STIM           = false;
    nADC           = 0;
    GridADC        = NULL;
    nSSP           = 0;
    GridSSP        = NULL;

    Markers        = NULL;
    NLR[0]         = UVector3();   // Nasion
    NLR[1]         = UVector3();   // Left
    NLR[2]         = UVector3();   // Right

    LaplaceRef     = NULL;
    CTFSensorInter = NULL;
}

void UMEEGDataBase::DeleteAllMembers(ErrorType E)
{
    delete[] ChIn;
    delete   GridAll;

    delete   GridREF;
    delete   GridMEG;
    delete   GridEEG;
    delete   GridADC;
    delete   GridSSP;

    delete   Markers;
    delete   LaplaceRef;
    delete   CTFSensorInter;

    SetAllMembersDefault();
    error = E;
}

UMEEGDataBase::UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataBase::~UMEEGDataBase()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataBase::UMEEGDataBase(const UMEEGDataBase& Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataBase.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataBase& UMEEGDataBase::operator=(const UMEEGDataBase &Data)
{
    if(this==NULL)
    {
        static UMEEGDataBase DumDat;
        CI.AddToLog("ERROR: UMEEGDataBase::operator=(). this has NULL address. \n");
        return DumDat;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    DeleteAllMembers(U_OK);

    DataFormat     = Data.DataFormat;
    ContineousData = Data.ContineousData;
    memcpy(PatName, Data.PatName, sizeof(PatName)-1);
    memcpy(PatID,   Data.PatID,   sizeof(PatID)-1);
    srate          = Data.srate;
    nsamp          = Data.nsamp;
    ntrial         = Data.ntrial;
    NPreTrig       = Data.NPreTrig;
    nAver          = Data.nAver;

    DataFileName   = Data.DataFileName;
    DateTimeRec    = Data.DateTimeRec;
    GeneralComment = Data.GeneralComment;

    NchannelRaw    = Data.NchannelRaw;
    NchannelTot    = Data.NchannelTot;
    ChIn           = new ChanInfo[MAXCHAN];
    GridAll        = new UGrid(MAXCHAN);
    if( ChIn    == NULL || Data.ChIn    == NULL ||
        GridAll == NULL || Data.GridAll == NULL ||
        GridAll->GetError()!=U_OK || Data.GridAll->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataBase::operator=(). channel info MAXCHAN = %d . \n", MAXCHAN);
        return *this;
    }
    memcpy(ChIn, Data.ChIn, MAXCHAN*sizeof(ChanInfo));
    *GridAll = *Data.GridAll;

    nREF     = Data.nREF;
    if(nREF)
    {
        GridREF    = new UGrid(*Data.GridREF);
        if(GridREF==NULL || GridREF->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). copying MEG reference info. \n");
            return *this;

        }
    }
    nMEG     = Data.nMEG;
    if(nMEG)
    {
        GridMEG    = new UGrid(*Data.GridMEG);
        if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). copying MEG channel info. \n");
            return *this;

        }
    }
    nEEG     = Data.nEEG;
    if(nEEG)
    {
        GridEEG    = new UGrid(*Data.GridEEG);
        if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). copying EEG channel info. \n");
            return *this;

        }
    }
    EEGposTrue   = Data.EEGposTrue;
    EEGlabelTrue = Data.EEGlabelTrue;
    NewCommonRef = Data.NewCommonRef;

    STIM         = Data.STIM;
    nADC         = Data.nADC;
    if(nADC)
    {
        GridADC    = new UGrid(*Data.GridADC);
        if(GridADC==NULL || GridADC->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). copying ADC channel info. \n");
            return *this;

        }
    }
    nSSP         = Data.nSSP;
    if(nSSP)
    {
        GridSSP    = new UGrid(*Data.GridSSP);
        if(GridSSP==NULL || GridSSP->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). copying SSP channel info. \n");
            return *this;

        }
    }

    if(Data.Markers)
    {
        Markers = new UMarkerArray(*Data.Markers);
        if(Markers==NULL || Markers->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). Copying Markers. \n");
            return *this;
        }
    }
    for(int k=0; k<3; k++) NLR[k] = Data.NLR[k];

    if(Data.LaplaceRef)
    {
        LaplaceRef = new UInterpolateSphere(*Data.LaplaceRef);
        if(LaplaceRef==NULL || LaplaceRef->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). Copying LaplaceRef. \n");
            return *this;
        }
    }
    if(Data.CTFSensorInter)
    {
        CTFSensorInter = new UInterpolateSensors(*Data.CTFSensorInter);
        if(CTFSensorInter==NULL || CTFSensorInter->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataBase::operator=(). Copying CTFSensorInter. \n");
            return *this;
        }
    }
    return *this;
}

double UMEEGDataBase::GetSampleTime_s(void) const
{
    if(srate>=0) return 1./srate;

    CI.AddToLog("ERROR: UMEEGDataBase::GetSampleTime_s(). Invalid sample rate: srate = %f \n", srate);
    return 1.;
}

bool UMEEGDataBase::IsAveragedData(void) const
{
    if(nAver>1) return true;
    return false;
}

const char* UMEEGDataBase::GetCommonReferenceLabel(void) const
{
    if(NewCommonRef<0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetCommonReferenceLabel(). Data not set as common reference. \n");
        return NULL;
    }
    if(GridEEG)
    {
        if(NewCommonRef>=GridEEG->GetNpoints())
        {
            CI.AddToLog("ERROR: UMEEGDataBase::GetCommonReferenceLabel(). Reference channel (%d) does not refer to proper EEG channel. \n", NewCommonRef);
            return NULL;
        }
        return GridEEG->GetName(NewCommonRef);
    }
    else
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetCommonReferenceLabel(). (EEG) Grid not set.\n");
        return NULL;
    }
}

ErrorType UMEEGDataBase::SetCommonRef(const char* RefLabel)
{
    if(GridAll==NULL || GridEEG==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetCommonRef(). (EEG) Grid not set. \n");
        return U_ERROR;
    }
    if(RefLabel==NULL)
    {
        NewCommonRef = -1;
        return U_OK;
    }

    DataType DT   = U_DAT_UNKNOWN;
    int      Iref = GetChanAndType(RefLabel, &DT);
    if(Iref<0 || DT!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetCommonRef(). Label (%s) is not valid EEG label. \n", RefLabel);
        return U_ERROR;
    }
    NewCommonRef = Iref;
    return U_OK;
}

ErrorType UMEEGDataBase::ConvertDataType(DataType DTOLD, DataType DTNEW)
{
    if(ChIn==NULL || GridAll==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ConvertDataType(). Grids not set. \n");
        return U_ERROR;
    }
    if(DTOLD==U_DAT_MEG || DTOLD==U_DAT_MEGREF || DTOLD==U_DAT_EEGREF ||
       DTNEW==U_DAT_MEG || DTNEW==U_DAT_MEGREF || DTNEW==U_DAT_EEGREF)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ConvertDataType(). Cannot convert channel from %s to %s \n", UMEEGDataBase::GetDataTypeText(DTOLD), UMEEGDataBase::GetDataTypeText(DTNEW));
        return U_ERROR;
    }

/*Convert*/
    for(int i=0; i<MAXCHAN; i++)
        if(ChIn[i].type==DTOLD)
        {
            ChIn[i].type = DTNEW;
            switch(DTNEW)
            {
            case U_DAT_EEG:  GridAll->SetSensorType(USensor::U_SEN_EEG   ,i); break;
            case U_DAT_SSP:  GridAll->SetSensorType(USensor::U_SEN_VECTOR,i); break;
            case U_DAT_ADC:  GridAll->SetSensorType(USensor::U_SEN_POINT ,i); break;
            case U_DAT_MEG:  GridAll->SetSensorType(USensor::U_SEN_GRAD  ,i); break;
            default:         GridAll->SetSensorType(USensor::U_SEN_NOTYPE,i); break;
            }
            GridAll->SetName(ChIn[i].namChannel, i);
        }

    if(DTOLD==U_DAT_EEG || DTNEW==U_DAT_EEG)
    {
        if(SetLaplacianReferenceMatrix()!=U_OK)
            CI.AddToLog("ERROR: UMEEGDataBase::ConvertDataType(). Setting new Laplacian reference matrix \n");
    }
/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::RemoveChannels(const char * const*BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::RemoveChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(BadChan==NULL) return U_OK;

/* Count the bad channels which are to be removed. */
    int nBad  = 0;
    while(* BadChan[ nBad]) nBad++;
    if(nBad<=0)       return U_OK;

/* Set skip flag */
    for(int i=0;i<MAXCHAN; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;

        if(ChIn[i].type == U_DAT_MEGREF)  continue; // Never skip reference channel

        for(int ibad=0;ibad<nBad;ibad++)
            if(IsStringCompatible(ChIn[i].namChannel, BadChan[ibad], false)==true)
            {
                ChIn[i].SkipChannel = true;
                break;
            }
    }

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::CopyChannelSelection(const UMEEGDataBase* Data)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::CopyChannelSelection(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::CopyChannelSelection(). In valid NULL or erroneous argument. \n");
        return U_ERROR;
    }

/* Set skip flag */
    const ChanInfo* ChDat = Data->ChIn;
    for(int i=0;i<MAXCHAN; i++)
    {
        ChIn[i].SkipChannel = false;
        if(ChIn[i].type == U_DAT_MEGREF) continue; // Never skip reference channel

        ChIn[i].SkipChannel = true;
        for(int ii=0; ii<MAXCHAN; ii++)
        {
            if(ChIn[i].type!=ChDat[ii].type) continue;
            if(IsStringCompatible(ChIn[i].namChannel, ChDat[ii].namChannel, false)==true)
                ChIn[i].SkipChannel = ChDat[ii].SkipChannel;
        }
    }

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SelectChannels(const char * const*GoodChan, const char * const*BadChan)
/*
    Prepare the object in such a way that next time, GetGrid(), GetGridMEG(), GetEpoch_d(),
    GetNmeg(), etc. is called, only the channels with labels compatible to GoodChan[]
    and not those compatible to BadChan[] are considered.

  Notes:
    -both arrays GoodChan and BadChan should end with a NULL pointer,
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    int nGood = 0;    if(GoodChan) while(*GoodChan[nGood]) nGood++;
    int nBad  = 0;    if(BadChan)  while(* BadChan[ nBad]) nBad++;

/* Set skip flag */
    for(int i=0;i<MAXCHAN; i++)
    {
        ChIn[i].SkipChannel = false;
        if(ChIn[i].type == U_DAT_MEGREF) continue; // Never skip reference channel
        if(BadChan)
        {
            for(int ibad=0;ibad<nBad;ibad++)
                if(IsStringCompatible(ChIn[i].namChannel, BadChan[ibad], false)==true)
                {
                    ChIn[i].SkipChannel = true;
                    break;
                }
        }
        if(ChIn[i].SkipChannel==true) continue;

        if(GoodChan)
        {
            ChIn[i].SkipChannel = true;
            for(int igood=0;igood<nGood;igood++)
            {
                if(IsStringCompatible(ChIn[i].namChannel, GoodChan[igood], false)==true)
                {
                    ChIn[i].SkipChannel = false;
                    break;
                }
            }
        }
    }

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SelectChannels(const char* GoodChan, const char* BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    char**    pGood = NULL;
    char**    pBad  = NULL;
    int       NStrG = 0;
    int       NStrB = 0;
    ErrorType E     = U_OK;
    if(E==U_OK && GoodChan)  E = GetNamesFromString(GoodChan, 10, &NStrG, &pGood);
    if(E==U_OK && BadChan )  E = GetNamesFromString(BadChan , 10, &NStrB, &pBad );

    if(E==U_OK) E = SelectChannels(pGood, pBad);
    else        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). Converting strings .\n");

    if(pGood)
    {
        for(int n=0; n<NStrG+1; n++) delete[] pGood[n];
        delete[] pGood;
    }
    if(pBad)
    {
        for(int n=0; n<NStrB+1; n++) delete[] pBad[n];
        delete[] pBad;
    }
    return E;
}

ErrorType UMEEGDataBase::SelectChannels(const ChanInfo* NewChIn)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NewChIn==NULL)
    {
        CI.AddToLog("UMEEGDataBase::SelectChannels(). Erroneous NULL argument. \n");
        return U_ERROR;
    }
    memcpy(ChIn, NewChIn, MAXCHAN*sizeof(ChanInfo));
    for(int i=0;i<MAXCHAN; i++)
        if(ChIn[i].type == U_DAT_MEGREF) ChIn[i].SkipChannel = false; // Never skip reference channel

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SelectChannels(DataType DT0, DataType DT1, DataType DT2, DataType DT3)
/*
    Exclusively select data types DT0, DT1, DT2 and DT3.
    Values equal to U_DAT_UNKNOWN are ignored.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    for(int i=0;i<MAXCHAN; i++)
    {
        if(ChIn[i].type == U_DAT_MEGREF)
        {
            ChIn[i].SkipChannel = false; // Never skip reference channel
            continue;
        }
        ChIn[i].SkipChannel = true;
        if(DT0!=U_DAT_UNKNOWN && DT0==ChIn[i].type) ChIn[i].SkipChannel = false;
        if(DT1!=U_DAT_UNKNOWN && DT1==ChIn[i].type) ChIn[i].SkipChannel = false;
        if(DT2!=U_DAT_UNKNOWN && DT2==ChIn[i].type) ChIn[i].SkipChannel = false;
        if(DT3!=U_DAT_UNKNOWN && DT3==ChIn[i].type) ChIn[i].SkipChannel = false;
    }

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SelectChannels(DataType DT0, const char* GoodChan, const char* BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(SelectChannels(GoodChan, BadChan)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). Selecting Good channels and Bad channels. \n");
        return U_ERROR;
    }
    for(int i=0;i<MAXCHAN; i++)
        if(ChIn[i].type == U_DAT_MEGREF)
        {
            ChIn[i].SkipChannel = false; // Never skip reference channel
            continue;
        }

    if(DT0==U_DAT_UNKNOWN) return U_OK;

    for(int i=0;i<MAXCHAN; i++)
    {
        if(ChIn[i].type == U_DAT_MEGREF)
        {
            ChIn[i].SkipChannel = false; // Never skip reference channel
            continue;
        }
        if(ChIn[i].SkipChannel==true) continue;

        ChIn[i].SkipChannel = (DT0!=ChIn[i].type);
    }

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SelectChannels(const UGrid* GridLabels)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(GridLabels==NULL || GridLabels->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). Erroneous or NULL argument. \n");
        return U_ERROR;
    }

    ChanInfo* ChInCopy = GetChanInfo();
    if(ChInCopy==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). Getting restore buffer with channel info. \n");
        return U_ERROR;
    }

    for(int i=0; i<MAXCHAN; i++)
    {
        if(ChIn[i].type == U_DAT_MEGREF) ChIn[i].SkipChannel = false;
        else                             ChIn[i].SkipChannel = true;
    }
    for(int ic=0; ic<GridLabels->GetNpoints(); ic++)
    {
        const char* Name  = GridLabels->GetName(ic);
        bool        Found = false;
        for(int i=0; i<MAXCHAN; i++)
        {
            if(IsStringCompatible(ChIn[i].namChannel, Name, false)==true)
            {
                ChIn[i].SkipChannel = false;
                Found               = true;
                break;
            }
        }
        if(Found==false)
        {
            for(int i=0; i<MAXCHAN; i++)
                ChIn[i].SkipChannel = ChInCopy[i].SkipChannel;
            delete[] ChInCopy;
            CI.AddToLog("ERROR: UMEEGDataBase::SelectChannels(). Label %s not found and cannot be selected. Old selection restored. \n", Name);
            return U_ERROR;
        }
    }
    delete[] ChInCopy;

/* Update grid and reference index info */
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::UpdateChannelColors(const ChanInfo* ChInNew, const UGrid* GSel)
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelColors(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(NchannelTot==0 || ChIn==NULL || GridAll==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelColors(). Object not properly set.\n");
        return U_ERROR;
    }
    if(ChInNew==NULL || GSel==NULL || GSel->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelColors(). Invalid (NULL) argument(s). \n");
        return U_ERROR;
    }
    for(int ic=0; ic<GSel->GetNpoints(); ic++)
    {
        const char* Name  = GSel->GetName(ic);
        bool        Found = false;
        int         ir=-1,ig=-1,ib=-1;
        for(int i=0; i<MAXCHAN; i++)
        {
            if(IsStringCompatible(ChInNew[i].namChannel, Name, false)==true)
            {
                ir    = ChInNew[i].Red;
                ig    = ChInNew[i].Green;
                ib    = ChInNew[i].Blue;
                Found = true;
                break;
            }
        }
        if(Found==false||ir<0||ig<0||ib<0) continue;
        for(int i=0; i<MAXCHAN; i++)
        {
            if(IsStringCompatible(ChIn[i].namChannel, Name, false)==true)
            {
                ChIn[i].Red      = ir;
                ChIn[i].Green    = ig;
                ChIn[i].Blue     = ib;
            }
        }
    }
    return U_OK;
}
ErrorType UMEEGDataBase::UpdateChannelGroups(const UGrid* GSel)
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelGroups(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(NchannelTot==0 || ChIn==NULL || GridAll==NULL || GridAll->GetGroup()==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelGroups(). Object not properly set.\n");
        return U_ERROR;
    }
    if(GSel==NULL || GSel->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateChannelColors(). Invalid (NULL) argument(s). \n");
        return U_ERROR;
    }
    bool ReplaceAny = false;
    for(int i=0; i<GridAll->GetNpoints(); i++)
    {
        USensor  S  = GridAll->GetSensor(i);
        int      is = GSel->GetChannum(S.GetName());
        if(is<0 || is>=GSel->GetNpoints()) continue;

        int GroupID = GSel->GetGroupID(is);
        GridAll->SetGroupID(GroupID, i);
        ReplaceAny = true;
    }
    if(ReplaceAny==true) GridAll->UpdateGroups();
/* Update grid and reference index info */
    return UpdateSensorGrids();
}
ErrorType UMEEGDataBase::ReplaceSensorPositions(const UGrid* GrNew, DataType DT)
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceSensorPositions(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(NchannelTot==0 || ChIn==NULL || GridAll==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceSensorPositions(). Object not properly set.\n");
        return U_ERROR;
    }
    if(GrNew==NULL || GrNew->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceSensorPositions(). New sensors NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DT!=U_DAT_MEG && DT!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceSensorPositions(). Wrong data type (DT = %d ) .\n", DT);
        return U_ERROR;
    }

/* Test if all sensors can be found. */
    ErrorType E = U_OK;
    for(int i=0; i<NchannelTot; i++)
    {
        USensor S = GridAll->GetSensor(i);
        if( (DT==U_DAT_MEG && (S.GetStype()==USensor::U_SEN_MAG || S.GetStype()==USensor::U_SEN_GRAD)) ||
            (DT==U_DAT_EEG &&  S.GetStype()==USensor::U_SEN_EEG  ) )
        {
            int is = GrNew->GetChannum(S.GetName());
            if(is<0 || is>=GrNew->GetNpoints())
            {
                if(ChIn[i].SkipChannel==true)
                {
                    CI.AddToLog("WARNING: UMEEGDataBase::ReplaceSensorPositions(). Label of skipped sensor not found in template: %s \n", S.GetName());
                }
                else
                {
                    CI.AddToLog("ERROR: UMEEGDataBase::ReplaceSensorPositions(). Label of selected sensor not found in template: %s \n", S.GetName());
                    E = U_ERROR;
                }
            }
        }
    }
    if(E!=U_OK) return U_ERROR;

/* Test OK, replace all sensor positions */
    for(int i=0; i<NchannelTot; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;

        USensor S = GridAll->GetSensor(i);
        if( (DT==U_DAT_MEG && (S.GetStype()==USensor::U_SEN_MAG || S.GetStype()==USensor::U_SEN_GRAD)) ||
            (DT==U_DAT_EEG &&  S.GetStype()==USensor::U_SEN_EEG  ) )
        {
            int is = GrNew->GetChannum(S.GetName());
            S.Setx(GrNew->GetPosition(is));
            S.Setc(GrNew->GetPositionCompCoil(is));
            S.Setn(GrNew->GetOrientation(is));
            GridAll->SetSensor(&S, i);
        }
    }
    if(DT==U_DAT_EEG) EEGposTrue = true;

    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::SaveSensorPositions(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SaveSensorPositions(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    return SaveSensorPositionsXYZ();
}
ErrorType UMEEGDataBase::SaveSensorPositionsXYZ(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SaveSensorPositionsXYZ(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SaveSensorPositionsXYZ(). Object not properly set, GridAll NULL or erroneous. \n");
        return U_ERROR;
    }
    UFileName  FXYZ = DataFileName; FXYZ.SetExtension("xyz");
    bool* Selection = GetSensorSelection();
    if(Selection==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SaveSensorPositionsXYZ(). Getting sensor selection. \n");
        return U_ERROR;
    }
    if(GridAll->WriteXYZ(FXYZ, Selection)!=U_OK)
    {
        delete[] Selection;
        CI.AddToLog("ERROR: UMEEGDataBase::SaveSensorPositionsXYZ(). Writing EEG electrodes to %s .\n", (const char*)FXYZ);
        return U_ERROR;
    }
    delete[] Selection;
    return U_OK;
}

ErrorType UMEEGDataBase::UpdateElectrodePositions(UFileName FilePos)
{
    return UpdateElectrodePositions(FilePos.GetFullFileName());
}
ErrorType UMEEGDataBase::UpdateElectrodePositions(const char* FilePos)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateElectrodePositions(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(NchannelTot==0 || ChIn==NULL || GridAll==NULL || GridEEG==NULL || nEEG==0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateElectrodePositions(). Object not properly set, nEEG =. \n", nEEG);
        return U_ERROR;
    }
    if(FilePos==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateElectrodePositions(). NULL pointer argument. \n");
        return U_ERROR;
    }
    FILE* fp=fopen(FilePos, "rt");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateElectrodePositions(). Cannot open %s . \n", FilePos);
        return U_ERROR;
    }
    int  Nupdate  = 0;
    char line[400];
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line);
        double x   = AA.GetNextDouble(0.);
        double y   = AA.GetNextDouble(0.);
        double z   = AA.GetNextDouble(0.);
        const char* Label = AA.GetNextString(sizeof(ChIn[0].namChannel)-1);
        DataType    DT    = U_DAT_UNKNOWN;
        int         isens = GetChanAndType(Label, &DT);
        int         index = GetChannelIndex(Label);
        if(DT!=U_DAT_EEG || isens<0 || index<0) continue;

        USensor   S(0.1*UVector3(x, y, z));
        S.SetName(Label);
        S.SetStype(USensor::U_SEN_EEG);
        ErrorType E = U_OK;
        if(E==U_OK) E = GridEEG->SetSensor(&S, isens);
        if(E==U_OK) E = GridAll->SetSensor(&S, index);

        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataBase::UpdateElectrodePositions(). Setting sensor %s \n", Label);
            continue;
        }
        Nupdate++;
    }
    fclose(fp);

    if(Nupdate!=nEEG)
        CI.AddToLog("WARNING: UMEEGDataBase::UpdateElectrodePositions(). Not all electrode positions updated: Nupdate = %d, nEEG = %d   . \n", Nupdate, nEEG);
    else
        EEGposTrue = true;

    return UpdateSensorGrids();
}
ErrorType UMEEGDataBase::CopyDataFiles(const char* BaseName)
{
    CI.AddToLog("ERROR: UMEEGDataBase::CopyDataFiles(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return U_ERROR;
}
ErrorType UMEEGDataBase::DeleteDataFiles(void) const
{
    CI.AddToLog("ERROR: UMEEGDataBase::DeleteDataFiles(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return U_ERROR;
}
ErrorType UMEEGDataBase::RenameDataFiles(const char* NewName)
{
    CI.AddToLog("ERROR: UMEEGDataBase::RenameDataFiles(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return U_ERROR;
}
UFileName UMEEGDataBase::GetSkipChannelLabelFile(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSkipChannelLabelFile(). Object NULL or erroneous.\n");
        return UFileName();
    }
    UFileName SkipFile = DataFileName;
    if(SkipFile.HasExtension("skptxt")) SkipFile.SetExtension(""); // Very odd condition, but never delete data file...
    SkipFile.SetExtension("skptxt");
    return SkipFile;
}
ErrorType UMEEGDataBase::UpdateDewar2Head(UEuler XFM)
{
    CI.AddToLog("ERROR: UMEEGDataBase::UpdateDewar2Head(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return U_ERROR;
}

UVector3 UMEEGDataBase::GetNLRMarker(int k) const
{
    if(k<0 || k>=3)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetNLRMarker(). Index out of range: k=%d  .\n", k);
        return UVector3();
    }
    return NLR[k];
}

ErrorType UMEEGDataBase::UpdateSensorGrids(void)
/*
    Update sensor grids, based on ChIn[] and *GridAll .
 */
{
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateSensorGrids(). Object not properly set. \n");
        return U_ERROR;
    }

    const char* CommonRefName = NULL;
    if(NewCommonRef>=0)
    {
        CommonRefName = GetCommonReferenceLabel();
        if(CommonRefName==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataBase::UpdateSensorGrids(). Getting EEG reference name. \n");
            return U_ERROR;
        }
    }

    delete GridREF; GridREF = new UGrid();
    delete GridMEG; GridMEG = new UGrid();
    delete GridEEG; GridEEG = new UGrid();
    delete GridADC; GridADC = new UGrid();
    delete GridSSP; GridSSP = new UGrid();

    if(GridREF==NULL || GridREF->GetError()!=U_OK ||
       GridMEG==NULL || GridMEG->GetError()!=U_OK ||
       GridEEG==NULL || GridEEG->GetError()!=U_OK ||
       GridADC==NULL || GridADC->GetError()!=U_OK ||
       GridSSP==NULL || GridSSP->GetError()!=U_OK)
    {
        delete GridREF; GridREF = NULL;nREF = 0;
        delete GridMEG; GridMEG = NULL;nMEG = 0;
        delete GridEEG; GridEEG = NULL;nEEG = 0;
        delete GridADC; GridADC = NULL;nADC = 0;
        delete GridSSP; GridSSP = NULL;nSSP = 0;
        CI.AddToLog("ERROR: UMEEGDataBase::UpdateSensorGrids(). Resetting grids. \n");
        return U_ERROR;
    }

/* Rebuild grids*/
    ErrorType E = U_OK;
    for(int i=0;i<NchannelTot; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;
        switch(ChIn[i].type)
        {
        case U_DAT_MEGREF: E=GridREF->AddSensor(GridAll->GetSensor(i)); break;
        case U_DAT_MEG   : E=GridMEG->AddSensor(GridAll->GetSensor(i)); break;
        case U_DAT_EEG   : E=GridEEG->AddSensor(GridAll->GetSensor(i)); break;
        case U_DAT_ADC   : E=GridADC->AddSensor(GridAll->GetSensor(i)); break;
        case U_DAT_SSP   : E=GridSSP->AddSensor(GridAll->GetSensor(i)); break;
        }
        if(E!=U_OK)
        {
            delete GridREF; GridREF = NULL;nREF = 0;
            delete GridMEG; GridMEG = NULL;nMEG = 0;
            delete GridEEG; GridEEG = NULL;nEEG = 0;
            delete GridADC; GridADC = NULL;nADC = 0;
            delete GridSSP; GridSSP = NULL;nSSP = 0;
            CI.AddToLog("ERROR: UMEEGDataBase::UpdateSensorGrids(). Adding sensor for channel %d. \n", i);
            return U_ERROR;
        }
    }

    nREF = GridREF->GetNpoints(); if(nREF<=0) {delete GridREF; GridREF=NULL;}
    nMEG = GridMEG->GetNpoints(); if(nMEG<=0) {delete GridMEG; GridMEG=NULL;}
    nEEG = GridEEG->GetNpoints(); if(nEEG<=0) {delete GridEEG; GridEEG=NULL;}
    nADC = GridADC->GetNpoints(); if(nADC<=0) {delete GridADC; GridADC=NULL;}
    nSSP = GridSSP->GetNpoints(); if(nSSP<=0) {delete GridSSP; GridSSP=NULL;}

/* Update reference index*/
    if(CommonRefName) return SetCommonRef(CommonRefName);
    return U_OK;
}
ErrorType UMEEGDataBase::ReorderChannelsSensors(const int* NewIndex, int Nindex)
{
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReorderChannelsSensors(). Object not properly set. \n");
        return U_ERROR;
    }
    if(NewIndex==NULL || Nindex==0 || Nindex>MAXCHAN)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReorderChannelsSensors(). Invalid (NULL) argument(s), Nindex = %d. \n", Nindex);
        return U_ERROR;
    }
    for(int k=0; k<Nindex; k++)
    {
        if(NewIndex[k]>=0 && NewIndex[k]<Nindex) continue;
        CI.AddToLog("ERROR: UMEEGDataBase::ReorderChannelsSensors(). Index out of range: NewIndex[%d] = %d. \n", k, NewIndex[k]);
        return U_ERROR;
    }

    ChanInfo* ChInNew = GetChanInfo();
    if(ChInNew==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReorderChannelsSensors(). Getting copy of ChIn. \n");
        return U_ERROR;
    }

    if(GridAll->ReorderSensors(NewIndex, Nindex)!=U_OK)
    {
        delete[] ChInNew;
        CI.AddToLog("ERROR: UMEEGDataBase::ReorderChannelsSensors(). Reordering sensors. \n");
        return U_ERROR;
    }
    for(int i=0;i<Nindex; i++)
    {
        int k = NewIndex[i];
        memcpy(ChInNew[i].namChannel, ChIn[k].namChannel, sizeof(ChIn[k].namChannel));
        ChInNew[i].type        = ChIn[k].type;
        ChInNew[i].SkipChannel = ChIn[k].SkipChannel;
        ChInNew[i].InGain      = ChIn[k].InGain;
        ChInNew[i].GainFact    = ChIn[k].GainFact;
        ChInNew[i].Offset      = ChIn[k].Offset;
        ChInNew[i].Red         = ChIn[k].Red;
        ChInNew[i].Green       = ChIn[k].Green;
        ChInNew[i].Blue        = ChIn[k].Blue;
        ChInNew[i].LT          = ChIn[k].LT;
    }
    delete[] ChIn; ChIn = ChInNew;
    return UpdateSensorGrids();
}

ErrorType UMEEGDataBase::RenameSensor(const char* OldName, const char* NewName, DataType DT)
{
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Object not properly set. \n");
        return U_ERROR;
    }
    if(OldName==NULL || NewName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }

/* Find Old channel */
    for(int i=0; i<NchannelTot; i++)
    {
        if(DT!=U_DAT_NTYPE && DT!=ChIn[i].type) continue;
        if(IsStringCompatible(OldName, ChIn[i].namChannel, false)==true)
        {
            strncpy(ChIn[i].namChannel, NewName, sizeof(ChIn[i].namChannel)-1);
            GridAll->SetName(ChIn[i].namChannel, i);
            if(UGrid::IsStandardEEGLabel(OldName)==false && UGrid::IsStandardEEGLabel(NewName)==true)
            {
                GridAll->SetPosition(UGrid::GetDefaultSensor(NewName).Getx(), i);
            }
            return UpdateSensorGrids();
        }
    }

    CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Label not found: %s \n", OldName);
    return U_ERROR;
}

ErrorType UMEEGDataBase::RenameSensor(const char* OldName, const char* NewName)
{
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Object not properly set. \n");
        return U_ERROR;
    }
    if(OldName==NULL || NewName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }

/* Find Old channel */
    for(int i=0; i<NchannelTot; i++)
    {
        if(IsStringCompatible(OldName, ChIn[i].namChannel, false)==true)
        {
            strncpy(ChIn[i].namChannel, NewName, sizeof(ChIn[i].namChannel)-1);
            GridAll->SetName(ChIn[i].namChannel, i);
            if(UGrid::IsStandardEEGLabel(OldName)==false && UGrid::IsStandardEEGLabel(NewName)==true)
            {
                GridAll->SetPosition(UGrid::GetDefaultSensor(NewName).Getx(), i);
            }
            return UpdateSensorGrids();
        }
    }

    CI.AddToLog("ERROR: UMEEGDataBase::RenameSensor(). Label not found: %s \n", OldName);
    return U_ERROR;
}

ErrorType UMEEGDataBase::CopySensorIDsFromNames(const UGrid* G)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::CopySensorIDsFromNames(). GridAll not set. \n");
        return U_ERROR;
    }
    if(G==NULL || G->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::CopySensorIDsFromNames(). Argument NULL or erroneous. \n");
        return U_ERROR;
    }
    if(GridAll->CopyIDsFromNames(G)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::CopySensorIDsFromNames(). Setting CTF sensorgroups. \n");
        return U_ERROR;
    }
    return UpdateSensorGrids();
}
ErrorType UMEEGDataBase::SetCTFSensorGroups(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetCTFSensorGroups(). GridAll not set. \n");
        return U_ERROR;
    }
    if(GridAll->SetCTFSensorGroups()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetCTFSensorGroups(). Setting CTF sensorgroups. \n");
        return U_ERROR;
    }
    return UpdateSensorGrids();
}

UGrid* UMEEGDataBase::GetSelectedGrid(DataType DT) const
/*
    Return a UGrid, with all selected (non-skipped) sensors of data type DT
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSelectedGrid(). Object NULL or erroneoes. \n");
        return NULL;
    }
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSelectedGrid(). Object not properly set. \n");
        return NULL;
    }
    UGrid* Grid = new UGrid();
    if(Grid==NULL||Grid->GetError()!=U_OK)
    {
        delete Grid;
        CI.AddToLog("ERROR: UMEEGDataBase::GetSelectedGrid(). Creating empty UGrid(). \n");
        return NULL;
    }

/* Build grids*/
    int nAdd = 0;
    for(int i=0;i<MAXCHAN; i++)
    {
        if(ChIn[i].SkipChannel==true||
           ChIn[i].type       !=DT    ) continue;

        if(Grid->AddSensor(GridAll->GetSensor(i))!=U_OK)
        {
            delete Grid; Grid = NULL;
            CI.AddToLog("ERROR: UMEEGDataBase::GetSelectedGrid(). Adding sensor for channel %d. \n", i);
            return NULL;
        }
        Grid->SetName(ChIn[i].namChannel, nAdd);
        nAdd++;
    }
    return Grid;
}
bool* UMEEGDataBase::GetSensorSelection(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensorSelection(). Object NULL or erroneoes. \n");
        return NULL;
    }
    if(ChIn==NULL || GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensorSelection(). Object not properly set. \n");
        return NULL;
    }
    int   NP        = GridAll->GetNpoints();
    bool* Selection = new bool[NP];
    if(Selection==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensorSelection(). Memory allocation error (NP=%d). \n", NP);
        return NULL;
    }
    for(int i=0; i<NP; i++) Selection[i] = NOT(ChIn[i].SkipChannel) && ChIn[i].type!=U_DAT_UNKNOWN;
    return Selection;
}

UEuler UMEEGDataBase::GetDewar2NLR(void) const
{
    CI.AddToLog("WARNING: UMEEGDataBase::GetDewar2NLR(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return UEuler();
}

const USensor* UMEEGDataBase::GetSensor(const char* Label) const
/*
   Return the sensor corresponding to channel index coresponding to Label[]
 */
{
    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensor(). GridAll not set. \n");
        return NULL;
    }
    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensor(). Invalid NULL argument. \n");
        return NULL;
    }
    int index = GetChannelIndex(Label);
    if(index<0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensor(). Label (%s) not present in data file. \n", Label);
        return NULL;
    }
    return GridAll->GetSensorPointer(index);
}

int UMEEGDataBase::GetChannelIndex(const char* Label) const
/*
    Return the channel index and type *DT of the channel corresponding to label[].
    On error, return -1.
 */
{
    if(Label==NULL) return -1;

    for(int i=0;i<NchannelTot; i++)
        if(IsStringCompatible(Label,ChIn[i].namChannel, false)==true)
        {
            if(ChIn[i].SkipChannel==false)  return i;

            CI.AddToLog("Note: UMEEGDataBase::GetChannelIndex() : Label %s is skipped.\n",Label);
            return -1;
        }

    CI.AddToLog("Note: UMEEGDataBase::GetChannelIndex() : Label %s not present in resource file.\n",Label);
    return -1;
}

int UMEEGDataBase::GetChanAndType(const char*Label, DataType* DT) const
/*
    Return the channel index and type *DT of the channel corresponding to label[].
    For REF, MEG and EEG the index corresponds to the index of the corresponding UGrid-object
    For other types, the index corresponds to the order of the channel in the data file.

    On error, return -1.
 */
{
    if(Label==NULL)
    {
        if(DT) *DT = U_DAT_UNKNOWN;
        return -1;
    }
    int ichan = -1;
    for(int i=0;i<NchannelTot; i++)
        if(!strcmp(Label,ChIn[i].namChannel))
        {
            ichan = i;
            break;
        }

    if(ichan==-1)
    {
        CI.AddToLog("Note: UMEEGDataBase::GetChanAndType() : Label %s not present in data file.\n",Label);
        return -1;
    }

    DataType DatTyp = ChIn[ichan].type;
    if(DT)   *DT    = DatTyp;

    if(ChIn[ichan].SkipChannel==true)
    {
        CI.AddToLog("Note: UMEEGDataBase::GetChanAndType() : Label %s skipped.\n",Label);
        return ichan;
    }

    if(ChIn[ichan].type==U_DAT_MEGREF)
    {
        if(!GridREF) return -1;
        return GridREF->GetChannum(Label);
    }

    if(ChIn[ichan].type==U_DAT_MEG)
    {
        if(!GridMEG) return -1;
        return GridMEG->GetChannum(Label);
    }

    if(ChIn[ichan].type==U_DAT_EEG)
    {
        if(!GridEEG) return -1;
        return GridEEG->GetChannum(Label);
    }

    if(ChIn[ichan].type==U_DAT_ADC)
    {
        if(!GridADC) return -1;
        return GridADC->GetChannum(Label);
    }

    if(ChIn[ichan].type==U_DAT_SSP)
    {
        if(!GridSSP) return -1;
        return GridSSP->GetChannum(Label);
    }
    int isens = 0;
    for(int i=0;i<NchannelTot; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;
        if(!strcmp(Label,ChIn[i].namChannel)) return isens;
        if(DatTyp == ChIn[i].type) isens++;
    }
    return -1;
}

USensor UMEEGDataBase::GetSensor(int isens, DataType DT) const
/*
    return the USensor with index ChannelIndex of GridAll
 */
{
    int index = GetChannelIndex(isens, DT);
    if(index<0 || index>=NchannelTot)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensor(). Sensor does not exist (isens=%d, DT=%s) . \n", isens, GetDataTypeText(DT));
        return USensor();
    }
    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetSensor(). UGrid GridAll not properly set. \n");
        return USensor();
    }
    return GridAll->GetSensor(index);
}

int UMEEGDataBase::GetChannelIndex(int isens, DataType DT) const
/*
    Return the channel index of sensor isens, of datatype DT
 */
{
    int itest = 0;
    for(int ichan=0; ichan<NchannelTot; ichan++)
    {
        if(ChIn[ichan].SkipChannel==true) continue;
        if(ChIn[ichan].type==DT)
        {
            if(itest==isens) return ichan;
            itest++;
        }
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetChannelIndex(). parameters out of range: isens=%d, DT=%d  .\n", isens, DT);
    return -1;
}

int* UMEEGDataBase::GetTriggerChannel(int itrial)
/*
     Get all data points of the stimulus channel, including pre-stimulus points.
 */
{
    if(itrial<0 || itrial>=ntrial)
    {
        CI.AddToLog("ERROR UMEEGDataBase::GetTriggerChannel() : trial number out of range: %d \n",itrial);
        return NULL;
    }
    UEvent Begin(itrial, 0);
    UEvent End(itrial, nsamp-1);

    return GetTriggerEpoch(Begin, End);  // pure virtual, dependent on data type
}

ErrorType UMEEGDataBase::RemoveSSPChannels(void)
{
    if(ChIn==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataBase::RemoveSSPChannels(). ChIn not set.   \n");
        return U_ERROR;
    }
    int Nrem = 0;
    for(int i=NchannelRaw; i<MAXCHAN; i++)
    {
        if(ChIn[i].type!=U_DAT_SSP) continue;

        memset(ChIn[i].namChannel, 0, sizeof(ChIn[i].namChannel));
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
        Nrem++;
    }
    NchannelTot -= Nrem;
    nSSP         = 0;
    delete GridSSP; GridSSP = NULL;
    return U_OK;
}

ErrorType UMEEGDataBase::SetSSPChannels(const UGrid* GrSSP)
{
    if(GrSSP==NULL || GrSSP->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataBase::SetSSPChannels(). Erroneous or NULL UGrid argument. \n");
        return U_ERROR;
    }
    if(GrSSP->GetNpoints()<=0 || GrSSP->GetNpoints()>=MAXSSP)
    {
        CI.AddToLog("ERROR UMEEGDataBase::SetSSPChannels(). Number of SSP-dipoles out of range: %d. \n", GrSSP->GetNpoints());
        return U_ERROR;
    }
    if(ChIn==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataBase::SetSSPChannels(). ChIn not set.   \n");
        return U_ERROR;
    }

/*  Remove old SSP channels*/
    RemoveSSPChannels();
    delete GridSSP; GridSSP = new UGrid(*GrSSP);
    nSSP = 0;
    if(GridSSP==NULL || GridSSP->GetError()!=U_OK)
    {
        delete GridSSP; GridSSP = NULL;
        CI.AddToLog("ERROR UMEEGDataBase::SetSSPChannels(). Copying UGrid().   \n");
        return U_ERROR;
    }
    nSSP = GridSSP->GetNpoints();

/* Copy new ones */
    for(int i=NchannelRaw, issp=0; i<NchannelRaw+nSSP; i++)
    {
        USensor S = GridSSP->GetSensor(issp);
        strncpy(ChIn[i].namChannel, S.GetName(), sizeof(ChIn[i].namChannel)-1);
        GridAll->SetSensor(&S, i);
        ChIn[i].type          = U_DAT_SSP;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 255;
        ChIn[i].LT            = 1;
        issp++;
    }
    NchannelTot = NchannelRaw + nSSP;
    return U_OK;
}

UFileName UMEEGDataBase::GetMarkerTextFile(const char* Dir) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetMarkerTextFile(). Object NULL or erroneous.\n");
        return UFileName();
    }
    UFileName MarkTextFile = DataFileName;
    if(Dir)   MarkTextFile = UDirectory(Dir) + UFileName(MarkTextFile.GetBaseName());
    MarkTextFile.SetExtension("mrktxt");
    return MarkTextFile;
}

const UMarkerArray* UMEEGDataBase::GetMarkerArray(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetMarkerArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    return Markers;
}

ErrorType UMEEGDataBase::SetMarkerArray(const UMarkerArray* Mar)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetMarkerArray(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar && Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetMarkerArray(). Invalid argument. \n");
        return U_ERROR;
    }
    if(nsamp!=Mar->GetnSampTrial())
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetMarkerArray(). Number of samples per trial is not consistent: nsamp = %d, Mar->nSampTrial=%d. \n", nsamp, Mar->GetnSampTrial());
        return U_ERROR;
    }
    delete Markers; Markers = NULL;
    if(Mar==NULL) return U_OK;

    Markers = new UMarkerArray(*Mar);
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("ERROR: UMEEGDataBase::SetMarkerArray(). Copying Argument argument. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMEEGDataBase::ReplaceMarkers(const UMarkerArray* Mar, bool Prepend)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceMarkers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar && Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceMarkers(). Invalid (NULL) argument. \n");
        return U_ERROR;
    }
    ErrorType E = U_OK;
    if(Markers==NULL)
    {
        Markers = new UMarkerArray(*Mar);
        E       = Markers->GetError();
    }
    else
    {
        E       = Markers->ReplaceMarkers(Mar, Prepend);
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceMarkers(). Replacing or copying argument. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMEEGDataBase::ReplaceMarker(const UMarker* Mark, int im)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::UMEEGDataBase(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceMarker(). MarkerArray not (properly) set. \n");
        return U_ERROR;
    }
    if(Mark==NULL || im<0 || im>=Markers->GetnMarkers())
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ReplaceMarker(). Invalid argument(s): im=%d. \n", im);
        return U_ERROR;
    }
    return Markers->SetMarker(*Mark, im);
}
ErrorType UMEEGDataBase::AddMarker(const UMarker* Mark)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::AddMarker(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::AddMarker(). MarkerArray not (properly) set. \n");
        return U_ERROR;
    }
    if(Mark==NULL || Mark->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::AddMarker(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    return Markers->AddMarker(Mark);
}
ErrorType UMEEGDataBase::MergeMarkerArray(const UMarkerArray* Mar)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::MergeMarkerArray(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::MergeMarkerArray(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(Markers==NULL)
    {
        Markers = new UMarkerArray(*Mar);
        if(Markers==NULL || Markers->GetError()!=U_OK)
        {
            delete Markers; Markers = NULL;
            CI.AddToLog("ERROR: UMEEGDataBase::MergeMarkerArray(). Copying argument. \n");
            return U_ERROR;
        }
        return U_OK;
    }
    if(Markers->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::MergeMarkerArray(). Existing marker array is erroneous. \n");
        return U_ERROR;
    }
    return Markers->MergeMarkerArray(Mar);
}


double* UMEEGDataBase::GetTrial_d(int itrial, DataType Dtype, ReReferenceType ReRef) const
/*
    return a double pointer to an array containing the data of trial itrial of
    the current data file (including pre-stimulus points.). This array is allocated with
    new[] and should be deleted by the calling function.

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL
 */
{
    if(itrial<0 || itrial>=ntrial)
    {
        CI.AddToLog("ERROR UMEEGDataBase::GetTrial_d() : trial number out of range: %d \n",itrial);
        return NULL;
    }
    UEvent Begin(itrial, 0);
    UEvent End(itrial, nsamp-1);

    return GetEpoch_d(Begin, End, Dtype, ReRef);// pure virtual, dependent on data type
}

const UString& UMEEGDataBase::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataBase-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(                                   " Base class properties:  \n") +
                  UString((const char*)DataFileName,         " File           = %s     \n") +
                  UString(GetDataFormatTypeText(DataFormat), " DataFormat     = %s     \n") +
                  UString(DateTimeRec.GetProperties(NULL, true, false), " RecordingDate      = %s     \n") +
                  UString(DateTimeRec.GetProperties(NULL, false, true), " RecordingTime      = %s     \n") +
                  UString(GetPatName(),                      " PatName        = %s     \n") +
                  UString(GetPatID()  ,                      " PatID          = %s     \n") +
                  UString(srate       ,                      " SampleRate     = %f     \n") +
                  UString(nsamp       ,                      " nsamp          = %d     \n") +
                  UString(ntrial      ,                      " ntrial         = %d     \n") +
                  UString(NPreTrig    ,                      " NPreTrigPnts   = %d     \n") +
                  UString(nAver       ,                      " NumAverages    = %d     \n");

    if(ContineousData) Properties += UString(" Data recorded continueously. \n");
    else               Properties += UString(" Data may have gaps between trials. \n");

    if(IsAveragedData()==true) Properties += UString(" Data is considered as averaged data.  \n");
    else                       Properties += UString(" Data not averaged.  \n");

    Properties += UString(nREF       ," Nref            = %d \n") +
                  UString(nMEG       ," Nmeg            = %d \n") +
                  UString(nEEG       ," Neeg            = %d \n") +
                  UString(nADC       ," Nadc            = %d \n") +
                  UString(nSSP       ," Nssp            = %d \n") +
                  UString(NchannelRaw," NChannelsInFile = %d \n") +
                  UString(NchannelTot," NTotalChannels  = %d // (including derived channels, e.g. SSP)\n");

    if(GridMEG)
    {
        UGrid GCopy(*GridMEG);
        if(GCopy.GetError()==U_OK)
        {
            Properties += UString(" \n MEG Channel grouping: \n");
            Properties += GCopy.GetGroupProperties(Comment+UString("  "));
        }
    }
    if(nEEG>0)
    {
        if(EEGposTrue==true)
            Properties += UString(" EEG sensor positions determined by 3D digitization. \n");
        else
            Properties += UString(" EEG sensor positions are defaults. \n");
        if(EEGlabelTrue==true)
            Properties += UString(" EEG sensor labels are true ones. \n");
        else
            Properties += UString(" EEG sensor labels are the defaults. \n");

        if(GridEEG)
        {
            UGrid GCopy(*GridEEG);
            if(GCopy.GetError()==U_OK)
            {
                Properties += UString(" \n EEG Channel grouping: \n");
                Properties += GCopy.GetGroupProperties(Comment+UString("  "));
            }
        }
    }
    if(GridADC)
    {
        UGrid GCopy(*GridADC);
        if(GCopy.GetError()==U_OK)
        {
            Properties += UString(" \n ADC Channel grouping: \n");
            Properties += GCopy.GetGroupProperties(Comment+UString("  "));
        }
    }
    if(GridSSP)
    {
        UGrid GCopy(*GridSSP);
        if(GCopy.GetError()==U_OK)
        {
            Properties += UString(" \n SSP Channel grouping: \n");
            Properties += GCopy.GetGroupProperties(Comment+UString("  "));
        }
    }
    Properties += UString(" \n");

    UString GenCom(GeneralComment, "%s\n");
    GenCom.Truncate(6000, "... ");
    GenCom.ReplaceBlankSpace(true);
    GenCom.RemoveSpacesEachLine();
    GenCom.InsertAtEachLine(" #  ");
    Properties += UString(" Description:\n") + GenCom + UString(" \n");

    if(Markers)
    {
        Properties += UString(" Event Markers. \n");
        Properties += UString(Markers->GetnMarkers(), " NMarkers = %d \n");
        for(int m=0; m<Markers->GetnMarkers(); m++)
        {
            const UMarker*  M = Markers->GetMarker(m);
            Properties += UString(M->GetMarkerName(), "     MarkerName = %s ;") +
                          UString(M->GetnEvents(),    " N = %d   \n");
        }
    }
    else
    {
        Properties += UString(" NMarkers = 0 \n");
        Properties += UString(" No event markers present in dat file. \n");
    }

    if(LaplaceRef)
    {
        Properties += UString(" Laplace Rereference:  \n") +
                      LaplaceRef->GetProperties("   ");
    }
    if(CTFSensorInter)
    {
        Properties += UString(" CTF Sensorgrid Interpolation: \n") +
                      CTFSensorInter->GetProperties("   ");
    }
    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UMEEGDataBase::SetLaplacianReferenceMatrix(void)
{
    const int    MORDER = 4;

    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetLaplacianReferenceMatrix(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    delete LaplaceRef; LaplaceRef = NULL;
    if(GridAll==NULL || GridAll->GetError()!=U_OK) return U_OK;

    UGrid GrEEGAll;
    for(int i=0; i<NchannelRaw; i++)
    {
        if(ChIn[i].type!=U_DAT_EEG) continue;

        USensor S = GridAll->GetSensor(i);
        if(S.Getx()==UVector3()) continue;

        GrEEGAll.AddSensor(S);
    }
    if(GrEEGAll.GetNpoints()<=0) return U_OK;

    LaplaceRef = new UInterpolateSphere(&GrEEGAll, MORDER);
    if(LaplaceRef==NULL || LaplaceRef->GetError()!=U_OK)
    {
        delete LaplaceRef; LaplaceRef = NULL;
        CI.AddToLog("ERROR: UMEEGDataBase::SetLaplacianReferenceMatrix(). Creating UInterpolateSphere-object. \n");
        return U_ERROR;
    }
    return U_OK;
}
bool UMEEGDataBase::IsCTFSensorInterpolationSet(void) const
{
    if(this          ==NULL || error!=U_OK                     ) return false;
    if(CTFSensorInter==NULL || CTFSensorInter->GetError()!=U_OK) return false;

    return true;
}
bool UMEEGDataBase::IsLaplacianReferenceMatrixSet(void) const
{
    if(this      ==NULL || error!=U_OK                 ) return false;
    if(LaplaceRef==NULL || LaplaceRef->GetError()!=U_OK) return false;

    return true;
}
bool UMEEGDataBase::IsReferenceConsistent(DataType Dtype, ReReferenceType ReRef) const
{
    if(this==NULL) return false;

    switch(ReRef)
    {
    case U_REF_RAW:            return true;
    case U_REF_AVERAGE:
    case U_REF_GROUPAVER:
    case U_REF_COMMON:
        if(Dtype==U_DAT_EEG)   return true;
        else                   return false;
    case U_REF_LAPLACIAN:
        if(IsLaplacianReferenceMatrixSet()==true && Dtype==U_DAT_EEG)   return true;
        else                                                            return false;

    case U_REF_UNBALANCED:
    case U_REF_FIRST:
    case U_REF_SECOND:
    case U_REF_THIRD:
        if(Dtype==U_DAT_MEG)   return true;
        else                   return false;
    }
    return false;
}

ErrorType UMEEGDataBase::BalanceMEG(double *MEGdata, UEvent Begin, UEvent End, ReReferenceType ReRef) const
{
    if(ReRef==U_REF_RAW) return U_OK;
    CI.AddToLog("ERROR: UMEEGDataBase::BalanceMEG(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return U_ERROR;
}

ErrorType UMEEGDataBase::ComputeGroupReference(double *EEGdata, int nsmp) const
{
    if(EEGdata==NULL || nsmp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ComputeGroupReference(). Invalid parameters, nsmp = %d \n", nsmp);
        return U_ERROR;
    }
    if(GridEEG==NULL               || GridEEG->GetError()!=U_OK ||
       nEEG!=GridEEG->GetNpoints() || GridEEG->GetGroup()==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ComputeGroupReference(). Inconsistent EEG grid. \n");
        return U_ERROR;
    }

/* Initialize static (group) parameters */
    static double aver[MAXEEG];
    int NG = GridEEG->GetGroup()->GetNGroup();

    static int N[MAXEEG];
    for(int ig=0; ig<NG; ig++) N[ig] = GridEEG->GetGroup()->GetNElem(ig);

    static int index[MAXEEG][MAXEEG];
    for(int ig=0; ig<NG; ig++)
        for(int ie=0; ie<N[ig]; ie++) index[ig][ie] = nsmp * GridEEG->GetGroup()->GetElem(ig, ie);

/* Compute group averages */
    for(int j=0; j<nsmp; j++)
    {
        for(int ig=0; ig<NG; ig++)
        {
            aver[ig] = 0.;
            for(int ie=0; ie<N[ig]; ie++)
                aver[ig] += EEGdata[index[ig][ie]+j];
            if(N[ig]>0) aver[ig] /= N[ig];
        }

        for(int ig=0; ig<NG; ig++)
            for(int ie=0; ie<N[ig]; ie++)
                EEGdata[index[ig][ie]+j] -= aver[ig];
    }
    return U_OK;
}

ErrorType UMEEGDataBase::ComputeAverageReference(double *EEGdata, int nsmp) const
{
    if(EEGdata==NULL || nsmp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ComputeAverageReference(). Invalid parameters, nsmp = %d \n", nsmp);
        return U_ERROR;
    }
    double* pEEG = NULL;
    for(int j=0; j<nsmp; j++)
    {
        double aver = 0;
        for(pEEG = EEGdata+j; pEEG<EEGdata+nEEG*nsmp; pEEG+=nsmp) aver += *pEEG;
        aver /= nEEG;
        for(pEEG = EEGdata+j; pEEG<EEGdata+nEEG*nsmp; pEEG+=nsmp) *pEEG -= aver;
    }
    return U_OK;
}

ErrorType UMEEGDataBase::ComputeCommonReference(double *EEGdata, int nsmp) const
{
    if(EEGdata==NULL || nsmp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ComputeCommonReference(). Invalid parameters, nsmp = %d \n", nsmp);
        return U_ERROR;
    }
    if(NewCommonRef<0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::ComputeCommonReference(). Common reference channel not (properly) set. Skipping Re-referencing. \n");
        return U_ERROR;
    }
    double* pEEG = NULL;
    for(int j=0; j<nsmp; j++)
    {
        double ref = EEGdata[NewCommonRef*nsmp + j];
        for(pEEG = EEGdata+j; pEEG<EEGdata+nEEG*nsmp; pEEG+=nsmp) *pEEG -= ref;
    }
    return U_OK;
}

int UMEEGDataBase::GetNkan(DataType Dtype) const
/*
     return the number of channels of type Dtype, or -1 on error
 */
{
    switch(Dtype)
    {
    case U_DAT_MEGREF: return nREF;
    case U_DAT_MEG:    return nMEG;
    case U_DAT_EEG:    return nEEG;
    case U_DAT_ADC:    return nADC;
    case U_DAT_SSP:    return nSSP;
    }

    int nKan = 0;
    for(int i=0; i<NchannelTot; i++)
    {
        if(ChIn[i].SkipChannel==true) continue;
        if(ChIn[i].type == Dtype) nKan++;
    }
    return nKan;
}

const UGrid* UMEEGDataBase::GetGrid(DataType Dtype) const
/*
     return the grid corresponding to type Dtype, or NULL on error
 */
{
    switch(Dtype)
    {
    case U_DAT_MEGREF: return GridREF;
    case U_DAT_MEG   : return GridMEG;
    case U_DAT_EEG   : return GridEEG;
    case U_DAT_ADC   : return GridADC;
    case U_DAT_SSP   : return GridSSP;
    }
    CI.AddToLog("ERROR: UMEEGDataBase::GetGrid(). Function not defined for data type Dtype = %d  .\n", Dtype);
    return NULL;
}

ChanInfo* UMEEGDataBase::GetChanInfo(void) const
/*
   return a new pointer to an ChanInfo[] array, containg a copy of the current
   contents of ChIn. This copy is meant for editing purposes.
 */
{
    if(this==NULL || error!=U_OK || ChIn==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetChanInfo(). Object not properly set. \n");
        return NULL;
    }
    ChanInfo* ChInNew = new ChanInfo[MAXCHAN];
    if(ChInNew==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetChanInfo(). Memory allocation. \n");
        return NULL;
    }
    memcpy(ChInNew, ChIn, MAXCHAN*sizeof(ChanInfo));
    return ChInNew;
}

ChanInfo UMEEGDataBase::GetChanInfo(int ichan) const
{
    ChanInfo CIdef;
    sprintf(CIdef.namChannel,"ERROR_%d",ichan);
    CIdef.type          = U_DAT_UNKNOWN;
    CIdef.InGain        = 1.;
    CIdef.GainFact      = 1.;
    CIdef.Offset        = 0.;
    CIdef.SkipChannel   = true;
    CIdef.Red           = 0;
    CIdef.Green         = 0;
    CIdef.Blue          = 0;
    CIdef.LT            = 1;
    if( ichan<0 || ichan >= MAXCHAN)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetChanInfo(). Argument out of range: ichan = %d  .\n", ichan);
        return CIdef;
    }
    return ChIn[ichan];
}

ErrorType UMEEGDataBase::SetChanDisplay(int ichan, unsigned char R, unsigned char G, unsigned char B, int LT) const
{
    if( ichan<0 || ichan >= MAXCHAN)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::SetChanDisplay(). Argument out of range: ichan = %d  .\n", ichan);
        return U_ERROR;
    }
    ChIn[ichan].Red    = R;
    ChIn[ichan].Green  = G;
    ChIn[ichan].Blue   = B;
    ChIn[ichan].LT     = LT;
    return U_OK;
}

const UMarkerArray* UMEEGDataBase::GetTrialClassArray(void) const
{
    CI.AddToLog("WARNING: UMEEGDataBase::GetTrialClassArray(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

int UMEEGDataBase::GetDataGradOrder(void) const
{
    CI.AddToLog("WARNING: UMEEGDataBase::GetDataGradOrder(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return 0;
}

bool UMEEGDataBase::CanBeBalanced() const
/*
  return iff balancing information is properly present in object
*/
{
    return false;
}

const UBalance**  UMEEGDataBase::GetpBalancing(void) const
{
    CI.AddToLog("WARNING: UMEEGDataBase::GetpBalancing(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

int* UMEEGDataBase::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataBase::GetTriggerEpoch(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

double* UMEEGDataBase::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    CI.AddToLog("ERROR: UMEEGDataBase::GetChannel_d(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

double* UMEEGDataBase::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
{
    CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). virtual function not implemented in derived class.(%s). \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

double* UMEEGDataBase::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(IsReferenceConsistent(Dtype, ReRef)==false)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Data type (%s) not consistent with rereferencing (%s) .\n", GetDataTypeText(Dtype), GetReReferenceText(ReRef));
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR UMEEGData::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    double* data = GetEpoch_d(Begin, End, Dtype);
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Getting data from derived class. \n");
        return NULL;
    }

/* Rereference data */
    ErrorType E = U_ERROR;
    if(Dtype==U_DAT_EEG)
    {
        switch(ReRef)
        {
        case U_REF_RAW:         E = U_OK;  break;
        case U_REF_AVERAGE:     E = ComputeAverageReference(data, NSamples); break;
        case U_REF_GROUPAVER:   E = ComputeGroupReference  (data, NSamples); break;
        case U_REF_COMMON:      E = ComputeCommonReference (data, NSamples); break;
        case U_REF_LAPLACIAN:
            {
                if(LaplaceRef==NULL || LaplaceRef->GetError()!=U_OK)
                {
                    CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Laplacian re-reference matrix not set. \n");
                    E = U_ERROR;
                }
                else
                {
                    E = LaplaceRef->ComputeSmoothedLaplacian(GridEEG, data, NSamples);
                    CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Computing Laplacian re-reference. Selected EEG channels might contain sensors with positions at origin. \n");
                }
            }
            break;
        }
    }
    else if(Dtype==U_DAT_MEG)
    {
        E = BalanceMEG(data, Begin, End, ReRef);
    }
    else
    {
        if(ReRef==U_REF_RAW) E = U_OK;
    }
    if(E!=U_OK)
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Rereferencing requested data. Data type is %s. \n", GetDataTypeText(Dtype));
        return NULL;
    }
    return data;
}

double* UMEEGDataBase::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef, const UGrid* GridLabels)
{
    if(GridLabels==NULL || GridLabels->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Erroneous or NULL argument. \n");
        return NULL;
    }

    ChanInfo* ChInCopy = GetChanInfo();
    if(ChInCopy==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Getting restore buffer with channel info. \n");
        return NULL;
    }

    if(SelectChannels(GridLabels)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEpoch_d(). Selecting channels. \n");
        return NULL;
    }

    double* data = GetEpoch_d(Begin, End, Dtype, ReRef);

/* Restore selection */
    for(int i=0; i<MAXCHAN; i++)
        ChIn[i].SkipChannel = ChInCopy[i].SkipChannel;
    delete[] ChInCopy;

    return data;
}

ErrorType UMEEGDataBase::GetMEGSphere(UVector3* Spos, double* Srad) const
{
    if(GridMEG==NULL || GridMEG->GetNpoints()<10) return U_ERROR;

    UGridFit G(*GridMEG);
    if(G.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetMEGSphere(). Copying MEG grid. \n");
        return U_ERROR;
    }

    UVector3 C;
    double   R=0;
    double   E=G.FitSphere(C, &R);
    if(E<0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetMEGSphere(). Fitting sphere to MEG grid. \n");
        return U_ERROR;
    }
    CI.AddToLog("Note: UMEEGDataBase::GetMEGSphere(). Fit error = %f cm. \n", E);
    if(Spos) *Spos = C;
    if(Srad) *Srad = R;
    return U_OK;
}

ErrorType UMEEGDataBase::GetEEGSphere(UVector3* Spos, double* Srad) const
{
    if(GridEEG==NULL || GridEEG->GetNpoints()<10) return U_ERROR;

    UGridFit G(*GridEEG);
    if(G.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEEGSphere(). Copying EEG grid. \n");
        return U_ERROR;
    }

    if(EEGposTrue==false)
        CI.AddToLog("WARNING: UMEEGDataBase::GetEEGSphere(). True EEG sensor positions not known. \n");

    UVector3 C;
    double   R=0;
    double   E=G.FitSphere(C, &R);
    if(E<0)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::GetEEGSphere(). Fitting sphere to EEG grid. \n");
        return U_ERROR;
    }
    CI.AddToLog("Note: UMEEGDataBase::GetEEGSphere(). Fit error = %f cm. \n", E);
    if(Spos) *Spos = C;
    if(Srad) *Srad = R;
    return U_OK;
}

const char* const*  UMEEGDataBase::GetBadChannels(void) const
{
    CI.AddToLog("WARNING: UMEEGDataBase::GetBadChannels(). Virtual function not implemented for DataType = %s. \n", GetDataFormatTypeText(DataFormat));
    return NULL;
}

ErrorType UMEEGDataBase::WriteSensorPositionsXYZ(UFileName FileXYZ) const
{
    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::WriteSensorPositionsXYZ(). Sensor grid not set. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(FileXYZ, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::WriteSensorPositionsXYZ(). File cannot be created: %s \n", (const char*)FileXYZ);
        return U_ERROR;
    }
    for(int i=0; i<GridAll->GetNpoints(); i++)
    {
        USensor S = GridAll->GetSensor(i);
        fprintf(fp, "%s \t", S.GetName());
        UVector3 x = S.Getx();
        fprintf(fp, "%f \t", x.Getx());
        fprintf(fp, "%f \t", x.Gety());
        fprintf(fp, "%f \t", x.Getz());
        if(S.GetStype()!=USensor::U_SEN_MAG    &&
           S.GetStype()!=USensor::U_SEN_VECTOR &&
           S.GetStype()!=USensor::U_SEN_GRAD  )
        {
            fprintf(fp, "\t \t \t \t \t \n");
            continue;
        }
        x = S.Getn();
        fprintf(fp, "%f \t", x.Getx());
        fprintf(fp, "%f \t", x.Gety());
        fprintf(fp, "%f \t", x.Getz());
        if(S.GetStype()!=USensor::U_SEN_GRAD  )
        {
            fprintf(fp, "\t \t \n");
            continue;
        }
        x = S.Getc();
        fprintf(fp, "%f \t", x.Getx());
        fprintf(fp, "%f \t", x.Gety());
        fprintf(fp, "%f \n", x.Getz());
    }
    fclose(fp);
    return U_OK;
}
ErrorType UMEEGDataBase::WriteChannelConfigTXT(UFileName FileConf) const
{
    if(GridAll==NULL || GridAll->GetError()!=U_OK || ChIn==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::WriteSensorPositionsXYZ(). Sensor grid not set. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(FileConf, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataBase::WriteChannelConfigTXT(). Channel config file %s cannot be created .\n", (const char*)FileConf);
        return U_ERROR;
    }
    fprintf(fp, "ChannelConfigFile\n");
    fprintf(fp, "Version = 1.0 \n");
    fprintf(fp, "%s", CI.GetProperties("// "));
    fprintf(fp, "// \n");
    for(int k=0; k<U_DAT_NTYPE; k++)
        fprintf(fp, "// %d  = %s \n", k, UMEEGDataBase::GetDataTypeText(UMEEGDataBase::GetDataType(k)));
    fprintf(fp, "// \n");
    fprintf(fp, "Label \tType \tSkip \tRed \tGreen \tBlue \tLT \tGroup \n");
    for(int i=0; i<GridAll->GetNpoints(); i++)
    {
        if(ChIn[i].type==U_DAT_UNKNOWN) continue;
        int GrpID = GridAll->GetGroupID(i);

        fprintf(fp, "%s \t", ChIn[i].namChannel);
        fprintf(fp, "%d \t", (int)ChIn[i].type);
        fprintf(fp, "%d \t", (int)ChIn[i].SkipChannel);
        fprintf(fp, "%d \t", (int)ChIn[i].Red);
        fprintf(fp, "%d \t", (int)ChIn[i].Green);
        fprintf(fp, "%d \t", (int)ChIn[i].Blue);
        fprintf(fp, "%d \t", (int)ChIn[i].LT);
        fprintf(fp, "%d \n", GrpID);
    }
    fclose(fp);

    return U_OK;
}

