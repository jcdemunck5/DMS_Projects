#ifndef _MEEGDATA_INCLUDED
#define _MEEGDATA_INCLUDED

#include "Euler.h"
#include "FileName.h"
#include "Event.h"
#include "DateTime.h"
#include "String.h"

enum DataFormatType
{
    U_DATFORM_UNKNOWN,
    U_DATFORM_CTF,
    U_DATFORM_NEUROSCAN,
    U_DATFORM_MICROMED,
    U_DATFORM_BRAINPROD,
    U_DATFORM_EDF,
    U_DATFORM_GDF,
    U_DATFORM_MAP,
    U_DATFORM_ASCII,
    U_DATFORM_ECG,
    U_DATFORM_TXT,
    U_DATFORM_PHILLOG,
    U_DATFORM_GELOG,
    U_DATFORM_ANT,
    U_DATFORM_ANT64,
    U_DATFORM_FIFF,
    U_DATFORM_TMSI,
    U_DATFORM_NTYPE        // Number of types
};

enum DataType     
{
    U_DAT_UNKNOWN,
    U_DAT_MEG,            // MEG
    U_DAT_MEGREF,
    U_DAT_EEG,
    U_DAT_EEGREF,
    U_DAT_SSP,            // MEG/EEG data, projected onto a dipolar source (signal space projection)
    U_DAT_EKG,
    U_DAT_EOG,
    U_DAT_EMG,
    U_DAT_ADC,
    U_DAT_STIM,
    U_DAT_ANNOT,
    U_DAT_NTYPE           // Number of types
};

enum TimeFormatType
{
    U_TIMEFORM_NOLAB,
    U_TIMEFORM_TRIALMS,
    U_TIMEFORM_TRIGGMS,
    U_TIMEFORM_SAMPLE
};

enum ReReferenceType     
{
    U_REF_RAW,            // Do not apply any re-referencing, data as is
    U_REF_AVERAGE,        // Rereference EEG to average reference
    U_REF_GROUPAVER,      // Rereference EEG to average reference of EEG chanel sub-groups
    U_REF_COMMON,         // Re-referenced to common reference
    U_REF_LAPLACIAN,      // Re-referenced to Laplacian reference
    U_REF_UNBALANCED,     // Rereference MEG by removing all gradient signals
    U_REF_FIRST,          // Rereference MEG to first gradient
    U_REF_SECOND,         // Rereference MEG to second gradient
    U_REF_THIRD,          // Rereference MEG to third gradient
    U_REF_SECONDFORWARD,  // Second gradient, used for forward modeling
    U_REF_THIRDFORWARD,   // Third gradient, used for forward modeling
    U_REF_NTYPE           // Number of reference types
};

typedef struct
{
    char          namChannel[20]; // Channel names (label)
    DataType      type;           // channel data type
    bool          SkipChannel;    // true iff a certain channel is to be skipped
    double        InGain;         // Conversion factor from digitial to double in input
    double        GainFact;       // Extra factor, applied on writing to digital, applied to avoid over/underflow
    double        Offset;         // Offset constant (all channels)
    unsigned char Red;            // Display color
    unsigned char Green;          // 
    unsigned char Blue;           // 
    int           LT;             // Line thickness
} ChanInfo;

class UBalance;
class UGrid;
class UMarkerArray;
class UMarker;
class UInterpolateSphere;
class UInterpolateSensors;


class DLL_IO UMEEGDataBase
{
public:
    static const int  MAXMEG;
    static const int  MAXREF;
    static const int  MAXEEG;
    static const int  MAXEKG;
    static const int  MAXEOG;
    static const int  MAXADC;
    static const int  MAXSSP;
    static const int  MAXCHAN;

    static const char*          GetDataFormatTypeText(DataFormatType DFT);
    static const char*          GetUnitText(DataType DT);
    static const char*          GetDataTypeText(DataType DT);
    static const char*          GetReReferenceText(ReReferenceType RRT);
    static DataType             GetDataType(int itype);
    static DataFormatType       GetDataFormatType(UFileName FileName);

    UMEEGDataBase();
    UMEEGDataBase(const UMEEGDataBase& Data); 
    virtual ~UMEEGDataBase();
    virtual UMEEGDataBase&      operator=(const UMEEGDataBase &Data);

    virtual ErrorType           GetError(void) const         {if(this) return error; return U_ERROR;}
    DataFormatType              GetDataFormatType(void) const{if(this) return DataFormat; return U_DATFORM_UNKNOWN;}
    const char*                 GetDate(void) const          {if(this) return DateTimeRec.GetProperties(NULL, true , false); return NULL;}
    const char*                 GetTime(void) const          {if(this) return DateTimeRec.GetProperties(NULL, false, true ); return NULL;}
    UDateTime                   GetDateTime(void) const      {if(this) return DateTimeRec;    return UDateTime();}
    bool                        IsDataContineous(void) const {if(this) return ContineousData; return false;}

    virtual ErrorType           CopyDataFiles(const char* BaseName);
    virtual ErrorType           DeleteDataFiles(void) const;
    virtual ErrorType           RenameDataFiles(const char* BaseName);
    UFileName                   GetDataFileName(void) const      {if(this) return DataFileName; return UFileName();}
    UFileName                   GetSkipChannelLabelFile(void) const;

    double                      GetSampleRate(void) const        {if(this) return srate;        return 0.;}
    double                      GetSampleTime_s(void) const;
    double                      GetPreTriggerTime_s(void) const  {if(this) return NPreTrig*GetSampleTime_s(); return 0.;}
    int                         GetPreNTriggerPnts(void) const   {if(this) return NPreTrig;     return 0;}
    int                         GetNsampTrial(void) const        {if(this) return nsamp;        return 0;}
    int                         GetNtrial(void) const            {if(this) return ntrial;       return 0;}
    int                         GetNsampTotal(void) const        {if(this) return nsamp*ntrial; return 0;}
    virtual bool                IsAveragedData(void) const;
    int                         GetNaver(void) const             {if(this) return nAver;        return 0;}

    ErrorType                   ConvertDataType(DataType DTOLD, DataType DTNEW);

    virtual const char* const*  GetBadChannels(void) const;
    ErrorType                   CopyChannelSelection(const UMEEGDataBase* Data);
    ErrorType                   RemoveChannels(const char * const*BadChan);
    ErrorType                   SelectChannels(const char * const*GoodChan, const char * const*BadChan);
    ErrorType                   SelectChannels(const char* GoodChan, const char* BadChan);
    ErrorType                   SelectChannels(const ChanInfo* NewChIn);
    ErrorType                   SelectChannels(DataType DT0, DataType DT1=U_DAT_UNKNOWN, DataType DT2=U_DAT_UNKNOWN, DataType DT3=U_DAT_UNKNOWN);  
    ErrorType                   SelectChannels(const UGrid* GridLabels);  
    ErrorType                   SelectChannels(DataType DT0, const char* GoodChan, const char* BadChan);

    ErrorType                   UpdateChannelColors(const ChanInfo* ChInNew, const UGrid* GSel);
    ErrorType                   UpdateChannelGroups(const UGrid* GSel);
    UGrid*                      GetSelectedGrid(DataType DT) const;
    const UGrid*                GetGridAll(void) const {return GridAll;}
    bool*                       GetSensorSelection() const;
    ErrorType                   RenameSensor(const char* OldName, const char* NewName);
    ErrorType                   RenameSensor(const char* OldName, const char* NewName, DataType DT);
    ErrorType                   SetCTFSensorGroups(void);
    ErrorType                   CopySensorIDsFromNames(const UGrid* G);

    const char*                 GetPatName(void) const {return PatName;}
    const char*                 GetPatID(void) const   {return PatID;}
    virtual UEuler              GetDewar2NLR(void) const;    

    bool                        AreEEGPositionsMeasured(void) const   {return EEGposTrue;}
    bool                        AreEEGLabelsTrue(void)        const   {return EEGlabelTrue;}
    bool                        IsLaplacianReferenceMatrixSet(void) const;
    bool                        IsCTFSensorInterpolationSet(void) const;
    const UInterpolateSensors*  GetCTFInterpolation(void) const       {if(this) return CTFSensorInter; return NULL;}
    int                         GetNkan(DataType Dtype) const;
    int                         GetNChan(DataType Dtype) const        {if(this) return GetNkan(Dtype); return 0;}
    const UGrid*                GetGrid(DataType Dtype) const;
    USensor                     GetSensor(int isens, DataType DT) const;

    int                         GetNref(void) const        {return nREF;}
    const UGrid*                GetGridREF(void) const     {return GridREF;}

    int                         GetNmeg(void) const        {return nMEG;}
    const UGrid*                GetGridMEG(void) const     {return GridMEG;}
    ErrorType                   GetMEGSphere(UVector3* Spos, double* Srad) const;
    virtual int                 GetDataGradOrder(void) const;
    virtual bool                CanBeBalanced() const;
    virtual const UBalance**    GetpBalancing(void) const;

    int                         GetNeeg(void) const        {return nEEG;}
    const UGrid*                GetGridEEG(void) const     {return GridEEG;}
    ErrorType                   GetEEGSphere(UVector3* Spos, double* Srad) const;
    bool                        IsNewCommonRefSet(void) const {if(NewCommonRef<0) return false; return true;}
    ErrorType                   SetCommonRef(const char* RefLabel);
    const char*                 GetCommonReferenceLabel(void) const;

    int                         GetNADC(void) const        {return nADC;}
    const UGrid*                GetGridADC(void) const     {return GridADC;}
    int                         GetNSSP(void) const        {return nSSP;}
    const UGrid*                GetGridSSP(void) const     {return GridSSP;}

    virtual const UString&      GetProperties(UString Comment) const;
    int                         GetChanAndType(const char*Label, DataType* DT) const;
    int                         GetChannelIndex(int isens, DataType DT) const;
    int                         GetChannelIndex(const char* Label) const;
    const USensor*              GetSensor(const char* Label) const;

/* channel data */
    double*                     GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef, const UGrid* GridLabels);
    double*                     GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef) const;
    virtual double*             GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    double*                     GetTrial_d(int itrial, DataType Dtype, ReReferenceType ReRef) const; 
    virtual double*             GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*                GetTriggerEpoch(UEvent Begin, UEvent End) const;
    int*                        GetTriggerChannel(int itrial);
    bool                        GetStim(void) const          {return STIM;}

/* SSP channels */
    ErrorType                   RemoveSSPChannels(void);
    ErrorType                   SetSSPChannels(const UGrid* GridSSP);

/* Editing markers*/
    UFileName                   GetMarkerTextFile(const char* AltDirectory=NULL) const;
    const UMarkerArray*         GetMarkerArray(void) const;
    ErrorType                   SetMarkerArray(const UMarkerArray* Mar);
    ErrorType                   MergeMarkerArray(const UMarkerArray* Mar);
    ErrorType                   ReplaceMarkers(const UMarkerArray* Mar, bool Prepend);
    ErrorType                   ReplaceMarker(const UMarker* Mark, int im);
    ErrorType                   AddMarker(const UMarker* Mark);

    virtual const UMarkerArray* GetTrialClassArray(void) const;
    
    ChanInfo*                   GetChanInfo(void) const;
    ChanInfo                    GetChanInfo(int ichan) const;
    ErrorType                   SetChanDisplay(int ichan, unsigned char R, unsigned char G, unsigned char B, int LT) const;
    int                         GetNChanRaw(void) const      {if(this) return NchannelRaw; return 0;}
    int                         GetNChanTot(void) const      {if(this) return NchannelTot; return 0;}

    virtual ErrorType           SaveSensorPositions(void) const;
    ErrorType                   SaveSensorPositionsXYZ(void) const;
    ErrorType                   UpdateElectrodePositions(UFileName FilePos);
    ErrorType                   UpdateElectrodePositions(const char* FilePos);
    virtual ErrorType           UpdateDewar2Head(UEuler DTH);
    ErrorType                   ReplaceSensorPositions(const UGrid* GrNew, DataType DT);
    
    UVector3                    GetNLRMarker(int k) const;

    ErrorType                   WriteSensorPositionsXYZ(UFileName FileXYZ) const;
    ErrorType                   WriteChannelConfigTXT(UFileName FileConf) const;

protected:
    static const char*          FILEID_MICROMED;
    static const char*          FILEID_BRAINPROD;
    static const char*          FILEID_PHILLOG;

    ErrorType                   error;         // General error flag
    DataFormatType              DataFormat;    // Data format
    UFileName                   DataFileName;  // Data file name (to be used in constructor)
    bool                        ContineousData;// is true iff the raw data is recorded without online triggers
    UDateTime                   DateTimeRec;   // Date and time the data were recorded
    char                        PatName[64];   // Name of patient or subject
    char                        PatID[64];     // Unique patient number or ID
    double                      srate;         // Sample frequency [Hz]
    int                         nsamp;         // Number of samples per trial
    int                         ntrial;        // Number of trials
    int                         NPreTrig;      // Number of samples before each trigger (of each trial)
    int                         nAver;         // if(averaged data) nAver = Number of averages, else nAver =1
    
    UString                     GeneralComment;// General comment string present in the header (.res4-file, for CTF)

    int                         NchannelRaw;   // Number of channels, in data file
    int                         NchannelTot;   // Total number of channels (including SSP, etc)
    ChanInfo*                   ChIn;          // labels, gain factors, offsets, etc of each channel
    UGrid*                      GridAll;       // sensor geometries and labels, of all sensors, of all types
    
    int                         nREF;          // Number of Reference MEG channels (same as _npoints in GridREF)
    UGrid*                      GridREF;       // Reference MEG sensor grid

    int                         nMEG;          // Number of MEG channels (same as _npoints in GridMEG)
    UGrid*                      GridMEG;       // MEG sensor grid

    int                         nEEG;          // Number of EEG channels (same as _npoints in GridEEG)
    UGrid*                      GridEEG;       // EEG sensor grid
    bool                        EEGposTrue;    // EEG positions are determined by 3D digitation method
    bool                        EEGlabelTrue;  // Default EEG channel labels overwritten by true ones
    int                         NewCommonRef;  // Common reference EEG channel index, set off-line using SetCommonRef();
    
    bool                        STIM;          // is true iff there is a stimulus channel present in the data-file
    int                         nADC;          // Number of ADC channels
    UGrid*                      GridADC;       // ADC grid 
    int                         nSSP;          // Number of SSP channels
    UGrid*                      GridSSP;       // SSP grid 
    
    UMarkerArray*               Markers;       // array of different types of events in the M/EEG data
    UVector3                    NLR[3];        // Fiducial markers (Nasion, Left and Right ear) in NLR coordinates

    ErrorType                   SetLaplacianReferenceMatrix(void);
    ErrorType                   UpdateSensorGrids(void);
    ErrorType                   ReorderChannelsSensors(const int* NewIndex, int Nindex);
    void                        SetAllMembersDefault(void);
    void                        DeleteAllMembers(ErrorType E);

    UInterpolateSensors*        CTFSensorInter;
private:
    static UString              Properties;
    UInterpolateSphere*         LaplaceRef;

    bool                        IsReferenceConsistent(DataType Dtype, ReReferenceType ReRef) const;
    ErrorType                   ComputeGroupReference(double *EEGdata, int nsmp) const;
    ErrorType                   ComputeAverageReference(double *EEGdata, int nsmp) const;
    ErrorType                   ComputeCommonReference(double *EEGdata, int nsmp) const;
    virtual ErrorType           BalanceMEG(double *MEGdata, UEvent Begin, UEvent End, ReReferenceType ReRef) const;
};

#endif// _MEEGDATA_INCLUDED
