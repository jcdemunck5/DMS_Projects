/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a CTF data file header and taking only the necesssary  */
/*     part.                                                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    20-11-03   creation, derived from ReadCTFData.cpp
  JdM    01-06-04   GetEpoch_d(). Make consistent with getting common reference data.
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    06-01-05   Added NLR[] markers
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    14-04-05   Made TruncateResourceLabel() static
                    BalanceMEG(): Test for MEG channel labels, to find appropriate pBal tabel
  JdM    22-04-05   Delete Balancing tables pBal[], when not all balancing elelements are read succesfully
                    Added GetBadChannels()
  JdM    15-01-06   Added EEG group-re-reference
  JdM    23-09-06   operator=(). Copying all MAXMEG pBal[], not only the first nMEG
  JdM    05-01-07   BalanceMEG(). Avoid use of UCTFData::ReferenceType
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    11-01-08   UFileName constructor: recognize EKG and EOG channels by their channel name
  JdM    28-01-08   Made BalanceMEG() virtual. GetEpoch_d(): remove re-reference argument.
                    Do all re-referencing in base clase GetEpoch_d(). Now UMEEGDataCTF() is more consistent with other data format classes
  JdM    30-01-08   Bug Fix, constructor. memcpy(ChIn[i].namChannel,...) account for maximum number of char to be copied.
  JdM    06-03-08   Bug Fix: ReadChannelLabels(). ch is int (not char). Include label ending with EOF (instead of 10).
  JdM    13-03-08   BUG FIX: DateTimeRec, character array overflow. Use UString i.s.o. char [60]
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    16-09-08   Bug Fix: Reading time: add space before "Time" in UString dt = ...
  JdM    04-01-09   Added RenameDataFiles() and DeleteDataFiles()
  JdM    16-02-09   Set GeneralComment as UString()
  JdM    13-02-10   Reading MEG data: make distiction between magnetometers and gradiometers using rez.senres[i].sensorTypeIndex
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    08-03-12   Added SaveSensorPositions()
  JdM    27-03-12   bug fix: UMEEGDataCTF::UMEEGDataCTF(). setting DateTimeRec
  JdM    09-09-12   SaveSensorPositions(). Make one or two backups of the old file.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    10-09-16   FileName constructor. Test for ECG channels using wild card and EKG* string
*/

#include <string.h>

#include "MEEGDataCTF.h"
#include "MEEGDataWriteCTF.h"
#include "CTFDataSet.h"
#include "MarkerArray.h"
#include "GridFit.h"
#include "Balance.h"

/* Inititalize static const parameters. */
UString UMEEGDataCTF::Properties = UString();

const double UMEEGDataCTF::GAUGE_MEG     =  1e15;
const double UMEEGDataCTF::GAUGE_EEG     =  1e6;
const int    UMEEGDataCTF::MAXLABELSIZE  =  8;


enum CTFFittType {U_CTF_FILT_ERROR,
                  U_CTF_FILT_LOWPASS,
                  U_CTF_FILT_HIGHPASS,
                  U_CTF_FILT_NOTCH};

void UMEEGDataCTF::SetAllMembersDefault(void)
{
    pBal            = NULL;
    HwFilterText    = NULL;
    Properties      = (const char*)NULL;
    TrialClassArray = NULL;
    BadChannels     = NULL;
    nBadChan        = 0;
}

void UMEEGDataCTF::DeleteAllMembers(ErrorType E)
{
    delete[] HwFilterText;    HwFilterText    = NULL;
    delete   TrialClassArray; TrialClassArray = NULL;
    InvalidateBalancing();
    if(BadChannels)
    {
        for(int ib=0; ib<nBadChan+1;ib++) delete[] BadChannels[ib];
        delete[] BadChannels;
    }

    SetAllMembersDefault();
    error = E;
}

UMEEGDataCTF::~UMEEGDataCTF()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataCTF::UMEEGDataCTF() : UMEEGDataBase()
{
    SetAllMembersDefault();
}


UMEEGDataCTF::UMEEGDataCTF(UFileName FileName) :
    UMEEGDataBase()
/*
    Read the CTF data from file called Filename and store resulting gradiometer/electrode
    positions in grid. Ignore the MEG references. See "MegDefs.h".

 */
{
    SetAllMembersDefault();

    UCTFDataSet DS(FileName.GetFullFileName());

/* Read resources */
    resource rez;
    if(readResources(DS.GetCTFFileName(), &rez)!=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        deleteResources(&rez);
        CI.AddToLog("ERROR UMEEGDataCTF: Reading file %s \n",DS.GetCTFFileName());
        return;
    }
    if(rez.genres.gSetUp.no_channels>MAXCHAN)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        deleteResources(&rez);
        CI.AddToLog("ERROR UMEEGDataCTF: Too many channels %d (MAX=%d) \n",rez.genres.gSetUp.no_channels,MAXCHAN);
        return;
    }
    ChIn           = new ChanInfo[MAXCHAN];
    pBal           = new UBalance*[MAXMEG];
    GeneralComment = new char[rez.genres.rdlen+2];
    GridAll        = new UGrid(MAXCHAN);

    if(!ChIn    || !pBal     || !GeneralComment ||
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        deleteResources(&rez);

        error = U_ERROR;
        CI.AddToLog("ERROR UMEEGDataCTF::UMEEGDataCTF(). Memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat     = U_DATFORM_CTF;
    DataFileName   = UFileName(DS.GetCTFFileName());
    DataFileName.ReplaceExtension("meg4");
    ContineousData = true;
    for(int i=0; i<MAX_AVERAGE_BINS ; i++)
        if(rez.genres.gSetUp.secondaryTrigger[i])
        {
            ContineousData = false;
            break;
        }
    strncpy(PatName,rez.genres.nfSetUp.nf_subject_id,31);
    strncpy(PatID,"CTF1234567890",31);
    
    UString dt;
    if(strstr(rez.genres.data_date, "Date")) dt += UString(rez.genres.data_date);
    else                                     dt += UString(rez.genres.data_date,"Date = %s");
    if(strstr(rez.genres.data_time, "Time")) dt += UString(rez.genres.data_time);
    else                                     dt += UString(rez.genres.data_time,"Time = %s");
    DateTimeRec    = UDateTime((const char*)dt);

    srate          = rez.genres.gSetUp.sample_rate;
    nsamp          = (int)rez.genres.gSetUp.no_samples;
    ntrial         = rez.genres.gSetUp.no_trials;
    NPreTrig       = rez.genres.gSetUp.preTrigPts;
    nAver          = rez.genres.no_trials_avgd;

    GeneralComment = UString(rez.run_description, rez.genres.rdlen);

    NchannelRaw    = rez.genres.gSetUp.no_channels;
    NchannelTot    = NchannelRaw;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel, 0, sizeof(ChIn[i].namChannel));
        sprintf(ChIn[i].namChannel,"CTF_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;

        if(i<MAXMEG) pBal[i]  = NULL;
    }

    if(strstr(rez.run_description,"EEG channel positions and names based on xyz-file") )
    {
        EEGposTrue   = true;
        EEGlabelTrue = true;
    }
    else if(strstr(rez.run_description,"EEG channel positions based on xyz-file") )
    {
        EEGposTrue   = true;
        EEGlabelTrue = false;
    }
    else if(strstr(rez.run_description,"EEG channel names based on xyz-file") )
    {
        EEGposTrue   = false;
        EEGlabelTrue = true;
    }
    else
    {
        EEGposTrue   = false;
        EEGlabelTrue = false;
    }

    HwFilterText = GetHardwareFilterText(&rez);

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;
    for(int i=0;i<NchannelRaw; i++)
    {
        ChIn[i].type = U_DAT_UNKNOWN;
        int MAXNAME  = MIN(USensor::MAXLABELSIZE, sizeof(ChIn[i].namChannel));
        memcpy(ChIn[i].namChannel, TruncateResourceLabel(rez.chanNames[i]), MAXNAME-1);

        switch(rez.senres[i].sensorTypeIndex)
        {
        case SENTYPE_MAGR:
        case SENTYPE_GRAR:
            ChIn[i].InGain = GAUGE_MEG/(rez.senres[i].qGain*rez.senres[i].properGain);
            if(rez.senres[i].ioGain!=0.) ChIn[i].InGain /= rez.senres[i].ioGain;
            ChIn[i].type   = U_DAT_MEGREF;
            nREF++;
            break;

        case SENTYPE_MEGMA:
        case SENTYPE_MEGGR:
            ChIn[i].InGain  = GAUGE_MEG/(rez.senres[i].qGain*rez.senres[i].properGain);
            if(rez.senres[i].ioGain!=0.) ChIn[i].InGain /= rez.senres[i].ioGain;
            if(nMEG<MAXMEG)
            {
                ChIn[i].type  = U_DAT_MEG;
                pBal[nMEG]    = NULL;
                if(rez.numcoef>0)
                {
                    pBal[nMEG]    = new UBalance(nMEG, rez.senres[i].sensorTypeIndex, &rez);
                    if(pBal[nMEG]==NULL || pBal[nMEG]->GetError()!=U_OK)
                    {
                        delete pBal[nMEG]; pBal[nMEG] = NULL;
                    }
                }
                nMEG++;
            }
            break;

        case SENTYPE_EEG:
            ChIn[i].InGain  = GAUGE_EEG/(rez.senres[i].qGain*rez.senres[i].properGain);
            if(rez.senres[i].ioGain!=0.) ChIn[i].InGain /= rez.senres[i].ioGain;
            if(IsStringCompatible(ChIn[i].namChannel, "EOG", false)==true)
            {
                ChIn[i].type  = U_DAT_EOG;
                break;
            }
            if(IsStringCompatible(ChIn[i].namChannel, "ECG*", false)==true || IsStringCompatible(ChIn[i].namChannel, "EKG*", false)==true)
            {
                ChIn[i].type  = U_DAT_EKG;
                break;
            }
            if(nEEG<MAXEEG)
            {
                ChIn[i].type  = U_DAT_EEG;
                nEEG++;
            }
            break;

        case SENTYPE_ADC:
        case SENTYPE_ADC2:
            ChIn[i].InGain  = 1./(rez.senres[i].qGain*rez.senres[i].properGain);
            if(rez.senres[i].ioGain!=0.) ChIn[i].InGain /= rez.senres[i].ioGain;
            if(nADC<MAXADC)
            {
                ChIn[i].type  = U_DAT_ADC;
                nADC++;
            }
            break;

        case SENTYPE_STIM:
            ChIn[i].InGain = 1;
            ChIn[i].type   = U_DAT_STIM;
            STIM           = true;
            break;

        default:
            ChIn[i].InGain  = 0.;
            ChIn[i].type    = U_DAT_UNKNOWN;  // Skip all channels that are no EEG, MEG or ADC, irrespective of the label lists
        }
    }

    if(nREF>MAXREF)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UMEEGDataCTF::UMEEGDataCTF(). Too many reference channels (%d>%d) \n", nREF, MAXREF);
        return;
    }
    for(int i=0; i<nMEG; i++)
        if(!pBal[i])
        {
            InvalidateBalancing();
            break;
        }

    if(nREF) GridREF = new UGrid(nREF);
    if(nMEG) GridMEG = new UGrid(nMEG);
    if(nEEG) GridEEG = new UGrid(nEEG);
    if(nADC) GridADC = new UGrid(nADC);

    if( (nREF && (GridREF==NULL || GridREF->GetError()!=U_OK) ) ||
        (nMEG && (GridMEG==NULL || GridMEG->GetError()!=U_OK) ) ||
        (nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) ||
        (nADC && (GridADC==NULL || GridADC->GetError()!=U_OK) ) )
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        deleteResources(&rez);

        CI.AddToLog("ERROR: UMEEGDataCTF::UMEEGDataCTF(). Memory allocation for Grid. \n");
        return;
    }

/* Store the sensor geometries in the grid GridAll */
    for(int i=0;i<NchannelRaw; i++)
    {
        USensor S;
        S.Setx((double) rez.senres[i].HdcoilTbl[0].position.x,
               (double) rez.senres[i].HdcoilTbl[0].position.y,
               (double) rez.senres[i].HdcoilTbl[0].position.z);
        S.Setn((double) rez.senres[i].HdcoilTbl[0].orient.x,
               (double) rez.senres[i].HdcoilTbl[0].orient.y,
               (double) rez.senres[i].HdcoilTbl[0].orient.z);
        if(ChIn[i].InGain>0) S.Setn(-S.Getn());

        if(rez.senres[i].sensorTypeIndex==SENTYPE_GRAR ||
           rez.senres[i].sensorTypeIndex==SENTYPE_MEGGR)
        {
            S.SetStype(USensor::U_SEN_GRAD);
            S.Setc((double) rez.senres[i].HdcoilTbl[1].position.x,
                   (double) rez.senres[i].HdcoilTbl[1].position.y,
                   (double) rez.senres[i].HdcoilTbl[1].position.z);

        }
        else if(rez.senres[i].sensorTypeIndex==SENTYPE_MAGR ||
                rez.senres[i].sensorTypeIndex==SENTYPE_MEGMA)
        {
            S.SetStype(USensor::U_SEN_MAG);
        }
        else if(rez.senres[i].sensorTypeIndex==SENTYPE_EEG)
        {
            S.SetStype(USensor::U_SEN_EEG);
        }
        else
            S.SetStype(USensor::U_SEN_POINT);

        S.SetName( ChIn[i].namChannel);
        GridAll->SetSensor(&S, i);
    }

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    UpdateDewar2Head(&rez);

/* Read markers and classes */
    if(DoesFileExist(DS.GetMarkerFileName())==true)
    {
        Markers = new UMarkerArray(DS.GetMarkerFileName(), nsamp, rez.genres.gSetUp.preTrigPts, srate, true);
        if(Markers==NULL || Markers->GetError()!=U_OK)
        {
            delete Markers; Markers = NULL;
            CI.AddToLog("WARNING: UMEEGDataCTF::UMEEGDataCTF(). Cannot create UMarkerArray()-object. \n");
        }
    }
    deleteResources(&rez);

    if(DoesFileExist(DS.GetClassFileName())==true)
    {
        TrialClassArray = ReadClassFile(DS.GetClassFileName());
        if(TrialClassArray==NULL || TrialClassArray->GetError()!=U_OK)
        {
            delete TrialClassArray; TrialClassArray = NULL;
            CI.AddToLog("Note: UMEEGDataCTF::UMEEGDataCTF(). No class-information can be read from CTF Class-file. \n");
        }
    }
    UFileName FBad(DataFileName.GetSiblingFileName("BadChannels"));
    ReadChannelLabels((const char*)FBad);


    NLR[0] = DS.GetFiducials(0);
    NLR[1] = DS.GetFiducials(1);
    NLR[2] = DS.GetFiducials(2);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataCTF::UMEEGDataCTF(). Setting new Laplacian reference matrix \n");

    error = U_OK;
}

UMEEGDataCTF::UMEEGDataCTF(const UMEEGDataCTF& Data) :
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataCTF.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataCTF& UMEEGDataCTF::operator=(const UMEEGDataCTF &Data)
{
    if(this==NULL)
    {
        static UMEEGDataCTF D; D.error = U_ERROR;
        return D;
    }
    if(&Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataCTF::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataCTF::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    if(Data.pBal)
    {
        pBal = new UBalance*[MAXMEG];
        if(pBal==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataCTF::operator=(). Copying balancing. \n");
            return *this;
        }
        for(int i=0; i<MAXMEG; i++)
            if(Data.pBal[i]) pBal[i] = new UBalance( *Data.pBal[i] );
            else             pBal[i] = NULL;
    }
    if(Data.HwFilterText)
    {
        size_t nb = 1+strlen(Data.HwFilterText);
        HwFilterText = new char[nb];
        if(HwFilterText)
            memcpy(HwFilterText, Data.HwFilterText, nb);
        else
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataCTF::operator=(). Copying Hardware filter text info. \n");
            return *this;
        }
    }
    Dewar2Head  = Data.Dewar2Head;
    nBadChan    = Data.nBadChan;
    if(nBadChan)
    {
        BadChannels = new char*[nBadChan+1];
        if(BadChannels==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataCTF::operator=(). Copying bad channel labels. \n");
            return *this;
        }
        for(int k=0; k<nBadChan+1; k++)
        {
            BadChannels[k] = new char[MAXLABELSIZE];
            memcpy(BadChannels[k], Data.BadChannels[k], MAXLABELSIZE);
        }
    }
    return *this;
}

ErrorType UMEEGDataCTF::SaveSensorPositions(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::SaveSensorPositions(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    if(GridAll==NULL || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::SaveSensorPositions(). GridAll NULL or erropneously set. \n");
        return U_ERROR;
    }

/* Read resources */
    UFileName FHead = UMEEGDataBase::DataFileName;
    FHead.SetExtension("res4");
    resource rez;
    if(readResources((const char*)FHead, &rez)!=0)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::SaveSensorPositions(). Reading file %s \n",(const char*)FHead);
        return U_ERROR;
    }
    UFileName FHeadBackUp = FHead;
    FHeadBackUp.InsertBeforeExtension("_b");
    if(FHeadBackUp.DoesFileExist()==true) FHeadBackUp.InsertFileNumber(1,2);
    if(FHead.CopyFile((const char*)FHeadBackUp)!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::SaveSensorPositions(). Making backup of resource file %s \n",(const char*)FHeadBackUp);
        return U_ERROR;
    }

/* Back copy from GridAll to rez*/
    UEuler Head2Dewar = Dewar2Head.GetInverse();
    for(int i=0; i<NchannelRaw;i++)
    {
        memcpy(rez.chanNames[i], ChIn[i].namChannel, 32);
        USensor S = GridAll->GetSensor(i);

        rez.senres[i].HdcoilTbl[0].position.x = S.Getx().Getx();
        rez.senres[i].HdcoilTbl[0].position.y = S.Getx().Gety();
        rez.senres[i].HdcoilTbl[0].position.z = S.Getx().Getz();
        rez.senres[i].HdcoilTbl[0].orient.x   = S.Getn().Getx();
        rez.senres[i].HdcoilTbl[0].orient.y   = S.Getn().Gety();
        rez.senres[i].HdcoilTbl[0].orient.z   = S.Getn().Getz();
        rez.senres[i].HdcoilTbl[1].position.x = S.Getc().Getx();
        rez.senres[i].HdcoilTbl[1].position.y = S.Getc().Gety();
        rez.senres[i].HdcoilTbl[1].position.z = S.Getc().Getz();
        rez.senres[i].HdcoilTbl[1].orient.x   =-S.Getn().Getx();
        rez.senres[i].HdcoilTbl[1].orient.y   =-S.Getn().Gety();
        rez.senres[i].HdcoilTbl[1].orient.z   =-S.Getn().Getz();
        if(ChIn[i].InGain>0.)
        {
            rez.senres[i].HdcoilTbl[0].orient.x = -rez.senres[i].HdcoilTbl[0].orient.x;
            rez.senres[i].HdcoilTbl[0].orient.y = -rez.senres[i].HdcoilTbl[0].orient.y;
            rez.senres[i].HdcoilTbl[0].orient.z = -rez.senres[i].HdcoilTbl[0].orient.z;
            rez.senres[i].HdcoilTbl[1].orient.x = -rez.senres[i].HdcoilTbl[1].orient.x;
            rez.senres[i].HdcoilTbl[1].orient.y = -rez.senres[i].HdcoilTbl[1].orient.y;
            rez.senres[i].HdcoilTbl[1].orient.z = -rez.senres[i].HdcoilTbl[1].orient.z;
        }

/* Compute the sensor positions w.r.t. the dwar*/
        if(ChIn[i].type==U_DAT_MEGREF || ChIn[i].type==U_DAT_MEG)
        {
            UVector3 xdewar;
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].position.x,
                                             rez.senres[i].HdcoilTbl[0].position.y,
                                             rez.senres[i].HdcoilTbl[0].position.z));
            rez.senres[i].coilTbl[0].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].orient.x,
                                             rez.senres[i].HdcoilTbl[0].orient.y,
                                             rez.senres[i].HdcoilTbl[0].orient.z),true);
            rez.senres[i].coilTbl[0].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].orient.z = xdewar.Getz();

            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].position.x,
                                             rez.senres[i].HdcoilTbl[1].position.y,
                                             rez.senres[i].HdcoilTbl[1].position.z));
            rez.senres[i].coilTbl[1].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].orient.x,
                                             rez.senres[i].HdcoilTbl[1].orient.y,
                                             rez.senres[i].HdcoilTbl[1].orient.z),true);
            rez.senres[i].coilTbl[1].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].orient.z = xdewar.Getz();
        }
    }
    if(UMEEGDataWriteCTF::WriteResources((const char*)FHead, &rez))
    {
        deleteResources(&rez);
        CI.AddToLog("ERROR UMEEGDataCTF::SaveSensorPositions(). Writing file %s \n",(const char*)FHead);
        return U_ERROR;
    }
    deleteResources(&rez);

    return U_OK;
}
ErrorType UMEEGDataCTF::DeleteDataFiles(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::DeleteDataFiles(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    UDirectory  Dir = DataFileName.GetDirectory();
    if(Dir.DeleteAllFiles()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::DeleteDataFiles(). Deleting files from directory (%s) .\n", Dir.GetDirectoryName());
        return U_ERROR;
    }
    if(Dir.RemoveDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::DeleteDataFiles(). Deleting directory (%s) .\n", Dir.GetDirectoryName());
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataCTF::RenameDataFiles(const char* BaseName)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    if(BaseName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    UFileName   B(BaseName);      B.ReplaceExtension("ds");
    UCTFDataSet DS((const char*)DataFileName);
    UDirectory  OldDir = DS.GetDirectory();
    UDirectory  NewDir = OldDir.Sibling((const char*)B);

    UFileName F = DataFileName;                 F.ReplaceExtension("res4");
    UFileName N = OldDir + UFileName(BaseName); N.ReplaceExtension("res4");
    if(F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming resource file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("meg4");
    N.ReplaceExtension("meg4");
    if(F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming data file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("acq");
    N.ReplaceExtension("acq");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming .acq file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("eeg");
    N.ReplaceExtension("eeg");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming .eeg file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hist");
    N.ReplaceExtension("hist");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming .hist file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hc");
    N.ReplaceExtension("hc");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming head coil file. \n");
        return U_ERROR;
    }
    if(OldDir.RenameDir((const char*)NewDir)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::RenameDataFiles(). Renaming data set directory. \n");
        return U_ERROR;
    }

    DataFileName = NewDir + UFileName(BaseName);
    DataFileName.ReplaceExtension("res4");;
    return U_OK;
}

bool UMEEGDataCTF::IsAveragedData(void) const
{
    if(nAver>1) return true;
    if(nAver==1 && (ntrial==1 || ntrial==2 || ntrial==3) ) return true;

    return false;
}

void UMEEGDataCTF::InvalidateBalancing(void)
/*
   Invalidate Balancing tables
 */
{
    if(pBal)
        for(int i=0; i<MAXMEG; i++)
        {
            delete pBal[i];
            pBal[i] = NULL;
        }
    delete[] pBal;
    pBal          = NULL;
}

int* UMEEGDataCTF::GetTriggerEpoch(UEvent Begin, UEvent End)
{
    if(STIM==false)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::GetTriggerEpoch() : No stimulus channel present. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::GetTriggerEpoch() : Arguments out of range.\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::GetTriggerEpoch() : Arguments : Begin is located after End\n");
        return NULL;
    }

    int    *data   = new int[NSamples];
    int    *buffer = new int[nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR: UMEEGDataCTF::GetTriggerEpoch(). Memory allocation.\n");
        return NULL;
    }

    FILE *fpData = fopen(DataFileName,"rb", false);
    if(!fpData)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR: UMEEGDataCTF::GetTriggerEpoch(). Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        int *DataChan  = data+nSamplesDone;
/* Skip nSampSkip samples from the beginning of this trial */
        int    nSampSkip  = 0;
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp;
        if(itrial==Begin.trial && itrial==End.trial)
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        for(int i=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type!=U_DAT_STIM) continue;

            if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
            {
                for(int j=0;j<nSampTrial;j++) DataChan[j] = 0;
            }
            else
            {
                fseek(fpData, 8+4*(nsamp*(NchannelRaw*itrial+i)+nSampSkip), SEEK_SET);
                fread(buffer,nSampTrial,4,fpData);
                SwapArray(buffer, nSampTrial, false);
                for(int j=0;j<nSampTrial;j++) DataChan[j] = buffer[j];
            }
            DataChan += NSamples;
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fpData);

    delete[] buffer;
    return data;
}

const UString& UMEEGDataCTF::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataCTF-object\n");
        return Properties;
    }
    Properties = UString();

    if(TrialClassArray)
    {
        Properties += UString(" Trial Classification. \n");
        Properties += UString(TrialClassArray->GetnMarkers(), " NClasses = %d \n");
        for(int m=0; m<TrialClassArray->GetnMarkers(); m++)
        {
            const UMarker* M  = TrialClassArray->GetMarker(m);
            Properties       += UString(M->GetMarkerName(), "     ClassName = %s;") +
                                UString(M->GetnEvents()   , " N = %d \n");
        }
    }
    else
    {
        Properties += UString(" NClasses = 0 \n");
        Properties += UString(" No trial class data present in data set. \n");
    }
    Properties += UString("  \n");
    Properties += UString(" Hardware Filtering: \n");
    if(nMEG>0)
    {
        int DataGradOrder = GetDataGradOrder();
        switch(DataGradOrder)
        {
        case -2: Properties += UString(" MEG data gradient order cannot be determined \n"); break;
        case -1: Properties += UString(" MEG data gradient varies over channels \n"); break;
        default: Properties += UString(DataGradOrder,"  MEG data gradient = %d \n"); break;
        }
    }

    Properties += UString("  \n");
    if(HwFilterText)
    {
        UString HwString(HwFilterText);
        HwString.RemoveEmptyLines();
        HwString.InsertAtEachLine("   ");
        Properties += HwString;
    }
    else
    {
        Properties += UString(" No Hardware filter settings available \n");
    }

    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UMEEGDataCTF::BalanceMEG(double *MEGdata, UEvent Begin, UEvent End, ReReferenceType ReRef) const
{
    if(ReRef==U_REF_RAW) return U_OK;

    if(MEGdata==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::BalanceMEG(). NULL argument .\n");
        return U_ERROR;
    }
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK || GridMEG->GetNpoints()==0)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::BalanceMEG(). NULL or invalid MEG grid.\n");
        return U_ERROR;
    }
    int     nsmp    = GetNsamples(Begin, End, nsamp);
    double* REFdata = GetEpoch_d(Begin, End, U_DAT_MEGREF);

    if(REFdata==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::BalanceMEG(). Getting reference channels.\n");
        return U_ERROR;
    }
    int ibold = -1;
    for(int i=0; i<nMEG; i++)
    {
        int ib = -1;
        for(int k=0; k<MAXMEG; k++)
        {
            int test = (ibold+1+k)%MAXMEG;
            if(pBal[test]==NULL) continue;
            if(pBal[test]->IsMEGLabel(GridMEG->GetName(i))==false) continue;
            ib = ibold = test;
            break;
        }
        if(ib<0)
        {
            CI.AddToLog("ERROR: UMEEGDataCTF::BalanceMEG(). Balancing balancing table not found for MEG label %s.\n",GridMEG->GetName(i));
            delete[] REFdata;
            return U_ERROR;
        }

        if(pBal[ib]->Balance(MEGdata+i*nsmp, REFdata, nsmp, ReRef)!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataCTF::BalanceMEG(). Balancing channel %s.\n",GridMEG->GetName(i));
            delete[] REFdata;
            return U_ERROR;
        }
    }
    delete[] REFdata;

    return U_OK;
}

double* UMEEGDataCTF::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In
    cases where time samples are derived from markers, the marker data have to be corrected
    for the pre-trigger time.

    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials.
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes
  -If the data consists of multiple averages, and (Begin, End) encompasses more
   than one trial zeroes are substituted for data not refering to trial 0

*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::GetEpoch_d(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::GetEpoch_d(). Arguments out of range.\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::GetEpoch_d() : requested type not present in file (Dtype=%s, nKAN=%d). \n", GetDataTypeText(Dtype), nKAN);
        return NULL;
    }

    double *data   = new double[NSamples*nKAN];
    int    *buffer = new int[nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataCTF::GetEpoch_d() : memory allocation. NSamples=%d, nKAN=%d and nsamp=%d.\n",NSamples,nKAN,nsamp);
        return NULL;
    }

    FILE *fpData = fopen(DataFileName,"rb", false);
    if(!fpData)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataCTF::GetEpoch_d() : Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
/* Skip nSampSkip samples from the beginning of this trial */
        int    nSampSkip  = 0;
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp;
        if(itrial==Begin.trial && itrial==End.trial)
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        for(int i=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type       !=Dtype) continue;
            if(ChIn[i].SkipChannel==true ) continue;

            if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
            {
                for(int j=0;j<nSampTrial;j++) DataChan[j] = 0.;
            }
            else
            {
                fseek(fpData, 8+4*(nsamp*(NchannelRaw*itrial+i)+nSampSkip), SEEK_SET);
                fread(buffer,nSampTrial,4,fpData);
                SwapArray(buffer, nSampTrial, false);
                for(int j=0;j<nSampTrial;j++) DataChan[j] = ChIn[i].InGain*buffer[j];
            }
            DataChan += NSamples;
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fpData);

    delete[] buffer;
    return data;
}

double* UMEEGDataCTF::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
/*
    Return a new pointer with the data between Begin and End, of the channel
    carrying the name Label[] (i.e. the first channel having the same first characters as Label[])

  Notes:
  -The Begin and End events refer to ABSOLUTUTE time samples numbers. In cases where time
   samples are derived from markers, the marker data have to be corrected for the pre-trigger
   time.
  -The events Begin and End may reside on different trials.
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::Channel_d(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::Channel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR UMEEGDataCTF::Channel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

/* Select the correct channel index. */
    if(Label==NULL || *Label==0)
    {
        CI.AddToLog("WARNING UMEEGDataCTF::GetChannel_d() : NULL label argument.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0;i<NchannelRaw; i++)
        if(!strcmp(Label,ChIn[i].namChannel))
        {
            ichan = i;
            break;
        }
    if(ichan==-1)
    {
        CI.AddToLog("WARNING UMEEGDataCTF::GetChannel_d() : required label %s not present.\n",Label);
        return NULL; // Label[] not present.
    }


    double *data   = new double[NSamples];
    int    *buffer = new int[nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataCTF::GetChannel_d() : memory allocation.\n");
        return NULL;
    }

    FILE *fpData = fopen(DataFileName,"rb", false);
    if(!fpData)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataCTF::GetChannel_d() : Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int nSamplesDone = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
/* Skip nSampSkip samples from the beginning of this trial */
        int    nSampSkip  = 0;
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp;
        if(itrial==Begin.trial && itrial==End.trial)
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
        {
            for(int j=0;j<nSampTrial;j++) DataChan[j] = 0.;
        }
        else
        {
            fseek(fpData, 8+4*(nsamp*(NchannelRaw*itrial+ichan)+nSampSkip), SEEK_SET);
            fread(buffer,nSampTrial,4,fpData);
            SwapArray(buffer, nSampTrial, false);
            for(int j=0;j<nSampTrial;j++) DataChan[j] = ChIn[ichan].InGain*buffer[j];
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fpData);

    delete[] buffer;
    return data;
}

ErrorType UMEEGDataCTF::UpdateDewar2Head(UEuler DTH)
{
    if(GridAll==NULL || GridAll->GetError()!=U_OK || ChIn==NULL) return U_ERROR;
    if(nMEG==0 || nREF==0)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::UpdateDewar2Head(). No channels of appropriate type. \n");
        return U_OK;
    }

    UEuler XFM = DTH * Dewar2Head.GetInverse();
    for(int i=0; i<MAXCHAN; i++)
    {
        USensor S = GridAll->GetSensor(i);
        if(ChIn[i].type!=U_DAT_MEGREF && ChIn[i].type!=U_DAT_MEG) continue;

        S = XFM.xfm(S);
        GridAll->SetSensor(&S, i);
    }
    Dewar2Head = DTH;

    return UpdateSensorGrids();
}

ErrorType UMEEGDataCTF::UpdateDewar2Head(const resource *rez)
/*
     Determine the best possible Dewar2Head Euler transformation by fitting
     the current MEG grid in head coordinates onto that grid in dewar coordinates.

     Also, determine the position of the best fitting sphere Spos, and HeadRadius.
 */
{
    UGridFit *Dewar = NULL;
    if(nMEG>0)
    {
        Dewar = new UGridFit(*GridMEG);
        if(Dewar==NULL || Dewar->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataCTF::UpdateDewar2Head(). Copying MEG grid.\n");
            return U_ERROR;
        }

        for(int jm=0,i=0;i<rez->genres.gSetUp.no_channels; i++)
        {
            if(ChIn[i].type!=U_DAT_MEG) continue;

            Dewar->SetPosition(UVector3((double) rez->senres[i].coilTbl[0].position.x,
                                        (double) rez->senres[i].coilTbl[0].position.y,
                                        (double) rez->senres[i].coilTbl[0].position.z), jm);
            Dewar->SetName( TruncateResourceLabel(rez->chanNames[i]), jm );
            jm++;
        }

/* Fit Dewar coordinates to head coordinates.*/
        double dist = 0;
        Dewar2Head = Dewar->FitGridEuler(GridMEG,&dist);
        if(dist<0.)
        {
            delete Dewar;
            CI.AddToLog("ERROR: UMEEGDataCTF::UpdateDewar2Head() : Fitting Dewar to head coordinates in  %s. \n",DataFileName.GetFullFileName());
            return U_ERROR;
        }
    }
    delete Dewar;

    return U_OK;
}

char* UMEEGDataCTF::TruncateResourceLabel(const char* RezName)
/* Copy first few characters of channel name
 */
{
    static Str32 label;
    memset(label,0,sizeof(label));
    for(int k=0;k<MIN(32,USensor::MAXLABELSIZE)-1;k++)
    {
        if(RezName[k]=='-') break;
        label[k] = RezName[k];
    }
    return label;
}

int UMEEGDataCTF::GetDataGradOrder(void) const
/*
     return MEG data gradient order (as it is recorded)
     -2 : Gradient order cannot be determined
     -1 : Gradient order varies over channels

 */
{
    if(pBal==NULL) return -2;

    int Order = -2;
    for(int i=0; i<nMEG; i++)
    {
        if(pBal[i]==NULL) return -2;
        if(Order==-2)
        {
            Order = pBal[i]->GetDataGradOrder();
            continue;
        }
        if(Order!=pBal[i]->GetDataGradOrder()) return -1;
    }
    return Order;
}

bool UMEEGDataCTF::CanBeBalanced() const
/*
  return iff balancing information is properly present in object
*/
{
    if(pBal==NULL) return false;

    for(int i=0; i<nMEG; i++)
    {
        if(pBal[i]==NULL) return false;
        if(pBal[i]->GetError() != U_OK) return false;
    }
    return true;
}

const UBalance**  UMEEGDataCTF::GetpBalancing(void) const
{
    if(CanBeBalanced()==false) return NULL;
    return (const UBalance**) pBal;
}

char* UMEEGDataCTF::GetHardwareFilterText(resource* rez)
/*
    Return the Hardware filter settings in text format.
 */
{
    if(rez==NULL) return NULL;

    int nbytes = 100;
    if(rez->num_filters>0) nbytes = 80*rez->num_filters;

    char* Text = new char[nbytes];
    if(Text==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::GetHardwareFilterText(). Memory allocation: nbytes = %d .\n", nbytes);
        return NULL;
    }
    memset(Text, 0, nbytes);
    if(rez->num_filters<=0)
    {
        sprintf(Text,"HARDWARE_FILTERS: No Hardware filters.\n");
        return Text;
    }
    int nc = sprintf(Text   ,"HARDWARE_FILTERS: \n");
    for(int i=0; i<rez->num_filters; i++)
    {
        switch(rez->filters[i].fType)
        {
        case U_CTF_FILT_LOWPASS:        nc += sprintf(Text+nc,"     LPASS = ");      break;
        case U_CTF_FILT_HIGHPASS:       nc += sprintf(Text+nc,"     HPASS = ");      break;
        case U_CTF_FILT_NOTCH:          nc += sprintf(Text+nc,"     NOTCH = ");      break;
        default:                        nc += sprintf(Text+nc,"     UNKNOWN\n"); break;
        }
        if(rez->filters[i].fType==U_CTF_FILT_LOWPASS  ||
           rez->filters[i].fType==U_CTF_FILT_HIGHPASS ||
           rez->filters[i].fType==U_CTF_FILT_NOTCH)
                nc += sprintf(Text+nc," %f \n", rez->filters[i].freq);
    }
    if(nc>=nbytes-1)
        CI.AddToLog("ERROR: UMEEGDataCTF::GetHardwareFilterText(). Array overflow. nc = %d, nbytes = %d .\n", nc, nbytes);
    return Text;
}

#define MAXCLASS_NAME 32
UMarkerArray* UMEEGDataCTF::ReadClassFile(const char* ClassFile) const
/*
    Read the CTF Class-file, named ClassFile[], and convert it into a UMarkerArray()-object
    wherein each class is represented by an event in the first sample of a trial.
 */
{
    if(ClassFile==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataCTF::ReadClassFile(). Invalid NULL pointer. \n");
        return NULL;
    }
    FILE*   fpClass = fopen(ClassFile,"rb");

    if(fpClass==NULL)
    {
        CI.AddToLog("WARNING: UMEEGDataCTF::ReadClassFile(). Cannot open %s \n",ClassFile);
        return NULL;
    }

    int NTrialClasses = 0;
    char string[200];
    while(strcmp(string,"CLASSES:") !=0) fscanf(fpClass,"%s",string);
    fscanf(fpClass,"%d",&NTrialClasses);
    if(NTrialClasses<=0)
    {
        fclose(fpClass);
        CI.AddToLog("Note: UMEEGDataCTF::ReadClassFile(). No class information present in  %s .\n",ClassFile);
        return NULL;
    }
    UMarkerArray* Mar = new UMarkerArray(NTrialClasses, nsamp, NPreTrig, srate);
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        fclose(fpClass);
        delete Mar;
        CI.AddToLog("Note: UMEEGDataCTF::ReadClassFile(). Creating UMarkerArray() with %d markers. \n",NTrialClasses);
        return NULL;
    }

    for(int ic=0;ic<NTrialClasses;ic++)   // Fill in the marker objects
    {
/* Classname */
        char ClassName[MAXCLASS_NAME];
        while(strcmp(string,"NAME:") !=0) fscanf(fpClass,"%s",string);
        fscanf(fpClass,"%s",ClassName);

        int Ntrial;
        while(strcmp(string,"TRIALS:") !=0) fscanf(fpClass,"%s",string);
        fscanf(fpClass,"%d",&Ntrial);

/* Make the UMaker object */
        UMarker M(ClassName, Ntrial, nsamp, 0, "CTF-Class", 0, false);

        if(M.GetError()!=U_OK)
        {
            fclose(fpClass);
            delete Mar;
            CI.AddToLog("Note: UMEEGDataCTF::ReadClassFile(). Creating Marker %d, named %s \n", ic, ClassName);
            return NULL;
        }

/* Find trial and sample numbers*/
        while(strcmp(string,"NUMBER") !=0) fscanf(fpClass,"%s",string);

        for(int j=0;j<Ntrial;j++)
        {
            int    itr;
            fscanf(fpClass,"%d",&itr);
            M.AddEvent(UEvent(itr, 0));
        }
        if(Mar->SetMarker(M, ic)!=U_OK)
        {
            fclose(fpClass);
            delete Mar;
            CI.AddToLog("Note: UMEEGDataCTF::ReadClassFile(). Copying marker (%d, %s) to marker array. \n", ic, ClassName);
            return NULL;
        }
    }
    fclose(fpClass);

    return Mar;
}

ErrorType UMEEGDataCTF::ReadChannelLabels(const char* BadChanFileName)
{
    if(BadChanFileName==NULL)
    {
        CI.AddToLog("Note: UMEEGDataCTF::ReadChannelLabels(). Invalid NULL argument. \n");
        return U_ERROR;
    }

/* Delete old labels */
    if(BadChannels)
    {
        for(int ib=0; ib<nBadChan+1;ib++) delete[] BadChannels[ib];
        delete[] BadChannels;
    }
    BadChannels = NULL;
    nBadChan    = 0;


    FILE *fpBad = fopen(BadChanFileName,"rb");
    if(fpBad==NULL) return U_OK;

/* Count labels */
    int ch = EOF;
    do
    {
        ch = getc(fpBad);
        if(ch==10 || ch==EOF) nBadChan++;
    }
    while(ch != EOF);

    if(nBadChan==0)
    {
        fclose(fpBad);
        return U_OK;
    }
    rewind(fpBad);
    BadChannels = new char*[nBadChan+1];
    if(BadChannels==NULL)
    {
        CI.AddToLog("Note: UMEEGDataCTF::ReadChannelLabels(). Memory allocation: nBadChan = %d. \n", nBadChan);
        return U_ERROR;
    }
    int iBad    = 0;
    int kchar   = 0;
    do
    {
        if(kchar==0)
        {
            BadChannels[iBad] = new char[MAXLABELSIZE];
            memset(BadChannels[iBad],0,MAXLABELSIZE);
        }
        ch = getc(fpBad);
        if(kchar<MAXLABELSIZE-1 && ch!=EOF && ch!=10 && ch!=13) BadChannels[iBad][kchar] = (char)ch;

        if(ch==10)
        {
            iBad++;
            kchar = 0;
        }
        else if(ch!=13)
            kchar++;
    }
    while(ch != EOF);
    BadChannels[nBadChan] = new char[MAXLABELSIZE];
    memset(BadChannels[nBadChan],0,MAXLABELSIZE);

    fclose(fpBad);
    return U_OK;
}
