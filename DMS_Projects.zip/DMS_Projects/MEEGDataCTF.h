#ifndef _MEEGDATACTF_INCLUDED
#define _MEEGDATACTF_INCLUDED

#include "MEEGDataBase.h"
#include "MegDefs.h"

class  UBalance;

class DLL_IO UMEEGDataCTF : public UMEEGDataBase
{
public:
    UMEEGDataCTF();
    UMEEGDataCTF(UFileName FileName);     
    UMEEGDataCTF(const UMEEGDataCTF& Data); 
    virtual ~UMEEGDataCTF();
    UMEEGDataCTF&               operator=(const UMEEGDataCTF &Data);

    virtual UEuler              GetDewar2NLR(void) const     {if(this) return Dewar2Head; return UEuler();}
    virtual ErrorType           GetError(void) const         {if(this) return error; return U_ERROR;}
    const UString&              GetProperties(UString Comment) const;

    virtual double*             GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*             GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*                GetTriggerEpoch(UEvent Begin, UEvent End);
    virtual const char* const*  GetBadChannels(void) const {return BadChannels;}

    virtual ErrorType           SaveSensorPositions(void) const;
    virtual ErrorType           DeleteDataFiles(void) const;
    virtual ErrorType           RenameDataFiles(const char* BaseName);
    bool                        IsAveragedData(void) const;
    const UBalance**            GetpBalancing(void) const;
    virtual bool                CanBeBalanced(void) const;
    int                         GetDataGradOrder(void) const;

    virtual const UMarkerArray* GetTrialClassArray(void) const {return TrialClassArray;}

    static char*                TruncateResourceLabel(const char* RezName);
    ErrorType                   UpdateDewar2Head(const resource *rez);
    virtual ErrorType           UpdateDewar2Head(UEuler DTH);

protected:
    UEuler                      Dewar2Head;          // The Euler transform to transform the MEG sensors from Dewar to Head coordinates
    void                        InvalidateBalancing(void);
    virtual ErrorType           BalanceMEG(double *MEGdata, UEvent Begin, UEvent End, ReReferenceType ReRef) const;

    static const double         GAUGE_MEG;  // make it femto Tesla   
    static const double         GAUGE_EEG;  // make it micro Volt    

    void                        SetAllMembersDefault(void);
    void                        DeleteAllMembers(ErrorType E);

private:
    static UString              Properties;
    static const int            MAXLABELSIZE;

    UBalance**                  pBal;                 // Balancing array for MEG channels

    char*                       HwFilterText;         // Description of hardware filters in text format
    UMarkerArray*               TrialClassArray;      // Array of marker, corresponding to class-file (first point of each trial is indicated)

    char*                       GetHardwareFilterText(resource* rez);
    UMarkerArray*               ReadClassFile(const char* ClassFile) const;

    char**                      BadChannels;          // Labels in BadChannelFile
    int                         nBadChan;
    ErrorType                   ReadChannelLabels(const char* BadChanFileName);
};

#endif// _MEEGDATACTF_INCLUDED
