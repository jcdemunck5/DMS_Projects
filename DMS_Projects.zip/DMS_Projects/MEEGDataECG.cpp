/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading an MRI .ecg-file containing the ECG                    */
/*                                                                               */
/*     Notes:                                                                    */
/*     The MRI system produces several dummy scans when it is in fMRI EPI mode   */
/*     These dummy scans produce TR-triggers in the .ecg/.puls files, but not    */
/*     on the coax cable led to the EEG system.                                  */
/*     In the files one first finds a "StartMarker", then the data corresponding */
/*     to the dummy-scans and then the data corresponding to the "true" data.    */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    01-07-04   creation
  JdM    21-09-04   ReadMarkers(): read exact sample rate
  JdM    24-11-04   Bug fix: ReadMarkers(): read sample rate
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    05-04-05   BUG Fixes ReadMarkers():   Read items AFTER tags, Time is give in decimal s.
                              AddECGMarkers(): In the old code the stoplogging marker was wrongly interpreted as one second after last scan.
                                               The new code is based in the determination of the sampling frequency from the ecg-file, and the time shift based on the number of dummy scans
  JdM    06-04-05   Added parameter on AddECGMarkers()
  JdM    19-09-05   Added AddECGMarkersUseTR()
                    Bug Fix: AddECGMarkers() Use TimeOffset (instead of wrong TimeShift)
  JdM    25-10-05   Added GetChannel_d()
  JdM    30-11-05   Named markers according to filename extension
  JdM    12-03-03   ReadMarkers(). Added TR-marker
  JdM    25-05-06   Bug Fix: WriteNewMarkers(). Write T1 and T2 times. Also export TR times
  JdM    11-10-06   AddECGMarkersUseTR(). Test variation in TR markers and pass them to extra marker MAXMARKERIN
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    21-06-07   AddECGMarkersUseTR(). Added the detection of events in last "volume"
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h> 

#include "MEEGDataECG.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataECG::Properties = UString();

const char*  UMEEGDataECG::StartMarker   = "OneSecToStart";
const char*  UMEEGDataECG::EndMarker     = "StopLogging";

//    const char* StartMarker = "OneSecToStart";
//    const char* EndMarker   = "OneSecAfterStop";

#define MAXLINE       200
#define MAXMARKERIN    16
#define MAXTRVARIATION 20 //samples

void UMEEGDataECG::SetAllMembersDefault(void)
{
}

void UMEEGDataECG::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
}

UMEEGDataECG::~UMEEGDataECG()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataECG::UMEEGDataECG() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataECG::UMEEGDataECG(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the Brain products data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

/* Read first line of data file */    
    FILE*   fp = fopen(FileName, "rt", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataECG::UMEEGDataECG(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }

    int nsampTot = 0;
    char line[MAXLINE];
    while(fscanf(fp,"%s",line)!=EOF)
    {
        UAnalyzeLine AA(line);
        int samp = AA.GetNextInt(6000);
        if(samp <5000) nsampTot++;
    }
    fclose(fp);

    if(nsampTot<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataECG::UMEEGDataECG(). Total number of samples is too small, nsampTot=%d .\n", nsampTot);
        return;
    }

/* Set gain and type*/
    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataECG::UMEEGDataECG(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_ECG;
    DataFileName      = FileName;   

    ContineousData    = true;
    DateTimeRec       = UDateTime();
    nsamp             = 1;
    ntrial            = nsampTot;
    NPreTrig          = 0;
    nAver             = 0;

    NchannelRaw       = 1;
    NchannelTot       = 1;
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"ECG_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = true;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    ChIn[0].type        = U_DAT_EKG;
    ChIn[0].SkipChannel = false;

    EEGposTrue    = false;
    EEGlabelTrue  = false; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;


    strncpy(PatName,"ECG_NONAME",31);
    strncpy(PatID  ,"ECG1234567890",31);

    error = U_OK;

/* Read markers and classes */
    Markers = ReadMarkers(FileName, &srate);
    if(srate<=0)
    {
        CI.AddToLog("WARNING: UMEEGDataECG::UMEEGDataECG(). Getting sampling rate. Set artificially to 400 Hz.\n");
        srate = 400.; 
    }
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("WARNING: UMEEGDataECG::UMEEGDataECG(). Cannot create UMarkerArray()-object. \n");
    }
    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataECG::UMEEGDataECG(). Setting new Laplacian reference matrix \n");
}

UMEEGDataECG::UMEEGDataECG(const UMEEGDataECG& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataECG.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataECG& UMEEGDataECG::operator=(const UMEEGDataECG &Data)
{
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataECG::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    return *this;
}

const UString& UMEEGDataECG::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataECG-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

ErrorType UMEEGDataECG::WriteNewMarkers(UFileName Fout) 
/*
    Add the updated marker array to data file in .ecg format
 */
{    
    if(Markers==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). No Markers present \n");
        return U_ERROR;
    }
    int  Nmark  = Markers->GetnMarkers();
    Markers->SortEvents();

    int* LastEv = new int[Nmark];
    if(LastEv==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). Memory allocation. \n");
        return U_ERROR;
    }
    for(int im=0; im<Nmark; im++) LastEv[im] = 0;


    FILE *fpOut  = fopen(Fout,"wt", false);
    if(fpOut==NULL)
    {
        delete[] LastEv;
        CI.AddToLog("ERROR UMEEGDataECG::WriteNewMarkers().  C output-file : %s\n",Fout.GetFullFileName());
        return U_ERROR;
    }    
    FILE* fpIn   = fopen(DataFileName, "rt", false);
    if(fpIn==NULL)
    {
        delete[] LastEv;
        CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). File cannot be opened: %s \n",DataFileName.GetFullFileName());
        return U_ERROR;
    }

    char line[MAXLINE];
    int  isamp = 0;
    while(fscanf(fpIn,"%s",line)!=EOF)
    {
        if(!strcmp(line, StartMarker)) 
        {
            fprintf(fpOut, "%s ",StartMarker);
            fscanf(fpIn,"%s",line);
            UAnalyzeLine AA(line);
            double T1 = AA.GetNextDouble(-1.);
            if(T1<0)
            {
                delete[] LastEv;
                CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). Invalid T1 %s .\n", line);
                return U_ERROR;
            }
            fprintf(fpOut, "%16.4f ",T1);
            continue;
        }
        if(!strcmp(line, EndMarker)) 
        {
            fprintf(fpOut, "%s ",EndMarker);
            fscanf(fpIn,"%s",line);
            UAnalyzeLine AA(line);
            double T2 = AA.GetNextDouble(-1.);
            if(T2<0)
            {
                delete[] LastEv;
                CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). Invalid T2 %s .\n", line);
                return U_ERROR;
            }
            fprintf(fpOut, "%16.4f ",T2);
            continue;
        }
        if(!strcmp(line, "TR")) 
        {
            fprintf(fpOut, "%s ","TR");
            fscanf(fpIn,"%s",line);
            UAnalyzeLine AA(line);
            double TR = AA.GetNextDouble(-1.);
            if(TR<0)
            {
                delete[] LastEv;
                CI.AddToLog("ERROR: UMEEGDataECG::WriteNewMarkers(). Invalid TR %s .\n", line);
                return U_ERROR;
            }
            fprintf(fpOut, "%16.4f ",TR);
            continue;
        }
        if(line[2]==':')
        {
            for(int k=0; k<sizeof(line); k++) if(line[k]==' ') line[k]=0;
            fprintf(fpOut, "%s ",line);
            continue;
        }

        UAnalyzeLine AA(line);
        int samp = AA.GetNextInt(6000);
        if(samp<5000) 
        {
            for(int im=0; im<Nmark; im++)
            {
                const UMarker* M = Markers->GetMarker(im);
                if(M==NULL) continue;
                if(LastEv[im]>=M->GetnEvents()) continue;

                if(isamp==M->GetAbsSample(LastEv[im]))
                {
                    fprintf(fpOut, "%d ",5000+im);
                    LastEv[im]++;
                }
            }
            fprintf(fpOut, "%d ",samp);
            isamp++;
        }
    }

    delete[] LastEv;
    fclose(fpIn);
    fclose(fpOut);

    return U_OK;
}

double* UMEEGDataECG::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::GetChannel_d(). NULL Label. \n");
        return NULL;
    }
    if(IsStringCompatible(ChIn[0].namChannel, Label, false)==false)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::GetChannel_d(). Invalid label (%s). \n", Label);
        return NULL;
    }
    return GetEpoch_d(Begin, End, U_DAT_EKG);
}

double* UMEEGDataECG::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
 */
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataECG::GetEpoch_d() : Arguments out of range: Begin.sample = %d  End.sample = %d  .\n", Begin.sample, End.sample);
        return NULL;
    }

    if(Dtype!=U_DAT_EKG && Dtype!=U_DAT_ADC)
    {
        CI.AddToLog("ERROR UMEEGDataECG::GetEpoch_d() : Only U_DAT_EKG or U_DAT_ADC is accepted, Dtype=%d  .\n", Dtype);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataECG::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataECG::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data = new double[NSamples*nKAN];
    if(!data)
    {
        delete[] data; 
        CI.AddToLog("ERROR UMEEGDataECG::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rt", true);
    if(fp==NULL)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataECG::GetEpoch_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  offset = Begin.GetAbsSample(nsamp);
    int  isamp  = 0;
    char line[MAXLINE];
    while(fscanf(fp,"%s",line)!=EOF)
    {
        if(isamp-offset>=NSamples) break;
        UAnalyzeLine AA(line);
        int samp = AA.GetNextInt(6000);
        if(samp >=5000)            continue;
        if(isamp>=offset)          data[isamp-offset] = samp;
        isamp++;
    }
    fclose(fp);

    return data;
}

int* UMEEGDataECG::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataECG::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}


UMarkerArray* UMEEGDataECG::ReadMarkers(UFileName FileName, double* fsamp) const
{
    UMarker Mark[MAXMARKERIN];
    for(int k=0; k<MAXMARKERIN; k++)
    {
        if(k<MAXMARKERIN-1)
        {
            UString Name = UString(FileName.GetExtension())+UString(500+k,"_%d");
            Mark[k]      = UMarker((const char*)Name, 0, nsamp, k, "ECG trigger", 0, false);
        }
        else
            Mark[k]      = UMarker("TR", 0, nsamp, k, "ECG trigger", 0, false);
    }

    FILE*   fp = fopen(FileName, "rt", true);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). Cannot open file %s .\n", FileName.GetFullFileName());
        return NULL;
    }
    
    double T1 = -1;
    double T2 = -1;
    char line[MAXLINE];
    int  isamp = 0;
    int  nsT12 = 0;
    while(fscanf(fp,"%s",line)!=EOF)
    {
        UAnalyzeLine AA(line);
        if(strstr(line, "TR"))
        {
            Mark[MAXMARKERIN-1].AddEvent(UEvent(isamp, 0));
            continue;
        }
        if(strstr(line, StartMarker) && T1<0.)
        {
            fscanf(fp,"%s",line);
            UAnalyzeLine AA(line);
            T1    = AA.GetNextDouble(-1.);
            if(T1<0)
            {
                CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). Invalid T1 %s .\n", line);
                return NULL;
            }
            nsT12 = 0;
            continue;
        }
        if(strstr(line, EndMarker))
        {
            fscanf(fp,"%s",line);
            UAnalyzeLine AA(line);
            T2    = AA.GetNextDouble(-1.);
            if(T2<0)
            {
                CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). Invalid T2 %s .\n", line);
                return NULL;
            }
            if(fsamp)
            {
                *fsamp = 0;
                if(T1>0 && T2>0 && T2>T1) *fsamp = nsT12/(T2-T1);
                else            CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). Getting sample frequency, nsT12 = %d, T1 = %f, T2 = %f \n", nsT12, T1, T2);
            }
            continue;
        }
        int samp = AA.GetNextInt(6000);
        if(samp<5000) 
        {
            isamp++;
            nsT12++;
        }
        else
            for(int k=0; k<MAXMARKERIN-1; k++)
                if(samp==5000+k) Mark[k].AddEvent(UEvent(isamp, 0));
    }
    fclose(fp);

    UMarkerArray* Mar = new UMarkerArray(MAXMARKERIN, nsamp, 0, srate);
    if(Mar==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). Creating UMarkerArray() object \n");
        return NULL;
    }
    Mar->AddNewMarkers(MAXMARKERIN, Mark);
    Mar->RemoveEmptyMarkers();
    return Mar;
}

ErrorType UMEEGDataECG::AddECGMarkersUseTR(UMarkerArray* Markers, UFileName ECGFileName, int NdumVol, const UMarker* VolMarker)
{
    if(Markers==NULL   || Markers->GetError()  !=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkersUseTR(). NULL or erroneous marker array. \n");
        return U_ERROR;
    }
    if(VolMarker==NULL || VolMarker->GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkersUseTR(). NULL or erroneous Volume marker. \n");
        return U_ERROR;
    }
    if(NdumVol<0 || VolMarker->GetnEvents()-NdumVol<=0) 
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkersUseTR(). Too few events in Volume marker (=%d), NdumVol=%d. \n",VolMarker->GetnEvents(),NdumVol);
        return U_ERROR;
    }
    if(Markers->GetSampleRate()<=0 || VolMarker->GetAverageTimeInterval(1./Markers->GetSampleRate())<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkersUseTR(). Average volume time connot be derived from VolMarker. \n");
        return U_ERROR;
    }
    
    FILE* fp = fopen(ECGFileName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Cannot open file %s .\n", ECGFileName.GetFullFileName());
        return U_ERROR;
    }

    int    iTR          =  0;
    int    NsampTrial   =  VolMarker->GetnSampTrial();
    int    NVol         =  VolMarker->GetnEvents();

    UMarker Mark[MAXMARKERIN+1];
    for(int k=0; k<MAXMARKERIN; k++)
    {
        UString Name   = UString(ECGFileName.GetExtension())+UString(500+k,"_%d");
        Mark[k]        = UMarker((const char*)Name, 0, NsampTrial, k, "ECG trigger", 0, false);
    }
    Mark[MAXMARKERIN]  = UMarker("BAD_TR", 0, NsampTrial, 0, "TR bad", 0, false);

    UMarker TRMarker(UEventArray("TRabs", VolMarker->GetnEvents(), 1));    // One sample per trial. 
    TRMarker.SetEvent(0, UEvent(0,0));                                     // Not compatible to Mark[]
                                                                           // Used to detect uneven distributions
    char    line[MAXLINE];
    while(fscanf(fp,"%s",line)!=EOF)
    {
        if(!strstr(line, "TR")) continue;

        fscanf(fp,"%s",line);  // read first TR string
        UAnalyzeLine AA(line);
        AA.GetNextDouble(-1.); // read timing of first TR string
        
        iTR++;
        if(iTR<=NdumVol) continue; // Skip Dummy volumes.
        int iVol = iTR-1-NdumVol;
        if(iVol>=NVol)   break;

        int          NSampTR  = 0;         // Count the number of samples between two TR markers
        bool         NextTR   = false;
        unsigned int TRoffset = ftell(fp); // FILE-offset of first item after (iTR-NdumVol)-th TR string
        
        if(iVol==NVol-1)
        {
            if(iVol<2) break;
            NextTR  = true;
            NSampTR = TRMarker.GetAbsSample(iVol-1) - TRMarker.GetAbsSample(iVol-2);
        }
        else
        {
            while(fscanf(fp,"%s",line)!=EOF)
            {
                if(strstr(line, "TR"))         // (iTR-NdumVol+1)-th TR string
                {
                    NextTR = true;
                    break;
                }
                UAnalyzeLine AA(line);
                if(AA.GetNextInt(10000)<5000) NSampTR++;
            }
        }
        if(NextTR==true)
        {
            if(NSampTR<=0)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Number of samples between TR %d and %d is %d. \n",iTR-1,iTR,NSampTR);
                return U_ERROR;
            }
            if(iVol>0)  TRMarker.SetEvent(iVol, UEvent(TRMarker.GetAbsSample(iVol-1)+NSampTR, 0));

            fseek(fp, TRoffset, SEEK_SET);
            int isamp = 0;
            while(fscanf(fp,"%s",line)!=EOF)
            {
                if(strstr(line, "TR"))       // (iTR-NdumVol+2)-th TR string
                {
                    fseek(fp, -20, SEEK_CUR);
                    break;
                }
                UAnalyzeLine AA(line);
                int samp = AA.GetNextInt(10000);
                if(samp<5000)
                {
                    isamp++;
                }
                else
                {
                    double Fact    = isamp/((double)NSampTR);
                    int    AbsSamp = 0;

                    if(iVol==NVol-1)
                    {
                        if(isamp==10000 || isamp>=NSampTR)  break;
                        AbsSamp = int( VolMarker->GetAbsSample(iVol) + Fact*(VolMarker->GetAbsSample(iVol) - VolMarker->GetAbsSample(iVol-1)) );
                    }
                    else
                    {
                         AbsSamp = int( VolMarker->GetAbsSample(iVol) + Fact*(VolMarker->GetAbsSample(iVol+1) - VolMarker->GetAbsSample(iVol)) );
                    }
                    UEvent E(AbsSamp/NsampTrial, AbsSamp%NsampTrial);

                    for(int k=0; k<MAXMARKERIN; k++)
                        if(samp==5000+k) Mark[k].AddEvent(E);
                }
            }
        }
    }        
    fclose(fp);

    if(iTR<=NdumVol) 
    {
        CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). To few TR markers found: iTR = %d \n", iTR);
        return U_ERROR;
    }
    int MinInt = TRMarker.GetMinInterval();
    int MaxInt = TRMarker.GetMaxInterval();
    int Median = TRMarker.GetMedianInterval();
    CI.AddToLog("Note: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Variation in TR: MinInterval = %d, MedianInterval = %d, MaxInterval = %d .\n", MinInt, Median, MaxInt);
    if(Median>0)
    {
        for(int k=0; k<TRMarker.GetnEvents()-1; k++)
        {
            int Interval = abs( TRMarker.GetAbsSample(k+1)-TRMarker.GetAbsSample(k) );
            if(abs(Interval-Median)>MAXTRVARIATION) 
            {
                Mark[MAXMARKERIN].AddEvent(VolMarker->GetEvent(k));    
                CI.AddToLog("WARNING: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Interval TR-Marker %d varies from median. Deviation = %d samples. Event added to BAD_TR. \n", k, Interval-Median);
            }
        }
    }

    if(Markers->AddNewMarkers(MAXMARKERIN+1, Mark)==U_OK) 
    {
        if(Markers->RemoveEmptyMarkers()==U_OK) return U_OK;
        CI.AddToLog("WARNING: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Removing empty Markers. \n");
        return U_OK;
    }
    CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkersUseTR(). Adding new Markers. \n");
    return U_ERROR;
}

ErrorType UMEEGDataECG::AddECGMarkers(UMarkerArray* Markers, UFileName ECGFileName, int NdumVol, const UMarker* VolMarker, double ForcedFsampECG)
/*
    Read ECG markers from .ecg file. Use the fMRI volume markers *VolMarker and the given number of dummy volumes NdumVol
    to time-align the .ecg markers (added to *Markers) to the EEG data.
    It is assumed that the first event of VolMarker corresponds to the first TRUE volume marker. Before that,
    in the .ECG file there is data corresponding to a 1-sec offset and NdumVol dummy volumes.
    
    if(ForcedFsampECG<=0) derive ECG sampling frequency from ECG file
    else                  use ForcedFsampECG
 */
{
    if(Markers==NULL   || Markers->GetError()  !=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkers(). NULL or erroneous marker array. \n");
        return U_ERROR;
    }
    if(VolMarker==NULL || VolMarker->GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkers(). NULL or erroneous Volume marker. \n");
        return U_ERROR;
    }
    
    FILE* fp = fopen(ECGFileName, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkers(). Cannot open file %s .\n", ECGFileName.GetFullFileName());
        return U_ERROR;
    }

/* Determine ECG sampling frequency */
    char    line[MAXLINE];
    double  FsampECG = 0;
    if(ForcedFsampECG>0.)
    {
        FsampECG = ForcedFsampECG;
    }
    else
    {
        double  T1       = -1;
        double  T2       = -1;
        int     nsT12    = 0;

        while(fscanf(fp,"%s",line)!=EOF)
        {
            UAnalyzeLine AA(line);
            if(strstr(line, StartMarker) && T1<0.)
            {
                fscanf(fp,"%s",line);
                UAnalyzeLine AA(line);
                T1    = AA.GetNextDouble(-1.);
                if(T1<0)
                {
                    fclose(fp);
                    CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkers(). Invalid T1 %s .\n", line);
                    return U_ERROR;
                }
                nsT12 = 0;
                continue;
            }
            if(strstr(line, EndMarker))
            {
                fscanf(fp,"%s",line);
                UAnalyzeLine AA(line);
                T2    = AA.GetNextDouble(-1.);
                if(T2<0)
                {
                    fclose(fp);
                    CI.AddToLog("ERROR: UMEEGDataECG::AddECGMarkers(). Invalid T2 %s .\n", line);
                    return U_ERROR;
                }
                if(T2<=T1)
                {
                    fclose(fp);
                    CI.AddToLog("ERROR: UMEEGDataECG::ReadMarkers(). T2 out of range, T2=%f, T1=%f .\n", T2, T1);
                    return U_ERROR;
                }
                FsampECG = nsT12/(T2-T1);
                break;
            }
            int samp = AA.GetNextInt(6000);
            if(samp<5000)  nsT12++;
        }
    }
    CI.AddToLog("Note: UMEEGDataECG::ReadMarkers(). FsampECG = %14.8f  \n", FsampECG);

/* Read samples */
    int    NsampTrial = VolMarker->GetnSampTrial();
    UMarker Mark[MAXMARKERIN];
    for(int k=0; k<MAXMARKERIN; k++)
    {
        UString Name = UString(ECGFileName.GetExtension())+UString(500+k,"_%d");
        Mark[k]      = UMarker((const char*)Name, 0, NsampTrial, k, "ECG trigger", 0, false);
    }
    rewind(fp);
    double SampleTime   =  1./Markers->GetSampleRate();
    double TimeVolEEG   =  VolMarker->GetAverageTimeInterval(SampleTime);
    double TimeStartEEG =  VolMarker->GetAbsSample(0)*SampleTime;
    double TimeOffset   =  TimeStartEEG-NdumVol*TimeVolEEG-1.;

    int    isamp        = 0;      // sample number after StartMarker, in ECG sampling frequency
    bool   StartReading = false;  // Wait until StartMarker
    while(1)
    {
        if(fscanf(fp,"%s",line)==EOF) 
        {
            fclose(fp);
            CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkers(). End of file reached before reading end marker: '%s' \n",EndMarker);
            return U_ERROR;
        }
        if(!strcmp(line, StartMarker)) 
        {
            isamp        = 0;
            StartReading = true;
            continue;
        }
        if(StartReading==false)   continue;
        if(!strcmp(line, EndMarker)) break;
        
        int samp = atoi(line);

        if(samp <5000) // ECG signal (instead of marker)
        {
            isamp++;
            continue;
        }

        double Time    = TimeOffset + isamp/FsampECG;
        int    AbsSamp = int( Time /SampleTime );
        if(AbsSamp<0)
        {
            CI.AddToLog("WARNING: UQMEEGMarkerAddECG::AddECGMarkers(). Negative sample number: Time = %f \n", Time);
            continue;
        }
        UEvent E(AbsSamp/NsampTrial, AbsSamp%NsampTrial);

        for(int k=0; k<MAXMARKERIN; k++)
            if(samp==5000+k) Mark[k].AddEvent(E);
    }
    fclose(fp);

    if(Markers->AddNewMarkers(MAXMARKERIN, Mark)==U_OK) 
    {
        if(Markers->RemoveEmptyMarkers()==U_OK) return U_OK;
        CI.AddToLog("WARNING: UQMEEGMarkerAddECG::AddECGMarkers(). Removing empty Markers. \n");
        return U_OK;
    }
    CI.AddToLog("ERROR: UQMEEGMarkerAddECG::AddECGMarkers(). Adding new Markers. \n");
    return U_ERROR;
}
