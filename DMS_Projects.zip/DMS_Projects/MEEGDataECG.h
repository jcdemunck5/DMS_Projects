#ifndef _MEEGDATAECG_INCLUDED
#define _MEEGDATAECG_INCLUDED

#include "MEEGDataBase.h"
class UMarker;

class DLL_IO UMEEGDataECG : public UMEEGDataBase
{
public:
    UMEEGDataECG();
    UMEEGDataECG(UFileName FileName);     
    UMEEGDataECG(const UMEEGDataECG& Data); 
    virtual ~UMEEGDataECG();
    UMEEGDataECG&          operator=(const UMEEGDataECG &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;
    ErrorType              WriteNewMarkers(UFileName Fout);
    static ErrorType       AddECGMarkers(UMarkerArray* Markers, UFileName ECGFileName, int NdumVol, const UMarker* VolMarker, double ForcedFsampECG = -1.);
    static ErrorType       AddECGMarkersUseTR(UMarkerArray* Markers, UFileName ECGFileName, int NdumVol, const UMarker* VolMarker);

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    static const char*     StartMarker; 
    static const char*     EndMarker;

    UMarkerArray*          ReadMarkers(UFileName FileName, double* fsamp) const;
};

#endif// _MEEGDATAECG_INCLUDED
