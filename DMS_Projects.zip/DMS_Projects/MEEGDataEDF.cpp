/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a .EDF data file and taking only the necesssary.       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    03-05-05   creation.
  JdM    15-01-06   Added EEG group-re-reference
  JdM    11-08-06   Added GetChannel_d() and ReadMarkers()
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    04-01-10   Skipped 'label headers' named "SEEG", "EEG", "EKG", etc.
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    08-10-10   Added EDF+ compatability
  JdM    08-08-12   Reading channel names: only remove ending spaces
  JdM    07-11-12   Bug Fix. ReadAnnotations(). Properly initialize Markers
  JdM    18-03-14   BUG FIX. UMEEGDataEDF::UMEEGDataEDF(). Setting and applying offsets (ChIn[i].Offset) in case of asymmetric scales
JdM/NK   06-05-14   BUG FIX. GetEpoch_d() and GetTriggerEpoch(). Updating Offset. In the prev version Offset was updated before reading, causing mixed (shifted) channels
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    02-03-15   Do not skip firsr character of channel labels when data is TwentyfourBits
  JdM    12-03-15   Bug Fix: Make sure that for EEG, GridAll SensorType is consistent with ChIn data type
  JdM    30-09-15   ReadAnnotations(). Stop further reading of timing parameters on error.
*/

#include <string.h>

#include "MEEGDataEDF.h"
#include "MarkerArray.h"
#include "AnalyzeLine.h"
#include "Grid.h"

/* Inititalize static const parameters. */
UString UMEEGDataEDF::Properties = UString();


void UMEEGDataEDF::SetAllMembersDefault(void)
{
    TwentyfourBits = false;
    GoldmanReref   = false;
    EDFPlus        = false;
    NCharAnnot     = 0;
    memset((void*)&hdr, ' ', sizeof(EDF_HEADER));
    Properties     = UString();
}

void UMEEGDataEDF::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataEDF::~UMEEGDataEDF()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataEDF::UMEEGDataEDF() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataEDF::UMEEGDataEDF(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the EDF data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

    bool GoldmRef    = false, 

/* Read the header*/
    GoldmanReref   = GoldmRef;
    memset((void*)&hdr, ' ', sizeof(hdr));
    FILE*   fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEDF::UMEEGDataEDF(). File cannot be opened: %s \n",(const char*)FileName);
        return;
    }

/* Read the general header*/
    fread(&hdr, sizeof(hdr), 1, fp);
    if(!memcmp(((char*)&hdr)+1, "BIOSEMI", 7)) TwentyfourBits = true;

    strncpy(PatName, hdr.patient, MIN(sizeof(PatName),80)-1);

    ntrial      = atoi(hdr.norecords);
    NchannelRaw = atoi(hdr.nosignals);
    NchannelTot = NchannelRaw;
    double Duration = atof(hdr.duration);
    if(ntrial<=0 || NchannelRaw<=0 || NchannelRaw>MAXCHAN || Duration<=0)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEDF::UMEEGDataEDF(). Invalid header parameters: NchannelRaw=%d, ntrial=%d and", NchannelRaw, ntrial);
        CI.AddToLog("Duration per trial = %f \n", Duration);
        return;
    }

    EDF_CHAN_HEAD* chhdr = new EDF_CHAN_HEAD[NchannelRaw];
    ChIn                 = new ChanInfo[MAXCHAN];
    GridAll              = new UGrid(MAXCHAN);
    
    if(!chhdr   || !ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        fclose(fp);
        delete[] chhdr;
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataEDF::UMEEGDataEDF(). Memory allocation. \n");
        return;
    }
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"EDF_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }

    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].label,      sizeof(chhdr[i].label),      1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].trans_type, sizeof(chhdr[i].trans_type), 1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].phys_dim  , sizeof(chhdr[i].phys_dim),   1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].phys_min  , sizeof(chhdr[i].phys_min),   1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].phys_max  , sizeof(chhdr[i].phys_max),   1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].digi_min  , sizeof(chhdr[i].digi_min),   1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].digi_max  , sizeof(chhdr[i].digi_max),   1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].prefilter , sizeof(chhdr[i].prefilter),  1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].nosamp_p_record, sizeof(chhdr[i].nosamp_p_record), 1, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].reserved  , sizeof(chhdr[i].reserved),  1, fp);
    fclose(fp);

    NCharAnnot     =  0;
    int NChanAnnot =  0;
    nsamp          = -1;
    for(int i=0; i<NchannelRaw; i++)
    {
        char LineLabel[MAXEDFLABEL+1]; memset(LineLabel, 0, sizeof(LineLabel)); 
        for(int k=0,kk=0; k<MAXEDFLABEL; k++) if(chhdr[i].label[k]!=' ') LineLabel[kk++] = chhdr[i].label[k];

        int nschan = atoi(chhdr[i].nosamp_p_record);
        if(IsStringCompatible(LineLabel, "EDFAnnotations", false)==true)
        {
            NCharAnnot    = 2*nschan;
            NChanAnnot++;
            ChIn[i].type  = U_DAT_ANNOT;
            continue;
        }
        if(nsamp<0)          
        {
            nsamp = nschan;
        }
        else if(nschan!=nsamp)
        {
            nsamp = -1;
            break;
        }
    }
    if(nsamp<=0)
    {
        delete[] chhdr;
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataEDF::UMEEGDataEDF(). nsamp is not constant over channels or invalid.\n");
        return;
    }
    if(NChanAnnot>1 || (NChanAnnot==1 && NCharAnnot<=0))
    {
        delete[] chhdr;
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataEDF::UMEEGDataEDF(). NChanAnnot(=%d) id too large or NChar (=%d) invalid.\n", NChanAnnot, NCharAnnot);
        return;
    }
    for(int i=0; i<NchannelRaw; i++)
    {
        char line[20]; memset(line, 0, sizeof(line));
        strncpy(line, chhdr[i].phys_min, sizeof(chhdr[i].phys_min)); double fmin = atof(line);
        strncpy(line, chhdr[i].phys_max, sizeof(chhdr[i].phys_max)); double fmax = atof(line);
        strncpy(line, chhdr[i].digi_min, sizeof(chhdr[i].digi_min)); double imin = atof(line);
        strncpy(line, chhdr[i].digi_max, sizeof(chhdr[i].digi_max)); double imax = atof(line);

        if(imin==imax)  
        {
            ChIn[i].InGain = 0;
            ChIn[i].Offset = 0;
        }
        else
        {
            ChIn[i].InGain = (     fmax-     fmin)/(imax-imin);
            ChIn[i].Offset = (imax*fmin-imin*fmax)/(imax-imin);
        }
    }

/* Copy general data and set defaults */
    char EDFPLUS[6] = {hdr.reserved[0], hdr.reserved[1],hdr.reserved[2],hdr.reserved[3],hdr.reserved[4],0};
    ContineousData  = IsStringCompatible(EDFPLUS, "EDF+C", false);
    EDFPlus         = IsStringCompatible(EDFPLUS, "EDF+C", false) || IsStringCompatible(EDFPLUS, "EDF+D", false); 
    DataFormat      = U_DATFORM_EDF;
    DataFileName    = FileName;
    char line[20]; memset(line, 0, sizeof(line)); memcpy(line, hdr.date, sizeof(hdr.date));
    DateTimeRec     = UDateTime(line);
    NPreTrig        = 0;
    nAver           = 0;
    srate           = nsamp/Duration;
       
    EEGposTrue      = false;
    EEGlabelTrue    = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

/* set type and namChannel */    
    int Nskip = 0;///3; /* Skipped characters of EDF channel labels */
////    if(TwentyfourBits==true) Nskip = 1; // JdM 2-3-15

    for(int i=0; i<NchannelRaw; i++)
    {
        if(ChIn[i].type!=U_DAT_ANNOT) ChIn[i].type = U_DAT_UNKNOWN;
        if(ChIn[i].SkipChannel==true) continue;

        char LinePhys[10]; memset(LinePhys, 0, sizeof(LinePhys)); memcpy(LinePhys, chhdr[i].phys_dim, 8);
        if(IsStringCompatible(LinePhys,"*uV*", true)==true ||
           IsStringCompatible(LinePhys,"*V*" , true)==true ) 
        {
            if(GoldmanReref==false) 
            {
                ChIn[i].type = U_DAT_EEG;
                nEEG++;
            }
            else
                if(!(i%2)) 
                {
                    ChIn[i].type = U_DAT_EEG;
                    nEEG++;
                }
                else       
                    ChIn[i].type = U_DAT_EEGREF;
        }
        else if(IsStringCompatible(LinePhys,"*fT*", true)==true) 
            ChIn[i].type = U_DAT_MEG;
        else if(IsStringCompatible(LinePhys,"*boolean*", false)==true) 
            ChIn[i].type = U_DAT_STIM;
        
        bool CaseSense = false;
        UString Label(chhdr[i].label+Nskip, sizeof(chhdr[i].label)-Nskip);
        if(Label.IsContaining("SEEG", CaseSense)==true)
        {
            Label.RemoveString("SEEG", CaseSense);
            if(ChIn[i].type != U_DAT_EEG) 
            {
                ChIn[i].type = U_DAT_EEG; 
                nEEG++;
            }
        }
        else if(Label.IsContaining("EEG", CaseSense)==true)
        {
            Label.RemoveString("EEG", CaseSense);
            if(ChIn[i].type != U_DAT_EEG) 
            {
                ChIn[i].type = U_DAT_EEG; 
                nEEG++;
            }
        }
        else if(Label.IsContaining("EKG", CaseSense)==true ||
                Label.IsContaining("ECG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EKG; 
        }
        else if(Label.IsContaining("EOG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EOG; 
        }
        else if(Label.IsContaining("EMG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EMG; 
        }
        else if(Label.IsContaining("Resp", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_ADC; 
        }
        Label.RemoveFirstBlanks();
        Label.RemoveLastBlanks();

        if(ChIn[i].type==U_DAT_UNKNOWN)
        {
            if(UGrid::IsStandardEEGLabel(Label)==true) {ChIn[i].type = U_DAT_EEG; nEEG++;}
            if(UGrid::IsStandardMEGLabel(Label)==true) {ChIn[i].type = U_DAT_MEG; nMEG++;}
        }
        memset(ChIn[i].namChannel, 0                ,     sizeof(ChIn[i].namChannel));
        memcpy(ChIn[i].namChannel, Label.GetString(), MIN(sizeof(ChIn[i].namChannel), Label.GetNbytes())); 
        USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
        if(ChIn[i].type==U_DAT_EEG) S.SetStype(USensor::U_SEN_EEG);
        GridAll->SetSensor(&S, i);
    }
    delete[] chhdr;

    if(GoldmanReref==true && GetNkan(U_DAT_EEG)!=GetNkan(U_DAT_EEGREF))
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEDF::UMEEGDataEDF(). Number of EEG channels (%d) not equal to number of EEG reference channels (%d) . \n", GetNkan(U_DAT_EEG), GetNkan(U_DAT_EEGREF));
        return;
    }

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

/* Read markers and classes */
    UFileName MarkerFile = FileName;
    MarkerFile.ReplaceExtension("Markers");
    if(DoesFileExist(MarkerFile))
    {
        Markers = ReadMarkers(MarkerFile);
        if(Markers==NULL || Markers->GetError()!=U_OK)
        {
            delete Markers; Markers = NULL;
            CI.AddToLog("WARNING: UMEEGDataEDF::UMEEGDataEDF(). Cannot create UMarkerArray()-object. \n");
        }
    }
    ReadAnnotations();
    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataEDF::UMEEGDataEDF(). Setting new Laplacian reference matrix \n");
}

UMEEGDataEDF::UMEEGDataEDF(const UMEEGDataEDF& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataEDF.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataEDF& UMEEGDataEDF::operator=(const UMEEGDataEDF &Data)
{
    if(this==NULL)
    {
        static UMEEGDataEDF M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEDF::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEDF::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    TwentyfourBits = Data.TwentyfourBits;
    GoldmanReref   = Data.GoldmanReref;
    EDFPlus        = Data.EDFPlus;
    NCharAnnot     = Data.NCharAnnot;
    memcpy(&hdr, &(Data.hdr), sizeof(hdr));
    return *this;
}

const UString& UMEEGDataEDF::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties =UString(" ERROR in UMEEGDataEDF-object \n");
        return Properties;
    }
    Properties = UString();
    if(TwentyfourBits==true) Properties += UString(" NbitsPerSample = 24 \n");
    else                     Properties += UString(" NbitsPerSample = 16 \n");
    Properties += UString(" GoldmanReref    = ") + BoolAsText(GoldmanReref) + " \n";
    Properties += UString(" EDFPlus         = ") + BoolAsText(EDFPlus)      + " \n";
    Properties += UString(NCharAnnot, " NCharAnnot      = %d \n");

    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UMEEGDataEDF::ReadAnnotations()
{
    if(NCharAnnot<=0 || NOT(EDFPlus)) return U_OK;

    if(Markers==NULL)
        Markers = new UMarkerArray(0, nsamp, 0, srate);
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("ERROR: UMEEGDataEDF::ReadAnnotations(). Creating UMarkerArray. \n");
        return U_ERROR;
    }
    int NB                  = 2;
    if(TwentyfourBits)  NB  = 3;
    int           NBTrial   = NB*nsamp*(NchannelRaw-1) + NCharAnnot;
    int           OffAnnot  = 256*(NchannelRaw+1);
    for(int i=0;i<NchannelRaw;i++)
    {
        if(ChIn[i].type!=U_DAT_ANNOT) OffAnnot += NB*nsamp;
        else break;
    }

    char* Annot = new char[NCharAnnot+1];
    if(Annot==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEDF::ReadAnnotations(). Memory allocation, NCharAnnot = %d . \n", NCharAnnot);
        return U_ERROR;
    }
    memset(Annot, 0, NCharAnnot+1);

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] Annot;
        CI.AddToLog("ERROR: UMEEGDataEDF::ReadAnnotations(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return U_ERROR;
    }

    UMarker M0("Annot0", 0, nsamp, 255, "EDFplus", 0, true);
    UMarker M1("Annot1", 0, nsamp, 255, "EDFplus", 0, true);
    for(int itrial=0; itrial<ntrial; itrial++)
    {
        int Offset = OffAnnot + itrial * NBTrial;
        fseek(fp, Offset, SEEK_SET);    
        fread(Annot,1,NCharAnnot,fp);
        for(int kc=0;kc<NCharAnnot; kc++) if(Annot[kc]==0) Annot[kc] = ' ';
        UString SAnnot(Annot);
        int     NAnnot = SAnnot.GetNItem();

        for(int im=0; im<MIN(NAnnot, 2); im++)
        {
            ErrorType E    = U_ERROR;
            int       Nc   = 0;
            double    time = SAnnot.GetDouble(0., &E, &Nc);
            if(E==U_OK)
            {
                int    samp = int(floor(time*srate)+0.5);
                UEvent EV(samp/nsamp, samp%nsamp);
                if(im==0) M0.AddEvent(EV);
                if(im==1) M1.AddEvent(EV);

                if(Nc+1<SAnnot.GetNbytes()) SAnnot = UString(SAnnot.GetString()+Nc+1);
            }
            else
            {
                CI.AddToLog("ERROR: UMEEGDataEDF::ReadAnnotations(). Reading double value for annotations timings.\n");
                break;
            }
        }
    }
    if(M0.GetnEvents()>0) Markers->AddMarker(&M0);
    if(M1.GetnEvents()>0) Markers->AddMarker(&M1);
    Markers->RemoveEmptyMarkers();

    delete[] Annot;
    fclose(fp);
    if(Markers->GetnMarkers()<=0)
    {
        delete Markers;
        Markers = NULL;
    }
    return U_OK;
}


double* UMEEGDataEDF::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    int NB                  = 2;
    if(TwentyfourBits)  NB  = 3;
    int            NBTrial  = NB*nsamp*NchannelRaw;
    if(NCharAnnot) NBTrial  = NB*nsamp*(NchannelRaw-1) + NCharAnnot;
    double          *data   = new double[NSamples*nKAN];
    unsigned char   *buffer = new unsigned char[NB*nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataEDF::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataEDF::GetTrial_d(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  OffsetHead      = 256*(NchannelRaw+1);
    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
        int    nSampSkip  = (itrial==Begin.trial) ? Begin.sample : 0; // Skip nSampSkip samples from the beginning of this trial 
        int    nSampTake = nsamp;                                     // Take nSampTake samples from the current trial
        if(itrial==Begin.trial && itrial==End.trial)    nSampTake = End.sample-Begin.sample+1;
        else if(itrial==Begin.trial)                    nSampTake = nsamp-Begin.sample;
        else if(itrial==End.trial)                      nSampTake = End.sample+1;

        int OffsetChan = 0;
        
        for(int i=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type==Dtype && ChIn[i].SkipChannel==false)
            {
                if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
                {
                    for(int j=0;j<nSampTake;j++) DataChan[j] = 0.;
                }
                else
                {
                    fseek(fp, OffsetHead+itrial*NBTrial+OffsetChan+NB*nSampSkip, SEEK_SET);
                    fread(buffer,NB,nSampTake,fp);

                    if(TwentyfourBits==false)
                    {
                        for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((signed short*)buffer)+j));    
                    }
                    else
                        for(int j=0;j<nSampTake;j++)
                        {
                            int bf = buffer[3*j] + (buffer[3*j+1]<<8) + ((signed char)buffer[3*j+2]<<16);
                            DataChan[j] = ChIn[i].Offset + ChIn[i].InGain*bf;
                        }
                }
                DataChan += NSamples;
            }
            if(ChIn[i].type==U_DAT_ANNOT) OffsetChan += NCharAnnot;
            else                          OffsetChan += NB*nsamp;
        }
        nSamplesDone += nSampTake;
    }
    fclose(fp);

    delete[] buffer;

    if(GoldmanReref==true && Dtype==U_DAT_EEG)
    {

/* Substract reference data*/
        double* dataRef = GetEpoch_d(Begin, End, U_DAT_EEGREF);
        if(dataRef==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataEDF::GetEpoch_d(). Getting reference data\n");
            delete[] data;
            return NULL;
        }
     
        for(int k=0; k<nEEG*NSamples; k++) 
        {
            data[k]    -= dataRef[k];
            dataRef[k]  = 0.;
        }

/* Convert bipolar signals to average reference*/
        for(int i=0; i<nEEG; i++)
        {
            for(int k=0; k<nEEG; k++)
            {
                int     ik   = (i+k  )%nEEG;
                double* pED  = data    +ik*NSamples;
                double* pAR  = dataRef + i*NSamples;
                double  W    = (nEEG-2*k-1)/(2.*nEEG);

                for(int j=0; j<NSamples; j++, pED++, pAR++)
                    *pAR += W* *pED ;
            }
        }
        delete[] data;
        data = dataRef;
    }    
    return data;
}

int* UMEEGDataEDF::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetTriggerEpoch() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetTriggerEpoch() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int nKAN = 1;

    int NB                  = 2;
    if(TwentyfourBits)  NB  = 3;
    int            NBTrial  = NB*nsamp*NchannelRaw;
    if(NCharAnnot) NBTrial  = NB*nsamp*(NchannelRaw-1) + NCharAnnot;

    unsigned int    *data   = new unsigned int [NSamples*nKAN];
    unsigned char   *buffer = new unsigned char[NB*nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataEDF::GetTriggerEpoch() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataEDF::GetTriggerEpoch(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  OffsetHead      = 256*(NchannelRaw+1);
    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        unsigned int *DataChan  = data+nSamplesDone;
        int    nSampSkip  = (itrial==Begin.trial) ? Begin.sample : 0; // Skip nSampSkip samples from the beginning of this trial 
        int    nSampTake = nsamp;                                     // Take nSampTake samples from the current trial
        if(itrial==Begin.trial && itrial==End.trial)    nSampTake = End.sample-Begin.sample+1;
        else if(itrial==Begin.trial)                    nSampTake = nsamp-Begin.sample;
        else if(itrial==End.trial)                      nSampTake = End.sample+1;

        int OffsetChan = 0;
        
        for(int i=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type==U_DAT_STIM && ChIn[i].SkipChannel==false)
            {
                if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
                {
                    for(int j=0;j<nSampTake;j++) DataChan[j] = 0;    
                }
                else
                {
                    fseek(fp, OffsetHead+itrial*NBTrial+OffsetChan+NB*nSampSkip, SEEK_SET);
                    fread(buffer,NB,nSampTake,fp);

                    if(TwentyfourBits==false)
                    {
                        for(int j=0;j<nSampTake;j++) DataChan[j] =  *((signed short*)buffer)+j;    
                    }
                    else
                        for(int j=0;j<nSampTake;j++)
                        {
                            DataChan[j] = buffer[3*j] + (buffer[3*j+1]<<8) + ((signed char)buffer[3*j+2]<<16);
                        }
                }
                DataChan += NSamples;
            }
            if(ChIn[i].type==U_DAT_ANNOT) OffsetChan += NCharAnnot;
            else                          OffsetChan += NB*nsamp;
        }
        nSamplesDone += nSampTake;
    }
    fclose(fp);

    delete[] buffer;
    return (int*)data;
}

double* UMEEGDataEDF::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataEDF::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

/* Select the correct channel index. */
    if(Label==NULL || *Label==0) 
    {
        CI.AddToLog("WARNING UMEEGDataEDF::GetChannel_d() : NULL label argument.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0;i<NchannelRaw; i++) 
        if(!strcmp(Label,ChIn[i].namChannel)) 
        {
            ichan = i;
            break;
        }
    if(ichan==-1)
    {
        CI.AddToLog("WARNING UMEEGDataEDF::GetChannel_d() : required label %s not present.\n",Label);
        return NULL; // Label[] not present.
    }
        
    int NB                  = 2;
    if(TwentyfourBits)  NB  = 3;
    int            NBTrial  = NB*nsamp*NchannelRaw;
    if(NCharAnnot) NBTrial  = NB*nsamp*(NchannelRaw-1) + NCharAnnot;
    double          *data   = new double[NSamples];
    int             *buffer = new int   [nsamp];

    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataEDF::GetChannel_d() : memory allocation.\n");
        return NULL;
    }
            
    FILE *fpData = fopen(DataFileName,"rb", false);
    if(!fpData)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataEDF::GetChannel_d() : Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }
    
    int  OffsetHead      = 256*(NchannelRaw+1);
    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    int OffsetChan = 0;
    for(int i=0;i<ichan;i++)
    {
        if(ChIn[i].type==U_DAT_ANNOT) OffsetChan += NCharAnnot;
        else                          OffsetChan += NB*nsamp;
    }
    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
        int    nSampSkip  = (itrial==Begin.trial) ? Begin.sample : 0; // Skip nSampSkip samples from the beginning of this trial 
        int    nSampTake = nsamp;                                     // Take nSampTake samples from the current trial
        if(itrial==Begin.trial && itrial==End.trial)    nSampTake = End.sample-Begin.sample+1;
        else if(itrial==Begin.trial)                    nSampTake = nsamp-Begin.sample;
        else if(itrial==End.trial)                      nSampTake = End.sample+1;

        if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
        {
            for(int j=0;j<nSampTake;j++) DataChan[j] = 0.;    
        }
        else
        {
            fseek(fpData, OffsetHead+itrial*NBTrial+OffsetChan+NB*nSampSkip, SEEK_SET);
            fread(buffer,NB,nSampTake,fpData);                    

            if(TwentyfourBits==false)
            {
                for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((signed short*)buffer)+j));    
            }
            else
                for(int j=0;j<nSampTake;j++)
                {
                    int bf = buffer[3*j] + (buffer[3*j+1]<<8) + ((signed char)buffer[3*j+2]<<16);
                    DataChan[j] = ChIn[ichan].Offset + ChIn[ichan].InGain*bf;
                }
        }
        nSamplesDone += nSampTake;
    }
    fclose(fpData);

    delete[] buffer;
    return data;
}

UMarkerArray* UMEEGDataEDF::ReadMarkers(UFileName FileName) const
{
    FILE*   fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEDF::ReadMarkers(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return NULL;
    }

/****
    Sampling rate: 200Hz, SamplingInterval: 5.00ms
    Type, Description, Position, Length, Channel
    Scanner, Scan Start, 11357, 1, All
    Scanner, Scan Start, 11957, 1, All
    Scanner, Scan Start, 12557, 1, All
    Scanner, Scan Start, 13157, 1, All
    Scanner, Scan Start, 13757, 1, All
****/


/* Read the header file*/
    char line[300];
    GetLine(line, sizeof(line), fp);
    GetLine(line, sizeof(line), fp);

    UMarkerArray* Mar = new UMarkerArray(0, nsamp, 0, srate);
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        delete Mar;
        CI.AddToLog("ERROR: UMEEGDataEDF::ReadMarkers(). Creating UMarkerArray object. \n");
        return NULL;
    }
    UMarker M("EDFmarker", 0, nsamp, 1, NULL, 1, true);

    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsCommentLine(";")==true) continue;
        if(AA.IsEmptyLine()==true) continue;

        int abssamp = AA.GetCollumn_i(3, -1);
        if(abssamp<0) continue;

        UEvent E(abssamp/nsamp, abssamp%nsamp);
        M.AddEvent(E);
    }
    fclose(fp);

    Mar->AddMarker(&M);
    
    return Mar; 
}
