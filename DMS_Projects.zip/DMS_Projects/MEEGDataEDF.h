#ifndef _MEEGDATAEDF_INCLUDED
#define _MEEGDATAEDF_INCLUDED

#include "MEEGDataBase.h"

#define MAXEDFLABEL 16

typedef struct{
    char version[8];
    char patient[80];
    char recording[80];
    char date[8];
    char time[8];
    char nobytes[8];
    char reserved[44];
    char norecords[8];
    char duration[8];
    char nosignals[4];
} EDF_HEADER;

typedef struct{
    char label[MAXEDFLABEL];
    char trans_type[80];
    char phys_dim[8];
    char phys_min[8];
    char phys_max[8];
    char digi_min[8];
    char digi_max[8];
    char prefilter[80];
    char nosamp_p_record[8];
    char reserved[32];
} EDF_CHAN_HEAD;


class DLL_IO UMEEGDataEDF : public UMEEGDataBase
{
public:
    UMEEGDataEDF();
    UMEEGDataEDF(UFileName FileName);     
    UMEEGDataEDF(const UMEEGDataEDF& Data); 
    virtual ~UMEEGDataEDF();
    UMEEGDataEDF&          operator=(const UMEEGDataEDF &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;

    bool                   TwentyfourBits;// true iff data containds 3 bytes per sample (instead of standard 2)
    bool                   GoldmanReref;  // true iff Goldman rereference system is used (twisted pairs)
    bool                   EDFPlus;       // true iff EDF+ is marked in file header
    int                    NCharAnnot;
    EDF_HEADER             hdr;

    UMarkerArray*          ReadMarkers(UFileName FileName) const;
    ErrorType              ReadAnnotations();
};

#endif// _MEEGDATAEDF_INCLUDED
