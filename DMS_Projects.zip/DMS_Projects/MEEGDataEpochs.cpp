/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Module to setting up time segments in the form of an UEpochs-object.        */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    21-11-03   Creation, derived from EpochsData.cpp
  JdM    20-12-03   bug fix SetEpochs(), testing startsample, endsample (use newtriallen)
  JdM    29-12-03   GetFilteredMultiChan(). Make it appropriate for all data types.
                    Added SelectChannels()
  JdM    25-01-04   Added Brain Products data format
  JdM    27-01-04   GetFilteredMultiChan(): In order to avoid problems with triangulation, avoid RemoveSensors() to create a single sensor grid
  JdM    03-02-04   Added new SetEpochs()
  JdM    15-02-04   Added new GetFilteredMultiChan()
  JdM    25-04-04   Added operator=() and copy constructor
  JdM    01-06-04   Added mechanism to set re-reference to common
  JdM    24-06-04   Added ASCII data formats
  JdM    01-07-04   Added ECG data formats
  JdM    03-07-04   SetAverFiltEpochs() added parameter
                    Addded ArePreProcessingEpochsSet(), ReSetPreProcessingEpochs(), GetFilter()
  JdM    07-07-04   Added .txt data formats
  JdM    07-07-04   GetFilteredMultiChan(), added Signal Space Projector
  JdM    18-08-04   Splitting off the SSP-part, move to derived class (UMEEGDataEpochsExt())
  JdM    22-08-04   Added another GetFilteredMultiChan(), with channel selection
  JdM    24-09-04   GetFilteredData(). Test if data set is already averaged. If so, set nEp=1, to prevent averaging of average, plus-minus and sd
  JdM    16-10-04   Added XfmSensorsMEG()
  JdM    17-10-04   Added GetLocalMax()
  JdM    21-11-04   Bug Fix: operator=(), Setting Data to erived class
  JdM    02-01-05   Added new GetFilteredMultiChan()
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    22-04-05   Added ReplaceSensorPositions()
  JdM    21-04-05   declared some undeclared identifiers (for g++-compatibility)
  FB     02-05-05   Added GetAverageMarkerData()
  FB     03-05-05   Added argument NSingleMatch in GetAverageMarkerData()
  JdM    03-05-05   Added EDF format
  JdM    13-05-05   GetFilteredMultiChan(), GetLocalMax(), GetAllFilteredData(), GetAllFilteredMultiChans(), GetFilteredDataNoAver():
                    Made it const
  JdM    05-06-05   Added UFreqBand-object and GetSpectra() and GetFilteredMultiChan() (merged version)
  JdM    03-06-05   Added Map format
  JdM    12-06-05   Renamed merged version of GetFilteredMultiChan() to GetFilteredMultiChanAllTypes(). Added parameter.
  JdM    21-06-05   Added two parameters (UMapFile**) to GetSpectra()
  JdM    25-06-05   Added GetCrossSpectra()
  JdM    09-07-05   Completed GetCrossSpectra()
  JdM    09-09-05   Added GetRMSOverview()
  JdM    01-10-05   Added GetSingleChannelAsField()
  JdM    19-10-05   Added GetTemplateMatch()
  JdM    20-10-05   Added another GetFilteredData()
  JdM    25-10-05   Added ConvertDataType()
                    GetSEFcorrectedData(). Implemented single channel data, for Dtype not equal to U_DAT_ADC, U_DAT_EEG, E_DAT_MEG
                    Bug fix: GetFilteredData() (20-10-05). Testing range of jstart
                    Added another UMultiChan-based GetTemplateMatch()
                    Added another GetFilteredMultiChan()
  JdM    01-11-05   Added RenameSensor()
  JdM    13-12-05   Bug fix: GetNsampReq(). Compute Begin for bs<0 (avoid % and /-operator on negative  integer!)
  JdM    29-12-05   Added UpdateChannelColors() and UpdateChannelGroups()
  JdM    15-01-06   Added WriteSensorPositionsXYZ() and WriteChannelConfigTXT()
  JdM    23-01-06   Added new SetEpochsMarker(), based on single UMarker
  JdM    26-01-06   Added channel-averaging parameter to GetSpectra()
  JdM    28-01-06   Added GetSpectrogramAsFieldArray()
                    Added virtual ShowStatus() (to be used in cooperation with derived Qt-object)
  JdM    05-02-06   UFreqBand::AddSpectra() and UMEEGDataEpochs::GetSpectra(): Added RMS parameter.
                    UMEEGDataEpochs::GetSpectrogramAsFieldArray(): Added overlap-parameter
  JdM    16-02-06   Added ConvertGraphsToMarkers()
  JdM    25-02-06   GetSpectra(): Fdel<=0 implies smallest possible DeltaF
                    Added ExcludeEpochs() and RemoveBadChannels()
  JdM    26-02-06   Added SetCTFSensorGroups()
  JdM    28-03-06   Bug fix GetCrossSpectra(). Initialize CrossReal[] and CrossImag[] to 0.
  JdM    11-05-06   Added RemoveBadEpochs()
  JdM    01-06-06   Added GetLRSymmetryAsTime()
  JdM    08-06-06   Added GetEpochsSuperThreshold()
  JdM    27-06-06   operator=() added EDF data
  JdM    08-10-06   Added GetChannelSamplesAsField()
  JdM    18-10-06   GetSpectra(). Extend file comments.
  JdM    16-11-06   Bug fix: GetFilteredData(). Testing whether isens is out of range.
  JdM    17-11-06   Added parameter to SetFilter()
  JdM    26-11-06   Replace GetChannelSamplesAsField() by GetChannelSamplesAsFieldGraph()
  JdM    05-01-07   Added GetAverPowerHistogramChan() and GetAverPowerHistogram()
                    Added GetAveragedData(), from obsolete UEpochStatistics
                    Added GetUsedMarkerNames(), from obsolete UEpochsData
  JdM    21-02-07   Added parameter type FreqBandType to fix different standard bands
  JdM    25-02-07   GetCrossSpectra() and GetSpectra(). U_FBAND_FIVE,U_FBAND_SEVEN: do not correct for width.
  JdM    14-03-07   GetSpectrogramAsFieldArray(). Added three parameters refering to sub-windows
  JdM    06-04-07   Added GetInterpolatedMEGSpectra()
  JdM    10-04-07   Added GetFilteredMultiChanMEG()
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    19-05-07   Bug fix GetSpectra(). Combining Group averages with maps.
  JdM    23-08-07   Added another SetFilter()
  JdM    29-10-07   Added GetCrossSpectrum()
  JdM    28-11-07   Used AverageTimeFreqPlots(), GetAveragedFilteredMultiChan() and ConvertTimeFreqPlotsToMapFile()
                    in GetSpectrogramAsFieldArray()
                    Added GetWaveletTransformAsFieldArray()
  JdM    19-12-07   Added parameter to SetFilter() (PLWidth)
  JdM    11-01-08   Added RemoveChannels()
  JdM    25-01-08   Added new data format, U_DATFORM_PHILLOG
  JdM    18-02-08   Added GetSynLikeMatrix()
  JdM    06-03-08   GetAveragedData() allowed MarkerName==NULL
  JdM    14-03-08   Merged both versions of GetTemplateMatch() and added parameter (SimilarityType ST)
                    Added new GetAveragedFilteredMultiChan()
  JdM    16-03-08   Made PreProcEpochsText a UString iso char [200]
  JdM    18-03-08   GetAveragedFilteredMultiChan(), GetLocalMax() and GetTemplateMatch(): removed const because of use of ShowStatus()
                    Added ReplaceMarker(), MergeMarkerArray() and AddMarker()
                    Bug fix GetFilteredData(). Set joff = jj; inside j-loop and use (joff>=Ns-1) i.s.o. (joff==Ns-1)
  JdM    19-03-08   GetTemplateMatch(): Several updates.
  JdM    08-05-08   Added another SelectChannels()
  JdM    09-05-08   Added GetSampleRate() and UFreqBand::GetBandAsText()
  JdM    13-05-08   operator=() Added data format U_DATFORM_PHILLOG
  JdM    10-06-08   Several bug fixes in GetTemplateMatch().
                    Bug fix GetAveragedFilteredMultiChan(): use isens (i.s.o. -1) in GetFilteredMultiChan()
  JdM    26-06-08   ExcludeSamples() and ExcludeEpochs(). return U_OK (with WARNING) if Data->MarkerArray()==NULL
  JdM    27-06-08   Replace "delete EpochsPre" by "ReSetPreProcessingEpochs()"
                    GetCrossSpectra() and GetSpectra(): Added epoch information to SpectText
  JdM    28-06-08   Bug Fix: GetInterpolatedMEGSpectra(), GetCrossSpectra() and GetSpectra(). if(SubAve==true): compute average by dividing sum by EpoLast-EpoFirst+1 (forgot the +1)
  JdM    15-08-08   Removed ConvertTimeFreqPlotsToMapFile(), and use new UMapFile constructor.
                    As a consequence, the "Average trial" is omitted from now on.
  JdM    16-08-08   Bug Fix: ExcludeTrials(int, int). Omitted call to ReSetPreProcessingEpochs()
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-09-08   Added GetNolteCausality()
                    Added UFreqBand::GetBandIndex()
  JdM    24-10-08   Added SetEpochs() based on UFieldGraph*
  JdM    22-11-08   Added GetSummedFilteredMultiChan()
  JdM    28-12-08   Bug Fix: GetSummedFilteredMultiChan(). Testing last trial.
  JdM    12-01-09   Added     UMarker* GetOutlierMarker()
  JdM    20-01-09   Bug Fix: GetSummedFilteredMultiChan(). Testing last trial.(Another time...)
  JdM    07-02-09   Added CopyFilter() and CopyChannelSelection()
  JdM    16-02-09   Added ANT data format
  JdM    25-01-08   Added new data format, U_DATFORM_GELOG
  JdM    29-05-09   removed obsolete MergeFiltEpochs and ComCompFiltEpochs
                    Added SetHilbertTransform()
  JdM    30-05-09   CopyFilter(): added copying of rereferencing settings
  JdM    12-09-09   Added GetDateTime()
  JdM    22-10-09   UMEEGDataEpochs(). Removed message of succesful conversion.
  JdM    05-11-09   UMEEGDataEpochs(). Added FIFF data type
  JdM    04-03-10   GetCrossSpectra(). Do less tests on freq parameters when FBT=U_FBAND_FIVE or FBT=U_FBAND_SEVEN
  JdM    10-06-10   Added GetMaxDatChan() and GetMinDatChan()
  JdM    06-11-10   Made several GetFilteredData() private. Added new GetFilteredMultiChan() based on UEvent and offsets
                    Remove (obsolete) AverFiltEpochs, GetRawPrepDataNoAver() and GetFilteredDataNoAver().
                    Added InterpolateCTF
                    NOTE: InterpolateCTF and ComputeHilbertXfm ARE ONLY APPLIED FOR FUNCTIONS RETURNING UMultiChan
  JdM    18-03-11   Bug Fix: DeleteAllMembers(). Use delete instead of delete[]
  JdM    29-03-11   GetTemplateMatch(). Bug fix in case isens>=0
  JdM    20-05-11   GetNEpochsPerMarkers(), GetUsedMarkerNames(). Use UString* instead of char**
  JdM    18-11-11   Remove (obsolete) GetADCData()
                    Added ApplySEFCorrection(), which assumes SEF artifacts are fixed w.r.t. raw trials
                    Added ApplyOutlierCorrection(), SetOutlierCorrection()
                    GetFilteredMultiChan(): use newly added GetRawMultiChan() and not GetFilteredData()
  JdM    15-12-11   Added CTF-directory constructor
  JdM    20-03-12   GetSpectrogramAsFieldArray(): added AbsSamples-parameter.
  JdM    21-03-12   Added new SelectChannels()
  JdM    22-03-12   bug fix: GetRawMultiChan(). Test whether data==NULL, after reading raw data
  JdM    27-03-12   CTF-directory constructor: read BAD channels
  JdM    12-08-12   SetEpochs(const UEpochs* NewEpochs): Allow argument with different NSampTrial than Data 
  JdM    26-11-12   Added SEFMarker data member to compute SEF artefact correction with respect to UMarker
  JdM    16-12-12   Added GetPreNTriggerPnts()
  JdM    21-12-12   Added GetSpatialCovariance()
  JdM    12-02-13   UMEEGDataEpochs(). Added TMSI data type
  JdM    18-07-13   GetAveragedFilteredMultiChan(): removed const because of use of ShowStatus()
                    GetAveragedFilteredMultiChan(UMarker*...): Added Outlier parameter and call GetSummedFilteredMultiChan()
  JdM    23-07-13   Smoothed GetProperties()
  JdM    27-07-13   GetSingleChannelAsField() removed const because of use of ShowStatus()
                    Eliminate compiler warnings regarding unused variables.
  JdM    09-09-13   Added AreEEGPositionsMeasured() and WriteSensorPositionsCTF()
  JdM    17-11-13   Added WriteMarkersMM(), WriteMarkersCTF() and WriteMarkersTXT()
  JdM    18-11-13   UMEEGDataEpochs(). Automatically merge markers from text file with extension ".mrktxt"
  JdM    14-01-14   operator=(), added U_DATFORM_GELOG
  JdM    06-02-14   Bug FIX: WriteMarkersMM(). Use ((UMEEGDataMM*) Data) instead of ((UMEEGDataMM*) this)
  JdM    08-03-14   BUG FIX: GetFilteredMultiChan(). Calling ApplySEFCorrection() in case EpochsPre!=NULL with the wrong Begin and End arguments.
  JdM    14-05-14   SetSEFCorrection(). Added parameters to set window. These are also added as data members: (SEFWinFrom, SEFWinTo)
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    10-11-14   Added GetAllFilteredMultiChans()
                    Added new GetAveragedFilteredMultiChan() with covariance computation.
  JdM    13-12-14   Added 64 bits data format of ANT  (U_DATFORM_ANT64)
  JdM    18-02-15   GetRMSOverview(). Create U_UNIFORM UField object, instead of U_RECTILINEAR
  JdM    20-02-15   Added GetSkipChannelLabelFile(), ReadSkipChannelLabels(), WriteSkipChannels() and RemoveChannelsFromSkipFile().
  JdM    08-03-15   Added GDF data format
  JdM    27-03-15   Added GetOverlapCorrectedAveragedMultiChan()
  JdM    06-04-15   GetOverlapCorrectedAveragedMultiChan(): Use UMatrixSymmetric instead of UMatrixSparse
  JdM    04-08-15   SetFilter(): use UPowerLineType to distinguish between 50. and 60. Hz powerline removal
  JdM    29-09-15   UMEEGDataEpochs::UMEEGDataEpochs(). More liberally compare sample frequencies of text file and data file
  JdM    07-04-15   GetSummedFilteredMultiChan(), test for first and last point current epoch settings, instead of testing of first and last point in data set
                    GetFilteredMultiChan(), when testing AreEpochsContiguous(), allow one sample tolerance
  JdM    09-09-16   Added CopySensorIDsFromNames()
  JdM    13-05-17   RemoveChannelsFromSkipFile() and ReadSkipChannelLabels(). Added (default) argument refering to directory where skipfile is found.
                    Added ReplaceMarkers()
*/

#include <math.h>
#include <string.h>

#include "MEEGDataEpochs.h"
#include "MEEGDataCTF.h"
#include "MEEGDataNS.h"
#include "MEEGDataMM.h"
#include "MEEGDataBP.h"
#include "MEEGDataASC.h"
#include "MEEGDataTxt.h"
#include "MEEGDataECG.h"
#include "MEEGDataEDF.h"
#include "MEEGDataGDF.h"
#include "MEEGDataMap.h"
#include "MEEGDataPhilipsLog.h"
#include "MEEGDataGELog.h"
#include "MEEGDataANT.h"
#include "MEEGDataFIFF.h"
#include "MEEGDataTMSI.h"

#include "Directory.h"
#include "Epochs.h"
#include "MultiChan.h"
#include "MatrixSymmetric.h"
#include "Covariance.h"
#include "MarkerArray.h"
#include "Grid.h"
#include "MapFile.h"
#include "SignalSpaceProj.h"
#include "FieldGraph.h"
#include "SensorCorrelate.h"
#include "Distribution.h"
#include "InterpolateSensors.h"
#include "WaveletTransform.h"
#include "MatrixSparse.h"
#include "SortSemiSort.h"

UString UFreqBand::Properties    = UString();

void UFreqBand::DeleteAllMembers(ErrorType E)
{
    delete[] BandIndexMin;
    delete[] BandIndexMax;
    delete[] CoBuffer;
    delete[] FFTBuffer;
    SetAllMembersDefault();
    error = E;
}

void UFreqBand::SetAllMembersDefault(void)
{
    error        = U_OK;
    Fres         = 1.;
    Fsamp        = 1.;
    NSamp        = 0;
    Nband        = 0;
    BandIndexMin = NULL;
    BandIndexMax = NULL;
    CoBuffer     = NULL;
    FFTBuffer    = NULL;
}

UFreqBand::UFreqBand()
{
    SetAllMembersDefault();
}
UFreqBand::UFreqBand(double Fmin, double Fmax, double Fdel, FreqBandType FBT, double Srate, int Ntime)
{
    SetAllMembersDefault();

    if(Fmin<0. || Fmax<=Fmin)
    {
        error = U_ERROR;
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). Invalid frequencies: Fmin=%f, Fmax=%f, Fdel=%f  \n", Fmin, Fmax, Fdel);
        return;
    }
    if(Srate<=0. || Ntime<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). Invalid sample frequency, or number of samples: Srate=%f, Ntime=%d   . \n", Srate, Ntime);
        return;
    }
    if(FBT==U_FBAND_FIVE || FBT==U_FBAND_SEVEN)
    {
        *this = UFreqBand(FBT, Srate, Ntime);
        return;
    }
    if(Fdel<=0) Fdel = Srate/Ntime;

    Fres         = Srate/Ntime;
    Fsamp        = Srate;
    NSamp        = Ntime;
    Nband        = MAX(1, MIN(Ntime,int(floor(.5+(Fmax-Fmin)/Fdel))));
    double BW    = MAX(Fdel, (Fsamp/Ntime));

    BandIndexMin = new int[Nband];
    BandIndexMax = new int[Nband];
    CoBuffer     = new double[Ntime/2+1];
    FFTBuffer    = new double[2*Ntime];
    if(BandIndexMin==NULL || BandIndexMax==NULL || CoBuffer==NULL || FFTBuffer==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). Memory allocation. \n");
        return;
    }

    for(int n=0; n<Nband; n++)
    {
        BandIndexMin[n] = GetFreqIndex(Fmin +  n   *BW);
        BandIndexMax[n] = GetFreqIndex(Fmin + (n+1)*BW);
    }
}

UFreqBand::UFreqBand(FreqBandType FBT, double Srate, int Ntime)
{
    SetAllMembersDefault();

    if(Srate<=0. || Ntime<=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). Invalid sample frequency, or number of samples: Srate=%f, Ntime=%d   . \n", Srate, Ntime);
        return;
    }
    Fres         = Srate/Ntime;
    Fsamp        = Srate;
    NSamp        = Ntime;

    switch(FBT)
    {
    case U_FBAND_FIVE : Nband = 5; break;
    case U_FBAND_SEVEN: Nband = 7; break;
    default:
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). FreqBandType argument (FBT=%d)  . \n", FBT);
        return;
    }

    BandIndexMin = new int[Nband];
    BandIndexMax = new int[Nband];
    CoBuffer     = new double[Ntime/2+1];
    FFTBuffer    = new double[2*Ntime];
    if(BandIndexMin==NULL || BandIndexMax==NULL || CoBuffer==NULL || FFTBuffer==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::UFreqBand(). Memory allocation. \n");
        return;
    }

    switch(FBT)
    {
    case U_FBAND_FIVE :
        {
        BandIndexMin[0] = GetFreqIndex( Fres);      // Delta
        BandIndexMax[0] = GetFreqIndex( 4.0);
        BandIndexMin[1] = GetFreqIndex( 4.0+Fres);  // Theta
        BandIndexMax[1] = GetFreqIndex( 8.0);
        BandIndexMin[2] = GetFreqIndex( 8.0+Fres);  // Alpha
        BandIndexMax[2] = GetFreqIndex(12.0);
        BandIndexMin[3] = GetFreqIndex(12.0+Fres);  // Beta
        BandIndexMax[3] = GetFreqIndex(20.0);
        BandIndexMin[4] = GetFreqIndex(20.0+Fres);  // Gamma
        BandIndexMax[4] = GetFreqIndex(40.0);
        }
        break;

    case U_FBAND_SEVEN:
        {
        BandIndexMin[0] = GetFreqIndex( Fres);      // Delta
        BandIndexMax[0] = GetFreqIndex( 4.0);
        BandIndexMin[1] = GetFreqIndex( 4.0+Fres);  // Theta
        BandIndexMax[1] = GetFreqIndex( 8.0);
        BandIndexMin[2] = GetFreqIndex( 8.0+Fres);  // Alpha1
        BandIndexMax[2] = GetFreqIndex(10.0);
        BandIndexMin[3] = GetFreqIndex(10.0+Fres);  // Alpha2
        BandIndexMax[3] = GetFreqIndex(13.0);
        BandIndexMin[4] = GetFreqIndex(13.0+Fres);  // Beta1
        BandIndexMax[4] = GetFreqIndex(20.0);
        BandIndexMin[5] = GetFreqIndex(20.0+Fres);  // Gamma1
        BandIndexMax[5] = GetFreqIndex(40.0);
        BandIndexMin[6] = GetFreqIndex(51.0+Fres);  // Gamma2
        BandIndexMax[6] = GetFreqIndex(99.0);
        }
    }
}

UFreqBand::~UFreqBand()
{
    DeleteAllMembers(U_OK);
}

UFreqBand::UFreqBand(const UFreqBand& FB)
{
    SetAllMembersDefault();
    *this = FB;
}

UFreqBand& UFreqBand::operator=(const UFreqBand& FB)
{
    if(this==NULL)
    {
        static UFreqBand F; F.error=U_ERROR;
        return F;
    }
    if(&FB==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UFreqBand::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&FB) return *this;

    DeleteAllMembers(U_OK);
    error        = FB.error;
    Fres         = FB.Fres;
    Fsamp        = FB.Fsamp;
    NSamp        = FB.NSamp;
    Nband        = FB.Nband;
    if(FB.BandIndexMin)
    {
        BandIndexMin = new int[Nband];
        if(BandIndexMin)
        {
            for(int k=0; k<Nband; k++) BandIndexMin[k] = FB.BandIndexMin[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UFreqBand::operator=(). Memory allocation, Nband = %d .\n", Nband);
            return *this;
        }
    }
    if(FB.BandIndexMax)
    {
        BandIndexMax = new int[Nband];
        if(BandIndexMax)
        {
            for(int k=0; k<Nband; k++) BandIndexMax[k] = FB.BandIndexMax[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UFreqBand::operator=(). Memory allocation, Nband = %d .\n", Nband);
            return *this;
        }
    }
    if(FB.CoBuffer)
    {
        CoBuffer     = new double[NSamp/2+1];
        if(CoBuffer)
        {
            for(int k=0; k<NSamp/2+1; k++) CoBuffer[k] = FB.CoBuffer[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UFreqBand::operator=(). Memory allocation, NSamp = %d .\n", NSamp);
            return *this;
        }
    }
    if(FB.FFTBuffer)
    {
        FFTBuffer    = new double[2*NSamp];
        if(FFTBuffer)
        {
            for(int k=0; k<2*NSamp; k++) FFTBuffer[k] = FB.FFTBuffer[k];
        }
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UFreqBand::operator=(). Memory allocation, NSamp = %d .\n", NSamp);
            return *this;
        }
    }
    return *this;
}

ErrorType UFreqBand::AddSpectra(const double* Data, const double* DataAve, int Nkan, double* Spectra, bool RMS) const
{
    if(Data==NULL || Spectra==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddSpectra(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UFreqBand::AddSpectra(). Invalid number of channels, Nkan=%d. \n", Nkan);
        return U_ERROR;
    }
    if(BandIndexMin==NULL || BandIndexMax==NULL || CoBuffer==NULL || FFTBuffer==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddSpectra(). Arrays not all set. \n");
        return U_ERROR;
    }

    const rfftw_plan pFFTplan = FFTW.GetRealPlan(NSamp, true);
    if(pFFTplan==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddSpectra(). FFT Plan cannot not be initialized. \n");
        return U_ERROR;
    }
    double* Temp = FFTBuffer+NSamp;

/* Compute averaged spectra*/
    for(int ic=0;ic<Nkan;ic++)
    {
        memcpy(Temp, Data+ic*NSamp, NSamp*sizeof(Data[0]));
        if(DataAve)
            for(int j=0; j<NSamp; j++)
                Temp[j] -= DataAve[ic*NSamp+j];

        rfftw_one(pFFTplan, Temp, FFTBuffer);       // fourier transform the data.
        CoBuffer[0] = FFTBuffer[0]*FFTBuffer[0];    // The DC-component

        for(int k=1; k<(NSamp+1)/2; k++)
            CoBuffer[k] = 2* (FFTBuffer[k]*FFTBuffer[k] + FFTBuffer[NSamp-k]*FFTBuffer[NSamp-k]);

        if(NSamp%2==0) CoBuffer[NSamp/2] = FFTBuffer[NSamp/2]*FFTBuffer[NSamp/2];

        if(RMS==true)
            for(int k=0; k<(NSamp+1)/2; k++) CoBuffer[k] = sqrt( fabs(CoBuffer[k]) );

/* Average over the selected frequency bands*/
        double *pReal = Spectra+ic*Nband;
        for(int k=0;k<Nband;k++)
            for(int ind=BandIndexMin[k]/2; ind<BandIndexMax[k]/2; ind++)
                pReal[k] += CoBuffer[ind];
    }
    return U_OK;
}

ErrorType UFreqBand::AddCrossSpectra(const double* Data, const double* DataAve, int Nkan, double* CrossReal, double* CrossImag)
{
    if(Data==NULL || CrossReal==NULL || CrossImag==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddCrossSpectra(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UFreqBand::AddCrossSpectra(). Invalid number of channels, Nkan=%d. \n", Nkan);
        return U_ERROR;
    }
    if(BandIndexMin==NULL || BandIndexMax==NULL || CoBuffer==NULL || FFTBuffer==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddCrossSpectra(). Arrays not all set. \n");
        return U_ERROR;
    }

    const rfftw_plan pFFTplan = FFTW.GetRealPlan(NSamp, true);
    if(pFFTplan==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::AddCrossSpectra(). FFT Plan cannot not be initialized. \n");
        return U_ERROR;
    }

    double* QuBuffer     = new double[NSamp/2+1];
    double* FFTBufferAll = new double[Nkan*NSamp];
    if(QuBuffer==NULL || FFTBufferAll==NULL)
    {
        delete[] QuBuffer;
        delete[] FFTBufferAll;
        CI.AddToLog("ERROR: UFreqBand::AddCrossSpectra(). Memory allocation, Nkan=%d, NSamp=%d   . \n", Nkan, NSamp);
        return U_ERROR;
    }

/* Compute the FFT of all channels and store in FFTBufferAll[] */
    double* Temp = FFTBuffer;
    for(int ic=0;ic<Nkan;ic++)
    {
        memcpy(Temp, Data+ic*NSamp, NSamp*sizeof(Data[0]));
        if(DataAve)
            for(int j=0; j<NSamp; j++)
                Temp[j] -= DataAve[ic*NSamp+j];

        rfftw_one(pFFTplan, Temp, FFTBufferAll+ic*NSamp);       // fourier transform the data.
    }

/* Compute the Cross Spectra */
    int Nkan2 = Nkan*Nkan;
    for(int ic1=0;ic1<Nkan;ic1++)
    {
        for(int ic2=0;ic2<Nkan;ic2++)
        {
            const double* pDataFFT1 = FFTBufferAll+ic1*NSamp;
            const double* pDataFFT2 = FFTBufferAll+ic2*NSamp;

            if(ic2>=ic1)
            {
                for(int k=0;k<NSamp/2+1;k++) CoBuffer[k] = QuBuffer[k] = 0;

                CoBuffer[0] = pDataFFT1[0]*pDataFFT2[0];  // The DC-component
                QuBuffer[0] = 0;
                for(int kr=1; kr<(NSamp+1)/2; kr++)
                {
                    int ki = NSamp-kr;
                    CoBuffer[kr] = 2* (pDataFFT1[kr]*pDataFFT2[kr] + pDataFFT1[ki]*pDataFFT2[ki]);
                    QuBuffer[kr] = 2* (pDataFFT1[ki]*pDataFFT2[kr] - pDataFFT1[kr]*pDataFFT2[ki]);
                }
                if(NSamp%2==0)
                {
                    CoBuffer[NSamp/2] = pDataFFT1[NSamp/2]*pDataFFT2[NSamp/2];
                    QuBuffer[NSamp/2] = 0;
                }

                for(int k=0;k<Nband;k++)
                {
                    for(int ind=BandIndexMin[k]/2; ind<BandIndexMax[k]/2; ind++)
                    {
                        CrossReal[k*Nkan2+ic1*Nkan+ic2] += CoBuffer[ind];
                        CrossImag[k*Nkan2+ic1*Nkan+ic2] += QuBuffer[ind];
                    }
                }
            }
            else
            {
                for(int k=0;k<Nband;k++)
                {
                    CrossReal[k*Nkan2+ic1*Nkan+ic2] = CrossReal[k*Nkan2+ic2*Nkan+ic1];
                    CrossImag[k*Nkan2+ic1*Nkan+ic2] =-CrossImag[k*Nkan2+ic2*Nkan+ic1];
                }
            }
        }
    }
    delete[] QuBuffer;
    delete[] FFTBufferAll;

    return U_OK;
}

const UString&  UFreqBand::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties =UString(" ERROR in UFreqBand-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(Fres , " Fres  = %f   \n");
    Properties += UString(Fsamp, " Fsamp = %f   \n");
    Properties += UString(NSamp, " NSamp = %d   \n");
    Properties += UString(Nband, " Nband = %d   \n");

    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}

UString UFreqBand::GetBandAsText(int iband) const
{
    if(this==NULL || error!=U_OK)        return UString("NULL_FreqBand");
    if(iband<0    || iband>=Nband)       return UString(iband, "ErrorBand_%d");

    double fm = GetLowBand(iband);
    double fM = GetHighBand(iband);

    return UString(fm,"%6.2f_") + UString(fM,"%6.2f");
}

int UFreqBand::GetFreqIndex(double Freq) const
{
    int    result = int( .5 + NSamp*fabs(Freq)/Fsamp );            // JdM/JV 9-8-2
    return result = MAX(0, MIN((NSamp-1), (result*2)));
}

int UFreqBand::GetBandIndex(double Freq) const
{
    if(BandIndexMin==NULL || BandIndexMax==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::GetBandIndex(). Band index arrays not set. \n");
        return -1;
    }
    int Findex = GetFreqIndex(Freq);
    for(int iband=0; iband<Nband; iband++)
    {
        if(BandIndexMin[iband]<=Findex && Findex<BandIndexMax[iband]) return iband;
    }
    return -1;
}

int UFreqBand::GetNFreq(int Index) const
{
    if(BandIndexMax==NULL || BandIndexMin==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::GetNFreq(). Index arrays not set. \n");
        return 0;
    }
    if(Index<0 || Index>=Nband)
    {
        CI.AddToLog("ERROR: UFreqBand::GetNFreq(). Index out of range (Index = %d). \n", Index);
        return 0;
    }
    return BandIndexMax[Index]/2 - BandIndexMin[Index]/2;
}

double UFreqBand::GetLowBand(int Index) const
{
    if(BandIndexMin==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::GetLowBand(). BandIndexMin=NULL. \n");
        return 0.;
    }
    if(NSamp<=1) return 0.;

    Index = MIN((Nband-1),(MAX(0,Index)));
    return .5*BandIndexMin[Index]*Fsamp/NSamp;      // JdM/JV 9-8-2
}

double UFreqBand::GetHighBand(int Index) const
{
    if(BandIndexMax==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::GetHighBand(). BandIndexMax=NULL. \n");
        return 0.;
    }
    if(NSamp<=1) return 0.;

    Index = MIN((Nband-1),(MAX(0,Index)));
    return .5*BandIndexMax[Index]*Fsamp/NSamp;      // JdM/JV 9-8-2
}

double UFreqBand::GetCenterFreq(int Index) const
{
    return ( GetLowBand(Index)+GetHighBand(Index) )/2.;
}

double* UFreqBand::GetFrequencies(void) const
{
    double* Freq = new double[Nband];
    if(Freq==NULL)
    {
        CI.AddToLog("ERROR: UFreqBand::GetFrequencies(). Memorie allocation. Nband = %d \n", Nband);
        return NULL;
    }
    for(int ib=0; ib<Nband; ib++)
        Freq[ib] = GetCenterFreq(ib);
    return Freq;
}


/* Inititalize static const parameters. */
      UString UMEEGDataEpochs::Properties    = UString();
const double  UMEEGDataEpochs::TMIN          = 2.;      // [seconds]
const double  UMEEGDataEpochs::NSAMPFACTOR   = 1.2;     // Should be larger than 1
const double  UMEEGDataEpochs::TartBegin     = 0.0005;  // Time after stimulus onset that artifact begins [s]
const double  UMEEGDataEpochs::TartWidth     = 0.0035;  // Width of the artifact [s]


void UMEEGDataEpochs::SetAllMembersDefault(void)
{
    Data                = NULL;
    Epochs              = NULL;
    EpochsPre           = NULL;

    error               = U_OK;
    Properties          = UString();

    for(int k=0; k<U_DAT_NTYPE; k++)
    {
        OutPar[k].Apply = false;
        DataType Dtype  = UMEEGDataBase::GetDataType(k);
        switch(Dtype)
        {
        case U_DAT_MEG:
        case U_DAT_MEGREF:
            OutPar[k].Normal =  2000.; break;
        case U_DAT_EEG:
        case U_DAT_EEGREF:
            OutPar[k].Normal =   100.; break;
        case U_DAT_EKG:
            OutPar[k].Normal =  1000.; break;
        case U_DAT_EOG:
        case U_DAT_EMG:
            OutPar[k].Normal =  1000.; break;
        default:
            OutPar[k].Normal = 1.E200; break;
        }
        OutPar[k].Outlier = 20*OutPar[k].Normal;
    }
    DoNotExtraSamples   = false;
    MEGReref            = U_REF_RAW;
    EEGReref            = U_REF_AVERAGE;
    CorrectSEFartifact  = false;
    SEFMarker           = UMarker();
    SEFWinFrom          = 0;
    SEFWinTo            = 0;
    ComputeHilbertXfm   = false;
    InterpolateCTF      = false;

    SampleTime_s        = 0.;
    NPreTriggerSamples  = 0;

    PreProcEpochsText   = UString();
}

void UMEEGDataEpochs::DeleteAllMembers(ErrorType E)
{
    delete  Data;
    delete  Epochs;
    delete  EpochsPre;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataEpochs::UMEEGDataEpochs(): Filt(0.)
{
    SetAllMembersDefault();
}

UMEEGDataEpochs::UMEEGDataEpochs(const UMEEGDataEpochs& DatEp)
{
    SetAllMembersDefault();
    *this = DatEp;
}

UMEEGDataEpochs::UMEEGDataEpochs(UDirectory DirName) : Filt(0.)
{
    SetAllMembersDefault();
    UFileName F(DirName.GetDirectoryName());
    F.ReplaceExtension(".ds");
    UDirectory Dir(F.GetFullFileName());
    F = Dir + UFileName(F.GetBaseName());
    F.ReplaceExtension("res4");
    if(F.DoesFileExist()==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). File does not exist: %s \n", (const char*)F);
        return;
    }
    FILE* fpBAD    = fopen(Dir + UFileName("BadChannels"), "rb");
    char* BadChans = NULL;
    if(fpBAD)
    {
        int Size = GetFileSize(fpBAD);
        BadChans = new char[Size+2];
        if(BadChans)
        {
            memset(BadChans,0,Size+2);
            for(int n=0; n<Size; n++)
            {
                int c = fgetc(fpBAD);
                if(c==EOF) break;
                if(c==10 || c==12) 
                {
                    if(n>0 && BadChans[n-1]!=',') BadChans[n] = ',';
                }
                else BadChans[n]=c;
            }
        }
        fclose(fpBAD);
    }
    *this = UMEEGDataEpochs(F, NULL, BadChans);
    delete[] BadChans;
}
UMEEGDataEpochs::UMEEGDataEpochs(UFileName FileName, const char* forceGoodCh, const char* forceBadCh) : Filt(0.)
/*
    DSName is the name of a CTF Data set, a directory containing several uniques files
    (see UCTFDataSet-object). This data set can be used by other functions to create epochs.
 */
{
    SetAllMembersDefault();

    DataFormatType DTF = UMEEGDataBase::GetDataFormatType(FileName);
    if(DTF==U_DATFORM_UNKNOWN)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). Data format of file %s is not recognized. \n", FileName.GetFullFileName());
        return;
    }
    switch(DTF)
    {
    case U_DATFORM_CTF:       Data = new UMEEGDataCTF(FileName);         break;
    case U_DATFORM_NEUROSCAN: Data = new UMEEGDataNS(FileName);          break;
    case U_DATFORM_MICROMED:  Data = new UMEEGDataMM(FileName);          break;
    case U_DATFORM_BRAINPROD: Data = new UMEEGDataBP(FileName);          break;
    case U_DATFORM_EDF:       Data = new UMEEGDataEDF(FileName);         break;
    case U_DATFORM_GDF:       Data = new UMEEGDataGDF(FileName);         break;
    case U_DATFORM_MAP:       Data = new UMEEGDataMap(FileName);         break;
    case U_DATFORM_ASCII:     Data = new UMEEGDataASC(FileName);         break;
    case U_DATFORM_ECG:       Data = new UMEEGDataECG(FileName);         break;
    case U_DATFORM_TXT:       Data = new UMEEGDataTxt(FileName);         break;
    case U_DATFORM_PHILLOG:   Data = new UMEEGDataPhilipsLog(FileName);  break;
    case U_DATFORM_GELOG:     Data = new UMEEGDataGELog(FileName);       break;
    case U_DATFORM_ANT:       Data = new UMEEGDataANT(FileName);         break;
    case U_DATFORM_ANT64:     Data = new UMEEGDataANT(FileName);         break;
    case U_DATFORM_FIFF:      Data = new UMEEGDataFIFF(FileName);        break;
    case U_DATFORM_TMSI:      Data = new UMEEGDataTMSI(FileName);        break;
    default:
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). Data format not yet implemented (%s). \n", Data->GetDataFormatTypeText(DTF));
        return;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). Data object cannot be created from file %s .\n", FileName.GetFullFileName());
        return;
    }
    if(DTF==U_DATFORM_CTF && forceGoodCh==NULL && forceBadCh==NULL)
    {
        Data->SelectChannels(NULL, Data->GetBadChannels());
    }
    else if(Data->SelectChannels(forceGoodCh, forceBadCh)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). Selecting channels. \n");
        return;
    }
    SampleTime_s = Data->GetSampleTime_s();
    Filt         = ULinearFilter(Data->GetSampleRate());

    UFileName FMarkText = Data->GetMarkerTextFile();
    if(FMarkText.DoesFileExist()==true)
    {
        UMarkerArray MText(FMarkText);
        if(MText.GetError()!=U_OK || fabs(MText.GetSampleRate()-Data->GetSampleRate())>0.1 || MText.GetnSampTrial()!=Data->GetNsampTrial())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::UMEEGDataEpochs(). Creating Markers from text file. SampleRate (%f) or NSampTrial (%d)might be incompatible. \n", MText.GetSampleRate(), MText.GetnSampTrial());
        }
        else
        {
            if(MText.GetSampleRate()!=Data->GetSampleRate())
                CI.AddToLog("WARNING: UMEEGDataEpochs::UMEEGDataEpochs(). Creating Markers from text file. SampleRate in text file (%f) or exactly equal to sample rate in data file (%f). \n", MText.GetSampleRate(), Data->GetSampleRate());

            ErrorType   E = U_OK;
            if(Data->GetMarkerArray())
            {
                if(E==U_OK) E = MText.MergeMarkerArray(Data->GetMarkerArray(), true);
                if(E==U_OK) E = MText.RemoveEmptyMarkers();
                if(E==U_OK)     MText.RemoveDoubleMarkers();
            }
            if(E==U_OK) E = SetMarkerArray(&MText);
            if(E!=U_OK)
            {
                CI.AddToLog("WARNING: UMEEGDataEpochs::UMEEGDataEpochs(). Merging markers from text file: %s \n", (const char*)FMarkText);
            }
        }
    }
}

UMEEGDataEpochs::~UMEEGDataEpochs()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataEpochs& UMEEGDataEpochs::operator=(const UMEEGDataEpochs &DatEp)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). this==NULL. \n");
        static UMEEGDataEpochs E; E.error=U_ERROR;
        return E;
    }
    if(&DatEp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Argument has NULL address. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&DatEp) return *this;

    DeleteAllMembers(U_OK);

    for(int k=0; k<U_DAT_NTYPE; k++)
    {
        OutPar[k].Apply   = DatEp.OutPar[k].Apply;
        OutPar[k].Normal  = DatEp.OutPar[k].Normal;
        OutPar[k].Outlier = DatEp.OutPar[k].Outlier;
    }
    if(DatEp.Data)
    {
        switch(DatEp.Data->GetDataFormatType())
        {
        case U_DATFORM_CTF:       Data = new UMEEGDataCTF       (*(UMEEGDataCTF*       )DatEp.Data);   break;
        case U_DATFORM_NEUROSCAN: Data = new UMEEGDataNS        (*(UMEEGDataNS *       )DatEp.Data);   break;
        case U_DATFORM_MICROMED:  Data = new UMEEGDataMM        (*(UMEEGDataMM *       )DatEp.Data);   break;
        case U_DATFORM_BRAINPROD: Data = new UMEEGDataBP        (*(UMEEGDataBP *       )DatEp.Data);   break;
        case U_DATFORM_EDF:       Data = new UMEEGDataEDF       (*(UMEEGDataEDF*       )DatEp.Data);   break;
        case U_DATFORM_GDF:       Data = new UMEEGDataGDF       (*(UMEEGDataGDF*       )DatEp.Data);   break;
        case U_DATFORM_MAP:       Data = new UMEEGDataMap       (*(UMEEGDataMap*       )DatEp.Data);   break;
        case U_DATFORM_ASCII:     Data = new UMEEGDataASC       (*(UMEEGDataASC*       )DatEp.Data);   break;
        case U_DATFORM_ECG:       Data = new UMEEGDataECG       (*(UMEEGDataECG*       )DatEp.Data);   break;
        case U_DATFORM_TXT:       Data = new UMEEGDataTxt       (*(UMEEGDataTxt*       )DatEp.Data);   break;
        case U_DATFORM_PHILLOG:   Data = new UMEEGDataPhilipsLog(*(UMEEGDataPhilipsLog*)DatEp.Data);   break;
        case U_DATFORM_GELOG:     Data = new UMEEGDataGELog     (*(UMEEGDataGELog*     )DatEp.Data);   break;
        case U_DATFORM_ANT:       Data = new UMEEGDataANT       (*(UMEEGDataANT*       )DatEp.Data);   break;
        case U_DATFORM_ANT64:     Data = new UMEEGDataANT       (*(UMEEGDataANT*       )DatEp.Data);   break;
        case U_DATFORM_FIFF:      Data = new UMEEGDataFIFF      (*(UMEEGDataFIFF*      )DatEp.Data);   break;
        case U_DATFORM_TMSI:      Data = new UMEEGDataTMSI      (*(UMEEGDataTMSI*      )DatEp.Data);   break;
        default:
            CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Data format not yet implemented (%s). \n", Data->GetDataFormatTypeText(DatEp.Data->GetDataFormatType()));
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        if(Data==NULL || Data->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying UMEEGDataBase()-object. \n");
            return *this;
        }
    }

    if(DatEp.Epochs)
    {
        Epochs = new UEpochs(*DatEp.Epochs);
        if(Epochs==NULL || Epochs->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying UEpochs()-object. \n");
            return *this;
        }
    }
    if(DatEp.EpochsPre)
    {
        EpochsPre = new UEpochs(*DatEp.EpochsPre);
        if(EpochsPre==NULL || EpochsPre->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying UEpochs()-object for pre-processing. \n");
            return *this;
        }
    }

    Filt               = DatEp.Filt;
    DoNotExtraSamples  = DatEp.DoNotExtraSamples;
    MEGReref           = DatEp.MEGReref;
    EEGReref           = DatEp.EEGReref;
    CorrectSEFartifact = DatEp.CorrectSEFartifact;
    SEFMarker          = DatEp.SEFMarker;
    SEFWinFrom         = DatEp.SEFWinFrom;
    SEFWinTo           = DatEp.SEFWinTo;
    ComputeHilbertXfm  = DatEp.ComputeHilbertXfm;
    InterpolateCTF     = DatEp.InterpolateCTF;

    SampleTime_s       = DatEp.SampleTime_s;
    NPreTriggerSamples = DatEp.NPreTriggerSamples;

    PreProcEpochsText  = DatEp.PreProcEpochsText;
    ClustEpo           = DatEp.ClustEpo;
    if(ClustEpo.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying ClustEpo. \n");
        return *this;
    }
    return *this;
}
int UMEEGDataEpochs::GetPreNTriggerPnts(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetPreNTriggerPnts(). Object NULL or erroneous.\n");
        return 0;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetPreNTriggerPnts(). Data not (properly) set. \n");
        return 0;
    }
    return Data->GetPreNTriggerPnts();
}
double UMEEGDataEpochs::GetSampleRate(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSampleRate(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSampleRate(). Data not (properly) set. \n");
        return 0.;
    }
    return Data->GetSampleRate();
}
int UMEEGDataEpochs::GetNsampTrial(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNsampTrial(). Object NULL or erroneous.\n");
        return 0;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNsampTrial(). Data not (properly) set. \n");
        return 0;
    }
    return Data->GetNsampTrial();
}

ErrorType UMEEGDataEpochs::SetEpochsMarker(int halfwidth, const char* markername)
/*
    Create epochs by taking about each marker named markername[] in the markerfile a symmetric
    window, with halfwidth samples before and halfwidth samples after the marker. Therefore
    the total width of each marker will be 2*halfwidth+1.

    Notes:
    If(markername==NULL or markername[0]==0) all markers are considered.
*/
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Data not set.\n");
        return U_ERROR;
    }

    int BeginOffset = -halfwidth;
    int EndOffset   =  halfwidth;

    UEpochs* NewEpochs = new UEpochs(BeginOffset, EndOffset, Data->GetMarkerArray(), markername);

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = ((2*halfwidth-1)/2);
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochsMarker(int BeginOffset, int EndOffset, const UMarker* M)
/*
    Create epochs by taking samples based on events of *M.
    From each event of M the begin of the epoch is set by shifting the marker
    BeginOffset samples (in the direction of the sign of BeginOffset) and the end
    of the epochs are similarly obtained by shifing the marker by EndOffset samples.
*/
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Data not set.\n");
        return U_ERROR;
    }

    UEpochs* NewEpochs = new UEpochs(BeginOffset, EndOffset, M);

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = -BeginOffset;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Creating new epochs. \n");
    return U_ERROR;
}

UFileName UMEEGDataEpochs::GetSkipChannelLabelFile(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSkipChannelLabelFile(). Obect NULL or erroneous.\n");
        return UFileName();
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSkipChannelLabelFile(). Data not (properly) set.\n");
        return UFileName();
    }
    return Data->GetSkipChannelLabelFile();
}
char* UMEEGDataEpochs::ReadSkipChannelLabels(const char* SkipDir) const // Comma separated labels string
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadSkipChannelLabels(). Obect NULL or erroneous.\n");
        return NULL;
    }

    UFileName FLab = GetSkipChannelLabelFile();
    if(SkipDir) FLab = UDirectory(SkipDir) + UFileName(FLab.GetBaseName());
    if(DoesFileExist(FLab)==false) return NULL;

    FILE *fpSkip = fopen(FLab,"rb");
    if(fpSkip==NULL) return NULL;

    char* SkipLabels = NULL;
    int Size   = GetFileSize(fpSkip);
    SkipLabels = new char[Size+2];
    if(SkipLabels)
    {
        memset(SkipLabels,0,Size+2);
        for(int n=0; n<Size; n++)
        {
            int c = fgetc(fpSkip);
            if(c==EOF) break;
            if(c==10 || c==12) 
            {
                if(n>0 && SkipLabels[n-1]!=',') SkipLabels[n] = ',';
            }
            else SkipLabels[n]=c;
        }
    }
    fclose(fpSkip);
    return SkipLabels;
}
ErrorType UMEEGDataEpochs::WriteSkipChannels(const ChanInfo* ChInf, UFileName FLab) // static
{
    if(ChInf==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteSkipChannels(). Invalid NULL argument.\n");
        return U_ERROR;
    }

    FILE *fpSkip = fopen(FLab,"wb");
    if(fpSkip==NULL) 
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteSkipChannels(). Cannot create file %s .\n", (const char*)FLab);
        return U_ERROR;
    }
    for(int i=0; i<UMEEGDataBase::MAXCHAN; i++)
    {
        if(ChInf[i].SkipChannel==false) continue;
        if(ChInf[i].type==U_DAT_MEGREF || ChInf[i].type==U_DAT_UNKNOWN) continue;
        for(int k=0; k<sizeof(ChInf[0].namChannel); k++) 
        {
            if(ChInf[i].namChannel[k]==0 || k==sizeof(ChInf[0].namChannel)-1)
            {
                fprintf(fpSkip, ",");
                break;
            }
            fprintf(fpSkip, "%c", ChInf[i].namChannel[k]);
        }
    }
    fclose(fpSkip);
    return U_OK;
}

ErrorType UMEEGDataEpochs::SetEpochsMarker(int BeginOffset, int EndOffset, const char* markername)
/*
    Create epochs by taking samples based on markers named markername[] in the markerfile.
    From each of those markers, the begin of the epoch is set by shifting the marker
    BeginOffset samples (in the direction of the sign of BeginOffset) and the end
    of the epochs are similarly obtained by shifing the marker by EndOffset samples.

    Notes:
    If(markername==NULL or markername[0]==0) all markers are considered.
*/
{
    if(this==NULL|| Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Data not set.\n");
        return U_ERROR;
    }

    UEpochs* NewEpochs = new UEpochs(BeginOffset, EndOffset, Data->GetMarkerArray(), markername);

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = -BeginOffset;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochsMarker(const char* BEName)
/*
    Create epochs by looking for pairs of BEGIN and END markers in the marker-file. BEGIN
    and END markers are markers whose name start with "Begin" and "End" (case insensitive,
    see UCTFDataMarker::GetEpochs()).
    Only markers located between starttrial and endtrial are considered.
*/
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Data not set.\n");
        return U_ERROR;
    }

    UEpochs* NewEpochs = new UEpochs(Data->GetMarkerArray(), BEName);

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochs(int startsample, int endsample)
/*
     Ignore Marker information. Time in sample numbers.
 */
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochsMarker() : Data==NULL\n");
        return U_ERROR;
    }

    if(startsample>=Data->GetNsampTrial()  ||startsample<0) startsample = 0;
    if(endsample  >=Data->GetNsampTrial()  ||  endsample<0) endsample   = Data->GetNsampTrial()-1;

    UEpochs* NewEpochs = new UEpochs(0, Data->GetNtrial()-1, startsample, endsample, Data->GetNsampTrial());

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = Data->GetPreNTriggerPnts()-startsample;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return U_OK;
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochsMarker(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochs(int npieces, bool ForcePower2, bool IgTrBd)
/*
     Create epochs by dividing each trial into (approximately)
     npieces non-overlapping pieces.
     If(ForcePower2==true) the size of the non-overlapping pieces will be forced to be a power of two.
     If(IgTrBd     ==true) the trial boundaries will be ignored during subdivsion of the trials.
 */
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochs() : Data==NULL\n");
        return U_ERROR;
    }
    UEpochs* NewEpochs = new UEpochs(npieces, Data->GetNtrial(), Data->GetNsampTrial(), ForcePower2, IgTrBd);

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochs(int nsampskip, int newtriallen, int startsample, int endsample)
/*
    Set the epochs by skipping the first nsampskip, then dividing the data into
    trials of newtriallen samples, and selecting from these new trials all
    samples from startsample to endsample.
 */
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochs() : Data==NULL\n");
        return U_ERROR;
    }

    if(startsample>=newtriallen  ||startsample<0) startsample = 0;
    if(endsample  >=newtriallen  ||  endsample<0) endsample   = newtriallen-1;

    UEpochs* NewEpochs = new UEpochs(nsampskip, newtriallen, startsample, endsample, Data->GetNsampTrial(), Data->GetNtrial());

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochs(const UEpochs* NewEpochs)
/*
    Replace Current epoochs by argument *NewEpochs.
 */
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochs() : Data==NULL\n");
        return U_ERROR;
    }
    if(NewEpochs && NewEpochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Invalid UEpochs() argument. \n");
        return U_ERROR;
    }

    if(NewEpochs==NULL)
    {
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NULL;
        return U_OK;
    }

    UEpochs* NNewEpochs = NULL;
    if(Data && Data->GetNsampTrial()!=NewEpochs->GetnSampTrial()) NNewEpochs = new UEpochs(*NewEpochs, Data->GetNsampTrial());
    else                                                          NNewEpochs = new UEpochs(*NewEpochs);

    if(NNewEpochs && NNewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NNewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NNewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochs(const UFieldGraph* FG, double Level)
{
    if(this==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochs() : this==NULL or Data==NULL\n");
        return U_ERROR;
    }
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). NULL or erroneous UFieldGraph argument.\n");
        return U_ERROR;
    }
    if((FG->GetFType()!=UField::U_UNIFORM && FG->GetFType()!=UField::U_RECTILINEAR) ||
        FG->Getndim()!=1 || FG->GetNpoints()<1 || FG->GetVeclen()!=1)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). UFieldGraph argument of wrong type (%s).\n", FG->GetProperties(""));
        return U_ERROR;
    }

    UEpochs* NewEpochs = new UEpochs(FG, Level, Data->GetSampleTime_s(), Data->GetNsampTrial());

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Creating new epochs. \n");
    return U_ERROR;
}


ErrorType UMEEGDataEpochs::SetEpochsShift(int EpochLen, int EpochShift)
/*
    Set the epochs, starting from the first sample, take the first EpochLen samples,
    and shifting this epoch over the data set, by EpochShift samples, until the
    end of the data set is reached. (Stop just before that point. so that all epochs fall
    within the data set).

    Note: trial boundaries are ignored.
 */
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SetEpochsShift() : Data==NULL\n");
        return U_ERROR;
    }
    UEpochs* NewEpochs = new UEpochs(EpochLen, EpochShift, Data->GetNsampTrial(), Data->GetNtrial());

    if(NewEpochs && NewEpochs->GetError()==U_OK)
    {
        NPreTriggerSamples = 0;
        ReSetPreProcessingEpochs();
        delete Epochs; Epochs = NewEpochs;
        return Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    }
    delete NewEpochs;
    CI.AddToLog("ERROR: UMEEGDataEpochs::SetEpochs(). Creating new epochs. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SetEpochsEqTime(double TimeSpan)
/*
   TimeSpan in seconds
   The complete data set is partitioned in epochs of length timespan
*/
{
    int NSamTimeSpan = int(TimeSpan / SampleTime_s );
    return SetEpochs(0, NSamTimeSpan, 0, NSamTimeSpan-1);
}

ErrorType UMEEGDataEpochs::ForceEpochsInDataSet(void)
/*
     Exclude all epochs that have at least one data sample outside the data set range.
     Reading such dat would normally end up in epochs filled with zeroes.

     if(endtrial<0) ignore endtrial
 */
{
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ForceEpochsInDataSet() : Epochs or data not set.\n");
        return U_ERROR;
    }

    if(Epochs->ForceEpochsInDataSet(Data->GetNtrial())==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ForceEpochsInDataSet() : Forcing epochs in data set.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ForceEqualSize(int NsampEp, bool NsampAverage, bool ForcePower2)
/*
    Adapt the positions of the begin and end markers of Epochs[] such that
    all eposchs have the same number of samples.
    if(NsampAverage==true)
    {
        new number of samples per epoch is the average number of samples of the existing epochs.
    }
    else
    {
        new number of samples per epoch is NsampEp
    }
    If(ForcePower2==true)
        new number of samples is power of 2, nearest to NsampEp/(the average number of samples per epoch).
*/
{
    if(Data==NULL || Epochs==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ForceEqualSize() : Data==NULL or Epochs==NULL\n");
        return U_ERROR; //Epochs not set yet
    }

    ErrorType   E = Epochs->ForceEqualSize(NsampEp, NsampAverage, ForcePower2);
    if(E==U_OK) E = Epochs->ForceEpochsInDataSet(Data->GetNtrial());
    if(E==U_OK) ReSetPreProcessingEpochs();

    if(E==U_OK) return U_OK;
    CI.AddToLog("ERROR: UMEEGDataEpochs::ForceEqualSize(). Forcing equal epoch size. \n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SubsampleEpochs(int Ntake, int Nphase)
/*
    Exclusively take every Ntake-epochs, starting with Nphase
 */
{
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::SubsampleEpochs() : Epochs or data not set.\n");
        return U_ERROR;
    }

    if(Epochs->Subsample(Ntake, Nphase)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::SubsampleEpochs() : Subsampling the epochs.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeOverlapping(void)
/*
   This function excludes epochs that overlap one another. Herewith, first the epoch
   with the maximum number of overlapping neighbour epochs is removed first. Then
   of the remaing epochs this procedure is repeated until no (overlapping) eochs
   are left.
 */
{
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeOverlapping() : Epochs==NULL\n");
        return U_ERROR; //Epochs not set yet
    }

    if(Epochs->ExcludeOverlapping()==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR: UMEEGDataEpochs::ExcludeOverlapping(). Excluding overlapping epochs.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeTrialClass(const char* TrialClassName)
{
    if(Data==NULL || Epochs==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeTrialClass() : Data==NULL or Epochs==NULL\n");
        return U_ERROR;
    }
    if(Data->GetDataFormatType()!=U_DATFORM_CTF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ExcludeTrialClass(). Function only works for CTF data. (current data format = %s ).\n", Data->GetDataFormatTypeText(Data->GetDataFormatType()));
        return U_ERROR;
    }

    const UMarkerArray* MarTrial = Data->GetTrialClassArray();
    if(MarTrial==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeTrialClass() : No Trial class information present in data.\n");
        return U_ERROR;
    }
    if(Epochs->ExcludeEpochs(0, Data->GetNsampTrial()-1, MarTrial, TrialClassName)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeTrialClass() : Excluding epochs.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::IncludeTrialClass(const char* TrialClassName)
{
    if(Data==NULL || Epochs==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::IncludeTrialClass() : Data==NULL or Epochs==NULL\n");
        return U_ERROR;
    }
    if(Data->GetDataFormatType()!=U_DATFORM_CTF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::IncludeTrialClass(). Function only works for CTF data. (current data format = %s ).\n", Data->GetDataFormatTypeText(Data->GetDataFormatType()));
        return U_ERROR;
    }
    if(TrialClassName==NULL) CI.AddToLog("ERROR UMEEGDataEpochs::IncludeTrialClass(): NULL argument.\n");
    CI.AddToLog("ERROR UMEEGDataEpochs::IncludeTrialClass() : Function not yet implemented.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeTrials(int starttrial, int endtrial)
/*
     Exclude all epochs that have at least one data sample outside trial
     starttrial to entrial.

     if(endtrial<0) ignore endtrial
 */
{
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeTrials() : Epochs or data not set.\n");
        return U_ERROR;
    }

    if(Epochs->ExcludeTrials(starttrial, endtrial)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeTrials() : Excluding trials.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeEpochs(int startepoch, int endepoch)
{
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeEpochs() : Epochs or data not set.\n");
        return U_ERROR;
    }

    if(Epochs->ExcludeEpochs(startepoch, endepoch)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeEpochs() : Excluding epochs.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeEpochs(int halfwidth, const char* markername)
/*
     Create a new series of epochs, all epochs are excluded that have at least one point in
     common with the series of epochs defined by a halfwidth halfwidth around markername[].

     Note: The result of this function the 'surviving' epochs remain unaffected.
 */
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK ||
       Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ExcludeEpochs(). Data or epochs not properly set. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray()==NULL)
    {
        CI.AddToLog("WARNING: UMEEGDataEpochs::ExcludeEpochs(). MarkerArray not set. \n");
        return U_OK;
    }

    if(Epochs->ExcludeEpochs(-halfwidth, halfwidth, Data->GetMarkerArray(), markername)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeEpochs() : Excluding epochs.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::ExcludeSamples(int halfwidth, const char* markername)
/*
     Create a new series of epochs, in such a way that all samples within a sample
     distance from halfwitdth from markers with the name markername[] are skipped.

     Note: The result of this function is that either epochs disappear completely, are split
           in two parts or loose samples and the begin or end.
 */
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK ||
       Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ExcludeSamples(). Data or epochs not properly set. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray()==NULL)
    {
        CI.AddToLog("WARNING: UMEEGDataEpochs::ExcludeSamples(). MarkerArray not set. \n");
        return U_OK;
    }

    if(Epochs->ExcludeSamples(-halfwidth, halfwidth, Data->GetMarkerArray(), markername)==U_OK)
    {
        ReSetPreProcessingEpochs();
        return U_OK;
    }
    CI.AddToLog("ERROR UMEEGDataEpochs::ExcludeSamples() : Excluding samples.\n");
    return U_ERROR;
}

ErrorType UMEEGDataEpochs::SortEpochs(void)
/*
    Reorder the selected epochs, according the the first sample of each epoch.
 */
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SortEpochs(). Epochs not (properly) set. \n");
        return U_ERROR;
    }
    ReSetPreProcessingEpochs();

    return Epochs->SortEpochs();
}

ErrorType UMEEGDataEpochs::SetHilbertTransform(bool Set)
{
    ComputeHilbertXfm = Set;
    return U_OK;
}
ErrorType UMEEGDataEpochs::SetInterpolateCTF(bool Set)
{
    InterpolateCTF    = Set;
    return U_OK;
}

int UMEEGDataEpochs::GetNSampEpoch(int Ep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetNSampEpoch() : Object NULL or erroneous.\n");
        return 0;
    }
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetNSampEpoch() : Epochs==NULL.\n");
        return 0;
    }
    if(Ep<0 || Ep>= Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNSampEpoch(). Ep out of boundary.\n");
        return 0;
    }
    return Epochs->GetNsamp(Ep);
}

int UMEEGDataEpochs::GetNEpoch(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetNEpoch() : Object NULL or erroneous.\n");
        return 0;
    }
    if(Epochs==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNEpoch(). Epochs==NULL\n");
        return 0;
    }
    return Epochs->GetnEpochs();
}

UString* UMEEGDataEpochs::GetUsedMarkerNames(int* nMarkers) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetUsedMarkerNames(). this==NULL or erroneous. \n");
        return NULL;
    }
    const  UMarkerArray* Mar = GetMarkerArray();
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        if(nMarkers) *nMarkers = 0;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetUsedMarkerNames(). Markers not (properly) set. \n");
        return NULL;
    }
    int      nMar  = Mar->GetnMarkers();
    if(nMar<=0)
    {
        if(nMarkers) *nMarkers = 0;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetUsedMarkerNames(). Number of markers invalid (%d). \n", nMar);
        return NULL;
    }

    UString* Names = new UString[nMar];
    if(Names==NULL)
    {
        delete[] Names;
        if(nMarkers) *nMarkers = 0;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetUsedMarkerNames(). Memory allocation. \n");
        return NULL;
    }

    int NUsed = 0;
    for(int q=0; q<nMar; q++)
    {
        const char* MNam = Mar->GetMarker(q)->GetMarkerName();
        if(MNam==NULL) continue;

        for(int k=0;k<Epochs->GetnEpochs();k++)
            if(Epochs->IsMarkerIsInDescriptor(k,MNam))
            {
                Names[NUsed++]  = UString(MNam);
                break;
            }
    }
    if(nMarkers) *nMarkers = NUsed;
    if(NUsed<=0)
    {
        delete[] Names;
        Names = NULL;
    }
    return Names;
}

UEvent UMEEGDataEpochs::GetEvent(int Iep, int sample) const
/*
    Return the event, corresponding to sample sample of epoch Iep.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEvent(). this==NULL or erroneous. \n");
        return UEvent(0,0);
    }
    return Epochs->GetEvent(Iep, sample);
}

int UMEEGDataEpochs::GetNPreTriggerSamples(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetNPreTriggerSamples(). this==NULL or erroneous. \n");
        return 0;
    }
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetNPreTriggerSamples(). Epochs==NULL or Data==NULL. \n");
        return 0;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("WARNING: UMEEGDataEpochs::GetNPreTriggerSamples(). Epochs are of different duration. \n");
        return 0;
    }
    return NPreTriggerSamples;
}

double UMEEGDataEpochs::GetPreTriggerTime_s(void) const
{
    return GetNPreTriggerSamples()*SampleTime_s;
}
UDateTime UMEEGDataEpochs::GetDateTime(UEvent E, double* FracSec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetDateTime(). this==NULL or erroneous. \n");
        return 0;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetDateTime(). Data==NULL or erroneous. \n");
        return 0;
    }
    if(E.sample<0 || E.sample>=Data->GetNsampTrial() || E.trial<0)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetDateTime(). Invalid Event (%d,%d). \n", E.trial, E.sample);
        return 0;
    }
    double    Shift = E.GetAbsSample(Data->GetNsampTrial()) * SampleTime_s;
    UDateTime DT    = Data->GetDateTime();
    double    Frac  = 0.;
    DT.ShiftSeconds(Shift, &Frac);
    if(FracSec) *FracSec = Frac;
    return DT;
}

ErrorType UMEEGDataEpochs::GetNEpochsPerMarkers(const UString* MarkerNames, int nNames, int* nEpochsPerMarker) const
/*
    On return *nEpochsPerMarker contains the number of epochs for all names in
    MarkerNames. If a marker of MarkerNames[i] is not selected in this object,
    the corresponding nEpochsPerMarker[i] is zero.
*/
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNEpochsPerMarkers(). Epochs not (properly) set.\n");
        return U_ERROR;
    }
    if(MarkerNames==NULL || nEpochsPerMarker==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNEpochsPerMarkers(). Invalid NULL pointer(s) in argument. \n");
        return U_ERROR;
    }
    for(int i=0;i<nNames;i++)
        nEpochsPerMarker[i]= Epochs->GetNMarkerIsInDescriptor((const char*)(MarkerNames[i]));
    return U_OK;
}

ErrorType UMEEGDataEpochs::CopyFilter(const UMEEGDataEpochs* Epo)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopyFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopyFilter(). Invalid NULL address argument. \n");
        return U_ERROR;
    }

    if(Epo->GetData()) Data->SetCommonRef(Epo->GetData()->GetCommonReferenceLabel());
    MEGReref           = Epo->MEGReref;
    EEGReref           = Epo->EEGReref;
    CorrectSEFartifact = Epo->CorrectSEFartifact;
    ComputeHilbertXfm  = Epo->ComputeHilbertXfm;
    InterpolateCTF     = Epo->InterpolateCTF;

    DoNotExtraSamples  = Epo->DoNotExtraSamples;
    Filt               = Epo->Filt;
    if(Epo->EpochsPre==NULL)
    {
        delete EpochsPre; EpochsPre = NULL;
    }
    else
    {
        delete EpochsPre; EpochsPre = new UEpochs(* (Epo->EpochsPre) );
        if(EpochsPre==NULL || EpochsPre->GetError()!=U_OK)
        {
            delete EpochsPre; EpochsPre = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::CopyFilter(). Copying pre-processing epochs. \n");
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UMEEGDataEpochs::SetFilter(const ULinearFilter& LinFilter, bool NoExtraSamp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(&LinFilter==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetFilter(). Invalid NULL address argument. \n");
        return U_ERROR;
    }
    DoNotExtraSamples = NoExtraSamp;
    Filt              = LinFilter;

    return U_OK;
}

ErrorType  UMEEGDataEpochs::SetFilter(UPreProType Prep, UPowerLineType PowerLine, double PLWidth, bool NoExtraSamp, double WindowSize_s)
{
    DoNotExtraSamples = NoExtraSamp;
    Filt              = ULinearFilter(Data->GetSampleRate());
    if(Epochs && Epochs->GetnEpochs()>10) Filt.SetManyFFT(true);
    else                                  Filt.SetManyFFT(false);

    return Filt.SetFilter(Prep, PowerLine, PLWidth, WindowSize_s);
}

ErrorType  UMEEGDataEpochs::SetFilter(double Fmin, double Fmax, UPreProType Prep, UPowerLineType PowerLine, double PLWidth, bool NoExtraSamp, double WindowSize_s)
/*
     Set the filter parameters.
     Fmin, Fmax : frequency range of the band-pass filter
     Tm         : the minimum time segment on which the the filter is applied [ms].
                  If an epoch is wider, a broader time window is read for filtering,
                  and then the begin and end samples of that window is disregarded.
 */
{
    if(error!=U_OK) return U_ERROR;
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetFilter(). Data not properly set.\n");
        return U_ERROR;
    }
    DoNotExtraSamples = NoExtraSamp;
    Filt              = ULinearFilter(Data->GetSampleRate());
    if(Epochs && Epochs->GetnEpochs()>10) Filt.SetManyFFT(true);
    else                                  Filt.SetManyFFT(false);

    return Filt.SetFilter(Fmin, Fmax, Prep, PowerLine, PLWidth, WindowSize_s);
}

ErrorType  UMEEGDataEpochs::SetFilter(int Ncomp, UPreProType Prep, UPowerLineType PowerLine, double PLWidth, double WindowSize_s)
/*
     Set the filter parameters for the SVD-type filter
     Ncomp: The number of components that is transferred.
 */
{
    if(error!=U_OK) return U_ERROR;
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetFilter(). Data not properly set.\n");
        return U_ERROR;
    }

    Filt = ULinearFilter(Data->GetSampleRate());
    if(Epochs && Epochs->GetnEpochs()>10) Filt.SetManyFFT(true);
    else                                  Filt.SetManyFFT(false);

    return Filt.SetFilter(Ncomp, Prep, PowerLine, PLWidth, WindowSize_s);
}

ErrorType UMEEGDataEpochs::AddStopBand(double fmin, double fmax)
{
    if(this==NULL ||error!=U_OK) return U_ERROR;
    return Filt.AddStopBand(fmin, fmax);
}

ErrorType UMEEGDataEpochs::SetOutlierCorrection(DataType Dtype, bool Set, double Normal, double Outlier)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Dtype==U_DAT_NTYPE)        return U_ERROR;
    if(Set)
    {
        if(Normal<0 || Outlier<Normal)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::SetOutlierCorrection(). Parameter(s) out of ramge: Normal = %f, Outlier=%f  \n", Normal, Outlier);
            return U_ERROR;
        }
    }
    OutPar[Dtype].Apply = Set;
    if(Set)
    {
        OutPar[Dtype].Normal  = Normal;
        OutPar[Dtype].Outlier = Outlier;
    }
    return U_OK;
}
int UMEEGDataEpochs::GetSEFCorrectionWinSampFrom(bool Default) const
{
    if(this==NULL || error!=U_OK) return -1;

    int  joffb  = (SEFMarker.GetnSamples()>0) ? 0 : NPreTriggerSamples; // Assume SEF artifacts are at fixed offsets from raw trials
    
    if(Default || SEFWinFrom>=SEFWinTo || CorrectSEFartifact==false) joffb += int(floor(TartBegin/SampleTime_s+.5 ));
    else                                                             joffb += SEFWinFrom;

    return joffb;
}
int UMEEGDataEpochs::GetSEFCorrectionWinSampTo(bool Default) const
{
    if(this==NULL || error!=U_OK) return -1;

    int  joffe     = GetSEFCorrectionWinSampFrom(Default);
    if(Default || SEFWinFrom>=SEFWinTo || CorrectSEFartifact==false) joffe += int(floor( TartWidth/SampleTime_s+.5 + 1 ));
    else                                                             joffe += SEFWinTo-SEFWinFrom;

    return joffe;
}
ErrorType UMEEGDataEpochs::SetSEFCorrection(bool RemoveSEFartifact, const UMarker* Mark, int smpFrom, int smpTo)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    
    CorrectSEFartifact = RemoveSEFartifact;
    if(CorrectSEFartifact && Mark)
    {
        SEFMarker = UMarker(*Mark);
        const UMarkerArray* Mar = GetMarkerArray();
        if(SEFMarker.GetnSampTrial() != Mar->GetnSampTrial())
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::SetSEFCorrection(). Incompatible number of samples per trial (%s). \n", Mark->GetMarkerName());
            SEFMarker = UMarker();
        }
        bool Found = false;
        for(int im=0; im<Mar->GetnMarkers(); im++)
        {
            if(IsStringCompatible(SEFMarker.GetMarkerName(), Mar->GetMarkerName(im), false) ==false) continue;
            if(SEFMarker.GetnEvents() != Mar->GetMarker(im)->GetnEvents()) continue;
            Found = true;
            break;
        }
        if(Found==false)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::SetSEFCorrection(). SEF Marker not found: %s. Use trial onsets. \n", Mark->GetMarkerName());
            SEFMarker = UMarker();
        }
        if(smpFrom>=smpTo)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::SetSEFCorrection(). Artefact window out of range (smpFrom, smpTo) = (%d,%d). Use defaults.\n", smpFrom, smpTo);
        }
        SEFWinFrom = smpFrom;
        SEFWinTo   = smpTo;
    }
    else
    {
        SEFWinFrom = GetSEFCorrectionWinSampFrom(true);
        SEFWinTo   = GetSEFCorrectionWinSampTo  (true);
        SEFMarker  = UMarker();
    }
    if(SEFMarker.GetnSamples()>0) SEFMarker.SortEvents();
    return U_OK;
}

ErrorType UMEEGDataEpochs::WriteSensorPositionsCTF(void) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteSensorPositionsCTF(). Data not (properly) set. \n");
        return U_ERROR;
    }
    DataFormatType DFT = Data->GetDataFormatType();
    if(DFT!=U_DATFORM_CTF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteSensorPositionsCTF(). Data is not in CTF format (%s). \n",UMEEGDataBase:: GetDataFormatTypeText(DFT));
        return U_ERROR;
    }
    return ((UMEEGDataCTF*)Data)->SaveSensorPositions();
}
ErrorType UMEEGDataEpochs::WriteSensorPositionsXYZ(UFileName FileXYZ) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteSensorPositionsXYZ(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->WriteSensorPositionsXYZ(FileXYZ);
}
ErrorType UMEEGDataEpochs::WriteChannelConfigTXT(UFileName FileConf) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteChannelConfigTXT(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->WriteChannelConfigTXT(FileConf);
}

ErrorType UMEEGDataEpochs::ConvertDataType(DataType DTOLD, DataType DTNEW)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertDataType(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertDataType(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->ConvertDataType(DTOLD, DTNEW);
}

ErrorType UMEEGDataEpochs::CopyChannelSelection(const UMEEGDataEpochs* Epo)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopyChannelSelection(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopyChannelSelection(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(Epo==NULL || Epo->GetError()!=U_OK || Epo->GetData()==NULL || Epo->GetData()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopyChannelSelection(). Argument NULL, erroneous or data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->CopyChannelSelection(Epo->GetData());
}

ErrorType UMEEGDataEpochs::SelectChannels(const char * const*GoodChan, const char * const*BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(GoodChan, BadChan);
}

ErrorType UMEEGDataEpochs::SelectChannels(const char *GoodChan, const char* BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(GoodChan, BadChan);
}

ErrorType UMEEGDataEpochs::SelectChannels(const ChanInfo* NewChIn)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(NewChIn);
}

ErrorType UMEEGDataEpochs::SelectChannels(DataType DT0, DataType DT1, DataType DT2, DataType DT3)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(DT0, DT1, DT2, DT3);
}
ErrorType UMEEGDataEpochs::SelectChannels(DataType DT0, const char* GoodChan, const char* BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(DT0, GoodChan, BadChan);
}
ErrorType UMEEGDataEpochs::SelectChannels(const UGrid* GridLabels)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SelectChannels(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SelectChannels(GridLabels);
}

ErrorType UMEEGDataEpochs::RemoveChannelsFromSkipFile(const char* SkipDir)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveChannelsFromSkipFile(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveChannelsFromSkipFile(). Data or Epochs not properly set. \n");
        return U_ERROR;
    }
    const char* SkipLabels = ReadSkipChannelLabels(SkipDir);
    if(SkipLabels==NULL) return U_OK;

    ErrorType E = Data->SelectChannels(NULL, SkipLabels);
    delete[] SkipLabels;
    return E;
}
ErrorType UMEEGDataEpochs::RemoveChannels(const char * const*BadChan)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveChannels(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveChannels(). Data or Epochs not properly set. \n");
        return U_ERROR;
    }
    return Data->RemoveChannels(BadChan);
}
static double* StaticDoubles = NULL;
static int SortDouble(const void *elem1, const void *elem2)
{
    double d1 = StaticDoubles[ *(int*)elem1 ];
    double d2 = StaticDoubles[ *(int*)elem2 ];

    if(d1>d2) return  1;
    if(d1<d2) return -1;
    return 0;
}
ErrorType UMEEGDataEpochs::RemoveBadChannels(DataType DT, double MedianFactor, UString* BADChannels, UField* ChanEpOverView)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). Data or Epochs not properly set. \n");
        return U_ERROR;
    }
    int nKan = Data->GetNkan(DT);
    if(nKan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). No channels of type %d. \n", DT);
        return U_ERROR;
    }
    int nEp = Epochs->GetnEpochs();
    if(nEp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). No epochs selected %d. \n", nEp);
        return U_ERROR;
    }
    if(MedianFactor<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). Invalid parameter: MedianFactor = %f  .\n", MedianFactor);
        return U_ERROR;
    }

    UField*   FOverw  = NULL;
    if(ChanEpOverView)
    {
        if(ChanEpOverView->GetError() !=U_OK ||
           ChanEpOverView->Getndim()  !=2    ||
           ChanEpOverView->GetDdata() ==NULL ||
           ChanEpOverView->GetVeclen()!=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). Invalid Channel/Epoch overview: %s \n",(const char*)ChanEpOverView->GetProperties(""));
            return U_ERROR;
        }
        FOverw = ChanEpOverView;
    }
    else
    {
        double RMSMax  = 0.;
        FOverw  = GetRMSOverview(DT, &RMSMax);
    }
    if(FOverw==NULL || FOverw->GetError()!=U_OK)
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). Getting RMS overview. \n");
        return U_ERROR;
    }
    if(nEp!=FOverw->GetDimensions(0) || nKan!=FOverw->GetDimensions(1) )
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). nEpochs/nKan (%d / %d) not consistent with UField object. \n", nEp, nKan);
        return U_ERROR;
    }

    StaticDoubles     = new double[nKan];
    int*      Index   = new int[nKan];
    ChanInfo* NewChIn = Data->GetChanInfo();
    if(StaticDoubles==NULL || Index==NULL || NewChIn==NULL)
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        delete[] StaticDoubles; StaticDoubles = NULL;
        delete[] Index;
        delete[] NewChIn;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadChannels(). Getting RMS overview. \n");
        return U_ERROR;
    }
    for(int i=0; i<nKan; i++)
    {
        StaticDoubles[i]  = 0;
        Index[i]          = i;
        for(int k=0; k<nEp; k++) StaticDoubles[i] += FOverw->GetDdata()[i*nEp+k];
    }
    if(ChanEpOverView==NULL) delete   FOverw;

    qsort(Index, nKan, sizeof(Index[0]), SortDouble);
    double Threshold = MedianFactor*StaticDoubles[Index[nKan/2]];
    delete[] Index;

    if(BADChannels) *BADChannels = UString(" ");
    for(int i=0,id=0,Nrem=0; i<UMEEGDataBase::MAXCHAN; i++)
    {
        if(NewChIn[i].type       !=DT       ) continue;
        if(NewChIn[i].SkipChannel==true     ) continue;
        if(StaticDoubles[id++]   <=Threshold) continue;

        NewChIn[i].SkipChannel = true;
        if(BADChannels   ) *BADChannels += UString(NewChIn[i].namChannel, "%s,");
        if(ChanEpOverView) ChanEpOverView->RemoveLine(1, id-Nrem);
        Nrem++;
        CI.AddToLog("Note UMEEGDataEpochs::RemoveBadChannels(). Remove: %s \n",NewChIn[i].namChannel);
    }
    delete[] StaticDoubles; StaticDoubles = NULL;

    ErrorType E = Data->SelectChannels(NewChIn);
    delete[] NewChIn;

    return E;
}
ErrorType UMEEGDataEpochs::RemoveBadEpochs(DataType DT, double MedianFactor, UString* BADEpochs, UField* ChanEpOverView)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). Data or Epochs not properly set. \n");
        return U_ERROR;
    }
    int nKan = Data->GetNkan(DT);
    if(nKan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). No channels of type %d. \n", DT);
        return U_ERROR;
    }
    int nEp = Epochs->GetnEpochs();
    if(nEp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). No epochs selected %d. \n", nEp);
        return U_ERROR;
    }
    if(MedianFactor<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). Invalid parameter: MedianFactor = %f  .\n", MedianFactor);
        return U_ERROR;
    }
    UField*   FOverw  = NULL;
    if(ChanEpOverView)
    {
        if(ChanEpOverView->GetError() !=U_OK ||
           ChanEpOverView->Getndim()  !=2    ||
           ChanEpOverView->GetDdata() ==NULL ||
           ChanEpOverView->GetVeclen()!=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). Invalid Channel/Epoch overview: %s \n",(const char*)ChanEpOverView->GetProperties(""));
            return U_ERROR;
        }
        FOverw = ChanEpOverView;
    }
    else
    {
        double RMSMax  = 0.;
        FOverw  = GetRMSOverview(DT, &RMSMax);
    }
    if(FOverw==NULL || FOverw->GetError()!=U_OK)
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). Getting RMS overview. \n");
        return U_ERROR;
    }
    if(nEp!=FOverw->GetDimensions(0) || nKan!=FOverw->GetDimensions(1) )
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). nEpochs/nKan (%d / %d) not consistent with UField object. \n", nEp, nKan);
        return U_ERROR;
    }

    StaticDoubles     = new double[nEp];
    int*      Index   = new int[nEp];
    if(StaticDoubles==NULL || Index==NULL)
    {
        if(ChanEpOverView==NULL) delete   FOverw;
        delete[] StaticDoubles; StaticDoubles = NULL;
        delete[] Index;
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveBadEpochs(). Getting RMS overview. \n");
        return U_ERROR;
    }
    for(int k=0; k<nEp; k++)
    {
        StaticDoubles[k]  = 0;
        Index[k]          = k;
        for(int i=0; i<nKan; i++) StaticDoubles[k] += FOverw->GetDdata()[i*nEp+k];
    }
    if(ChanEpOverView==NULL) delete   FOverw;

    qsort(Index, nEp, sizeof(Index[0]), SortDouble);
    double Threshold = MedianFactor*StaticDoubles[Index[nEp/2]];
    delete[] Index;

    if(BADEpochs) *BADEpochs = UString(" ");
    for(int k=0,Nrem=0; k<nEp; k++)
    {
        if(StaticDoubles[k]<=Threshold) continue;

        Epochs->RemoveEpoch(k-Nrem);
        if(EpochsPre     ) EpochsPre->RemoveEpoch(k-Nrem);
        if(ChanEpOverView) ChanEpOverView->RemoveLine(0, k-Nrem);

        Nrem++;
        if(BADEpochs) *BADEpochs += UString(k, "%d,");
        CI.AddToLog("Note UMEEGDataEpochs::RemoveBadEpochs(). Remove: epoch %d \n",k);
    }

    delete[] StaticDoubles; StaticDoubles = NULL;

    return U_OK;
}

ErrorType UMEEGDataEpochs::UpdateChannelColors(const ChanInfo* ChIn, const UGrid* GSel)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::UpdateChannelColors(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->UpdateChannelColors(ChIn, GSel);
}
ErrorType UMEEGDataEpochs::UpdateChannelGroups(const UGrid* GSel)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::UpdateChannelGroups(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->UpdateChannelGroups(GSel);
}

int* UMEEGDataEpochs::GetStimData(int Iepoch) const
{
    if(Data==NULL || Epochs==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetStimData(). Data or Epochs not set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetStimData(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    UEvent Begin = Epochs->GetBegin(Iepoch);
    UEvent End   = Epochs->GetEnd(Iepoch);

/* Get the expanded data set*/
    return Data->GetTriggerEpoch(Begin, End);
}

int* UMEEGDataEpochs::GetEpochsSuperThreshold(DataType Dtype, const char* ChanLab, double Thresh, int* NSuper)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetEpochsSuperThreshold(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetEpochsSuperThreshold(). Data or Epochs not properly set. \n");
        return NULL;
    }

    if(Data->GetGrid(Dtype)==0)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : Requested type not present in file as UGrid (Dtype=%s). \n", Data->GetDataTypeText(Dtype));
        return NULL;
    }
    int NEpo    = Epochs->GetnEpochs();
    if(NEpo<=0)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : No epochs set. \n");
        return NULL;
    }
    if(NSuper==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : Erroneous NULL argument. \n");
        return NULL;
    }
    UGrid Gsel(* Data->GetGrid(Dtype) );
    if(Gsel.GetError()!=U_OK || (ChanLab && Gsel.SelectSensors(ChanLab)!=U_OK))
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : Creating selection grid \n");
        return NULL;
    }

    int* EpoSup = new int[NEpo];
    if(EpoSup==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : Memory allocation (NEpo=%d). \n", NEpo);
        return NULL;
    }

    *NSuper= 0;
    for(int k=0; k<NEpo; k++)
    {
        UMultiChan* MC = GetFilteredMultiChan(k, Dtype, &Gsel);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR UMEEGDataEpochs::GetEpochsSuperThreshold() : Getting data from epock %d . \n", k);
            delete EpoSup;
            return NULL;
        }
        if(MC->IsAnySampleSuperThreshold(Thresh)==true)
        {
            EpoSup[*NSuper] = k;
            (*NSuper) += 1;
        }
        delete MC;
    }
    return EpoSup;
}

UField* UMEEGDataEpochs::GetRMSOverview(DataType Dtype, double* RMSMax)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRMSOverview(). Data or Epochs not properly set. \n");
        return NULL;
    }

    int nKAN = Data->GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::GetRMSOverview() : requested type not present in file (Dtype=%s, nKAN=%d). \n", Data->GetDataTypeText(Dtype), nKAN);
        return NULL;
    }
    int NEpo    = Epochs->GetnEpochs();
    int Dims[2] = {NEpo, nKAN};

    UVector2 DMin(0.     , Epochs->GetBeginSample(0     ) * SampleTime_s);
    UVector2 DMax(nKAN-1., Epochs->GetBeginSample(NEpo-1) * SampleTime_s);
    UField* OverView = new UField(DMin, DMax, Dims, UField::U_DOUBLE, 1);
    if(OverView==NULL || OverView->GetError()!=U_OK)
    {
        delete OverView;
        CI.AddToLog("ERROR UMEEGDataEpochs::GetRMSOverview() : Creation of output UField. \n");
        return NULL;
    }

    double MMax = 0.;
    for(int k=0; k<NEpo; k++)
    {
        UMultiChan* pMC = GetFilteredMultiChan(k, Dtype);
        if(pMC==NULL || pMC->GetError()!=U_OK)
        {
            delete pMC;
            delete OverView;
            CI.AddToLog("ERROR UMEEGDataEpochs::GetRMSOverview() : Getting filtered data of epoch: %d. \n", k);
            return NULL;
        }
        const double* MCData = pMC->GetData();
        for(int i=0; i<nKAN; i++)
        {
            int    Ntime = pMC->GetNtime();
            double RMS   = 0.;
            for(int j=0; j<Ntime; j++) RMS += MCData[i*Ntime+j]*MCData[i*Ntime+j];
            if(RMS>=0 && Ntime>0) RMS = sqrt( RMS/Ntime);
            OverView->GetDdata()[i*NEpo+k] = RMS;
            if(RMS>MMax) MMax = RMS;
        }
        delete pMC;
        
        UString Status = UString("RMS of ") + UString(UMEEGDataBase::GetDataTypeText(Dtype)) + UString(k, ". Processing. Epoch %d of") + UString(NEpo, " %d epochs completed.");
        ShowStatus((const char*)Status, k, NEpo);
    }
    OverView->AddFileComments(this->GetProperties("  "));
    if(RMSMax) *RMSMax = MMax;
    return OverView;
}

UField* UMEEGDataEpochs::GetSingleChannelAsField(const char* Label)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSingleChannelAsField(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSingleChannelAsField(). Epochs not constant in length. \n");
        return NULL;
    }
    if(Label==NULL || Label[0]==0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSingleChannelAsField(). NULL or empty label. \n");
        return NULL;
    }
    DataType DT = U_DAT_UNKNOWN;
    int isens   = Data->GetChanAndType(Label, &DT);
    if(isens<0 || DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSingleChannelAsField(). channel or data type not found: Label = %s   . \n", Label);
        return NULL;
    }

    int Ntime   = Epochs->GetNsamp(0);
    int NEpo    = Epochs->GetnEpochs();
    int Dims[2] = {Ntime, NEpo};

    double* Times   = new double[Ntime];
    double* EpTimes = new double[NEpo];
    if(Times==NULL||EpTimes==NULL)
    {
        delete[] Times;
        delete[] EpTimes;
        CI.AddToLog("ERROR UMEEGDataEpochs::GetSingleChannelAsField() : Memory allocation: (Ntime=%d, NEpo=%d). \n", Ntime, NEpo);
        return NULL;
    }
    for(int k=0; k<NEpo;  k++) EpTimes[k] = Epochs->GetBeginSample(k) * SampleTime_s;
    for(int j=0; j<Ntime; j++) Times[j]   = (j-Data->GetPreNTriggerPnts())*SampleTime_s;
    UField* FChan = new UField(Times, EpTimes, NULL, Dims, UField::U_DOUBLE, 1);
    delete[] Times;
    delete[] EpTimes;
    if(FChan==NULL || FChan->GetError()!=U_OK)
    {
        delete FChan;
        CI.AddToLog("ERROR UMEEGDataEpochs::GetSingleChannelAsField() : Creation of output UField. \n");
        return NULL;
    }

    for(int k=0; k<NEpo; k++)
    {
        UMultiChan* pMC = GetFilteredMultiChan(k, DT, isens);
        if(pMC==NULL || pMC->GetError()!=U_OK)
        {
            delete pMC;
            delete FChan;
            CI.AddToLog("ERROR UMEEGDataEpochs::GetSingleChannelAsField() : Getting filtered data of epoch: %d. \n", k);
            return NULL;
        }
        const double* MCData = pMC->GetData();
        for(int j=0; j<Ntime; j++) FChan->GetDdata()[k*Ntime+j] = MCData[j];
        delete pMC;

        UString Status = UString(k, "Procesed. Epoch %d of") + UString(NEpo, " %d epochs completed.");
        ShowStatus((const char*)Status, k, NEpo);
    }
    UString Lab(Label, "  Label = %s \n");
    FChan->AddFileComments((const char*)Lab, this->GetProperties("  "));
    return FChan;
}

UFieldGraph* UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(const UMarker* Mark, const char* Label) const
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Mark==NULL || Mark->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). NULL or erroneous marker. \n");
        return NULL;
    }
    if(Mark->GetnSampTrial()!=Data->GetNsampTrial())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Marker has invalid number of samples per trial (=%d). \n", Mark->GetnSampTrial());
        return NULL;
    }
    if(Mark->GetnEvents()<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Marker has no events (=%d). \n", Mark->GetnEvents());
        return NULL;
    }
    UMarker MarkOrder(*Mark);
    if(MarkOrder.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Ordering events of copied marker. \n");
        return NULL;
    }
    if(Label==NULL || Label[0]==0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). NULL or empty label. \n");
        return NULL;
    }
    DataType DT = U_DAT_UNKNOWN;
    int   isens = Data->GetChanAndType(Label, &DT);
    if(isens<0 || DT==U_DAT_UNKNOWN)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). channel or data type not found: Label = %s   . \n", Label);
        return NULL;
    }
    int     Nev    = Mark->GetnEvents();
    float*  Ftimes = new float[Nev];
    if(Ftimes==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Memory allocation, Nev=%d  . \n", Nev);
        return NULL;
    }
    for(int iev=0; iev<Nev; iev++)
        Ftimes[iev] = float( MarkOrder.GetAbsSample(iev) * Data->GetSampleTime_s() );
    UFieldGraph* FG = new UFieldGraph(Ftimes, Nev, UField::U_DOUBLE, 1);
    delete[] Ftimes;
    if(FG==NULL || FG->GetError()!=U_OK)
    {
        delete FG;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Creation of UField object. \n");
        return NULL;
    }
    FG ->SetLabel(UString("Sample_") + UString(Label) + UString("_") + UString(Mark->GetMarkerName()));
    FG ->SetDatTypeHor(U_GDAT_TIME_S);
    UString Comment = UString("MarkerName    =") + UString(Mark->GetMarkerName(), "%s \n") +
                      UString("Channel       =") + UString(Label, "%s \n");
    FG ->AddFileComments(Comment);

    int NST = Data->GetNsampTrial();
    int NEP = Epochs->GetnEpochs();
    for(int iep=0; iep<NEP; iep++)
    {
        UMultiChan* MCchan = NULL;
        for(int iev=0; iev<Nev; iev++)
        {
            UEvent E = MarkOrder.GetEvent(iev);
            if(Epochs->IsInEpoch(iep, E))
            {
                if(MCchan==NULL)
                {
                    MCchan = GetFilteredMultiChan(iep, DT, isens);
                    if(MCchan==NULL || MCchan->GetError()!=U_OK)
                    {
                        
                        CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). Getting channel data for epoch %d .\n", iep);
                        return NULL;
                    }
                }
                int isamp = E.GetAbsSample(NST) - Epochs->GetBegin(iep).GetAbsSample(NST);
                if(isamp<0 || isamp>=Epochs->GetNsamp(iep))
                {
                    delete FG; delete MCchan;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetChannelSamplesAsFieldGraph(). isamp (=%d) out of range in epoch %d .\n", isamp, iep);
                    return NULL;
                }
                FG->GetDdata()[iev] = MCchan->GetData()[isamp];
            }
        }
        delete MCchan;
    }
    return FG;
}

UMultiChan* UMEEGDataEpochs::GetRawMultiChan(UEvent Begin, UEvent End, DataType Dtype, int isens) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Data not properly set. \n");
        return NULL;
    }
    int NST   = Data->GetNsampTrial();
    int Ntime = End.GetAbsSample(NST) - Begin.GetAbsSample(NST) + 1;
    if(Ntime<0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Begin event after End: Ntime = %d. \n", Ntime);
        return NULL;
    }    
    if(isens>=Data->GetNkan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Required channel out of range: isens=%d Nkan=%d .\n",isens, Data->GetNkan(Dtype));
        return NULL;
    }

// Read data
    double*  data   = GetRawData(Begin, End, Dtype, isens, &Ntime);
    UGrid*   Grid   = NULL;
    if(Dtype==U_DAT_MEG || Dtype==U_DAT_MEGREF || Dtype==U_DAT_EEG || Dtype==U_DAT_ADC)
    {
        Grid = new UGrid(*Data->GetGrid(Dtype));
    }
    else
    {
        int Nkan = Data->GetNkan(Dtype);
        Grid     = new UGrid(Nkan);
        if(Grid && Grid->GetError()==U_OK)
        {
            for(int i=0; i<Nkan; i++)
            {
                USensor S = (Data->GetSensor(i, Dtype));
                Grid->SetSensor(&S, i);
            }
        }
    }

    UMultiChan* MC = NULL;
    if(isens<0) MC = new UMultiChan(data, Grid, Ntime, SampleTime_s);
    else
    {
        UGrid* G = new UGrid(Grid->GetSensorPointer(isens));
        if(G && G->GetError()==U_OK)
            MC = new UMultiChan(data, G, Ntime, SampleTime_s);
        delete G;
    }
    delete[] data;
    delete   Grid;
    if(data==NULL || MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Creating UMultiChan-object. \n");
        delete MC;
        return NULL;
    }
    return MC;
}
UMultiChan* UMEEGDataEpochs::GetRawMultiChan(int Iepoch, DataType Dtype, int isens) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }
    if(isens>Data->GetNkan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawMultiChan(). Required channel out of range: isens=%d Nkan=%d .\n",isens, Data->GetNkan(Dtype));
        return NULL;
    }
    UEvent   Begin  = Epochs->GetBegin(Iepoch);
    UEvent   End    = Epochs->GetEnd(Iepoch);

    return GetRawMultiChan(Begin, End, Dtype, isens);
}

UMultiChan* UMEEGDataEpochs::GetFilteredMultiChan(UEvent Beg, UEvent End, DataType Dtype, int isens) const
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }

    bool AllowOneSampleSkipped = true;
    if(Epochs->AreEpochsContiguous(Beg, End, AllowOneSampleSkipped)==false)
    {
        int NST = Data->GetNsampTrial();
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Epochs not contigeous from begin (%d) to end (%d) sample.\n", Beg.GetAbsSample(NST), End.GetAbsSample(NST));
        return NULL;
    }

    if(Beg.trial<0 || End.trial<0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Begin and/or End event have negative trial number. \n");
        return NULL;
    }
    int NST   = Data->GetNsampTrial();
    int Nsamp = GetNsamples(Beg, End, NST);
    if(Nsamp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Begin after End, or Begin and End coincide, Nsamp = %d. \n", Nsamp);
        return NULL;
    }
    UMultiChan* MC = new UMultiChan();
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Creating empty UMultiChan-object. \n");
        return NULL;
    }

    int Ns = 0;
    for(int iep=0; iep<Epochs->GetnEpochs(); iep++)
    {
        if(Ns==0 && Epochs->IsInEpoch(iep, Beg)==false) continue;

        UMultiChan* MCiep    = GetFilteredMultiChan(iep, Dtype, isens);
        if(MCiep==NULL || MCiep->GetError()!=U_OK)
        {
            delete MC; delete MCiep;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Getting data from epoch %d . \n", iep);
            return NULL;
        }

        if(Ns==0) // First data epoch
        {
            int NSampEpo = MCiep->GetNtime();
            int NSkip    = Beg.GetAbsSample(NST) - Epochs->GetBegin(iep).GetAbsSample(NST);
            if(MCiep->Cut(NSkip, NSampEpo-NSkip)!=U_OK)
            {
                delete MC; delete MCiep;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Cutting data from first epoch (%d) . \n", iep);
                return NULL;
            }
        }
        if(MC->Merge(*MCiep)!=U_OK)
        {
            delete MC; delete MCiep;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Merging data from epoch %d . \n", iep);
            return NULL;
        }
        delete MCiep;
        Ns = MC->GetNtime(); 
        
        if(Ns>=Nsamp)
        {
            if(MC->Cut(0, Nsamp)!=U_OK)
            {
                delete MC;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Cutting last samples. \n");
                return NULL;
            }
            return MC;
        }
    }
    if(Ns<=0)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Ns = %d samples at end of loop. \n", Ns);
        return NULL;
    }

    CI.AddToLog("WARNING: UMEEGDataEpochs::GetFilteredMultiChan(). End of data filled with zeroes. \n");
    int         NZero  = Nsamp-Ns;
    UMultiChan* MCzero = new UMultiChan(*MC, 0, NZero);
    if(MCzero==NULL || MCzero->GetError()!=U_OK || MCzero->SetData(0.)!=U_OK)
    {
        delete MC; delete MCzero;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Creating zero data object.\n");
        return NULL;
    }
    if(MC->Merge(*MCzero)!=U_OK)
    {
        delete MC; delete MCzero;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Merging zero data. \n");
        return NULL;
    }
    delete MCzero;
    return MC;
}

UMultiChan* UMEEGDataEpochs::GetFilteredMultiChan(int Iepoch, DataType Dtype, int isens) const
/*
    return a new pointer to a MultiChan-object, containing the  filtered data of
    epoch Iepoch.
    if(isens<0) return filtered data of all channels of Dtype
    else        return filtered data of channel isens, of type Dtype.
                       (The index isens is running for each data type separately)

    On error: return NULL;
 */
{
    if(this==NULL || error!=U_OK) 
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    if(isens>Data->GetNkan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Required channel out of range: isens=%d Nkan=%d .\n",isens, Data->GetNkan(Dtype));
        return NULL;
    }
    UEvent Beg = Epochs->GetBegin(Iepoch);
    UEvent End = Epochs->GetEnd  (Iepoch);
// The number of times present and the minimum number of time samples that are required
    int      NST      = Data->GetNsampTrial();
    int      NsampEpo = GetNsamples( Beg,  End, NST);
    UEvent   BegReq   = Beg;
    UEvent   EndReq   = End;
    int      NsampReq = GetNsampReq(&BegReq, &EndReq, NsampEpo);
    if(NsampReq<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Computing required number of samples: NsampReq = %d. \n", NsampReq);
        return NULL;
    }

// Get the expanded data set
    UMultiChan* MC = GetRawMultiChan(BegReq, EndReq, Dtype, isens);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Getting raw data.\n");
        return NULL;
    }
    if(ApplySEFCorrection(MC, BegReq, EndReq, Dtype)!=U_OK ||
       ApplyOutlierCorrection(MC, Dtype)!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). SEF Correction or outlier correction .\n");
        return NULL;
    }

// Get pre-processing epochs
    UMultiChan* MCpre = NULL;
    if(EpochsPre)
    {
        if(Epochs->GetnEpochs() != EpochsPre->GetnEpochs())
        {
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Number of epochs for analysis (%d) unequal to number of epochs for pre-processing (%d).\n",Epochs->GetnEpochs(),EpochsPre->GetnEpochs());
            return NULL;
        }

        UEvent BegPre   = EpochsPre->GetBegin(Iepoch);
        UEvent EndPre   = EpochsPre->GetEnd  (Iepoch);
        MCpre           = GetRawMultiChan(BegPre, EndPre, Dtype, isens);
        if(MCpre==NULL || MCpre->GetError()!=U_OK)
        {
            delete MC; delete MCpre;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Getting pre-processing epochs.\n");
            return NULL;
        }
        if(ApplySEFCorrection(MCpre, BegPre, EndPre, Dtype)!=U_OK ||
           ApplyOutlierCorrection(MCpre, Dtype)!=U_OK)
        {
            delete MC; delete MCpre;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). SEF Correction or outlier correction on pre-processing epochs.\n");
            return NULL;
        }
    }
    ULinearFilter FiltCopy = Filt;
    if(MC->ApplyLinearFilter(FiltCopy, MCpre)!=U_OK)
    {
        delete MC; delete MCpre;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Applying filter. \n");
        return NULL;
    }
    delete MCpre;        
    
    int NSkip = Beg.GetAbsSample(NST)-BegReq.GetAbsSample(NST);
    if(MC->Cut(NSkip, NsampEpo)!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Cutting required window. \n");
        return NULL;
    }    
    return InterpolateAndHilbert(MC, Dtype);
}
UMultiChan* UMEEGDataEpochs::GetFilteredMultiChan(int Iepoch, const char* Label) const
/*
    return a new pointer to a MultiChan-object, containing the  filtered data
    of epoch Iepoch, of the channel named Label[].

    On error: return NULL;
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Invalid NULL argument. \n");
        return NULL;
    }
    DataType Dtype = U_DAT_UNKNOWN;
    int      isens = Data->GetChanAndType(Label, &Dtype);

    if(isens<0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Label (%s) not in data file, or not selected. \n", Label);
        return NULL;
    }
    return GetFilteredMultiChan(Iepoch, Dtype, isens);
}

UMultiChan* UMEEGDataEpochs::GetFilteredMultiChan(int Iepoch, DataType Dtype, const UGrid* GridLabels) const
/*
    return a new pointer to a MultiChan-object containing a selection of channels
    of the  filtered data of epoch Iepoch.

    The selection consists of all channels of data type Dtype in the file,
    of which the labels are consistent with GridLabels. The channel selecion
    set by Data->SelectChannels() is ignored.

    On error: return NULL;
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    ChanInfo* ChInCopy = Data->GetChanInfo();
    if(ChInCopy==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Getting restore buffer with channel info. \n");
        return NULL;
    }

    if(Data->SelectChannels(Dtype)!=U_OK)
    {
        delete[] ChInCopy;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Selecting channels to type %d. \n", Dtype);
        return NULL;
    }
    UMultiChan* MChanSel = GetFilteredMultiChan(Iepoch, Dtype);

/* Restore selection */
    if(Data->SelectChannels(ChInCopy)!=U_OK)
    {
        delete[] ChInCopy;
        delete   MChanSel;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Restoring selection. \n");
        return NULL;
    }
    delete[] ChInCopy;
    if(MChanSel==NULL || MChanSel->GetError()!=U_OK)
    {
        delete   MChanSel;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Getting all filtered channels of type %d. \n", Dtype);
        return NULL;
    }
    if(MChanSel->SelectChannels(GridLabels)==U_OK) return MChanSel;

    CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Selecting Channels. \n");
    delete MChanSel;
    return NULL;
}

UMultiChan* UMEEGDataEpochs::GetFilteredMultiChan(UEvent E, const int* Offsets, int Noff, DataType Dtype) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Offsets==NULL || Noff<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Invalid arguments. \n");
        return NULL;
    }
    if(Data->GetNkan(Dtype)<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). No data of data type %d.\n", Dtype);
        return NULL;
    }

    UMultiChan* MC     = NULL;
    UMultiChan* MCiep  = NULL;
    int         NST    = Epochs->GetnSampTrial();
    int         oldiep = -1;
    for(int n=0; n<Noff; n++)
    {
        UEvent Eshift = E.GetShiftedEvent(Offsets[n], NST);
        int off = -1;
        int iep = Epochs->GetEpochIndex(Eshift, &off);
        if(iep<0 || off<0)
        {
            delete MC; delete MCiep;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Shifted event can not be found in existing epochs, Offset[%d]=%d.\n", n, Offsets[n]);
            return NULL;
        }
        if(iep!=oldiep)
        {
            delete MCiep; MCiep = GetFilteredMultiChan(iep, Dtype, -1);
            if(MCiep==NULL || MCiep->GetError()!=U_OK)
            {
                delete MC; delete MCiep;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Reading data from epoch %d .\n", iep);
                return NULL;
            }
            if(MC==NULL)
            {
                MC = new UMultiChan(MCiep->GetSensorGrid(), Noff, MCiep->GetSampTime());
                if(MC==NULL || MC->GetError()!=U_OK)
                {
                    delete MC; delete MCiep;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Creating output UMultiChan-object.\n");
                    return NULL;
                }
            }
            oldiep = iep;
        }

/* Copy selected data to output array */
        if(MC->CopyData(*MCiep, off, 1, n)!=U_OK)
        {
            delete MC; delete MCiep;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChan(). Copying data to destination object. \n");
            return NULL;
        }
    }
    delete MCiep;
    
    return InterpolateAndHilbert(MC, Dtype);
}

UMultiChan* UMEEGDataEpochs::InterpolateAndHilbert(UMultiChan* MC, DataType Dtype) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::InterpolateAndHilbert(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::InterpolateAndHilbert(). Invalid or erroneous NULL argument.\n");
        return NULL;
    }
    if(Dtype==U_DAT_MEG && InterpolateCTF==true)
    {
        const UInterpolateSensors* CTFI = Data->GetCTFInterpolation();
        if(CTFI==NULL || CTFI->GetError()!=U_OK)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::InterpolateAndHilbert(). CTF interpolation object not (properly set. Keep old sensors.\n");
        }
        else
        {
            UMultiChan* MCI = CTFI->GetInterpolatedMultiChan(MC);
            if(MCI==NULL || MCI->GetError()!=U_OK)
            {
                delete MCI;
                CI.AddToLog("WARNING: UMEEGDataEpochs::InterpolateAndHilbert(). Computing interpolation to CTF sensors. Keep old sensors.\n");
            }
            else
            {
                delete MC; MC = MCI;
            }
        }
    }

/* Compute Hilbert transform */
    if(ComputeHilbertXfm==true && MC->ApplyHilbertTransform()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::InterpolateAndHilbert(). Computing Hilbert transform.\n");
        delete MC;
        return NULL;
    }
    return MC;
}

UMultiChan** UMEEGDataEpochs::GetFilteredMultiChan(int Iepoch, const bool DataTypeArray[U_DAT_NTYPE]) const
/*
    return a new pointer to a new array of U_DAT_NTYPE new UMultiChan-objects, each
    containing the filtered data of epoch Iepoch, if the corresponding bool of
    DataTypeArray[] is tue, or NULL of that bool is false.

    On error: return NULL;
 */
{
    UMultiChan** EpArr = new UMultiChan*[U_DAT_NTYPE];

    if(EpArr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory allocation. U_DAT_NTYPE=%d .\n", U_DAT_NTYPE);
        return NULL;
    }
    for(int n=0; n<U_DAT_NTYPE; n++) EpArr[n] = NULL;

    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        if(DataTypeArray[n]==false) continue;

        DataType DT = UMEEGDataBase::GetDataType(n);
        EpArr[n]    = GetFilteredMultiChan(Iepoch, DT, -1);
        if(EpArr[n]==NULL || EpArr[n]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Getting data from epoch %d, type %s. \n", Iepoch, UMEEGDataBase::GetDataTypeText(DT));

            for(int nn=0; nn<=n; nn++) delete EpArr[nn];
            delete[] EpArr;
            return NULL;
        }
    }
    return EpArr;
}

UMultiChan* UMEEGDataEpochs::GetFilteredMultiChanAllTypes(int Iepoch, DataType DtypeSkip) const
/*
    Return the filtered data of all selected channels and all data types, merged
    into a single UMultiChan-object. Skip channels of type DtypeSkip
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanAllTypes(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanAllTypes(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    UMultiChan* MC = new UMultiChan();
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanAllTypes(). Creating empty UMultiChan. \n");
        return NULL;
    }
    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        DataType DT = UMEEGDataBase::GetDataType(n);
        if(DT==DtypeSkip || Data->GetNChan(DT)<=0) continue;

        UMultiChan* MCDT = GetFilteredMultiChan(Iepoch, DT, -1);

        if(MCDT==NULL || MCDT->GetError()!=U_OK || MC->MergeChannels(*MCDT)!=U_OK)
        {
            delete MC;
            delete MCDT;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanAllTypes(). Getting filtered data of type %s, or merging it to the rest. \n", UMEEGDataBase::GetDataTypeText(DT));
            return NULL;
        }
        delete MCDT;
    }
    if(MC->GetNChan()<=0)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanAllTypes(). No data selected. \n");
        return NULL;
    }
    return MC;
}

UMultiChan* UMEEGDataEpochs::GetAveragedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, UMatrixSymmetric** CovXX, UMatrixSymmetric** CovTT, int MaxIter)
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). NULL or erreouneous UMarker argument. \n");
        return NULL;
    }

    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). No data of type %d present. \n", Dtype);
        return NULL;
    }
    if(isens>=Nkan)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Sensor number (isens=%d) out of range. \n", isens);
        return NULL;
    }
    if(FractOutlier>=1)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Parameter out of range: FractOutlier = %f  .\n", FractOutlier);
        return NULL;
    }
    if(CovXX==NULL && CovTT==NULL) return GetAveragedFilteredMultiChan(M, NLeft, NRight, Dtype, isens, FractOutlier);
    if(CovXX!=NULL && CovTT!=NULL && MaxIter<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Maxiter (=%d) out of range.\n", MaxIter);
        return NULL;
    }

    int          Nep   = 0;
    UMultiChan** MCArr = GetAllFilteredMultiChans(M, NLeft, NRight, Dtype, isens, FractOutlier, &Nep);
    if(MCArr==NULL || Nep<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Getting array of UMultiChan objects (Nep=%d). \n", Nep);
        return NULL;
    }
    
/* Compute average UMultiChan and subtract from each epoch*/
    double Fact = 1./Nep;
    UMultiChan* MCAve = new UMultiChan();
    for(int iep=0; iep<Nep; iep++)
    {
        if(MCArr[iep]==NULL || MCArr[iep]->GetError()!=U_OK)
        {
            for(int kk=0; kk<Nep; kk++) delete MCArr[kk]; delete[] MCArr;
            delete MCAve;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). NULL or erroneous epoch data at iep = %d . \n", iep);
            return NULL;
        }
        *MCAve += *(MCArr[iep]);
    }
    *MCAve *= Fact;
    for(int iep=0; iep<Nep; iep++) *(MCArr[iep]) -= *MCAve;


    if(CovXX==NULL) // Only compute temporal covariance
    {
        *CovTT = new UMatrixSymmetric();
        for(int iep=0; iep<Nep; iep++) **CovTT += MCArr[iep]->GetMTM();
        **CovTT *= Fact;
    }
    else if(CovTT==NULL)
    {
        *CovXX = new UMatrixSymmetric();
        for(int iep=0; iep<Nep; iep++) **CovXX += MCArr[iep]->GetMMT();
        **CovXX *= Fact;
    }
    else
    {
        *CovXX = new UMatrixSymmetric(MCAve->GetNChan());
        *CovTT = new UMatrixSymmetric(MCAve->GetNtime());

        for(int iter=0; iter<=MaxIter; iter++)
        {
            UMatrixSymmetric XXi;
            UMatrixSymmetric TTi(UMatrix(MCAve->GetNcol()));

            for(int iep=0; iep<Nep; iep++) XXi += (*CovTT)->GetAMAT(*MCArr[iep], true);
            TTi = UMatrixSymmetric();
            for(int iep=0; iep<Nep; iep++) TTi += XXi.GetATMA(*MCArr[iep], true);

            TTi         /= TTi.GetFrobNorm();
            double Error = (*CovTT)->GetFrobNormDifference(TTi)/(*CovTT)->GetFrobNorm();

            UString SError(Error,"Error = %23.7f  ");
            UString Status = UString(iter, "Iter %d   ") + UString(MaxIter,"of maximum %d  . ") + SError;
            ShowStatus((const char*)Status, iter, MaxIter);

            **CovXX = XXi;
            **CovTT = TTi;

            if(Error< 1.e-8) break;
        }
    }
    for(int kk=0; kk<Nep; kk++) delete MCArr[kk]; delete[] MCArr;
    return MCAve;
}

UMultiChan* UMEEGDataEpochs::GetAveragedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier)  // virtual
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). NULL or erreouneous UMarker argument. \n");
        return NULL;
    }

    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). No data of type %d present. \n", Dtype);
        return NULL;
    }
    if(isens>=Nkan)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Sensor number (isens=%d) out of range. \n", isens);
        return NULL;
    }
    if(FractOutlier>=1)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Parameter out of range: FractOutlier = %f  .\n", FractOutlier);
        return NULL;
    }

    UMultiChan* MCSum = GetSummedFilteredMultiChan(M, NLeft, NRight, Dtype, isens, FractOutlier);
    if(MCSum==NULL || MCSum->GetError()!=U_OK)
    {
        delete MCSum;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Getting summed epochs. \n");
        return NULL;
    }
    int nEp = M   ->GetnEvents();
    if(nEp) *MCSum *= (1./nEp);
    return MCSum;
}
UMultiChan* UMEEGDataEpochs::GetSummedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, UMarker** pMgood)  // virtual
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }
    if(pMgood) *pMgood = NULL;

    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). NULL or erreouneous UMarker argument. \n");
        return NULL;
    }

    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). No data of type %d present. \n", Dtype);
        return NULL;
    }
    if(isens>=Nkan)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Sensor number (isens=%d) out of range. \n", isens);
        return NULL;
    }
    if(FractOutlier>=1)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Parameter out of range: FractOutlier = %f  .\n", FractOutlier);
        return NULL;
    }

    UMultiChan* MCSum = new UMultiChan();
    if(MCSum==NULL || MCSum->GetError()!=U_OK)
    {
        delete MCSum;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Initializing average. \n");
        return NULL;
    }
    int     NTR      = Data->GetNtrial();
    int     NST      = Data->GetNsampTrial();
    int     nEp      = M   ->GetnEvents();
    int     Nout     = int(0.5 + FractOutlier*nEp);
    double* MaxArray = NULL;
    if(FractOutlier>0)
    {
        MaxArray = new double[nEp];
        if(MaxArray==NULL || Nout>=nEp-1)
        {
            delete MCSum;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Memory allocation: nEp=%d or too many outliers, Nout=%d.\n", nEp, Nout);
            return NULL;
        }
        for(int iep=0; iep<nEp; iep++) MaxArray[iep] = 0.;
    }
    UEvent F  = Epochs->GetFirstBegin();
    UEvent L  = Epochs->GetLastEnd();
    for(int iep=0; iep<nEp; iep++)
    {
        UString Status = UString(iep, "Summing. Epoch %d of") + UString(nEp, " %d .");
        UEvent     B   = M->GetEvent(iep).GetShiftedEvent(-NLeft , NST);
        UEvent     E   = M->GetEvent(iep).GetShiftedEvent( NRight, NST);
        if(E.GetAbsSample(NST)< F.GetAbsSample(NST)) continue;
        if(B.GetAbsSample(NST)>=L.GetAbsSample(NST)) continue;
        UEvent BB = B;
        UEvent EE = E;
        if(B.GetAbsSample(NST)< F.GetAbsSample(NST)) BB = F;
        if(E.GetAbsSample(NST)>=L.GetAbsSample(NST)) EE = L;

        ShowStatus((const char*)Status, iep, nEp);
        UMultiChan*  MC  = GetFilteredMultiChan(BB, EE, Dtype, isens);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete   MC;
            delete   MCSum;
            delete[] MaxArray;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Summing data, getting data epoch, iep = %d . \n", iep);
            return NULL;
        }
        if(MaxArray) MaxArray[iep] = MC->GetMaxData(true);
        if(B.GetAbsSample(NST)< F.GetAbsSample(NST) || E.GetAbsSample(NST)>=L.GetAbsSample(NST))
        {
            UMultiChan* Temp  = MC;
            int         Nnull = NLeft+NRight+1 - (Temp->GetNtime());
            UMultiChan* Mnull = new UMultiChan(Temp->GetSensorGrid(), Nnull, Temp->GetSampTime());
            MC                = NULL;
            if(Mnull)
            {
                if(B.GetAbsSample(NST)< F.GetAbsSample(NST)) MC = Merge(*Mnull, *Temp);
                if(E.GetAbsSample(NST)>=L.GetAbsSample(NST)) MC = Merge(*Temp ,*Mnull);
            }
            delete Temp;
            delete Mnull;
            if(MC==NULL || MC->GetError()!=U_OK)
            {
                delete   MC;
                delete   MCSum;
                delete[] MaxArray;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Merging data with zeroes in first epoch. \n");
                return NULL;
            }
        }

        *MCSum += *MC;
        delete MC;
    }
    UMarker BadEvents(*M);
    BadEvents.DeleteEvents(0,-1);
    if(Nout>0)
    {
        bool Fabs      = true;
        bool HighFirst = true;
        int* Index     = GetOrderIndexArray(MaxArray, nEp, Fabs, HighFirst);
        if(Index==NULL)
        {
            delete   MCSum;
            delete[] MaxArray;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Getting index array.\n");
            return NULL;
        }        
        for(int k=0; k<Nout; k++)
        {
            int       iep  = Index[k];
            UString Status = UString(iep, "Removing. Epoch %d of") + UString(Nout, " %d (outlier).");
            UEvent     B   = M->GetEvent(iep).GetShiftedEvent(-NLeft , NST);
            UEvent     E   = M->GetEvent(iep).GetShiftedEvent( NRight, NST);

            if(E.GetAbsSample(NST)< F.GetAbsSample(NST)) continue;
            if(B.GetAbsSample(NST)>=L.GetAbsSample(NST)) continue;
            UEvent BB = B;
            UEvent EE = E;
            if(B.GetAbsSample(NST)< F.GetAbsSample(NST)) BB = F;
            if(E.GetAbsSample(NST)>=L.GetAbsSample(NST)) EE = L;

            ShowStatus((const char*)Status, iep, nEp);
            UMultiChan*  MC  = GetFilteredMultiChan(BB, EE, Dtype, isens);
            if(MC==NULL || MC->GetError()!=U_OK)
            {
                delete   MC;       delete   MCSum;
                delete[] MaxArray; delete[] Index;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Removing outliers, getting data epoch, iep = %d . \n", iep);
                return NULL;
            }
            if(B.GetAbsSample(NST)< F.GetAbsSample(NST) || E.GetAbsSample(NST)>=L.GetAbsSample(NST))
            {
                UMultiChan* Temp  = MC;
                int         Nnull = NLeft+NRight+1 - (Temp->GetNtime());
                UMultiChan* Mnull = new UMultiChan(Temp->GetSensorGrid(), Nnull, Temp->GetSampTime());
                MC                = NULL;
                if(Mnull)
                {
                    if(B.GetAbsSample(NST)< F.GetAbsSample(NST)) MC = Merge(*Mnull, *Temp);
                    if(E.GetAbsSample(NST)>=L.GetAbsSample(NST)) MC = Merge(*Temp ,*Mnull);
                }
                delete Temp;  delete Mnull;
                if(MC==NULL || MC->GetError()!=U_OK)
                {
                    delete   MC;       delete   MCSum;
                    delete[] MaxArray; delete[] Index;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Merging data with zeroes in first epoch. \n");
                    return NULL;
                }
            }
            *MCSum -= *MC;
            delete MC;

            if(pMgood) BadEvents.AddEvent( M->GetEvent(iep));
        }
        *MCSum *= (nEp/double(nEp-Nout));
        delete[] Index;
    }
    delete[] MaxArray;

    if(pMgood)
    {
        *pMgood = new UMarker(*M);
        if(*pMgood==NULL || (*pMgood)->GetError()!=U_OK)
        {
            delete *pMgood; *pMgood = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Creating UMarker with good events. \n");
            return NULL;
        }
        if( (*pMgood)->DeleteEvents(&BadEvents, 0)!=U_OK)
        {
            delete *pMgood; *pMgood = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSummedFilteredMultiChan(). Removing BAD events from output UMarker object. \n");
            return NULL;
        }
    }
    return MCSum;
}
UMultiChan* UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier)  // virtual
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). NULL or erreouneous UMarker argument. \n");
        return NULL;
    }

    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). No data of type %d present. \n", Dtype);
        return NULL;
    }
    if(isens>=Nkan)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Sensor number (isens=%d) out of range. \n", isens);
        return NULL;
    }
    if(FractOutlier>=1)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Parameter out of range: FractOutlier = %f  .\n", FractOutlier);
        return NULL;
    }

    UMarker*    Mgood = NULL;
    UMultiChan* MCSum = GetSummedFilteredMultiChan(M, NLeft, NRight, Dtype, isens, FractOutlier, &Mgood);
    if(MCSum==NULL || MCSum->GetError()!=U_OK || Mgood==NULL || Mgood->GetError()!=U_OK)
    {
        delete MCSum; delete Mgood;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Initializing average, or creating good UMarker object. \n");
        return NULL;
    }
    UMatrixSymmetric* pMS = Mgood->GetCrossingBlockMatrix(NLeft, NRight, Data->GetNtrial());
    if(pMS==NULL || pMS->GetError()!=U_OK)
    {
        delete MCSum;  delete pMS; delete Mgood;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Getting (sparse) overlap matrix. \n");
        return NULL;
    }
////
    double CondNumInv = pMS->GetEigen(pMS->GetNrow()-1)/pMS->GetEigen(0);
    CI.AddToLog("Note: CondNumInv = %20.10f  \n",CondNumInv);
////
    UMultiChan* MCOver = new UMultiChan(*MCSum);
    if(MCOver==NULL || MCOver->GetError()!=U_OK)
    {
        delete MCOver;
        delete MCSum;  delete pMS; delete Mgood;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOverlapCorrectedAveragedMultiChan(). Copying average or allocating buffer (Nsamp = %d). \n", MCSum->GetNcol());
        return NULL;
    }
    
    *MCOver = pMS->GetAxIsB(MCSum->GetTranspose()).GetTranspose();

    delete MCSum;  delete pMS; delete Mgood;
    return MCOver;
}
UMultiChan** UMEEGDataEpochs::GetAllFilteredMultiChans(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, int* Ntaken)
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). NULL or erreouneous UMarker argument. \n");
        return NULL;
    }

    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). No data of type %d present. \n", Dtype);
        return NULL;
    }
    if(isens>=Nkan)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Sensor number (isens=%d) out of range. \n", isens);
        return NULL;
    }
    if(FractOutlier>=1)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Parameter out of range: FractOutlier = %f  .\n", FractOutlier);
        return NULL;
    }
    if(Ntaken==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Invalid NULL pointer for Ntaken.\n");
        return NULL;
    }

    int     NTR      = Data->GetNtrial();
    int     NST      = Data->GetNsampTrial();
    int     nEp      = M   ->GetnEvents();
    int     Nout     = int(0.5 + FractOutlier*nEp);
    double* MaxArray = NULL;
    if(FractOutlier>0)
    {
        MaxArray = new double[nEp];
        if(MaxArray==NULL || Nout>=nEp-1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory allocation: nEp=%d or too many outliers, Nout=%d.\n", nEp, Nout);
            return NULL;
        }
        for(int iep=0; iep<nEp; iep++) MaxArray[iep] = 0.;
    }
    UMultiChan** MCArr = new UMultiChan*[nEp];
    if(MCArr==NULL)
    {
        delete[] MaxArray; delete[] MCArr;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory allocation for output array: nEp=%d .\n", nEp);
        return NULL;
    }
    for(int iep=0; iep<nEp; iep++) MCArr[iep] = NULL;

    UEvent F(0,0);
    UEvent L(NTR-1,NST-1);
    for(int iep=0; iep<nEp; iep++)
    {
        UString Status = UString(iep, "Getting. Epoch %d of") + UString(nEp, " %d .");
        UEvent     B   = M->GetEvent(iep).GetShiftedEvent(-NLeft , NST);
        UEvent     E   = M->GetEvent(iep).GetShiftedEvent( NRight, NST);
        if(E.trial< 0  ) continue;
        if(B.trial>=NTR) continue;
        UEvent BB = B;
        UEvent EE = E;
        if(B.trial< 0  ) BB = F;
        if(E.trial>=NTR) EE = L;

        ShowStatus((const char*)Status, iep, nEp);
        UMultiChan*  MC  = GetFilteredMultiChan(BB, EE, Dtype, isens);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            for(int kk=0; kk<nEp; kk++) delete MCArr[kk];
            delete[] MaxArray; delete[] MCArr;
            delete   MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Summing data, getting data epoch, iep = %d . \n", iep);
            return NULL;
        }
        if(MaxArray) MaxArray[iep] = MC->GetMaxData(true);
        if(B.trial<0 || E.trial>=NTR)
        {
            UMultiChan* Temp  = MC;
            int         Nnull = NLeft+NRight+1 - (Temp->GetNtime());
            UMultiChan* Mnull = new UMultiChan(Temp->GetSensorGrid(), Nnull, Temp->GetSampTime());
            MC                = NULL;
            if(Mnull)
            {
                if(B.trial<   0) MC = Merge(*Mnull, *Temp);
                if(E.trial>=NTR) MC = Merge(*Temp ,*Mnull);
            }
            delete Temp;
            delete Mnull;
            if(MC==NULL || MC->GetError()!=U_OK)
            {
                for(int kk=0; kk<nEp; kk++) delete MCArr[kk];
                delete[] MaxArray; delete[] MCArr;
                delete   MC;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Merging data with zeroes in first epoch. \n");
                return NULL;
            }
        }
        MCArr[iep] = MC;
    }
    if(Nout>0)
    {
        bool Fabs      = true;
        bool HighFirst = true;
        int* Index     = GetOrderIndexArray(MaxArray, nEp, Fabs, HighFirst);
        if(Index==NULL)
        {
            for(int kk=0; kk<nEp; kk++) delete MCArr[kk];
            delete[] MaxArray; delete[] MCArr;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Getting index array.\n");
            return NULL;
        }        
        for(int k=0; k<Nout; k++)
        {
            int       iep  = Index[k];
            delete MCArr[iep]; MCArr[iep] = NULL;
            UString Status = UString(iep, "Removing. Epoch %d of") + UString(Nout, " %d (outlier).");
        }
        delete[] Index;
    }
    delete[] MaxArray;

    *Ntaken             = nEp-Nout;
    UMultiChan** MCtemp = new UMultiChan*[*Ntaken];
    if(MCtemp==NULL)
        CI.AddToLog("WARNING: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory re-allocation for output array: *Ntaken=%d .\n", *Ntaken);

    for(int k  =0; k<*Ntaken; k++) MCtemp[k] = NULL;
    for(int iep=0, itak=0; iep<nEp; iep++)
    {
        if(MCArr[iep]==NULL) continue;
        if(MCtemp) MCtemp[itak] = MCArr[iep];
        else       MCArr [itak] = MCArr[iep];
        itak++;
    }
    if(MCtemp==NULL) return MCArr;
    delete[] MCArr;
    return MCtemp;
}

UMultiChan* UMEEGDataEpochs::GetAveragedFilteredMultiChan(DataType Dtype) // virtual
{
    if(this==NULL    || error!=U_OK ||
        Data==NULL   || Data->GetError()!=U_OK ||
        Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Object NULL, erreouneous, or data/epochs not well set. \n");
        return NULL;
    }

    UMultiChan* MCAv = new UMultiChan();
    if(MCAv==NULL || MCAv->GetError()!=U_OK)
    {
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Initializing average. \n");
        return NULL;
    }
    int nEp = Epochs->GetnEpochs();
    for(int iep=0; iep<nEp; iep++)
    {
        UString Status = UString(iep, "Averaging. Epoch %d of") + UString(nEp, " %d .");
        ShowStatus((const char*)Status, iep, nEp);

        UMultiChan*  MC  = GetFilteredMultiChan(iep, Dtype, -1);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete MC;
            delete MCAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedFilteredMultiChan(). Averaging data, getting data epoch, iep = %d . \n", iep);
            return NULL;
        }
        *MCAv += *MC;
        delete MC;
    }
    if(nEp) *MCAv *= (1./nEp);
    return MCAv;
}
UMultiChan** UMEEGDataEpochs::GetAllFilteredMultiChans(DataType Dtype, int isens) const
/*
    return a new pointer to an array of new UMultiChan-objects, each containing the
    filtered data of a certain epoch. The number of these pointers coincides with
    the UMEEGDataEpochs::GetNEpoch().
    if(isens<0) return filtered data of all channels of Dtype
    else        return filtered data of channel isens, of type Dtype.
                       (So the index isens is running for each data type separately)

    On error: return NULL;

    This function is handy when the same filtered epochs are required for many times.
    The disadvantage id that it requires a lot of memory.
 */
{
    int NEP = UMEEGDataEpochs::GetNEpoch();
    UMultiChan** EpArr = new UMultiChan*[NEP];

    if(EpArr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory allocation. NEP=%d .\n", NEP);
        return NULL;
    }

    for(int k=0;k<NEP; k++) EpArr[k] = NULL;

    CI.AddToLog("Note: UMEEGDataEpochs::GetAllFilteredMultiChans(). Getting %d Epochs. \n",NEP);
    for(int k=0; k<NEP; k++)
    {
        EpArr[k] = GetFilteredMultiChan(k, Dtype, isens);
        if(EpArr[k]==NULL)
        {
            for(int kk=0; kk<k; kk++) {delete[] EpArr[kk]; EpArr[kk]=NULL;}
            delete[] EpArr;

            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAllFilteredMultiChans(). Memory allocation in epoch=%d .\n", k);
            return NULL;
        }
        CI.AddToLog("%d \t",k);
    }
    CI.AddToLog("\n");
    return EpArr;
}


UMultiChan* UMEEGDataEpochs::GetFilteredMultiChanMEG(int Iepoch, const UInterpolateSensors* Inter) const
/*
    return a new pointer to a MultiChan-object, containing the  filtered MEG data
    of epoch Iepoch, interpolated to a new MEG grid, using *Inter

    On error: return NULL;
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanMEG(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanMEG(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    if(Inter==NULL || Inter->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanMEG(). Invalid or NULL Inter argument. \n");
        return NULL;
    }
    UMultiChan* MCRaw = GetFilteredMultiChan(Iepoch, U_DAT_MEG, -1);
    if(MCRaw==NULL || MCRaw->GetError()!=U_OK)
    {
        delete MCRaw;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanMEG(). Getting filtered MEG data. \n");
        return NULL;
    }
    UMultiChan* MCout = Inter->GetInterpolatedMultiChan(MCRaw);
    delete MCRaw;
    if(MCout==NULL || MCout->GetError()!=U_OK)
    {
        delete MCout;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredMultiChanMEG(). Interpolating MEG data to new sensor positions.\n");
        return NULL;
    }
    return MCout;
}
double* UMEEGDataEpochs::GetMinDatChan(int Iepoch, DataType Dtype, bool Fabs) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMinDatChan(). Data or Epochs member not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMinDatChan(). Iepoch (%d) out of range . \n", Iepoch);
        return NULL;
    }
    UMultiChan* MC = GetFilteredMultiChan(Iepoch, Dtype, -1);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMinDatChan(). Getting data from epoch %d. \n", Iepoch);
        return NULL;
    }
    double* MinDat = MC->GetMinDatChan(Fabs);
    delete MC;
    return MinDat;
}
double* UMEEGDataEpochs::GetMaxDatChan(int Iepoch, DataType Dtype, bool Fabs) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMaxDatChan(). Data or Epochs member not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMaxDatChan(). Iepoch (%d) out of range . \n", Iepoch);
        return NULL;
    }
    UMultiChan* MC = GetFilteredMultiChan(Iepoch, Dtype, -1);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMaxDatChan(). Getting data from epoch %d. \n", Iepoch);
        return NULL;
    }
    double* MaxDat = MC->GetMaxDatChan(Fabs);
    delete MC;
    return MaxDat;
}

double* UMEEGDataEpochs::GetLRSymmetryAsTime(int Iepoch, DataType Dtype) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). NULL or erroneous object. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }
    if(Dtype!=U_DAT_EEG && Dtype!=U_DAT_MEG)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Function only available for MEG or EEG data..(Dtype=%d) \n",Dtype);
        return NULL;
    }
    if((Dtype==U_DAT_MEG && Data->GetGridMEG()==NULL ) ||
       (Dtype==U_DAT_EEG && Data->GetGridEEG()==NULL ) )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Requested data type not available. (Dtype=%d) \n",Dtype);
        return NULL;
    }
    UMultiChan* MC = GetFilteredMultiChan(Iepoch, Dtype, -1);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Getting filtered data epoch. \n");
        return NULL;
    }

    double* DataLRCor = MC->GetLRSymmetryAsTime();
    delete MC;
    if(DataLRCor==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLRSymmetryAsTime(). Computing Left Right correlation pattern. \n");
        return NULL;
    }
    return DataLRCor;
}

double* UMEEGDataEpochs::GetFilteredData(int Iepoch, DataType Dtype, int isens) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredData(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredData(). Data or Epochs not properly set. \n");
        return NULL;
    }
    UMultiChan* MC = GetFilteredMultiChan(Iepoch, Dtype, isens);
    if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredData(). Reading data.\n");
        return NULL;
    }
    int     NCT  = MC->GetNChan() * MC->GetNtime();
    double* data = new double[NCT];
    if(data==NULL)
    {
        delete MC;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetFilteredData(). Memory allocation. NCT = %d .\n", NCT);
        return NULL;
    }
    for(int ij=0; ij<NCT; ij++) data[ij] = MC->GetData()[ij];
    delete MC;
    return data;
}
double* UMEEGDataEpochs::GetAverageMarkerData(const char* MarkerName, DataType Dtype, int* nSingleMatch)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(MarkerName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Invalid argument. \n");
        return NULL;
    }

// Define some general parameters
    int  nChan     = Data->GetNkan(Dtype);
    int  nSamp     = Epochs->GetNsamp(0);
    int  nEp       = Epochs->GetnEpochs();
    int  nTotMatch = 0;
    int* MarEpochs = GetMarkerArray()->GetMarker(MarkerName)->GetNMatchPerEpoch(Epochs, &nTotMatch, nSingleMatch);
    if(MarEpochs==NULL || nTotMatch==0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Error in finding epochs for marker %s.\n",MarkerName);
        return NULL;
    }

// Allocate memory for output 
    int     NCT    = nChan*nSamp;
    double* DatAv  = new double[NCT];
    if(DatAv==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Memory allocation error.\n");
        return NULL;
    }
    for(int ij=0; ij<NCT; ij++) DatAv[ij] = 0;

// Compute average data over epochs that correspond to MarkerName 
    for(int iep=0; iep<nEp; iep++)
    {
        if(MarEpochs[iep]<1)   continue;
        if(MarEpochs[iep]>1)
        {
            CI.AddToLog("WARNING: Marker %s occurring more than once in epoch %d.\n",MarkerName, iep);
            continue;
        }
        UMultiChan* MCiep = GetFilteredMultiChan(iep, Dtype, -1);
        if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL)
        {
            delete MCiep;
            delete[] MarEpochs; delete[] DatAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Cannot get filtered data from Epoch %d.\n", iep);
            return NULL;
        }
        const double* data = MCiep->GetData();
        for(int ij=0; ij<NCT; ij++) DatAv[ij] += data[ij];
        delete MCiep;
    }
    delete[] MarEpochs;

    for(int ij=0; ij<NCT; ij++) DatAv[ij] /= nTotMatch;
    return DatAv;
}
double* UMEEGDataEpochs::GetAveragedData(DataType Dtype, const char* MarkerName) const
/*
    Compute the averaged data over a selection of (filtered) epochs. The selection
    is made over all epochs that are derived from CTF markers with marker name
    MarkerName[]. It is assumed that the epoch descriptors are appropriately set.

    Return a new pointer to this averaged epoch.
    On error (e.g. if epochs are not equally dimensioned) return NULL.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverageMarkerData(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Data or Epochs not properly set. \n");
        return NULL;
    }

    int iepfirst = 0;
    int nEp      = Epochs->GetnEpochs();
    if(MarkerName)
    {
        iepfirst = Epochs->GetFirstEpochIndex(MarkerName);
        if(iepfirst<0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). No epochs with %s in their descriptor.\n", MarkerName);
            return NULL;
        }
        if(Epochs->AreEpochTimesEqual(MarkerName)==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Epochs have difference sizes.\n");
            return NULL;
        }
        nEp      = Epochs->GetNMarkerIsInDescriptor(MarkerName);
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Epochs have difference sizes.\n");
            return NULL;
        }
    }
    int nChan = Data->GetNkan(Dtype);
    int nTime = Epochs->GetNsamp(iepfirst);
    if(nChan<=0 || nTime<=0 || nEp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Data not properly set: nKan=%d, nTime=%d, nEp=%d .\n", nChan, nTime, nEp);
        return NULL;
    }

    int     NCT    = nChan*nTime;
    double* DatAv  = new double[NCT];
    if(DatAv==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Memory allocation error.\n");
        return NULL;
    }
    for(int ij=0; ij<NCT; ij++) DatAv[ij] = 0;

    for(int iep=0; iep<Epochs->GetnEpochs(); iep++)
    {
        if(MarkerName && Epochs->IsMarkerIsInDescriptor(iep, MarkerName)==false) continue;

        UMultiChan* MCiep = GetFilteredMultiChan(iep, Dtype, -1);
        if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL)
        {
            delete   MCiep;
            delete[] DatAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAveragedData(). Cannot get data from Epoch %d.\n", iep);
            return NULL;
        }
        const double* data = MCiep->GetData();
        for(int ij=0; ij<NCT; ij++) DatAv[ij] += data[ij];
        delete MCiep;
    }
    for(int ij=0; ij<NCT; ij++) DatAv[ij] /= nEp;
    return DatAv;
}

UMarker* UMEEGDataEpochs::GetTemplateMatch(const UMultiChan* Template, DataType Dtype, int isens, double DetectThresh, int MinInterval, int SubSample, SimilarityType ST, bool ShiftLocalMax)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Epochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Epochs lengths not constant. \n");
        return NULL;
    }
    if(Template==NULL || Template->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). NULL or erroneous Template .\n");
        return NULL;
    }
    int NsampTemp = Template->GetNtime();
    if(NsampTemp<=1 || NsampTemp>=Epochs->GetNsamp(0))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). NsampTemp = %d  is out of range. \n", NsampTemp);
        return NULL;
    }
    if(SubSample<=0 || SubSample>NsampTemp/2)
    {
        CI.AddToLog("WARNING: UMEEGDataEpochs::GetTemplateMatch(). Subsampling factor (= %d) out of range; set to 1. \n", SubSample);
        SubSample = 1;
    }
    if(isens<0)
    {
        if(Data->GetNkan(Dtype) != Template->GetNChan())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Number of channels of template (%d) not equal to number of channels of chosen data type (=%d). \n", Template->GetNChan(), Data->GetNkan(Dtype));
            return NULL;
        }
    }
    else
    {
        if(isens>Data->GetNkan(Dtype))
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Channels index out of range (isens=%d) .\n", isens);
            return NULL;
        }
        if(Template->GetNChan()!=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Number of channels of template should equal 1, when te,plate is matched on single channel.\n", isens);
            return NULL;
        }
    }
    const double* temp       = Template->GetData();
    double        NormTemp2  = 0;
    int           NChan      = Data->GetNkan(Dtype);
    if(isens>=0)  NChan      = 1;

    for(int i=0; i<NChan; i++)
        for(int j=0; j<NsampTemp; j+=SubSample) NormTemp2 += temp[i*NsampTemp+j]*temp[i*NsampTemp+j];

    if(NormTemp2<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Template identically zero. \n");
        return NULL;
    }
    if(DetectThresh<-1. || 1.<DetectThresh || DetectThresh==0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Correlation threshold out of range: DetectThresh = %f  .\n", DetectThresh);
        return NULL;
    }

    int      Nep    = Epochs->GetnEpochs();
    int      NsaTr  = Data  ->GetNsampTrial();
    int      NsaEp  = Epochs->GetNsamp(0);
    double*  data12 = new double[NChan*(NsampTemp+NsaEp)];
    UMarker* M      = new UMarker("Match", 0, NsaTr, 0, "Template MultiChan Match", 0, false);

    if(data12==NULL || M==NULL || M->GetError()!=U_OK)
    {
        delete[] data12;
        delete   M;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Memory allocation or creation of UMarker. \n");
        return NULL;
    }

    double  BestCor = 0.;
    UEvent  BestE;
    UEvent  LastE;

    for(int k=0; k<Nep; k++)
    {
        UString Status = UString(k, "Template matching. Examining epoch %d of") + UString(Nep, " %d .") + UString(M->GetnEvents(), " %d events detected.");
        ShowStatus((const char*)Status, k, Nep);

        UMultiChan*  Mul = GetFilteredMultiChan(k, Dtype, isens);
        if(Mul==NULL || Mul->GetError()!=U_OK || Mul->GetData()==NULL)
        {
            delete   Mul;
            delete[] data12;
            delete   M;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetTemplateMatch(). Getting filtered multichan in epock %d .\n", k);
            return NULL;
        }
        const double* data    = Mul->GetData();
        int           joffset = 0;
        if(k==0)
        {
            for(int i=0; i<NChan; i++)
                for(int j=0; j<NsampTemp; j++) data12[i*(NsampTemp+NsaEp)+j] = 0;
            joffset = NsampTemp;
        }
        for(int i=0; i<NChan; i++)
            for(int j=NsampTemp; j<NsampTemp+NsaEp; j++) data12[i*(NsampTemp+NsaEp)+j] = data[i*NsaEp+j-NsampTemp];

        if(MinInterval>0 && M->GetnEvents()>0)
        {
            int Last  = M->GetEvent(-1+M->GetnEvents()).GetAbsSample(NsaEp);
            int Start = Last  + MinInterval;
            joffset   = Start - Epochs->GetBegin(k).GetAbsSample(NsaEp);
            if(joffset<0) joffset=0;
            if(joffset>=NsaEp) continue;
        }
        for(int j=joffset; j<NsaEp; j+=SubSample)
        {
            double Cov  = 0;
            double Nor2 = 0;
            for(int i=0; i<NChan; i++)
                for(int jj=0; jj<NsampTemp; jj+=SubSample)
                {
                    double dat = data12[i*(NsampTemp+NsaEp)+j+jj];
                    Cov  += dat * temp[i*NsampTemp+jj];
                    Nor2 += dat * dat;
                }
            if(Nor2<=0) continue; // Data window identically zero.

            double  Cor = Cov/sqrt(Nor2*NormTemp2);
            double fCor = fabs(Cor);
            double  GOF = 1-fabs(NormTemp2+Nor2-2*Cov)/NormTemp2;
            UEvent    E = Epochs->GetBegin(k).GetShiftedEvent(j-NsampTemp, NsaTr);

            bool Detect = false;
            if(ST==U_SIMI_CORR2 && DetectThresh>0) Detect =  ( DetectThresh<= Cor);
            if(ST==U_SIMI_CORR2 && DetectThresh<0) Detect =  (-DetectThresh<=fCor);
            if(ST==U_SIMI_FROBNORM               ) Detect =  ( DetectThresh<= GOF);

            if(Detect==false)
            {
                if(BestCor>0)         // Accept last detection
                {
                    BestCor = 0;
                    M->AddEvent(BestE);
                    LastE   = BestE;

                    if(MinInterval>0 && GetNsamples(E, BestE, NsaTr)<MinInterval)
                        j += MinInterval - GetNsamples(E, BestE, NsaTr) - SubSample;
                }
            }
            else // Succesfull detection
            {
                if( BestCor==0                                          ||   // Set initial best
                   (ST==U_SIMI_CORR2 && DetectThresh>0 && BestCor< Cor) ||   // Find local best
                   (ST==U_SIMI_CORR2 && DetectThresh<0 && BestCor<fCor) ||
                   (ST==U_SIMI_FROBNORM                && BestCor< GOF) )
                {
                    if(ST==U_SIMI_CORR2) BestCor = fCor;
                    else                 BestCor =  GOF;
                    BestE   = E;
                }
            }
        }
        for(int i=0; i<NChan; i++)
            for(int j=0; j<NsampTemp; j++) data12[i*(NsampTemp+NsaEp)+j] = data[i*NsaEp+NsaEp-NsampTemp+j];
        delete Mul;
    }
    delete[] data12;
    M->ShiftAllEvents(+NsampTemp/2);

    if(ShiftLocalMax==true)
    {

        UMarker* MLoc = GetLocalMax(M, Dtype, NsampTemp/2);
        if(MLoc && MLoc->GetError()==U_OK)
        {
            delete M;
            M = MLoc;
        }
        else
        {
            delete MLoc;
            CI.AddToLog("WARNING: UMEEGDataEpochs::GetTemplateMatch(). Determining local max of detected markers. \n");
        }
    }
    return M;
}

UMarker* UMEEGDataEpochs::GetOutlierMarker(DataType Dtype, int isens, double Thresh, int NWindow, UString MarkerName)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOutlierMarker(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(isens>Data->GetNkan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOutlierMarker(). Channels index out of range (isens=%d) .\n", isens);
        return NULL;
    }
    if(Thresh<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOutlierMarker(). Threshold parameter out of range (Thresh=%f) .\n", Thresh);
        return NULL;
    }
    if((const char*)MarkerName == NULL) MarkerName = UString("Outlier");


    int      Nep    = Epochs->GetnEpochs();
    int      NsaTr  = Data  ->GetNsampTrial();
    UMarker* M      = new UMarker((const char*)MarkerName, 0, NsaTr, 0, "Outlier Match", 0, false);

    if(M==NULL || M->GetError()!=U_OK)
    {
        delete   M;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetOutlierMarker(). Creation UMarker. \n");
        return NULL;
    }

    int offset = 0;
    for(int k=0; k<Nep; k++)
    {
        UString Status = UString(k, "Outlier detection. Examining epoch %d of") + UString(Nep, " %d .") + UString(M->GetnEvents(), " %d events detected.");
        ShowStatus((const char*)Status, k, Nep);

        UMultiChan*  Mul = GetFilteredMultiChan(k, Dtype, isens);
        if(Mul==NULL || Mul->GetError()!=U_OK || Mul->GetData()==NULL)
        {
            delete   Mul;
            delete   M;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetOutlierMarker(). Getting filtered multichan in epock %d .\n", k);
            return NULL;
        }

        int Ntime = Mul->GetNtime();
        while(1)
        {
            if(NWindow<=0) NWindow = Ntime;

            int samp = Mul->GetMaxOutlier(offset, NWindow, Thresh);
            if(samp>=0)
            {
                UEvent E = Epochs->GetBegin(k).GetShiftedEvent(samp, NsaTr);
                M->AddEvent(E);
                offset = samp + NWindow;
            }
            else
            {
                offset += NWindow;
            }
            if(offset+NWindow/2 >= Ntime) offset = Ntime;
            if(offset>=Ntime) break;
        }
        offset -= Ntime;
        delete Mul;
    }
    return M;
}

UMarker* UMEEGDataEpochs::GetLocalMax(const UMarker* M, DataType Dtype, int WinLocMax)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(WinLocMax<=0)
    {
        if(WinLocMax<0)
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Invalid Window argument, WinLocMax = %d  . \n", WinLocMax);
        return NULL;
    }
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Invalid or NULL UMarker-argument. \n");
        return NULL;
    }
    if(Epochs->GetnSampTrial()!=M->GetnSampTrial())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Number of samples per trial not consistent. \n");
        return NULL;
    }

    UMarker* MLocMax = new UMarker(*M);
    if(MLocMax==NULL || MLocMax->GetError()!=U_OK)
    {
        delete MLocMax;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Copying UMarker-argument. \n");
        return NULL;
    }
    int Nev = MLocMax->GetnEvents();
    for(int k=0; k<Nev; k++)
    {
        UEvent E = MLocMax->GetEvent(k);
        int    s = GetLocalMax(E, Dtype, WinLocMax);
        E.GetShiftedEvent(s, Epochs->GetnSampTrial());
        MLocMax->SetEvent(k, E);

        UString Status = UString(k, "LocalMax. Examined event %d of") + UString(Nev, " %d .") + UString(s, " Event shifted %d samples.");
        ShowStatus((const char*)Status, k, Nev);
    }
    UString NewName(MLocMax->GetMarkerName(), "LocMax_%s");
    MLocMax->SetName((const char*)NewName);
    return MLocMax;
}

int UMEEGDataEpochs::GetLocalMax(UEvent E, DataType Dtype, int WinLocMax) const
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Data or Epochs not properly set. \n");
        return 0;
    }
    if(WinLocMax<=0)
    {
        if(WinLocMax<0)
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Invalid Window argument, WinLocMax = %d  . \n", WinLocMax);
        return 0;
    }
    int Nkan = Data->GetNkan(Dtype);
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). No data of data type %d .\n", Nkan);
        return 0;
    }

/* Get test data, in order to determine local max */
    int     TestNtime   = 2*WinLocMax-1;
    int*    TestOffsets = new int   [TestNtime];
    double* Data4       = new double[TestNtime];
    if(TestOffsets==NULL || Data4==NULL)
    {
        delete[] TestOffsets;
        delete[] Data4;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Memory allocation, WinLocMax = %d. \n", WinLocMax);
        return NULL;
    }
    for(int k=0; k<2*WinLocMax-1; k++) TestOffsets[k] = k-WinLocMax+1;

    UMultiChan* MC = GetFilteredMultiChan(E, TestOffsets, TestNtime, Dtype);
    if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
    {
        delete   MC;
        delete[] Data4;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetLocalMax(). Getting Test data. \n");
        return NULL;
    }
    const double* data = MC->GetData();

    for(int j=0; j<TestNtime; j++)
    {
        Data4[j] = 0;
        for(int i=0; i<Nkan; i++)
        {
            double T  = data[i*TestNtime+j];
            Data4[j] += T*T*T*T;
        }
    }
    delete MC;

    int jmax = 0;
    for(int jm=0; jm<WinLocMax; jm++)
    {
        int kplu =  jm + WinLocMax -1; // WinLocMax-1,...,2*WinLocMax-2
        int kmin = -jm + WinLocMax -1; // WinLocMax-1,...,0
        if(jm==WinLocMax-1)
        {
            if(Data4[kmin]>Data4[kplu]) {jmax = TestOffsets[kmin]; break;}
            else                        {jmax = TestOffsets[kplu]; break;}
        }
        else
        {
            if(Data4[kplu]>Data4[kplu-1] && Data4[kplu]>Data4[kplu+1]) {jmax = TestOffsets[kplu]; break;}
            if(Data4[kmin]>Data4[kmin-1] && Data4[kmin]>Data4[kmin+1]) {jmax = TestOffsets[kmin]; break;}
        }
    }
    delete[] TestOffsets;
    delete[] Data4;

    return jmax;
}

UMarkerArray* UMEEGDataEpochs::ConvertGraphsToMarkers(UFieldGraph* const* Graphs, int NGraphs) const
{
    if(Data  ==NULL || Data  ->GetError()!=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertGraphsToMarkers(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Graphs==NULL || NGraphs<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertGraphsToMarkers(). Invalid (NULL) argument(s). NGraphs=%d .\n", NGraphs);
        return NULL;
    }
    UMarkerArray* MarkGraph = new UMarkerArray(0, Data->GetNsampTrial(), Data->GetPreNTriggerPnts(), Data->GetSampleRate());
    if(MarkGraph==NULL || MarkGraph->GetError()!=U_OK)
    {
        delete MarkGraph;
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertGraphsToMarkers(). Setting initial markerarray .\n");
        return NULL;
    }
    for(int n=0; n<NGraphs; n++)
    {
        if(Graphs[n]==NULL || Graphs[n]->GetError()!=U_OK)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::ConvertGraphsToMarkers(). Skipping graph %d (NULL or erroneous) .\n", n);
            continue;
        }
        UMarker* M = Epochs->ConvertGraphToMarkers(Graphs[n]);
        if(M==NULL || M->GetError()!=U_OK)
        {
            delete M;
            CI.AddToLog("WARNING: UMEEGDataEpochs::ConvertGraphsToMarkers(). Converting graph %d .\n", n);
            continue;
        }
        if(MarkGraph->AddMarker(M)!=U_OK)
        {
            delete M;
            CI.AddToLog("WARNING: UMEEGDataEpochs::ConvertGraphsToMarkers(). Adding marker %d to array.\n", n);
            continue;
        }
        delete M;
    }
    if(MarkGraph->GetnMarkers()<=0)
    {
        delete MarkGraph;
        CI.AddToLog("ERROR: UMEEGDataEpochs::ConvertGraphsToMarkers(). Not any marker converted succesfully. \n");
        return NULL;
    }
    return MarkGraph;
}


void UMEEGDataEpochs::Mirror(UEvent Begin, UEvent End, double* data, int nKan) const
{
/* Mirror the zeroed data values*/
    int NsampReq = GetNsamples(Begin, End, Data->GetNsampTrial());

    if(Begin.trial<0)
    {
        int last0 = GetNsamples(Begin, UEvent(0,0), Data->GetNsampTrial())-2;

        for(int i=0; i<nKan; i++)
        {
            double* chan = data+i*NsampReq;
            for(int jm=last0, jp=last0+1; jm>=0; jp++, jm--)
////                chan[jm] = yoff2-chan[jp];
                chan[jm] = chan[jp];
        }
    }
    if(End.trial>=Data->GetNtrial())
    {
        int first0 = NsampReq-GetNsamples(UEvent(Data->GetNtrial()-1,Data->GetNsampTrial()-1), End, Data->GetNsampTrial())+1;
        for(int i=0; i<nKan; i++)
        {
            double* chan = data+i*NsampReq;
////            double yoff2 = 2*chan[first0-1];
            for(int jp=first0, jm=first0-1; jp<NsampReq; jp++, jm--)
////                chan[jp] = yoff2-chan[jm];
                chan[jp] = chan[jm];
        }
    }
}

int UMEEGDataEpochs::GetNsampReq(UEvent *Begin, UEvent *End, int NsampEpoch) const
/*
     Return the number of required data points in order to filter adquately.
     For linear time invariant filters, this number may be larger than
     the number of data samplers between Begin and End.
     Also, update the begin and End events, according to the required number
     of data samples. The newly computed Begin and End (which are centered about
     the average of Begin and End) may refer to trials outside the range
     [0, Data->ntrial>
 */
{
    if(Filt.GetFilterType()!=U_FILT_BANDPASS &&
       Filt.GetPowerLine() ==false             ) return NsampEpoch;

    if(DoNotExtraSamples   ==true              ) return NsampEpoch;

/* Compute the required amount of samples*/
    int NsampReq = (int)(.5+TMIN/SampleTime_s);
    if(NsampReq<NSAMPFACTOR*NsampEpoch) NsampReq = int( floor(0.5+ NSAMPFACTOR*NsampEpoch ));

/* Because ULinearFilter uses a finit impuls response of Filt.GetNImpulseResponse() samples,
   it does not make sense to take more than NsampEpoch+2*Filt.GetNImpulseResponse() samples */
    if(NsampReq-NsampEpoch>2*Filt.GetNImpulseResponse())
        NsampReq = NsampEpoch+2*Filt.GetNImpulseResponse();

/* Replace Begin and End event */
    int NST  = Data->GetNsampTrial();
    int mid  = Center(*Begin, *End, NST).GetAbsSample(NST);
    int bs   = mid -  NsampReq/2; // Absolute sample number of Epoch begin

    if(bs>=0)  *Begin = UEvent(bs/NST, bs%NST);
    else       *Begin = UEvent(-(-bs/NST)-1, NST-1-(-bs%NST));

    *End   = Begin->GetShiftedEvent(NsampReq-1,NST);

/*Return the required amount of samples*/
    return NsampReq;
}

double* UMEEGDataEpochs::GetRawData(UEvent Beg, UEvent End, DataType Dtype, int isens, int* Nsamp) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Data-member NULL or erroneous.\n");
        return NULL;
    }
    int NST = Data->GetNsampTrial();
    if(Beg.GetAbsSample(NST)>End.GetAbsSample(NST))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Invalid ordering of begin and end sample.\n");
        return NULL;
    }
    if(Nsamp) *Nsamp = End.GetAbsSample(NST) - Beg.GetAbsSample(NST) + 1;

    ReReferenceType      ReRef = U_REF_RAW;
    if(Dtype==U_DAT_MEG) ReRef = MEGReref;
    if(Dtype==U_DAT_EEG) ReRef = EEGReref;

    if(isens<0) return Data->GetEpoch_d(Beg, End, Dtype, ReRef);

    if(isens>=Data->GetNkan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Sensor index out of range (isens = %d) .\n", isens);
        return NULL;
    }
    switch(Dtype)
    {
    case U_DAT_MEGREF:  return Data->GetChannel_d(Beg, End, Data->GetGridREF()->GetName(isens)); break;
    case U_DAT_MEG:     return Data->GetChannel_d(Beg, End, Data->GetGridMEG()->GetName(isens)); break;
    case U_DAT_EEG:     return Data->GetChannel_d(Beg, End, Data->GetGridEEG()->GetName(isens)); break;
    case U_DAT_ADC:     return Data->GetChannel_d(Beg, End, Data->GetGridADC()->GetName(isens)); break;
    default:
        {
            int ichan = Data->GetChannelIndex(isens, Dtype);
            if(ichan<0)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Cannot determine label name for data type :%d, (isens = %d) \n", Dtype, isens);
                return NULL;
            }
            return Data->GetChannel_d(Beg, End, Data->GetChanInfo(ichan).namChannel);
        }
    }
    CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawData(). Channel not found. Data type :%d, (isens = %d) \n", Dtype, isens);
    return NULL;
}
ErrorType UMEEGDataEpochs::ApplyOutlierCorrection(UMultiChan* MC, DataType Dtype) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplyOutlierCorrection(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplyOutlierCorrection(). Data-member NULL or erroneous.\n");
        return U_ERROR;
    }
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplyOutlierCorrection(). NULL or erroneous UMultiChan argument.\n");
        return U_ERROR;
    }
    if(Dtype==U_DAT_NTYPE||OutPar[Dtype].Apply==false) return U_OK;

    int MaxWin = MC->GetNtime()/2;
    if(MC->InterpolateOutliers(OutPar[Dtype].Normal, OutPar[Dtype].Outlier, MaxWin, NULL, NULL)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplyOutlierCorrection(). Interpolating outliers.\n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataEpochs::ApplySEFCorrection(UMultiChan* MC, UEvent Begin, UEvent End, DataType Dtype) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplySEFCorrection(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplySEFCorrection(). Data-member NULL or erroneous.\n");
        return U_ERROR;
    }
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplySEFCorrection(). NULL or erroneous UMultiChan argument.\n");
        return U_ERROR;
    }

    int NST = Data->GetNsampTrial();
    if(End.GetAbsSample(NST)-Begin.GetAbsSample(NST)+1!=MC->GetNtime())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ApplySEFCorrection(). Given data window not compatible with MC->GetNtime() = %d .\n", MC->GetNtime());
        return U_ERROR;
    }
    
    if((Dtype!=U_DAT_MEGREF && Dtype!=U_DAT_MEG && Dtype!=U_DAT_EEG) 
        || NOT(CorrectSEFartifact)) return U_OK;

// Apply SEF-correction.
    int joffb = GetSEFCorrectionWinSampFrom(false);
    int joffe = GetSEFCorrectionWinSampTo  (false);
    int jBabs = Begin.GetAbsSample(NST);

    if(SEFMarker.GetnSamples()<=0) // Assume SEF artifacts are at fixed offsets from raw trials
    {
        for(int it=Begin.trial; it<=End.trial; it++)
        {
            UEvent B     = UEvent(it, 0);
            int    jb    = B.GetAbsSample(NST)+joffb - jBabs;
            int    je    = B.GetAbsSample(NST)+joffe - jBabs;

            if(je<0 || jb>MC->GetNtime()) continue;

            if(jb<=0 && MC->GetNtime()<=je)
            {
                CI.AddToLog("WARNING: UMEEGDataEpochs::GetSEFCorrectedMultiChan(). Epoch complety enclosed by artifact.\n");
                return U_OK;
            }
            if(MC->InterpolateDataSegment(jb, je, -1)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFCorrectedMultiChan(). Correcting data for stimulus artifact.\n");
                return U_ERROR;
            }
        }
    }
    else // Assume fixed intervals around SEFMarker
    {
        for(int iev=0; iev<SEFMarker.GetnSamples(); iev++)
        {
            UEvent EV    = SEFMarker.GetEvent(iev);
            int    jb    = EV.GetAbsSample(NST) + joffb - jBabs;
            int    je    = EV.GetAbsSample(NST) + joffe - jBabs;

            if(je<0             ) continue;
            if(jb>MC->GetNtime()) continue;

            if(jb<=0 && MC->GetNtime()<=je)
            {
                CI.AddToLog("WARNING: UMEEGDataEpochs::GetSEFCorrectedMultiChan(). Epoch complety enclosed by artifact.\n");
                return U_OK;
            }
            if(MC->InterpolateDataSegment(jb, je, -1)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFCorrectedMultiChan(). Correcting data for stimulus artifact.\n");
                return U_ERROR;
            }
        }
    }
    return U_OK;
}

double* UMEEGDataEpochs::GetSEFcorrectedData(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef, int isens) const
{
    double* DefData = NULL;
    if(isens<0)
    {
        DefData = Data->GetEpoch_d(Begin, End, Dtype, ReRef);
    }
    else
    {
        if(isens>=Data->GetNkan(Dtype))
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFcorrectedData(). Channel out of range: isens=%d, Nkan=%d \n", isens, Data->GetNkan(Dtype));
            return NULL;
        }
        switch(Dtype)
        {
        case U_DAT_MEGREF:  DefData = Data->GetChannel_d(Begin, End, Data->GetGridREF()->GetName(isens)); break;
        case U_DAT_MEG:     DefData = Data->GetChannel_d(Begin, End, Data->GetGridMEG()->GetName(isens)); break;
        case U_DAT_EEG:     DefData = Data->GetChannel_d(Begin, End, Data->GetGridEEG()->GetName(isens)); break;
        case U_DAT_ADC:     DefData = Data->GetChannel_d(Begin, End, Data->GetGridADC()->GetName(isens)); break;
        default:
            {
                int ichan = Data->GetChannelIndex(isens, Dtype);
                if(ichan<0)
                {
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFcorrectedData(). Cannot determine label name for data type :%d, (isens = %d) \n", Dtype, isens);
                    return NULL;
                }
                DefData = Data->GetChannel_d(Begin, End, Data->GetChanInfo(ichan).namChannel);
            }
        }
    }
    if(DefData==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFcorrectedData(). Getting raw data from file.\n");
        return NULL;
    }
    if(CorrectSEFartifact==false ||
       Dtype==U_DAT_ADC) return DefData;

/* Determine whether stimulus onset can be determined with respect to begin of epochs*/
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("WARNING: UMEEGDataEpochs::GetSEFcorrectedData(). Stimulus onset can not be found because epochs are of different duration.\n");
        return DefData;
    }

    int joffb = int(floor( NPreTriggerSamples + TartBegin/SampleTime_s+.5     ));  // Begin and end of artifact
    int joffe = joffb + int(floor(              TartWidth/SampleTime_s+.5 + 1 ));

/* Test whether the requested data window overlaps with the expected SEF artifact */
    int Nkan         = 1;
    if(isens<0) Nkan = Data->GetNkan(Dtype);
    int NsampTrial   = Data->GetNsampTrial();
    for(int iep=0; iep<Epochs->GetnEpochs(); iep++)
    {
        int jBabs  = Begin.GetAbsSample(NsampTrial);
        int jEabs  = End.GetAbsSample(NsampTrial);
        int jb     = Epochs->GetBegin(iep).GetAbsSample(NsampTrial)+joffb;
        int je     = Epochs->GetBegin(iep).GetAbsSample(NsampTrial)+joffe;

        if(jb<=jBabs && jEabs<=je)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFcorrectedData(). Epoch %d complety enclosed by artifact.\n",iep);
            delete[] DefData;
            return NULL;
        }
        if(jBabs<=je && jb<=jEabs)
        {
            if(RemoveSEFart(DefData, jEabs-jBabs+1, Nkan, joffb, joffe)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSEFcorrectedData(). Correcting data for stimulus artifact in epoch %d.\n",iep);
                delete[] DefData;
                return NULL;
            }
        }
    }
    return DefData;
}

ErrorType UMEEGDataEpochs::RemoveSEFart(double* data, int Nsamp, int Nkan, int joffb, int joffe) const
{
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RemoveSEFart(). NULL argument. \n");
        return U_ERROR;
    }

    if(joffb<0 && joffe>=Nsamp) return U_ERROR;
    if(joffe<0 || joffb>=Nsamp) return U_OK; // Nothing to do!

    if(joffb<0) // copy first artifact free sample backwards
    {
        for(int i=0; i<Nkan; i++)
        {
            for(int j=0; j<joffe; j++)
                data[i*Nsamp+j] = data[i*Nsamp+joffe];
        }
        return U_OK;
    }

    if(joffe>=Nsamp) // copy last artifact free sample forwards
    {
        for(int i=0; i<Nkan; i++)
        {
            for(int j=joffb; j<Nsamp; j++)
                data[i*Nsamp+j] = data[i*Nsamp+joffb-1];
        }
        return U_OK;
    }

/* Interpolate linearly between first and last artifact free samples*/
    for(int i=0; i<Nkan; i++)
    {
        double offset =  data[i*Nsamp+joffb-1];
        double slope  = (data[i*Nsamp+joffe]-data[i*Nsamp+joffb-1]) /(joffe-joffb+1);
        for(int j=joffb; j<joffe; j++)
            data[i*Nsamp+j] = offset + (j-joffb+1)*slope;
    }
    return U_OK;
}


ErrorType UMEEGDataEpochs::SetRereference(ReReferenceType MEGR, ReReferenceType EEGR)
{
    switch(MEGR)
    {
    case U_REF_RAW:
    case U_REF_UNBALANCED:
    case U_REF_FIRST:
    case U_REF_SECOND:
    case U_REF_THIRD:
        MEGReref = MEGR;
        break;

    default:
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetRereference(). Invalid re-referening parameter for MEG: %d \n",MEGR);
        return U_ERROR;
    }
    if(Data&&Data->CanBeBalanced()==false)
    {
        MEGReref = U_REF_RAW;
        if(MEGR!=U_REF_RAW)
            CI.AddToLog("WARNING: UMEEGDataEpochs::SetRereference(). No balancing tables present in data file. Read MEG data as in file, without balanicing to %s \n",UMEEGDataBase::GetReReferenceText(MEGR));
    }

    switch(EEGR)
    {
    case U_REF_RAW:
    case U_REF_AVERAGE:
    case U_REF_GROUPAVER:
    case U_REF_COMMON:
    case U_REF_LAPLACIAN:
        EEGReref = EEGR;
        break;

    default:
        CI.AddToLog("UMEEGDataEpochs::SetRereference(). Invalid re-referening parameter for EEG: %d \n",EEGR);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataEpochs::SetCommonRef(const char* RefLabel)
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetCommonRef(). Data not set. \n");
        return U_ERROR;
    }
    ErrorType E = Data->SetCommonRef(RefLabel);
    if(E==U_OK && RefLabel) EEGReref = U_REF_COMMON;

    return E;
}

const char* UMEEGDataEpochs::GetCommonRef(void) const
{
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCommonRef(). Data not set. \n");
        return NULL;
    }
    return Data->GetCommonReferenceLabel();
}


//// TEST:
////double* UMEEGDataEpochs::GetFilteredData(int Iepoch, DataType Dtype, ReReferenceType ReRef)
////{
////    // Window Filter Version of the Data
////    if(Data==NULL)
////    {
////        fprintf(stderr,"\nError:EpochsData2:\nNo data available for filtering ");
////        return NULL;
////    }
////    if(Epochs==NULL)
////    {
////        fprintf(stderr,"\nError:EpochsData2:\nNo epochs set for filtering ");
////        return NULL;
////    }
////
////    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs()) return NULL;
////    int MinNoSamples = (int)(4.0 * Data->GetSampleRate());// Minimum number samples for frequency resolution
////    int MinFactor2NoSamples = UpperPower2(MinNoSamples);// Make it a factor two for the FFT
////
////    int NoSamplesEpoch = Epochs->GetNsamp(Iepoch, Data->GetNsampTrial());
////    int MinNoSamplesEpoch = UpperPower2(2 * NoSamplesEpoch);// Make window twice as big for side effects and make it an upper power of two
////
////    int WindowSamples; // The minimum number of samples of the last two minima
////    WindowSamples = max(MinFactor2NoSamples, MinNoSamplesEpoch);
////
////    UEvent Begin = Epochs->GetBegin(Iepoch) ; // Begin of the wanted filtered epoch
////    UEvent End   = Epochs->GetEnd(Iepoch);    // End   of the wanted filtered epoch
////    int shift = -(WindowSamples -  NoSamplesEpoch)/2 ; // shift of window begin event with respect to begin event
////    UEvent WindowBegin = Begin.GetShiftedEvent(shift, Data->GetNsampTrial()); // Begin of the epoch for filtering
////    UEvent WindowEnd   = WindowBegin.GetShiftedEvent( WindowSamples - 1, Data->GetNsampTrial());              // End   of the epoch for filtering
////
////    /* Get window data and filter them */
////    double* datawindow = Data->GetEpoch_d(WindowBegin, WindowEnd, Dtype, ReRef); // Creating an object containing the data over the epoch for filtering
////    if(datawindow==NULL)
////    {
////        fprintf(stderr,"\nError:EpochsData2:\nNo data available for filtering ");
////        delete[] datawindow;
////        return NULL;
////    }
////
////    if(Filt.GetFilterType()!=NO_TYPE)
////        if(Filt.ComputeFilter(datawindow, WindowSamples, Data->GetNkan(Dtype))!=U_OK)
////        {
////            delete[] datawindow;
////            return NULL;
////        }
////
////    /* Get epoch data out of the filtered window data */
////    double *epochdata = new double[NoSamplesEpoch*Data->GetNkan(Dtype)];
////    if(epochdata==NULL)
////    {
////        fprintf(stderr,"\nERROR:EpochsData2:\n cannot created data object");
////        delete[]datawindow;
////        return NULL;
////    }
////
////    for(int i=0,k=0; i<Data->GetNkan(Dtype); i++)
////          for(int j=0;j<NoSamplesEpoch;j++,k++)
////            epochdata[k] = datawindow[i*WindowSamples-shift+j];
////    delete[] datawindow;
////    return epochdata;
////}
/////END TEST


const UString& UMEEGDataEpochs::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataEpochs-object\n");
        return Properties;
    }

    Properties = UString();
    if(InterpolateCTF   ==true)
    {
        Properties += UString(" MEG data interpolated to CTF sensor system.\n");
    }
    if(ComputeHilbertXfm==true)
    {
        Properties += UString(" Amplitude modulation of filtered data computed using Hilbert transform. \n");
    }
    if(Data)
    {
        Properties += Data->GetProperties("   ");
    }
    if(Epochs)
    {
        Properties += Epochs->GetProperties("   ");
        if(Epochs->GetHistory())
        {
            UString Hist(Epochs->GetHistory());
            Hist.Truncate(4000, "...");
            Hist.InsertAtEachLine("   ");
            Properties += UString(" Epochs history:\n") + Hist;
        }
    }

    Properties += UString(" Filters: \n");
    Properties += UString(Filt.GetProperties("     "));
    if(CorrectSEFartifact==true)
    {
        Properties += UString(1000*TartBegin,"     SEF artifact removed by linear interpolation. Time window after stimulus onset: %f ") +UString(1000*(TartBegin+TartWidth), "- %f ms. \n");
        if(SEFMarker.GetnSamples()<=0) Properties += UString("SEFMarker    = All Trials \n");
        else                           Properties += UString(SEFMarker.GetMarkerName(), "SEFMarker    = %s \n");

        int joffb = GetSEFCorrectionWinSampFrom(false);
        int joffe = GetSEFCorrectionWinSampTo  (false);
        Properties += UString(joffb, "SEFWinBegin  = %d \n");
        Properties += UString(joffe, "SEFWinEnd    = %d \n");
    }
    bool First = false;
    for(int k=0; k<U_DAT_NTYPE; k++)
    {
        if(OutPar[k].Apply == false) continue;
        if(First==false) Properties += UString(" Outliers removed: \n");
        First       = true;
        DataType DT = UMEEGDataBase::GetDataType(k);
        Properties += UString("  ") + UString(UMEEGDataBase::GetDataTypeText(DT)) + "  : ";
        Properties += UString(OutPar[k].Normal,"(%f,") + UString(OutPar[k].Outlier,"%f) \n");
    }
    if(Filt.GetFilterType()==U_FILT_BANDPASS)
    {
        if(DoNotExtraSamples == false)
        {
            Properties += UString(TMIN,"    For filtering take at least %f s of data, or enlarge epoch")+UString(NSAMPFACTOR," by a factor of %f.\n");
        }
        else
        {
            Properties += UString("    No extra samples are taken for band pass filtering.\n");
        }
    }
    if(Filt.GetPreProType()!=U_PREP_NO)
    {
        Properties += PreProcEpochsText + UString(" \n");
    }
    if(Data && Data->GetNmeg()>0)
    {
        switch(MEGReref)
        {
        case U_REF_RAW:        Properties += UString("     MEG data not re-referenced \n"); break;
        case U_REF_UNBALANCED: Properties += UString("     MEG data forced unbalanced \n"); break;
        case U_REF_FIRST:      Properties += UString("     MEG data computed in first gradient \n"); break;
        case U_REF_SECOND:     Properties += UString("     MEG data computed in second gradient \n"); break;
        case U_REF_THIRD:      Properties += UString("     MEG data computed in third gradient \n"); break;
        default:               Properties += UString("     Unknown re-referencing applied on MEG data \n"); break;
        }
    }
    if(Data && Data->GetNeeg()>0)
    {
        switch(EEGReref)
        {
        case U_REF_RAW:        Properties += UString("     EEG data not re-referenced \n"); break;
        case U_REF_AVERAGE:    Properties += UString("     EEG data computed w.r.t. average reference \n"); break;
        case U_REF_GROUPAVER:  Properties += UString("     EEG data computed w.r.t. average reference of EEG channel sub-grous \n"); break;
        case U_REF_COMMON:
            {
                const char* Name = Data->GetCommonReferenceLabel();
                if(Name)
                    Properties += UString(Name, "     EEG data computed w.r.t. to %s\n");
                else
                    Properties += UString("     EEG data computed w.r.t. to Unknown Reference \n");
            }
        case U_REF_LAPLACIAN:  Properties += UString("     EEG data computed as Laplacian reference \n"); break;
        default:    Properties += UString("     Unknown re-referencing applied on EEG data \n"); break;
        }
    }
    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}


double* UMEEGDataEpochs::GetRawPrepVariance(int Iepoch, DataType Dtype) const
/*
     Return an array with the variances of the MEG/EEG data over the pre-proceesing
     window of epoch Iepoch.
 */
{
    if(EpochsPre==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Preprocessing epochs not set.\n");
        return NULL;
    }
    if(Epochs==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Epochs or Data not set.\n");
        return NULL;
    }

    if(Epochs->GetnEpochs() != EpochsPre->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Number of epochs for analysis (%d) unequal to number of epochs for pre-processing (%d).\n",Epochs->GetnEpochs(),EpochsPre->GetnEpochs());
        return NULL;
    }

    if(Iepoch<0 || Iepoch>=EpochsPre->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Function not compatible with computation of Hilbert transform. \n",Iepoch);
        return NULL;
    }

    ReReferenceType      ReRef = U_REF_RAW;
    if(Dtype==U_DAT_MEG) ReRef = MEGReref;
    if(Dtype==U_DAT_EEG) ReRef = EEGReref;


    UEvent Begin = EpochsPre->GetBegin(Iepoch);
    UEvent End   = EpochsPre->GetEnd(Iepoch);

    double* Prep = GetSEFcorrectedData(Begin, End, Dtype, ReRef, -1);
    double* Var  = new double[Data->GetNkan(Dtype)];
    if(Var==NULL || Prep==NULL)
    {
        delete[] Var;
        delete[] Prep;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetRawPrepVariance(). Memory allocation error. \n");
        return NULL;
    }

    int NsampPrep = EpochsPre->GetNsamp(Iepoch);
    for(int i=0; i<Data->GetNkan(Dtype); i++)
    {
        Var[i] = 0;
        for(int j=0; j<NsampPrep; j++) Var[i] += Prep[i*NsampPrep+j]*Prep[i*NsampPrep+j];
        if(NsampPrep) Var[i] /= NsampPrep;
    }
    delete[] Prep;

    return Var;
}

bool UMEEGDataEpochs::ArePreProcessingEpochsSet(void) const
{
    if(EpochsPre) return true;
    return false;
}

ErrorType UMEEGDataEpochs::ReSetPreProcessingEpochs(void)
{
    delete EpochsPre; EpochsPre = NULL;
    PreProcEpochsText = UString("Pre-procesing (if set) based on analysis windows. ");
    return U_OK;
}

ErrorType UMEEGDataEpochs::SetPreProcessingEpochs(int BeginOffset, int EndOffset)
/*
     Set the pre-processing epochs in such a way that each pre-processing
     epoch corresponds to a shifted version of the epochs in Epochs.

     The begin sample of the pre-processing epoch is determined by shifting
     the begin sample of each epoch over BeginOffset samples. The end sample
     is obtained by shifting that begin sample over EndOffset samples.

     if(BeginOffset>EndOffset) The pre-processing epochs are set to last the pre-trigger
           interval before the begin sample of the data epoch.

     Note: SetPreProcessingEpochs() should always be set after the (data) Epochs
           are set.
 */
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetPreProcessingEpochs(). Epochs not (properly) set.\n");
        return U_ERROR;
    }

    delete EpochsPre;
    EpochsPre = new UEpochs(*Epochs);
    if(EpochsPre==NULL || EpochsPre->GetError()!=U_OK)
    {
        ReSetPreProcessingEpochs();
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetPreProcessingEpochs(). Memory allocation.\n");
        return U_ERROR;
    }

    if(BeginOffset<=EndOffset)
    {
        int Nsamp = Data->GetNsampTrial();
        for(int iep=0; iep<Epochs->GetnEpochs(); iep++)
        {
            UEvent Ev    = Epochs->GetBegin(iep);
            UEvent Begin = Ev.GetShiftedEvent(BeginOffset, Nsamp);
            UEvent End   = Ev.GetShiftedEvent(EndOffset, Nsamp);
            if(Begin.trial<0 || Begin.trial>=Data->GetNtrial() ||
               End.trial<0   || End.trial  >=Data->GetNtrial() )
            {
                CI.AddToLog("WARNING: pre-processing window of epoch %d out of range.\n",iep);
            }

            EpochsPre->SetBegin(iep, Begin);
            EpochsPre->SetEnd(iep, End);
        }
        PreProcEpochsText = UString("Pre-procesing set by shifting begin sample of analysis epoch over")
                          + UString(BeginOffset," %d") + UString(EndOffset," and %d .");
    }
    else
    {
        int Npretrigger = Data->GetPreNTriggerPnts();
        for(int iep=0; iep<Epochs->GetnEpochs(); iep++)
        {
            int itrial   = Epochs->GetBegin(iep).trial;
            UEvent Begin(itrial, 0);
            UEvent End(itrial, Npretrigger);

            EpochsPre->SetBegin(iep, Begin);
            EpochsPre->SetEnd(iep, End);
        }
        PreProcEpochsText = UString(Npretrigger, "Pre-procesing set equal to pre-stimulus epoch: (0,%d");
    }
    return U_OK;
}

ReReferenceType UMEEGDataEpochs::GetMEGForwardBalancing(void) const
/*
    Return the optial Balancing parameter for the MEG forward modeling.
    This parameter depends on the way the MEG data is re-balanced or, if no re-balancing
    is applied, it depends on the way the data is recorded.
 */
{
    ReReferenceType  ReRefForw = U_REF_RAW;

    switch(MEGReref)
    {
    case U_REF_RAW:
        {
            int DGOrder = Data->GetDataGradOrder();
            switch(DGOrder)
            {
            case 0: ReRefForw = U_REF_RAW; break;
            case 1: ReRefForw = U_REF_RAW; break;
            case 2: ReRefForw = U_REF_SECONDFORWARD; break;
            case 3: ReRefForw = U_REF_THIRDFORWARD; break;
            default:
                CI.AddToLog("WARNING: UMEEGDataEpochs::GetMEGForwardBalancing(). The gradient order in which the data is recorded cannot be determined or varies over channels (%d). Compute forward model without re-balancing. \n",DGOrder);
                ReRefForw = U_REF_RAW; break;
            }
        }
        break;
    case U_REF_UNBALANCED: ReRefForw = U_REF_RAW; break;
    case U_REF_FIRST:      ReRefForw = U_REF_RAW; break;
    case U_REF_SECOND:     ReRefForw = U_REF_SECONDFORWARD; break;
    case U_REF_THIRD:      ReRefForw = U_REF_THIRDFORWARD; break;
    default:
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMEGForwardBalancing(). Invalid MEG rereferencing type in UMEEGDataEpochs: %d .\n", MEGReref);
        return U_REF_RAW;
    }
    CI.AddToLog("Note: UMEEGDataEpochs::GetMEGForwardBalancing(). Data read as '%s'; Forward model as '%s' .\n", UMEEGDataBase::GetReReferenceText(MEGReref), UMEEGDataBase::GetReReferenceText(ReRefForw));

    return ReRefForw;
}
UCovariance* UMEEGDataEpochs::GetSpatialCovariance(int Iepoch, DataType Dtype)
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Data not (properly) set.\n");
        return NULL;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Epochs not (properly) set.\n");
        return NULL;
    }
    if(Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
        return NULL;
    }
    if(Dtype!=U_DAT_MEG && Dtype!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Only MEG and EEG data are supported. \n");
        return NULL;
    }
    int NChan = Data->GetNkan(Dtype);
    if(NChan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Too few channels of requested data type: NChan = %d .\n", NChan);
        return NULL;
    }
    int iepBeg = (Iepoch<0) ? 0                    : Iepoch;
    int iepEnd = (Iepoch<0) ? Epochs->GetnEpochs() : Iepoch+1;

    UCovariance* Cov = NULL;
    if(Dtype==U_DAT_MEG) Cov = new UCovariance(Data->GetGridMEG(), NULL, 0, 0., U_COV_DATA_XX);
    if(Dtype==U_DAT_EEG) Cov = new UCovariance(NULL, Data->GetGridEEG(), 0, 0., U_COV_DATA_XX);
    if(Cov==NULL || Cov->GetError()!=U_OK)
    {
        delete Cov;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Creating default covariance. .\n");
        return NULL;
    }
    int NTerm=0;
    for(int iep = iepBeg; iep<iepEnd; iep++, NTerm++)
    {
        UMultiChan* MC = GetFilteredMultiChan(iep, Dtype);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete Cov;
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Getting filtered data from epoch %d .\n", iep);
            return NULL;
        }
        UCovariance* Term = MC->GetSpatialCovariance(Dtype);
        delete MC;
        if(Term==NULL || Term->GetError()!=U_OK)
        {
            delete Cov;
            delete Term;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatialCovariance(). Getting covarience for epoch %d .\n", iep);
            return NULL;
        }
        (*Cov) += (*Term);
        delete Term;
    }
    (*Cov) *= (1./NTerm);
    return Cov;
}

UFileName UMEEGDataEpochs::GetSpatCovarianceFile(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatCovarianceFile(). Object NULL or erroneous. \n");
        return UFileName();
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpatCovarianceFile(). Data not (properly) set.\n");
        return UFileName();
    }
    return GetData()->GetDataFileName().GetSiblingFileName("CovarXX.cov");
}
UFileName UMEEGDataEpochs::GetTempCovarianceFile(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTempCovarianceFile(). Object NULL or erroneous. \n");
        return UFileName();
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetTempCovarianceFile(). Data not (properly) set.\n");
        return UFileName();
    }
    return GetData()->GetDataFileName().GetSiblingFileName("CovarTT.cov");
}

ErrorType UMEEGDataEpochs::WriteMarkersMM(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersMM(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersMM(). Data not (properly) set.\n");
        return U_ERROR;
    }
    if(Data->GetDataFormatType()!=U_DATFORM_MICROMED)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersMM(). Data of wrong format.\n");
        return U_ERROR;
    }
    const UMarkerArray* Mar = GetMarkerArray();
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersMM(). UMarkerArray NULL or erroneous.\n");
        return U_ERROR;
    }
    if(((UMEEGDataMM*) Data)->WriteMarkers(Mar)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersMM(). Writing markers.\n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMEEGDataEpochs::WriteMarkersCTF(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersCTF(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersCTF(). Data not (properly) set.\n");
        return U_ERROR;
    }
    if(Data->GetDataFormatType()!=U_DATFORM_CTF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersCTF(). Data of wrong format.\n");
        return U_ERROR;
    }
    const UMarkerArray* Mar = GetMarkerArray();
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersCTF(). UMarkerArray NULL or erroneous.\n");
        return U_ERROR;
    }
    UFileName MFile = GetData()->GetDataFileName().GetSiblingFileName("MarkerFile.mrk");

    if(Mar->WriteMarkersCTF(MFile)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersCTF(). Writing markers.\n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMEEGDataEpochs::WriteMarkersTXT(void) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersTXT(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersTXT(). Data not (properly) set.\n");
        return U_ERROR;
    }
    const UMarkerArray* Mar = GetMarkerArray();
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersTXT(). UMarkerArray NULL or erroneous.\n");
        return U_ERROR;
    }
    UFileName MFile = GetData()->GetDataFileName();
    MFile.SetExtension(".mrktxt");

    if(Mar->WriteMarkersTXT(MFile)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMarkersTXT(). Writing markers.\n");
        return U_ERROR;
    }
    return U_OK;
}

const UMarkerArray* UMEEGDataEpochs::GetMarkerArray(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMarkerArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetMarkerArray(). Data not (properly) set. \n");
        return NULL;
    }
    return Data->GetMarkerArray();
}

ErrorType UMEEGDataEpochs::SetMarkerArray(const UMarkerArray* Mar) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetMarkerArray(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar && Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetMarkerArray(). Invalid argument. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetMarkerArray(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SetMarkerArray(Mar);
}
ErrorType UMEEGDataEpochs::ReplaceMarkers(const UMarkerArray* Mar, bool Prepend)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarkers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarkers(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray()==NULL || Data->GetMarkerArray()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarkers(). MarkerArray not (properly) set. \n");
        return U_ERROR;
    }
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarker(). Invalid argument(s). \n");
        return U_ERROR;
    }
    return Data->ReplaceMarkers(Mar, Prepend);
}
ErrorType UMEEGDataEpochs::ReplaceMarker(const UMarker* Mark, int im)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarker(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarker(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray()==NULL || Data->GetMarkerArray()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarker(). MarkerArray not (properly) set. \n");
        return U_ERROR;
    }
    if(Mark==NULL || Mark->GetError()!=U_OK || im<0 || im>=Data->GetMarkerArray()->GetnMarkers())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceMarker(). Invalid argument(s): im=%d. \n", im);
        return U_ERROR;
    }
    return Data->ReplaceMarker(Mark, im);
}
ErrorType UMEEGDataEpochs::AddMarker(const UMarker* Mark)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AddMarker(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AddMarker(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray()==NULL || Data->GetMarkerArray()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AddMarker(). MarkerArray not (properly) set. \n");
        return U_ERROR;
    }
    if(Mark==NULL || Mark->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AddMarker(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    return Data->AddMarker(Mark);
}
ErrorType UMEEGDataEpochs::MergeMarkerArray(const UMarkerArray* Mar)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::MergeMarkerArray(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::MergeMarkerArray(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AddMarker(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    return Data->MergeMarkerArray(Mar);
}


/* Spectra */
UFieldGraph** UMEEGDataEpochs::GetSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool RMS, bool Overlap, bool SubAve, int* NChan, UMapFile** MapMEG, UMapFile** MapEEG, bool AverChanGrp)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }
    int EpoFirst =  0;
    int EpoLast  = -1;
    if(Iepoch>=0)
    {
        if(Iepoch>=Epochs->GetnEpochs())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
            return NULL;
        }
        if(SubAve==true)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Substracting average not compatible with single epoch power spectrum. \n");
            return NULL;
        }
        EpoFirst = EpoLast = Iepoch;
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Epoch times are not constant. \n");
            return NULL;
        }
        if(SubAve==true && Epochs->GetnEpochs()<=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Substracting average not compatible with single epoch power spectrum, Nepochs=%d. \n", Epochs->GetnEpochs());
            return NULL;
        }
        EpoFirst = 0;
        EpoLast  = Epochs->GetnEpochs()-1;
    }
    if(Fdel<=0)
    {
        double     TimeEpoch = Epochs->GetNsamp(EpoFirst) * GetSampleTime_s();
        if(TimeEpoch>0) Fdel = 1./TimeEpoch;
    }
    if(Fmin<0. || Fdel<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Invalid frequencies: Fmin=%f, Fmax=%f, Fdel=%f  \n", Fmin, Fmax, Fdel);
        return NULL;
    }
    if(NChan==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Invalid NULL pointer for NChan. \n");
        return NULL;
    }

/* Get first and average epoch */
    UMultiChan*  MC0  = NULL;
    UMultiChan*  MCAv = NULL;
    for(int Epo=EpoFirst; Epo<=EpoLast; Epo++)
    {
        UMultiChan*  MC  = GetFilteredMultiChanAllTypes(Epo, U_DAT_MEGREF);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete MC;   MC   = NULL;
            delete MCAv; MCAv = NULL;
            delete MC0;  MC0  = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Getting data epoch, Epo = %d . \n", Epo);
            return NULL;
        }
        if(Epo==EpoFirst)
        {
            if(SubAve==true)
            {
                MCAv = new UMultiChan(*MC);
                if(MCAv==NULL || MCAv->GetError()!=U_OK)
                {
                    delete MC;   MC   = NULL;
                    delete MCAv; MCAv = NULL;
                    delete MC0;  MC0  = NULL;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Getting data epoch, Epo = %d . \n", Epo);
                    return NULL;
                }
            }
            MC0  = MC;
            continue;
        }
        if(SubAve==false)
        {
            delete MC;
            break;
        }
        *MCAv += *MC;
        delete MC;
    }
    if(SubAve==true)
    {
        double    Fac = EpoLast-EpoFirst+1;
        if(Fac>0) Fac = 1./Fac;
        *MCAv *= Fac;
    }
    int Nkan  = MC0->GetNChan();
    int Ntime = MC0->GetNtime();

    UFreqBand FB(Fmin, Fmax, Fdel, FBT, Data->GetSampleRate(), Ntime);
    if(FB.GetError()!=U_OK)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Setting UFreqBand-object . \n");
        return NULL;
    }
    int Nband = FB.GetNband();

/* Compute (averaged) spectra */
    double* Spectra = new double[Nkan*Nband];
    if(Spectra==NULL)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Memory allocation . \n");
        return NULL;
    }
    for(int k=0;k<Nkan*Nband; k++) Spectra[k] = 0.;

    ErrorType        E = U_OK;
    if(SubAve==true) E = FB.AddSpectra(MC0->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
    else             E = FB.AddSpectra(MC0->GetData(), NULL           , Nkan, Spectra, RMS);
    int            Nep = 1;
    for(int Epo=EpoFirst+1; Epo<=EpoLast; Epo++)
    {
        if(E!=U_OK) break;

        UMultiChan*  MC1  = GetFilteredMultiChanAllTypes(Epo, U_DAT_MEGREF);
        if(MC1==NULL || MC1->GetError()!=U_OK)
        {
            delete MC1;   MC1   = NULL;
            E = U_ERROR;
            continue;
        }
        if(SubAve==true) E = FB.AddSpectra(MC1->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
        else             E = FB.AddSpectra(MC1->GetData(), NULL           , Nkan, Spectra, RMS);
        Nep++;

        if(Overlap==true)
        {
            if(MC0->MergeCut(*MC1, Ntime/2, Ntime)!=U_OK)
            {
                delete MC1;   MC1   = NULL;
                E = U_ERROR;
                continue;
            }
            if(SubAve==true) E = FB.AddSpectra(MC0->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
            else             E = FB.AddSpectra(MC0->GetData(), NULL           , Nkan, Spectra, RMS);
            Nep++;
        }
        delete MC0;
        MC0 = MC1;

        UString Status = UString(Epo, "Computing spectra. Epoch %d of") + UString(EpoLast-EpoFirst+1, " %d epochs completed.");
        ShowStatus((const char*)Status, Epo, EpoLast-EpoFirst+1);
    }
    delete MCAv;
    if(E!=U_OK || Nep<=0)
    {
        delete MC0;
        delete[] Spectra;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Computing spectra from at least one of the data epochs . \n");
        return NULL;
    }


/* Convert Spectra to UFieldGraph array */
    UField F;
    if(FBT==U_FBAND_FIVE || FBT==U_FBAND_SEVEN)
    {
        double* Freq = FB.GetFrequencies();
        F=UField(Freq, NULL, NULL, &Nband, UField::U_DOUBLE, 1);
        delete[] Freq;

        double factor = 1./Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
            for(int ic=0;ic<Nkan;ic++)  Spectra[ic*Nband+k] *=factor;
    }
    else
    {
        F=UField(float(Fmin+0.5*Fdel), float(Fmin+(Nband-0.5)*Fdel), Nband, UField::U_DOUBLE, 1);

/* Correct for number of epochs and relative bandwidths*/
        double AverBandInd = 0;
        for(int k=0;k<Nband;k++)  AverBandInd += FB.GetNFreq(k);
        AverBandInd /= Nband;

        double factor = AverBandInd/Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
        {
            int width = FB.GetNFreq(k);
            if(width<=0) continue;
            for(int ic=0;ic<Nkan;ic++)  Spectra[ic*Nband+k] *=factor/width;
        }
    }

    UGrid G       = UGrid(*MC0->GetSensorGrid());
    UFieldGraph** FGarr = new UFieldGraph*[Nkan];
    if(G.GetError()==U_OK && FGarr && F.GetError()==U_OK)
    {
        UString SpectText("//Data, Filters and Epochs: \n");
        SpectText += this->GetProperties("//   ")
                   + UString("//Frequency band settings: \n")
                   + FB.GetProperties("//   ");

        switch(FBT)
        {
        case U_FBAND_FIVE : SpectText += UString("//  Bands         = FiveBands  \n"); break;
        case U_FBAND_SEVEN: SpectText += UString("//  Bands         = SevenBands \n"); break;
        case U_FBAND_EVEN : SpectText += UString(Fmin  , "//  Fmin          = %f  \n")
                                       + UString(Fmax  , "//  Fmax          = %f  \n")
                                       + UString(Fdel  , "//  Fdel          = %f  \n"); break;
        }
        if(Iepoch<0)
        {
            SpectText += UString(Epochs->GetNsamp(0)            , "//  NSampEpoch    = %d  \n");
            SpectText += UString(Epochs->GetBegin(0      ).trial, "//  FirstEpStart  = (%d") + UString(Epochs->GetBegin(0      ).sample,",%d)  \n");
            SpectText += UString(Epochs->GetBegin(EpoLast).trial, "//  LastEpStart   = (%d") + UString(Epochs->GetBegin(EpoLast).sample,",%d)  \n");
            if(Epochs->GetDescriptor(0))
                SpectText += UString(Epochs->GetDescriptor(     0), "//  Epoch[0]      = %s  \n");
        }
        else
        {
            SpectText += UString(Iepoch             , "//  Epoch         = %d  \n");
            if(Epochs->GetDescriptor(Iepoch))
                SpectText += UString(Epochs->GetDescriptor(Iepoch), "//  Epoch[ ]      = %s  \n");
        }
        SpectText +=  UString(BoolAsText(SubAve ), "//  SubstractAver = %s  \n")
                   +  UString(BoolAsText(Overlap), "//  OverlapEpochs = %s  \n");
        if(RMS==true) SpectText +=         UString("//  Value         =  RMS \n");
        else          SpectText +=         UString("//  Value         =  Power \n");

        F.SetFileComments((const char*)SpectText);
        for(int ic=0; ic<Nkan; ic++)
        {
            F.SetData(Spectra+ic*Nband);
            USensor S = G.GetSensor(ic);
            FGarr[ic] = new UFieldGraph(&F, UString(S.GetName()), S.Getx(), 0., U_GDAT_FREQ_HZ);
            if(FGarr[ic]==NULL || FGarr[ic]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Converting spectra to graphical objects, ic=%d . \n", ic);
                for(int i=0; i<=ic; i++) delete FGarr[i]; delete[] FGarr;
                return NULL;
            }
        }
    }
    else
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Creating UFieldGraph array. \n");
        delete[] FGarr; FGarr = NULL;
    }
    if(AverChanGrp==true)
    {
        UGrid Gaver = G;
        const UGroup* Grp = Gaver.GetGroup();
        if(Gaver.PutSensorTypesInDifferentGroups()!=U_OK || Grp==NULL || Grp->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Putting sensors in different groups. \n");
            for(int i=0; i<Nkan; i++) delete FGarr[i]; delete[] FGarr;
            return NULL;
        }
        int NkanGrp = Grp->GetNGroup();
        UFieldGraph** FGarrGrp = new UFieldGraph*[NkanGrp];
        if(FGarrGrp==NULL)
        {
            for(int i=0; i<Nkan; i++) delete FGarr[i]; delete[] FGarr;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Putting sensors in different groups. (NkanGrp=%d) \n", NkanGrp);
            return NULL;
        }
        F.SetDataDouble(0.);
        UString Comments(F.GetFileComments());
        for(int ig=0; ig<NkanGrp; ig++)
        {
            UString ComGrp = Comments + UString("Group Elements: \n") + Grp->GetGroupLabels(ig) + UString("\n");
            F.SetFileComments((const char*) ComGrp);

            USensor S = Gaver.GetSensor(Grp->GetElem(ig, 0));
            FGarrGrp[ig] = new UFieldGraph(&F, UString(S.GetName()), S.Getx(), 0., U_GDAT_FREQ_HZ);
            if(FGarrGrp[ig]==NULL || FGarrGrp[ig]->GetError()!=U_OK)
            {
                for(int i=0; i<Nkan; i++) delete FGarr   [i]; delete[] FGarr;
                for(int i=0; i<ig  ; i++) delete FGarrGrp[i]; delete[] FGarrGrp;
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Initializing spectrum of group %d . \n", ig);
                return NULL;
            }
            int Nel = Grp->GetNElem(ig);
            for(int el=0; el<Nel; el++)
                *(FGarrGrp[ig]) += *(FGarr[Grp->GetElem(ig, el)]);
            if(Nel) *(FGarrGrp[ig]) *= (1./Nel);
        }
        for(int i=0; i<Nkan; i++) delete FGarr   [i]; delete[] FGarr;
        FGarr = FGarrGrp;
        if(NChan) *NChan = NkanGrp;
    }
    else
        if(NChan) *NChan = Nkan;

/* Convert MEG Spectra to UMapFile */
    if(MapMEG)
    {
        *MapMEG = NULL;
        const UGrid* GrMEG = Data->GetGridMEG();
        if(InterpolateCTF==true) GrMEG = Data->GetCTFInterpolation()->GetGridTo();

        if(GrMEG==NULL || GrMEG->GetError()!=U_OK || GrMEG->GetNpoints()<=0)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::GetSpectra(). No MEG sensors available. \n");
        }
        else
        {
            *MapMEG            = new UMapFile(GrMEG, Nband, "MEG Spectra");
            char*   Labels     = new char[40*Nband];
            char**  pLabels    = new char*[Nband];
            double* SpectraMEG = new double[GrMEG->GetNpoints()*Nband];
            if(!Labels || !pLabels || MapMEG==NULL || SpectraMEG==NULL)
            {
                CI.AddToLog("WARNING: UMEEGDataEpochs::GetSpectra(). Memory allocation creating MEG spectra maps.\n");
                delete[] Labels;
                delete[] pLabels;
                delete[] SpectraMEG;
                delete   MapMEG; *MapMEG = NULL;
            }
            else
            {
                for(int ij=0; ij<GrMEG->GetNpoints()*Nband; ij++) SpectraMEG[ij] = 0.;
                for(int k=0; k<Nband; k++)
                {
                    sprintf(Labels+k*40,"%7.2f-%7.2f Hz",FB.GetLowBand(k),FB.GetHighBand(k));
                    pLabels[k] = Labels+k*40;
                }
                for(int i=0, iMEG=0; i<Nkan&&iMEG<GrMEG->GetNpoints(); i++)
                    if(G.GetSensor(i) == GrMEG->GetSensor(iMEG) )
                    {
                        for(int j=0; j<Nband; j++) SpectraMEG[iMEG*Nband+j] = Spectra[i*Nband+j];
                        iMEG++;
                    }

                (*MapMEG)->SetMapLabels(pLabels);
                (*MapMEG)->SetData(SpectraMEG, false);
            }
            delete[] Labels;
            delete[] pLabels;
            delete[] SpectraMEG;
        }
    }

/* Convert EEG Spectra to UMapFile */
    if(MapEEG)
    {
        *MapEEG = NULL;
        const UGrid* GrEEG = Data->GetGridEEG();
        if(GrEEG==NULL || GrEEG->GetError()!=U_OK || GrEEG->GetNpoints()<=0)
        {
            CI.AddToLog("WARNING: UMEEGDataEpochs::GetSpectra(). No EEG sensors available. \n");
        }
        else
        {
            *MapEEG            = new UMapFile(GrEEG, Nband, "EEG Spectra");
            char*   Labels     = new char[40*Nband];
            char**  pLabels    = new char*[Nband];
            double* SpectraEEG = new double[GrEEG->GetNpoints()*Nband];
            if(!Labels || !pLabels || MapEEG==NULL || SpectraEEG==NULL)
            {
                CI.AddToLog("WARNING: UMEEGDataEpochs::GetSpectra(). Memory allocation creating EEG spectra maps.\n");
                delete[] Labels;
                delete[] pLabels;
                delete[] SpectraEEG;
                delete   MapEEG; *MapEEG = NULL;
            }
            else
            {
                for(int ij=0; ij<GrEEG->GetNpoints()*Nband; ij++) SpectraEEG[ij] = 0.;
                for(int k=0; k<Nband; k++)
                {
                    sprintf(Labels+k*40,"%7.2f-%7.2f Hz",FB.GetLowBand(k),FB.GetHighBand(k));
                    pLabels[k] = Labels+k*40;
                }
                for(int i=0, iEEG=0; i<Nkan&&iEEG<GrEEG->GetNpoints(); i++)
                    if(G.GetSensor(i) == GrEEG->GetSensor(iEEG))
                    {
                        for(int j=0; j<Nband; j++) SpectraEEG[iEEG*Nband+j] = Spectra[i*Nband+j];
                        iEEG++;
                    }

                (*MapEEG)->SetMapLabels(pLabels);
                (*MapEEG)->SetData(SpectraEEG, false);
            }
            delete[] Labels;
            delete[] pLabels;
            delete[] SpectraEEG;
        }
    }

    delete[] Spectra;
    delete MC0;
    if(FGarr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectra(). Converting spectra to graphical objects. \n");
        return NULL;
    }
    return FGarr;
}

UMapFile* UMEEGDataEpochs::GetInterpolatedMEGSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool RMS, bool Overlap, bool SubAve, const UInterpolateSensors* Inter)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Function not compatible with InterpolateCTF==true. \n");
        return NULL;
    }
    int EpoFirst =  0;
    int EpoLast  = -1;
    if(Iepoch>=0)
    {
        if(Iepoch>=Epochs->GetnEpochs())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
            return NULL;
        }
        if(SubAve==true)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Substracting average not compatible with single epoch power spectrum. \n");
            return NULL;
        }
        EpoFirst = EpoLast = Iepoch;
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Epoch times are not constant. \n");
            return NULL;
        }
        if(SubAve==true && Epochs->GetnEpochs()<=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Substracting average not compatible with single epoch power spectrum, Nepochs=%d. \n", Epochs->GetnEpochs());
            return NULL;
        }
        EpoFirst = 0;
        EpoLast  = Epochs->GetnEpochs()-1;
    }
    if(Fdel<=0)
    {
        double     TimeEpoch = Epochs->GetNsamp(EpoFirst) * GetSampleTime_s();
        if(TimeEpoch>0) Fdel = 1./TimeEpoch;
    }
    if(Fmin<0. || Fdel<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Invalid frequencies: Fmin=%f, Fmax=%f, Fdel=%f  \n", Fmin, Fmax, Fdel);
        return NULL;
    }
    if(Inter && Inter->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Erroneous sensor interpolation object. \n");
        return NULL;
    }

/* Get first and average epoch */
    UMultiChan*  MC0  = NULL;
    UMultiChan*  MCAv = NULL;
    for(int Epo=EpoFirst; Epo<=EpoLast; Epo++)
    {
        UMultiChan*  MC  = GetFilteredMultiChanMEG(Epo, Inter);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete MC;   MC   = NULL;
            delete MCAv; MCAv = NULL;
            delete MC0;  MC0  = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Getting data epoch, Epo = %d . \n", Epo);
            return NULL;
        }
        if(Epo==EpoFirst)
        {
            if(SubAve==true)
            {
                MCAv = new UMultiChan(*MC);
                if(MCAv==NULL || MCAv->GetError()!=U_OK)
                {
                    delete MC;   MC   = NULL;
                    delete MCAv; MCAv = NULL;
                    delete MC0;  MC0  = NULL;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Getting data epoch, Epo = %d . \n", Epo);
                    return NULL;
                }
            }
            MC0  = MC;
            continue;
        }
        if(SubAve==false)
        {
            delete MC;
            break;
        }
        *MCAv += *MC;
        delete MC;
    }
    if(SubAve==true)
    {
        double    Fac = EpoLast-EpoFirst+1;
        if(Fac>0) Fac = 1./Fac;
        *MCAv *= Fac;
    }
    int Nkan  = MC0->GetNChan();
    int Ntime = MC0->GetNtime();

    UFreqBand FB(Fmin, Fmax, Fdel, FBT, Data->GetSampleRate(), Ntime);
    if(FB.GetError()!=U_OK)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Setting UFreqBand-object . \n");
        return NULL;
    }
    int Nband = FB.GetNband();

/* Compute (averaged) spectra */
    double* Spectra = new double[Nkan*Nband];
    if(Spectra==NULL)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Memory allocation . \n");
        return NULL;
    }
    for(int k=0;k<Nkan*Nband; k++) Spectra[k] = 0.;

    ErrorType        E = U_OK;
    if(SubAve==true) E = FB.AddSpectra(MC0->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
    else             E = FB.AddSpectra(MC0->GetData(), NULL           , Nkan, Spectra, RMS);
    int            Nep = 1;
    for(int Epo=EpoFirst+1; Epo<=EpoLast; Epo++)
    {
        if(E!=U_OK) break;

        UMultiChan*  MC1  = GetFilteredMultiChanMEG(Epo, Inter);
        if(MC1==NULL || MC1->GetError()!=U_OK)
        {
            delete MC1;   MC1   = NULL;
            E = U_ERROR;
            continue;
        }
        if(SubAve==true) E = FB.AddSpectra(MC1->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
        else             E = FB.AddSpectra(MC1->GetData(), NULL           , Nkan, Spectra, RMS);
        Nep++;

        if(Overlap==true)
        {
            if(MC0->MergeCut(*MC1, Ntime/2, Ntime)!=U_OK)
            {
                delete MC1;   MC1   = NULL;
                E = U_ERROR;
                continue;
            }
            if(SubAve==true) E = FB.AddSpectra(MC0->GetData(), MCAv->GetData(), Nkan, Spectra, RMS);
            else             E = FB.AddSpectra(MC0->GetData(), NULL           , Nkan, Spectra, RMS);
            Nep++;
        }
        delete MC0;
        MC0 = MC1;

        UString Status = UString(Epo, "Computing spectra. Epoch %d of") + UString(EpoLast-EpoFirst+1, " %d epochs completed.");
        ShowStatus((const char*)Status, Epo, EpoLast-EpoFirst+1);
    }
    delete MCAv;
    delete MC0;
    if(E!=U_OK || Nep<=0)
    {
        delete[] Spectra;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Computing spectra from at least one of the data epochs . \n");
        return NULL;
    }

/* Correct for number of epochs and relative bandwidths*/
    if(FBT==U_FBAND_FIVE || FBT==U_FBAND_SEVEN)
    {
        double factor = 1./Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
            for(int ic=0;ic<Nkan;ic++)  Spectra[ic*Nband+k] *=factor;
    }
    else
    {
        double AverBandInd = 0;
        for(int k=0;k<Nband;k++)  AverBandInd += FB.GetNFreq(k);
        AverBandInd /= Nband;

        double factor = AverBandInd/Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
        {
            int width = FB.GetNFreq(k);
            if(width<=0) continue;
            for(int ic=0;ic<Nkan;ic++)  Spectra[ic*Nband+k] *=factor/width;
        }
    }

/* Convert Spectra to UMapFile */
    const UGrid* GrMEG   = Inter->GetGridTo();
    UMapFile*    MapMEG  = new UMapFile(GrMEG, Nband, "MEG Spectra");
    char*        Labels  = new char[40*Nband];
    char**       pLabels = new char*[Nband];
    if(!Labels || !pLabels || MapMEG==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetInterpolatedMEGSpectra(). Memory allocation creating MEG spectra maps.\n");
        delete[] Labels;
        delete[] pLabels;
        delete   MapMEG;
        return   NULL;
    }
    for(int k=0; k<Nband; k++)
    {
        sprintf(Labels+k*40,"%7.2f-%7.2f Hz",FB.GetLowBand(k),FB.GetHighBand(k));
        pLabels[k] = Labels+k*40;
    }

    MapMEG ->SetMapLabels(pLabels);
    MapMEG ->SetData(Spectra, false);

    delete[] Labels;
    delete[] pLabels;
    delete[] Spectra;
    return MapMEG;
}

UField** UMEEGDataEpochs::GetWaveletTransformAsFieldArray(double Fmin, double Fdel, double Fmax, DataType Dtype, bool RMS, int Iepoch, bool SubAve, int* NSpect, UMapFile** MapData, bool AverChanGrp, int WavelOrder)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Epochs have difference sizes.\n");
        return NULL;
    }
    if(Fmin<0 || Fmin>=Fmax)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Frequency range invalid: Fmin=%f, Fmax = %f .  \n", Fmin, Fmax);
        return NULL;
    }
    if(Fdel<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Frequency step invalid: Fdel=%f .  \n", Fdel);
        return NULL;
    }
    if(NSpect==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Invalid NULL pointer for NChan. \n");
        return NULL;
    }
    else *NSpect=0;

    int Nkan  = Data->GetNkan(Dtype);
    if(Dtype==U_DAT_MEG && InterpolateCTF==true)
        Nkan = Data->GetCTFInterpolation()->GetGridTo()->GetNpoints();
    if(Data->GetNkan(Dtype)<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). No data op type %s is present. \n", UMEEGDataBase::GetDataTypeText(Dtype));
        return NULL;
    }
    if(Dtype!=U_DAT_MEG && Dtype!=U_DAT_EEG && MapData)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). MapData can only be computed for EEG or MEG data. \n");
        return NULL;
    }
    if(MapData)    *MapData    = NULL;

    UField** FSpectArr = new UField*[Nkan];
    if(FSpectArr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Creating output array.. \n");
        return NULL;
    }
    for(int i=0; i<Nkan; i++) FSpectArr[i] = new UField();

    int nEp          = Epochs->GetnEpochs();
    int iepStart     = 0;
    int iepEnd       = nEp-1;
    UMultiChan* MCAv = NULL;
    if(SubAve==true) /* Compute average epoch */
    {
        if(Iepoch>=0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Invalid arguments (substract average, and computing WL-transform for specific epoch: %d). \n", Iepoch);
            return NULL;
        }
        MCAv = GetAveragedFilteredMultiChan(Dtype);
        if(MCAv==NULL || MCAv->GetError()!=U_OK)
        {
            delete MCAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Initializing average. \n");
            return NULL;
        }
    }
    else
    {
        if(Iepoch<0 || Iepoch>=nEp)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Invalid epoch number (Iepoch= %d). \n", Iepoch);
            return NULL;
        }
        iepStart = iepEnd = Iepoch;
    }

/* Initialize Wavelet object*/
    int Nsamp = Epochs->GetNsamp(0);
    UWaveletTransform W(WavelOrder, SampleTime_s, Nsamp, Fmin, Fdel, Fmax);
    if(W.GetError()!=U_OK)
    {
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Creating UWaveletTransform-object. \n");
        return NULL;
    }

    const int SubFactor = 1;
    for(int iep=iepStart; iep<=iepEnd; iep++)
    {
        UMultiChan*    MC   =  GetFilteredMultiChan(iep, Dtype, -1);
        if(MCAv && MC)*MC  -= *MCAv;
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete MCAv;
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Getting data from epoch %d. \n", iep);
            return NULL;
        }
        UField** FSpectArrIep = MC->GetMorletWaveletTransformArray(W, SubFactor, NULL);
        delete MC;
        if(FSpectArrIep==NULL)
        {
            delete MCAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Computing WL-transform for epoch %d. \n", iep);
            return NULL;
        }
        for(int i=0; i<Nkan; i++)
        {
            *(FSpectArr[i]) += *(FSpectArrIep[i]);
            delete FSpectArrIep[i];
        }
        delete[] FSpectArrIep;

        UString Status = UString(iep, "Computing WL-transform. Epoch %d of") + UString(nEp, " %d epochs completed.");
        ShowStatus((const char*)Status, iep, nEp);
    }
    delete MCAv;

    if(RMS==true) for(int i=0; i<Nkan; i++) FSpectArr[i]->SquareRoot();

    if(MapData) /* Compute UMapFile object */
    {
        const UGrid* Grid = Data->GetGrid(Dtype);
        if(Dtype==U_DAT_MEG && InterpolateCTF==true)
            Grid = Data->GetCTFInterpolation()->GetGridTo();

        *MapData = new UMapFile(Grid, FSpectArr, "s", "Hz", "WL-transform");
        if(*MapData==NULL || (*MapData)->GetError()!=U_OK)
        {
            delete *MapData; *MapData=NULL;
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;

            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Creating UMapFile-object. \n");
            return NULL;
        }
    }

    if(AverChanGrp==true)
    {
        const UGrid* Grid = Data->GetGrid(Dtype);
        if(Dtype==U_DAT_MEG && InterpolateCTF==true)
            Grid = Data->GetCTFInterpolation()->GetGridTo();
        if(AverageTimeFreqPlots(&FSpectArr, Grid, NSpect)!=U_OK)
        {
            if(MapData) {delete *MapData; *MapData=NULL;}
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetWaveletTransformAsFieldArray(). Averaging spectrograms over channels channels. \n");
            return NULL;
        }
    }
    else
        if(NSpect) *NSpect = Nkan;

    return FSpectArr;
}

UField** UMEEGDataEpochs::GetSpectrogramAsFieldArray(double Fmin, double Fmax,  DataType Dtype, bool RMS, bool Overlap, bool SubAve, int* NSpect, UMapFile** MapData, int** AbsSamples, bool AverChanGrp, int NsubWindows, double FracOver, bool AverEpoch)
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Epochs have difference sizes.\n");
        return NULL;
    }
    if(Fmin<0 || Fmin>=Fmax)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Frequency range invalid: Fmin=%f, Fmax = %f .  \n", Fmin, Fmax);
        return NULL;
    }
    if(NSpect==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Invalid NULL pointer for NChan. \n");
        return NULL;
    }
    else *NSpect=0;

    int Nkan = Data->GetNkan(Dtype);
    if(Dtype==U_DAT_MEG && InterpolateCTF==true)
        Nkan = Data->GetCTFInterpolation()->GetGridTo()->GetNpoints();
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). No data op type %s is present. \n", UMEEGDataBase::GetDataTypeText(Dtype));
        return NULL;
    }
    if(Dtype!=U_DAT_EEG && Dtype!=U_DAT_MEG && MapData)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). MapData can only be computed for EEG or MEG data. \n");
        return NULL;
    }
    if(MapData)    *MapData    = NULL;
    if(AbsSamples) *AbsSamples = NULL;

    int  nTimeEpo    = Epochs->GetNsamp(0);
    int  nEp         = Epochs->GetnEpochs();
    bool ApplySubWin = (NsubWindows>1);
    if(ApplySubWin==true)
    {
        if(FracOver<0 || FracOver>=1.)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Subwindows: FracOver (=%f) out of range. \n", FracOver);
            return NULL;
        }
        if(NsubWindows>nTimeEpo/2)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Subwindows: NsubWindows (=%d) out of range. \n", NsubWindows);
            return NULL;
        }
        if(Overlap==true)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Subwindows is set. This cannot be combined with overlapping epochs,.\n");
            return NULL;
        }
    }
    else
    {
        NsubWindows = 1;
    }

/* Compute average epoch */
    UMultiChan*  MCAv = NULL;

    if(SubAve==true)
    {
        MCAv = GetAveragedFilteredMultiChan(Dtype);
        if(MCAv==NULL || MCAv->GetError()!=U_OK)
        {
            delete MCAv;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Initializing average. \n");
            return NULL;
        }
    }

/* Set output array */
    int      NTimes    = nEp;
    int      NsampSub  = nTimeEpo;
    if(ApplySubWin==true)
    {
        NsampSub  = int( nTimeEpo/(NsubWindows - NsubWindows*FracOver + FracOver) );

        if(AverEpoch) NTimes = NsubWindows;
        else          NTimes = NsubWindows * nEp;
    }
    int      Npower    = NsampSub/2 + 1;
    double*  Times     = new double [NTimes];
    double*  Freqs     = new double [Npower];
    UField** FSpectArr = new UField*[Nkan];
    if(Times==NULL || Freqs==NULL || FSpectArr==NULL)
    {
        delete[] Times;
        delete[] Freqs;
        delete[] FSpectArr;
        delete   MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Memory allocation NTimes=%d, Npower=%d, Nkan=%d .\n", NTimes, Npower, Nkan);
        return NULL;
    }
    if(AbsSamples) 
    {
        *AbsSamples = new int[NTimes];
        if(*AbsSamples==NULL)
            CI.AddToLog("WARNING: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Memory allocation NTimes=%d for AbsSamples.\n", NTimes);
    }
    int Fmindex = 0;
    int Fmaxdex = Npower-1;
    if(ApplySubWin==true)
    {
        if(AverEpoch) for(int k=0; k<NTimes; k++)  Times[k] =                           k            *(NsampSub-NsampSub*FracOver) *SampleTime_s - GetPreTriggerTime_s();
        else          for(int k=0; k<NTimes; k++)  Times[k] = (k*nTimeEpo/NsubWindows + k%NsubWindows*(NsampSub-NsampSub*FracOver))*SampleTime_s;
    }
    else
    {
        for(int k=0; k<NTimes; k++)   Times[k] = Epochs->GetBeginSample(k)*SampleTime_s;
    }
    if(AbsSamples && *AbsSamples)
    {
        if(ApplySubWin==true)
        {
            if(AverEpoch) for(int k=0; k<NTimes; k++)  (*AbsSamples)[k] = int(                          k            *(NsampSub-NsampSub*FracOver)  - GetNPreTriggerSamples());
            else          for(int k=0; k<NTimes; k++)  (*AbsSamples)[k] = int((k*nTimeEpo/NsubWindows + k%NsubWindows*(NsampSub-NsampSub*FracOver))                          );
        }
        else
        {
            for(int k=0; k<NTimes; k++)  (*AbsSamples)[k] = Epochs->GetBeginSample(k);
        }
    }
    for(int k=0; k<Npower; k++)
    {
        Freqs[k] = Data->GetSampleRate()*(k+.5)/(2*Npower); // Center frequency
        if(Freqs[k]<Fmin) Fmindex = k;
        if(Freqs[k]<Fmax) Fmaxdex = k+1;
    }
    Fmaxdex     = MIN(Fmaxdex, (Npower-1));
    int Nfreq   = Fmaxdex-Fmindex;
    int Dims[2] = {NTimes, Nfreq};
    for(int i=0; i<Nkan; i++) FSpectArr[i]=NULL;
    for(int i=0; i<Nkan; i++)
    {
        FSpectArr[i] = new UField(Times, Freqs+Fmindex, NULL, Dims, UField::U_DOUBLE, 1);
        if(FSpectArr[i]==NULL || FSpectArr[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Creating empty UField for channel %d . \n",i);
            for(int ii=0; ii<Nkan; ii++) delete FSpectArr[ii];
            delete[] FSpectArr; FSpectArr=NULL;
            if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
            break;
        }
        UString SpectText = this->GetProperties("//  ");
        SpectText        += UString(Fmin               ,  "//   Fmin          = %f  \n")
                         +  UString(Fmax               ,  "//   Fmax          = %f  \n")
                         +  UString(BoolAsText(SubAve ),  "//   SubstractAver = %s  \n")
                         +  UString(BoolAsText(Overlap),  "//   OverlapEpochs = %s  \n");
        if(RMS==true)               SpectText +=  UString("//   Value         =  RMS\n");
        else                        SpectText +=  UString("//   Value         =  Power\n");
        SpectText    += UString(BoolAsText(ApplySubWin),  "//   SubWindows    =  %s  \n");
        if(ApplySubWin==true)
        {
            SpectText +=    UString(NsubWindows,          "//   NsubWindows   =  %d  \n");
            SpectText +=    UString(NsampSub,             "//   NsampSub      =  %d  \n");
            SpectText +=    UString(FracOver   ,          "//   FracOver      =  %f  \n");
            SpectText +=    UString(BoolAsText(AverEpoch),"//   AverEpoch     =  %s  \n");
        }
        FSpectArr[i]->SetFileComments((const char*)SpectText);
    }
    delete[] Times;
    delete[] Freqs;
    if(FSpectArr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Creating empty field array. \n");
        delete MCAv;
        if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
        return NULL;
    }
    for(int i=0; i<Nkan; i++) FSpectArr[i]->SetDataDouble(0.);

/* Compute spectra as a function of epoch*/
    UMultiChan* M0   = GetFilteredMultiChan(0, Dtype, -1);
    if(MCAv)   *M0  -= *MCAv;
    for(int iep=0; iep<nEp ; iep++)
    {
        UMultiChan*  M1 = M0;
        if(iep>0)    M1 = GetFilteredMultiChan(iep, Dtype, -1);
        if(M1==NULL || M1->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Getting UMultiChan() data from epoch %d . \n",iep);
            delete MCAv;
            delete M0;  if(iep>0) delete M1;
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
            if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
            return NULL;
        }
        if(MCAv) *M1  -= *MCAv;
        int      nChan = 0;
        UField** pFarr = M1->GetSpectrogramArray2(NsampSub, NsubWindows, &nChan, U_WIN_BLOCK, Filt.GetPreProType());
        if(pFarr==NULL || pFarr[0]==NULL             || pFarr[0]->GetError()!=U_OK ||
           nChan!=Nkan || pFarr[0]->GetDdata()==NULL || Npower!=pFarr[0]->GetDimensions(1))
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Getting Spectra from epoch %d .\n",iep);
            if(pFarr) for(int k=0; k<nChan; k++) delete pFarr[k]; delete[] pFarr;
            delete MCAv;
            delete M0;  if(iep>0) delete M1;
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
            if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
            return NULL;
        }

        double Weight = 1.;
        if(Overlap==true) {if(iep==0 || iep==nEp-1) Weight = 2./3.;
                           else                     Weight = 0.5;}

        for(int i=0; i<Nkan; i++)
        {
            if(ApplySubWin==true)
            {
                if(AverEpoch==true)
                {
                    for(int jf=0; jf<Nfreq ; jf++)
                        for(int j=0; j<NsubWindows; j++ )
                            FSpectArr[i]->GetDdata()[jf*NsubWindows+j] += pFarr[i]->GetDdata()[(jf+Fmindex)*NsubWindows+j]/(2*nEp);
                }
                else
                {
                    for(int jf=0; jf<Nfreq ; jf++)
                        for(int j=0; j<NsubWindows; j++ )
                            FSpectArr[i]->GetDdata()[jf*NTimes+iep*NsubWindows+j] += pFarr[i]->GetDdata()[(jf+Fmindex)*NsubWindows+j]/(2*nEp);
                }
            }
            else
            {
                for(int jf=0; jf<Nfreq; jf++)
                    FSpectArr[i]->GetDdata()[jf*nEp+iep] += Weight*pFarr[i]->GetDdata()[jf+Fmindex]/2;
            }
            delete pFarr[i];
        }
        delete[] pFarr; pFarr = NULL;

        if(Overlap==true && iep>0 && ApplySubWin==false)
        {
            if(M0->MergeCut(*M1, nTimeEpo/2, nTimeEpo)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Merging UMultiChans in epoch %d .\n",iep);
                delete MCAv;
                delete M0;  if(iep>0) delete M1;
                for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
                if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
                return NULL;
            }
            if(MCAv) *M0  -= *MCAv;
                     pFarr = M0->GetSpectrogramArray(nTimeEpo, 1, NULL, U_WIN_BLOCK, Filt.GetPreProType());
            if(pFarr==NULL || pFarr[0]==NULL             || pFarr[0]->GetError()!=U_OK ||
                              pFarr[0]->GetDdata()==NULL || Npower!=pFarr[0]->GetDimensions(1))
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Getting Spectra from (merged) epoch %d .\n",iep);
                if(pFarr) for(int k=0; k<nChan; k++) delete pFarr[k]; delete[] pFarr;
                delete MCAv;
                delete M0;  if(iep>0) delete M1;
                for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
                if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
                return NULL;
            }
            double W0 = 0.25, W1 = 0.25;
            if(iep==1    ) W0 = 1./3.;
            if(iep==nEp-1) W1 = 1./3.;

            for(int i=0; i<Nkan; i++)
            {
                for(int jf=0; jf<Nfreq; jf++)
                    FSpectArr[i]->GetDdata()[jf*nEp+iep-1] += W0*pFarr[i]->GetDdata()[jf+Fmindex]/2;
                for(int jf=0; jf<Nfreq; jf++)
                    FSpectArr[i]->GetDdata()[jf*nEp+iep  ] += W1*pFarr[i]->GetDdata()[jf+Fmindex]/2;
                delete pFarr[i];
            }
            delete[] pFarr;
        }
        if(iep>0) delete M0;
        M0 = M1;

        UString Status = UString(iep, "Computing spectrogram. Epoch %d of") + UString(nEp, " %d epochs completed.");
        ShowStatus((const char*)Status, iep, nEp);
    }
    delete MCAv;
    delete M0;

    if(RMS==true) for(int i=0; i<Nkan; i++) FSpectArr[i]->SquareRoot();

    if(MapData) /* Compute UMapFile object */
    {
        const UGrid* Grid = Data->GetGrid(Dtype);
        if(Dtype==U_DAT_MEG && InterpolateCTF==true)
            Grid = Data->GetCTFInterpolation()->GetGridTo();
        *MapData = new UMapFile(Grid, FSpectArr, "s", "Hz", "Spectrogram");
        if(*MapData==NULL || (*MapData)->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Creating UMapFile-object. \n");
            delete *MapData; *MapData=NULL;
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
            if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}

            return NULL;
        }
    }

    if(AverChanGrp==true)
    {
        const UGrid* Grid = Data->GetGrid(Dtype);
        if(Dtype==U_DAT_MEG && InterpolateCTF==true)
            Grid = Data->GetCTFInterpolation()->GetGridTo();

        if(AverageTimeFreqPlots(&FSpectArr, Grid, NSpect)!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSpectrogramAsFieldArray(). Averaging spectrograms over channels channels. \n");
            if(MapData) {delete *MapData; *MapData=NULL;}
            for(int i=0; i<Nkan; i++) delete FSpectArr[i]; delete[] FSpectArr;
            if(AbsSamples) {delete[] *AbsSamples; *AbsSamples=NULL;}
            return NULL;
        }
    }
    else
        if(NSpect) *NSpect = Nkan;

    return FSpectArr;
}

ErrorType UMEEGDataEpochs::AverageTimeFreqPlots(UField*** FSpectArr, const UGrid* Grid, int *NSpect) const
{
    if(this==NULL || error!=U_OK || Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Object NULL or erroneously set. \n");
        return U_ERROR;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Function not compatible with ComputeHilbertXfm==true. \n");
        return U_ERROR;
    }
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). NULL or erroneous UGrid argument. \n");
        return U_ERROR;
    }
    int Nkan = Grid->GetNpoints();
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Number of sensors of UGrid object is invalid (Nkan=%d). \n", Nkan);
        return U_ERROR;
    }
    if(FSpectArr==NULL || *FSpectArr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Erroneously NULL argument. \n");
        return U_ERROR;
    }
    for(int i=0; i<Nkan; i++)
    {
        if((*FSpectArr)[i]==NULL || (*FSpectArr)[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Erroneously NULL argument (UField -object %d). \n", i);
            return U_ERROR;
        }
        if((*FSpectArr)[i]->IsGeometryCompatible((*FSpectArr)[0])==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Geometry of element %d not compatible with first one. \n", i);
            return U_ERROR;
        }
    }

    const UGroup*  Grp = Grid->GetGroup();
    int NkanGrp = 1;
    if(Grp)    NkanGrp = Grp ->GetNGroup();
    else       CI.AddToLog("WARNING: UMEEGDataEpochs::AverageTimeFreqPlots(). No Group information found. Average over all available channels. \n");

    UField** FGarrGrp = new UField*[NkanGrp];
    if(FGarrGrp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Memory allocation. (NkanGrp=%d) \n", NkanGrp);
        return U_ERROR;
    }
    for(int ig=0; ig<NkanGrp; ig++) FGarrGrp[ig] = NULL;

    UString Comments((*FSpectArr)[0]->GetFileComments());
    for(int ig=0; ig<NkanGrp; ig++)
    {
        FGarrGrp[ig]   = new UField(*((*FSpectArr)[0]));
        if(FGarrGrp[ig]==NULL || FGarrGrp[ig]->GetError()!=U_OK)
        {
            for(int i=0; i<NkanGrp; i++) delete FGarrGrp[i];  delete[] FGarrGrp;
            CI.AddToLog("ERROR: UMEEGDataEpochs::AverageTimeFreqPlots(). Initializing spectrum of group %d . \n", ig);
            return U_ERROR;
        }
        if(Grp)
        {
            int Nel = Grp->GetNElem(ig);
            for(int el=0; el<Nel; el++)
                *(FGarrGrp[ig]) += *((*FSpectArr)[Grp->GetElem(ig, el)]);
            if(Nel) *(FGarrGrp[ig]) *= (1./Nel);

            UString ComGrp = Comments + UString("Group Elements: \n") + Grp->GetGroupLabels(ig) + UString("\n");
            FGarrGrp[ig]->SetFileComments((const char*)ComGrp);
        }
        else
        {
            for(int el=0; el<Nkan; el++)
                *(FGarrGrp[ig]) += *((*FSpectArr)[el]);
            if(Nkan) *(FGarrGrp[ig]) *= (1./Nkan);

            UString ComGrp = Comments + UString("Averaged over all channels. \n");
            FGarrGrp[ig]->SetFileComments((const char*)ComGrp);
        }
    }
    for(int i=0; i<Nkan; i++) delete (*FSpectArr)[i]; delete[] (*FSpectArr);
    *FSpectArr = FGarrGrp;
    if(NSpect) *NSpect = NkanGrp;

    return U_OK;
}
USensorCorrelate* UMEEGDataEpochs::GetCrossSpectrum(double Fmin, double Fmax, int Iepoch, bool Overlap, bool SubAve, DataType DType)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectrum(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectrum(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectrum(). Data or Epochs not set. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectrum(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }

    int          NBand = 0;
    FreqBandType FBT   = U_FBAND_EVEN;
    USensorCorrelate** CrSpArray = GetCrossSpectra(Fmin, Fmax, Fmax-Fmin, FBT, Iepoch, Overlap, SubAve, &NBand, DType);
    if(CrSpArray==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectrum(). Computing cross spectra. \n");
        return NULL;
    }
    USensorCorrelate* CrSp = CrSpArray[0];
    delete[] CrSpArray;
    return CrSp;
}
USensorCorrelate** UMEEGDataEpochs::GetCrossSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool Overlap, bool SubAve, int* NBand, DataType DType)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }
    int EpoFirst =  0;
    int EpoLast  = -1;
    if(Iepoch>=0)
    {
        if(Iepoch>=Epochs->GetnEpochs())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
            return NULL;
        }
        if(SubAve==true)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Substracting average not compatible with single epoch power spectrum. \n");
            return NULL;
        }
        EpoFirst = EpoLast = Iepoch;
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Epoch times are not constant. \n");
            return NULL;
        }
        if(SubAve==true && Epochs->GetnEpochs()<=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Substracting average not compatible with single epoch power spectrum, Nepochs=%d. \n", Epochs->GetnEpochs());
            return NULL;
        }
        EpoFirst = 0;
        EpoLast  = Epochs->GetnEpochs()-1;
    }
    if(FBT!=U_FBAND_FIVE && FBT!=U_FBAND_SEVEN)
    {
        if(Fmin<0. || Fdel<=0.)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Invalid frequencies: Fmin=%f, Fmax=%f, Fdel=%f  \n", Fmin, Fmax, Fdel);
            return NULL;
        }
    }
    if(NBand==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Invalid NULL pointer for NBand. \n");
        return NULL;
    }

/* Get first and average epoch */
    UMultiChan*  MC0  = NULL;
    UMultiChan*  MCAv = NULL;
    for(int Epo=EpoFirst; Epo<=EpoLast; Epo++)
    {
        UMultiChan*  MC  = GetFilteredMultiChan(Epo, DType);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete MC;   MC   = NULL;
            delete MCAv; MCAv = NULL;
            delete MC0;  MC0  = NULL;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Getting data epoch, Epo = %d . \n", Epo);
            return NULL;
        }
        if(Epo==EpoFirst)
        {
            if(SubAve==true)
            {
                MCAv = new UMultiChan(*MC);
                if(MCAv==NULL || MCAv->GetError()!=U_OK)
                {
                    delete MC;   MC   = NULL;
                    delete MCAv; MCAv = NULL;
                    delete MC0;  MC0  = NULL;
                    CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Getting data epoch, Epo = %d . \n", Epo);
                    return NULL;
                }
            }
            MC0  = MC;
            continue;
        }
        if(SubAve==false) break;

        *MCAv += *MC;
        delete MC;
    }
    if(SubAve==true)
    {
        double    Fac = EpoLast-EpoFirst+1;
        if(Fac>0) Fac = 1./Fac;
        *MCAv *= Fac;
    }
    int Nkan  = MC0->GetNChan();
    int Ntime = MC0->GetNtime();

    UFreqBand FB(Fmin, Fmax, Fdel, FBT, Data->GetSampleRate(), Ntime);
    if(FB.GetError()!=U_OK)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Setting UFreqBand-object . \n");
        return NULL;
    }
    int Nband = FB.GetNband();
    if(Nband<=0)
    {
        delete MC0;
        delete MCAv;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Number of frequency band out of range: Nband=%d. \n", Nband);
        return NULL;
    }

/* Compute (averaged) cross-spectra */
    USensorCorrelate** SenCor = new USensorCorrelate*[Nband];
    double*         CrossReal = new double[Nband*Nkan*Nkan];
    double*         CrossImag = new double[Nband*Nkan*Nkan];
    if(CrossReal==NULL || CrossImag==NULL || SenCor==NULL)
    {
        delete   MC0;
        delete   MCAv;
        delete[] SenCor;
        delete[] CrossReal;
        delete[] CrossImag;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Memory allocation: Nband = %d, Nkan = %d . \n", Nband, Nkan);
        return NULL;
    }
    for(int k=0; k<Nband; k++)
    {
        SenCor[k] = NULL;
        for(int i12=0; i12<Nkan*Nkan; i12++) CrossReal[k*Nkan*Nkan+i12]=
                                             CrossImag[k*Nkan*Nkan+i12]=0.;
    }
    ErrorType        E = U_OK;
    if(SubAve==true) E = FB.AddCrossSpectra(MC0->GetData(), MCAv->GetData(), Nkan, CrossReal, CrossImag);
    else             E = FB.AddCrossSpectra(MC0->GetData(), NULL           , Nkan, CrossReal, CrossImag);
    int            Nep = 1;
    for(int Epo=EpoFirst+1; Epo<=EpoLast; Epo++)
    {
        if(E!=U_OK) break;

        UMultiChan*  MC1  = GetFilteredMultiChan(Epo, DType);
        if(MC1==NULL || MC1->GetError()!=U_OK)
        {
            delete MC1;   MC1   = NULL;
            E = U_ERROR;
            continue;
        }
        if(SubAve==true) E = FB.AddCrossSpectra(MC1->GetData(), MCAv->GetData(), Nkan, CrossReal, CrossImag);
        else             E = FB.AddCrossSpectra(MC1->GetData(), NULL           , Nkan, CrossReal, CrossImag);
        Nep++;

        if(Overlap==true)
        {
            if(MC0->MergeCut(*MC1, Ntime/2, Ntime)!=U_OK)
            {
                delete MC1;   MC1   = NULL;
                E = U_ERROR;
                continue;
            }
            if(SubAve==true) E = FB.AddCrossSpectra(MC0->GetData(), MCAv->GetData(), Nkan, CrossReal, CrossImag);
            else             E = FB.AddCrossSpectra(MC0->GetData(), NULL           , Nkan, CrossReal, CrossImag);
            Nep++;
        }
        delete MC0;
        MC0 = MC1;

        UString Status = UString(Epo, "Computing cross-spectra. Epoch %d of") + UString(EpoLast-EpoFirst+1, " %d epochs completed.");
        ShowStatus((const char*)Status, Epo, EpoLast-EpoFirst+1);
    }
    delete MCAv;
    if(E!=U_OK || Nep<=0)
    {
        delete   MC0;
        delete[] SenCor;
        delete[] CrossReal;
        delete[] CrossImag;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Computing cross-spectra from at least one of the data epochs . \n");
        return NULL;
    }

/* Correct for number of epochs and relative bandwidths. Convert to USensorCorrelate* array. */
    if(FBT==U_FBAND_FIVE || FBT==U_FBAND_SEVEN)
    {
        double factor = 1./Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
            for(int ic2=0;ic2<Nkan*Nkan;ic2++)
            {
                CrossReal[k*Nkan*Nkan+ic2] *= factor;
                CrossImag[k*Nkan*Nkan+ic2] *= factor;
            }
    }
    else
    {
        double AverBandInd = 0;
        for(int k=0;k<Nband;k++)  AverBandInd += FB.GetNFreq(k);
        AverBandInd /= Nband;

        double factor = AverBandInd/Ntime/Ntime/Nep;
        for(int k=0;k<Nband;k++)
        {
            int width = FB.GetNFreq(k);
            if(width<=0) continue;
            for(int ic2=0;ic2<Nkan*Nkan;ic2++)
            {
                CrossReal[k*Nkan*Nkan+ic2] *= factor/width;
                CrossImag[k*Nkan*Nkan+ic2] *= factor/width;
            }
        }
    }
    for(int k=0;k<Nband;k++)
    {
        UString Lab = UString(FB.GetLowBand(k),"%9.4f - ") + UString(FB.GetHighBand(k),"%9.4f  Hz");
        SenCor[k]   = new USensorCorrelate(MC0->GetSensorGrid(), DType, CrossReal+k*Nkan*Nkan, CrossImag+k*Nkan*Nkan, U_CORREL_CROSSSPEC, Lab);
        if(SenCor[k]==NULL || SenCor[k]->GetError()!=U_OK)
        {
            for(int kk=0;kk<=k; kk++) delete SenCor[kk];
            delete[] SenCor; SenCor = NULL;
            delete   MC0;
            delete[] CrossReal;
            delete[] CrossImag;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetCrossSpectra(). Adding frequency band %d to USensorCorrelate-array. \n", k);
            return NULL;
        }
        UString SpectText = FB.GetProperties("    ");

        switch(FBT)
        {
        case U_FBAND_FIVE : SpectText += UString("//  Bands         = FiveBands  \n"); break;
        case U_FBAND_SEVEN: SpectText += UString("//  Bands         = SevenBands \n"); break;
        case U_FBAND_EVEN : SpectText += UString(Fmin  , "//  Fmin          = %f  \n")
                                       + UString(Fmax  , "//  Fmax          = %f  \n")
                                       + UString(Fdel  , "//  Fdel          = %f  \n"); break;
        }
        if(Iepoch<0)
        {
            SpectText += UString(Epochs->GetNsamp(0)            , "//  NSampEpoch    = %d  \n");
            SpectText += UString(Epochs->GetBegin(0      ).trial, "//  FirstEpStart  = (%d") + UString(Epochs->GetBegin(0      ).sample,",%d)  \n");
            SpectText += UString(Epochs->GetBegin(EpoLast).trial, "//  LastEpStart   = (%d") + UString(Epochs->GetBegin(EpoLast).sample,",%d)  \n");
            if(Epochs->GetDescriptor(0))
                SpectText += UString(Epochs->GetDescriptor(     0), "//  Epoch[0]      = %s  \n");
        }
        else
        {
            SpectText += UString(Iepoch             , "//  Epoch         = %d  \n");
            if(Epochs->GetDescriptor(Iepoch))
                SpectText += UString(Epochs->GetDescriptor(Iepoch), "//  Epoch[ ]      = %s  \n");
        }
        SpectText +=  UString(BoolAsText(SubAve ), "//  SubstractAver = %s  \n")
                   +  UString(BoolAsText(Overlap), "//  OverlapEpochs = %s  \n");

        SenCor[k]->SetCreation(SpectText);
    }
    delete   MC0;
    delete[] CrossReal;
    delete[] CrossImag;

    *NBand = Nband;
    return SenCor;
}
USensorCorrelate** UMEEGDataEpochs::GetNolteCausality(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool Overlap, bool SubAve, int* NBand, DataType Dtype)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }

    if(Data->GetGrid(Dtype)==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Data not present or function not available for data type %s. \n", UMEEGDataBase::GetDataTypeText(Dtype));
        return NULL;
    }
    if(Iepoch>=0)
    {
        if(Iepoch>=Epochs->GetnEpochs())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
            return NULL;
        }
        if(SubAve==true)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Substracting average not compatible with single epoch power spectrum. \n");
            return NULL;
        }
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Epoch times are not constant. \n");
            return NULL;
        }
        if(SubAve==true && Epochs->GetnEpochs()<=1)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Substracting average not compatible with single epoch power spectrum, Nepochs=%d. \n", Epochs->GetnEpochs());
            return NULL;
        }
    }
    if(Fmin<0. || Fmax<=Fmin)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Invalid frequencies: Fmin=%f, Fmax=%f, Fdel=%f  \n", Fmin, Fmax, Fdel);
        return NULL;
    }
    if(NBand==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Invalid NULL pointer for NBand. \n");
        return NULL;
    }
    UFreqBand FBEven(Fmin, Fmax, -1, U_FBAND_EVEN, Data->GetSampleRate(), Epochs->GetNsamp(0));
    if(FBEven.GetError()!=U_OK || FBEven.GetNband()<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Setting up frequency bands. \n");
        return NULL;
    }
    if(Fdel<3*FBEven.GetFreqRes())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Invalid frequency band width: Fdel=%f, Fres=%f  \n", Fdel, FBEven.GetFreqRes());
        return NULL;
    }
    UFreqBand FBOut(Fmin, Fmax, Fdel, FBT, Data->GetSampleRate(), Epochs->GetNsamp(0));
    if(FBOut.GetError()!=U_OK || FBOut.GetNband()<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Setting up frequency bands for output. \n");
        return NULL;
    }

    int                NBandEven = 0;
    USensorCorrelate** CoherArr  = GetCrossSpectra(Fmin, Fmax, FBEven.GetFreqRes(), U_FBAND_EVEN, Iepoch, Overlap, SubAve, &NBandEven, Dtype);
    if(CoherArr==NULL || NBandEven==0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Computing cross-spectra. \n");
        return NULL;
    }

    int Nband = FBOut.GetNband();
    USensorCorrelate** NolteCaus = new USensorCorrelate*[Nband];
    if(NolteCaus==NULL)
    {
        for(int k=0; k<NBandEven; k++) delete CoherArr[k];
        delete[] CoherArr;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Memory allocation. \n");
        return NULL;
    }
    for(int k=0; k<Nband; k++) NolteCaus[k] = NULL;
    for(int k=0; k<Nband; k++)
    {
        const UGrid* Grid = Data->GetGrid(Dtype);
        if(Dtype==U_DAT_MEG && InterpolateCTF==true)
            Grid = Data->GetCTFInterpolation()->GetGridTo();

        NolteCaus[k] = new USensorCorrelate(Grid, Dtype, NULL, NULL, U_CORREL_NOLTECAUSE, FBOut.GetBandAsText(k));
        if(NolteCaus[k]==NULL || NolteCaus[k]->GetError()!=U_OK)
        {
            for(int kk=0; kk<Nband     ;kk++) delete NolteCaus[kk];
            delete[] NolteCaus;
            for(int kk=0; kk<NBandEven; kk++) delete CoherArr[kk];
            delete[] CoherArr;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Creating empty slot for band %d . \n", k);
            return NULL;
        }
    }

    for(int k=0; k<NBandEven-1; k++)
    {
        double Freq     = FBEven.GetCenterFreq(k  );

        if(Freq<Fmin || Freq  >=Fmax) continue;

        int    Index    = FBOut.GetBandIndex(Freq);
        if(Index<0   || Index>=Nband) continue;

        if(NolteCaus[Index]->IntegrateNolteCausality(CoherArr[k], CoherArr[k+1])!=U_OK)
        {
            for(int kk=0; kk<Nband     ;kk++) delete NolteCaus[kk];
            delete[] NolteCaus;
            for(int kk=0; kk<NBandEven; kk++) delete CoherArr[kk];
            delete[] CoherArr;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Integrating Nolte-causality. \n");
            return NULL;
        }
    }

    int NNull = 0;
    for(int ib=0; ib<Nband-NNull; ib++)
    {
        if(NolteCaus[ib+NNull]==NULL) NNull++;
        NolteCaus[ib] = NolteCaus[ib+NNull];
    }
    *NBand = Nband-NNull;

    if(*NBand==0)
    {
        delete[] NolteCaus;
        for(int kk=0; kk<NBandEven; kk++) delete CoherArr[kk];
        delete[] CoherArr;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetNolteCausality(). Not any frequency band detected. \n");
        return NULL;
    }

    for(int k=0; k<NBandEven; k++) delete CoherArr[k];
    delete[] CoherArr;
    return NolteCaus;
}


USensorCorrelate* UMEEGDataEpochs::GetSynLikeMatrix(int NSampSubWindow, double FracOverlap, int SubSamp, SimilarityType SimTyp, double Pref, int Iepoch, DataType Dtype)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Data or Epochs not set. \n");
        return NULL;
    }
    if(ComputeHilbertXfm==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Function not compatible with ComputeHilbertXfm==true. \n");
        return NULL;
    }
    if(InterpolateCTF==true && (Data->GetCTFInterpolation()==NULL || Data->GetCTFInterpolation()->GetGridTo()==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). MEG sensor interpolation object not consistently set.\n");
        return NULL;
    }

    int Nkan     = Data->GetNkan(Dtype);
    if(Dtype==U_DAT_MEG && InterpolateCTF==true)
        Nkan = Data->GetCTFInterpolation()->GetGridTo()->GetNpoints();
    if(Nkan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). No channel of type %s .\n", UMEEGDataBase::GetDataTypeText(Dtype));
        return NULL;
    }

    int EpoFirst =  0;
    int EpoLast  = -1;
    if(Iepoch>=0)
    {
        if(Iepoch>=Epochs->GetnEpochs())
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Iepoch out of range (Iepoch=%d). \n", Iepoch);
            return NULL;
        }
        EpoFirst = EpoLast = Iepoch;
    }
    else
    {
        if(Epochs->AreEpochTimesEqual()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Epoch times are not constant. \n");
            return NULL;
        }
        EpoFirst = 0;
        EpoLast  = Epochs->GetnEpochs()-1;
    }
    int Ntime    = Epochs->GetNsamp(EpoFirst);
    if(Ntime<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). No time samples (Ntime=%d) .\n", Ntime);
        return NULL;
    }
    if(NSampSubWindow<=1 || NSampSubWindow>Ntime || SubSamp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Input parameters out of range: NSampSubWindow=%d, SubSamp=%d, ichan=%d.\n", NSampSubWindow, SubSamp);
        return NULL;
    }
    if(FracOverlap<0 || 1<=FracOverlap)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Invalid overlap (FracOverlap = %f). \n", FracOverlap);
        return NULL;
    }


/* Compute (averaged) SL matrices */
    double*  SLMat      = new double [Nkan*Nkan];
    double*  ThreshArr  = new double [Nkan];
    UField** SLMatArrTr = new UField*[Nkan];
    if(SLMatArrTr==NULL || ThreshArr==NULL || SLMat==NULL)
    {
        delete[] SLMat;
        delete[] ThreshArr;
        delete[] SLMatArrTr;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Memory allocation: Nkan = %d . \n", Nkan);
        return NULL;
    }
    for(int i12=0; i12<Nkan*Nkan; i12++) SLMat[i12]    = 0.;
    for(int i  =0; i  <Nkan;      i++  ) ThreshArr[i]  = 0.;
    for(int i  =0; i  <Nkan;      i++  ) SLMatArrTr[i] = NULL;

    UGrid       G;
    ErrorType   E = U_OK;
    int DiagWidth = 0;
    for(int Epo=EpoFirst; Epo<=EpoLast; Epo++)
    {
        if(E!=U_OK) break;

        UMultiChan*  MC  = GetFilteredMultiChan(Epo, Dtype);
        if(MC==NULL || MC->GetError()!=U_OK)
        {
            delete   MC;
            E = U_ERROR;
            continue;
        }
        if(Epo==EpoFirst) G = UGrid(*MC->GetSensorGrid());

        for(int i=0; i<Nkan; i++)
        {
            delete SLMatArrTr[i]; SLMatArrTr[i] = MC->GetSynLikeMatrix(NSampSubWindow, FracOverlap, SubSamp, i, SimTyp, &DiagWidth);
            if(SLMatArrTr[i]==NULL || SLMatArrTr[i]->GetError()!=U_OK)
            {
                delete   MC;
                E = U_ERROR;
                break;
            }
            ThreshArr[i]  = SLMatArrTr[i]->GetUpperQuantile_d(Pref, DiagWidth, -1, -1);
            double Mindat = 0.;
            double Maxdat = 1.;
            SLMatArrTr[i] ->GetMinMaxData(&Mindat, &Maxdat);
            SLMatArrTr[i] ->ThresholdAbsolute(ThreshArr[i], 1.1*Maxdat, Maxdat);
            SLMatArrTr[i] ->SetDataDiagonal(DiagWidth, 0.);
        }
        if(E==U_ERROR) continue;

        int Ncompare = SLMatArrTr[0]->GetDimensions(0)*(SLMatArrTr[0]->GetDimensions(0)-1);

        for(int i1=0; i1<Nkan; i1++)
        {
            for(int i2=0; i2<Nkan; i2++)
            {
                if(i2!=i1)
                {
                    int    Nsup = SLMatArrTr[i2]->GetNDataSuperThreshold(ThreshArr[i2], DiagWidth, -1, -1, SLMatArrTr[i1]);
                    double SynLike = 0.;
                    if(Ncompare>0) SynLike = Nsup / (double) Ncompare;

                    SLMat[i1*Nkan+i2] += SynLike  / (EpoLast-EpoFirst+1);
                }
                else if(i1==i2)
                {
                    SLMat[i1*Nkan+i2] = 1.;
                }
                else
                {
                    SLMat[i1*Nkan+i2] = SLMat[i2*Nkan+i1];
                }
            }
        }

        delete MC;
        UString Status = UString(Epo, "Computing cross-spectra. Epoch %d of") + UString(EpoLast-EpoFirst+1, " %d epochs completed.");
        ShowStatus((const char*)Status, Epo-EpoFirst, EpoLast-EpoFirst+1);
    }
    for(int i=0; i<Nkan; i++) delete SLMatArrTr[i];
    delete[] SLMatArrTr;
    delete[] ThreshArr;
    if(E!=U_OK)
    {
        delete[] SLMat;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Computing cross-spectra from at least one of the data epochs . \n");
        return NULL;
    }

    USensorCorrelate* SenCor = new USensorCorrelate(&G, Dtype, SLMat, NULL, U_CORREL_SYNLIKE, UString("SynLike"));
    delete[] SLMat;
    if(SenCor==NULL || SenCor->GetError()!=U_OK)
    {
        delete SenCor;
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetSynLikeMatrix(). Creating USensorCorrelate-object. \n");
        return NULL;
    }

    UString SpectText  = GetProperties("//  ");
            SpectText += UString("Synchronization Likelyhood: \n")
                       + UString(NSampSubWindow, "NSampSubWindow      = %d\n")
                       + UString(FracOverlap   , "FracOverlap         = %f\n")
                       + UString(SimTyp        , "SimTyp              = %d\n")
                       + UString(Iepoch        , "Iepoch              = %d\n")
                       + UString(Pref          , "Pref                = %f\n");

    SenCor ->SetCreation(SpectText);

    return SenCor;
}


/* manipulating sensors*/
bool UMEEGDataEpochs::AreEEGPositionsMeasured(void) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::AreEEGPositionsMeasured(). Data not (properly) set. \n");
        return false;
    }
    return Data->AreEEGPositionsMeasured();
}
ErrorType UMEEGDataEpochs::RenameSensor(const char* OldName, const char* NewName)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::RenameSensor(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->RenameSensor(OldName, NewName);
}
ErrorType UMEEGDataEpochs::SetCTFSensorGroups(void)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::SetCTFSensorGroups(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->SetCTFSensorGroups();
}
ErrorType UMEEGDataEpochs::CopySensorIDsFromNames(const UGrid* G)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::CopySensorIDsFromNames(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->CopySensorIDsFromNames(G);
}

ErrorType UMEEGDataEpochs::UpdateDewar2Head(UEuler DewarToHead)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::UpdateDewar2Head(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->UpdateDewar2Head(DewarToHead);
}

ErrorType UMEEGDataEpochs::XfmSensorsMEG(UEuler XFM)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::XfmSensorsMEG(). Data not (properly) set. \n");
        return U_ERROR;
    }
    return Data->UpdateDewar2Head(XFM);
}

ErrorType UMEEGDataEpochs::ReplaceSensorPositions(const UGrid* GrNew, DataType DT)
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceSensorPositions(). Data not (properly) set. \n");
        return U_ERROR;
    }
    if(GrNew==NULL || GrNew->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceSensorPositions(). New sensors NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DT!=U_DAT_MEG && DT!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReplaceSensorPositions(). Wrong data type (DT = %d ) .\n", DT);
        return U_ERROR;
    }
    return Data->ReplaceSensorPositions(GrNew, DT);
}


ErrorType UMEEGDataEpochs::LogProperties(const char* FileName) const
{
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::LogProperties(). Epochs not properly set. \n");
        return U_ERROR;
    }
    return Epochs->LogProperties(FileName);
}

UDistribution* UMEEGDataEpochs::GetAverPowerHistogramChan(int Nbin, double PowerMax, DataType DT, int ichan) const
{
    if(ichan<0 || ichan>=Data->GetNkan(DT))
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverPowerDistribution(). Channel number out of range: ichan = %d.\n", ichan);
        return NULL;
    }

    CI.TimeReset("Note: Compute power histogram.\n");
    UDistribution* Dist = new UDistribution(Nbin, 0., PowerMax);
    if(Dist==NULL || Dist->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverPowerDistribution(). Creating distribution object.\n");
        return NULL;
    }

    int nEp   = Epochs->GetnEpochs();

    for(int k=0; k<nEp; k++)
    {
        CI.AddToLog("Note: Trial %d of %d \n",k,nEp);
        UMultiChan* MCiep = GetFilteredMultiChan(k, DT, ichan);
        if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL)
        {
            delete   MCiep;
            delete[] Dist;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverPowerDistribution(). Cannot get data from Epoch %d.\n", k);
            return NULL;
        }
        int           nTime = Epochs->GetNsamp(k);
        const double* data  = MCiep->GetData();
        for(int j=0; j<nTime; j++) Dist->AddValue(data[j]*data[j]);
        delete MCiep;
    }

    CI.TimeFlag("Note: Compute power histogram.\n");
    return Dist;
}

UDistribution* UMEEGDataEpochs::GetAverPowerHistogram(int Nbin, double PowerMax, DataType DT) const
/*
    Compute the distribution of the power, averaged over all channels, considering all
    time samples in all (filtered) epochs.

    Nbin:     the number of bins
    PowerMax: the maximum power (averaged over channels) taken into consideration.

    return NULL on any error.
 */
{
    CI.TimeReset("Note: Compute power histogram.\n");
    UDistribution* Dist = new UDistribution(Nbin, 0., PowerMax);
    if(Dist==NULL || Dist->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverPowerDistribution(). Creating distribution object.\n");
        return NULL;
    }

    int nKan  = Data->GetNkan(DT);
    int nEp   = Epochs->GetnEpochs();

    for(int k=0; k<nEp; k++)
    {
        CI.AddToLog("Note: Trial %d of %d \n",k,nEp);
        UMultiChan* MCiep = GetFilteredMultiChan(k, DT);
        if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL)
        {
            delete MCiep;
            CI.AddToLog("ERROR: UMEEGDataEpochs::GetAverPowerDistribution(). Cannot get data from Epoch %d.\n", k);
            return NULL;
        }
        int           nTime = Epochs->GetNsamp(k);
        const double* data  = MCiep->GetData();
        for(int j=0; j<nTime; j++)
        {
            double Power = 0;
            for(int i=0; i<nKan; i++) Power += data[i*nTime+j]*data[i*nTime+j];
            Power /= nKan;

            Dist->AddValue(Power);
        }
        delete MCiep;
    }

    CI.TimeFlag("Note: Compute power histogram.\n");
    return Dist;
}

UClusterEpochs::UClusterEpochs() : UCluster()
{
    EpochsArray = NULL;
    Nepochs     = 0;
}

UClusterEpochs::UClusterEpochs(const UClusterEpochs& Clus)
{
    EpochsArray = Clus.EpochsArray;
    Nepochs     = Clus.Nepochs;
}

UClusterEpochs& UClusterEpochs::operator=(const UClusterEpochs &Clus)
{
    if(&Clus==NULL)
    {
        CI.AddToLog("ERROR: UClusterEpochs::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Clus) return *this;

    UCluster::operator=(Clus);
    if(UCluster::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UClusterEpochs::operator=(). Copying base class. \n");
        return *this;
    }

    EpochsArray = Clus.EpochsArray;
    Nepochs     = Clus.Nepochs;
    return *this;
}

ErrorType UClusterEpochs::InitClustering(LinkType LM, const UMultiChan* EpArr, int Nepo)
{
    if(EpArr && Nepo>0)
    {
        int NChan = EpArr[0].GetNChan();
        int Ntime = EpArr[0].GetNtime();
        for(int k=1; k<Nepo; k++)
        {
            if(NChan!=EpArr[k].GetNChan()  ||
               Ntime!=EpArr[k].GetNtime())
            {
                EpochsArray = NULL;
                Nepochs     = 0;
                CI.AddToLog("ERROR: UClusterEpochs::InitClustering(). Epochs have different numbers of channels or samples, k=%d \n", k);
                return U_ERROR;
            }
        }
        EpochsArray = EpArr;
        Nepochs     = Nepo;

        return UCluster::InitClustering(LM);
    }
    EpochsArray = NULL;
    Nepochs     = 0;
    return U_OK;
}

double UClusterEpochs::GetDistance2(int i1, int i2)
{
    if(EpochsArray==NULL || Nepochs<=0)
    {
        CI.AddToLog("ERROR UClusterEpochs::GetDistance2(). EpochsArray==NULL  .\n");
        return 0.;
    }
    return Distance2(EpochsArray[i1], EpochsArray[i2]);
}
