#ifndef _MEEGDATAEPOCHS_INCLUDED
#define _MEEGDATAEPOCHS_INCLUDED

#include "Marker.h"
#include "Cluster.h"
#include "LinearFilter.h"
#include "MultiChan.h"

enum FreqBandType
{
    U_FBAND_EVEN,
    U_FBAND_FIVE,
    U_FBAND_SEVEN,
};


class UMarkerArray;
class UMarker;
class UEpochs;
class UFieldGraph;
class UMapFile;
class USensorCorrelate;
class UDistribution;
class UField;
class UFieldGraph;
class UInterpolateSensors;
class UCovarianceModel;

class DLL_IO UFreqBand
{
public:
    UFreqBand();
    UFreqBand(double Fmin, double Fmax, double Fdel, FreqBandType FBT, double Srate, int Ntime);
    UFreqBand(FreqBandType FBT, double Srate, int Ntime);
    UFreqBand(const UFreqBand& FB);
    ~UFreqBand();
    UFreqBand&      operator=(const UFreqBand& FB);

    ErrorType       GetError(void) const {return error;}
    const UString&  GetProperties(UString Comment) const;
    UString         GetBandAsText(int iband) const;

    int             GetNband(void)          const {return Nband;}
    double          GetFreqRes(void)        const {return Fres;}
    int             GetFreqIndex(double Freq) const;
    int             GetBandIndex(double Freq) const;
    int             GetNFreq(int Index) const;
    double          GetLowBand(int Index) const;
    double          GetHighBand(int Index) const;
    double          GetCenterFreq(int Index) const;
    double*         GetFrequencies(void) const;

    ErrorType       AddSpectra(const double* Data, const double* DataAve, int Nkan, double* Spectra, bool RMS) const;
    ErrorType       AddCrossSpectra(const double* Data, const double* DataAve, int Nkan, double* CrossReal, double* CrossImag);

protected:
    void            DeleteAllMembers(ErrorType E);
    void            SetAllMembersDefault(void);

private:
    ErrorType       error;
    static UString  Properties;   

    double          Fres;                // Frequency resolution
    double          Fsamp;               // The sample rate
    int             NSamp;               // The number of samples per epcch
    int             Nband;               // The number of frequency bands
    int*            BandIndexMin;        // Table to transform from frequency band number to frequency index
    int*            BandIndexMax;        // id. 
    
    double*         CoBuffer;            //  General array to store Nsamp/2+1 power spectra 
    double*         FFTBuffer;           //  General array to store the FFT of the time signal, and a buffer
};

class DLL_IO UClusterEpochs  : public UCluster
{
public:
    UClusterEpochs();
    UClusterEpochs(const UClusterEpochs& Clus); 
    virtual UClusterEpochs& operator=(const UClusterEpochs &Clus);

    ErrorType            InitClustering(LinkType LM, const UMultiChan* EpArr, int Nepo);

private:
    const UMultiChan*    EpochsArray; 
    int                  Nepochs;
    virtual double       GetDistance2(int i1, int i2); 
    virtual int          GetNobjects(void) const        {return Nepochs;}
};

typedef struct
{
    bool   Apply;
    double Normal;
    double Outlier;
} OutlierType;

class DLL_IO UMEEGDataEpochs
{
public:
    UMEEGDataEpochs();
    UMEEGDataEpochs(UDirectory DirName);
    UMEEGDataEpochs(UFileName FileName, const char* forceGoodCh=NULL, const char* forceBadCh=NULL);
    UMEEGDataEpochs(const UMEEGDataEpochs& DatEp); 
    virtual ~UMEEGDataEpochs();
    virtual UMEEGDataEpochs& operator=(const UMEEGDataEpochs &DatEp);

/* Reading settings */
    ErrorType               GetError(void) const {if(this) return error; return U_ERROR;}
    int                     GetNSampEpoch(int Ep) const;
    int                     GetNEpoch(void) const;
    UString*                GetUsedMarkerNames(int* nMarkers) const;
    UEvent                  GetEvent(int Iep, int sample) const;
    ErrorType               GetNEpochsPerMarkers(const UString* MarkerNames, int nNames, int* nEpochsPerMarker) const;
    double                  GetPreTriggerTime_s(void) const;
    int                     GetNPreTriggerSamples(void) const;
    UDateTime               GetDateTime(UEvent E, double* FracSec=NULL) const;

    const UString&          GetProperties(UString Comment) const;
    ErrorType               LogProperties(const char* FileName) const;

/* Setting Epochs */
    ErrorType               SetEpochsMarker(const char *BEName);
    ErrorType               SetEpochsMarker(int halfwidth, const char* markername);
    ErrorType               SetEpochsMarker(int BeginOffset, int EndOffset, const char* markername);
    ErrorType               SetEpochsMarker(int BeginOffset, int EndOffset, const UMarker* M);

    ErrorType               SetEpochs(int startsample, int endsample);
    ErrorType               SetEpochs(int npieces, bool ForcePower2, bool IgTrBo);
    ErrorType               SetEpochs(int nsampskip, int newtriallen, int startsample, int endsample);
    ErrorType               SetEpochs(const UEpochs* NewEpochs);
    ErrorType               SetEpochs(const UFieldGraph* FG, double Level);
    
    ErrorType               SetEpochsShift(int EpochSize, int EpochShift);
    ErrorType               SetEpochsEqTime(double TimeSpan);

/* Editing Epochs */
    ErrorType               ForceEpochsInDataSet(void);
    ErrorType               ForceEqualSize(int NsampEp, bool NsampAverage=true, bool ForcePower2=false);
    ErrorType               SubsampleEpochs(int Ntake, int Nphase);
    ErrorType               ExcludeOverlapping(void);
    ErrorType               ExcludeTrialClass(const char* TrialClassName);
    ErrorType               IncludeTrialClass(const char* TrialClassName);
    ErrorType               ExcludeTrials(int starttrial, int endtrial);
    ErrorType               ExcludeEpochs(int startepoch, int endepoch);
    ErrorType               ExcludeEpochs(int halfwidth, const char* markername);
    ErrorType               ExcludeSamples(int halfwidth, const char* markername);
    ErrorType               SortEpochs(void);
    ErrorType               RemoveBadEpochs(DataType DT, double MedianFactor, UString* BADEpochs, UField* ChanEpOverView=NULL);

/* Filter  settings */
    ErrorType               SetOutlierCorrection(DataType Dtype, bool Set, double Normal, double Outlier);
    ErrorType               SetSEFCorrection(bool RemoveSEFartifact, const UMarker* Mark, int smpFrom, int smpTo);
    bool                    GetSEFCorrection(void) const {if(this) return CorrectSEFartifact; return false;}
    int                     GetSEFCorrectionWinSampFrom(bool Default) const;
    int                     GetSEFCorrectionWinSampTo(bool Default) const;

    ErrorType               SetRereference(ReReferenceType MEGR, ReReferenceType EEGR);
    ErrorType               SetCommonRef(const char* RefLabel);
    const char*             GetCommonRef(void) const;

    ErrorType               SetPreProcessingEpochs(int BeginOffset, int EndOffset);
    ErrorType               ReSetPreProcessingEpochs(void);
    bool                    ArePreProcessingEpochsSet(void) const;
    double*                 GetRawPrepVariance(int Iepoch, DataType Dtype) const;

    ErrorType               CopyFilter(const UMEEGDataEpochs* Epo);
    ErrorType               SetFilter(UPreProType Prep, UPowerLineType PowerLine, double PLWidth, bool NoExtraSamp, double WindowSize_s);
    ErrorType               SetFilter(double Fmin, double Fmax, UPreProType Prep, UPowerLineType PowerLine, double PLWidth, bool NoExtraSamp, double WindowSize_s);
    ErrorType               SetFilter(int Ncomp, UPreProType Prep, UPowerLineType PowerLine, double PLWidth, double WindowSize_s);
    ErrorType               SetFilter(const ULinearFilter& LinFilter, bool NoExtraSamp);
    ULinearFilter           GetFilter(void) const {return Filt;}
    bool                    GetExtraSamples(void) const {return NOT(DoNotExtraSamples);}
    bool                    GetNoExtraSamples(void) const {return DoNotExtraSamples;}

    ErrorType               AddStopBand(double fmin, double fmax);
    ErrorType               SetInterpolateCTF(bool Set);
    ErrorType               SetHilbertTransform(bool Set);

/* Selecting channels */
    char*                   ReadSkipChannelLabels(const char* SkipDir) const;
    static ErrorType        WriteSkipChannels(const ChanInfo* ChInf, UFileName FLab);

    ErrorType               CopyChannelSelection(const UMEEGDataEpochs* Epo);
    ErrorType               RemoveChannelsFromSkipFile(const char* SkipDir=NULL);
    ErrorType               RemoveChannels(const char *const* BadChan);
    ErrorType               SelectChannels(const char *const* GoodChan, const char * const*BadChan);
    ErrorType               SelectChannels(const char* GoodChan, const char* BadChan);
    ErrorType               SelectChannels(const ChanInfo* NewChIn);
    ErrorType               SelectChannels(DataType DT0, DataType DT1=U_DAT_UNKNOWN, DataType DT2=U_DAT_UNKNOWN, DataType DT3=U_DAT_UNKNOWN);  
    ErrorType               SelectChannels(DataType DT0, const char* GoodChan, const char* BadChan);    
    ErrorType               SelectChannels(const UGrid* GridLabels);
    
    ErrorType               RemoveBadChannels(DataType DT, double MedianFactor, UString* BADChannels, UField* ChanEpOverView=NULL);
    ErrorType               ConvertDataType(DataType DTOLD, DataType DTNEW);
    ErrorType               UpdateChannelColors(const ChanInfo* ChIn, const UGrid* GSel);
    ErrorType               UpdateChannelGroups(const UGrid* GSel);

/* Export file formats */
    ErrorType               WriteMapFile(DataType Dtype, const char* FileName, const char* const* TrialLab, double NewSampFreq, int IEpoch, bool InvertData=false) const;
    ErrorType               WriteTextFile(UFileName FileOut, bool WriteHeader, bool ChannelLabels, bool Transpose, bool  FixedFormat, bool SepFiles, TimeFormatType FTime, char Separator, const bool SaveArray[U_DAT_NTYPE], double NewSampFreq, int IEpoch, bool InvEEG=false, bool InvEKG=false) const;
    ErrorType               WriteTextHeader(UFileName FileOut, bool ChannelLabels, bool Transpose, double NewSampFreq, int Iepoch, TimeFormatType TForm, char Separator, const UMultiChan* const* MCarr) const;
    ErrorType               WriteCTFDataSet(const char* DSName, const bool SaveArray[U_DAT_NTYPE], DataType ConvEKG, double NewSampFreq, int IEpoch, bool InvEEG=false, bool InvEKG=false) const;
    ErrorType               WriteMarkersInECGFile(const char* FileName) const;
    ErrorType               WriteEDF(const char* FileEDF, const bool SaveArray[U_DAT_NTYPE], double NewSampFreq, int IEpoch, bool InvEEG=false, bool InvEKG=false) const;
    ErrorType               WriteSensorPositionsXYZ(UFileName FileXYZ) const;
    ErrorType               WriteSensorPositionsCTF(void) const;
    ErrorType               WriteChannelConfigTXT(UFileName FileConf) const;
    ErrorType               ReadResampleWriteCTFData(double Fresamp);

    ReReferenceType         GetMEGReref(void) const {return MEGReref;}
    ReReferenceType         GetEEGReref(void) const {return EEGReref;}
    ReReferenceType         GetMEGForwardBalancing(void) const;

/* Editing markers*/
    const UMarkerArray*     GetMarkerArray(void) const;
    ErrorType               SetMarkerArray(const UMarkerArray* Mar) const;
    ErrorType               MergeMarkerArray(const UMarkerArray* Mar);
    ErrorType               ReplaceMarkers(const UMarkerArray* Mar, bool Prepend);
    ErrorType               ReplaceMarker(const UMarker* Mark, int im);
    ErrorType               AddMarker(const UMarker* Mark);
    ErrorType               WriteMarkersMM(void) const;
    ErrorType               WriteMarkersCTF(void) const;
    ErrorType               WriteMarkersTXT(void) const;

    const UMEEGDataBase*    GetData(void) const               {return Data;}
    const UEpochs*          GetEpochs(void)     const         {return Epochs;}
    UFileName               GetSkipChannelLabelFile(void) const;
    UFileName               GetSpatCovarianceFile(void) const;
    UFileName               GetTempCovarianceFile(void) const;
    UCovariance*            GetSpatialCovariance(int Iepoch, DataType Dtype);
    double                  GetSampleTime_s(void) const       {return SampleTime_s;}
    double                  GetSampleRate(void) const;
    int                     GetPreNTriggerPnts(void) const;
    int                     GetNsampTrial(void) const;

/* Get filtered data */
    UField*                 GetRMSOverview(DataType Dtype, double* RMSMax);
    UField*                 GetSingleChannelAsField(const char* Label);
    int*                    GetEpochsSuperThreshold(DataType Dtype, const char* ChanLab, double Thresh, int* NSuper);
    UFieldGraph*            GetChannelSamplesAsFieldGraph(const UMarker* Mark, const char* Label) const;

    UMultiChan*             GetRawMultiChan(int Iepoch, DataType Dtype, int isens=-1) const;
    UMultiChan*             GetRawMultiChan(UEvent Beg, UEvent End, DataType Dtype, int isens=-1) const;
    virtual UMultiChan*     GetFilteredMultiChan(int Iepoch, DataType Dtype, const UGrid* GridLabels) const;
    virtual UMultiChan*     GetFilteredMultiChan(int Iepoch, DataType Dtype, int isens=-1) const;
    virtual UMultiChan*     GetFilteredMultiChan(int Iepoch, const char* Label) const;
    UMultiChan**            GetFilteredMultiChan(int Iepoch, const bool DataTypeArray[U_DAT_NTYPE]) const;
    UMultiChan*             GetFilteredMultiChan(UEvent Beg, UEvent End, DataType Dtype, int isens=-1) const;
    UMultiChan*             GetFilteredMultiChan(UEvent E, const int* Offsets, int Noff, DataType Dtype) const;
    UMultiChan*             GetFilteredMultiChanAllTypes(int Iepoch, DataType DtypeSkip) const;
    UMultiChan*             GetFilteredMultiChanMEG(int Iepoch, const UInterpolateSensors* Inter) const;
    UMultiChan*             InterpolateAndHilbert(UMultiChan* MC, DataType Dtype) const;

    virtual UMultiChan*     GetAveragedFilteredMultiChan(DataType Dtype);
    virtual UMultiChan*     GetAveragedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier);
    virtual UMultiChan*     GetAveragedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, UMatrixSymmetric** CovXX, UMatrixSymmetric** CovTT, int MaxIter);
    UMultiChan*             GetSummedFilteredMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, UMarker** pMgood=NULL);
    UMultiChan*             GetOverlapCorrectedAveragedMultiChan(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier);
    UMultiChan**            GetAllFilteredMultiChans(const UMarker* M, int NLeft, int NRight, DataType Dtype, int isens, double FractOutlier, int* Ntaken);
    UMultiChan**            GetAllFilteredMultiChans(DataType Dtype, int isens=-1) const;

    double*                 GetAverageMarkerData(const char* MarkerName, DataType Dtype, int* nSingleMatch);
    double*                 GetFilteredData(int Iepoch, DataType Dtype, int isens=-1) const;
    double*                 GetAveragedData(DataType DT, const char* MarkerName) const;
    double*                 GetMinDatChan(int Iepoch, DataType Dtype, bool Fabs) const;
    double*                 GetMaxDatChan(int Iepoch, DataType Dtype, bool Fabs) const;
    double*                 GetLRSymmetryAsTime(int Iepoch, DataType Dtype) const;

    ErrorType               ApplyOutlierCorrection(UMultiChan* MC, DataType Dtype) const;
    ErrorType               ApplySEFCorrection(UMultiChan* MC, UEvent Begin, UEvent End, DataType Dtype) const;

    int*                    GetStimData(int Iepoch) const;
    int                     GetLocalMax(UEvent E, DataType Dtype, int WinLocMax) const;
    UMarker*                GetLocalMax(const UMarker* M, DataType Dtype, int WinLocMax);
    UMarker*                GetTemplateMatch(const UMultiChan* Template, DataType Dtype, int isens, double DetectThresh, int MinInterval, int SubSample, SimilarityType ST, bool ShiftLocalMax);    
    UMarker*                GetOutlierMarker(DataType Dtype, int isens, double Thresh, int NWindow, UString MarkerName);
    UMarkerArray*           ConvertGraphsToMarkers(UFieldGraph* const* Graphs, int NGraphs) const;

/* Power/Cross Spectra */
    UFieldGraph**           GetSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool RMS, bool Overlap, bool SubAve, int* NChan, UMapFile** MapMEG, UMapFile** MapEEG, bool AverChanGrp);
    UMapFile*               GetInterpolatedMEGSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool RMS, bool Overlap, bool SubAve, const UInterpolateSensors* Inter);
    UField**                GetWaveletTransformAsFieldArray(double Fmin, double Fdel, double Fmax, DataType Dtype, bool RMS, int Iepoch, bool SubAve, int* NSpect, UMapFile** MapData, bool AverChanGrp, int WavelOrder);
    UField**                GetSpectrogramAsFieldArray(double Fmin, double Fmax, DataType Dtype, bool RMS, bool Overlap, bool SubAve, int* NSpect, UMapFile** MapData, int** AbsSamples, bool AverChanGrp, int NsubWindows, double FracOver, bool AverEpoch);
    USensorCorrelate**      GetCrossSpectra(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool Overlap, bool SubAve, int* NBand, DataType DType);
    USensorCorrelate*       GetCrossSpectrum(double Fmin, double Fmax, int Iepoch, bool Overlap, bool SubAve, DataType DType);
    USensorCorrelate*       GetSynLikeMatrix(int NSampSubWindow, double FracOverlap, int SubSamp, SimilarityType SimTyp, double Pref, int Iepoch, DataType DType);
    USensorCorrelate**      GetNolteCausality(double Fmin, double Fmax, double Fdel, FreqBandType FBT, int Iepoch, bool Overlap, bool SubAve, int* NBand, DataType DType);

    UDistribution*          GetAverPowerHistogramChan(int Nbin, double PowerMax, DataType DT, int ichan) const;
    UDistribution*          GetAverPowerHistogram(int Nbin, double PowerMax, DataType DT) const;

/* Fuctions for clustering epochs*/
    ErrorType               InitClustering(LinkType LM, const UMultiChan* EpArr, int Nepo);
    const int*              ComputeClusters(int Ncluster)  {return ClustEpo.ComputeClusters(Ncluster);}

/* Manipulating sensors*/
    bool                    AreEEGPositionsMeasured(void) const;
    ErrorType               UpdateDewar2Head(UEuler DewarToHead);
    ErrorType               XfmSensorsMEG(UEuler XFM);
    ErrorType               ReplaceSensorPositions(const UGrid* GrNew, DataType DT);
    ErrorType               RenameSensor(const char* OldName, const char* NewName);
    ErrorType               SetCTFSensorGroups(void);
    ErrorType               CopySensorIDsFromNames(const UGrid* G);

protected:
    UMEEGDataBase*          Data;               // Object containg the MEG/EEG data
    UEpochs*                Epochs;             // Epochs used for data analysis
    UEpochs*                EpochsPre;          // Epochs used for pre-processing when filtering

    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);
    virtual void            ShowStatus(const char* Status)                       {if(Status==NULL) return;}
    virtual void            ShowStatus(const char* Status, int istep, int Nstep) {if(Status==NULL || istep<0 || Nstep<=0) return;}

private:
    static UString          Properties;
    static const double     TMIN;               // Minimum amount of time taken from data set for filtering (seconds)
    static const double     NSAMPFACTOR;        // Increase the number of time samples taken from the data set by at least this factor
    static const double     TartBegin;          // Time after stimulus onset that artifact begins [s]
    static const double     TartWidth;          // Width of the artefact [s]
    ErrorType               error;

    OutlierType             OutPar[U_DAT_NTYPE];// Outlier parameters
    ULinearFilter           Filt;               // A filter object, used to filter the epochs
    bool                    DoNotExtraSamples;  // Set true to skip the option to take extra samples in bandpass filtering
    ReReferenceType         MEGReref;           // Rereference type for MEG data
    ReReferenceType         EEGReref;           // Rereference type for EEG data
    bool                    CorrectSEFartifact; // if true, interpolate SEF artifact
    UMarker                 SEFMarker;          // if(CorrectSEFartifact) this marker refers to a marker in UMarkerArray, containing the SEF triggers
    int                     SEFWinFrom;         // Window (in samples) used for SEF artefact correction
    int                     SEFWinTo;           // 
    bool                    InterpolateCTF;     // if true (AND returning UMultiChan), Interpolate MEG data to CTF sensor system
    bool                    ComputeHilbertXfm;  // if true (AND returning UMultiChan), Compute Hilbert transform of raw data 
    
    double                  SampleTime_s;       // Sampletime in s (copy of 1./Data->srate)
    int                     NPreTriggerSamples; // Estimated or true number of samples, between trigger and start of epoch

    UString                 PreProcEpochsText;

    UClusterEpochs          ClustEpo;

    double*                 GetRawData(UEvent Beg, UEvent End, DataType Dtype, int isens, int* Nsamp) const;
    double*                 GetSEFcorrectedData(UEvent Begin, UEvent End, DataType Dtype, ReReferenceType ReRef, int chan) const;
    ErrorType               RemoveSEFart(double* data, int Nsamp, int nKan, int joffb, int joffe) const;
    int                     GetNsampReq(UEvent *Begin, UEvent *End, int NsampEpoch) const;
    void                    Mirror(UEvent Begin, UEvent End, double* data, int nKan) const;

    ErrorType               AverageTimeFreqPlots(UField*** FSpectArr, const UGrid* Grid, int *NSpect) const;
};
#endif//_MEEGDATAEPOCHS_INCLUDED
