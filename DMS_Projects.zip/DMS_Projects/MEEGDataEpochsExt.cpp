/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Extension of base class UMEEGDataEpochsExt(), meant for dipole fitting and  */
/*   Signal Space Projection.                                                    */
/*                                                                               */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    18-08-04   Creation, derived from MEEGDataEpochsExt.cpp, splitting of the SSP-part
  JdM    04-12-04   Implemented FitMovingDipoles()
  JdM    06-01-05   Implemented GetDipoleMoveList()
JdM/FB   30-03-05   Started implementation of Stationary dipole model.
  FB     25-04-05   Finished implementation of Stationary dipole model.
  FB     28-04-05   Started implementation of Coupled Dipole Model
  FB     12-05-05   Finished implementation of Coupled Dipole Model
  FB     12-05-05   Started implementation of Constrained dipole model
  JdM    13-05-05   GetFilteredMultiChan(): Made it const
  FB     03-06-05   Finished implementation of Constrained dipole model
  JdM    04-03-06   Added InitFindCoils() and ComputeFindCoils()
  JdM    05-01-07   Avoid any reference to obsolete UCTFData
  JdM    23-05-07   ComputeFindCoils(). Added parameter.
  JdM    29-05-07   Removed obsolete StartDip, StartMesh, StartFile
  JdM    01-11-07   Added beamformers
  JdM    27-06-08   Added LogEigen parameter to ComputeBeamFormerScan().
  JdM    19-08-08   InitBeamFormerScan() set MEG forward balacing.
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    18-11-09   ComputeBeamFormerScan(). Added regularization parameter.
  JdM    09-03-10   ComputeBeamFormerScan(). Added parameter to select use of LeadField table
  JdM    22-03-11   ComputeBeamFormerScan(). Return scan in pure (CTF) NLR coordinates, added parameter to transform to Wld coords
  AMW    23-11-12   Assure compatibility with gcc4.7: FitMovingDipoles(), . Use .GetString() to convert UString to const char*
  JdM    02-08-13   Added AbsoluteTime-parameter to choose between absolute or relative time
*/

#include <math.h>
#include <string.h>

#include "MEEGDataEpochsExt.h"

#include "String.h"
#include "Epochs.h"
#include "MultiChan.h"
#include "MarkerArray.h"
#include "Grid.h"
#include "SignalSpaceProj.h"
#include "Covariance.h"
#include "LocCoil.h"
#include "LocMovDip.h"
#include "DipoleMoveList.h"
#include "LocStatDip.h"
#include "DipoleEditList.h"
#include "LocCodeDip.h"

#include "Scan.h"
#include "SensorCorrelate.h"
#include "BeamFormer.h"

void UMEEGDataEpochsExt::SetAllMembersDefault(void)
{
    error            = U_OK;
    SSP              = NULL;

    AdvancedForwMod  = true;
    CovXX            = NULL;
    CovTT            = NULL;
    SensType         = UEMfield::U_UNKNOWN;

/* Output format */
    OneFile          = true;
    AllDipoles       = true;
    TimeSamples      = true;
    AbsoluteTime     = true;
    Append           = false;
    NDigit           = 6;
    OldUnits         = false;

    ULMD             = NULL;
    MaxMovDipFitError= 0.;
    MinRelDataPower  = 0.;

    ULC              = NULL;
    ULSD             = NULL;
    ULCD             = NULL;
    ULED             = NULL;

    BEAM             = NULL;
    BeamFormerGrid   = NULL;
}

void UMEEGDataEpochsExt::DeleteAllMembers(ErrorType E)
{
    delete CovXX;
    delete CovTT;
    delete ULC;
    delete ULMD;
    delete ULSD;
    delete ULED;
    delete BEAM;
    delete BeamFormerGrid;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataEpochsExt::UMEEGDataEpochsExt() : UMEEGDataEpochs()
{
    SetAllMembersDefault();
}
UMEEGDataEpochsExt::UMEEGDataEpochsExt(const UMEEGDataEpochs& DatEp) : UMEEGDataEpochs(DatEp)
{
    SetAllMembersDefault();
    *this = DatEp;
}
UMEEGDataEpochsExt::UMEEGDataEpochsExt(const UMEEGDataEpochsExt& DatEp) : UMEEGDataEpochs((const UMEEGDataEpochs&) DatEp)
{
    SetAllMembersDefault();
    *this = DatEp;
}

UMEEGDataEpochsExt::UMEEGDataEpochsExt(UFileName FileName, const char* forceGoodCh, const char* forceBadCh) : UMEEGDataEpochs(FileName, forceGoodCh, forceBadCh)
{
    SetAllMembersDefault();
}

UMEEGDataEpochsExt::~UMEEGDataEpochsExt()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataEpochs& UMEEGDataEpochsExt::operator=(const UMEEGDataEpochs &DatEp)
{
    if(this==NULL)
    {
        static UMEEGDataEpochsExt M; M.error=U_ERROR;
        return M;
    }
    if(&DatEp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&DatEp) return *this;

    UMEEGDataEpochs::operator=(DatEp);
    if(UMEEGDataEpochs::GetError() != U_OK)
    {
        UMEEGDataEpochs::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying base class. \n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    return *(UMEEGDataEpochs*)this;
}
UMEEGDataEpochsExt& UMEEGDataEpochsExt::operator=(const UMEEGDataEpochsExt &DatEp)
{
    if(&DatEp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&DatEp) return *this;

    UMEEGDataEpochs::operator=(DatEp);
    if(UMEEGDataEpochs::GetError() != U_OK)
    {
        UMEEGDataEpochs::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataEpochs::operator=(). Copying base class. \n");
        return *this;
    }
    DeleteAllMembers(U_OK);

    SSP  = DatEp.SSP;
    return *this;
}

ErrorType UMEEGDataEpochsExt::GetError() const
{
    if(this==NULL)                        return U_ERROR;
    if(UMEEGDataEpochs::GetError()!=U_OK) return U_ERROR;
    return error;
}

UMultiChan* UMEEGDataEpochsExt::GetFilteredMultiChan(UEvent E, const int* Offsets, int Noff, DataType Dtype) const
{
    return UMEEGDataEpochs::GetFilteredMultiChan(E, Offsets, Noff, Dtype);
}

UMultiChan* UMEEGDataEpochsExt::GetFilteredMultiChan(int Iepoch, const char* Label) const
/*
    return a new pointer to a MultiChan-object, containing the  filtered data
    of epoch Iepoch, of the channel named Label[].

    On error: return NULL;
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Inalid NULL argument. \n");
        return NULL;
    }
    DataType Dtype = U_DAT_UNKNOWN;
    int      ichan = Data->GetChanAndType(Label, &Dtype);

    if(ichan<0)
    {
        if(SSP && SSP->GetSourceGrid())
            ichan = SSP->GetSourceGrid()->GetChannum(Label);

        if(ichan<0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Label (%s) not in data file, or not selected. \n", Label);
            return NULL;
        }
        Dtype = U_DAT_SSP;
    }
    return GetFilteredMultiChan(Iepoch, Dtype, ichan);
}

UMultiChan* UMEEGDataEpochsExt::GetFilteredMultiChan(int Iepoch, DataType Dtype, int ichan) const
/*
    return a new pointer to a MultiChan-object, containing the  filtered data of
    epoch Iepoch.
    if(ichan<0) return filtered data of all channels of Dtype
    else        return filtered data of channel ichan, of type Dtype.
                       (The index ichan is running for each data type separately)

    On error: return NULL;
 */
{
    if(Data  ==NULL || Data->GetError()  !=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Data or Epochs not properly set. \n");
        return NULL;
    }
    if(Iepoch<0 || Iepoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Required epoch out of range (Iepoch=%d). \n",Iepoch);
        return NULL;
    }

    if(Dtype!=U_DAT_SSP)
        return UMEEGDataEpochs::GetFilteredMultiChan(Iepoch, Dtype, ichan);

/* Compute signal space projection */
    if(SSP==NULL || SSP->GetError()!=U_OK || SSP->GetSourceGrid()==NULL ||
        (SSP->GetGridMEG()==NULL && SSP->GetGridEEG()==NULL)    )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Signal Space Projection requested, but SSP object not properly set. \n");
        return NULL;
    }
    UMultiChan* Mdat = NULL; if(SSP->GetGridMEG()) Mdat = UMEEGDataEpochs::GetFilteredMultiChan(Iepoch, U_DAT_MEG, SSP->GetGridMEG());
    UMultiChan* Edat = NULL; if(SSP->GetGridEEG()) Edat = UMEEGDataEpochs::GetFilteredMultiChan(Iepoch, U_DAT_EEG, SSP->GetGridEEG());
    UMultiChan* Ddat = SSP->ProjectData(Mdat, Edat, ichan);
    delete Mdat;
    delete Edat;
    if(Ddat && Ddat->GetError()==U_OK)
    {
        UGrid*    G = Data->GetSelectedGrid(U_DAT_SSP);
        ErrorType E = Ddat->SelectChannels(G);
        delete G;
        if(E==U_OK) return Ddat;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Selecting Channels. \n");
        delete Ddat;
        return NULL;
    }
    delete Ddat;
    CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetFilteredMultiChan(). Projecting signals onto signal space. \n");
    return NULL;
}

ErrorType UMEEGDataEpochsExt::SetSSP(const USignalSpaceProj* NewSSP)
{
    if(NewSSP==NULL)
    {
        SSP = NULL;
        if(Data==NULL) return U_OK;
        return Data->RemoveSSPChannels();
    }
    if(NewSSP->GetError() || NewSSP->GetSourceGrid()==NULL ||
        (NewSSP->GetGridMEG()==NULL && NewSSP->GetGridEEG()==NULL) )
    {
        CI.AddToLog("ERROR:UMEEGDataEpochsExt::SetSSP(). Argument not properly initialized. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR:UMEEGDataEpochsExt::SetSSP(). UDataBase() member not (properly) set. \n");
        return U_ERROR;
    }
    if(Data->SetSSPChannels(NewSSP->GetSourceGrid())!=U_OK)
    {
        SetSSP(NULL);
        CI.AddToLog("ERROR:UMEEGDataEpochsExt::SetSSP(). Setting SSP channels. \n");
        return U_ERROR;
    }
    SSP = NewSSP;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::SetMinimize(UCostminimize C, bool AdFordMod)
{
    Cmin             = C;
    AdvancedForwMod  = AdFordMod;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::SetCovar(const UCovariance* SpatCov, UEMfield::FieldType SensorsUsed, const UCovariance* TempCov)
{
    if(Data==NULL)
    {
        CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Data not set. \n");
        return U_ERROR;
    }
    if(SpatCov==NULL || SpatCov->GetError()!=U_OK)
    {
        CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Invalid or NULL spatial covariance argument. \n");
        return U_ERROR;
    }
    if(TempCov!=NULL && TempCov->GetError()!=U_OK)
    {
        CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Invalid temporal covariance argument. \n");
        return U_ERROR;
    }
    int nKan = 0;
    if(SensorsUsed==UEMfield::U_MEG || SensorsUsed==UEMfield::U_MEGEEG)
    {
        if(Data->GetGridMEG()==NULL)
        {
            CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). MEG input data requested, but MEG data not selected. \n");
            return U_ERROR;
        }
        nKan += Data->GetGridMEG()->GetNpoints();
    }
    if(SensorsUsed==UEMfield::U_EEG || SensorsUsed==UEMfield::U_MEGEEG)
    {
        if(Data->GetGridEEG()==NULL)
        {
            CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). EEG input data requested, but EEG data not selected. \n");
            return U_ERROR;
        }
        nKan += Data->GetGridEEG()->GetNpoints();
    }
    if(nKan!=SpatCov->GetNdim())
    {
        CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Number of requested channels (nKan =%d) not equal to size of spatial covariance (nDim=%d). \n", nKan, SpatCov->GetNdim());
        return U_ERROR;
    }
    delete CovXX; CovXX = NULL;
    delete CovTT; CovTT = NULL;
    CovXX = new UCovariance(*SpatCov);

    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        delete CovXX; CovXX = NULL;
        CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Copying spatial covariance object. \n");
        return U_ERROR;
    }
    if(TempCov)
    {
        CovTT = new UCovariance(*TempCov);
        if(CovTT==NULL || CovTT->GetError()!=U_OK)
        {
            delete CovTT; CovTT = NULL;
            CI.AddToLog("UMEEGDataEpochsExt::SetCovar(). Copying temporal covariance object. \n");
            return U_ERROR;
        }
    }
    SensType = SensorsUsed;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::SetOutputFormat(UFileName F, bool SingleFile, bool WriteAllDipoles, bool TimeInSamp, bool UseAbsTime, bool AppendResult, int NumDigits, bool UseOldUnits)
{
    UDirectory D=F.GetDirectory();
    if(D.GetStatus()!=UDirectory::U_EXIST)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::SetOutputFormat(). Directory of output file does not exist: %s   .\n",(const char*)F);
        return U_ERROR;
    }

    FileOut     = F;
    OneFile     = SingleFile;
    AllDipoles  = WriteAllDipoles;
    TimeSamples = TimeInSamp;
    AbsoluteTime= UseAbsTime;
    Append      = AppendResult;
    NDigit      = NumDigits;
    if(NumDigits<2 || NumDigits>12)
    {
        NDigit = 6;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::SetOutputFormat(). Number of digits (%d) out of range. Set number of digits qual to %d . \n", NumDigits, NDigit);
    }
    OldUnits    = UseOldUnits;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::InitFindCoils(UVector3 Start, StartDipType SType, UMeshPoints::RegionType GlobalSRegion, int Ngrd,
                            CalibType CType, double* calib)
{
    if(this==NULL || this->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). this NULL or not (properly) set. \n");
        return U_ERROR;
    }
    if(Data  ==NULL || Data  ->GetError()!=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Data and or epohs not (properly) set. \n");
        return U_ERROR;
    }
    if(SType!=U_SDIP_DEFAULT && SType!=U_SDIP_PREVSAMP && SType!=U_SDIP_GLOBSEARCH && SType!=U_SDIP_GLOBSEARCHPREV)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils() Invalid start dipole mode (ST=%d).\n", SType);
        return U_ERROR;
    }


/* Test the arguments */
    if( CType==U_NOCALIB ||
       (CType==U_CONSTANT && calib==NULL) )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Invalid callibration parameters. \n");
        return U_ERROR;
    }
    if(CType==U_ITERATIVE)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Iterative calibration not yet implemented. \n");
        return U_ERROR;
    }

    int nADC        = Data  ->GetNADC();
    int nEpochs     = Epochs->GetnEpochs();
    if(nADC<=0 || nEpochs<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). nADC = %d; nEpochs = %d; \n",nADC, nEpochs);
        return U_ERROR;
    }

    delete ULC; ULC = new ULocCoil(Cmin, GetMEGForwardBalancing(), Data);
    if(ULC==NULL || ULC->GetError()!=U_OK)
    {
        delete ULC; ULC = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Creating ULocCoil() object. \n");
        return U_ERROR;
    }
    if(ULC->ResetCoilCalibration(calib)!=U_OK)
    {
        delete ULC; ULC = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Resetting ULocCoil() object. \n");
        return U_ERROR;
    }
    UDipole* Dipoles = new UDipole[nADC*nEpochs];

    if(Dipoles)
    {
        for(int k=0; k<nADC; k++)
        {
            Dipoles[k].Setx(Start + UVector3(0.,0.,k));
            Dipoles[k].SetDipoleType(UDipole::Magnetic);
        }
    }
    if(!Dipoles || ULC->UStartDipole::InitStart(SType, Dipoles, nADC, Ngrd, GlobalSRegion) !=U_OK)
    {
        delete[] Dipoles;
        delete   ULC;      ULC = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitFindCoils(). Initializing ULocCoil() object. \n");
        return U_ERROR;
    }
    delete[] Dipoles;

    return U_OK;
}
UDipoleList* UMEEGDataEpochsExt::ComputeFindCoils(double BadThreshold, UString** ErrorString, double* MaxResErrPerc)
{
    if(this==NULL || this->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeFindCoils(). this NULL or not (properly) set. \n");
        return NULL;
    }
    if(Data  ==NULL || Data  ->GetError()!=U_OK  ||
       Epochs==NULL || Epochs->GetError()!=U_OK )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeFindCoils(). Data and or epohs not (properly) set. \n");
        return NULL;
    }
    if(ULC==NULL || ULC->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeFindCoils(). Object not properly initialized. \n");
        return NULL;
    }
    int nADC        = Data  ->GetNADC();
    int nEpochs     = Epochs->GetnEpochs();
    if(nADC<=0 || nEpochs<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeFindCoils(). nADC = %d; nEpochs = %d; \n",nADC, nEpochs);
        return NULL;
    }
    if(ErrorString) *ErrorString = new UString[nEpochs];

    UDipoleList* DipList = new UDipoleList(nADC*nEpochs, UDipole::Magnetic);
    UDipole*     Dipoles = NULL;
    if(DipList && DipList->GetError()==U_OK) Dipoles = DipList->GetDipoles();
    if(DipList==NULL || Dipoles==NULL)
    {
        delete   DipList;
        delete[] Dipoles;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeFindCoils(). Memory allocation for DipList. \n");
        return NULL;
    }

    if(MaxResErrPerc) *MaxResErrPerc = 0.;
    int ipNADC = 0;
    for(int m=0; m<nEpochs; m++, ipNADC+=nADC)
    {
        CI.AddToLog("%3d\t ",m);

/* Get the data corresponding to the Epochs */

        double  *MEGDataEp = GetFilteredData(m, U_DAT_MEG);
        double  *ADCDataEp = GetFilteredData(m, U_DAT_ADC);

        int       NsampEp  = Epochs->GetNsamp(m);
        ErrorType Error    = ULC->InitCompute(MEGDataEp, ADCDataEp, NsampEp, BadThreshold);
        if(ErrorString) (*ErrorString)[m] = UString(ULC->GetErrorString());


        delete[] MEGDataEp;
        delete[] ADCDataEp;
        if(Error!=U_OK) continue;

/* Copy start parameters*/
        if(m>0) for(int k=0; k<nADC; k++) Dipoles[ipNADC+k] = Dipoles[ipNADC-nADC+k];

        double ResErrPerc = 100.;
        ULC->ComputeCoils(Dipoles+ipNADC, ULocCoil::FREE_STRENGTH, &ResErrPerc);
        ULC->UpdateCoilCalibration(Dipoles+ipNADC);

        if(MaxResErrPerc && ResErrPerc > *MaxResErrPerc) *MaxResErrPerc = ResErrPerc;

        for(int k=0; k<nADC; k++) DipList->SetDipole(ipNADC+k, Dipoles[ipNADC+k]);
        if(*ErrorString) (*ErrorString)[m] = UString(ULC->GetErrorString());

        CI.AddToLog("%f [%%]\n ",ResErrPerc);
    }
    CI.AddToLog("\n");
    delete[] Dipoles;

/* Compute the optimum coil callibrations*/
    ULC->ComputeCoilCalibration();

    return DipList;
}

ErrorType UMEEGDataEpochsExt::InitMovingDipoleModel(const UHeadModel* HM, UDipole::DipoleType DipType, StartDipType ST, int NStartPnts, double MaxStartError, double MinPowFact, bool ConfidenceLimits, double AmatThreshold, bool MarkOutliers)
{
    if(HM==NULL || HM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel(). NULL or erroneous UHeadModel argument. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel(). Data (properly) not set. \n");
        return U_ERROR;
    }
    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel(). Covariance not (properly) set. \n");
        return U_ERROR;
    }
    if(ST!=U_SDIP_DEFAULT && ST!=U_SDIP_PREVSAMP && ST!=U_SDIP_GLOBSEARCH && ST!=U_SDIP_GLOBSEARCHPREV && ST!=U_SDIP_FILE)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel() Invalid start dipole mode (ST=%d).\n", ST);
        return U_ERROR;
    }

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdvancedForwMod==true) ReRefForw = GetMEGForwardBalancing();

    const UGrid* gridM = NULL;
    if((SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridMEG()) gridM = Data->GetGridMEG();
    else if(SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitMovingDipoles(). Required MEG data not present in dataset. \n");

    const UGrid* gridE = NULL;
    if((SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridEEG()) gridE = Data->GetGridEEG();
    else if(SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitMovingDipoles(). Required EEG data not present in dataset. \n");

    bool   CTAbs           = false;
    bool   ExportGlobTable = false;
    delete ULMD;
    ULMD = new ULocMovDip(Cmin, OldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), gridM, gridE, HM, CTAbs, CovXX);

    if(ULMD==NULL || ULMD->GetError()!=U_OK)
    {
        delete ULMD; ULMD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel(). Creating ULovMovDip-object. \n");
        return U_ERROR;
    }
    if(MarkOutliers==true) ULMD->SetAmatThreshold( fabs(AmatThreshold));
    else                   ULMD->SetAmatThreshold(-fabs(AmatThreshold));

    UDipole DumDip(UVector3(0.,0.,5.), UVector3(1.,1.,1.), DipType);
    if(ULMD->InitStart(ST, &DumDip, 1, NStartPnts)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitMovingDipoleModel(). Initializing starting point algorithm. \n");
        return U_ERROR;
    }

    MaxMovDipFitError = MaxStartError;
    MinRelDataPower   = MinPowFact;
    return U_OK;
}

ErrorType UMEEGDataEpochsExt::FitMovingDipoles(int Iepoch)
{
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitMovingDipoles(). Data or Epochs not (properly) initialized. \n");
        return U_ERROR;
    }
    if(ULMD==NULL || ULMD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitMovingDipoles(). ULovMovDip-object not (properly) initialized. \n");
        return U_ERROR;
    }


    FILE*      fpOut = NULL;
    if(OneFile==true)
    {
        if(FileOut.GetStatus()==UFileName::U_FILE_CANBEREAD)  fpOut = fopen(FileOut,"at", true);
        else                                                  fpOut = fopen(FileOut,"wt", true);
    }
    else
    {
        UFileName FileNum = FileOut;
        FileNum.InsertFileNumber(Iepoch,4);
        if(FileNum.GetStatus()==UFileName::U_FILE_CANBEREAD)  fpOut = fopen(FileNum,"at", true);
        else                                                  fpOut = fopen(FileNum,"wt", true);
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitMovingDipoles(). Cannot open file for writing: %s .\n",(const char*)FileOut);
        return U_ERROR;
    }

/* Allocate Arrays */
    bool    ConfidenceLimits = false;

    UEvent  Begin       = Epochs->GetBegin(Iepoch);
    UEvent  End         = Epochs->GetEnd(Iepoch);
    int     NsampEp     = GetNSampEpoch(Iepoch);

    UDipole *Dipoles    = new UDipole[NsampEp];
    double  *Residuals  = new double[NsampEp];
    double  *DataNorm   = new double[NsampEp];
    double  *ConfIntPos = NULL;
    if(ConfidenceLimits==true)
        ConfIntPos      = new double[3*NsampEp];

    if(!Residuals || !DataNorm || !Dipoles || (ConfIntPos==NULL && ConfidenceLimits==true))
    {
        delete[] DataNorm;
        delete[] Residuals;
        delete[] Dipoles;
        delete[] ConfIntPos;
        delete ULMD;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitMovingDipoles(). Memory allocation. \n");
        fclose(fpOut);
        return U_ERROR;
    }
    for(int n=0; n<NsampEp; n++) Dipoles[n].SetDipoleType(ULMD->GetDipType());
    Dipoles[0] = UDipole(UVector3(1.,1.,1.)+ULMD->GetSpos(),UVector3(1.,1.,1.),Dipoles[0].GetDipoleType());

/* Get Data. */
    UMultiChan*  MCmeg     = NULL;
    UMultiChan*  MCeeg     = NULL;
    int          nKan      = 0;

    switch(SensType)
    {
    case UEMfield::U_MEGEEG:
        MCmeg = GetFilteredMultiChan(Iepoch, U_DAT_MEG);
        MCeeg = GetFilteredMultiChan(Iepoch, U_DAT_EEG);
        nKan  = Data->GetNmeg() + Data->GetNeeg();
        break;

    case UEMfield::U_MEG:
        MCmeg = GetFilteredMultiChan(Iepoch, U_DAT_MEG);
        nKan  = Data->GetNmeg();
        break;

    case UEMfield::U_EEG:
        MCeeg = GetFilteredMultiChan(Iepoch, U_DAT_EEG);
        nKan  = Data->GetNeeg();
        break;
    }

    if( (!MCmeg && SensType==UEMfield::U_MEGEEG) || (!MCmeg && SensType==UEMfield::U_MEG) ||
        (!MCeeg && SensType==UEMfield::U_MEGEEG) || (!MCeeg && SensType==UEMfield::U_EEG) )
    {
        delete[] DataNorm;
        delete[] Residuals;
        delete[] ConfIntPos;
        delete[] Dipoles;
        delete   MCmeg;
        delete   MCmeg;
        delete ULMD; ULMD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitMovingDipoles(). Reading MEG/EEG data in epoch %d .\n",Iepoch);

        fclose(fpOut);
        return U_ERROR;
    }

/* Set Data and compute dipoles*/
    double MinDataPowMEG = 0.;
    double MinDataPowEEG = 0.;
    ULMD->SetDataMeg(MCmeg, MinDataPowMEG);
    ULMD->SetDataEeg(MCeeg, MinDataPowEEG);
    ULMD->ComputeDipoles(Dipoles, ConfIntPos, Residuals, DataNorm, MaxMovDipFitError);

/* Write File header */
    if(Iepoch==0||OneFile==false)
    {
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"%s",CI.GetProperties("//    "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        fprintf(fpOut,"//\n");

/****
        if(PowerDistMEG)
        {
            fprintf(fpOut,"//     MEG power distribution:\n");
            fprintf(fpOut,"%s",PowerDistMEG->GetProperties("//    "));
        }
        if(PowerDistEEG)
        {
            fprintf(fpOut,"//     EEG power distribution:\n");
            fprintf(fpOut,"%s",PowerDistEEG->GetProperties("//    "));
        }
 ****/
        if(Data->GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",Data->GetMarkerArray()->GetProperties("//  ").GetString());
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"//   AbsoluteTime = %s  // true iff time/sample corrected trial number \n", BoolAsText(AbsoluteTime));
        fprintf(fpOut,"%s",GetProperties("//  ").GetString());

        if((SensType==UEMfield::U_MEGEEG || SensType==UEMfield::U_MEG)&&MinDataPowMEG>0)
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"//   All samples with powers lower than %6.1f times the MEG median have been skipped prior to dipole fitting.\n", MinRelDataPower);
        }
        if((SensType==UEMfield::U_MEGEEG || SensType==UEMfield::U_EEG)&&MinDataPowEEG>0)
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"//   All samples with powers lower than %6.1f times the EEG median have been skipped prior to dipole fitting.\n", MinRelDataPower);
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
        fprintf(fpOut,"%s", (const char*)ULMD->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");
/****
        fprintf(fpOut,"// HEAD MODEL:\n");
        fprintf(fpOut,"%s",HModel->GetProperties("//  "));
        fprintf(fpOut,"//\n");
 ****/
    }

    char line[400];
    int  nc=0;
    if(Iepoch==0||OneFile==false)
    {
        if(TimeSamples==true)   nc += sprintf(line,"Samp");
        else                    nc += sprintf(line,"Time");

        nc += Dipoles[0].PrintParameters(line+nc,-(300-nc-1));
        nc += sprintf(line+nc,"\tERROR(%%)");
        if(ConfIntPos)
        {
            nc += sprintf(line+nc,"\tDeltaX ");
            nc += sprintf(line+nc,"\tDeltaY ");
            nc += sprintf(line+nc,"\tDeltaZ ");
        }
        nc += sprintf(line+nc,"\tAverDataPower");

        fprintf(fpOut,"%s\n",line);
    }
    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

    for(int i=0; i<NsampEp; i++)
    {
        if(AllDipoles==false && MaxMovDipFitError>0. && Residuals[i]>MaxMovDipFitError) continue;

        UEvent E = GetEvent(Iepoch, i);
        nc       = 0;

        if(AbsoluteTime==true)
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
            else                  nc += sprintf(line,"%f  "    ,Stime*E.GetAbsSample(Data->GetNsampTrial()));
        }
        else
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.sample);
            else                  nc += sprintf(line,"%f  "    ,Stime*E.sample);
        }
        nc += Dipoles[i].PrintParameters(line+nc,300-nc-1, -1, NDigit);
        nc += sprintf(line+nc,"\t%f",Residuals[i]);
        if(ConfIntPos)
        {
            nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i  ]);
            nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i+1]);
            nc += sprintf(line+nc,"\t%f",ConfIntPos[3*i+2]);
        }

        if(nKan)  nc += sprintf(line+nc,"\t%f",DataNorm[i]/nKan);
        else      nc += sprintf(line+nc,"\t0.0");

        fprintf(fpOut,"%s\n",line);
    }
    delete[] DataNorm;
    delete[] Residuals;
    delete[] ConfIntPos;
    delete[] Dipoles;
    delete  MCmeg;
    delete  MCeeg;

    fclose(fpOut);
    return U_OK;
}

UDipoleMoveList* UMEEGDataEpochsExt::GetDipoleMoveList(int Iepoch, const UHeadModel* HModel)
{
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). Data or Epochs not (properly) initialized. \n");
        return NULL;
    }
    if(ULMD==NULL || ULMD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). ULovMovDip-object not (properly) initialized. \n");
        return NULL;
    }

    bool    ConfidenceLimits = false;
    UDipoleMoveList* pDML = new UDipoleMoveList(Data, HModel, Epochs, TimeSamples, AbsoluteTime, ULMD->GetDipType(), ConfidenceLimits);

    if(pDML==NULL || pDML->GetError()!=U_OK)
    {
        delete pDML;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). Creating UDipoleMoveList-object. \n");
        return NULL;
    }

/* Allocate Arrays */
    UEvent  Begin       = Epochs->GetBegin(Iepoch);
    UEvent  End         = Epochs->GetEnd(Iepoch);
    int     NsampEp     = GetNSampEpoch(Iepoch);

    UDipole *Dipoles    = new UDipole[NsampEp];
    double  *Residuals  = new double[NsampEp];
    double  *DataNorm   = new double[NsampEp];
    double  *ConfIntPos = NULL;
    if(ConfidenceLimits==true)
        ConfIntPos      = new double[3*NsampEp];

    if(!Residuals || !DataNorm || !Dipoles || (ConfIntPos==NULL && ConfidenceLimits==true))
    {
        delete   pDML;
        delete[] DataNorm;
        delete[] Residuals;
        delete[] Dipoles;
        delete[] ConfIntPos;
        delete ULMD;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). Memory allocation. \n");
        return NULL;
    }
    for(int n=0; n<NsampEp; n++) Dipoles[n].SetDipoleType(ULMD->GetDipType());
    Dipoles[0] = UDipole(UVector3(1.,1.,1.)+ULMD->GetSpos(),UVector3(1.,1.,1.),Dipoles[0].GetDipoleType());

/* Get Data. */
    UMultiChan* MCmeg  = NULL;
    UMultiChan* MCeeg  = NULL;
    int         nKan   = 0;

    switch(SensType)
    {
    case UEMfield::U_MEGEEG:
        MCmeg     = GetFilteredMultiChan(Iepoch, U_DAT_MEG);
        MCeeg     = GetFilteredMultiChan(Iepoch, U_DAT_EEG);
        nKan      = Data->GetNmeg() + Data->GetNeeg();
        break;

    case UEMfield::U_MEG:
        MCmeg     = GetFilteredMultiChan(Iepoch, U_DAT_MEG);
        nKan      = Data->GetNmeg();
        break;

    case UEMfield::U_EEG:
        MCeeg     = GetFilteredMultiChan(Iepoch, U_DAT_EEG);
        nKan      = Data->GetNeeg();
        break;
    }

    if( (!MCmeg && SensType==UEMfield::U_MEGEEG) || (!MCmeg && SensType==UEMfield::U_MEG) ||
        (!MCeeg && SensType==UEMfield::U_MEGEEG) || (!MCeeg && SensType==UEMfield::U_EEG) )
    {
        delete   pDML;
        delete[] DataNorm;
        delete[] Residuals;
        delete[] Dipoles;
        delete[] ConfIntPos;
        delete   MCmeg;
        delete   MCeeg;
        delete ULMD; ULMD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). Reading MEG/EEG data in epoch %d .\n",Iepoch);

        return NULL;
    }

/* Set Data and compute dipoles*/
    double MinDataPowMEG = 0.;
    double MinDataPowEEG = 0.;
    if(ULMD->SetDataMeg(MCmeg, MinDataPowMEG) !=U_OK ||
       ULMD->SetDataEeg(MCeeg, MinDataPowEEG) !=U_OK ||
       ULMD->ComputeDipoles(Dipoles, ConfIntPos, Residuals, DataNorm, MaxMovDipFitError) !=U_OK)
    {
        delete   pDML;
        delete[] DataNorm;
        delete[] Residuals;
        delete[] Dipoles;
        delete[] ConfIntPos;
        delete   MCmeg;
        delete   MCeeg;
        delete ULMD; ULMD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::GetDipoleMoveList(). Computing dipoles in epoch %d .\n",Iepoch);

        return NULL;
    }

    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

    for(int i=0; i<NsampEp; i++)
    {
        if(AllDipoles==false && MaxMovDipFitError>0. && Residuals[i]>MaxMovDipFitError) continue;

        UEvent E = GetEvent(Iepoch, i);

        UDipoleMove Dip(Dipoles[i]);
        if(AbsoluteTime)       Dip.SetTime(Stime*E.GetAbsSample(Data->GetNsampTrial()));
        else                   Dip.SetTime(Stime*E.sample                          );
        Dip.SetGroup(Iepoch);
        Dip.SetResidualError(Residuals[i]);
        if(ConfIntPos)  Dip.SetDelta(UVector3(ConfIntPos+3*i));
        if(nKan)        Dip.SetMEGDataPower(DataNorm[i]/nKan);
        pDML->AddDipole(Dip);
    }
    delete[] DataNorm;
    delete[] Residuals;
    delete[] ConfIntPos;
    delete[] Dipoles;
    delete   MCmeg;
    delete   MCeeg;
    return pDML;
}

ErrorType UMEEGDataEpochsExt::InitStationaryDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints)
{
    if(HM==NULL || HM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). NULL or erroneous UHeadModel argument. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Data (properly) not set. \n");
        return U_ERROR;
    }
    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Spatial covariance not (properly) set. \n");
        return U_ERROR;
    }
    if(CovTT==NULL || CovTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Temporal covariance not (properly) set. \n");
        return U_ERROR;
    }
    if(ST!=U_SDIP_DEFAULT && ST!=U_SDIP_PREVSAMP && ST!=U_SDIP_GLOBSEARCH && ST!=U_SDIP_GLOBSEARCHPREV && ST!=U_SDIP_FILE)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel() Invalid start dipole mode (ST=%d).\n", ST);
        return U_ERROR;
    }
    if(ST==U_SDIP_FILE && DoesFileExist(StartFile)==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel() Dipole start file does not exist: %s  .\n", (const char*)StartFile);
        return U_ERROR;
    }

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdvancedForwMod==true) ReRefForw = GetMEGForwardBalancing();

    const UGrid* gridM = NULL;
    if((SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridMEG()) gridM = Data->GetGridMEG();
    else if(SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Required MEG data not present in dataset. \n");

    const UGrid* gridE = NULL;
    if((SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridEEG()) gridE = Data->GetGridEEG();
    else if(SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Required EEG data not present in dataset. \n");

/* Set the stationary dipole object*/
    delete ULSD;
    ULSD = new ULocStatDip(Cmin, OldUnits, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), gridM, gridE, HM, CovXX, CovTT);
    if(ULSD==NULL || ULSD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Cannot create ULocStatDip-object\n");
        delete ULSD; ULSD=NULL;
        return U_ERROR;
    }

    if(ULSD->InitStart(ST, StartFile, NGlobPoints, Ndipoles, DipEd)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitStationaryDipoleModel(). Initializing start parameters. \n");
        delete ULSD; ULSD=NULL;
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataEpochsExt::FitStationaryDipoles(int Iepoch, int Ndipoles, UDipoleEdit* DipEd, bool ConfInt, bool Bonferroni, int Ncomp, double SVDThreshold)
{
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitStationaryDipoles(). Data or Epochs not (properly) initialized. \n");
        return U_ERROR;
    }
    if(ULSD==NULL || ULSD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitStationaryDipoles(). ULocStatDip-object not (properly) initialized. \n");
        return U_ERROR;
    }

    FILE*      fpOut = NULL;
    if(OneFile==true)
    {
        if(FileOut.GetStatus()==UFileName::U_FILE_CANBEREAD)
            fpOut = fopen(FileOut,"at", true);
        else
            fpOut = fopen(FileOut,"wt", true);
    }
    else
    {
        UFileName FileNum = FileOut;
        FileNum.InsertFileNumber(Iepoch,4);
        if(FileNum.GetStatus()==UFileName::U_FILE_CANBEREAD)
            fpOut = fopen(FileNum,"at", true);
        else
            fpOut = fopen(FileNum,"wt", true);
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitStationaryDipoles(). Cannot open file for writing: %s .\n",(const char*)FileOut);
        return U_ERROR;
    }

    UEvent  Begin       = Epochs->GetBegin(Iepoch);
    UEvent  End         = Epochs->GetEnd(Iepoch);
    int     NsampEp     = GetNSampEpoch(Iepoch);

/* Allocate Arrays */
    double       Residual    = 0.;
    double       *DataNorm   = new double[NsampEp];
    int          nSTF        = ULSD->GetNfreeSTF();
    double       *STF        = new double[nSTF*NsampEp];
    double       *CIntervals = new double[nSTF*NsampEp];

    if(!DataNorm || !STF)
    {
        delete[] DataNorm;
        delete[] STF;
        delete[] CIntervals;
        delete   ULSD; ULSD = NULL;
        CI.AddToLog("ERROR: UFitDipoles::FitStationaryDipoles(). Memory allocation. \n");
        fclose(fpOut);
        return U_ERROR;
    }

/* Get Data */
    double  *DataEpMEG = NULL;
    double  *DataEpEEG = NULL;
    int     nKan       = 0;

    switch(SensType)
    {
    case UEMfield::U_MEGEEG:
        DataEpMEG = GetFilteredData(Iepoch, U_DAT_MEG);
        DataEpEEG = GetFilteredData(Iepoch, U_DAT_EEG);
        nKan = Data->GetNmeg() + Data->GetNeeg();
        break;

    case UEMfield::U_MEG:
        DataEpMEG = GetFilteredData(Iepoch, U_DAT_MEG);
        nKan = Data->GetNmeg();
        break;

    case UEMfield::U_EEG:
        DataEpEEG = GetFilteredData(Iepoch, U_DAT_EEG);
        nKan = Data->GetNeeg();
        break;
    }

    if((!DataEpMEG && SensType==UEMfield::U_MEGEEG) || (!DataEpMEG && SensType==UEMfield::U_MEG) ||
       (!DataEpEEG && SensType==UEMfield::U_MEGEEG) || (!DataEpEEG && SensType==UEMfield::U_EEG) ||
         ULSD->SetData(DataEpMEG, DataEpEEG, NsampEp) != U_OK)
    {
        delete[] DataNorm;
        delete[] STF;
        delete[] CIntervals;
        delete[] DataEpMEG;
        delete[] DataEpEEG;
        delete ULSD; ULSD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitStationaryDipoles(). Reading and setting MEG/EEG data in epoch %d .\n",Iepoch);

        fclose(fpOut);
        return U_ERROR;
    }

/* Set number of eigenvalues in Data to be taken into account */
    ULSD->SetNcomp(Ncomp, SVDThreshold);

/* Compute dipoles, source time functions and confidence intervals */
    if(ULSD->ComputeDipoles(DipEd, Ndipoles, &Residual, DataNorm, STF)!=U_OK)
    {
        delete[] DataNorm;
        delete[] STF;
        delete[] CIntervals;
        delete[] DataEpMEG;
        delete[] DataEpEEG;
        delete ULSD; ULSD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitStationaryDipoles(). Computing dipoles in epoch %d .\n",Iepoch);

        fclose(fpOut);
        return U_ERROR;
    }
    if(ConfInt==true)
    {
        int l=0;
        for(l=0;l<Ndipoles;l++)if(DipEd[l].GetRotating()==true) break;
        if(l==Ndipoles) // no dipoles are rotating
            ULSD->ComputeConfIntervals(CIntervals,Bonferroni);
        else
            CI.AddToLog("WARNING: UMEEGDataEpochsExt::FitStationaryDipoles(). Computing Confidence Intervals not implemented for rotating dipoles (yet).\n");
    }

/* Export results */

/* Write File header */
    if(Iepoch==0||OneFile==false)
    {
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"//   Results obtained with\n");
        fprintf(fpOut,"%s",CI.GetProperties("//    "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        if(Data->GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",(const char*)Data->GetMarkerArray()->GetProperties("//  "));
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"%s",(const char*)GetProperties("//  "));

        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
        fprintf(fpOut,"%s", (const char*)ULSD->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");
    }

/* Write Header of Dipole Results */
    char line[200+100*MAXSTATDIP];
    int  nc=0;
    if(Iepoch==0||OneFile==false)
    {
        if(TimeSamples=true)      nc += sprintf(line,"Samp");
        else                      nc += sprintf(line,"Time");

        for(int l=0; l<Ndipoles; l++)
            nc += DipEd[l].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

        for(int l=0; l<Ndipoles; l++)
        {
            if(DipEd[l].GetRotating()==false)
            {
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\tSTF_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_R%d ",l);
                }
                else
                    nc += sprintf(line+nc,"\tSTF%d ",l);
            }
            else
            {
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\tSTF_x_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_y_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_z_L%d ",l);
                    nc += sprintf(line+nc,"\tSTF_x_R%d ",l);
                    nc += sprintf(line+nc,"\tSTF_y_R%d ",l);
                    nc += sprintf(line+nc,"\tSTF_z_R%d ",l);
                }
                else
                {
                    nc += sprintf(line+nc,"\tSTF_x%d ",l);
                    nc += sprintf(line+nc,"\tSTF_y%d ",l);
                    nc += sprintf(line+nc,"\tSTF_z%d ",l);
                }
            }
        }
        nc += sprintf(line+nc,"\tERROR(%%)");
        nc += sprintf(line+nc,"\tAverDataPower");

        if(ConfInt==true)
        {
            for(int l=0; l<Ndipoles; l++)
            {
                if(DipEd[l].GetRotating()==true) continue;
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\tConfInt_L%d ",l);
                    nc += sprintf(line+nc,"\tConfInt_R%d ",l);
                }
                else
                    nc += sprintf(line+nc,"\tConfInt%d ",l);
            }
        }
        fprintf(fpOut,"%s\n",line);
    }

/* Write Dipole Results */
    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

    for(int i=0; i<NsampEp; i++)
    {
        UEvent E = GetEvent(Iepoch, i);
        nc       = 0;
        if(AbsoluteTime)
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
            else                  nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(Data->GetNsampTrial()));
        }
        else
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.sample);
            else                  nc += sprintf(line,"%f  ",Stime*E.sample);
        }
        for(int l=0; l<Ndipoles; l++)
            nc += DipEd[l].PrintParameters(line+nc,200+100*MAXSTATDIP-nc-1);
        int istf=0; //s keeps track of index of stf (row number in STF[])
        for(int l=0; l<Ndipoles; l++)
        {
            if(DipEd[l].GetRotating()==false)
            {
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\t%f ",STF[istf*NsampEp+i]); istf++;
                    nc += sprintf(line+nc,"\t%f ",STF[istf*NsampEp+i]); istf++;
                }
                else
                {
                    nc += sprintf(line+nc,"\t%f ",STF[istf*NsampEp+i]); istf++;
                }
            }
            else
            {
                UDipole DD    = (UDipole)DipEd[l];
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    double  dd[6] = {STF[(istf  )*NsampEp+i], STF[(istf+1)*NsampEp+i], STF[(istf+2)*NsampEp+i],STF[(istf+3)*NsampEp+i], STF[(istf+4)*NsampEp+i], STF[(istf+5)*NsampEp+i]};
                    istf+=6;
                    DD.Setd(UVector3(dd));
                    DD.SetdSym(UVector3(dd+3));
                }
                else
                {
                    double  dd[3] = {STF[(istf  )*NsampEp+i], STF[(istf+1)*NsampEp+i], STF[(istf+2)*NsampEp+i]};
                    istf+=3;
                    DD.Setd(UVector3(dd));
                    dd[1] = -dd[1];
                    DD.SetdSym(UVector3(dd));
                }
                nc += DD.PrintParameters(line+nc,200+100*MAXSTATDIP-nc-1);
            }
        }
        nc += sprintf(line+nc,"\t%f",Residual);
        if(nKan)    nc += sprintf(line+nc,"\t%f",DataNorm[i]/nKan);
        else        nc += sprintf(line+nc,"\t0.0");

        if(ConfInt==true)
        {
            int iConfSTF=0;
            for(int l=0; l<Ndipoles; l++,iConfSTF++)
            {
                if(DipEd[l].GetRotating()==true) continue;
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\t%f ",CIntervals[iConfSTF*NsampEp+i]);
                    iConfSTF++;
                    nc += sprintf(line+nc,"\t%f ",CIntervals[iConfSTF*NsampEp+i]);
                }
                else
                    nc += sprintf(line+nc,"\t%f ",CIntervals[iConfSTF*NsampEp+i]);
            }
        }
        fprintf(fpOut,"%s\n",line);
    }
    fclose(fpOut);

    delete[] DataNorm;
    delete[] STF;
    delete[] CIntervals;
    delete[] DataEpMEG;
    delete[] DataEpEEG;

    delete ULSD; ULSD = NULL;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::InitCoupledDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints)
{
/* Test arguments */
    if(HM==NULL || HM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). NULL or erroneous UHeadModel argument. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Data (properly) not set. \n");
        return U_ERROR;
    }
    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Spatial covariance not (properly) set. \n");
        return U_ERROR;
    }
    if(CovTT==NULL || CovTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Temporal covariance not (properly) set. \n");
        return U_ERROR;
    }
    for(int iDip=0;iDip<Ndipoles;iDip++)
    {
        if(DipEd[iDip].GetRotating()!=false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Not implemented for rotating dipoles (yet).\n");
            return U_ERROR;
        }
    }
    if(ST!=U_SDIP_DEFAULT && ST!=U_SDIP_PREVSAMP && ST!=U_SDIP_GLOBSEARCH && ST!=U_SDIP_GLOBSEARCHPREV && ST!=U_SDIP_FILE)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel() Invalid start dipole mode (ST=%d).\n", ST);
        return U_ERROR;
    }
    if(ST==U_SDIP_FILE && DoesFileExist(StartFile)==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel() Dipole start file does not exist: %s  .\n", (const char*)StartFile);
        return U_ERROR;
    }

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdvancedForwMod==true) ReRefForw = GetMEGForwardBalancing();

    const UGrid* gridM = NULL;
    if((SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridMEG()) gridM = Data->GetGridMEG();
    else if(SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Required MEG data not present in dataset. \n");

    const UGrid* gridE = NULL;
    if((SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridEEG()) gridE = Data->GetGridEEG();
    else if(SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Required EEG data not present in dataset. \n");

/* Set the Coupled Dipole Model object*/
    delete ULCD;

    ULCD = new ULocCodeDip(Cmin, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), gridM, gridE, HM, CovXX, CovTT);
    if(ULCD==NULL || ULCD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Cannot create ULocStatDip-object\n");
        delete ULCD; ULCD=NULL;
        return U_ERROR;
    }

    if(ULCD->InitStart(ST, StartFile, NGlobPoints, Ndipoles, DipEd)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Initializing start parameters. \n");
        delete ULCD; ULCD=NULL;
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataEpochsExt::FitCoupledDipoleModel(int Ndipoles, UDipoleEdit* DipEd, int Ncomp, double SVDThreshold, bool** CoupleMat, char** MarkerNames, int nCondition, int nDipSTF, int nBasicSTF)
{
/* Test arguments */
    if(Ndipoles<=0 || !DipEd || !CoupleMat || !MarkerNames || nCondition<=0 || nDipSTF<=0 || nBasicSTF<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Invalid Argument.\n");
        return U_ERROR;
    }
    for(int iDip=0;iDip<Ndipoles;iDip++)
    {
        if(DipEd[iDip].GetRotating()!=false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Not implemented for rotating dipoles (yet).\n");
            return U_ERROR;
        }
    }
/* Test whether current object settings are appropriate */
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Data or Epochs not (properly) initialized. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Epochs of different length.\n");
        return U_ERROR;
    }
    if(ULCD==NULL || ULCD->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). ULocCodeDip-object not (properly) initialized. \n");
        delete ULCD; ULCD = NULL;
        return U_ERROR;
    }

/* Setting Couple design */
    int    iCond       = 0;
    if(ULCD->SetCoupleDesign(CoupleMat, MarkerNames, nCondition, nBasicSTF, DipEd, Ndipoles)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Error in setting couple design in ULocCodeDip-object.\n");
        delete ULCD; ULCD = NULL;
        return U_ERROR;
    }

/* Compute average data and number of trials per marker (i.e. per condition) */
    double** DataMEG = new double*[nCondition];
    double** DataEEG = NULL;
    int      nSamp   = GetNSampEpoch(0);
    int      nChan   = Data->GetNmeg()+ Data->GetNeeg();
    int*     nEpochPerCondition = new int[nCondition];

    switch(SensType)
    {
    case UEMfield::U_MEG:

        for(iCond=0;iCond<nCondition;iCond++)
        {
            nEpochPerCondition[iCond]=0;
            DataMEG[iCond] = GetAverageMarkerData(MarkerNames[iCond],U_DAT_MEG,nEpochPerCondition+iCond);
            if(DataMEG[iCond]==NULL)
            {
                for(int jCond=0; jCond<iCond; jCond++)
                    delete[] DataMEG[jCond];
                delete[] DataMEG;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel() Computing data for marker %s.\n", MarkerNames[iCond]);
                return U_ERROR;
            }
        }
        break;

    default:
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Not implemented for EEG data yet.\n");
            for(int iCond=0; iCond<nCondition; iCond++)
                delete[] DataMEG[iCond];
            delete[] DataMEG;
            delete ULCD; ULCD = NULL;
            return U_ERROR;
        }
    }

/* Setting the Data in ULCD */
    if(ULCD->SetData(DataMEG, DataEEG, nEpochPerCondition, nCondition) != U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Error in setting data in ULocCodeDip-object.\n");
        for(int iCond=0; iCond<nCondition; iCond++)
            delete[] DataMEG[iCond];
        delete[] DataMEG;
        delete ULCD; ULCD = NULL;
        return U_ERROR;
    }
    ULCD->SetNComp(Ncomp, SVDThreshold);
    if(DataMEG)
    {
        for(iCond=0;iCond<nCondition;iCond++)
            if(DataMEG[iCond])
                delete[] DataMEG[iCond];
    }
    delete[] DataMEG;
    if(DataEEG)
    {
        for(iCond=0;iCond<nCondition;iCond++)
            if(DataEEG[iCond])
                delete[] DataEEG[iCond];
    }
    delete[] DataEEG;

/* Compute Dipoles */
    UEvent   Begin      = Epochs->GetBegin(0);
    UEvent   End        = Epochs->GetEnd(0);
    double   residual   = 0.;
    double** DNorm      = new double*[nCondition];
    double*  BasicSTF   = new double[nBasicSTF*nSamp];
    double*  resPerCond = new double[nCondition];

    if(DNorm && BasicSTF && resPerCond)
    {
        for(iCond=0;iCond<nCondition;iCond++)
        {
            DNorm[iCond]= new double[nSamp];
            if(DNorm[iCond])
            {
                for(int i=0;i<nSamp;i++) DNorm[iCond][i]=0.;
            }
            else
            {
                for(int jCond=0;jCond<iCond;jCond++)
                   delete[] DNorm[jCond];
                delete[] DNorm;
                delete[] BasicSTF;
                delete[] resPerCond;
                delete ULCD; ULCD = NULL;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Memory allocation error.\n");
                return U_ERROR;
            }
        }
    }
    else
    {
        for(iCond=0;iCond<nCondition;iCond++)
        {
            if (DNorm[iCond]) delete[] DNorm[iCond];
        }
        delete[] DNorm;
        delete[] BasicSTF;
        delete[] resPerCond;
        delete ULCD; ULCD = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Memory allocation error.\n");
        return U_ERROR;
    }

    int elt=0;
    for(elt=0;elt<nCondition;elt++) resPerCond[elt]=0.;
    for(iCond=0;iCond<nCondition;iCond++)
        for(elt=0;elt<nSamp;elt++)  DNorm[iCond][elt]=0.;
    for(elt=0;elt<nBasicSTF*nSamp;elt++)  BasicSTF[elt]=0.;

    if(ULCD->ComputeDipoles(DipEd, Ndipoles, &residual, DNorm, BasicSTF, resPerCond) !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Error in computing dipoles in ULocCodeDip-object.\n");
        for(iCond=0;iCond<nCondition;iCond++)
        {
            if (DNorm[iCond]) delete[] DNorm[iCond];
        }
        delete[] DNorm;
        delete[] BasicSTF;
        delete[] resPerCond;
        delete ULCD; ULCD = NULL;
        return U_ERROR;
    }

/* Export Results */
/* Write Header */
    FILE* fpOut = NULL;

/* Write Dipole file for each condition separately */
    for(iCond=0;iCond<nCondition;iCond++)
    {
        UFileName FileOutCond = FileOut;
        FileOutCond.InsertFileNumber(iCond,3);
        fpOut = fopen(FileOutCond,"wt", true);
        fprintf(fpOut,"// CONDITION %s:\n//\n",MarkerNames[iCond]);
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"//   Results obtained with\n");
        fprintf(fpOut,"%s",CI.GetProperties("//    "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        if(Data->GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",(const char*)Data->GetMarkerArray()->GetProperties("//  "));
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"%s",(const char*)GetProperties("//  "));


        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
        fprintf(fpOut,"%s", (const char*)ULCD->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");

    /* Compute STFs for this condition */
        int nDipInCond=0;
        int DipInCondIndex[MAXCODES];
        double* CondSTF = new double[2*MAXCODEDIP*nSamp];
        for(elt=0;elt<2*MAXCODEDIP*nSamp;elt++) CondSTF[elt]=0.;
        if (ULCD->ComputeCodeOutput(iCond,nDipInCond,DipInCondIndex,BasicSTF,CondSTF,nSamp)!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitCoupledDipoleModel(). Error in ComputeCondOutput() for condition %d\n",iCond);
            for(iCond=0;iCond<nCondition;iCond++)
            {
                if (DNorm[iCond]) delete[] DNorm[iCond];
            }
            delete[] DNorm;
            delete[] BasicSTF;
            delete[] resPerCond;
            delete ULCD; ULCD = NULL;
            return U_ERROR;
        }

    /* Write header of dipole results */
        char line[200+100*MAXCODEDIP];
        int  nc=0;

        if(TimeSamples=true)  nc += sprintf(line,"Samp");
        else                  nc += sprintf(line,"Time");

        int l=0;
        for(   ; l<nDipInCond; l++)
            nc += DipEd[DipInCondIndex[l]].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

        for(l=0; l<nDipInCond; l++)
        {
            if(DipEd[DipInCondIndex[l]].GetDipoleType()==UDipole::SymmetricPos)
            {
                nc += sprintf(line+nc,"\tSTF_L%d ",l);
                nc += sprintf(line+nc,"\tSTF_R%d ",l);
            }
            else
                nc += sprintf(line+nc,"\tSTF%d ",l);

        }
        nc += sprintf(line+nc,"\tERROR(%%)");
        nc += sprintf(line+nc,"\tResPerConditionPerSample(%%)");
        nc += sprintf(line+nc,"\tAverDataPower");
        fprintf(fpOut,"%s\n",line);

/* Write Dipole Results for this condition */
        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

        for(int j=0; j<nSamp; j++)
        {
            UEvent E = GetEvent(0, j);
            nc       = 0;

            if(AbsoluteTime)
            {
                if(TimeSamples==true)    nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
                else                     nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(Data->GetNsampTrial()));
            }
            else
            {
                if(TimeSamples==true)    nc += sprintf(line,"%6.6d   ",E.sample);
                else                     nc += sprintf(line,"%f  ",Stime*E.sample);
            }
            int l=0;
            for(l=0; l<nDipInCond; l++)
            {
                nc += DipEd[DipInCondIndex[l]].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
            }
            int istf=0; //s keeps track of index of stf (row number in STF[])
            for(l=0; l<nDipInCond; l++)
            {
                if(DipEd[DipInCondIndex[l]].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                }
                else
                {
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                }
            }

            nc += sprintf(line+nc,"\t%f",residual);
            nc += sprintf(line+nc,"\t%f",resPerCond[iCond]);
            if(nChan)
                nc += sprintf(line+nc,"\t%f",DNorm[iCond][j]/(nChan*(nEpochPerCondition[iCond])));
            else
                nc += sprintf(line+nc,"\t0.0");
            fprintf(fpOut,"%s\n",line);

        }
        delete[] CondSTF;
        fclose(fpOut);
    }

/* Write Dipole file with computed basic STFs and Couple Matrices */
    FileOut.InsertBeforeExtension("BasicOutput");
    UFileName FileOutBasic = FileOut;
    fpOut = fopen(FileOutBasic,"wt", true);

    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut,"//   Results obtained with\n");
    fprintf(fpOut,"%s",CI.GetProperties("//    "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// DATA:\n");
    fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
    if(Data->GetMarkerArray())
    {
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA MARKERS:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetMarkerArray()->GetProperties("//  "));
    }
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// EPOCHS:\n");
    if(OneFile==false)
        fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
    else
    {
        if(Epochs->GetnEpochs()<10)
        {
            for(int k=0; k<Epochs->GetnEpochs(); k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
        }
        else
        {
            for(int k=0; k<9; k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            fprintf(fpOut,"//   ..., Etc. \n");
        }
    }
    fprintf(fpOut,"%s",(const char*)GetProperties("//  "));


    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// FITTING:\n");
    fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
    fprintf(fpOut,"%s", (const char*)ULCD->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"//\n");

 /* Write header of dipole results */
    char line[200+100*MAXCODEDIP];
    int  nc=0;

    if(TimeSamples=true)
        nc += sprintf(line,"Samp");
    else
        nc += sprintf(line,"Time");

    int l=0;
    for(   ; l<Ndipoles; l++)
        nc += DipEd[l].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

    for(l=0; l<Ndipoles; l++)
    {
        if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
        {
            nc += sprintf(line+nc,"\tSTF_L%d ",l);
            nc += sprintf(line+nc,"\tSTF_R%d ",l);
        }
        else
            nc += sprintf(line+nc,"\tSTF%d ",l);

    }
    fprintf(fpOut,"%s\n",line);

/* Write Dipole Results with basic STFs */
    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

    for(int j=0; j<nSamp; j++)
    {
        UEvent E = GetEvent(0, j);
        nc       = 0;

        if(AbsoluteTime)
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
            else                  nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(Data->GetNsampTrial()));
        }
        else
        {
            if(TimeSamples==true) nc += sprintf(line,"%6.6d   ",E.sample);
            else                  nc += sprintf(line,"%f  ",Stime*E.sample);
        }
        int l=0;
        for(l=0; l<Ndipoles; l++)
        {
            nc += DipEd[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
        }
        int istf=0; //s keeps track of index of stf (row number in STF[])
        for(l=0; l<Ndipoles; l++)
        {
            if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
            {
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
            }
            else
            {
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
            }
        }
        fprintf(fpOut,"%s\n",line);

    }
    fprintf(fpOut,"\n");
    fclose( fpOut);

/* Write the estimated coupling matrices to the BasicOutput file */
    for(iCond=0;iCond<nCondition;iCond++)
        ULCD->PrintCodeMat(FileOut,iCond,true);
    ULCD->PrintCodePars(FileOut,true);

/* delete all allocated arrays */
    for(iCond=0;iCond<nCondition;iCond++)
    {
        if (DNorm[iCond]) delete[] DNorm[iCond];
    }
    delete[] DNorm;
    delete[] BasicSTF;
    delete[] resPerCond;
    delete[] nEpochPerCondition;
    delete ULCD; ULCD = NULL;

    return U_OK;
}

ErrorType UMEEGDataEpochsExt::InitConstrainedDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints)
{
/* Test arguments */
    if(HM==NULL || HM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). NULL or erroneous UHeadModel argument. \n");
        return U_ERROR;
    }
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Data (properly) not set. \n");
        return U_ERROR;
    }
    if(CovXX==NULL || CovXX->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Spatial covariance not (properly) set. \n");
        return U_ERROR;
    }
    if(CovTT==NULL || CovTT->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Temporal covariance not (properly) set. \n");
        return U_ERROR;
    }
    for(int iDip=0;iDip<Ndipoles;iDip++)
    {
        if(DipEd[iDip].GetRotating()!=false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Not implemented for rotating dipoles (yet).\n");
            return U_ERROR;
        }
    }
    if(ST!=U_SDIP_DEFAULT && ST!=U_SDIP_PREVSAMP && ST!=U_SDIP_GLOBSEARCH && ST!=U_SDIP_GLOBSEARCHPREV && ST!=U_SDIP_FILE)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel() Invalid start dipole mode (ST=%d).\n", ST);
        return U_ERROR;
    }
    if(ST==U_SDIP_FILE && DoesFileExist(StartFile)==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel() Dipole start file does not exist: %s  .\n", (const char*)StartFile);
        return U_ERROR;
    }

    ReReferenceType  ReRefForw = U_REF_RAW;
    if(AdvancedForwMod==true) ReRefForw = GetMEGForwardBalancing();

    const UGrid* gridM = NULL;
    if((SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridMEG()) gridM = Data->GetGridMEG();
    else if(SensType==UEMfield::U_MEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Required MEG data not present in dataset. \n");

    const UGrid* gridE = NULL;
    if((SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG) && Data->GetGridEEG()) gridE = Data->GetGridEEG();
    else if(SensType==UEMfield::U_EEG||SensType==UEMfield::U_MEGEEG)                    CI.AddToLog("WARNING: UMEEGDataEpochsExt::InitCoupledDipoleModel(). Required EEG data not present in dataset. \n");

/* Set the Constrained Dipole Model object (ULocCodeDip) */
    delete ULED;

    ULED = new ULocCodeDip(Cmin, ReRefForw, Data->GetGridREF(), Data->GetpBalancing(), gridM, gridE, HM, CovXX, CovTT,true);
    if(ULED==NULL || ULED->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Cannot create ULocStatDip-object\n");
        delete ULED; ULED=NULL;
        return U_ERROR;
    }

    if(ULED->InitStart(ST, StartFile, NGlobPoints, Ndipoles, DipEd)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitConstrainedDipoleModel(). Initializing start parameters. \n");
        delete ULED; ULED=NULL;
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataEpochsExt::FitConstrainedDipoleModel(int Ndipoles, UDipoleEdit* DipEd, bool ConfInt, bool Bonferroni, int Ncomp, double SVDThreshold, char** MarkerNames, int nCondition, int nDipSTF, int nBasicSTF)
{
/* Test arguments */
    if(Ndipoles<=0 || !DipEd || !MarkerNames || nCondition<=0 || nDipSTF<=0 || nBasicSTF<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Invalid Argument.\n");
        return U_ERROR;
    }
    for(int iDip=0;iDip<Ndipoles;iDip++)
    {
        if(DipEd[iDip].GetRotating()!=false)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Not implemented for rotating dipoles (yet).\n");
            return U_ERROR;
        }
    }
/* Test whether current object settings are appropriate */
    if(Data  ==NULL || Data  ->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Data or Epochs not (properly) initialized. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Epochs of different length.\n");
        return U_ERROR;
    }
    if(ULED==NULL || ULED->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). ULocCodeDip-object not (properly) initialized. \n");
        delete ULED; ULED = NULL;
        return U_ERROR;
    }

/* Compute average data and number of trials per marker (i.e. per condition) */
    double** DataMEG = new double*[nCondition];
    double** DataEEG = NULL;
    int      iCond=0;
    int      nSamp   = GetNSampEpoch(0);
    int      nChan   = Data->GetNmeg()+ Data->GetNeeg();
    int*     nEpochPerCondition = new int[nCondition];

    switch(SensType)
    {
    case UEMfield::U_MEG:

        for(iCond=0;iCond<nCondition;iCond++)
        {
            nEpochPerCondition[iCond]=0;
            DataMEG[iCond] = GetAverageMarkerData(MarkerNames[iCond],U_DAT_MEG,nEpochPerCondition+iCond);
            if(DataMEG[iCond]==NULL)
            {
                for(int jCond=0;jCond<iCond;jCond++)
                delete[] DataMEG[jCond];
                delete[] DataMEG;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel() Computing data for marker %s.\n", MarkerNames[iCond]);
                return U_ERROR;
            }
        }
        break;

    default:
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Not implemented for EEG data yet.\n");
            delete ULED; ULED = NULL;
            return U_ERROR;
        }
    }

/* Setting the Data in ULED */
    if (ULED->SetECDMDesignAndData(MarkerNames, nCondition, nBasicSTF, DipEd, Ndipoles, DataMEG, DataEEG, nEpochPerCondition) !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Error in setting data in ULocCodeDip-object.\n");
        delete ULED; ULED = NULL;
        for(iCond=0;iCond<nCondition;iCond++)
                delete[] DataMEG[iCond];
                delete[] DataMEG;
        return U_ERROR;
    }
    ULED->SetNComp(Ncomp, SVDThreshold);
    if(DataMEG)
    {
        for(iCond=0;iCond<nCondition;iCond++)
            if(DataMEG[iCond])
                delete[] DataMEG[iCond];
    }
    delete[] DataMEG;
    if(DataEEG)
    {
        for(iCond=0;iCond<nCondition;iCond++)
            if(DataEEG[iCond])
                delete[] DataEEG[iCond];
    }
    delete[] DataEEG;

/* Compute Dipoles */
    UEvent   Begin      = Epochs->GetBegin(0);
    UEvent   End        = Epochs->GetEnd(0);
    double   residual   = 0.;
    double** DNorm      = new double*[nCondition];
    double*  BasicSTF   = new double[nBasicSTF*nSamp];
    double*  resPerCond = new double[nCondition];

    if(DNorm && BasicSTF && resPerCond)
    {
        for(iCond=0;iCond<nCondition;iCond++)
        {
            DNorm[iCond]= new double[nSamp];
            if(DNorm[iCond])
            {
                for(int i=0;i<nSamp;i++) DNorm[iCond][i]=0.;
            }
            else
            {
                for(int jCond=0;jCond<iCond;jCond++)
                   delete[] DNorm[jCond];
                delete[] DNorm;
                delete[] BasicSTF;
                delete[] resPerCond;
                delete[] nEpochPerCondition;
                delete ULED; ULED = NULL;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Memory allocation error.\n");
                return U_ERROR;
            }
        }
    }
    else
    {
        delete[] DNorm;
        delete[] BasicSTF;
        delete[] resPerCond;
        delete[] nEpochPerCondition;
        delete ULED; ULED = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Memory allocation error.\n");
        return U_ERROR;
    }

    int elt=0;
    for(elt=0;elt<nCondition;elt++) resPerCond[elt]=0.;
    for(iCond=0;iCond<nCondition;iCond++)
        for(elt=0;elt<nSamp;elt++)  DNorm[iCond][elt]=0.;
    for(elt=0;elt<nBasicSTF*nSamp;elt++)  BasicSTF[elt]=0.;

    if(ULED->ComputeDipoles(DipEd, Ndipoles, &residual, DNorm, BasicSTF, resPerCond) !=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Error in computing dipoles in ULocCodeDip-object.\n");
        for(iCond=0;iCond<nCondition;iCond++)
        {
            if (DNorm[iCond]) delete[] DNorm[iCond];
        }
        delete[] DNorm;
        delete[] BasicSTF;
        delete[] resPerCond;
        delete[] nEpochPerCondition;
        delete ULED; ULED = NULL;
        return U_ERROR;
    }

/* Export Results */
/* Write Header */
    FILE* fpOut = NULL;

/* Write Dipole file for each condition separately */
    for(iCond=0;iCond<nCondition;iCond++)
    {
        UFileName FileOutCond = FileOut;
        FileOutCond.InsertFileNumber(iCond,3);
        fpOut = fopen(FileOutCond,"wt", true);
        fprintf(fpOut,"// CONDITION %s:\n//\n",MarkerNames[iCond]);
        fprintf(fpOut,"// GENERAL:\n");
        fprintf(fpOut,"//   Results obtained with\n");
        fprintf(fpOut,"%s",CI.GetProperties("//    "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
        if(Data->GetMarkerArray())
        {
            fprintf(fpOut,"//\n");
            fprintf(fpOut,"// DATA MARKERS:\n");
            fprintf(fpOut,"%s",(const char*)Data->GetMarkerArray()->GetProperties("//  "));
        }
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// EPOCHS:\n");
        if(OneFile==false)
            fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
        else
        {
            if(Epochs->GetnEpochs()<10)
            {
                for(int k=0; k<Epochs->GetnEpochs(); k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            }
            else
            {
                for(int k=0; k<9; k++)
                        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                        k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                           Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
                fprintf(fpOut,"//   ..., Etc. \n");
            }
        }
        fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// FITTING:\n");
        fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
        fprintf(fpOut,"%s", (const char*)ULED->GetProperties("//  "));
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"//\n");

    /* Compute STFs for this condition */
        double* CondSTF = new double[2*MAXCODEDIP*nSamp];
        for(elt=0;elt<2*MAXCODEDIP*nSamp;elt++) CondSTF[elt]=0.;
        if (ULED->ComputeGMANSetOutput(iCond,BasicSTF,CondSTF)!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::FitConstrainedDipoleModel(). Error in ComputeCondOutput() for condition %d\n",iCond);
            for(iCond=0;iCond<nCondition;iCond++)
            {
                if (DNorm[iCond]) delete[] DNorm[iCond];
            }
            delete[] DNorm;
            delete[] BasicSTF;
            delete[] resPerCond;
            delete[] nEpochPerCondition;
            delete ULED; ULED = NULL;
            return U_ERROR;
        }

    /* Write header of dipole results */
        char line[200+100*MAXCODEDIP];
        int  nc=0;

        if(TimeSamples=true)  nc += sprintf(line,"Samp");
        else                  nc += sprintf(line,"Time");

        int l=0;
        for(   ; l<Ndipoles; l++)
            nc += DipEd[l].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

        for(l=0; l<Ndipoles; l++)
        {
            if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
            {
                nc += sprintf(line+nc,"\tSTF_L%d ",l);
                nc += sprintf(line+nc,"\tSTF_R%d ",l);
            }
            else
                nc += sprintf(line+nc,"\tSTF%d ",l);

        }
        nc += sprintf(line+nc,"\tERROR(%%)");
        nc += sprintf(line+nc,"\tResPerConditionPerSample(%%)");
        nc += sprintf(line+nc,"\tAverDataPower");
        fprintf(fpOut,"%s\n",line);

/* Write Dipole Results for this condition */
        double Stime = 1000.;
        if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

        for(int j=0; j<nSamp; j++)
        {
            UEvent E = GetEvent(0, j);
            nc       = 0;

            if(AbsoluteTime)
            {
                if(TimeSamples==true)  nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
                else                   nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(Data->GetNsampTrial()));
            }
            else
            {
                if(TimeSamples==true)  nc += sprintf(line,"%6.6d   ",E.sample);
                else                   nc += sprintf(line,"%f  ",Stime*E.sample);
            }

            int l=0;
            for(l=0; l<Ndipoles; l++)
            {
                nc += DipEd[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
            }
            int istf=0; //s keeps track of index of stf (row number in STF[])
            for(l=0; l<Ndipoles; l++)
            {
                if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
                {
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                }
                else
                {
                    nc += sprintf(line+nc,"\t%f ",CondSTF[istf*nSamp+j]);
                    istf++;
                }
            }

            nc += sprintf(line+nc,"\t%f",residual);
            nc += sprintf(line+nc,"\t%f",resPerCond[iCond]);
            if(nChan)
                nc += sprintf(line+nc,"\t%f",DNorm[iCond][j]/(nChan*(nEpochPerCondition[iCond])));
            else
                nc += sprintf(line+nc,"\t0.0");
            fprintf(fpOut,"%s\n",line);

        }
        delete[] CondSTF;
        fclose(fpOut);
    }

/* Write Dipole file with computed basic STFs and Couple Matrices */
    FileOut.InsertBeforeExtension("BasicOutput");
    UFileName FileOutBasic = FileOut;
    fpOut = fopen(FileOutBasic,"wt", true);

    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut,"//   Results obtained with\n");
    fprintf(fpOut,"%s",CI.GetProperties("//    "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// DATA:\n");
    fprintf(fpOut,"%s",(const char*)Data->GetProperties("//  "));
    if(Data->GetMarkerArray())
    {
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// DATA MARKERS:\n");
        fprintf(fpOut,"%s",(const char*)Data->GetMarkerArray()->GetProperties("//  "));
    }
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// EPOCHS:\n");
    if(OneFile==false)
        fprintf(fpOut,"//   Data Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n", Begin.trial, Begin.sample, End.trial, End.sample);
    else
    {
        if(Epochs->GetnEpochs()<10)
        {
            for(int k=0; k<Epochs->GetnEpochs(); k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
        }
        else
        {
            for(int k=0; k<9; k++)
                    fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            fprintf(fpOut,"//   ..., Etc. \n");
        }
    }
    fprintf(fpOut,"%s",(const char*)GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// FITTING:\n");
    fprintf(fpOut,"//   %s\n",Cmin.GetParameterString());
    fprintf(fpOut,"%s", (const char*)ULED->GetProperties("//  "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"//\n");

 /* Write header of dipole results */
    char line[200+100*MAXCODEDIP];
    int  nc=0;

    if(TimeSamples=true)  nc += sprintf(line,"Samp");
    else                  nc += sprintf(line,"Time");

    int l=0;
    for(   ; l<Ndipoles; l++)
        nc += DipEd[l].PrintParameters(line+nc,-(200+100*MAXSTATDIP-nc-1),l);

    for(l=0; l<Ndipoles; l++)
    {
        if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
        {
            nc += sprintf(line+nc,"\tSTF_L%d ",l);
            nc += sprintf(line+nc,"\tSTF_R%d ",l);
        }
        else
            nc += sprintf(line+nc,"\tSTF%d ",l);

    }
    fprintf(fpOut,"%s\n",line);

/* Write Dipole Results with basic STFs */
    double Stime = 1000.;
    if(Data->GetSampleRate()!=0) Stime = 1000./Data->GetSampleRate();

    for(int j=0; j<nSamp; j++)
    {
        UEvent E = GetEvent(0, j);
        nc       = 0;

        if(AbsoluteTime)
        {
            if(TimeSamples==true)  nc += sprintf(line,"%6.6d   ",E.GetAbsSample(Data->GetNsampTrial()));
            else                   nc += sprintf(line,"%f  ",Stime*E.GetAbsSample(Data->GetNsampTrial()));
        }
        else
        {
            if(TimeSamples==true)  nc += sprintf(line,"%6.6d   ",E.sample);
            else                   nc += sprintf(line,"%f  ",Stime*E.sample);
        }
        int l=0;
        for(l=0; l<Ndipoles; l++)
        {
            nc += DipEd[l].PrintParameters(line+nc,200+100*MAXCODEDIP-nc-1);
        }
        int istf=0; //s keeps track of index of stf (row number in STF[])
        for(l=0; l<Ndipoles; l++)
        {
            if(DipEd[l].GetDipoleType()==UDipole::SymmetricPos)
            {
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
            }
            else
            {
                nc += sprintf(line+nc,"\t%f ",BasicSTF[istf*nSamp+j]);
                istf++;
            }
        }
        fprintf(fpOut,"%s\n",line);

    }
    fprintf(fpOut,"\n");
    fclose( fpOut);

/* Write the estimated coupling matrices to the BasicOutput file */
    for(iCond=0;iCond<nCondition;iCond++)
        ULED->PrintCodeMat(FileOut,iCond,true);
    ULED->PrintCodePars(FileOut,true);

/* delete all allocated arrays */
    for(iCond=0;iCond<nCondition;iCond++)
    {
        if (DNorm[iCond]) delete[] DNorm[iCond];
    }
    delete[] DNorm;
    delete[] BasicSTF;
    delete[] resPerCond;
    delete[] nEpochPerCondition;
    delete ULED; ULED = NULL;

    return U_OK;
}


ErrorType UMEEGDataEpochsExt::InitBeamFormerScan(const UHeadModel* HM, double MeshSize)
{
    if(HM==NULL || HM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). NULL or erroneous head model.\n");
        return U_ERROR;
    }
    if(MeshSize<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Invalid mesh size (MSize = %6.3f) .\n", MeshSize);
        return U_ERROR;
    }
    UEMfield EMF(HM);
    if(EMF.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Creating UEMField 0bject .\n");
        return U_ERROR;
    }
    ReReferenceType ReRefForw = GetMEGForwardBalancing();
    if(ReRefForw!=U_REF_RAW &&
       EMF.SetBalancing(Data->GetGridREF(), Data->GetpBalancing(), UMEEGDataBase::MAXMEG, ReRefForw)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::UMEEGDataEpochsExt(). Setting forward balancing failed. \n");
        return U_ERROR;
    }


    delete BeamFormerGrid; BeamFormerGrid = NULL;
    switch(EMF.GetGrossModelType())
    {
    case U_GMODEL_REALISTIC:
        {
            const USurface* Brain = EMF.GetSurface(EMF.GetInnerSurf());
            if(Brain==NULL || Brain->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Getting inner surface.\n");
                return U_ERROR;
            }
            UVector3 Minx, Maxx;
            Brain->ComputeMinMax(&Minx, &Maxx);

            BeamFormerGrid = new UField(MeshSize, Minx-UVector3(1.,1.,1.), Maxx+UVector3(1.,1.,1.), UField::U_BYTE);

            if(BeamFormerGrid==NULL || BeamFormerGrid->GetError()!=U_OK)
            {
                delete BeamFormerGrid; BeamFormerGrid = NULL;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Creating Beamformer search grid.\n");
                return U_ERROR;
            }
            BeamFormerGrid->SetDataByte((unsigned char)1);
            BeamFormerGrid->IsInSurface(Brain);
        }
        break;
    case U_GMODEL_SPHERE:
        {
            UVector3   Spos = EMF.GetSpherePos();
            double     Rad  = EMF.GetInnerRadius();
            BeamFormerGrid  = new UField(MeshSize, Spos-UVector3(Rad,Rad,Rad), Spos+UVector3(Rad,Rad,Rad), UField::U_BYTE);

            if(BeamFormerGrid==NULL || BeamFormerGrid->GetError()!=U_OK)
            {
                delete BeamFormerGrid; BeamFormerGrid = NULL;
                CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Creating Beamformer search grid.\n");
                return U_ERROR;
            }

            BeamFormerGrid->SetDataByte((unsigned char)1);
            BeamFormerGrid->IsInSphere(Spos, Rad);
        }
        break;
    default:
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Invalid headmodel type.\n");
        return U_ERROR;
    }

    delete BEAM; BEAM = new UBeamFormer(&EMF);
    if(BEAM==NULL || BEAM->GetError()!=U_OK)
    {
        delete BeamFormerGrid; BeamFormerGrid = NULL;
        delete BEAM;           BEAM           = NULL;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::InitBeamFormerScan(). Creating BeamFormer object.\n");
        return U_ERROR;
    }
    return U_OK;
}
UScan* UMEEGDataEpochsExt::ComputeBeamFormerScan(const USensorCorrelate* CovarAct, const USensorCorrelate* CovarRest, bool LogEigen, double RegParameter, bool MAGonly, bool GRAonly, bool UseLFTable, UEuler NLR2Wld) const
{
    if(BEAM==NULL           || BEAM->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). UBeamFormer object not (properly) set .\n");
        return NULL;
    }
    if(BeamFormerGrid==NULL || BeamFormerGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). Search grid object not (properly) set .\n");
        return NULL;
    }
    if(CovarAct ==NULL || CovarAct ->GetError()!=U_OK || CovarAct ->GetGrid()==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). NULL or in valid rest covariance object .\n");
        return NULL;
    }
    if(CovarRest==NULL || CovarRest->GetError()!=U_OK || CovarRest->GetGrid()==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). NULL or in valid active covariance object .\n");
        return NULL;
    }
    if(RegParameter<0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). Regularization parameter out of range (RegParameter = %f).\n", RegParameter);
        return NULL;
    }
    int* Select  = NULL;
    int  NSelect = -1;
    if(CovarAct ->GetGrid()->GetGridType()==UEMfield::U_MEG &&
       CovarRest->GetGrid()->GetGridType()==UEMfield::U_MEG)
    {
             if(MAGonly==true) Select = CovarAct->GetGrid()->GetSensorTypeIndices(USensor::U_SEN_MAG , &NSelect);
        else if(GRAonly==true) Select = CovarAct->GetGrid()->GetSensorTypeIndices(USensor::U_SEN_GRAD, &NSelect);
        if(Select && NSelect<=0)
        {
            delete[] Select;
            CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). Selecting channel types gives %d channels. \n", NSelect);
            return NULL;
        }
    }

    UField* F = BEAM->GetSAMField(BeamFormerGrid, CovarAct, CovarRest, LogEigen, RegParameter, Select, NSelect, UseLFTable);
    delete[] Select;
    if(F==NULL || F->GetError()!=U_OK)
    {
        delete F;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). Computing beamformer scan .\n");
        return NULL;
    }
    UScan* S = new UScan(*F);
    if(S==NULL || S->GetError()!=U_OK)
    {
        delete F;
        delete S;
        CI.AddToLog("ERROR: UMEEGDataEpochsExt::ComputeBeamFormerScan(). Copying UField to UScan .\n");
        return NULL;
    }
    delete F;

    S->SetDateTime   (Data->GetDateTime());
    S->SetPatID      (Data->GetPatID  () );
    S->SetPatName    (Data->GetPatName() );
    S->SetModality   (U_MOD_MEG  );
    S->SetOrientation(U_ORI_AXIAL);
    S->SetMatchScanToWld(NLR2Wld);
    return S;

/****
    S->SwapDirections(1 , 2);
    S->ReverseData(0, false);
    S->ReverseData(1, false);
    S->ReverseData(2, false);
****/
}
