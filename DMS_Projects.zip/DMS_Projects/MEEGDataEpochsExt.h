#ifndef _MEEGDATAEPOCHSEXTRA_INCLUDED
#define _MEEGDATAEPOCHSEXTRA_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include "MEEGDataEpochs.h"
#include "EMfield.h"
#include "StartDipole.h"
#include "CostMinimize.h"
#include "EventArray.h"

#include "LocCoil.h"
#include "DipoleList.h"

class USignalSpaceProj;

class ULocCoil;
class ULocStatDip;
class ULocMovDip;
class ULocCodeDip;
class UCovariance;
class UHeadModel;

class UDipoleMoveList;
class UDipoleEdit;

class UScan;
class UBeamFormer;
class USensorCorrelate;

class DLL_IO UMEEGDataEpochsExt : public  UMEEGDataEpochs
{
public:
    UMEEGDataEpochsExt();
    UMEEGDataEpochsExt(UFileName FileName, const char* forceGoodCh=NULL, const char* forceBadCh=NULL);
    UMEEGDataEpochsExt(const UMEEGDataEpochs& DatEp); 
    UMEEGDataEpochsExt(const UMEEGDataEpochsExt& DatEp); 
    virtual ~UMEEGDataEpochsExt();
    virtual UMEEGDataEpochs&    operator=(const UMEEGDataEpochs    &DatEp);
    virtual UMEEGDataEpochsExt& operator=(const UMEEGDataEpochsExt &DatEp);

    ErrorType               GetError() const;

/* Dipole fit parameters */
    ErrorType               SetMinimize(UCostminimize C, bool AdFordMod);
    ErrorType               SetCovar(const UCovariance* SpatCov, UEMfield::FieldType SensorsUsed, const UCovariance* TempCov);
    ErrorType               SetOutputFormat(UFileName F, bool SingleFile, bool WriteAllDipoles, bool TimeInSampp, bool UseAbsTime, bool AppendResult, int NumDigits, bool UseOldUnits);
    
/* Coils */
    ErrorType               InitFindCoils(UVector3 Start, StartDipType SType, UMeshPoints::RegionType GlobalSRegion, int Ngrd, 
                                CalibType CType, double* calib);
    UDipoleList*            ComputeFindCoils(double BadThreshold, UString** ErrorString, double* MaxResErrPerc);               

/* Moving Dipoles */
    ErrorType               InitMovingDipoleModel(const UHeadModel* HM, UDipole::DipoleType DipType, StartDipType ST, int NStartPnts, double MaxStartError, double MinPowFact, bool ConfidenceLimits, double AmatThreshold, bool MarkOutliers);
    ErrorType               FitMovingDipoles(int Iepoch);
    UDipoleMoveList*        GetDipoleMoveList(int Iepoch, const UHeadModel* HM);

/* Stationary Dipoles */
    ErrorType               InitStationaryDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints);
    ErrorType               FitStationaryDipoles(int Iepoch, int Ndipoles, UDipoleEdit* DipEd, bool ConfInt, bool Bonferroni, int Ncomp, double SVDThreshold);

/* Coupled Dipole Model */
    ErrorType               InitCoupledDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints);
    ErrorType               FitCoupledDipoleModel(int Ndipoles, UDipoleEdit* DipEd, int Ncomp, double SVDThreshold, bool** CoupleMatrix, char** MarkerNames, int nCondition, int nDipSTF, int nBasicSTF);

/* Constrained Stationary Dipole Model */
    ErrorType               InitConstrainedDipoleModel(const UHeadModel* HM, int Ndipoles, const UDipoleEdit* DipEd, StartDipType ST, UFileName StartFile, int NGlobPoints);
    ErrorType               FitConstrainedDipoleModel(int Ndipoles, UDipoleEdit* DipEd, bool ConfInt, bool Bonferroni, int Ncomp, double SVDThreshold, char** MarkerNames, int nCondition, int nDipSTF, int nBasicSTF);
        
/* BeamFormers */    
    ErrorType               InitBeamFormerScan(const UHeadModel* HM, double MeshSize);
    UScan*                  ComputeBeamFormerScan(const USensorCorrelate* CovarAct, const USensorCorrelate* CovarRest, bool LogEigen, double RegParameter, bool MAGonly, bool GRAonly, bool UseLFTable, UEuler NLR2Wld) const;

/* Get filtered data */
    UMultiChan*             GetFilteredMultiChan(int Iepoch, DataType Dtype, int ichan=-1) const;
    UMultiChan*             GetFilteredMultiChan(int Iepoch, const char* Label) const;
    UMultiChan*             GetFilteredMultiChan(UEvent E, const int* Offsets, int Noff, DataType Dtype) const;

/* Signal space projection*/
    const USignalSpaceProj* GetSSP(void) const {return SSP;}
    ErrorType               SetSSP(const USignalSpaceProj* NewSSP);

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;
    const USignalSpaceProj* SSP;

/* Computation parameters */
    UCostminimize           Cmin;
    bool                    AdvancedForwMod;

    UCovariance*            CovXX;
    UCovariance*            CovTT;
    UEMfield::FieldType     SensType;

/* Output format */
    UFileName               FileOut;
    bool                    OneFile;      // Parameters determining the output file format
    bool                    AllDipoles;
    bool                    TimeSamples;
    bool                    AbsoluteTime; // True iff time/sample is corrected for trial number
    bool                    Append;
    int                     NDigit;
    bool                    OldUnits;

/* Magnetic dipoles (energized coils)*/
    ULocCoil*               ULC;

/* Moving dipole model */
    ULocMovDip*             ULMD;
    double                  MaxMovDipFitError;
    double                  MinRelDataPower;

/* Stationary dipole model */
    ULocStatDip*            ULSD;

/* Coupled Dipole Model */
    ULocCodeDip*            ULCD;

/* Constrained Dipole Model */
    ULocCodeDip*            ULED;

/* Beamformer */
    UBeamFormer*            BEAM;
    UField*                 BeamFormerGrid;
};
#endif//_MEEGDATAEPOCHSEXTRA_INCLUDED
