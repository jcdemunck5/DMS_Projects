/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*   Module to setting up time segments in the form of an UEpochs-object.        */
/*   THis file contains functions to export selectred data in different formats. */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    24-11-03   Creation
  JdM    12-02-04   Bug Fix: WriteCTFDataSet(). Setting data file name of output.
  JdM    21-09-04   WriteTextFile(): added parameter to export EKG data
  JdM    27-12-04   Added parameters on WriteTextFile()
  JdM    02-01-05   WriteTextFile(): Added parameters, used (new version of) GetFilteredMultiChan()
  JdM    29-03-05   Implemented the export of MEG Reference data
  JdM    13-01-05   Added WriteEDF(). Changed arguments of WriteCTFDataSet() and WriteTextFile()
  JdM    09-05-06   bug fix: WriteCTFDataSet(), converting EKG (apply data conversion on copy of *this).
  JdM    16-10-06   WriteEDF(). Writing date.
  JdM    24-10-06   WriteEDF(). Writing date.
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    16-05-08   WriteTextFile(): added parameter to save different epochs in different files.
                    Added WriteTextHeader()
  JdM    02-07-08   Bug Fixes: WriteEDF(). Writing date and time, choosing appropriate channels.
                    WriteEDF(). Added down sampling parameter
  JdM    06-07-08   WriteEDF(). Scale channels individually; use new UString constructor (i.s.o. %8f) to write phys_min and phys_max
  JdM    04-01-09   Added ReadResampleWriteCTFData()
  JdM    29-05-09   Added parameter onto WriteMapFile(), WriteTextFile(), WriteEDF() and WriteCTFDataSet()
  JdM    03-10-09   ReadResampleWriteCTFData(). Try linear interpolation if FFT does not work
  JdM    10-06-10   WriteCTFDataSet(). ScaleCallibrations() to avoid overflow.
  JdM    20-11-11   WriteMapFile(),WriteCTFDataSet(): Use GetFilteredMultiChan() i.s.o. GetFilteredData()
  JdM    11-01-12   Added inversion parameter(s) to WriteMapFile(), WriteTextFile(), WriteEDF() and WriteCTFDataSet()
  JdM    24-04-12   Added/replaced NewSampFreq-parameter to WriteEDF(), WriteMapFile(), WriteTextFile(), WriteTextHeader() and WriteCTFDataSet()
  JdM    20-02-13   WriteTextFile(). Skip last separator before "\n"
  JdM    27-07-13   Eliminate compiler warnings regarding unused variables.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    22-11-15   WriteEDF(). Improved detectiuon of overflow errors and changed FACT constant for large data sets.
  JdM    03-12-15   Bug Fix. WriteEDF(). Resampling first data epoch.
*/

#include <math.h>
#include <string.h>

#include "MEEGDataEpochs.h"
#include "MEEGDataCTF.h"
#include "MEEGDataNS.h"
#include "MEEGDataECG.h"
#include "MEEGDataEDF.h"

#include "MEEGDataWriteCTF.h"
#include "MultiChan.h"
#include "Directory.h"
#include "Epochs.h"
#include "MarkerArray.h"
#include "Grid.h"
#include "MapFile.h"
#include "CTFDataSet.h"
#include "Interpolate.h"
#include "MegDefs.h"

ErrorType UMEEGDataEpochs::WriteMapFile(DataType Dtype, const char* FileName, const char* const* TrialLab, double NewSampFreq, int IEpoch, bool InvData) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Data not properly set. \n");
        return U_ERROR;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Epochs not properly set. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Epochs times are not equal. \n");
        return U_ERROR;
    }
    if(NewSampFreq<=0.) NewSampFreq = Data->GetSampleRate();
    int NSampOut = int( Epochs->GetNsamp(0) * NewSampFreq / Data->GetSampleRate() );
    UInterpolate INT(Epochs->GetNsamp(0), NSampOut, U_INTERPOL_LIN);
    if(INT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Creating interpolation object. \n");
        return U_ERROR;
    }
    if(IEpoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Epoch number out of range (IEpoch=%d). \n", IEpoch);
        return U_ERROR;
    }
    if(Data->GetNkan(Dtype)<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). No data available of the required type (%d) . \n",Dtype);
        return U_ERROR;
    }
    if(FileName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Invalid NULL pointer. \n");
        return U_ERROR;
    }
    UFileName F(FileName);
    if(F.IsPureFile()==true)
        F = Data->GetDataFileName().GetSiblingFileName(F.GetBaseName());
    F.ReplaceExtension("map");

    int NEP = 1;
    if(IEpoch<0) NEP = Epochs->GetnEpochs();
    UMapFile Map(Data->GetGrid(Dtype), NSampOut, NEP, CI.GetProgArgs());
    if(Map.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Creating UMapFile-object. \n");
        return U_ERROR;
    }

/*Set time labels*/
    const int NTIMELAB = 30;
    char** pTimeLabels = new char*[         NSampOut];
    char*   TimeLabels = new char [NTIMELAB*NSampOut];
    if(pTimeLabels && TimeLabels)
    {
        memset(TimeLabels, 0, NTIMELAB*NSampOut);
        double Presim_s    = GetPreTriggerTime_s();
        double NewSampTime = 1./NewSampFreq;
        for(int j=0; j<NSampOut; j++)
        {
            pTimeLabels[j] = TimeLabels + j*NTIMELAB;
            sprintf(pTimeLabels[j],"%8.1f ms", 1000*(j*NewSampTime-Presim_s));
        }
    }
    else
    {
        delete[] pTimeLabels;
        delete[] TimeLabels;
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Allocating time labels. \n");
        return U_ERROR;
    }
    if(Map.SetMapLabels(pTimeLabels)!=U_OK)
    {
        delete[] pTimeLabels;
        delete[] TimeLabels;
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Setting time labels. \n");
        return U_ERROR;
    }
    delete[] pTimeLabels;
    delete[] TimeLabels;

/*Set trial labels*/
    if(TrialLab)
    {
        if(IEpoch<0)
        {
            if(Map.SetTrialLabels(TrialLab)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Setting trial labels. \n");
                return U_ERROR;
            }
        }
        else
        {
            if(Map.SetTrialLabels(TrialLab+IEpoch)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Setting trial labels. \n");
                return U_ERROR;
            }
        }
    }
    else
    {
        const int NTRIALLAB = 300;
        char** pTrialLabels = new char*[          NEP];
        char*   TrialLabels = new char [NTRIALLAB*NEP];
        if(pTrialLabels && TrialLabels)
        {
            memset(TrialLabels, 0, NTRIALLAB*Epochs->GetnEpochs());
            for(int j=0; j<NEP; j++)
            {
                pTrialLabels[j] = TrialLabels + j*NTRIALLAB;
                int jep = j;
                if(IEpoch>=0) jep = IEpoch;
                if(Epochs->GetDescriptor(jep)==NULL)  sprintf(pTrialLabels[j], "Epoch %d", jep);
                else                                  strncpy(pTrialLabels[j],Epochs->GetDescriptor(jep),NTRIALLAB-1);
            }
        }
        else
        {
            delete[] pTrialLabels;
            delete[] TrialLabels;
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Allocating trial labels. \n");
            return U_ERROR;
        }
        if(Map.SetTrialLabels(pTrialLabels)!=U_OK)
        {
            delete[] pTrialLabels;
            delete[] TrialLabels;
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Setting trial labels. \n");
            return U_ERROR;
        }
        delete[] pTrialLabels;
        delete[] TrialLabels;
    }
    int kstart = MAX(0, IEpoch);
    for(int k=kstart,kout=0; k<kstart+NEP; k++, kout++)
    {
        UMultiChan* MC = GetFilteredMultiChan(k, Dtype);
        if(MC==NULL || MC->GetError()!=U_OK || MC->GetData()==NULL)
        {
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Reading data of epoch %d. \n",k);
            return U_ERROR;
        }
        if(MC->ResampleData(&INT)!=U_OK)
        {
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Resampling data in epoch %d. \n",k);
            return U_ERROR;
        }
        if(InvData) MC->InvertData();
        if(Map.SetData(MC->GetData(), kout, false)!=U_OK)
        {
            delete MC;
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Setting data of epoch %d. \n",k);
            return U_ERROR;
        }
        delete MC;
    }
    if(Map.WriteFile(F.GetFullFileName(), UMEEGDataBase::GetUnitText(Dtype))!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteMapFile(). Writing to file %s \n",F.GetFullFileName());
        return U_ERROR;
    }
    CI.AddToLog("Note: UMEEGDataEpochs::WriteMapFile(). Exporting .map file %s succesfully. \n",F.GetFullFileName());
    return U_OK;
}

ErrorType UMEEGDataEpochs::WriteTextFile(UFileName FileOut, bool WriteHeader, bool ChannelLabels, bool Transpose, bool  FixedFormat, bool SepFiles, TimeFormatType TForm, char Separator, const bool SaveType[U_DAT_NTYPE], double NewSampFreq, int IEpoch, bool InvEEG, bool InvEKG) const
{
    if(Data == NULL || Data->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextFile(). Base class not properly set. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Epochs times are not equal. \n");
        return U_ERROR;
    }
    if(NewSampFreq<=0.) NewSampFreq = Data->GetSampleRate();
    int NSampOut = int( Epochs->GetNsamp(0) * NewSampFreq / Data->GetSampleRate() );
    UInterpolate INT(Epochs->GetNsamp(0), NSampOut, U_INTERPOL_LIN);
    if(INT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Creating interpolation object. \n");
        return U_ERROR;
    }
    if(IEpoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Epoch number out of range (IEpoch=%d). \n", IEpoch);
        return U_ERROR;
    }
    int NchanSave = 0;
    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        int Nchan = Data->GetNkan(UMEEGDataBase::GetDataType(n));
        if(SaveType[U_DAT_NTYPE]==true && Nchan<=0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). No channels of type %s have been selected. \n", UMEEGDataBase::GetDataType(n));
            return U_ERROR;
        }
        NchanSave += Nchan;
    }
    if(NchanSave<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Nothing to export, all data type booleans are false. \n");
        return U_ERROR;
    }

    const int NDIGIT = 4;

    int NEP = 1;
    if(IEpoch<0) NEP = Epochs->GetnEpochs();
    int kstart       = MAX(0, IEpoch);
    for(int k=kstart,kout=0; k<kstart+NEP; k++, kout++)
    {
        UFileName F(FileOut);
        if(F.IsPureFile()==true)
            F = Data->GetDataFileName().GetSiblingFileName(F.GetBaseName());
        if(F.HasAnyExtension()==false) F.ReplaceExtension("txt");

        UFileName Fout = F;
        if(SepFiles==true)
        {
            Fout = F;
            Fout.InsertFileNumber(k,NDIGIT);
        }
        if(kout==0 || SepFiles==true) /// Delete File if it exists aleady.
        {
            FILE *fpOut = fopen(Fout,"wt", false);
            if(fpOut) fclose(fpOut);
        }
        UMultiChan** MCarr = this->GetFilteredMultiChan(k, SaveType);
        if(MCarr==NULL)
        {
            CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextFile().  Getting data of epoch %d  .\n", k);
            return U_ERROR;
        }
        if(InvEEG && SaveType[U_DAT_EEG] && MCarr[U_DAT_EEG]) MCarr[U_DAT_EEG]->InvertData();
        if(InvEKG && SaveType[U_DAT_EKG] && MCarr[U_DAT_EKG]) MCarr[U_DAT_EKG]->InvertData();
        for(int n=0; n<U_DAT_NTYPE; n++)
        {
            if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;
            
            if(MCarr[n]->ResampleData(&INT)!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Resampling data in epoch %d. \n",k);
                for(int nn=0; nn<U_DAT_NTYPE; nn++) delete MCarr[nn];
                delete[] MCarr;
            }
        }
/* Write Header*/
        if(WriteHeader)
        {
            ErrorType E = U_ERROR;
            if(SepFiles==true)
            {
                E = WriteTextHeader(Fout, ChannelLabels, Transpose, NewSampFreq,  k, TForm, Separator, MCarr);
            }
            else if(kout==0)
            {
                E = WriteTextHeader(Fout, ChannelLabels, Transpose, NewSampFreq, -1, TForm, Separator, MCarr);
            }
            else
            {
                E = U_OK;
            }
            if(E!=U_OK)
            {
                for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
                delete[] MCarr;
                CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextFile().  Writing header, epoch %d  .\n", k);
                return U_ERROR;
            }
        }
        FILE *fpOut = fopen(Fout,"at", false);
        if(fpOut==NULL)
        {
            for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
            delete[] MCarr;
            CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextFile().  Opening output-file : %s\n",FileOut.GetFullFileName());
            return U_ERROR;
        }

/* Save the EEG/MEG/ADC/EKG/SSP data*/
        char Format[32];
        char FormatEnd[32];
        if(FixedFormat)  
        {
            sprintf(Format   ,"%s%c","%12.5f",Separator);
            sprintf(FormatEnd,"%s"  ,"%12.5f");
        }
        else
        {
            sprintf(Format   ,"%s%c","%12.5e",Separator);
            sprintf(FormatEnd,"%s"  ,"%12.5e");
        }
        double Stime = 1;
        if(NewSampFreq!=0) Stime = 1000./NewSampFreq;
        double TimeOffset = 0;
        if(TForm==U_TIMEFORM_TRIGGMS) TimeOffset = -GetPreTriggerTime_s() *1000;

        if(Transpose==true)
        {
            for(int j=0; j<NSampOut; j++)
            {
                UEvent E = GetEvent(k, j);
                switch(TForm)
                {
                case U_TIMEFORM_NOLAB:      break;
                case U_TIMEFORM_TRIALMS:
                case U_TIMEFORM_TRIGGMS:    fprintf(fpOut,"%f%c",Stime*E.GetAbsSample(Data->GetNsampTrial())+TimeOffset,Separator); break;
                case U_TIMEFORM_SAMPLE:     fprintf(fpOut,"%d%c",      E.GetAbsSample(Data->GetNsampTrial())           ,Separator); break;
                }

                for(int n=0; n<U_DAT_NTYPE; n++)
                {
                    if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;
                    const double* dat = MCarr[n]->GetData();
                    if(dat) 
                    {
                        int NC = MCarr[n]->GetNChan();
                        for(int i=0; i<NC-1; i++) 
                            fprintf(fpOut,Format,dat[i*NSampOut+j]);
                        fprintf(fpOut,FormatEnd,dat[(NC-1)*NSampOut+j]);
                    }
                    else
                    {
                        if(j==0)  CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Getting data type %d \n", n);
                    }
                }
                fprintf(fpOut,"\n");
            }
        }
        else
        {
            for(int n=0; n<U_DAT_NTYPE; n++)
            {
                if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;                
                const double* dat = MCarr[n]->GetData();
                if(dat)
                    for(int i=0; i<MCarr[n]->GetNChan(); i++)
                    {
                        if(ChannelLabels==true)
                            fprintf(fpOut,"%s%c",MCarr[n]->GetSensorGrid()->GetName(i),Separator);
                        for(int j=0; j<NSampOut-1; j++) 
                            fprintf(fpOut,Format,dat[i*NSampOut+j]);
                        fprintf(fpOut,FormatEnd,dat[i*NSampOut+(NSampOut-1)]);
                        fprintf(fpOut,"\n");
                    }
                else
                    CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextFile(). Getting data type %d \n", n);
            }
        }
        for(int n=0; n<U_DAT_NTYPE; n++)
            delete MCarr[n];
        delete[] MCarr;
        fclose(fpOut);
    }
    return U_OK;
}

ErrorType UMEEGDataEpochs::WriteTextHeader(UFileName FileOut, bool ChannelLabels, bool Transpose, double NewSampFreq, int Iepoch, TimeFormatType TForm, char Separator, const UMultiChan* const* MCarr) const
{
    if(Data == NULL || Data->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextHeader(). Base class not properly set. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextHeader(). Epochs times are not equal. \n");
        return U_ERROR;
    }
    if(NewSampFreq<=0.) NewSampFreq = Data->GetSampleRate();
    int NSampOut = int( Epochs->GetNsamp(0) * NewSampFreq / Data->GetSampleRate() );
    UInterpolate INT(Epochs->GetNsamp(0), NSampOut, U_INTERPOL_LIN);
    if(INT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextHeader(). Creating interpolation object. \n");
        return U_ERROR;
    }
    if(Iepoch>Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextHeader(). Epoch number out of range (Iepoch=%d). \n", Iepoch);
        return U_ERROR;
    }
    if(MCarr==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteTextHeader(). Data array NULL. \n");
        return U_ERROR;
    }

    FILE *fpOut   = fopen(FileOut,"wt", false);
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteTextHeader().  Opening output-file : %s\n",FileOut.GetFullFileName());
        return U_ERROR;
    }

/* Write Header*/
    UString DatProp = Data->GetProperties("//  ");
    fprintf(fpOut,"// GENERAL:\n");
    fprintf(fpOut,"%s",CI.GetProperties("//   "));
    fprintf(fpOut,"//\n");
    fprintf(fpOut,"// DATA:\n");
    fprintf(fpOut,"%s", (const char*)DatProp);
    fprintf(fpOut,"//\n");
    if(Data->GetSampleRate()!=NewSampFreq)
    {
        fprintf(fpOut,"//\n");
        fprintf(fpOut,"// Data down sampled from %f to %f Hz .\n", Data->GetSampleRate(), NewSampFreq);
        fprintf(fpOut,"//\n");
    }
    if(Iepoch<0)
    {
        fprintf(fpOut,"// EPOCHS:\n");
        if(Epochs->GetnEpochs()<10)
        {
            for(int k=0; k<Epochs->GetnEpochs(); k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
        }
        else
        {
            for(int k=0; k<9; k++)
                fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
                    k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
                       Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
            fprintf(fpOut,"//   ..., Etc. \n");
        }
    }
    else
    {
        int k=Iepoch;
        fprintf(fpOut,"// EPOCH %d :\n", Iepoch);
        fprintf(fpOut,"//   Epoch %d Range From (Trial, Sample) = (%d, %d) to (%d, %d) \n",
            k, Epochs->GetBegin(k).trial, Epochs->GetBegin(k).sample,
               Epochs->GetEnd(k).trial,   Epochs->GetEnd(k).sample);
    }
    UString Prop = GetProperties("//  ");
    fprintf(fpOut,"%s", (const char*)Prop);
    fprintf(fpOut,"//\n");

    for(int n=0, ichan=0; n<U_DAT_NTYPE; n++)
    {
        if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;

        DataType DT   = UMEEGDataBase::GetDataType(n);
        switch(DT)
        {
        case U_DAT_MEG:
            fprintf(fpOut,"// MEG Data Units: fT\n");
            switch(GetMEGReref())
            {
            case U_REF_RAW:        fprintf(fpOut,"// MEG data not re-referenced. Data kept as is in CTF file. \n"); break;
            case U_REF_UNBALANCED: fprintf(fpOut,"// MEG data converted to unbalanced. \n"); break;
            case U_REF_FIRST:      fprintf(fpOut,"// MEG data converted to first gradiometer. \n"); break;
            case U_REF_SECOND:     fprintf(fpOut,"// MEG data converted to second gradiometer. \n"); break;
            case U_REF_THIRD:      fprintf(fpOut,"// MEG data converted to third gradiometer. \n"); break;
            default:               fprintf(fpOut,"// Unknown balancing applied to MEG data. \n"); break;
            }
            break;
        case U_DAT_EEG:
            fprintf(fpOut,"// EEG Data Units: uV\n");
            switch(GetEEGReref())
            {
            case U_REF_RAW:        fprintf(fpOut,"// EEG data not re-referenced. Data kept as is in CTF file. \n"); break;
            case U_REF_AVERAGE:    fprintf(fpOut,"// EEG data converted to average reference. \n"); break;
            default:               fprintf(fpOut,"// Unknown balancing applied to MEG data. \n"); break;
            }
            break;
        case U_DAT_ADC:
            fprintf(fpOut,"// ADC Data Units: V\n");
            break;
        case U_DAT_EKG:
            fprintf(fpOut,"// EKG Data Units: uV\n");
            break;
        case U_DAT_SSP:
            fprintf(fpOut,"// SSP Data Units: nAm\n");
            break;
        }
        fprintf(fpOut,"// \n");
        fprintf(fpOut,"//     %s\n",MCarr[n]->GetSensorGrid()->GetSensor(0).GetProperties(true));
        for(int i=0; i<MCarr[n]->GetNChan(); i++, ichan++)
            fprintf(fpOut,"// %3d %s\n",ichan,MCarr[n]->GetSensorGrid()->GetSensor(i).GetProperties());
    }

    double TimeOffset = 0;
    if(TForm==U_TIMEFORM_TRIGGMS) TimeOffset = -GetPreTriggerTime_s() *1000;
    fprintf(fpOut,"// \n// \n");
    if(Transpose==true)
    {
        fprintf(fpOut,"//  For each epoch, each row contains the data of one sample point:\n");
        fprintf(fpOut,"//  trial0\n");
        fprintf(fpOut,"//    samp0: ch0, ch1, ch2...\n");
        fprintf(fpOut,"//    samp1: ch0, ch1, ch2...\n");
        fprintf(fpOut,"//    ....                \n");
        fprintf(fpOut,"//    sampN-1: ch0, ch1, ch2...\n");
        fprintf(fpOut,"//  trial1\n");
        fprintf(fpOut,"//    ....                \n");
        switch(TForm)
        {
        case U_TIMEFORM_NOLAB:                                       break;
        case U_TIMEFORM_TRIALMS:    fprintf(fpOut,"// Time \t");     break;
        case U_TIMEFORM_TRIGGMS:    fprintf(fpOut,"// TimeTrig \t"); break;
        case U_TIMEFORM_SAMPLE:     fprintf(fpOut,"// Samp \t");     break;
        }
        if(ChannelLabels==true)
        {
            for(int n=0, ichan=0; n<U_DAT_NTYPE; n++)
            {
                if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;
                for(int i=0; i<MCarr[n]->GetNChan(); i++, ichan++)
                    fprintf(fpOut,"%s%c",MCarr[n]->GetSensorGrid()->GetSensor(i).GetName(), Separator);
            }
            fprintf(fpOut,"\n");
        }
    }
    else
    {
        fprintf(fpOut,"//  For each trial, each row contains the data of one channel:\n");
        fprintf(fpOut,"//  trial0\n");
        fprintf(fpOut,"//    chan0: s0, s1, s2, ...\n");
        fprintf(fpOut,"//    chan1: s0, s1, s2, ...\n");
        fprintf(fpOut,"//    ....                \n");
        fprintf(fpOut,"//    chanN-1: s0, s1, s2, ...\n");
        fprintf(fpOut,"//  trial1\n");
        fprintf(fpOut,"//    ....                \n");

        double Stime = 1;
        if(NewSampFreq!=0) Stime = 1000./NewSampFreq;
        if(ChannelLabels==true)
            fprintf(fpOut,"// Chan%c",Separator);

        int j = 0;
        switch(TForm)
        {
        case U_TIMEFORM_NOLAB:      break;
        case U_TIMEFORM_TRIALMS:
        case U_TIMEFORM_TRIGGMS:    for(j=0; j<NSampOut; j++) fprintf(fpOut,"%f%c",j*Stime+TimeOffset,Separator); fprintf(fpOut,"\n"); break;
        case U_TIMEFORM_SAMPLE:     for(j=0; j<NSampOut; j++) fprintf(fpOut,"%d%c",j                 ,Separator); fprintf(fpOut,"\n"); break;
        }
    }
    fclose(fpOut);
    return U_OK;
}

ErrorType UMEEGDataEpochs::WriteCTFDataSet(const char* DSName, const bool SaveType[U_DAT_NTYPE], DataType ConvEKG, double NewSampFreq, int IEpoch, bool InvEEG, bool InvEKG) const
{
    if(Data==NULL || Data->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Data not properly set. \n");
        return U_ERROR;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Epochs not properly set. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Epochs times are not equal. \n");
        return U_ERROR;
    }
    if(NewSampFreq<=0.) NewSampFreq = Data->GetSampleRate();
    int NSampOut = int( Epochs->GetNsamp(0) * NewSampFreq / Data->GetSampleRate() );
    UInterpolate INT(Epochs->GetNsamp(0), NSampOut, U_INTERPOL_LIN);
    if(INT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Creating interpolation object. \n");
        return U_ERROR;
    }
    if(IEpoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Epoch number out of range (IEpoch=%d). \n", IEpoch);
        return U_ERROR;
    }

/* Test arguments */
    if(SaveType==NULL || DSName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Invalid NULL argument . \n");
        return U_ERROR;
    }
    int NchanSave = 0;
    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        int Nchan = Data->GetNkan(UMEEGDataBase::GetDataType(n));
        if(SaveType[n]==true && Nchan<=0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). No channels of type %d have been selected. \n", UMEEGDataBase::GetDataType(n));
            return U_ERROR;
        }
        NchanSave += Nchan;
    }
    if(NchanSave<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Nothing to export, all data type booleans are false. \n");
        return U_ERROR;
    }
    if(SaveType[U_DAT_EKG]==true&& (ConvEKG!=U_DAT_EEG && ConvEKG!=U_DAT_ADC) )
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Save as CTF file is only possible for EKG, when converted to EEG or ADC. \n");
        return U_ERROR;
    }
    if(SaveType[U_DAT_UNKNOWN]==true || SaveType[U_DAT_EEGREF]==true || SaveType[U_DAT_SSP ]==true ||
       SaveType[U_DAT_EOG    ]==true || SaveType[U_DAT_EMG   ]==true || SaveType[U_DAT_STIM]==true)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Unsupported data type selected. \n");
        return U_ERROR;
    }
    bool SaveREF = SaveType[U_DAT_MEGREF];
    bool SaveMEG = SaveType[U_DAT_MEG];
    bool SaveEEG = SaveType[U_DAT_EEG] || (SaveType[U_DAT_EKG]==true && ConvEKG==U_DAT_EEG);
    bool SaveADC = SaveType[U_DAT_ADC] || (SaveType[U_DAT_EKG]==true && ConvEKG==U_DAT_ADC);
    bool SaveEKG = SaveType[U_DAT_EKG];

    UCTFDataSet DS(DSName);
    if(DS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). UCTFDataSet()-object cannot be created from %s . \n", DSName);
        return U_ERROR;
    }

    UMEEGDataEpochs EpCopy(*this);
    if(SaveEKG==true && EpCopy.Data->ConvertDataType(U_DAT_EKG, ConvEKG)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Converting EKG to %s \n", UMEEGDataBase::GetDataTypeText(ConvEKG));
        return U_ERROR;
    }
    int NEP = 1;
    if(IEpoch<0) NEP = Epochs->GetnEpochs();
    int kstart       = MAX(0, IEpoch);

    UMEEGDataWriteCTF DatOut((UMEEGDataBase)(*EpCopy.Data));
    DatOut.SetDataFileName(DS.GetDataSetName());
    DatOut.SetNtrial(NEP);
    DatOut.SetNsampTrial(NSampOut);
    DatOut.SetSampleRate(NewSampFreq);
    DatOut.SetPreNTriggerPnts(INT.GetNsampOutput() * this->GetNPreTriggerSamples()/INT.GetNsampInput());

    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        DataType Dtype = UMEEGDataBase::GetDataType(n);

        if(SaveType[n]==false || EpCopy.GetData()->GetNChan(Dtype)<=0) continue;

        bool    Fabs   = true;
        double* DatMax = EpCopy.GetMaxDatChan(kstart, Dtype, Fabs);
        if(DatMax)
            DatOut.ScaleCallibrations(Dtype, DatMax, EpCopy.GetData()->GetNkan(Dtype), 32);
        delete[] DatMax;
    }

    if(SaveREF==true)
    {
        if(DatOut.GetGridREF()==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). No MEGREF data present in data set (%s). \n", Data->GetDataFileName().GetFullFileName());
            return U_ERROR;
        }
        DatOut.SetDewar2NLR(Data->GetDewar2NLR());
    }
    else
        DatOut.SetGridREF(NULL);

    if(SaveMEG==true)
    {
        if(DatOut.GetGridMEG()==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). No MEG data present in data set (%s). \n", Data->GetDataFileName().GetFullFileName());
            return U_ERROR;
        }
        DatOut.SetDewar2NLR(Data->GetDewar2NLR());
    }
    else
        DatOut.SetGridMEG(NULL);

    if(SaveEEG==true)
    {
        if(DatOut.GetGridEEG()==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). No EEG data present in data set (%s). \n", Data->GetDataFileName().GetFullFileName());
            return U_ERROR;
        }
    }
    else
        DatOut.SetGridEEG(NULL);

    if(SaveADC==true)
    {
        if(DatOut.GetGridADC()==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). No ADC data present in data set (%s). \n", Data->GetDataFileName().GetFullFileName());
            return U_ERROR;
        }
    }
    else
        DatOut.SetGridADC(NULL);

    if(DS.CreateDataSet()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Cannot create output directory (%s) .\n", DS.GetDataSetName());
        return U_ERROR;
    }

    DatOut.AddComment(CI.GetProperties("//  "), this->GetProperties("//  "));
    if(InvEEG) DatOut.AddComment("// EEGinverted = TRUE   \n");
    if(InvEKG) DatOut.AddComment("// ADCinverted = TRUE   \n");
    if(Data->GetSampleRate(), NewSampFreq)
    {
        UString Text = UString(Data->GetSampleRate(), "// \n// Data down sampled from %f")
                      +UString(NewSampFreq          , "to %f Hz .\n// \n");
        DatOut.AddComment(Text);
    }
    if(DatOut.WriteHeader()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Writing header of data set (%s) .\n", DS.GetDataSetName());
        return U_ERROR;
    }

    UFileName Fout(DS.GetCTFFileName());
    Fout.ReplaceExtension("meg4");
    FILE* fp = fopen(Fout,"wb", false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Cannot open %s .\n", Fout.GetFullFileName());
        return U_ERROR;
    }
    fclose(fp);

    for(int k=kstart,kout=0; k<kstart+NEP; k++, kout++)
    {
        ErrorType E = U_OK;
        if(SaveREF==true)
        {
            UMultiChan* MCiep = EpCopy.GetFilteredMultiChan(k, U_DAT_MEGREF);

            if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL) E = U_ERROR;
            if(E==U_OK) E = MCiep->ResampleData(&INT);                                   
            if(E==U_OK) E = DatOut.WriteTrial(MCiep->GetData(), U_DAT_MEGREF, kout);
            delete MCiep;
        }
        if(E==U_OK && SaveMEG==true)
        {
            UMultiChan* MCiep = EpCopy.GetFilteredMultiChan(k, U_DAT_MEG);
            if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL) E = U_ERROR;
            if(E==U_OK) E = MCiep->ResampleData(&INT);                                  
            if(E==U_OK) E = DatOut.WriteTrial(MCiep->GetData(), U_DAT_MEG, kout);
            delete MCiep;
        }
        if(E==U_OK && SaveEEG==true)
        {
            UMultiChan* MCiep = EpCopy.GetFilteredMultiChan(k, U_DAT_EEG);
            if(InvEEG && MCiep && MCiep->GetError()==U_OK) MCiep->InvertData();

            if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL) E = U_ERROR;
            if(E==U_OK) E = MCiep->ResampleData(&INT);                                   
            if(E==U_OK) E = DatOut.WriteTrial(MCiep->GetData(), U_DAT_EEG, kout);
            delete MCiep;
        }
        if(E==U_OK && SaveADC==true)
        {
            UMultiChan* MCiep = EpCopy.GetFilteredMultiChan(k, U_DAT_ADC);
            if(InvEKG && MCiep && MCiep->GetError()==U_OK) MCiep->InvertData();

            if(MCiep==NULL || MCiep->GetError()!=U_OK || MCiep->GetData()==NULL) E = U_ERROR;
            if(E==U_OK) E = MCiep->ResampleData(&INT);                                   
            if(E==U_OK) E = DatOut.WriteTrial(MCiep->GetData(), U_DAT_ADC, kout);
            delete MCiep;
        }
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Writing trial %d of data set (%s) .\n", k, DS.GetDataSetName());
            return U_ERROR;
        }
    }

    if(IEpoch<0 && Data->GetMarkerArray())
    {
        UMarkerArray NewMarkers(*(Data->GetMarkerArray()));
        if(NewMarkers.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Copying markers. \n");
            return U_ERROR;
        }
        if(NewMarkers.RedistributeTrials(Epochs, NewSampFreq)!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Redistributing events over new epochs. \n");
            return U_ERROR;
        }
        if(NewMarkers.WriteMarkersCTF(DS.GetMarkerFileName())!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteCTFDataSet(). Writing markers to file %s. \n", DS.GetMarkerFileName());
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UMEEGDataEpochs::WriteMarkersInECGFile(const char* FileOut) const
{
    if(Data == NULL || Data->GetError()!=U_OK ||
       Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteMarkersInECGFile(). Base class not properly set. \n");
        return U_ERROR;
    }

    if(Data->GetDataFormatType()!=U_DATFORM_ECG)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteMarkersInECGFile(). Original dat type should be %s \n", UMEEGDataBase::GetDataFormatTypeText(U_DATFORM_ECG));
        return U_ERROR;
    }
    if(FileOut==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteMarkersInECGFile(). NULL file name. \n");
        return U_ERROR;
    }

    UFileName Fout(FileOut);
    if(Fout.IsPureFile()==true)
        Fout = Data->GetDataFileName().GetSiblingFileName(Fout.GetBaseName());
    Fout.ReplaceExtension("ecg");
    if(Fout==Data->GetDataFileName())
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteMarkersInECGFile(). Output file name equals input file name: %s  .\n", Fout.GetFullFileName());
        return U_ERROR;
    }
    return ((UMEEGDataECG*)Data)->WriteNewMarkers(Fout);
}

ErrorType UMEEGDataEpochs::WriteEDF(const char* FileEDF, const bool SaveType[U_DAT_NTYPE], double NewSampFreq, int IEpoch, bool InvEEG, bool InvEKG) const
{
    if(Data == NULL             || Data->GetError()!=U_OK               ||
       Epochs==NULL             || Epochs->GetError()!=U_OK             ||
       Data->GetGridAll()==NULL || Data->GetGridAll()->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF(). Base class not properly set. \n");
        return U_ERROR;
    }
    if(FileEDF==NULL || SaveType==NULL)
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(NewSampFreq<=0.) NewSampFreq = Data->GetSampleRate();
    int NSampOut = int( Epochs->GetNsamp(0) * NewSampFreq / Data->GetSampleRate() );
    UInterpolate INT(Epochs->GetNsamp(0), NSampOut, U_INTERPOL_LIN);
    if(INT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Creating interpolation object. \n");
        return U_ERROR;
    }
    if(Epochs->AreEpochTimesEqual()==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Epochs are not of equal length.\n");
        return U_ERROR;
    }
    if(IEpoch>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Epoch number out of range (IEpoch=%d). \n", IEpoch);
        return U_ERROR;
    }

    int NchanSave = 0;
    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        int Nchan = Data->GetNkan(UMEEGDataBase::GetDataType(n));
        if(SaveType[n]==false) continue;

        if(Nchan<=0)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). No channels of type %s have been selected. \n", UMEEGDataBase::GetDataType(n));
            return U_ERROR;
        }
        NchanSave += Nchan;
    }
    if(NchanSave<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Nothing to export, all data type booleans are false. \n");
        return U_ERROR;
    }

    UFileName Fout(FileEDF);
    if(Fout.IsPureFile()==true)
        Fout = Data->GetDataFileName().GetSiblingFileName(Fout.GetBaseName());
    Fout.ReplaceExtension("edf");
    if(Fout==Data->GetDataFileName())
    {
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF(). Output file name equals input file name: %s  .\n", Fout.GetFullFileName());
        return U_ERROR;
    }
    FILE* fpEDF = fopen(Fout, "w+b");
    if(!fpEDF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Cannot create the file %s.\n",Fout.GetFullFileName());
        return U_ERROR;
    }

    int NEP = 1;
    if(IEpoch<0) NEP = Epochs->GetnEpochs();
    int kstart       = MAX(0, IEpoch);

    int   Nepochs          = NEP;
    EDF_CHAN_HEAD* chhdr   = new EDF_CHAN_HEAD[NchanSave];
    UMultiChan**   MCarr   = this->GetFilteredMultiChan(kstart, SaveType);
    short*         dataout = new short[NchanSave*NSampOut];
    double*        Scale   = new double[NchanSave];
    double*        MinLev  = new double[NchanSave];

    if(MCarr==NULL || chhdr==NULL || dataout==NULL || Scale==NULL || MinLev==NULL)
    {
        if(MCarr) for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
        delete[] MCarr;
        delete[] chhdr;
        delete[] dataout;
        delete[] Scale;
        delete[] MinLev;

        fclose(fpEDF);
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF().  Getting data of first epoch, or memory allocation. \n");
        return U_ERROR;
    }
    for(int n=0; n<U_DAT_NTYPE; n++)
    {
        if(SaveType[n]==false) continue;
        if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;
        if(MCarr[n]->ResampleData(&INT)!=U_OK)
        {
            if(MCarr) for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
            delete[] MCarr;
            delete[] chhdr;
            delete[] dataout;
            delete[] Scale;
            delete[] MinLev;

            fclose(fpEDF);
            CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF(). Resampling first data epoch. \n");
            return U_ERROR;
        }
    }

/* Fill header */
    const UGrid* GridAll = Data->GetGridAll();
    const double FACT  = NEP <100 ? 5. : 8.;
    const int    IMIN  = - (1<<15);
    const int    IMAX  =   (1<<15) -1;

    ErrorType   E        = U_OK;
    for(int n=0, ichan=0; n<U_DAT_NTYPE; n++)
    {
        if(SaveType[n]==false) continue;

        DataType DT    = UMEEGDataBase::GetDataType(n);
        int      Nchan = Data->GetNkan(DT);

        for(int i=0; i<Nchan; i++, ichan++)
        {
            int index = Data->GetChannelIndex(i, DT);
            if(index<0 || index>UMEEGDataBase::MAXCHAN)
            {
                CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF().  Index out of range. DataType = %d, senor = %d .\n",UMEEGDataBase::GetDataTypeText(DT), i);
                E = U_ERROR;
                break;
            }
            double MinDat = 0.;
            double MaxDat = 1.;
            if(MCarr[n]->GetMinMax(&MinDat, &MaxDat, i)!=U_OK)
            {
                CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF().  Computing minima and maxima of data type %s .\n", UMEEGDataBase::GetDataTypeText(DT));
                E = U_ERROR;
                break;
            }
            if(MinDat==MaxDat)
            {
                CI.AddToLog("WARNING UMEEGDataEpochs::WriteEDF().  Range of data type %s is zero. Level = %f .\n", UMEEGDataBase::GetDataTypeText(DT), MinDat);
                if(MinDat==0.)     {MinDat  =-1.  ; MaxDat  =1.  ;}
                else if(MinDat<0.) {MinDat *= FACT; MaxDat /=FACT;}
                else               {MinDat /= FACT; MaxDat *=FACT;}
            }
            else
            {
                if((InvEEG && DT==U_DAT_EEG) || (InvEKG && DT==U_DAT_EKG))
                {
                    double dum =  MaxDat;
                    MaxDat     = -MinDat;
                    MinDat     = -dum;
                }
                double Delta = MaxDat - MinDat;
                MaxDat       = MinDat +   FACT*Delta;
                MinDat       = MaxDat - 2*FACT*Delta;
            }
            Scale [ichan]    = (IMAX-IMIN)/(MaxDat-MinDat);
            MinLev[ichan]    = MinDat;
            const char* Name = GridAll->GetName(index);

            memset(chhdr+ichan,' ',sizeof(EDF_CHAN_HEAD));
            strncpy(chhdr[ichan].label, Name, 8);
            strncpy(chhdr[ichan].trans_type,UMEEGDataBase::GetDataTypeText(DT),80);
            strncpy(chhdr[ichan].phys_dim,UMEEGDataBase::GetUnitText(DT),8);

            UString Smin(MinDat, 8);
            UString Smax(MaxDat, 8);
            memcpy(chhdr[ichan].phys_min,(const char*)Smin, 8);
            memcpy(chhdr[ichan].phys_max,(const char*)Smax, 8);

            sprintf(chhdr[ichan].digi_min,"%d",IMIN);
            sprintf(chhdr[ichan].digi_max,"%d",IMAX);
            sprintf(chhdr[ichan].prefilter," ");
            sprintf(chhdr[ichan].nosamp_p_record,"%d",NSampOut);
        }
        if(E!=U_OK) break;
    }
    if(E!=U_OK)
    {
        if(MCarr) for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
        delete[] MCarr;
        delete[] chhdr;
        delete[] dataout;
        delete[] Scale;
        delete[] MinLev;

        fclose(fpEDF);
        CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF().  Creating EDF header. \n");
        return U_ERROR;
    }
    char *testhdr = (char*) chhdr;
    for(unsigned int k=0;k<NchanSave*sizeof(EDF_CHAN_HEAD);k++) if(testhdr[k]==0) testhdr[k] = ' ';

/* Fill general header */
    EDF_HEADER     hdr;
    memset(&hdr,' ',sizeof(EDF_HEADER));
    UFileName      DatF     = Data->GetDataFileName();
    const char*    FileName = DatF.GetBaseName();

    sprintf(hdr.version,"0");
    strncpy(hdr.patient     ,Data->GetPatName(),32);
    strncpy(hdr.recording   ,"E/MEG data: ",12);
    strncpy(hdr.recording+12, FileName,MIN(68,strlen(FileName)));

    char temp[10];
    memset(temp, 0, sizeof(temp));
    sprintf(temp+0,"%2.2d." ,Data->GetDateTime().GetDay());
    sprintf(temp+3,"%2.2d." ,Data->GetDateTime().GetMonth());
    sprintf(temp+6,"%2.2d " ,Data->GetDateTime().GetYear()%100);
    strncpy(hdr.date        ,temp,8);

    memset(temp, 0, sizeof(temp));
    sprintf(temp+0,"%2.2d." ,Data->GetDateTime().GetHour());
    sprintf(temp+3,"%2.2d." ,Data->GetDateTime().GetMin());
    sprintf(temp+6,"%2.2d"  ,Data->GetDateTime().GetSec());
    strncpy(hdr.time        ,temp,8);

    sprintf(hdr.nobytes     ,"%d" ,256+NchanSave*256);
    sprintf(hdr.norecords   ,"%d" ,Nepochs);
    sprintf(hdr.duration    ,"%7f",NSampOut/NewSampFreq);
    sprintf(hdr.nosignals   ,"%d" ,NchanSave);

    testhdr = (char*) &hdr;
    for(int k=0;k<sizeof(EDF_HEADER);k++) if(testhdr[k]==0) testhdr[k] = ' ';

/* Write General header */
    fwrite(&hdr, sizeof(hdr), 1, fpEDF);

/* Write channel headers */
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].label,      sizeof(chhdr[j].label),      1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].trans_type, sizeof(chhdr[j].trans_type), 1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].phys_dim  , sizeof(chhdr[j].phys_dim),   1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].phys_min  , sizeof(chhdr[j].phys_min),   1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].phys_max  , sizeof(chhdr[j].phys_max),   1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].digi_min  , sizeof(chhdr[j].digi_min),   1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].digi_max  , sizeof(chhdr[j].digi_max),   1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].prefilter , sizeof(chhdr[j].prefilter),  1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].nosamp_p_record, sizeof(chhdr[j].nosamp_p_record), 1, fpEDF);
    for(int j=0; j<NchanSave; j++) fwrite(chhdr[j].reserved  , sizeof(chhdr[j].reserved),  1, fpEDF);
    delete[] chhdr;

    CI.AddToLog("\nEpoch :");
    for(int k=kstart,kout=0; k<kstart+NEP; k++, kout++)
    {
        if(kout==NEP-1) CI.AddToLog("\n");
        if(kout!=0) // case k==0 is still valid
        {
            MCarr = this->GetFilteredMultiChan(k, SaveType);
            if(MCarr==NULL)
            {
                delete[] dataout;
                fclose(fpEDF);
                CI.AddToLog("ERROR UMEEGDataEpochs::WriteEDF().  Getting data of epoch %d. \n", k);
                return U_ERROR;
            }
            for(int n=0; n<U_DAT_NTYPE; n++)
            {
                if(MCarr[n]==NULL || MCarr[n]->GetNChan()<=0 || MCarr[n]->GetSensorGrid()==NULL) continue;
            
                if(MCarr[n]->ResampleData(&INT)!=U_OK)
                {
                    CI.AddToLog("ERROR: UMEEGDataEpochs::WriteEDF(). Resampling data in epoch %d. \n",k);
                    for(int nn=0; nn<U_DAT_NTYPE; nn++) delete MCarr[nn];
                    delete[] MCarr;
                    delete[] dataout;
                    fclose(fpEDF);
                }
            }
            if(InvEEG && SaveType[U_DAT_EEG] && MCarr[U_DAT_EEG]) MCarr[U_DAT_EEG]->InvertData();
            if(InvEKG && SaveType[U_DAT_EKG] && MCarr[U_DAT_EKG]) MCarr[U_DAT_EKG]->InvertData();
        }
        for(int n=0, ij=0, ichan=0; n<U_DAT_NTYPE; n++)
        {
            if(SaveType[n]==false) continue;
            DataType DT        = UMEEGDataBase::GetDataType(n);
            int          Nchan = Data->GetNkan(DT);
            const double* data = MCarr[n]->GetData();

            for(int i=0; i<Nchan; i++, ichan++)
                for(int j=0; j<NSampOut; j++, ij++)
                {
                    int idatout = int(floor((data[ i*NSampOut+j]-MinLev[ichan])*Scale[ichan] + IMIN + .5));
                    if(idatout<IMIN || idatout>IMAX)
                    {
                        static int NMESSASAGE = 0;
                        if(NMESSASAGE<32)
                        {
                            CI.AddToLog("WARNING: UMEEGDataEpochs::WriteEDF(). Data overflow, epoch = %d, datatype = %d \n", k, n);
                            NMESSASAGE++;
                            if(NMESSASAGE==32)
                                CI.AddToLog("WARNING: UMEEGDataEpochs::WriteEDF(). Data overflow, Last WARNING... \n", k, n);
                        }
                        idatout = MIN(IMAX, MAX(IMIN, idatout));
                    }
                    dataout[ij] = short(idatout);
                }
        }
        fwrite(dataout,2,NchanSave*NSampOut,fpEDF);

        if(MCarr) for(int n=0; n<U_DAT_NTYPE; n++) delete MCarr[n];
        delete[] MCarr;
    }
    delete[] dataout;
    delete[] Scale;
    delete[] MinLev;
    fclose(fpEDF);

    return U_OK;
}

#undef IMIN
#undef IMAX

ErrorType UMEEGDataEpochs::ReadResampleWriteCTFData(double Fresamp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL || DoesFileExist(Data->GetDataFileName())==false)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Data not read or data file does not exist.\n");
        return U_ERROR;
    }
    if(Data->GetDataFormatType()!=U_DATFORM_CTF)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Data of wrong format (%s).\n", UMEEGDataBase::GetDataFormatTypeText(Data->GetDataFormatType()));
        return U_ERROR;
    }

    *this = UMEEGDataEpochs(Data->GetDataFileName());
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Re-reading data.\n");
        return U_ERROR;
    }
    SetEpochs(-1, -1);

    double Fsamp = GetSampleRate();
    if(Fsamp<=0 || Fresamp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Invalid (re)sample frequencies (Fres=%s. Fsamp=%f) .\n", Fresamp, Fsamp);
        return U_ERROR;
    }
    double  ResampFact  = Fresamp/Fsamp;
    int     NsampTrial  = Data->GetNsampTrial();
    int    NtimeResamp  = int(floor( NsampTrial * ResampFact ));
    ResampFact          = NtimeResamp/double(NsampTrial);

    UString Text        = UString(NsampTrial, "Initializing resampling object from %d to ") + UString(NtimeResamp,"%d samples...");
    ShowStatus((const char*)Text);
    UInterpolate Resamp = UInterpolate(NsampTrial, NtimeResamp, U_INTERPOL_FFT);
    if(Resamp.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Initializing resampling object for FFT interpolation. \n");
        CI.AddToLog("Note:  UMEEGDataEpochs::ReadResampleWriteCTFData(). Try linear interpolation. \n");
        Resamp = UInterpolate(NsampTrial, NtimeResamp, U_INTERPOL_LIN);
        if(Resamp.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Initializing resampling object for piecewise linear interpolation. \n");
            return U_ERROR;
        }
    }
    SetRereference(U_REF_RAW, U_REF_RAW);
    SelectChannels(U_DAT_MEGREF, U_DAT_MEG, U_DAT_EEG, U_DAT_ADC);

    UDirectory TmpDir   =  Data->GetDataFileName().GetDirectory().Sibling("tmp.ds");
    UFileName  TmpFile  =  TmpDir + UFileName("tmp.res4");

    UMEEGDataWriteCTF CTFout(*Data);
    ErrorType   E = CTFout.GetError();
    if(E==U_OK) E = CTFout.SetDataFileName(TmpFile);
    if(E==U_OK) E = CTFout.SetNtrial(Epochs->GetnEpochs());
    if(E==U_OK) E = CTFout.SetNsampTrial(NtimeResamp);
    if(E==U_OK) E = CTFout.SetSampleRate(ResampFact*Fsamp);
    if(E==U_OK) E = CTFout.WriteHeader();
    if(E!=U_OK)
    {
        CTFout.DeleteDataFiles();
        CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Creating, modifying or writing CTF Header file. \n");
        return U_ERROR;
    }
    if(Data->GetMarkerArray())
    {
        UMarkerArray Mnew(*Data->GetMarkerArray());
        E = Mnew.GetError();
        if(E==U_OK) E = Mnew.ResampleData(NtimeResamp);
        if(E==U_OK) E = CTFout.WriteMarkerArray(&Mnew, false);
        if(E!=U_OK)
        {
            CTFout.DeleteDataFiles();
            CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Writing marker file. \n");
            return U_ERROR;
        }
    }

    UPowerLineType  PowerLine      = U_POWERLINE_NO;
    double          PLWidth        = 0.;
    double          FIRWindow      = 1.;
    ULinearFilter Filt(Fsamp);
    Filt.SetFilter(0., ResampFact*Fsamp/3., U_PREP_OFFSET, PowerLine, PLWidth, FIRWindow);

    int NTrial = Epochs->GetnEpochs();
    for(int it=0; it<NTrial; it++)
    {
        Text = UString(it, "Converting data of trial %d of ") + UString(NTrial,"%d ...");
        ShowStatus((const char*)Text);

        for(int n=0; n<U_DAT_NTYPE; n++)
        {
            DataType    DT = UMEEGDataBase::GetDataType(n);
            if(Data->GetNkan(DT)<=0) continue;

            UMultiChan* MC = GetFilteredMultiChan(it,DT);
            ErrorType   E  = U_OK;
            if(MC==NULL ||MC->GetError()!=U_OK) E=U_ERROR;
            if(E==U_OK) E  = MC->ApplyLinearFilter(Filt);
            if(E==U_OK) E  = MC->ResampleData(&Resamp);
            if(E==U_OK) E  = CTFout.WriteTrial(MC->GetData(), DT, it);
            delete MC;
            if(E!=U_OK)
            {
                CTFout.DeleteDataFiles();
                CI.AddToLog("ERROR: UMEEGDataEpochs::ReadResampleWriteCTFData(). Reading, filtering or writing data of trial %d, data type %d .\n",it, n);
                return U_ERROR;
            }
        }
    }
    CTFout.CopyDataFiles(Data->GetDataFileName().GetBaseName());
    CTFout.DeleteDataFiles();
    return U_OK;
}
