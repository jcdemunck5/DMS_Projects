/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a Elekta fif-file.                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    25-10-09   creation
  JdM    17-01-10   Corrected MEG/EEG sensor positions
  JdM    18-02-10   Getting triggers and Polhemus Points
  JdM    03-03-10   Bug fix. Corrected sensor coordinates, added GetDewar2NLR()
  JdM    31-03-10   ReadDirectory(). test tag.size==NULL
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    12-06-10   Changed parameters (AND THEIR MEANING) of main constructor. Bools indicate what data to read
  JdM    13-06-10   Added UScan member and functions to read beamformer and MRI scan data
  JdM    03-11-10   Added GetCTFGrid() and system to interpolate to default CTF sensor system
  JdM    27-11-10   Structured initialization of structure constants
  JdM    19-01-11   Bug fixes: GetScanData(). Analyzed MRI-alignment.
  JdM    18-07-11   GetScanData(): Added (guessed) modality to output UScan
  JdM    29-01-13   UMEEGDataFIFF::UMEEGDataFIFF(). Reading measurement date (FIFF_MEAS_DATE): test for invalid NULL pointer to avoid crashing
  JdM    28-11-13   UMEEGDataFIFF::UMEEGDataFIFF(). Be more flexible with invalid tags.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include <string.h>
#include <time.h>

#include "MEEGDataFIFF.h"
#include "MarkerArray.h"
#include "GridFit.h"
#include "Scan.h"
#include "InterpolateSensors.h"

/* Inititalize static const parameters. */
      UString UMEEGDataFIFF::Properties = UString();
const UEuler  UMEEGDataFIFF::Fiff2CTF   = UEuler(UVector3(0.,0.,1.),-PI/2);

#define LABTABSIZE 150
static const char* CTFLab[LABTABSIZE][2] =
{
    {"MEG0623","MLC11"},{"MEG0641","MLC12"},{"MEG0332","MLC13"},{"MEG0413","MLC14"},{"MEG0231","MLC15"},
    {"MEG0632","MLC21"},{"MEG0421","MLC22"},{"MEG0412","MLC23"},{"MEG0443","MLC24"},{"MEG0431","MLC31"},
    {"MEG0433","MLC32"},{"MEG1821","MLC33"},{"MEG0711","MLC41"},{"MEG0712","MLC42"},{"MEG0743","MLC43"},
    {"MEG0523","MLF11"},{"MEG0513","MLF12"},{"MEG0812","MLF21"},{"MEG0522","MLF22"},{"MEG0512","MLF23"},
    {"MEG0531","MLF31"},{"MEG0541","MLF32"},{"MEG0543","MLF33"},{"MEG0322","MLF34"},{"MEG1013","MLF41"},
    {"MEG0613","MLF42"},{"MEG0333","MLF43"},{"MEG0323","MLF44"},{"MEG0221","MLF45"},{"MEG0642","MLF51"},
    {"MEG0643","MLF52"},{"MEG2042","MLO11"},{"MEG1912","MLO12"},{"MEG1923","MLO21"},{"MEG1943","MLO22"},
    {"MEG1933","MLO31"},{"MEG1733","MLO32"},{"MEG1723","MLO33"},{"MEG1712","MLO42"},{"MEG1532","MLO43"},
    {"MEG1831","MLP11"},{"MEG1841","MLP12"},{"MEG1811","MLP13"},{"MEG2011","MLP21"},{"MEG1842","MLP22"},
    {"MEG1913","MLP31"},{"MEG1633","MLP32"},{"MEG1812","MLP33"},{"MEG1621","MLP34"},{"MEG0311","MLT11"},
    {"MEG0342","MLT12"},{"MEG0212","MLT13"},{"MEG0232","MLT14"},{"MEG1622","MLT15"},{"MEG1632","MLT16"},
    {"MEG0313","MLT21"},{"MEG0343","MLT22"},{"MEG0213","MLT23"},{"MEG0243","MLT24"},{"MEG1613","MLT25"},
    {"MEG1643","MLT26"},{"MEG0122","MLT31"},{"MEG0123","MLT32"},{"MEG0133","MLT33"},{"MEG1513","MLT34"},
    {"MEG1523","MLT35"},{"MEG0111","MLT41"},{"MEG0112","MLT42"},{"MEG0142","MLT43"},{"MEG1542","MLT44"},
    {"MEG1033","MRC11"},{"MEG1113","MRC12"},{"MEG1122","MRC13"},{"MEG1123","MRC14"},{"MEG1341","MRC15"},
    {"MEG1041","MRC21"},{"MEG1112","MRC22"},{"MEG1132","MRC23"},{"MEG1133","MRC24"},{"MEG1143","MRC31"},
    {"MEG2213","MRC32"},{"MEG2211","MRC33"},{"MEG0721","MRC41"},{"MEG0732","MRC42"},{"MEG0733","MRC43"},
    {"MEG0913","MRF11"},{"MEG0923","MRF12"},{"MEG0912","MRF21"},{"MEG0922","MRF22"},{"MEG1212","MRF23"},
    {"MEG0941","MRF31"},{"MEG0931","MRF32"},{"MEG1233","MRF33"},{"MEG1221","MRF34"},{"MEG1022","MRF41"},
    {"MEG1023","MRF42"},{"MEG1243","MRF43"},{"MEG1313","MRF44"},{"MEG1312","MRF45"},{"MEG1032","MRF51"},
    {"MEG1241","MRF52"},{"MEG2112","MRO11"},{"MEG2312","MRO12"},{"MEG2343","MRO21"},{"MEG2323","MRO22"},
    {"MEG2123","MRO31"},{"MEG2333","MRO32"},{"MEG2513","MRO33"},{"MEG2132","MRO41"},{"MEG2542","MRO42"},
    {"MEG2532","MRO43"},{"MEG2243","MRP11"},{"MEG2232","MRP12"},{"MEG2221","MRP13"},{"MEG2021","MRP21"},
    {"MEG2022","MRP22"},{"MEG2033","MRP31"},{"MEG2313","MRP32"},{"MEG2443","MRP33"},{"MEG2411","MRP34"},
    {"MEG1222","MRT11"},{"MEG1322","MRT12"},{"MEG1332","MRT13"},{"MEG2422","MRT14"},{"MEG2432","MRT15"},
    {"MEG2442","MRT16"},{"MEG1213","MRT21"},{"MEG1411","MRT22"},{"MEG1441","MRT23"},{"MEG1333","MRT24"},
    {"MEG2423","MRT25"},{"MEG2433","MRT26"},{"MEG1413","MRT31"},{"MEG1443","MRT32"},{"MEG2612","MRT33"},
    {"MEG2643","MRT34"},{"MEG2523","MRT35"},{"MEG1422","MRT41"},{"MEG1432","MRT42"},{"MEG2622","MRT43"},
    {"MEG2632","MRT44"},{"MEG1042","MZC01"},{"MEG0742","MZC02"},{"MEG0813","MZF01"},{"MEG0821","MZF02"},
    {"MEG0622","MZF03"},{"MEG2113","MZO01"},{"MEG2142","MZO02"},{"MEG1833","MZP01"},{"MEG2043","MZP02"}
};

#define MAXLEVEL 32  // Levels is directory tree
#define MAXTRANS 32  // Number of trigger transitions

static const bool IntelData = false;
int BaseSize[U_FIFF_NTYPE] = {1,1,2,4,4,8,8,2,   // ..., FIFF_USHORT,
                              4,0,1,0,0,2,2,0,   // ..., FIFF_DAU_PACK14,???,
                              2,0,0,0,0,0,0,-1,  // ..., FIFF_OLD_PACK,
                              0,0,0,0,0,0,80,20, // ..., FIFF_ID_STRUCT,
                              16,20,44,80,-1};   // ..., FIFF_DIG_STRING_STRUCT


FIFF_CoordType GetFIFF_CoordType(int itype)
{
    switch(itype)
    {
    case   0: return FIFFV_COORD_UNKNOWN       ;
    case   1: return FIFFV_COORD_DEVICE        ;
    case   2: return FIFFV_COORD_ISOTRAK       ;
    case   3: return FIFFV_COORD_HPI           ;
    case   4: return FIFFV_COORD_HEAD          ;
    case   5: return FIFFV_COORD_MRI           ;
    case   6: return FIFFV_COORD_MRI_SLICE     ;
    case   7: return FIFFV_COORD_MRI_DISPLAY   ;
    case   8: return FIFFV_COORD_DICOM_DEVICE  ;
    case   9: return FIFFV_COORD_IMAGING_DEVICE;
    case 100: return FIFFV_COORD_TORSO         ;
    }
    CI.AddToLog("ERROR: GetFIFF_CoordType(). invalid index (itype=%d)  .\n", itype);
    return FIFFV_COORD_UNKNOWN;
}

const char* GetBlockText(int iblock)
{
    switch(iblock)
    {
    case FIFFB_MEAS                : return "One data acquisition.";
    case FIFFB_MEAS_INFO           : return "Contains the information about the acquisition details.";
    case FIFFB_RAW_DATA            : return "Contains the raw continuous data.";
    case FIFFB_PROCESSED_DATA      : return "Contains data processed from the raw data like evoked responses.";
    case FIFFB_EVOKED              : return "Used within FIFFB_PROCESSED_DATA. Contains evoked responses (or Averaged MCG data).";
    case FIFFB_ASPECT              : return "Used within FIFFB_EVOKED to include one aspect of evoked responses like standard average, alternating average, standard error of mean etc.";
    case FIFFB_SUBJECT             : return "Contains information about the subject or patient.";
    case FIFFB_ISOTRAK             : return "Contains the head digitization data.";
    case FIFFB_HPI_MEAS            : return "Contains the data acquired when the head-position indicator (HPI) coils were energized.";
    case FIFFB_HPI_RESULT          : return "Result of the HPI coil fitting procedure.";
    case FIFFB_HPI_COIL            : return "Used within FIFFB_HPI_MEAS. Contains data acquired from one HPI coil.";
    case FIFFB_PROJECT             : return "Contains information about the project under which the data were acquired.";
    case FIFFB_CONTINUOUS_DATA     : return "Continuous data.";
    case FIFFB_VOID                : return "Unspecified contents.";
    case FIFFB_EVENTS              : return "Contains information about the events detected on the trigger channels during data acquisition.";
    case FIFFB_INDEX               : return "Contains an index of file id/file name pairs.";
    case FIFFB_DACQ_PARS           : return "Contains the acquisition setup parameters.";
    case FIFFB_REF                 : return "Reference mechanism.";
    case FIFFB_SMSH_RAW_DATA       : return "Indicates raw data collected with active compensation.";
    case FIFFB_SMSH_ASPECT         : return "Epoch data collected with active compensation.";
    case FIFFB_MRI                 : return "Contains MRI data.";
    case FIFFB_MRI_SET             : return "Contains one MRI series.";
    case FIFFB_MRI_SLICE           : return "Contains one MRI slices.";
    case FIFFB_MRI_SCENERY         : return "Contains a set of related (in DICOM terminology �secondary capture�) images like the 3D renderings of the brain surface.";
    case FIFFB_MRI_SCENE           : return "Contains one image of a scenery.";
    case FIFFB_MRI_SEG             : return "Contains MRI segmentation data.";
    case FIFFB_MRI_SEG_REGION      : return "Contains description of one segmented region.";
    case FIFFB_SPHERE              : return "Contains a spherically symmetric volume conductor description.";
    case FIFFB_BEM                 : return "Contains a boundary-element model (BEM) description.";
    case FIFFB_BEM_SURF            : return "Describes one BEM surface.";
    case FIFFB_CONDUCTOR_MODEL     : return "Contains one or more conductor model descriptions (FIFFB_SPHERE or FIFFB_BEM).";
    case FIFFB_XFIT_PROJ           : return "Contains the signal-space projection (SSP) data.";
    case FIFFB_XFIT_PROJ_ITEM      : return "Contains one set of vectors of the SSP data.";
    case FIFFB_XFIT_AUX            : return "Contains the auxiliary data created by the source modelling program xfit.";
    case FIFFB_VOL_INFO            : return "Describes a data volume.";
    case FIFFB_DATA_CORRECTION     : return "Indicates that correction was done on the data.";
    case FIFFB_CHANNEL_DECOUPLER   : return "Cross-talk compensation information.";
    case FIFFB_SSS_INFO            : return "Signal space separation SSS information.";
    case FIFFB_SSS_CAL_ADJUST      : return "Calibration adjustment information.";
    case FIFFB_SSS_ST_INFO         : return "Information of the SSST parameters.";
    case FIFFB_SSS_BASES           : return "Basis matrices of SSS.";
    case FIFFB_SMARTSHIELD         : return "Information of MaxShield.";
    case FIFFB_PROCESSING_HISTORY  : return "Processing history block.";
    case FIFFB_PROCESSING_RECORD   : return "One processing history record.";
    case FIFFB_ROOT                : return "Root block of a file (has not been used so far).";
    }
    return "Block type unknown";
}

void UMEEGDataFIFF::SetAllMembersDefault(void)
{
    Nitem                    = 0;
    ItemDir                  = NULL;
    TrialItem                = NULL;
    NtrialSkip               = 0;
    NBadChan                 = 0;
    BadChanIndex             = NULL;
    ChanIndex                = NULL;
    RawDatType               = U_FIFF_VOID;
    RawDatSize               = 0;
    NTrigChan                = 0;
    TrChan                   = NULL;

    Dev2Head                 = UEuler();
    Nasion                   = UVector3();
    Left                     = UVector3();
    Right                    = UVector3();
    NPolPoint                = 0;
    NPolPointAlloc           = 0;
    PolhemusPoints           = NULL;
    Scan                     = NULL;

    FileIdentifier.timesec   = 0;
    FileIdentifier.timefrac  = 0;
    FileIdentifier.machid[0] = 0;
    FileIdentifier.machid[1] = 0;
    FileIdentifier.version   = 0;

    Properties      = (const char*)NULL;
    Comments        = UString();
}

void UMEEGDataFIFF::DeleteAllMembers(ErrorType E)
{
    delete[] ItemDir;
    delete[] TrialItem;
    delete[] BadChanIndex;
    delete[] ChanIndex;
    delete[] TrChan;
    delete[] PolhemusPoints;
    delete   Scan;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataFIFF::~UMEEGDataFIFF()
{
    DeleteAllMembers(U_OK);
}

UMEEGDataFIFF::UMEEGDataFIFF() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataFIFF::UMEEGDataFIFF(UFileName FileName) :
    UMEEGDataBase()
{
    SetAllMembersDefault();
    *this = UMEEGDataFIFF(FileName, true, false, false);
}
UMEEGDataFIFF::UMEEGDataFIFF(UFileName FileName, bool ReadMEEGData, bool ReadPolData, bool ReadScanData) :
    UMEEGDataBase()
{
    SetAllMembersDefault();

    if(ReadDirectory(FileName)!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading directory from file : %s \n",(const char*)FileName);
        return;
    }
    if(ItemDir==NULL || Nitem<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). No items in directory : %s \n",(const char*)FileName);
        return;
    }
    FILE* fpIn = fopen(FileName, "rb", false);
    if(fpIn==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Cannot open file : %s \n",(const char*)FileName);
        return;
    }
    DataFileName   = FileName;
    Comments       = UString();
    Comments      += UString(     FileIdentifier.timesec , "FileCreationTime_s  = %d //[s] \n");
    Comments      += UString((int)FileIdentifier.timefrac, "FileCreationTime_us = %d //[us]\n");

    ChIn           = new ChanInfo[MAXCHAN];
    ChanIndex      = new int[MAXCHAN];
    GridAll        = new UGrid(MAXCHAN);
    TrialItem      = new int[Nitem];

    if(!ChIn    || !ChanIndex                ||
       !GridAll || GridAll->GetError()!=U_OK ||
       !TrialItem)
    {
        fclose(fpIn);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). memory allocation. \n");
        return;
    }
/******
    UFileName Test(FileName);
    Test.InsertBeforeExtension("_dir");
    Test.ReplaceExtension("txt");
    PrintDirectory(Test);
/******/

    for(int k=0; k<Nitem;   k++) TrialItem[k] = 0;
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"FIFF_%d",i);
        ChIn[i].type          =  U_DAT_UNKNOWN;
        ChIn[i].InGain        =  1.;
        ChIn[i].GainFact      =  1.;
        ChIn[i].Offset        =  0.;
        ChIn[i].SkipChannel   =  false;
        ChIn[i].Red           =  0;
        ChIn[i].Green         =  0;
        ChIn[i].Blue          =  0;
        ChIn[i].LT            =  1;
        ChanIndex[i]          = -1;
    }
    EEGposTrue           = true;
    EEGlabelTrue         = true;
    DataFormat           = U_DATFORM_FIFF;
    DataFileName         = FileName;
    ContineousData       = true;
    bool   Dev2HeadFound = false;

    nMEG = nEEG = nADC   = nREF = 0;
    STIM                 = false;
    ntrial               =  0;
    nsamp                =  0;
    int  ichan           =  0;
    int  Dpack           = -1;
    int  FirstSamp       =  0;
    int  LastSamp        =  0;
    int  TestRaw         = -1;
    int  NextItem        = -1;
    int  LevelMeas       = -1; ///??

    if(ReadPolData)
    {
        if(GetIsoTrackData(fpIn)!=U_OK)
        {
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading isotrack data. \n");
            return;
        }
    }
    if(ReadScanData)
    {
        if(GetScanData(fpIn)!=U_OK)
        {
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading scan data. \n");
            return;
        }
    }
    if(ReadMEEGData || ReadPolData)
    {
        if(ReadMEEGData)
        {
            TestRaw = GetItemNextBlock(0,        FIFFB_RAW_DATA,        fpIn);
            if(TestRaw<0)
                 TestRaw         =  GetItemNextBlock(0,        FIFFB_CONTINUOUS_DATA, fpIn);
            if(TestRaw<0)
            {
                fclose(fpIn);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Raw data not found. \n");
                return;
            }
        }
        NextItem       =  GetItemNextBlock(0, FIFFB_MEAS, fpIn);
        if(NextItem<0)
        {
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). FIFFB_MEAS block not found. \n");
            return;
        }
        NextItem           =  GetItemNextBlock(NextItem, FIFFB_MEAS_INFO, fpIn);
        if(NextItem<0)
        {
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). FIFFB_MEAS_INFO block not found. \n");
            return;
        }
        LevelMeas = ItemDir[NextItem].Level +1;
    }
    else
        LevelMeas = GetItemNextBlock(0,FIFFB_MRI, fpIn);

    for(int n = NextItem; n<Nitem; n++)
    {
        switch(ItemDir[n].kind)
        {
        case FIFF_HPI_NCOIL:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int Ncoil =  ReadBinaryInt(IntelData, fpIn);
                Comments += UString(Ncoil , "Ncoil               = %d \n");
            }   break;
        case FIFF_DESCRIPTION:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                char Combuf[600];
                memset(Combuf, 0, sizeof(Combuf));
                int nbytes = MIN(sizeof(Combuf), ItemDir[n].size)-1;
                fread(Combuf, nbytes, 1, fpIn);
                UString C(Combuf); C.ReplaceBlankSpace(false);
                Comments += UString("Comment             = ") +C+" \n";
            }   break;
        }

        if(ItemDir[n].Level <LevelMeas  ) continue;
        if(ItemDir[n].Level==LevelMeas+1)
        {
            switch(ItemDir[n].kind)
            {
            case FIFF_SUBJ_LAST_NAME:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    memset(PatName, 0, sizeof(PatName));
                    int nbytes = MIN(sizeof(PatName), ItemDir[n].size)-1;
                    fread(PatName, nbytes, 1, fpIn);
                } break;
            case FIFF_SUBJ_HIS_ID:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    memset(PatID, 0, sizeof(PatID));
                    int nbytes = MIN(sizeof(PatID), ItemDir[n].size)-1;
                    fread(PatID, nbytes, 1, fpIn);
                } break;
            case FIFF_SUBJ_BIRTH_DAY:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    int Birth = ReadBinaryInt  (IntelData, fpIn);
                    break;
                }
            }
        }
        if(ItemDir[n].Level==LevelMeas)
        {
            switch(ItemDir[n].kind)
            {
            case FIFF_COORD_TRANS:
                Dev2HeadFound = ReadDevToHead(fpIn, ItemDir[n].pos+16, &Dev2Head);
                break;
            case FIFF_NCHAN:
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                NchannelRaw = ReadBinaryInt  (IntelData, fpIn);
                break;
            case FIFF_SFREQ:
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                srate       = ReadBinaryFloat(IntelData, fpIn);
                break;
            case FIFF_FIRST_SAMPLE:
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                FirstSamp   = ReadBinaryInt  (IntelData, fpIn);
                break;
            case FIFF_LAST_SAMPLE:
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                LastSamp    = ReadBinaryInt  (IntelData, fpIn);
                break;
            case FIFF_DACQ_PARS:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    char Combuf[600];
                    memset(Combuf, 0, sizeof(Combuf));
                    int nbytes = MIN(sizeof(Combuf), ItemDir[n].size)-1;
                    fread(Combuf, nbytes, 1, fpIn);
                    UString C(Combuf); C.ReplaceBlankSpace(false);
                    Comments += UString("ACQpars            = ") +C+" \n";
                }   break;
            case FIFF_LOWPASS:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    double lpass = ReadBinaryFloat(IntelData, fpIn);
                    Comments += UString(lpass, "Lowpass            =  %f \n");
                }   break;
            case FIFF_HIGHPASS:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    double hpass = ReadBinaryFloat(IntelData, fpIn);
                    Comments += UString(hpass, "Highpass           =  %f \n");
                }   break;

            case FIFF_MEAS_DATE:
                {
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    long Date1       =  ReadBinaryInt(IntelData, fpIn);
                    struct       tm *ltime = localtime((const time_t*)&Date1);
                    if(ltime) DateTimeRec  = UDateTime(1900+ltime->tm_year, ltime->tm_mon, ltime->tm_mday, ltime->tm_hour, ltime->tm_min, ltime->tm_sec);
                    else      CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Invalid date in file: %s \n", (const char*)DataFileName);
                }   break;

            case FIFF_BAD_CHS:
                {
                    NBadChan         = MAX(0, (ItemDir[n].size/4));
                    if(NBadChan<=0) break;
                    BadChanIndex     = new int[NBadChan];
                    if(BadChanIndex==NULL)
                    {
                        CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Memmory allocation, NBadChan = %d. Bad channels not marked .\n", NBadChan);
                        NBadChan = 0;
                        break;
                    }
                    fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                    for(int k=0; k<NBadChan; k++) BadChanIndex[k] = ReadBinaryInt(IntelData, fpIn) -1;
                }   break;

            case FIFF_CH_INFO:
                {
                    FIFF_CHANINFO ChI = ReadChanInfo(fpIn, ItemDir[n].pos+16);
                    ChanIndex[ichan]  = ChI.scanNo-1;
                    UVector3 xx,cc,nn;
                    if(ChI.kind==FIFFDAT_MEG)
                    {
                        int Cindex = -1;
                        switch(ChI.coil_type)
                        {
                        case 2   : Cindex =  0; break;
                        case 2000: Cindex =  1; break;
                        case 3012: Cindex =  2; break;
                        case 3013: Cindex =  3; break;
                        case 3022: Cindex =  4; break;
                        case 3023: Cindex =  5; break;
                        case 3024: Cindex =  6; break;
                        case 4001: Cindex =  7; break;
                        case 4002: Cindex =  8; break;
                        case 4003: Cindex =  9; break;
                        case 4004: Cindex = 10; break;
                        case 4005: Cindex = 11; break;
                        case 5001: Cindex = 12; break;
                        case 5002: Cindex = 13; break;
                        case 5003: Cindex = 14; break;
                        case 5004: Cindex = 15; break;
                        case 6001: Cindex = 16; break;
                        case 7001: Cindex = 17; break;
                        }
                        if(Cindex<0 || Cindex>=MEGGRID)
                        {
                            Cindex = 0;
                            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading channel info %s. \n", ChI.name);
                        }
                        Cindex *=3;

                        UEuler   D2H;
                        D2H.SetRotMatrix(ChI.ex, ChI.ey, ChI.ez);
                        UVector3 Sx(FiffGrid[Cindex].P[0].x, FiffGrid[Cindex].P[0].y, FiffGrid[Cindex].P[0].z);
                        UVector3 Sc(FiffGrid[Cindex].P[1].x, FiffGrid[Cindex].P[1].y, FiffGrid[Cindex].P[1].z);
                        xx = UVector3(ChI.r0) + D2H.xfm(Sx);
                        cc = UVector3(ChI.r0) + D2H.xfm(Sc);
                        nn = D2H.xfm(UVector3(FiffGrid[Cindex].P[0].nx, FiffGrid[Cindex].P[0].ny, FiffGrid[Cindex].P[0].nz));
                    }
                    else
                    {
                        xx = UVector3(ChI.r0);
                        cc = UVector3(ChI.r0);
                        nn = UVector3(1.,0.,0.);
                    }
                    xx = 100.*xx;
                    cc = 100.*cc;

                    memset(ChIn[ichan].namChannel, 0       ,     sizeof(ChIn[ichan].namChannel));
                    memcpy(ChIn[ichan].namChannel, ChI.name, MIN(sizeof(ChIn[ichan].namChannel), sizeof(ChI.name))-1);
                    USensor S;
                    switch(ChI.kind)
                    {
                    case FIFFDAT_MEG:
                        ChIn[ichan].type = U_DAT_MEG;
                        if(ChI.coil_type==FIFFCOIL_GRAD) S = USensor(xx,nn,cc, USensor::U_SEN_GRAD, ChIn[ichan].namChannel);
                        else                             S = USensor(xx,nn,cc, USensor::U_SEN_MAG , ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = ChI.range * ChI.cal * 1e15;
                        if(ChI.coil_type==FIFFCOIL_GRAD) ChIn[ichan].InGain *= 0.01*(cc-xx).GetNorm();
                        nMEG++;
                        break;
                    case FIFFDAT_EEG:
                        ChIn[ichan].type = U_DAT_EEG;
                        S = USensor(xx,UVector3(), UVector3() , USensor::U_SEN_EEG, ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = ChI.range * ChI.cal * 1e6;
                        nEEG++;
                        break;
                    case FIFFDAT_STI:
                        ChIn[ichan].type = U_DAT_ADC;
                        S = USensor(xx,UVector3(), UVector3() , USensor::U_SEN_POINT, ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = 1;
                        nADC++;
                        break;
                    case FIFFDAT_EMG:
                        ChIn[ichan].type = U_DAT_EMG;
                        S = USensor(xx,UVector3(), UVector3() , USensor::U_SEN_POINT, ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = ChI.range * ChI.cal * 1e6;
                        break;
                    case FIFFDAT_ECG:
                        ChIn[ichan].type = U_DAT_EKG;
                        S = USensor(xx,UVector3(), UVector3() , USensor::U_SEN_POINT, ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = ChI.range * ChI.cal * 1e6;
                        break;
                    default:
                        ChIn[ichan].type = U_DAT_UNKNOWN;
                        S = USensor(xx,UVector3(), UVector3() , USensor::U_SEN_POINT, ChIn[ichan].namChannel);
                        ChIn[ichan].InGain = 1;
                        break;
                    }
                    GridAll->SetSensor(&S, ichan);
                    if(ichan+1<MAXCHAN) ichan++;
                    else                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Too many channels. \n");
                    if(nMEG>=MAXMEG) {nMEG--; ichan--; CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Too many MEG channels. \n");}
                    if(nEEG>=MAXEEG) {nEEG--; ichan--; CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Too many EEG channels. \n");}
                    if(nADC>=MAXADC) {nADC--; ichan--; CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Too many ADC channels. \n");}

                } break;
            case FIFF_DATA_PACK:
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                Dpack       = ReadBinaryInt  (IntelData, fpIn);
                Comments   += UString(Dpack , "DatPack             = %d \n");
                break;
/****
            case FIFF_EPOCH:
                TrialItem[ntrial] = n;
                ntrial++;
                break;
*****/
            case FIFF_DATA_SKIP:
                NtrialSkip++;
                break;
            case FIFF_DATA_BUFFER:
                {
                    if(NchannelRaw<=0)
                    {
                        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Number of channels not read when reading data buffer. \n");
                        fclose(fpIn);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                    if((ItemDir[n].type!=U_FIFF_SHORT        &&
                        ItemDir[n].type!=U_FIFF_INT          &&
                        ItemDir[n].type!=U_FIFF_FLOAT        &&
                        ItemDir[n].type!=U_FIFF_DAU_PACK16)        ||
                        BaseSize[ItemDir[n].type]==0)
                    {
                        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Wrong data type. \n");
                        fclose(fpIn);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                    if(ntrial==0)
                    {
                        RawDatType = ItemDir[n].type;
                        RawDatSize = BaseSize[ItemDir[n].type];
                    }
                    else
                    {
                        if(RawDatType!=ItemDir[n].type || RawDatSize!=BaseSize[ItemDir[n].type])
                        {
                            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Data size/type not constant. \n");
                            fclose(fpIn);
                            UMEEGDataBase::DeleteAllMembers(U_ERROR);
                            DeleteAllMembers(U_ERROR);
                            return;
                        }
                    }
                    if( (ItemDir[n].size%NchannelRaw) || ((ItemDir[n].size/NchannelRaw)%RawDatSize) )
                    {
                        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Number of channels (%d) compatible with buffer size (%d) .\n", NchannelRaw, ItemDir[n].size);
                        fclose(fpIn);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                    if(ntrial==0)
                    {
                        nsamp = ItemDir[n].size/(NchannelRaw*RawDatSize);
                    }
                    else if(nsamp != ItemDir[n].size/(NchannelRaw*RawDatSize))
                    {
                        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Trial size is variyng from (%d) to (%d) .\n", NchannelRaw, ItemDir[n].size);
                        fclose(fpIn);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                }
                TrialItem[ntrial] = n;
                ntrial++;
                break;
            }
        }
    }

/*
    The positions of MEG channels are given in device coordinates
    while the position of the EEG channels are obtained in the head
    digitization procedure and are thus given in head coordinates.
 */
    Nasion = UVector3();
    Left   = UVector3();
    Right  = UVector3();
    if(Dev2HeadFound==false)
    {
        int HPIblock = GetItemNextBlock(0, FIFFB_HPI_RESULT, fpIn);
        if(HPIblock>0)
        {
            for(int n = HPIblock; n<Nitem; n++)
            {
                if(ItemDir[n].kind!=FIFF_COORD_TRANS) continue;
                Dev2HeadFound = ReadDevToHead(fpIn, ItemDir[n].pos+16, &Dev2Head);
                break;
            }
        }
    }
    if(Dev2HeadFound) Dev2HeadFound = ReadNLR(fpIn, &Nasion, &Left, &Right);

    if(Dev2HeadFound==false)
    {
        CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). NLR positions not found. Apply default orientation.\n");
        GridAll->Transform(Fiff2CTF); // Apply the default transform;
    }
    else
    {
        UEuler ToNLR(Nasion, Left, Right);
        GridAll->Transform(ToNLR * Dev2Head, USensor::U_SEN_MAG );
        GridAll->Transform(ToNLR * Dev2Head, USensor::U_SEN_GRAD);
        GridAll->Transform(ToNLR           , USensor::U_SEN_EEG );
        Nasion = ToNLR.xfm(Nasion);
        Left   = ToNLR.xfm(Left  );
        Right  = ToNLR.xfm(Right );
        if(PolhemusPoints)
            for(int k=0; k<NPolPoint; k++) PolhemusPoints[k] = ToNLR.xfm(PolhemusPoints[k]);
    }
    if(ReadMEEGData)
    {
        NPreTrig           = 0;
        nAver              = 0;
        NchannelTot        = NchannelRaw;
        if(nsamp==0) nsamp = abs(LastSamp - FirstSamp);

        if(srate<=0 || ntrial<=0 || nsamp<=0 || NchannelRaw<=0)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading srate, ntrial, nsamp and/or NchannelRaw . \n");
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int ichan=0; ichan<NchannelRaw; ichan++)
        {
            if(ChanIndex[ichan]<0 || ChanIndex[ichan]>=NchannelRaw)
            {
                CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Channel index (%d) out of range (NchannelRaw=%d). \n", ChanIndex[ichan], NchannelRaw);
                fclose(fpIn);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }

        if(nREF) GridREF = new UGrid(nREF);
        if(nMEG) GridMEG = new UGrid(nMEG);
        if(nEEG) GridEEG = new UGrid(nEEG);
        if(nADC) GridADC = new UGrid(nADC);

        if( (nREF && (GridREF==NULL || GridREF->GetError()!=U_OK) ) ||
            (nMEG && (GridMEG==NULL || GridMEG->GetError()!=U_OK) ) ||
            (nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) ||
            (nADC && (GridADC==NULL || GridADC->GetError()!=U_OK) ) )
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Memory allocation for Grid. \n");
            fclose(fpIn);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return;
        }

/* Set the type specific grids*/
        SelectChannels((char*)NULL, (char*)NULL);

/* Read markers and classes */
        TrChan          = ReadFiffTrigChans(fpIn, &NTrigChan);
        UFiffEvents* FE = ReadFiffEvents(fpIn);
        fclose(fpIn);
        Markers = NULL;
        if(FE && FE->GetError()==U_OK)
            Markers = FE->GetMarkerArray(nsamp, NtrialSkip, srate);
        delete FE;

        UMarkerArray* ChanMark = NULL;
        if(TrChan!=NULL)
            ChanMark = GetChannelMarkers();
        if(ChanMark!=NULL)
        {
            if(Markers) {Markers->MergeMarkerArray(ChanMark, true); delete ChanMark;}
            else         Markers = ChanMark;
        }
        if(SetLaplacianReferenceMatrix()!=U_OK)
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Setting new Laplacian reference matrix \n");


        UGrid* GridCTF = GetCTFGrid();
        double R0      = 7.5;
        if(GridMEG && GridCTF)
        {
            CTFSensorInter = new UInterpolateSensors(GridMEG, GridCTF, R0);
            if(CTFSensorInter==NULL || CTFSensorInter->GetError()!=U_OK)
            {
                delete CTFSensorInter; CTFSensorInter = NULL;
                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Creating CTF sensor interpolation system. \n");
            }
        }
        delete GridCTF;
    }
}

UMEEGDataFIFF::UMEEGDataFIFF(const UMEEGDataFIFF& Data) :
    UMEEGDataBase((UMEEGDataBase) Data)
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataFIFF& UMEEGDataFIFF::operator=(const UMEEGDataFIFF &Data)
{
    if(this==NULL)
    {
        static UMEEGDataFIFF D; D.error = U_ERROR;
        return D;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Argument has NULL address. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Copying base class. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return *this;
    }

    DeleteAllMembers(U_OK);

    Nitem                    = Data.Nitem;
    FileIdentifier.timesec   = Data.FileIdentifier.timesec   ;
    FileIdentifier.timefrac  = Data.FileIdentifier.timefrac  ;
    FileIdentifier.machid[0] = Data.FileIdentifier.machid[0] ;
    FileIdentifier.machid[1] = Data.FileIdentifier.machid[1] ;
    FileIdentifier.version   = Data.FileIdentifier.version   ;

    Comments                 = Data.Comments;
    NBadChan                 = Data.NBadChan;
    RawDatType               = Data.RawDatType;
    RawDatSize               = Data.RawDatSize;
    NtrialSkip               = Data.NtrialSkip;

    if(Data.ItemDir)
    {
        ItemDir = new FIFF_DIRENTRY[Nitem];
        if(ItemDir==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (Nitem=%d) \n", Nitem);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int it=0; it<Nitem; it++)
        {
            ItemDir[it].kind  = Data.ItemDir[it].kind ;
            ItemDir[it].type  = Data.ItemDir[it].type ;
            ItemDir[it].size  = Data.ItemDir[it].size ;
            ItemDir[it].pos   = Data.ItemDir[it].pos  ;
            ItemDir[it].Level = Data.ItemDir[it].Level;
        }
    }
    if(Data.TrialItem)
    {
        TrialItem = new int[Nitem];
        if(TrialItem==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (Nitem=%d). \n", Nitem);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int it=0; it<Nitem; it++) TrialItem[it] = Data.TrialItem[it];
    }
    if(Data.BadChanIndex)
    {
        BadChanIndex = new int[NBadChan];
        if(BadChanIndex==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (NBadChan=%d). \n", NBadChan);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int i=0; i<NBadChan; i++) BadChanIndex[i] = Data.BadChanIndex[i];
    }
    if(Data.ChanIndex)
    {
        ChanIndex = new int[MAXCHAN];
        if(ChanIndex==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (MAXCHAN=%d). \n", MAXCHAN);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int i=0; i<MAXCHAN; i++) ChanIndex[i] = Data.ChanIndex[i];
    }
    if(Data.TrChan)
    {
        TrChan = new int[NTrigChan];
        if(TrChan==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (NTrigChan=%d). \n", NTrigChan);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        for(int i=0; i<NTrigChan; i++) TrChan[i] = Data.TrChan[i];
    }

    Dev2Head           = Data.Dev2Head;
    Nasion             = Data.Nasion;
    Left               = Data.Left;
    Right              = Data.Right;
    NPolPoint          = Data.NPolPoint;
    if(Data.PolhemusPoints)
    {
        PolhemusPoints = new UVector3[Data.NPolPoint];
        if(PolhemusPoints==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Memory allocation (NPolPoint=%d). \n", NPolPoint);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        NPolPointAlloc  = Data.NPolPoint;
        for(int k=0; k<NPolPoint; k++) PolhemusPoints[k] = Data.PolhemusPoints[k];
    }
    if(Data.Scan)
    {
        Scan = new UScan(*Data.Scan);
        if(Scan==NULL || Scan->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::operator=(). Copying Scan data-member. \n");
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    return *this;
}

UEuler UMEEGDataFIFF::GetDewar2NLR(void) const
{
    if(this==NULL || error!=U_OK) return UEuler();
    if(Nasion==UVector3() || Left==UVector3() || Right==UVector3()) return UEuler();
    UEuler ToNLR(Nasion, Left, Right);
    return ToNLR * Dev2Head;
}

int UMEEGDataFIFF::GetItemNextBlock(int StartItem, int BlockType, FILE* fpIn) const
{
    if(this==NULL    || error!=U_OK) return -1;
    if(ItemDir==NULL || Nitem<=0   ) return -1;

    if(StartItem<0 || StartItem>=Nitem)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetItemNextBlock(). StartItem =%d out of range, (Nitem=%d). \n", StartItem, Nitem);
        return -1;
    }
    FILE* fpLoc = fpIn;
    if(fpLoc==NULL)
    {
        fpLoc = fopen(DataFileName, "rb", false);
        if(fpLoc==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::GetItemNextBlock(). Cannot open file : %s \n",(const char*)DataFileName);
            return -1;
        }
    }

    int BlockItem = -1;
    for(int n=StartItem; n<Nitem;n++)
    {
        if(ItemDir[n].kind!=FIFF_BLOCK_START) continue;
        fseek(fpLoc, ItemDir[n].pos+16, SEEK_SET);
        if(BlockType==ReadBinaryInt(IntelData, fpLoc))
        {
            BlockItem = n;
            break;
        }
    }
    if(fpIn==NULL) fclose(fpLoc);
    if(BlockItem<0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetItemNextBlock(). Block not found : %s \n",GetBlockText(BlockType));
        return -1;
    }
    return BlockItem;
}

ErrorType UMEEGDataFIFF::PrintDirectory(UFileName F) const
{
    if(this==NULL    || error!=U_OK) return U_ERROR;
    if(ItemDir==NULL || Nitem<=0   ) return U_ERROR;

    FILE* fpOut = fopen(F, "wt", false);
    if(fpOut==NULL) return U_ERROR;

    FILE* fpIn = fopen(DataFileName, "rb", false);
    if(fpIn==NULL)
    {
        fclose(fpOut);
        return U_ERROR;
    }

    int NMAG  = 0;
    int NGRA  = 0;

    fprintf(fpOut, "Level\tkind \ttype \tsize \tpos \t(Block)Type\n");
    for(int n=0; n<Nitem; n++)
    {
        fprintf(fpOut, "%d \t%d \t%d \t%d \t%d \t", ItemDir[n].Level, ItemDir[n].kind, ItemDir[n].type, ItemDir[n].size, ItemDir[n].pos);
        switch(ItemDir[n].kind)
        {
        case FIFF_DATA_SKIP:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int Dskip =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", Dskip);
            }   break;
        case FIFF_BLOCK_START:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int BlockType =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%s ", GetBlockText(BlockType));
            }   break;
        case FIFF_DIG_POINT:
            {
                FIFF_DIGPOINT P = ReadDigPoint(fpIn, ItemDir[n].pos+16);

                fprintf(fpOut, "%d\t ",P.kind  );
                fprintf(fpOut, "%d\t ",P.runnum);
                fprintf(fpOut, "%f\t ",P.r[0]  );
                fprintf(fpOut, "%f\t ",P.r[1]  );
                fprintf(fpOut, "%f\t ",P.r[2]  );
            }   break;
        case FIFF_CH_INFO:
            {
                FIFF_CHANINFO ChI = ReadChanInfo(fpIn, ItemDir[n].pos+16);
                fprintf(fpOut, "%d\t ",ChI.scanNo   );
                fprintf(fpOut, "%d\t ",ChI.logNo    );
                fprintf(fpOut, "%d\t ",ChI.kind     );
                fprintf(fpOut, "%f\t ",ChI.range    );
                fprintf(fpOut, "%g\t ",ChI.cal      );
                fprintf(fpOut, "%d\t ",ChI.coil_type);
                fprintf(fpOut, "%f\t ",ChI.r0[0]    );
                fprintf(fpOut, "%f\t ",ChI.r0[1]    );
                fprintf(fpOut, "%f\t ",ChI.r0[2]    );
                fprintf(fpOut, "%f\t ",ChI.ex[0]    );
                fprintf(fpOut, "%f\t ",ChI.ex[1]    );
                fprintf(fpOut, "%f\t ",ChI.ex[2]    );
                fprintf(fpOut, "%f\t ",ChI.ey[0]    );
                fprintf(fpOut, "%f\t ",ChI.ey[1]    );
                fprintf(fpOut, "%f\t ",ChI.ey[2]    );
                fprintf(fpOut, "%f\t ",ChI.ez[0]    );
                fprintf(fpOut, "%f\t ",ChI.ez[1]    );
                fprintf(fpOut, "%f\t ",ChI.ez[2]    );
                fprintf(fpOut, "%d\t ",ChI.unit     );
                fprintf(fpOut, "%d\t ",ChI.unit_mul );
                fprintf(fpOut, "%s\t ",ChI.name     );
                if(ChI.coil_type==FIFFCOIL_GRAD) NGRA++;
                if(ChI.coil_type==FIFFCOIL_MAG ) NMAG++;
            }   break;
        case FIFF_HPI_NCOIL:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int Ncoil =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", Ncoil);
            }   break;
        case FIFF_NCHAN:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int Nchan =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", Nchan);
            }   break;
        case FIFF_NAVE:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int Nav =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", Nav);
            }   break;
        case FIFF_SFREQ:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fsamp =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f ", fsamp);
            }   break;
        case FIFF_FIRST_SAMPLE:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int samp =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", samp);
            }   break;
        case FIFF_LAST_SAMPLE:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int samp =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", samp);
            }   break;
        case FIFF_DATA_PACK:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int DatPack =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d ", DatPack);
            }   break;
        case FIFF_MEAS_DATE:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                long Date1       =  ReadBinaryInt(IntelData, fpIn);
                struct tm *ltime = localtime((const time_t*)&Date1);
                UDateTime    D(1900+ltime->tm_year, ltime->tm_mon, ltime->tm_mday, ltime->tm_hour, ltime->tm_min, ltime->tm_sec);
                fprintf(fpOut, "%s", D.GetProperties("",true, true));
            }   break;
        case FIFF_SUBJECT:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                char subject[100];
                memset(subject, 0, sizeof(subject));
                int nbytes = MIN(sizeof(subject), ItemDir[n].size)-1;
                fread(subject, nbytes, 1, fpIn);
                fprintf(fpOut, "%s ", subject);
            }   break;
        case FIFF_DESCRIPTION:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                char Comment[100];
                memset(Comment, 0, sizeof(Comment));
                int nbytes = MIN(sizeof(Comment), ItemDir[n].size)-1;
                fread(Comment, nbytes, 1, fpIn);
                UString C(Comment); C.ReplaceBlankSpace(false);
                fprintf(fpOut, "%s ", (const char*)C);
            }   break;

        case  FIFF_MRI_SOURCE_PATH:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                char Path[100];
                memset(Path, 0, sizeof(Path));
                int nbytes = MIN(sizeof(Path), ItemDir[n].size)-1;
                fread(Path, nbytes, 1, fpIn);
                fprintf(fpOut, "%s ", Path);
            }   break;
        case  FIFF_MRI_SOURCE_FORMAT:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // Source format ", dum);
            }   break;
        case  FIFF_MRI_PIXEL_ENCODING:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // Pixel encoding ", dum);
            }   break;
        case  FIFF_MRI_PIXEL_DATA_OFFSET:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // Data offset in orig file ", dum);
            }   break;
        case  FIFF_MRI_PIXEL_DATA:
            {
                fprintf(fpOut, "\t // Pixel data ");
            }   break;
        case  FIFF_MRI_PIXEL_OVERLAY_ENCODING:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // Pixel overlay encoding ", dum);
            }   break;
        case  FIFF_MRI_PIXEL_OVERLAY_DATA:
            {
                fprintf(fpOut, "\t // Pixel data overlay");
            }   break;
        case  FIFF_MRI_WIDTH:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // MRI width in pixels ", dum);
            }   break;
        case  FIFF_MRI_WIDTH_M:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // MRI width in meter ", fdum);
            }   break;
        case  FIFF_MRI_HEIGHT:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // MRI height in pixels ", dum);
            }   break;
        case  FIFF_MRI_HEIGHT_M:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // MRI height in meter ", fdum);
            }   break;
        case  FIFF_MRI_DEPTH:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // MRI depth in pixels ", dum);
            }   break;
        case  FIFF_MRI_DEPTH_M:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // MRI depth in meter ", fdum);
            }   break;
        case  FIFF_MRI_THICKNESS:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // MRI slice thickness in meter ", fdum);
            }   break;
        case  FIFF_MRI_ORIG_SOURCE_PATH:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                char Path[100];
                memset(Path, 0, sizeof(Path));
                int nbytes = MIN(sizeof(Path), ItemDir[n].size)-1;
                fread(Path, nbytes, 1, fpIn);
                fprintf(fpOut, "%s // Orig", Path);
            }   break;
        case  2018:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // 2018 ", fdum);
            }   break;
        case  2019:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // 2019 ", fdum);
            }   break;
        case  2024:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                float fdum =  ReadBinaryFloat(IntelData, fpIn);
                fprintf(fpOut, "%f \t // 2024 ", fdum);
            }   break;
        case  FIFF_CH_UNIT:
            {
                fseek(fpIn, ItemDir[n].pos+16, SEEK_SET);
                int dum =  ReadBinaryInt(IntelData, fpIn);
                fprintf(fpOut, "%d \t // Unit ", dum);
            }   break;
        }
        fprintf(fpOut, "\n");
    }

    fclose(fpIn);
    fclose(fpOut);

    CI.AddToLog("NMAG = %d \n",NMAG);
    CI.AddToLog("NGRA = %d \n",NGRA);

    return U_OK;
}

UGrid* UMEEGDataFIFF::GetCTFGrid(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Object NULL or not properly set.\n");
        return NULL;
    }

    UGridFit GRCTF(UGrid::U_GRD_MEG);
    UGrid    GRFIF;
    for(int i=0; i<GridAll->GetNpoints(); i++)
    {
        USensor S(GridAll->GetSensor(i));
        if(S.GetStype()!=USensor::U_SEN_MAG && S.GetStype()!=USensor::U_SEN_GRAD) continue;
        GRFIF.AddSensor(S);
    }
    if(GRCTF.GetError()!=U_OK || GRFIF.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Creating CTF or FIFF -sensor grid .\n");
        return NULL;
    }
    int NPF = GRFIF.GetNpoints();
    int NPC = GRCTF.GetNpoints();
    if(NPF<5 || NPC<5)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Too few or no MEG sensors present (NP=%d). \n", NPF);
        return NULL;
    }

    int* FIFInd = new int[MAX(LABTABSIZE,NPC)];
    int* IndCTF = new int[NPC                ];
    if(FIFInd==NULL || IndCTF==NULL)
    {
        delete[] FIFInd; delete[] IndCTF;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Memory allocation (LABTABSIZE=%d, NPC=%d). \n", LABTABSIZE, NPC);
        return NULL;
    }

    size_t NByte   = strlen(CTFLab[0][0]);
    int    NMatchF = 0;
    for(int im=0; im<LABTABSIZE; im++) FIFInd[im]=-1;
    for(int im=0; im<LABTABSIZE; im++)
    {
        for(int i=0; i<NPF; i++)
        {
            const char* Name     = GRFIF.GetName(i);
            if(Name==NULL) continue;

            if(strncmp(CTFLab[im][0],Name,NByte)) continue;
            FIFInd[im] = i;
            NMatchF++;
            break;
        }
    }
        NByte   = strlen(CTFLab[0][1]);
    int NMatchC = 0;
    for(int i=0; i<NPC; i++) IndCTF[i]=-1;
    for(int i=0; i<NPC; i++)
    {
        const char* Name = GRCTF.GetName(i);
        if(Name==NULL) continue;
        for(int im=0; im<LABTABSIZE; im++)
        {
            if(strncmp(CTFLab[im][1], Name, NByte)) continue;
            IndCTF[i] = im;
            NMatchC++;
            break;
        }
    }
    if(NMatchF<5 || NMatchC<5)
    {
        delete[] FIFInd; delete[] IndCTF;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Too few matching sensors (NMatchFIF =%d, NMatchCTF=%d). \n", NMatchF,NMatchC);
        return NULL;
    }
    for(int i=0; i<NPC; i++)
    {
        if(IndCTF[i]>=0) FIFInd[i] = FIFInd[IndCTF[i]];
        else             FIFInd[i] = -1;
    }
    double   Residual  = -1;
    ULinTran CTFtoFIFF = GRCTF.FitGridLinTran(&GRFIF, FIFInd, &Residual);
    delete[] FIFInd;
    delete[] IndCTF;
    if(Residual<0.)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Fitting CTF default grid to actotal FIFF sensors.\n");
        return NULL;
    }
    UGrid* CTFGrid = new UGrid(GRCTF);
    if(CTFGrid==NULL || CTFGrid->GetError()!=U_OK)
    {
        delete CTFGrid;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetCTFGrid(). Copying end result.\n");
        return NULL;
    }
    CTFGrid->Transform(CTFtoFIFF);
    return CTFGrid;
}

ErrorType UMEEGDataFIFF::ReadDirectory(UFileName Fiff)
{
    Nitem   = 0;
    delete[] ItemDir;
    ItemDir = NULL;


    FILE* fp = fopen(Fiff, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). File cannot be opened: %s \n",(const char*)Fiff);
        return U_ERROR;
    }
    FIFF_TAGDATA fid;
    fid.kind =                ReadBinaryInt(IntelData, fp);
    fid.type = (FIFF_DataType)ReadBinaryInt(IntelData, fp);
    fid.size =                ReadBinaryInt(IntelData, fp);
    fid.next =                ReadBinaryInt(IntelData, fp);
    if(fid.kind !=   FIFF_FILE_ID  ||
       fid.type != U_FIFF_ID_STRUCT||
       fid.size != 20)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). File of wrong type:  %s \n",(const char*)Fiff);
        return U_ERROR;
    }

    FileIdentifier.version        = ReadBinaryInt (IntelData, fp);
    FileIdentifier.machid[0]      = ReadBinaryInt (IntelData, fp);
    FileIdentifier.machid[1]      = ReadBinaryInt (IntelData, fp);
    FileIdentifier.timesec        = ReadBinaryInt (IntelData, fp);
    FileIdentifier.timefrac       = ReadBinaryInt (IntelData, fp);

    FIFF_TAGDATA dir;
    dir.kind                      = ReadBinaryInt (IntelData, fp);
    dir.type   = (FIFF_DataType)    ReadBinaryInt (IntelData, fp);
    dir.size                      = ReadBinaryInt (IntelData, fp);
    dir.next                      = ReadBinaryInt (IntelData, fp);
      int DirectoryPointer = ReadBinaryInt(IntelData, fp);

    FIFF_TAGDATA freel;
    freel.kind                    = ReadBinaryInt (IntelData, fp);
    freel.type = (FIFF_DataType)    ReadBinaryInt (IntelData, fp);
    freel.size                    = ReadBinaryInt (IntelData, fp);
    freel.next                    = ReadBinaryInt (IntelData, fp);
      int FreeLPointer     = ReadBinaryInt(IntelData, fp);

    if(dir.kind!=FIFF_DIR_POINTER || freel.kind!=FIFF_FREE_LIST)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). File of wrong type. No dir pointer or freelist. \n");
        return U_ERROR;
    }
    unsigned int DataPointer = ftell(fp);
    unsigned int FileSize    = GetFileSize(fp);
    if(DirectoryPointer>0 && DirectoryPointer>=(int)FileSize)
    {
        CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Directory pointer beyond end of file. \n");
        DirectoryPointer = -1;
    }
    if(DirectoryPointer>0)
    {
        fseek(fp, DirectoryPointer, SEEK_SET);

        FIFF_DIRENTRY ent;

        ent.kind =                ReadBinaryInt(IntelData, fp);
        ent.type = (FIFF_DataType)ReadBinaryInt(IntelData, fp);
        ent.size =                ReadBinaryInt(IntelData, fp);
        ent.pos  =                ReadBinaryInt(IntelData, fp);
        Nitem    = ent.size/16;

        if(Nitem>0 && Nitem<=500000) ItemDir = new FIFF_DIRENTRY[Nitem];
        if(ItemDir==NULL)
        {
            CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Reading directory structure. Nitem = %d. Try reading directly. \n", Nitem);
            fseek(fp, DataPointer, SEEK_SET);
            DirectoryPointer = -1;
        }
        else
        {
            for(int n=0; n<Nitem; n++)
            {
                ItemDir[n].kind  =                ReadBinaryInt(IntelData, fp);
                ItemDir[n].type  = (FIFF_DataType)ReadBinaryInt(IntelData, fp);
                ItemDir[n].size  =                ReadBinaryInt(IntelData, fp);
                ItemDir[n].pos   =                ReadBinaryInt(IntelData, fp);
                ItemDir[n].Level = -1;
            }
        }
    }
    if(DirectoryPointer<0)
    {
        Nitem = 0;
        while(1)
        {
            FIFF_TAGDATA tag;
            tag.kind   =                ReadBinaryInt(IntelData, fp);
            tag.type   = (FIFF_DataType)ReadBinaryInt(IntelData, fp);
            tag.size   =                ReadBinaryInt(IntelData, fp);
            tag.next   =                ReadBinaryInt(IntelData, fp);
            if(tag.kind<0 || tag.type<0 || tag.size<=0 || (tag.next<0 && tag.next!=FIFF_NEXT_NONE))
            {
                UString Tag = UString(tag.kind, "Kind = %d; ") + UString(tag.type, "Type = %d; ") +
                              UString(tag.size, "Size = %d; ") + UString(tag.next, "Next = %d; ");
                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Invalid tag (item = %d) %s. \n", Nitem, (const char*)Tag);
                break;
            }

            int er     = 1;
            if(tag.next==FIFF_NEXT_NONE)     break;
            else if(tag.next==FIFF_NEXT_SEQ) er = fseek(fp, tag.size, SEEK_CUR);
            else                             er = fseek(fp, tag.next, SEEK_SET);

            if(er!=0)
            {
                fclose(fp);
                CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Reading tag directory at item = %d .\n",Nitem);
                return U_ERROR;
            }
            Nitem++;
        }
        if(Nitem>0) ItemDir = new FIFF_DIRENTRY[Nitem];
        if(ItemDir==NULL)
        {
            fclose(fp);
            CI.AddToLog("ERROR: UMEEGDataFIFF::UMEEGDataFIFF(). Memory allocation Nitem = %d (nodir)\n", Nitem);
            return U_ERROR;
        }
        fseek(fp, DataPointer, SEEK_SET);
        for(int n=0; n<Nitem; n++)
        {
            int pos    = ftell(fp);
            FIFF_TAGDATA tag;
            tag.kind   =                ReadBinaryInt(IntelData, fp);
            tag.type   = (FIFF_DataType)ReadBinaryInt(IntelData, fp);
            tag.size   =                ReadBinaryInt(IntelData, fp);
            tag.next   =                ReadBinaryInt(IntelData, fp);

            if(tag.kind<0 || tag.type<0 || tag.size<=0 || (tag.next<0 && tag.next!=FIFF_NEXT_NONE)) break;
            if(tag.next==FIFF_NEXT_NONE)     break;
            else if(tag.next==FIFF_NEXT_SEQ) fseek(fp, tag.size, SEEK_CUR);
            else                             fseek(fp, tag.next, SEEK_SET);

            ItemDir[n].kind  = tag.kind;
            ItemDir[n].type  = tag.type;
            ItemDir[n].size  = tag.size;
            ItemDir[n].pos   = pos;
            ItemDir[n].Level = -1;
        }
    }

// Set levels and test blocks
    int Lev   = 0;
    int Btype[MAXLEVEL]; for(int k=0; k<MAXLEVEL; k++) Btype[k] = -1;
    int Etype[MAXLEVEL]; for(int k=0; k<MAXLEVEL; k++) Etype[k] = -2;

    for(int n=0; n<Nitem; n++)
    {
        if(ItemDir[n].kind==FIFF_BLOCK_END  )
        {
            Lev--;
            if(Lev<0)
            {
                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Level (%d) out of range; (Item=%d)  \n", Lev, n);
                Lev = 0;
            }
            fseek(fp, ItemDir[n].pos+16, SEEK_SET);
            Etype[Lev] =  ReadBinaryInt(IntelData, fp);
            if(Etype[Lev]!=Btype[Lev])
                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). BlockBeginType (%d) != BlockEndType (%d); (Item=%d)  \n", Btype[Lev], Etype[Lev], n);
        }
        ItemDir[n].Level = Lev;
        if(ItemDir[n].kind==FIFF_BLOCK_START)
        {
            fseek(fp, ItemDir[n].pos+16, SEEK_SET);
            Btype[Lev] =  ReadBinaryInt(IntelData, fp);
            Lev++;
            if(Lev>=MAXLEVEL)
            {
                CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). Level (%d) out of range; (Item=%d)  \n", Lev, n);
                Lev = MAXLEVEL-1;
            }
        }
    }
    if(Lev!=0)
        CI.AddToLog("WARNING: UMEEGDataFIFF::UMEEGDataFIFF(). #BlockBegin != #BlockEnd (Lev=%d) .\n", Lev);
    fclose(fp);

    return U_OK;
}

void UFiffEvents::SetAllMembersDefault(void)
{
    error  = U_OK;
    Nev    = NULL;
    Events = NULL;
}
void UFiffEvents::DeleteAllMembers(ErrorType E)
{
    delete[] Events;
    error = E;
}

UFiffEvents::UFiffEvents()
{
    SetAllMembersDefault();
}
UFiffEvents::UFiffEvents(int Nevents)
{
    SetAllMembersDefault();
    if(Nevents<0)
    {
        CI.AddToLog("ERROR: UFiffEvents::UFiffEvents(). Invalid argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    Nev    = Nevents;
    Events = new EVENT_DESC[Nev];
    if(Events==NULL)
    {
        CI.AddToLog("ERROR: UFiffEvents::UFiffEvents(). Memory allocation. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int iev=0; iev<Nev; iev++)
    {
        Events[iev].when   = 0;
        Events[iev].before = 0;
        Events[iev].now    = 0;
    }
}
UFiffEvents::~UFiffEvents()
{
    DeleteAllMembers(U_OK);
}

ErrorType UFiffEvents::SetEvent(int iev, int sam, int bef, int now)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(iev<0 || iev>=Nev)
    {
        CI.AddToLog("ERROR: UFiffEvents::SetEvents(). argument out of range (iev=%d) \n", iev);
        return U_ERROR;
    }
    Events[iev].when   = sam;
    Events[iev].before = bef;
    Events[iev].now    = now;
    return U_OK;
}
UMarkerArray* UFiffEvents::GetMarkerArray(int NsampTrial, int NtrialSkip, double Srate) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Nev<=0 || Events==NULL)    return NULL;

    if(NsampTrial<=0 || Srate<=0) return NULL;

    UMarkerArray* MarkAr = new UMarkerArray(0, NsampTrial, 0, Srate);
    if(MarkAr==NULL || MarkAr->GetError()!=U_OK)
    {
        delete   MarkAr;
        CI.AddToLog("ERROR: UFiffEvents::GetMarkerArray(). Creation of empty UMarkerArray()-object. \n");
        return NULL;
    }

    int IMarker[MAXTRANS][MAXTRANS];
    for(int i1=0; i1<MAXTRANS; i1++)
        for(int i2=0; i2<MAXTRANS; i2++) IMarker[i1][i2] = -1;

    int NMarker = 0;
    for(int iev=0; iev<Nev; iev++)
    {
        int   i1 = int(floor(0.5+log(double(Events[iev].before))/log(2.)));
        int   i2 = int(floor(0.5+log(double(Events[iev].now   ))/log(2.)));
        if(i1<0 || i1>=MAXTRANS ||
           i2<0 || i2>=MAXTRANS) continue;

        if(IMarker[i1][i2]>=0)   continue;
        IMarker[i1][i2] = NMarker;
        NMarker++;
    }
    if(NMarker<=0)
    {
        delete   MarkAr;
        CI.AddToLog("ERROR: UFiffEvents::GetMarkerArray(). No selectable events .\n");
        return NULL;
    }

    for(int im=0; im<NMarker; im++)
    {
        UString Name;
        for(int i1=0; i1<MAXTRANS; i1++)
            for(int i2=0; i2<MAXTRANS; i2++)
            {
                if(IMarker[i1][i2]!=im) continue;
                Name = UString(i1,"Trig_%d") + UString(i2,"_%d");
                break;
            }

        UMarker Mark(Name, 0, NsampTrial, 1, "FiFF Trigger", 0, false);
        MarkAr->AddMarker(&Mark);
    }

    for(int iev=0; iev<Nev; iev++)
    {
        int   i1 = int(floor(0.5+log(double(Events[iev].before))/log(2.)));
        int   i2 = int(floor(0.5+log(double(Events[iev].now   ))/log(2.)));
        if(i1<0 || i1>=MAXTRANS ||
           i2<0 || i2>=MAXTRANS) continue;

        int   samp = Events[iev].when-NtrialSkip*NsampTrial;
        UEvent   E = UEvent( samp/NsampTrial, samp%NsampTrial);

        MarkAr->AddEvent(IMarker[i1][i2],E);
    }
    return MarkAr;
}

ErrorType UMEEGDataFIFF::AddPolPoint(UVector3 X)
{
    if(NPolPoint>NPolPointAlloc-1) // Allocate new memory for points
    {
        int NewAlloc = 2*NPolPointAlloc+10;
        if(NewAlloc<100)   NewAlloc = 100;
        if(NewAlloc>10000) NewAlloc = NPolPointAlloc+10000;
        UVector3*   plistNew = new UVector3[NewAlloc];
        if(plistNew==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::AddPolPoint(). Memory allocation. NPolPointAlloc = %d, NewAlloc = %d  .\n", NPolPointAlloc, NewAlloc);
            return U_ERROR;
        }
        for(int n=0; n<NPolPoint; n++) plistNew[n] = PolhemusPoints[n];
        delete[] PolhemusPoints; PolhemusPoints    = plistNew;
        NPolPointAlloc = NewAlloc;
    }

    PolhemusPoints[NPolPoint] = X;
    NPolPoint++;

    return U_OK;
}

ErrorType UMEEGDataFIFF::GetIsoTrackData(FILE* fp)
{
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetIsoTrackData(). Invalid argumen(s). \n");
        return U_ERROR;
    }
    int ISOBlock = GetItemNextBlock(0, FIFFB_ISOTRAK, fp);

    if(ISOBlock<=0) return U_ERROR;

    for(int n = ISOBlock; n<Nitem; n++)
    {
        if(ItemDir[n].kind!=FIFF_DIG_POINT   &&
           ItemDir[n].kind!=FIFF_DIG_STRING) continue;

        fseek(fp, ItemDir[n].pos+16, SEEK_SET);
        int kind =  ReadBinaryInt(IntelData, fp);
        int runn =  ReadBinaryInt(IntelData, fp);
        if(ItemDir[n].kind==FIFF_DIG_STRING)
        {
            int Np   =  ReadBinaryInt(IntelData, fp);
            if(Np<=0) continue;
            NPolPoint = Np;
            for(int k=0; k<Np; k++)
            {
                double x = 100.*ReadBinaryFloat(IntelData, fp);
                double y = 100.*ReadBinaryFloat(IntelData, fp);
                double z = 100.*ReadBinaryFloat(IntelData, fp);
                AddPolPoint(UVector3(x, y, z));
            }
        }
        else
        {
            double x = 100.*ReadBinaryFloat(IntelData, fp);
            double y = 100.*ReadBinaryFloat(IntelData, fp);
            double z = 100.*ReadBinaryFloat(IntelData, fp);
            AddPolPoint(UVector3(x, y, z));
        }
    }
    return U_OK;
}
ErrorType UMEEGDataFIFF::GetScanData(FILE* fp)
{
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Invalid argumen(s). \n");
        return U_ERROR;
    }
    int MRIBlock = GetItemNextBlock(0, FIFFB_MRI_SET, fp);

    if(MRIBlock<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Scan block not found. \n");
        return U_ERROR;
    }
    int NSlice = 0;
    int Nx     = 0;  double Dx = 0;
    int Ny     = 0;  double Dy = 0;   
    FIFF_PixelEncodingType  PE = U_FIFF_MRI_PIXEL_UNKNOWN;
    FIFF_COORDTRANS_T TransB;
    FIFF_COORDTRANS_T TransE;
    for(int n = MRIBlock; n<Nitem; n++)
    {
        if(ItemDir[n].kind==FIFF_BLOCK_START)
        {
            fseek(fp, ItemDir[n].pos+16, SEEK_SET);
            if(FIFFB_MRI_SLICE!=ReadBinaryInt(IntelData, fp)) continue;

            n++;
            int Lev    = ItemDir[n].Level;
            int Nxx    = 0;  double Dxx  = 0; 
            int Nyy    = 0;  double Dyy  = 0;
            FIFF_PixelEncodingType  PEE  = U_FIFF_MRI_PIXEL_UNKNOWN;
            int                     PEEi = -1;
            int doffset= -1;
            FIFF_COORDTRANS_T Trans;
            char DirName[1000]; memset(DirName, 0, sizeof(DirName));
            while(n<Nitem && ItemDir[n].Level==Lev)
            {
                fseek(fp, ItemDir[n].pos+16, SEEK_SET);
                switch(ItemDir[n].kind)
                {
                case FIFF_MRI_WIDTH_M       : Dxx     = ReadBinaryFloat(IntelData, fp); break;
                case FIFF_MRI_HEIGHT_M      : Dyy     = ReadBinaryFloat(IntelData, fp); break;
                case FIFF_MRI_WIDTH         : Nxx     = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_HEIGHT        : Nyy     = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_PIXEL_ENCODING: PEEi    = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_PIXEL_DATA    : doffset = ItemDir[n].pos                ; break;
                case FIFF_COORD_TRANS       : Trans   = ReadCoordTrans(fp, ItemDir[n].pos+16); break;
                case FIFF_MRI_SOURCE_PATH   :
                    {
                        int nbytes = MIN(sizeof(DirName), ItemDir[n].size)-1;
                        fread(DirName, nbytes, 1, fp);
                    }
                }
                n++;
            }
            if(Nxx==0 || Nyy==0 || Dxx==0. || Dyy==0. || doffset<0) 
            {
                if(doffset<0 && DirName[0])
                    CI.AddToLog("Note: UMEEGDataFIFF::GetScanData(). Fiff file refers to directory: %s \n", DirName);                    
                CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Invalid slice parameters (slice = %d). \n", NSlice);
                return U_ERROR;
            }
            switch(PEEi)
            {
            case  0: PEE =  U_FIFF_MRI_PIXEL_UNKNOWN;            break;
            case  1: PEE =  U_FIFF_MRI_PIXEL_BYTE;               break;
            case  2: PEE =  U_FIFF_MRI_PIXEL_WORD;               break;              
            case  3: PEE =  U_FIFF_MRI_PIXEL_SWAP_WORD;          break;         
            case  4: PEE =  U_FIFF_MRI_PIXEL_FLOAT;              break;             
            case  5: PEE =  U_FIFF_MRI_PIXEL_BYTE_INDEXED_COLOR; break;
            case  6: PEE =  U_FIFF_MRI_PIXEL_BYTE_RGB_COLOR;     break;
            case  7: PEE =  U_FIFF_MRI_PIXEL_BYTE_RLE_RGB_COLOR; break;
            case  8: PEE =  U_FIFF_MRI_PIXEL_BIT_RLE;            break;
            case  9: PEE =  U_FIFF_MRI_PIXEL_SIGNED_WORD;        break;
            case 10: PEE =  U_FIFF_MRI_PIXEL_SIGNED_SWAP_WORD;   break;
            default: PEE =  U_FIFF_MRI_PIXEL_UNKNOWN;
            }
            if(NSlice==0)
            {
                Nx=Nxx; Dx=Dxx; Ny=Nyy; Dy=Dyy; PE=PEE;
                TransB = TransE = Trans;
            }
            else if(Nx==Nxx && Dx==Dxx && Ny==Nyy && Dy==Dyy && PE==PEE)
            {
                TransE = Trans;
            }
            else
            {
                CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Incontiguous slice parameters (slice = %d). \n", NSlice);
                return U_ERROR;
            }
            NSlice++;
        }
    }
    if(PE==U_FIFF_MRI_PIXEL_UNKNOWN)
    {
        CI.AddToLog("WARNING: UMEEGDataFIFF::GetScanData(). Invalid or unspecified pixel encoding (PE=%d). Assume bytes. \n",int(PE));
        PE = U_FIFF_MRI_PIXEL_BYTE;
    }
    if(Nx<=0 || Ny<=0 || Dx==0. || Dy==0. || NSlice<=0 || PE<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). No valid slices found. \n");
        return U_ERROR;
    }
    UField::DataType DT   = UField::U_BYTE;
    int              VL   = -1;
    int              Size =  0;
    bool             Swap = false;
    switch(PE)
    {
    case  U_FIFF_MRI_PIXEL_UNKNOWN             :                       VL = -1;                        break;
    case  U_FIFF_MRI_PIXEL_BYTE                : DT = UField::U_BYTE ; VL =  1;              Size = 1; break;
    case  U_FIFF_MRI_PIXEL_WORD                : DT = UField::U_SHORT; VL =  1;              Size = 2; break;
    case  U_FIFF_MRI_PIXEL_SWAP_WORD           : DT = UField::U_SHORT; VL =  1; Swap = true; Size = 2; break;
    case  U_FIFF_MRI_PIXEL_FLOAT               : DT = UField::U_FLOAT; VL =  1;              Size = 4; break;
    case  U_FIFF_MRI_PIXEL_BYTE_INDEXED_COLOR  :                       VL = -1;                        break;
    case  U_FIFF_MRI_PIXEL_BYTE_RGB_COLOR      : DT = UField::U_BYTE ; VL =  3;              Size = 3; break;
    case  U_FIFF_MRI_PIXEL_BYTE_RLE_RGB_COLOR  : DT = UField::U_BYTE ; VL = -1;                        break;
    case  U_FIFF_MRI_PIXEL_BIT_RLE             : DT = UField::U_BYTE ; VL = -1;                        break;
    case  U_FIFF_MRI_PIXEL_SIGNED_WORD         : DT = UField::U_SHORT; VL =  1;              Size = 2; break;
    case  U_FIFF_MRI_PIXEL_SIGNED_SWAP_WORD    : DT = UField::U_SHORT; VL =  1; Swap = true; Size = 2; break;
    default                                    :                       VL = -1;
    }
    if(VL<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Pixel encoding not supported, PE = %d .\n",PE);
        return U_ERROR;
    }
    double Dz = 0;
    if(NSlice<=1) 
    {
        Dz = 1;
    }
    else
    {
        double T0 = fabs(TransB.move[0]-TransE.move[0]);
        double T1 = fabs(TransB.move[1]-TransE.move[1]);
        double T2 = fabs(TransB.move[2]-TransE.move[2]);
                        
        Dz = MAX(MAX(T0,T1),T2);
    }
    int      dims[3]    = {Nx, Ny, NSlice};
    UVector3 Min        = UVector3();
    UVector3 Max        = 100*UVector3(Dx*(Nx-1.)/Nx, Dy*(Ny-1.)/Ny, Dz);
    delete Scan;
    Scan = new UScan(Min, Max, dims, DT, VL);
    if(Scan==NULL || Scan->GetError()!=U_OK)
    {
        delete Scan; Scan = NULL;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetScanData(). Creating UScan object . \n");
        return U_ERROR;
    }
    if(DT==UField::U_FLOAT || DT==UField::U_DOUBLE) Scan->SetModality(U_MOD_MEG);
    else                                            Scan->SetModality(U_MOD_MR );
    
    int islice =0;
    for(int n = MRIBlock; n<Nitem; n++)
    {
        if(ItemDir[n].kind==FIFF_COMMENT)
        {
            fseek(fp, ItemDir[n].pos+16, SEEK_SET);
            char Comment[200];
            memset(Comment, 0, sizeof(Comment));
            int nbytes = MIN(sizeof(Comment), ItemDir[n].size)-1;
            fread(Comment, nbytes, 1, fp);
            UString C(Comment); C.ReplaceBlankSpace(true);
            Scan->AddFileComments(C);
        }
        if(ItemDir[n].kind==FIFF_BLOCK_START)
        {
            fseek(fp, ItemDir[n].pos+16, SEEK_SET);
            if(FIFFB_MRI_SLICE!=ReadBinaryInt(IntelData, fp)) continue;

            n++;
            int Lev    = ItemDir[n].Level;
            int Nzz    = 0; double Dzz = 0;
            int Nxx    = 0; double Dxx = 0; int PEE = -1;
            int doffset= -1;
            while(ItemDir[n].Level==Lev)
            {
                fseek(fp, ItemDir[n].pos+16, SEEK_SET);
                switch(ItemDir[n].kind)
                {
                case FIFF_MRI_WIDTH_M       : Dxx     = ReadBinaryFloat(IntelData, fp); break;
                case FIFF_MRI_HEIGHT_M      : Dzz     = ReadBinaryFloat(IntelData, fp); break;
                case FIFF_MRI_WIDTH         : Nxx     = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_HEIGHT        : Nzz     = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_PIXEL_ENCODING: PEE     = ReadBinaryInt  (IntelData, fp); break;
                case FIFF_MRI_PIXEL_DATA    : doffset = ItemDir[n].pos                ; break;
                }
                n++;
            }

            int       NpointsSlice = Nx*Ny*VL;
            int       soffset      = islice*NpointsSlice;
            ErrorType E            = U_ERROR;
            fseek(fp, doffset+16, SEEK_SET);
            switch(DT)
            {
            case UField::U_BYTE   : E=ReadBinaryUCharArray (Scan->GetBdata()+soffset, NpointsSlice, IntelData, fp); break;
            case UField::U_SHORT  : E=ReadBinaryShortArray (Scan->GetSdata()+soffset, NpointsSlice, IntelData, fp); break;
            case UField::U_INTEGER: E=ReadBinaryIntArray   (Scan->GetIdata()+soffset, NpointsSlice, IntelData, fp); break;
            case UField::U_FLOAT  : E=ReadBinaryFloatArray (Scan->GetFdata()+soffset, NpointsSlice, IntelData, fp); break;
            case UField::U_DOUBLE : E=ReadBinaryDoubleArray(Scan->GetDdata()+soffset, NpointsSlice, IntelData, fp); break;
            }
            islice++;
        }
    }
    UVector3 Xt(TransB.rotmat[0][0], TransB.rotmat[1][0], TransB.rotmat[2][0]);
    UVector3 Yt(TransB.rotmat[0][1], TransB.rotmat[1][1], TransB.rotmat[2][1]);
    UVector3 Zt(TransB.rotmat[0][2], TransB.rotmat[1][2], TransB.rotmat[2][2]);

    if(TransB.kindFrom!=FIFFV_COORD_MRI_SLICE || TransB.kindTo!=FIFFV_COORD_MRI)
    {
        CI.AddToLog("WARNING: UMEEGDataFIFF::GetScanData(). Unsupported slice transformation (from%d to %d) .\n", TransB.kindFrom, TransB.kindTo);
    }
    if( (Xt-UVector3( 0.,-1, 0.)).GetNorm()<1.e-5 &&  // -y ???
        (Yt-UVector3( 0., 0, 1.)).GetNorm()<1.e-5 &&  //  z ???
        (Zt-UVector3(-1., 0, 0.)).GetNorm()<1.e-5 )   // -x ???
    {
/* Rotate scan according to TransB.rotmat[][] */
        Scan->SwapDirections(0,1);
        Scan->SwapDirections(1,2);
        Scan->MirrorCoordinates(0);
        Scan->MirrorCoordinates(2);

/* Shift scan according to TransB.move[] */
        Scan->ShiftCoords(UVector3(TransB.move));

/* Extra */     
        Scan->ReverseData(0,false);
        Scan->SetOrientation(U_ORI_SAGITAL);
    }
    else if( (Xt-UVector3( 1.,  0., 0.)).GetNorm()<1.e-5 &&  //  x ???
             (Yt-UVector3( 0.,  0., 1.)).GetNorm()<1.e-5 &&  //  z ???
             (Zt-UVector3( 0., -1., 0.)).GetNorm()<1.e-5 )   // -y ???
    {
/* Rotate scan according to TransB.rotmat[][] */
        Scan->SwapDirections(2,0);
        Scan->MirrorCoordinates(2);

/* Shift scan according to TransB.move[] */
        Scan->ShiftCoords(UVector3(TransB.move));

/* Extra */     
        Scan->ReverseData(2,false);
        Scan->SetOrientation(U_ORI_AXIAL);
    }
    else
    {
        CI.AddToLog("WARNING: UMEEGDataFIFF::GetScanData(). Scan orientation not implemented. \n");
        Scan->SetOrientation(U_ORI_AXIAL);
    }
    UFileName F = UFileName(DataFileName.GetBaseName()); F.ReplaceExtension(NULL);
    Scan->SetScanName((const char*)F);
    Scan->SetOrigFileName(DataFileName);
    return U_OK;
}

int* UMEEGDataFIFF::ReadFiffTrigChans(FILE* fp, int *NTrigChan) const
{
    if(fp==0 || NTrigChan==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::ReadFiffTrigChans(). Invalid argumen(s). \n");
        return NULL;
    }
    int EventBlock = GetItemNextBlock(0, FIFFB_EVENTS, fp);

    *NTrigChan = 0;
    if(EventBlock<=0) return NULL;


    int* TC = NULL;
    for(int n = EventBlock; n<Nitem; n++)
    {
        if(ItemDir[n].kind!=FIFF_EVENT_CHANNELS) continue;

        int NTC = ItemDir[n].size/4;
        if(NTC<=0) return NULL;

        TC      = new int[NTC];
        if(TC==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::ReadFiffTrigChans(). Memory allocation, NTC = %d. \n", NTC);
            return NULL;
        }
        fseek(fp, ItemDir[n].pos+16, SEEK_SET);
        for(int ic=0; ic<NTC; ic++) TC[ic] = ReadBinaryInt(IntelData, fp)-1;
        *NTrigChan = NTC;

        return TC;
    }
    return NULL;
}

UMarkerArray* UMEEGDataFIFF::GetChannelMarkers(void)
{
    if(NTrigChan<=0 || TrChan==0) return NULL;

    if(GridAll==NULL) return NULL;
    for(int ic=0; ic<NTrigChan; ic++)
    {
        int ichan = TrChan[ic];
        if(ichan<0 || ichan>=GridAll->GetNpoints())
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::GetChannelMarkers(). Channel out of range (ic=%d).\n", ic);
            return NULL;
        }
    }

    UMarkerArray* M = new UMarkerArray(0, nsamp, 0, srate);
    if(M==NULL || M->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetChannelMarkers(). Creating UMarkerArray. \n");
        return NULL;
    }

    for(int ic=0; ic<NTrigChan; ic++)
    {
        const char* ChName = GridAll->GetName(TrChan[ic]);
        if(ChName==NULL)
        {
            delete M;
            CI.AddToLog("ERROR: UMEEGDataFIFF::GetChannelMarkers(). Channel not found (ic=%d).\n", ic);
            return NULL;
        }
        UMarker Mark[MAXTRANS];
        for(int k=0;k<MAXTRANS; k++)
        {
            UString Name = UString(ChName) + UString(k+1,"_%d");
            Mark[k] = UMarker((const char*)Name, 0, nsamp, 255+k*60000, "Fiff channel marker", 0, true);
        }
        for(int it=0; it<ntrial; it++)
        {
            double* Dat = GetChannel_d(UEvent(it,0), UEvent(it,nsamp-1), ChName);
            if(Dat==NULL)
            {
                delete M;
                CI.AddToLog("ERROR: UMEEGDataFIFF::GetChannelMarkers(). Reading channel %d, trial %d .\n", ic, it);
                return NULL;
            }
            for(int j=0; j<nsamp; j++)
            {
                if(j==0 && Dat[0]==0)                   continue;
                if(j >0 && !(Dat[j-1]==0 && Dat[j]>=1)) continue;

                int ibit = int( floor(0.5+log(Dat[j])/log(2.)) );
                if(ibit<0 || ibit>16)                   continue;
                Mark[ibit].AddEvent(UEvent(it, j));
            }
            delete[] Dat;
        }
        for(int k=0;k<MAXTRANS; k++)
        {
            if(Mark[k].GetnEvents()<=0) continue;
            M->AddMarker(Mark+k);
        }
    }
    return M;
}

UFiffEvents* UMEEGDataFIFF::ReadFiffEvents(FILE* fp) const
{
    if(fp==0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::ReadFiffEvents(). Invalid argumen(s). \n");
        return NULL;
    }
    int EventBlock = GetItemNextBlock(0, FIFFB_EVENTS, fp);
    if(EventBlock<=0) return NULL;


    UFiffEvents* FE = NULL;
    for(int n = EventBlock; n<Nitem; n++)
    {
        if(ItemDir[n].kind!=FIFF_EVENT_LIST) continue;

        int Nev = MAX(0, ItemDir[n].size/(3*4));
        FE      = new UFiffEvents(Nev);
        if(FE==NULL || FE->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataFIFF::ReadFiffEvents(). Memory allocation, Nev = %d. \n", Nev);
            delete FE;
            return NULL;
        }
        fseek(fp, ItemDir[n].pos+16, SEEK_SET);
        for(int iev=0; iev<Nev; iev++)
        {
            int sam = ReadBinaryInt(IntelData, fp);
            int bef = ReadBinaryInt(IntelData, fp);
            int now = ReadBinaryInt(IntelData, fp);
            FE->SetEvent(iev, sam,bef, now);
        }
        return FE;
    }
    return NULL;
}

bool UMEEGDataFIFF::ReadNLR(FILE* fp, UVector3* Nas, UVector3* Lef, UVector3* Rig) const
{
    if(fp==0 || Nas==NULL || Lef==NULL || Rig==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::ReadNLR(). Invalid argumen(s). \n");
        return false;
    }
    int ISOtrack = GetItemNextBlock(0, FIFFB_ISOTRAK, fp);
    if(ISOtrack<=0) return false;

    *Nas = UVector3();
    *Lef = UVector3();
    *Rig = UVector3();
    for(int n = ISOtrack; n<Nitem; n++)
    {
        if(ItemDir[n].kind!=FIFF_DIG_POINT) continue;

        fseek(fp, ItemDir[n].pos+16, SEEK_SET);
        int   kind  =      ReadBinaryInt  (IntelData, fp);
        int   ident =      ReadBinaryInt  (IntelData, fp);
        if(kind!=FIFFV_POINT_CARDINAL) continue;
        float x     = float(100.)*ReadBinaryFloat(IntelData, fp);;
        float y     = float(100.)*ReadBinaryFloat(IntelData, fp);;
        float z     = float(100.)*ReadBinaryFloat(IntelData, fp);;
        switch(ident)
        {
        case FIFFV_POINT_NASION: *Nas=UVector3(x,y,z); break;
        case FIFFV_POINT_LPA:    *Lef=UVector3(x,y,z); break;
        case FIFFV_POINT_RPA:    *Rig=UVector3(x,y,z); break;
        }
    }
    if(*Nas==UVector3() || *Lef==UVector3() || *Rig==UVector3()) return false;
    return true;
}

bool UMEEGDataFIFF::ReadDevToHead(FILE* fp, int offset, UEuler* Dev2Head) const
{
    if(fp==0 || offset<=0 || Dev2Head==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::ReadDevToHead(). Invalid argumen(s). \n");
        return false;
    }
    fseek(fp, offset, SEEK_SET);
    int From  =  ReadBinaryInt  (IntelData, fp);
    int To    =  ReadBinaryInt  (IntelData, fp);
    if(From!=FIFFV_COORD_DEVICE || To!=FIFFV_COORD_HEAD) return false;

    float Rot[9], Mov[3];
    for(int k=0; k<9; k++) Rot[k] =             ReadBinaryFloat(IntelData, fp);
    for(int k=0; k<3; k++) Mov[k] = float(100.)*ReadBinaryFloat(IntelData, fp);

    Dev2Head->SetRotMatrix(Rot);
    Dev2Head->SetShift    (Mov);

    return true;
}

FIFF_CHANINFO UMEEGDataFIFF::ReadChanInfo(FILE* fp, int offset) const
{
    FIFF_CHANINFO ChI;
    ChI.scanNo      = -1;     // position of channel in  scanning order
    ChI.logNo       = -1;     // unique logical scanning number
    ChI.kind        = -1;     // kind of channel (MEG, EEG, EOG)
    ChI.range       =  0;     // scaling from integer to physical value
    ChI.cal         =  0;     // calibration
    ChI.coil_type   = -1;     //
    ChI.r0[0]       =  0;     // coil coordinate system origin (EEG: electrode position)
    ChI.r0[1]       =  0;     // coil coordinate system origin (EEG: electrode position)
    ChI.r0[2]       =  0;     // coil coordinate system origin (EEG: electrode position)
    ChI.ex[0]       =  0;     // x-direction (EEG: position reference, (0.,0.,0.) -> no reference)
    ChI.ex[1]       =  0;     // x-direction (EEG: position reference, (0.,0.,0.) -> no reference)
    ChI.ex[2]       =  0;     // x-direction (EEG: position reference, (0.,0.,0.) -> no reference)
    ChI.ey[0]       =  0;     // y-direction (EEG: ignored)
    ChI.ey[1]       =  0;     // y-direction (EEG: ignored)
    ChI.ey[2]       =  0;     // y-direction (EEG: ignored)
    ChI.ez[0]       =  0;     // z-direction (EEG: ignored)
    ChI.ez[1]       =  0;     // z-direction (EEG: ignored)
    ChI.ez[2]       =  0;     // z-direction (EEG: ignored)
    ChI.unit        =  0;
    ChI.unit_mul    =  0;
    memset(ChI.name, 0, sizeof(ChI.name));

    if(fp==0 || offset<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::ReadChanInfo(). Invalid argumen(s). \n");
        return ChI;
    }
    fseek(fp, offset, SEEK_SET);
    ChI.scanNo      = ReadBinaryInt  (IntelData, fp);
    ChI.logNo       = ReadBinaryInt  (IntelData, fp);
    ChI.kind        = ReadBinaryInt  (IntelData, fp);
    ChI.range       = ReadBinaryFloat(IntelData, fp);
    ChI.cal         = ReadBinaryFloat(IntelData, fp);
    ChI.coil_type   = ReadBinaryInt  (IntelData, fp);
    ChI.r0[0]       = ReadBinaryFloat(IntelData, fp);
    ChI.r0[1]       = ReadBinaryFloat(IntelData, fp);
    ChI.r0[2]       = ReadBinaryFloat(IntelData, fp);
    ChI.ex[0]       = ReadBinaryFloat(IntelData, fp);
    ChI.ex[1]       = ReadBinaryFloat(IntelData, fp);
    ChI.ex[2]       = ReadBinaryFloat(IntelData, fp);
    ChI.ey[0]       = ReadBinaryFloat(IntelData, fp);
    ChI.ey[1]       = ReadBinaryFloat(IntelData, fp);
    ChI.ey[2]       = ReadBinaryFloat(IntelData, fp);
    ChI.ez[0]       = ReadBinaryFloat(IntelData, fp);
    ChI.ez[1]       = ReadBinaryFloat(IntelData, fp);
    ChI.ez[2]       = ReadBinaryFloat(IntelData, fp);
    ChI.unit        = ReadBinaryInt  (IntelData, fp);
    ChI.unit_mul    = ReadBinaryInt  (IntelData, fp);
    fread(ChI.name, sizeof(ChI.name)-1,1,fp);
    return ChI;
}
FIFF_DIGPOINT UMEEGDataFIFF::ReadDigPoint(FILE* fp, int offset) const
{
    FIFF_DIGPOINT P;
    P.kind   = FIFFV_COORD_UNKNOWN;
    P.runnum = -1;
    P.r[0]   =  0;
    P.r[1]   =  0;
    P.r[2]   =  0;
    if(fp==0 || offset<=0)
    {
        return P;
    }
    fseek(fp, offset, SEEK_SET);
    P.kind      = GetFIFF_CoordType(ReadBinaryInt  (IntelData, fp));
    P.runnum    = ReadBinaryInt  (IntelData, fp);
    P.r[0]      = ReadBinaryFloat(IntelData, fp);
    P.r[1]      = ReadBinaryFloat(IntelData, fp);
    P.r[2]      = ReadBinaryFloat(IntelData, fp);
    return P;
}
FIFF_COORDTRANS_T UMEEGDataFIFF::ReadCoordTrans(FILE* fp, int offset) const
{
    FIFF_COORDTRANS_T T;

    T.kindFrom = FIFFV_COORD_UNKNOWN;
    T.kindTo   = FIFFV_COORD_UNKNOWN;
    for(int k1=0; k1<3; k1++)
    {
        T.move[k1]    = 0.F;
        T.invmove[k1] = 0.F;
        for(int k2=0; k2<3; k2++) T.rotmat[k1][k2] = T.invrot[k1][k2] = 0.F;
        T.rotmat[k1][k1] = T.invrot[k1][k1] = 1.F;
    }
    if(fp==0 || offset<=0) return T;

    fseek(fp, offset, SEEK_SET);
    T.kindFrom  = GetFIFF_CoordType(ReadBinaryInt  (IntelData, fp));
    T.kindTo    = GetFIFF_CoordType(ReadBinaryInt  (IntelData, fp));

    for(int k1=0; k1<3; k1++) for(int k2=0; k2<3; k2++) T.rotmat [k1][k2] = ReadBinaryFloat(IntelData, fp);
    for(int k1=0; k1<3; k1++)                           T.move   [k1]     = ReadBinaryFloat(IntelData, fp);
    for(int k1=0; k1<3; k1++) for(int k2=0; k2<3; k2++) T.invrot [k1][k2] = ReadBinaryFloat(IntelData, fp);
    for(int k1=0; k1<3; k1++)                           T.invmove[k1]     = ReadBinaryFloat(IntelData, fp);

    return T;
}

const UString& UMEEGDataFIFF::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataFIFF-object\n");
        return Properties;
    }
    int MaxLev = 0;
    int NBlock = 0;
    if(ItemDir)
    {
        for(int it=0; it<Nitem; it++)
        {
            if(ItemDir[it].Level >          MaxLev) MaxLev = ItemDir[it].Level;
            if(ItemDir[it].kind ==FIFF_BLOCK_START) NBlock++;
        }
    }

    Properties = UString();
    char line[100]; sprintf(line,     "%04x%04x", FileIdentifier.machid[0], FileIdentifier.machid[1]);
    Properties += UString(line  ,     "MachineID          =  %s \n");
    Properties += UString(Nitem ,     "Nitem              =  %d \n");
    Properties += UString(NBlock,     "NBlock             =  %d \n");
    Properties += UString(MaxLev,     "MaxLev             =  %d \n");
    Properties += UString(NtrialSkip, "NtrialSkip         =  %d \n");
    Properties += UString(NPolPoint,  "NPolPoint          =  %d \n");
    Properties += UString(Nasion.GetProperties(),  "Nasion             =  %s \n");
    Properties += UString(Left  .GetProperties(),  "Left               =  %s \n");
    Properties += UString(Right .GetProperties(),  "Right              =  %s \n");

    Properties += Comments + UString("\n\nBaseClass: \n");
    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');
    else                                        Properties.InsertAtEachLine(Comment);

    return Properties;
}

UVector3* UMEEGDataFIFF::GetPolhemusPoints(int* Npoints, bool* NLRincluded) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetPolhemusPoints(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(PolhemusPoints==NULL && NPolPoint!=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetPolhemusPoints(). Object not properly set. \n");
        return NULL;
    }
    if(Npoints==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetPolhemusPoints(). Invalid NULL argument. \n");
        return NULL;
    }
    bool NLR    =  (Nasion!=UVector3() && Left!=UVector3() && Right!=UVector3());
    int  Np     =  NPolPoint;
    if(NLR) Np += 3;
    if(Np==0)
    {
        if(NLRincluded) *NLRincluded = false;
        return NULL;
    }
    UVector3* p = new UVector3[Np];
    if(p==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetPolhemusPoints(). Memory allocation. Np = %d .\n", Np);
        return NULL;
    }
    *Npoints     = Np;
    UVector3* pp = p;
    if(NLR)
    {
        pp[0] = Nasion;
        pp[1] = Left  ;
        pp[2] = Right ;
        pp    = p+3;
    }
    for(int k=0; k<NPolPoint; k++) pp[k] = PolhemusPoints[k];
    if(NLRincluded) *NLRincluded = NLR;

    return p;
}

double* UMEEGDataFIFF::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
{
    if(this==NULL || error!=U_OK || ItemDir==NULL || TrialItem==NULL || RawDatSize<=0 || ChanIndex==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d(). Object NULL or erroneously set. \n");
        return NULL;
    }
    if(RawDatType!=U_FIFF_SHORT        &&
       RawDatType!=U_FIFF_INT          &&
       RawDatType!=U_FIFF_FLOAT        &&
       RawDatType!=U_FIFF_DAU_PACK16)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d(). Raw data type not supported (%d). \n", RawDatType);
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d(). Arguments out of range\n");
        return NULL;
    }
    if(Begin.trial < 0 || End.trial   < 0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d(). Arguments out of range (Begin.trial=%d, End.trial=%d)\n", Begin.trial, End.trial);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d() : Requested type not present in file (%s). \n", GetDataTypeText(Dtype));
        return NULL;
    }

    double  *data   = new double [NSamples*nKAN                  ];
    char    *buffer = new char   [   nsamp*NchannelRaw*RawDatSize];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }
    short* Sbuf = (short*)buffer;
    int*   Ibuf = (int*  )buffer;
    float* Fbuf = (float*)buffer;

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int nSamplesDone = 0;
    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        if(itrial<ntrial)
        {
            int offset = ItemDir[TrialItem[itrial]].pos+16;
            fseek(fp, offset, SEEK_SET);
            fread(buffer, nsamp*NchannelRaw, RawDatSize, fp);

            switch(RawDatType)
            {
            case U_FIFF_SHORT:
            case U_FIFF_DAU_PACK16:
                SwapArray(Sbuf, nsamp*NchannelRaw, IntelData);
                break;
            case U_FIFF_INT:
                SwapArray(Ibuf, nsamp*NchannelRaw, IntelData);
                break;
            case U_FIFF_FLOAT:
                SwapArray(Fbuf, nsamp*NchannelRaw, IntelData);
                break;
            }
        }
        else
            for(int ij=0; ij<nsamp*NchannelRaw*RawDatSize; ij++) buffer[ij] = 0;

        int    nSampSkip  = 0;
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

        int    nTake      = nsamp;
        if(itrial==Begin.trial && itrial==End.trial)
        {
            nTake = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nTake = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nTake = End.sample+1;
        }

        for(int i=0, ichan=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type       !=Dtype) continue;
            if(ChIn[i].SkipChannel==true ) continue;

            int iraw = ChanIndex[i];

            switch(RawDatType)
            {
            case U_FIFF_SHORT:
            case U_FIFF_DAU_PACK16:
                for(int j=0; j<nTake; j++)
                    data[ichan*NSamples+nSamplesDone+j] = ChIn[i].InGain * Sbuf[(j+nSampSkip)*NchannelRaw+iraw];
                break;
            case U_FIFF_INT:
                for(int j=0; j<nTake; j++)
                    data[ichan*NSamples+nSamplesDone+j] = ChIn[i].InGain * Ibuf[(j+nSampSkip)*NchannelRaw+iraw];
                break;
            case U_FIFF_FLOAT:
                for(int j=0; j<nTake; j++)
                    data[ichan*NSamples+nSamplesDone+j] = ChIn[i].InGain * Fbuf[(j+nSampSkip)*NchannelRaw+iraw];
                break;
            }
            ichan++;
        }
        nSamplesDone += nTake;
    }
    delete[] buffer;
    fclose(fp);
    return data;
}

double* UMEEGDataFIFF::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(this==NULL || error!=U_OK || ItemDir==NULL || TrialItem==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataFIFF::Channel_d(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp)
    {
        CI.AddToLog("ERROR UMEEGDataFIFF::Channel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0)
    {
        CI.AddToLog("ERROR UMEEGDataFIFF::Channel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

/* Select the correct channel index. */
    if(Label==NULL || *Label==0)
    {
        CI.AddToLog("WARNING UMEEGDataFIFF::GetChannel_d() : NULL or empty label argument.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0;i<NchannelRaw; i++)
        if(!strcmp(Label,ChIn[i].namChannel))
        {
            ichan = i;
            break;
        }
    if(ichan==-1)
    {
        CI.AddToLog("WARNING UMEEGDataFIFF::GetChannel_d() : required label %s not present.\n",Label);
        return NULL; // Label[] not present.
    }


    double  *data   = new double [NSamples                       ];
    char    *buffer = new char   [   nsamp*NchannelRaw*RawDatSize];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR: UMEEGDataFIFF::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }
    short* Sbuf = (short*)buffer;
    int*   Ibuf = (int*  )buffer;
    float* Fbuf = (float*)buffer;

    FILE *fp = fopen(DataFileName,"rb", false);
    if(!fp)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataFIFF::GetChannel_d() : Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int nSamplesDone = 0;
    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        if(itrial<ntrial)
        {
            int offset = ItemDir[TrialItem[itrial]].pos+16;
            fseek(fp, offset, SEEK_SET);
            fread(buffer, nsamp*NchannelRaw, RawDatSize, fp);

            switch(RawDatType)
            {
            case U_FIFF_SHORT:
            case U_FIFF_DAU_PACK16:
                SwapArray(Sbuf, nsamp*NchannelRaw, IntelData);
                break;
            case U_FIFF_INT:
                SwapArray(Ibuf, nsamp*NchannelRaw, IntelData);
                break;
            case U_FIFF_FLOAT:
                SwapArray(Fbuf, nsamp*NchannelRaw, IntelData);
                break;
            }
        }
        else
            for(int ij=0; ij<nsamp*NchannelRaw*RawDatSize; ij++) buffer[ij] = 0;

        int    nSampSkip  = 0;
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

        int    nTake      = nsamp;
        if(itrial==Begin.trial && itrial==End.trial)
        {
            nTake = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nTake = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nTake = End.sample+1;
        }

        int iraw = ChanIndex[ichan];

        switch(RawDatType)
        {
        case U_FIFF_SHORT:
        case U_FIFF_DAU_PACK16:
            for(int j=0; j<nTake; j++)
                data[nSamplesDone+j] = ChIn[ichan].InGain * Sbuf[(j+nSampSkip)*NchannelRaw+iraw];
            break;
        case U_FIFF_INT:
            for(int j=0; j<nTake; j++)
                data[nSamplesDone+j] = ChIn[ichan].InGain * Ibuf[(j+nSampSkip)*NchannelRaw+iraw];
            break;
        case U_FIFF_FLOAT:
            for(int j=0; j<nTake; j++)
                data[nSamplesDone+j] = ChIn[ichan].InGain * Fbuf[(j+nSampSkip)*NchannelRaw+iraw];
            break;
        }
        nSamplesDone += nTake;
    }
    delete[] buffer;
    fclose(fp);
    return data;
}

/*********
megresponse responses = fiff_load_evoked (filename, fiff_select, &comment);
---

and then transform the coil descriptions (dest_frame = FIFFV_COORD_HEAD):
---
void fiddle_locations (megResponse responses, int dest_frame)
{
    megResponse this;

    for(this = responses; this != NULL; this = this->next)
    {
        if(this->kind == FIFFV_MEG_CH && this->trans != NULL)
        {
            if(this->coord_frame != dest_frame)
            {
                if(dest_frame == this->trans->to           &&
                   this->coord_frame == this->trans->from)
                {
                    fiff_coord_trans(this->chPos.r0,this->trans,FIFFV_MOVE);
                    fiff_coord_trans(this->chPos.ex,this->trans,FIFFV_NO_MOVE);
                    fiff_coord_trans(this->chPos.ey,this->trans,FIFFV_NO_MOVE);
                    fiff_coord_trans(this->chPos.ez,this->trans,FIFFV_NO_MOVE);
                    this->coord_frame = this->trans->to;
                }
                else if(dest_frame == this->trans->from     &&
                        this->coord_frame == this->trans->to)
                {
                    fiff_coord_trans_inv(this->chPos.r0,this->trans,FIFFV_MOVE);
                    fiff_coord_trans_inv(this->chPos.ex,this->trans,FIFFV_NO_MOVE);
                    fiff_coord_trans_inv(this->chPos.ey,this->trans,FIFFV_NO_MOVE);
                    fiff_coord_trans_inv(this->chPos.ez,this->trans,FIFFV_NO_MOVE);
                    this->coord_frame = this->trans->from;
                }
            }
        }
   }
   return;
}
---

Thereafter, compose the coil points.

***********/

/****************
#
#   MEG coil definition file
#
#       Copyright 2005 - 2006
#
#       Matti Hamalainen
#       Athinoula A. Martinos Center for Biomedical Imaging
#       Charlestown, MA, USA
#
#
#   <class> <id> <accuracy> <np> <size> <baseline> "<description>"
#
# struct class id accuracy num_points size baseline description # format '%d %d %d %d %e %e %s'
#
#   <w_1> <x_1/m> <y_1/m> <z_1/m> <nx_1> <ny_1> <nz_1>
#
# struct w     x       y       z       nx     ny     nz
# format '%f %e %e %e %e %e %e'
#
#   ....
#
#   <w_np> <x_np/m> <y_np/m> <z_np/m> <nx_np> <ny_np> <nz_np>
#
#   <class>     1   magnetometer
#           2   axial gradiometer
#           3   planar gradiometer
#           4   axial second-order gradiometer
#
#   <accuracy>  0       point approximation
#                       1   normal
#           2   accurate
#
#       Produced with:
#
#   mne_list_coil_def version 1.9 compiled at May  7 2007 22:32:01
#

#   <class> <id> <accuracy> <np> <size> <baseline> "<description>"
***********/



const FIFF_MEGGRID UMEEGDataFIFF::FiffGrid[3*MEGGRID] =
{
{3,  2,      0,  2, 2.789e-02, 1.620e-02,"Neuromag-122 planar gradiometer size = 27.89  mm base = 16.20  mm",
                              {{   61.7284,  8.100e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -61.7284, -8.100e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  2,      1,  2, 2.789e-02, 1.620e-02,"Neuromag-122 planar gradiometer size = 27.89  mm base = 16.20  mm",
                              {{   61.7284,  8.100e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -61.7284, -8.100e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  2,      2,  8, 2.789e-02, 1.620e-02,"Neuromag-122 planar gradiometer size = 27.89  mm base = 16.20  mm",
                              {{   15.1057,  1.111e-02,  7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {   15.1057,  5.440e-03,  7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {   15.1057,  5.440e-03, -7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {   15.1057,  1.111e-02, -7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -15.1057, -1.111e-02,  7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -15.1057, -5.440e-03,  7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -15.1057, -5.440e-03, -7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {  -15.1057, -1.111e-02, -7.680e-03,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  2000,   0,  1, 0.000e+00, 0.000e+00,"Point magnetometer",
                              {{   1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  2000,   1,  1, 0.000e+00, 0.000e+00,"Point magnetometer",
                              {{   1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  2000,   2,  1, 0.000e+00, 0.000e+00,"Point magnetometer",
                              {{   1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3012,   0,  2, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T1 size = 26.39  mm base = 16.80  mm",
                              {{   59.5238,  8.400e-03,  0.000e+00,  3.000e-04,  0.000,  0.000,  1.000},
                               {  -59.5238, -8.400e-03,  0.000e+00,  3.000e-04,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3012,   1,  4, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T1 size = 26.39  mm base = 16.80  mm",
                              {{  29.7619,   8.400e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {  29.7619,   8.400e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -29.7619,  -8.400e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -29.7619,  -8.400e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3012,   2,  8, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T1 size = 26.39  mm base = 16.80  mm",
                              {{  14.9858,   1.079e-02,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {  14.9858,   5.891e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {  14.9858,   5.891e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {  14.9858,   1.079e-02, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -14.9858,  -1.079e-02,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -14.9858,  -5.891e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -14.9858,  -5.891e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               { -14.9858,  -1.079e-02, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3013,   0,  2, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T2 size = 26.39  mm base = 16.80  mm",
                              {{  59.5238,   8.400e-03,  0.000e+00,  3.000e-04,  0.000,  0.000,  1.000},
                               { -59.5238,  -8.400e-03,  0.000e+00,  3.000e-04,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                               {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3013,   1,  4, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T2 size = 26.39  mm base = 16.80  mm",
                               {{ 29.7619,   8.400e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                { 29.7619,   8.400e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-29.7619,  -8.400e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-29.7619,  -8.400e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{3,  3013,   2,  8, 2.639e-02, 1.680e-02,"Vectorview planar gradiometer T2 size = 26.39  mm base = 16.80  mm",
                               {{ 14.9858,   1.079e-02,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                { 14.9858,   5.891e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                { 14.9858,   5.891e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                { 14.9858,   1.079e-02, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-14.9858,  -1.079e-02,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-14.9858,  -5.891e-03,  6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-14.9858,  -5.891e-03, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {-14.9858,  -1.079e-02, -6.713e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3022,   0,  1, 2.580e-02, 0.000e+00,"Vectorview magnetometer T1 size = 25.80  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3022,   1,  4, 2.580e-02, 0.000e+00,"Vectorview magnetometer T1 size = 25.80  mm",
                               {{  0.2500,  -6.450e-03, -6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,  -6.450e-03,  6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   6.450e-03, -6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   6.450e-03,  6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3022,   2, 16, 2.580e-02, 0.000e+00,"Vectorview magnetometer T1 size = 25.80  mm",
                               {{    0.0625, -9.675e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000}}},
{1,  3023,   0,  1, 2.580e-02, 0.000e+00,"Vectorview magnetometer T2 size = 25.80  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3023,   1,  4, 2.580e-02, 0.000e+00,"Vectorview magnetometer T2 size = 25.80  mm",
                               {{  0.2500,  -6.450e-03, -6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,  -6.450e-03,  6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   6.450e-03, -6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   6.450e-03,  6.450e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3023,   2, 16, 2.580e-02, 0.000e+00,"Vectorview magnetometer T2 size = 25.80  mm",
                               {{    0.0625, -9.675e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -9.675e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625, -3.225e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  3.225e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03, -9.675e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03, -3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03,  3.225e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {    0.0625,  9.675e-03,  9.675e-03,  3.000e-04,  0.000,  0.000,  1.000}}},
{1,  3024,   0,  1, 2.100e-02, 0.000e+00,"Vectorview magnetometer T3 size = 21.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3024,   1,  4, 2.100e-02, 0.000e+00,"Vectorview magnetometer T3 size = 21.00  mm",
                               {{  0.2500,  -5.250e-03, -5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,  -5.250e-03,  5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   5.250e-03, -5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   5.250e-03,  5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  3024,   2,  4, 2.100e-02, 0.000e+00,"Vectorview magnetometer T3 size = 21.00  mm",
                               {{  0.2500,  -5.250e-03, -5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,  -5.250e-03,  5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   5.250e-03, -5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.2500,   5.250e-03,  5.250e-03,  3.000e-04,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  4001,   0,  1, 2.300e-02, 0.000e+00,"Magnes WH2500 magnetometer size = 23.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  4001,   1,  4, 2.300e-02, 0.000e+00,"Magnes WH2500 magnetometer size = 23.00  mm",
                               {{  0.2500,   5.750e-03,  5.750e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -5.750e-03,  5.750e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -5.750e-03, -5.750e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   5.750e-03, -5.750e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  4001,   2,  7, 2.300e-02, 0.000e+00,"Magnes WH2500 magnetometer size = 23.00  mm",
                               {{  0.2500,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,   9.390e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,  -9.390e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,   4.695e-03,  8.132e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,   4.695e-03, -8.132e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,  -4.695e-03,  8.132e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.1250,  -4.695e-03, -8.132e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4002,   0,  2, 1.800e-02, 5.000e-02,"Magnes WH3600 gradiometer size = 18.00  mm base = 50.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,   0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4002,   1,  8, 1.800e-02, 5.000e-02,"Magnes WH3600 gradiometer size = 18.00  mm base = 50.00  mm",
                               {{  0.2500,   4.500e-03,  4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.500e-03,  4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.500e-03, -4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   4.500e-03, -4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500,   4.500e-03,  4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500,  -4.500e-03,  4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500,  -4.500e-03, -4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500,   4.500e-03, -4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4002,   2, 14, 1.800e-02, 5.000e-02,"Magnes WH3600 gradiometer size = 18.00  mm base = 50.00  mm",
                               {{   0.2500,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  7.348e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -7.348e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  3.674e-03,  6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  3.674e-03, -6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -3.674e-03,  6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -3.674e-03, -6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500,  0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  7.348e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -7.348e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  3.674e-03,  6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  3.674e-03, -6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -3.674e-03,  6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -3.674e-03, -6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000, 1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000, 1.000}}},
{1,  4003,   0,  1, 3.000e-02, 0.000e+00,"Magnes reference magnetometer size = 30.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  4003,   1,  4, 3.000e-02, 0.000e+00,"Magnes reference magnetometer size = 30.00  mm",
                               {{  0.2500,   7.500e-03,  7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -7.500e-03,  7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -7.500e-03, -7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   7.500e-03, -7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  4003,   2,  4, 3.000e-02, 0.000e+00,"Magnes reference magnetometer size = 30.00  mm",
                               {{  0.2500,   7.500e-03,  7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -7.500e-03,  7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -7.500e-03, -7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   7.500e-03, -7.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4004,   0,  2,  8.000e-02, 1.350e-01,"Magnes reference gradiometer (diag) size = 80.00  mm base = 135.00 mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,   0.000e+00,  0.000e+00,  1.350e-01,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4004,   1,  8, 8.000e-02, 1.350e-01,"Magnes reference gradiometer (diag) size = 80.00  mm base = 135.00 mm",
                               {{   0.2500,  2.000e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -2.000e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -2.000e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  2.000e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500,  2.000e-02,  2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500, -2.000e-02,  2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500, -2.000e-02, -2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500,  2.000e-02, -2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4004,   2,  8, 8.000e-02, 1.350e-01,"Magnes reference gradiometer (diag) size = 80.00  mm base = 135.00 mm",
                               {{   0.2500,  2.000e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -2.000e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -2.000e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  2.000e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500,  2.000e-02,  2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500, -2.000e-02,  2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500, -2.000e-02, -2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {  -0.2500,  2.000e-02, -2.000e-02,  1.350e-01,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4005,   0,  2, 8.000e-02, 1.350e-01,"Magnes reference gradiometer (offdiag) size = 80.00  mm base = 135.00 mm",
                               {{  1.0000,   6.750e-02,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,  -6.750e-02,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4005,   1,  8, 8.000e-02, 1.350e-01,"Magnes reference gradiometer (offdiag) size = 80.00  mm base = 135.00 mm",
                               {{   0.2500,  8.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  4.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  4.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  8.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -8.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -8.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  4005,   2,  8, 8.000e-02, 1.350e-01,"Magnes reference gradiometer (offdiag) size = 80.00  mm base = 135.00 mm",
                               {{   0.2500,  8.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  4.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  4.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  8.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -8.750e-02,  2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -8.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.750e-02, -2.000e-02,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5001,   0,  2, 1.800e-02, 5.000e-02,"CTF axial gradiometer size = 18.00  mm base = 50.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,   0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5001,   1,  8, 1.800e-02, 5.000e-02,"CTF axial gradiometer size = 18.00  mm base = 50.00  mm",
                               {{   0.2500,  4.500e-03,  4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -4.500e-03,  4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500, -4.500e-03, -4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.2500,  4.500e-03, -4.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500,  4.500e-03,  4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.500e-03,  4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.2500, -4.500e-03, -4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.2500,  4.500e-03, -4.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5001,   2, 14, 1.800e-02, 5.000e-02,"CTF axial gradiometer size = 18.00  mm base = 50.00  mm",
                               {{    0.2500,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250,  7.348e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250, -7.348e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250,  3.674e-03,  6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250,  3.674e-03, -6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250, -3.674e-03,  6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.1250, -3.674e-03, -6.364e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   -0.2500,  0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250,  7.348e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250, -7.348e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250,  3.674e-03,  6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250,  3.674e-03, -6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250, -3.674e-03,  6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   -0.1250, -3.674e-03, -6.364e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {    0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  5002,   0,  1, 1.600e-02, 0.000e+00,"CTF reference magnetometer size = 16.00  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  5002,   1,  4, 1.600e-02, 0.000e+00,"CTF reference magnetometer size = 16.00  mm",
                               {{  0.2500,   4.000e-03,  4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.000e-03,  4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.000e-03, -4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   4.000e-03, -4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{1,  5002,   2,  4, 1.600e-02, 0.000e+00,"CTF reference magnetometer size = 16.00  mm",
                               {{  0.2500,   4.000e-03,  4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.000e-03,  4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -4.000e-03, -4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   4.000e-03, -4.000e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5003,   0,  2, 3.440e-02, 7.860e-02,"CTF reference gradiometer (diag) size = 34.40  mm base = 78.60  mm",
                               {{  1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,   0.000e+00,  0.000e+00,  7.860e-02,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5003,   1,  8, 3.440e-02, 7.860e-02,"CTF reference gradiometer (diag) size = 34.40  mm base = 78.60  mm",
                               {{  0.2500,   8.600e-03,  8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -8.600e-03,  8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  -8.600e-03, -8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,   8.600e-03, -8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500,   8.600e-03,  8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                { -0.2500,  -8.600e-03,  8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                { -0.2500,  -8.600e-03, -8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                { -0.2500,   8.600e-03, -8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5003,   2,  8, 3.440e-02, 7.860e-02,"CTF reference gradiometer (diag) size = 34.40  mm base = 78.60  mm",
                               {{    0.2500,  8.600e-03,  8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.2500, -8.600e-03,  8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.2500, -8.600e-03, -8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {    0.2500,  8.600e-03, -8.600e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   -0.2500,  8.600e-03,  8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                {   -0.2500, -8.600e-03,  8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                {   -0.2500, -8.600e-03, -8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                {   -0.2500,  8.600e-03, -8.600e-03,  7.860e-02,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5004,   0,  2, 3.440e-02, 7.860e-02,"CTF reference gradiometer (offdiag) size = 34.40  mm base = 78.60  mm",
                               {{  1.0000,   3.930e-02,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,  -3.930e-02,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5004,   1,  8, 3.440e-02, 7.860e-02,"CTF reference gradiometer (offdiag) size = 34.40  mm base = 78.60  mm",
                               {{  0.2500,  4.780e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  3.080e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  3.080e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  4.780e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -3.080e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -4.780e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -4.780e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -3.080e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  5004,   2,  8, 3.440e-02, 7.860e-02,"CTF reference gradiometer (offdiag) size = 34.40  mm base = 78.60  mm",
                               {{  0.2500,  4.780e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  3.080e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  3.080e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  4.780e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -3.080e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -4.780e-02,  8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -4.780e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500, -3.080e-02, -8.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  6001,   0,  2, 1.550e-02, 5.000e-02,"MIT KIT system gradiometer size = 15.50  mm base = 50.00  mm",
                               {{  1.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { -1.0000,  0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  6001,   1,  8, 1.550e-02, 5.000e-02,"MIT KIT system gradiometer size = 15.50  mm base = 50.00  mm",
                               {{  0.2500,  3.875e-03,  3.875e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500, -3.875e-03,  3.875e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500, -3.875e-03, -3.875e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.2500,  3.875e-03, -3.875e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                { -0.2500,  3.875e-03,  3.875e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500, -3.875e-03,  3.875e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500, -3.875e-03, -3.875e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                { -0.2500,  3.875e-03, -3.875e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  6001,   2, 14, 1.550e-02, 5.000e-02,"MIT KIT system gradiometer size = 15.50  mm base = 50.00  mm",
                               {{   0.2500,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  6.328e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -6.328e-03,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  3.164e-03,  5.480e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250,  3.164e-03, -5.480e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -3.164e-03,  5.480e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.1250, -3.164e-03, -5.480e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                {  -0.2500,  0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  6.328e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -6.328e-03,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  3.164e-03,  5.480e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250,  3.164e-03, -5.480e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -3.164e-03,  5.480e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {  -0.1250, -3.164e-03, -5.480e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {   0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  7001,   0,  2, 6.000e-03, 5.000e-02,"BabySQUID system gradiometer size = 6.00   mm base = 50.00  mm",
                               {{ 1.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                {-1.0000,   0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  7001,   1,  2, 6.000e-03, 5.000e-02,"BabySQUID system gradiometer size = 6.00   mm base = 50.00  mm",
                                {{  1.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { -1.0000,  0.000e+00,  0.000e+00,  5.000e-02,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 { 0.0000,   0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}},
{2,  7001,   2,  8, 6.000e-03, 5.000e-02,"BabySQUID system gradiometer size = 6.00   mm base = 50.00  mm",
                                {{  0.2500,  1.500e-03,  1.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.2500, -1.500e-03,  1.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.2500, -1.500e-03, -1.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.2500,  1.500e-03, -1.500e-03,  0.000e+00,  0.000,  0.000,  1.000},
                                 { -0.2500,  1.500e-03,  1.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                 { -0.2500, -1.500e-03,  1.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                 { -0.2500, -1.500e-03, -1.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                 { -0.2500,  1.500e-03, -1.500e-03,  5.000e-02,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000},
                                 {  0.0000,  0.000e+00,  0.000e+00,  0.000e+00,  0.000,  0.000,  1.000}}
}
};
