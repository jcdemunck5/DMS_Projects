#ifndef _MEEGDATAFIFF_INCLUDED
#define _MEEGDATAFIFF_INCLUDED

#include "MEEGDataBase.h"

enum FIFF_DataType
{
    U_FIFF_VOID               = 0,  // void 1
    U_FIFF_BYTE               = 1,  // unsigned char 1
    U_FIFF_SHORT              = 2,  // fiff_short_t 2
    U_FIFF_INT                = 3,  // fiff_int_t 4
    U_FIFF_FLOAT              = 4,  // fiff_float_t 4
    U_FIFF_DOUBLE             = 5,  // fiff_double_t 8
    U_FIFF_JULIAN             = 6,  // fiff_int_t 8
    U_FIFF_USHORT             = 7,  // fiff_ushort_t 2
    U_FIFF_UINT               = 8,  // fiff_uint_t 4
    U_FIFF_STRING             = 10, // unsigned char 1
    U_FIFF_ASCII              = 10, // unsigned char 1
    U_FIFF_DAU_PACK13         = 13, // fiff_dau_pack_13_t 2
    U_FIFF_DAU_PACK14         = 14, // fiff_dau_pack_14_t 2
    U_FIFF_DAU_PACK16         = 16, // fiff_dau_pack_16_t 2
    U_FIFF_OLD_PACK           = 23, // void see 3.1.1
    U_FIFF_CH_INFO_STRUCT     = 30, // fiff_ch_info_t
    U_FIFF_ID_STRUCT          = 31, // fiff_id_t
    U_FIFF_DIR_ENTRY_STRUCT   = 32, // fiff_dir_entry_t
    U_FIFF_DIG_POINT_STRUCT   = 33, // fiff_dig_point_t
    U_FIFF_CH_POS_STRUCT      = 34, // fiff_ch_pos_t 44
    U_FIFF_COORD_TRANS_STRUCT = 35, // fiff_coord_trans_t 80
    U_FIFF_DIG_STRING_STRUCT  = 36,  // void see 3.1.2
    U_FIFF_NTYPE              = 37
};

enum FIFF_PixelEncodingType
{
    U_FIFF_MRI_PIXEL_UNKNOWN             =  0, // The encoding is unknown.
    U_FIFF_MRI_PIXEL_BYTE                =  1, // The pixels are unsigned bytes.
    U_FIFF_MRI_PIXEL_WORD                =  2, // The pixels are unsigned shorts (2 bytes) in big-endian byte order.
    U_FIFF_MRI_PIXEL_SWAP_WORD           =  3, // The pixels are unsigned shorts (2 bytes) in little-endian byte order.
    U_FIFF_MRI_PIXEL_FLOAT               =  4, // The pixels are 4-byte IEEE floats.
    U_FIFF_MRI_PIXEL_BYTE_INDEXED_COLOR  =  5, // The pixels are indexes to a 8-bit color map (this has not been used so far).
    U_FIFF_MRI_PIXEL_BYTE_RGB_COLOR      =  6, // The pixels are represented by three byte values indicating the red, green, and blue intensities (0..255).
    U_FIFF_MRI_PIXEL_BYTE_RLE_RGB_COLOR  =  7, // RGB values with run-length enconding.
    U_FIFF_MRI_PIXEL_BIT_RLE             =  8, // A run-length encoded bitmap. This will eventually be used for representation of segmentation regions.
    U_FIFF_MRI_PIXEL_SIGNED_WORD         =  9, // The pixels are signed shorts (2 bytes) in big-endian byte order.
    U_FIFF_MRI_PIXEL_SIGNED_SWAP_WORD    = 10  // The pixels are signed shorts (2 bytes) in little-endian byte order.
};


typedef struct
{
    int          version;
    int          machid[2];
    int          timesec;
    unsigned int timefrac;
} FIFF_ID_T;
typedef struct
{
    int             kind;
    FIFF_DataType   type;
    int             size;
    int             pos;
    int             Level;   // Member added: depth of block
} FIFF_DIRENTRY;
typedef struct
{
    int             kind;
    FIFF_DataType   type;
    int             size;
    int             next;
    char*           data;
} FIFF_TAGDATA;


#define FIFFV_POINT_CARDINAL         1
#define FIFFV_POINT_HPI              2
#define FIFFV_POINT_EEG              3
#define FIFFV_POINT_ECG              FIFF_POINT_EEG
#define FIFFV_POINT_EXTRA            4

#define FIFFV_POINT_LPA              1
#define FIFFV_POINT_NASION           2
#define FIFFV_POINT_RPA              3

enum FIFF_CoordType
{
    FIFFV_COORD_UNKNOWN         = 0,  // Unspecified coordinate frame.
    FIFFV_COORD_DEVICE          = 1,  // Neuromag device specific coordinates.
    FIFFV_COORD_ISOTRAK         = 2,  // Coordinate frame of the Polhemus Isotrak and Fastrak digitizers.
    FIFFV_COORD_HPI             = 3,  // Coordinate frame defined by the HPI coils.
    FIFFV_COORD_HEAD            = 4,  // Neuromag head coordinate system.
    FIFFV_COORD_MRI             = 5,  // Neuromag MRI coordinates. Similar to the DICOM coordinates except that the coordinate frame is rotated by 180 degrees around the axis: the axis points to the front and the axis points to the right.
    FIFFV_COORD_MRI_SLICE       = 6,  // A local coordinate system of an MRI slice. The origin is at the upper left corner and the axis points to the right on the slice and the axis points up.
    FIFFV_COORD_MRI_DISPLAY     = 7,  // A coordinate system defining the orientation of the MRI display. This can be set in the MEG-MRI integration software (mrilab).
    FIFFV_COORD_DICOM_DEVICE    = 8,  // The DICOM standard coordinate system: The axis points left, the axis back, and the axis up.
    FIFFV_COORD_IMAGING_DEVICE  = 9,  // Unspecified imaging device coordinate system.
    FIFFV_COORD_TORSO           = 100  // Neuromag torso coordinate system used in the MCG device.
};
FIFF_CoordType GetFIFF_CoordType(int itype);

typedef struct
{
    FIFF_CoordType  kind;
    int             runnum;
    float           r[3];     // coordinates in m
} FIFF_DIGPOINT;
typedef struct
{
    FIFF_CoordType  kind;
    int             runnum;
    int             Npoints;
    float**         r;       // coordinates in m
} FIFF_DIGSTRING_T;
typedef struct
{
    FIFF_CoordType  kindFrom;
    FIFF_CoordType  kindTo;
    float           rotmat[3][3];
    float           move[3];
    float           invrot[3][3];
    float           invmove[3];
} FIFF_COORDTRANS_T;

typedef struct
{
    int     scanNo;    // position of channel in  scanning order
    int     logNo;     // unique logical scanning number
    int     kind;      // kind of channel (MEG, EEG, EOG)
    float   range;     // scaling from integer to physical value
    float   cal;       // calibration
    int     coil_type; //
    float   r0[3];     // coil coordinate system origin (EEG: electrode position)
    float   ex[3];     // x-direction (EEG: position reference, (0.,0.,0.) -> no reference)
    float   ey[3];     // y-direction (EEG: ignored)
    float   ez[3];     // z-direction (EEG: ignored)
    int     unit;      // Unit of measurement
    int     unit_mul;  // Unit multiplier exponent
    char    name[16];
} FIFF_CHANINFO;


#define FIFFV_COIL_NONE                  0  // The location info contains no data
#define FIFFV_COIL_EEG                   1  // EEG electrode position in r0
#define FIFFV_COIL_NM_122                2  // Neuromag 122 coils
#define FIFFV_COIL_NM_24                 3  // Old 24 channel system in HUT
#define FIFFV_COIL_NM_MCG_AXIAL          4  // The axial devices in the HUCS MCG system
#define FIFFV_COIL_EEG_BIPOLAR           5  // Bipolar EEG lead
#define FIFFV_COIL_DIPOLE              200  // Time-varying dipole definition. The coil info contains dipole location (r0) and direction (ex)
#define FIFFV_COIL_MCG_42             1000  // For testing the MCG software
#define FIFFV_COIL_POINT_MAGNETOMETER 2000  // Simple point magnetometer
#define FIFFV_COIL_AXIAL_GRAD_5CM     2001  // Generic axial gradiometer
#define FIFFV_COIL_VV_PLANAR_W        3011  // VV prototype wirewound planar sensor
#define FIFFV_COIL_VV_PLANAR_T1       3012  // Vectorview SQ20483N planar gradiometer
#define FIFFV_COIL_VV_PLANAR_T2       3013  // Vectorview SQ20483N-A planar gradiometer
#define FIFFV_COIL_VV_PLANAR_T3       3014  // Vectorview SQ20950N planar gradiometer
#define FIFFV_COIL_VV_MAG_W           3021  // VV prototype wirewound magnetometer
#define FIFFV_COIL_VV_MAG_T1          3022  // Vectorview SQ20483N magnetometer
#define FIFFV_COIL_VV_MAG_T2          3023  // Vectorview SQ20483-A magnetometer
#define FIFFV_COIL_VV_MAG_T3          3024  // Vectorview SQ20950N magnetometer
#define FIFFV_COIL_MAGNES_MAG         4001  // Magnes WH magnetometer
#define FIFFV_COIL_MAGNES_GRAD        4002  // Magnes WH gradiometer
#define FIFFV_COIL_CTF_GRAD           5001  // CTF axial gradiometer

#define FIFFM_IS_VV_COIL(c) ((c)/1000 == 3)

#define FIFF_UNIT_NONE -1
#define FIFF_UNIT_M     1    /* SI base units */
#define FIFF_UNIT_KG    2
#define FIFF_UNIT_SEC   3
#define FIFF_UNIT_A     4
#define FIFF_UNIT_K     5
#define FIFF_UNIT_MOL   6
#define FIFF_UNIT_RAD   7   /* SI Supplementary units */
#define FIFF_UNIT_SR    8
#define FIFF_UNIT_CD    9   /* SI candela */
#define FIFF_UNIT_HZ  101   /* SI derived units */
#define FIFF_UNIT_N   102
#define FIFF_UNIT_PA  103
#define FIFF_UNIT_J   104
#define FIFF_UNIT_W   105
#define FIFF_UNIT_C   106
#define FIFF_UNIT_V   107
#define FIFF_UNIT_F   108
#define FIFF_UNIT_OHM 109
#define FIFF_UNIT_MHO 110
#define FIFF_UNIT_WB  111
#define FIFF_UNIT_T   112
#define FIFF_UNIT_H   113
#define FIFF_UNIT_CEL 114
#define FIFF_UNIT_LM  115
#define FIFF_UNIT_LX  116
#define FIFF_UNIT_T_M 201   /* T/m */
#define FIFF_UNIT_AM  202   /* Am  */

#define FIFF_UNITM_E   18   /* * 10E18 */
#define FIFF_UNITM_PET 15   /* * 10E15 */
#define FIFF_UNITM_T   12
#define FIFF_UNITM_MEG  6
#define FIFF_UNITM_K    3
#define FIFF_UNITM_H    2
#define FIFF_UNITM_DA   1
#define FIFF_UNITM_NONE 0
#define FIFF_UNITM_D   -1
#define FIFF_UNITM_C   -2
#define FIFF_UNITM_M   -3
#define FIFF_UNITM_MU  -6
#define FIFF_UNITM_N   -9
#define FIFF_UNITM_P  -12
#define FIFF_UNITM_F  -15
#define FIFF_UNITM_A  -18

typedef struct
{
    int     when;          // Sample of transition
    int     before;        // Status of trigger channels before and
    int     now;           // as a result of the event
} EVENT_DESC;

typedef struct
{
    int         ntrig_chs; // Number of trigger channels
    int         *trig_chs; // The trigger channel numbers in the acquired data (channels are numbered from one in file)
    int         nev;       // Number of events
    EVENT_DESC* ev;        // The actual events
} EVENT_INFO;

class UFiffEvents
{
public:
    UFiffEvents();
    UFiffEvents(int Nevents);
    ~UFiffEvents();

    ErrorType       GetError(void) const {if(this) return error; return U_ERROR;}
    ErrorType       SetEvent(int iev, int sam, int bef, int now);
    UMarkerArray*   GetMarkerArray(int NsampTrial, int NtrialSkip, double Srate) const;

protected:
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;
    int             Nev;
    EVENT_DESC*     Events;
};

const char* GetBlockText(int iblock);

typedef struct
{
    double   W;
    double   x;
    double   y;
    double   z;
    double   nx;
    double   ny;
    double   nz;
} FIFF_MEGGRIDPOINT;
#define MAXGRIDPOINT 16

enum FIFF_CoilType
{
    U_FIFF_COIL_MAG  = 1,
    U_FIFF_COIL_AXGRA   ,
    U_FIFF_COIL_PLAGRA  ,
    U_FIFF_COIL_AXGRA2
};
enum FIFF_AccType
{
    U_FIFF_ACC_POINT    ,
    U_FIFF_ACC_NORMAL   ,
    U_FIFF_ACC_ACCURATE
};
typedef struct
{
    int               CT;
    int               type;
    int               AT;
    int               Npoint;
    double            size;
    double            BaseLine;
    const char*       Name;
    FIFF_MEGGRIDPOINT P[MAXGRIDPOINT];
} FIFF_MEGGRID;

#define MEGGRID 18

class UScan;
class DLL_IO UMEEGDataFIFF : public UMEEGDataBase
{
public:
    UMEEGDataFIFF();
    UMEEGDataFIFF(UFileName FileName);
    UMEEGDataFIFF(UFileName FileName, bool ReadMEEGData, bool ReadPolData, bool ReadScanData);
    UMEEGDataFIFF(const UMEEGDataFIFF& Data);
    virtual ~UMEEGDataFIFF();
    UMEEGDataFIFF&              operator=(const UMEEGDataFIFF &Data);

    virtual ErrorType           GetError(void) const         {if(this) return error; return U_ERROR;}
    const UString&              GetProperties(UString Comment) const;

    virtual double*             GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*             GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;

    UVector3*                   GetPolhemusPoints(int* Npoints, bool* NLRincluded) const;
    UScan*                      GetScan(void) const {return Scan;}
    ErrorType                   PrintDirectory(UFileName F) const;
    UEuler                      GetDewar2NLR(void) const;
    UGrid*                      GetCTFGrid(void) const;

////    static UEuler               GetDefaultFiff2CTF(void) {return Fiff2CTF;}
protected:
    void                        SetAllMembersDefault(void);
    void                        DeleteAllMembers(ErrorType E);

private:
    static       UString        Properties;
    static const UEuler         Fiff2CTF;
    static const FIFF_MEGGRID   FiffGrid[3*MEGGRID];

    int                         Nitem;
    FIFF_DIRENTRY*              ItemDir;
    FIFF_ID_T                   FileIdentifier;
    int*                        TrialItem;
    int                         NtrialSkip;
    UString                     Comments;

    int                         NBadChan;
    int*                        BadChanIndex;
    int*                        ChanIndex;
    FIFF_DataType               RawDatType;
    int                         RawDatSize;
    int                         NTrigChan;
    int*                        TrChan;

    UEuler                      Dev2Head;
    UVector3                    Nasion;
    UVector3                    Left;
    UVector3                    Right;
    int                         NPolPoint;
    int                         NPolPointAlloc;
    UVector3*                   PolhemusPoints;

    UScan*                      Scan;

    ErrorType                   ReadDirectory(UFileName Fiff);
    FIFF_CHANINFO               ReadChanInfo(FILE* fp, int offset) const;
    FIFF_DIGPOINT               ReadDigPoint(FILE* fp, int offset) const;
    FIFF_COORDTRANS_T           ReadCoordTrans(FILE* fp, int offset) const;
    bool                        ReadDevToHead(FILE* fp, int offset, UEuler* Dev2Head) const;
    bool                        ReadNLR(FILE* fp, UVector3* Nas, UVector3* Lef, UVector3* Rig) const;
    UFiffEvents*                ReadFiffEvents(FILE* fp) const;
    int*                        ReadFiffTrigChans(FILE* fp, int *NTrigChan) const;
    UMarkerArray*               GetChannelMarkers(void);
    ErrorType                   GetIsoTrackData(FILE* fp);
    ErrorType                   GetScanData(FILE* fp);
    ErrorType                   AddPolPoint(UVector3 X);

    int                         GetItemNextBlock(int StartItem, int BlockType, FILE* fpIn) const;
};

#define FIFFDAT_MEG      1
#define FIFFDAT_EEG      2
#define FIFFDAT_STI      3   /* Stimulus channel */
#define FIFFDAT_MCG    201   /* Magneto Cardio Graphy */
#define FIFFDAT_EOG    202
#define FIFFDAT_EMG    302
#define FIFFDAT_ECG    402
#define FIFFDAT_MISC   502
#define FIFFDAT_RESP   602  /* Respiration monitoring */





#define FIFFCOIL_GRAD 3012
#define FIFFCOIL_MAG  3024


#define FIFF_NEXT_NONE           -1
#define FIFF_NEXT_SEQ             0

#define FIFF_FILE_ID            100 // Unique identifier for a file, see Section 2.3.2.  ID_STRUCT
#define FIFF_DIR_POINTER        101 // Pointer to the tag directory, seeSection 2.3.2.   INT
#define FIFF_DIR                102 // Directory of tags, see Section 2.3.3.             DIR_ENTRY_STRUCT
#define FIFF_BLOCK_ID           103 // Unique identifier for a data block.               ID_STRUCT
#define FIFF_BLOCK_START        104 // Starts a block of tags belonging logically together, see Section 2.4.  INT
#define FIFF_BLOCK_END          105 // Closes a block of tags belonging together.        INT
#define FIFF_FREE_LIST          106 // Pointer to the list of free space in the file, see Section 2.3.2. INT
#define FIFF_FREE_BLOCK         107 // One block of free space in the file. VOID
#define FIFF_NOP                108 // Can be used at will as a terminator.No data are contained in this tag. VOID
#define FIFF_PARENT_FILE_ID     109 // The unique identifier of the file from which this file was derived in data analysis. ID_STRUCT
#define FIFF_PARENT_BLOCK_ID    110 // The unique identifier of a data block from which this block was derived in analysis. ID_STRUCT
#define FIFF_BLOCK_NAME         111 // Reserved
#define FIFF_BLOCK_VERSION      112 // Reserved
#define FIFF_CREATOR            113 // Name of the program that created this file or block. STRING
#define FIFF_MODIFIER           114 // Name of the program that modified this file or block.STRING
#define FIFF_REF_ROLE           115 // Role of the reference. Available types are: FIFFV_ROLE_PREV_FILE, FIFFV_ROLE_NEXT_FILE, INT
#define FIFF_REF_FILE_ID        116 // File ID of the referenced object. ID_STRUCT
#define FIFF_REF_FILE_NUM       117 // File number of the referenced file. INT
#define FIFF_REF_FILE_NAM       118 // Name hint for the referenced file. STRING
#define FIFF_REF_BLOCK_ID       120 // ID of a referenced block. ID_STRUCT
#define FIFF_DACQ_PARS          150 // Data acquisition parameters. STRING
#define FIFF_DACQ_STIM          151 // Stimulus parameters. STRING
#define FIFF_NCHAN              200 // Number of channels. INT
#define FIFF_SFREQ              201 // Sampling frequency (Hz). FLOAT
#define FIFF_DATA_PACK          202 // How the raw data is packed. INT
#define FIFF_CH_INFO            203 // Channel descriptor. CH_INFO_STRUCT
#define FIFF_MEAS_DATE          204 // Measurement date. INT
#define FIFF_SUBJECT            205 // Subject description(?) STRING
#define FIFF_DESCRIPTION        206 // Textual description of a data block (may be long).STRING
#define FIFF_COMMENT            206 // Textual description of a data block (may be long).STRING
#define FIFF_NAVE               207 // Number of averages. INT
#define FIFF_FIRST_SAMPLE       208 // The first sample of an epoch. INT
#define FIFF_LAST_SAMPLE        209 // The last sample of an epoch. INT
#define FIFF_ASPECT_KIND        210 // Aspect label. Different aspects are listed in Table 4.4. INT
#define FIFF_REF_EVENT          211 // Reference event. INT
#define FIFF_EXPERIMENTER       212 // Experimenter name. STRING
#define FIFF_DIG_POINT          213 // Digitization point. FLOAT*
#define FIFF_CH_POS_VEC         214 // Channel position. CH_POS_STRUCT
#define FIFF_HPI_SLOPES         215 // HPI amplitudes. FLOAT*
#define FIFF_HPI_NCOIL          216 // Number of HPI coils. INT
#define FIFF_REQ_EVENT          217 // Required event. INT
#define FIFF_REQ_LIMIT          218 // Window (secs) for required event. FLOAT
#define FIFF_LOWPASS            219 // Analog lowpass filtering frequency. FLOAT
#define FIFF_BAD_CHS            220 // List of bad channels. INT*
#define FIFF_ARTEF_REMOVAL      221 // Artefact removal. INT
#define FIFF_COORD_TRANS        222 // Coordinate transformation. COORD_TRANS_STRUCT
#define FIFF_HIGHPASS           223 // Analog highpass filtering frequency. FLOAT
#define FIFF_CH_CALS_VEC        224 // This will not occur in new files FLOAT*
#define FIFF_HPI_BAD_CHS        225 // List of channels considered to bebad in hpi.INT*
#define FIFF_HPI_CORR_COEFF     226 // Hpi curve fit correlations. FLOAT*
#define FIFF_EVENT_COMMENT      227 // Comment about the events used inaveraging. STRING
#define FIFF_NO_SAMPLES         228 // Number of samples in an epoch. INT
#define FIFF_FIRST_TIME         229 // Time scale minimum. FLOAT
#define FIFF_SUBAVE_SIZE        230 // Size of a subaverage. INT
#define FIFF_SUBAVE_FIRST       231 // The first epoch # contained in the subaverage.INT
#define FIFF_NAME               233 // A short descriptive name of a data block.STRING
#define FIFF_DIG_STRING         234 // String of digitized points. DIG_STRING_STRUCT

#define FIFF_LINE_FREQ          235 // Basic line interference frequency. FLOAT
#define FIFF_HPI_COIL_FREQ      236 // HPI coil excitation frequency. FLOAT
#define FIFF_HPI_COIL_MOMENTS   240 // Estimated moment vectors for the HPI coil magnetic dipoles. FLOAT
#define FIFF_HPI_FIT_GOODNESS   241 // Three floats indicating the goodness of fit. FLOAT*
#define FIFF_HPI_FIT_ACCEPT     242 // Bitmask indicating acceptance: HPI_ACCEPT_NONE (0), HPI_ACCEPT_PROGRAM(0<<1) or HPI_ACCEPT_USER (1<<1) BITMASK
#define FIFF_HPI_FIT_GOOD_LIMIT 243 // Limit for the goodness-of-fit.        FLOAT
#define FIFF_HPI_FIT_DIST_LIMIT 244 // Limit for the coil distance difference. FLOAT
#define FIFF_HPI_COIL_NO        245 // Coil number listed by HPI measurement.  INT
#define FIFF_HPI_COILS_USED     246 // List of coils finally used when the transformation was computed. INT*
#define FIFF_HPI_DIGITIZATION_ORDER 247 // Which Isotrak digitization point corresponds to each of the coils energized. INT*

#define FIFF_CH_SCAN_NO         250 // Channel scan number, fiff_ch_info_t field scanNo.  INT
#define FIFF_CH_LOGICAL_NO      251 // Channel logical number, fiff_ch_info_t field logNo.INT
#define FIFF_CH_KIND            252 // Channel type, fiff_ch_info_t field kind.    INT
#define FIFF_CH_RANGE           253 // Conversion from recorded number to (possibly virtual) voltage at the output. FLOAT
#define FIFF_CH_CAL             254 // Calibration coefficient from output voltage to some real units. FLOAT
#define FIFF_CH_POS             255 // Channel position. CH_POS_STRUCT
#define FIFF_CH_UNIT            256 // Unit of the data, see Table 4.7. SI-UNIT
#define FIFF_CH_UNIT_MUL        257 // Unit multiplier exponent, see Table Table 4.7. INT

#define FIFF_CH_DACQ_NAME       258 // Name of the channel in the data acquisition system, fiff_ch_info_t field name. STRING
#define FIFF_DATA_BUFFER        300 // Buffer containing measurement data.SHORT | FLOAT
#define FIFF_DATA_SKIP          301 // Data skip in buffers. INT
#define FIFF_EPOCH              302 // Buffer containing one epoch and channel. OLDPACK
#define FIFF_DATA_SKIP_SAMP     303 // Data skip in samples. INT
////???                         304 // Data buffer with int32 time channel. INT

#define FIFF_SUBJ_ID            400 // Numeric id assigned to this patient by the Neuromag data acquisition software.INT
#define FIFF_SUBJ_FIRST_NAME    401 // Patient�s first name. STRING
#define FIFF_SUBJ_MIDDLE_NAME   402 // Patient�s middle name. STRING
#define FIFF_SUBJ_LAST_NAME     403 // Patient�s last name. STRING
#define FIFF_SUBJ_BIRTH_DAY     404 // Patient�s day of birth in Julian calender. JULIAN
#define FIFF_SUBJ_SEX           405 // Patient�s gender: 1 = male 2 = female INT
#define FIFF_SUBJ_HAND          406 // Patient�s handedness: 1 = right 2 = left INT
#define FIFF_SUBJ_WEIGHT        407 // Patient�s weight in kilograms. FLOAT
#define FIFF_SUBJ_HEIGHT        408 // Patient�s height in meters. FLOAT
#define FIFF_SUBJ_COMMENT       409 // Comments about this patient STRING
#define FIFF_SUBJ_HIS_ID        410 // ID assigned to this patient in the hospital information system (HIS). STRING

#define FIFF_PROJ_ID            500 // Numeric id assigned to this project by the Neuromag data acquisition software INT
#define FIFF_PROJ_NAME          501 // Short single-word identifier of the project. STRING
#define FIFF_PROJ_AIM           502 // Description of the aims of the project. STRING
#define FIFF_PROJ_PERSONS       503 // Individuals in charge of the project. STRING
#define FIFF_PROJ_COMMENT       504 // Additional comments about the project. STRING

#define FIFF_EVENT_CHANNELS     600 // Event channel numbers
#define FIFF_EVENT_LIST         601 // List of events (integers: sample before after
#define FIFF_EVENT_CHANNEL      602 // Event channel name
#define FIFF_EVENT_BITS         603 // Event bits array

/*
 * Event bitmask constants
 */
#define FIFFC_EVENT_FROMMASK   0
#define FIFFC_EVENT_FROMBITS   1
#define FIFFC_EVENT_TOMASK     2
#define FIFFC_EVENT_TOBITS     3

#define FIFF_MRI_SOURCE_PATH            1101 // Directory???
#define FIFF_MRI_SOURCE_FORMAT          2002 // Format of the original MRI slice data file
#define FIFF_MRI_PIXEL_ENCODING         2003 // Encoding of pixels, see FIFF_MRI_PIXEL_DATA
#define FIFF_MRI_PIXEL_DATA_OFFSET      2004 // Offset in bytes to the pixel data in the original file
#define FIFF_MRI_PIXEL_SCALE            2005 // Suitable scaling of pixels to one byte representation
#define FIFF_MRI_PIXEL_DATA             2006 // The pixel data of an MRI slice

#define FIFF_MRI_PIXEL_OVERLAY_ENCODING 2007 // How the pixels are encoded in FIFF_MRI_PIXEL_OVERLAY_DATA
#define FIFF_MRI_PIXEL_OVERLAY_DATA     2008 // Overlay data for the MRI slice
#define FIFF_MRI_BOUNDING_BOX           2009 // What is this??
#define FIFF_MRI_WIDTH                  2010 // Width of the slice in pixels
#define FIFF_MRI_WIDTH_M                2011 // Width of the slice in meters
#define FIFF_MRI_HEIGHT                 2012 // Height of the slice in pixels
#define FIFF_MRI_HEIGHT_M               2013 // Height of the slice in meters
#define FIFF_MRI_DEPTH                  2014 // Depth of the stack of slices in images.
#define FIFF_MRI_DEPTH_M                2015 // Depth of the stack of slices in meters
#define FIFF_MRI_THICKNESS              2016 // Thickness of one slice in meters
#define FIFF_MRI_SCENE_AIM              2017 // Location of the aim point of the camera when the 3D scene was calculated (vector of three floats).
#define FIFF_MRI_ORIG_SOURCE_PATH       2020 // Hmmm...
#define FIFF_MRI_ORIG_SOURCE_FORMAT     2021
#define FIFF_MRI_ORIG_PIXEL_ENCODING    2022
#define FIFF_MRI_ORIG_PIXEL_DATA_OFFSET 2023
#define FIFF_MRI_VOXEL_DATA             2030 // Voxel data of a data volume.
#define FIFF_MRI_VOXEL_ENCODING         2031 // Encoding of the voxels. INT
#define FIFF_MRI_MRILAB_SETUP           2100 // mrilab setup information. STRING
#define FIFF_MRI_SEG_REGION_ID          2200 // Identifier of a segmented region.

#define FIFF_MRI_FORMAT_UNKNOWN            0 // The source format is unknown.
#define FIFF_MRI_FORMAT_MAGNETOM_SHORT     1 // The short Siemens Magnetom format (any better name??).
#define FIFF_MRI_FORMAT_MAGNETOM_LONG      2 // The long Siemens Magnetom format (any better name?).
#define FIFF_MRI_FORMAT_MERIT              3 // The Picker Merit low-field system format.
#define FIFF_MRI_FORMAT_SIGNA              4 // One of the GE Signa formats (any specs).
#define FIFF_MRI_FORMAT_PIXEL_RAW          5 // Raw pixels.
#define FIFF_MRI_FORMAT_PIXEL_RAW_PACKED   6 // Raw pixels packed??
#define FIFF_MRI_FORMAT_MAGNETOM_NEW       7 // The Siemens Magnetom Vision native format.
#define FIFF_MRI_FORMAT_FIFF               8 // The pixel data are present in this FIFF file.
#define FIFF_MRI_FORMAT_ACR_NEMA           9 // The ACR NEMA version 2.0 format.
#define FIFF_MRI_FORMAT_DICOM_3           10 // The DICOM 3.0 format.

#define FIFF_CONDUCTOR_MODEL_KIND   3000 // What kind of a conductor model, see Table 4.11. INT
#define FIFF_SPHERE_ORIGIN          3001 // Threee float containing the sphere origin. FLOAT
#define FIFF_SPHERE_COORD_FRAME     3002 // Sphere model coordinate frame. Possible values are listed in Table 1.8 on page 11. INT
#define FIFF_SPHERE_LAYERS          3003 // An array of sphere layer structures.xxx
#define FIFF_BEM_SURF_ID            3101 // Which BEM surface, possible values are listed in Table 4.12. INT
#define FIFF_BEM_SURF_NAME          3102 // Short name for the surface. STRING
#define FIFF_BEM_SURF_NNODE         3103 // How many nodes are used in the surface triangulation (nnode). INT
#define FIFF_BEM_SURF_NTRI          3104 // How many triangles are used in the surface triangulation (ntri). INT
#define FIFF_BEM_SURF_NODES         3105 // An nnode by 3 matrix of surface node locations. Coordinates are given in meters. FLOAT



#define FIFFB_ROOT               999 // Root block of a file (has not been used so far).
#define FIFFB_MEAS               100 // One data acquisition.
#define FIFFB_MEAS_INFO          101 // Contains the information about the acquisition details.
#define FIFFB_RAW_DATA           102 // Contains the raw continuous data.
#define FIFFB_PROCESSED_DATA     103 // Contains data processed from the raw data like evoked responses.
#define FIFFB_EVOKED             104 // Used within FIFFB_PROCESSED_DATA. Contains evoked responses.
#define FIFFB_MCG_AVE            104 // Averaged MCG data.
#define FIFFB_ASPECT             105 // Used within FIFFB_EVOKED to include one aspect of evoked responses like standard average, alternating average, standard error of mean etc.
#define FIFFB_SUBJECT            106 // Contains information about the subject or patient.
#define FIFFB_ISOTRAK            107 // Contains the head digitization data.
#define FIFFB_HPI_MEAS           108 // Contains the data acquired when the head-position indicator (HPI) coils were energized.
#define FIFFB_HPI_RESULT         109 // Result of the HPI coil fitting procedure
#define FIFFB_HPI_COIL           110 // Used within FIFFB_HPI_MEAS. Contains data acquired from one HPI coil
#define FIFFB_PROJECT            111 // Contains information about the project under which the data were acquired.
#define FIFFB_CONTINUOUS_DATA    112 // Continuous data.
#define FIFFB_VOID               114 // Unspecified contents.
#define FIFFB_EVENTS             115 // Contains information about the events detected on the trigger channels during data acquisition.
#define FIFFB_INDEX              116 // Contains an index of file id/file name pairs.
#define FIFFB_DACQ_PARS          117 // Contains the acquisition setup parameters.
#define FIFFB_REF                118 // Reference mechanism.
#define FIFFB_SMSH_RAW_DATA      119 // Indicates raw data collected with active compensation.
#define FIFFB_SMSH_ASPECT        120 // Epoch data collected with active compensation.
#define FIFFB_MRI                200 // Contains MRI data.
#define FIFFB_MRI_SET            201 // Contains one MRI series.
#define FIFFB_MRI_SLICE          202 // Contains one MRI slices.
#define FIFFB_MRI_SCENERY        203 // Contains a set of related (in DICOM terminology �secondary capture�) images like the 3D renderings of the brain surface.
#define FIFFB_MRI_SCENE          204 // Contains one image of a scenery.
#define FIFFB_MRI_SEG            205 // Contains MRI segmentation data
#define FIFFB_MRI_SEG_REGION     206 // Contains description of one segmented region.
#define FIFFB_SPHERE             300 // Contains a spherically symmetric volume conductor description.
#define FIFFB_BEM                310 // Contains a boundary-element model (BEM) description.
#define FIFFB_BEM_SURF           311 // Describes one BEM surface.
#define FIFFB_CONDUCTOR_MODEL    312 // Contains one or more conductor model descriptions (FIFFB_SPHERE or FIFFB_BEM).
#define FIFFB_XFIT_PROJ          313 // Contains the signal-space projection (SSP) data.
#define FIFFB_XFIT_PROJ_ITEM     314 // Contains one set of vectors of the SSP data.
#define FIFFB_XFIT_AUX           315 // Contains the auxiliary data created by the source modelling program xfit.
#define FIFFB_VOL_INFO           400 // Describes a data volume.
#define FIFFB_DATA_CORRECTION    500 // Indicates that correction was done on the data.
#define FIFFB_CHANNEL_DECOUPLER  501 // Cross-talk compensation information.
#define FIFFB_SSS_INFO           502 // Signal space separation SSS information.
#define FIFFB_SSS_CAL_ADJUST     503 // Calibration adjustment information.
#define FIFFB_SSS_ST_INFO        504 // Information of the SSST parameters.
#define FIFFB_SSS_BASES          505 // Basis matrices of SSS.
#define FIFFB_SMARTSHIELD        510 // Information of MaxShield.
#define FIFFB_PROCESSING_HISTORY 900 // Processing history block.
#define FIFFB_PROCESSING_RECORD  901 // One processing history record.


#endif// _MEEGDATAFIFF_INCLUDED
