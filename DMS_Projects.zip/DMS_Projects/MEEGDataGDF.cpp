/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a GDF data file and taking only the necesssary.        */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    08-03-15   creation.
*/

#include <string.h>

#include "MEEGDataGDF.h"
#include "MarkerArray.h"
#include "AnalyzeLine.h"
#include "Grid.h"

/* Inititalize static const parameters. */
UString UMEEGDataGDF::Properties = UString();


GDDDataType GetGDFDataType(int itype)
{
    switch(itype)
    {
    case 0   : return    U_GDFTYPE_NOTYPE  ;
    case 1   : return    U_GDFTYPE_INT8    ;
    case 2   : return    U_GDFTYPE_UINT8   ;
    case 3   : return    U_GDFTYPE_INT16   ;
    case 4   : return    U_GDFTYPE_UINT16  ;
    case 5   : return    U_GDFTYPE_INT32   ;
    case 6   : return    U_GDFTYPE_UINT32  ;
    case 7   : return    U_GDFTYPE_INT64   ;
    case 8   : return    U_GDFTYPE_UINT64  ;
    case 16  : return    U_GDFTYPE_FLOAT32 ;
    case 17  : return    U_GDFTYPE_FLOAT64 ;
    case 18  : return    U_GDFTYPE_FLOAT128;
    case 279 : return    U_GDFTYPE_INT24   ;
    case 535 : return    U_GDFTYPE_UINT24  ;
    default:  break;
    }
    return U_GDFTYPE_NOTYPE;
};
int GetGDFDataSize(GDDDataType GDT)
{
    switch(GDT)
    {
    case  U_GDFTYPE_NOTYPE  : return    0;
    case  U_GDFTYPE_INT8    : return    1;
    case  U_GDFTYPE_UINT8   : return    1;
    case  U_GDFTYPE_INT16   : return    2;
    case  U_GDFTYPE_UINT16  : return    2;
    case  U_GDFTYPE_INT32   : return    4;
    case  U_GDFTYPE_UINT32  : return    4;
    case  U_GDFTYPE_INT64   : return    8;
    case  U_GDFTYPE_UINT64  : return    8;
    case  U_GDFTYPE_FLOAT32 : return    4;
    case  U_GDFTYPE_FLOAT64 : return    8;
    case  U_GDFTYPE_FLOAT128: return   16;
    case  U_GDFTYPE_INT24   : return    3;
    case  U_GDFTYPE_UINT24  : return    3;
    default:  break;
    }
    return 0;
}

void UMEEGDataGDF::SetAllMembersDefault(void)
{
    memset((void*)&hdr, ' ', sizeof(GDF_HEADER));
    chhdr          = NULL;
    NBytesSamp     = 0;
    Properties     = UString();
}

void UMEEGDataGDF::DeleteAllMembers(ErrorType E)
{
    delete[] chhdr;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataGDF::~UMEEGDataGDF()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataGDF::UMEEGDataGDF() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataGDF::UMEEGDataGDF(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the GDF data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

/* Read the header*/
    FILE*   fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::UMEEGDataGDF(). File cannot be opened: %s \n",(const char*)FileName);
        return;
    }

/* Read the general header*/
    bool IntelData = true;
    fread(hdr.Version,   1, sizeof(hdr.Version  ), fp);
    fread(hdr.Patient,   1, sizeof(hdr.Patient  ), fp);
    fread(hdr.Reserved1, 1, sizeof(hdr.Reserved1), fp);

    hdr.Medication   = ReadBinaryUChar(IntelData, fp);
    hdr.Weight       = ReadBinaryUChar(IntelData, fp);
    hdr.Height       = ReadBinaryUChar(IntelData, fp);
    hdr.Subject      = ReadBinaryUChar(IntelData, fp);
    fread(hdr.Recording, 1, sizeof(hdr.Recording), fp);
    hdr.Location[0]  = ReadBinaryUInt  (IntelData, fp);
    hdr.Location[1]  = ReadBinaryUInt  (IntelData, fp);
    hdr.Location[2]  = ReadBinaryUInt  (IntelData, fp);
    hdr.Location[3]  = ReadBinaryUInt  (IntelData, fp);
    hdr.DateTime[0]  = ReadBinaryUInt  (IntelData, fp);
    hdr.DateTime[1]  = ReadBinaryUInt  (IntelData, fp);
    hdr.Birthday[0]  = ReadBinaryUInt  (IntelData, fp);
    hdr.Birthday[1]  = ReadBinaryUInt  (IntelData, fp);
    hdr.HeaderSize   = ReadBinaryUShort(IntelData, fp);

    fread(hdr.PatClass,  1, sizeof(hdr.PatClass ), fp);
    hdr.Equipment    = ReadBinaryUInt64(IntelData, fp);
    fread(hdr.Reserved2, 1, sizeof(hdr.Reserved2), fp);
    hdr.HeadSize[0] = ReadBinaryUShort(IntelData, fp);
    hdr.HeadSize[1] = ReadBinaryUShort(IntelData, fp);
    hdr.HeadSize[2] = ReadBinaryUShort(IntelData, fp);
    hdr.PosRef  [0] = ReadBinaryFloat(IntelData, fp);
    hdr.PosRef  [1] = ReadBinaryFloat(IntelData, fp);
    hdr.PosRef  [2] = ReadBinaryFloat(IntelData, fp);
    hdr.PosGrnd [0] = ReadBinaryFloat(IntelData, fp);
    hdr.PosGrnd [1] = ReadBinaryFloat(IntelData, fp);
    hdr.PosGrnd [2] = ReadBinaryFloat(IntelData, fp);
    hdr.NRecords    = ReadBinaryInt64(IntelData, fp);
    hdr.Duration[0] = ReadBinaryUInt(IntelData, fp);
    hdr.Duration[1] = ReadBinaryUInt(IntelData, fp);
    hdr.NChan       = ReadBinaryUShort(IntelData, fp);
    hdr.TimeZone    = ReadBinaryShort(IntelData, fp);

    strncpy(PatName, hdr.Patient, MIN(sizeof(PatName),sizeof(hdr.Patient))-1);

    ntrial      = int(hdr.NRecords);
    NchannelRaw = hdr.NChan;
    NchannelTot = NchannelRaw;
    double Duration = hdr.Duration[1]==0 ? 0. : hdr.Duration[0]/double(hdr.Duration[1]);
    if(ntrial<=0 || NchannelRaw<=0 || NchannelRaw>MAXCHAN || Duration<=0.)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::UMEEGDataGDF(). Invalid header parameters: NchannelRaw=%d, ntrial=%d and", NchannelRaw, ntrial);
        CI.AddToLog("Duration per trial = %f \n", Duration);
        return;
    }
    if(hdr.HeaderSize<hdr.NChan+1)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::UMEEGDataGDF(). Invalid header size (%d), (NchannelRaw=%d) .\n", hdr.HeaderSize, NchannelRaw);
        return;
    }

    chhdr     = new GDF_CHAN_HEAD[NchannelRaw];
    ChIn      = new ChanInfo[MAXCHAN];
    GridAll   = new UGrid(MAXCHAN);
    
    if(!chhdr   || !ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataGDF::UMEEGDataGDF(). Memory allocation. \n");
        return;
    }
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"GDF_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }

    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].Label     , 1,      sizeof(chhdr[i].Label)    , fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].TransType , 1,      sizeof(chhdr[i].TransType), fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].PhysDim   , 1,      sizeof(chhdr[i].PhysDim)  , fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].PhysDimCode  = ReadBinaryUShort(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].PhysMin      = ReadBinaryDouble(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].PhysMax      = ReadBinaryDouble(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].DigiMin      = ReadBinaryDouble(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].DigiMax      = ReadBinaryDouble(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].PreFilter , 1,      sizeof(chhdr[i].PreFilter), fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].TimeOffset   = ReadBinaryFloat(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].LowPass      = ReadBinaryFloat(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].HighPass     = ReadBinaryFloat(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].Notch        = ReadBinaryFloat(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].Nsamp        = ReadBinaryUInt(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++) chhdr[i].DataType     = ReadBinaryUInt(IntelData, fp);
    for(int i=0;i<NchannelRaw;i++){chhdr[i].PosSensor[0] = ReadBinaryFloat(IntelData, fp); 
                                   chhdr[i].PosSensor[1] = ReadBinaryFloat(IntelData, fp);
                                   chhdr[i].PosSensor[2] = ReadBinaryFloat(IntelData, fp);}
    for(int i=0;i<NchannelRaw;i++) fread(chhdr[i].SensorInfo , 1,      sizeof(chhdr[i].SensorInfo), fp);
    fclose(fp);

    nsamp          = -1;
    for(int i=0; i<NchannelRaw; i++)
    {
        int MAXGDFLABEL = sizeof(chhdr[0].Label);
        char LineLabel[100]; memset(LineLabel, 0, sizeof(LineLabel)); 
        for(int k=0,kk=0; k<MAXGDFLABEL; k++) if(chhdr[i].Label[k]!=' ') LineLabel[kk++] = chhdr[i].Label[k];

        int nschan = chhdr[i].Nsamp;
        if(nsamp<0)          
        {
            nsamp = nschan;
        }
        else if(nschan!=nsamp)
        {
            nsamp = -1;
            break;
        }
    }
    if(nsamp<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::UMEEGDataGDF(). nsamp is not constant over channels or invalid.\n");
        return;
    }
    for(int i=0; i<NchannelRaw; i++)
    {
        if(chhdr[i].DigiMin==chhdr[i].DigiMax)  
        {
            ChIn[i].InGain = 0;
            ChIn[i].Offset = 0;
        }
        else
        {
            ChIn[i].InGain = (                 chhdr[i].PhysMax-                 chhdr[i].PhysMin)/(chhdr[i].DigiMax-chhdr[i].DigiMin);
            ChIn[i].Offset = (chhdr[i].DigiMax*chhdr[i].PhysMin-chhdr[i].DigiMin*chhdr[i].PhysMax)/(chhdr[i].DigiMax-chhdr[i].DigiMin);
        }

        GDDDataType GT = GetGDFDataType(chhdr[i].DataType);
        if(GT!=U_GDFTYPE_INT8    && GT!=U_GDFTYPE_UINT8  && GT!=U_GDFTYPE_INT16 && GT!=U_GDFTYPE_UINT16 && 
           GT!=U_GDFTYPE_INT32   && GT!=U_GDFTYPE_UINT32 && GT!=U_GDFTYPE_INT24 && GT!=U_GDFTYPE_UINT24 && 
           GT!=U_GDFTYPE_FLOAT32 && GT!=U_GDFTYPE_FLOAT64)
        {
            CI.AddToLog("WARNING: UMEEGDataGDF::UMEEGDataGDF(). Unsupported data type (%d) in channel %d \n", int(GT), i);
        }
    }

/* Copy general data and set defaults */
    DataFormat      = U_DATFORM_GDF;
    DataFileName    = FileName;
    NPreTrig        = 0;
    nAver           = 0;
    srate           = nsamp/Duration;
///    DateTimeRec     = UDateTime(1970, hdr.DateTime[0] - 719529 + (unsigned int)(86400.*pow(2.,-32.)*hdr.DateTime[1]));
    DateTimeRec     = UDateTime(0, hdr.DateTime[0] + (unsigned int)(86400.*pow(2.,-32.)*hdr.DateTime[1]));

    EEGposTrue      = false;
    EEGlabelTrue    = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

    NBytesSamp = 0;
/* set type and namChannel */    
    for(int i=0; i<NchannelRaw; i++)
    {
        int   NB    = GetGDFDataSize(GetGDFDataType(chhdr[i].DataType));
        if(NB==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR UMEEGDataGDF::UMEEGDataGDF(). Ill define data size of channel (%d).\n", i);
            return;
        }
        NBytesSamp += NB;
        if(ChIn[i].type!=U_DAT_ANNOT) ChIn[i].type = U_DAT_UNKNOWN;
        if(ChIn[i].SkipChannel==true) continue;

        char LinePhys[10]; memset(LinePhys, 0, sizeof(LinePhys)); memcpy(LinePhys, chhdr[i].PhysDim, 8);
        if(IsStringCompatible(LinePhys,"*uV*", true)==true ||
           IsStringCompatible(LinePhys,"*V*" , true)==true ) 
        {
            ChIn[i].type = U_DAT_EEG;
            nEEG++;
        }
        else if(IsStringCompatible(LinePhys,"*fT*", true)==true) 
            ChIn[i].type = U_DAT_MEG;
        else if(IsStringCompatible(LinePhys,"*boolean*", false)==true) 
            ChIn[i].type = U_DAT_STIM;
        
        bool CaseSense = false;
        UString Label(chhdr[i].Label, sizeof(chhdr[i].Label));
        if(Label.IsContaining("SEEG", CaseSense)==true)
        {
            Label.RemoveString("SEEG", CaseSense);
            if(ChIn[i].type != U_DAT_EEG) 
            {
                ChIn[i].type = U_DAT_EEG; 
                nEEG++;
            }
        }
        else if(Label.IsContaining("EEG", CaseSense)==true)
        {
            Label.RemoveString("EEG", CaseSense);
            if(ChIn[i].type != U_DAT_EEG) 
            {
                ChIn[i].type = U_DAT_EEG; 
                nEEG++;
            }
        }
        else if(Label.IsContaining("EKG", CaseSense)==true ||
                Label.IsContaining("ECG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EKG; 
        }
        else if(Label.IsContaining("EOG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EOG; 
        }
        else if(Label.IsContaining("EMG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EMG; 
        }
        else if(Label.IsContaining("Resp", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_ADC; 
        }
        Label.RemoveFirstBlanks();
        Label.RemoveLastBlanks();

        if(ChIn[i].type==U_DAT_UNKNOWN)
        {
            if(UGrid::IsStandardEEGLabel(Label)==true) {ChIn[i].type = U_DAT_EEG; nEEG++;}
            if(UGrid::IsStandardMEGLabel(Label)==true) {ChIn[i].type = U_DAT_MEG; nMEG++;}

            if(ChIn[i].type==U_DAT_UNKNOWN) ChIn[i].type = U_DAT_ADC;
        }
        memset(ChIn[i].namChannel, 0                ,     sizeof(ChIn[i].namChannel));
        memcpy(ChIn[i].namChannel, Label.GetString(), MIN(sizeof(ChIn[i].namChannel), Label.GetNbytes())); 
        USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
        GridAll->SetSensor(&S, i);
    }

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

/* Read markers and classes */
    Markers = ReadMarkers();
    if(Markers && Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("WARNING: UMEEGDataGDF::UMEEGDataGDF(). Cannot create UMarkerArray()-object. \n");
    }
}

UMEEGDataGDF::UMEEGDataGDF(const UMEEGDataGDF& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataGDF.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataGDF& UMEEGDataGDF::operator=(const UMEEGDataGDF &Data)
{
    if(this==NULL)
    {
        static UMEEGDataGDF M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGDF::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    NBytesSamp = Data.NBytesSamp;
    memcpy(&hdr, &(Data.hdr), sizeof(hdr));
    if(Data.chhdr)
    {
        if(hdr.NChan<=0)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataGDF::operator=(). Invalid number of channels: %d. \n", hdr.NChan);
            return *this;
        }
        chhdr = new GDF_CHAN_HEAD[hdr.NChan];
        if(chhdr==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataGDF::operator=(). Memory allocation, hdr.NChan = %d .\n", hdr.NChan);
            return *this;
        }
        for(int i=0; i<hdr.NChan; i++)  memcpy(chhdr+i, Data.chhdr+i, sizeof(chhdr[0]));
    }
    return *this;
}

const UString& UMEEGDataGDF::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties =UString(" ERROR in UMEEGDataGDF-object \n");
        return Properties;
    }
    Properties = UString();

    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');  
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}


double* UMEEGDataGDF::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(chhdr==NULL || NBytesSamp<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetEpoch_d(). Header not (properly) set. \n");
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetEpoch_d(). Requested type not present in file. \n");
        return NULL;
    }

    int            NBTrial  = NBytesSamp*nsamp;
    double         *data    = new double[NSamples*nKAN];
    unsigned char  *buffer  = new unsigned char[8*nsamp];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataGDF::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataGDF::GetTrial_d(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  OffsetHead      = 256*hdr.HeaderSize;
    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
        int    nSampSkip  = (itrial==Begin.trial) ? Begin.sample : 0; // Skip nSampSkip samples from the beginning of this trial 
        int    nSampTake = nsamp;                                     // Take nSampTake samples from the current trial
        if(itrial==Begin.trial && itrial==End.trial)    nSampTake = End.sample-Begin.sample+1;
        else if(itrial==Begin.trial)                    nSampTake = nsamp-Begin.sample;
        else if(itrial==End.trial)                      nSampTake = End.sample+1;

        int OffsetChan = 0;
        for(int i=0;i<NchannelRaw;i++)
        {
            GDDDataType GT = GetGDFDataType(chhdr[i].DataType);

            int NB = GetGDFDataSize(GetGDFDataType(chhdr[i].DataType));
            if(ChIn[i].type==Dtype && ChIn[i].SkipChannel==false)
            {
                if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
                {
                    for(int j=0;j<nSampTake;j++) DataChan[j] = 0.;
                }
                else
                {
                    fseek(fp, OffsetHead+itrial*NBTrial+OffsetChan+NB*nSampSkip, SEEK_SET);
                    fread(buffer,NB,nSampTake,fp);

                    switch(GT)
                    {
                    case  U_GDFTYPE_INT8    : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((  signed char*)buffer)+j));  break;
                    case  U_GDFTYPE_UINT8   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((unsigned char*)buffer)+j));  break;
                    case  U_GDFTYPE_INT16   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((  signed short*)buffer)+j)); break;
                    case  U_GDFTYPE_UINT16  : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((unsigned short*)buffer)+j)); break;
                    case  U_GDFTYPE_INT32   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((  signed int*)buffer)+j));   break;
                    case  U_GDFTYPE_UINT32  : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((unsigned int*)buffer)+j));   break;
                    case  U_GDFTYPE_FLOAT32 : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((       float*)buffer)+j));   break;
                    case  U_GDFTYPE_FLOAT64 : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[i].Offset + ( ChIn[i].InGain*  *(((      double*)buffer)+j));   break;
                    case  U_GDFTYPE_INT24   :
                        for(int j=0;j<nSampTake;j++)
                        {
                            int bf = buffer[3*j] + (buffer[3*j+1]<<8) + ((signed char)buffer[3*j+2]<<16);
                            DataChan[j] = ChIn[i].Offset + ChIn[i].InGain*bf;
                        }
                        break;
                    case  U_GDFTYPE_UINT24  :
                        for(int j=0;j<nSampTake;j++)
                        {
                            unsigned int bf = buffer[3*j] + (buffer[3*j+1]<<8) + (             buffer[3*j+2]<<16);
                            DataChan[j] = ChIn[i].Offset + ChIn[i].InGain*bf;
                        }
                        break;
                    default:
                        fclose(fp);
                        delete[] buffer;
                        delete[] data;
                        CI.AddToLog("ERROR: UMEEGDataGDF::GetTrial_d(). Unsupported data type .\n");
                        return NULL;
                    }
                }
                DataChan += NSamples;
            }
            OffsetChan += NB*nsamp;
        }
        nSamplesDone += nSampTake;
    }
    fclose(fp);

    delete[] buffer;

    return data;
}

int* UMEEGDataGDF::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    if(chhdr==NULL || NBytesSamp<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetTriggerEpoch(). Header not (properly) set. \n");
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetTriggerEpoch() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetTriggerEpoch() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int nKAN = 1;

    CI.AddToLog("ERROR UMEEGDataGDF::GetTriggerEpoch() : AFunction not (yet) implemented,\n");
    return NULL;
}

double* UMEEGDataGDF::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(chhdr==NULL || NBytesSamp<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetChannel_d(). Header not (properly) set. \n");
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGDF::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

/* Select the correct channel index. */
    if(Label==NULL || *Label==0) 
    {
        CI.AddToLog("WARNING UMEEGDataGDF::GetChannel_d() : NULL label argument.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0;i<NchannelRaw; i++) 
        if(!strcmp(Label,ChIn[i].namChannel)) 
        {
            ichan = i;
            break;
        }
    if(ichan==-1)
    {
        CI.AddToLog("WARNING UMEEGDataGDF::GetChannel_d() : required label %s not present.\n",Label);
        return NULL; // Label[] not present.
    }
    int NBChan = GetGDFDataSize(GetGDFDataType(chhdr[ichan].DataType));
    if(NBChan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataGDF::GetChannel_d(). Invalid number of bytes per sample (%d) in channel %d.\n", NBChan, ichan);
        return NULL;
    }

    int            NBTrial  = NBytesSamp*nsamp;
    double          *data   = new double[NSamples];
    char            *buffer = new char  [NBChan*nsamp];

    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataGDF::GetChannel_d() : memory allocation.\n");
        return NULL;
    }
            
    FILE *fpData = fopen(DataFileName,"rb", false);
    if(!fpData)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataGDF::GetChannel_d() : Opening file %s .\n",DataFileName.GetFullFileName());
        return NULL;
    }
    
    int  OffsetHead      = 256*hdr.HeaderSize;
    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    int OffsetChan = 0;
    for(int i=0;i<ichan;i++)
    {
        GDDDataType GT  = GetGDFDataType(chhdr[i].DataType);
        int         NB  = GetGDFDataSize(GT);
        OffsetChan     += NB*nsamp;
    }
    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
        int    nSampSkip  = (itrial==Begin.trial) ? Begin.sample : 0; // Skip nSampSkip samples from the beginning of this trial 
        int    nSampTake = nsamp;                                     // Take nSampTake samples from the current trial
        if(itrial==Begin.trial && itrial==End.trial)    nSampTake = End.sample-Begin.sample+1;
        else if(itrial==Begin.trial)                    nSampTake = nsamp-Begin.sample;
        else if(itrial==End.trial)                      nSampTake = End.sample+1;

        if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
        {
            for(int j=0;j<nSampTake;j++) DataChan[j] = 0.;    
        }
        else
        {
            fseek(fpData, OffsetHead+itrial*NBTrial+OffsetChan+NBChan*nSampSkip, SEEK_SET);
            fread(buffer,NBChan,nSampTake,fpData);

            switch(GetGDFDataType(chhdr[ichan].DataType))
            {
            case  U_GDFTYPE_INT8    : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((  signed char*)buffer)+j));  break;
            case  U_GDFTYPE_UINT8   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((unsigned char*)buffer)+j));  break;
            case  U_GDFTYPE_INT16   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((  signed short*)buffer)+j)); break;
            case  U_GDFTYPE_UINT16  : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((unsigned short*)buffer)+j)); break;
            case  U_GDFTYPE_INT32   : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((  signed int*)buffer)+j));   break;
            case  U_GDFTYPE_UINT32  : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((unsigned int*)buffer)+j));   break;
            case  U_GDFTYPE_FLOAT32 : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((       float*)buffer)+j));   break;
            case  U_GDFTYPE_FLOAT64 : for(int j=0;j<nSampTake;j++) DataChan[j] = ChIn[ichan].Offset + ( ChIn[ichan].InGain*  *(((      double*)buffer)+j));   break;
            case  U_GDFTYPE_INT24   :
                for(int j=0;j<nSampTake;j++)
                {
                    int bf = buffer[3*j] + (buffer[3*j+1]<<8) + ((signed char)buffer[3*j+2]<<16);
                    DataChan[j] = ChIn[ichan].Offset + ChIn[ichan].InGain*bf;
                }
                break;
            case  U_GDFTYPE_UINT24  :
                for(int j=0;j<nSampTake;j++)
                {
                    unsigned int bf = buffer[3*j] + (buffer[3*j+1]<<8) + (             buffer[3*j+2]<<16);
                    DataChan[j] = ChIn[ichan].Offset + ChIn[ichan].InGain*bf;
                }
                break;
            default:
                fclose(fpData);
                delete[] buffer;
                delete[] data;
                CI.AddToLog("ERROR: UMEEGDataGDF::GetChannel_d(). Unsupported data type .\n");
                return NULL;
            }
        }
        nSamplesDone += nSampTake;
    }
    fclose(fpData);

    delete[] buffer;
    return data;
}

UMarkerArray* UMEEGDataGDF::ReadMarkers() const
{
    FILE* fp = fopen(DataFileName, "rb");
    if(fp==NULL) return NULL;

    unsigned int FS = GetFileSize(fp);
    unsigned int OF = 256*hdr.HeaderSize + NBytesSamp * hdr.NRecords;
    if(FS<=OF) 
    {
        CI.AddToLog("Note: UMEEGDataGDF::ReadMarkers(). No event table present after headers and data part \n");
        fclose(fp);
        return NULL;
    }
    fseek(fp, OF, SEEK_SET);

    bool          IntelData = true;
    unsigned char mode      = ReadBinaryUChar(IntelData, fp);
    unsigned char ns0       = ReadBinaryUChar(IntelData, fp);
    unsigned char ns1       = ReadBinaryUChar(IntelData, fp);
    unsigned char ns2       = ReadBinaryUChar(IntelData, fp);
    unsigned int  Nev       = ns0 + (ns1<<8) + (ns2<<16);
    float         rate      = ReadBinaryFloat(IntelData, fp);
    unsigned int* Evar      = new unsigned int[Nev];
    if(Evar==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataGDF::ReadMarkers(). Memory allocation, Nev = %d \n", int(Nev));
        fclose(fp);
        return NULL;
    }
    UMarker M("GDF", 0, nsamp, 255, "All GDF events", 0, true);
    double fact = rate>0 ? srate/rate : 1.;
    for(int iev=0; iev<Nev; iev++) M.AddEvent(int(fact * Evar[iev]));

    delete[] Evar;
    fclose(fp);

    UMarkerArray *Mar = new UMarkerArray(1, nsamp, 0, srate);
    if(Mar==NULL || Mar->GetError()!=U_OK || Mar->AddMarker(&M)!=U_OK)
    {
        delete Mar;
        CI.AddToLog("ERROR: UMEEGDataGDF::ReadMarkers(). Creating UMarkerArray or adding first marker. \n");
        return NULL;
    }

    return Mar;
}


//#define FIX(a) (a)<0 ? ceil(a) : floor(a)
//UDateTime GetDateTomeGDF(double t)
//{
//    int64_t* ti = (int64_t*)&t;
//
//    int32_t rd  = (int32_t)floor(ldexp((double)t,-32));      // days since 0001-01-01
//    double   s  = ldexp((*ti & 0x00000000ffffffff)*86400,-32); // seconds of the day
//
//// s += timezone;
///* derived from datenum.m from Octave 3.0.0 */
//
//
//    double z = rd - 60;                               // Move day 0 from midnight -0001-12-31 to midnight 0000-3-1
//    double a = floor((z - 0.25) / 36524.25);          // Calculate number of centuries; K1 = 0.25 is to avoid rounding problems.
//    double b = z - 0.25 + a - floor (a / 4);          // Days within century; K2 = 0.25 is to avoid rounding problems.
//    int    y = (int)floor (b / 365.25);               // Calculate the year (year starts on March 1).
//    double c = FIX(b - floor (365.25 * y)) + 1;       // Calculate day in year.
//    double m = FIX((5 * c + 456) / 153);              // Calculate month in year.
//    double d = c - FIX((153 * m - 457) / 5);
//    if (m>12) {y++; m-=12;}                           // Move to Jan 1 as start of year.
//
//    int yy = y-1900;
//    int mm = (int)m-1;
//    int dd = (int)d;
//
//    int hh = (int)(floor (s / 3600));
//    s      = s - 3600 * hh;
//    int ii = (int)(floor (s / 60));
//    int ss = (int)(s) - 60 * ii;
//
//    //t3->tm_gmtoff = 3600;
//
//    return UDateTime(yy, mm, dd, hh, ii, ss);
//}
