#ifndef _MEEGDATAGDF_INCLUDED
#define _MEEGDATAGDF_INCLUDED

#include "MEEGDataBase.h"

typedef struct{
    char            Version[8];
    char            Patient[66];
    char            Reserved1[10];
    unsigned char   Medication;
    unsigned char   Weight;         // kg
    unsigned char   Height;         // cm
    unsigned char   Subject;        // gender, handedness, visual impairment, hearing impairment
    char            Recording[64];  // Recording identification, study id, serial number
    unsigned int    Location[4];    // (Lat, Long, Alt)
    unsigned int    DateTime[2];
    unsigned int    Birthday[2];
    unsigned short  HeaderSize;     // in blocks of 256 bytes
    char            PatClass[6];
    uint64_t        Equipment;
    char            Reserved2[6];
    unsigned short  HeadSize[3];    // in mm
    float           PosRef[3];
    float           PosGrnd[3];
    int64_t         NRecords;
    unsigned int    Duration[2];    // numerator, denominator, in seconds
    unsigned short  NChan;
    short           TimeZone;       // minutes east of UTC (version 2.5 or higher)
} GDF_HEADER;

enum GDDDataType
{
    U_GDFTYPE_NOTYPE     = 0,
    U_GDFTYPE_INT8       = 1,
    U_GDFTYPE_UINT8      = 2,
    U_GDFTYPE_INT16      = 3,
    U_GDFTYPE_UINT16     = 4,
    U_GDFTYPE_INT32      = 5,
    U_GDFTYPE_UINT32     = 6,
    U_GDFTYPE_INT64      = 7,
    U_GDFTYPE_UINT64     = 8,
    U_GDFTYPE_FLOAT32    = 16,
    U_GDFTYPE_FLOAT64    = 17,
    U_GDFTYPE_FLOAT128   = 18, // ??
    U_GDFTYPE_INT24      = 279,
    U_GDFTYPE_UINT24     = 535
};
GDDDataType GetGDFDataType(int itype);
int         GetGDFDataSize(GDDDataType GDT);
UDateTime   GetDateTomeGDF(double t);

typedef struct{
    char            Label[16];
    char            TransType[80];
    char            PhysDim[6];
    unsigned short  PhysDimCode;
    double          PhysMin;
    double          PhysMax;
    double          DigiMin;
    double          DigiMax;
    char            PreFilter[64];
    float           TimeOffset;    // sampling time offset in s
    float           LowPass;
    float           HighPass;
    float           Notch;
    unsigned int    Nsamp;
    unsigned int    DataType;
    float           PosSensor[3];
    char            SensorInfo[20]; // Version 2.19 and later
    //unsigned char   Impedance;    // Version 2.0 to 2.18
    //char            Reserved[19];
} GDF_CHAN_HEAD;


class DLL_IO UMEEGDataGDF : public UMEEGDataBase
{
public:
    UMEEGDataGDF();
    UMEEGDataGDF(UFileName FileName);     
    UMEEGDataGDF(const UMEEGDataGDF& Data); 
    virtual ~UMEEGDataGDF();
    UMEEGDataGDF&          operator=(const UMEEGDataGDF &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;

    GDF_HEADER             hdr;
    GDF_CHAN_HEAD*         chhdr;
    int                    NBytesSamp;   // Total number of bytes per sample (summed over channels, assuming same number of samples per chan)
    UMarkerArray*          ReadMarkers() const;
};

#endif// _MEEGDATAGDF_INCLUDED
