/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading an MRI log file of GE scanner                          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    29-02-09   creation
  JdM    22-03-10   Bug fix: GetChannel_d(). Test Lab==NULL argument instead of Label
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
  JdM    20-04-12   BUG fix. The correction factor of UMEEGDataGELog::TACQ = 1./0.999333333
  JdM    14-01-14   UMEEGDataGELog(UFileName). Extend acceptance of file names.
*/

#include <string.h> 

#include "MEEGDataGELog.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString       UMEEGDataGELog::Properties = UString();
const double  UMEEGDataGELog::TACQ       = 0.025 / 0.999333333;


#define LINESTEP        20
#define MAXLINE         50 


void UMEEGDataGELog::SetAllMembersDefault(void)
{
    error         = U_OK;
    NPointsInFile = 0;
    sec           = 0;
    min           = 0;
    hou           = 0;
    day           = 1;
    mon           = 1;
    yea           = 2000;
    NOffSet       = 0;
    DataLineTab   = NULL;
    Label         = "Unknown";
}

void UMEEGDataGELog::DeleteAllMembers(ErrorType E)
{
    delete[] DataLineTab;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataGELog::~UMEEGDataGELog()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataGELog::UMEEGDataGELog() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataGELog::UMEEGDataGELog(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the GE log file called Filename and store the relevant data in 
    the base class, cq this class.


  ECGData_epi_0226200917_24_28     or  // 14 nums
PPGData_epiRT_0109201417_51_07_94  or  // 16 nums
PPGData_epiRT_0109201418_00_37_556     // 17 nums
 */ 
{
    SetAllMembersDefault();

    if(FileName.HasAnyExtension()==true)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). File name has extension (%s). \n",FileName.GetFullFileName());
        return;
    }
    UString Test((const char*)FileName);
    Label   = UString(FileName.GetBaseName()); 
    if(Label.GetNNumChar()==16) Test .Truncate(Test .GetNbytes()-4);
    if(Label.GetNNumChar()==17) Test .Truncate(Test .GetNbytes()-5);

    int Len = Test.GetNbytes();
    if(Len>0) sec = Test.GetIntNumber(Len- 3, 2, -1);
    if(sec>0) min = Test.GetIntNumber(Len- 6, 2, -1);
    if(min>0) hou = Test.GetIntNumber(Len- 9, 2, -1);
    if(hou>0) yea = Test.GetIntNumber(Len-13, 4, -1);
    if(yea>0) day = Test.GetIntNumber(Len-15, 2, -1);
    if(day>0) mon = Test.GetIntNumber(Len-17, 2, -1);
    Label = UString(FileName.GetBaseName()); 
    Len   = Label.GetNbytes();
    if(Len<18 || yea<0 || mon<0 || day<0 ||hou<0 || min<0 || sec<0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). File name has lacks date/time information (%s) (should be XXX_DDMMYYYY_HH_MM_SS. \n",FileName.GetFullFileName());
        return;
    }
    Label.Truncate(Len-18);
    DateTimeRec  = UDateTime(yea, mon, day, hou, min, sec);
    if(DateTimeRec.GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). Invalid date information File name has lacks date/time information (%s) (should be XXX_DDMMYYYY_HH_MM_SS. \n",FileName.GetFullFileName());
        return;
    }

    DataFileName = FileName;
    FILE*     fp = fopen(DataFileName, "rt", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return;
    }
 
/* Read first line of data file */    
    NPointsInFile =  GetNLines(fp);
    NOffSet       =  1 + NPointsInFile/LINESTEP;
    DataLineTab   =  new unsigned int[NOffSet];
    if(DataLineTab==NULL)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). Memory allocation. NOffSet = %d .\n", NOffSet);
        return;
    }
    for(int n=0; n<NOffSet; n++) DataLineTab[n] = 0;

    rewind(fp);
    unsigned int ioff  = ftell(fp);
    int          itab  = 0;
    int          Nline = 0;
    char line[MAXLINE];
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsEmptyLine()==false && AA.IsCommentLine()==false)
        {
            if(Nline%LINESTEP==0) DataLineTab[itab++] = ioff;
            Nline++;
        }
        ioff  = ftell(fp);
    }
    fclose(fp);

    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataGELog::UMEEGDataGELog(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_GELOG;
    DataFileName      = FileName;   

    ContineousData    = true;
    nsamp             = 1;
    ntrial            = Nline;
    NPreTrig          = 0;
    nAver             = 0;
    NchannelRaw       = 1;
    NchannelTot       = 1;
    srate             = 1./TACQ;
    nMEG = nEEG       = 0;
    nADC = nREF       = 0;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"GE_%d",i);
        if(i==0)
        {
            strncpy(ChIn[i].namChannel, (const char*)Label, sizeof(ChIn[0].namChannel)-1);
            ChIn[i].type          = U_DAT_ADC;
            ChIn[i].SkipChannel   = false;
            ChIn[i].Red           = 0;
            ChIn[i].Green         = 0;
            ChIn[i].Blue          = 255;

            USensor  S(UVector3(), UVector3(), UVector3(), USensor::U_SEN_POINT, ChIn[i].namChannel);
            GridAll->SetSensor(&S, i);
            nADC++;
        }        
        else
        {
            sprintf(ChIn[i].namChannel,"GE_%d",i);
            ChIn[i].type          = U_DAT_UNKNOWN;
            ChIn[i].SkipChannel   = true;
            ChIn[i].Red           = 0;
            ChIn[i].Green         = 0;
            ChIn[i].Blue          = 0;
        }
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].LT            = 1;
    }
    strncpy(PatName,"GE_NONAME",31);
    strncpy(PatID  ,"GE1234567890",31);

    EEGposTrue       = false;
    EEGlabelTrue     = false; 
    STIM             = false;
    if(nADC) GridADC = new UGrid(nADC);

    if( nADC && (GridADC==NULL || GridADC->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). Memory allocation for Grid. \n");
        return;
    }    
    if(ReadMarkers()!=U_OK)
        CI.AddToLog("WARNING: UMEEGDataGELog::UMEEGDataGELog(). Setting markers. \n");

    
/* Set the type specific grids*/
    error = UMEEGDataBase::UpdateSensorGrids();
    if(error==U_OK) SelectChannels((char*)NULL, (char*)NULL);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataGELog::UMEEGDataGELog(). Setting new Laplacian reference matrix \n");
}

UMEEGDataGELog::UMEEGDataGELog(const UMEEGDataGELog& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataGELog& UMEEGDataGELog::operator=(const UMEEGDataGELog &Data)
{
    if(this==NULL)
    {
        static UMEEGDataGELog M; M.error=U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataGELog::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataGELog::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    error         = Data.error;
    NPointsInFile = Data.NPointsInFile;
    sec           = Data.sec;
    min           = Data.min;
    hou           = Data.hou;
    day           = Data.day;
    mon           = Data.mon;
    yea           = Data.yea;
    NOffSet       = Data.NOffSet;
    Label         = Data.Label;
    
    if(NOffSet>0)
    {
        DataLineTab   =  new unsigned int[NOffSet];
        if(DataLineTab==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataGELog::operator=(). Memory allocation. \n");
            return *this;
        }
        for(int n=0; n<NOffSet; n++) DataLineTab[n] = Data.DataLineTab[n];
    }
    return *this;
}

const UString& UMEEGDataGELog::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataGELog-object\n");
        return Properties;
    }
    Properties  = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

double* UMEEGDataGELog::GetChannel_d(UEvent Begin, UEvent End, const char* Lab) const
{
    if(Lab==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataGELog::GetChannel_d(). NULL Label. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetChannel_d() : Arguments out of range: Begin.sample = %d  End.sample = %d  .\n", Begin.sample, End.sample);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    if(IsStringCompatible((const char*)(this->Label), Lab, false)==false)
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetChannel_d() : Label not present in file (%s). \n", Lab);
        return NULL;
    }

    double *data = new double[NSamples];
    if(!data)
    {
        delete[] data; 
        CI.AddToLog("ERROR UMEEGDataGELog::GetChannel_d() : memory allocation.\n");
        return NULL;
    }
    for(int ij=0; ij<NSamples; ij++) data[ij] = 0.;

    FILE* fp = fopen(DataFileName, "rt", true);
    if(fp==NULL)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataGELog::GetChannel_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  jbeg  = Begin.GetAbsSample(nsamp);
    int  itab  = jbeg/LINESTEP;
    int  nline = 0;///itab*LINESTEP  -1;
////    fseek(fp, DataLineTab[itab], SEEK_SET);
    
    int  jsamp = -1;
    char line[MAXLINE];
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsEmptyLine()==true || AA.IsCommentLine()==true) continue;

        nline++;
        if(nline<jbeg) continue;
        jsamp++;
        if(jsamp>=NSamples) break;

        data[jsamp] = AA.GetNextInt(-1000000);
    }
    fclose(fp);
    return data;
}

double* UMEEGDataGELog::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetEpoch_d() : Arguments out of range: Begin.sample = %d  End.sample = %d  .\n", Begin.sample, End.sample);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN  = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataGELog::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }
    return GetChannel_d(Begin, End, (const char*)Label);
}
int* UMEEGDataGELog::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataGELog::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}

ErrorType UMEEGDataGELog::ReadMarkers(void)
{
    delete Markers; Markers = NULL;

    UString Name;
    UString M;
    UString F(DataFileName.GetBaseName());
    bool CaseSense = false;
    if(F.GetNNumChar()==16 || F.GetNNumChar()==17)
    {
        if(F.IsBegining("ECG" ,CaseSense)) Name = "ECG" ;
        if(F.IsBegining("PPG" ,CaseSense)) Name = "ECG" ;
        if(F.IsBegining("RESP",CaseSense)) Name = "Resp";
        M = F;
        int off = M.GetFirstOccurance("Data", CaseSense);
        M.SetChar(off, 'T'); M.SetChar(off+1, 'r'); M.SetChar(off+2, 'i'); M.SetChar(off+3, 'g');
    }
    else
    {
        if(F.IsBegining("ECG" ,CaseSense)) {Name = "ECG" ; M = UString("TrigEcg")  + UString(((const char*) F)+7);}
        if(F.IsBegining("PPG" ,CaseSense)) {Name = "ECG" ; M = UString("TrigPpg")  + UString(((const char*) F)+7);}
        if(F.IsBegining("RESP",CaseSense)) {Name = "Resp"; M = UString("TrigResp") + UString(((const char*) F)+8);}
    }
    UFileName FileM = DataFileName.GetSiblingFileName((const char*)M);

    FILE* fp = fopen(FileM, "rt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataGELog::ReadMarkers(). Marker file name cannot be opened %s .\n", (const char*)FileM);
        return U_ERROR;
    }

    int NEvent = GetNLines(fp);
    if(NEvent<=0)
    {
        fclose(fp);
        CI.AddToLog("WARNING: UMEEGDataGELog::ReadMarkers(). No events fount in  %s .\n", (const char*)FileM);
        return U_OK;
    }
    UMarker Mark(Name, NEvent, 1, 200*256*256,"GE events", 0, false);
    int niev=0;
    while(1)
    {
        char line[100];
        if(GetLine(line, sizeof(line), fp)==NULL) break;
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine() || AA.IsCommentLine()) continue;
        int samp = AA.GetNextInt(-1);

        Mark.SetEvent(niev++, UEvent(samp, 0));
    }
    Mark.SetnEvents(niev);
    fclose(fp);

    Markers = new UMarkerArray(1, 1, 0, srate);
    if(Markers==NULL || Markers->GetError()!=U_OK || Markers->SetMarker(Mark, 0)!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("ERROR: UMEEGDataGELog::ReadMarkers(). Creating UMarkerArray-obkject. \n");
        return U_ERROR;
    }

    return U_OK;
}
