#ifndef _MEEGDATAGELOG_INCLUDED
#define _MEEGDATAGELOG_INCLUDED


#include "MEEGDataBase.h"
class UMarker;


class DLL_IO UMEEGDataGELog : public UMEEGDataBase
{
public:
    UMEEGDataGELog();
    UMEEGDataGELog(UFileName FileName);     
    UMEEGDataGELog(const UMEEGDataGELog& Data); 
    virtual ~UMEEGDataGELog();
    UMEEGDataGELog&        operator=(const UMEEGDataGELog &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    ErrorType              error;
    static const double    TACQ;
    int                    NPointsInFile;
    UString                Label;
    int                    sec;
    int                    min;
    int                    hou;
    int                    day;
    int                    mon;
    int                    yea;
    int                    NOffSet;
    unsigned int*          DataLineTab;

    ErrorType              ReadMarkers(void);
};

#endif// _MEEGDATAGELOG_INCLUDED
