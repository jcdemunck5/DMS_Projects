/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a MicroMed data file and taking only the necesssary    */
/*     part.                                                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-11-03   creation.
  JdM    29-12-03   Bug fix: GetEpoch_d(). Skip unselected channels
  JdM    30-12-03   Give labels default name that is "visible", MM_xx.
  JdM    01-06-04   GetEpoch_d(). Make consistent with getting common reference data.
  JdM    14-12-04   Occasionally ignore first character in the recognition of EEG labels
  JdM    27-12-04   Allow 4 bytes per sample (Head.Bytes==4)
  JdM    29-12-04   Updated (corrected?) recognition of non-EEG channels
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    06-03-05   Added ConvertAnalogMarkers() to convert analog markers to digital ones, and to correct the data samples
  JdM    21-04-05   declared some undeclared identifiers (for g++-compatibility)
  JdM    21-09-05   Added WriteMarkers(), obtained by splitting ConvertAnalogMarkers()
  JdM    26-10-05   Added GetChannel_d()
  JdM    15-01-06   Added EEG group-re-reference
  JdM    14-03-07   Bug Fix: WriteMarkers(). Testing number of events (MAX_TRIGG). Check for array-overflow of trigger[]
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    28-06-08   Allowed MicroMed HeaderType 3
  JdM    30-06-08   Read_EEG_Header(). Use "rb" iso "rb+" as second parameter
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    06-02-09   ReadMarkers(): also read markers as MM annotations
  JdM    09-09-09   Bug fix: WriteMarkers(). Start counting new events inside loop so that a new bit is used for every marker
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
  JdM    01-01-11   Detected ECG channel
  JdM    24-05-11   Allow SrateMult==0. Launch warning and set SrateMult=1.
  JdM    06-08-12   BUG Fix. UMEEGDataMM::UMEEGDataMM(). Of un-recognized channel types, wrong (null?) offsets were taken. In new code ALL channels are read, unknowns are treated as ADC. 
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    11-09-16   Moved reference layer information to Grid.cpp
*/

#include <string.h> 

#include "MEEGDataMM.h"
#include "Grid.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataMM::Properties = UString();


void UMEEGDataMM::SetAllMembersDefault(void)
{
    error          = U_OK;
    Properties     = UString();

    memset((void*)&Head,           0, sizeof(Micromed_Header_Type_4));
    memset((void*)&Code,           0, sizeof(Micromed_New_Code)       *MAX_CAN);
    memset((void*)&Parameters,     0, sizeof(Micromed_New_Electrode)  *MAX_LAB);
    memset((void*)&Note,           0, sizeof(Micromed_New_Annotation) *MAX_NOTE);
    memset((void*)&Flag,           0, sizeof(Micromed_New_Marker_Pair)*MAX_FLAG);
    memset((void*)&Segment,        0, sizeof(Micromed_New_Segment)    *MAX_SEGM);
    memset((void*)&B_Impedance,    0, sizeof(Micromed_New_Impedance)  *MAX_CAN);
    memset((void*)&E_Impedance,    0, sizeof(Micromed_New_Impedance)  *MAX_CAN);
    memset((void*)&Montage,        0, sizeof(Micromed_New_Montage)    *MAX_MONT);
    memset((void*)&Compression,    0, sizeof(Micromed_New_Compression));
    memset((void*)&Average        ,0, sizeof(Micromed_New_Average));
    memset((void*)&History_Sample ,0, sizeof(Micromed_New_Sample)*MAX_SAMPLE);
    memset((void*)&History        ,0, sizeof(Micromed_New_Montage)*MAX_HISTORY);
    memset((void*)&Digital_Video  ,0, sizeof(Micromed_New_Sample)*MAX_VIDEO_FILE);
    memset((void*)&EventA         ,0, sizeof(Micromed_New_Event));
    memset((void*)&EventB         ,0, sizeof(Micromed_New_Event));
    memset((void*)&Trigger        ,0, sizeof(Micromed_New_Trigger)*MAX_TRIGGER);
}

void UMEEGDataMM::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataMM::~UMEEGDataMM()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataMM::UMEEGDataMM() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataMM::UMEEGDataMM(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the MicroMed data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();
    
/* Read the header*/
    FILE* fp = Read_EEG_Header(FileName.GetFullFileName(),"rb",&Head,Code,Parameters,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,&Compression,&Average,History_Sample,History,Digital_Video,&EventA,&EventB,Trigger);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Cannot open file %s (rb+).\n",FileName.GetFullFileName());
        return;
    }
    int FileSize = GetFileSize(fp);
    fclose(fp);

    Head.Patient_Data.Surname[sizeof(Head.Patient_Data.Surname)-1] = 0;
    if(Head.Bytes!=2 && Head.Bytes!=4)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Number of bytes per sample should be 2 or 4. It is %d .\n",Head.Bytes);
        return;
    }
    if(Head.Multiplexer!=Head.Bytes*Head.Num_Chan)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Multiplexer should by equal to the number of channels times the number of bytes per channel. Multiplexer = %d, Num_Chan = %d, Bytes = %d.\n",Head.Multiplexer, Head.Num_Chan, Head.Bytes);
        return;
    }
    if(Head.Header_Type!=4 && Head.Header_Type!=3)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Header is of unsupprted type: Header_Type = %d .\n",Head.Header_Type);
        return;
    }
    if(Head.Rate_Min<=0.)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Invalid (basis) sample rate. SrateBasis = %f .\n", Head.Rate_Min);
        return;
    }

    ChIn           = new ChanInfo[MAXCHAN];
    GridAll        = new UGrid(MAXCHAN);

    if(!ChIn || !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataMM::UMEEGDataMM(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_MICROMED;
    DataFileName      = FileName;
    ContineousData    = true;
    DateTimeRec       = UDateTime(1900+Head.Date.Year, Head.Date.Month, Head.Date.Day, Head.Time.Hour, Head.Time.Min, Head.Time.Sec);
    nsamp             = 1;
    ntrial            =  ( FileSize - Head.Data_Start_Offset)/(Head.Bytes * Head.Num_Chan);
    if(ntrial<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Total number of samples out of range: ntrial = %d    .\n", ntrial);
        return;
    }
    NPreTrig          = 0;
    nAver             = 0;
    NchannelRaw       = Head.Num_Chan;
    NchannelTot       = NchannelRaw;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"MM_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

    double    SrateBasis  = Head.Rate_Min;
    int       SrateMult   = 0;
    ErrorType TestAllChan = U_OK;
    for(int i=0; i<NchannelRaw; i++)
    {
        Micromed_New_Electrode  P = Parameters[Code[i]];
        if(i==0) SrateMult        = P.Rate_Coefficient;

        if(P.Status==0) 
        {
            ChIn[i].SkipChannel   = true;
            continue;
        }
        SetBlankNull(P.Positive_Input_Label, 6);
        SetBlankNull(P.Negative_Input_Label, 6);
        if(P.Type&1)
        {
            if(IsStringCompatible(P.Positive_Input_Label, "*ecg*", false)==true)
            {
                ChIn[i].type = U_DAT_EKG; // Bipolar
            }
            else if(IsStringCompatible(P.Positive_Input_Label, "*ekg*", false)==true)
            {
                ChIn[i].type = U_DAT_EKG; // Bipolar
            }
            else if(IsStringCompatible(P.Positive_Input_Label, "*heart*", false)==true)
            {
                ChIn[i].type = U_DAT_EKG; // Bipolar
            }
            else if(IsStringCompatible(P.Positive_Input_Label,"*musc*", false)==true)
            {
                ChIn[i].type = U_DAT_EEG; // Bipolar
            }
            else if(IsStringCompatible(P.Positive_Input_Label,"*ADC*", false)==true)
            {
                ChIn[i].type = U_DAT_ADC; // Bipolar
            }
            else if(IsStringCompatible(P.Positive_Input_Label,"*EMG*", false)==true)
            {
                ChIn[i].type = U_DAT_EMG; // Bipolar
            }
            else 
            {
                CI.AddToLog("WARNING: UMEEGDataMM::UMEEGDataMM(). (Bipolar?) channel %s unknown, treated as ADC. \n",P.Positive_Input_Label);
                ChIn[i].type = U_DAT_ADC; // Bipolar
            }
        }
        strncpy(ChIn[i].namChannel, P.Positive_Input_Label, MIN(6, sizeof(ChIn[0].namChannel))-1); 
        
        if(ChIn[i].type == U_DAT_UNKNOWN)
        {
            GridAll->SetName(ChIn[i].namChannel, i);
            ChIn[i].SkipChannel = false;  
            if(UGrid::IsStandardEEGLabel(ChIn[i].namChannel)==true)  
            {
                ChIn[i].type = U_DAT_EEG;
                USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
                GridAll->SetSensor(&S,i);
                nEEG++;
            }
            else if(UGrid::IsStandardEEGLabelRefLay(ChIn[i].namChannel)==true)  
            {
                ChIn[i].type = U_DAT_EEG;
                USensor S    = UGrid::GetDefaultSensor(ChIn[i].namChannel);
                GridAll->SetSensor(&S, i);
                GridAll->SetGroupID(2, i);
                nEEG++;
            }
            else if(UGrid::IsStandardREFLabelRefLay(ChIn[i].namChannel)==true)  
            {
                ChIn[i].type = U_DAT_EEG;
                USensor S    = UGrid::GetDefaultSensor(ChIn[i].namChannel);
                GridAll->SetSensor(&S, i);
                GridAll->SetGroupID(3, i);
                nEEG++;
            }
        }
        else if(IsStringCompatible(ChIn[i].namChannel, "*EKG*",false)==true)  ChIn[i].type = U_DAT_EKG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*ECG*",false)==true)  ChIn[i].type = U_DAT_EKG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*EOG*",false)==true)  ChIn[i].type = U_DAT_EOG;
        else if(IsStringCompatible(ChIn[i].namChannel, "*EMG*",false)==true)  ChIn[i].type = U_DAT_EMG;
///        else if(IsStringCompatible(ChIn[i].namChannel, "*musc*")==true) ChIn[i].type = U_DAT_SKIP;
        else
        {
            ChIn[i].SkipChannel = true;  
            CI.AddToLog("Note: UMEEGDataMM::UMEEGDataMM(). Skipped channel with label %s \n", ChIn[i].namChannel);
        }
        if(P.Rate_Coefficient!=SrateMult)
        {
            CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Sampling frequency is not constant or 0. Rate_Coefficient = %d \n", P.Rate_Coefficient);
            TestAllChan = U_ERROR;
            break;
        }
        if(P.Logic_Maximum-P.Logic_Minimum+1==0)
        {
            CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Logic minimum a maximum are equal. \n");
            TestAllChan = U_ERROR;
            break;
        }
        ChIn[i].InGain = -(double)(P.Physic_Maximum-P.Physic_Minimum) / (double) (P.Logic_Maximum-P.Logic_Minimum+1);
        ChIn[i].Offset = -ChIn[i].InGain*P.Logic_Ground;
    }
    if(TestAllChan!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }

    strncpy(PatName,Head.Patient_Data.Surname,sizeof(PatName)-1);
    strncpy(PatID  ,"MM1234567890",31);

    if(SrateMult==0)
    {
        SrateMult = 1;
        CI.AddToLog("WARNING: UMEEGDataMM::UMEEGDataMM(). Invalid sample frequency multiplication factor (SrateMult = %d). Value set to 1. \n", SrateMult);
    }
    srate   = SrateBasis * SrateMult;

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

/* Read markers and classes */
    Markers = ReadMarkers();
    if(Markers==NULL)
        Markers = ConvertAnalogMarkers();
    if(Markers==NULL || Markers->GetError()!=U_OK)
    {
        delete Markers; Markers = NULL;
        CI.AddToLog("WARNING: UMEEGDataMM::UMEEGDataMM(). Cannot create UMarkerArray()-object. \n");
    }
    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataMM::UMEEGDataMM(). Setting new Laplacian reference matrix \n");
}

UMEEGDataMM::UMEEGDataMM(const UMEEGDataMM& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataMM.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataMM& UMEEGDataMM::operator=(const UMEEGDataMM &Data)
{
    if(this==NULL)
    {
        static UMEEGDataMM M; M.error=U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::operator=(). Argument has NULL address. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMM::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    memcpy(&Head, &(Data.Head), sizeof(Head));
    memcpy(&Code,           &(Data.Code          ), sizeof(Micromed_New_Code)       *MAX_CAN);
    memcpy(&Parameters,     &(Data.Parameters    ), sizeof(Micromed_New_Electrode)  *MAX_LAB);
    memcpy(&Note,           &(Data.Note          ), sizeof(Micromed_New_Annotation) *MAX_NOTE);
    memcpy(&Flag,           &(Data.Flag          ), sizeof(Micromed_New_Marker_Pair)*MAX_FLAG);
    memcpy(&Segment,        &(Data.Segment       ), sizeof(Micromed_New_Segment)    *MAX_SEGM);
    memcpy(&B_Impedance,    &(Data.B_Impedance   ), sizeof(Micromed_New_Impedance)  *MAX_CAN);
    memcpy(&E_Impedance,    &(Data.E_Impedance   ), sizeof(Micromed_New_Impedance)  *MAX_CAN);
    memcpy(&Montage,        &(Data.Montage       ), sizeof(Micromed_New_Montage)    *MAX_MONT);
    memcpy(&Compression,    &(Data.Compression   ), sizeof(Micromed_New_Compression));
    memcpy(&Average        ,&(Data.Average       ), sizeof(Micromed_New_Average));
    memcpy(&History_Sample ,&(Data.History_Sample), sizeof(Micromed_New_Sample)*MAX_SAMPLE);
    memcpy(&History        ,&(Data.History       ), sizeof(Micromed_New_Montage)*MAX_HISTORY);
    memcpy(&Digital_Video  ,&(Data.Digital_Video ), sizeof(Micromed_New_Sample)*MAX_VIDEO_FILE);
    memcpy(&EventA         ,&(Data.EventA        ), sizeof(Micromed_New_Event));
    memcpy(&EventB         ,&(Data.EventB        ), sizeof(Micromed_New_Event));
    memcpy(&Trigger        ,&(Data.Trigger       ), sizeof(Micromed_New_Trigger)*MAX_TRIGGER);

    return *this;
}

const UString& UMEEGDataMM::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties =UString(" ERROR in UMEEGDataMM-object \n");
        return Properties;
    }
    Properties = UString(Head.Bytes, " NbytesPerSample = %d \n");

    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');  
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}

double* UMEEGDataMM::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetChannel_d(). NULL Label. \n");
        return NULL;
    }
    int IChan = GetChannelIndex(Label);
    if(IChan<0 || IChan>=NchannelRaw)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetChannel_d(). Label not found: %s. \n", Label);
        return NULL;
    }

    if(Head.Bytes!=2 && Head.Bytes!=4)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetChannel_d() : Only 16 or 32 bits supported. \n");
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=1 ||
       End.sample   < 0 || End.sample   >=1) 
    {
        CI.AddToLog("ERROR UMEEGDataMM::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, 1);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataMM::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int nKAN = 1;

    double *data   = new double[NSamples*nKAN                  ];
    char   *buffer = new char  [NSamples*NchannelRaw*Head.Bytes];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataMM::GetChannel_d() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataMM::GetChannel_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int dataoff  = Head.Data_Start_Offset + Head.Bytes * NchannelRaw*Begin.trial;
    fseek(fp, dataoff, SEEK_SET);    
    fread(buffer, Head.Bytes, NSamples*NchannelRaw, fp); 
    fclose(fp);

    for(int j=0; j<NSamples; j++)
    {
        if(Head.Bytes==2)
        {
            data[j] = ChIn[IChan].Offset + ChIn[IChan].InGain*  * (unsigned short*) (buffer + Head.Bytes*(j*NchannelRaw+IChan));
        }
        else if(Head.Bytes==4)
        {
            data[j] = ChIn[IChan].Offset + ChIn[IChan].InGain*  * (unsigned int  *) (buffer + Head.Bytes*(j*NchannelRaw+IChan));
        }
    }
    delete[] buffer;
    
    return data;
}

double* UMEEGDataMM::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d(). Object NULL or erroneously set. \n");
        return NULL;
    }
    if(Head.Bytes!=2 && Head.Bytes!=4)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d() : Only 16 or 32 bits supported. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=1 ||
       End.sample   < 0 || End.sample   >=1) 
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, 1);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double          *data   = new double       [           NSamples*nKAN       ];
    unsigned char   *buffer = new unsigned char[Head.Bytes*NSamples*NchannelRaw];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataMM::GetEpoch_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int dataoff  = Head.Data_Start_Offset + Head.Bytes * NchannelRaw*Begin.trial;
    fseek(fp, dataoff, SEEK_SET);    
    fread(buffer, Head.Bytes, NSamples*NchannelRaw, fp); 
    fclose(fp);

    for(int j=0; j<NSamples; j++)
    {
        if(Head.Bytes==2)
        {
            for(int i=0,k=0; i<NchannelRaw; i++)
            {
                if(ChIn[i].type       !=Dtype) continue;
                if(ChIn[i].SkipChannel==true ) continue;
                data[k++ * NSamples + j] = ChIn[i].Offset + ChIn[i].InGain*  * (unsigned short*) (buffer + Head.Bytes*(j*NchannelRaw+i));
            }
        }
        else if(Head.Bytes==4)
        {
            for(int i=0,k=0; i<NchannelRaw; i++)
            {
                if(ChIn[i].type       !=Dtype) continue;
                if(ChIn[i].SkipChannel==true ) continue;
                data[k++ * NSamples + j] = ChIn[i].Offset + ChIn[i].InGain*  * (unsigned int*) (buffer + Head.Bytes*(j*NchannelRaw+i));
            }
        }
    }
    delete[] buffer;
    return data;
}

int* UMEEGDataMM::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    if(Head.Bytes!=2 && Head.Bytes!=4)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetTriggerEpoch() : Only 16 or 32 bits supported. \n");
        return NULL;
    }
    int Ntrig = GetNkan(U_DAT_STIM);
    if(Ntrig<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::GetTriggerEpoch() : No triggers present in file. \n");
        return NULL;
    }

    if(Begin.sample < 0 || Begin.sample >=1 ||
       End.sample   < 0 || End.sample   >=1) 
    {
        CI.AddToLog("ERROR UMEEGDataMM::GetTriggerEpoch() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, 1);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataMM::GetTriggerEpoch() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int nKAN = 1;

    int   *data   = new int [NSamples*nKAN                  ];
    char  *buffer = new char[NSamples*NchannelRaw*Head.Bytes];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataMM::GetTriggerEpoch() : memory allocation.\n");
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataMM::GetTriggerEpoch(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int dataoff  = Head.Data_Start_Offset + Head.Bytes * NchannelRaw*Begin.trial;
    fseek(fp, dataoff, SEEK_SET);    
    fread(buffer, Head.Bytes, NSamples*NchannelRaw, fp); 
    fclose(fp);

    for(int j=0; j<NSamples; j++)
    {
        data[j] = 0;
        int ibitTrig = 1;
        for(int i=0; i<NchannelRaw; i++)
        {
            if(ChIn[i].type!=U_DAT_STIM) continue;

            if(Head.Bytes==2)
            {
                if(((unsigned short*)buffer)[j*NchannelRaw+i]==65535) data[j] |= ibitTrig;
            }
            else
            {
                if(((unsigned int  *)buffer)[j*NchannelRaw+i]==65535) data[j] |= ibitTrig;
            }
            ibitTrig<<=1;
        }
    }
    delete[] buffer;
    
    return data;
}

UMarkerArray* UMEEGDataMM::ReadMarkers() const
{
    if(NchannelRaw<=0 || Head.Bytes<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ReadMarkers(). Invalid number of channels (%d) or number of bytes per sample (%d). \n", NchannelRaw, Head.Bytes);
        return NULL;
    }
    if(Head.Trigger_Area.Start_Offset<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ReadMarkers(). File offset (%d) out of range.\n", (int)Head.Trigger_Area.Start_Offset);
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ReadMarkers(). Opening file %s .\n", DataFileName.GetFullFileName());
        return NULL;
    }
    if(fseek(fp, Head.Trigger_Area.Start_Offset, SEEK_SET)!=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ReadMarkers(). Setting file pointer (offset = %d) .\n", (int)Head.Trigger_Area.Start_Offset);
        fclose(fp);
        return NULL;
    }

/* Read triggers*/
    for(int k=0; k<MAX_TRIGGER; k++)
    {
        fread((void*)&(Trigger[k].Sample), 4, 1, fp);
        fread((void*)&(Trigger[k].Type  ), 2, 1, fp);
    }
    fclose(fp);

/* Convert to Markers*/
#define NBIT 16
    UMarker Mark[NBIT];
    for(int k=0; k<NBIT; k++)
    {
        UString Name(k, "Bit%d");
        Mark[k] = UMarker((const char*)Name, 0, nsamp, 1, "MicroMed Bit Trigger", 0, false);
    }

    for(int ke=0; ke<MAX_TRIGGER; ke++)
    {
        if(Trigger[ke].Sample<0) continue;

        unsigned int bit = 1;
        for(int k=0; k<NBIT; k++)
        {
            if((bit&Trigger[ke].Type)) 
            {
                Mark[k].AddEvent(UEvent(Trigger[ke].Sample, 0));
            }
            bit = bit<<1;
        }
    }

    int Nmarker = 0;
    for(int k=0; k<NBIT; k++) 
        if(Mark[k].GetnEvents()>0) 
            Nmarker++;

    if(Nmarker<=0)
    {
        CI.AddToLog("Note: UMEEGDataMM::ReadMarkers(). There are no digital markers in the file. \n");
        return NULL;
    }
    
    UMarkerArray* MarkAr = new UMarkerArray(Nmarker, nsamp, 0, srate);
    if(MarkAr==NULL || MarkAr->GetError()!=U_OK)
    {
        delete   MarkAr;
        CI.AddToLog("ERROR: UMEEGDataMM::ReadMarkers(). Creation of UMarkerArray()-object. \n");
        return NULL;
    }
    int im=0;
    for(int k=0; k<NBIT; k++) 
        if(Mark[k].GetnEvents()>0) 
            MarkAr->SetMarker(Mark[k], im++);

/* Read markers the other way */
    int  Firstke   =  0;
    int  LastType  = -1;
    bool NewMark   =  false;
    while(NewMark==false)
    {
        NewMark = true;
        for(int ke=Firstke; ke<MAX_TRIGGER; ke++)
        {
            if(Trigger[ke].Sample <0) continue;
            if(Trigger[ke].Type  ==0) continue;
        
            if(NewMark==true)
            {
                if(Trigger[ke].Type==LastType) continue;

                Firstke  = ke;
                LastType = Trigger[ke].Type;
                NewMark  = false;

                UString Name(Trigger[ke].Type, "%d");
                UMarker M((const char *)Name, 0, 1, 255, "MicroMed Type Trigger", 0, true);
            
                M.AddEvent(UEvent(Trigger[ke].Sample, 0));
                MarkAr->AddMarker(&M);
            }
            else if(Trigger[ke].Type==LastType)
            {
                MarkAr->AddEvent(Nmarker, UEvent(Trigger[ke].Sample, 0));
            }
        }
    }        
    return MarkAr;
}

UMarkerArray* UMEEGDataMM::ConvertAnalogMarkers()
{
    if(NchannelRaw<=0 || (Head.Bytes!=2 && Head.Bytes!=4))
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ConvertAnalogMarkers(). Invalid number of channels (%d) or number of bytes per sample (%d). \n", NchannelRaw, Head.Bytes);
        return NULL;
    }
    if(Head.Trigger_Area.Start_Offset<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ConvertAnalogMarkers(). File offset (%d) out of range.\n", (int)Head.Trigger_Area.Start_Offset);
        return NULL;
    }

    FILE* fp = fopen(DataFileName, "rb+", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ConvertAnalogMarkers(). Opening file %s for read/write.\n", DataFileName.GetFullFileName());
        return NULL;
    }
    unsigned char* buffer = new unsigned char[3*Head.Bytes*NchannelRaw];
    UMarkerArray*  Mar    = new UMarkerArray(NchannelRaw, 1, 0, srate);
    if(!buffer || Mar==NULL || Mar->GetError()!=U_OK)
    {
        fclose(fp);
        delete[] buffer;
        delete   Mar;
        CI.AddToLog("ERROR: UMEEGDataMM::ConvertAnalogMarkers() : memory allocation.\n");
        return NULL;
    }
    memset(buffer, 0, 3*Head.Bytes*NchannelRaw);

    fseek(fp, Head.Data_Start_Offset, SEEK_SET);    
    for(int j=0; j<ntrial; j++)
    {
        unsigned char* pb = buffer+Head.Bytes*NchannelRaw;
        fseek(fp, Head.Data_Start_Offset+Head.Bytes*NchannelRaw*j, SEEK_SET);    
        fread(pb, Head.Bytes, 2*NchannelRaw, fp); 
        if(j==ntrial-1)     memset(pb+Head.Bytes*NchannelRaw, 0, Head.Bytes*NchannelRaw);

        for(int i=0; i<NchannelRaw; i++)
        {
            if( (Head.Bytes==2 && pb[2*i]==255 && pb[2*i+1]==255                 ) ||
                (Head.Bytes==4 && *(((unsigned int*)pb)+i) == 4194303))
            {
                if(Mar->GetMarker(i) && Mar->GetMarker(i)->GetnEvents()==0)
                {
                    UMarker M("NoName", 0, 1, i, "Analog trigger", 1, true);
                    if((GridAll->GetSensorPointer(i) && GridAll->GetName(i)))
                        M = UMarker(GridAll->GetName(i), 0, 1, i, "Analog trigger", 1, true);
                    Mar->SetMarker(M, i);
                }
                Mar->AddEvent(i, UEvent(j, 0));

                unsigned int ioff = ftell(fp);
                fseek(fp, Head.Data_Start_Offset+Head.Bytes*(NchannelRaw*j+i), SEEK_SET);    
                if(Head.Bytes==2)
                {
                    unsigned short newdat = 0;
                    if(j==0)             newdat =  *(unsigned short*) (pb+2*NchannelRaw+2*i);
                    else if(j==ntrial-1) newdat =  *(unsigned short*) (pb-2*NchannelRaw+2*i);
                    else                 newdat = (*(unsigned short*) (pb-2*NchannelRaw+2*i) +
                                                   *(unsigned short*) (pb+2*NchannelRaw+2*i))/2;
                    fwrite(&newdat, 2, 1, fp);
                }
                else
                {
                    unsigned int newdat = 0;
                    if(j==0)             newdat =  *(unsigned int*) (pb+4*NchannelRaw+4*i);
                    else if(j==ntrial-1) newdat =  *(unsigned int*) (pb-4*NchannelRaw+4*i);
                    else                 newdat = (*(unsigned int*) (pb-4*NchannelRaw+4*i) +
                                                   *(unsigned int*) (pb+4*NchannelRaw+4*i))/2;
                    fwrite(&newdat, 4, 1, fp);
                }
                fseek(fp, ioff, SEEK_SET);    
            }
        }
        memcpy(buffer, pb, Head.Bytes*NchannelRaw);
    }
    delete[] buffer;    
    fclose(fp);

    if(Mar->RemoveEmptyMarkers()!=U_OK || Mar->GetnMarkers()<=0 || Mar->SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::ConvertAnalogMarkers(). Removing empty markers, no markers left, or sorting events.\n");
        delete Mar; Mar = NULL;
    }
    if(WriteMarkers(Mar)!=U_OK)
    {
        CI.AddToLog("WARNING::UMEEGDataMM::ConvertAnalogMarkers(). Writing markers in digital form.\n");
    }
    return Mar;
}

ErrorType UMEEGDataMM::WriteMarkers(const UMarkerArray* Mar) 
{
    if(Mar==NULL || Mar->GetError()!=U_OK || Mar->GetnMarkers()<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers() : NULL or Invalid  markers.\n");
        return U_ERROR;
    }
    for(int im=0; im<Mar->GetnMarkers(); im++)
    {
        if(Mar->GetMarker(im)==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers() : Invalid NULL marker %d. \n", im);
            return U_ERROR;
        }
        if(Mar->GetMarker(im)->AreEventsSortedIncr()==false)
        {
            CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers() : Events of marker %s not sorted. \n", Mar->GetMarker(im)->GetMarkerName());
            return U_ERROR;
        }
    }
    if(NchannelRaw<=0 || (Head.Bytes!=2 && Head.Bytes!=4))
    {
        CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers(). Invalid number of channels (%d) or number of bytes per sample (%d). \n", NchannelRaw, Head.Bytes);
        return U_ERROR;
    }
    if(Head.Trigger_Area.Start_Offset<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers(). File offset (%d) out of range.\n", (int)Head.Trigger_Area.Start_Offset);
        return U_ERROR;
    }

    FILE* fp = fopen(DataFileName, "rb+", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers(). Opening file %s for read/write.\n", DataFileName.GetFullFileName());
        return U_ERROR;
    }
    
    for (int i=0; i<MAX_TRIGGER; i++)                                               
    {                                                                           
        Trigger[i].Sample=-1;                                                   
        Trigger[i].Type  = 0;                                                     
    }       

/* Convert to MM triggers */
    for(int im=0; im<Mar->GetnMarkers(); im++)
    {
        int nev = 0; /* Start counting inside marker-loop! */
        if(im>=16) 
        {
            if(im==16) 
                CI.AddToLog("WARNING: UMEEGDataMM::WriteMarkers(). Too many markers (%d). Only first 16 markers are written.\n", Mar->GetnMarkers());
            break;
        }
        const UMarker* M = Mar->GetMarker(im);
        if(M==NULL || M->GetError()!=U_OK) continue;

        for(int j=0; j<M->GetnSamples(); j++)
        {                
            int   jsamp = M->GetAbsSample(j);
            bool  news  = true;
            int   jev   = nev;
            for(int jt=0; jt<MIN(nev, MAX_TRIGGER); jt++)
                if(Trigger[jt].Sample == jsamp)
                {
                    jev  = jt;
                    news = false;
                    break;
                }
            if(news==true) nev++;
            if(nev>=MAX_TRIGGER) 
            {
                if(nev==MAX_TRIGGER) 
                    CI.AddToLog("WARNING: UMEEGDataMM::WriteMarkers(). Too many events. Only first %d events are written.\n", MAX_TRIGGER);
                continue;
            }
            short bit   = 1<<im;
            Trigger[jev].Sample = jsamp;                 
            Trigger[jev].Type  |= bit;                                                     
        }
    }
/* Write triggers*/
    if(fseek(fp, Head.Trigger_Area.Start_Offset, SEEK_SET)!=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMM::WriteMarkers(). Setting file pointer (offset = %d). Digital triggers not written. \n", (int)Head.Trigger_Area.Start_Offset);
        fclose(fp);
        return U_ERROR;
    }
    for(int k=0; k<MAX_TRIGGER; k++)
    {
        fwrite((void*)&(Trigger[k].Sample), 4, 1, fp);
        fwrite((void*)&(Trigger[k].Type  ), 2, 1, fp);
    }
    fclose(fp);
    return U_OK;
}
