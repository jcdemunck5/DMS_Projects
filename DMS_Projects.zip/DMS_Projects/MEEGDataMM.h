#ifndef _MEEGDATAMM_INCLUDED
#define _MEEGDATAMM_INCLUDED

#include "MEEGDataBase.h"
#include "MicroMed.h"

class DLL_IO UMEEGDataMM : public UMEEGDataBase
{
public:
    UMEEGDataMM();
    UMEEGDataMM(UFileName FileName);     
    UMEEGDataMM(const UMEEGDataMM& Data); 
    virtual ~UMEEGDataMM();
    UMEEGDataMM&                operator=(const UMEEGDataMM &Data);

    virtual ErrorType           GetError(void) const         {return error;}
    const UString&              GetProperties(UString Comment) const;

    virtual double*             GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*             GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*                GetTriggerEpoch(UEvent Begin, UEvent End) const;
    ErrorType                   WriteMarkers(const UMarkerArray* Mar);

protected:
    void                        SetAllMembersDefault(void);
    void                        DeleteAllMembers(ErrorType E);

private:
    static UString              Properties;
    ErrorType                   error;

/* MicroMed internal structure */
    Micromed_Header_Type_4      Head;
    Micromed_New_Code           Code[MAX_CAN];
    Micromed_New_Electrode      Parameters[MAX_LAB];
    Micromed_New_Annotation     Note[MAX_NOTE];
    Micromed_New_Marker_Pair    Flag[MAX_FLAG];
    Micromed_New_Segment        Segment[MAX_SEGM];
    Micromed_New_Impedance      B_Impedance[MAX_CAN];
    Micromed_New_Impedance      E_Impedance[MAX_CAN];
    Micromed_New_Montage        Montage[MAX_MONT];
    Micromed_New_Compression    Compression;
    Micromed_New_Average        Average;
    Micromed_New_Sample         History_Sample[MAX_SAMPLE];
    Micromed_New_Montage        History[MAX_HISTORY];
    Micromed_New_Sample         Digital_Video[MAX_VIDEO_FILE];
    Micromed_New_Event          EventA,EventB;
    Micromed_New_Trigger        Trigger[MAX_TRIGGER];

    UMarkerArray*               ReadMarkers(void) const;
    UMarkerArray*               ConvertAnalogMarkers(void);
};

#endif// _MEEGDATAMM_INCLUDED
