/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading .map file and taking only the                          */
/*     necesssary part.                                                          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    07-06-05   creation.
  JdM    15-01-06   Added EEG group-re-reference
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h>

#include "MEEGDataMap.h"
#include "Grid.h"
#include "AnalyzeLineExt.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */

#define MAXLINE 200
UString UMEEGDataMap::Properties = UString();

void UMEEGDataMap::SetAllMembersDefault(void)
{
    MapTitle    =  UString("No Title");
    Unit        =  UString("au");
    MapLabels   =  NULL;   // Strings explaining the meaning of each map
    TrialLabels =  NULL;   // Strings explaining the meaning of each trial
    offsetData  =  0;
}

void UMEEGDataMap::DeleteAllMembers(ErrorType E)
{
    if(MapLabels)
        for(int k=0; k<nsamp; k++) delete[] MapLabels[k];
    delete[] MapLabels;
    if(TrialLabels)
        for(int k=0; k<ntrial; k++) delete[] TrialLabels[k];
    delete[] TrialLabels;

    SetAllMembersDefault();
    error = E;
}

UMEEGDataMap::~UMEEGDataMap()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataMap::UMEEGDataMap() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataMap::UMEEGDataMap(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the ap file data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

/* Read first line of data file */    
    FILE*   fp = fopen(FileName, "rb", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }
    char line[MAXLINE];
    GetLine(line, sizeof(line), fp);
    UAnalyzeLine AA(line);
    if(strncmp(line,"MAPFILE",sizeof("MAPFILE")-1))
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). String %s not found in first line of %s \n", "MAPFILE", FileName.GetFullFileName());
        return;
    }

    unsigned int  FSize = GetFileSize(fp);
    unsigned int  ioff  = ftell(fp);
    char cp1            = getc(fp);
    char cp2            = getc(fp);
    while(cp1!=12 || cp2!=12)
    {
        cp1 = cp2;
        cp2 = getc(fp);
        if(ioff>=FSize)
        {
            CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Unexpected end of file in map-file : %s\n",FileName);
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            fclose(fp);
            return;
        }
        ioff++;
    }
    offsetData=ftell(fp);

/* Read data */
    rewind(fp); 

/* Read Header part*/
    bool MapLabInFile  = false;
    bool TriLabInFile  = false;
    bool GridInFile    = false;
    bool NormalsInFile = false;
    NchannelRaw        = -1;
    nsamp              = -1;     
    while(GetLine(line, sizeof(line), fp))
    {
        if(ftell(fp)>offsetData) break;
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;
        if(AA.IsEmptyLine()==true) continue;

        if(AA.IsIdentifierIs("UNIT"))
        {
            Unit = UString(AA.GetNextString(10, NULL));
        }
        if(AA.IsIdentifierIs("MAPTITLE"))
        {
            MapTitle = UString(AA.GetNextString(MAXLINE-10, NULL));
        }
        if(AA.IsIdentifierIs("NTRIAL")) 
        {
            ntrial = AA.GetNextInt(-1);
            if(ntrial<=0)
            {
                CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Number of trials out of range: ntrial = %d\n",ntrial);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
        }
        if(AA.IsStartList("GRID")==true)        GridInFile    = true;
        if(AA.IsStartList("NORMALS")==true)     NormalsInFile = true;
        if(AA.IsStartList("MAPLABELS")==true)   MapLabInFile  = true;
        if(AA.IsStartList("TRIALLABELS")==true) TriLabInFile  = true;
        if(AA.IsIdentifierIs("NCHANNEL")==true) NchannelRaw   = AA.GetNextInt(-1);
        if(AA.IsIdentifierIs("NMAP")==true)     nsamp         = AA.GetNextInt(-1);
        if(AA.IsIdentifierIs("DATATYPE")==true)     
        {
            if(strcmp(AA.GetNextString(10,line), "DOUBLE"))
            {
                CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Data type should be double, not %s  .\n",line);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                fclose(fp);
                return;
            }
            continue;
        }
    }
    NchannelTot = NchannelRaw;
    if(NchannelRaw<=0 || nsamp<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Number of channels/ number of maps out of range or not in file. NchannelRaw=%d nsamp=%d .\n",NchannelRaw,nsamp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(offsetData==0)
    {
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Data offsef not found. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(GridInFile==false)
    {
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Sensor grid is not in file. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }

    rewind(fp);
    GridAll = new UGrid(MAXCHAN);
    ChIn    = new ChanInfo[MAXCHAN];
    if(GridAll==NULL || GridAll->GetError()!=U_OK || ChIn==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Creating Grid .\n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(MapLabInFile==true)
    {
        MapLabels = new char*[nsamp];
        if(MapLabels==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). creating map labels.\n");
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            fclose(fp);
            return;
        }
        for(int k=0; k<nsamp; k++) 
        {
            MapLabels[k] = new char[sizeof(line)+1];
            if(MapLabels[k]) memset(MapLabels[k], 0, sizeof(line)+1);
        }
    }
    if(TriLabInFile==true)
    {
        TrialLabels = new char*[ntrial];
        if(TrialLabels==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). creating trial labels.\n");
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            fclose(fp);
            return;
        }
        for(int k=0; k<ntrial; k++) 
        {
            TrialLabels[k] = new char[sizeof(line)+1];
            if(TrialLabels[k]) memset(TrialLabels[k], 0, sizeof(line)+1);
        }
    }

/* Read the sensor information of map file.*/
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
    
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsStartList("GRID")==true)
        {
            int is =0;
            while(1)
            {
            {
                GetLine(line, sizeof(line), fp);
                UAnalyzeLineExt AA(line);
                if(AA.IsComment()==true) continue;
                if(AA.IsEmptyLine()==true) continue;
                if(AA.IsEndList())
                {
                    if(is!=NchannelRaw)
                    {
                        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Reading all sensor positions (is=%d).\n",is);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        fclose(fp);
                        return;
                    }
                    break;
                }
                UVector3 x = AA.GetNextVector3();
                GridAll->SetPosition(x, is);
                if(NormalsInFile==true)  GridAll->SetSensorType(USensor::U_SEN_VECTOR, is);
                else                     GridAll->SetSensorType(USensor::U_SEN_POINT , is);
                char Item[20] = "";
                strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
                GridAll->SetName(Item, is);
                is++;
            }
            }
        }
        if(AA.IsStartList("NORMALS")==true)
        {
            int is =0;
            while(1)
            {
            {
                GetLine(line, sizeof(line), fp);
                UAnalyzeLineExt AA(line);
                if(AA.IsComment()==true) continue;
                if(AA.IsEmptyLine()==true) continue;
                if(AA.IsEndList())
                {
                    if(is!=NchannelRaw)
                    {
                        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Reading all sensor orientations (is=%d).\n",is);
                        UMEEGDataBase::DeleteAllMembers(U_ERROR);
                        DeleteAllMembers(U_ERROR);
                        fclose(fp);
                        return;
                    }
                    break;
                }
                UVector3 x = AA.GetNextVector3();
                GridAll->SetOrientation(x, is);
                is++;
            }
            }
        }
        if(AA.IsStartList("MAPLABELS")==true)
        {
            for(int k=0; k<nsamp; k++)
            {
                GetLine(line, sizeof(line), fp);
                for(int kk=0; kk<sizeof(line)-1; kk++) 
                    if(line[kk]==10 || line[kk]==12) {line[kk] =0;break;}
                if(MapLabels[k])
                    strncpy(MapLabels[k], line, sizeof(line));
            }
        }
        if(AA.IsStartList("TRIALLABELS")==true)
        {
            for(int k=0; k<ntrial; k++)
            {
                GetLine(line, sizeof(line), fp);
                for(int kk=0; kk<sizeof(line)-1; kk++) 
                    if(line[kk]==10 || line[kk]==12) {line[kk] =0;break;}
                if(TrialLabels[k])
                    strncpy(TrialLabels[k], line, sizeof(line));
            }
        }
    }
    fclose(fp);


/* Copy general data and set defaults */   
    DataFormat        = U_DATFORM_MAP;
    srate             = 1000;
    DataFileName      = FileName;   

    ContineousData    = false;
    DateTimeRec       = UDateTime();
    NPreTrig          = 0;
    nAver             = 0;

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"MAP_%d",i);

        const char* Name = GridAll->GetName(i);
        if(i<NchannelRaw)  
        {
            strncpy(ChIn[i].namChannel, Name, sizeof(ChIn[i].namChannel)-1);
            if(UGrid::IsStandardMEGLabel(Name)==true)  
            {
                ChIn[i].type = U_DAT_MEG;
                GridAll->SetSensorType(USensor::U_SEN_GRAD, i);
                nMEG++;
            }
            else if(UGrid::IsStandardEEGLabel(Name)==true)  
            {
                ChIn[i].type = U_DAT_EEG;
                GridAll->SetSensorType(USensor::U_SEN_EEG, i);
                nEEG++;
            }
        }
        else
        {
            sprintf(ChIn[i].namChannel,"MAP_%d",i);
            ChIn[i].type  = U_DAT_UNKNOWN;
        }
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = true;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    if(nMEG) GridMEG = new UGrid(nMEG);
    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nMEG && (GridMEG==NULL || GridMEG->GetError()!=U_OK) ||
        nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);

        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Memory allocation for Grid. \n");
        error = U_ERROR;
        return;
    }        
    EEGposTrue   = false;
    EEGlabelTrue = true; 

    strncpy(PatName,"MAP_NONAME",31);
    strncpy(PatID  ,"MAP1234567890",31);

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    error = U_OK;

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataMap::UMEEGDataMap(). Setting new Laplacian reference matrix \n");
}

UMEEGDataMap::UMEEGDataMap(const UMEEGDataMap& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataMap.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataMap& UMEEGDataMap::operator=(const UMEEGDataMap &Data)
{
    if(this==NULL)
    {
        static UMEEGDataMap M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMap::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataMap::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    MapTitle    =  Data.MapTitle;
    Unit        =  Data.Unit;
    offsetData  =  Data.offsetData;

    if(Data.MapLabels && Data.nsamp>=0)
    {
        if(SetMapLabels(Data.MapLabels)!=U_OK)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            error  = U_ERROR;
            CI.AddToLog("ERROR: UMEEGDataMap::operator=(). Copying MapLabels(). \n");
            return *this;
        }
    }

/* Detete old part */
        
    if(Data.TrialLabels && Data.ntrial>=0)
    {
        if(SetTrialLabels(Data.TrialLabels)!=U_OK)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            error  = U_ERROR;
            CI.AddToLog("ERROR: UMEEGDataMap::operator=(). Copying TrialLabels. \n");
            return *this;
        }
    }
    return *this;
}

const UString& UMEEGDataMap::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataMap-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}


double* UMEEGDataMap::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataMap::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataMap::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataMap::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data   = new double[NSamples*nKAN];
    double *buffer = new double[nsamp];

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataMap::GetEpoch_d(). Cannot open file: %s  .\n", (const char*)DataFileName);
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;
    if(nAver>1 && End.trial!=Begin.trial) ForceFirstTrial = true;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        double *DataChan  = data+nSamplesDone;
/* Skip nSampSkip samples from the beginning of this trial */
        int    nSampSkip  = 0; 
        if(itrial==Begin.trial) nSampSkip = Begin.sample;

/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp; 
        if(itrial==Begin.trial && itrial==End.trial) 
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        for(int i=0;i<NchannelRaw;i++)
        {
            if(ChIn[i].type       !=Dtype) continue;
            if(ChIn[i].SkipChannel==true ) continue;

            if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0))
            {
                for(int j=0;j<nSampTrial;j++) DataChan[j] = 0.;    
            }
            else
            {
                fseek(fp, offsetData+8*(nsamp*(NchannelRaw*itrial+i)+nSampSkip), SEEK_SET);
                fread(buffer,nSampTrial,8,fp);
                SwapArray(buffer, nSampTrial, true);                    
                for(int j=0;j<nSampTrial;j++) DataChan[j] = buffer[j];    
            }
            DataChan += NSamples;        
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fp);

    return data;
}

int* UMEEGDataMap::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataMap::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}


ErrorType UMEEGDataMap::SetMapLabels(const char* const* Labels)
{
    if(Labels==NULL || nsamp<=0) return U_ERROR;

    if(MapLabels)
        for(int k=0; k<nsamp; k++) delete[] MapLabels[k];
    delete[] MapLabels;

    MapLabels = new char*[nsamp];
    if(MapLabels==NULL) return U_ERROR;

    for(int k=0; k<nsamp; k++)
    {
        if(Labels[k]==NULL) 
        {
            MapLabels[k] = NULL;
            continue;
        }

        size_t nbytes = strlen(Labels[k]);
        MapLabels[k]  = new char[nbytes+1];
        if(MapLabels[k]==NULL) return U_ERROR;

        strcpy(MapLabels[k], Labels[k]);
    }

    return U_OK;
}

ErrorType UMEEGDataMap::SetTrialLabels(const char* const* Labels)
{
    if(Labels==NULL || ntrial<=0) return U_ERROR;

    if(TrialLabels)
        for(int k=0; k<ntrial; k++) delete[] TrialLabels[k];
    delete[] TrialLabels;

    TrialLabels = new char*[ntrial];
    if(TrialLabels==NULL) return U_ERROR;

    for(int k=0; k<ntrial; k++)
    {
        if(Labels[k]==NULL) 
        {
            TrialLabels[k] = NULL;
            continue;
        }
        size_t   nbytes = strlen(Labels[k]);
        TrialLabels[k]  = new char[nbytes+1];
        if(TrialLabels[k]==NULL) return U_ERROR;

        strcpy(TrialLabels[k], Labels[k]);
    }
    return U_OK;
}
