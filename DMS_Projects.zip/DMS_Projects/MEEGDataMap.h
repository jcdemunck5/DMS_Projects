#ifndef _MEEGDATAMAP_INCLUDED
#define _MEEGDATAMAP_INCLUDED

#include "MEEGDataBase.h"

class DLL_IO UMEEGDataMap : public UMEEGDataBase
{
public:
    UMEEGDataMap();
    UMEEGDataMap(UFileName FileName);     
    UMEEGDataMap(const UMEEGDataMap& Data); 
    virtual ~UMEEGDataMap();
    UMEEGDataMap&          operator=(const UMEEGDataMap &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    virtual const UString& GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    UString                MapTitle;
    UString                Unit;
    char**                 MapLabels;   // Strings explaining the meaning of each map
    char**                 TrialLabels; // Strings explaining the meaning of each trial
    int                    offsetData;

    ErrorType              SetMapLabels(const char* const* Labels);
    ErrorType              SetTrialLabels(const char* const* Labels);
};

#endif// _MEEGDATAMAP_INCLUDED
