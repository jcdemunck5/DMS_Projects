/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a NeoroScan data file and taking only the necesssary   */
/*     part.                                                                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    20-11-03   creation.
  JdM    30-12-03   Give labels default name that is "visible", NS_xx.
  JdM    01-06-04   GetEpoch_d(). Make consistent with getting common reference data.
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    15-01-06   Added EEG group-re-reference
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    19-12-07   Bug Fix. Constructor: set error=U_ERROR on error condition
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h>

#include "MEEGDataNS.h"
#include "Grid.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataNS::Properties = UString();

static const int Nbytes = 4;

void UMEEGDataNS::SetAllMembersDefault(void)
{
    error = U_OK;
    memset(&Head, 0, sizeof(Head));
}

void UMEEGDataNS::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataNS::~UMEEGDataNS()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataNS::UMEEGDataNS() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataNS::UMEEGDataNS(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the NeuroScan data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();
    
    if(FileName.HasExtension("cnt")==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). File has wrong extension. Filename = %s .\n",FileName.GetFullFileName());
        return;                         
    }
    FILE* fp = fopen(FileName,"rb", false);
    if(fp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Cannot open file %s .\n",FileName.GetFullFileName());
        return;                         
    }
    fread(&Head.rev,                20,  1,  fp);
    fread(&Head.type,                1,  1,  fp);
    fread(&Head.PatID,              20,  1,  fp);
    fread(&Head.Operator,           20,  1,  fp);
    fread(&Head.Docter,             20,  1,  fp);
    fread(&Head.Referral,           20,  1,  fp);
    fread(&Head.Hospital,           20,  1,  fp);
    fread(&Head.PatName,            20,  1,  fp);
    fread(&Head.Age,                 2,  1,  fp);
    fread(&Head.Sex,                 1,  1,  fp);
    fread(&Head.Hand,                1,  1,  fp);
    fread(&Head.Medication,         20,  1,  fp);
    fread(&Head.Catagory,           20,  1,  fp);
    fread(&Head.SubjectState,       20,  1,  fp);
    fread(&Head.SessionLabel,       20,  1,  fp);
    fread(&Head.Date,               10,  1,  fp);
    fread(&Head.Time,               12,  1,  fp);
    fread(&Head.Reserved4,         115,  1,  fp);
    fread(&Head.CompSweeps,          2,  1,  fp);
    fread(&Head.AcceptedSweeps,      2,  1,  fp);
    fread(&Head.RejectedSweeps,      2,  1,  fp);
    fread(&Head.PointsPerWaveform,   2,  1,  fp);
    fread(&Head.NChan,               2,  1,  fp);
    fread(&Head.Reserved5,           3,  1,  fp);
    fread(&Head.VarianceIncluded,    1,  1,  fp);
    fread(&Head.SampleRate,          2,  1,  fp);
    fread(&Head.CalScale,            8,  1,  fp);
    fread(&Head.Reserved6,         111,  1,  fp);
    fread(&Head.DisplayMin,          4,  1,  fp);
    fread(&Head.DisplayMax,          4,  1,  fp);
    fread(&Head.EpochStart,          4,  1,  fp);
    fread(&Head.EpochEnd,            4,  1,  fp);
    fread(&Head.Reserved7,         351,  1,  fp);
    fread(&Head.NumSamples,          4,  1,  fp);
    fread(&Head.Reserved8,          18,  1,  fp);
    fread(&Head.EventTableOffseset,  4,  1,  fp);
    fread(&Head.NsecondsPerPage,     4,  1,  fp);
    fread(&Head.ChannelOffset,       4,  1,  fp); // =NsampTrial??
    fread(&Head.AutoCorrectDCflag,   1,  1,  fp);
    fread(&Head.DCthreshold,         1,  1,  fp);

    Head.PatID[sizeof(Head.PatID)-1]     = 0;
    Head.PatName[sizeof(Head.PatName)-1] = 0;
    
    if(Head.ChannelOffset==0)
    {
        Head.ChannelOffset=1;
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Head.ChannelOffset set to 1 .\n", (int)Head.ChannelOffset);
    }
    if(Head.ChannelOffset!=1)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Unsupported Head.ChannelOffset (=%d) .\n", (int)Head.ChannelOffset);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(Head.NChan<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Number of channels out of range: NChan = %d .\n", Head.NChan);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    if(Head.SampleRate<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Sample rate out of range: Head.SampleRate = %f .\n", Head.SampleRate);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    ChIn           = new ChanInfo[MAXCHAN];
    GeneralComment = new char[3+sizeof(Head.SessionLabel)];
    GridAll        = new UGrid(MAXCHAN);
    
    if(!ChIn    || !GeneralComment ||
       !GridAll || GridAll->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataNS::UMEEGDataNS(). memory allocation. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }

/* Copy general data and set defaults */
    DataFormat     = U_DATFORM_NEUROSCAN;
    DataFileName   = FileName;
    ContineousData = true;
    DateTimeRec    = UDateTime(atoi(6+Head.Date), atoi(3+Head.Date), atoi(Head.Date), atoi(Head.Time), atoi(3+Head.Time), atoi(6+Head.Time));

    strncpy(PatName,Head.PatName,sizeof(PatName)-1);
    strncpy(PatID  ,Head.PatID,  sizeof(PatID)-1);

    srate          = Head.SampleRate;    
    nsamp          = Head.ChannelOffset;
    ntrial         = (Head.EventTableOffseset - 900 - Head.NChan*ELECTRSIZE) / (Head.NChan*Nbytes);
    if(ntrial<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Total number of samples out of range: PointsPerWaveform = %d , CompSweeps = %d    .\n", Head.PointsPerWaveform, Head.CompSweeps);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fclose(fp);
        return;
    }
    NPreTrig       = 0;
    nAver          = 0;
    Head.SessionLabel[sizeof(Head.SessionLabel)-1]=0;
    GeneralComment = UString(Head.SessionLabel);

    NchannelRaw    = Head.NChan;
    NchannelTot    = NchannelRaw;

    for(int i=0; i<MAXCHAN; i++) 
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"NS_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true; 

/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;
    for(int i=0; i<NchannelRaw; i++)
    {
        NeuroScanElect Elec;
        fread(&(Elec.Label),          10,  1,  fp);
        fread(&(Elec.Reserved1),       5,  1,  fp);
        fread(&(Elec.Nobservations),   2,  1,  fp);
        fread(&(Elec.Reserved2),      30,  1,  fp);
        fread(&(Elec.BaseLineOffset),  2,  1,  fp);
        fread(&(Elec.Reserved3),      10,  1,  fp);
        fread(&(Elec.Sensitivity),     4,  1,  fp);
        fread(&(Elec.Reserved4),       8,  1,  fp);
        fread(&(Elec.CalibCoef),       4,  1,  fp);

        ChIn[i].type   =  U_DAT_UNKNOWN;  
        ChIn[i].InGain =  Elec.Sensitivity * Elec.CalibCoef/204.8;
        ChIn[i].Offset = -ChIn[i].InGain*Elec.BaseLineOffset;
        strncpy(ChIn[i].namChannel, Elec.Label, 10);

        USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
        GridAll->SetSensor(&S,i);
        ChIn[i].SkipChannel = false;  
        if(UGrid::IsStandardEEGLabel(ChIn[i].namChannel)==true)  
        {
            ChIn[i].type = U_DAT_EEG;
            nEEG++;
        }
///        else if(IsStringCompatible(ChIn[i].namChannel, "*EKG*")==true)  ChIn[i].type = U_DAT_ECG;
///        else if(IsStringCompatible(ChIn[i].namChannel, "*ECG*")==true)  ChIn[i].type = U_DAT_ECG;
///        else if(IsStringCompatible(ChIn[i].namChannel, "*EOG*")==true)  ChIn[i].type = U_DAT_EOG;
///        else if(IsStringCompatible(ChIn[i].namChannel, "*EMG*")==true)  ChIn[i].type = U_DAT_SKIP;
///        else if(IsStringCompatible(ChIn[i].namChannel, "*musc*")==true) ChIn[i].type = U_DAT_SKIP;
        else
        {
            ChIn[i].SkipChannel = true;  
            CI.AddToLog("Note: UMEEGDataNS::UMEEGDataNS(). Skipped channel with label %s \n", ChIn[i].namChannel);
        }
    }
    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Memory allocation for Grid. \n");
        fclose(fp);
        return;
    }        

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    Markers = GetMarkersFromFile(fp, &error);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Setting new Laplacian reference matrix \n");
    
    if(error==U_OK)
        CI.AddToLog("Note: UMEEGDataNS::UMEEGDataNS(). Succesfully read file %s \n",FileName.GetFullFileName());
}

UMEEGDataNS::UMEEGDataNS(const UMEEGDataNS& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataNS.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataNS& UMEEGDataNS::operator=(const UMEEGDataNS &Data)
{
    if(this==NULL)
    {
        static UMEEGDataNS M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataNS::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    memcpy(&Head, &(Data.Head), sizeof(Head));

    return *this;
}

const UString& UMEEGDataNS::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataNS-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

double* UMEEGDataNS::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=1 ||
       End.sample   < 0 || End.sample   >=1) 
    {
        CI.AddToLog("ERROR: UMEEGDataNS::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, 1);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR: UMEEGDataNS::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataNS::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double          *data   = new double       [       NSamples*nKAN       ];
    unsigned char   *buffer = new unsigned char[Nbytes*NSamples*NchannelRaw];
    if(!data || !buffer)
    {
        delete[] data;
        delete[] buffer;
        CI.AddToLog("ERROR UMEEGDataNS::GetEpoch_d() : memory allocation.\n");
        return NULL;
    } 

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] buffer;
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataNS::GetTrial_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int dataoff  = 900 + NchannelRaw*ELECTRSIZE + Nbytes * NchannelRaw*Begin.trial;
    fseek(fp, dataoff, SEEK_SET);    
    fread(buffer, Nbytes, NSamples*NchannelRaw, fp); 
    fclose(fp);

    for(int j=0; j<NSamples; j++)
    {
        if(Begin.GetAbsSample(1) + j>=ntrial) 
        {
            for(int i=0,k=0; i<NchannelRaw; i++)
            {
                if(ChIn[i].type!=U_DAT_EEG) continue;
                data[k++ * NSamples + j] = 0;
            }
        }
        else
            for(int i=0,k=0; i<NchannelRaw; i++)
            {
                if(ChIn[i].type       !=Dtype) continue;
                if(ChIn[i].SkipChannel==true) continue;
                data[k++ * NSamples + j] = ChIn[i].Offset + ChIn[i].InGain *  *(int*) (buffer + Nbytes*(j*NchannelRaw+i));
            }
    }
    delete[] buffer;
    
    return data;
}


UMarkerArray* UMEEGDataNS::GetMarkersFromFile(FILE*fp, ErrorType* E) const
{
/* Read events */
    if(E) *E=U_OK;
    int FileSize   = GetFileSize(fp);
    if(Head.EventTableOffseset<=0 || Head.EventTableOffseset>=FileSize)
    {
        CI.AddToLog("WARNING: UMEEGDataNS::GetMarkersFromFile(). Invalid Event pointer. No events are read. EventTableOffseset = %d  . \n", (int)Head.EventTableOffseset);
        return NULL;
    }
    if(fseek(fp, Head.EventTableOffseset, SEEK_SET))
    {
        if(E) *E=U_ERROR;
        CI.AddToLog("ERROR: UMEEGDataNS::GetMarkersFromFile(). Setting Event pointer. No events are read. EventTableOffseset = %d  . \n", (int)Head.EventTableOffseset);
        return NULL;
    }
    
    NeuroScanTag Tag;
    fread(&(Tag.TagType), 1,  1,  fp);
    fread(&(Tag.Size),    4,  1,  fp);
    fread(&(Tag.Offset),  4,  1,  fp);
    if(Tag.TagType!=1 && Tag.TagType!=2)
    {
        CI.AddToLog("WARNING: UMEEGDataNS::GetMarkersFromFile(). Events type not supported. (Tag.TagType=%d). No events read. \n", (int)Tag.TagType);
        return NULL;
    }
    
    if(Tag.Size%EVENTSIZE2)
    {
        if(E) *E=U_ERROR;
        CI.AddToLog("ERROR: UMEEGDataNS::GetMarkersFromFile(). Invalid size of event table. Size = %d .  \n", (int) Tag.Size);
        return NULL;
    }

    if(Tag.Size/EVENTSIZE2<=0)
    {
        if(E) *E=U_ERROR;
        CI.AddToLog("WARNING: UMEEGDataNS::UMEEGDataNS(). Number of events =%d). No events read. \n", (int) (Tag.Size/EVENTSIZE2) );
        return NULL;
    }

    NeuroScanEvent2* EventArray = new NeuroScanEvent2[Tag.Size/EVENTSIZE2];
    if(EventArray==NULL)
    {
        if(E) *E=U_ERROR;
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Memory allocation in event array. Nevent = %d . \n", (int) (Tag.Size/EVENTSIZE2) );
        return NULL;
    }
    
    int Nevent = Tag.Size/EVENTSIZE2;
    for(int k=0; k<Nevent; k++)
    {
        fread(&(EventArray[k].StimType),       2,  1,  fp);
        fread(&(EventArray[k].KeyBoard),       1,  1,  fp);
        fread(&(EventArray[k].KeyPad_Accept),  1,  1,  fp);
        fread(&(EventArray[k].Offset),         4,  1,  fp);
        fread(&(EventArray[k].Type),           2,  1,  fp);
        fread(&(EventArray[k].Code),           2,  1,  fp);
        fread(&(EventArray[k].Latency),        4,  1,  fp);
        fread(&(EventArray[k].EpochEvent),     1,  1,  fp);
        fread(&(EventArray[k].Accept),         1,  1,  fp);
        fread(&(EventArray[k].Accuracy),       1,  1,  fp);
    }

/* Convert events to UMarkerArray */
#define NBIT 8

    UMarker Mark[NBIT];
    for(int k=0; k<NBIT; k++)
    {
        char Name[100];
        sprintf(Name, "Bit%d",k);
        Mark[k] = UMarker(Name, 0, nsamp, k, "NeuroScan Event", 0, false);
    }

    int StartOffset = 900 + NchannelRaw*ELECTRSIZE;
    for(int ke=0; ke<Nevent; ke++)
    {
        unsigned int bit = 1;
        for(int k=0; k<NBIT; k++)
        {
            if((bit&EventArray[ke].KeyPad_Accept)) 
            {
                int j = (EventArray[ke].Offset - StartOffset)/(NchannelRaw*Nbytes);
                Mark[k].AddEvent(UEvent(j, 0));
            }
            bit = bit<<1;
        }
    }

    int Nmarker = 0;
    for(int k=0; k<NBIT; k++) 
        if(Mark[k].GetnEvents()>1) 
            Nmarker++;
    
    UMarkerArray* MarkAr = new UMarkerArray(Nmarker, nsamp, 0, srate);
    if(MarkAr==NULL || MarkAr->GetError()!=U_OK)
    {
        delete[] EventArray;
        delete   MarkAr;
        if(E) *E=U_ERROR;
        CI.AddToLog("ERROR: UMEEGDataNS::UMEEGDataNS(). Creation of UMarkerArray()-object. \n");
        return NULL;
    }
    int im=0;
    for(int k=0; k<NBIT; k++) 
        if(Mark[k].GetnEvents()>1) 
            MarkAr->SetMarker(Mark[k], im++);
    return MarkAr;
}
