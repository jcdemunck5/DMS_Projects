#ifndef _MEEGDATANS_INCLUDED
#define _MEEGDATANS_INCLUDED

#include "MEEGDataBase.h"
#include "NeuroScan.h"

class DLL_IO UMEEGDataNS : public UMEEGDataBase
{
public:
    UMEEGDataNS();
    UMEEGDataNS(UFileName FileName);     
    UMEEGDataNS(const UMEEGDataNS& Data); 
    virtual ~UMEEGDataNS();
    UMEEGDataNS&           operator=(const UMEEGDataNS &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
////    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    ErrorType              error;

/* NeuroScan internal structure */
    NeuroScanSetUp         Head;
    UMarkerArray*          GetMarkersFromFile(FILE*fp, ErrorType* E) const;
};

#endif// _MEEGDATANS_INCLUDED
