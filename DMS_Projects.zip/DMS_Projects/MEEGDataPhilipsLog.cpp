/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading an MRI log file of Philips scanner                     */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    24-01-08   creation
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    13-05-08   Read files more general first strings (test '(SWID ' iso '(SWID 123')
  JdM    14-08-08   Use DataLineTab[] table to speed up reading of data
  JdM    23-08-08   Create Marker array
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h> 

#include "MEEGDataPhilipsLog.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataPhilipsLog::Properties = UString();

const char*  UMEEGDataPhilipsLog::MarkerCollumnName   = "mark";

#define MAXLINE        (MAX_PHILIPSCOLLUMN*20) 
#define DEFAULT_SRATE   500.
#define MAXMARKERIN     16

void UMEEGDataPhilipsLog::SetAllMembersDefault(void)
{
    error        = U_OK;
    iColMarker   = -1;
    NCollumn     =  0;
    NDataLineTab =  0;
    DataLineTab  =  NULL;

    memset(LabelNames, 0, MAX_PHILIPSCOLLUMN*MAX_PHILPSLABEL);
}

void UMEEGDataPhilipsLog::DeleteAllMembers(ErrorType E)
{
    delete[] DataLineTab;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataPhilipsLog::~UMEEGDataPhilipsLog()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataPhilipsLog::UMEEGDataPhilipsLog() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the Philips log file called Filename and store the relevant data in 
    the base class, cq this class.

## Kempenhaeghe, Release r1v5 (SWID 123)
## Fri 18-01-2008 12:14:47
## 0 0 0 0 0 0 0 0 0
## Dockable table = FALSE
# v1raw v2raw  v1 v2  ppu resp  gx gy gz mark
0 0  0 0  4349 -20  0 0 0 0000
0 0  0 0  4349 -20  0 0 0 0000
0 0  0 0  4349 -20  0 0 0 0000
0 0  0 0  4349 -20  0 0 0 0000

 */ 
{
    SetAllMembersDefault();
 
/* Read first line of data file */    
    FILE*   fp = fopen(FileName, "rt", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }
    int NLines   =  GetNLines(fp);
    NDataLineTab =  1 + NLines/LINESTEP;
    DataLineTab  =  new unsigned int[NDataLineTab];
    if(DataLineTab==NULL)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). Memory allocation. NLines = %d .\n", NLines);
        return;
    }
    for(int n=0; n<NDataLineTab; n++) DataLineTab[n] = 0;

    char line[MAXLINE];
    GetLine(line, MAXLINE, fp);
    if(strstr(line, UMEEGDataBase::FILEID_PHILLOG)==NULL)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). File is not a Philips log file (First line = %s) Line should contain ID '%s'\n", line, UMEEGDataBase::FILEID_PHILLOG);
        return;
    } 
    GetLine(line, MAXLINE, fp);
    DateTimeRec = UDateTime(line+6);
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line+1, MAXLINE);
        if(AA.IsEmptyLine()==true || AA.IsCommentLine()==true) continue;
        
        NCollumn = AA.GetNCollumn();
        if(NCollumn>MAX_PHILIPSCOLLUMN)
        {
            CI.AddToLog("WARNING: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). Too Many collumns (%d), Maximum = %d \n", NCollumn, MAX_PHILIPSCOLLUMN);
            NCollumn = MAX_PHILIPSCOLLUMN;
        }
        for(int ic=0; ic<NCollumn; ic++)
        {
            const char* Lab = AA.GetNextString(MAX_PHILPSLABEL-1, NULL);
            if(Lab)
            {
                strncpy(LabelNames[ic], Lab, MAX_PHILPSLABEL-1);
                if(IsStringCompatible(Lab, MarkerCollumnName, false)==true) iColMarker = ic;
            }
            else
            {
                UString DefLab(ic, "Label_%d");
                strncpy(LabelNames[ic], DefLab, MAX_PHILPSLABEL-1);
            }
        }
        break;
    }
    if(iColMarker>=0)
    {
        int NMarker    = 2;
        int NSampT     = 1;
        Markers        = new UMarkerArray(NMarker, NSampT, 0, DEFAULT_SRATE);
        if(Markers && Markers->GetError()==U_OK)
        {
            UMarker M1("0001", 0, NSampT, 0, "mark = 1", 0, true);
            Markers->SetMarker(M1, 0);
            UMarker M2("0020", 0, NSampT, 0, "mark = 20", 0, true);
            Markers->SetMarker(M2, 1);
        }
        else
        {
            delete Markers; Markers = NULL;
            CI.AddToLog("WARNING: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). Creating UMarkerArray.\n");
        }
    }

    unsigned int ioff  = ftell(fp);
    int          itab  = 0;
    int          Nline = 0;
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsEmptyLine()==false && AA.IsCommentLine()==false)
        {
            if(Nline%LINESTEP==0) DataLineTab[itab++] = ioff;
            
            if(Markers)
            {
                int val = AA.GetCollumn_i(iColMarker, 0);
                if(val== 1) 
                    Markers->AddEvent(0, UEvent(Nline,0));
                if(val==20) 
                    Markers->AddEvent(1, UEvent(Nline,0));
            }            
            Nline++;
        }
        ioff  = ftell(fp);
    }
    fclose(fp);

    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_PHILLOG;
    DataFileName      = FileName;   

    ContineousData    = true;
    DateTimeRec       = UDateTime();
    nsamp             = 1;
    ntrial            = Nline;
    NPreTrig          = 0;
    nAver             = 0;
    NchannelRaw       = NCollumn;
    NchannelTot       = NchannelRaw;
    srate             = DEFAULT_SRATE;
    nMEG = nEEG       = 0;
    nADC = nREF       = 0;

    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"PHIL_%d",i);
        if(i<NCollumn && i!=iColMarker)
        {
            strncpy(ChIn[i].namChannel, LabelNames[i], sizeof(ChIn[0].namChannel)-1);
            ChIn[i].type          = U_DAT_ADC;
            ChIn[i].SkipChannel   = false;
            ChIn[i].Red           = 0;
            ChIn[i].Green         = 0;
            ChIn[i].Blue          = 255;

            USensor  S(UVector3(), UVector3(), UVector3(), USensor::U_SEN_POINT, ChIn[i].namChannel);
            GridAll->SetSensor(&S, i);
            nADC++;
        }        
        else if(i==iColMarker)
        {
            sprintf(ChIn[i].namChannel,"Stim");
            ChIn[i].type          = U_DAT_STIM;
            ChIn[i].SkipChannel   = true;
            ChIn[i].Red           = 0;
            ChIn[i].Green         = 255;
            ChIn[i].Blue          = 0;
        }
        else
        {
            sprintf(ChIn[i].namChannel,"PHIL_%d",i);
            ChIn[i].type          = U_DAT_UNKNOWN;
            ChIn[i].SkipChannel   = true;
            ChIn[i].Red           = 0;
            ChIn[i].Green         = 0;
            ChIn[i].Blue          = 0;
        }
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].LT            = 1;
    }
    strncpy(PatName,"PHIL_NONAME",31);
    strncpy(PatID  ,"PHIL1234567890",31);

    EEGposTrue       = false;
    EEGlabelTrue     = false; 
    STIM             = (iColMarker>=0);
    if(nADC) GridADC = new UGrid(nADC);

    if( nADC && (GridADC==NULL || GridADC->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). Memory allocation for Grid. \n");
        return;
    }    
    
/* Set the type specific grids*/
    error = UMEEGDataBase::UpdateSensorGrids();
    if(error==U_OK) SelectChannels((char*)NULL, (char*)NULL);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(). Setting new Laplacian reference matrix \n");
}

UMEEGDataPhilipsLog::UMEEGDataPhilipsLog(const UMEEGDataPhilipsLog& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataPhilipsLog& UMEEGDataPhilipsLog::operator=(const UMEEGDataPhilipsLog &Data)
{
    if(this==NULL)
    {
        static UMEEGDataPhilipsLog M; M.error=U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    
    iColMarker   = Data.iColMarker;
    NCollumn     = Data.NCollumn;
    memcpy(LabelNames, Data.LabelNames, MAX_PHILIPSCOLLUMN*MAX_PHILPSLABEL);

    NDataLineTab =  Data.NDataLineTab;
    DataLineTab  =  new unsigned int[NDataLineTab];

    if(NDataLineTab>0)
    {
        if(DataLineTab==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataPhilipsLog::operator=(). Memory allocation. \n");
            return *this;
        }
        for(int n=0; n<NDataLineTab; n++) DataLineTab[n] = Data.DataLineTab[n];
    }
    return *this;
}

const UString& UMEEGDataPhilipsLog::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataPhilipsLog-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

double* UMEEGDataPhilipsLog::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Label==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetChannel_d(). NULL Label. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetChannel_d() : Arguments out of range: Begin.sample = %d  End.sample = %d  .\n", Begin.sample, End.sample);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

    int  icollumn = -1;
    int  ichan    = 0;
    for(int ic=0, i=0; ic<NCollumn; ic++)
    {
        if(ic==iColMarker) continue;
        if(ChIn[i].SkipChannel==false) 
        {
            if(IsStringCompatible(Label, LabelNames[ic], false)==true)
            {
                icollumn = ic;
                break;
            }
        }
        i++;
    }
    if(icollumn<0 || icollumn>=NCollumn)
    {
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetChannel_d(). Label %d not found or not selected. \n", Label);
        return NULL;
    }
    double *data = new double[NSamples];
    if(!data)
    {
        delete[] data; 
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetChannel_d() : memory allocation.\n");
        return NULL;
    }
    for(int ij=0; ij<NSamples; ij++) data[ij] = 0.;

    FILE* fp = fopen(DataFileName, "rt", true);
    if(fp==NULL)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetChannel_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  jbeg  = Begin.GetAbsSample(nsamp);
    int  itab  = jbeg/LINESTEP;
    int  nline = itab*LINESTEP  -1;
    fseek(fp, DataLineTab[itab], SEEK_SET);
    
    int  jsamp = -1;
    char line[MAXLINE];
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsEmptyLine()==true || AA.IsCommentLine()==true) continue;

        nline++;
        if(nline<jbeg) continue;
        jsamp++;
        if(jsamp>=NSamples) break;

        data[jsamp] = AA.GetCollumn_i(icollumn, -1);
    }
    fclose(fp);
    return data;
}

double* UMEEGDataPhilipsLog::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetEpoch_d() : Arguments out of range: Begin.sample = %d  End.sample = %d  .\n", Begin.sample, End.sample);
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN  = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data = new double[NSamples*nKAN];
    if(!data)
    {
        delete[] data; 
        CI.AddToLog("ERROR UMEEGDataPhilipsLog::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }
    for(int ij=0; ij<NSamples*nKAN; ij++) data[ij] = 0.;

    FILE* fp = fopen(DataFileName, "rt", true);
    if(fp==NULL)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetEpoch_d(). Cannot open file: %s  .\n",DataFileName.GetFullFileName());
        return NULL;
    }

    int  Select[MAX_PHILIPSCOLLUMN];
    int  ichan = 0;
    for(int ic=0; ic<NCollumn; ic++)
    {
        bool        found = false;
        const char* Lab   = LabelNames[ic];
        for(int i=0; i<NchannelRaw; i++)
        {
            if(ChIn[i].SkipChannel==true || ChIn[i].type!=Dtype) continue; 
            if(strcmp(ChIn[i].namChannel, Lab)) continue;

            found = true;
            break;
        }
        if(found)
        {
            Select[ic] = ichan;
            ichan++;
        }
        else
        {
            Select[ic] = -1;
        }
    }

    int  jbeg  = Begin.GetAbsSample(nsamp);
    int  itab  = jbeg/LINESTEP;
    int  nline = itab*LINESTEP  -1;
    fseek(fp, DataLineTab[itab], SEEK_SET);
    
    int  jsamp = -1;
    char line[MAXLINE];
    while(GetLine(line, MAXLINE, fp))
    {
        UAnalyzeLine AA(line, MAXLINE);
        if(AA.IsEmptyLine()==true || AA.IsCommentLine()==true) continue;

        nline++;
        if(nline<jbeg) continue;
        jsamp++;
        if(jsamp>=NSamples) break;

        for(int ic=0; ic<NCollumn; ic++)
        {
            int idat = AA.GetNextInt(0);
            if(Select[ic]<0) continue;

            data[Select[ic]*NSamples+jsamp] = idat;
        }        
    }
    fclose(fp);

    if(jsamp!=NSamples)
    {
        delete[] data; 
        CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetEpoch_d(). Not all samples read (jsamp=%d, NSamples=%d)  .\n",jsamp, NSamples);
        return NULL;
    }


    return data;
}
int* UMEEGDataPhilipsLog::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataPhilipsLog::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}

