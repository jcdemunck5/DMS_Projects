#ifndef _MEEGDATAPHILIPSLOG_INCLUDED
#define _MEEGDATAPHILIPSLOG_INCLUDED


#include "MEEGDataBase.h"
class UMarker;

#define MAX_PHILIPSCOLLUMN 10 // MUST BE SMALLER OR EQUAL TO   UMEEGDataBase::MAXADC
#define MAX_PHILPSLABEL    20 // MUST peferrably be equal to   sizeof(ChIn[0].namChannel))
#define LINESTEP           20 

class DLL_IO UMEEGDataPhilipsLog : public UMEEGDataBase
{
public:
    UMEEGDataPhilipsLog();
    UMEEGDataPhilipsLog(UFileName FileName);     
    UMEEGDataPhilipsLog(const UMEEGDataPhilipsLog& Data); 
    virtual ~UMEEGDataPhilipsLog();
    UMEEGDataPhilipsLog&   operator=(const UMEEGDataPhilipsLog &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    ErrorType              error;
    static const char*     MarkerCollumnName; 
    int                    iColMarker;
    int                    NCollumn;
    int                    NDataLineTab;
    unsigned int*          DataLineTab;
    char                   LabelNames[MAX_PHILIPSCOLLUMN][MAX_PHILPSLABEL];
};

#endif// _MEEGDATAPHILIPSLOG_INCLUDED
