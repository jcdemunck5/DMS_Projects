/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a TMSI data file and taking only the necesssary.       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    12-02-13   creation.
  JdM    04-04-13   GetTriggerEpoch(). Removed warning: uninitialized local variable 'i' .
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    27-11-14   Changed algorithm to recognize data type from label name (added "ExG" and "AUX")
*/

#include <string.h>

#include "MEEGDataTMSI.h"
#include "MarkerArray.h"
#include "Grid.h"

/* Inititalize static const parameters. */
UString UMEEGDataTMSI::Properties = UString();

static const bool     IntelData = true;

#define SIZE_TMSI_HEADER            217
#define SIZE_TMSI_SIGNAL_HEADER     136
#define SIZE_TMSI_BLOCK_HEADER       86

void UMEEGDataTMSI::SetAllMembersDefault(void)
{
    memset((void*)&hdr, ' ', sizeof(TMSI_HEADER));
    Experiment     = UString();
    TMSIchan       = NULL;
    Properties     = UString();
}

void UMEEGDataTMSI::DeleteAllMembers(ErrorType E)
{
    delete[] TMSIchan;
    SetAllMembersDefault();
    error = E;
}

UMEEGDataTMSI::~UMEEGDataTMSI()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataTMSI::UMEEGDataTMSI() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataTMSI::UMEEGDataTMSI(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the EDF data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();

/* Read the header*/
    memset((void*)&hdr, 0, sizeof(hdr));
    FILE*   fp = fopen(FileName, "rb", false);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTMSI::UMEEGDataTMSI(). File cannot be opened: %s \n",(const char*)FileName);
        return;
    }

/* Read the general header*/
    DataFileName   = FileName;
    DataFormat     = U_DATFORM_TMSI;
    ContineousData = true;

    fread(&hdr.FileID      , sizeof(hdr.FileID), 1, fp);
    hdr.Version            = ReadBinaryShort(IntelData, fp); // 203
    fread(&hdr.Measurement , sizeof(hdr.Measurement), 1, fp);
    hdr.SampFreq           = ReadBinaryShort(IntelData, fp); // SR
    hdr.SampFreqStored     = ReadBinaryShort(IntelData, fp);
    fread(&hdr.SampFreqUnit, sizeof(hdr.SampFreqUnit), 1, fp);
    hdr.NSignal            = ReadBinaryShort(IntelData, fp); // NS
    hdr.NSampTotal         = ReadBinaryInt  (IntelData, fp); // NP
    hdr.Reserve1           = ReadBinaryInt  (IntelData, fp);
    hdr.RecDate.year       = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.month      = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.day        = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.dayweek    = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.hour       = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.minute     = ReadBinaryShort(IntelData, fp);
    hdr.RecDate.second     = ReadBinaryShort(IntelData, fp);
    hdr.NDataBlock         = ReadBinaryInt  (IntelData, fp); // NB = [NP/PB]
    hdr.NSampBlock         = ReadBinaryShort(IntelData, fp); // PB
    hdr.BlockSize          = ReadBinaryShort(IntelData, fp); // SD = 2 * PB * NS
    hdr.DeltaComp          = ReadBinaryShort(IntelData, fp); 
    fread(&hdr.Reserve2     , sizeof(hdr.Reserve2), 1, fp);

    if(hdr.Version!=203)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTMSI::UMEEGDataTMSI(). Invalid header version number %s (should be 203). \n", hdr.Version);
        CI.AddToLog("                                       srate = %f \n", srate);
        return;
    }
    Experiment  = UString(hdr.Measurement+1, hdr.Measurement[0]);
    Experiment.ReplaceBlankSpace(false);
    ntrial      = hdr.NDataBlock;
    nsamp       = hdr.NSampBlock;
    srate       = 0;
    if(!hdr.SampFreqUnit) srate = hdr.SampFreqStored; else {if(hdr.SampFreqStored>0) srate = 1./hdr.SampFreqStored;}
    if(hdr.NDataBlock<=0 || hdr.NSignal<=0 || hdr.NSignal>MAXCHAN || nsamp<=0 || srate <=0. || hdr.BlockSize%2)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTMSI::UMEEGDataTMSI(). Invalid header parameters: hdr.NSignal=%d, hdr.NDataBlock=%d and", hdr.NSignal, hdr.NDataBlock);
        CI.AddToLog("                                       srate = %f \n", srate);
        return;
    }
    DateTimeRec   = UDateTime(hdr.RecDate.year, hdr.RecDate.month, hdr.RecDate.day, hdr.RecDate.hour, hdr.RecDate.minute, hdr.RecDate.second);
    NPreTrig      = 0;
    nAver         = 0;
       
    EEGposTrue    = false;
    EEGlabelTrue  = true; 
    ChIn          = new ChanInfo[MAXCHAN];
    GridAll       = new UGrid(MAXCHAN);
    TMSIchan      = new TMSI_CHANNEL[hdr.NSignal];

    if(!TMSIchan || !ChIn    || 
       !GridAll  || GridAll->GetError()!=U_OK)
    {
        fclose(fp);
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataTMSI::UMEEGDataTMSI(). Memory allocation. \n");
        return;
    }
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"TMSI_%d",i);
        ChIn[i].type          = U_DAT_UNKNOWN;
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].SkipChannel   = false;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    fseek(fp, SIZE_TMSI_HEADER, SEEK_SET);

    STIM        = false;
    NchannelRaw = 0;
    for(int n=0; n<hdr.NSignal; n++, NchannelRaw++)
    {
        TMSI_SIGNAL_HEADER chhdr1;
        memset((void*)&chhdr1, 0, sizeof(TMSI_SIGNAL_HEADER));
        
        fread(&chhdr1.Name      , sizeof(chhdr1.Name    ), 1, fp);
        fread(&chhdr1.Reserve1  , sizeof(chhdr1.Reserve1), 1, fp);
        fread(&chhdr1.Unit      , sizeof(chhdr1.Unit    ), 1, fp);
        chhdr1.UnitMin     = ReadBinaryFloat(IntelData, fp);
        chhdr1.UnitMax     = ReadBinaryFloat(IntelData, fp);
        chhdr1.DataMin     = ReadBinaryFloat(IntelData, fp);
        chhdr1.DataMax     = ReadBinaryFloat(IntelData, fp);
        chhdr1.Index       = ReadBinaryShort(IntelData, fp);
        chhdr1.Offset      = ReadBinaryShort(IntelData, fp);
        fread(&chhdr1.Reserve2  , sizeof(chhdr1.Reserve2), 1, fp);

        TMSIchan[NchannelRaw].BlockOffset = n; //chhdr1.Index;

        if(chhdr1.Name[1]=='(' && (chhdr1.Name[2]=='L'||chhdr1.Name[2]=='l') && chhdr1.Name[4]==')')
        {
            TMSI_SIGNAL_HEADER chhdr2;
            memset((void*)&chhdr2, 0, sizeof(TMSI_SIGNAL_HEADER));
            
            fread(&chhdr2.Name      , sizeof(chhdr2.Name    ), 1, fp);
            fread(&chhdr2.Reserve1  , sizeof(chhdr2.Reserve1), 1, fp);
            fread(&chhdr2.Unit      , sizeof(chhdr2.Unit    ), 1, fp);
            chhdr2.UnitMin     = ReadBinaryFloat(IntelData, fp);
            chhdr2.UnitMax     = ReadBinaryFloat(IntelData, fp);
            chhdr2.DataMin     = ReadBinaryFloat(IntelData, fp);
            chhdr2.DataMax     = ReadBinaryFloat(IntelData, fp);
            chhdr2.Index       = ReadBinaryShort(IntelData, fp);
            chhdr2.Offset      = ReadBinaryShort(IntelData, fp);
            fread(&chhdr2.Reserve2  , sizeof(chhdr2.Reserve2), 1, fp);
            if(NOT(chhdr2.Name[1]=='(' && (chhdr2.Name[2]=='H'||chhdr2.Name[2]=='h') && chhdr2.Name[4]==')'))
            {
                fclose(fp);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR UMEEGDataTMSI::UMEEGDataTMSI(). (Lo) and (Hi) signals expected in pairs. \n");
                return;
            }
            if(chhdr1.UnitMin!=chhdr2.UnitMin || chhdr1.UnitMax!=chhdr2.UnitMax ||
               chhdr1.DataMin!=chhdr2.DataMin || chhdr1.DataMax!=chhdr2.DataMax)
            {
                fclose(fp);
                UMEEGDataBase::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR UMEEGDataTMSI::UMEEGDataTMSI(). Scaling parameters different for parired signals. \n");
                return;
            }
            TMSIchan[NchannelRaw].NByte       = 4;
            memset(ChIn[NchannelRaw].namChannel, 0            ,     sizeof(ChIn[NchannelRaw].namChannel));
            memcpy(ChIn[NchannelRaw].namChannel, chhdr1.Name+5, MIN(sizeof(ChIn[NchannelRaw].namChannel), sizeof(chhdr1.Name)-5)); 
            n++;
        }
        else
        {
            memset(ChIn[NchannelRaw].namChannel, 0            ,     sizeof(ChIn[NchannelRaw].namChannel));
            memcpy(ChIn[NchannelRaw].namChannel, chhdr1.Name+1, MIN(sizeof(ChIn[NchannelRaw].namChannel), sizeof(chhdr1.Name)-1)); 

            TMSIchan[NchannelRaw].NByte       = 2;
            ChIn[NchannelRaw].type            = U_DAT_STIM;
            STIM                              = true;
        }
        double Gain        = 0.;
        if(chhdr1.DataMax != chhdr1.DataMin) 
            Gain  = (chhdr1.UnitMax-chhdr1.UnitMin) /(chhdr1.DataMax-chhdr1.DataMin);
        
        ChIn[NchannelRaw].GainFact            = Gain;
        ChIn[NchannelRaw].Offset              = chhdr1.UnitMin - chhdr1.UnitMin*Gain;
        ChIn[NchannelRaw].SkipChannel         = false;
    }
    NchannelTot = NchannelRaw;

    fclose(fp);
    if(NchannelRaw<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataTMSI::UMEEGDataTMSI(). NchannelRaw out ofrange: %d.\n", NchannelRaw);
        return;
    }


/* set channel information  */
    nMEG = nEEG = nADC = nREF = 0;

/* set type and namChannel */    
    for(int i=0; i<NchannelRaw; i++)
    {
        ChIn[i].type = U_DAT_UNKNOWN;
        if(ChIn[i].SkipChannel==true) continue;

        USensor::SensorType ST        = USensor::U_SEN_POINT;
        bool                CaseSense = false;
        UString Label(ChIn[i].namChannel);
        if(Label.IsContaining("EEG", CaseSense)==true || Label.IsContaining("ExG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EEG; 
            ST           = USensor::U_SEN_EEG;
            nEEG++;
        }
        else if(Label.IsContaining("EKG", CaseSense)==true ||
                Label.IsContaining("ECG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EKG; 
        }
        else if(Label.IsContaining("EOG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EOG; 
        }
        else if(Label.IsContaining("EMG", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_EMG; 
        }
        else if(Label.IsContaining("AUX", CaseSense)==true || Label.IsContaining("Resp", CaseSense)==true)
        {
            ChIn[i].type = U_DAT_ADC; 
        }

        if(ChIn[i].type==U_DAT_UNKNOWN)
        {
            if(UGrid::IsStandardEEGLabel(Label)==true) {ChIn[i].type = U_DAT_EEG; ST = USensor::U_SEN_EEG ; nEEG++;}
            if(UGrid::IsStandardMEGLabel(Label)==true) {ChIn[i].type = U_DAT_MEG; ST = USensor::U_SEN_GRAD; nMEG++;}
        }
        if(ChIn[i].type==U_DAT_UNKNOWN) ChIn[i].type=U_DAT_ADC;

        USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
        GridAll->SetSensor(&S, i);
    }

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataTMSI::UMEEGDataTMSI(). Setting new Laplacian reference matrix \n");
}

UMEEGDataTMSI::UMEEGDataTMSI(const UMEEGDataTMSI& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataTMSI.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataTMSI& UMEEGDataTMSI::operator=(const UMEEGDataTMSI &Data)
{
    if(this==NULL)
    {
        static UMEEGDataTMSI M; M.error = U_ERROR;
        return M;
    }
    if(&Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTMSI::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTMSI::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    memcpy(&hdr, &(Data.hdr), sizeof(hdr));
    Experiment = Data.Experiment;
    if(Data.TMSIchan && Data.hdr.NSignal>0)
    {
        TMSIchan = new TMSI_CHANNEL[Data.hdr.NSignal];
        if(TMSIchan==NULL)
        {
            UMEEGDataBase::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMEEGDataTMSI::operator=(). Memory allocation, Data.hdr.NSignal = %d   . \n", Data.hdr.NSignal);
            return *this;
        }
        for(int n=0; n<Data.hdr.NSignal; n++)
        {
            TMSIchan[n].BlockOffset = Data.TMSIchan[n].BlockOffset;
            TMSIchan[n].NByte       = Data.TMSIchan[n].NByte;
        }
    }
    return *this;
}

const UString& UMEEGDataTMSI::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties =UString(" ERROR in UMEEGDataTMSI-object \n");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(hdr.Version," VersionNumber    = %d \n");
    Properties += UString(            " Experiment       = ") + Experiment + UString(" \n");
    Properties += UMEEGDataBase::GetProperties("  ");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');  
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}

double* UMEEGDataTMSI::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     
    if(Dtype == U_DAT_MEG) return MEG data,
    else if(Dtype == U_DAT_EEG) return EEG data,
    else if(Dtype == U_DAT_ADC) return ADC data,
    else return NULL

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetEpoch_d() : Object not prperly set. \n");
        return NULL;
    }
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetEpoch_d() : Arguments out of range. \n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data   = new double[NSamples*nKAN];
    if(!data)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }
    for(int ij=0; ij<NSamples*nKAN; ij++) data[ij] = 0.;

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataTMSI::GetTrial_d(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
        if(itrial<0 || itrial>=ntrial || (ForceFirstTrial==true && itrial!=0)) continue;

/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp; 
        if(itrial==Begin.trial && itrial==End.trial) 
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        int Offset     = SIZE_TMSI_HEADER 
                       + hdr.NSignal* SIZE_TMSI_SIGNAL_HEADER 
                       + itrial     *(SIZE_TMSI_BLOCK_HEADER+hdr.BlockSize) 
                       + SIZE_TMSI_BLOCK_HEADER;
        int nSampSkip  = (itrial!=Begin.trial) ? 0 : Begin.sample;

        fseek(fp, Offset, SEEK_SET);
        fseek(fp, nSampSkip*hdr.NSignal*2, SEEK_CUR);

        for(int j=0;j<nSampTrial;j++)
        {
            double *DataChan  = data + nSamplesDone + j;
            for(int i=0; i<NchannelRaw;i++)
            {
                if(ChIn[i].SkipChannel==true  || ChIn[i].type!=Dtype)
                {
                    fseek(fp, TMSIchan[i].NByte, SEEK_CUR);
                    continue;
                }
                if(TMSIchan[i].NByte==4)  *DataChan = ReadBinaryFloat(IntelData, fp);
                else                      *DataChan = ReadBinaryShort(IntelData, fp);

                DataChan += NSamples;
            }
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fp);

    return data;
}

int* UMEEGDataTMSI::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetTriggerEpoch() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetTriggerEpoch() : Arguments : Begin is located after End\n");
        return NULL;
    }

    CI.AddToLog("ERROR UMEEGDataTMSI::GetTriggerEpoch() : Function not yet implemented. \n");
    int ichan=-1;
    for(int i=0; i<NchannelRaw; i++)
    {
        if(TMSIchan[i].NByte!=2) continue;
        ichan = i;
        break;
    }
    if(ichan<0)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetTriggerEpoch() : No trigger signals present.\n");
        return NULL;
    }

    int NSkipBefore = 0;
    int NSkipAfter  = 0;
    for(int i=0; i<NchannelRaw;i++)
    {
        if(i<ichan) NSkipBefore += TMSIchan[i].NByte;
        if(i>ichan) NSkipAfter  += TMSIchan[i].NByte;
    }

    int *data   = new int[NSamples];
    if(!data)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetTriggerEpoch() : memory allocation.\n");
        return NULL;
    }
    for(int j=0; j<NSamples; j++) data[j] = 0;

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataTMSI::GetTriggerEpoch(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp; 
        if(itrial==Begin.trial && itrial==End.trial) 
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        int Offset     = SIZE_TMSI_HEADER 
                       + hdr.NSignal* SIZE_TMSI_SIGNAL_HEADER 
                       + itrial     *(SIZE_TMSI_BLOCK_HEADER+hdr.BlockSize) 
                       + SIZE_TMSI_BLOCK_HEADER;
        int nSampSkip  = (itrial!=Begin.trial) ? 0 : Begin.sample;

        fseek(fp, Offset, SEEK_SET);
        fseek(fp, nSampSkip*hdr.NSignal*2, SEEK_CUR);

        for(int j=0;j<nSampTrial;j++)
        {
            int *DataChan  = data + nSamplesDone + j;
            fseek(fp, NSkipBefore, SEEK_CUR);
            if(TMSIchan[ichan].NByte==4)  *DataChan = ReadBinaryFloat(IntelData, fp);
            else                          *DataChan = ReadBinaryShort(IntelData, fp);
            fseek(fp, NSkipAfter , SEEK_CUR);
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fp);

    return data;
}

double* UMEEGDataTMSI::GetChannel_d(UEvent Begin, UEvent End, const char* Label) const
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetChannel_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetChannel_d() : Arguments : Begin is located after End\n");
        return NULL;
    }

/* Select the correct channel index. */
    if(Label==NULL || *Label==0) 
    {
        CI.AddToLog("WARNING UMEEGDataTMSI::GetChannel_d() : NULL label argument.\n");
        return NULL;
    }
    int ichan = -1;
    for(int i=0;i<NchannelRaw; i++) 
        if(!strcmp(Label,ChIn[i].namChannel)) 
        {
            ichan = i;
            break;
        }
    if(ichan<0)
    {
        CI.AddToLog("WARNING UMEEGDataTMSI::GetChannel_d() : required label %s not present.\n",Label);
        return NULL; // Label[] not present.
    }

    int NSkipBefore = 0;
    int NSkipAfter  = 0;
    for(int i=0; i<NchannelRaw;i++)
    {
        if(i<ichan) NSkipBefore += TMSIchan[i].NByte;
        if(i>ichan) NSkipAfter  += TMSIchan[i].NByte;
    }

    double *data   = new double[NSamples];
    if(!data)
    {
        CI.AddToLog("ERROR UMEEGDataTMSI::GetChannel_d() : memory allocation.\n");
        return NULL;
    }
    for(int j=0; j<NSamples; j++) data[j] = 0.;

    FILE* fp = fopen(DataFileName, "rb", true);
    if(fp==NULL)
    {
        delete[] data;
        CI.AddToLog("ERROR: UMEEGDataTMSI::GetChannel_d(). Cannot open file: %s  .\n",(const char*)DataFileName);
        return NULL;
    }

    int  nSamplesDone    = 0;
    bool ForceFirstTrial = false;

    for(int itrial=Begin.trial; itrial<=End.trial; itrial++)
    {
/* Take nSampTrial samples from the current trial*/
        int    nSampTrial = nsamp; 
        if(itrial==Begin.trial && itrial==End.trial) 
        {
            nSampTrial = End.sample-Begin.sample+1;
        }
        else if(itrial==Begin.trial)
        {
            nSampTrial = nsamp-Begin.sample;
        }
        else if(itrial==End.trial)
        {
            nSampTrial = End.sample+1;
        }

        int Offset     = SIZE_TMSI_HEADER 
                       + hdr.NSignal* SIZE_TMSI_SIGNAL_HEADER 
                       + itrial     *(SIZE_TMSI_BLOCK_HEADER+hdr.BlockSize) 
                       + SIZE_TMSI_BLOCK_HEADER;
        int nSampSkip  = (itrial!=Begin.trial) ? 0 : Begin.sample;

        fseek(fp, Offset, SEEK_SET);
        fseek(fp, nSampSkip*hdr.NSignal*2, SEEK_CUR);

        for(int j=0;j<nSampTrial;j++)
        {
            double *DataChan  = data + nSamplesDone + j;
            fseek(fp, NSkipBefore, SEEK_CUR);
            if(TMSIchan[ichan].NByte==4)  *DataChan = ReadBinaryFloat(IntelData, fp);
            else                          *DataChan = ReadBinaryShort(IntelData, fp);
            fseek(fp, NSkipAfter , SEEK_CUR);
        }
        nSamplesDone += nSampTrial;
    }
    fclose(fp);

    return data;
}