#ifndef _MEEGDATATMSI_INCLUDED
#define _MEEGDATATMSI_INCLUDED

#include "MEEGDataBase.h"

#define MAXEDFLABEL 16

typedef struct{
    short year;
    short month;
    short day;
    short dayweek;
    short hour;
    short minute;
    short second;
} DOSTIME;

typedef struct{
    char            FileID[31];   // "POLY SAMPLE FILEversion 2.03"+CR(#13)+LF(#10)+EOF(#26)
    short           Version;
    char            Measurement[81];
    short           SampFreq;
    short           SampFreqStored;
    char            SampFreqUnit; // 0 = Hz, 1 = s
    short           NSignal;
    int             NSampTotal;
    int             Reserve1;
    DOSTIME         RecDate;
    int             NDataBlock;
    unsigned short  NSampBlock;  // multiple of 16
    unsigned short  BlockSize;   // prefered 8192, ex header
    short           DeltaComp;
    char            Reserve2[64];
} TMSI_HEADER;

typedef struct{
    char            Name[41];
    char            Reserve1[4];
    char            Unit[11];
    float           UnitMin;
    float           UnitMax;
    float           DataMin;
    float           DataMax;
    short           Index;
    short           Offset; // 0 in PortLab
    char            Reserve2[60];
} TMSI_SIGNAL_HEADER;

typedef struct{
    int BlockOffset;
    int NByte;  // 2 (digital) or 4 (float)
} TMSI_CHANNEL;

typedef struct{
    int             Index;
    int             Reserve;
    DOSTIME         RecTime;
    char            Reserve2[64];
} TMSI_BLOCK_HEADER;


class DLL_IO UMEEGDataTMSI : public UMEEGDataBase
{
public:
    UMEEGDataTMSI();
    UMEEGDataTMSI(UFileName FileName);     
    UMEEGDataTMSI(const UMEEGDataTMSI& Data); 
    virtual ~UMEEGDataTMSI();
    UMEEGDataTMSI&          operator=(const UMEEGDataTMSI &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual double*        GetChannel_d(UEvent Begin, UEvent End, const char* Label) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    UString                Experiment;
    TMSI_CHANNEL*          TMSIchan;
    TMSI_HEADER            hdr;
};

#endif// _MEEGDATATMSI_INCLUDED
