/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for reading a .txt data file and taking only the                   */
/*     necesssary part.                                                          */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    07-07-04   creation.
  JdM    02-01-05   ChanInfo[] keeps track of channel color and line thickness
  JdM    22-02-05   GetProperties(). return const UString& . Use static Properties to keep this function const
  JdM    07-03-05   Default srate = 250 (it was 1000, Hz)
  JdM    15-01-06   Added EEG group-re-reference
  JdM    15-05-07   GetEpoch_d(). Remove ReRef parameter. Treat in base class.
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
*/

#include <string.h>

#include "MEEGDataTxt.h"
#include "Grid.h"
#include "AnalyzeLine.h"
#include "MarkerArray.h"

/* Inititalize static const parameters. */
UString UMEEGDataTxt::Properties = UString();

#define MAXLINE  1000
#define MAXLABEL   16


void UMEEGDataTxt::SetAllMembersDefault(void)
{
    error        = U_OK;
    Elecfile     = UFileName();
    Datafile     = UFileName();
    Properties   = (const char*)NULL;
}

void UMEEGDataTxt::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMEEGDataTxt::~UMEEGDataTxt()
{ 
    DeleteAllMembers(U_OK);
}

UMEEGDataTxt::UMEEGDataTxt() : UMEEGDataBase()
{
    SetAllMembersDefault();
}

UMEEGDataTxt::UMEEGDataTxt(UFileName FileName) : 
    UMEEGDataBase() 
/*
    Read the Brain products data from file called Filename and store the relevant data in 
    the base class, cq this class.
 */
{
    SetAllMembersDefault();
    error = U_ERROR;

/* Read first line of data file */    
    FileName.ReplaceExtension("txt");
    FILE*   fp = fopen(FileName, "rb", true);
    if(fp==NULL)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). File cannot be opened: %s \n",FileName.GetFullFileName());
        return;
    }
    char LabelLine[MAXLINE];
    GetLine(LabelLine, sizeof(LabelLine), fp);

    int nsampTot = 0;
    char line[MAXLINE];
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine()==true || AA.IsCommentLine()==true) continue;
        nsampTot++;
    }
    fclose(fp);
    if(nsampTot<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). Total number of samples is too small, nsampTot=%d .\n", nsampTot);
        return;
    }

    UAnalyzeLine AALab(LabelLine);
    int NChan = AALab.GetNString();
    if(NChan<=0)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). Total number of channels is too small, NChan=%d .\n", NChan);
        return;
    }
    
/* Set gain and type*/
    ChIn        = new ChanInfo[MAXCHAN];
    GridAll     = new UGrid(MAXCHAN);
    
    if(!ChIn    || 
       !GridAll || GridAll->GetError()!=U_OK)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR UMEEGDataTxt::UMEEGDataTxt(). memory allocation. \n");
        return;
    }

/* Copy general data and set defaults */
    DataFormat        = U_DATFORM_TXT;
    DataFileName      = FileName;   
    Elecfile          = FileName;   Elecfile.ReplaceExtension("xyz");
    Datafile          = FileName;   Datafile.ReplaceExtension("txt");

    ContineousData    = true;
    DateTimeRec       = UDateTime();
    nsamp             = 1;
    ntrial            = nsampTot;
    NPreTrig          = 0;
    nAver             = 0;
    srate             = 250.;

/* set channel information  */
    NchannelRaw       = NChan;
    NchannelTot       = NchannelRaw;
    nMEG = nEEG = nADC = nREF = 0;
    STIM = false;

    const int MaxLab  = sizeof(ChIn[0].namChannel)-1;
    for(int i=0; i<MAXCHAN; i++)
    {
        memset(ChIn[i].namChannel,0, sizeof(ChIn[0].namChannel));
        sprintf(ChIn[i].namChannel,"TXT_%d",i);
        if(i<NchannelRaw)
        {
            strncpy(ChIn[i].namChannel, AALab.GetNextString(MaxLab), MaxLab);
            ChIn[i].type          = U_DAT_EEG;
            ChIn[i].SkipChannel   = false;
            nEEG++;
            USensor S = UGrid::GetDefaultSensor(ChIn[i].namChannel);
            GridAll->SetSensor(&S, i);
        }
        else
        {
            sprintf(ChIn[i].namChannel,"TXT_%d",i);
            ChIn[i].type          = U_DAT_UNKNOWN;
            ChIn[i].SkipChannel   = true;
        }
        ChIn[i].InGain        = 1.;
        ChIn[i].GainFact      = 1.;
        ChIn[i].Offset        = 0.;
        ChIn[i].Red           = 0;
        ChIn[i].Green         = 0;
        ChIn[i].Blue          = 0;
        ChIn[i].LT            = 1;
    }
    EEGposTrue   = false;
    EEGlabelTrue = true; 

    strncpy(PatName,"Txt_NONAME",31);
    strncpy(PatID  ,"Txt1234567890",31);

    if(nEEG) GridEEG = new UGrid(nEEG);

    if( nEEG && (GridEEG==NULL || GridEEG->GetError()!=U_OK) ) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). Memory allocation for Grid. \n");
        return;
    }        

/* Set the type specific grids*/
    SelectChannels((char*)NULL, (char*)NULL);

    if(nEEG<=0 || nEEG>MAXEEG)
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). Number of EEG channels out of range: nEEG = %d.\n", nEEG);
        return;
    }

/* Read true electrode positions from .xyz file */
    error = U_OK;
    UMEEGDataBase::UpdateElectrodePositions(Elecfile);

    if(SetLaplacianReferenceMatrix()!=U_OK)
        CI.AddToLog("ERROR: UMEEGDataTxt::UMEEGDataTxt(). Setting new Laplacian reference matrix \n");
}

UMEEGDataTxt::UMEEGDataTxt(const UMEEGDataTxt& Data) : 
    UMEEGDataBase((UMEEGDataBase) Data)
/*
    Copy constructor. Copy contents of Data to a new Object of the type UMEEGDataTxt.
    Note: only the sensor information, etc is copied; not the trial data.
 */
{
    SetAllMembersDefault();
    *this = Data;
}

UMEEGDataTxt& UMEEGDataTxt::operator=(const UMEEGDataTxt &Data)
{
    if(this==NULL)
    {
        static UMEEGDataTxt T; T.error=U_ERROR;
        return T;
    }
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataTxt::operator=(). Argument has NULL address. \n");
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataTxt::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    Elecfile  = Data.Elecfile;
    Datafile  = Data.Datafile;
    return *this;
}

const UString& UMEEGDataTxt::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMEEGDataTxt-object\n");
        return Properties;
    }
    Properties = UMEEGDataBase::GetProperties(Comment);

    return Properties;
}

double* UMEEGDataTxt::GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const
/*
    return a double pointer to an array containing the data between the event
    Begin and the event End. These events refer to ABSOLUTE time samples numbers. In 
    cases where time samples are derived from markers, the marker data have to be corrected 
    for the pre-trigger time.
     

    Rereference EEG w.r.t. average reference, if ReRef specifies so.
    On error, return NULL (e.g. when Begin is located after End)

  Notes:
  -The events Begin and End may reside on different trials. 
  -The data array is allocated with new[] and should be deleted by the calling function.
  -As far as Begin and End refer to trials <0 or trials>=ntrial, substitute zeroes

*/
{
    if(Begin.sample < 0 || Begin.sample >=nsamp ||
       End.sample   < 0 || End.sample   >=nsamp) 
    {
        CI.AddToLog("ERROR UMEEGDataTxt::GetEpoch_d() : Arguments out of range\n");
        return NULL;
    }

    int NSamples = GetNsamples(Begin, End, nsamp);
    if(NSamples<=0) 
    {
        CI.AddToLog("ERROR UMEEGDataTxt::GetEpoch_d() : Arguments : Begin is located after End\n");
        return NULL;
    }
    int    nKAN    = GetNkan(Dtype);
    if(nKAN<=0)
    {
        CI.AddToLog("ERROR UMEEGDataTxt::GetEpoch_d() : requested type not present in file. \n");
        return NULL;
    }

    double *data = new double[NSamples*nKAN];
    char*   Line = new char[MAXCHAN*30];
    if(!data || !Line)
    {
        delete[] data; delete[] Line;
        CI.AddToLog("ERROR UMEEGDataTxt::GetEpoch_d() : memory allocation.\n");
        return NULL;
    }


    FILE* fp = fopen(Datafile, "rt", true);
    if(fp==NULL)
    {
        delete[] data; delete[] Line;
        CI.AddToLog("ERROR: UMEEGDataTxt::GetEpoch_d(). Cannot open file: %s  .\n",Datafile.GetFullFileName());
        return NULL;
    }
    GetLine(Line, 30, fp);      // Skip dummy line

    int SampB = Begin.GetAbsSample(nsamp);
    for(int j=0; j<SampB; j++)
        GetLine(Line, 30, fp);  // Skip dummy lines

    for(int j=0; j<NSamples; j++)
    {
        if(GetLine(Line,MAXCHAN*30, fp)==NULL)
        {
            delete[] data; delete[] Line;
            fclose(fp);
            CI.AddToLog("ERROR: UMEEGDataTxt::GetEpoch_d(). End of file reached before getting sample %d  .\n",j);
            return NULL;
        }
        UAnalyzeLine AA(Line);
        for(int i=0, ic=0; i<NchannelRaw; i++)
        {
            double Val = AA.GetNextDouble(123456789.);
            if(ChIn[i].type!=Dtype)       continue;
            if(ChIn[i].SkipChannel==true) continue;
            if(Val==123456789.)
            {
                CI.AddToLog("ERROR: UMEEGDataTxt::GetEpoch_d(). Sample not read, i=%d, j=%d   \n", i,j);
                Val = 0.;
            }
            data[ic*NSamples+j] = Val;
            ic++;
        }        
    }
    
    fclose(fp);
    return data;
}

int* UMEEGDataTxt::GetTriggerEpoch(UEvent Begin, UEvent End) const
{
    CI.AddToLog("ERROR: UMEEGDataTxt::GetTriggerEpoch(). Function not implemented. \n");
    return NULL;
}

