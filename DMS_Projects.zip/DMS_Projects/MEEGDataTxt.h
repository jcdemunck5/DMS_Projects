#ifndef _MEEGDATATXT_INCLUDED
#define _MEEGDATATXT_INCLUDED

#include "MEEGDataBase.h"

class DLL_IO UMEEGDataTxt : public UMEEGDataBase
{
public:
    UMEEGDataTxt();
    UMEEGDataTxt(UFileName FileName);     
    UMEEGDataTxt(const UMEEGDataTxt& Data); 
    virtual ~UMEEGDataTxt();
    UMEEGDataTxt&          operator=(const UMEEGDataTxt &Data);

    virtual ErrorType      GetError(void) const         {return error;}
    const UString&         GetProperties(UString Comment) const;

    virtual double*        GetEpoch_d(UEvent Begin, UEvent End, DataType Dtype) const;
    virtual int*           GetTriggerEpoch(UEvent Begin, UEvent End) const;

protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

private:
    static UString         Properties;
    ErrorType              error;

/* Txt data */
    UFileName              Elecfile;   // Filename containing electrode positions
    UFileName              Datafile;   // Filename containg the data in txt collumns
};

#endif// _MEEGDATATXT_INCLUDED
