/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Abstract base class for writing various MEG/EEG data formats.             */
/*     For each data type a new derived class of UMEEGDataWriteBase() has to be  */
/*     implemented.                                                              */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    29-11-03   creation
  JdM    19-03-06   Bug fix: SetGridADC(), update nADC.
  JdM    23-09-06   Bug fix: SetGridREF(), SetGridMEG(),SetGridEEG(), update nREF, nMEG, nEEG.
  JdM    16-02-09   Set GeneralComment as UString()
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
                    Added ScaleCallibrations()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
*/

#include <string.h>

#include "MEEGDataWriteBase.h"
#include "Grid.h"
#include "MarkerArray.h"
#include "Directory.h"
#include "SortSemiSort.h"

/* Inititalize static const parameters. */
UMEEGDataWriteBase::UMEEGDataWriteBase() : 
    UMEEGDataBase()
{
}

UMEEGDataWriteBase::UMEEGDataWriteBase(const UMEEGDataBase& Data)  : 
    UMEEGDataBase( (UMEEGDataBase) Data)
{
}

UMEEGDataWriteBase::UMEEGDataWriteBase(const UMEEGDataWriteBase& Data) : 
    UMEEGDataBase( (UMEEGDataBase) Data)
{
    DataFileNameOut = Data.DataFileNameOut;
}

UMEEGDataWriteBase::~UMEEGDataWriteBase()
{
}

UMEEGDataWriteBase& UMEEGDataWriteBase::operator=(const UMEEGDataWriteBase &Data)
{
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataBase::operator=(Data);
    if(UMEEGDataBase::GetError() != U_OK) 
    {
        UMEEGDataBase::DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMEEGDataWriteBase::operator=(). Copying base class. \n");
        return *this;
    }
    DataFileNameOut = Data.DataFileNameOut;
    return *this;
}

ErrorType UMEEGDataWriteBase::SetDataFormatType(DataFormatType DFT) 
{
    if(DFT != U_DATFORM_CTF       &&
       DFT != U_DATFORM_NEUROSCAN &&
       DFT != U_DATFORM_MICROMED)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetDataFormatType(). Unknown data format(%s) \n", GetDataFormatTypeText(DFT));
        return U_ERROR;
    }
    DataFormat  = DFT;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetDateTimeRef(UDateTime DT)          
{
    if(DT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetDateTimeRef(). Erroneous date or time. \n");
        return U_ERROR;
    }
    DateTimeRec = DT;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetDataContineous(bool cont)          
{
    ContineousData = cont;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetComment(const char *comment1, const char *comment2)
{
    GeneralComment = UString();
    return AddComment(comment1, comment2);
}

ErrorType UMEEGDataWriteBase::AddComment(const char *comment1, const char *comment2)
{
    if(comment1) GeneralComment += UString(comment1);
    if(comment2) GeneralComment += UString(comment2);
    return GeneralComment.GetError();
}

ErrorType UMEEGDataWriteBase::SetDataFileName(UFileName FileOut)    
{
    switch(FileOut.GetStatus())
    {
    case UFileName::U_FILE_NOSTAT:
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetDataFileName(). Unknown file status (%s) .\n", FileOut.GetFullFileName());
        return U_ERROR;

    case UFileName::U_FILE_CANBEREAD:
        CI.AddToLog("WARNING: UMEEGDataWriteBase::SetDataFileName(). File already exists (%s) .\n", FileOut.GetFullFileName());
        DataFileNameOut = FileOut;
        return U_OK;

    case UFileName::U_FILE_CANBECREATED:
        DataFileNameOut = FileOut;
        return U_OK;

    case UFileName::U_FILE_CANNOTBECREATED:
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetDataFileName(). File cannot be created (%s) .\n", FileOut.GetFullFileName());
        return U_ERROR;
    }
    return U_ERROR;
}

ErrorType UMEEGDataWriteBase::SetSampleRate(double Srate)           
{
    if(Srate<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetSampleRate(). Invalid sample rate (Srate=%f) .\n", Srate);
        return U_ERROR;
    }
    srate = Srate;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetSampleTime_s(double Stime_s)
{
    if(Stime_s<=0.)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetSampleTime_s(). Invalid sample time (Stime_s=%f) .\n", Stime_s);
        return U_ERROR;
    }
    srate = 1./Stime_s;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetPreTriggerTime_s(double Time_s)    
{
    NPreTrig = int(floor(0.5+Time_s*srate));
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetPreNTriggerPnts(int NpreTr)        
{
    NPreTrig = NpreTr;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetNsampTrial(int NsampTrial)         
{
    if(NsampTrial<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetNsampTrial(). Invalid number of samples per trial (NsampTrial=%d) . \n", NsampTrial);
        return U_ERROR;
    }
    nsamp = NsampTrial;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetNtrial(int Ntrial)
{
    if(Ntrial<=0)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetNtrial(). Invalid number of trials (Ntrial=%d) . \n", Ntrial);
        return U_ERROR;
    }
    ntrial = Ntrial;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetNaver(int Naverages)               
{
    nAver = MAX(1,Naverages);
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetPatName(const char* Pnam)          
{
    if(Pnam==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetPatName(). Invalid NULL pointer argument.\n");
        return U_ERROR;
    }
    strncpy(PatName, Pnam, sizeof(PatName)-1);
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetPatID(const char* Pid)             
{
    if(Pid==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetPatID(). Invalid NULL pointer argument.\n");
        return U_ERROR;
    }
    strncpy(PatID, Pid, sizeof(PatID)-1);
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetDewar2NLR(UEuler D2N)              
{
    CI.AddToLog("ERROR: UMEEGDataWriteBase::SetDewar2NLR(). virual function not implemented. \n");
    return U_ERROR;
}

ErrorType UMEEGDataWriteBase::SetEEGPositionsMeasured(bool SetM)    
{
    EEGposTrue   = SetM;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetEEGLabelsTrue(bool SetL)           
{
    EEGlabelTrue = SetL;
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetGridREF(const UGrid* GrRef)              
{
    if(GrRef==NULL)
    {
        delete GridREF; GridREF = NULL;
        nREF = 0;
        return U_OK;
    }
    if(GrRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridREF(). Erroneous argument. \n");
        return U_ERROR;
    }

    delete GridREF;  GridREF = new UGrid(*GrRef);
    if(GridREF==NULL || GridREF->GetError()!=U_OK)
    {
        delete GridREF; GridREF = NULL;
        nREF = 0;
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridREF(). Copying argument. \n");
        return U_ERROR;
    }
    nREF = GridREF->GetNpoints();
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetGridMEG(const UGrid* GrMeg)              
{
    if(GrMeg==NULL)
    {
        delete GridMEG; GridMEG = NULL;
        nMEG = 0;
        return U_OK;
    }
    if(GrMeg->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridMEG(). Erroneous argument. \n");
        return U_ERROR;
    }

    delete GridMEG;  GridMEG = new UGrid(*GrMeg);
    if(GridMEG==NULL || GridMEG->GetError()!=U_OK)
    {
        delete GridMEG; GridMEG = NULL;
        nMEG = 0;
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridMEG(). Copying argument. \n");
        return U_ERROR;
    }
    nMEG = GridMEG->GetNpoints();
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetGridEEG(const UGrid* GrEeg)              
{
    if(GrEeg==NULL)
    {
        delete GridEEG; GridEEG = NULL;
        nEEG = 0;
        return U_OK;
    }
    if(GrEeg->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridEEG(). Erroneous argument. \n");
        return U_ERROR;
    }

    delete GridEEG;  GridEEG = new UGrid(*GrEeg);
    if(GridEEG==NULL || GridEEG->GetError()!=U_OK)
    {
        delete GridEEG; GridEEG = NULL;
        nEEG = 0;
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridEEG(). Copying argument. \n");
        return U_ERROR;
    }
    nEEG = GridEEG->GetNpoints();
    return U_OK;
}

ErrorType UMEEGDataWriteBase::SetGridADC(const UGrid* GrAdc)              
{
    if(GrAdc==NULL)
    {
        delete GridADC; GridADC = NULL;
        nADC = 0;
        return U_OK;
    }
    if(GrAdc->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridADC(). Erroneous argument. \n");
        return U_ERROR;
    }

    delete GridADC;  GridADC = new UGrid(*GrAdc);
    if(GridADC==NULL || GridADC->GetError()!=U_OK)
    {
        delete GridADC; GridADC = NULL;
        nADC = 0;
        CI.AddToLog("ERROR: UMEEGDataWriteBase::SetGridADC(). Copying argument. \n");
        return U_ERROR;
    }
    nADC = GridADC->GetNpoints();
    return U_OK;
}

/* write data (all virtual) */
ErrorType UMEEGDataWriteBase::WriteHeader(void) 
{
    CI.AddToLog("ERROR: UMEEGDataWriteBase::WriteHeader(). virtual function not implemented. \n");
    return U_ERROR;
}

ErrorType UMEEGDataWriteBase::WriteTrial(const double* Data, DataType Dtype, int itrial) const
{
    CI.AddToLog("ERROR: UMEEGDataWriteBase::WriteTrial(). virtual function not implemented. \n");
    return U_ERROR;
}

ErrorType UMEEGDataWriteBase::WriteTrigger(const int* Data, int itrial) const
{
    CI.AddToLog("ERROR: UMEEGDataWriteBase::WriteTrigger(). virtual function not implemented. \n");
    return U_ERROR;
}

ErrorType UMEEGDataWriteBase::WriteMarkerArray(const UMarkerArray* ResampledMarkers) const
{
    CI.AddToLog("ERROR: UMEEGDataWriteBase::WriteMarkerArray(). virtual function not implemented. \n");
    return U_ERROR;
}
    
ErrorType UMEEGDataWriteBase::ScaleCallibrations(DataType Dtype, const double* DatMax, int NChan, int Nbits) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::ScaleCallibrations(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(DatMax==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::ScaleCallibrations(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(NChan!=GetNChan(Dtype))
    {
        CI.AddToLog("ERROR: UMEEGDataWriteBase::ScaleCallibrations(). Invalid parameter (NChan=%d) .\n", NChan);
        return U_ERROR;
    }
    int    Imax = 0;
    double Dmax = GetUpperQuantile(DatMax, NChan, 0.8);

    switch(Nbits)
    {
    case  8: Dmax*= 2; Imax =        128; break;
    case 16: Dmax*= 5; Imax =      32768; break;
    case 24: Dmax*=10; Imax =    8388608; break;
    case 32: Dmax*=50; Imax = 2147483648; break;
    default:
        CI.AddToLog("ERROR: UMEEGDataWriteBase::ScaleCallibrations(). Parameter invalid: Nbits = %d .\n", Nbits);
        return U_ERROR;
    }
    if(Dmax==0) return U_OK;

    for(int isens=0; isens<NChan; isens++)
    {
        int i = GetChannelIndex(isens, Dtype);
        if(i<0 || i>=MAXCHAN) continue;
        if(ChIn[i].InGain==0) continue;

        ChIn[i].GainFact = fabs(Dmax/ChIn[i].InGain)/Imax;
    }
    return U_OK;
}

