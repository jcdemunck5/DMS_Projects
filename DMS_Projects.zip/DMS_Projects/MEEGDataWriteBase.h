#ifndef _MEEGDATAWRITE_INCLUDED
#define _MEEGDATAWRITE_INCLUDED

#include "MEEGDataBase.h"

class DLL_IO UMEEGDataWriteBase : public UMEEGDataBase
{
public:
    UMEEGDataWriteBase();
    UMEEGDataWriteBase(const UMEEGDataBase& Data); 
    UMEEGDataWriteBase(const UMEEGDataWriteBase& Data); 
    virtual ~UMEEGDataWriteBase();
    virtual UMEEGDataWriteBase& operator=(const UMEEGDataWriteBase &Data);

    ErrorType              SetDataFormatType(DataFormatType DFT); 
    ErrorType              SetDateTimeRef(UDateTime DT);          
    ErrorType              SetDataContineous(bool cont);          
    ErrorType              SetComment(const char *comment1, const char *comment2=NULL);
    ErrorType              AddComment(const char *comment1, const char *comment2=NULL);

    virtual ErrorType      SetDataFileName(UFileName FileOut); 
    UFileName              GetDataFileName(void) const {return DataFileNameOut;}
    
    ErrorType              SetSampleRate(double Srate);           
    ErrorType              SetSampleTime_s(double Stime_s);       
    ErrorType              SetPreTriggerTime_s(double Time_s);    
    ErrorType              SetPreNTriggerPnts(int NpreTr);        
    ErrorType              SetNsampTrial(int NsampTrial);         
    ErrorType              SetNtrial(int Ntrial);                 
    ErrorType              SetNaver(int Naverages);               

    ErrorType              SetPatName(const char* Pnam);          
    ErrorType              SetPatID(const char* Pid);             
    virtual ErrorType      SetDewar2NLR(UEuler D2N);              

    ErrorType              SetEEGPositionsMeasured(bool SetM);    
    ErrorType              SetEEGLabelsTrue(bool SetL);           

    ErrorType              SetGridREF(const UGrid* GrRef);              
    ErrorType              SetGridMEG(const UGrid* GrMeg);              
    ErrorType              SetGridEEG(const UGrid* GrEeg);              
    ErrorType              SetGridADC(const UGrid* GrAdc);              

/* write data */
    ErrorType              ScaleCallibrations(DataType Dtype, const double* DatMax, int NChan, int Nbits) const;
    virtual ErrorType      WriteHeader(void);
    virtual ErrorType      WriteTrial(const double* Data, DataType Dtype, int itrial) const;
    virtual ErrorType      WriteTrigger(const int* Data, int itrial) const;

    virtual ErrorType      WriteMarkerArray(const UMarkerArray* ResampledMarkers) const;
    
protected:
    UFileName              DataFileNameOut; // Output file name
};

#endif// _MEEGDATAWRITE_INCLUDED
