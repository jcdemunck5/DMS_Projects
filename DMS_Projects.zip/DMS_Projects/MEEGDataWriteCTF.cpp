/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for writing MEG/EEG data in CTF data format.                       */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    30-11-03   creation, derived from WriteCTFData.cpp
  JdM    17-11-04   Bug fix: WriteTrial() writing more than one data type: apply iwrite++ always for MEG,EEG,ADC
  JdM    29-03-05   WriteHeader() WriteTrial(): Add MEGREF (MEG reference type as data type)
  JdM    13-04-05   Bug fixes WriteHeader(). Due to changes made on  29-03-05. Updating sensor tables.
  JdM    07-11-05   Added WriteHC().
  JdM    23-01-06   WriteTrial(). Test itrial-parameter
  JdM    20-04-06   Bug fix (?) rez.genres.gSetUp.epoch_time = total time of all trials (i.s.o. trial length)
  JdM    11-05-06   WriteTrial(). Test itrial-parameter, properly (<ntrial, iso <=ntrial)
  JdM    24-09-06   BUG FIX. WriteHeader(). Writing EEG sensor positions in case nMEG>0.
  JdM    05-01-07   Added and used WriteResources()
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    25-03-08   BUG FIX: In relation to changes in UMEEGDataBase dd 12 and 13-03-08, split nchannel into NchannelRaw and NchannelTot
  JdM    06-01-09   Bug Fix: WriteHeader(). Ordering of ADC channels
  JdM    06-01-09   Added RenameDataFiles() and DeleteDataFiles()
  JdM    24-06-09   Bug Fix: WriteHeader(). Storing of ADC channel names in ChIn[]
  JdM    21-10-09   WriteHeader(): Remove message that file is sucessfully written.
                    SetDataFileName(). Remove WARNING that data set already exists
  JdM    13-02-10   Bug fix: WriteHeader(). Make a distiction between magneometers and gradiometers, using rez.senres[i].sensorTypeIndex
  JdM    10-06-10   Added GainFact- member to ChanInfo -struct. Renamed offset and gain members.
                    WriteTrial(). Limit number of overflow WARNINGS
  JdM    10-10-10   Bug Fix: WriteHeader(). use strncmp() instead of IsStringCompatible()
  JdM    08-03-12   Made WriteResources() static
  JdM    19-07-13   BUG FIX. #define WRITE_STRUCT_DIRECT ????. Old code failed to read genres.gSetUp.preTrigPts
                    New code is consistent with ReadCTF.c (but also with golden standard????)
  JdM    01-08-13   Added DeleteBadChannelFile()
  JdM    14-12-13   Bug Fix. WriteHeader(). Testing whether index i is between nREF and nREF+nMEG (old code tested:  nMEG and nREF+nMEG)
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    21-03-15   BUG FIX: WriteTrial(). Added test whether channel is to be skipped:  if(ChIn[i].SkipChannel) continue;
  JdM    22-03-16   WriteMarkerArray(). Added bool parameter: MergeExistingMarkers
*/

#include <string.h>

#include "MEEGDataWriteCTF.h"
#include "CTFDataSet.h"
#include "MarkerArray.h"
#include "Grid.h"
#include "MegDefs.h"

/* Inititalize static const parameters. */

const double UMEEGDataWriteCTF::GAUGE_MEG     =  1e15;
const double UMEEGDataWriteCTF::GAUGE_EEG     =  1e6;
const double UMEEGDataWriteCTF::DEF_MEG_GAIN  =  0.001;
const double UMEEGDataWriteCTF::DEF_EEG_GAIN  =  0.1;

#ifdef WIN32
#define WRITE_STRUCT_DIRECT
#endif

UMEEGDataWriteCTF::UMEEGDataWriteCTF() : UMEEGDataWriteBase()
{
}

UMEEGDataWriteCTF::UMEEGDataWriteCTF(const UMEEGDataBase& Data) :
    UMEEGDataWriteBase((UMEEGDataBase)Data)
{
}

UMEEGDataWriteCTF::UMEEGDataWriteCTF(const UMEEGDataWriteBase& Data) :
    UMEEGDataWriteBase(Data)
{
}

UMEEGDataWriteCTF::UMEEGDataWriteCTF(const UMEEGDataWriteCTF& Data) :
    UMEEGDataWriteBase((const UMEEGDataWriteBase&)Data)
{
    Dewar2Head = Data.Dewar2Head;
}

UMEEGDataWriteCTF::~UMEEGDataWriteCTF()
{
}

UMEEGDataWriteCTF& UMEEGDataWriteCTF::operator=(const UMEEGDataWriteCTF &Data)
{
    if(&Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Data) return *this;

    UMEEGDataWriteBase::operator=(Data);
    Dewar2Head = Data.Dewar2Head;
    return *this;
}
ErrorType UMEEGDataWriteCTF::CopyDataFiles(const char* BaseName)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    if(BaseName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    UFileName   B(BaseName);      B.ReplaceExtension("ds");
    UCTFDataSet DS((const char*)DataFileNameOut);
    UDirectory  OldDir = DS.GetDirectory();
    UDirectory  NewDir = OldDir.Sibling((const char*)B);

    if(NewDir.CreateDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Creating output directory. \n");
        return U_ERROR;
    }

    UFileName F = DataFileNameOut;              F.ReplaceExtension("res4");
    UFileName N = NewDir + UFileName(BaseName); N.ReplaceExtension("res4");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying resource file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("meg4");
    N.ReplaceExtension("meg4");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying data file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("acq");
    N.ReplaceExtension("acq");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying .acq file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("eeg");
    N.ReplaceExtension("eeg");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying .eeg file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hist");
    N.ReplaceExtension("hist");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying .hist file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hc");
    N.ReplaceExtension("hc");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying head coil file. \n");
        return U_ERROR;
    }
    F.ReplaceBaseName("BadChannels");
    N.ReplaceBaseName("BadChannels");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying bad channel file. \n");
        return U_ERROR;
    }
    F.ReplaceBaseName("MarkerFile.mrk");
    N.ReplaceBaseName("MarkerFile.mrk");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying marker file. \n");
        return U_ERROR;
    }
    F.ReplaceBaseName("ClassFile.cls");
    N.ReplaceBaseName("ClassFile.cls");
    if(F.DoesFileExist()==true && CopyFile((const char*)F,(const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::CopyDataFiles(). Copying marker file. \n");
        return U_ERROR;
    }

    DataFileName = NewDir + UFileName(BaseName);
    DataFileName.ReplaceExtension("res4");;
    return U_OK;
}
ErrorType UMEEGDataWriteCTF::DeleteBadChannelFile(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::DeleteBadChannelFile(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    UCTFDataSet DSout((const char*)DataFileNameOut);
    UFileName FBAD(DSout.GetBADFileName());
    return FBAD.RemoveFile();
}
ErrorType UMEEGDataWriteCTF::DeleteDataFiles(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::DeleteDataFiles(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    UDirectory  Dir = DataFileNameOut.GetDirectory();
    if(Dir.DeleteAllFiles()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::DeleteDataFiles(). Deleting files from directory (%s) .\n", Dir.GetDirectoryName());
        return U_ERROR;
    }
    if(Dir.RemoveDir()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::DeleteDataFiles(). Deleting directory (%s) .\n", Dir.GetDirectoryName());
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMEEGDataWriteCTF::RenameDataFiles(const char* BaseName)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Object NULL or erropneous. \n");
        return U_ERROR;
    }
    if(BaseName==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    UFileName   B(BaseName);      B.ReplaceExtension("ds");
    UCTFDataSet DS((const char*)DataFileNameOut);
    UDirectory  OldDir = DS.GetDirectory();
    UDirectory  NewDir = OldDir.Sibling((const char*)B);

    UFileName F = DataFileNameOut;              F.ReplaceExtension("res4");
    UFileName N = OldDir + UFileName(BaseName); N.ReplaceExtension("res4");
    if(F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming resource file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("meg4");
    N.ReplaceExtension("meg4");
    if(F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming data file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("acq");
    N.ReplaceExtension("acq");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming .acq file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("eeg");
    N.ReplaceExtension("eeg");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming .eeg file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hist");
    N.ReplaceExtension("hist");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming .hist file. \n");
        return U_ERROR;
    }
    F.ReplaceExtension("hc");
    N.ReplaceExtension("hc");
    if(F.DoesFileExist()==true && F.RenameFile((const char*)N)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming head coil file. \n");
        return U_ERROR;
    }
    if(NewDir.GetStatus()!=UDirectory::U_EXIST && OldDir.RenameDir((const char*)NewDir)!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::RenameDataFiles(). Renaming data set directory. \n");
        return U_ERROR;
    }

    DataFileName = NewDir + UFileName(BaseName);
    DataFileName.ReplaceExtension("res4");;
    return U_OK;
}

ErrorType UMEEGDataWriteCTF::SetDataFileName(UFileName FileOut)
{
    const char* Ext = FileOut.GetExtension();

    if(IsStringCompatible(Ext, "ds"  , false)==true   ||
       IsStringCompatible(Ext, "res4", false)==true   ||
       IsStringCompatible(Ext, "meg4", false)==true)
    {
        UCTFDataSet DS(FileOut.GetFullFileName());
        if(DS.GetDataSetStatus()==UDirectory::U_EXIST)
        {
            DataFileNameOut = UFileName(DS.GetCTFFileName());
            return U_OK;
        }
        else
        {
            if(DS.CreateDataSet()!=U_OK)
            {
                CI.AddToLog("ERROR: UMEEGDataWriteCTF::SetDataFileName(). Data set cannot be created: %s \n", DS.GetDataSetName());
                return U_ERROR;
            }
        }
        CI.AddToLog("Note: UMEEGDataWriteCTF::SetDataFileName(). Data set created: %s \n", DS.GetDataSetName());
        DataFileNameOut = UFileName(DS.GetCTFFileName());
        return U_OK;
    }

    CI.AddToLog("ERROR: UMEEGDataWriteCTF::SetDataFileName(). Invalid or unrecognized file name: %s \n", FileOut.GetFullFileName());
    return U_ERROR;
}

ErrorType UMEEGDataWriteCTF::SetDewar2NLR(UEuler D2N)
{
    Dewar2Head = D2N;
    return U_OK;
}

/* write data */
ErrorType UMEEGDataWriteCTF::WriteHeader(void)
/*
    Write resource file (.res4), without reference channels and stimulus channel.
 */
{
    if(nREF<0 || nMEG<0 || nEEG<0 || nADC<0 ||
        nREF+nMEG+nEEG+nADC<=0         ||
        nREF+nMEG+nEEG+nADC>UMEEGDataBase::MAXCHAN)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Nchannels out of range (nREF,nMEG,nEEG,nADC) = (%d, %d, %d, %d). \n", nREF,nMEG,nEEG,nADC);
        return U_ERROR;
    }
    if( (nREF>0 && GridREF==NULL) ||
        (nMEG>0 && GridMEG==NULL) ||
        (nEEG>0 && GridEEG==NULL) ||
        (nADC>0 && GridADC==NULL))
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Inconsistent settings (nREF,nMEG,nEEG,nADC) = (%d, %d, %d, %d). \n", nREF,nMEG,nEEG,nADC);
        return U_ERROR;
    }

    NchannelTot  -= NchannelRaw -(nREF + nMEG + nEEG + nADC);
    NchannelRaw   = nREF + nMEG + nEEG + nADC;

    if(ChIn==NULL || GridAll==NULL)    // Create defaults when not existent
    {
        delete   GridAll; GridAll = NULL;
        delete[] ChIn;    ChIn    = NULL;
        GridAll = new UGrid(MAXCHAN);
        ChIn    = new ChanInfo[MAXCHAN];
        if(ChIn==NULL || ChIn==NULL)
        {
            delete   GridAll; GridAll = NULL;
            delete[] ChIn;    ChIn    = NULL;
            CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Memory allocation error. \n");
            return U_ERROR;
        }
        for(int i=0; i<MAXCHAN; i++)
        {
            if(0  <=i && i<nREF)
            {
                int iREF = i;
                GridAll->SetSensor(GridREF->GetSensorPointer(iREF),i);
                if(GridREF->GetName(iREF))   strncpy(ChIn[i].namChannel, GridREF->GetName(iREF), sizeof(ChIn[i].namChannel)-1);
                else                         strncpy(ChIn[i].namChannel, "CTF_NONAME_REF"      , sizeof(ChIn[i].namChannel)-1);
                ChIn[i].type        = U_DAT_MEGREF;
                ChIn[i].SkipChannel = false;
                ChIn[i].InGain      = DEF_MEG_GAIN;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
            }
            else if(nREF  <=i && i<nREF+nMEG)
            {
                int iMEG = i-nREF;
                GridAll->SetSensor(GridMEG->GetSensorPointer(iMEG),i);
                if(GridMEG->GetName(iMEG)) strncpy(ChIn[i].namChannel, GridMEG->GetName(iMEG), sizeof(ChIn[i].namChannel)-1);
                else                       strncpy(ChIn[i].namChannel, "CTF_NONAME_MEG"      , sizeof(ChIn[i].namChannel)-1);
                ChIn[i].type        = U_DAT_MEG;
                ChIn[i].SkipChannel = false;
                ChIn[i].InGain      = DEF_MEG_GAIN;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
            }
            else if(nREF+nMEG<=i && i<nREF+nMEG+nEEG)
            {
                int iEEG = i-nREF-nMEG;
                GridAll->SetSensor(GridEEG->GetSensorPointer(iEEG),i);
                if(GridEEG->GetName(iEEG)) strncpy(ChIn[i].namChannel, GridEEG->GetName(iEEG), sizeof(ChIn[i].namChannel)-1);
                else                       strncpy(ChIn[i].namChannel, "CTF_NONAME_EEG"      , sizeof(ChIn[i].namChannel)-1);
                ChIn[i].type        = U_DAT_EEG;
                ChIn[i].SkipChannel = false;
                ChIn[i].InGain      = DEF_EEG_GAIN;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
            }
            else if(nREF+nMEG+nEEG<=i && i<nREF+nMEG+nEEG+nADC)
            {
                int iADC = i-nREF-nMEG-nEEG;
                GridAll->SetSensor(GridADC->GetSensorPointer(iADC),i);
                if(GridADC->GetName(iADC)) strncpy(ChIn[i].namChannel, GridADC->GetName(iADC), sizeof(ChIn[i].namChannel)-1);
                else                       strncpy(ChIn[i].namChannel, "CTF_NONAME_ADC"      , sizeof(ChIn[i].namChannel)-1);
                ChIn[i].type        = U_DAT_ADC;
                ChIn[i].SkipChannel = false;
                ChIn[i].InGain      = 1.;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
            }
            else
            {
                strncpy(ChIn[i].namChannel, "Skip", sizeof(ChIn[i].namChannel)-1);
                USensor S;
                GridAll->SetSensor(&S,i);
                ChIn[i].type        = U_DAT_UNKNOWN;
                ChIn[i].SkipChannel = true;
                ChIn[i].InGain      = 0.;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
            }
        }
    }
    else // Reorder MEGREF->MEG->EEG->ADC and remove skipped channels
    {
        ChanInfo* ChInTemp = new ChanInfo[MAXCHAN];
        if(ChInTemp==NULL)
        {
            CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Memory allocation error, template channel info. \n");
            return U_ERROR;
        }
        memcpy(ChInTemp, ChIn, MAXCHAN*sizeof(ChanInfo));
        for(int i=0; i<MAXCHAN; i++)
        {
            if(0  <=i && i<nREF)
            {
                int iREF = i;
                GridAll->SetSensor(GridREF->GetSensorPointer(iREF),i);

                bool found = false;
                for(int i2=0; i2<MAXCHAN; i2++)
                {
                    if(ChInTemp[i2].SkipChannel==true ) continue;
                    if(ChInTemp[i2].type!=U_DAT_MEGREF) continue;
                    if(!strncmp(GridAll->GetName(i), ChInTemp[i2].namChannel, sizeof(ChIn[i].namChannel)))
                    {
                        memcpy(ChIn+i, ChInTemp+i2, sizeof(ChanInfo));
                        found = true;
                        break;
                    }
                }
                if(found==false)
                {
                    strncpy(ChIn[i].namChannel, GridREF->GetName(iREF), sizeof(ChIn[i].namChannel)-1);
                    ChIn[i].type        = U_DAT_MEGREF;
                    ChIn[i].SkipChannel = false;
                    ChIn[i].InGain      = DEF_MEG_GAIN;
                    ChIn[i].GainFact    = 1.;
                    ChIn[i].Offset      = 1.;
                    CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteHeader(). Updating sensor table, MEG ref label not found: %s \n", GridAll->GetName(i));
                }
            }
            else if(nREF<=i && i<nREF+nMEG)
            {
                int iMEG = i-nREF;
                GridAll->SetSensor(GridMEG->GetSensorPointer(iMEG),i);

                bool found = false;
                for(int i2=0; i2<MAXCHAN; i2++)
                {
                    if(ChInTemp[i2].SkipChannel==true) continue;
                    if(ChInTemp[i2].type!=U_DAT_MEG  ) continue;
                    if(!strncmp(GridAll->GetName(i), ChInTemp[i2].namChannel, sizeof(ChIn[i].namChannel)))
                    {
                        memcpy(ChIn+i, ChInTemp+i2, sizeof(ChanInfo));
                        found = true;
                        break;
                    }
                }
                if(found==false)
                {
                    strncpy(ChIn[i].namChannel, GridMEG->GetName(iMEG), sizeof(ChIn[i].namChannel)-1);
                    ChIn[i].type        = U_DAT_MEG;
                    ChIn[i].SkipChannel = false;
                    ChIn[i].InGain      = DEF_MEG_GAIN;
                    ChIn[i].GainFact    = 1.;
                    ChIn[i].Offset      = 1.;
                    CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteHeader(). Updating sensor table, MEG label not found: %s \n", GridAll->GetName(i));
                }
            }
            else if(nREF+nMEG<=i && i<nREF+nMEG+nEEG)
            {
                int iEEG = i-nREF-nMEG;
                GridAll->SetSensor(GridEEG->GetSensorPointer(iEEG),i);

                bool found = false;
                for(int i2=0; i2<MAXCHAN; i2++)
                {
                    if(ChInTemp[i2].SkipChannel==true) continue;
                    if(ChInTemp[i2].type!=U_DAT_EEG  ) continue;
                    if(!strncmp(GridAll->GetName(i), ChInTemp[i2].namChannel, sizeof(ChIn[i].namChannel)))
                    {
                        memcpy(ChIn+i, ChInTemp+i2, sizeof(ChanInfo));
                        found = true;
                        break;
                    }
                }
                if(found==false)
                {
                    strncpy(ChIn[i].namChannel, GridEEG->GetName(iEEG), sizeof(ChIn[i].namChannel)-1);
                    ChIn[i].type        = U_DAT_EEG;
                    ChIn[i].SkipChannel = false;
                    ChIn[i].InGain      = DEF_EEG_GAIN;
                    ChIn[i].GainFact    = 1.;
                    ChIn[i].Offset      = 0.;
                    CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteHeader(). Updating sensor table, EEG label not found: %s \n", GridAll->GetName(i));
                }
            }
            else if(nREF+nMEG+nEEG<=i && i<nREF+nMEG+nEEG+nADC)
            {
                int iADC = i-nREF-nMEG-nEEG;
                GridAll->SetSensor(GridADC->GetSensorPointer(iADC),i);

                bool found = false;
                for(int i2=0; i2<MAXCHAN; i2++)
                {
                    if(ChInTemp[i2].SkipChannel==true) continue;
                    if(ChInTemp[i2].type!=U_DAT_ADC  ) continue;
                    if(!strncmp(GridAll->GetName(i), ChInTemp[i2].namChannel, sizeof(ChIn[i].namChannel)))
                    {
                        memcpy(ChIn+i, ChInTemp+i2, sizeof(ChanInfo));
                        found = true;
                        break;
                    }
                }
                if(found==false)
                {
/// Restored next line dd 24-06-2009
                    strncpy(ChIn[i].namChannel, GridADC->GetName(iADC), sizeof(ChIn[i].namChannel)-1);
                    ChIn[i].type        = U_DAT_ADC;
                    ChIn[i].SkipChannel = false;
                    ChIn[i].InGain      = 1.;
                    ChIn[i].GainFact    = 1.;
                    ChIn[i].Offset      = 0.;
                    GridAll->SetSensor(GridADC->GetSensorPointer(iADC),i);
                    CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteHeader(). Updating sensor table, ADC label not found: %s \n", GridAll->GetName(i));
                }
            }
            else
            {
                strncpy(ChIn[i].namChannel, "Skip", sizeof(ChIn[i].namChannel)-1);
                ChIn[i].type        = U_DAT_UNKNOWN;
                ChIn[i].SkipChannel = true;
                ChIn[i].InGain      = 0.;
                ChIn[i].GainFact    = 1.;
                ChIn[i].Offset      = 0.;
                USensor S;
                GridAll->SetSensor(&S,i);
            }
        }
        delete[] ChInTemp;
        if(UpdateSensorGrids()!=U_OK)
        {
            CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Updating sensor grids. \n");
            return U_ERROR;
        }
    }

/* Initialize CTF resource*/
    resource   rez;

    memset(rez.genres.appName, 0, sizeof(rez.genres.appName));
    memset(rez.genres.dataOrigin, 0, sizeof(rez.genres.dataOrigin));
    memset(rez.genres.dataDescription, 0, sizeof(rez.genres.dataDescription));
    rez.genres.no_trials_avgd  =  nAver;
    memset(rez.genres.data_time, 0, sizeof(rez.genres.data_time));
    memset(rez.genres.data_date, 0, sizeof(rez.genres.data_date));
    strncpy(rez.genres.data_date, DateTimeRec.GetProperties(NULL, true, false), sizeof(rez.genres.data_date)-1);
    strncpy(rez.genres.data_time, DateTimeRec.GetProperties(NULL, false, true), sizeof(rez.genres.data_time)-1);

    rez.genres.gSetUp.no_samples          = nsamp;
    rez.genres.gSetUp.no_channels         = NchannelRaw;
    rez.genres.gSetUp.sample_rate         = srate;
    rez.genres.gSetUp.epoch_time          = nsamp*GetSampleTime_s()  *ntrial; // Is this necessary? (JdM 20-04-2006)
    rez.genres.gSetUp.no_trials           = ntrial;
    rez.genres.gSetUp.preTrigPts          = NPreTrig;
    rez.genres.gSetUp.no_trials_done      = 0;
    rez.genres.gSetUp.no_trials_display   = 0;
    rez.genres.gSetUp.save_trials         = False;
    rez.genres.gSetUp.primaryTrigger      = 0;
    memset(rez.genres.gSetUp.secondaryTrigger, 0, MAX_AVERAGE_BINS);
    rez.genres.gSetUp.triggerPolarityMask = 0;
    rez.genres.gSetUp.trigger_mode        = 0;
    rez.genres.gSetUp.accept_reject_Flag  = False;
    rez.genres.gSetUp.run_time_display    = 0;
    rez.genres.gSetUp.zero_Head_flag      = False;
    rez.genres.gSetUp.artifact_mode       = False;
    memset(rez.genres.nfSetUp.nf_run_name, 0, sizeof(rez.genres.nfSetUp.nf_run_name));
    memset(rez.genres.nfSetUp.nf_run_title, 0, sizeof(rez.genres.nfSetUp.nf_run_title));
    memset(rez.genres.nfSetUp.nf_instruments, 0, sizeof(rez.genres.nfSetUp.nf_instruments));
    memset(rez.genres.nfSetUp.nf_collect_descriptor, 0, sizeof(rez.genres.nfSetUp.nf_collect_descriptor));
    memset(rez.genres.nfSetUp.nf_subject_id, 0, sizeof(rez.genres.nfSetUp.nf_subject_id));
    strncpy(rez.genres.nfSetUp.nf_subject_id, PatName, sizeof(rez.genres.nfSetUp.nf_subject_id)-1);
    memset(rez.genres.nfSetUp.nf_operator, 0, sizeof(rez.genres.nfSetUp.nf_operator));
    memset(rez.genres.nfSetUp.nf_sensorFileName, 0, sizeof(rez.genres.nfSetUp.nf_sensorFileName));

    rez.genres.rdlen    = 0;
    rez.run_description = NULL;
    rez.num_filters     = 0;
    rez.filters         = NULL;
    rez.chanNames       = NULL;
    rez.senres          = NULL;
    rez.numcoef         = 0;         // Disable re-referencing
    rez.scrr            = NULL;

/* Set comment string */
    if(EEGposTrue ==true && EEGlabelTrue==true)
    {
        AddComment("EEG channel positions and names based on xyz-file \n");
    }
    else
    {
        if(EEGposTrue  ==true)  AddComment("EEG channel positions based on xyz-file \n");
        if(EEGlabelTrue==true)  AddComment("EEG channel names based on xyz-file \n");
    }
    rez.genres.rdlen    = 2;
    if(GeneralComment) rez.genres.rdlen = 2+int(strlen(GeneralComment));
    rez.run_description = (char*) malloc(rez.genres.rdlen);
    if(GeneralComment) memcpy(rez.run_description,GeneralComment, rez.genres.rdlen);
    else               memcpy(rez.run_description," ", rez.genres.rdlen);

/* Set channel names and resources */
    rez.chanNames = (Str32*) calloc(NchannelRaw,32);
    rez.senres    = (NewSensorResRec*) calloc(NchannelRaw,sizeof(NewSensorResRec));
    if(rez.chanNames==NULL || rez.senres==NULL)
    {
        if(rez.chanNames) free(rez.chanNames);
        if(rez.senres )   free(rez.senres);
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Memory allocation error, CTF resources, NchannelRaw = %d. \n", NchannelRaw);
        return U_ERROR;
    }

    UEuler Head2Dewar = Dewar2Head.GetInverse();
    for(int i=0; i<NchannelRaw;i++)
    {
        memcpy(rez.chanNames[i], ChIn[i].namChannel, 32);
        rez.senres[i].qGain = 1e6;
        switch(ChIn[i].type)
        {
        case U_DAT_MEGREF:
            if(GridAll->GetSensorType(i) ==USensor::U_SEN_MAG) rez.senres[i].sensorTypeIndex = SENTYPE_MAGR;
            else                                               rez.senres[i].sensorTypeIndex = SENTYPE_GRAR;
            rez.senres[i].properGain      = GAUGE_MEG/(ChIn[i].GainFact*ChIn[i].InGain*rez.senres[i].qGain);
            break;
        case U_DAT_MEG:
            if(GridAll->GetSensorType(i) ==USensor::U_SEN_MAG) rez.senres[i].sensorTypeIndex = SENTYPE_MEGMA;
            else                                               rez.senres[i].sensorTypeIndex = SENTYPE_MEGGR;
            rez.senres[i].properGain      = GAUGE_MEG/(ChIn[i].GainFact*ChIn[i].InGain*rez.senres[i].qGain);
            break;
        case U_DAT_EEG:
            rez.senres[i].sensorTypeIndex = SENTYPE_EEG;
            rez.senres[i].properGain      = GAUGE_EEG/(ChIn[i].GainFact*ChIn[i].InGain*rez.senres[i].qGain);
            break;
        case U_DAT_ADC:
            rez.senres[i].sensorTypeIndex = SENTYPE_ADC;
            rez.senres[i].properGain      = 1./(ChIn[i].GainFact*ChIn[i].InGain*rez.senres[i].qGain);
            break;
        }

        rez.senres[i].originalRunNum  = 0;
        rez.senres[i].coilShape       = CIRCULAR;
        rez.senres[i].ioGain          = 1;
        rez.senres[i].ioOffset        = 0;
        if(GridAll->GetSensorType(i)==USensor::U_SEN_GRAD)
        {
            rez.senres[i].numCoils        = 2;
            rez.senres[i].grad_order_no   = 0;  // ???
        }
        else
        {
            rez.senres[i].numCoils        = 1;
            rez.senres[i].grad_order_no   = 0;  // ???
        }
        for(int l=0; l<MAX_COILS; l++)
        {
            rez.senres[i].coilTbl[l].position.x  = 0;
            rez.senres[i].coilTbl[l].position.y  = 0;
            rez.senres[i].coilTbl[l].position.z  = 0;
            rez.senres[i].coilTbl[l].orient.x    = 0;
            rez.senres[i].coilTbl[l].orient.y    = 0;
            rez.senres[i].coilTbl[l].orient.z    = 0;
            rez.senres[i].coilTbl[l].numturns    = 2;
            rez.senres[i].coilTbl[l].area        = 3.1384518467442;
            rez.senres[i].HdcoilTbl[l].position.x= 0;
            rez.senres[i].HdcoilTbl[l].position.y= 0;
            rez.senres[i].HdcoilTbl[l].position.z= 0;
            rez.senres[i].HdcoilTbl[l].orient.x  = 0;
            rez.senres[i].HdcoilTbl[l].orient.y  = 0;
            rez.senres[i].HdcoilTbl[l].orient.z  = 0;
            rez.senres[i].HdcoilTbl[l].numturns  = 2;
            rez.senres[i].HdcoilTbl[l].area      = 3.1384518467442;
        }

        if(ChIn[i].type==U_DAT_MEGREF)
        {
            USensor S = GridAll->GetSensor(i);
            rez.senres[i].HdcoilTbl[0].position.x = S.Getx().Getx();
            rez.senres[i].HdcoilTbl[0].position.y = S.Getx().Gety();
            rez.senres[i].HdcoilTbl[0].position.z = S.Getx().Getz();
            rez.senres[i].HdcoilTbl[0].orient.x   = S.Getn().Getx();
            rez.senres[i].HdcoilTbl[0].orient.y   = S.Getn().Gety();
            rez.senres[i].HdcoilTbl[0].orient.z   = S.Getn().Getz();
            rez.senres[i].HdcoilTbl[1].position.x = S.Getc().Getx();
            rez.senres[i].HdcoilTbl[1].position.y = S.Getc().Gety();
            rez.senres[i].HdcoilTbl[1].position.z = S.Getc().Getz();
            rez.senres[i].HdcoilTbl[1].orient.x   =-S.Getn().Getx();
            rez.senres[i].HdcoilTbl[1].orient.y   =-S.Getn().Gety();
            rez.senres[i].HdcoilTbl[1].orient.z   =-S.Getn().Getz();
            if(ChIn[i].InGain>0.)
            {
                rez.senres[i].HdcoilTbl[0].orient.x = -rez.senres[i].HdcoilTbl[0].orient.x;
                rez.senres[i].HdcoilTbl[0].orient.y = -rez.senres[i].HdcoilTbl[0].orient.y;
                rez.senres[i].HdcoilTbl[0].orient.z = -rez.senres[i].HdcoilTbl[0].orient.z;
                rez.senres[i].HdcoilTbl[1].orient.x = -rez.senres[i].HdcoilTbl[1].orient.x;
                rez.senres[i].HdcoilTbl[1].orient.y = -rez.senres[i].HdcoilTbl[1].orient.y;
                rez.senres[i].HdcoilTbl[1].orient.z = -rez.senres[i].HdcoilTbl[1].orient.z;
            }

/* Compute the sensor positions w.r.t. the dwar*/
            UVector3 xdewar;
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].position.x,
                                             rez.senres[i].HdcoilTbl[0].position.y,
                                             rez.senres[i].HdcoilTbl[0].position.z));
            rez.senres[i].coilTbl[0].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].orient.x,
                                             rez.senres[i].HdcoilTbl[0].orient.y,
                                             rez.senres[i].HdcoilTbl[0].orient.z),true);
            rez.senres[i].coilTbl[0].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].orient.z = xdewar.Getz();

            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].position.x,
                                             rez.senres[i].HdcoilTbl[1].position.y,
                                             rez.senres[i].HdcoilTbl[1].position.z));
            rez.senres[i].coilTbl[1].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].orient.x,
                                             rez.senres[i].HdcoilTbl[1].orient.y,
                                             rez.senres[i].HdcoilTbl[1].orient.z),true);
            rez.senres[i].coilTbl[1].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].orient.z = xdewar.Getz();
        }
        if(ChIn[i].type==U_DAT_MEG)
        {
            USensor S = GridAll->GetSensor(i);
            rez.senres[i].HdcoilTbl[0].position.x = S.Getx().Getx();
            rez.senres[i].HdcoilTbl[0].position.y = S.Getx().Gety();
            rez.senres[i].HdcoilTbl[0].position.z = S.Getx().Getz();
            rez.senres[i].HdcoilTbl[0].orient.x   = S.Getn().Getx();
            rez.senres[i].HdcoilTbl[0].orient.y   = S.Getn().Gety();
            rez.senres[i].HdcoilTbl[0].orient.z   = S.Getn().Getz();
            rez.senres[i].HdcoilTbl[1].position.x = S.Getc().Getx();
            rez.senres[i].HdcoilTbl[1].position.y = S.Getc().Gety();
            rez.senres[i].HdcoilTbl[1].position.z = S.Getc().Getz();
            rez.senres[i].HdcoilTbl[1].orient.x   =-S.Getn().Getx();
            rez.senres[i].HdcoilTbl[1].orient.y   =-S.Getn().Gety();
            rez.senres[i].HdcoilTbl[1].orient.z   =-S.Getn().Getz();
            if(ChIn[i].InGain>0.)
            {
                rez.senres[i].HdcoilTbl[0].orient.x = -rez.senres[i].HdcoilTbl[0].orient.x;
                rez.senres[i].HdcoilTbl[0].orient.y = -rez.senres[i].HdcoilTbl[0].orient.y;
                rez.senres[i].HdcoilTbl[0].orient.z = -rez.senres[i].HdcoilTbl[0].orient.z;
                rez.senres[i].HdcoilTbl[1].orient.x = -rez.senres[i].HdcoilTbl[1].orient.x;
                rez.senres[i].HdcoilTbl[1].orient.y = -rez.senres[i].HdcoilTbl[1].orient.y;
                rez.senres[i].HdcoilTbl[1].orient.z = -rez.senres[i].HdcoilTbl[1].orient.z;
            }

/* Compute the sensor positions w.r.t. the dwar*/
            UVector3 xdewar;
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].position.x,
                                             rez.senres[i].HdcoilTbl[0].position.y,
                                             rez.senres[i].HdcoilTbl[0].position.z));
            rez.senres[i].coilTbl[0].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[0].orient.x,
                                             rez.senres[i].HdcoilTbl[0].orient.y,
                                             rez.senres[i].HdcoilTbl[0].orient.z),true);
            rez.senres[i].coilTbl[0].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[0].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[0].orient.z = xdewar.Getz();

            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].position.x,
                                             rez.senres[i].HdcoilTbl[1].position.y,
                                             rez.senres[i].HdcoilTbl[1].position.z));
            rez.senres[i].coilTbl[1].position.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].position.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].position.z = xdewar.Getz();
            xdewar = Head2Dewar.xfm(UVector3(rez.senres[i].HdcoilTbl[1].orient.x,
                                             rez.senres[i].HdcoilTbl[1].orient.y,
                                             rez.senres[i].HdcoilTbl[1].orient.z),true);
            rez.senres[i].coilTbl[1].orient.x = xdewar.Getx();
            rez.senres[i].coilTbl[1].orient.y = xdewar.Gety();
            rez.senres[i].coilTbl[1].orient.z = xdewar.Getz();
        }
        else if(ChIn[i].type==U_DAT_EEG)
        {
            USensor S = GridAll->GetSensor(i);
            rez.senres[i].HdcoilTbl[0].position.x = S.Getx().Getx();
            rez.senres[i].HdcoilTbl[0].position.y = S.Getx().Gety();
            rez.senres[i].HdcoilTbl[0].position.z = S.Getx().Getz();
        }
        else if(ChIn[i].type==U_DAT_ADC)
        {
            USensor S = GridAll->GetSensor(i);
            rez.senres[i].HdcoilTbl[0].position.x = S.Getx().Getx();
            rez.senres[i].HdcoilTbl[0].position.y = S.Getx().Gety();
            rez.senres[i].HdcoilTbl[0].position.z = S.Getx().Getz();
        }
    }

    UCTFDataSet DS(DataFileNameOut.GetFullFileName());
    UFileName Fout(DS.GetCTFFileName());
    Fout.ReplaceExtension("res4");

    if(WriteResources(Fout.GetFullFileName(), &rez))
    {
        deleteResources(&rez);
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteHeader(). Writing to file %s\n",Fout.GetFullFileName());
        return U_ERROR;
    }
    deleteResources(&rez);
    return U_OK;
}

ErrorType UMEEGDataWriteCTF::WriteHC(void) const
{
    UCTFDataSet DS(DataFileNameOut.GetFullFileName());
    UEuler HeadToDewar = Dewar2Head.GetInverse();
    if(DS.WriteHC(NLR, HeadToDewar)!=U_OK)
    {
        CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteHC(). Writing NLR markers . \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMEEGDataWriteCTF::WriteTrial(const double* Data, DataType Dtype, int itrial) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(Dtype!=U_DAT_MEGREF && Dtype!=U_DAT_MEG && Dtype!=U_DAT_EEG && Dtype!=U_DAT_ADC)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Invalid data type (%s). \n", GetDataTypeText(Dtype));
        return U_ERROR;
    }
    if( (Dtype==U_DAT_MEGREF && nREF<=0) ||
        (Dtype==U_DAT_MEG    && nMEG<=0) ||
        (Dtype==U_DAT_EEG    && nEEG<=0) ||
        (Dtype==U_DAT_ADC    && nADC<=0) )
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Data type inconstent with header. \n");
        return U_ERROR;
    }
    if(itrial<0 || itrial>=ntrial)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). itrial out of range: itrial = %d, Ntrial = %d .\n",itrial, ntrial);
        return U_ERROR;
    }

    UCTFDataSet DS(DataFileNameOut.GetFullFileName());
    UFileName Fout(DS.GetCTFFileName());
    Fout.ReplaceExtension("meg4");

    int *buffer = new int[nsamp];
    if(buffer==NULL)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Memory allocation error. \n");
        return U_ERROR;
    }

    FILE *fpData = fopen(Fout,"rb+", false);
    if(fpData==NULL) fpData = fopen(Fout,"wb", false);

    if(!fpData)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrial(). Cannot open %s .\n", Fout.GetFullFileName());
        delete[] buffer;
        return U_ERROR;
    }

    fwrite("MEG41CP",8,1,fpData);

    static int NDigiError = 0;
    if(itrial<20) NDigiError = 0;

    int ij = 0;
    for(int i=0,iwrite=0;i<NchannelRaw;i++)
    {
        if( (ChIn[i].type != U_DAT_MEGREF ) &&
            (ChIn[i].type != U_DAT_MEG    ) &&
            (ChIn[i].type != U_DAT_EEG    ) &&
            (ChIn[i].type != U_DAT_ADC    )  ) continue;

        if(ChIn[i].SkipChannel) continue; // Added JdM 21-03-2015

        if(ChIn[i].type==Dtype)
        {
            bool OverFlow  = false;
            int  iPower    = 0;
            for(int j=0;j<nsamp;j++)
            {
                double DatCal = Data[ij++]/(ChIn[i].GainFact*ChIn[i].InGain);
                if(fabs(DatCal)>2147483647.) 
                {
                    OverFlow = true;
                    DatCal   = MIN(2147483647., MAX(-2147483647.,DatCal));
                }
                int k      = (int)floor( DatCal + .5) ;
                buffer[j]  = swapint(&k);
                iPower    += k*k;
            }
            fseek(fpData, 8+4*(nsamp*(NchannelRaw*itrial+iwrite)), SEEK_SET);
            fwrite(buffer,nsamp,4,fpData);

            if(OverFlow==true)
            {
                NDigiError++;
                if(NDigiError<10)
                    CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteTrial(). Overflow in %s data. Trial = %d, chan=%d\n", GetDataTypeText(Dtype), itrial, i);
            }
            if(iPower==0)
            {
                double Power = 0.;
                for(int j=0;j<nsamp;j++)
                    Power  += Data[ij-nsamp+j]*Data[ij-nsamp+j];
                if(Power>0.)
                {
                    NDigiError++;
                    if(NDigiError<10)
                        CI.AddToLog("WARNING: UMEEGDataWriteCTF::WriteTrial(). Digitization error (underflow) in %s. Trial = %d, chan=%d\n", GetDataTypeText(Dtype), itrial, i);
                }
            }
        }
        iwrite++;
    }
    fclose(fpData);

    delete[] buffer;
    return U_OK;
}

ErrorType UMEEGDataWriteCTF::WriteTrigger(const int* Data, int itrial) const
{
    CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteTrigger(). Function not yet implemented. \n");
    return U_ERROR;
}

ErrorType UMEEGDataWriteCTF::WriteMarkerArray(const UMarkerArray* ResampledMarkers, bool MergeExistingMarkers) const
{
    if(ResampledMarkers==NULL || ResampledMarkers->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteMarkerArray(). NULL or erroneous argument. \n");
        return U_ERROR;
    }
    if(ResampledMarkers->GetnSampTrial()!=nsamp)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteMarkerArray(). Inconsistent number of samples per trial (%d and %d) .\n",ResampledMarkers->GetnSampTrial(), nsamp);
        return U_ERROR;
    }

    UCTFDataSet DS(DataFileNameOut.GetFullFileName());
    if(NOT(MergeExistingMarkers) || NOT(DoesFileExist(DS.GetMarkerFileName()))) 
        return ResampledMarkers->WriteMarkersCTF(DS.GetMarkerFileName());

    UMarkerArray MMerge(DS.GetMarkerFileName(), this, false); // Read binary version (MarkerFil.mrk)
    MMerge.MergeMarkerArray(ResampledMarkers);
    MMerge.RemoveDoubleMarkers();
    return MMerge.WriteMarkersCTF(DS.GetMarkerFileName());
}

ErrorType UMEEGDataWriteCTF::WriteResources(UFileName FileName, resource* rez)
{
    Int16  i=0,j=0,k=0;
    char   dum[50];

    Int16  TnumParam;
    int    TnumCoils;
    int    Tnumcoef     = rez->numcoef;
    Int16  TnumChannels = rez->genres.gSetUp.no_channels;
    int    Trdlen       = rez->genres.rdlen;
    int    Tnum_filters = rez->num_filters;

/* open file*/
    FileName.ReplaceExtension(".res4");
    FILE *fp=fopen(FileName,"wb", false);
    if(!fp)
    {
        CI.AddToLog("ERROR: UMEEGDataWriteCTF::WriteResources(). Opening/creating file = %s .\n", (const char*)FileName);
        return U_ERROR;
    }
    fwrite("MEG4RES",8,1,fp);

/* Export non-IntelData */
    bool IntelData = false;

/* swap: */
    rez->genres.no_trials_avgd           = SwapVal(rez->genres.no_trials_avgd,          IntelData);
    rez->genres.rdlen                    = SwapVal((int)rez->genres.rdlen,                   IntelData);

    rez->genres.gSetUp.no_samples        = SwapVal((int)rez->genres.gSetUp.no_samples,       IntelData);
    rez->genres.gSetUp.no_channels       = SwapVal(rez->genres.gSetUp.no_channels,      IntelData);
    rez->genres.gSetUp.sample_rate       = SwapVal(rez->genres.gSetUp.sample_rate,      IntelData);
    rez->genres.gSetUp.epoch_time        = SwapVal(rez->genres.gSetUp.epoch_time,       IntelData);
    rez->genres.gSetUp.no_trials         = SwapVal(rez->genres.gSetUp.no_trials,        IntelData);
    rez->genres.gSetUp.preTrigPts        = SwapVal((int)rez->genres.gSetUp.preTrigPts,       IntelData);
    rez->genres.gSetUp.no_trials_done    = SwapVal(rez->genres.gSetUp.no_trials_done,   IntelData);
    rez->genres.gSetUp.no_trials_display = SwapVal(rez->genres.gSetUp.no_trials_display,IntelData);
    rez->genres.gSetUp.trigger_mode      = SwapVal(rez->genres.gSetUp.trigger_mode,     IntelData);
    rez->genres.gSetUp.run_time_display  = SwapVal(rez->genres.gSetUp.run_time_display, IntelData);

    memset(dum, 0, sizeof(dum));

#ifdef WRITE_STRUCT_DIRECT
    fwrite(&rez->genres,1832,1,fp);
    fwrite(&dum,4,1,fp);
#else
    fwrite(&rez->genres.appName,256,1,fp);
    fwrite(&rez->genres.dataOrigin,256,1,fp);
    fwrite(&rez->genres.dataDescription,256,1,fp);
    fwrite(&rez->genres.no_trials_avgd,1,2,fp);
    fwrite(&rez->genres.data_time,255,1,fp);
    fwrite(&rez->genres.data_date,255,1,fp);
    fwrite(&rez->genres.gSetUp.no_samples,1,4,fp);
    fwrite(&rez->genres.gSetUp.no_channels,1,2,fp);
    fwrite(&dum,2,1,fp);
    fwrite(&rez->genres.gSetUp.sample_rate,1,8,fp);
    fwrite(&rez->genres.gSetUp.epoch_time,1,8,fp);
    fwrite(&rez->genres.gSetUp.no_trials,1,2,fp);
    fwrite(&rez->genres.gSetUp.no_trials_done,1,2,fp);
    fwrite(&dum,2,1,fp);
    fwrite(&rez->genres.gSetUp.preTrigPts,1,2,fp);
    fwrite(&rez->genres.gSetUp.no_trials_display,1,2,fp);
    fwrite(&rez->genres.gSetUp.save_trials,1,1,fp);
    fwrite(&rez->genres.gSetUp.primaryTrigger,1,1,fp);
    fwrite(&rez->genres.gSetUp.secondaryTrigger,MAX_AVERAGE_BINS,1,fp);
    fwrite(&rez->genres.gSetUp.triggerPolarityMask,1,1,fp);
    fwrite(&rez->genres.gSetUp.trigger_mode,1,2,fp);
    fwrite(&rez->genres.gSetUp.accept_reject_Flag,1,1,fp);
    fwrite(&rez->genres.gSetUp.run_time_display,1,2,fp);
    fwrite(&rez->genres.gSetUp.zero_Head_flag,1,1,fp);
    fwrite(&rez->genres.gSetUp.artifact_mode,1,1,fp);
    fwrite(&dum,20,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_run_name,32,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_run_title,256,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_instruments,32,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_collect_descriptor,32,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_subject_id,32,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_operator,32,1,fp);
    fwrite(&rez->genres.nfSetUp.nf_sensorFileName,60,1,fp);
    fwrite(&rez->genres.rdlen,1,4,fp);
    fwrite(&dum,4,1,fp);
#endif
    if(Trdlen>0)
        fwrite(rez->run_description,1,Trdlen,fp);

    rez->num_filters = SwapVal(rez->num_filters,IntelData);
    fwrite(&rez->num_filters,2,1,fp);
    rez->num_filters = Tnum_filters;

    for(i=0; i<Tnum_filters; i++)
    {
        TnumParam = rez->filters[i].numParam;

        rez->filters[i].freq     =            SwapVal(     rez->filters[i].freq    ,IntelData);
        rez->filters[i].fClass   =(classType) SwapVal((int)rez->filters[i].fClass  ,IntelData);
        rez->filters[i].fType    = (filtType) SwapVal((int)rez->filters[i].fType   ,IntelData);
        rez->filters[i].numParam =            SwapVal(     rez->filters[i].numParam,IntelData);

        fwrite(&rez->filters[i].freq,8,1,fp);
        fwrite(&rez->filters[i].fClass,4,1,fp);
        fwrite(&rez->filters[i].fType,4,1,fp);
        fwrite(&rez->filters[i].numParam,2,1,fp);

        for(j=0;j<TnumParam;j++) rez->filters[i].params[j] = SwapVal(rez->filters[i].params[j],IntelData);
        fwrite(rez->filters[i].params,8,TnumParam,fp);
    }

    fwrite(rez->chanNames,32,TnumChannels,fp);


    for(j=0;j<TnumChannels;j++)
    {
        TnumCoils = rez->senres[j].numCoils;
        rez->senres[j].sensorTypeIndex =           SwapVal(     rez->senres[j].sensorTypeIndex,IntelData);
        rez->senres[j].originalRunNum  =           SwapVal(     rez->senres[j].originalRunNum ,IntelData);
        rez->senres[j].coilShape       = (CoilType)SwapVal((int)rez->senres[j].coilShape      ,IntelData);
        rez->senres[j].properGain      =           SwapVal(     rez->senres[j].properGain     ,IntelData);
        rez->senres[j].qGain           =           SwapVal(     rez->senres[j].qGain          ,IntelData);
        rez->senres[j].ioGain          =           SwapVal(     rez->senres[j].ioGain         ,IntelData);
        rez->senres[j].ioOffset        =           SwapVal(     rez->senres[j].ioOffset       ,IntelData);
        rez->senres[j].numCoils        =           SwapVal(     rez->senres[j].numCoils       ,IntelData);
        rez->senres[j].grad_order_no   =           SwapVal(     rez->senres[j].grad_order_no  ,IntelData);

        for(k=0;k<TnumCoils;k++)
        {
            rez->senres[j].coilTbl[k].position.x   = SwapVal(rez->senres[j].coilTbl[k].position.x  ,IntelData);
            rez->senres[j].coilTbl[k].position.y   = SwapVal(rez->senres[j].coilTbl[k].position.y  ,IntelData);
            rez->senres[j].coilTbl[k].position.z   = SwapVal(rez->senres[j].coilTbl[k].position.z  ,IntelData);
            rez->senres[j].coilTbl[k].orient.x     = SwapVal(rez->senres[j].coilTbl[k].orient.x    ,IntelData);
            rez->senres[j].coilTbl[k].orient.y     = SwapVal(rez->senres[j].coilTbl[k].orient.y    ,IntelData);
            rez->senres[j].coilTbl[k].orient.z     = SwapVal(rez->senres[j].coilTbl[k].orient.z    ,IntelData);
            rez->senres[j].coilTbl[k].numturns     = SwapVal(rez->senres[j].coilTbl[k].numturns    ,IntelData);
            rez->senres[j].coilTbl[k].area         = SwapVal(rez->senres[j].coilTbl[k].area        ,IntelData);
            rez->senres[j].HdcoilTbl[k].position.x = SwapVal(rez->senres[j].HdcoilTbl[k].position.x,IntelData);
            rez->senres[j].HdcoilTbl[k].position.y = SwapVal(rez->senres[j].HdcoilTbl[k].position.y,IntelData);
            rez->senres[j].HdcoilTbl[k].position.z = SwapVal(rez->senres[j].HdcoilTbl[k].position.z,IntelData);
            rez->senres[j].HdcoilTbl[k].orient.x   = SwapVal(rez->senres[j].HdcoilTbl[k].orient.x  ,IntelData);
            rez->senres[j].HdcoilTbl[k].orient.y   = SwapVal(rez->senres[j].HdcoilTbl[k].orient.y  ,IntelData);
            rez->senres[j].HdcoilTbl[k].orient.z   = SwapVal(rez->senres[j].HdcoilTbl[k].orient.z  ,IntelData);
            rez->senres[j].HdcoilTbl[k].numturns   = SwapVal(rez->senres[j].HdcoilTbl[k].numturns  ,IntelData);
            rez->senres[j].HdcoilTbl[k].area       = SwapVal(rez->senres[j].HdcoilTbl[k].area      ,IntelData);
        }
    }
#ifdef WRITE_STRUCT_DIRECT
    fwrite(rez->senres,1328,TnumChannels,fp);
#else
    for(j=0;j<TnumChannels;j++)
    {
        fwrite(&rez->senres[j].sensorTypeIndex, 1, 2, fp);
        fwrite(&rez->senres[j].originalRunNum, 1, 2, fp);
        fwrite(&rez->senres[j].coilShape, 1, 4, fp);
        fwrite(&rez->senres[j].properGain, 1, 8, fp);
        fwrite(&rez->senres[j].qGain, 1, 8, fp);
        fwrite(&rez->senres[j].ioGain, 1, 8, fp);
        fwrite(&rez->senres[j].ioOffset, 1, 8, fp);
        fwrite(&rez->senres[j].numCoils, 1, 2, fp);
        fwrite(&rez->senres[j].grad_order_no, 1, 2, fp);
        fwrite(&dum,4,1,fp);

        for(k=0;k<MAX_COILS;k++)
        {
            fwrite(&rez->senres[j].coilTbl[k].position.x, 1, 8, fp);
            fwrite(&rez->senres[j].coilTbl[k].position.y, 1, 8, fp);
            fwrite(&rez->senres[j].coilTbl[k].position.z, 1, 8, fp);
            fwrite(&dum,8,1,fp);
            fwrite(&rez->senres[j].coilTbl[k].orient.x, 1, 8, fp);
            fwrite(&rez->senres[j].coilTbl[k].orient.y, 1, 8, fp);
            fwrite(&rez->senres[j].coilTbl[k].orient.z, 1, 8, fp);
            fwrite(&dum,8,1,fp);
            fwrite(&rez->senres[j].coilTbl[k].numturns, 1, 2, fp);
            fwrite(&dum,6,1,fp);
            fwrite(&rez->senres[j].coilTbl[k].area, 1, 8, fp);
        }
        for(k=0;k<MAX_COILS;k++)
        {
            fwrite(&rez->senres[j].HdcoilTbl[k].position.x, 1, 8, fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].position.y, 1, 8, fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].position.z, 1, 8, fp);
            fwrite(&dum,8,1,fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].orient.x, 1, 8, fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].orient.y, 1, 8, fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].orient.z, 1, 8, fp);
            fwrite(&dum,8,1,fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].numturns, 1, 2, fp);
            fwrite(&dum,6,1,fp);
            fwrite(&rez->senres[j].HdcoilTbl[k].area, 1, 8, fp);
        }
    }
#endif

    rez->numcoef = SwapVal(rez->numcoef,IntelData);
    fwrite(&rez->numcoef,2,1,fp);

    for(i=0;i<Tnumcoef;i++)
    {
        rez->scrr[i].coefType              = (Bit32) SwapVal((int)rez->scrr[i].coefType            ,IntelData);
        rez->scrr[i].coefRec.num_of_coefs  =         SwapVal(     rez->scrr[i].coefRec.num_of_coefs,IntelData);
        for(j=0;j<MAX_BALANCING;j++)
            rez->scrr[i].coefRec.coefs_list[k] = SwapVal(rez->scrr[i].coefRec.coefs_list[k],IntelData);

    }

#ifdef WRITE_STRUCT_DIRECT
    fwrite(rez->scrr,1992,Tnumcoef,fp);
#else
    for(i=0;i<Tnumcoef;i++)
    {
        fwrite(&rez->scrr[i].sensorName,1,32,fp);
        fwrite(&rez->scrr[i].coefType,  4, 1,fp);
        fwrite(dum, 4, 1,fp);
        fwrite(&rez->scrr[i].coefRec.num_of_coefs, 2, 1,fp);
        fwrite(&rez->scrr[i].coefRec.sensor_list, MAX_BALANCING*SENSOR_LABEL, 1, fp);
        fwrite(&(rez->scrr[i].coefRec.coefs_list) , MAX_BALANCING,              8, fp);
    }
#endif

    fclose(fp);

    return U_OK;
}
