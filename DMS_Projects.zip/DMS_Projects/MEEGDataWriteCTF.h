#ifndef _MEEGDATAWRITECTF_INCLUDED
#define _MEEGDATAWRITECTF_INCLUDED

#include "MEEGDataWriteBase.h"
#include "MegDefs.h"

class DLL_IO UMEEGDataWriteCTF : public UMEEGDataWriteBase
{
public:
    UMEEGDataWriteCTF();
    UMEEGDataWriteCTF(const UMEEGDataBase& Data); 
    UMEEGDataWriteCTF(const UMEEGDataWriteBase& Data); 
    UMEEGDataWriteCTF(const UMEEGDataWriteCTF& Data);
    virtual ~UMEEGDataWriteCTF();
    virtual UMEEGDataWriteCTF& operator=(const UMEEGDataWriteCTF &Data);

    virtual ErrorType       DeleteBadChannelFile(void) const;
    virtual ErrorType       CopyDataFiles(const char* BaseName);
    virtual ErrorType       DeleteDataFiles(void) const;
    virtual ErrorType       RenameDataFiles(const char* BaseName);
    virtual ErrorType       SetDataFileName(UFileName FileOut);
    virtual ErrorType       SetDewar2NLR(UEuler D2N);              

/* write data */
    virtual ErrorType       WriteHeader(void);
    virtual ErrorType       WriteTrial(const double* Data, DataType Dtype, int itrial) const;
    virtual ErrorType       WriteTrigger(const int* Data, int itrial) const;

    virtual ErrorType       WriteMarkerArray(const UMarkerArray* ResampledMarkers, bool MergeExistingMarkers) const;
            ErrorType       WriteHC(void) const;
    static  ErrorType       WriteResources(UFileName Filename, resource* rez);

private:
    UEuler                  Dewar2Head;          // The Euler transform to transform the MEG sensors from Dewar to Head coordinates

    static const double     GAUGE_MEG;           // make it femto Tesla   
    static const double     GAUGE_EEG;           // make it micro Volt   
    static const double     DEF_MEG_GAIN;        // default MEG gain
    static const double     DEF_EEG_GAIN;        // default EEG gain
};


#endif// _MEEGDATAWRITECTF_INCLUDED
