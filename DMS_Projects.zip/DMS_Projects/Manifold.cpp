/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a 3D closed surface with manifold structure.       */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history

  Who    When       What
  JdM    15-03-10   creation
  JdM    15-04-10   Added GetMatrixSparseVertexConnectivity()
  JdM    25-04-10   Added SelectLargestComponent()
  JdM    27-06-10   Substantial update of GetCrossSection() and Split().
                    Allow contours of that are partly along and against QEdge orientations.
  JdM    04-07-10   Bug fix: Split(). Find edge colours by loop over faces instead of loop over vertices.
  AvR    04-07-10   ProjectSphere(). Added dir argument.
  JdM    10-07-10   Several improvements and bug fixes in GetCrossSection(). Test on 168 cases.
  JdM    18-07-10   Bug fix: GetVertexIDExtremeCoord(). Old algoritm always returned first point
JdM/AvR  23-07-10   ProjectSphereInit(). remove sqrt(sqrt()) on p.GetNorm()
  JdM    28-07-10   Bug Fix: ProjectCircle(). Testing whether point is on contour, mixed up ID and index
  JdM    11-08-10   ProjectCircle(), add argument, ProjecteSphereInit(), add three (default) arguments.
  JdM    13-08-10   GetCrossSection(). Add random number to level to avoid coincidende with coordlines
                    GetNComponents() and GetComponents(). Replaced algorithm by more robust one based on equivalence classes (old alg. did not always work correctly).
                    Added GetContourCut() and use it in newly added GetSplittedManifolds().
                    GetSplittedManifolds() replaces Split(), which is now obsolete and called SplitOld()
  JdM    29-08-10   Bug fix: CompleteTriangulation(). Triangulate from scratch
  JdM    01-09-10   Default constructor: do not create single vertex, face nor quadedge
                    WriteConnectivityText(). Reformat output.
                    Added ForceSphericalTopology()
  JdM    02-10-10   Added ProjectSphereExpand()
  JdM    14-10-10   Added ComputeMoments()
  JdM    15-10-10   Bug fix. ProjectSphereExpand() (finding second index)
  JdM    23-10-10   Added GetXfm2Moments(), ans new GetCrossSection() and new GetCrossSectionAsDrawing()
  JdM    27-10-10   Changed argument of GetMatrixSparseVertexConnectivity()
                    Added ProjectSphereConformal() and GetFaceIDExtremeCoord()
  JdM    21-11-10   Restructured ProjectCircle(). Numerical output was comparred to old code.
  JdM    01-12-10   Bug fix. ProjectSphereExpand() (testing minimum projection in combination with raw coord)
  JdM    02-12-10   Added SkipShortCuts() and used it at the end of GetCrossSection();
                    GetContourCut(). Test for short-cuts in contour
  JdM    22-12-10   ProjectSphereInit(). Swap both halves if Max0<Max1
  JdM    24-12-10   ProjectSphereInit(). Rotate contour to "standard" position
  JdM    30-12-10   Added GetLargestCrossSectionAsDrawing()
                    Bug fix: GetCrossSectionAsDrawing(). Closing contour when no points are present caused crash. Added test to prevent this.
  JdM    05-01-10   ProjectCircle(), ProjectSphereInit() and ProjectSphere(): Added Harmonic-parameter
  JdM    22-01-11   ProjectSphereConformal(). Optimized shift and scaling.
  JdM    23-01-11   Added GetTipVertexID() and GetTipFaceID()
  JdM    28-01-11   Added GetClosestDirVertexID()
  JdM    12-02-11   Merge(). Changed way to make IDs unique.
                    Assure sorted IDs in vertices[], faces[] and qedges[] and use optimized serach in
                    FindVertex(), FindFace() and FindQuadEdge()
  JdM    12-10-11   Added GetVertexThetaArray() and GetVertexFiArray()
  JdM    06-11-11   Added GetVertexStretchArray()
TA/JdM   16-02-12   Added another GetTipVertexID() and GetTipFaceID()
  TA     16-02-12   Bug Fix: GetVertexStretchArray() (used wrong vertex initializer)
  JdM    16-05-12   Split AddTriangle() into two parts.
  JdM    27-05-12   Added Marching Cubes constructors
  JdM    02-08-12   ExpandSphere(). Use pow(,1./3.) instead of sqrt()
  JdM    13-08-12   ProjectSphereConformal(), insert new parameter: bool MinimizeMedianZ
  JdM    15-08-12   Added RemoveFlatTriangles()
                    BUG FIX: AddVertex(), AddFace() and AddQuadEdge(). Keeping ID s sorted (try first item in array)
                    GetClosestDirVertexID(), add NegDir parameter, add another, generic, version of GetClosestDirVertexID()
                    GetMomentDir()
  JdM    17-08-12   SmoothSphereHarm(). Center *this before projection, then shift back before returning
  JdM    23-08-12   ExpandSphereAcos(). Added (default) parameter Lam
  JdM    28-08-12   Added GetFaceMedian(), GetVertexMedian(), RemoveFaceOutliers() and related functions
  JdM    30-08-12   Added GetNVertexCrossings() and GetVertexProjections()
  JdM    03-09-12   Added GetMorfedSurface() and MorfVerices()
                    Added GetFaceCenterFromID()
  JdM    06-09-12   Added another GetVertexProjections()
  JdM    21-10-12   BUG FIX: MorfVertices(). Don't update vertices on the flight, but store updates in temporary array.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    24-10-14   RemoveFlatTriangles(). Lowered default argument from 1.e-7 to 1.e-10
  JdM    12-11-14   GetXfm2Moments(). Added parameter
  JdM    15-12-14   GetProperties(). Added number of components for small object
  JdM    28-02-15   Use new LevelType type for MarchingCubes constructors
  JdM    11-04-15   SelectLargestComponent(). Added default parameter (old number of components)
  JdM    18-04-15   Added GetPathLength()
  JdM    05-11-15   Added GetVertexCurveVector(), GetVertexMeanCurvature(), GetVertexAngleDeficit() and GetVertexGaussCurvature()
                    Added GetSmoothedVertexData() and SmoothVertices()
  JdM    10-11-15   Added GetVertexNeighbourIDs(), MarkNeighbours(), GetMeanCurvature() and extended GetProperties()
  JdM    23-12-15   Added GetVertexMinCurvature() and GetVertexMaxCurvature()
  JdM    27-12-15   Added GetVerticesAsPointList() and double contour constructor
  JdM    30-12-15   GetCrossSectionAsDrawing(). Do not copy first point of contour to close, but call UPointList::CloseLastSegment()
  JdM    01-02-16   Added UPointList() constructors. 
  JdM    29-02-16   Added WriteEvolver(). UPointList constructors: Set lowest vertex IDs to boundary points.
                    BUG FIX: FindQuadEdge(int, int). In case LoopO==true or LoopD==true, also test reversed ordering of IDs
  JdM    01-04-16   Added MinimizeMeanCurvature() and RandomizeVertices()
  JdM    05-04-16   Renamed MinimizeMeanCurvature() as MinimizeCurvature() and added bool parameter
  JdM    06-04-16   Added GetVertexAngleDeficit()
  JdM    10-04-16   BUG FIX. UPointList constructor. Contouring algoritm. 
  JdM    23-04-16   UPointList constructor. Added torsion reduction. 
  JdM    24-04-16   Added GetCrossSectionAsFlatDrawing()
                    Use UInterpolateCircle for contour interpolation in UPointList constructor.
  JdM    06-05-16   Renamed CompleteTriangulation() as CompleteTriangulationScratch(), added CompleteTriangulation(bool) which only modifies non-triangle faces. 
                    Removed (obsolete) Simplify
                    Added RemoveEdgeMergeFaces() and RemoveEdgeMergeVertices() and GetLengthFromID()
  JdM    08-05-16   Added SwapEdgeID()
  JdM    10-05-16   Added MaximizeMinAngleSwapEdge() and MaximizeVolumeSwapEdge() and MinimizeCurvatureSwapEdge()
                    Added RemoveEdges()
                    Removed obsolete functions:  DeleteVertex(), DeleteFace(), DeleteQuadEdge(), RemoveDoubleEdges(), RemoveVertexEdge(), MakeFaceEdge(), RemoveFaceEdge()
                    This was only used in ProjectCicle(), references blocked.
  JdM    16-05-16   MinimizeCurvature(). Add gravity points when completing triangulation, do not include derivatives to these new points (added parameter to UMinimizeCurve)
  JdM    16-05-16   Bug Fix UPointList constructor. Setting the correct number of intermediate layers.
  JdM    23-05-16   Added InterpolateVertices()
  JdM    28-05-16   Added Maximize parameter on SwapEdgeID().
                    Added GetPyramid()
  JdM    29-05-16   WriteConnectivityText(). Write text in parts, using "at" mode.
                    Added MergeFaces()
  JdM    03-06-16   UPointList constructor. Restored shortest distance shift pre-processing. Added AddCap parameter
  JdM    16-06-16   InterpolateVertices(). Allow NULL pointer for FixedIDs to fix all vertices (and smooth them)
  JdM    17-07-16   Added GetVertexNNeighborsMatrix()
                    GetMatrixSparseVertexConnectivity(): return UMatrixSparse instead of UMatrixSparse*
  FaB    18-07-16   Bug fix: UPointList constructor. Corrected NContInter (added 1). dd 22-06-16
  JdM    26-07-16   UPointList constructor and InterpolateVertices(). Use newly defined TypePenalty as argument
 JdM/FaB 12-09-16   Bug Fix: GetCrossSectionAsFlatDrawing(). In case of more than one contour iedge was not properly initialized
  JdM    21-10-16   UPointList constructor. Account for orientation of contours. 
  JdM    24-10-16   Added GetFrustum()
  JdM    27-10-16   Added GetFace(), GetQuadEdge(), MergeEdgesSameFace() and GetJuction()
  JdM    28-10-16   Bug FIX: MergeFaces(). Do not delete F (only FM). 
                    Added GetVertex()
  JdM    01-11-16   Added output parameter to UPointList constructor
                    Added GetClosestVertextIDs()
                    InterpolateVertices(). Skip double IDs
  JdM    10-11-16   Bug FIX: MergeFaces(). Delete both F and FM. 
  JdM    15-12-16   Added RenumberVerticesFacesEdges(). Reimplemented GetFrustrum(). GetCylinder(): reorder face IDs
  JdM    21-10-16   UPointList constructor. Reimplemted the algorithm on the basis of GetFrustum() and (new) GetPointsFromContours()
  JdM    17-02-17   Added new InterpolateVertices(), based on "vertex directions", derived from Marching Cubes
  JdM    27-02-17   UPointList constructor. Made AddCap int. 0: no caps added. <0: add flat caps. >0: add curved caps
  JdM    05-03-17   Added ReconstructFromRandomSubset()
  JdM    10-03-17   InterpolateVertices() and ReconstructFromRandomSubset(): allow order<0 to use U_CONNECT_HARMONIC i.s.o U_CONNECT_LAPLACIAN
  JdM    17-03-17   Reimplement InterpolateVertices() according to notation in Botsch et al. Replace ConnectType by LaplacianType. Added GetMatrixSparseVertexLaplacian()
  JdM    06-04-17   GetMatrixSparseVertexLaplacian(). Aplly scaling of diagonal in case of U_LAPLACIAN_HARMONIC. Use GetTotalArea()
  JdM    07-04-17   Added GetVertexVoronoiArea(). ReconstructFromRandomSubset(): added area-ratio parameter
  JdM    09-04-17   Added InterpolateVertices() based on thresholded vertex data
  JdM    06-06-17   UPointList constructor. Allow NSublayer==2 (or larger)
  JdM    07-07-17   Added GetCoordMatrix() and SetCoordMatrix()
  JdM    10-07-17   Added GetLevelContours(), re-implemented GetCrossSection()
  JdM    11-07-17   Added GetDrawing(), GetVertexIDs()
  JdM    11-07-17   Bug Fix. GetContourCut(). Adapt to change dd 29-02-16 (FindQuadEdge(int,int)), which does not account for direction anymore.
  JdM    17-07-17   Added GetNVertexNeigbours()
  JdM    24-07-17   Added GetLevelContoursAsDrawing() and InterpolateVertices(). Renamed GetLevelCountours() as GetLevelContours()
  JdM    28-07-17   Improved InterpolateVertices() such that it can deal with "handles". First merge all faces on both cut faces, finally take larges component.
  JdM    13-08-17   Bug Fix. SortVertices(), SorFaces(), SortEdges(). Testing for identical IDs (Use "<" instead of "<=" in line after qsort())
                    GetContourCut(). Use extra argument.
  JdM    17-08-17   Added GetVertexComponentMembership()
  JdM    23-08-17   Added another MarkNeighbours()
  JdM    27-08-17   SelectLargestComponent(), GetNComponents() and GetComponents(). Avoid GetEquivalenceClass(). Use much faster GetVertexComponentMembership()
  JdM    30-08-17   InterpolateVertices() (from contours: remove obsolete penalty arguments)
  JdM    31-08-17   InterpolateVertices(). Use symmetric version of Laplacian for efficiend power raising.
                    GetMatrixSparseVertexLaplacian(). Remove obsolete and ambigeous argument to (not) invert the diagonal.
  JdM    26-09-17   Added another GetDrawing()
  JdM    01-10-17   Added UpdateLastIDs() and ::GetStrip()
  JdM    04-10-17   BUG fix. GetPathLength(). Computing shortest path (path legngth was OK)
  JdM    05-10-17   GetPyramid(). Added parameter.
  JdM    07-10-17   Added WriteVTK(), RemoveHandles(), RemoveFirstHandle()
                    GetSurface(). Do not output warnings in case of non-triangluar faces
  JdM    08-10-17   Renamed MarkNeighbours() as MarkVertexNeighbours()
                    MergeFaces(): added call to UpdateLastIDs()
                    GetPyramid(). Allow MaxHeight==1
  JdM    10-10-17   Added integer version ofGetLevelContours(). Added RemoveOutliers()
  JdM    12-10-17   MergeFaces(). Account for vertex offset when merging matched faces
  JdM    13-10-17   Added GetVertextID().
                    InterplateVertices(). Inserted FiedFree parameter
  JdM    14-10-17   Added MergeIDs() and GetTrangulatedCompletion()
                    Bug Fix: RemoveEdgeMergeFaces(). last loops: run to NFace-1 and NQEdge-1, iso NFace and NQEdge
                    Added GetTrangulatedCompletion()
  JdM    17-10-17   Bug Fix: GetFrustum(). Case of two NULL pointer arguments was not properly treated.
                    Added WriteVTKVertexData()
  JdM    20-10-17   Added AddEdgeSameFace()
  JdM    11-06-18   Contour constructors: Use UPointList instead of UDrawing data type
  JdM    10-07-18   Bug Fix. InterpolateVertices(). In case of L1 penalty, call MS.ApplySettings().
                    InterpolateVertices(). Skip multiplication of Lamda2 with NVertex (Use Lamda2 as is).
  JdM    13-09-18   UPointList constructors. Changed the algoritmhm by which AddCaps determines the meshsize of the cap. (abs==1 -> automatic).
  */
#include<math.h>

#include "ManifoldHandle.h" // Should be included first!
#include "Manifold.h"
#include "MatrixSparse.h"
#include "MatrixSquare.h"

#include "SphereHarm.h"
#include "Drawing.h"
#include "SortSemiSort.h"
#include "Random.h"

#include "FieldGraph.h"
#include "MarchingCubes.h"
#include "InterpolateCircle.h"
#include "LassoBregman.h"

#include "Distribution.h"
 
#define EIGEN_THRESHOLD 1.e-8   // Eigen value truncation of inverted matrix, used
                                // in the computation of spherical harmonics coefficients.

/* Inititalize static (const) parameters. */
UString UManifold::Properties = UString();

void UManifold::SetAllMembersDefault(void)
{
    error           = U_OK;
    NVertex         = 0;
    NVertexAlloc    = 0;
    LastVertexID    = 0;
    vertices        = NULL;

    NFace           = 0;
    NFaceAlloc      = 0;
    LastFaceID      = 0;
    faces           = NULL;

    NQEdge          = 0;
    NQEdgeAlloc     = 0;
    LastQuadEdgeID  = 0;
    qedges          = NULL;
}
void UManifold::DeleteAllMembers(ErrorType E)
{
    if(vertices) for(int k=0; k<NVertex; k++) delete vertices[k]; delete[] vertices;
    if(faces)    for(int k=0; k<NFace;   k++) delete faces[k];    delete[] faces;
    if(qedges)   for(int k=0; k<NQEdge;  k++) delete qedges[k];   delete[] qedges;

    SetAllMembersDefault();
    error = E;
}

UManifold::UManifold()
{
    SetAllMembersDefault();
}
UManifold::UManifold(const UManifold &m)
{
    SetAllMembersDefault();
    *this = m;
}
UManifold::UManifold(const USurface& S)
{
    SetAllMembersDefault();
    if(&S==NULL || S.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Invalid USurface argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    const UVector3*   p    = S.GetPoints();
    const int*        Tril = S.GetTriList();
    for(int it=0; it<S.GetNtri(); it++)
        AddTriangle(Tril[3*it+0],Tril[3*it+1],Tril[3*it+2],p);
}
UManifold::UManifold(const UPointList* Cbot, const UPointList* Ctop, int NPcontInter, int NSublayer, int order, int AddCap)
{
    SetAllMembersDefault();
    if(Cbot==NULL || Cbot->GetError()!=U_OK || Cbot->GetNpoints()<3)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). NULL or erroneous bottom contour, NPbot = %d (<3). \n", Cbot?Cbot->GetNpoints():-1);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Ctop==NULL || Ctop->GetError()!=U_OK || Ctop->GetNpoints()<3)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). NULL or erroneous bottom contour, NPtop = %d (<3). \n", Ctop?Ctop->GetNpoints():-1);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if((NPcontInter>0&&NPcontInter<4) || NSublayer<2)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Parameters out of range: NPcontInter=%d, NContInter=%d. \n", NPcontInter, NSublayer);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(order!=0 && order!=1 && order!=2 && order!=3)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Parameters out of range: order=%d. \n", order);
        DeleteAllMembers(U_ERROR);
        return;
    }

    const UPointList* Cont[2] = {Cbot, Ctop}; 
    *this = UManifold(Cont, 2, NPcontInter, NSublayer, order, AddCap, U_PENALTY_NO, 0.);
}
UManifold::UManifold(const UPointList** Cont, int NCont, int NPcontInter, int NSublayer, int order, int AddCap, TypePenalty PT, double Lamda2, int** VertexBoundID)
{
    SetAllMembersDefault();

    if(VertexBoundID) *VertexBoundID = NULL;
    if(Cont==NULL || NCont<=1)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Invalid NULL argument, or NCont (=%d) parameter out of range. \n", NCont);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if((NPcontInter>0&&NPcontInter<4) || NSublayer<2)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Parameters out of range: NPcontInter=%d, NContInter=%d (NCont=%d). \n", NPcontInter, NSublayer, NCont);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(order!=0 && order!=1 && order!=2 && order!=3)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Parameters out of range: order=%d. \n", order);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(AddCap>0 && order==0)
        CI.AddToLog("WARNING: UManifold::UManifold(). AddCap parameters ignored, order=%d. \n", order);

    if(((PT==U_PENALTY_L1 || PT==U_PENALTY_L2) && Lamda2<=0.) || PT==U_PENALTY_UNKNOWN)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Parameters out of range: PT=%d, Lamdat2=%f. \n", int(PT), Lamda2);
        DeleteAllMembers(U_ERROR);
        return;
    }

    int NBound = 0;
    for(int ic=0; ic<NCont; ic++)
    {
        if(Cont[ic]==NULL || Cont[ic]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::UManifold(). NULL or erroneous drawing ic = %d. \n", ic);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(Cont[ic]->GetNpoints()<3)
        {
            CI.AddToLog("ERROR: UManifold::UManifold(). Invalid contour, Npoints[%d] = %d (<3). \n", ic, Cont[ic]->GetNpoints());
            DeleteAllMembers(U_ERROR);
            return;
        }
        NBound += ((NPcontInter<=0) ? Cont[ic]->GetNpoints() : NPcontInter);
    }
    int*      NPOff    = NULL;
    UVector3* Pnts     = GetPointsFromContours(Cont, NCont, NPcontInter, &NPOff);
    int*      BoundID  = new int[NBound];             // IDs of boundary nodes
    if(NPOff==NULL || Pnts==NULL || BoundID==NULL)
    {
        delete[] NPOff; delete[] Pnts; delete[] BoundID;
        CI.AddToLog("ERROR: UManifold::UManifold(). Creating points from contours. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int ib=0; ib<NBound; ib++) BoundID[ib] = -1;
    UFace*    Fbot = NULL;
    UFace*    Ftop = NULL;
    ErrorType E    = U_OK;
    for(int ilayer=0; ilayer<NCont-1 && E==U_OK; ilayer++)
    {
        int FBotID = -1;
        int FTopID = -1;
        int NPbot       = NPOff[ilayer+1]-NPOff[ilayer  ];
        int NPtop       = NPOff[ilayer+2]-NPOff[ilayer+1];
        UManifold* MLayer = GetFrustum(NPbot, Pnts+NPOff[ilayer], NPtop, Pnts+NPOff[ilayer+1], NSublayer+1, &FBotID, &FTopID);
        if(MLayer==NULL || MLayer->GetError()!=U_OK)
        {
            delete[] NPOff; delete[] Pnts; delete[] BoundID;
            CI.AddToLog("ERROR: UManifold::UManifold(). Getting layer %d. \n", ilayer);
            DeleteAllMembers(U_ERROR);
            return;
        }
        int       NN = -1;
        if(ilayer==0) 
        {
            *this    = *MLayer;
            UFace* F = GetFace(FBotID); Fbot = F;
            if(E==U_OK && F) E = F->GetNeigborVertexIDs(BoundID+NPOff[0],&NN);
            F        = GetFace(FTopID); Ftop = F;
            if(E==U_OK && F) E = F->GetNeigborVertexIDs(BoundID+NPOff[1],&NN);
        }
        else
        {
            if(E==U_OK) E = MergeFaces(LastFaceID, *MLayer, FBotID);
            UFace*      F = GetFace(LastFaceID); Ftop = F;
            if(E==U_OK && F) E = F->GetNeigborVertexIDs(BoundID+NPOff[ilayer+1],&NN);
        }
        delete MLayer;
    }
    delete[] NPOff; delete[] Pnts; 
    if(NPOff==NULL || Pnts==NULL || BoundID==NULL)
    {
        delete[] BoundID;
        CI.AddToLog("ERROR: UManifold::UManifold(). Adding layers. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    
    int NVertCaps = 0;
    if(AddCap!=0 && order>0)
    {
        int           NBaseT = (NPcontInter<=0) ? Ftop->GetNEdge() : NPcontInter;
        int           NBaseB = (NPcontInter<=0) ? Fbot->GetNEdge() : NPcontInter;
        int           MaxH   = abs(AddCap)==1 ? (NBaseT/10) : abs(AddCap);
        int           IDcap  = 0;
        UManifold*    Mcap   = GetPyramid(NBaseT, NULL, MaxH, &IDcap, false);
        NVertCaps           += (Mcap==NULL || Mcap->GetError()!=U_OK) ? 0 : Mcap->GetNVertex()-NBaseT;
        if(Mcap==NULL || Mcap->GetError()!=U_OK || MergeFaces(Ftop->GetID(), *Mcap, IDcap)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::UManifold(). Creating/adding top cap. \n");
            DeleteAllMembers(U_ERROR);
            delete Mcap; delete[] BoundID;
            return;
        }
        MaxH   = abs(AddCap)==1 ? (NBaseB/10) : abs(AddCap);
        delete Mcap;  Mcap  = GetPyramid(NBaseB, NULL, MaxH, &IDcap, false);
        NVertCaps           += (Mcap==NULL || Mcap->GetError()!=U_OK) ? 0 : Mcap->GetNVertex()-NBaseB;
        if(Mcap==NULL || Mcap->GetError()!=U_OK || MergeFaces(Fbot->GetID(), *Mcap, IDcap)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::UManifold(). Creating/adding bottom cap. \n");
            DeleteAllMembers(U_ERROR);
            delete Mcap; delete[] BoundID;
            return;
        }
        delete Mcap;
    }
    SortVertices();

    if(order>0 && InterpolateVertices(BoundID, NBound, true, order, PT, Lamda2)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::UManifold(). Interpolating vertices. \n");
        DeleteAllMembers(U_ERROR);
        delete[] BoundID;
        return;
    }
    if(AddCap<0) // Make added caps flat
    {
        int  NBoundNoCap  = NVertex-NVertCaps;
        int* BoundIDNoCap = NVertCaps<=0 || NVertCaps>=NVertex ? NULL : new int[NBoundNoCap];
        if(BoundIDNoCap==NULL)
        {
            CI.AddToLog("WARNING: UManifold::UManifold(). N added vertertices out of range (NVertCaps=%d). \n", NVertCaps);
        }
        else
        {
            for(int k=0; k<NBoundNoCap; k++) BoundIDNoCap[k] = vertices[k]->GetID();
            if(InterpolateVertices(BoundIDNoCap, NBoundNoCap, true, 1, U_PENALTY_NO, 0.)!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::UManifold(). Flattening caps. \n");
                DeleteAllMembers(U_ERROR);
                delete[] BoundID; delete[] BoundIDNoCap;
                return;
            }
        }
        delete[] BoundIDNoCap;
    }
    if(VertexBoundID) *VertexBoundID = BoundID;
    else              delete[] BoundID;
}
UManifold::UManifold(const UField* F, int Level, LevelType LevT)
{
    SetAllMembersDefault();

    if(F==NULL || F->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). NULL or erroneous UField- argument. \n");
        return;
    }
    if(F->GetFType()!=UField::U_UNIFORM &&
       F->GetFType()!=UField::U_RECTILINEAR)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field of wrong type (%d). \n",F->GetFType());
        return;
    }
    if(F->GetDType()!=UField::U_BYTE &&
       F->GetDType()!=UField::U_SHORT &&
       F->GetDType()!=UField::U_INTEGER)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field has wrong data type (%d). \n",F->GetDType());
        return;
    }
    if(F->Getndim()!=3       || F->GetDimensions(0)<2 ||
       F->GetDimensions(1)<2 || F->GetDimensions(2)<2)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field has wrong dimensions (%s). \n",F->GetProperties(""));
        return;
    }
    int icomp        = 0;
    int NLevelPoints = F->GetNLevelPoints(Level, LevT, icomp);
    if(NLevelPoints<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input has no point corresponding with given level (Level=%d, NLevelPoints=%d) \n",Level, NLevelPoints);
        return;
    }

    bool CreateManifold = true;
    UMarchingCubes MC(F, Level, LevT, CreateManifold);
    if(MC.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Creating UMarchingCubes object. \n");
        return;
    }

    int         veclen = F->GetVeclen();
    int         xoff   = veclen*F->GetDimensions(0);
    int         xyoff  = veclen*F->GetDimensions(1)*F->GetDimensions(0);
    unsigned char* bd  = F->GetBdata();
    short*         sd  = F->GetSdata();
    int*           id  = F->GetIdata();
    int io[8]          = {0, 0, 0, 0,  0,  0,  0,   0};
    for(int z=0; z<F->GetDimensions(2)-1; z++)
    {
        if(error!=U_OK) break;
        error = MC.NextSlice();
        if(error!=U_OK) break;
        for(int y=0; y<F->GetDimensions(1)-1; y++)
        {
            if(error!=U_OK) break;
            int off = z*xyoff + y*xoff + icomp;
            io[0]   = off            ;
            io[1]   = off     +veclen;
            io[2]   = off+xoff+veclen;
            io[3]   = off+xoff       ;
            off    += xyoff;
            io[4]   = off            ;
            io[5]   = off     +veclen;
            io[6]   = off+xoff+veclen;
            io[7]   = off+xoff       ;

            for(int x=0; x<F->GetDimensions(0)-1; x++)
            {
                int Val[8];
                switch(F->GetDType())
                {
                case UField::U_BYTE:    for(int k=0; k<8; k++) Val[k] = bd[io[k]]; break;
                case UField::U_SHORT:   for(int k=0; k<8; k++) Val[k] = sd[io[k]]; break;
                case UField::U_INTEGER: for(int k=0; k<8; k++) Val[k] = id[io[k]]; break;
                default:  break;
                }

                if(MC.AddCube(x, y, Val)!=U_OK)
                {
                    error = U_ERROR;
                    break;
                }
                for(int k=0; k<8; k++) io[k] += veclen;
            }
        }
    }
    if(error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Processing cubes. \n");
        return;
    }
    *this = *MC.GetManifold();
}
UManifold::UManifold(const UField* F, double Level, LevelType LevT)
{
    SetAllMembersDefault();

    if(F==NULL || F->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). NULL or erroneous UField- argument. \n");
        return;
    }
    if(F->GetFType()!=UField::U_UNIFORM &&
       F->GetFType()!=UField::U_RECTILINEAR)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field of wrong type (%d). \n",F->GetFType());
        return;
    }
    if(F->GetDType()!=UField::U_FLOAT  &&
       F->GetDType()!=UField::U_DOUBLE)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field has wrong data type (%d). \n",F->GetDType());
        return;
    }
    if(F->Getndim()!=3       || F->GetDimensions(0)<2 ||
       F->GetDimensions(1)<2 || F->GetDimensions(2)<2)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input field has wrong dimensions (%s). \n",F->GetProperties(""));
        return;
    }
    int icomp        = 0;
    int NLevelPoints = F->GetNLevelPoints(Level, LevT, icomp);
    if(NLevelPoints<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Input has no point corresponding with given level (Level=%d, NLevelPoints=%d) \n",Level, NLevelPoints);
        return;
    }

    bool CreateManifold = false;
    UMarchingCubes MC(F, Level, LevT, CreateManifold);
    if(MC.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Creating UMarchingCubes object. \n");
        return;
    }
    int         veclen = F->GetVeclen();
    int         xoff   = veclen*F->GetDimensions(0);
    int         xyoff  = veclen*F->GetDimensions(1)*F->GetDimensions(0);
    float*      fd     = F->GetFdata();
    double*     dd     = F->GetDdata();
    int io[8]          = {0, 0, 0, 0, 0, 0,  0, 0};
    for(int z=0; z<F->GetDimensions(2)-1; z++)
    {
        if(error!=U_OK) break;
        error = MC.NextSlice();
        if(error!=U_OK) break;
        for(int y=0; y<F->GetDimensions(1)-1; y++)
        {
            if(error!=U_OK) break;
            int off = z*xyoff + y*xoff + icomp;
            io[0]   = off            ;
            io[1]   = off     +veclen;
            io[2]   = off+xoff+veclen;
            io[3]   = off+xoff       ;
            off    += xyoff;
            io[4]   = off            ;
            io[5]   = off     +veclen;
            io[6]   = off+xoff+veclen;
            io[7]   = off+xoff       ;

            for(int x=0; x<F->GetDimensions(0)-1; x++)
            {
                double Val[8];
                switch(F->GetDType())
                {
                case UField::U_FLOAT:   for(int k=0; k<8; k++) Val[k] = fd[io[k]]; break;
                case UField::U_DOUBLE:  for(int k=0; k<8; k++) Val[k] = dd[io[k]]; break;
                default:  break;
                }

                if(MC.AddCube(x, y, Val)!=U_OK)
                {
                    error = U_ERROR;
                    break;
                }
                for(int k=0; k<8; k++) io[k] += veclen;
            }
        }
    }
    if(error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::UManifold(). Processing cubes. \n");
        return;
    }
    *this = *MC.GetManifold();
}

UManifold::~UManifold()
{
    DeleteAllMembers(U_OK);
}

int* UManifold::GetVertexIDs() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDs(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDs(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    int* IDarr = new int[NVertex];
    if(IDarr==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDs(). Memory allocation (NVertex=%d). \n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) IDarr[n] = (vertices[n]) ? vertices[n]->GetID() : -1;

    return IDarr;
}
ErrorType UManifold::WriteVTK(UFileName FileName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTK(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::WriteVTK(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    USurface* S = GetSurface(FileName.GetBaseName(), true);
    if(S==NULL || S->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTK(). Getting USurface object. \n");
        delete S;
        return U_ERROR;
    }
    if(S->WriteVTK(FileName, ULinTran(), UColor())!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTK(). Writing Surface as VTK-file. \n");
        delete S;
        return U_ERROR;
    }
    delete S;
    return U_OK;
}
ErrorType UManifold::WriteVTKVertexData(UFileName FileName, const double** Data, int NDataVec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Data argument is NULL. \n");
        return U_ERROR;
    }
    if(NDataVec<=0)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Invalid argument: NDataVec=%d. \n", NDataVec);
        return U_ERROR;
    }
    for(int k=0; k<NDataVec; k++)
    {
        if(Data[k]) continue;
        CI.AddToLog("ERROR: USurface::WriteVTKVertexData(). Data[%d] is NULL. \n", k);
        return U_ERROR;
    }

    USurface* S = GetSurface(FileName.GetBaseName(), true);
    if(S==NULL || S->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Getting USurface object. \n");
        delete S;
        return U_ERROR;
    }
    if(S->WriteVTKVertexData(FileName, ULinTran(), Data, NDataVec)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteVTKVertexData(). Writing Surface as VTK-file. \n");
        delete S;
        return U_ERROR;
    }
    delete S;
    return U_OK;
}

ErrorType UManifold::WriteMatLab(UFileName FileName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteMatLab(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::WriteMatLab(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    UFileName FPoints = FileName;  FPoints.InsertBeforeExtension("_Pts");
    UFileName FTriang = FileName;  FTriang.InsertBeforeExtension("_Tri");

    FILE* fpP = fopen(FPoints, "wt", false);
    FILE* fpT = fopen(FTriang, "wt", false);
    if(fpP==NULL)
    {
        if(fpT) fclose(fpT);
        CI.AddToLog("ERROR: UManifold::WriteMatLab(). Cannot open points file (%s) .\n", (const char*)FPoints);
        return U_ERROR;
    }
    if(fpT==NULL)
    {
        if(fpP) fclose(fpP);
        CI.AddToLog("ERROR: UManifold::WriteMatLab(). Cannot open triangle file (%s) .\n", (const char*)FTriang);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++)
        fprintf(fpP,"%f \t%f \t%f\n", vertices[n]->Getx(), vertices[n]->Gety(), vertices[n]->Getz() );
    fclose(fpP);

    const int FACENNEIGH = 3;
    for(int n=0; n<NFace; n++)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);
        int  NNeig = FEI.GetNNeighbour();
        if(NNeig!=FACENNEIGH)
        {
            CI.AddToLog("WARNING: UManifold::WriteMatLab(). Skipping face %d with %d edges.\n", F->GetID(), NNeig);
            continue;
        }

        UEdge*   E = FEI.GetStart();
        for(int k=0; k<FACENNEIGH; k++, E=FEI.GetNext())
        {
            if(E==NULL || E->GetSym()==NULL || E->GetSym()->GetOrg()==NULL)
            {
                CI.AddToLog("ERROR: UManifold::WriteMatLab(). Invalid edge structure of face %d (k=%d) .\n", n, k);
                fclose(fpT);
                return U_ERROR;
            }
            int id = E->GetOrg()->GetID();
            int in = FindVertex(id);
            if(in<0 || in>=NVertex)
            {
                CI.AddToLog("ERROR: UManifold::WriteMatLab(). vertex ID (%d) not found or out of range (%d).\n", id, in);
                fclose(fpT);
                return U_ERROR;
            }
            fprintf(fpT,"\t%d ", in+1);
        }
        fprintf(fpT,"\n");
    }
    fclose(fpT);

    return U_OK;
}
ErrorType UManifold::WriteEvolver(UFileName FileName, int Nfixed) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteEvolver(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::WriteEvolver(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    UFileName FEvolve = FileName;  FEvolve.SetExtension("fe");

    FILE* fp = fopen(FEvolve, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UManifold::WriteEvolver(). Cannot create points file (%s) .\n", (const char*)FEvolve);
        return U_ERROR;
    }
    fprintf(fp,"vertices\n");
    for(int n=0; n<NVertex; n++)
    {
        int ID = vertices[n]->GetID();
        if(ID<Nfixed) fprintf(fp,"%d %f %f %f fixed\n", ID+1, vertices[n]->Getx(), vertices[n]->Gety(), vertices[n]->Getz() );
        else          fprintf(fp,"%d %f %f %f      \n", ID+1, vertices[n]->Getx(), vertices[n]->Gety(), vertices[n]->Getz() );
    }

    fprintf(fp,"edges\n");
    for(int n=0; n<NQEdge; n++)
    {
        int ID = qedges[n]->GetID();
        fprintf(fp,"%d %d %d       \n", ID+1, qedges[n]->GetOrgID()+1, qedges[n]->GetDestID()+1 );
    }

    fprintf(fp,"faces\n");
    for(int n=0; n<NFace; n++)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);

        fprintf(fp,"%d ", F->GetID()+1);
        for(UEdge* E=FEI.GetStart(); E; E=FEI.GetNext())
        {
            int IDo = E->GetOrg() ->GetID();
            int IDd = E->GetDest()->GetID();
            int ind = FindQuadEdge(IDo, IDd);
            if(ind<0)
            {
                CI.AddToLog("ERROR: UManifold::WriteEvolver(). QuadEdgde (%d, %d) not found or out of range.\n", IDo,IDd);
                fclose(fp);
                return U_ERROR;
            }
            if(qedges[ind]->GetOrgID()==IDo) fprintf(fp, "%d ", qedges[ind]->GetID()+1);
            else                             fprintf(fp, "%d ",-qedges[ind]->GetID()-1);
        }
        fprintf(fp, " \n");
    }
    fclose(fp);

    return U_OK;
}

ErrorType UManifold::GetMinMaxBox(UVector3* Min, UVector3* Max) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMinMaxBox(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetMinMaxBox(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetMinMaxBox(). Invalid NULL argument(s) .\n");
        return U_ERROR;
    }
    *Min = *Max = *(vertices[0]);
    for(int n=1; n<NVertex; n++)
    {
        if((*vertices[n])[0] < Min->Getx()) Min->Setx((*vertices[n])[0]);
        if((*vertices[n])[0] > Max->Getx()) Max->Setx((*vertices[n])[0]);
        if((*vertices[n])[1] < Min->Gety()) Min->Sety((*vertices[n])[1]);
        if((*vertices[n])[1] > Max->Gety()) Max->Sety((*vertices[n])[1]);
        if((*vertices[n])[2] < Min->Getz()) Min->Setz((*vertices[n])[2]);
        if((*vertices[n])[2] > Max->Getz()) Max->Setz((*vertices[n])[2]);
    }
    return U_OK;
}
double UManifold::GetMinCoord(int dir) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMinCoord(). Object NULL or erroneous.\n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetMinCoord(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetMinCoord(). Invalid direction parameter (dir = %d) .\n", dir);
        return 0;
    }
    double Min = (*vertices[0])[dir];
    for(int n=1; n<NVertex; n++)
    {
        if((*vertices[n])[dir] > Min) continue;
        Min = (*vertices[n])[dir];
    }
    return Min;
}
double UManifold::GetMaxCoord(int dir) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMaxCoord(). Object NULL or erroneous.\n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetMaxCoord(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetMaxCoord(). Invalid direction parameter (dir = %d) .\n", dir);
        return 0;
    }
    double Max = (*vertices[0])[dir];
    for(int n=1; n<NVertex; n++)
    {
        if((*vertices[n])[dir] < Max) continue;
        Max = (*vertices[n])[dir];
    }
    return Max;
}
int* UManifold::GetTipVertexIDset(int dir, bool Largest, double TolAbs, int* NID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). Invalid direction parameter (dir = %d) .\n", dir);
        return NULL;
    }
    if(TolAbs<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). Invalid TolAbs parameter (TolAbs=%f).\n",TolAbs);
        return NULL;
    }
    if(NID==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). NULL NID parameter.\n");
        return NULL;
    }

    int* Co = GetIndexVertexCoordOrder(dir, false, Largest);
    if(Co==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexIDset(). Getting coord ordering. \n");
        return NULL;
    }
    double   CoFirst = (*(vertices[Co[0]]))[dir];
    *NID             = 1;
    for(int n=1; n<NVertex; n++)
    {
        if(vertices[Co[n]]==NULL) continue;
        UVector3 V = *(vertices[Co[n]]);
        if(fabs(V[dir] - CoFirst) > TolAbs) break;
        (*NID)++;
    }    
    return Co;
}
int UManifold::GetTipVertexID(int dirpri, int dirsec, bool Largest, bool Top, double TolAbs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dirpri<0 || dirpri>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid direction parameter (dirpri = %d) .\n", dirpri);
        return -1;
    }
    if(dirsec<0 || dirsec>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid direction parameter (dirsec = %d) .\n", dirsec);
        return -1;
    }
    if(dirpri==dirsec)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid direction primary and secondary direction parameters should be different (dirpri = %d, dirsec = %d) .\n", dirpri, dirsec);
        return -1;
    }
    if(TolAbs<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid TolAbs parameter (TolAbs=%f).\n",TolAbs);
        return -1;
    }

    int* Co = GetIndexVertexCoordOrder(dirpri, false, Largest);
    if(Co==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Getting coord ordering. \n");
        return -1;
    }

    int      OriginalTip = GetTipVertexID(dirpri, Largest, 0.001);
    UVector3 Tip         = GetPointFromID(OriginalTip);
    double   CoorPri     = Tip[dirpri];///Tip.Getz();
    double   CoorSec     = Tip[dirsec];///Tip.Gety();
    double   MaxY        = CoorSec;
    int      MaxInd      = 0;
    const double gainreq = 2; //the higher the gainreq, the more distance we should gain towards the "tip" compared to the distance we lose from the top slice.
                              //a value of 0.5 means that for every 1 we move from the top slice, we only need to move 0.5 towards tip.

    for(int n=1; n<NVertex; n++)
    {
        if(vertices[Co[n]]==NULL) continue;

        UVector3 V = *(vertices[Co[n]]);
        if(fabs(V[dirpri] - CoorPri) < TolAbs) 
        {
            if(!Top == V[dirsec]>MaxY )
            { 
                bool significant = fabs(V[dirsec]-CoorSec) > ( fabs(V[dirpri]-CoorPri) * gainreq ) ;
                if(significant)//is there a significant gain in y vs distance from top?
                {
                    MaxInd = n;
                    MaxY   = V[dirsec];
                }
            }
        }
    }
    int TipID = vertices[Co[MaxInd]]->GetID();
    delete[] Co;
    return TipID;
}

int UManifold::GetTipVertexID(int dir, bool Largest, double TolAbs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid direction parameter (dir = %d) .\n", dir);
        return -1;
    }
    if(TolAbs<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Invalid TolAbs parameter (TolAbs=%f).\n",TolAbs);
        return -1;
    }

    int* Co = GetIndexVertexCoordOrder(dir, false, Largest);
    if(Co==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Getting coord ordering. \n");
        return -1;
    }
    UVector3 Tip     = *(vertices[Co[0]]);
    double   CoFirst = Tip[dir];
    for(int n=1; n<NVertex; n++)
    {
        if(vertices[Co[n]]==NULL) continue;
        UVector3 V = *(vertices[Co[n]]);
        if(fabs(V[dir] - CoFirst) > TolAbs) 
        {
            Tip = Tip * (1./n);
            break;
        }
        Tip += *(vertices[Co[n]]);
    }
    delete[] Co;

    int IndexTip  = GetIndexClosestPoint(Tip);
    if(IndexTip<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipVertexID(). Finding closest point. \n");
        return -1;
    }
    return vertices[IndexTip]->GetID();
}
UVertex* UManifold::GetVertex(int VID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertex(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetVertex(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    int index = VID>=0 ? FindVertex(VID) : -1;
    if(index<0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertex(). Vertex not found, VID = %d. \n", VID);
        return NULL;
    }
    return vertices[index];
}

UQuadEdge* UManifold::GetQuadEdge(int EID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetQuadEdge(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NQEdge  <=0 || qedges   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetQuadEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    int index = EID>=0 ? FindQuadEdge(EID) : -1;
    if(index<0)
    {
        CI.AddToLog("ERROR: UManifold::GetQuadEdge(). QuadEdge not found, EID = %d. \n", EID);
        return NULL;
    }
    return qedges[index];
}

UFace* UManifold::GetFace(int FID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFace(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetFace(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    int index = FID>=0 ? FindFace(FID) : -1;
    if(index<0)
    {
        CI.AddToLog("ERROR: UManifold::GetFace(). Face not found, FID = %d. \n", FID);
        return NULL;
    }
    return faces[index];
}

int UManifold::GetTipFaceID(int dir, bool Largest, double TolAbs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid direction parameter (dir = %d) .\n", dir);
        return -1;
    }
    if(TolAbs<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid TolAbs parameter (TolAbs=%f).\n",TolAbs);
        return -1;
    }
    int VID = GetTipVertexID(dir, Largest, TolAbs);
    if(VID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Getting vertex ID of tip.\n");
        return -1;
    }
    int VIN = FindVertex(VID);
    if(VIN<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Getting vertex index of tip.\n");
        return -1;
    }
    if(vertices[VIN]==NULL                              || 
       vertices[VIN]->GetEdge()==NULL                   || 
       vertices[VIN]->GetEdge()->GetLeftFace()==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid pointer structure at tip. \n");
        return -1;
    }
    return vertices[VIN]->GetEdge()->GetLeftFace()->GetID();
}
int UManifold::GetTipFaceID(int dirpri, int dirsec, bool Largest, bool Top, double TolAbs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dirpri<0 || dirpri>=3 || dirsec<0 || dirsec>=3 || dirpri==dirsec)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid direction parameter(s) (dirpri = %d, dirsec = %d) .\n", dirpri, dirsec);
        return -1;
    }
    if(TolAbs<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid TolAbs parameter (TolAbs=%f).\n",TolAbs);
        return -1;
    }
    int VID = GetTipVertexID(dirpri, dirsec, Largest, Top,  TolAbs);
    if(VID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Getting vertex ID of tip.\n");
        return -1;
    }
    int VIN = FindVertex(VID);
    if(VIN<0)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Getting vertex index of tip.\n");
        return -1;
    }
    if(vertices[VIN]==NULL                              || 
       vertices[VIN]->GetEdge()==NULL                   || 
       vertices[VIN]->GetEdge()->GetLeftFace()==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetTipFaceID(). Invalid pointer structure at tip. \n");
        return -1;
    }
    return vertices[VIN]->GetEdge()->GetLeftFace()->GetID();
}

double UManifold::GetPathLength(int VIDfrom, int VIDto, int** PathID, int* NVPath) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetPathLength(). Object NULL or erroneous.\n");
        return -1.;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetPathLength(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1.;
    }
    if(PathID && NVPath==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetPathLength(). Invalid NVPath parameter (NULL). \n");
        return -1.;
    }

    int Index1 = FindVertex(VIDfrom);
    int Index2 = FindVertex(VIDto  );
    if(Index1<0 || Index2<0)
    {
        CI.AddToLog("ERROR: UManifold::GetPathLength(). Begin and/or end vertices not found: (%d, %d) \n", VIDfrom, VIDto);
        return -1.;
    }

    if(PathID) *PathID = NULL;
    if(NVPath) *NVPath = 0;

    int*    Prev = (PathID||NVPath) ? new int[NVertex] : NULL; // Used to store squence of nodes, starting from source, and running in increasing distance
    int*    Q    = new int[NVertex];
    double* Dist = new double[NVertex];
    if( ((PathID||NVPath)&&Prev==NULL) || Q==NULL || Dist==NULL)
    {
        delete[] Prev; delete[] Q; delete[] Dist;
        CI.AddToLog("ERROR: UManifold::GetPathLength(). Memory allocation, or creating output matrix (NVertex=%d) .\n", NVertex);
        return -1.;
    }
    if(Prev) for(int k=0; k<NVertex;k++) Prev[k] = -1;

    for(int k=0; k<NVertex;k++) Q[k]    = (k+1)%NVertex;
    for(int k=0; k<NVertex;k++) Dist[k] = (k==Index1)? 0. : -1.;

    double PathLength = -1.;
    int    NQ         = NVertex;
    int    qstart     = 0;
    while(NQ>0)
    {
        int    uprev = qstart;
        int    u     = Q[qstart];
        double Dmin  = Dist[u];
        for(int k=0, q=Q[qstart], qp=qstart; k<NQ; k++, q=Q[q], qp =Q[qp])  
            if(Dist[q]>=0. && (Dist[q]<Dmin||Dmin<0.)) 
            { 
                u      = q;  
                Dmin   = Dist[q]; 
                uprev  = qp;
                qstart = uprev;
            }
        Q[uprev] = Q[u]; //Remove u from list
        NQ--;

        if(u==Index2)
        {
            PathLength = Dist[u];
            break;
        }

        int* Neigh  = NULL;
        int  NNeigh = GetVertexNeighbors(u, &Neigh);
        if(NNeigh<=0 || Neigh==NULL)
        {
            delete[] Neigh;
            delete[] Prev; delete[] Q; delete[] Dist;
            CI.AddToLog("ERROR: UManifold::GetPathLenght(). Getting neighbors of vertex %d .\n", u);
            return -1.;
        }

        for(int k=0; k<NNeigh; k++)
        {
            int    v       = Neigh[k];
            double Distuv  = (*vertices[u]-*vertices[v]).GetNorm();
            double DistAlt = Dist[u] + Distuv;
            if(DistAlt<Dist[v] || Dist[v]<0)
            {
                Dist[v] = DistAlt;
                if(Prev) Prev[v] = u;
            }
        }
        delete[] Neigh;
    }
    delete[] Dist;
    if(PathLength<0)
    {
        delete[] Q; delete[] Prev;
        CI.AddToLog("ERROR: UManifold::GetPathLenght(). Endpoint not found %d (disconnected?) .\n", Index2);
        return -1;
    }

    if(PathID || NVPath) 
    {
        *NVPath = 0;
        for(int k=0, u=Index2; k<NVertex && u!=Index1; k++, u=Prev[u], (*NVPath)++) Q[k] = vertices[u]->GetID();
        Q[(*NVPath)++] = vertices[Index1]->GetID();
        if(PathID) *PathID = Q; else delete[] Q;
    }
    else
        delete[] Q;

    delete[] Prev;
    return PathLength;
}

int* UManifold::GetClosestVertextIDs(const UPointList* PL) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestVertextIDs(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetClosestVertextIDs(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(PL==NULL || PL->GetError()!=U_OK || PL->GetNpoints()<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestVertextIDs(). UPointList argument NULL, erroneous or empty .\n");
        return NULL;
    }
    int  NP      = PL->GetNpoints();
    int* VertIDs = new int[NP];
    if(VertIDs==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestVertextIDs(). Memory allocation, NP=%d .\n", NP);
        return NULL;
    }
    for(int n=0; n<NP; n++)
    {
        int ind = GetIndexClosestPoint(PL->GetPoint(n));
        if(ind<0)
        {
            delete[] VertIDs;
            CI.AddToLog("ERROR: UManifold::GetClosestVertextIDs(). point not found, n=%d .\n", n);
            return NULL;
        }
        VertIDs[n] = vertices[ind]->GetID();
    }
    return VertIDs;
}

int UManifold::GetClosestDirVertexID(const int* VertID, int NVert, UVector3 Dir) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(VertID==NULL || NVert<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Invalid NULL argument. NVert = %d .\n", NVert);
        return -1;
    }
    if(Dir.GetNorm()<1.e-8)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Invalid Direction parameter (Dir=%s).\n", Dir.GetProperties());
        return -1;
    }
    UVector3 C       = GetCenter(VertID, NVert);
    int      IDclose = VertID[0];
    double   Cost    = fabs(Angle(*(vertices[ FindVertex(VertID[0]) ]) - C, Dir));
    for(int k=1; k<NVert; k++) 
    {
        double Test = fabs(Angle(*(vertices[ FindVertex(VertID[k]) ]) - C, Dir));
        if(Test>Cost) continue;

        IDclose = VertID[k];
        Cost    = Test;
    }
    return IDclose;
}
int UManifold::GetClosestDirVertexID(double Level, int dircross, int dir, bool NegDir) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dircross==dir || dircross<0 || dircross>2 || dir<0 || dir>2)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Invalid direction parameters (dircross=%d, dir=%d) .\n", dircross, dir);
        return -1;
    }
    UVector3 Dir;
    switch(dir)
    {
    case 0: if(NegDir) Dir = UVector3(-1. ,0., 0.); else Dir = UVector3(1.,0.,0.); break;
    case 1: if(NegDir) Dir = UVector3( 0.,-1., 0.); else Dir = UVector3(0.,1.,0.); break;
    case 2: if(NegDir) Dir = UVector3( 0., 0.,-1.); else Dir = UVector3(0.,0.,1.); break;
    }
    return GetClosestDirVertexID(Level, dircross, Dir);
}
int UManifold::GetClosestDirVertexID(double Level, int dircross, UVector3 Dir)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dircross<0 || dircross>2)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Invalid direction parameters (dircross=%d) .\n", dircross);
        return -1;
    }
    if(Dir.GetNorm()<=1.e-6)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Direction undefined (%s) .\n", Dir.GetProperties());
        return -1;
    }
    int**    VertIDs    = NULL;
    int*     NPointsCon = NULL;
    int      NCont      = 0;
    if(GetCrossSection(dircross, Level, &VertIDs, &NPointsCon, &NCont)!=U_OK || NPointsCon[0]<=0)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Getting cross-section .\n");
        return U_ERROR;
    }
    int IDclose = GetClosestDirVertexID(VertIDs[0], NPointsCon[0], Dir);
    for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
    if(IDclose<0)
    {
        CI.AddToLog("ERROR: UManifold::GetClosestDirVertexID(). Getting closest point from cross-section .\n");
        return U_ERROR;
    }
    return IDclose;
}
int* UManifold::GetIndexEdgeCoordOrder(int coor, bool Fabs, bool HighFirst) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeCoordOrder(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeCoordOrder(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(coor<0 || coor>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeCoordOrder(). Parameter out of range: coor = %d .\n", coor);
        return NULL;
    }
    double* CoorArr = new double[NQEdge];
    if(CoorArr==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeCoordOrder(). Memory allocation, NQEdge = %d .\n", NQEdge);
        return NULL;
    }
    for(int n=0; n<NQEdge; n++)
    {
        CoorArr[n] = 0.;
        if(qedges[n]==NULL || qedges[n]->GetEdge()==NULL) continue;

        double C1 = 0;
        double C2 = 0;
        switch(coor)
        {
        case 0: C1 = qedges[n]->GetEdge()->GetOrg()->Getx(); C1 = qedges[n]->GetEdge()->GetDest()->Getx(); break;
        case 1: C1 = qedges[n]->GetEdge()->GetOrg()->Gety(); C1 = qedges[n]->GetEdge()->GetDest()->Gety(); break;
        case 2: C1 = qedges[n]->GetEdge()->GetOrg()->Getz(); C1 = qedges[n]->GetEdge()->GetDest()->Getz(); break;
        }
        if(Fabs) {C1=fabs(C1); C2=fabs(C2);}
        if(HighFirst) CoorArr[n] = MAX(C1, C2);
        else          CoorArr[n] = MIN(C1, C2);
    }
    int* Index = GetOrderIndexArray(CoorArr, NQEdge, Fabs, HighFirst);
    delete[] CoorArr;
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeCoordOrder(). Getting array ordering, NQEdge = %d .\n", NQEdge);
        return NULL;
    }
    return Index;
}
int* UManifold::GetIndexEdgeMinAngle(bool HighFirst) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeMinAngle(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeMinAngle(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* MinAngArr = new double[NQEdge];
    if(MinAngArr==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeMinAngle(). Memory allocation, NQEdge = %d .\n", NQEdge);
        return NULL;
    }
    for(int n=0; n<NQEdge; n++)
    {
        MinAngArr[n] = -1.;
        if(qedges[n]==NULL || qedges[n]->GetEdge()==NULL) continue;

        MinAngArr[n] = qedges[n]->GetMinAdjacentAngle();
    }
    bool Fabs  = false;
    int* Index = GetOrderIndexArray(MinAngArr, NQEdge, Fabs, HighFirst);
    delete[] MinAngArr;
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexEdgeMinAngle(). Getting array ordering, NQEdge = %d .\n", NQEdge);
        return NULL;
    }
    return Index;
}

double UManifold::GetTotalArea(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetTotalArea(). Object NULL or erroneous.\n");
        return 0.;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetTotalArea(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0.;
    }
    double Area = 0;
    for(int n=0; n<NFace; n++)
    {
        if(faces[n]==NULL) continue;
        Area += faces[n]->GetArea();
    }
    return Area;
}

int* UManifold::GetIndexVertexCoordOrder(int coor, bool Fabs, bool HighFirst) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexVertexCoordOrder(). Object NULL or erroneous.\n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetIndexVertexCoordOrder(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(coor<0 || coor>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexVertexCoordOrder(). Parameter out of range: coor = %d .\n", coor);
        return NULL;
    }
    double* CoorArr = new double[NVertex];
    if(CoorArr==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexVertexCoordOrder(). Memory allocation, NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++)
    {
        CoorArr[n] = 0.;
        if(vertices[n]==NULL) continue;

        switch(coor)
        {
        case 0: CoorArr[n] = vertices[n]->Getx(); break;
        case 1: CoorArr[n] = vertices[n]->Gety(); break;
        case 2: CoorArr[n] = vertices[n]->Getz(); break;
        }
    }
    int* Index = GetOrderIndexArray(CoorArr, NVertex, Fabs, HighFirst);
    delete[] CoorArr;
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexVertexCoordOrder(). Getting array ordering, NVertex = %d .\n", NVertex);
        return NULL;
    }
    return Index;
}
int UManifold::GetFaceIndexMaxNEdges()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIndexMaxNEdges(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIndexMaxNEdges(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    int NNeigh =  0;
    int Index  = -1;
    for(int n=0; n<NFace; n++)
    {
        if(faces[n]==NULL) continue;
        int NN = faces[n]->GetNEdge();
        if(NN>NNeigh)
        {
            NNeigh = NN;
            Index  = n;
        }
    }
    return Index;
}

UMatrixSparse UManifold::GetVertexNNeighborsMatrix(bool Invert) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UMatrixSparse(U_ERROR);
    }
    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Creating empty sparse matrix. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(MS.SetNrow(NVertex)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Setting rows. \n");
        return UMatrixSparse(U_ERROR);
    }
    for(int n=0; n<NVertex; n++)
    {
        if(vertices[n]==NULL)
        {
            CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Vertex =%d is NULL. \n", n);
            return UMatrixSparse(U_ERROR);
        }
        UVertexEdgeIterator VEI(vertices[n]);
        double Val = double(VEI.GetNNeighbour());
        if(Invert) Val = (Val==0.) ? -1. : 1./Val;
        if(Val<0 || MS.AddCollumn(&n, Val, 1)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::GetVertexNNeighborsMatrix(). Vertex =%d has no neigbors, or setting collumn. \n", n);
            return UMatrixSparse(U_ERROR);
        }
    }
    return MS;
}
UMatrixSparse UManifold::GetMatrixSparseVertexConnectivity(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexConnectivity(). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexConnectivity(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse MS;
    if(MS.GetError()!=U_OK || MS.SetNrow(NVertex)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexConnectivity(). Setting rows. \n");
        return UMatrixSparse(U_ERROR);
    }
    for(int n=0; n<NVertex; n++)
    {
        int* Neigh  = NULL;
        int  NNeigh = GetVertexNeighbors(n, &Neigh);
        if(NNeigh<=0 || Neigh==NULL)
        {
            delete[] Neigh;
            CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexConnectivity(). Getting neighbors of vertex %d .\n", n);
            return UMatrixSparse(U_ERROR);
        }
        double Val = (NNeigh<=0) ? 0. : 1./NNeigh;
        if(MS.AddCollumn(Neigh, Val, NNeigh)!=U_OK)
        {
            delete[] Neigh;
            CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexConnectivity(). Adding collumn corresponding to vertex %d .\n", n);
            return UMatrixSparse(U_ERROR);
        }
    }
    return MS;
}
UMatrixSparse UManifold::GetMatrixSparseVertexLaplacian(LaplacianType LT, bool GetDiag) const
/*
    if(NOT(Diagonal)) return full and symmetric Laplacian matrix
    else              return diagonal matrix needed to scale diagonal of full L matrix to 1. (by pre-multiplication).
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UMatrixSparse(U_ERROR);
    }
    if(LT!=U_LAPLACIAN_UNIFORM && LT!=U_LAPLACIAN_HARMONIC)
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Connection type argument invalid (LT=%d).\n", LT);
        return UMatrixSparse(U_ERROR);
    }
    UMatrixSparse MS;
    if(MS.GetError()!=U_OK || MS.SetNrow(NVertex)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Setting rows. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(GetDiag)
    {
        for(int n=0; n<NVertex; n++)
        {
            if(vertices[n]==NULL)
            {
                CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Vertex =%d is NULL. \n", n);
                return UMatrixSparse(U_ERROR);
            }
            UVertexEdgeIterator VEI(vertices[n]);
            double Val = (LT==U_LAPLACIAN_UNIFORM) ? double(VEI.GetNNeighbour()) : vertices[n]->GetAmixed()*NVertex/GetTotalArea();
            if(Val>0.) Val = 1./Val;
            if(Val<=0. || MS.AddCollumn(&n, Val, 1)!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Vertex =%d has no neigbors, or setting collumn. \n", n);
                return UMatrixSparse(U_ERROR);
            }
        }
    }
    else
    {
        for(int n=0; n<NVertex; n++)
        {
            int* Neigh  = NULL;
            int  NNeigh = GetVertexNeighbors(n, &Neigh);
            if(NNeigh<=0 || Neigh==NULL)
            {
                delete[] Neigh;
                CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Getting neighbors of vertex %d .\n", n);
                return UMatrixSparse(U_ERROR);
            }
            int*    Index  = new int   [NNeigh+1];
            double* Values = new double[NNeigh+1];
            if(Index==NULL || Values==NULL)
            {
                delete[] Neigh; delete[] Index; delete[] Values;
                CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Memory allocation in vertex %d .\n", n);
                return UMatrixSparse(U_ERROR);
            }
            Index[NNeigh]  = n;      // Diagonal index

            switch(LT)
            {
            case U_LAPLACIAN_UNIFORM:
                for(int k=0; k<NNeigh; k++)
                {
                    Index[k]   =  Neigh[k];
                    Values[k]  = 1.;
                }
                Values[NNeigh] = -NNeigh; // Diagonal value
                break;

            case U_LAPLACIAN_HARMONIC:
                {
                    double Diag = 0.;
                    for(int k=0; k<NNeigh; k++)
                    {
                        UEdge* E    = vertices[n]->GetEdge(k);

                        Index[k]    = FindVertex(E->GetDest()->GetID());
                        double t1   = 0; bool LTri = E->IsLeftFaceTriangle ();
                        double t2   = 0; bool RTri = E->IsRightFaceTriangle();                    
                        if(LTri) t1 = tan(E->GetLeftAngle ());
                        if(RTri) t2 = tan(E->GetRightAngle());
                        if((t1==0.&&LTri) || (t2==0.&&RTri))
                        {
                            CI.AddToLog("WARNING: UManifold::GetMatrixSparseVertexLaplacian(). Zero angle detected, n=%d. \n", n);
                            if(t1==0) t1 = 1.e-10;
                            if(t2==0) t2 = 1.e-10;
                        }
                        Values[k]  = 0.5 * (1./t1 + 1./t2);
                        Diag      -= Values[k];
                    }
                    Values[NNeigh] = Diag; // Diagonal value
                }
                break;
            }
            delete[] Neigh; 
            ErrorType E = MS.AddCollumn(Index, Values, NNeigh+1);
            delete[] Index; delete[] Values;
            if(E!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::GetMatrixSparseVertexLaplacian(). Adding collumn corresponding to vertex %d .\n", n);
                return UMatrixSparse(U_ERROR);
            }
        }
    }
    return MS;
}

UVector3 UManifold::GetCenter() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCenter(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCenter(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    UVector3 C;
    for(int n=0; n<NVertex; n++) C += *(vertices[n]);

    if(NVertex) C = (1./NVertex) * C;
    return C;
}
UVector3 UManifold::GetCenter(const int* VertID, int NVert) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCenter(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCenter(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(VertID==NULL || NVert<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetCenter(). Invalid NULL argument, NVert = %d . \n", NVert);
        return UVector3();
    }
    UVector3 C;
    for(int k=0; k<NVert; k++)
    {
        int ind = FindVertex(VertID[k]);
        if(ind<0 || ind>=NVertex)
        {
            CI.AddToLog("ERROR: UManifold::GetCenter(). VertID[%d] = %d not found .\n", k, VertID[k]);
            return UVector3();
        }
        C += *(vertices[ind]);
    }
    C = C * (1./NVert);
    return C;
}

ErrorType UManifold::ComputeMoments(double* First3, double* Second6, double* Third10) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ComputeMoments(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(NVertex<=0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ComputeMoments(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    UPointList* PL = GetPointList();
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UManifold::ComputeMoments(). Getting pointlist.\n");
        return U_ERROR;
    }
    ErrorType E = PL->ComputeMoments(First3, Second6, Third10);
    delete PL;

    if(E!=U_OK)  CI.AddToLog("ERROR: UManifold::ComputeMoments(). Computing moments from pointlist.\n");
    return E;
}
UVector3 UManifold::GetMomentDir(int dir) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMomentDir(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<=0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetMomentDir(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetMomentDir(). dir (=%d) out of range. \n", dir);
        return UVector3();
    }
    UPointList* PL = GetPointList();
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UManifold::GetMomentDir(). Getting pointlist.\n");
        return UVector3();
    }
    UVector3 Dir = PL->GetMomentDir(dir);
    delete PL;

    return Dir;
}
UEuler UManifold::GetXfm2Moments(bool ForceMinRot) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetXfm2Moments(). Object NULL or erroneous.\n");
        return UEuler();
    }
    if(NVertex<=0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetXfm2Moments(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UEuler();
    }
    UPointList* PL = GetPointList();
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UManifold::GetXfm2Moments(). Getting pointlist.\n");
        return UEuler();
    }
    UEuler XFM = PL->GetXfm2Moments(ForceMinRot);
    delete PL;
    return XFM;
}

UEuler GetMomentMatch(const UManifold* M1, const UManifold* M2)
{
    if(M1==NULL || M1->GetError()!=U_OK || M1->GetNVertex()<=0)
    {
        CI.AddToLog("ERROR: GetMomentMatch(). First argument NULL or erroneous. \n");
        return UEuler();
    }
    if(M2==NULL || M2->GetError()!=U_OK || M2->GetNVertex()<=0)
    {
        CI.AddToLog("ERROR: GetMomentMatch(). Second argument NULL or erroneous. \n");
        return UEuler();
    }
    UPointList* PL1 = M1->GetPointList();
    UPointList* PL2 = M2->GetPointList();
    if(PL1==NULL || PL1->GetError()!=U_OK ||
       PL2==NULL || PL2->GetError()!=U_OK)
    {
        delete PL1; delete PL2;
        CI.AddToLog("ERROR: GetMomentMatch(). Getting pointlist(s). \n");
        return UEuler();
    }
    UEuler XFM = GetMomentMatch(PL1, PL2);
    delete PL1;
    delete PL2;
    return XFM;
}

UVector3 UManifold::GetFaceCenterFromID(int FaceID) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceCenterFromID(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<=0 || vertices==NULL ||
       NFace  <=0 || faces   ==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceCenterFromID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    int IndexF = FindFace(FaceID);
    if(IndexF<0)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceCenterFromID(). Face not found: ID = %d \n", FaceID);
        return UVector3();
    }
    if(faces[IndexF]==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceCenterFromID(). Invalid (NULL) face: ID = %d \n", FaceID);
        return UVector3();
    }
    return faces[IndexF]->GetCenter();
}


UVector3 UManifold::GetFacesCenter(const int* FaceIndices, int NIndex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFacesCenter(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<=0 || vertices==NULL ||
       NFace  <=0 || faces   ==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFacesCenter(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(FaceIndices==NULL || NIndex<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetFacesCenter(). Invalid NULL argument; NIndex = %d .\n", NIndex);
        return UVector3();
    }
    UVector3 C;
    int      Nin=0;
    for(int n=0; n<NIndex; n++)
    {
        if(FaceIndices[n]<0 || FaceIndices[n]>=NFace)
        {
            CI.AddToLog("ERROR: UManifold::GetFacesCenter(). Face index %d out of range (value %d ). \n", n, FaceIndices[n]);
            return UVector3();
        }
        UFaceEdgeIterator FEI(faces[FaceIndices[n]]);
        for(UEdge* E = FEI.GetStart(); E; E=FEI.GetNext())
        {
            C  += *(E->GetOrg());
            Nin++;
        }
    }
    if(Nin<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetFacesCenter(). No points found: nin = %d .\n", Nin);
        return UVector3();
    }
    return (1./Nin)*C;
}
int UManifold::GetIndexClosestPoint(UVector3 C) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexClosestPoint(). Object NULL or erroneous.\n");
        return -1;
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetIndexClosestPoint(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    int    iclose = 0;
    double Dist   = ( *(vertices[0]) - C).GetNorm2();
    for(int n=0; n<NVertex; n++)
    {
        double Test = ( *(vertices[n]) - C).GetNorm2();
        if(Test>Dist) continue;

        iclose = n;
        Dist   = Test;
    }
    return iclose;
}

int UManifold::GetVertexIDExtremeCoord(int dir, bool Largest) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDExtremeCoord(). Object NULL or erroneous.\n");
        return -1;
    }
    if(NVertex<=0|| vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDExtremeCoord(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dir<0||dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDExtremeCoord(). Direction parameter out of range (dir=%d) .\n",dir);
        return -1;
    }
    double CoExt = (*(vertices[0]))[dir];
    int    ivext = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(vertices[n]==NULL) continue;
        double Co = (*(vertices[n]))[dir];
        if((Largest && Co<CoExt) || (NOT(Largest) && Co>CoExt)) continue;

        CoExt = Co;
        ivext = n;
    }
    return vertices[ivext]->GetID();
}
int UManifold::GetFaceIDExtremeCoord(int dir, bool Largest) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDExtremeCoord(). Object NULL or erroneous.\n");
        return -1;
    }
    if(NVertex<=0 || vertices==NULL ||
       NFace<=0   || faces   ==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDExtremeCoord(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(dir<0||dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDExtremeCoord(). Direction parameter out of range (dir=%d) .\n",dir);
        return -1;
    }

    UVector3 MinF, MaxF;
    if(faces[0]->GetBoundBox(&MinF, &MaxF)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDExtremeCoord(). Getting bounding box of first face.\n");
        return -1;
    }
    int IDF = faces[0]->GetID();
    for(int n=0; n<NFace; n++)
    {
        UVector3 MinTest, MaxTest;
        if(faces[n]->GetBoundBox(&MinTest, &MaxTest)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::GetFaceIDExtremeCoord(). Getting bounding box of face %d.\n", n);
            return -1;
        }
        if(Largest)
        {
            if(MinTest[dir]<MinF[dir]) continue;

            MinF = MinTest;
            IDF  = faces[n]->GetID();
        }
        else
        {
            if(MaxTest[dir]>MaxF[dir]) continue;

            MaxF = MaxTest;
            IDF  = faces[n]->GetID();
        }
    }
    return IDF;
}

int UManifold::GetQEdgeIDShortestEdge(const int* VIDset, int NVID) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetQEdgeIDShortestEdge(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetQEdgeIDShortestEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(VIDset && NVID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetQEdgeIDShortestEdge(). Invalid vertex ID set (NVID=%d) .\n", NVID);
        return -1;
    }
    int    iemin = 0;
    double Rmin  = qedges[iemin]->GetLength();
    if(VIDset&&NVID>0)
    {
        int ind = -1;
        for(int m=0; m<NVID; m++)
        {
            ind = FindVertex(VIDset[m]);
            if(ind<0) continue;
            break;
        }
        if(ind<0)
        {
            CI.AddToLog("ERROR: UManifold::GetQEdgeIDShortestEdge(). None of the vertex ID's are present in Manifold .\n");
            return -1;
        }
        iemin = FindQuadEdge(vertices[ind]->GetEdge());
        if(iemin<0)
        {
            CI.AddToLog("ERROR: UManifold::GetQEdgeIDShortestEdge(). QEdge not found .\n");
            return -1;
        }
        Rmin  = qedges[iemin]->GetLength();
    }
    
    for(int n=0; n<NQEdge; n++)
    {
        if(qedges[n]==NULL) continue;
        bool Skip = false;
        if(VIDset&&NVID>0)
        {
            Skip    = true;
            int ID1 = qedges[n]->GetEdge()->GetOrg ()->GetID();
            int ID2 = qedges[n]->GetEdge()->GetDest()->GetID();
            for(int m=0; m<NVID; m++)
            {
                if(ID1!=VIDset[m] && ID2!=VIDset[m]) continue;
                Skip = false;
                break;
            }
        }
        if(Skip) continue;
        double R = qedges[n]->GetLength();
        if(R>Rmin) continue;

        Rmin  = R;
        iemin = n;
    }
    return qedges[iemin]->GetID();
}
double UManifold::GetLengthFromID(int QEID) const
{
    if(this==NULL || error!=U_OK) return -1.;

    if( (NVertex<0 || vertices==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetLengthFromID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1.;
    }
    int inde = FindQuadEdge(QEID);
    if(inde<0)
    {
        CI.AddToLog("ERROR: UManifold::GetLengthFromID(). QuadEdge not found: QEID = %d. \n", QEID);
        return -1.;
    }
    return qedges[inde]->GetLength();
}
ErrorType UManifold::RemoveEdges(double LengthThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdges(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(LengthThreshold<0.) return U_OK;

    for(int kk=0; kk<NQEdge; kk++)
    {
        int    ID = GetQEdgeIDShortestEdge(NULL, -1);
        double L  = GetLengthFromID(ID);
        if(L<0)
        {
            CI.AddToLog("ERROR: UManifold::RemoveEdges(). Invalid edge length found (%f). \n", L);
            return U_ERROR;
        }
        if(L>LengthThreshold) break;
        if(RemoveEdgeMergeVertices(ID)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::RemoveEdges(). Removing edge %d \n", ID);
            return U_ERROR;
        }
    }
    return U_OK;
}

int UManifold::GetFaceIDShortestEdge(const int* VIDset, int NVID) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDShortestEdge(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDShortestEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(VIDset && NVID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDShortestEdge(). Invalid vertex ID set (NVID=%d) .\n", NVID);
        return -1;
    }
    
    int ieminID = GetQEdgeIDShortestEdge(VIDset,NVID);
    if(ieminID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDShortestEdge(). Finding shortest QuadEdge.\n");
        return -1;
    }
    int iemin = FindQuadEdge(ieminID);
    if(iemin<0)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceIDShortestEdge(). Finding QuadEdge from ID.\n");
        return -1;
    }
    return qedges[iemin]->GetEdge()->GetLeftFace()->GetID();
}
int UManifold::GetVertexIDShortestEdge(const int* VIDset, int NVID) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDShortestEdge(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDShortestEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(VIDset && NVID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDShortestEdge(). Invalid vertex ID set (NVID=%d) .\n", NVID);
        return -1;
    }
    
    int ieminID = GetQEdgeIDShortestEdge(VIDset,NVID);
    if(ieminID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDShortestEdge(). Finding shortest QuadEdge.\n");
        return -1;
    }
    int iemin = FindQuadEdge(ieminID);
    if(iemin<0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexIDShortestEdge(). Finding QuadEdge from ID.\n");
        return -1;
    }
    return qedges[iemin]->GetEdge()->GetOrg()->GetID();
}
UVector3 UManifold::GetPointShortestEdge(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetPointShortestEdge(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetPointShortestEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    int ID = GetVertexIDShortestEdge(NULL, 0);
    if(ID<0)
    {
        CI.AddToLog("ERROR: UManifold::GetPointShortestEdge(). Finding shortest edge.\n");
        return UVector3();
    }
    int Ind = FindVertex(ID);
    if(Ind<0 || Ind>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetPointShortestEdge(). Finding point with ID = %d .\n",ID);
        return UVector3();
    }
    return *(vertices[Ind]);
}
int UManifold::GetVertexID(int Vindex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexID(). Object NULL or erroneous.\n");
        return -1;
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexID(). Vertex not found, Vindex = %d .\n", Vindex);
        return -1;
    }
    if(vertices[Vindex]==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexID(). Vertex not set, Vindex = %d .\n", Vindex);
        return -1;
    }
    return vertices[Vindex]->GetID();
}
UVector3 UManifold::GetVertexNormal(int Vindex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNormal(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNormal(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNormal(). Vertex not found, Vindex = %d .\n", Vindex);
        return UVector3();
    }
    if(vertices[Vindex]==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNormal(). Vertex not set, Vindex = %d .\n", Vindex);
        return UVector3();
    }
    return vertices[Vindex]->GetAverageNormal();
}
UVector3 UManifold::GetVertexCurveVector(int Vindex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexCurveVector(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexCurveVector(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexCurveVector(). Vertex not found, Vindex = %d .\n", Vindex);
        return UVector3();
    }
    if(vertices[Vindex]==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexCurveVector(). Vertex not set, Vindex = %d .\n", Vindex);
        return UVector3();
    }
    return vertices[Vindex]->GetMeanCurveVector();
}
//double UManifold::GetVertexMeanCurvature(int Vindex)
//{
//    if(this==NULL || error!=U_OK)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Object NULL or erroneous.\n");
//        return 0.;
//    }
//    if(NVertex<0 || vertices==NULL)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
//        return 0.;
//    }
//    if(Vindex<0 || Vindex>=NVertex)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Vertex not found, Vindex = %d .\n", Vindex);
//        return 0.;
//    }
//    if(vertices[Vindex]==NULL)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Vertex not set, Vindex = %d .\n", Vindex);
//        return 0.;
//    }
//    double   Amixed = vertices[Vindex]->GetAmixed();
//    UVector3 K      = vertices[Vindex]->GetMeanCurveVector();
//    
//    if(Amixed>0.) return K.GetNorm()/Amixed;
//    return 0.;
//}
//
//double UManifold::GetVertexAngleDeficit(int Vindex, double* Amixed) const
//{
//    if(this==NULL || error!=U_OK)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Object NULL or erroneous.\n");
//        return 0.;
//    }
//    if(NVertex<0 || vertices==NULL)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
//        return 0.;
//    }
//    if(Vindex<0 || Vindex>=NVertex)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Vertex not found, Vindex = %d .\n", Vindex);
//        return 0.;
//    }
//    if(vertices[Vindex]==NULL)
//    {
//        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Vertex not set, Vindex = %d .\n", Vindex);
//        return 0.;
//    }
//    if(Amixed) *Amixed = vertices[Vindex]->GetAmixed();
//    return               vertices[Vindex]->GetAngleDeficit();
//}

UVector3 UManifold::GetPoint(int Vindex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetPoint(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetPoint(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetPoint(). Vertex not found, Vindex = %d .\n", Vindex);
        return UVector3();
    }
    return UVector3(*(vertices[Vindex]));
}

UVector3 UManifold::GetPointFromID(int ID) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetPointFromID(). Object NULL or erroneous.\n");
        return UVector3();
    }
    if(NVertex<0 || vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetPointFromID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UVector3();
    }
    int index = FindVertex(ID);
    if(index<0 || index>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetPointFromID(). Vertex not found, ID = %d .\n", ID);
        return UVector3();
    }
    return UVector3(*(vertices[index]));
}

int UManifold::GetVertexNeighbors(int VertIndex, int** Neigh) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Object NULL or erroneous.\n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(VertIndex<0 || VertIndex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). VertIndex (=%d) argument out of range. NVertex = %d .\n", VertIndex, NVertex);
        return -1;
    }
    if(Neigh==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Invalid NULL argument. \n");
        return -1;
    }
    UVertex* V = vertices[VertIndex];
    if(V==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Vertex =%d is NULL. \n");
        return -1;
    }
    UVertexEdgeIterator VEI(V);
    int NNeig  = VEI.GetNNeighbour();
    if(NNeig<=0)
    {
        *Neigh = NULL;
        return 0;
    }
    (*Neigh) = new int[NNeig];
    if( (*Neigh)==NULL)
    {
        *Neigh = NULL;
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Memory allocation (NNeigh=%d). \n", NNeig);
        return -1;
    }
    int ip = 0;
    for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext(), ip++)
    {
        if(E==NULL || E->GetSym()==NULL || E->GetSym()->GetOrg()==NULL)
        {
            delete[] (*Neigh);  *Neigh = NULL;
            CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Invalid data structure (VertIndex=%d). \n", VertIndex);
            return -1;
        }
        int ind = FindVertex(E->GetSym()->GetOrg()->GetID());
        if(ind<0)
        {
            delete[] (*Neigh);  *Neigh = NULL;
            CI.AddToLog("ERROR: UManifold::GetVertexNeighbors(). Neighbor %d of center %d not found. \n", E->GetSym()->GetOrg()->GetID(), V->GetID());
            return -1;
        }
        (*Neigh)[ip] = ind;
    }
    return NNeig;
}

UManifold& UManifold::operator=(const UManifold &M)
{
    if(this==NULL)
    {
        static UManifold n; n.error=U_ERROR;
        CI.AddToLog("ERROR: UManifold::operator=(). this==NULL. \n");
        return n;
    }
    if(&M==NULL)
    {
        CI.AddToLog("ERROR: UManifold::operator=(). Argument has NULL address. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&M) return *this;

    DeleteAllMembers(U_OK);

    error           = M.error;
    NVertex         = M.NVertex;
    LastVertexID    = M.LastVertexID;
    NFace           = M.NFace;
    LastFaceID      = M.LastFaceID;
    NQEdge          = M.NQEdge;
    LastQuadEdgeID  = M.LastQuadEdgeID;

    if(M.vertices)
    {
        vertices = new UVertex*[NVertex];
        if(vertices==NULL)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Memory allocation, NVertex = %d. \n", NVertex);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        NVertexAlloc = NVertex;
        for(int n=0; n<NVertex; n++) vertices[n] = new UVertex(*(M.vertices[n]));
        if(SortVertices()!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Sorting vertices.\n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    if(M.faces)
    {
        faces = new UFace*[NFace];
        if(faces==NULL)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Memory allocation, NFace = %d. \n", NFace);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        NFaceAlloc = NFace;
        for(int n=0; n<NFace; n++) faces[n] = new UFace(*(M.faces[n]));
        if(SortFaces()!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Sorting faces.\n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    if(M.qedges)
    {
        qedges = new UQuadEdge*[NQEdge];
        if(qedges==NULL)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Memory allocation, NQEdge = %d. \n", NQEdge);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        NQEdgeAlloc = NQEdge;
        for(int n=0; n<NQEdge; n++) qedges[n] = new UQuadEdge(*(M.qedges[n]));
        if(SortEdges()!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Sorting edges.\n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }

/* Fill in the appropriate pointers */
    ErrorType ERROR = U_OK;

    for(int n=0; n<NQEdge; n++) // First QEdges, then vertices and faces!
    {
        UEdge E[4];
        for(int k=0; k<4; k++) E[k] = (M.qedges[n]->GetEdge())[k];
        for(int k=0; k<4; k++)
        {
            int index  = E[k].GetONext()->GetIndex();
            int IndexQ = FindQuadEdge(E[k].GetONext());
            int IndexV = 0; if(E[k].GetOrg())      IndexV = FindVertex(E[k].GetOrg()     ->GetID());
            int IndexF = 0; if(E[k].GetLeftFace()) IndexF = FindFace  (E[k].GetLeftFace()->GetID());

            if(qedges[n]==NULL || IndexQ<0 || IndexQ>=NQEdge || IndexV<0 || IndexV>=NVertex || IndexF<0 || IndexF>=NFace)
            {
                CI.AddToLog("ERROR: UManifold::operator=(). Finding Vertex/Edge/Face pointer(s) corresponding to edge %d - %d.\n", int(M.qedges[n]->GetEdge()->GetID()), int(M.qedges[n]->GetEdgeSym()->GetID()));
                ERROR = U_ERROR;
                continue;
            }
            if(E[k].GetOrg()     ) E[k].SetOrg     (vertices[IndexV]);
            if(E[k].GetLeftFace()) E[k].SetLeftFace(faces   [IndexF]);

            E[k].SetONext(qedges[IndexQ]->GetEdge()+index);
        }
        qedges[n]->SetEdges(E);
    }
    for(int n=0; n<NVertex; n++)
    {
        int index  = M.vertices[n]->GetEdge()->GetIndex();
        int IndexQ = FindQuadEdge(M.vertices[n]->GetEdge());
        if(vertices[n]==NULL || IndexQ<0 || IndexQ>=NQEdge)
        {
            if(M.vertices[n]) 
            {
                CI.AddToLog("ERROR: UManifold::operator=(). Finding Edge pointer leaving vertex[%d]= %d, NVertex = %d .\n", M.vertices[n]->GetID(), NVertex);
                if(M.vertices[n]->GetEdge()) CI.AddToLog("ERROR: UManifold::operator=(). Edge from %d to %d   .\n", M.vertices[n]->GetEdge()->GetOrg()->GetID(), M.vertices[n]->GetEdge()->GetDest()->GetID() );
                else                         CI.AddToLog("ERROR: UManifold::operator=(). Vertex %d of M has NULL edge.\n", n);
            }
            else              
                CI.AddToLog("ERROR: UManifold::operator=(). Invalid vertex on M (n=%d).\n", n);
            
            ERROR = U_ERROR;
            continue;
        }
        vertices[n]->SetEdge(qedges[IndexQ]->GetEdge()+index);
    }
    for(int n=0; n<NFace; n++)
    {
        int index  = M.faces[n]->GetEdge()->GetIndex();
        int IndexQ = FindQuadEdge(M.faces[n]->GetEdge());

        if(faces[n]==NULL || IndexQ<0 || IndexQ>=NQEdge)
        {
            CI.AddToLog("ERROR: UManifold::operator=(). Finding Edge pointer surrounding face[%d]= %d, NFace = %d .\n", n, (int)M.faces[n]->GetID(), NFace);
            CI.AddToLog("ERROR: UManifold::operator=(). Edge from %d to %d   .\n", M.faces[n]->GetEdge()->GetOrg()->GetID(), M.faces[n]->GetEdge()->GetDest()->GetID() );
            ERROR = U_ERROR;
            continue;
        }
        faces[n]->SetEdge(qedges[IndexQ]->GetEdge()+index);
    }
    if(ERROR!=U_OK) DeleteAllMembers(U_ERROR);

    return *this;
}
const UString& UManifold::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UManifold-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(NVertex       , "NVertex       =  %d \n")
                + UString(NVertexAlloc  , "NVertexAlloc  =  %d \n")
                + UString(LastVertexID  , "LastVertexID  =  %d \n")
                + UString(NFace         , "NFace         =  %d \n")
                + UString(NFaceAlloc    , "NFaceAlloc    =  %d \n")
                + UString(LastFaceID    , "LastFaceID    =  %d \n")
                + UString(NQEdge        , "NQEdge        =  %d \n")
                + UString(NQEdgeAlloc   , "NQEdgeAlloc   =  %d \n")
                + UString(LastQuadEdgeID, "LastQEdgeID   =  %d \n");

    UVector3 Min, Max;
    GetMinMaxBox(&Min, &Max);
    Properties += UString(Min.GetProperties(), "MinBox        =  %s \n");
    Properties += UString(Max.GetProperties(), "MaxBox        =  %s \n");
    Properties += UString(GetEulerChar()     , "EulerChar     =  %d \n");
    if(NVertex<10000)
    {
        UManifold Copy(*this);
        Properties += UString(Copy.GetNComponents()   , "Ncomp         =  %d \n");
        Properties += UString(GetMeanCurvature()      , "MeanCurvature =  %f \n");
    }
    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

int* UManifold::GetVertexComponentMembership(int *Ncomp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexComponentMembership(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexComponentMembership(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Ncomp==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexComponentMembership(). Invalid NULL pointer argument Ncomp. \n");
        return NULL;
    }

    UVertexInt** LabelVert = new UVertexInt*[NVertex]; 
    int*         IndexV    = new int[LastVertexID+1];
    if(LabelVert==NULL || IndexV==NULL)
    {
        delete[] LabelVert; delete[] IndexV;
        CI.AddToLog("ERROR: UManifold::GetVertexComponentMembership(). Memory allocation, NVertex = %d. \n", NVertex);
        return NULL;
    }
    for(int i=0; i< NVertex     ; i++) LabelVert[i] = new UVertexInt(*(vertices[i]),-1);
    for(int i=0; i<=LastVertexID; i++) IndexV[i]    = -1;
    for(int i=0; i< NVertex     ; i++) IndexV[vertices[i]->GetID()] = i;

    for(int n=0; n<NQEdge; n++)
    {
        int OrgID = qedges[n]->GetEdge()->GetOrg() ->GetID();
        int DesID = qedges[n]->GetEdge()->GetDest()->GetID();
        qedges[n]->GetEdge()->SetOrg (LabelVert[IndexV[OrgID]]);
        qedges[n]->GetEdge()->SetDest(LabelVert[IndexV[DesID]]);
    }

    UFIFOQueuePointer fifoQueue(NVertex/10);

    int curlab = -1;
    for(int i=0; i<NVertex; i++) //visit all foreground pixels
    {
        if(LabelVert[i]->IData>=0) continue; // output already labeled

        curlab++;       //create new label
        fifoQueue.Enqueue(LabelVert[i]);
        LabelVert[i]->IData = curlab;

        while(fifoQueue.GetSize())
        {
            UVertexInt* Vert = (UVertexInt*) fifoQueue.Dequeue();

            UVertexEdgeIterator VEI(Vert);
            for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext())
            {
                UVertexInt* VertDest = (UVertexInt*)E->GetDest();
                if(VertDest->IData==curlab) continue; // Neigbor already labeled

                VertDest->IData   = curlab;
                fifoQueue.Enqueue(VertDest);
            }
        } // vertices connected to curlab
    }
    *Ncomp = curlab+1;

    for(int n=0; n<NQEdge; n++)
    {
        int OrgID = qedges[n]->GetEdge()->GetOrg() ->GetID();
        int DesID = qedges[n]->GetEdge()->GetDest()->GetID();
        qedges[n]->GetEdge()->SetOrg (vertices[IndexV[OrgID]]);
        qedges[n]->GetEdge()->SetDest(vertices[IndexV[DesID]]);
    }
    delete[] IndexV;

    int* CompNo = new int[NVertex];
    int* Sizes  = new int[*Ncomp];
    if(CompNo==NULL || Sizes==NULL)
    {
        delete[] LabelVert; delete[] CompNo; delete[] Sizes;
        CI.AddToLog("ERROR: UManifold::GetVertexComponentMembership(). Memory allocation for output array (NVertex=%d). \n", NVertex);
        return NULL;
    }
    for(int i=0; i<NVertex; i++) CompNo[i] = LabelVert[i]->IData;
    delete[] LabelVert;

    for(int n=0; n <*Ncomp  ; n++) Sizes[n] = 0;
    for(int i=0; i < NVertex; i++) Sizes[CompNo[i]]++;

    int* NewLabel = GetOrderIndexArray(Sizes, *Ncomp, false, true);
    if(NewLabel)    for(int k=0; k<*Ncomp; k++) Sizes[NewLabel[k]] = k;
    else            for(int k=0; k<*Ncomp; k++) Sizes[k]           = k;

    for(int i=0; i<NVertex; i++) CompNo[i] = Sizes[CompNo[i]];
    delete[] Sizes; delete[] NewLabel;
    return CompNo;
}

int UManifold::GetNComponents(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNComponents(). this==NULL or erroneous. \n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetNComponents(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    int  Ncomp  = -1;
    int* Ivert  = GetVertexComponentMembership(&Ncomp);
    delete[] Ivert; 
    if(Ivert==NULL || Ncomp<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetNComponents(). Computing vertex component membership (Ncomp=%d). \n", Ncomp);
        return 0;
    }
    return Ncomp;
}
ErrorType UManifold::SelectLargestComponent(int* NcompOld)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SelectLargestComponent(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::SelectLargestComponent(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(NcompOld) *NcompOld = 0;

    int  Ncomp  = -1;
    int* Ivert  = GetVertexComponentMembership(&Ncomp);
    int* IndexV = new int[LastVertexID+1];
    if(Ivert==NULL || IndexV==NULL || Ncomp<=0)
    {
        delete[] Ivert; delete[] IndexV;
        CI.AddToLog("ERROR: UManifold::SelectLargestComponent(). Computing vertex component membership (Ncomp=%d). \n", Ncomp);
        return U_ERROR;
    }
    if(NcompOld) *NcompOld = Ncomp;
    if(Ncomp==1)
    {
        delete[] Ivert; delete[] IndexV;
        return U_OK;
    }

    for(int i=0; i<LastVertexID+1; i++) IndexV[i                   ]    = -1;
    for(int i=0; i<NVertex       ; i++) IndexV[vertices[i]->GetID()]    =  i;

    for(int i=0; i<NFace  ; i++) if(Ivert[IndexV[faces[i] ->GetEdge()->GetOrg()->GetID()]]) {delete faces[i];    faces[i]   =NULL;}
    for(int i=0; i<NQEdge ; i++) if(Ivert[IndexV[qedges[i]->GetEdge()->GetOrg()->GetID()]]) {delete qedges[i];   qedges[i]  =NULL;}
    for(int i=0; i<NVertex; i++) if(Ivert[i])                                               {delete vertices[i]; vertices[i]=NULL;}

    delete[] Ivert; delete[] IndexV;

    int NF = 0; for(int i=0; i<NFace  ; i++) if(faces   [i]) faces   [NF++] = faces   [i]; NFace   = NF;
    int NQ = 0; for(int i=0; i<NQEdge ; i++) if(qedges  [i]) qedges  [NQ++] = qedges  [i]; NQEdge  = NQ;
    int NV = 0; for(int i=0; i<NVertex; i++) if(vertices[i]) vertices[NV++] = vertices[i]; NVertex = NV;

    return U_OK;
}
UManifold** UManifold::GetComponents(int* NComp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetComponents(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetComponents(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(NComp==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetComponents(). Invalid NULL argument. \n");
        return NULL;
    }

    int  Ncomp  = -1;
    int* Ivert  = GetVertexComponentMembership(&Ncomp);
    int* IndexV = new int[LastVertexID+1];
    if(Ivert==NULL || IndexV==NULL || Ncomp<=0)
    {
        delete[] Ivert; delete[] IndexV;
        CI.AddToLog("ERROR: UManifold::GetComponents(). Computing vertex component membership (Ncomp=%d). \n", Ncomp);
        return NULL;
    }
    UManifold**  Mar  = new UManifold*[Ncomp];
    UManifold    Copy = *this;
    if(Mar==NULL || Copy.GetError()!=U_OK)
    {
        delete[] Ivert; delete[] IndexV; delete[] Mar;
        CI.AddToLog("ERROR: UManifold::GetComponents(). Creating output array or copying this. \n");
        return NULL;
    }
    
    for(int i=0; i<LastVertexID+1; i++) IndexV[i                   ]    = -1;
    for(int i=0; i<NVertex       ; i++) IndexV[vertices[i]->GetID()]    =  i;

    for(int ic=0; ic<Ncomp; ic++) 
    {
        Mar[ic] =  new UManifold();

        int NF = 0; for(int i=0; i<NFace  ; i++) if(Ivert[IndexV[faces[i] ->GetEdge()->GetOrg()->GetID()]]==ic) NF++;
        int NQ = 0; for(int i=0; i<NQEdge ; i++) if(Ivert[IndexV[qedges[i]->GetEdge()->GetOrg()->GetID()]]==ic) NQ++;
        int NV = 0; for(int i=0; i<NVertex; i++) if(Ivert[i]                                              ==ic) NV++;

        if(Mar[ic]==NULL || NF==0 || NQ==0 || NV==0)
        {
            for(int i=0; i<Ncomp; i++) delete Mar[i];
            delete[] Ivert; delete[] IndexV; delete[] Mar;
            CI.AddToLog("ERROR: UManifold::GetComponents(). Creating component %d. \n", ic);
            return NULL;
        }

        UManifold* MarIc  = Mar[ic];

        MarIc->faces     = new UFace*    [NF]; MarIc->NFace   = NF;
        MarIc->qedges    = new UQuadEdge*[NQ]; MarIc->NQEdge  = NQ;
        MarIc->vertices  = new UVertex*  [NV]; MarIc->NVertex = NV;
        if(MarIc->faces==NULL || MarIc->qedges==NULL || MarIc->vertices==NULL)
        {
            for(int i=0; i<Ncomp; i++) delete Mar[i];
            delete[] Ivert; delete[] IndexV; delete[] Mar;
            CI.AddToLog("ERROR: UManifold::GetComponents(). Memory allocation, component %d. \n", ic);
            return NULL;
        }

        MarIc ->NFaceAlloc   = NF;
        MarIc ->NQEdgeAlloc  = NQ;
        MarIc ->NVertexAlloc = NV;
        NF = 0; for(int i=0; i<NFace  ; i++) if(Ivert[IndexV[faces[i] ->GetEdge()->GetOrg()->GetID()]]==ic) MarIc->faces   [NF++] = Copy.faces   [i];
        NQ = 0; for(int i=0; i<NQEdge ; i++) if(Ivert[IndexV[qedges[i]->GetEdge()->GetOrg()->GetID()]]==ic) MarIc->qedges  [NF++] = Copy.qedges  [i];
        NV = 0; for(int i=0; i<NVertex; i++) if(Ivert[i]                                              ==ic) MarIc->vertices[NV++] = Copy.vertices[i];

        MarIc->LastFaceID     = MarIc->faces   [0]->GetID(); for(int i=0; i<NF; i++) MarIc->LastFaceID     = MAX(MarIc->LastFaceID    , MarIc->faces   [i]->GetID());
        MarIc->LastQuadEdgeID = MarIc->qedges  [0]->GetID(); for(int i=0; i<NQ; i++) MarIc->LastQuadEdgeID = MAX(MarIc->LastQuadEdgeID, MarIc->qedges  [i]->GetID());
        MarIc->LastVertexID   = MarIc->vertices[0]->GetID(); for(int i=0; i<NV; i++) MarIc->LastVertexID   = MAX(MarIc->LastVertexID  , MarIc->vertices[i]->GetID());
    }
    delete[] Ivert; delete[] IndexV;

/* Delete the Copy pointer only partly. Use its consistent mutual references in the components. */
    delete[] Copy.vertices; Copy.vertices = NULL;
    delete[] Copy.faces;    Copy.faces    = NULL;
    delete[] Copy.qedges;   Copy.qedges   = NULL;

    return Mar;
}

UManifold* UManifold::GetContourCut(const int* ContourID, int NPointsContour, double SplitFactor , UFace** LRFace, bool KeepOldPointsOnLargestComp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(ContourID==NULL || NPointsContour<=2)
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Invalid (NULL) argument, NPointsContour = %d. \n", NPointsContour);
        return NULL;
    }

    UFace*     LRFloc[2] = {NULL, NULL};
    UManifold* MCCut = GetContourCut(ContourID, NPointsContour, LRFloc, KeepOldPointsOnLargestComp);
    if(MCCut==NULL || MCCut->GetError()!=U_OK)
    {
        delete MCCut;
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Splitting manifold along given contour. \n");
        return NULL;
    }

/* Move points of left and right face */
    for(int k=0; k<2; k++)
    {
        UVector3          Norm = LRFloc[k]->GetNormal();
        UFaceEdgeIterator FEI(LRFloc[k]);
        for(UEdge* E=FEI.GetStart(); E; E = FEI.GetNext())
        {
            UVector3* V  = E->GetOrg();
            *V          += SplitFactor * Norm;
        }
    }
    if(LRFace)
    {
        LRFace[0] = LRFloc[0];
        LRFace[1] = LRFloc[1];
    }
    return MCCut;
}

UManifold* UManifold::GetContourCut(const int* ContourID, int NPointsContour, UFace** LRFace, bool KeepOldPointsOnLargestComp)
/*
    Cut Manifold along the given closed contour of vertex IDs, duplicated vertices and edges (with new IDs) and add a face to each side.
    This operation will change the Euler characteristic or the number of components.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(ContourID==NULL || NPointsContour<=2)
    {
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Invalid (NULL) argument, NPointsContour = %d. \n", NPointsContour);
        return NULL;
    }
    for(int n1=0; n1<NPointsContour; n1++)
    {
        if(FindVertex(ContourID[n1])<0)
        {
            CI.AddToLog("ERROR: UManifold::GetContourCut(). Vertex not found: %d \n", ContourID[n1]);
            return NULL;
        }
        for(int n2=0; n2<n1; n2++)
            if(ContourID[n1]==ContourID[n2])
            {
                CI.AddToLog("ERROR: UManifold::GetContourCut(). Contour is self intersecting at ID = %d .\n", ContourID[n1]);
                CI.AddToLog("Note: Contour = ");
                for(int k=0; k<NPointsContour; k++) CI.AddToLog("\t%d ",ContourID[k]); CI.AddToLog(" \n");
                return NULL;
            }
    }

    UManifold* MCCut     = new UManifold(*this);
    int*       ContQEIn  = new int[NPointsContour];   // Indices of quadedges along contour
    bool*      Forward   = new bool[NPointsContour];  // Indicate for each of thoes quadedges whether it is pointing forward
    if(ContQEIn==NULL || MCCut==NULL || MCCut->GetError()!=U_OK || Forward==NULL)
    {
        delete[] ContQEIn; delete MCCut; delete[] Forward;
        CI.AddToLog("ERROR: UManifold::GetContourCut(). Memory allocation,  (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }

/* Add NPointsContour vertices and QuadEdges */
    for(int n=0; n<NPointsContour; n++)
    {
        int  nf   =  n;
        int  nt   = (n+1)%NPointsContour;
        int  indQ = MCCut->FindQuadEdge(ContourID[nf], ContourID[nt]);
        if(indQ<0)
        {
            delete[] ContQEIn; delete MCCut; delete[] Forward;
            CI.AddToLog("ERROR: UManifold::GetContourCut(). QuadEdge not found, from %d to %d or reversed.\n", ContourID[nf], ContourID[nt]);
            return NULL;
        }
        Forward[n]    = ContourID[nf] == qedges[indQ]->GetOrgID();
        UVertex*   V  = MCCut->AddNewVertex();
        UQuadEdge* QE = MCCut->AddNewQuadEdge();
        if(V==NULL || QE==NULL)
        {
            delete[] ContQEIn; delete MCCut; delete[] Forward;
            CI.AddToLog("ERROR: UManifold::GetContourCut(). Adding new vertex or quadedge.\n");
            return NULL;
        }
        V->SetPoint(*(MCCut->vertices[MCCut->FindVertex(ContourID[n])]));
    }

/* Fill contour edge indices and connect subsequent points of duplicate countour. */
/* ContQEIn[] is array of (old) QEdges indices along the contour.                 */
    for(int n=0; n<NPointsContour; n++)
    {
        int      np  = (n+NPointsContour-1)%NPointsContour;
        int      Ind = MCCut->FindQuadEdge(ContourID[np], ContourID[n]);
        UEdge*   E   = MCCut->qedges[NQEdge+n]->GetEdge();
        if(ContourID[np] == qedges[Ind]->GetOrgID())
        {
            E->SetOrg (MCCut->vertices[NVertex+np]);
            E->SetDest(MCCut->vertices[NVertex+n ]);
        }
        else
        {
            E->SetOrg (MCCut->vertices[NVertex+n ]);  // Keep new QEs in same direction as original QEs
            E->SetDest(MCCut->vertices[NVertex+np]);
        }
        ContQEIn[n] = Ind;
    }

/* Connect new edges to old edges and faces */
    for(int n=0; n<NPointsContour; n++)
    {
        int    np   = (n+NPointsContour-1)%NPointsContour;
        UEdge* Eold = MCCut->qedges[ContQEIn[ n  ]]->GetEdge();
        UEdge* Enew = MCCut->qedges[NQEdge +  n   ]->GetEdge();
        if(Forward[np])
        {
            Eold = Eold->GetSym();
            Enew = Enew->GetSym();   // Force both edges against ContourID[]
        }
        Enew->SetRightFace(Eold->GetRightFace());
        Enew->GetSym()            ->SetONext(Eold->GetSym()->GetONext());
        Enew->GetRot()            ->SetONext(Eold->GetRot()->GetONext());
        Eold->GetOPrev()          ->SetONext(Enew);
        Eold->GetRot()->GetOPrev()->SetONext(Enew->GetRot());
    }
    delete[] Forward;
/* Add two faces */
    UFace* FL = MCCut->AddNewFace();
    UFace* FR = MCCut->AddNewFace();

/* Connect new faces to QuadEdges */
    for(int n=0; n<NPointsContour; n++)
    {
        for(int k=0; k<2; k++)  // k==0: original, k==1, new QEs
        {
            UEdge* P=NULL; UEdge* E=NULL;
            if(k==0)
            {
                P  = MCCut->qedges[ContQEIn[(n+1)%NPointsContour]]->GetEdge();
                E  = MCCut->qedges[ContQEIn[ n                  ]]->GetEdge();
            }
            else
            {
                P  = MCCut->qedges[NQEdge +   n                  ]->GetEdge();
                E  = MCCut->qedges[NQEdge +  (n+1)%NPointsContour]->GetEdge();
            }
            if(P->GetOrg ()->GetID()==E->GetOrg ()->GetID())  P = P->GetSym();
            if(P->GetOrg ()->GetID()==E->GetDest()->GetID()) {P = P->GetSym(); E = E->GetSym();}
            if(P->GetDest()->GetID()==E->GetDest()->GetID())                   E = E->GetSym();

            E  ->GetRot() ->SetONext(P->GetRot());
            P  ->GetSym() ->SetONext(E);
            E  ->GetOrg() ->SetEdge(E);
            if(k==0)   E  ->SetRightFace(FL);
            else       E  ->SetRightFace(FR);
        }
    }

/* Connect neighboring vertices to new QuadEdges */
    for(int n=0; n<NPointsContour; n++)
    {
        UVertexEdgeIterator VEI(MCCut->vertices[NVertex+n]);
        for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext())
            E->GetSym()->SetDest(MCCut->vertices[NVertex+n]);
    }
    if(LRFace)
    {
        LRFace[0] = FL;
        LRFace[1] = FR;
    }

    if(KeepOldPointsOnLargestComp)
    {
        int NCold =        GetNComponents();
        int NCnew = MCCut->GetNComponents();
        if(NCold!=NCnew)
        {
            UManifold Mlargest = UManifold(*MCCut);
            if(Mlargest.GetError()!=U_OK || Mlargest.SelectLargestComponent()!=U_OK)
            {
                delete[] ContQEIn;
                CI.AddToLog("ERROR: UManifold::GetContourCut(). Keping old points on largest component.\n");
                return NULL;
            }
            if(Mlargest.FindVertex(ContourID[0])<0)
            {
                for(int n=0; n<NPointsContour; n++) ContQEIn[n] = MCCut->FindVertex(ContourID[n]);
                for(int n=0; n<NPointsContour; n++)
                {
                    MCCut->vertices[ContQEIn[n]]->SetID(MCCut->vertices[NVertex+n]->GetID());
                    MCCut->vertices[NVertex+n]  ->SetID(ContourID[n]);
                }
                MCCut->SortVertices();
            }
        }
    }
    delete[] ContQEIn;
    return MCCut;
}

UManifold** UManifold::GetSplittedManifolds(const int* ContourID, int NPointsContour, UFace** LRFace, bool DupVertexIDs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(LRFace==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). Invalid NULL argument (LRFace).\n");
        return NULL;
    }
    int NComp = GetNComponents();
    if(NComp!=1)
    {
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). Object should have a single component, NComp = %d. \n", NComp);
        return NULL;
    }
    int EulerChar = GetEulerChar();
    if(EulerChar!=2)
        CI.AddToLog("WARNING UManifold::GetSplittedManifolds(). Object does not have an Euler characteristic of 2. It is: %d  .\n", EulerChar);

/* Make a cut at the given contour and collect resulting two components. */
    UManifold* MCCut = GetContourCut(ContourID, NPointsContour, LRFace, false);
    if(MCCut==NULL || MCCut->GetError()!=U_OK)
    {
        delete MCCut;
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). Making a cut along given contour. \n");
        return NULL;
    }
    int    LRID[2] = {LRFace[0]->GetID(), LRFace[1]->GetID()};
    UManifold** MC = MCCut->GetComponents(&NComp);
    delete MCCut;
    if(MC==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). Splitting the cutted manifolds into connected components. ");
        return NULL;
    }
    if(NComp!=2)
    {
        for(int n=0; n<NComp; n++) delete MC[n]; delete[] MC;
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). The cutted manifold should give 2 components. NComp = %d .\n", NComp);
        return NULL;
    }

    LRFace[0] = LRFace[1] = NULL;
    for(int f=0; f<2; f++)
    {
             if(MC[0]->FindFace(LRID[f])>=0) LRFace[0] = MC[0]->faces[MC[0]->FindFace(LRID[f])];
        else if(MC[1]->FindFace(LRID[f])>=0) LRFace[1] = MC[1]->faces[MC[1]->FindFace(LRID[f])];
        else
        {
            delete MC[0]; delete MC[1]; delete[] MC;
            CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). New face(s) not found on either component, f=%d. \n", f);
            return NULL;
        }
    }
    if(LRFace[0]==NULL || LRFace[1]==NULL)
    {
        delete MC[0]; delete MC[1]; delete[] MC;
        CI.AddToLog("ERROR: UManifold::GetSplittedManifolds(). New face(s) not found on either component. \n");
        return NULL;
    }

    if(DupVertexIDs)
    {
        UEdge* E0   = LRFace[0]->GetEdge();
        UEdge* E1   = LRFace[1]->GetEdge();
        int    Off0 = -1;
        int    Off1 = -1;
        for(int n=0; n<NPointsContour; n++) 
        {
            if(E0->GetDest()->GetID() == ContourID[0]) { Off0 = n; break; }
            if(E1->GetOrg()->GetID()  == ContourID[0]) { Off1 = n; break; }
            E0 = E0->GetLNext();
            E1 = E1->GetLPrev();
        }
        if(Off0<0 && Off1<0)
        {
            CI.AddToLog("WARNING: UManifold::GetSplittedManifolds(). ID (%d) not found on either faces. \n", ContourID[0]);
            return MC;
        }
        int  Offset = -1;
        GetFaceMatch(LRFace[0], LRFace[1], &Offset);
        if(Offset<0)
        {
            CI.AddToLog("WARNING: UManifold::GetSplittedManifolds(). Finding best match between connecting faces, Offset = %d. \n", Offset);
            return MC;
        }
        if(Off1<0) for(int n=0; n<Offset; n++) E1 = E1->GetLPrev();
        else       for(int n=0; n<Offset; n++) E0 = E0->GetLPrev();

        for(int n=0; n<NPointsContour; n++)
        {
            if(Off1>0) E0->GetDest()->SetID(E1->GetOrg() ->GetID());
            else       E1->GetOrg() ->SetID(E0->GetDest()->GetID());
            E0 = E0->GetLNext();
            E1 = E1->GetLPrev();
        }
    }
    return MC;
}

UVector3* UManifold::GetDensityPoints(int* NDensPoints) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). this==NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Object empty or not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(NDensPoints==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Invalid NULL pointer argument .\n");
        return NULL;
    }
    double TArea = GetTotalArea();
    if(TArea<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Total area invalid: TArea= %f .\n", TArea);
        return NULL;
    }
    double Rmax  = sqrt(TArea/NVertex)/5;
    int*   IVal  = new int[NVertex];
    if(IVal==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Memory allocation, NVertex=%d   \n", NVertex);
        return NULL;
    }
    int NFore = 0;
    int NPair = 0;
    for(int n=0; n<NVertex; n++) IVal[n] = -1;
    for(int n=0; n<NVertex; n++)
    {
        if(vertices[n]==NULL) continue;
        if(vertices[n]->GetShortestEdgeLength()>=Rmax) continue;
        IVal[n]  = NFore++;
        NPair   += vertices[n]->GetNEdge();
    }
    int* ListA = new int[NPair];
    int* ListB = new int[NPair];
    if(NFore<=0 || NPair<=0 || ListA==NULL || ListB==NULL)
    {
        delete[] IVal; delete[] ListA; delete[] ListB;
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Memory allocation(?), NFore=%d, NPair = %d \n", NFore, NPair);
        return NULL;
    }
    NPair = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(vertices[n]==NULL) continue;
        if(IVal[n]<0)         continue;
        UEdge* S = vertices[n]->GetEdge();
        UEdge* E = vertices[n]->GetEdge();
        do
        {
            int nn = FindVertex(E->GetDest()->GetID());
            if(n<nn && IVal[nn]>=0)
            {
                ListA[NPair] = IVal[n ];
                ListB[NPair] = IVal[nn];
                NPair++;
            }
            E=E->GetONext();
        }
        while(E && E!=S);
    }

    int     NComp = -1;
    int*    Comps = GetEquivalenceClass(NFore, ListA, ListB, NPair, &NComp);
    delete[] ListA;
    delete[] ListB;
    if(Comps==NULL || NComp<=0)
    {
        delete[] IVal; delete[] Comps;
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Computing equivalences classes, NComp = %d  .\n", NComp);
        return NULL;
    }
    double*   Rmin = new double[NComp];
    UVector3* PDen = new UVector3[NComp];
    if(PDen==NULL || Rmin==NULL)
    {
        delete[] PDen; delete[] Rmin; delete[] IVal; delete[] Comps;
        CI.AddToLog("ERROR: UManifold::GetDensityPoints(). Memory allocation, NComp = %d  .\n", NComp);
        return NULL;
    }
    for(int ic=0; ic<NComp; ic++)
    {
        Rmin[ic]      =  Rmax;
        int    CompNo = -1;
        bool   First  = true;
        for(int n=0; n<NVertex; n++)
        {
            if(vertices[n]==NULL || IVal[n]<0) continue;
            if(First)
            {
                PDen[ic] = *(vertices[n]);
                Rmin[ic] = vertices[n]->GetShortestEdgeLength();
                CompNo   = Comps[IVal[n]];
                First    = false;
            }
            else
            {
                if(Comps[IVal[n]]!=CompNo) continue;

                double R = vertices[n]->GetShortestEdgeLength();
                if(R<Rmin[ic])
                {
                    Rmin[ic] = R;
                    PDen[ic] = *(vertices[n]);
                }
            }
            IVal[n] = -1;
        }
    }
    delete[] IVal; delete[] Comps;

    int*      Index = GetOrderIndexArray(Rmin, NComp, false, false);
    UVector3* Pord  = new UVector3[NComp];
    if(Index && Pord)
    {
        for(int ic=0; ic<NComp; ic++) Pord[ic] = PDen[Index[ic]];
        UVector3* Dum=PDen; PDen=Pord; Pord=Dum;
    }
    delete[] Pord; delete[] Index; delete[] Rmin;

    *NDensPoints = NComp;
    return PDen;
}

ErrorType UManifold::Merge(const UManifold &M)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::Merge(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(&M==NULL || M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::Merge(). Argument has NULL address or is erroneous. \n");
        return U_ERROR;
    }

    UManifold* CopyM = new UManifold(M);
    if(CopyM==NULL || CopyM->GetError()!=U_OK)
    {
        delete CopyM;
        CI.AddToLog("ERROR: UManifold::Merge(). Copying argument. \n");
        return U_ERROR;
    }

    int NewNVertex   = NVertex+M.NVertex;
    if(M.vertices)
    {
        if(NewNVertex>NVertexAlloc)
        {
            UVertex** Newvertices  = new UVertex*[NewNVertex];
            if(Newvertices==NULL)
            {
                delete CopyM;
                CI.AddToLog("ERROR: UManifold::Merge(). Memory allocation, NewNVertex = %d. \n", NewNVertex);
                return U_ERROR;
            }
            for(int n=0; n<NVertex; n++) Newvertices[n] = vertices[n];
            delete[] vertices; vertices = Newvertices;
            NVertexAlloc = NewNVertex;
        }
        if(CopyM->vertices)
            for(int n=0;n<M.NVertex; n++) vertices[n+NVertex] = CopyM->vertices[n];
    }

    int NewNFace = NFace+M.NFace;
    if(M.faces)
    {
        if(NewNFace>NFaceAlloc)
        {
            UFace** Newfaces  = new UFace*[NewNFace];
            if(Newfaces==NULL)
            {
                delete CopyM;
                CI.AddToLog("ERROR: UManifold::Merge(). Memory allocation, NewNFace = %d. \n", NewNFace);
                return U_ERROR;
            }
            for(int n=0; n<NFace; n++) Newfaces[n] = faces[n];
            delete[] faces; faces = Newfaces;
            NFaceAlloc = NewNFace;
        }
        if(CopyM->faces)
            for(int n=0;n<M.NFace; n++) faces[n+NFace] = CopyM->faces[n];
    }

    int NewNQEdge = NQEdge+M.NQEdge;
    if(M.qedges)
    {
        if(NewNQEdge>NQEdgeAlloc)
        {
            UQuadEdge** Newqedges  = new UQuadEdge*[NewNQEdge];
            if(Newqedges==NULL)
            {
                delete CopyM;
                CI.AddToLog("ERROR: UManifold::Merge(). Memory allocation, NewNQEdge = %d. \n", NewNQEdge);
                return U_ERROR;
            }
            for(int n=0; n<NQEdge; n++) Newqedges[n] = qedges[n];
            delete[] qedges; qedges = Newqedges;
            NQEdgeAlloc = NewNQEdge;
        }
        if(CopyM->qedges)
            for(int n=0;n<M.NQEdge; n++) qedges[n+NQEdge] = CopyM->qedges[n];
    }

/* Make IDs unique*/
    for(int m=NVertex; m<NewNVertex; m++)  vertices[m]->SetID(LastVertexID   + m-NVertex + 1);
    for(int m=NFace  ; m<NewNFace  ; m++)  faces[m]   ->SetID(LastFaceID     + m-NFace   + 1);
    for(int m=NQEdge;  m<NewNQEdge;  m++)  qedges[m]  ->SetID(LastQuadEdgeID + m-NQEdge  + 1);

    LastVertexID   += M.NVertex;
    LastFaceID     += M.NFace;
    LastQuadEdgeID += M.NQEdge;

    NVertex         = NewNVertex;
    NFace           = NewNFace;
    NQEdge          = NewNQEdge;

/* Delete the CopyM pointer only partly. Use its consistent mutual references in the merged object. */
    delete[] CopyM->vertices; CopyM->vertices = NULL;
    delete[] CopyM->faces;    CopyM->faces    = NULL;
    delete[] CopyM->qedges;   CopyM->qedges   = NULL;
    delete   CopyM;

    return U_OK;
}
ErrorType UManifold::MergeFaces(int FaceID, const UManifold &M, int FaceIDM)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(&M==NULL || M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Argument has NULL address or is erroneous. \n");
        return U_ERROR;
    }
    if( (M.NVertex<0 || M.vertices==NULL) ||
        (M.NFace  <0 || M.faces   ==NULL) ||
        (M.NQEdge <0 || M.qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Object argument not properly set (M.NVertex, M.NFace, M.NQEdge) = (%d,%d,%d). \n", M.NVertex, M.NFace, M.NQEdge);
        return U_ERROR;
    }

    int    indF  =   FindFace(FaceID );
    int    indFM = M.FindFace(FaceIDM);
    UFace* F    = indF >=0 ?   faces[indF ] : NULL;
    UFace* FM   = indFM>=0 ? M.faces[indFM] : NULL;
    if(F==NULL || FM==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Face(s) not found: FaceID=%d, FaceIDM=%d   . \n", FaceID, FaceIDM);
        return U_ERROR;
    }
    UFaceEdgeIterator FEI (F );
    UFaceEdgeIterator FEIM(FM);
    int NN  = FEI .GetNNeighbour();
    int NNm = FEIM.GetNNeighbour();
    if(NN!=NNm || NN<=2)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Face(s) have different NNeighbors: %d and =%d, or these numbers are smaller than 3. \n", NN, NNm);
        return U_ERROR;
    }
    int       IvertOff = 0;
    ULinTran  XFM      = GetFaceMatch(F, FM, &IvertOff);

    indFM          += NFace;
    UManifold Mcopy = M;
    Mcopy.Transform(XFM);
    if(Merge(Mcopy)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Merging copy of transformed M . \n");
        return U_ERROR;
    }
    F  = faces[indF ];
    FM = faces[indFM];

// Merge faces F and FM, remove them, remove boundary edges and vertices of FM
    int*    RemE = new int[NN];
    int*    RemV = new int[NN];
    UEdge** Ebuf = new UEdge*[10*NN];

    if(RemE==NULL || RemV==NULL || Ebuf==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MergeFaces(). Memory allocation . \n");
        delete[] RemE; delete[] RemV; delete[] Ebuf;
        return U_ERROR;
    }
    UEdge** Efr  = Ebuf;
    UEdge** Eto  = Ebuf + 4*NN;
    UEdge** EEb  = Ebuf + 8*NN;
    UEdge** EEMb = Ebuf + 9*NN;

    UEdge* EE  = F ->GetEdge();
    UEdge* EEM = FM->GetEdge();
    for(int k=0; k<IvertOff; k++) EEM = EEM->GetLPrev();
    for(int k=0; k<NN; k++, EE=EE->GetLNext(), EEM=EEM->GetLPrev())  // Fill (UEdge) tables
    {
        EEb [k]       = EE;
        EEMb[k]       = EEM;
        
        UVertex*   VM = EEMb[k]->GetOrg();
        int      indV = FindVertex(VM->GetID());
        int      indE = FindQuadEdge(EEM);
        if(indV<0 || indE<0)
        {
            CI.AddToLog("ERROR: UManifold::MergeFaces(). Vertex or Edge not found. k=%d . \n", k);
            delete[] RemE; delete[] RemV; delete[] Ebuf;
            return U_ERROR;
        }
        RemE[k]    = indE; 
        RemV[k]    = indV;

        Eto[4*k+0] = EEb [k]                                ;    Efr[4*k+0] = EEMb[k]->GetSym()->GetONext()   ;
        Eto[4*k+1] = EEMb[k]->GetOPrev()                    ;    Efr[4*k+1] = EEb [k]->GetSym()               ;
        Eto[4*k+2] = EEb [k]->GetInvRot()                   ;    Efr[4*k+2] = EEMb[k]->GetOPrev()->GetInvRot();
        Eto[4*k+3] = EEMb[k]->GetSym()->GetONext()->GetRot();    Efr[4*k+3] = EEb [k]->GetInvRot()            ;
    }
    for(int k=0; k<NN; k++)  // Eliminate vertices and face to be deleted
    {
        UVertex* VM = EEMb[k]->GetOrg();
        UVertex* V  = EEb [k]->GetDest();

        UVertexEdgeIterator VEI(VM);
        for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext()) 
            if(E!=EEMb[(NN+k-1)%NN]->GetSym()&&E!=EEMb[k]) E->SetOrg(V);

        EEb[k]->SetLeftFace(EEMb[k]->GetRightFace());
    }
    for(int k=0; k<NN; k++) // Sew edges
    {
        Eto[4*k+0]->SetONext(Efr[4*k+0]);
        Eto[4*k+1]->SetONext(Efr[4*k+1]);
        Eto[4*k+2]->SetONext(Efr[4*k+2]);
        Eto[4*k+3]->SetONext(Efr[4*k+3]);
    }
    delete faces[indF ]; faces[indF]  = NULL; 
    delete faces[indFM]; faces[indFM] = NULL; 
    for(int n=0,k=0; n<NFace ; n++) if(faces  [n]) faces  [k++] = faces  [n]; NFace -=2;

    for(int k=0; k<NN; k++)
    {
        delete qedges  [RemE[k]]; qedges  [RemE[k]] = NULL;
        delete vertices[RemV[k]]; vertices[RemV[k]] = NULL;
    }
    delete[] RemE; delete[] RemV; delete[] Ebuf;

    for(int n=0,k=0; n<NQEdge ; n++) if(qedges  [n]) qedges  [k++] = qedges  [n]; NQEdge -=NN;
    for(int n=0,k=0; n<NVertex; n++) if(vertices[n]) vertices[k++] = vertices[n]; NVertex-=NN;

    UpdateLastIDs();
    return U_OK;
}
ErrorType UManifold::MergeEdgesSameFace(int QEdgeID1, int QEdgeID2)
/* 
    Note: function can yield degenerated results if origin or destination have three or less neighbors.
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(QEdgeID1==QEdgeID2)
    {
        CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). QuadEdge IDs identical: %d. \n", QEdgeID1);
        return U_ERROR;
    }
    int indE1 = FindQuadEdge(QEdgeID1);
    int indE2 = FindQuadEdge(QEdgeID2);
    if(indE1<0 || indE2<0)
    {
        CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Edges not found: ID = %d, %d .\n", QEdgeID1, QEdgeID2);
        return U_ERROR;
    }
    UFace* FL1 = qedges[indE1]->GetEdge()->GetLeftFace();
    UFace* FR1 = qedges[indE1]->GetEdge()->GetRightFace();
    UFace* FL2 = qedges[indE2]->GetEdge()->GetLeftFace();
    UFace* FR2 = qedges[indE2]->GetEdge()->GetRightFace();

    UFace* FF  = NULL;
    UEdge* E1  = NULL;
    UEdge* E2  = NULL;
    if(FL1==FL2) {FF = FL1; E1=qedges[indE1]->GetEdge()    ; E2=qedges[indE2]->GetEdge()   ;}
    if(FL1==FR2) {FF = FL1; E1=qedges[indE1]->GetEdge()    ; E2=qedges[indE2]->GetEdgeSym();}
    if(FR1==FL2) {FF = FR1; E1=qedges[indE1]->GetEdgeSym() ; E2=qedges[indE2]->GetEdge()   ;}
    if(FR1==FR2) {FF = FR1; E1=qedges[indE1]->GetEdgeSym() ; E2=qedges[indE2]->GetEdgeSym();}

    int indFF = FF ? FindFace(FF->GetID()):-1;
    if(FF==NULL || indFF<0 || E1==NULL || E2==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Edges with IDs %d and %d do not share same face.\n", QEdgeID1, QEdgeID2);
        return U_ERROR;
    }

    if(E1->GetLNext()==E2 && E2->GetLNext()==E1)  // remove FF and E1
    {
        RemoveQEdgeReferences(qedges[indE1]);

        E1->GetOrg()->SetEdge(E2->GetSym());
        E2->GetOrg()->SetEdge(E2          );

        E2->SetLeftFace(E1->GetRightFace());

        E1->GetOPrev()           ->SetONext(E1->GetONext()             );
        E2                       ->SetONext(E2->GetONext()->GetONext() );
        E2->GetONext()->GetRot() ->SetONext(E2->GetInvRot()            );
        E2->GetInvRot()          ->SetONext(E1->GetOPrev()->GetInvRot());

        delete FF           ; for(int k=indFF; k<NFace -1; k++) faces [k] = faces [k+1]; NFace--;
        delete qedges[indE1]; for(int k=indE1; k<NQEdge-1; k++) qedges[k] = qedges[k+1]; NQEdge--;
    }
    else if(E1->GetLNext()==E2 || E2->GetLNext()==E1)
    {
        if(E2->GetLNext()==E1)          // Start with E1
        {
            UEdge* Edum = E1   ; E1    = E2   ; E2    = Edum;
            int    Idum = indE1; indE1 = indE2; indE2 = Idum;
        }
        UEdge* E3 = E2->GetLNext();
        if(E3->GetLNext()==E1)  // Triangle. Remove E1, E2, E3 and FF. Replace corners by center of FF
        {
            CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Removing complete triangle. Case not yet implemented.\n");
            return U_ERROR;
        }
        else // Remove E1 and E1->Org. FF is at least triangle
        {
            RemoveQEdgeReferences(qedges[indE1]);
            UVertex* VD2   = E2->GetDest();
            UVertex* VO1   = E1->GetOrg();

            int      indV1 = FindVertex(VO1->GetID());
            UVector3 Aver  = 0.5*(*VO1 + *VD2); *VD2 = Aver;

            UVertexEdgeIterator VE1(VO1);
            for(UEdge* E=VE1.GetStart(); E; E=VE1.GetNext()) if(E!=E1) E->SetOrg(VD2);
            
            E2->SetLeftFace(E1->GetRightFace());
            FF->SetEdge(E3);

            UEdge* ETo[6] = {E1->GetSym()->GetONext(), E2->GetInvRot()                   , E1->GetONext(), E3->GetInvRot()         , E2->GetSym()   , E1->GetOPrev()->GetInvRot()};
            UEdge* EFr[6] = {E2                      , E1->GetSym()->GetONext()->GetRot(), E3            , E1->GetONext()->GetRot(), E1->GetOPrev() , E2->GetInvRot()            };

            for(int k=0; k<6; k++) EFr[k]->SetONext(ETo[k]);

            delete VO1          ; for(int k=indV1; k<NVertex-1; k++) vertices[k] = vertices[k+1]; NVertex--;
            delete qedges[indE1]; for(int k=indE1; k<NQEdge -1; k++) qedges  [k] = qedges  [k+1]; NQEdge--;

            UEdge* E4 = E3->GetLNext();
            if(E4->GetLNext()==E3) // Square. Remove E3 and FF
            {
                if(MergeEdgesSameFace(E3->GetID()/4, E4->GetID()/4)!=U_OK)
                {
                    CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Removing one of remaining double edges (%d, %d).\n", E3->GetID()/4, E4->GetID()/4);
                    return U_ERROR;
                }
            }
        }
    }
    else if(E1->GetLNext()->GetLNext()==E2 && E2->GetLNext()->GetLNext()==E1) // Square with paralel sides E1 and E2.
    {                                                                         // Remove E1, E1->LNext, E2->LNext, E1->Org, E2->Org and FF
        UEdge* E3 = E1->GetLNext();
        UEdge* E4 = E2->GetLNext();        
        if(RemoveEdgeMergeVertices(E1->GetID()/4)!=U_OK || RemoveEdgeMergeVertices(E2->GetID()/4)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Merging vertices of either %d or %d.\n", E1->GetID()/4, E2->GetID()/4);
            return U_ERROR;
        }
        if(MergeEdgesSameFace(E3->GetID()/4, E4->GetID()/4)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace(). Removing double edges, one of %d and %d.\n", E1->GetID()/4, E2->GetID()/4);
            return U_ERROR;
        }
    }
    else if(E1->GetLNext()->GetLNext()==E2 || E2->GetLNext()->GetLNext()==E1)
    {
        if(E2->GetLNext()->GetLNext()==E1)          // Start with E1
        {
            UEdge* Edum = E1   ; E1    = E2   ; E2    = Edum;
            int    Idum = indE1; indE1 = indE2; indE2 = Idum;
        }                                           // Remove E1, E1->LNext, E1->Org, E2->Org
        
        UEdge*   EN1 = E1->GetLNext();;
        if(EN1==NULL ||RemoveEdgeMergeVertices(EN1->GetID()/4)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::MergeEdgesSameFace().Removing intermediate edge between %d and %d.\n", QEdgeID1, QEdgeID2);
            return U_ERROR;
        }
        return MergeEdgesSameFace(QEdgeID1, QEdgeID2);
    }
    else // Remove E1, E1->Org, E2->Org, Add new Face
    {
        UVertex* VD1 = E1->GetDest();
        UVertex* VD2 = E2->GetDest();
        UVertex* VO1 = E1->GetOrg();  int indV1 = FindVertex(VO1->GetID());
        UVertex* VO2 = E2->GetOrg();  int indV2 = FindVertex(VO2->GetID());
        UEdge*   EN1 = E1->GetLNext(); 
        UEdge*   EN2 = E2->GetLNext(); 
       
        RemoveQEdgeReferences(qedges[indE1]);

        UVector3 Aver = 0.5*(*VO1 + *VD2); *VD2 = Aver;
                 Aver = 0.5*(*VO2 + *VD1); *VD1 = Aver;

        UVertexEdgeIterator VE1(VO1); for(UEdge* E=VE1.GetStart(); E; E=VE1.GetNext()) if(E!=E1) E->SetOrg(VD2);
        UVertexEdgeIterator VE2(VO2); for(UEdge* E=VE2.GetStart(); E; E=VE2.GetNext())           E->SetOrg(VD1);

        FF ->SetEdge(EN2);
        EN2->SetLeftFace(FF);
        E2 ->SetLeftFace(E1->GetRightFace());

        UEdge* ETo[8] = {E1 ->GetONext()->GetRot(),E2 ->GetONext()->GetRot(), E1->GetSym()->GetONext()->GetRot(), E2->GetInvRot()            , E2                      , EN1           , E1->GetOPrev(), EN2           };
        UEdge* EFr[8] = {EN2->GetInvRot()         ,EN1-> GetInvRot()        , E2->GetInvRot()                   , E1->GetOPrev()->GetInvRot(), E1->GetSym()->GetONext(), E2->GetONext(), E2->GetSym()  , E1->GetONext()};
        for(int k=0; k<8; k++) ETo[k]->SetONext(EFr[k]);

        UFace*  Fnew = AddNewFace();
        Fnew->SetEdge(EN1); 
        EN1 ->SetLeftFace(Fnew);
        for(UEdge* E=EN1->GetLNext(); E!=EN1;E=E->GetLNext()) E->SetLeftFace(Fnew);

        delete vertices[indV1]; vertices[indV1] = NULL; 
        delete vertices[indV2]; vertices[indV2] = NULL; 
        for(int n=0, k=0; n<NVertex; n++) if(vertices[n]) vertices[k++]=vertices[n]; NVertex-=2;

        delete qedges[indE1 ]; qedges[indE1 ] = NULL;
        for(int n=0, k=0; n<NQEdge; n++) if(qedges[n]) qedges[k++]=qedges[n]; NQEdge-=1;
    }
    return U_OK;
}
ErrorType UManifold::AddEdgeSameFace(int QEdgeID1, int QEdgeID2)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(QEdgeID1==QEdgeID2)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). QuadEdge IDs identical: %d. \n", QEdgeID1);
        return U_ERROR;
    }
    int indE1 = FindQuadEdge(QEdgeID1);
    int indE2 = FindQuadEdge(QEdgeID2);
    if(indE1<0 || indE2<0)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). Edges not found: ID = %d, %d .\n", QEdgeID1, QEdgeID2);
        return U_ERROR;
    }
    UFace* FL1 = qedges[indE1]->GetEdge()->GetLeftFace();
    UFace* FR1 = qedges[indE1]->GetEdge()->GetRightFace();
    UFace* FL2 = qedges[indE2]->GetEdge()->GetLeftFace();
    UFace* FR2 = qedges[indE2]->GetEdge()->GetRightFace();

    UFace* FF  = NULL;
    UEdge* E1  = NULL;
    UEdge* E2  = NULL;
    if(FL1==FL2) {FF = FL1; E1=qedges[indE1]->GetEdge()    ; E2=qedges[indE2]->GetEdge()   ;}
    if(FL1==FR2) {FF = FL1; E1=qedges[indE1]->GetEdge()    ; E2=qedges[indE2]->GetEdgeSym();}
    if(FR1==FL2) {FF = FR1; E1=qedges[indE1]->GetEdgeSym() ; E2=qedges[indE2]->GetEdge()   ;}
    if(FR1==FR2) {FF = FR1; E1=qedges[indE1]->GetEdgeSym() ; E2=qedges[indE2]->GetEdgeSym();}

    int indFF = FF ? FindFace(FF->GetID()):-1;
    if(FF==NULL || indFF<0 || E1==NULL || E2==NULL)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). Edges with IDs %d and %d do not share same face.\n", QEdgeID1, QEdgeID2);
        return U_ERROR;
    }
    if(E1->GetLNext()==E2 || E2->GetLNext()==E1)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). Edges with IDs %d and %d mutually connected.\n", QEdgeID1, QEdgeID2);
        return U_ERROR;
    }
    if(FindQuadEdge(E1->GetOrg()->GetID(), E2->GetOrg()->GetID())>=0)
    {
        CI.AddToLog("ERROR: UManifold::AddEdgeSameFace(). Edge from %d to %d already exists.\n", E1->GetOrg()->GetID(), E2->GetOrg()->GetID());
        return U_ERROR;
    }

    UQuadEdge* Qnew = AddNewQuadEdge();
    Qnew->GetEdge()->SetOrg (E1->GetOrg());
    Qnew->GetEdge()->SetDest(E2->GetOrg());

    UEdge*     EE   = Qnew->GetEdge();
    UEdge*     ES   = Qnew->GetEdge()->GetSym();
    UFace*     Fnew = AddNewFace();
    EE->SetLeftFace(FF  );
    ES->SetLeftFace(Fnew);

    UEdge* Efr[8] = {E1->GetONext(),E2->GetONext(),EE,ES,E1->GetInvRot(),E2->GetInvRot(),ES->GetRot()            ,EE->GetRot()            };
    UEdge* Eto[8] = {EE            ,ES            ,E1,E2,EE->GetRot()   ,ES->GetRot()   ,E1->GetONext()->GetRot(),E2->GetONext()->GetRot()};

    for(int k=0; k<8; k++) Eto[k]->SetONext(Efr[k]);

    for(UEdge* E=ES->GetLNext(); E!=ES;E=E->GetLNext()) E->SetLeftFace(Fnew);

    return U_OK;
}

ErrorType UManifold::AddTriangle(int ip0, int ip1, int ip2, const UVector3* p)
/*
    Add a triangle to *this manifold, where ip0, ip1 and ip2 are indices to
    points in the array p[] and they aew also the ID s of the vertices in the
    *this manifold. AddTriangle() should be called iteratively in an arbitrary 
    sequence until all triangles described a closed surface.
 */
{
    if(ip0==ip1 || ip1==ip2 || ip2==ip0) return U_ERROR;
    if(ip0<0    || ip1<0    || ip2<0   ) return U_ERROR;

    int      n0   = FindVertex(ip0);
    int      n1   = FindVertex(ip1);
    int      n2   = FindVertex(ip2);
    UVertex* ver0 = NULL; if(n0<0) {ver0 = p?new UVertex(p[ip0], ip0):new UVertex(UVector3(), ip0); AddVertex(ver0,&n0,&n1,&n2);} else {ver0 = vertices[n0];}
    UVertex* ver1 = NULL; if(n1<0) {ver1 = p?new UVertex(p[ip1], ip1):new UVertex(UVector3(), ip1); AddVertex(ver1,&n0,&n1,&n2);} else {ver1 = vertices[n1];}
    UVertex* ver2 = NULL; if(n2<0) {ver2 = p?new UVertex(p[ip2], ip2):new UVertex(UVector3(), ip2); AddVertex(ver2,&n0,&n1,&n2);} else {ver2 = vertices[n2];}
    if(LastVertexID<=ip0) LastVertexID = ip0;
    if(LastVertexID<=ip1) LastVertexID = ip1;
    if(LastVertexID<=ip2) LastVertexID = ip2;

    int nq10 = FindQuadEdge(ip1, ip0);
    int nq21 = FindQuadEdge(ip2, ip1);
    int nq02 = FindQuadEdge(ip0, ip2);
    
    return AddTriangle(ver0, ver1, ver2, nq10, nq21, nq02);
}

ErrorType UManifold::AddTriangle(UVertex* ver0, UVertex* ver1, UVertex* ver2, int nq10, int nq21, int nq02)
/*
    Add a triangle to *this manifold, where ver0, ver1 and ver2 are elements in the
    vertices[] array and nq10, nq21 and nq02 are indices in the qedges[] array. For
    negative indices new QuadEdges are created. AddTriangle() makes sure all
    neighbor references are created.
    
    AddTriangle() should be called iteratively in an arbitrary sequence until all 
    triangles described a closed surface.
 */
{
    if(ver0==NULL||ver1==NULL||ver2==NULL) return U_ERROR;

    UFace*   tri  = AddNewFace();
    if(tri==NULL)                          return U_ERROR;

    UQuadEdge* QE01 = NULL; if(nq10<0) {QE01 = AddNewQuadEdge();} else {QE01 = qedges[nq10];}
    UQuadEdge* QE12 = NULL; if(nq21<0) {QE12 = AddNewQuadEdge();} else {QE12 = qedges[nq21];}
    UQuadEdge* QE20 = NULL; if(nq02<0) {QE20 = AddNewQuadEdge();} else {QE20 = qedges[nq02];}

    if(QE01==NULL || QE12==NULL || QE20==NULL) return U_ERROR;

/* Vertices */
    if(nq10<0) {QE01->GetEdge()->SetOrg(ver0);  QE01->GetEdge()->SetDest(ver1);}
    if(nq21<0) {QE12->GetEdge()->SetOrg(ver1);  QE12->GetEdge()->SetDest(ver2);}
    if(nq02<0) {QE20->GetEdge()->SetOrg(ver2);  QE20->GetEdge()->SetDest(ver0);}

/* Clock wise and counter clock wise edges */
    if(nq10<0)
    {
        if(nq02<0) QE01->GetEdge()   ->SetONext(QE20->GetEdgeSym());
        else       QE01->GetEdge()   ->SetONext(QE20->GetEdge()   );
        QE01->GetEdgeSym()->SetONext(NULL);
    }
    else
    {
        if(nq02<0) QE01->GetEdgeSym()->SetONext(QE20->GetEdgeSym());
        else       QE01->GetEdgeSym()->SetONext(QE20->GetEdge()   );
    }

    if(nq21<0)
    {
        if(nq10<0) QE12->GetEdge()   ->SetONext(QE01->GetEdgeSym());
        else       QE12->GetEdge()   ->SetONext(QE01->GetEdge()   );
        QE12->GetEdgeSym()->SetONext(NULL);
    }
    else
    {
        if(nq10<0) QE12->GetEdgeSym()->SetONext(QE01->GetEdgeSym());
        else       QE12->GetEdgeSym()->SetONext(QE01->GetEdge()   );
    }

    if(nq02<0)
    {
        if(nq21<0) QE20->GetEdge()   ->SetONext(QE12->GetEdgeSym());
        else       QE20->GetEdge()   ->SetONext(QE12->GetEdge()   );
        QE20->GetEdgeSym()->SetONext(NULL);
    }
    else
    {
        if(nq21<0) QE20->GetEdgeSym()->SetONext(QE12->GetEdgeSym());
        else       QE20->GetEdgeSym()->SetONext(QE12->GetEdge()   );
    }

/* Faces */
    if(nq10<0) QE01->GetEdge()->SetLeftFace (tri);
    else       QE01->GetEdge()->SetRightFace(tri);
    if(nq21<0) QE12->GetEdge()->SetLeftFace (tri);
    else       QE12->GetEdge()->SetRightFace(tri);
    if(nq02<0) QE20->GetEdge()->SetLeftFace (tri);
    else       QE20->GetEdge()->SetRightFace(tri);

/* Inward and outward edges */
    if(nq10<0) // QE01->GetEdgeRot()    is undefined yet
    {
                   QE01->GetEdgeRot()   ->SetONext(NULL);
        if(nq21<0) QE01->GetEdgeInvRot()->SetONext(QE12->GetEdgeInvRot());
        else       QE01->GetEdgeInvRot()->SetONext(QE12->GetEdgeRot()   );
    }
    else       // QE01->GetEdgeInvRot() is set already before
    {
        if(nq21<0) QE01->GetEdgeRot()   ->SetONext(QE12->GetEdgeInvRot());
        else       QE01->GetEdgeRot()   ->SetONext(QE12->GetEdgeRot()   );
    }

    if(nq21<0) // QE12->GetEdgeRot()    is undefined yet
    {
                   QE12->GetEdgeRot()   ->SetONext(NULL);
        if(nq02<0) QE12->GetEdgeInvRot()->SetONext(QE20->GetEdgeInvRot());
        else       QE12->GetEdgeInvRot()->SetONext(QE20->GetEdgeRot()   );
    }
    else       // QE12->GetEdgeInvRot() is set already before
    {
        if(nq02<0) QE12->GetEdgeRot()   ->SetONext(QE20->GetEdgeInvRot());
        else       QE12->GetEdgeRot()   ->SetONext(QE20->GetEdgeRot()   );
    }

    if(nq02<0) // QE20->GetEdgeRot()    is undefined yet
    {
                   QE20->GetEdgeRot()   ->SetONext(NULL);
        if(nq10<0) QE20->GetEdgeInvRot()->SetONext(QE01->GetEdgeInvRot());
        else       QE20->GetEdgeInvRot()->SetONext(QE01->GetEdgeRot()   );
    }
    else       // QE20->GetEdgeInvRot() is set already before
    {
        if(nq10<0) QE20->GetEdgeRot()   ->SetONext(QE01->GetEdgeInvRot());
        else       QE20->GetEdgeRot()   ->SetONext(QE01->GetEdgeRot()   );
    }
    return U_OK;
}

static int SortVert(const void *elem1, const void *elem2)
{
    int ID1 = (*((const UVertex**)elem1))->GetID();
    int ID2 = (*((const UVertex**)elem2))->GetID();
    if(ID1>ID2) return  1;
    if(ID1<ID2) return -1;
    return 0;
}
static int SortFace(const void *elem1, const void *elem2)
{
    int ID1 = (*((const UFace**)elem1))->GetID();
    int ID2 = (*((const UFace**)elem2))->GetID();
    if(ID1>ID2) return  1;
    if(ID1<ID2) return -1;
    return 0;
}
static int SortEdge(const void *elem1, const void *elem2)
{
    int ID1 = (*((const UQuadEdge**)elem1))->GetID();
    int ID2 = (*((const UQuadEdge**)elem2))->GetID();
    if(ID1>ID2) return  1;
    if(ID1<ID2) return -1;
    return 0;
}
bool UManifold::AreVerticesSorted(void) const
{
    if(this==NULL     || error  !=U_OK) return true;
    if(vertices==NULL || NVertex<=0   ) return true; 

    for(int n=0; n<NVertex-1; n++)
    {
        if(vertices[n]->GetID()<vertices[n+1]->GetID()) continue;
        return false; 
    }
    return true;
}
bool UManifold::AreFacesSorted(void) const
{
    if(this==NULL  || error  !=U_OK) return true;
    if(faces==NULL || NFace  <=0   ) return true; 

    for(int n=0; n<NFace-1; n++)
    {
        if(faces[n]->GetID()<faces[n+1]->GetID()) continue;
        return false; 
    }
    return true;
}
bool UManifold::AreEdgesSorted(void) const
{
    if(this==NULL   || error  !=U_OK) return true;
    if(qedges==NULL || NQEdge <=0   ) return true; 

    for(int n=0; n<NQEdge-1; n++)
    {
        if(qedges[n]->GetID()<qedges[n+1]->GetID()) continue;
        return false; 
    }
    return true;
}

ErrorType UManifold::UpdateLastIDs(void)
{
    if(this==NULL     || error  !=U_OK) return U_ERROR;
    if(vertices==NULL || NVertex<=0)    return U_ERROR; 
    if(faces   ==NULL || NFace  <=0)    return U_ERROR; 
    if(qedges  ==NULL || NQEdge <=0)    return U_ERROR; 

    LastVertexID   = 0; for(int n=0; n<NVertex; n++) LastVertexID   = MAX(LastVertexID  , vertices[n]->GetID());
    LastFaceID     = 0; for(int n=0; n<NFace  ; n++) LastFaceID     = MAX(LastFaceID    , faces   [n]->GetID());
    LastQuadEdgeID = 0; for(int n=0; n<NQEdge ; n++) LastQuadEdgeID = MAX(LastQuadEdgeID, qedges  [n]->GetID());
    return U_OK;
}

ErrorType UManifold::RenumberVerticesFacesEdges(void)
{
    if(this==NULL     || error  !=U_OK) return U_ERROR;
    if(vertices==NULL || NVertex<=0)    return U_ERROR; 
    if(faces   ==NULL || NFace  <=0)    return U_ERROR; 
    if(qedges  ==NULL || NQEdge <=0)    return U_ERROR; 
    if(SortVertices()!=U_OK || SortFaces()!=U_OK || SortEdges()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RenumberVerticesFacesEdges(). Sorting vertices, faces or edges .\n");
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) vertices[n]->SetID(n); LastVertexID   = NVertex-1;
    for(int n=0; n<NFace  ; n++) faces   [n]->SetID(n); LastFaceID     = NFace  -1;
    for(int n=0; n<NQEdge ; n++) qedges  [n]->SetID(n); LastQuadEdgeID = NQEdge -1;

    return U_OK;
}

ErrorType UManifold::SortVertices(void)
{
    if(this==NULL     || error  !=U_OK) return U_ERROR;
    if(vertices==NULL || NVertex<=0)    return U_ERROR; 

    if(AreVerticesSorted()==true) return U_OK;

    qsort(vertices, NVertex, sizeof(vertices[0]), SortVert);
    for(int n=0; n<NVertex-1; n++)
    {
        if(vertices[n]->GetID()<vertices[n+1]->GetID()) continue;
        CI.AddToLog("ERROR: UManifold::SortVertices(). Invalid IDs: n=%d, (ID, INnext) = (%d, %d) .\n", n, vertices[n]->GetID(), vertices[n+1]->GetID());
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UManifold::SortFaces(void)
{
    if(this==NULL  || error!=U_OK) return U_ERROR;
    if(faces==NULL || NFace<=0)    return U_ERROR; 

    if(AreFacesSorted()==true) return U_OK;

    qsort(faces, NFace, sizeof(faces[0]), SortFace);
    for(int n=0; n<NFace-1; n++)
    {
        if(faces[n]->GetID()<faces[n+1]->GetID()) continue;
        CI.AddToLog("ERROR: UManifold::SortFaces(). Invalid IDs: n=%d, (ID, INnext) = (%d, %d) .\n", n, faces[n]->GetID(), faces[n+1]->GetID());
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UManifold::SortEdges(void)
{
    if(this ==NULL  || error !=U_OK) return U_ERROR;
    if(qedges==NULL || NQEdge<=0)    return U_ERROR; 

    if(AreEdgesSorted()==true) return U_OK;

    qsort(qedges, NQEdge, sizeof(qedges[0]), SortEdge);
    for(int n=0; n<NQEdge-1; n++)
    {
        if(qedges[n]->GetID()<qedges[n+1]->GetID()) continue;
        CI.AddToLog("ERROR: UManifold::SortEdges(). Invalid IDs: n=%d, (ID, INnext) = (%d, %d) .\n", n, qedges[n]->GetID(), qedges[n+1]->GetID());
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UManifold::RemoveQEdgeReferences(UQuadEdge* QE1, UQuadEdge* QE2, UQuadEdge* QE3)
{
    if(this ==NULL    || error !=U_OK)  return U_ERROR;
    if(qedges==NULL   || NQEdge <=0)    return U_ERROR; 
    if(vertices==NULL || NVertex<=0)    return U_ERROR; 
    if(faces==NULL    || NFace  <=0)    return U_ERROR; 

    if(QE1==NULL && QE2==NULL) return U_OK;

    UEdge* E1  = QE1 ? QE1->GetEdge() : NULL;
    UEdge* E1s =  E1 ? E1 ->GetSym()  : NULL;
    UEdge* E2  = QE2 ? QE2->GetEdge() : NULL;
    UEdge* E2s =  E2 ? E2 ->GetSym()  : NULL;
    UEdge* E3  = QE3 ? QE3->GetEdge() : NULL;
    UEdge* E3s =  E3 ? E3 ->GetSym()  : NULL;

    UVertex* VO1 = E1  ? E1 ->GetOrg() : NULL;
    UVertex* VD1 = E1s ? E1s->GetOrg() : NULL;
    UVertex* VO2 = E2  ? E2 ->GetOrg() : NULL;
    UVertex* VD2 = E2s ? E2s->GetOrg() : NULL;
    UVertex* VO3 = E3  ? E3 ->GetOrg() : NULL;
    UVertex* VD3 = E3s ? E3s->GetOrg() : NULL;

    UFace* FL1 = E1  ? E1 ->GetRot()->GetFace() : NULL;
    UFace* FR1 = E1s ? E1s->GetRot()->GetFace() : NULL;
    UFace* FL2 = E2  ? E2 ->GetRot()->GetFace() : NULL;
    UFace* FR2 = E2s ? E2s->GetRot()->GetFace() : NULL;
    UFace* FL3 = E3  ? E3 ->GetRot()->GetFace() : NULL;
    UFace* FR3 = E3s ? E3s->GetRot()->GetFace() : NULL;

    UEdge*   E[6] = {E1 , E1s, E2 , E2s, E3 , E3s};
    UVertex* V[6] = {VO1, VD1, VO2, VD2, VO3, VD3};
    UFace*   F[6] = {FL1, FR1, FL2, FR2, FL3, FR3};

    for(int k=0; k<6; k++)
    {
        if(V[k]==NULL) continue;
        bool VOK = false;
        UVertexEdgeIterator VEI(V[k]);
        for(UEdge* EE=VEI.GetStart(); EE; EE=VEI.GetNext())
        {
            if(EE!=E[0] && EE!=E[1] && EE!=E[2] && EE!=E[3] && EE!=E[4] && EE!=E[5])
            {
                V[k]->SetEdge(EE);
                VOK = true;
                break;
            }
        }
        if(VOK==false)
        {
            CI.AddToLog("ERROR: UManifold::RemoveQEdgeReferences(). Non-adjacent edge cannot be found for vertex %d \n", V[k]->GetID());
            return U_ERROR;
        }
    }

    for(int k=0; k<6; k++)
    {
        if(F[k]==NULL) continue;
        bool VOK = false;
        UFaceEdgeIterator FEI(F[k]);
        for(UEdge* EE=FEI.GetStart(); EE; EE=FEI.GetNext())
        {
            if(EE!=E[0] && EE!=E[1] && EE!=E[2] && EE!=E[3] && EE!=E[4] && EE!=E[5])
            {
                F[k]->SetEdge(EE);
                VOK = true;
                break;
            }
        }
        if(VOK==false)
        {
            CI.AddToLog("ERROR: UManifold::RemoveQEdgeReferences(). Non-adjacent edge cannot be found for face %d \n", F[k]->GetID());
            return U_ERROR;
        }
    }
    return U_OK;
}

int UManifold::FindFace(int ID) const
{
    if(ID<0 || ID>LastFaceID) return -1;
    if(NFace<=0)    return -1;
    if(faces==NULL) return -1;

/* Try some fast heuristics */
    int n = ID;
    if(n<NFace   &&        faces[n  ]->GetID()==ID) return n;
    if(n<NFace-1 &&        faces[n+1]->GetID()==ID) return n+1;
    if(n<NFace-2 &&        faces[n+2]->GetID()==ID) return n+2;
    if(n<NFace+1 && n>0 && faces[n-1]->GetID()==ID) return n-1;
    if(n<NFace+2 && n>1 && faces[n-2]->GetID()==ID) return n-2;
    if(LastFaceID>NFace+2)
    {
        n = MAX(0,MIN(NFace,(ID-LastFaceID+NFace)));
        if(n<NFace   &&        faces[n  ]->GetID()==ID) return n;
        if(n<NFace-1 &&        faces[n+1]->GetID()==ID) return n+1;
        if(n<NFace-2 &&        faces[n+2]->GetID()==ID) return n+2;
        if(n<NFace+1 && n>0 && faces[n-1]->GetID()==ID) return n-1;
        if(n<NFace+2 && n>1 && faces[n-2]->GetID()==ID) return n-2;
    }

/* Search in ordered table of IDs */
    int il = 0;
    int iu = NFace-1;
    while(iu-il > 1)
    {
        int im   = (iu+il) >> 1;
        int IDim = faces[im]->GetID();
        if(ID==IDim) return im;
        if(ID >IDim) il=im;
        else         iu=im;
    }
    if(faces[il]->GetID()==ID) return il;
    if(faces[iu]->GetID()==ID) return iu;

/****
    if(ID<NFace)
    {
        for(int n=ID; n>=0;    n--) if(faces[n]->GetID()==ID) return n;
        for(int n=ID; n<NFace; n++) if(faces[n]->GetID()==ID) return n;
    }
    else
    {
        for(int n=0; n<NFace; n++) if(faces[n]->GetID()==ID) return n;
    }
****/
    return -1;
}
int UManifold::FindVertex(int ID) const
{
    if(ID<0 || ID>LastVertexID) return -1;
    if(NVertex<=0)     return -1;
    if(vertices==NULL) return -1;

/* Try some fast heuristics */    
    int n = ID;
    if(n<NVertex   &&        vertices[n  ]->GetID()==ID) return n;
    if(n<NVertex-1 &&        vertices[n+1]->GetID()==ID) return n+1;
    if(n<NVertex-2 &&        vertices[n+2]->GetID()==ID) return n+2;
    if(n<NVertex+1 && n>0 && vertices[n-1]->GetID()==ID) return n-1;
    if(n<NVertex+2 && n>1 && vertices[n-2]->GetID()==ID) return n-2;
    if(LastVertexID>NVertex+2)
    {
        n = MAX(0,MIN(NVertex,(ID-LastVertexID+NVertex)));
        if(n<NVertex   &&        vertices[n  ]->GetID()==ID) return n;
        if(n<NVertex-1 &&        vertices[n+1]->GetID()==ID) return n+1;
        if(n<NVertex-2 &&        vertices[n+2]->GetID()==ID) return n+2;
        if(n<NVertex+1 && n>0 && vertices[n-1]->GetID()==ID) return n-1;
        if(n<NVertex+2 && n>1 && vertices[n-2]->GetID()==ID) return n-2;
    }

/* Search in ordered table of IDs */
    int il = 0;
    int iu = NVertex-1;
    while(iu-il > 1)
    {
        int im   = (iu+il) >> 1;
        int IDim = vertices[im]->GetID();
        if(ID==IDim) return im;
        if(ID >IDim) il=im;
        else         iu=im;
    }
    if(vertices[il]->GetID()==ID) return il;
    if(vertices[iu]->GetID()==ID) return iu;

/****
    if(ID<NVertex)
    {
        for(int n=ID; n>=0;      n--) if(vertices[n]->GetID()==ID) return n;
        for(int n=ID; n<NVertex; n++) if(vertices[n]->GetID()==ID) return n;
    }
    else
    {
        for(int n=0; n<NVertex; n++) if(vertices[n]->GetID()==ID) return n;
    }
****/
    return -1;
}

int UManifold::FindQuadEdge(int ID) const
{
    if(ID<0 || ID>LastQuadEdgeID) return -1;
    if(NQEdge<=0   ) return -1;
    if(qedges==NULL) return -1;

/* Try some fast heuristics */
    int n = ID;
    if(n<NQEdge   &&        qedges[n  ]->GetID()==ID) return n;
    if(n<NQEdge-1 &&        qedges[n+1]->GetID()==ID) return n+1;
    if(n<NQEdge-2 &&        qedges[n+2]->GetID()==ID) return n+2;
    if(n<NQEdge+1 && n>0 && qedges[n-1]->GetID()==ID) return n-1;
    if(n<NQEdge+2 && n>1 && qedges[n-2]->GetID()==ID) return n-2;
    if(LastQuadEdgeID>NQEdge+2)
    {
        n = MAX(0,MIN(NQEdge,(ID-LastQuadEdgeID+NQEdge)));
        if(n<NQEdge   &&        qedges[n  ]->GetID()==ID) return n;
        if(n<NQEdge-1 &&        qedges[n+1]->GetID()==ID) return n+1;
        if(n<NQEdge-2 &&        qedges[n+2]->GetID()==ID) return n+2;
        if(n<NQEdge+1 && n>0 && qedges[n-1]->GetID()==ID) return n-1;
        if(n<NQEdge+2 && n>1 && qedges[n-2]->GetID()==ID) return n-2;
    }

/* Search in ordered table of IDs */
    int il = 0;
    int iu = NQEdge-1;
    while(iu-il > 1)
    {
        int im   = (iu+il) >> 1;
        int IDim = qedges[im]->GetID();
        if(ID==IDim) return im;
        if(ID >IDim) il=im;
        else         iu=im;
    }
    if(qedges[il]->GetID()==ID) return il;
    if(qedges[iu]->GetID()==ID) return iu;

    return -1;
}
int UManifold::FindQuadEdge(int IDorg, int IDdest) const
{
    if(this==NULL || qedges==NULL || vertices==NULL) return -1;
    if(IDorg <0   || IDorg  > LastVertexID) return -1;
    if(IDdest<0   || IDdest > LastVertexID) return -1;
    if(NVertex<=0) return -1;
    if(NQEdge <=0) return -1;

    int indOrg = FindVertex(IDorg ); if(indOrg<0) return -1;
    int indDes = FindVertex(IDdest); if(indDes<0) return -1;
    int indQ   = -1;

    UVertexEdgeIterator VEI(vertices[indOrg]);
    bool LoopO = VEI.AreNeighboursClosedLoop();
    if(LoopO==true)
    {
        for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext())
        {
            indQ = FindQuadEdge(E); 
            if(indQ<0)  continue;
            if(qedges[indQ]->GetOrgID() ==IDorg  && qedges[indQ]->GetDestID()==IDdest) return indQ;
            if(qedges[indQ]->GetOrgID() ==IDdest && qedges[indQ]->GetDestID()==IDorg ) return indQ;
        }
    }
    indQ       = -1;
    VEI        = UVertexEdgeIterator(vertices[indDes]);
    bool LoopD = VEI.AreNeighboursClosedLoop();
    if(LoopD==true && indQ<0)
    {
        for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext())
        {
            indQ = FindQuadEdge(E); 
            if(indQ<0)  continue;
            if(qedges[indQ]->GetOrgID() ==IDorg &&  qedges[indQ]->GetDestID()==IDdest) return indQ;
            if(qedges[indQ]->GetOrgID() ==IDdest && qedges[indQ]->GetDestID()==IDorg ) return indQ;
        }
    }
    if(LoopO && LoopD) return -1;

/* Triangulation still incomplete, search all old edges*/
    for(int n=0; n<NQEdge; n++)
    {
        if(qedges[n]->GetOrgID() ==IDorg && 
           qedges[n]->GetDestID()==IDdest) return n;
    }
    return -1;
}
int UManifold::FindQuadEdge(UEdge* Edge) const
{
    if(this==NULL || qedges==NULL)       return -1;
    if(Edge==NULL          ) return -1;
    if(Edge->GetSym()==NULL) return -1;

    int IDQ = Edge->GetID()/4;

    int ind = FindQuadEdge(IDQ);
    if(ind>=0 && qedges[ind]->HasEdge(Edge)) return ind;
    return -1;
}

UVertex* UManifold::AddNewVertex()
{
    UVertex* V = new UVertex();
    if(V==NULL) return NULL;
    LastVertexID++;
    V->SetID(LastVertexID);
    if(AddVertex(V)!=U_OK)
    {
        delete V;
        return NULL;
    }
    return V;
}
UVertex* UManifold::AddNewVertex(UVector3 P)
{
    UVertex* V = new UVertex(P);
    if(V==NULL) return NULL;
    LastVertexID++;
    V->SetID(LastVertexID);
    if(AddVertex(V)!=U_OK)
    {
        delete V;
        return NULL;
    }
    return V;
}
UFace* UManifold::AddNewFace()
{
    UFace* F = new UFace();
    if(F==NULL) return NULL;
    LastFaceID++;
    F->SetID(LastFaceID);
    if(AddFace(F)!=U_OK)
    {
        delete F;
        return NULL;
    }
    return F;
}
UQuadEdge* UManifold::AddNewQuadEdge()
{
    UQuadEdge* QE = new UQuadEdge();
    if(QE==NULL) return NULL;
    LastQuadEdgeID++;
    QE->SetID(LastQuadEdgeID);
    if(AddQuadEdge(QE)!=U_OK)
    {
        delete QE;
        return NULL;
    }
    return QE;
}
ErrorType UManifold::AddVertex(UVertex* V, int* ind0, int* ind1, int* ind2)
{
    if(NVertex+1>NVertexAlloc)
    {
        int       newAlloc = 3*(NVertexAlloc+1)/2;
        UVertex** NewV     = new UVertex*[newAlloc];
        if(NewV==NULL)
        {
            CI.AddToLog("ERROR: UManifold::AddVertex(). Memory allocation. newAlloc =%d .\n", newAlloc);
            return U_ERROR;
        }
        for(int k=0;       k<NVertex;  k++) NewV[k] = vertices[k];
        for(int k=NVertex; k<newAlloc; k++) NewV[k] = NULL;
        delete[] vertices; vertices = NewV;
        NVertexAlloc = newAlloc;
    }

/* Keep ordering to allow binary serach */
    if(NVertex==0 || V->GetID()>vertices[NVertex-1]->GetID())  
    {
        vertices[NVertex] = V;
    }
    else 
    {
        int ID = V->GetID();
        int il = 0;
        int iu = NVertex-1;
        if(V->GetID()<vertices[0]->GetID()) 
        {
            iu=0;
        }
        else
        {
            while(iu-il > 1)
            {
                int im   = (iu+il) >> 1;
                int IDim = vertices[im]->GetID();
                if(ID >IDim) il=im;
                else         iu=im;
            }
        }
        for(int n=NVertex; n>iu; n--) vertices[n]=vertices[n-1];
        vertices[iu] = V; 
        if(ind0 && *ind0>=iu) (*ind0)++;
        if(ind1 && *ind1>=iu) (*ind1)++;
        if(ind2 && *ind2>=iu) (*ind2)++;
    }
    NVertex++;
    return U_OK;
}
ErrorType UManifold::AddFace(UFace* F, int* ind0, int* ind1, int* ind2)
{
    if(NFace+1>NFaceAlloc)
    {
        int     newAlloc = 3*(NFaceAlloc+1)/2;
        UFace** NewF     = new UFace*[newAlloc];
        if(NewF==NULL)
        {
            CI.AddToLog("ERROR: UManifold::AddFace(). Memory allocation. newAlloc =%d .\n", newAlloc);
            return U_ERROR;
        }
        for(int k=0;     k<NFace;    k++) NewF[k] = faces[k];
        for(int k=NFace; k<newAlloc; k++) NewF[k] = NULL;
        delete[] faces; faces = NewF;
        NFaceAlloc = newAlloc;
    }

/* Keep ordering to allow binary serach */
    if(NFace==0 || F->GetID()>faces[NFace-1]->GetID())  
    {
        faces[NFace] = F;
    }
    else
    {
        int ID = F->GetID();
        int il = 0;
        int iu = NFace-1;
        if(F->GetID()<faces[0]->GetID()) 
        {
            iu=0;
        }
        else
        {
            while(iu-il > 1)
            {
                int im   = (iu+il) >> 1;
                int IDim = faces[im]->GetID();
                if(ID >IDim) il=im;
                else         iu=im;
            }
        }
        for(int n=NFace; n>iu; n--) faces[n]=faces[n-1];
        faces[iu] = F; 
        if(ind0 && *ind0>=iu) (*ind0)++;
        if(ind1 && *ind1>=iu) (*ind1)++;
        if(ind2 && *ind2>=iu) (*ind2)++;
    }
    NFace++;
    return U_OK;
}
ErrorType UManifold::AddQuadEdge(UQuadEdge* QE)
{
    if(NQEdge+1>NQEdgeAlloc)
    {
        int         newAlloc = 3*(NQEdgeAlloc+1)/2;
        UQuadEdge** NewQE    = new UQuadEdge*[newAlloc];
        if(NewQE==NULL)
        {
            CI.AddToLog("ERROR: UManifold::AddQuadEdge(). Memory allocation. newAlloc =%d .\n", newAlloc);
            return U_ERROR;
        }
        for(int k=0;      k<NQEdge;   k++) NewQE[k] = qedges[k];
        for(int k=NQEdge; k<newAlloc; k++) NewQE[k] = NULL;
        delete[] qedges; qedges = NewQE;
        NQEdgeAlloc = newAlloc;
    }
/* Keep ordering to allow binary serach */
    if(NQEdge==0 || QE->GetID()>qedges[NQEdge-1]->GetID())  
    {
        qedges[NQEdge] = QE;
    }
    else
    {
        int ID = QE->GetID();
        int il = 0;
        int iu = NQEdge-1;
        if(QE->GetID()<qedges[0]->GetID()) 
        {
            iu=0;
        }
        else
        {
            while(iu-il > 1)
            {
                int im   = (iu+il) >> 1;
                int IDim = qedges[im]->GetID();
                if(ID >IDim) il=im;
                else         iu=im;
            }
        }
        for(int n=NQEdge; n>iu; n--) qedges[n]=qedges[n-1];
        qedges[iu] = QE; 
    }    
    NQEdge++;
    return U_OK;
}

ErrorType UManifold::ReAllocateMemory(void)
{
    if(vertices)
    {
        if(NVertex>NVertexAlloc)
        {
            CI.AddToLog("ERROR: UManifold::ReAllocateMemory(). Array overflow (NVertex=%d, NVertexAlloc=%d). \n", NVertex, NVertexAlloc);
            return U_ERROR;
        }
        if(NVertex<NVertexAlloc)
        {
            int       newAlloc = NVertex;
            UVertex** NewV     = new UVertex*[newAlloc];
            if(NewV==NULL)
            {
                CI.AddToLog("WARNING: UManifold::ReAllocateMemory(). Memory allocation. newAlloc =%d .\n", newAlloc);
                return U_ERROR;
            }
            for(int k=0; k<NVertex;  k++) NewV[k] = vertices[k];
            delete[] vertices; vertices = NewV;
            NVertexAlloc = NVertex;
        }
        if(NVertex>0)
        {
            LastVertexID    = vertices[0]->GetID();
            for(int n=1; n<NVertex; n++) LastVertexID = MAX(LastVertexID, vertices[n]->GetID());
        }
    }
    if(faces)
    {
        if(NFace>NFaceAlloc)
        {
            CI.AddToLog("ERROR: UManifold::ReAllocateMemory(). Array overflow (NFace=%d, NFaceAlloc=%d). \n", NFace, NFaceAlloc);
            return U_ERROR;
        }
        if(NFace<NFaceAlloc)
        {
            int     newAlloc = NFace;
            UFace** NewF     = new UFace*[newAlloc];
            if(NewF==NULL)
            {
                CI.AddToLog("WARNING: UManifold::ReAllocateMemory(). Memory allocation. newAlloc =%d .\n", newAlloc);
                return U_ERROR;
            }
            for(int k=0; k<NFace;  k++) NewF[k] = faces[k];
            delete[] faces; faces = NewF;
            NFaceAlloc = NFace;
        }
        if(NFace>0)
        {
            LastFaceID    = faces[0]->GetID();
            for(int n=1; n<NFace; n++) LastFaceID = MAX(LastFaceID, (faces[n]->GetID()));
        }
    }
    if(qedges)
    {
        if(NQEdge>NQEdgeAlloc)
        {
            CI.AddToLog("ERROR: UManifold::ReAllocateMemory(). Array overflow (NQEdge=%d, NQEdgeAlloc=%d). \n", NQEdge, NQEdgeAlloc);
            return U_ERROR;
        }
        if(NQEdge<NQEdgeAlloc)
        {
            int         newAlloc = NQEdge;
            UQuadEdge** NewQE    = new UQuadEdge*[newAlloc];
            if(NewQE==NULL)
            {
                CI.AddToLog("WARNING: UManifold::ReAllocateMemory(). Memory allocation. newAlloc =%d .\n", newAlloc);
                return U_ERROR;
            }
            for(int k=0; k<NQEdge; k++) NewQE[k] = qedges[k];
            delete[] qedges; qedges = NewQE;
            NQEdgeAlloc = NQEdge;
        }
        if(NQEdge>0)
        {
            LastQuadEdgeID  = qedges[0]->GetID();
            for(int n=1; n<NQEdge; n++) LastQuadEdgeID = MAX(LastQuadEdgeID, (qedges[n]->GetID()));
        }
    }
    return U_OK;
}
ErrorType UManifold::MorfVertices(const double* VertexFunc)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MorfVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MorfVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexFunc==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MorfVertices(). Invalid NULL argument.\n");
        return U_ERROR;
    }
    UVector3* NewP = new UVector3[NVertex];
    if(NewP==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MorfVertices(). Memory allocation, NVertex = %d  .\n", NVertex);
        return U_ERROR;
    }

    for(int i=0; i<NVertex; i++)
    {
        UVector3 Sup = *(vertices[i]);
        UVector3 Ori = GetVertexNormal(i);
        NewP[i]      = Sup + Ori * VertexFunc[i];
    }
    for(int i=0; i<NVertex; i++) *(vertices[i]) = NewP[i];
    delete[] NewP;

    return U_OK;
}

USurface* UManifold::GetMorfedSurface(const double* VertexFunc) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMorfedSurface(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetMorfedSurface(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertexFunc==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetMorfedSurface(). Invalid NULL argument.\n");
        return NULL;
    }
    UManifold M(*this);
    if(M.MorfVertices(VertexFunc)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMorfedSurface(). Morfing copy of *this.\n");
        return NULL;
    }
    return M.GetSurface("Warp",false);
}
int* UManifold::GetNVertexCrossings(const USurface& S) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(&S==NULL || S.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Erroneous or NULL argument. \n");
        return NULL;
    }

    int* NCross = new int[NVertex];
    if(NCross==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Memory allocation, NVertex=%d \n", NVertex);
        return NULL;
    }
    for(int i=0; i<NVertex; i++) NCross[i] = 0;

    int MAXERROR = 0;
    for(int i=0; i<NVertex; i++)
    {
        UVector3 Sup = *(vertices[i]);
        UVector3 Ori = GetVertexNormal(i);
        if(Ori==UVector3())
        {
            if(MAXERROR<50)
                CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Getting normal from vertex %d .\n", i);
            MAXERROR++;
            continue;
        }
        Ori.Normalize();

        UPointList* PL = S.GetLineInterSection(Sup, Ori);
        if(PL==NULL || PL->GetError()!=U_OK)
        {
            delete PL;
            if(MAXERROR<50)
                CI.AddToLog("ERROR: UManifold::GetNVertexCrossings(). Getting intersection at triangle %d .\n", i);
            MAXERROR++;
            continue;
        }
        if(PL->GetNpoints()<=0)        
        {
            delete PL;
            continue;
        }
        NCross[i] = PL->GetNpoints();
        delete PL;
    }
    return NCross;
}
double* UManifold::GetVertexProjections(const USurface& S, int** NCross) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(&S==NULL || S.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Erroneous or NULL argument. \n");
        return NULL;
    }

    double* Dist = new double[NVertex];
    if(Dist==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Memory allocation, NVertex=%d \n", NVertex);
        return NULL;
    }
    if(NCross)
    {
        *NCross = new int[NVertex];
        if(*NCross==NULL)
        {
            delete[] Dist;
            CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Memory allocation for number of crossings, NVertex=%d \n", NVertex);
            return NULL;
        }
        for(int i=0; i<NVertex; i++) (*NCross)[i] = 0;
    }
    
    for(int i=0; i<NVertex; i++) Dist[i] = 0.;

    int MAXERROR = 0;
    for(int i=0; i<NVertex; i++)
    {
        UVector3 Sup = *(vertices[i]);
        UVector3 Ori = GetVertexNormal(i);
        if(Ori==UVector3())
        {
            if(MAXERROR<50)
                CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Getting normal vector from vertex %d  .\n", i);
            MAXERROR++;
            continue;
        }
        Ori.Normalize();

        UPointList* PL = S.GetLineInterSection(Sup, Ori);
        if(PL==NULL || PL->GetError()!=U_OK)
        {
            delete PL;
            if(MAXERROR<50)
                CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Getting intersection at triangle %d .\n", i);
            MAXERROR++;
            continue;
        }
        if(PL->GetNpoints()<=0)
        {
            delete PL;
            continue;
        }
        double Proj  = (PL->GetPoint(0)-Sup)&Ori;
        for(int n=1; n<PL->GetNpoints(); n++)
        {
            double Test = (PL->GetPoint(n)-Sup)&Ori;
            if(fabs(Test)>fabs(Proj)) continue;
            Proj = Test;
        }
        Dist[i] = Proj;
        if(NCross) (*NCross)[i] = PL->GetNpoints();
        delete PL;
    }
    return Dist;
}
double* UManifold::GetVertexProjections(const UManifold& TSphere, const UManifold& M, const UManifold& MSphere, int** NCross) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(&TSphere==NULL || TSphere.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Erroneous or NULL argument. \n");
        return NULL;
    }
    if(NVertex!=TSphere.NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). NVertex (%d) not consistent with spherical projection (%d). \n", NVertex, TSphere.NVertex);
        return NULL;
    }
    if(&M==NULL || M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Target manifold NULL or erroneous. \n");
        return NULL;
    }
    if(M.IsTriangulation()==false)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Target manifold is not triangulation. \n");
        return NULL;
    }
    if(&MSphere==NULL || MSphere.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Spherical projection of target is NULL or erroneous. \n");
        return NULL;
    }
    if(M.NVertex!=MSphere.NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). M.NVertex (%d) not consistent with spherical projection (%d). \n", M.NVertex, MSphere.NVertex);
        return NULL;
    }
    double*     Dist = new double[NVertex];
    if(Dist==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Memory allocation, NVertex=%d \n", NVertex);
        return NULL;
    }
    if(NCross)
    {
        *NCross = new int[NVertex];
        if(*NCross==NULL)
        {
            delete[] Dist;
            CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Memory allocation for number of crossings, NVertex=%d \n", NVertex);
            return NULL;
        }
        for(int i=0; i<NVertex; i++) (*NCross)[i] = 0;
    }
    
    for(int i=0; i<NVertex; i++) Dist[i] = 0.;

    int MAXERROR = 0;
    for(int i=0; i<NVertex; i++)
    {
        UVector3 Sup = *(vertices[i]);
        UVector3 Ori = GetVertexNormal(i);
        if(Ori==UVector3())
        {
            if(MAXERROR<50)
                CI.AddToLog("ERROR: UManifold::GetVertexProjections(). Getting normal vector from vertex %d  .\n", i);
            MAXERROR++;
            continue;
        }
        Ori.Normalize();

        UVector3 Axis = Ori ^ UVector3(0.,0.,1);         // Tested order
        double   Omeg = Angle(UVector3(0.,0.,1.), Ori);
        UEuler   XFM;
        if(Axis!=UVector3()) XFM = UEuler(Axis, Omeg);
        XFM.SetShift(XFM.xfm(-Sup));

        double   SDist = -1;
        int      NCR   =  0;
        for(int j=0; j<M.GetNFace(); j++)
        {
            const UFace* F  = M.faces[j];
            UVector3     W0 = XFM.xfm(*F->GetEdge()->GetOrg()                        );
            UVector3     W1 = XFM.xfm(*F->GetEdge()->GetLNext()->GetOrg()            );
            UVector3     W2 = XFM.xfm(*F->GetEdge()->GetLNext()->GetLNext()->GetOrg());

            UVector2     V0 = W0.Pz();
            UVector2     V1 = W1.Pz();
            UVector2     V2 = W2.Pz();
        
            if(IsInTriangle(UVector2(), V0, V1, V2)==false) continue;

            UVector3 SphereThis = TSphere.GetPointFromID(vertices[i]->GetID());
            UVector3 SphereM    = MSphere.GetFaceCenterFromID(F->GetID());
            double   Test       = (SphereThis-SphereM).GetNorm();
            if(SDist<0. || Test <SDist)
            {
                double Det0 = GetDeterminant(V1, V2);
                double Det1 = GetDeterminant(V2, V0);
                double Det2 = GetDeterminant(V0, V1);
                double Det  = GetDeterminant(V0, V1, V2);

                if(Det==0.)
                {
                    CI.AddToLog("WARNING: UManifold::GetVertexProjections(). Triangle %d degenerated .\n", j);
                    continue;
                }
                SDist      = Test;
                UVector3 P = (Det0/Det) * W0 + (Det1/Det) * W1 + (Det2/Det) * W2;
                Dist[i]    = P.Getz();
////
                double TTT = (Sup + Ori*Dist[i] - XFM.xfmInv(P)).GetNorm();
                double ik  = 10;
/////    
            }
            NCR++;
        }
        if(NCross) (*NCross)[i] = NCR;
    }
    return Dist;
}

ErrorType UManifold::CompleteTriangulationScratch(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::CompleteTriangulationScratch(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::CompleteTriangulationScratch(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    UVector3*  Ptri  = new UVector3[LastVertexID+1];
    UManifold* Tria  = new UManifold();
    if(Ptri==NULL || Tria==NULL || Tria->GetError()!=U_OK)
    {
        delete[] Ptri;
        delete   Tria;
        CI.AddToLog("ERROR: UManifold::CompleteTriangulationScratch(). Memory allocation, LastVertexID=%d  . \n", LastVertexID);
        return U_ERROR;
    }

    for(int n=0; n<NVertex; n++) Ptri[vertices[n]->GetID()] = *(vertices[n]);
    for(int n=0; n<NFace; n++)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);
        int  NNeig = FEI.GetNNeighbour();
        if(NNeig<3 || NNeig>=MAXEIGHBOR)
        {
            delete[] Ptri;
            delete   Tria;
            CI.AddToLog("ERROR: UManifold::CompleteTriangulationScratch(). Invalid face. ID = %d NNeig = %d .\n", F->GetID(), NNeig);
            return U_ERROR;
        }
        UEdge*   E0 = F ->GetEdge();
        UEdge*   E1 = E0->GetLNext();

        for(int k=0; k<NNeig-2; k++)
        {
            UEdge*   E2 = E1->GetLNext();

            UVertex* V0 = E0->GetOrg();
            UVertex* V1 = E1->GetOrg();
            UVertex* V2 = E2->GetOrg();

            if(Tria->AddTriangle(V0->GetID(), V1->GetID(), V2->GetID(), Ptri)!=U_OK)
            {
                delete[] Ptri;
                delete   Tria;
                CI.AddToLog("ERROR: UManifold::CompleteTriangulationScratch(). Adding triangle.\n");
                return U_ERROR;
            }
            E1 = E2;
        }
    }
    delete[] Ptri;
    *this = *Tria;
    delete Tria;
    return U_OK;
}
ErrorType UManifold::CompleteTriangulation(bool AddCenters)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::CompleteTriangulation(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::CompleteTriangulation(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    int NFaceOld  = NFace;
    for(int n=0; n<NFaceOld; n++)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);
        int  NNeig = FEI.GetNNeighbour();
        if(NNeig<3 || NNeig>=MAXEIGHBOR)
        {
            CI.AddToLog("ERROR: UManifold::CompleteTriangulation(). Invalid face. ID = %d NNeig = %d .\n", F->GetID(), NNeig);
            return U_ERROR;
        }
        if(NNeig==3) continue;

        if(AddCenters)
        {
            UVertex* Vnew = AddNewVertex(F->GetCenter());

            for(int k=0; k<NNeig; k++)
            {
                UQuadEdge* Qtest = AddNewQuadEdge();
                UFace*     Ftest = AddNewFace();
                if(Vnew==NULL || Qtest==NULL || Ftest==NULL)
                {
                    CI.AddToLog("ERROR: UManifold::CompleteTriangulation(). Creating new vertex, edge or face, n=%d, k=%d.\n", n, k);
                    return U_ERROR;
                }
            }
            UQuadEdge** Qnew = qedges+NQEdge-NNeig;
            UFace**     Fnew = faces +NFace -NNeig;

            Vnew->SetEdge(Qnew[0]->GetEdge());

            UEdge*      E0   = F ->GetEdge();
            for(int k=0; k<NNeig; k++)
            {
                int        km     = (NNeig+k-1)%NNeig;
                int        kp     = (NNeig+k+1)%NNeig;

                Fnew[k]->SetEdge(E0);

                Qnew[k]->GetEdge()->SetOrg(Vnew);
                Qnew[k]->GetEdge()->SetDest(E0->GetOrg());
            
                Qnew[k]->GetEdge()->SetLeftFace (Fnew[k ]);
                Qnew[k]->GetEdge()->SetRightFace(Fnew[km]);
            
                UEdge* Edum1 = Qnew[kp]->GetEdge();
                UEdge* Edum2 = E0->GetONext() ;
                UEdge* Edum3 = Qnew[km]->GetEdge()->GetInvRot();
                UEdge* Edum4 = E0->GetInvRot();

                Qnew[k]->GetEdge()             ->SetONext(Edum1);
                Qnew[k]->GetEdge()->GetSym()   ->SetONext(Edum2);
                Qnew[k]->GetEdge()->GetRot()   ->SetONext(Edum3);
                Qnew[k]->GetEdge()->GetInvRot()->SetONext(Edum4);

                UEdge* Enext = E0->GetLNext();
                E0->SetLeftFace(Fnew[k]);
                E0->             SetONext(Qnew[k ]->GetEdge()->GetSym());
                E0->GetInvRot()->SetONext(Qnew[kp]->GetEdge()->GetRot());

                E0=Enext;
            }
        }
        else
        {
            int NNewEdge = NNeig-3;
            int NNewFace = NNeig-2;
            for(int k=0; k<NNewFace; k++)
            {
                UQuadEdge* Qtest = k ? AddNewQuadEdge() : NULL;
                UFace*     Ftest =     AddNewFace();
                if((Qtest==NULL &&k) || Ftest==NULL)
                {
                    CI.AddToLog("ERROR: UManifold::CompleteTriangulation(). Creating new edge or face, n=%d, k=%d.\n", n, k);
                    return U_ERROR;
                }
            }
            UQuadEdge** Qnew  = qedges+NQEdge-NNewEdge;
            UFace**     Fnew  = faces +NFace -NNewFace;
            UEdge*      E0    = F ->GetEdge();
            UEdge*      E1    = E0->GetLNext();
            UEdge*      E2    = E1->GetLNext();
            UVertex*    Vold  = E0->GetOrg();

            E0  ->SetONext(Qnew[0]->GetEdge());
            E0  ->SetLeftFace(Fnew[0]);
            for(int k=0; k<NNewFace; k++)
            {
                Fnew[k]->SetEdge(E1);
                if(k<NNewEdge) 
                {
                    Qnew[k]->GetEdge()->SetOrg (Vold);
                    Qnew[k]->GetEdge()->SetDest(E1->GetDest());
            
                    Qnew[k]->GetEdge()->SetLeftFace (Fnew[k+1]);
                    Qnew[k]->GetEdge()->SetRightFace(Fnew[k  ]);
            
                    UEdge* Edum1 = k==NNewEdge-1 ? E2->GetLNext()->GetSym()    : Qnew[k+1]->GetEdge();
                    UEdge* Edum2 = E1->GetSym();
                    UEdge* Edum3 = k             ? Qnew[k-1]->GetEdgeInvRot()  : E0->GetInvRot();
                    UEdge* Edum4 = E2->GetInvRot();

                    Qnew[k]->GetEdge()             ->SetONext(Edum1);
                    Qnew[k]->GetEdge()->GetSym()   ->SetONext(Edum2);
                    Qnew[k]->GetEdge()->GetRot()   ->SetONext(Edum3);
                    Qnew[k]->GetEdge()->GetInvRot()->SetONext(Edum4);
                }
                E1  ->             SetONext(k             ? Qnew[k-1]->GetEdgeSym()        : E0->GetSym());
                E1  ->GetInvRot()->SetONext(k==NNewFace-1 ? E2->GetInvRot()                : Qnew[k]->GetEdgeRot());
             
                E0=E1;
                E1=E2;
                E2=E2->GetLNext();
            }
            Vold->SetEdge(E1->GetSym());
            E1  ->SetLeftFace(Fnew[NNewFace-1]);
            E1  ->GetInvRot()->SetONext(Qnew[NNewEdge-1]->GetEdgeInvRot());
        }
        delete faces[n]; faces[n] = NULL;
    }
    int NTri = 0;
    for(int n=0; n<NFace; n++) 
    {
        if(faces[n]==NULL) continue;
        faces[NTri++] = faces[n];
    }
    NFace = NTri;

    return U_OK;
}
ErrorType UManifold::RemoveEdgeMergeFaces(int QEID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<3 || vertices==NULL) ||
        (NFace  <3 || faces   ==NULL) ||
        (NQEdge <3 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    int inde = FindQuadEdge(QEID);
    if(inde<0)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). QuadEdge not found: ID = %d \n", QEID);
        return U_ERROR;
    }
    return RemoveEdgeMergeFaces(qedges[inde]->GetEdge());
}
ErrorType UManifold::RemoveEdgeMergeVertices(int QEID)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<3 || vertices==NULL) ||
        (NFace  <3 || faces   ==NULL) ||
        (NQEdge <3 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    int inde = FindQuadEdge(QEID);
    if(inde<0)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). QuadEdge not found: ID = %d \n", QEID);
        return U_ERROR;
    }
    return RemoveEdgeMergeVertices(qedges[inde]->GetEdge());
}

ErrorType UManifold::RemoveEdgeMergeFaces(UEdge* Edge)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<3 || vertices==NULL) ||
        (NFace  <3 || faces   ==NULL) ||
        (NQEdge <3 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    UFace* FL = Edge ? Edge->GetLeftFace()  : NULL;
    UFace* FR = Edge ? Edge->GetRightFace() : NULL;
    int indfL = FL   ? FindFace(FL->GetID()): -1;
    if(indfL<0 || FR==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Left face not found. \n");
        return U_ERROR;
    }
    int inde = Edge ? FindQuadEdge(Edge) :-1;
    if(inde<0 || Edge->GetOrg()==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeFaces(). Edge not found, or vertex orgin is NULL. \n");
        return U_ERROR;
    }
    
    UFaceEdgeIterator FEI(FL);
    for(UEdge* E=FEI.GetStart(); E; E=FEI.GetNext()) E->SetLeftFace(FR); 

    Edge->GetOrg() ->SetEdge(Edge->          GetONext());
    Edge->GetDest()->SetEdge(Edge->GetSym()->GetONext());

    UEdge* Edum1 = Edge->            GetONext();
    UEdge* Edum2 = Edge->GetSym()  ->GetONext();
    UEdge* Edum3 = Edge->GetSym()  ->GetOPrev()->GetInvRot();
    UEdge* Edum4 = Edge->            GetOPrev()->GetInvRot();

    Edge->             GetOPrev()->SetONext(Edum1);
    Edge->GetSym()   ->GetOPrev()->SetONext(Edum2);
    Edge->GetRot()   ->GetOPrev()->SetONext(Edum3);
    Edge->GetInvRot()->GetOPrev()->SetONext(Edum4);

    delete faces[indfL]; for(int n=indfL; n<NFace -1; n++) faces[n]  = faces [n+1]; NFace--;
    delete qedges[inde]; for(int n=inde ; n<NQEdge-1; n++) qedges[n] = qedges[n+1]; NQEdge--;

    return U_OK;
}
ErrorType UManifold::RemoveEdgeMergeVertices(UEdge* Edge)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<3 || vertices==NULL) ||
        (NFace  <3 || faces   ==NULL) ||
        (NQEdge <3 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    UFace* FL = Edge ? Edge->GetLeftFace()  : NULL;
    UFace* FR = Edge ? Edge->GetRightFace() : NULL;
    int indfL = FL   ? FindFace(FL->GetID()): -1;
    int indfR = FR   ? FindFace(FR->GetID()): -1;
    if(indfL<0 || indfR<0)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Left or right face not found. \n");
        return U_ERROR;
    }
    int  inde = Edge                   ? FindQuadEdge(Edge)                      : -1;
    int  indo = Edge && Edge->GetOrg() ? FindVertex  (Edge->GetOrg()->GetID())   : -1;
    if(inde<0 || indo<0)
    {
        CI.AddToLog("ERROR: UManifold::RemoveEdgeMergeVertices(). Edge not found, or vertex orgin not found. \n");
        return U_ERROR;
    }
    UVertexEdgeIterator VEI(Edge->GetOrg());
    for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext()) E->SetOrg(Edge->GetDest()); 

// Remove reference to edge that will be removed
    FL  ->SetEdge(Edge->          GetLNext());
    FR  ->SetEdge(Edge->GetSym()->GetLNext());
    Edge->GetDest()->SetEdge(Edge->GetSym()->GetONext());

    UEdge* Edum1 = Edge->GetSym()  ->GetONext()             ;
    UEdge* Edum2 = Edge->            GetONext()             ;
    UEdge* Edum3 = Edge->GetSym()  ->GetOPrev()->GetInvRot();
    UEdge* Edum4 = Edge->            GetOPrev()->GetInvRot();

    Edge->          GetOPrev()          ->SetONext(Edum1);
    Edge->GetSym()->GetOPrev()          ->SetONext(Edum2);
    Edge->          GetONext()->GetRot()->SetONext(Edum3);
    Edge->GetSym()->GetONext()->GetRot()->SetONext(Edum4);

    delete vertices[indo]; for(int n=indo;  n<NVertex-1; n++) vertices[n] = vertices[n+1];  NVertex--;
    delete qedges[inde];   for(int n=inde ; n<NQEdge-1;  n++) qedges[n]   = qedges[n+1];    NQEdge--;

    UFaceEdgeIterator FEIL(FL);
    if(FEIL.GetNNeighbour()==2)   RemoveEdgeMergeFaces(FEIL.GetStart());

    UFaceEdgeIterator FEIR(FR);
    if(FEIR.GetNNeighbour()==2)   RemoveEdgeMergeFaces(FEIR.GetStart());

    return U_OK;
}
ErrorType UManifold::SwapEdgeID(int QEID, bool MaximizeAngle)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<3 || vertices==NULL) ||
        (NFace  <3 || faces   ==NULL) ||
        (NQEdge <3 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    int inde = FindQuadEdge(QEID);
    if(inde<0)
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). QuadEdge not found: QEID = %d. \n", QEID);
        return U_ERROR;
    }
    UEdge* Edge = qedges[inde]->GetEdge(); 

    UFace* FL = Edge ? Edge->GetLeftFace()  : NULL;
    UFace* FR = Edge ? Edge->GetRightFace() : NULL;
    if(FL==NULL || FR==NULL)
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). Left or right face not found. \n");
        return U_ERROR;
    }
    
    UFaceEdgeIterator FEIL(FL); int NL = FEIL.GetNNeighbour();
    UFaceEdgeIterator FEIR(FR); int NR = FEIR.GetNNeighbour();
    if(NL!=3||NR!=3)
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). Left or right face are not triangles: NL=%d, NR=%d. \n", NL, NR);
        return U_ERROR;
    }

    double   MinAng = MaximizeAngle ? MIN(FL->GetMinAngle(), FR->GetMinAngle()) : 0.;

    UVertex* V1 = Edge->GetOrg();
    UVertex* V2 = Edge->GetDest();
    UVertex* V3 = Edge->GetOPrev()->GetDest();
    UVertex* V4 = Edge->GetONext()->GetDest();

    UVertexEdgeIterator VEI1(V1);
    UVertexEdgeIterator VEI2(V2);
    if(VEI1.GetNNeighbour()<4 || VEI2.GetNNeighbour()<4)
    {
        CI.AddToLog("ERROR: UManifold::SwapEdgeID(). Do not swap to avoid degeneration. \n");
        return U_ERROR;
    }

    Edge->SetOrg (V3);
    Edge->SetDest(V4);

    Edge->GetOPrev()->SetLeftFace(FL);
    Edge->GetLNext()->SetLeftFace(FR);

// Remove Edge
    UEdge* Edum1 = Edge->            GetONext();
    UEdge* Edum2 = Edge->GetSym()  ->GetONext();
    UEdge* Edum3 = Edge->GetSym()  ->GetOPrev()->GetInvRot();
    UEdge* Edum4 = Edge->            GetOPrev()->GetInvRot();

    Edge->             GetOPrev()->SetONext(Edum1);
    Edge->GetSym()   ->GetOPrev()->SetONext(Edum2);
    Edge->GetRot()   ->GetOPrev()->SetONext(Edum3);
    Edge->GetInvRot()->GetOPrev()->SetONext(Edum4);

// Connect Edge
    Edum1 = Edge->GetOPrev()->GetLNext() ;
    Edum2 = Edge->GetOPrev()->GetLPrev() ;
    Edum3 = Edge->GetOPrev()->GetLPrev()->GetLPrev()->GetInvRot();
    Edum4 = Edge->GetOPrev()->GetInvRot();

    V1   ->SetEdge(Edum2->GetSym());
    V2   ->SetEdge(Edum1->GetSym());

    UEdge* Edam1 = Edge->GetOPrev()->GetSym();
    UEdge* Edam2 = Edge->GetOPrev()->GetLPrev()->GetLPrev()->GetSym();
    UEdge* Edam3 = Edge->GetOPrev()->GetLNext()->GetInvRot();
    UEdge* Edam4 = Edge->GetOPrev()->GetLPrev()->GetInvRot();

    Edum1->SetONext(Edge             );
    Edum2->SetONext(Edge->GetSym()   );
    Edum3->SetONext(Edge->GetRot()   );
    Edum4->SetONext(Edge->GetInvRot());

    Edge->             SetONext(Edam1);
    Edge->GetSym()   ->SetONext(Edam2);
    Edge->GetRot()   ->SetONext(Edam3);
    Edge->GetInvRot()->SetONext(Edam4);

    if(MaximizeAngle)
    {
        FL = Edge->GetLeftFace() ;
        FR = Edge->GetRightFace();
        double   MinAngSwa = MIN(FL->GetMinAngle(), FR->GetMinAngle());
        if(MinAngSwa>=MinAng) return U_OK;
        return SwapEdgeID(QEID, false); // Swap back
    }
    return U_OK;
}

bool UManifold::IsTriangulation(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::IsTriangulation(). Object NULL or erroneous. \n");
        return false;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::IsTriangulation(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return false;
    }
    for(int n=0; n<NFace; n++)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);
        int  NNeig = FEI.GetNNeighbour();
        if(NNeig!=3) return false;
    }
    return true;
}

ErrorType UManifold::RemoveFirstHandle(int MaxOrder, int** HandleVertexIDs, int* NBound, int* NnewVertex)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(MaxOrder<=0)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Parameter out of range (MaxOrder=%d). \n", MaxOrder);
        return U_ERROR;
    }
    if(HandleVertexIDs==NULL || NBound==NULL || NnewVertex==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    if(IsTriangulation()==false)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Manifold contains non-trianglar faces. \n");
        return U_ERROR;
    }
    if(GetNComponents()!=1)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Manifold consists of more than one component. \n");
        return U_ERROR;
    }
    *NBound          = 0;
    *NnewVertex      = 0;
    *HandleVertexIDs = NULL;
    if(GetEulerChar()==2) return U_OK;

    const int LABELINIT  =   -1;
    const int FICTITIOUS =   -3;
    UFaceInt** facesDist = new UFaceInt*[NFace]; 
    int*       IndexF    = new int[LastFaceID+1];
    if(facesDist==NULL || IndexF==NULL)
    {
        delete[] facesDist; delete[] IndexF;
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Memory allocation, NFace = %d. \n", NFace);
        return U_ERROR;
    }
    for(int i=0; i< NFace     ; i++) facesDist[i]  = new UFaceInt(*(faces[i]), LABELINIT);
    for(int i=0; i<=LastFaceID; i++) IndexF[i]     = -1;
    for(int i=0; i< NFace     ; i++) IndexF[faces[i]->GetID()] = i;

    for(int i=0; i<NQEdge; i++)
    {
        int LeftID  = qedges[i]->GetEdge()->GetLeftFace() ->GetID();
        int RightID = qedges[i]->GetEdge()->GetRightFace()->GetID();
        qedges[i]->GetEdge()->SetLeftFace (facesDist[IndexF[LeftID ]]);
        qedges[i]->GetEdge()->SetRightFace(facesDist[IndexF[RightID]]);
    }

    int* VertexBoundIDs  = NULL; 
    bool CircuitDetected = false;
    for(int n=0; n<NFace && CircuitDetected==false; n++)
    {
        for(int i=0; i< NFace; i++) facesDist[i]->IData = LABELINIT;

        int Dist      = 0;
        int MaxBuffer = 20*MaxOrder;
        UFIFOQueuePointer fifoQueue(MaxBuffer);

        facesDist[n]->IData = Dist++;
        fifoQueue.Enqueue(facesDist[n]);

        UFaceInt* FIfict = new UFaceInt(FICTITIOUS);
        fifoQueue.Enqueue(FIfict);

        UManifoldHandle MH(facesDist[n]);
        while(CircuitDetected==false)
        {
            UFaceInt* FIndex = (UFaceInt*)fifoQueue.Dequeue();

            if(FIndex->IData==FICTITIOUS)
            {
                if(fifoQueue.GetSize()==0) break;

                fifoQueue.Enqueue(FIfict);
                Dist++;
                if(Dist>MaxOrder) break;
                FIndex = (UFaceInt*)fifoQueue.Dequeue();
            }
            UFaceEdgeIterator FEI(FIndex);
            for(UEdge* E=FEI.GetStart(); E; E=FEI.GetNext())
            {
                UFaceInt* FaceRight = (UFaceInt*)E->GetRightFace();
                if(FaceRight->IData>Dist)
                {
                    FaceRight->IData = Dist;
                }
                else if(FaceRight->IData==LABELINIT)
                {
                    FaceRight->IData = Dist;
                    fifoQueue.Enqueue(FaceRight);
                    int*   LoopID = NULL;
                    int    NPloop = 0;
                    UEdge* Esep   = MH.AddTriangle(FIndex, FaceRight, &LoopID, &NPloop);
                    if(Esep)
                    {
                        CircuitDetected  = true;
                        *NBound          = 0;
                        *HandleVertexIDs = NULL;
                        if(MH.ComputeNonSeparatingContour(Esep, &VertexBoundIDs, NBound)!=U_OK || *NBound<=0)
                        {
                            delete[] VertexBoundIDs; VertexBoundIDs = NULL;
                            *NBound  = -1;
                        }
                        else
                        {
                            int* pArrayID[2] = {VertexBoundIDs, LoopID};
                            int  NPCont[2]   = {*NBound       , NPloop};
                            SkipShortCuts(pArrayID, NPCont, 2);
                            *NBound = NPCont[0]; NPloop = NPCont[1];

                            if(NPloop>0 && NPloop<*NBound)
                            {
                                CI.AddToLog("Note: UManifold::RemoveFirstHandle(). Use side loop with %d i.s.o. %d nodes. \n", NPloop, *NBound);
                                *NBound=NPloop;
                                for(int k=0; k<NPloop; k++) VertexBoundIDs[k] = LoopID[k];
                            }
                        }
                        delete[] LoopID;
                        //UPointList* pDr = GetDrawing(&LoopID, &NPloop, 1);
                        //pDr->WriteVTK("C:/Data/Hippocampus/VTK_Files_for_RegionalHC_Jaccard/_Test/LoopID.vtk", ULinTran(), 0.01);
                        //delete pDr;
                        break;
                    }
                    delete[] LoopID;
                }
            }
        }
        delete FIfict;
    }
    for(int i=0; i<NQEdge; i++)
    {
        int LeftID  = qedges[i]->GetEdge()->GetLeftFace() ->GetID();
        int RightID = qedges[i]->GetEdge()->GetRightFace()->GetID();
        qedges[i]->GetEdge()->SetLeftFace (faces[IndexF[LeftID ]]);
        qedges[i]->GetEdge()->SetRightFace(faces[IndexF[RightID]]);
    }
    delete[] facesDist; delete[] IndexF;

    if(*NBound==0) return U_OK; // MaxOrder too small to detect new handle
    if(*NBound<0)
    {
        delete[] VertexBoundIDs;
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Detecting boundary. \n");
        return U_ERROR;
    }
    UFace*     FaceLR[2];
    UManifold* MCCut = GetContourCut(VertexBoundIDs, *NBound, FaceLR, false);
    if(MCCut==NULL || MCCut->GetError()!=U_OK)
    {
        delete MCCut;
        delete[] VertexBoundIDs; *NBound = 0;
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Cutting along non-separating contour. \n");
        return U_ERROR;
    }
    int       IDleft  = 0;
    int       IDright = 0;

    UManifold*  PL    = GetTrangulatedCompletion(FaceLR[0], &IDleft);
    UManifold*  PR    = GetTrangulatedCompletion(FaceLR[1], &IDright);

    ErrorType    E    = (PL&&PR) ? U_OK : U_ERROR;
    *NnewVertex       = (E==U_OK) ? PL->NVertex + PR->NVertex - 2* *NBound : 0;
    *HandleVertexIDs  = (E==U_OK) ? new int[*NnewVertex + *NBound] : NULL;
    if(*HandleVertexIDs==NULL) E = U_ERROR;

    if(E==U_OK)  for(int k=0; k<*NBound; k++) (*HandleVertexIDs)[k] = VertexBoundIDs[k];
    if(E==U_OK)  E    = MCCut->MergeFaces(FaceLR[0]->GetID(), *PL, IDleft );
    if(E==U_OK)  for(int k=0; k<PL->NVertex-*NBound; k++) (*HandleVertexIDs)[    *NBound+k] = MCCut->LastVertexID-k;
    if(E==U_OK)  E    = MCCut->MergeFaces(FaceLR[1]->GetID(), *PR, IDright); 
    if(E==U_OK)  for(int k=0; k<PR->NVertex-*NBound; k++) (*HandleVertexIDs)[PL->NVertex+k] = MCCut->LastVertexID-k;
    
    delete PL; delete PR;
    if(E!=U_OK)
    {
        delete MCCut; delete[] VertexBoundIDs;
        delete[] *HandleVertexIDs; *HandleVertexIDs = NULL; *NBound = 0; *NnewVertex =0;
        CI.AddToLog("ERROR: UManifold::RemoveFirstHandle(). Merging pyramids to manifold. \n");
        return U_ERROR;
    }
    
    *this = *MCCut;
    delete MCCut; delete[] VertexBoundIDs;

    return U_OK;
}

ErrorType UManifold::RemoveHandles(int MaxOrder, int** HandleInds, int* NHandleInds, UPointList** pDraw)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    const int MaxDistMin = 4;
    if(MaxOrder<=MaxDistMin+1)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Parameter out of range (MaxOrder=%d). \n", MaxOrder);
        return U_ERROR;
    }
    if(HandleInds==NULL || NHandleInds==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    *HandleInds  = NULL;
    *NHandleInds = 0;
    if(pDraw) *pDraw  = new UPointList();

    if(GetNComponents()!=1)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Manifold consists of more than one component. \n");
        return U_ERROR;
    }

    int NHandle = (2-GetEulerChar())/2;
    if(NHandle<0 ) return U_ERROR;
    if(NHandle==0) return U_OK;

    if(IsTriangulation()==false)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Manifold contains non-trianglar faces. \n");
        return U_ERROR;
    }

    int** ContID = new int*[NHandle];
    int*  NPcont = new int [NHandle];
    int*  NPnew  = new int [NHandle];
    if(ContID==NULL || NPcont==NULL || NPnew==NULL)
    {
        delete[] ContID; delete[] NPcont; delete[] NPnew;
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Memory allocation, NHandle = %d. \n", NHandle);
        return U_ERROR;
    }
    for(int k=0; k<NHandle; k++) {ContID[k]=NULL; NPcont[k]=0; NPnew[k]=0;}

    int Ntot     = 0;
    int StartTry = 0;
    for(int k=0; k<NHandle; k++)
    {
        CI.AddToLog("Note: Handle = %d  of %d \t", k, NHandle);
        
        ErrorType E = U_OK;
        for(int itry=StartTry; itry<=(MaxOrder-MaxDistMin)/2; itry++)
        {
            int maxO = MaxDistMin + itry*2;
            if(maxO>MaxOrder) break;
            E = RemoveFirstHandle(maxO, ContID+k, NPcont+k, NPnew+k);
            if(NPcont[k]>0) StartTry = itry;
            if(E!=U_OK || NPcont[k]>0) break;
        }
        if(E!=U_OK)
        {
            for(int kk=0; kk<NHandle; kk++) delete[] ContID[kk];
            delete[] ContID; delete[] NPcont; delete[] NPnew;
            CI.AddToLog("ERROR: UManifold::RemoveHandles(). Removing  handle = %d. \n", k);
            return U_ERROR;
        }
        CI.AddToLog("\tNPoints = %d  \n", NPcont[k]);
        Ntot += NPcont[k] + NPnew[k];
    }
    if(Ntot==NULL) return U_OK;

    *HandleInds = new int[Ntot];
    if(*HandleInds)
    {
        ErrorType  E = U_OK;
        for(int k=0,n=0; k<NHandle && E==U_OK; k++)
        {
            if(NPcont[k]==0) continue;
            for(int kk=0; kk<NPcont[k]+NPnew[k] && E==U_OK; kk++, n++)  
            {
                int ind = FindVertex(ContID[k][kk]);
                if(ind<0)
                {
                    CI.AddToLog("ERROR: : UManifold::RemoveHandles(). Finding vertex ID %d on contour %d (point %d).\n", ContID[k][kk], k, kk);
                    E = U_ERROR;
                    delete[] *HandleInds; *HandleInds = NULL; Ntot = 0;
                }
                (*HandleInds)[n] = ind;
            }
        }
        if(pDraw)  *pDraw = GetDrawing(ContID, NPcont, NHandle);
        *NHandleInds = Ntot;
    }
    for(int kk=0; kk<NHandle; kk++) delete[] ContID[kk]; delete[] ContID; delete[] NPcont; delete[] NPnew;
    if(*HandleInds==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveHandles(). Memory allocation or finding vertices.\n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UManifold::RemoveOutliers(int MaxOrder, bool ConstThresh, double ThreshPar, int** NewVertexInds, int* NNewVInds, UPointList** pDraw)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(MaxOrder<1)
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Parameter out of range (MaxOrder=%d). \n", MaxOrder);
        return U_ERROR;
    }
    if(ThreshPar<=0.)
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Parameter out of range (ThreshPar=%f). \n", ThreshPar);
        return U_ERROR;
    }

    if(NewVertexInds==NULL || NNewVInds==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    *NewVertexInds    = NULL;
    *NNewVInds        = 0;
    if(pDraw) *pDraw  = new UPointList();

/* Find outliers and store indices in Dum[] array. */
    int* Dum          = new int[NVertex];
    for(int n=0; n<NVertex; n++) Dum[n]=-1;
    for(int n=0; n<NVertex; n++)
    {
        int*  NNeig = GetNVertexNeigbours2(n, MaxOrder, NULL);
        ErrorType E = NNeig ? U_OK : U_ERROR;
        if(E==U_OK)
            for(int m=MaxOrder; m>2; m--)
            {
                if(NNeig[m]<=0) continue;
                if(     ConstThresh && NNeig[m]>=int(ThreshPar  )) continue;
                if(NOT(ConstThresh) && NNeig[m]>=int(ThreshPar*m)) continue;

                int**     Verts = NULL;
                int*      NN    = GetNVertexNeigbours2(n, MaxOrder, &Verts);

                E = NN ? U_OK : U_ERROR;
                for(int mm=0; mm<=m && E==U_OK; mm++)
                    for(int n=0; n<NN[mm] && E==U_OK; n++) 
                    {
                        int ind = FindVertex(Verts[mm][n]);
                        if(ind>=0) Dum[ind] = 1; else E = U_ERROR;
                    }
                if(Verts) {for(int mm=0; mm<=MaxOrder; mm++) delete[] Verts[mm];} delete[] Verts; delete[] NN;
                break;
            }

        delete[] NNeig;
        if(E!=U_OK)
        {
            delete[] Dum;
            CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Finding neighbors in vertex n=%d. \n", n);
            return U_ERROR;
        }
    }

    int Ncorrect =0;
    for(int n=0; n<NVertex; n++)
    {
        if(Dum[n]<0) continue;

        UVertexEdgeIterator VEI(vertices[n]);
        int    NPM  = 0;
        for(UEdge* E=VEI.GetStart(); E; E=VEI.GetNext())
        {
            UEdge* EE  = E->GetSym()->GetONext();
            int    id0 = FindVertex(EE->GetOrg() ->GetID());
            int    id1 = FindVertex(EE->GetDest()->GetID());

            if(Dum[id0]>0 && Dum[id1]<0) NPM++;
        }
        if(NPM>1) {Dum[n] = -1; Ncorrect++;}
    }
    int** VertIDs    = NULL;
    int*  NPContour  = NULL;
    int   NContour   = 0;
    if(GetLevelContours(Dum, 0, U_LEVEL_LARGER, &VertIDs, &NPContour, &NContour)!=U_OK || VertIDs==NULL || NPContour==NULL)
    {
        delete[] Dum;
        if(VertIDs) {for(int k=0; k<NContour; k++) delete[] VertIDs[k];} delete[] VertIDs; delete[] NPContour;
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Getting level contours. \n");
        return U_ERROR;
    }
    delete[] Dum;
    if(pDraw) *pDraw = GetDrawing(VertIDs, NPContour, NContour);

    UManifold MM  = *this;
    for(int ic=0; ic<NContour; ic++)
    {
        int NPCont = NPContour[ic];
        if(VertIDs[ic]==NULL || NPCont<=3) 
        {
            CI.AddToLog("WARNING: UManifold::RemoveOutliers(). Invalid contour, ic=%d or too few points (NPCont = %d).\n", ic, NPCont); 
            continue;
        }

        UFace* LRFace[2] = {NULL, NULL};
        UManifold*  Mcut = MM.GetContourCut(VertIDs[ic], NPCont, LRFace, true); // Replace contour by two (non-triangular) faces.
        if(Mcut==NULL || Mcut->GetError()!=U_OK)
        {
            delete Mcut; 
            CI.AddToLog("WARNING: UManifold::RemoveOutliers(). Cutting along contour %d (of %d) with %d points. \n", ic, NContour, NPCont);
            for(int ii=0; ii<NContour; ii++)
            {
                CI.AddToLog("cont%d :", ii);
                for(int k=0; k<NPContour[ii]; k++) CI.AddToLog("%d \t", VertIDs[ii][k]); CI.AddToLog(" \n");
            }
            continue;
        }

        int FID = 0; UManifold* Mtip = GetTrangulatedCompletion(LRFace[0], &FID);
        if(Mtip==NULL || Mtip->GetError()!=U_OK)
        {
            for(int k=0; k<NContour; k++) delete[] VertIDs[k]; delete[] VertIDs; delete[] NPContour;
            delete Mcut; delete Mtip;
            CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Creating new tip, ic=%d, NPCont=%d. \n", ic, NPCont);
            return U_ERROR;
        }
        if(Mcut->MergeFaces(LRFace[0]->GetID(), *Mtip, FID)!=U_OK || Mcut->MergeFaces(LRFace[1]->GetID(), *Mtip, FID)!=U_OK) // Replace new faces by pyramids
        {
            for(int k=0; k<NContour; k++) delete[] VertIDs[k]; delete[] VertIDs; delete[] NPContour;
            delete Mcut; delete Mtip;
            CI.AddToLog("ERROR: UManifold::RemoveOutliers(). Merging face(s), ic=%d, NPCont=%d. \n", ic, NPCont);
            return U_ERROR;
        }
        MM = *Mcut;
        delete Mtip; delete Mcut;
    }
    for(int k=0; k<NContour; k++) delete[] VertIDs[k]; delete[] VertIDs; delete[] NPContour;

    int LastVID = LastVertexID;
    MM.SelectLargestComponent();
    *this       = MM;

    Dum         = new int[NVertex];
    if(Dum==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveOutliers(). MMemory allocation, NVertex=%d. \n", NVertex);
        return U_ERROR;
    }

    *NNewVInds  = 0;
    for(int n=0; n<NVertex; n++) if(vertices[n]->GetID()>LastVID) Dum[(*NNewVInds)++] = n;

    *NewVertexInds = new int[*NNewVInds];
    if(*NewVertexInds)
    {
        for(int k=0; k<*NNewVInds; k++) (*NewVertexInds)[k] = Dum[k];
        delete[] Dum;
    }
    else
    {
        CI.AddToLog("WARNING: UManifold::RemoveOutliers(). Creating output array. \n");
        *NewVertexInds = Dum;
    }
    return U_OK;
}

ErrorType UManifold::ForceSphericalTopology(int IfaceStart, int MaxNTheta, int MaxNFi, UEuler* XfmOpt, int* icontOpt)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(IfaceStart<0 || IfaceStart>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Face parameter out of range (IFaceStart=%d). \n", IfaceStart);
        return U_ERROR;
    }
    if(MaxNTheta<=1 || MaxNFi<=1)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). MaxNTheta (=%d) and/or MaxNFi (=%d) out of range.\n", MaxNTheta, MaxNFi);
        return U_ERROR;
    }
    if(XfmOpt==NULL || icontOpt==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Invalid NULL pointer argument(s) for optimal UEuler and/or contour. \n");
        return U_ERROR;
    }

/* Ignore small topologically seperated parts */
    if(this->SelectLargestComponent()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Selecting largest component.  \n");
        return U_ERROR;
    }

/* Compute Euler characteristic */
    int EulerChar = this->GetEulerChar();
    if(EulerChar==2)
    {
        CI.AddToLog("Note: UManifold::ForceSphericalTopology(). Euler characteristic is 2. \n");
        return U_OK;
    }

/* Project onto triangle IfaceStart, determine failures and itst center */
    UManifold MFlat          = *this;
    bool      CenterDense    = false;
    bool      ApplySqrtXfm   = false;
    bool      RepairFailures = false;
    bool      Harmonic       = false;
    int       Iface          = 0;
    if(MFlat.ProjectCircle(IfaceStart,-1, CenterDense, ApplySqrtXfm, RepairFailures, Harmonic)!=U_OK)
    {
        CI.AddToLog("Note: UManifold::ForceSphericalTopology(). Projecting onto sphere. \n");
        return U_ERROR;
    }
    int       NReverse  = 0;
    int*      RevArrArr = MFlat.GetReverselyProjectedFaceIndices(Iface, &NReverse);
    UVector3  Center    = this->GetFacesCenter(RevArrArr, NReverse);

/* Determine best cross-section */ int k1=-1, k2=-1;
    int       NPContOpt = -1;
              *icontOpt = -1;
    for(int ith=0; ith<MaxNTheta; ith++)
    {
        for(int ifi=0; ifi<MaxNFi; ifi++)
        {
            double   the = ith*PI/MaxNTheta;
            double   phi = ifi*PI/MaxNFi;
            UVector3 Ax(sin(the), 0., cos(the));
            UEuler Rot(Ax, phi);

            UManifold MHipRot = *this;
            UEuler    Xfm     = Rot*UEuler(-Center);
            MHipRot.Transform(Xfm);

            int**  VertIDs    = NULL;
            int*   NPointsCon = NULL;
            int    NCont      = 0;
            if(MHipRot.GetCrossSection(2, 0., &VertIDs, &NPointsCon, &NCont)!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Computing cross-section, The=%f, Fi=%f .\n", the, phi);
                return U_ERROR;
            }

            for(int ic=0; ic<NCont; ic++)
            {
                UManifold* HipCut = MHipRot.GetContourCut(VertIDs[ic], NPointsCon[ic], NULL, false);
                if(HipCut==NULL || HipCut->GetError()!=U_OK)
                {
                    delete HipCut;
                    for(int icc=0; icc<NCont; icc++) delete[] VertIDs[icc]; delete[] VertIDs; delete[] NPointsCon;
                    CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Cutting rotated UManifold, The=%f, Fi=%f .\n", the, phi);
                    return U_ERROR;
                }
                int        EulerCut = HipCut->GetEulerChar();
                int        NComp    = HipCut->GetNComponents();
                if(abs(EulerCut-2)<abs(EulerChar-2) && EulerCut!=-1 && NComp==1 && NPointsCon[ic]>3 && (NPContOpt<0 || NPointsCon[ic]<NPContOpt))
                {
                    NPContOpt  = NPointsCon[ic];
                    *XfmOpt    = Xfm;
                    *icontOpt  = ic; k1 =ith; k2=ifi;
                }
                delete HipCut;
            }
            for(int icc=0; icc<NCont; icc++) delete[] VertIDs[icc]; delete[] VertIDs; delete[] NPointsCon;
        }
    }

/* Apply optimum cut */
    this->Transform(*XfmOpt);
    int**  VertIDs    = NULL;
    int*   NPointsCon = NULL;
    int    NCont      = 0;
    if(this->GetCrossSection(2, 0., &VertIDs, &NPointsCon, &NCont)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Computing cross-section, applying optimum xfm.\n");
        return U_ERROR;
    }
////    UManifold* HipCut = this->GetContourCut(VertIDs[*icontOpt], NPointsCon[*icontOpt], NULL);
////    UManifold* HipCut = this->GetContourCut(VertIDs[*icontOpt], NPointsCon[*icontOpt], -0.02, NULL);
    UManifold* HipCut = this->GetContourCut(VertIDs[*icontOpt], NPointsCon[*icontOpt], 0.02, NULL, false);
    if(HipCut==NULL || HipCut->GetError()!=U_OK)
    {
        delete HipCut;
        for(int icc=0; icc<NCont; icc++) delete[] VertIDs[icc]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::ForceSphericalTopology(). Cutting rotated UManifold, applying optimum xfm.\n");
        return U_ERROR;
    }
    *this = *HipCut;
    delete HipCut;
    for(int icc=0; icc<NCont; icc++) delete[] VertIDs[icc]; delete[] VertIDs; delete[] NPointsCon;
    this->Transform(XfmOpt->GetInverse());

    int EulerCharNew = this->GetEulerChar();
    CI.AddToLog("Note: UManifold::ForceSphericalTopology(). EulerCharacteristic changed from %d to %d. Apply new update. \n", EulerChar, EulerCharNew);
    this->CompleteTriangulationScratch();
    return ForceSphericalTopology(IfaceStart, MaxNTheta, MaxNFi, XfmOpt, icontOpt);
}
UDrawing* UManifold::GetLargestCrossSectionAsDrawing(int dir, double Step)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetLargestCrossSectionAsDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetLargestCrossSectionAsDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetLargestCrossSectionAsDrawing(). Invalid direction parameter, dir = %d .\n", dir);
        return NULL;
    }
    if(Step<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetLargestCrossSectionAsDrawing(). Invalid stepsize parameter, Step = %f .\n", Step);
        return NULL;
    }
    double Minc = GetMinCoord(dir);
    double Maxc = GetMaxCoord(dir);
    if(Minc==Maxc)
        return GetCrossSectionAsDrawing(dir, Minc, 0);

    int MaxStep = 1 + int(0.5 + (Maxc-Minc)/Step);

    int    NP    = -1;
    double Level = 0;
    
    for(int k=1; k<MaxStep-1; k++)
    {
        double  Lev = Minc + k*(Maxc-Minc)/(MaxStep-1);
        if(Lev>=Maxc) break;
        
        UPointList* Dra = GetCrossSectionAsDrawing(dir, Lev, 0);
        if(Dra==NULL || Dra->GetError()!=U_OK)
        {
            delete Dra; continue;
        }
        int N = Dra->GetNpoints();
        if(NP<N)
        {
            NP    = N;
            Level = Lev;
        }
        delete Dra;
    }
    return GetCrossSectionAsDrawing(dir, Level, 0);
}

UDrawing* UManifold::GetCrossSectionAsDrawing(UVector3 Dir, double Level, int ICont)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Dir==UVector3())
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Direction parameter is null-vector.\n");
        return NULL;
    }
    Dir.Normalize();

    UManifold M(*this);
    if(M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Copying *this. \n");
        return NULL;
    }

    UEuler   XFM;
    UVector3 Axis = Dir ^ UVector3(0.,0.,1);         // Tested order
    double   Omeg = Angle(UVector3(0.,0.,1.), Dir);
    if(Axis!=UVector3()) XFM = UEuler(Axis, Omeg);

    M.Transform(XFM);
    return M.GetCrossSectionAsDrawing(2, Level, ICont);
}
UDrawing* UManifold::GetDrawing(int* const* VertIDarray, const int* NPointsContour, int NContour, int ICont) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertIDarray==NULL || NPointsContour==NULL  || NContour<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Invalid NULL pointer, NContour = %d. \n", NContour);
        return NULL;
    }
    if(ICont>=NContour)
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Parameter out of range. ICont = %d , NContour = %d. \n", ICont, NContour);
        return NULL;
    }
    UDrawing* Draw = new UDrawing();
    if(Draw==NULL || Draw->GetError()!=U_OK)
    {
        delete Draw;
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Creating empty drawing object. \n");
        return NULL;
    }
    int icstart = ICont<0 ? 0        : ICont;
    int icend   = ICont<0 ? NContour : ICont+1;

    for(int ic=icstart; ic<icend; ic++)
    {
        for(int n=0; n<NPointsContour[ic]; n++)
        {
            if(FindVertex(VertIDarray[ic][n])<0                                 ||
                Draw->AddPoint(GetPointFromID(VertIDarray[ic][n]), n>0)!=U_OK)
            {
                delete Draw;
                CI.AddToLog("ERROR: UManifold::GetDrawing(). Point not found: %d or adding point gives error. \n", VertIDarray[ic][n]);
                return NULL;
            }
        }
        if(NPointsContour[ic]>1) Draw->CloseLastSegment(); // Close contour, before starting next
    }
    return Draw;
}
UDrawing* UManifold::GetDrawing(PMT_CUVERTEXP* Vert, int NVert) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Vert==NULL || NVert<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Invalid NULL pointer, NVert = %d. \n", NVert);
        return NULL;
    }
    UDrawing* Draw = new UDrawing();
    if(Draw==NULL || Draw->GetError()!=U_OK)
    {
        delete Draw;
        CI.AddToLog("ERROR: UManifold::GetDrawing(). Creating empty drawing object. \n");
        return NULL;
    }
    for(int n=0; n<NVert; n++)
        if(Draw->AddPoint(*Vert[n], n>0)!=U_OK)
        {
            delete Draw;
            CI.AddToLog("ERROR: UManifold::GetDrawing(). Adding point gives error. \n");
            return NULL;
        }

    Draw->CloseLastSegment(); // Close contour, before starting next
    return Draw;
}

UDrawing* UManifold::GetCrossSectionAsDrawing(int dir, double Level, int ICont)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Direction parameter out of range (dir=%d).\n", dir);
        return NULL;
    }
    int**  VertIDs    = NULL;
    int*   NPointsCon = NULL;
    int    NCont      = 0;
    if(GetCrossSection(dir, Level, &VertIDs, &NPointsCon, &NCont)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Getting cross section. \n");
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        return NULL;
    }
    UDrawing* Draw = GetDrawing(VertIDs, NPointsCon, NCont, ICont);
    if(Draw==NULL || Draw->GetError()!=U_OK)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsDrawing(). Creating empty drawing object. \n");
        return NULL;
    }
    for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
    return Draw;
}
UDrawing* UManifold::GetCrossSectionAsFlatDrawing(int dir, double Level)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsFlatDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsFlatDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsFlatDrawing(). Direction parameter out of range (dir=%d).\n", dir);
        return NULL;
    }
    srand(NVertex);
    Level += 1.e-7 * (-0.5 + rand()/(double) RAND_MAX);

    int NCrossEdge = 0;
    for(int n=0; n<NQEdge; n++) if(qedges[n]->IsCrossing(dir, Level)) NCrossEdge++;
    if(NCrossEdge<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsFlatDrawing(). No crossing edges found: dir=%d, Level=%f .\n", dir, Level);
        return NULL;
    }
    UQuadEdge** CrEdge  = new UQuadEdge*[NCrossEdge];
    UDrawing*   Draw    = new UDrawing();
    if(CrEdge==NULL||Draw==NULL)
    {
        delete[] CrEdge; delete Draw;
        CI.AddToLog("ERROR: UManifold::GetCrossSectionAsFlatDrawing(). Memory allocation, NCrossEdge=%d or creating empty Drawing.\n", NCrossEdge);
        return NULL;
    }
    int IFirstEdge   = -1;
    for(int n=0,k=0; n<NQEdge; n++) 
    {
        if(qedges[n]->IsCrossing(dir, Level)==false) continue;
        CrEdge[k++]   = qedges[n];
        if(IFirstEdge<0) IFirstEdge = n;
    }

/* Find chains of contours */
    int iedge        = IFirstEdge;
    int NCrossTested = 0;
    while(NCrossTested!=NCrossEdge)  // Start new contour
    {
        int  NPcont  = 0;
        bool Up      = false;

        while(iedge>=0)
        {
            Up = NOT(qedges[iedge]->IsOrgUp(dir, Level));
            Draw->AddPoint(qedges[iedge]->GetCrossingPoint(dir, Level), NPcont>0);
            NPcont++;
            NCrossTested++;
            
            for(int k=0; k<NCrossEdge; k++)
            {
                if(CrEdge[k]!=qedges[iedge]) continue;
                CrEdge[k]=NULL;
                break;
            }
            int IDnext = qedges[iedge]->GetNextCrossingID(dir, Level, NOT(Up));
            iedge      = -1;
            for(int k=0; k<NCrossEdge; k++)
            {
                if(CrEdge[k]==NULL) continue;
                if(CrEdge[k]->GetID()!=IDnext) continue;
                iedge = FindQuadEdge(IDnext);
                break;
            }
        }
        if(NPcont>1) Draw->CloseLastSegment();
        for(int k=0; k<NCrossEdge; k++)
        {
            if(CrEdge[k]==NULL) continue;
            iedge = FindQuadEdge(CrEdge[k]->GetID());
            break;
        }
    }
    delete[] CrEdge;
    return Draw;
}

ErrorType UManifold::GetCrossSection(UVector3 Dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(Dir==UVector3())
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Direction parameter is null-vector.\n");
        return U_ERROR;
    }
    Dir.Normalize();
    if(VertIDarray==NULL || NPointsContour==NULL || NContour==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    UManifold M(*this);
    if(M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Copying *this. \n");
        return U_ERROR;
    }

    UEuler   XFM;
    UVector3 Axis = Dir ^ UVector3(0.,0.,1);         // Tested order
    double   Omeg = Angle(UVector3(0.,0.,1.), Dir);
    if(Axis!=UVector3()) XFM = UEuler(Axis, Omeg);

    M.Transform(XFM);
    return M.GetCrossSection(2, Level, VertIDarray, NPointsContour, NContour);
}
ErrorType UManifold::GetCrossSection(int dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Direction parameter out of range (dir=%d).\n", dir);
        return U_ERROR;
    }
    if(VertIDarray==NULL || NPointsContour==NULL || NContour==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    srand(NVertex);
    Level += 1.e-7 * (-0.5 + rand()/(double) RAND_MAX);

    /* Default output */
    *VertIDarray     = NULL;
    *NPointsContour  = NULL;
    *NContour        = 0;

    double* Coords = new double[NVertex];
    if(Coords==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Memory allocation, NVertex = %d. \n", NVertex);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) Coords[n] = (*(vertices[n]))[dir];

    if(this->GetLevelContours(Coords, Level, U_LEVEL_SMALLEREQUAL, VertIDarray, NPointsContour, NContour)!=U_OK)
    {
        delete[] Coords;
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Computing level contours. \n");
        return U_ERROR;
    }
    delete[] Coords;
    return U_OK;
}
UDrawing* UManifold::GetLevelContoursAsDrawing(const double* VertexData, double Level, LevelType LevTyp)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). VertexData is NULL.\n");
        return NULL;
    }
    if(LevTyp!=U_LEVEL_SMALLER && LevTyp!=U_LEVEL_SMALLEREQUAL && LevTyp!=U_LEVEL_LARGER && LevTyp!=U_LEVEL_LARGEREQUAL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). Unsupported level type (%d). \n", int(LevTyp));
        return NULL;
    }

    int** VertIDarray    = NULL;
    int*  NPointsContour = NULL;
    int   NContour       = 0;
    if(GetLevelContours(VertexData, Level, LevTyp, &VertIDarray, &NPointsContour, &NContour)!=U_OK)
    {
        if(NContour>0) for(int n=0; n<NPointsContour[n]; n++) delete[] VertIDarray[n];
        delete[] VertIDarray; delete[] NPointsContour;
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). Creating contours. \n");
        return NULL;
    }
    UDrawing* Dr = GetDrawing(VertIDarray, NPointsContour,  NContour);
    if(NContour>0) for(int n=0; n<NContour; n++) delete[] VertIDarray[n];
    delete[] VertIDarray; delete[] NPointsContour;

    if(Dr==NULL || Dr->GetError()!=U_OK)
    {
        delete Dr;
        CI.AddToLog("ERROR: UManifold::GetLevelContoursAsDrawing(). Creating drawing from contours. \n");
        return NULL;
    }
    return Dr;
}

ErrorType UManifold::GetLevelContours(const int* VertexData, int Level, LevelType LevTyp, int*** VertIDarray, int** NPointsContour, int* NContour)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). VertexData is NULL.\n");
        return U_ERROR;
    }
    if(VertIDarray==NULL || NPointsContour==NULL || NContour==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }

    /* Default output */
    *VertIDarray     = NULL;
    *NPointsContour  = NULL;
    *NContour        = 0;

    double* DVertexData = new double[NVertex];
    if(DVertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Creating double array, NVertex = %d. \n", NVertex);
        return U_ERROR;
    }
    for(int i=0; i<NVertex; i++) DVertexData[i] = VertexData[i];
    ErrorType E = GetLevelContours(DVertexData, double(Level), LevTyp, VertIDarray, NPointsContour, NContour);
    delete[] DVertexData;
    return E;
}

ErrorType UManifold::GetLevelContours(const double* VertexData, double Level, LevelType LevTyp, int*** VertIDarray, int** NPointsContour, int* NContour)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). VertexData is NULL.\n");
        return U_ERROR;
    }
    if(VertIDarray==NULL || NPointsContour==NULL || NContour==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }

    /* Default output */
    *VertIDarray     = NULL;
    *NPointsContour  = NULL;
    *NContour        = 0;

    if(LevTyp!=U_LEVEL_SMALLER && LevTyp!=U_LEVEL_SMALLEREQUAL && LevTyp!=U_LEVEL_LARGER && LevTyp!=U_LEVEL_LARGEREQUAL)
    {
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Unsupported level type (%d). \n", int(LevTyp));
        return U_ERROR;
    }
    double DatMin = GetMin(VertexData, NVertex);
    double DatMax = GetMax(VertexData, NVertex);
    srand(NVertex);
    Level += 1.e-7 * (DatMax-DatMin)*(-0.5 + rand()/(double) RAND_MAX);
    if(DatMax<=DatMin || Level<=DatMin || DatMax<=Level)
    {
        CI.AddToLog("WARNING: UManifold::GetLevelContours(). Level out of range: (DatMin, DatMax, Level)=(%f, %f %f).\n", DatMin, DatMax, Level);
        return U_OK;
    }

    /* Cross edge count */
    int    NCrossFace =  0;
    int    IFirstFace = -1;
    double Dist       = 1.e50;
    for(int n=0; n<NFace; n++)
    {
        double MinD = 1.;
        double MaxD = 0.;
        if(faces[n]==NULL || GetMinMaxVertexData(faces[n], VertexData, &MinD, &MaxD)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::GetLevelContours(). Getting min/max data from face %d .\n", n);
            return U_ERROR;
        }
        if(MinD>Level || MaxD<Level) continue;

        double MinDif = MIN( fabs(MinD-Level), fabs(MaxD-Level) );
        if(IFirstFace<0 || MinDif<Dist)
        {
            IFirstFace  = NCrossFace;
            Dist        = MinDif;
        }
        NCrossFace++;
    }
    if(IFirstFace<0 || NCrossFace<=0)
    {
        CI.AddToLog("WARNING: UManifold::GetLevelContours(). Crossection empty, Level = %f .\n", Level);
        return U_OK;
    }

    UFace** CrFace       = new UFace*[NCrossFace];
    int     NPoints      = 0;                   // Total number of points, of all contours
    int     NPointsAlloc = NCrossFace;
    int*    IDArr        = new int[NPointsAlloc];
    int     NCont        = 0;
    int     NContAlloc   = 10+NPointsAlloc/2;
    int*    ContArr      = new int[NContAlloc]; // Number of points for each contour
    if(CrFace==NULL || IDArr==NULL || ContArr==NULL)
    {
        delete[] CrFace; delete[] IDArr; delete[] ContArr;
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Memory allocation, NPointsAlloc = %d, NContAlloc = %d .\n", NPointsAlloc, NContAlloc);
        return U_ERROR;
    }
    for(int k=0; k<NCrossFace;   k++) CrFace [k] =  NULL;
    for(int k=0; k<NPointsAlloc; k++) IDArr  [k] = -1;
    for(int k=0; k<NContAlloc;   k++) ContArr[k] =  0;

    for(int n=0, k=0; n<NFace; n++)
    {
        double MinD = 1.;
        double MaxD = 0.;
        GetMinMaxVertexData(faces[n], VertexData, &MinD, &MaxD);
        if(MinD>Level || MaxD<Level) continue;
        CrFace[k++]   = faces[n];
    }
    /* Find chains of contours */
    int NCrossTested = 0;
    while(NCrossTested!=NCrossFace)  // Start new contour
    {
        int NPointsCon   = 0;
        int iface        = IFirstFace;

        while(iface>=0)
        {
            double  LevTst= (LevTyp==U_LEVEL_SMALLER || LevTyp==U_LEVEL_SMALLEREQUAL) ? -Level : Level;
            UEdge*  E     = CrFace[iface]->GetEdge();
            UEdge*  N     = NULL;
            int     NEdge = CrFace[iface]->GetNEdge();
            for(int k=0; k<NEdge; k++)
            {
                double LevOrg = (LevTyp==U_LEVEL_SMALLER || LevTyp==U_LEVEL_SMALLEREQUAL) ? -GetDataOrg (E, VertexData) :GetDataOrg (E, VertexData);
                double LevDes = (LevTyp==U_LEVEL_SMALLER || LevTyp==U_LEVEL_SMALLEREQUAL) ? -GetDataDest(E, VertexData) :GetDataDest(E, VertexData);
                if(LevDes>=LevTst)
                {
                    if(LevOrg<=LevTst)
                    {
                        N = E;
                    }
                    if(LevOrg>=LevTst)
                    {
                        if(NPointsCon>=2 && E->GetDest()->GetID()==IDArr[NPoints-2])
                        {
                            NPointsCon--;
                            NPoints--;
                        }
                        else
                        {
                            if(NPoints+2>=NPointsAlloc)
                            {
                                if(NPoints>=NVertex)
                                {
                                    delete[] CrFace; delete[] IDArr; delete[] ContArr;
                                    CI.AddToLog("ERROR: UManifold::GetLevelContours(). Algorithm not converging: NPoints=%d, NVertex=%d \n", NPoints, NVertex);
                                    return U_ERROR;
                                }
                                int  NewAlloc = 3*NPoints/2 + 10;
                                int* NewArray = new int[NewAlloc];
                                if(NewArray==NULL)
                                {
                                    delete[] CrFace; delete[] IDArr; delete[] ContArr;
                                    CI.AddToLog("ERROR: UManifold::GetLevelContours(). Memory allocation, NewAlloc = %d  .\n", NewAlloc);
                                    return U_ERROR;
                                }
                                for(int kk=0      ; kk<NPoints;  kk++) NewArray[kk] = IDArr[kk];
                                for(int kk=NPoints; kk<NewAlloc; kk++) NewArray[kk] = -1;
                                delete[] IDArr; IDArr = NewArray;
                                NPointsAlloc = NewAlloc;
                            }
                            NPointsCon++;
                            IDArr[NPoints++] = E->GetDest()->GetID();
                        }
                    }
                }
                E = E->GetLNext();
            }
            if(N==NULL)
            {
                delete[] CrFace; delete[] IDArr; delete[] ContArr;
                CI.AddToLog("ERROR: UManifold::GetLevelContours(). Next edge not found, iface = %d  .\n", iface);
                return U_ERROR;
            }
            CrFace[iface] = NULL;
            NCrossTested++;
            iface         = -1;
            for(int k=0; k<NCrossFace; k++)
            {
                if(CrFace[k]==NULL) continue;
                if(CrFace[k]->HasEdge(N->GetSym())) {iface=k; break;}
            }
        }

        /* Next face not found. Start new contour */
        if(NCont+NPointsCon+1>NContAlloc) // Expand array, account for contour splitting
        {
            if(NCont>=NVertex)
            {
                delete[] CrFace; delete[] IDArr; delete[] ContArr;
                CI.AddToLog("ERROR: UManifold::GetLevelContours(). Algorithm not converging: NCont=%d, NVertex=%d \n", NCont, NVertex);
                return U_ERROR;
            }
            int  NewAlloc = 3*NCont/2 + NPointsCon + 3;
            int* NewArray = new int[NewAlloc];
            if(NewArray==NULL)
            {
                delete[] CrFace; delete[] IDArr; delete[] ContArr;
                CI.AddToLog("ERROR: UManifold::GetLevelContours(). Memory allocation, NewAlloc = %d  (NCont = %d).\n", NewAlloc, NCont);
                return U_ERROR;
            }
            for(int k=0    ; k<NCont   ; k++) NewArray[k] = ContArr[k];
            for(int k=NCont; k<NewAlloc; k++) NewArray[k] = 0;
            delete[] ContArr; ContArr = NewArray;
            NContAlloc = NewAlloc;
        }
        ContArr[NCont++] = NPointsCon;

        if(NCrossTested<NCrossFace) // Start new contour
        {
            IFirstFace = -1;
            for(int k=0; k<NCrossFace; k++) // Find new free cross edge
                if(CrFace[k]) {IFirstFace = k; break;}
        }
    }
    delete[] CrFace;

    /* Store contours in separate pointers, split self-crossings and order in size */
    int**  pArrayID  = new int*[NContAlloc];
    if(pArrayID)
    {
        for(int ic=0        ; ic<NContAlloc; ic++) pArrayID[ic] = NULL;
        for(int ic=0, noff=0; ic<NCont     ; ic++)
        {
            pArrayID[ic] = new int[ContArr[ic]];
            if(pArrayID[ic])
            {
                for(int n=0; n<ContArr[ic]; n++) pArrayID[ic][n] = IDArr[noff+n];
                noff += ContArr[ic];
            }
            else
            {
                for(int icc=0; icc<NCont; icc++) delete[] pArrayID[icc];
                delete[] pArrayID; pArrayID = NULL;
                break;
            }
        }
    }
    delete[] IDArr; // This array has now been copied
    if(pArrayID==NULL)
    {
        delete[] ContArr;
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Copying contours. \n");
        return U_ERROR;
    }

    SplitContour (pArrayID, ContArr, &NCont, 0, NContAlloc);
    SkipShortCuts(pArrayID, ContArr,  NCont);

    int*   SizeOrder = GetOrderIndexArray(ContArr, NCont, false, true);
    int**  OrderedID = new int*[NCont];
    int*   OrderedNP = new int [NCont];
    if(SizeOrder==NULL || OrderedID==NULL || OrderedNP==NULL)
    {
        for(int icc=0; icc<NCont; icc++) delete[] pArrayID[icc]; delete[] pArrayID;
        delete[] SizeOrder;  delete[] OrderedID; delete[] OrderedNP;
        CI.AddToLog("ERROR: UManifold::GetLevelContours(). Ordering contour sizes. \n");
        return U_ERROR;
    }
    for(int n=0; n<NCont; n++) {OrderedNP[n] = 0; OrderedID[n] = NULL;}
    for(int n=0; n<NCont; n++)
    {
        if(ContArr[SizeOrder[n]]<=2) // Minimum number of points per cont should be 3
        {
            NCont = n;
            break;
        }
        OrderedNP[n] = ContArr [SizeOrder[n]];
        OrderedID[n] = pArrayID[SizeOrder[n]];
    }
    delete[] SizeOrder;
    delete[] ContArr;
    delete[] pArrayID;

    *VertIDarray    = OrderedID;
    *NPointsContour = OrderedNP;
    *NContour       = NCont;
    return U_OK;
}

ErrorType UManifold::SplitContour(int**  pArrayID, int* NPCont, int *NCont, int Istart, int NContAlloc) const
{
    int NC = *NCont;
    for(int ic=Istart; ic<NC; ic++)
    {
        int NPC = NPCont[ic];
        for(int Size=2; Size<NPC-1; Size++)
        {
            for(int n=0; n<NPC; n++)
            {
                int nbeg = n;
                int nend = (nbeg+Size)%NPC;
                if(pArrayID[ic][nbeg]!=pArrayID[ic][nend]) continue;
                if(nend<nbeg) {int dum=nend; nend=nbeg; nbeg=dum;}

                if(NC+1>NContAlloc)
                {
                    CI.AddToLog("ERROR: UManifold::SplitContour(). Too few contours allocated: NC=%d .\n", NC);
                    return U_ERROR;
                }
                pArrayID[NC] = new int[NPC];
                if(pArrayID[NC]==NULL)
                {
                    CI.AddToLog("ERROR: UManifold::SplitContour(). Memory allocation NPC=%d .\n", NPC);
                    return U_ERROR;
                }
                for(int nn=0   ; nn<     nend-nbeg; nn++) pArrayID[NC][nn] = pArrayID[ic][     nbeg+nn];
                for(int nn=nbeg; nn<NPC -nend+nbeg; nn++) pArrayID[ic][nn] = pArrayID[ic][nend-nbeg+nn];
                NPCont[NC]  = nend-nbeg;
                NPCont[ic] -= nend-nbeg;
                *NCont      = NC+1;
                if(n==nbeg)
                {
                    int  dum = NPCont[NC];   NPCont[NC]   = NPCont[ic];   NPCont[ic]   = dum;
                    int* pum = pArrayID[NC]; pArrayID[NC] = pArrayID[ic]; pArrayID[ic] = pum;
                }
                return SplitContour(pArrayID, NPCont, NCont, ic+1, NContAlloc);
            }
        }
    }
    return U_OK;
}

ErrorType UManifold::SkipShortCuts(int**  pArrayID, int* NPCont, int NCon) const
{
    if(pArrayID==NULL || NPCont==NULL) return U_ERROR;
    for(int ic=0; ic<NCon; ic++) 
        if(pArrayID[ic]==NULL && NPCont[ic]!=0) return U_ERROR;

    bool ShortCutFound = false;
    for(int ic=0; ic<NCon; ic++)
    {
        int NPC = NPCont[ic];
        if(NPC<=3) continue;

        for(int n=0; n<NPC; n++)
        {
            int np = (n+NPC-1)%NPC;
            int nn = (n    +1)%NPC;
            if(FindQuadEdge(pArrayID[ic][np], pArrayID[ic][nn])<0 &&
               FindQuadEdge(pArrayID[ic][nn], pArrayID[ic][np])<0)  continue;

            for(int n2=n; n2<NPC-1;n2++) pArrayID[ic][n2] = pArrayID[ic][n2+1];
            NPCont[ic]--;
            ShortCutFound = true;
            break;
        }
    }
    if(ShortCutFound==true) return SkipShortCuts(pArrayID, NPCont, NCon);
    return U_OK;
}
ErrorType UManifold::SkipEdgeShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const
{
    if(EArray==NULL || NEdgeOut==NULL || NEdgeIn<0) return U_ERROR;
    if(NEdgeIn==NULL) return U_OK;

    ErrorType E =U_OK;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]==NULL)                                       E=U_ERROR;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]->GetDest()!=EArray[(n+1)%NEdgeIn]->GetOrg()) E=U_ERROR;
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SkipEdgeShortCuts(). Invalid contour.\n");
        return U_ERROR;
    }

    int  NN        = NEdgeIn;
    bool ShortCut  = false;
    do{
        bool ShortCut = false;
        for(int nn1=0; nn1<NN && NOT(ShortCut); nn1++)
        {
            for(int nn2=nn1+1; nn2<NN && NOT(ShortCut); nn2++)
            {
                if(EArray[nn1]!=EArray[nn2]->GetSym()) continue;
                if(nn2-nn1-1>nn1+NN-nn2-1)  // Keep middle part
                {
                    NN = 0;
                    for(int n=nn1+1;n<nn2    ; n++) EArray[NN++] = EArray[n];
                }
                else  // Keep first and last end
                {
                    int NNtot = nn1;
                    for(int n=nn2+1;n< NN; n++) EArray[NNtot++] = EArray[n];
                    NN = NNtot;
                }
                ShortCut = true;
            }
        }
    }
    while(ShortCut);
    *NEdgeOut = NN;
    return U_OK;
}
ErrorType UManifold::SkipVertexShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const
{
    if(EArray==NULL || NEdgeOut==NULL || NEdgeIn<0) return U_ERROR;
    if(NEdgeIn==NULL) return U_OK;

    ErrorType E =U_OK;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]==NULL)                                       E=U_ERROR;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]->GetDest()!=EArray[(n+1)%NEdgeIn]->GetOrg()) E=U_ERROR;
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SkipVertexShortCuts(). Invalid contour.\n");
        return U_ERROR;
    }

    int  NN        = NEdgeIn;
    bool ShortCut  = false;
    do{
        bool ShortCut = false;
        for(int nn1=0; nn1<NN && NOT(ShortCut); nn1++)
        {
            for(int nn2=nn1+1; nn2<NN && NOT(ShortCut); nn2++)
            {
                if(EArray[nn1]->Vertex!=EArray[nn2]->Vertex) continue;
                if(nn2-nn1>nn1+NN-nn2)  // Keep middle part
                {
                    NN = 0;
                    for(int n=nn1;n<nn2; n++) EArray[NN++] = EArray[n];
                }
                else  // Keep first and last end
                {
                    int NNtot = nn1;
                    for(int n=nn2;n< NN; n++) EArray[NNtot++] = EArray[n];
                    NN = NNtot;
                }
                ShortCut = true;
            }
        }
    }
    while(ShortCut);
    *NEdgeOut = NN;
    return U_OK;
}
ErrorType UManifold::SkipOneStepShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const
{
    if(EArray==NULL || NEdgeOut==NULL || NEdgeIn<0) return U_ERROR;
    if(NEdgeIn==NULL) return U_OK;

    ErrorType E =U_OK;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]==NULL)                                       E=U_ERROR;
    for(int n=0; n<NEdgeIn && E==U_OK; n++) if(EArray[n]->GetDest()!=EArray[(n+1)%NEdgeIn]->GetOrg()) E=U_ERROR;
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SkipOneStepShortCuts(). Invalid contour.\n");
        return U_ERROR;
    }

    int  NN        = NEdgeIn;
    bool ShortCut  = false;
    do{
        if(NN<=3) break;
        ShortCut = false;
        for(int n=0; n<NN; n++)  // Set new inner contour: Set one step short cuts
        {
            UEdge*  E1 = EArray[ n      ];
            UEdge*  E2 = EArray[(n+1)%NN];
            if(E1==NULL || E2==NULL) break;
            UEdge*  EE = E1->GetOrg() ->GetEdgeTo(E2->GetDest());
            if(EE)
            {
                ShortCut    = true;
                UEdge*   E0 = EArray[(n+NN-1)%NN];
                if(EE!=E0 && EE->GetSym()!=E0)
                {
                    bool   order = (EE->GetDest() == E2->GetDest());
                    EArray[ n      ] = order ? EE : EE->GetSym(); 
                    EArray[(n+1)%NN] = NULL;
                }
                else // Remove intersecting triangle
                {
                    EArray[(n+NN-1)%NN] = EArray[n] = EArray[(n+1)%NN] = NULL;
                }
                n++;
            }
        }
        NEdgeIn = 0;
        for(int n=0; n<NN; n++) if(EArray[n]) EArray[NEdgeIn++] = EArray[n];
        NN = NEdgeIn;
    }
    while(ShortCut);

    *NEdgeOut = NN;
    return U_OK;
}


ErrorType UManifold::GetCrossSection(int dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour, double* CoMin, double* CoMax)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Direction parameter out of range (dir=%d).\n", dir);
        return U_ERROR;
    }
    if(VertIDarray==NULL || NPointsContour==NULL || NContour==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    if(this->GetCrossSection(dir, Level, VertIDarray, NPointsContour, NContour)!=U_OK)
    {
        VertIDarray = NULL; NPointsContour = NULL; NContour = 0;
        CI.AddToLog("ERROR: UManifold::GetCrossSection(). Computing contours. \n");
        return U_ERROR;
    }
    if(CoMin==NULL && CoMax==NULL) return U_OK;

    int ifirst  = FindVertex((*VertIDarray)[0][0]);

    double Cmin = (*vertices[ifirst])[dir];
    double Cmax = Cmin;

    for(int ic=0; ic<*NContour; ic++)
    {
        for(int n=0; n<(*NPointsContour)[ic]; n++)
        {
            int    ind   = FindVertex((*VertIDarray)[ic][n]);
            double Coord = (*vertices[ind])[dir];
            if(Coord<Cmin) Cmin = Coord;
            if(Coord>Cmax) Cmax = Coord;
        }
    }

    if(CoMin) *CoMin = Cmin;
    if(CoMax) *CoMax = Cmax;
    return U_OK;
}

UPointList* UManifold::GetPointList(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetPointList(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( NVertex>0 && vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetPointList(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(NVertex<=0)   return new UPointList();

    UVector3* P    = new UVector3[NVertex];
    if(P==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetPointList(). Memory allocation. NVertex = %d, NFace = %d .\n", NVertex, NFace);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) P[n] = UVector3(*(vertices[n]));

    UPointList* PL = new UPointList(P, NVertex);
    delete[] P;
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UManifold::GetPointList(). Creating surface object. \n");
        return NULL;
    }
    return PL;
}
UPointList* UManifold::GetVerticesAsPointList(const int* VertIDarray, int Npoint) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVerticesAsPointList(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( NVertex>0 && vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVerticesAsPointList(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertIDarray==NULL || Npoint<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetVerticesAsPointList(). Invalid NULL argument or invalid Npoint (%d).\n", Npoint);
        return NULL;
    }
    UPointList* PL = new UPointList();
    if(PL==NULL || PL->GetError()!=U_OK)
    {
        delete PL;
        CI.AddToLog("ERROR: UManifold::GetVerticesAsPointList(). Creating empty point list.\n");
        return NULL;
    }
    for(int k=0; k<Npoint; k++)
    {
        int ind = FindVertex(VertIDarray[k]);
        if(ind<0 || PL->AddPoint(*(vertices[ind]))!=U_OK)
        {
            delete PL;
            CI.AddToLog("ERROR: UManifold::GetVerticesAsPointList(). Finding point with ID %d, or adding point with index %d.\n", VertIDarray[k], ind);
            return NULL;
        }
    }
    return PL;
}
UMatrix UManifold::GetCoordMatrix(void) const
{
    if (this == NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCoordMatrix(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if (NVertex<=0 || vertices == NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetCoordMatrix(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return UMatrix(U_ERROR);
    }
    UMatrix CoMat(DNULL, NVertex, 3);
    double* pCoMat = CoMat.Data;
    if(pCoMat == NULL || CoMat.GetError() != U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetCoordMatrix(). Creating output matrix, NVertex = %d . \n", NVertex);
        return UMatrix(U_ERROR);
    }
    for(int n=0; n<NVertex; n++)
    {
        pCoMat[0] = vertices[n]->Getx();
        pCoMat[1] = vertices[n]->Gety();
        pCoMat[2] = vertices[n]->Getz();
        pCoMat   += 3;
    }
    return CoMat;
}
ErrorType UManifold::SetCoordMatrix(const UMatrix& CoordMat)
{
    if(this == NULL || error != U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SetCoordMatrix(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NVertex <= 0 || vertices == NULL)
    {
        CI.AddToLog("ERROR: UManifold::SetCoordMatrix(). Object not properly set (NVertex=%d). \n", NVertex);
        return U_ERROR;
    }
    if(CoordMat.IsDiagonalType()==true || CoordMat.Data==NULL)
    {
        CI.AddToLog("ERROR: UManifold::SetCoordMatrix(). Argument matrix of wrong type, or data not set. \n");
        return U_ERROR;
    }
    if(CoordMat.Nrow != NVertex || CoordMat.Ncol != 3)
    {
        CI.AddToLog("ERROR: UManifold::SetCoordMatrix(). Argument not compatible with function, (NVertex=%d, Nrow=%d, Ncol=%d). \n", NVertex, CoordMat.Nrow, CoordMat.Ncol);
        return U_ERROR;
    }
    double* pCoMat = CoordMat.Data;
    for(int n=0; n<NVertex; n++)
    {
        *(vertices[n]) = UVector3(pCoMat);
        pCoMat       += 3;
    }
    return U_OK;
}

USurface* UManifold::GetSurface(const char* Name, bool SkipNonTri) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetSurface(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex>0 && vertices==NULL) ||
        (NFace  >0 && faces   ==NULL) ||
        (NQEdge >0 && qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetSurface(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(SkipNonTri==false)
    {
        for(int n=0; n<NFace; n++)
        {
            UFace*   F = faces[n];
            UFaceEdgeIterator FEI(F);
            int  NNeig = FEI.GetNNeighbour();
            if(NNeig!=3)
            {
                CI.AddToLog("ERROR: UManifold::GetSurface(). Manifold is not triangulated surface. Face %d has degree %d .\n", n, NNeig);
                return NULL;
            }
        }
    }
    if(NVertex<=0 || NFace<=0)   return new USurface();

    UVector3* P    = new UVector3[NVertex];
    int*      Tril = new int[3*NFace];
    if(P==NULL || Tril==NULL)
    {
        delete[] P;  delete[] Tril;
        CI.AddToLog("ERROR: UManifold::GetSurface(). Memory allocation. NVertex = %d, NFace = %d .\n", NVertex, NFace);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) P[n] = UVector3(*(vertices[n]));

    int NSkipFace = 0;
    for(int n=0,n3=0; n<NFace;   n++,n3+=3)
    {
        UFace*   F = faces[n];
        UFaceEdgeIterator FEI(F);
        int  NNeig = FEI.GetNNeighbour();
        if(NNeig!=3)
        {
            NSkipFace++;
            n3-=3;
            continue;
        }

        UEdge*   E = FEI.GetStart();
        for(int k=0; k<3; k++, E=FEI.GetNext())
        {
            if(E==NULL || E->GetSym()==NULL || E->GetSym()->GetOrg()==NULL)
            {
                delete[] P;  delete[] Tril;
                CI.AddToLog("ERROR: UManifold::GetSurface(). Invalid edge structure of face %d (k=%d) .\n", n, k);
                return NULL;
            }
            int id = E->GetOrg()->GetID();
            int in = FindVertex(id);
            if(in<0 || in>=NVertex)
            {
                delete[] P;  delete[] Tril;
                CI.AddToLog("ERROR: UManifold::GetSurface(). vertex ID (%d) not found or out of range (%d).\n", id, in);
                return NULL;
            }
            Tril[n3+k] = in;
        }
    }
    USurface* S = new USurface(P, NVertex, Tril, NFace-NSkipFace, Name);
    delete[] P;
    delete[] Tril;
    if(S==NULL || S->GetError()!=U_OK)
    {
        delete S;
        CI.AddToLog("ERROR: UManifold::GetSurface(). Creating surface object. \n");
        return NULL;
    }
    return S;
}

UVector3* UManifold::GetFaceNormals(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceNormals(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetFaceNormals(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(IsTriangulation()!=true)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceNormals(). Object not a triangulation. \n");
        return NULL;
    }
    UVector3* N = new UVector3[LastFaceID];
    if(N==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceNormals(). Memory allocation. LastFaceID = %d .\n", LastFaceID);
        return NULL;
    }
    for(int n=0; n<NFace; n++)
    {
        int ID = faces[n]->GetID();
        N[ID]   = faces[n]->GetNormal();
        if(N[ID]==UVector3())
        {
            delete[] N;
            CI.AddToLog("ERROR: UManifold::GetFaceNormals(). Getting normal from face %d .\n", n);
            return NULL;
        }
    }
    return N;
}

ErrorType UManifold::Transform(UEuler eul)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::Transform(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::Transform(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    for(int n=0; n<NVertex; n++)
        *(vertices[n]) = eul.xfm(*(vertices[n]));
    return U_OK;
}
ErrorType UManifold::Transform(ULinTran Tra)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::Transform(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::Transform(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    for(int n=0; n<NVertex; n++)
        *(vertices[n]) = Tra.xfm(*(vertices[n]));
    return U_OK;
}
ErrorType UManifold::TransformCenter(double Sx, double Sy, double Sz)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::TransformCenter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::TransformCenter(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    UVector3 Center = GetCenter();
    for(int n=0; n<NVertex; n++)
    {
        UVector3   p   = *(vertices[n]);
        double     x   = Sx * (p.Getx()-Center.Getx());
        double     y   = Sy * (p.Gety()-Center.Gety());
        double     z   = Sz * (p.Getz()-Center.Getz());
        *(vertices[n]) = Center + UVector3(x,y,z);
    }
    return U_OK;
}
ErrorType UManifold::RandomizeVertices(double StDev, int iseed)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RandomizeVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(StDev<=0)
    {
        CI.AddToLog("ERROR: UManifold::RandomizeVertices(). Invalid standard deviation parameter (StDev=%f). \n", StDev);
        return U_ERROR;
    }
    if(NVertex==0) return U_OK;

    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RandomizeVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    UGaussian G(StDev,0.,iseed);
    for(int ip=0; ip<NVertex; ip++)
    {
        double X = G.GetGaussian();
        double Y = G.GetGaussian();
        double Z = G.GetGaussian();

        *(vertices[ip]) += UVector3(X, Y, Z);
    }
    return U_OK;
}

ErrorType UManifold::ReconstructFromRandomSubset(int Depth, int seed, int order, TypePenalty PT, double Lamda2, UPointList** pPL, double** ARatio)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    if(order==0 || abs(order)>3)
    {
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Interpolation order out of range: order = %d out of range (PT=%d). \n", order, (int)PT);
        return U_ERROR;
    }
    if(((PT==U_PENALTY_L1 || PT==U_PENALTY_L2) && Lamda2<=0.) || PT==U_PENALTY_UNKNOWN)
    {
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Parameters out of range: PT=%d, Lamdat2=%f. \n", int(PT), Lamda2);
        return U_ERROR;
    }

    USurface* S = GetSurface("S", true);
    if(S==NULL || S->GetError()!=U_OK)
    {
        delete S;
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Converting *this to USurface. \n");
        return U_ERROR;
    }
    int  NIndex = 0;
    int* Index  = S->GetRandomIndices(Depth, seed, &NIndex);
    delete S;
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Getting random points from USurface. \n");
        return U_ERROR;
    }
    if(pPL)
    {
        *pPL = new UPointList();
        for(int n=0; n<NIndex; n++) (*pPL)->AddPoint(*vertices[Index[n]]);
    }
    for(int n=0; n<NIndex; n++) Index[n] = vertices[Index[n]]->GetID();

    if(ARatio)
    {
        *ARatio = GetVertexVoronoiArea();
        if(*ARatio==NULL) CI.AddToLog("WARNING: UMinifold::ReconstructFromRandomSubset(). Getting Voronoi areas of input Manifold.\n");
    }
    if(InterpolateVertices(Index, NIndex, true, order, PT, Lamda2)!=U_OK)
    {
        delete[] Index;
        CI.AddToLog("ERROR: UManifold::ReconstructFromRandomSubset(). Interpolating points. \n");
        return U_ERROR;
    }
    delete[] Index;

    if(ARatio && *ARatio)
    {
        double* ARatio2 = GetVertexVoronoiArea();
        if(ARatio2==NULL)
        {
            CI.AddToLog("WARNING: UMinifold::ReconstructFromRandomSubset(). Getting Voronoi areas of input Manifold.\n");
            delete[] *ARatio; ARatio = NULL;
        }
        else
        {
            for(int n=0; n<NVertex; n++) if((*ARatio)[n]>0) (*ARatio)[n] = ARatio2[n]/(*ARatio)[n]; else (*ARatio)[n] = 0.;
            delete[] ARatio2;
        }
    }
    return U_OK;
}
ErrorType UManifold::InterpolateVertices(const double* VertexData, double Thresh, bool FixLower, int order)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL || order==0 || abs(order)>3)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid (NULL) arguments, order = %d . \n", order);
        return U_ERROR;
    }
    int* FixedIDs = new int[NVertex];
    if(FixedIDs==NULL)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Memory allocation error, NVertex = %d . \n", NVertex);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) FixedIDs[n] = -1;
    int NFixed = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(bool(VertexData[n]<Thresh)!=FixLower) continue;
        FixedIDs[NFixed++] = vertices[n]->GetID();
    }
    ErrorType E = InterpolateVertices(FixedIDs, NFixed, true, order, U_PENALTY_NO, 0.);
    delete[] FixedIDs;
    return E;
}
ErrorType UManifold::InterpolateVertices(const int* VertexData, int Thresh, bool FixLower, int order)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL || order==0 || abs(order)>3)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid (NULL) arguments, order = %d . \n", order);
        return U_ERROR;
    }
    int* FixedIDs = new int[NVertex];
    if(FixedIDs==NULL)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Memory allocation error, NVertex = %d . \n", NVertex);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) FixedIDs[n] = -1;
    int NFixed = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(bool(VertexData[n]<Thresh)!=FixLower) continue;
        FixedIDs[NFixed++] = vertices[n]->GetID();
    }
    ErrorType E = InterpolateVertices(FixedIDs, NFixed, true, order, U_PENALTY_NO, 0.);
    delete[] FixedIDs;
    return E;
}

ErrorType UManifold::InterpolateVertices(const int* FFIDs, int NFF, bool IDsFixed, int order, TypePenalty PT, double Lamda2)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(FFIDs==NULL && IDsFixed==false)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid combination of input parameters, FFISa= NULL and IDSFixed = false. \n");
        return U_ERROR;
    }

    if(FFIDs==NULL) NFF = NVertex;
    if(NFF<=0)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid NULL pointer argument or NFF = %d out of range. \n", NFF);
        return U_ERROR;
    }
    if(order==0 || abs(order)>3)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Interpolation order out of range: order = %d out of range (PT=%d). \n", order, (int)PT);
        return U_ERROR;
    }
    if(((PT==U_PENALTY_L1 || PT==U_PENALTY_L2) && Lamda2<=0.) || PT==U_PENALTY_UNKNOWN)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Parameters out of range: PT=%d, Lamdat2=%f. \n", int(PT), Lamda2);
        return U_ERROR;
    }

    int* FixedIDs = new int[NVertex];
    if(FixedIDs==NULL)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Memory allocation, NVertex = %d. \n", NVertex);
        return U_ERROR;
    }
    int NFixed = 0;
    for(int n=0; n<NVertex; n++) FixedIDs[n] = vertices[n]->GetID();
    if(FFIDs)
    {
        if(IDsFixed) // Given IDs are fixed
        {
            NFixed = NFF;
            for(int n=0; n<NFixed; n++) FixedIDs[n]=FFIDs[n]; 
        }
        else        // Given IDs are free : translate array in free indices
        {
            for(int n=0; n<NVertex; n++)
                for(int m=0; m<NFF; m++) if(FixedIDs[n]==FFIDs[m]) {FixedIDs[n]=-1; break;}
            NFixed = 0;
            for(int n=0; n<NVertex; n++) if(FixedIDs[n]>=0) FixedIDs[NFixed++] = FixedIDs[n];
        }
        bool HighFirst = false;
        bool Fabs      = false;
        if(SortArray(FixedIDs, NFixed, Fabs, HighFirst)!=U_OK || SortVertices()!=U_OK)
        {
            delete[] FixedIDs;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Sorting vertex IDs or vertices. \n");
            return U_ERROR;
        }
        int Ndoub = 0;  // Skip double IDs
        for(int n=1, k=0; n<NFixed; n++) if(FixedIDs[n-1]!=FixedIDs[n]) FixedIDs[k++] = FixedIDs[n-1]; else Ndoub++;
        NFixed-=Ndoub;
        FixedIDs[NFixed-1] = FixedIDs[NFixed-1+Ndoub];
    }
    else
    {
        NFixed = NVertex;
    }
    int*    FixedInd = new int[NFixed];
    double* Xco      = new double[3*NVertex];
    if(FixedInd==NULL || Xco==NULL)
    {
        delete[] FixedIDs; delete[] FixedInd; delete[] Xco;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Memory allocation, NFixed = %d, NVertex = %d. \n", NFixed, NVertex);
        return U_ERROR;
    }
    double* Yco      = Xco + NVertex;
    double* Zco      = Yco + NVertex;

    for(int n=0; n<3*NVertex; n++)  Xco[n]      = 0.;
    for(int k=0; k<  NFixed;  k++)  FixedInd[k] = -1;
    for(int n=0,k=0; n<NVertex&&k<NFixed; n++)
    {
        if(vertices[n]->GetID()!=FixedIDs[k]) continue;
        FixedInd[k++] = n;
    }
    delete[] FixedIDs;

    if(FixedInd[NFixed-1]<0)
    {
        delete[] FixedInd; delete[] Xco;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Not all fixed IDs are found. \n");
        return U_ERROR;
    }

    LaplacianType LT   =  order<0 ? U_LAPLACIAN_HARMONIC : U_LAPLACIAN_UNIFORM;
    UMatrixSparse MS   =  this->GetMatrixSparseVertexLaplacian(LT, false);         // Symmetric part

    if(MS.GetError()==U_OK && abs(order)!=1 && PT!=U_PENALTY_L2)                   // L2 case is dealt with efficiently using UMatrixExpand mechanism
    {
        UMatrixSparse  DS    = this->GetMatrixSparseVertexLaplacian(LT, true);     // Diagonal
        UMatrix        Diag  = DS.GetDiagonalAsMatrix(); 

        if(Diag.ApplySquareRoot()!=U_OK || MS.SandwichDiagonal(Diag)!=U_OK) MS = UMatrixSparse(U_ERROR);
        else
        {
            UMatrixSparse MS2 = MS.GetSparseMTM();
            if(abs(order)==2) MS = MS2;
            if(abs(order)==3) MS = GetSparseATB(MS, MS2);
            if(Diag.ApplyInverse()!=U_OK || MS.SandwichDiagonal(Diag)!=U_OK) MS = UMatrixSparse(U_ERROR);
        }
        if(MS.GetError()==U_OK && abs(order)%2) MS=-MS;
    }
    if(MS.GetError()!=U_OK)
    {
        delete[] FixedInd; delete[] Xco;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting Laplacian matrix. \n");
        return U_ERROR;
    }

    int       itol    = 1;
    double    Tol     = 1.e-8;
    int       itmax   = 2*NVertex;
    int       Niter   = 0;
    double    Err     = 0;
    if(PT==U_PENALTY_NO)
    {
        UMatrixSparse RHS = MS.GetSelectedCollumnsSparse(FixedInd, NFixed);
        if(RHS.GetError()!=U_OK)
        {
            delete[] FixedInd; delete[] Xco;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting boundary order or selected rows. \n");
            return U_ERROR;
        }
        if(MS .RemoveSelectedRows(FixedInd, NFixed)!=U_OK || MS .RemoveSelectedCollumns(FixedInd, NFixed)!=U_OK || 
           RHS.RemoveSelectedRows(FixedInd, NFixed)!=U_OK)
        {
            delete[] FixedInd; delete[] Xco;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Removing row(s) or collumn(s).\n");
            return U_ERROR;
        }
        MS.ApplySettings();

        for(int k=0; k<NFixed; k++)
        {
            Xco[k] = -vertices[FixedInd[k]]->Getx();
            Yco[k] = -vertices[FixedInd[k]]->Gety();
            Zco[k] = -vertices[FixedInd[k]]->Getz();
        }
        double*  XRHS = RHS.GetMatVec(Xco, NFixed);
        double*  YRHS = RHS.GetMatVec(Yco, NFixed);
        double*  ZRHS = RHS.GetMatVec(Zco, NFixed);
        if(XRHS==NULL || YRHS==NULL || ZRHS==NULL)
        {
            delete[] FixedInd; delete[] Xco;
            delete[] XRHS; delete[] YRHS; delete[] ZRHS;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting Right hand sides .\n");
            return U_ERROR;
        }
        int       Nintern = NVertex-NFixed;
        ErrorType E       = U_OK;
        if(E==U_OK) E = MS.Solve(XRHS, Xco, Nintern, itol, Tol, itmax, &Niter, &Err);
        if(E==U_OK) E = MS.Solve(YRHS, Yco, Nintern, itol, Tol, itmax, &Niter, &Err);
        if(E==U_OK) E = MS.Solve(ZRHS, Zco, Nintern, itol, Tol, itmax, &Niter, &Err);
        delete[] XRHS; delete[] YRHS; delete[] ZRHS;
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Solving system.\n");
            delete[] FixedInd; delete[] Xco;
            return U_ERROR;
        }

        for(int n=0,k=0,m=0; n<NVertex;n++)
        {
            if(k<NFixed && vertices[n]->GetID()==vertices[FixedInd[k]]->GetID()) {k++; continue;}

            vertices[n]->Setx(Xco[m]);
            vertices[n]->Sety(Yco[m]);
            vertices[n]->Setz(Zco[m]);
            m++;
        }
    }
    else
    {
        if(PT==U_PENALTY_L2)
        {
            UMatrixSparse  DS    = this->GetMatrixSparseVertexLaplacian(LT, true);   // Normalization
            UMatrix        Diag  = DS.GetDiagonalAsMatrix(); 
            ErrorType      E     = Diag.GetError();
            if(E==U_OK)    E     = Diag.ApplySquareRoot();
            if(E==U_OK)    E     = MS.SandwichDiagonal(Diag);
            double*        Buff  = new double[NVertex];
            if(E!=U_OK || Buff==NULL)
            {
                delete[] Buff;
                delete[] FixedInd; delete[] Xco;
                CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting Laplacian diagonal or memory allocation.\n");
                return U_ERROR;
            }
            MS.SetPower(abs(order));
            if((abs(order)%2)) MS=-MS;

            if(E==U_OK) E = Diag.ApplyInverse();
            if(E==U_OK) E = MS.SetDiagonalOffset(Lamda2, FixedInd, NFixed);
            if(E==U_OK) E = MS.ApplySettings();

            for(int n=0; n<NVertex; n++) Buff[n] = 0.;
            for(int k=0; k<NFixed ; k++) Buff[FixedInd[k]] = Lamda2*Diag.GetElement(FixedInd[k],FixedInd[k]) * vertices[FixedInd[k]]->Getx();
            if(E==U_OK) E = MS.Solve(Buff, Xco, NVertex, itol, Tol, itmax, &Niter, &Err);
            for(int n=0; n<NVertex; n++) Xco[n] /= Diag[n];

            for(int k=0; k<NFixed ; k++) Buff[FixedInd[k]] = Lamda2*Diag.GetElement(FixedInd[k],FixedInd[k]) * vertices[FixedInd[k]]->Gety();
            if(E==U_OK) E = MS.Solve(Buff, Yco, NVertex, itol, Tol, itmax, &Niter, &Err);
            for(int n=0; n<NVertex; n++) Yco[n] /= Diag[n];

            for(int k=0; k<NFixed ; k++) Buff[FixedInd[k]] = Lamda2*Diag.GetElement(FixedInd[k],FixedInd[k]) * vertices[FixedInd[k]]->Getz();
            if(E==U_OK) E = MS.Solve(Buff, Zco, NVertex, itol, Tol, itmax, &Niter, &Err);
            for(int n=0; n<NVertex; n++) Zco[n] /= Diag[n];

            delete[] Buff;
            if(E!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Solving system.\n");
                delete[] FixedInd; delete[] Xco;
                return U_ERROR;
            }
        }
        else
        {
            MS.ApplySettings();

            for(int n=0; n<NVertex; n++)
            {
                Xco[n] = vertices[n]->Getx();
                Yco[n] = vertices[n]->Gety();
                Zco[n] = vertices[n]->Getz();
            }

            UFitShapeLasso FSL(NVertex, FixedInd, NFixed, MS, Lamda2);
            if(FSL.MinimizeLasso(Xco, Yco, Zco)!=U_OK)
            {
                CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Split Bregman algorithm failed.\n");
                delete[] FixedInd; delete[] Xco;
                return U_ERROR;
            }
        }
        for(int n=0; n<NVertex;n++) vertices[n]->SetPoint(UVector3(Xco[n],Yco[n],Zco[n]));
    }
    delete[] FixedInd; delete[] Xco;

    return U_OK;
}
ErrorType UManifold::InterpolateVertices(const char* VertexDirections, int order)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    if(VertexDirections==NULL || order==0 || abs(order)>3)
    {
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid NULL pointer argument or order = %d out of range. \n", order);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) 
    {
        if(VertexDirections[n]==0||VertexDirections[n]==1||VertexDirections[n]==2) continue;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Invalid direction at point = %d (dir = %d). \n", n, VertexDirections[n]);
        return U_ERROR;
    }

    int*    FixedInd = new int[NVertex];
    double* Xco      = new double[NVertex];
    if(FixedInd==NULL || Xco==NULL)
    {
        delete[] FixedInd; delete[] Xco;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Memory allocation, NVertex = %d. \n", NVertex);
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++)  {Xco[n] = 0.; FixedInd[n] = -1;}

    LaplacianType LT   =  order<0 ? U_LAPLACIAN_HARMONIC : U_LAPLACIAN_UNIFORM;
    UMatrixSparse MS   =  this->GetMatrixSparseVertexLaplacian(LT, false);         // Symmetric part

    if(MS.GetError()==U_OK && abs(order)!=1)
    {
        UMatrixSparse  DS    = this->GetMatrixSparseVertexLaplacian(LT, true);     // Diagonal
        UMatrix        Diag  = DS.GetDiagonalAsMatrix(); 

        if(Diag.ApplySquareRoot()!=U_OK || MS.SandwichDiagonal(Diag)!=U_OK) MS = UMatrixSparse(U_ERROR);
        else
        {
            UMatrixSparse MS2 = MS.GetSparseMTM();
            if(abs(order)==2) MS = MS2;
            if(abs(order)==3) MS = GetSparseATB(MS, MS2);
            if(Diag.ApplyInverse()!=U_OK || MS.SandwichDiagonal(Diag)!=U_OK) MS = UMatrixSparse(U_ERROR);
        }
        if(MS.GetError()==U_OK && abs(order)%2) MS=-MS;
    }
    if(MS.GetError()!=U_OK)
    {
        delete[] FixedInd; delete[] Xco;
        CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting Laplacian matrix. \n");
        return U_ERROR;
    }

    for(int dir=0; dir<3; dir++)
    {
        int NFixed = 0;
        for(int n=0; n<NVertex; n++) if(VertexDirections[n]!=dir) FixedInd[NFixed++] = n;
        if(NFixed<=0 || NFixed>=NVertex) continue;

        int       itol    = 1;
        double    Tol     = 1.e-10;
        int       itmax   = 2*NVertex;
        int       Niter   = 0;
        double    Err     = 0;

        UMatrixSparse MSdir = MS;
        UMatrixSparse RHS   = MS.GetSelectedCollumnsSparse(FixedInd, NFixed);

        if(RHS  .GetError()                              !=U_OK ||
           MSdir.RemoveSelectedCollumns(FixedInd, NFixed)!=U_OK ||
           MSdir.RemoveSelectedRows    (FixedInd, NFixed)!=U_OK ||
           RHS  .RemoveSelectedRows    (FixedInd, NFixed)!=U_OK)
        {
            delete[] FixedInd; delete[] Xco;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting boundary order or selected rows or removing row(s) or collumn(s), dir =%d.\n", dir);
            return U_ERROR;
        }
        MSdir.ApplySettings();

        for(int k=0; k<NFixed; k++) Xco[k] = - (*vertices[FixedInd[k]])[dir];
        double*  XRHS = RHS.GetMatVec(Xco, NFixed);
        if(XRHS==NULL)
        {
            delete[] FixedInd; delete[] Xco; delete[] XRHS;
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Getting Right hand side (dir=%d) .\n", dir);
            return U_ERROR;
        }
        int      Nintern = NVertex-NFixed;
        if(MSdir.Solve(XRHS, Xco, Nintern, itol, Tol, itmax, &Niter, &Err)!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::InterpolateVertices(). Solving system.\n");
            delete[] FixedInd; delete[] Xco; delete[] XRHS;
            return U_ERROR;
        }

        for(int n=0,k=0,m=0; n<NVertex;n++)
        {
            if(VertexDirections[n]!=dir) {k++; continue;}

            switch(dir)
            {
            case 0: vertices[n]->Setx(Xco[m++]); break;
            case 1: vertices[n]->Sety(Xco[m++]); break;
            case 2: vertices[n]->Setz(Xco[m++]); break;
            }
        }
    }
    delete[] FixedInd; delete[] Xco;

    return U_OK;
}

ErrorType UManifold::ExpandSphere(UVector3 Axis)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphere(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphere(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(Axis==UVector3())
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphere(). Invalid NULL vector argument. \n");
        return U_ERROR;
    }

    UEuler Rot(Axis^UVector3(0.,0.,1.), Axis.GetTheta());

    for(int n=0; n<NVertex; n++)
    {
        UVector3   p   = Rot.xfm    (*(vertices[n]));
        double     tt  = p.GetTheta(); tt  = PI* pow( fabs(tt/PI), 1./3. );
        double     ff  = p.GetFi();
        *(vertices[n]) = Rot.xfmInv(UVector3(sin(tt)*cos(ff), sin(tt)*sin(ff), cos(tt)));
    }
    return U_OK;
}
ErrorType UManifold::ExpandSphereAcos(int IDNPole, int IDSPole, double Lam)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphereAcos(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphereAcos(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(Lam==0.) return U_OK;
    if(Lam<0)
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphereAcos(). Lamda parameter should be positive (Lam = %f) .\n", Lam);
        return U_ERROR;
    }
    UVector3 N = GetPointFromID(IDNPole);
    UVector3 S = GetPointFromID(IDSPole);
    
    if(N.GetNorm()<1.e-6 || S.GetNorm()<1.e-6 || IDNPole==IDSPole)
    {
        CI.AddToLog("ERROR: UManifold::ExpandSphereAcos(). Invalid pole IDs,  (%d,%d). \n", IDNPole,IDSPole);
        return U_ERROR;
    }
    UVector3 Org = (N+S) * 0.5;

    for(int n=0; n<NVertex; n++)
    {
        UVector3    p   = *(vertices[n]) - Org;
        double      tt  = p.GetTheta();
        double      st  = 1. - 2*tt/PI;
        double      ta  = acos(  MAX(-1.,MIN(1.,st))  );
                    tt  = (1.-Lam)*tt + Lam*ta;
        double      ff  = p.GetFi();
        *(vertices[n])  = UVector3(sin(tt)*cos(ff), sin(tt)*sin(ff), cos(tt));
    }
    return U_OK;
}

ErrorType UManifold::ProjectCircle(int ifaceIndex, int CenterVertexID, bool EqualizeBoundary, bool XfmSqrt, bool RepairFailures, bool Harmonic)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(ifaceIndex<0 || ifaceIndex>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Argument out of range, ifaceIndex = %d .\n", ifaceIndex);
        return U_ERROR;
    }
    int CenterIndex = -1;
    if(CenterVertexID>=0)
    {
        CenterIndex = FindVertex(CenterVertexID);
        if(CenterIndex<0 || CenterIndex>=NVertex)
        {
            CI.AddToLog("ERROR: UManifold::ProjectCircle(). CenterVertexID not found (ID = %d) .\n", CenterVertexID);
            return U_ERROR;
        }
    }
    UMatrixSparse  MS = Harmonic ? this->GetMatrixSparseVertexLaplacian(U_LAPLACIAN_HARMONIC, false) :
                                   this->GetMatrixSparseVertexLaplacian(U_LAPLACIAN_UNIFORM , false);
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Getting connectivity matrix. \n");
        return U_ERROR;
    }

    int NBound = faces[ifaceIndex]->GetNEdge();    // Number of boundary points (set on the unit circle)
    int NInter = NVertex - NBound;                 // Internal points (of which coordinates are to be found)
    if(NBound<3)
    {
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Face has too few edges (NBound = %d) .\n", NBound);
        return U_ERROR;
    }

    int* BoundInd = new int[NBound]; // Boundary indices
    int* InterInd = new int[NInter]; // Mapping from internal index to original
    if(BoundInd==NULL || InterInd==NULL)
    {
        delete[] BoundInd; delete[] InterInd;
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Memory allocation, NVertex = %d .\n", NVertex);
        return U_ERROR;
    }

/* Find indices of boundary nodes and store them in BoundInd[] array */
    UFaceEdgeIterator FEI(faces[ifaceIndex]);
    int k=0;
    for(UEdge*  E = FEI.GetStart(); E!=NULL; E=FEI.GetNext(), k++)
    {
        int Ind  = -1;
        int ID   = E->GetOrg()->GetID();
        if(E->GetOrg()) Ind = FindVertex(ID);
        if(Ind<0 || Ind>=NVertex)
        {
            delete[] BoundInd; delete[] InterInd;
            CI.AddToLog("ERROR: UManifold::ProjectCircle(). Finding boundary point, k=%d .\n", k);
            return U_ERROR;
        }
        if(CenterVertexID>=0 && CenterVertexID==ID)
        {
            delete[] BoundInd; delete[] InterInd;
            CI.AddToLog("ERROR: UManifold::ProjectCircle(). New Center point is on boundary (CenterVertexID=%d). \n", CenterVertexID);
            return U_ERROR;
        }
        BoundInd[k] = Ind;
    }
    UMatrixSparse  RHS = MS.GetSelectedRowsSparse(BoundInd, NBound);
    int*    BoundOrder = GetOrderIndexArray(BoundInd,NBound,false,false);
    if(RHS.GetError()!=U_OK || BoundOrder==NULL)
    {
        delete[] InterInd;
        delete[] BoundInd; delete[] BoundOrder;
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Getting boundary order or selected rows. \n");
        return U_ERROR;
    }

/* Determine indices of internal nodes and store them in InterInd[] */
    for(int n=0, m=0, k=0; n<NVertex; n++)
    {
        if(k<NBound && n==BoundInd[BoundOrder[k]]) {k++; continue;}
        InterInd[m++] = n;
    }
    delete[] BoundOrder;

    if(MS .RemoveSelectedCollumns(BoundInd, NBound)!=U_OK ||
       MS .RemoveSelectedRows    (BoundInd, NBound)!=U_OK ||
       RHS.RemoveSelectedCollumns(BoundInd, NBound)!=U_OK)
    {
        delete[] InterInd;  delete[] BoundInd;
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Removing row(s) or collumn(s).\n");
        return U_ERROR;
    }
    MS.ApplySettings();

/* Compute coordinates of boundary points */
    double* Xco = new double[NBound];
    double* Yco = new double[NBound];
    if(Xco==NULL || Yco==NULL)
    {
        delete[] InterInd;
        delete[] BoundInd;  delete[] Xco; delete[] Yco;
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Memory allocation, NBound = %d \n", NBound);
        return U_ERROR;
    }

    for(int k=0; k<NBound; k++)
    {
        double fi = k*PI2/double(NBound) ;
        Xco[k]    = -cos(fi);
        Yco[k]    = -sin(fi);
    }
    double*  XRHS = RHS.GetMatTVec(Xco, NBound);
    double*  YRHS = RHS.GetMatTVec(Yco, NBound);
    double*  Xnew = new double[NInter];
    double*  Ynew = new double[NInter];
    if(XRHS==NULL || YRHS==NULL || Xnew==NULL || Ynew==NULL)
    {
        delete[] XRHS; delete[] YRHS;
        delete[] InterInd; delete[] BoundInd;  delete[] Xnew; delete[] Ynew;
        delete[] Xco;  delete[] Yco;
        CI.AddToLog("ERROR: UManifold::ProjectCircle(). Memory allocation, Xnew, Ynew, NVertex = %d .\n", NVertex);
        return U_ERROR;
    }
    for(int n=0; n<NInter; n++) {Xnew[n] = Ynew[n] = 0.;}

    int     itol   = 1;
    double  Tol    = 1.e-10;
    int     itmax  = 2*NVertex;
    int     Niter  = 0;
    double  Err    = 0;

    MS.SolveT(XRHS, Xnew, NInter, itol, Tol, itmax, &Niter, &Err);
    MS.SolveT(YRHS, Ynew, NInter, itol, Tol, itmax, &Niter, &Err);
    delete[] XRHS; delete[] YRHS;

    for(int n=0; n<NInter; n++)
    {
        vertices[InterInd[n]]->Setx(Xnew[n]);
        vertices[InterInd[n]]->Sety(Ynew[n]);
        vertices[InterInd[n]]->Setz(0.);
    }
    for(int k=0; k<NBound; k++)
    {
        vertices[BoundInd[k]]->Setx(-Xco[k]);
        vertices[BoundInd[k]]->Sety(-Yco[k]);
        vertices[BoundInd[k]]->Setz(0.);
    }
    delete[] InterInd; delete[] BoundInd;  delete[] Xnew; delete[] Ynew;
    delete[] Xco;  delete[] Yco;

/*   The Moebius transform in the complex plane is simply: z' = (z-a) / (1- (a*) z)
     To express it in real coordinates one finds
     z' = (z-a) / (1- (a*) z) = (z-a - a z*z + a2 z*) / (1- 2 Re(a* z)  + z*z a*a)

     a2     = (a_x + i a_y) * (a_x + i a_y) = (a_x)2 - (a_y)2  + i (2 a_x a_y)
     a2 z*  = ( ((a_x)2 - (a_y)2) x + 2 a_x a_y y, -((a_x)2 - (a_y)2) y + 2 a_x a_y x )

     Finally, for numerator and denominator:
     N = (x - a_x(1+x2+y2) + ((a_x)2 - (a_y)2) x + 2 a_x a_y y   , y-a_y(1+x2+y2) -((a_x)2 - (a_y)2) y + 2 a_x a_y x )
     D =  1 - 2 (a_x x + a_y y) + (x2 + y2)(a_x2 + a_y2)
*/
    if(CenterIndex>=0)
    {
        double   Ax  = vertices[CenterIndex]->Getx() - 1./sqrt(2.*NVertex);
        double   Ay  = vertices[CenterIndex]->Gety() - 1./sqrt(2.*NVertex);
        double   Axx = Ax*Ax;
        double   Ayy = Ay*Ay;
        double   Axy = Ax*Ay;

        for(int n=0; n<NVertex; n++)
        {
            double  X  = vertices[n]->Getx();    // Moebius transform
            double  Y  = vertices[n]->Gety();
            double  XX = X*X;
            double  YY = Y*Y;

            double  D  = 1 - 2*(Ax*X + Ay*Y) + (XX+YY)*(Axx+Ayy);
            double  Nx = X - Ax*(1+XX+YY)    + (Axx - Ayy)*X + 2*Axy*Y;
            double  Ny = Y - Ay*(1+XX+YY)    - (Axx - Ayy)*Y + 2*Axy*X;
            double  Rh = sqrt(Nx*Nx+Ny*Ny);
            if(Rh==0.)
            {
                *(vertices[n]) = UVector3(0., 0., 0.);
                continue;
            }
            if(EqualizeBoundary)
            {
                double  Xb  = Nx/Rh;  // Inverse Moebius transform of boundary
                double  Yb  = Ny/Rh;

                double  Db  = 1  + 2*(Ax*Xb + Ay*Yb)    + (Xb*Xb+Yb*Yb)*(Axx+Ayy);
                double  Nxb = Xb +    Ax*(1+Xb*Xb+Yb*Yb)+ (Axx - Ayy)*Xb + 2*Axy*Yb;
                double  Nyb = Yb +    Ay*(1+Xb*Xb+Yb*Yb)- (Axx - Ayy)*Yb + 2*Axy*Xb;

                Rh = Rh/D;
                *(vertices[n]) = UVector3((Nxb/Db)*Rh, (Nyb/Db)*Rh, 0.);
            }
            else
                *(vertices[n]) = UVector3(Nx/D, Ny/D, 0.);
        }
    }
    if(XfmSqrt)
    {
        for(int n=0; n<NVertex; n++)
        {
            double Rh = sqrt(vertices[n]->GetNorm());
            if(Rh<1.e-14) continue;
            *(vertices[n]) = *(vertices[n]) / Rh;
        }
    }

    int NFail   = TestProjectedFaces(ifaceIndex, (RepairFailures?100:-1));
    if(NFail!=0)
    {
        if(NFail<0)
        {
            CI.AddToLog("ERROR: UManifold::ProjectCircle(). Face orientation test failed.\n");
            return U_ERROR;
        }
        CI.AddToLog("WARNING: UManifold::ProjectCircle(). There are %d faces with reversed orientation. \n", NFail);
        if(RepairFailures==true)
        {
            int NRepair = RepairProjectedTriangles(ifaceIndex);
            if(NRepair<0)
            {
                CI.AddToLog("ERROR: UManifold::ProjectCircle(). Face orientation test failed.\n");
                return U_ERROR;
            }
            CI.AddToLog("Note: UManifold::ProjectCircle(). There are %d faces with reversed orientation that are 'repaired'. \n", NRepair);
            NFail   = TestProjectedFaces(ifaceIndex, 100);
            if(NFail<0)
            {
                CI.AddToLog("ERROR: UManifold::ProjectCircle(). Face orientation test failed.\n");
                return U_ERROR;
            }
            if(NFail!=0) CI.AddToLog("WARNING: UManifold::ProjectCircle(). There are %d faces with reversed orientation left. \n", NFail);
        }
    }
    return U_OK;
}
int UManifold::RepairProjectedTriangles(int ifaceIndex) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RepairProjectedTriangles(). Object NULL or erroneous. \n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RepairProjectedTriangles(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(ifaceIndex<0 || ifaceIndex>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::RepairProjectedTriangles(). Argument out of range, iface = %d .\n", ifaceIndex);
        return U_ERROR;
    }
    double   DetFace = faces[ifaceIndex]->GetArea(2);
    if(DetFace==0.)
    {
        CI.AddToLog("ERROR: UManifold::RepairProjectedTriangles(). Face degenerate, index = %d .\n", ifaceIndex);
        return U_ERROR;
    }

    int  NRepair  = 0;
    for(int n=0; n<NFace; n++)
    {
        if(n==ifaceIndex || faces[n]==NULL) continue;
        UFace*   F    = faces[n];
        UEdge*   E[3] = {0,0,0};
        UVector2 V[3];
        E[0]       = F   ->GetEdge();
        E[1]       = E[0]->GetLNext();
        E[2]       = E[1]->GetLNext();
        V[0]       = E[0]->GetOrg()->Pz();
        V[1]       = E[1]->GetOrg()->Pz();
        V[2]       = E[2]->GetOrg()->Pz();
        double Det = GetDeterminant(V[0], V[1], V[2]);

        if((Det>=0&&DetFace>0) || (Det<=0&&DetFace<0))
        {
            UFaceEdgeIterator FEI(F);
            int  NNeig = FEI.GetNNeighbour();
            if(NNeig!=3)
            {
                CI.AddToLog("WARNING: UManifold::RepairProjectedTriangles(). Skipping face %d with %d edges. \n", F->GetID(), NNeig);
                continue;
            }
            int kmid = -1;
                 if(Intersect(V[0], V[1], V[2], UVector2())) kmid = 2;
            else if(Intersect(V[1], V[2], V[0], UVector2())) kmid = 0;
            else if(Intersect(V[2], V[0], V[1], UVector2())) kmid = 1;
            if(kmid<0)
            {
                CI.AddToLog("WARNING: UManifold::RepairProjectedTriangles(). Skipping triangle %d because it is degenerated. \n", F->GetID());
                continue;
            }

            UVector2 UU2 = (V[(kmid+1)%3]-V[(kmid+2)%3]).GetRot90();
            double   Den =  UU2&V[kmid];
            if(fabs(Den)<1.e-10)
            {
                CI.AddToLog("WARNING: UManifold::RepairProjectedTriangles(). Skipping triangle %d, zero denominator. \n", F->GetID());
                continue;
            }
            double    Mu  = (1-5./NVertex) * (V[(kmid+2)%3]&UU2)/ Den;
            *(E[kmid]->GetOrg()) = *(E[kmid]->GetOrg()) * Mu;
            NRepair++;
        }
    }
    return NRepair;
}
int UManifold::TestProjectedFaces(int ifaceIndex, int MaxNErrorLog) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::TestProjectedFaces(). Object NULL or erroneous. \n");
        return -1;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::TestProjectedFaces(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return -1;
    }
    if(ifaceIndex<0 || ifaceIndex>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::TestProjectedFaces(). Argument out of range, iface = %d .\n", ifaceIndex);
        return -1;
    }
    double   DetFace = faces[ifaceIndex]->GetArea(2);
    if(DetFace==0.)
    {
        CI.AddToLog("ERROR: UManifold::TestProjectedFaces(). Face degenerate, index = %d .\n", ifaceIndex);
        return -1;
    }

    int  Nfail  = 0;
    for(int n=0; n<NFace; n++)
    {
        if(n==ifaceIndex) continue;
        double   Det = faces[n]->GetArea(2);

        if((Det>=0&&DetFace>0) || (Det<=0&&DetFace<0))
        {
            Nfail++;
            if(Nfail<=MaxNErrorLog)
                CI.AddToLog("ERROR: UManifold::TestProjectedFaces(). Determinant Face %d is %g .\n", faces[n]->GetID(), Det);
        }
    }
    return Nfail;
}
int* UManifold::GetReverselyProjectedFaceIndices(int ifaceIndex, int* NReversed) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(ifaceIndex<0 || ifaceIndex>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Argument out of range, iface = %d .\n", ifaceIndex);
        return NULL;
    }
    if(NReversed==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Invalid NULL Argument.\n");
        return NULL;
    }
    for(int n=0; n<NVertex; n++)
    {
        if(fabs((*(vertices[n]))[2])<1.e-8) continue;
        CI.AddToLog("WARNING: UManifold::GetReverselyProjectedFaceIndices(). Not all faces are projected onto z=0 -plane. First exception: n=%d .\n", n);
        break;
    }
    double   DetFace = faces[ifaceIndex]->GetArea(2);
    if(DetFace==0.)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Face degenerate, index = %d .\n", ifaceIndex);
        return NULL;
    }
    int NRev = TestProjectedFaces(ifaceIndex, -1);
    if(NRev<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). No revered faces found (NRev = %d ).\n", NRev);
        return NULL;
    }
    int* RevIndex = new int[NRev];
    if(RevIndex==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetReverselyProjectedFaceIndices(). Memory allocation (NRev = %d ). \n", NRev);
        return NULL;
    }
    for(int n=0, irev=0; n<NFace; n++)
    {
        if(n==ifaceIndex) continue;
        double   Det = faces[n]->GetArea(2);

        if((Det>=0&&DetFace>0) || (Det<=0&&DetFace<0)) RevIndex[irev++] = n;
    }
    *NReversed = NRev;
    return RevIndex;
}

ErrorType UManifold::ProjectSphereInit(int dir, double Level, bool CenterDense, bool ApplySqrtXfm, bool RepairFailures, bool Harmonic, bool CompensateCoord)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    int**    VertIDs    = NULL;
    int*     NPointsCon = NULL;
    int      NCont      = 0;
    double   CoMin      = 0.;
    double   CoMax      = 0.;
    if(GetCrossSection(dir, Level, &VertIDs, &NPointsCon, &NCont, &CoMin, &CoMax)!=U_OK || NPointsCon[0]<=0)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Getting cross-section .\n");
        return U_ERROR;
    }

/* "Rotate" first contour to standard position */
    UVector3 Dir;
    switch(dir)
    {
    case 0: Dir = UVector3(0.,1.,0.); break;
    case 1: Dir = UVector3(0.,0.,1.); break;
    case 2: Dir = UVector3(1.,0.,0.); break;
    }
    int IDfirst = GetClosestDirVertexID(VertIDs[0], NPointsCon[0], Dir);
    int Ifirst  = -1;
    if(IDfirst>=0)
    {
        for(int k=0; k<NPointsCon[0]; k++)
        {
            if(VertIDs[0][k]!=IDfirst) continue;
            Ifirst = k;
            break;
        }
    }
    if(Ifirst<0)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Finding start of cross-section .\n");
        return U_ERROR;
    }
    int  NP0 = NPointsCon[0];

    int* Buf = new int[NP0];
    if(Buf==NULL)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Memory allocation (NP0=%d) .\n", NP0);
        return U_ERROR;
    }
    for(int k=0; k<NP0; k++) Buf[k]        = VertIDs[0][k];
    for(int k=0; k<NP0; k++) VertIDs[0][k] = Buf[(k+Ifirst)%NP0];
    delete[] Buf;

    UFace*     LRFace[2] = {NULL, NULL};
    UManifold** MLR      = GetSplittedManifolds(VertIDs[0], NPointsCon[0], LRFace, false);
    if(MLR==NULL || MLR[0]==NULL || MLR[1]==NULL || LRFace[0]==NULL || LRFace[1]==NULL)
    {
        for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
        if(MLR) {delete MLR[0]; delete[] MLR[1];} delete MLR;
        CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Splitting manifold into two parts. \n");
        return U_ERROR;
    }
    if( MLR[0]->GetMaxCoord(dir) < MLR[1]->GetMaxCoord(dir))
    {
        UManifold* Mdum = MLR[0];
        MLR[0]          = MLR[1];
        MLR[1]          = Mdum;
        UFace*     Fdum = LRFace[0];
        LRFace[0]       = LRFace[1];
        LRFace[1]       = Fdum;
    }

// Project each half into unit circle
    for(int k=0; k<2; k++)
    {
        int IDs   = MLR[k]->GetVertexIDExtremeCoord(dir, k==0 );
        int iface = MLR[k]->FindFace(LRFace[k]->GetID());

        bool EqualizeBoundary = false;
        if(CenterDense==false) IDs = -1;
        else                   EqualizeBoundary = true;
        if(iface<0 || MLR[k]->ProjectCircle(iface, IDs, EqualizeBoundary, ApplySqrtXfm, RepairFailures, Harmonic)!=U_OK)
        {
            if(iface<0)
                CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Face not found, ID = %d, Part %d .\n", LRFace[k]->GetID(), k);
            else
                CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Projecting part %d into unit circle. \n", k);

            for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
            delete MLR[0]; delete MLR[1]; delete[] MLR;
            return U_ERROR;
        }
    }

// Find 'phase difference'
    int NEdgeCross = LRFace[0]->GetNEdge();
    int ID0        = LRFace[0]->GetEdge()->GetOrg()->GetID();
    int NRot       = 0;
    UFaceEdgeIterator FEI(LRFace[1]);
    for(UEdge* E=FEI.GetStart(); E; E=FEI.GetNext(), NRot++)
        if(E->GetOrg()->GetID()==ID0) break;
    double PhaDif = NRot*PI2/NEdgeCross;

// Project into unit sphere
    UPointList* PL = NULL;
    if(CompensateCoord)
    {
        PL = this->GetPointList();
        if(PL==NULL || PL->GetError()!=U_OK)
        {
            delete PL;
            for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
            delete MLR[0]; delete MLR[1]; delete[] MLR;
            CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Creating UPointList.\n");
            return U_ERROR;
        }
    }
    for(int n=0; n<NVertex; n++)
    {
        int ID  = vertices[n]->GetID();
        int n0  = MLR[0]->FindVertex(ID);

        UVector3 p;
        double   t=0, f=0;
        if(n0>=0)
        {
            p   = *(MLR[0]->vertices[n0]);
            t   = p.GetNorm()*PI/2;
            f   = p.GetFi();
        }
        else
        {
            int n1 = MLR[1]->FindVertex(ID);
            if(n1>=0)
            {
                p  = *(MLR[1]->vertices[n1]);
                t  = PI - p.GetNorm()*PI/2;
                f  = -(p.GetFi()-PhaDif);
            }
            else
            {
                for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;
                delete MLR[0]; delete MLR[1]; delete[] MLR;
                CI.AddToLog("ERROR: UManifold::ProjectSphereInit(). Finding point %d on split hemispheres. \n", ID);
                return U_ERROR;
            }
        }
        *(vertices[n]) = UVector3(sin(t)*cos(f), sin(t)*sin(f), cos(t));
    }
    delete MLR[0]; delete MLR[1]; delete[] MLR;

    if(CompensateCoord && CoMin<CoMax)
    {
        for(int n=0; n<NPointsCon[0]; n++)
        {
            int    ip   = FindVertex(VertIDs[0][n]);
            double Coor = PL->GetPoint(ip)[dir]-Level;
            double Alfa = (Coor-CoMin)/((CoMax-CoMin)*sqrt(fabs(NVertex+1.)));

            for(int nn=0; nn<NVertex; nn++)
            {
                UVector2 V1 = vertices[ip]->Pz();
                UVector2 V2 = vertices[nn]->Pz();

                if(Angle(V1, V2)>PI/NPointsCon[0]) continue;

                double f = vertices[nn]->GetFi();
                double t = vertices[nn]->GetTheta();

                t -= Alfa * t * (t-PI);
                *(vertices[nn]) = UVector3(sin(t)*cos(f), sin(t)*sin(f), cos(t));
            }

        }
    }
    delete PL;
    for(int ic=0; ic<NCont; ic++) delete[] VertIDs[ic]; delete[] VertIDs; delete[] NPointsCon;

    return U_OK;
}

ErrorType UManifold::ProjectSphereExpand(int dir)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Invalid dir argument, dir=%d. \n", dir);
        return U_ERROR;
    }

    double*   CoExt  = new double[NVertex];
    if(CoExt==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Memory allocation, NVertex = %d . \n", NVertex);
        return U_ERROR;
    }
    int NVNN = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(vertices[n]==NULL) continue;
        CoExt[n] = (*(vertices[NVNN]))[dir];
        NVNN++;
    }
    double CoThr1 = GetUpperQuantile(CoExt, NVNN, 0.1);
    double CoThr2 = GetUpperQuantile(CoExt, NVNN, 0.9);
    delete[] CoExt;

    UManifold MSphereRaw      = *this;
    UVector3  Center          = GetCenter();
    bool      CenterDense     = false;
    bool      ApplySqrtXfm    = false;
    bool      RepairFailures  = false;
    bool      Harmonic        = false;
    bool      CompensateCoord = false;

    if(MSphereRaw.ProjectSphereInit(dir, Center[dir], CenterDense, ApplySqrtXfm, RepairFailures, Harmonic, CompensateCoord)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Projecting copy on sphere, dir=%d. \n", dir);
        return U_ERROR;
    }
    UVector3 BMin, BMax;
    GetMinMaxBox(&BMin, &BMax);

    int Index1 = -1; double Dmin1 = (BMax-BMin).GetNorm();
    int Index2 = -1; double Dmin2 = (BMax-BMin).GetNorm();

    for(int n=0; n<MSphereRaw.GetNVertex(); n++)
    {
        if(vertices[n]==NULL) continue;
        double Test = MSphereRaw.vertices[n]->GetShortestEdgeLength();
        double Coor = (*(vertices[n]))[dir];

        if(Coor>=CoThr1 && Test<Dmin1)
        {
            Dmin1  = Test;
            Index1 = n;
        }
        if(Coor<=CoThr2 && Test<Dmin2)
        {
            Dmin2  = Test;
            Index2 = n;
        }
    }

    if(Index1<0 || Index1>=NVertex ||
       Index2<0 || Index2>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Vertices not found, Index1=%d,  Index2=%d  . \n", Index1, Index2);
        return U_ERROR;
    }

    if(ProjectSphere(dir)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Projecting on sphere. \n");
        return U_ERROR;
    }
    UVector3 Ax1 = *(vertices[Index1]);
    UVector3 Ax2 = *(vertices[Index2]);

    if(ExpandSphere(Ax1)!=U_OK || ExpandSphere(Ax2)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereExpand(). Expanding sphere. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UManifold::ProjectSphere(int dir)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(dir<0 || dir>=3)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Invalid dir argument, dir=%d. \n", dir);
        return U_ERROR;
    }

    UMatrixSparse  MS = this->GetMatrixSparseVertexConnectivity();
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Getting connectivity matrix. \n");
        return U_ERROR;
    }
    double* Xve = new double[3*NVertex];
    double* Bve = new double[3*NVertex];
    if(Xve==NULL || Bve==NULL)
    {
        delete[] Xve; delete[] Bve;
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Memory allocation, NVertex = %d .\n", NVertex);
        return U_ERROR;
    }


    bool CenterDense     =  true;
    bool ApplySqrtXfm    =  true;
    bool RepairFailures  =  true; 
    bool Harmonic        = false;
    bool CompensateCoord = false;        
    if(ProjectSphereInit(dir, GetCenter()[dir], CenterDense, ApplySqrtXfm, RepairFailures, Harmonic, CompensateCoord)!=U_OK)
    {
        delete[] Xve; delete[] Bve;
        CI.AddToLog("ERROR: UManifold::ProjectSphere(). Initializing iterations.\n");
        return U_ERROR;
    }
    double*   Xco  = Xve;
    double*   Yco  = Xve+  NVertex;
    double*   Zco  = Xve+2*NVertex;

    for(int n=0; n<NVertex; n++)
    {
        UVertex* V = vertices[n];
        Xco[n]     = V->Getx();
        Yco[n]     = V->Gety();
        Zco[n]     = V->Getz();
    }

// Gauss-Seidel iterations
    double    ResSum    = NVertex;
    const int MAXITER   = 10000;
    double*   XcoA      = Bve;
    double*   YcoA      = Bve+  NVertex;
    double*   ZcoA      = Bve+2*NVertex;
    for(int NIT =0; NIT<MAXITER; NIT++)
    {
        MS.MatTVec(Xco, NVertex, XcoA);
        MS.MatTVec(Yco, NVertex, YcoA);
        MS.MatTVec(Zco, NVertex, ZcoA);

        double SumX=0, SumY=0, SumZ=0;
        for(int n=0; n<NVertex; n++)
        {
            double Alf = sqrt( XcoA[n]*XcoA[n] + YcoA[n]*YcoA[n] + ZcoA[n]*ZcoA[n] );
            XcoA[n]   /= Alf;
            YcoA[n]   /= Alf;
            ZcoA[n]   /= Alf;
            SumX      += fabs(XcoA[n]-Xco[n]);
            SumY      += fabs(YcoA[n]-Yco[n]);
            SumZ      += fabs(ZcoA[n]-Zco[n]);
        }
        if(NIT>100 && SumX+SumY+SumZ>ResSum) break;
        ResSum = SumX+SumY+SumZ;
        for(int n=0; n<NVertex; n++)
        {
            Xco[n] = XcoA[n];
            Yco[n] = YcoA[n];
            Zco[n] = ZcoA[n];
        }
    }
    for(int n=0; n<NVertex; n++)
    {
        vertices[n]->Setx(Xco[n]);
        vertices[n]->Sety(Yco[n]);
        vertices[n]->Setz(Zco[n]);
    }

// Local Newton iterations
    ResSum  = NVertex;
    int NVS = GetNearPrime(int(sqrt(double(NVertex))));
    int nn  = 0;
    for(int NIT=0; NIT<10; NIT++)
    {
        if(ResSum<1.e-8*NVertex) break;
        for(int n=0; n<NVertex; n++)
        {
            nn = (nn+NVS)%NVertex;
            if(OptimizePointOnSphere(&MS, nn)!=U_OK)
            {
                delete[] Bve; delete[] Xve;
                CI.AddToLog("ERROR: UManifold::ProjectSphere(). Updating vertex %d .\n");
                return U_ERROR;
            }
        }
        for(int n=0; n<NVertex; n++)
        {
            Xco[n] = vertices[n]->Getx();
            Yco[n] = vertices[n]->Gety();
            Zco[n] = vertices[n]->Getz();
        }
        MS.MatTVec(Xco, NVertex, XcoA);
        MS.MatTVec(Yco, NVertex, YcoA);
        MS.MatTVec(Zco, NVertex, ZcoA);
        ResSum = 0;
        for(int n=0; n<NVertex; n++)
        {
            UVector3 X (Xco [n], Yco [n], Zco [n]);  X .Normalize();
            UVector3 XA(XcoA[n], YcoA[n], ZcoA[n]);  XA.Normalize();
            ResSum      += (X^XA).GetNorm2();
        }
    }
    delete[] Bve; delete[] Xve;
    return U_OK;
}
ErrorType  UManifold::ProjectSphereConformal(int FaceIDSouth, int VertexIDNorth, int IDxaxis, bool MinimizeMedianZ, double* MultPar, double* BestCost)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<0 || vertices==NULL) ||
        (NFace  <0 || faces   ==NULL) ||
        (NQEdge <0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(this->IsTriangulation()!=true)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Object should be a triangulation (but contains faces of more than three edges). \n");
        return U_ERROR;
    } 
    if(this->RemoveFlatTriangles()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Removing degenerated triangles . \n");
        return U_ERROR;
    }
    int indface   = FindFace(FaceIDSouth);
    if(indface<0 || indface>=NFace)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Invalid face ID argument, FaceIDSouth=%d. \n", FaceIDSouth);
        return U_ERROR;
    }
    int indvertex = -1;
    if(VertexIDNorth>=0)
    {
        indvertex = FindVertex(VertexIDNorth);
        if(indvertex<0 || indvertex>=NVertex)
        {
            CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Invalid vertex ID argument, VertexIDNorth=%d. \n", VertexIDNorth);
            return U_ERROR;
        }
    }
    int indA = FindVertex(faces[indface]->GetEdge(0)->GetOrg()->GetID());
    int indB = FindVertex(faces[indface]->GetEdge(1)->GetOrg()->GetID());
    int indC = FindVertex(faces[indface]->GetEdge(2)->GetOrg()->GetID());

    if(indA<0 || indB<0 || indC<0)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Surrounding vertices not all found (indA, indB, indC) = (%d,%d,%d) .\n", indA, indB, indC);
        return U_ERROR;
    }

    UVector3 A = *(vertices[indA]);
    UVector3 B = *(vertices[indB]);
    UVector3 C = *(vertices[indC]);

    if(  ( (A-B)==UVector3() ) || ( (B-C)==UVector3() ) || ( (C-A)==UVector3() ) )
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Not all surrounding vertices are different from each other.\n");
        return U_ERROR;
    }
    double  th = (C-A)&(B-A)/(A-B).GetNorm2();
    UVector3 D = A + th*(B-A);


    UMatrixSparse MS = this->GetMatrixSparseVertexLaplacian(U_LAPLACIAN_HARMONIC, false);
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Getting connectivity matrix. \n");
        return U_ERROR;
    }
    double* Xco = new double[NVertex];
    double* Yco = new double[NVertex];
    double* BX  = new double[NVertex];
    double* BY  = new double[NVertex];
    if(Xco==NULL || Yco==NULL || BX==NULL || BY==NULL)
    {
        delete[] Xco; delete[] Yco; delete[] BX; delete[] BY;
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Memory allocation, NVertex = %d .\n", NVertex);
        return U_ERROR;
    }

/* Set right hand side and solve system */
    for(int n=0; n<NVertex; n++) Xco[n] = Yco[n] = BX[n] = BY[n] = 0.;

    double BA = (B-A).GetNorm();
    BX[indA]  = -1./BA;
    BX[indB]  =  1./BA;
    BX[indC]  =  0.;

    double CD = (C-D).GetNorm();
    BY[indA]  = (1-th)/CD;
    BY[indB]  = th    /CD;
    BY[indC]  = -1.   /CD;

    int     itol   = 1;
    double  Tol    = 1.e-10;
    int     itmax  = 2*NVertex;
    int     Niter  = 0;
    double  Err    = 0;

    MS.SetMatOffset(1.);
    MS.ApplySettings();

    if(MS.Solve(BX, Xco, NVertex, itol, Tol, itmax, &Niter, &Err)!=U_OK ||
       MS.Solve(BY, Yco, NVertex, itol, Tol, itmax, &Niter, &Err)!=U_OK)
    {
        delete[] Xco; delete[] Yco; delete[] BX; delete[] BY;
        CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Solving system of equations, NVertex = %d .\n", NVertex);
        return U_ERROR;
    }
    delete[] BX; delete[] BY;

    UFitMoeb FM(Xco, Yco, NVertex);
    FM.SetMaxiter(1000);
    FM.SetTolerance(0.00001);
    FM.SetOptMethod(UCostminimize::U_SIMPLEX_BOOST);
    double par[3] = {10.,0.,0.};
    if(indvertex<0)
    {    
        FM.Iterate(par,3,1.);
        const double* BestP = FM.GetBestPar();
        par[0] = BestP[0]; 
        par[1] = BestP[1]; 
        par[2] = BestP[2]; 
    }
    else 
    {
        par[1] = Xco[indvertex];
        par[2] = Yco[indvertex];
        if(NOT(MinimizeMedianZ))
        {
            FM.SetShift(par[1], par[2]);
            FM.Iterate(par,1,10.);
            const double* BestP = FM.GetBestPar();
            par[0] = BestP[0]; 

            if(MultPar ) *MultPar  = par[0];
            if(BestCost) *BestCost = FM.GetBestCost();
        }
    }
    if(MinimizeMedianZ)
    {
        double* Rar2 = new double[NVertex];
        if(Rar2)
        {
            for(int n=0; n<NVertex; n++) Rar2[n] = (Xco[n]-par[1])*(Xco[n]-par[1]) +
                                                   (Yco[n]-par[2])*(Yco[n]-par[2]);
            double RZ0 = sqrt(fabs(GetMedian(Rar2, NVertex)));
            delete[] Rar2;
            par[0] = 1./RZ0;
        }
        else
            CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). Memory allocation\n");
    }
    if(IDxaxis>=0)
    {
        int ind = FindVertex(IDxaxis);
        if(ind<0)
        {
            CI.AddToLog("ERROR: UManifold::ProjectSphereConformal(). IDxaxis = %d not found.\n", IDxaxis);
            return U_ERROR;
        }
        UVector2 X(Xco[ind]-par[1],Yco[ind]-par[2]);
        double fi = X.GetFi();
        double cf = cos(fi);
        double sf = sin(fi);
        for(int n=0; n<NVertex; n++)
        {
            double XX = par[1] + cf*(Xco[n]-par[1]) + sf*(Yco[n]-par[2]);
            double YY = par[2] - sf*(Xco[n]-par[1]) + cf*(Yco[n]-par[2]);
            Xco[n]    = XX;
            Yco[n]    = YY;
        }
    }
/* Transform x- and y- coordinates to sphere */
    for(int n=0; n<NVertex; n++)
    {
        double   X     = par[0]*(Xco[n]-par[1]);
        double   Y     = par[0]*(Yco[n]-par[2]);
        double   r2    = X*X + Y*Y;
        UVector3 Pcon  = UVector3(2*X/(1+r2), 2*Y/(1+r2), 2*r2/(1+r2)-1);
        *(vertices[n]) = Pcon;
    }
    delete[] Xco; delete[] Yco;
    return U_OK;
}

UFitMoeb::UFitMoeb(const double* Xco, const double* Yco, int Npoints) :
    Uminimize(UCostminimize()) 
{
    X        = Xco;
    Y        = Yco;
    N        = Npoints;
    FixShift = false;
    FixX     = 0.;
    FixY     = 0.;
}
UFitMoeb::~UFitMoeb()
{
}
ErrorType UFitMoeb::SetShift(double XX, double YY)
{
    FixShift = true;
    FixX     = XX;
    FixY     = YY;
    return U_OK;
}
double UFitMoeb::ComputeCost(double *par, int iter, int *status, double *grad, double *gauss)
{
    double XSh  = 0;           
    double YSh  = 0;           
    if(FixShift==true)
    {
        XSh = FixX;
        YSh = FixY;
    }
    else
    {
        XSh = par[1];
        YSh = par[2];
    }

    UVector3 Center;
    for(int n=0; n<N; n++)
    {
        double   Xco   = par[0]*(X[n]-XSh);
        double   Yco   = par[0]*(Y[n]-YSh);
        double   r2    = Xco*Xco + Yco*Yco;
        Center        += UVector3(2*Xco/(1+r2), 2*Yco/(1+r2), 2*r2/(1+r2)-1);
    }
    return Center.GetNorm()/N;
}

ErrorType UManifold::OptimizePointOnSphere(const UMatrixSparse* MS, int Ivert)
{
    UMatrixSparse MScol = MS->GetCollumnSparse(Ivert);
    UMatrixSparse MSrow = MS->GetRowTSparse(Ivert);
    if(MScol.GetError()!=U_OK ||
       MSrow.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::OptimizePointOnSphere(). Getting row or collumn %d \n", Ivert);
        return U_ERROR;
    }

/////
    UVector3 T;
    for(int k=0; k<MScol.GetNvalue(); k++)
    {
        int    ineig = MScol.GetNonZeroRowIndex(0, k);
        double     W = MScol[ineig];
        T           += W * UVector3(*(vertices[ineig]));
    }
    for(int k=0; k<MSrow.GetNvalue(); k++)
    {
        int    ineig = MSrow.GetNonZeroRowIndex(0, k);
        double     W = MSrow[ineig];
        T           += W * UVector3(*(vertices[ineig]));
    }
    T.Normalize();
////
    UVector3      X = *(vertices[Ivert]);
    if((T&X) < 0) X =-T;
    else          X = T;

    *(vertices[Ivert]) = X;
    return U_OK;
}


double* UManifold::GetVertexStretchArray(const UManifold& M) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(&M==NULL || M.GetError()!=U_OK || M.vertices==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). Argument NULL, erroneous or not properly set. \n");
        return NULL;
    }
    if(NVertex!=M.NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). NVertices not compatible: NVertex=%d  ,  M.NVertex = %d  . \n", NVertex!=M.NVertex);
        return NULL;
    }
    double* SArray = new double[NVertex];
    if(SArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). Memory allocation: NVertex = %d .\n");
        return NULL;
    }
    for(int n=0; n<NVertex; n++) SArray[n] = 0.;
    for(int n=0; n<NVertex; n++)
    {
        UVertex*  V =   vertices[n];
        UVertex* MV = M.vertices[n];

        UVertexEdgeIterator  VEI( V);
        UVertexEdgeIterator MVEI(MV);
        int  NNeig =  VEI.GetNNeighbour();
        int MNNeig = MVEI.GetNNeighbour();
        if(NNeig != MNNeig)
        {
            delete[] SArray;
            CI.AddToLog("ERROR: UManifold::GetVertexStretchArray(). Vertex %d. NNeighbors of this and argument UManifold are different: %d = %d .\n", V->GetID(), NNeig, MNNeig);
            return NULL;
        }
        UEdge*    E =  VEI.GetStart();
        UEdge*   ME = MVEI.GetStart();
        int      Ne = 0;
        do
        {
            if(E==NULL || ME==NULL) break;
           
            double  L =  E->GetLength();
            double ML = ME->GetLength();
            
            if(L<=0) continue;
            
            SArray[n] += ML/L;
            Ne++;
        }
        while( (E=VEI.GetNext())!=NULL && (ME=MVEI.GetNext())!=NULL);

        if(Ne>0) SArray[n]/=Ne;
    }
    return SArray;
}

int UManifold::GetNNeigbours(int Vindex, int* NeigArr) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNNeigbours(). Object NULL or erroneous. \n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetNNeigbours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetNNeigbours(). Vertex index out of range (%d). \n", Vindex);
        return 0;
    }
    if(NeigArr==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetNNeigbours(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    int     NN = 0;
    UVertex* v = vertices[Vindex];
    UEdge*   E = v->GetEdge();
    UEdge*   E1= E;
    for(int k=0; k<MAXEIGHBOR && E1; k++)
    {
        UVertex* v1 = E1->GetDest();
        if(v1==NULL) break;
        int Ind = FindVertex(v1->GetID());

        NeigArr[NN++] = Ind;
        E1 = E1->GetONext();
        if(E1==E) break;
    }
    return NN;
}
int* UManifold::GetNVertexNeigbours(int Vindex, int MaxOrder, int*** VertexIDs, int VerboseLevel) const
/* Assume (locally) triangulated manifold */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) || (NFace<=0 || faces==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Vindex<0 || Vindex>=NVertex || MaxOrder<=1)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Parameter index out of range: (Vindex = %d, MaxOrder = %d). \n", Vindex, MaxOrder);
        return NULL;
    }

    int*  NNeighOrd = new int [MaxOrder+1];
    int** pVertIDs  = new int*[MaxOrder+1];
    if(NNeighOrd==NULL || pVertIDs==NULL)
    {
        delete[] NNeighOrd; delete[] pVertIDs;
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Memory allocation, MaxOrder = %d. \n", MaxOrder);
        return NULL;
    }
    for(int m=0; m<=MaxOrder; m++) {NNeighOrd[m]=0; pVertIDs[m]=NULL;}

    NNeighOrd[0] = 1;
    NNeighOrd[1] = vertices[Vindex]->GetNEdge();
    if(NNeighOrd[1]==0) {delete[] pVertIDs; return NNeighOrd;}

    int     NEdgeAlloc  = NNeighOrd[1]+10*MaxOrder;
    UEdge** EdgeBound1  = new UEdge*[NEdgeAlloc];
    UEdge** EdgeBound2  = new UEdge*[NEdgeAlloc];
    pVertIDs[0]         = new int[1];
    pVertIDs[1]         = new int[NNeighOrd[1]];
    if(EdgeBound1==NULL || EdgeBound2==NULL || pVertIDs[0]==NULL || pVertIDs[1]==NULL)
    {
        delete[] EdgeBound1; delete[] EdgeBound2; delete[] pVertIDs[0]; delete[] pVertIDs[1];
        delete[] NNeighOrd;  delete[] pVertIDs;
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Memory allocation, NEdgeAlloc = %d. \n", NEdgeAlloc);
        return NULL;
    }
    pVertIDs[0][0]      = vertices[Vindex]->GetID();

    int     NEdge1      = NNeighOrd[1];
    int     NEdge2      = 0;

    for(int i=0; i<NEdgeAlloc; i++) EdgeBound1[i] = EdgeBound2[i] = NULL;
    EdgeBound1[0] = vertices[Vindex]->GetEdge()->GetSym()->GetOPrev();
    for(int i=1; i<NEdge1; i++) EdgeBound1[i]  = EdgeBound1[i-1]->GetSym()->GetOPrev()->GetOPrev();
    for(int i=0; i<NEdge1; i++) pVertIDs[1][i] = EdgeBound1[i]->GetOrg()->GetID();

    const int MAXSTEP = 100;
    for(int m=2; m<=MaxOrder; m++)
    {
        int    k1   = 0;      // Find first edge of next contour
        UEdge* Es   = EdgeBound1[k1]->GetOPrev()->GetSym();
        int    n    = 0;
        for(n=0; n<MAXSTEP; n++, Es=Es->GetOPrev())
            if(Es->GetDest() != EdgeBound1[n%NEdge1]->GetOrg()) {if(n>2) k1+=(n-2); break;}
        if(n>=MAXSTEP-1)
        {
            CI.AddToLog("WARNING: UManifold::GetNVertexNeigbours(). VertexID= %d; level m = %d. Cannot find starting point for next contour. \n", vertices[Vindex]->GetID(), m);
            break;
        }
        if(VerboseLevel>=3 && NEdge2<400) CI.AddToLog("m=%d NEdge2=%d (IDfr,IDto) = \t%d- \t%d \n", m, NEdge2, Es->GetOrg()->GetID(), Es->GetDest()->GetID());
        EdgeBound2[NEdge2++] = Es;

        while(EdgeBound2[0]->GetOrg()!=EdgeBound2[NEdge2-1]->GetDest() || k1<NEdge1/2) // Find next edges
        {
            if(NEdge2>NQEdge)
            {
                delete[] EdgeBound1; delete[] EdgeBound2; delete[] NNeighOrd; 
                for(int mm=0; mm<=MaxOrder; mm++) delete[] pVertIDs[mm]; delete[] pVertIDs;
                CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Vertex =%d, Closing contour 2 at level m = %d. \n", vertices[Vindex]->GetID(),m);
                return NULL;
            }
            if(EdgeBound2[0]->GetOrg()==EdgeBound2[NEdge2-1]->GetDest())// Try again, skip small part
            {
                if(VerboseLevel>=1) CI.AddToLog("Note: UManifold::GetNVertexNeigbours(). VertexID= %d; Skipping %d points of contour 2 at level m = %d and retry. \n", vertices[Vindex]->GetID(), NEdge2, m);
                k1++;
                for(int n=0; n<NEdge2; n++) EdgeBound2[n] = NULL; NEdge2 = 0;
                Es   = EdgeBound1[k1]->GetOPrev()->GetSym();
                for(int n=0; n<MAXSTEP; n++, Es=Es->GetOPrev())
                    if(Es->GetDest() != EdgeBound1[(k1+n)%NEdge1]->GetOrg()) {if(n>2) k1+=(n-2); break;}
                if(VerboseLevel>=3 && NEdge2<400) CI.AddToLog("m=%d NEdge2=%d (IDfr,IDto) = \t%d- \t%d \n", m, NEdge2, Es->GetOrg()->GetID(), Es->GetDest()->GetID());
                EdgeBound2[NEdge2++] = Es;
            }
            UEdge* En = EdgeBound2[NEdge2-1]->GetSym()->GetOPrev();
            for(int n=0; n<MAXSTEP; n++, En=En->GetOPrev())
                if(En->GetDest() != EdgeBound1[(k1+n)%NEdge1]->GetDest()) {k1+=(n-1); break;}

            if(NEdge2+2>=NEdgeAlloc)
            {
                int     NewNEdgeAlloc  = 10+3*NEdgeAlloc/2;
                UEdge** NewEdgeBound1  = new UEdge*[NewNEdgeAlloc];
                UEdge** NewEdgeBound2  = new UEdge*[NewNEdgeAlloc];
                if(NewEdgeBound1==NULL || NewEdgeBound2==NULL)
                {
                    delete[] NewEdgeBound1; delete[] NewEdgeBound1; delete[] EdgeBound1; delete[] EdgeBound2; delete[] NNeighOrd; 
                    for(int mm=0; mm<=MaxOrder; mm++) delete[] pVertIDs[mm]; delete[] pVertIDs;
                    CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Memory allocation, NewNEdgeAlloc = %d. \n", NewNEdgeAlloc);
                    return NULL;
                }

                for(int n=0; n<NewNEdgeAlloc; n++) NewEdgeBound1[n] = NewEdgeBound2[n] = NULL;
                for(int n=0; n<NEdge1;        n++) NewEdgeBound1[n] = EdgeBound1[n];
                for(int n=0; n<NEdge2;        n++) NewEdgeBound2[n] = EdgeBound2[n];
                NEdgeAlloc = NewNEdgeAlloc;
                delete[] EdgeBound1; EdgeBound1 = NewEdgeBound1; 
                delete[] EdgeBound2; EdgeBound2 = NewEdgeBound2; 
            }
            if(VerboseLevel>=3 && NEdge2<400) CI.AddToLog("m=%d NEdge2=%d (IDfr,IDto) = \t%d- \t%d \n", m, NEdge2, En->GetOrg()->GetID(), En->GetDest()->GetID());
            EdgeBound2[NEdge2++] = En;
        }
        NNeighOrd[m] = NEdge2;
        pVertIDs[m]  = new int[NEdge2];
        if(pVertIDs[m]) for(int i=0; i<NEdge2; i++) pVertIDs[m][i] = EdgeBound2[i]->GetOrg()->GetID();

        int  NN2         = NEdge2;
        ErrorType ESkip1 = SkipEdgeShortCuts(EdgeBound2, NEdge2, &NN2);
        if(VerboseLevel>=1 && NN2!=NEdge2) CI.AddToLog("Note: UManifold::GetNVertexNeigbours(). Vertex=%d, Level = %d. Edge ShortCut of %d points of %d removed.\n", vertices[Vindex]->GetID(), m, NEdge2-NN2, NEdge2);
        NEdge2           = NN2;
        ErrorType ESkip2 = SkipVertexShortCuts(EdgeBound2, NEdge2, &NN2);
        if(VerboseLevel>=1 && NN2!=NEdge2) CI.AddToLog("Note: UManifold::GetNVertexNeigbours(). Vertex=%d, Level = %d. Vertex ShortCut of %d points of %d removed.\n", vertices[Vindex]->GetID(), m, NEdge2-NN2, NEdge2);
        NEdge2           = NN2;
        ErrorType ESkip3 = SkipOneStepShortCuts(EdgeBound2, NEdge2, &NN2);
        if(VerboseLevel>=2 && NN2!=NNeighOrd[m]) CI.AddToLog("Note: UManifold::GetNVertexNeigbours(). Vertex=%d, Level = %d. Skipped %d points of %d.\n", vertices[Vindex]->GetID(), m, NNeighOrd[m]-NEdge2, NNeighOrd[m]);
        NEdge2           = NN2;
        if(ESkip1!=U_OK || ESkip2!=U_OK || ESkip3!=U_OK)
        {
            delete[] EdgeBound1; delete[] EdgeBound2; delete[] NNeighOrd; 
            for(int mm=0; mm<=MaxOrder; mm++) delete[] pVertIDs[mm]; delete[] pVertIDs;
            CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours(). Removing shortcuts. \n");
            return NULL;
        }

        NEdge1 = NEdge2; for(int i=0; i<NEdge1    ; i++) EdgeBound1[i] = EdgeBound2[i];
        NEdge2 = 0     ; for(int i=0; i<NEdgeAlloc; i++) EdgeBound2[i] = NULL;
        if(NEdge1<=0)
        {
            CI.AddToLog("WARNING: UManifold::GetNVertexNeigbours(). VertexID = %d. No neighbors left at level = %d. \n", vertices[Vindex]->GetID(), m);
            break;
        }
/////////
        //NNeighOrd[m] = NEdge1;
        //for(int i=0; i<NEdge1; i++) pVertIDs[m][i] = EdgeBound1[i]->GetOrg()->GetID();
/////////
    }
    delete[] EdgeBound1; delete[] EdgeBound2; 
    if(VertexIDs==NULL)
    {
        for(int m=0; m<=MaxOrder; m++) delete[] pVertIDs[m];
        delete[] pVertIDs;
    }
    else *VertexIDs = pVertIDs;

    return NNeighOrd;
}

int* UManifold::GetNVertexNeigbours2(int Vindex, int MaxOrder, int*** VertexIDs) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) || (NFace<=0 || faces==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Vindex<0 || Vindex>=NVertex || MaxOrder<=1)
    {
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Parameter index out of range: (Vindex = %d, MaxOrder = %d). \n", Vindex, MaxOrder);
        return NULL;
    }

    int* Distances = new int[NVertex];
    int  NMarked   = Distances ? MarkVertexNeighbours(Vindex, MaxOrder, Distances) : -1;
    if(NMarked<=0)
    {   
        delete[] Distances;
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Marking neighbors. \n");
        return NULL;
    }

    int*  NNeighOrd = new int [MaxOrder+1];
    int** pVertIDs  = new int*[MaxOrder+1];
    if(NNeighOrd==NULL || pVertIDs==NULL)
    {
        delete[] Distances;
        delete[] NNeighOrd; delete[] pVertIDs;
        CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Memory allocation, MaxOrder = %d. \n", MaxOrder);
        return NULL;
    }
    for(int m=0; m<=MaxOrder; m++) {NNeighOrd[m]=0; pVertIDs[m]=NULL;}
    for(int n=0; n<NVertex; n++) if(Distances[n]>=0&&Distances[n]<=MaxOrder) NNeighOrd[Distances[n]]++;

    for(int m=0; m<=MaxOrder; m++)
    {
        pVertIDs[m] = new int[MAX(NNeighOrd[m],1)];
        if(pVertIDs[m]==NULL)
        {
            for(int mm=0; mm<=MaxOrder; mm++) delete[] pVertIDs[mm]; 
            delete[] NNeighOrd; delete[] pVertIDs;
            CI.AddToLog("ERROR: UManifold::GetNVertexNeigbours2(). Memory allocation, m = %d. \n", m);
            return NULL;
        }
        pVertIDs[m][0] = -1;
        NNeighOrd[m]   =  0;
    }
    for(int n=0; n<NVertex; n++) 
    {
        int m = Distances[n];
        if(m<0||m>MaxOrder) continue;
        pVertIDs[m][NNeighOrd[m]] = vertices[n]->GetID();
        NNeighOrd[m]++;
    }
    delete[] Distances;

    if(VertexIDs==NULL)
    {
        for(int m=0; m<=MaxOrder; m++) delete[] pVertIDs[m];
        delete[] pVertIDs;
    }
    else *VertexIDs = pVertIDs;
    return NNeighOrd;
}

int UManifold::MarkVertexNeighbours(const int* VindicesForeground, int NForeground, int MaxNeighDegree, int* Distances) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Object NULL or erroneous. \n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    if(VindicesForeground==NULL || NForeground<=0)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Foreground vertices out of range (NForeGround = %d). \n", NForeground);
        return 0;
    }
    for(int n=0; n<NForeground; n++)
    {
        if(VindicesForeground[n]>=0 && VindicesForeground[n]<NVertex) continue;
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). VindicesForeground[%d] out of range (= %d). \n", n, VindicesForeground[n]);
        return 0;
    }
    if(MaxNeighDegree<0)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Ntimes parameter out of range: NNeighDegree = %d .\n", MaxNeighDegree);
        return 0;
    }
    if(Distances==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Invalid NULL pointer argument. \n");
        return 0;
    }

    int NeigArr[MAXEIGHBOR];
    int MaxBuffer = NForeground + 10*MaxNeighDegree;
    UFIFOQueueInt fifoQueue(MaxBuffer);

    const int LABELINIT  =   -1;
    const int FICTITIOUS =   -3;

    for(int n=0; n<NVertex; n++) Distances[n] = LABELINIT;
    for(int n=0; n<NForeground; n++)
    {
        fifoQueue.Enqueue(VindicesForeground[n]);
        Distances[VindicesForeground[n]] = 0;
    }
    int NMarked = NForeground;
    int Dist    = 1;

    fifoQueue.Enqueue(FICTITIOUS); // Add artifical boundary marker in fifoQueue

    while(true) // extend basins 
    {
        int Index = fifoQueue.Dequeue();

        if(Index==FICTITIOUS)
        {
            if(fifoQueue.GetSize()==0) break;
                    
            fifoQueue.Enqueue(FICTITIOUS); // Add points with curdist steps away from processed points
            Dist++;
            if(Dist>MaxNeighDegree) break;
            Index = fifoQueue.Dequeue();
        }
        int NNEig = GetNNeigbours(Index, NeigArr);
        for(int i=0; i<NNEig; i++) // inspect neighbours of Index
        {
            if(Distances[NeigArr[i]]>Dist) 
            {
                Distances[NeigArr[i]]=Dist;
                continue;
            }
            if(Distances[NeigArr[i]]==LABELINIT)
            {
                fifoQueue.Enqueue(NeigArr[i]);
                Distances[NeigArr[i]] = Dist;
                NMarked++;
            }
        }
    }
    return NMarked;
}
int UManifold::MarkVertexNeighbours(int Vindex, int MaxNeighDegree, int* Distances) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Object NULL or erroneous. \n");
        return 0;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0;
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Vertex index out of range (%d). \n", Vindex);
        return 0;
    }
    if(MaxNeighDegree<0)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Ntimes parameter out of range: NNeighDegree = %d .\n", MaxNeighDegree);
        return 0;
    }

    const int LABELINIT  =   -1;
    const int FICTITIOUS =   -3;

    if(Distances==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MarkVertexNeighbours(). Invalid NULL pointer argument. \n");
        return 0;
    }
    for(int n=0; n<NVertex; n++) Distances[n] = LABELINIT;

    int NeigArr[MAXEIGHBOR];
    int MaxBuffer = 20*MaxNeighDegree;
    UFIFOQueueInt fifoQueue(MaxBuffer);

    int NMarked = 1;
    int Dist    = 0;
    fifoQueue.Enqueue(Vindex);
    Distances[Vindex] = Dist++;

    fifoQueue.Enqueue(FICTITIOUS); // Add artifical boundary marker in fifoQueue

    while(true) // extend basins 
    {
        int Index = fifoQueue.Dequeue();

        if(Index==FICTITIOUS)
        {
            if(fifoQueue.GetSize()==0) break;
                    
            fifoQueue.Enqueue(FICTITIOUS); // Add points with curdist steps away from processed points
            Dist++;
            if(Dist>MaxNeighDegree) break;
            Index = fifoQueue.Dequeue();
        }
        int NNEig = GetNNeigbours(Index, NeigArr);
        for(int i=0; i<NNEig; i++) // inspect neighbours of Index
        {
            if(Distances[NeigArr[i]]>Dist) // This never happens...
            {
                Distances[NeigArr[i]]=Dist;
                continue;
            }
            if(Distances[NeigArr[i]]==LABELINIT)
            {
                fifoQueue.Enqueue(NeigArr[i]);
                Distances[NeigArr[i]] = Dist;
                NMarked++;
            }
        }
    }
    return NMarked;
}

int* UManifold::GetVertexNeighbourIDs(int Vindex, int NNeighDegree, int* NNeigh) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(Vindex<0 || Vindex>=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). Vertex index out of range (%d). \n", Vindex);
        return NULL;
    }
    if(NNeigh==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). Invalid NULL pointer argument. \n");
        return NULL;
    }
    if(NNeighDegree<0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). Ntimes parameter out of range: NNeighDegree = %d .\n", NNeighDegree);
        return NULL;
    }

    int* Distances = new int[NVertex];
    int  NMarked   = MarkVertexNeighbours(Vindex, NNeighDegree, Distances);
    if(Distances==NULL || NMarked<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexNeighbourIDs(). No neigbours found, Vindex =%d .\n", Vindex);
        delete[] Distances;
        return NULL;
    }

    int* Neig = new int[NMarked];
    for(int n=0, k=0; n<NVertex; n++)
    {
        if(Distances[n]<0) continue;
        Neig[k++] = vertices[n]->GetID();
        if(k==NMarked) break;
    }
    delete[] Distances;

    *NNeigh = NMarked;
    return Neig;
}

ErrorType UManifold::MaximizeMinAngleSwapEdge(int MaxNSwaps, int MaxIDfixed, int iseed, int* NSwap)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeMinAngleSwapEdge(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MaximizeMinAngleSwapEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(MaxNSwaps<0)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeMinAngleSwapEdge(). Parameters out of range: MaxNSwaps = %d. \n", MaxNSwaps);
        return U_ERROR;
    }

    if(CompleteTriangulation(false)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeMinAngleSwapEdge(). Completing triangulation. \n");
        return U_ERROR;
    }
    int* Perm = iseed<0 ? GetIndexEdgeMinAngle() : GetRandomPermutation(NQEdge, iseed);
    if(Perm==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeMinAngleSwapEdge(). Computing edge permutation. \n");
        return U_ERROR;
    }
    int NS = 0;
    for(int n=0; n<MaxNSwaps; n++)   
    {
        int inde = Perm[n];
        if(qedges[inde]->GetOrgID() <MaxIDfixed &&
           qedges[inde]->GetDestID()<MaxIDfixed) continue;

        int      QEID   = qedges[inde]->GetID();
        UEdge*   Edge   = qedges[inde]->GetEdge();

        UVertexEdgeIterator VEI1(Edge->GetOrg());
        UVertexEdgeIterator VEI2(Edge->GetDest());
        if(VEI1.GetNNeighbour()<4 || VEI2.GetNNeighbour()<4) continue;  // Do not swap to avoid degeneration

        UFace*   Left   = Edge->GetLeftFace();
        UFace*   Right  = Edge->GetRightFace();
        double   MinAng = MIN(Left->GetMinAngle(), Right->GetMinAngle());

        SwapEdgeID(QEID, false);
        inde             = FindQuadEdge(QEID);
        Edge             = qedges[inde]->GetEdge(); 
        Left             = Edge->GetLeftFace();
        Right            = Edge->GetRightFace();
        double   MinAngS = MIN(Left->GetMinAngle(), Right->GetMinAngle());

        if(MinAngS>MinAng) 
        {
            NS++;
            continue;  // Succesful swap
        }
        SwapEdgeID(QEID,false);             // Swap back
    }
    if(NSwap) *NSwap = NS;
    delete[] Perm;
    return U_OK;
}
ErrorType UManifold::MaximizeVolumeSwapEdge(int MaxNSwaps, int MaxIDfixed, int iseed, int* NSwap)
{
    CI.AddToLog("WARNING: UManifold::MaximizeVolumeSwapEdge(). This function can result in self crossings. \n");

    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeVolumeSwapEdge(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MaximizeVolumeSwapEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(MaxNSwaps<0 || iseed<0)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeVolumeSwapEdge(). Parameters out of range: MaxNSwaps = %d, iseed = %d. \n", MaxNSwaps, iseed);
        return U_ERROR;
    }

    if(CompleteTriangulation(false)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeVolumeSwapEdge(). Completing triangulation. \n");
        return U_ERROR;
    }
    int* Perm = GetRandomPermutation(NQEdge, iseed);
    if(Perm==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MaximizeVolumeSwapEdge(). Computing edge permutation. \n");
        return U_ERROR;
    }
    int NS = 0;
    for(int n=0; n<MaxNSwaps; n++)   
    {
        int inde = Perm[n];
        if(qedges[inde]->GetOrgID() <MaxIDfixed &&
           qedges[inde]->GetDestID()<MaxIDfixed) continue;

        int      QEID   = qedges[inde]->GetID();
        UEdge*   Edge   = qedges[inde]->GetEdge();

        UVertexEdgeIterator VEI1(Edge->GetOrg());
        UVertexEdgeIterator VEI2(Edge->GetDest());
        if(VEI1.GetNNeighbour()<4 || VEI2.GetNNeighbour()<4) continue;  // Do not swap to avoid degeneration

        UVector3 O    = *Edge->GetOrg();
        UVector3 D    = *Edge->GetDest();
        UVector3 P    = *Edge->GetOPrev()->GetDest();
        UVector3 N    = *Edge->GetONext()->GetDest();

        double Diff = GetDeterminant(P,O,D) + GetDeterminant(D,O,N) -
                     (GetDeterminant(D,P,N) + GetDeterminant(N,P,O));

        if(Diff>=0.) continue; // Assume negative volumes
        SwapEdgeID(QEID, false);
        NS++;
    }
    if(NSwap) *NSwap = NS;
    delete[] Perm;
    return U_OK;
}
ErrorType UManifold::MinimizeCurvatureSwapEdge(bool GaussCurvature, bool MeanCurvature, int MaxIDfixed, int MaxNSwaps, int iseed, int* NSwap)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvatureSwapEdge(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvatureSwapEdge(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(MaxNSwaps<0 || iseed<0)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvatureSwapEdge(). Parameters out of range: MaxNSwaps = %d, iseed = %d. \n", MaxNSwaps, iseed);
        return U_ERROR;
    }
    if(NOT(GaussCurvature) && NOT(MeanCurvature)) return U_OK;

    if(CompleteTriangulation(false)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvatureSwapEdge(). Completing triangulation. \n");
        return U_ERROR;
    }
    int* Perm = GetRandomPermutation(NQEdge, iseed);
    if(Perm==NULL)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvatureSwapEdge(). Computing edge permutation. \n");
        return U_ERROR;
    }
    int NS = 0;
    for(int n=0; n<MaxNSwaps; n++)   
    {
        int inde = Perm[n];
        if(qedges[inde]->GetOrgID() <MaxIDfixed &&
           qedges[inde]->GetDestID()<MaxIDfixed) continue;

        int      QEID   = qedges[inde]->GetID();
        UEdge*   Edge   = qedges[inde]->GetEdge();

        UVertexEdgeIterator VEI1(Edge->GetOrg());
        UVertexEdgeIterator VEI2(Edge->GetDest());
        if(VEI1.GetNNeighbour()<4 || VEI2.GetNNeighbour()<4) continue;  // Do not swap to avoid degeneration

        UVertex* V[4] = {Edge->GetOrg(), Edge->GetDest(), Edge->GetOPrev()->GetDest(), Edge->GetONext()->GetDest()};

        double C1 = 0;
        for(int n=0; n<4; n++) 
        {
            if(GaussCurvature) C1 +=       V[n]->GetGaussCurveSQR();
            if(MeanCurvature ) C1 += 0.25 *V[n]->GetMeanCurveSQR();
        }
        SwapEdgeID(QEID, false);

        double C2 = 0;
        for(int n=0; n<4; n++) 
        {
            if(GaussCurvature) C2 +=       V[n]->GetGaussCurveSQR();
            if(MeanCurvature ) C2 += 0.25 *V[n]->GetMeanCurveSQR();
        }
        if(C2<C1) 
        {
            NS++;
            continue;  // Succesful swap
        }
        SwapEdgeID(QEID,false);    // Swap back
    }
    if(NSwap) *NSwap = NS;
    delete[] Perm;
    return U_OK;
}

ErrorType UManifold::MinimizeCurvature(bool GaussCurvature, bool MeanCurvature, int MaxIDfixed, double AreaPenalty, int Maxiter, bool SwapEdges)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    if(Maxiter<=0)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Maxiter parameter out of range: Maxiter = %d .\n", Maxiter);
        return U_ERROR;
    }
    int Nfixed = 0;
    for(int i=0; i<NVertex; i++) if(vertices[i]->GetID()<MaxIDfixed) Nfixed++; 
    if(Nfixed<=0) 
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Too few fixed vertices: Nfixed = %d, MaxIDfixed=%d .\n", Nfixed, MaxIDfixed);
        return U_ERROR;
    }

    int MaxIDmoved = LastVertexID;
    if(CompleteTriangulation(true)!=U_OK || RandomizeVertices(0.001,1001)!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Completing triangulation or randomization.\n");
        return U_ERROR;
    }
    if(NOT(GaussCurvature) && NOT(MeanCurvature)) return U_OK;

    UMinimizeCurve MC(vertices, NVertex, GaussCurvature, MeanCurvature, MaxIDfixed, MaxIDmoved, AreaPenalty);
    MC.SetMaxIter(20);
    MC.SetMaxStep(0.1);

    double CostOld = MC.ComputeCost();
    int    iter    = 0;
    for(int it =0; it<Maxiter; it++, iter++)
    {
        if(SwapEdges)
        {
            int NSwa = -1;
            MaximizeMinAngleSwapEdge(NVertex-Nfixed, MaxIDfixed, it+10, &NSwa);
            CI.AddToLog("Note: UManifold::MinimizeCurvature(). NSwap = %d \n", NSwa);
        }
        if(MC.MinimizeCurvature()!=U_OK)
        {
            CI.AddToLog("ERROR: UManifold::MinimizeCurvature(). Computing line search in iteration %d .\n", it);
            return U_ERROR;
        }
        double CostNew = MC.ComputeCost();
        if(fabs(CostNew-CostOld)<0.000001*CostOld) break;
        CostOld = CostNew;

        CI.AddToLog("Cost = %f \n", CostNew);
    }
    CI.AddToLog("Note: UManifold::MinimizeCurvature(). Convergence after %d iterations.\n", iter);
    return U_OK;
}

UMinimizeCurve::UMinimizeCurve(UVertex** vert, int Nvert, bool GCurve, bool MCurve, int MaxIDF, int MaxIDM, double Lam) : ULineSearch(3*Nvert)
{
    vertices   = vert;
    NVertex    = Nvert;
    GaussCurve = GCurve;
    MeanCurve  = MCurve;
    MaxIDfixed = MaxIDF;
    MaxIDmoved = MaxIDM;
    Lamda      = MAX(Lam, 0.);

    ParOld = new double[3*NVertex];
    if(ParOld==NULL)
        CI.AddToLog("ERROR: UMinimizeCurve::UMinimizeCurve(). Memory allocation. Dir. NVertex = %d .\n", NVertex);
}
UMinimizeCurve::~UMinimizeCurve()
{
    delete[] ParOld; 
}
double UMinimizeCurve::ComputeCost(const double *Par) const
{
    if(Par) for(int n=0; n<NVertex; n++) *(vertices[n]) = UVector3(Par+3*n);
   
    double MC2 = 0;
    for(int n=0; n<NVertex; n++)
    {
        if(GaussCurve) MC2 +=       vertices[n]->GetGaussCurveSQR();
        if(MeanCurve ) MC2 += 0.25 *vertices[n]->GetMeanCurveSQR();
        if(Lamda>0.  ) MC2 += Lamda*vertices[n]->GetAmixed();
    }
    return MC2/NVertex;
}
double* UMinimizeCurve::GetGradient(const double* Par) const
{
    if(Par) for(int n=0; n<NVertex; n++) *(vertices[n]) = UVector3(Par+3*n);

    const double Eps = 0.0001;

    double* ParGra = new double[3*NVertex];
    double* GradN  = new double[  NVertex];
    if(ParGra==NULL || GradN==NULL)
    {
        delete[] ParGra; delete[] GradN;
        CI.AddToLog("ERROR: UMinimizeCurve::GetGradient(). Memory allocation. NVertex = %d .\n", NVertex);
    }
    for(int n=0; n<3*NVertex; n++) ParGra[n]  = 0;
    for(int n=0; n<  NVertex; n++) GradN[n]   = 0.;
    for(int n=0; n<  NVertex; n++)
    {
        int IDn = vertices[n]->GetID();
        if(IDn<MaxIDfixed) continue;
        if(MaxIDmoved<IDn) continue;

        UVector3 Grad;
        if(GaussCurve)  Grad +=       vertices[n]->GetGradGaussCurveSQR(IDn, Eps);
        if(MeanCurve )  Grad += 0.25 *vertices[n]->GetGradMeanCurveSQR(IDn, Eps);
        UVertexEdgeIterator VEI(vertices[n]);
        for(UEdge* E = VEI.GetStart(); E; E=VEI.GetNext())
        {
            if(GaussCurve)   Grad +=      E->GetDest()->GetGradGaussCurveSQR(IDn, Eps);
            if(MeanCurve )   Grad += 0.25*E->GetDest()->GetGradMeanCurveSQR(IDn, Eps);
        }
        if(Lamda>0.)         Grad += Lamda*vertices[n]->GetGradAmixed(IDn, Eps);

        GradN[n]      = Grad.GetNorm()/NVertex;

        ParGra[3*n+0] = Grad.Getx()/NVertex;
        ParGra[3*n+1] = Grad.Gety()/NVertex;
        ParGra[3*n+2] = Grad.Getz()/NVertex;
    }
    double gamT = ::GetUpperQuantile(GradN, NVertex, 0.01);
    for(int n=0; n<NVertex; n++) 
    {
////        double Factor = GradN[n] <gamT ? 0.1/gamT : 0.1/GradN[n];
        double Factor = 100.;

        ParGra[3*n+0] *= Factor;
        ParGra[3*n+1] *= Factor;
        ParGra[3*n+2] *= Factor;
    }
    delete[] GradN;
    return ParGra;
}

ErrorType UMinimizeCurve::MinimizeCurvature(void)
{
    for(int n=0; n<NVertex; n++) 
    {
        ParOld[3*n+0] = (*(vertices[n]))[0];
        ParOld[3*n+1] = (*(vertices[n]))[1];
        ParOld[3*n+2] = (*(vertices[n]))[2];
    }
    double  Cost0  = ComputeCost(ParOld);
    double* ParGra = GetGradient(ParOld);
    double* ParNew = ULineSearch::GetLineSearch(ParOld, Cost0, ParGra);

    if(ParGra==NULL || ParNew==NULL) 
    {
        delete[] ParGra; delete[] ParNew;
        CI.AddToLog("ERROR: UMinimizeCurve::MinimizeCurvature(). Line search .\n");
        return U_ERROR;
    }
    for(int n=0; n<NVertex; n++) *(vertices[n]) = UVector3(ParNew+3*n);
    delete[] ParGra; delete[] ParNew;
    return U_OK;
}

ErrorType UManifold::SmoothVertices(double WeigNeig, int Ntimes)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(WeigNeig==0. || Ntimes==0) return U_OK;
    if(Ntimes<=0)
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Ntimes parameter out of range: Ntimes = %d .\n", Ntimes);
        return U_ERROR;
    }
    UVector3* SmoothDat = new UVector3[NVertex];
    if(SmoothDat==NULL)
    {
        delete[] SmoothDat;
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Memory allocation: NVertex = %d .\n", NVertex);
        return U_ERROR;
    }

    int NeighID[MAXEIGHBOR];
    for(int it=0; it<Ntimes; it++)
    {
        for(int n=0; n<NVertex; n++)
        {
            int  NNeig = 0;
            if(vertices[n]==NULL || vertices[n]->GetNeigborIDs(NeighID, &NNeig)!=U_OK)
            {
                delete[] SmoothDat;
                CI.AddToLog("ERROR: UManifold::SmoothVertices(). Getting neighbours of vertex  %d .\n", n);
                return U_ERROR;
            }
            SmoothDat[n] = *vertices[n];
            for(int k=0; k<NNeig; k++)
            {
                int ind = FindVertex(NeighID[k]);
                if(ind<0) continue;
                SmoothDat[n] += UVector3(*(vertices[ind]))*WeigNeig;
            }
            SmoothDat[n] = SmoothDat[n]/(1.+NNeig*fabs(WeigNeig));
        }
        for(int n=0; n<NVertex; n++) *(vertices[n]) = SmoothDat[n];
    }
    
    delete[] SmoothDat;
    return U_OK;
}
ErrorType UManifold::SmoothVertices(int NNeighDegree)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(NNeighDegree==0) return U_OK;
    if(NNeighDegree<=0)
    {
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Ntimes parameter out of range: NNeighDegree = %d .\n", NNeighDegree);
        return U_ERROR;
    }
    UVector3* SmoothDat = new UVector3[NVertex];
    if(SmoothDat==NULL)
    {
        delete[] SmoothDat;
        CI.AddToLog("ERROR: UManifold::SmoothVertices(). Memory allocation: NVertex = %d .\n", NVertex);
        return U_ERROR;
    }

    for(int n=0; n<NVertex; n++)
    {
        int  NNeig = 0;
        int* Neig  = GetVertexNeighbourIDs(n, NNeighDegree, &NNeig);
        if(Neig==NULL)
        {
            delete[] SmoothDat;
            CI.AddToLog("ERROR: UManifold::SmoothVertices(). Getting neighbors from vertex = %d .\n", n);
            return U_ERROR;
        }
        SmoothDat[n] = UVector3();
        for(int k=0; k<NNeig; k++)
        {
            int ind = FindVertex(Neig[k]);
            if(ind<0) continue;
            SmoothDat[n] += UVector3(*(vertices[ind]));
        }
        if(NNeig) SmoothDat[n] = SmoothDat[n]/double(NNeig);
        delete[] Neig;
    }
    for(int n=0; n<NVertex; n++) *(vertices[n]) = SmoothDat[n];
    
    delete[] SmoothDat;
    return U_OK;
}

double* UManifold::GetSmoothedVertexData(const double* VertDat, double WeigNeig, int Ntimes) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertDat==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Invalid NULL pointer for input data. \n");
        return NULL;
    }
    if(Ntimes<0)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Ntimes parameter out of range: Ntimes = %d .\n", Ntimes);
        return NULL;
    }

    double* SmoothDat = new double[NVertex];
    double* TempDat   = new double[NVertex];
    if(SmoothDat==NULL || TempDat==NULL)
    {
        delete[] SmoothDat; delete[] TempDat;
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }

    for(int n=0; n<NVertex; n++) TempDat[n] = VertDat[n];

    if(WeigNeig==0. || Ntimes==0)
    {
        delete[] SmoothDat;
        return TempDat;
    }

    for(int it=0; it<Ntimes; it++)
    {
        for(int n=0; n<NVertex; n++)
        {
            int  NNeig = 0;
            int NeighID[MAXEIGHBOR];
            if(vertices[n]==NULL || vertices[n]->GetNeigborIDs(NeighID, &NNeig)!=U_OK)
            {
                delete[] SmoothDat; delete[] TempDat;
                CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Getting neighbours of vertex  %d .\n", n);
                return NULL;
            }

            SmoothDat[n] = VertDat[n];
            for(int k=0; k<NNeig; k++)
            {
                int ind = FindVertex(NeighID[k]);
                if(ind<0) continue;
                SmoothDat[n] += WeigNeig*VertDat[ind];
            }
            if(NNeig) SmoothDat[n] = SmoothDat[n]/(1.+WeigNeig*NNeig);
        }
        for(int n=0; n<NVertex; n++) TempDat[n] = SmoothDat[n];
    }
    delete[] TempDat;
    return SmoothDat;
}
double* UManifold::GetSmoothedVertexData(const double* VertDat, int NNeighDegree) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) || (NQEdge<=0 || qedges==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertDat==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Invalid NULL pointer for input data. \n");
        return NULL;
    }
    if(NNeighDegree<=0)
    {
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Ntimes parameter out of range: NNeighDegree = %d .\n", NNeighDegree);
        return NULL;
    }
    double* SmoothDat = new double[NVertex];
    if(SmoothDat==NULL)
    {
        delete[] SmoothDat;
        CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) SmoothDat[n] = 0.;

    for(int n=0; n<NVertex; n++)
    {
        int  NNeig = 0;
        int* Neig  = GetVertexNeighbourIDs(n, NNeighDegree, &NNeig);
        if(Neig==NULL)
        {
            delete[] SmoothDat;
            CI.AddToLog("ERROR: UManifold::GetSmoothedVertexData(). Getting neighbors from vertex = %d .\n", n);
            return NULL;
        }
        SmoothDat[n] = 0.;
        for(int k=0; k<NNeig; k++)
        {
            int ind = FindVertex(Neig[k]);
            if(ind<0) continue;
            SmoothDat[n] += VertDat[ind];
        }
        if(NNeig) SmoothDat[n] = SmoothDat[n]/double(NNeig);
        delete[] Neig;
    }
    return SmoothDat;
}

double* UManifold::GetVertexAngleDeficit() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CurveArray = new double[NVertex];
    if(CurveArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexAngleDeficit(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CurveArray[n] = vertices[n]->GetAngleDeficit();
    return CurveArray;
}
double* UManifold::GetVertexGaussCurvature(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvature(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CurveArray = new double[NVertex];
    if(CurveArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvature(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CurveArray[n] = vertices[n]->GetGaussCurve();

    return CurveArray;
}
double* UManifold::GetVertexGaussCurvatureSQR(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvatureSQR(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvatureSQR(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CurveArray = new double[NVertex];
    if(CurveArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexGaussCurvatureSQR(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CurveArray[n] = vertices[n]->GetGaussCurveSQR();

    return CurveArray;
}
double* UManifold::GetVertexMeanCurvature(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CurveArray = new double[NVertex];
    if(CurveArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvature(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CurveArray[n] = vertices[n]->GetMeanCurve();

    return CurveArray;
}
double* UManifold::GetVertexMeanCurvatureSQR(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvatureSQR(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvatureSQR(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CurveArray = new double[NVertex];
    if(CurveArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMeanCurvatureSQR(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CurveArray[n] = vertices[n]->GetMeanCurveSQR();

    return CurveArray;
}
double* UManifold::GetVertexVoronoiArea(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexVoronoiArea(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexVoronoiArea(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* VAreaArray = new double[NVertex];
    if(VAreaArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexVoronoiArea(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) VAreaArray[n] = vertices[n]->GetAmixed();

    return VAreaArray;
}

double* UManifold::GetVertexMinCurvature(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMinCurvature(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMinCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CMean  = GetVertexMeanCurvature();
    double* CGauss = GetVertexGaussCurvature();
    if(CMean==NULL || CGauss==NULL)
    {
        delete[] CMean; delete[] CGauss;
        CI.AddToLog("ERROR: UManifold::GetVertexMinCurvature(). Computing mean or Gauss curvature. \n");
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CMean[n]/=2;

    for(int n=0; n<NVertex; n++)
    {
        double Disc = MAX(0., (CMean[n]*CMean[n]-CGauss[n]));
        CMean[n]  -= sqrt(Disc);
    }
    delete[] CGauss;
    return CMean;
}
double* UManifold::GetVertexMaxCurvature(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMaxCurvature(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMaxCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* CMean  = GetVertexMeanCurvature();
    double* CGauss = GetVertexGaussCurvature();
    if(CMean==NULL || CGauss==NULL)
    {
        delete[] CMean; delete[] CGauss;
        CI.AddToLog("ERROR: UManifold::GetVertexMaxCurvature(). Computing mean or Gauss curvature. \n");
        return NULL;
    }
    for(int n=0; n<NVertex; n++) CMean[n]/=2;

    for(int n=0; n<NVertex; n++)
    {
        double Disc = MAX(0., (CMean[n]*CMean[n]-CGauss[n]));
        CMean[n]  += sqrt(Disc);
    }
    delete[] CGauss;
    return CMean;
}

double UManifold::GetMeanCurvature(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetMeanCurvature(). Object NULL or erroneous. \n");
        return 0.;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetMeanCurvature(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return 0.;
    }
    double MeanC = 0.;
    for(int n=0; n<NVertex; n++) MeanC += vertices[n]->GetMeanCurve();
    if(NVertex) MeanC /= NVertex;

    return MeanC;
}
double* UManifold::GetVertexThetaArray(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexThetaArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexThetaArray(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* TArray = new double[NVertex];
    if(TArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexThetaArray(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) TArray[n] = vertices[n]->GetTheta();
    
    return TArray;
}

double* UManifold::GetVertexFiArray(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexFiArray(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL))
    {
        CI.AddToLog("ERROR: UManifold::GetVertexFiArray(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    double* FArray = new double[NVertex];
    if(FArray==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexFiArray(). Memory allocation: NVertex = %d .\n", NVertex);
        return NULL;
    }
    for(int n=0; n<NVertex; n++) FArray[n] = vertices[n]->GetFi();
    
    return FArray;
}

ErrorType UManifold::GetMinMaxVertexData(UFace* F, const double* VertData, double* MinDat, double* MaxDat) const
{
    if(this==NULL     || error !=U_OK  ) return U_ERROR;
    if(vertices==NULL || NVertex<=0    ) return U_ERROR;
    if(faces==NULL    || NFace<=0      ) return U_ERROR;
    if(F    ==NULL    || VertData==NULL) return U_ERROR;

    double MinD = 0.;
    double MaxD = 0.;

    UFaceEdgeIterator FEI(F);
    bool first = true;
    for(UEdge* E=FEI.GetStart(); E; E=FEI.GetNext())
    {
        int ind = FindVertex(E->GetOrg() ->GetID());
        if(ind<0) return U_ERROR;
        double Val = VertData[ind];
        if(first || Val<MinD) MinD = Val;
        if(first || Val>MaxD) MaxD = Val;
        first = false;
    }
    if(MinDat) *MinDat = MinD;
    if(MaxDat) *MaxDat = MaxD;
    return U_OK;
}
double UManifold::GetDataOrg(UEdge* E, const double* VertData) const
{
    if(this==NULL     || error !=U_OK  ) return 0.;
    if(vertices==NULL || NVertex<=0    ) return 0.;
    if(E==NULL        || VertData==NULL) return 0.;

    int ind = FindVertex(E->GetOrg()->GetID());
    if(ind<0) return 0.;
    return VertData[ind];
}

double UManifold::GetDataDest(UEdge* E, const double* VertData) const
{
    if(this==NULL     || error !=U_OK  ) return 0.;
    if(vertices==NULL || NVertex<=0    ) return 0.;
    if(E==NULL        || VertData==NULL) return 0.;
    
    int ind = FindVertex(E->GetDest()->GetID());
    if(ind<0) return 0.;
    return VertData[ind];
}

ErrorType UManifold::RemoveFlatTriangles(double Eps)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFlatTriangles(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::RemoveFlatTriangles(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(IsTriangulation()==false)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFlatTriangles(). Object is not a triangulation .\n");
        return U_ERROR;
    }
    int Nrem = 0;
    for(int n=0; n<NVertex; n++)
    {
        UVertex*  V  = vertices[n];
        UVertexEdgeIterator VEI(V);
        bool   IsPI  = false;
        int    NNeig = VEI.GetNNeighbour();
        UEdge*     E = VEI.GetStart();
        for(int in=0; in<NNeig; in++)
        {
            if(V->IsSectorAnglePI(E, Eps)==true)
            {
                IsPI = true;
                break;
            }
            E = VEI.GetNext();
        }

        if(IsPI)
        {
            *V = V->GetGravityPoint();
            Nrem++;
        }
    }
    if(Nrem>0) CI.AddToLog("Note: UManifold::RemoveFlatTriangles(). Removed %d degenerated triangles. \n", Nrem);
    return U_OK;
}

ErrorType UManifold::SmoothSphereHarm(const UManifold* MSphere, int NSphereHarm, double TruncThresh, bool UseL1norm, double* ErrDist, double*ErrMax, double*ErrMed, double** CoefXYZ)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) ||
        (NQEdge <=0 || qedges  ==NULL))
    {
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }

    if(CoefXYZ) *CoefXYZ = NULL;
    if(MSphere==NULL || MSphere->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). UManifold argument NULL or erroneous. \n");
        return U_ERROR;
    }
    if(MSphere->GetNVertex()<=0 || MSphere->GetNVertex()!=NVertex)
    {
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). UManifold argument NVertex out of range (=%d ).\n", MSphere->GetNVertex());
        return U_ERROR;
    }
    int NSpherePoints = MSphere->GetNVertex();
    if(NSphereHarm>NSpherePoints)
    {
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). NSphereHarm (=%d) out of range (NVertex=%d ).\n", NSphereHarm, MSphere->GetNVertex());
        return U_ERROR;
    }
    for(int n=0; n<NSpherePoints; n++)
    {
        int ID = MSphere->vertices[n]->GetID();
        if(FindVertex(ID)<0)
        {
            CI.AddToLog("ERROR: UManifold::SmoothSphereHarm(). Vertex not found: ID = %d .\n");
            return U_ERROR;
        }
    }
    double* Matrix = new double[  NSpherePoints*NSphereHarm];
    double* Coeff  = new double[3*NSphereHarm  ];
    double* Coord  = new double[3*NSpherePoints];

    if(Matrix==NULL || Coeff==NULL || Coord==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm() Memory allocation NSphereHarm = %d, NSpherePoints = %d   .\n", NSphereHarm, NSpherePoints);
        delete[] Matrix;
        delete[] Coeff;
        delete[] Coord;
        return U_ERROR;
    }

// Compute the system Matrix
    UVector3 Center = this->GetCenter();
    for(int n=0; n<NSpherePoints; n++)
    {
        int         ID           = MSphere->vertices[n]->GetID();
        int         Index        = FindVertex(ID);
        Coord[                n] = vertices[Index]->Getx()-Center.Getx();
        Coord[  NSpherePoints+n] = vertices[Index]->Gety()-Center.Gety();
        Coord[2*NSpherePoints+n] = vertices[Index]->Getz()-Center.Getz();
        double      Th           = MSphere->vertices[n]->GetTheta();
        double      Fi           = MSphere->vertices[n]->GetFi();
        for(int k=0;k<NSphereHarm; k++)
            Matrix[n*NSphereHarm+k] = USphereHarm::SphereHarm(k, Th, Fi);
    }

    ErrorType E = U_OK;
    if(UseL1norm)
    {
        if(SolveL1Norm(Matrix, Coeff              ,  Coord                , NSpherePoints, NSphereHarm)!=U_OK  ||
           SolveL1Norm(Matrix, Coeff+  NSphereHarm,  Coord+  NSpherePoints, NSpherePoints, NSphereHarm)!=U_OK  ||
           SolveL1Norm(Matrix, Coeff+2*NSphereHarm,  Coord+2*NSpherePoints, NSpherePoints, NSphereHarm)!=U_OK )   E = U_ERROR;
    }
    else
    {
        if(TruncThresh<0) TruncThresh = EIGEN_THRESHOLD;
        if(SolveL2Norm(Matrix, Coeff              ,  Coord                , NSpherePoints, NSphereHarm, TruncThresh)!=U_OK  ||
           SolveL2Norm(Matrix, Coeff+  NSphereHarm,  Coord+  NSpherePoints, NSpherePoints, NSphereHarm, TruncThresh)!=U_OK  ||
           SolveL2Norm(Matrix, Coeff+2*NSphereHarm,  Coord+2*NSpherePoints, NSpherePoints, NSphereHarm, TruncThresh)!=U_OK )   E = U_ERROR;
    }
    if(E!=U_OK)
    {
        delete[] Matrix;
        delete[] Coeff;
        delete[] Coord;
        CI.AddToLog("ERROR: UManifold::SmoothSphereHarm() Soving system matrix.\n");
        return U_ERROR;
    }
    for(int n=0; n<NSpherePoints; n++)
    {
        Coord[n] = 0;
        double X = 0;
        double Y = 0;
        double Z = 0;
        for(int k=0; k<NSphereHarm; k++)
        {
            X += Matrix[n*NSphereHarm+k] * Coeff[              k];
            Y += Matrix[n*NSphereHarm+k] * Coeff[  NSphereHarm+k];
            Z += Matrix[n*NSphereHarm+k] * Coeff[2*NSphereHarm+k];
        }
        UVector3 Xsmo  = Center + UVector3(X, Y, Z);
        Coord[n]       = (Xsmo - *(vertices[n])).GetNorm();
        *(vertices[n]) = Xsmo;
    }
    if(ErrDist) *ErrDist = GetAverage(Coord, NSpherePoints);
    if(ErrMax ) *ErrMax  = GetMax    (Coord, NSpherePoints);
    if(ErrMed ) *ErrMed  = GetMedian (Coord, NSpherePoints);

    delete[] Coord;
    delete[] Matrix;

    if(CoefXYZ) *CoefXYZ = Coeff;
    else          delete[] Coeff;

    return U_OK;
}
ErrorType UManifold::ComputeFaceMedian(double* FaceData, const int* Skip) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ComputeFaceMedian(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::ComputeFaceMedian(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(FaceData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ComputeFaceMedian(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    double* FiltData = GetFaceMedian(FaceData, Skip);
    if(FiltData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ComputeFaceMedian(). Computing median filter. \n");
        return U_ERROR;
    }
    for(int k=0; k<NFace; k++) FaceData[k] = FiltData[k];
    delete[] FiltData;
    return U_OK;
}
double* UManifold::GetFaceMedian(const double* FaceData, const int* Skip) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(FaceData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Invalid NULL argument. \n");
        return NULL;
    }

    int*    NeighID  = new int   [MAXEIGHBOR];
    double* NData    = new double[MAXEIGHBOR];
    double* FData    = new double[NFace];
    if(FData==NULL || NeighID==NULL || NData==NULL)
    {
        delete[] FData; delete[] NeighID; delete[] NData;
        CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Memory allocation: NFace = %d. \n", NFace);
        return NULL;
    }
    for(int k=0; k<NFace     ; k++) FData  [k] = 0.;
    for(int k=0; k<MAXEIGHBOR; k++) NeighID[k] = -1;
    for(int k=0; k<MAXEIGHBOR; k++) NData  [k] = 0.;

    for(int k=0; k<NFace; k++)
    {
        if(Skip && Skip[k])
        {
            FData[k] = FaceData[k];
        }
        else
        {
            int NNeigh = 0;
            if(faces[k]->GetNeigborFaceIDs(NeighID, &NNeigh)!=U_OK)
            {
                delete[] FData; delete[] NeighID; delete[] NData;
                CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Getting neighbors of face k = %d .\n", k);
                return NULL;
            }
            for(int n=0, m=0; n<NNeigh; n++)
            {
                int ifd  = FindFace(NeighID[n]);
                if(ifd<0)
                {
                    delete[] FData; delete[] NeighID; delete[] NData;
                    CI.AddToLog("ERROR: UManifold::GetFaceMedian(). Neighboring face not found: ID = %d .\n", NeighID[n]);
                    return NULL;
                }
                if(Skip && Skip[ifd])  NData[m++] = FaceData[ifd];
                else                   NNeigh--;
            }
            if(NNeigh) FData[k] = GetMedian(NData, NNeigh);
        }
    }
    delete[] NeighID; delete[] NData;
    return FData;
}
ErrorType UManifold::RemoveFaceOutliers(double* FaceData, double MinFrac, double MaxFrac) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(FaceData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(MinFrac<0. || MinFrac>1. || MinFrac+MaxFrac>=1 ||
       MaxFrac<0. || MaxFrac>1. ) 
    {
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Invalid fractions: MinFrac = %f, MaxFrac = %f   . \n", MinFrac, MaxFrac);
        return U_ERROR;
    }
    bool    Fabs      = false;
    bool    HighFirst = false;
    int*    Index     = GetOrderIndexArray(FaceData, NFace, Fabs, HighFirst);
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Ordering data. \n");
        return U_ERROR;
    }
    int NLow  = int(MinFrac*NFace);
    int NHigh = int(MaxFrac*NFace);
    
    int*    NeighID  = new int   [MAXEIGHBOR];
    double* NData    = new double[MAXEIGHBOR];
    double* FData    = new double[NFace];
    if(FData==NULL || NeighID==NULL || NData==NULL || Index==NULL)
    {
        delete[] FData; delete[] NeighID; delete[] NData; delete[] Index;
        CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Memory allocation: NFace = %d, or ordering data. \n", NFace);
        return U_ERROR;
    }
    for(int k=0; k<NFace     ; k++) FData  [k] = FaceData[k];
    for(int k=0; k<MAXEIGHBOR; k++) NeighID[k] = -1;
    for(int k=0; k<MAXEIGHBOR; k++) NData  [k] = 0.;

    int Nrem  = 0;
    for(int k=0; k<NFace; k++)
    {
        if(k==NLow) k = MAX( (NFace-NHigh), (NLow+1));

        int krem = Index[k];

        int NNeigh = 0;
        if(faces[krem]->GetNeigborFaceIDs(NeighID, &NNeigh)!=U_OK)
        {
            delete[] FData; delete[] NeighID; delete[] NData; delete[] Index;
            CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Getting neighbors of face k = %d .\n", k);
            return U_ERROR;
        }
        for(int n=0; n<NNeigh; n++)
        {
            int ifd  = FindFace(NeighID[n]);
            if(ifd<0)
            {
                delete[] FData; delete[] NeighID; delete[] NData; delete[] Index;
                CI.AddToLog("ERROR: UManifold::RemoveFaceOutliers(). Neighboring face not found: ID = %d .\n", NeighID[n]);
                return U_ERROR;
            }
            NData[n] = FaceData[ifd];
        }
        if(NNeigh) 
        {
            FData[krem] = GetMedian(NData, NNeigh); 
            Nrem++;
        }
    }
    for(int k=0; k<NFace; k++) FaceData[k] = FData[k];

    delete[] FData; delete[] NeighID; delete[] NData; delete[] Index;
    
    CI.AddToLog("Note: UManifold::RemoveFaceOutliers().  %d outliers removed.\n", Nrem);    
    return U_OK;
}
ErrorType UManifold::RemoveVertexOutliers(double* VertexData, double MinFrac, double MaxFrac) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(MinFrac<0. || MinFrac>1. || MinFrac+MaxFrac>=1 ||
       MaxFrac<0. || MaxFrac>1. ) 
    {
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Invalid fractions: MinFrac = %f, MaxFrac = %f   . \n", MinFrac, MaxFrac);
        return U_ERROR;
    }
    bool    Fabs      = false;
    bool    HighFirst = false;
    int*    Index     = GetOrderIndexArray(VertexData, NVertex, Fabs, HighFirst);
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Ordering data. \n");
        return U_ERROR;
    }
    int NLow  = int(MinFrac*NVertex);
    int NHigh = int(MaxFrac*NVertex);
    
    int*    NeighID  = new int   [MAXEIGHBOR];
    double* NData    = new double[MAXEIGHBOR];
    double* VData    = new double[NVertex];
    if(VData==NULL || NeighID==NULL || NData==NULL || Index==NULL)
    {
        delete[] VData; delete[] NeighID; delete[] NData; delete[] Index;
        CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Memory allocation: NVertex = %d, or ordering data. \n", NVertex);
        return U_ERROR;
    }
    for(int k=0; k<NVertex   ; k++) VData  [k] = VertexData[k];
    for(int k=0; k<MAXEIGHBOR; k++) NeighID[k] = -1;
    for(int k=0; k<MAXEIGHBOR; k++) NData  [k] = 0.;

    int Nrem  = 0;
    for(int k=0; k<NVertex; k++)
    {
        if(k==NLow) k = MAX( (NVertex-NHigh), (NLow+1));

        int krem = Index[k];

        int NNeigh = 0;
        if(vertices[krem]->GetNeigborIDs(NeighID, &NNeigh)!=U_OK)
        {
            delete[] VData; delete[] NeighID; delete[] NData; delete[] Index;
            CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Getting neighbors of vertex k = %d .\n", k);
            return U_ERROR;
        }
        for(int n=0; n<NNeigh; n++)
        {
            int ivd  = FindVertex(NeighID[n]);
            if(ivd<0)
            {
                delete[] VData; delete[] NeighID; delete[] NData; delete[] Index;
                CI.AddToLog("ERROR: UManifold::RemoveVertexOutliers(). Neighboring vertex not found: ID = %d .\n", NeighID[n]);
                return U_ERROR;
            }
            NData[n] = VertexData[ivd];
        }
        if(NNeigh) 
        {
            VData[krem] = GetMedian(NData, NNeigh); 
            Nrem++;
        }
    }
    for(int k=0; k<NVertex; k++) VertexData[k] = VData[k];

    delete[] VData; delete[] NeighID; delete[] NData; delete[] Index;
    
    CI.AddToLog("Note: UManifold::RemoveVertexOutliers().  %d outliers removed.\n", Nrem);    
    return U_OK;
}

ErrorType UManifold::ComputeVertexMedian(double* VertexData, const int* Skip) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::ComputeVertexMedian(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::ComputeVertexMedian(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ComputeVertexMedian(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    double* FiltData = GetVertexMedian(VertexData, Skip);
    if(FiltData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::ComputeVertexMedian(). Computing median filter. \n");
        return U_ERROR;
    }
    for(int k=0; k<NVertex; k++) VertexData[k] = FiltData[k];
    delete[] FiltData;
    return U_OK;
}
double* UManifold::GetVertexMedian(const double* VertexData, const int* Skip) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Object NULL or erroneous. \n");
        return NULL;
    }
    if( (NVertex<=0 || vertices==NULL) ||
        (NFace  <=0 || faces   ==NULL) )
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return NULL;
    }
    if(VertexData==NULL)
    {
        CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Invalid NULL argument. \n");
        return NULL;
    }

    int*    NeighID  = new int   [MAXEIGHBOR];
    double* NData    = new double[MAXEIGHBOR];
    double* VData    = new double[NVertex];
    if(VData==NULL || NeighID==NULL || NData==NULL)
    {
        delete[] VData; delete[] NeighID; delete[] NData;
        CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Memory allocation: NVertex = %d. \n", NVertex);
        return NULL;
    }
    for(int k=0; k<NVertex   ; k++) VData  [k] = 0.;
    for(int k=0; k<MAXEIGHBOR; k++) NeighID[k] = -1;
    for(int k=0; k<MAXEIGHBOR; k++) NData  [k] = 0.;

    for(int k=0; k<NVertex; k++)
    {
        if(Skip && Skip[k])
        {
            VData[k] = VertexData[k];
        }
        else
        {
            int NNeigh = 0;
            if(vertices[k]->GetNeigborIDs(NeighID, &NNeigh)!=U_OK)
            {
                delete[] VData; delete[] NeighID; delete[] NData;
                CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Getting neighbors of face k = %d .\n", k);
                return NULL;
            }
            for(int n=0, m=0; n<NNeigh; n++)
            {
                int ivd  = FindVertex(NeighID[n]);
                if(ivd<0)
                {
                    delete[] VData; delete[] NeighID; delete[] NData;
                    CI.AddToLog("ERROR: UManifold::GetVertexMedian(). Neighboring face not found: ID = %d .\n", NeighID[n]);
                    return NULL;
                }
                if(Skip && !Skip[ivd]) NNeigh--;
                else                   NData[m++] = VertexData[ivd];
            }
            if(NNeigh) VData[k] = GetMedian(NData, NNeigh);
        }
    }
    delete[] NeighID; delete[] NData;
    return VData;
}

ErrorType UManifold::WriteConnectivityText(UFileName Ftxt) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UManifold::WriteConnectivityText(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    FILE* fp = fopen(Ftxt, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UManifold::WriteConnectivityText(). Cannot create or open file %s. \n", (const char*)Ftxt);
        return U_ERROR;
    }
    fclose(fp);
    fp = fopen(Ftxt, "at", false);

    fprintf(fp, "NVertex       =  %d \n", NVertex);
    fprintf(fp, "NVertexAlloc  =  %d \n", NVertexAlloc);
    fprintf(fp, "LastVertexID  =  %d \n", LastVertexID);
    fprintf(fp, "NFace         =  %d \n", NFace);
    fprintf(fp, "NFaceAlloc    =  %d \n", NFaceAlloc);
    fprintf(fp, "LastFaceID    =  %d \n", LastFaceID);
    fprintf(fp, "NQEdge        =  %d \n", NQEdge);
    fprintf(fp, "NQEdgeAlloc   =  %d \n", NQEdgeAlloc);
    fprintf(fp, "LastQEdgeID   =  %d \n", LastQuadEdgeID);

    if( (NVertex>0 && vertices==NULL) ||
        (NFace  >0 && faces   ==NULL) ||
        (NQEdge >0 && qedges  ==NULL))
    {
        fclose(fp);
        CI.AddToLog("ERROR: UManifold::WriteConnectivityText(). Object not properly set (NVertex, NFace, NQEdge) = (%d,%d,%d). \n", NVertex, NFace, NQEdge);
        return U_ERROR;
    }
    fprintf(fp, "// \n");
    fprintf(fp, "// \n");
    fprintf(fp, "// Vertices:\n");
    fprintf(fp, "// ID \tx \ty \tz \n");
    fclose(fp);
    for(int n=0; n<NVertex; n++)
    {
        fp = fopen(Ftxt, "at", false);
        fprintf(fp,"%d \t%f \t%f \t%f \n",vertices[n]->GetID(), vertices[n]->Getx(), vertices[n]->Gety(), vertices[n]->Getz());
        fclose(fp);
    }
    fp = fopen(Ftxt, "at", false);
    fprintf(fp, "// \n");
    fprintf(fp, "// Neighboring vertices\n");
    fprintf(fp, "// ID \tNNeigh \tNeighboring IDs \n");
    fclose(fp);
    for(int n=0; n<NVertex; n++)
    {
        fp = fopen(Ftxt, "at", false);
        UVertex* V = vertices[n];

        UVertexEdgeIterator VEI(V);
        int NNeig  = VEI.GetNNeighbour();
        
        if(NNeig<0)
        {
            fprintf(fp,"%d \t%d \n",V->GetID(), NNeig);
            CI.AddToLog("ERROR: UManifold::WriteConnectivityText(). Invalid neighbors at vertex %d, with ID=%d. \n", n, V->GetID());
        }
        else
        {
            fprintf(fp,"%d \t%d ",V->GetID(), NNeig);
            UEdge*   E = VEI.GetStart();
            do
            {
                if(E && E->GetSym() && E->GetSym()->GetOrg())
                    fprintf(fp,"\t%d ", E->GetSym()->GetOrg()->GetID());
            }
            while(E=VEI.GetNext());
            fprintf(fp, "\n");
        }
        fclose(fp);
    }

    fp = fopen(Ftxt, "at", false);
    fprintf(fp, "// \n");
    fprintf(fp, "// \n");
    fprintf(fp, "// Faces and neighbors  \n");
    fprintf(fp, "// ID \tNNeigh \tNeighboring vertex IDs \n");
    fclose(fp);
    for(int n=0; n<NFace; n++)
    {
        fp = fopen(Ftxt, "at", false);
        UFace*   F = faces[n];

        UFaceEdgeIterator FEI(F);
        int NNeig  = FEI.GetNNeighbour();
        if(NNeig<0)
        {
            fprintf(fp,"%d \t%d \n",F->GetID(), NNeig);
            CI.AddToLog("ERROR: UManifold::WriteConnectivityText(). Invalid neighbors at face %d, with ID=%d. \n", n, F->GetID());
        }
        else
        {
            fprintf(fp,"%d \t%d ",F->GetID(), NNeig);
            UEdge*   E = FEI.GetStart();
            do
            {
                if(E && E->GetSym() && E->GetSym()->GetOrg())
                    fprintf(fp,"\t%d ", E->GetSym()->GetOrg()->GetID());
            }
            while(E=FEI.GetNext());
            fprintf(fp, "\n");
        }
        fclose(fp);
    }

    fp = fopen(Ftxt, "at", false);
    fprintf(fp, "// \n");
    fprintf(fp, "// \n");
    fprintf(fp, "// Edges \n");
    fprintf(fp, "// EdgeID \tFromVert \tToVert \tLeftFace  \tRightFace \n");
    fclose(fp);
    for(int n=0; n<NQEdge; n++)
    {
        fp = fopen(Ftxt, "at", false);
        UEdge* E = qedges[n]->GetEdge();
        UEdge* S = qedges[n]->GetEdgeSym();
        if(E&&S   &&   E->GetOrg()&&S->GetOrg()   &&   E->GetDest()&&S->GetDest()   &&   E->GetONext()&&S->GetONext())
        {
            fprintf(fp,"%d \t%d \t%d \t",qedges[n]->GetID(), E->GetOrg()->GetID(), E->GetDest()->GetID());
            fprintf(fp,"%d \t",E->GetLeftFace ()?E->GetLeftFace ()->GetID():-1);
            fprintf(fp,"%d \n",E->GetRightFace()?E->GetRightFace()->GetID():-1);
        }
        fclose(fp);
    }
    return U_OK;
}

UManifold* GetJunction(int NVertexBase, int Height, int NBridge, int NVertexTopLeft, int NVertexTopRight, int* FBotID, int* FTopLID, int* FTopRID)
{
    if(NVertexBase<=3 || Height<2 || NBridge<1 || NVertexTopLeft<=3 || NVertexTopRight<=3)
    {
        CI.AddToLog("ERROR: GetJunction(). Parameter(s) out of range: NVertexBase=%d, Height=%d, NBridge=%d, NVertexTopLeft=%d, NVertexTopRight=%d  .\n", NVertexBase, Height, NBridge, NVertexTopLeft, NVertexTopRight);
        return NULL;
    }
    if(FBotID==NULL || FTopLID==NULL || FTopRID==NULL)
    {
        CI.AddToLog("ERROR: GetJunction(). Invalid NULL pointer argument(s)  .\n");
        return NULL;
    }
    int        FTopID     = -1;
    int        Height2    = (Height+1)/2;
    int        NVertexTop = 2*NBridge+NVertexTopLeft+NVertexTopRight;
    UManifold* MFrust     = GetFrustum(NVertexBase, NULL, NVertexTop, NULL, Height2, FBotID, &FTopID);
    int*       SewBuf     = new int[2*NBridge];

    if(MFrust==NULL || MFrust->GetError()!=U_OK || SewBuf==NULL)
    {
        delete MFrust; delete[] SewBuf;
        CI.AddToLog("ERROR: GetJunction(). Creating basis frustum part. \n");
        return NULL;
    }

    UFace* FFrTop = MFrust->GetFace( FTopID);
    UFace* FFrBot = MFrust->GetFace(*FBotID);
    if(FFrTop==NULL || FFrBot==NULL)
    {
        delete MFrust; delete[] SewBuf;
        CI.AddToLog("ERROR: GetJunction(). Finding bottom or top faces from IDs %d and %d  .\n", FTopID, *FBotID);
        return NULL;
    }
    for(int k=0; k<NBridge; k++)
    {
        SewBuf[2*k  ] = FFrTop->GetEdge(                           k)->GetID()/4;
        SewBuf[2*k+1] = FFrTop->GetEdge(2*NBridge+NVertexTopLeft-1-k)->GetID()/4;
    }
    int EdgeIDL = FFrTop->GetEdge(  NBridge               )->GetID()/4;
    int EdgeIDR = FFrTop->GetEdge(2*NBridge+NVertexTopLeft)->GetID()/4;

    for(int k=0; k<NBridge; k++)
        if(MFrust->MergeEdgesSameFace(SewBuf[2*k  ], SewBuf[2*k+1])!=U_OK)
        {
            delete MFrust; delete[] SewBuf;
            CI.AddToLog("ERROR: GetJunction(). Sewing step %d of %d. \n", k, NBridge);
            return NULL;
        }

    delete[] SewBuf;
    int        FBotIDL    =-1;
    int        FBotIDR    =-1;
    int        FTopIDL    =-1;
    int        FTopIDR    =-1;
    UManifold* MBranL     = GetCylinder(NVertexTopLeft , NULL, NULL, Height-Height2, &FBotIDL, &FTopIDL); 
    UManifold* MBranR     = GetCylinder(NVertexTopRight, NULL, NULL, Height-Height2, &FBotIDR, &FTopIDR); 

    if(MFrust==NULL || MFrust->GetError()!=U_OK || MBranL==NULL || MBranL->GetError()!=U_OK || MBranR==NULL || MBranR->GetError()!=U_OK)
    {
        delete MFrust; delete MBranL; delete MBranR;
        CI.AddToLog("ERROR: GetJunction(). Left and/or right sub-parts  .\n");
        return NULL;
    }

    *FTopLID    = FTopIDL + MFrust->LastFaceID;
    *FTopRID    = FTopIDR + MFrust->LastFaceID + MBranL->LastFaceID;

    int FaceIDL = MFrust->GetQuadEdge(EdgeIDL)->GetRightFaceID();
    int FaceIDR = MFrust->GetQuadEdge(EdgeIDR)->GetRightFaceID();

    if(MFrust->MergeFaces(FaceIDL, *MBranL, FBotIDL)!=U_OK || 
       MFrust->MergeFaces(FaceIDR, *MBranR, FBotIDR)!=U_OK)
    {
        delete MFrust; delete MBranL; delete MBranR;
        CI.AddToLog("ERROR: GetJunction(). Joining basis part with Left or Right junction.\n");
        return NULL;
    }
    delete MBranL; delete MBranR;

    UFace* FFrTopL = MFrust->GetFace(*FTopLID);
    UFace* FFrTopR = MFrust->GetFace(*FTopRID);

    if(FFrTopL==NULL || FFrTopL->GetNEdge()!=NVertexTopLeft || FFrTopR==NULL || FFrTopR->GetNEdge()!=NVertexTopRight)
    {
        delete MFrust;
        CI.AddToLog("ERROR: GetJunction(). Top faces not found or inconsistent: Left (%,%d), Right (%d, %d).\n", FFrTopL?FFrTopL->GetNEdge():-1, NVertexTopLeft, FFrTopR?FFrTopR->GetNEdge():0, NVertexTopRight);
        return NULL;
    }

    for(int n=0; n<NVertexBase    ; n++) FFrBot ->GetEdge(n)->GetOrg()->SetPoint(UVector3(       cos(n*PI2/NVertexBase    ),     sin(-n*PI2/NVertexBase    ), -1.));
    for(int n=0; n<NVertexTopLeft ; n++) FFrTopL->GetEdge(n)->GetOrg()->SetPoint(UVector3(-1+0.5*cos(n*PI2/NVertexTopLeft ), 0.5*sin( n*PI2/NVertexTopLeft ), +1.));
    for(int n=0; n<NVertexTopRight; n++) FFrTopR->GetEdge(n)->GetOrg()->SetPoint(UVector3( 1+0.3*cos(PI+n*PI2/NVertexTopRight),0.3*sin(PI+n*PI2/NVertexTopRight), +1.));

    return MFrust;
}
UManifold* GetFrustum(int NVertexBase, const UVector3* BasePoints, int NVertexTop, const UVector3* TopPoints, int Height, int* FBotID, int* FTopID)
{
    if(NVertexBase<=3 || Height<1 || NVertexTop<=3)
    {
        CI.AddToLog("ERROR: GetFrustum(). Parameter(s) out of range: NVertexBase=%d, Height=%d, NVertexTop=%d  .\n", NVertexBase, Height, NVertexTop);
        return NULL;
    }
    if( (BasePoints&&!TopPoints) || (!BasePoints&&TopPoints) )
    {
        CI.AddToLog("ERROR: GetFrustum(). Bottom and top points should be either set both, or neither should be set.\n");
        return NULL;
    }

    int MaxBaseTop = MAX(NVertexBase, NVertexTop);
    UManifold*  MS = NVertexBase==NVertexTop ? GetCylinder(MaxBaseTop, BasePoints, TopPoints, Height, FBotID, FTopID) : 
                                               GetCylinder(MaxBaseTop, NULL      , NULL     , Height, FBotID, FTopID);
    if(MS==NULL || MS->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetFrustum(). Creating cylinder object  .\n");
        return NULL;
    }
    if(NVertexBase==NVertexTop) return MS;

    UVertex**     vertices = MS->vertices;
    UQuadEdge**   qedges   = MS->qedges;
    UFace**       faces    = MS->faces;
    int*          rembuf   = new int[MaxBaseTop];
    int*          NPL      = new int[Height +1 ];
    UVector3*     pBuff    = new UVector3[NVertexBase+NVertexTop];
    if(rembuf==NULL || NPL==NULL || pBuff==NULL)
    {
        CI.AddToLog("ERROR: GetFrustum(). Memory allocation .\n");
        delete MS; delete[] rembuf; delete[] NPL; delete[] pBuff;
        return NULL;
    }

// Remove edges until requested size
    for(int ic=0; ic<=Height; ic++) // run from Base to Top.
    {
        int NvertRem = NVertexBase > NVertexTop ?  int(0.5 + (NVertexBase-NVertexTop )* (ic       )/(double(Height))) :
                                                   int(0.5 + (NVertexTop -NVertexBase)* (Height-ic)/(double(Height)));
        NPL[ic]      = MaxBaseTop - NvertRem;
        if(NvertRem<=0) continue;

        int random   = MaxBaseTop - NvertRem/2;
        for(int k=0; k<MaxBaseTop; k++) rembuf[k] = -1;
        for(int k=0; k<NvertRem  ; k++) rembuf[k] = (int(0.5 + (MaxBaseTop-1.)* k/double(NvertRem)) + random)%MaxBaseTop;
        
        int kstart = -1;
        int istay =  -1;
        for(int k=0; k<NvertRem ; k++) 
        {
            int k1 = k ? k-1: NvertRem-1;
            istay  = (rembuf[k]-1+MaxBaseTop)%MaxBaseTop;
            if(istay!=rembuf[k1]) {kstart=k; break;}
        }
        for(int kk=kstart; kk<kstart+NvertRem; kk++)
        {
            int k    = kk%NvertRem;
            int irem = rembuf[k];
            int ind  = MS->FindQuadEdge(ic*MaxBaseTop + istay, ic*MaxBaseTop + irem);
            if(ind<0) 
            {
                CI.AddToLog("ERROR: GetFrustum(). Edge not found, ic = %d: from %d to %d: k=%d.\n", ic, istay, irem, k);
                delete MS; delete[] rembuf; delete[] NPL; delete[] pBuff;
                return NULL;
            }
            if(ic==0) MS->RemoveEdgeMergeVertices(qedges[ind]->GetEdge());
            else      MS->RemoveEdgeMergeVertices(qedges[ind]->GetEdgeSym());

            int k1   =  (kk+1)%NvertRem;
            if((irem+1)%MaxBaseTop==rembuf[k1]) continue; // Delete two or more subsequent vertices and keep istay
            istay    = (rembuf[k1]+MaxBaseTop-1)%MaxBaseTop;
        }
    }
    delete[] rembuf;

    if(MS->RenumberVerticesFacesEdges()!=U_OK)
    {
        delete MS; delete[] NPL; delete[] pBuff;
        CI.AddToLog("ERROR: GetFrustum(). Rearranging vertices, faces or edges.\n");
        return NULL;
    }
    if(FBotID) *FBotID = 0;
    if(FTopID) *FTopID = MS->LastFaceID;

    UVector3* pB = pBuff; 
    UVector3* pT = pBuff + NVertexBase; 

    if(BasePoints && TopPoints)
    {
        int istart = MS->NVertex-NVertexTop;
        for(int i=0; i<NVertexBase; i++) pB[i] = *vertices[i       ] = BasePoints[i];
        for(int i=0; i<NVertexTop ; i++) pT[i] = *vertices[istart+i] = TopPoints[i];
    }
    else
    {
        int istart = MS->NVertex-NVertexTop;
        for(int i=0; i<NVertexBase; i++) pB[i] = *vertices[i       ];
        for(int i=0; i<NVertexTop ; i++) pT[i] = *vertices[istart+i];
    }
    int istart = NPL[0];
    for(int ic=1; ic<Height; ic++)
    {
        double F   = ic/double(Height);
        for(int i=0; i<MaxBaseTop; i++)
        {
            int nb = NVertexBase > NVertexTop ? i : int(0.5+(NVertexBase-1.)*i/double(MaxBaseTop-1));
            int nt = NVertexBase < NVertexTop ? i : int(0.5+(NVertexTop -1.)*i/double(MaxBaseTop-1));
            int nc =                                int(0.5+(NPL[ic]    -1.)*i/double(MaxBaseTop-1));
            *vertices[istart+nc] = (1.-F)*pB[nb] + F*(pT[nt]);
        }
        istart    += NPL[ic];
    }
    delete[] NPL; delete[] pBuff;

    return MS;
}

UManifold* GetCylinder(int NVertexBase, const UVector3* BasePoints, const UVector3* TopPoints, int Height, int* FBotID, int* FTopID)
{
    if(NVertexBase<=3 || Height<1)
    {
        CI.AddToLog("ERROR: GetCylinder(). Parameter(s) out of range: NVertexBase=%d, Height=%d  .\n", NVertexBase, Height);
        return NULL;
    }
    if( (BasePoints&&!TopPoints) || (!BasePoints&&TopPoints) )
    {
        CI.AddToLog("ERROR: GetCylinder(). Bottom and top points should be either set both, or neither should be set.\n");
        return NULL;
    }
    
    UManifold* MS = new UManifold();
    if(MS==NULL || MS->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetCylinder(). Creating output object  .\n");
        return NULL;
    }
    if(FBotID) *FBotID = -1;
    if(FTopID) *FTopID = -1;

// First create cylinder walls
    ErrorType E = U_OK;
    UFace* Fbot = MS->AddNewFace(); // First face: bottom
    for(int ic=0; ic<Height; ic++)
    {
        for(int n=0; n<NVertexBase; n++)
        {
            int k11 =  ic   *NVertexBase+n;
            int k21 = (ic+1)*NVertexBase+n;
            int k12 =  ic   *NVertexBase+((n+1)%NVertexBase);
            int k22 = (ic+1)*NVertexBase+((n+1)%NVertexBase);
            if(E==U_OK) E = MS->AddTriangle(k11, k22, k12); // add triangle and vertices
            if(E==U_OK) E = MS->AddTriangle(k11, k21, k22);
            if(E!=U_OK) break;
        }
        if(E!=U_OK) break;
    }
    if(E!=U_OK)
    {
        delete MS;
        CI.AddToLog("ERROR: GetCylinder(). Adding triangles .\n");
        return NULL;
    }
    UFace* Ftop = MS->AddNewFace(); // Last face ID: top

    UVertex**     vertices = MS->vertices;
    UQuadEdge**   qedges   = MS->qedges;
    UFace**       faces    = MS->faces;
    UVertex**     verttop  = vertices+Height*NVertexBase;

// set default coords: bottom and top
    for(int n=0; n<NVertexBase; n++)
    {
        if(BasePoints&&TopPoints) 
        {
            *vertices[n] = BasePoints[n];
            *verttop [n] = TopPoints[n];
        }
        else
        {
            double     F = PI2*n/double(NVertexBase);
            *vertices[n] = UVector3(cos(F), -sin(F), 0.);
            *verttop [n] = UVector3(cos(F), -sin(F), 1.);
        }
    }

// set default coords: intermediate layers
    for(int ic=1; ic<Height; ic++)
    {
        double H = ic/double(Height);
        for(int n=0; n<NVertexBase; n++)   *vertices[ic*NVertexBase+n] = (1-H)*(*vertices[n]) + H*(*verttop [n]);
    }

// Sew bottom and top faces to close off
    for(int n=0; n<NVertexBase; n++) 
    {
        int n1 = (n+1)%NVertexBase;
        int n2 = (n+2)%NVertexBase;

        UQuadEdge* QE10 = qedges[ MS->FindQuadEdge(vertices[n1]->GetID(), vertices[n ]->GetID()) ];
        UQuadEdge* QE21 = qedges[ MS->FindQuadEdge(vertices[n2]->GetID(), vertices[n1]->GetID()) ];
    
        QE21->GetEdgeSym()   ->SetONext(QE10->GetEdge()   );
        QE10->GetEdge()      ->SetRightFace (Fbot);
        QE10->GetEdgeRot()   ->SetONext(QE21->GetEdgeRot());

        n1 = (n+NVertexBase-1)%NVertexBase;
        n2 = (n+NVertexBase-2)%NVertexBase;
        UVertex** vertices2 = vertices+NVertexBase*Height;

        QE10 = qedges[ MS->FindQuadEdge(vertices2[n1]->GetID(), vertices2[n ]->GetID()) ];
        QE21 = qedges[ MS->FindQuadEdge(vertices2[n2]->GetID(), vertices2[n1]->GetID()) ];

        QE21->GetEdgeSym()   ->SetONext(QE10->GetEdge()   );
        QE10->GetEdge()      ->SetRightFace (Ftop);
        QE10->GetEdgeRot()   ->SetONext(QE21->GetEdgeRot());
    }

    MS->RenumberVerticesFacesEdges();
    if(FBotID) *FBotID = Fbot->GetID();
    if(FTopID) *FTopID = Ftop->GetID();

    return MS;
}
UManifold* GetPyramid(int NVertexBase, const UVector3* BasePoints, int MaxHeight, int* FBasisID, bool FlatManifold)
{
    if(NVertexBase<=3 || MaxHeight<1)
    {
        CI.AddToLog("ERROR: GetPyramid(). Parameter(s) out of range: NVertexBase=%d, MaxHeight=%d  .\n", NVertexBase, MaxHeight);
        return NULL;
    }
    UManifold* MS = new UManifold();
    if(MS==NULL || MS->GetError()!=U_OK)
    {
        delete MS;
        CI.AddToLog("ERROR: GetPyramid(). Creating output object  .\n");
        return NULL;
    }
    if(FBasisID) *FBasisID = -1;

// First create cylinder walls
    ErrorType E = U_OK;
    if(MaxHeight==1)
    {
        for(int n=0; n<NVertexBase; n++)
        {
            int k0 = (n+1)%NVertexBase;
            int k1 =  n;
            int k2 = NVertexBase;
            if(E==U_OK) E = MS->AddTriangle(k0, k1, k2); // add triangle and vertices
            if(E!=U_OK) break;
        }
    }
    else
    {
        for(int ic=0; ic<MaxHeight-1; ic++)
        {
            for(int n=0; n<NVertexBase; n++)
            {
                int k11 =  ic   *NVertexBase+n;
                int k21 = (ic+1)*NVertexBase+n;
                int k12 =  ic   *NVertexBase+((n+1)%NVertexBase);
                int k22 = (ic+1)*NVertexBase+((n+1)%NVertexBase);
                if(E==U_OK) E = MS->AddTriangle(k11, k22, k12); // add triangle and vertices
                if(E==U_OK) E = MS->AddTriangle(k11, k21, k22);
                if(E!=U_OK) break;
            }
            if(E!=U_OK) break;
        }
    }
    if(E!=U_OK)
    {
        delete MS;
        CI.AddToLog("ERROR: GetPyramid(). Adding triangles .\n");
        return NULL;
    }

    UVertex**     vertices = MS->vertices;
    UQuadEdge**   qedges   = MS->qedges;
    UFace**       faces    = MS->faces;

// set default coords
    for(int ic=0; ic<MaxHeight; ic++)
    {
        double H = (ic+1.)/double(MaxHeight);
        if(BasePoints)
            if(FlatManifold) for(int n=0; n<NVertexBase; n++) *vertices[ic*NVertexBase+n] = BasePoints[n];
            else             for(int n=0; n<NVertexBase; n++) *vertices[ic*NVertexBase+n] = UVector3(H*BasePoints[n].Getx(), H*BasePoints[n].Gety(), H);
        else
            for(int n=0; n<NVertexBase; n++) 
            {
                double F = PI2*n/double(NVertexBase);
                *vertices[ic*NVertexBase+n] = UVector3(H*cos(F), -H*sin(F), H);
            }
    }
// Add bottom and top faces to close off
    UFace* Fbot =                         MS->AddNewFace();
    UFace* Ftop = (MaxHeight==1) ? NULL : MS->AddNewFace();
    for(int n=0; n<NVertexBase; n++) 
    {
        int n1 = (n+1)%NVertexBase;
        int n2 = (n+2)%NVertexBase;

        UQuadEdge* QE10 = qedges[ MS->FindQuadEdge(vertices[n1]->GetID(), vertices[n ]->GetID()) ];
        UQuadEdge* QE21 = qedges[ MS->FindQuadEdge(vertices[n2]->GetID(), vertices[n1]->GetID()) ];
    
        QE21->GetEdgeSym()   ->SetONext(QE10->GetEdge()   );
        QE10->GetEdge()      ->SetRightFace (Fbot);
        QE10->GetEdgeRot()   ->SetONext(QE21->GetEdgeRot());
        if(MaxHeight==1) continue; 

        n1 = (n+NVertexBase-1)%NVertexBase;
        n2 = (n+NVertexBase-2)%NVertexBase;
        UVertex** vertices2 = vertices+NVertexBase*(MaxHeight-1);

        QE10 = qedges[ MS->FindQuadEdge(vertices2[n1]->GetID(), vertices2[n ]->GetID()) ];
        QE21 = qedges[ MS->FindQuadEdge(vertices2[n2]->GetID(), vertices2[n1]->GetID()) ];

        QE21->GetEdgeSym()   ->SetONext(QE10->GetEdge()   );
        QE10->GetEdge()      ->SetRightFace (Ftop);
        QE10->GetEdgeRot()   ->SetONext(QE21->GetEdgeRot());
    }
    if(MaxHeight>1)
    {
        int* rembuf = new int[NVertexBase];
        if(rembuf==NULL)
        {
            CI.AddToLog("ERROR: GetPyramid(). Memory allocation .\n");
            delete MS;
            return NULL;
        }

// Remove edges until bottom face is triangular
        for(int ic=0; ic<MaxHeight; ic++)
        {
            int NvertRem = NVertexBase - 3 - int(0.5 + (NVertexBase-3)* ic/(double(MaxHeight-1.)));
            if(NvertRem<=0) break;

            for(int k=0; k<NVertexBase; k++)      rembuf[k] = -1;
            if(NvertRem==1)                       rembuf[0] = ic *NVertexBase+1;
            else for(int k=0; k<NvertRem   ; k++) rembuf[k] = ic *NVertexBase + int(1.5 + (NVertexBase-2.)* k/double(NvertRem-1.));

            int kstay = ic *NVertexBase;
            for(int k=0; k<NvertRem; k++)
            {
                int krem = rembuf[k];
                int ind  = MS->FindQuadEdge(kstay, krem);
                if(ind<0) 
                {
                    CI.AddToLog("ERROR: GetPyramid(). Edge not found, ic = %d: from %d to %d.\n", ic, kstay, krem);
                    delete[] rembuf;
                    delete   MS;
                    return NULL;
                }
                if(ic) MS->RemoveEdgeMergeVertices(qedges[ind]->GetEdgeSym());
                else   MS->RemoveEdgeMergeVertices(qedges[ind]->GetEdge());

                if(krem+1==rembuf[k+1]) continue;
                kstay = rembuf[k+1]-1;
            }
        }
        delete[] rembuf;
    }
    MS->SortVertices();
    MS->SortFaces();
    MS->SortEdges();
    if(FBasisID) *FBasisID = (MaxHeight==1) ? Fbot->GetID() : Ftop->GetID();

    if(FlatManifold)
    {
        int* FixedIDs = new int[NVertexBase];
        if(FixedIDs)
        {
            int    NN     = 0;
            UFace* FFixed = (MaxHeight==1) ? Fbot : Ftop;
            FFixed->GetNeigborVertexIDs(FixedIDs, &NN);
            if(MS->InterpolateVertices(FixedIDs, NN, true, 1, U_PENALTY_NO, 0.)!=U_OK)
                CI.AddToLog("ERROR: GetPyramid(). Interpolating interior.\n");
        }
        else
            CI.AddToLog("ERROR: GetPyramid(). Memory allocation....\n");
    }
    return MS;
}
UManifold* GetTrangulatedCompletion(UFace* FPolygon, int* FBasisID)
{
    if(FPolygon==NULL)
    {
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Invalid NULL UFace pointer argument.\n");
        return NULL;
    }
    if(FBasisID) *FBasisID = -1;

    UPointList* PL = FPolygon->GetPointList();
    if(PL==NULL || PL->GetError()!=U_OK || PL->GetNpoints()<=3 || PL->GetNpoints()>=MAXEIGHBOR)
    {
        delete PL;
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Getting PointList, or FPolygon is triangular.\n");
        return NULL;
    }
    double Lam[3]      = {1.,1.,1.};
    UEuler PL2Mom      = PL->GetXfm2Moments(0, Lam);
    int    NVertexBase = PL->GetNpoints();
    int    Imax0       = 0;
    double Max0        = fabs(PL2Mom.xfm(PL->GetPoint(0)).Getx());
    for(int n=1; n<NVertexBase; n++)
    {
        UVector3 p = PL2Mom.xfm(PL->GetPoint(n));
        if(Max0<fabs(p[0])) continue;
        Imax0      = n;
        Max0       = fabs(p[0]);
    }
    double     Rat    = sqrt(Lam[0]/Lam[1]);

    if(Rat<1.5)
    {
        UManifold* MS = GetPyramid(NVertexBase, PL->GetPoints(), (9+NVertexBase)/6, FBasisID, true);
        delete PL;
        if(MS==NULL || MS->GetError()!=U_OK)
        {
            delete MS;
            CI.AddToLog("ERROR: GetTrangulatedCompletion(). Creating output object (Pyramid).\n");
            return NULL;
        }
        return MS;
    }

    int  Height     = MAX(1, int( (6+NVertexBase)/(3+2*Rat)));
    int  NVertexTop = MAX(4, int( 2*Rat*Height));
    int  FTopID     = -1;
    UManifold* MS   = GetFrustum(NVertexBase, NULL, NVertexTop, NULL, Height, FBasisID, &FTopID);

    if(MS==NULL || MS->GetError()!=U_OK)
    {
        delete MS; delete PL;
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Creating output object (Frustrum).\n");
        return NULL;
    }
    int  FBasisInd  = MS->FindFace(*FBasisID);
    int  FTopInd    = MS->FindFace(FTopID);
    UFace* Fbot     = FBasisInd<0? NULL : MS->faces[FBasisInd];
    UFace* Ftop     = FTopInd  <0? NULL : MS->faces[FTopInd  ];
    if(FBasisInd<0 || FTopInd<0 || Fbot==NULL || Ftop==NULL)
    {
        delete MS; delete PL;
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Finding frustrum top or bottom faces.\n");
        return NULL;
    }
    int  NSew      = NVertexTop-3;
    int* Dist      = new int[MS->NVertex];
    int* SewBuf    = new int[2*NSew];
    int  VBotInd   = MS->FindVertex(MS->faces[FBasisInd]->GetEdge()->GetOrg()->GetID());
    if(Dist==NULL || VBotInd<0 ||SewBuf==NULL)
    {
        delete MS; delete PL; delete[] Dist; delete[] SewBuf;
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Finding first bottom vertex or memory allocation.\n");
        return NULL;
    }
    MS  ->MarkVertexNeighbours(VBotInd, MS->NVertex, Dist);  // Distances o first bottom index
        
    int DisMin = MS->NVertex+2;
    int KStart = -1;
    for(int k=0; k<NVertexTop; k++)
    {
        int ind = MS->FindVertex(Ftop->GetEdge(k)->GetOrg()->GetID());
        if(ind<0 || Dist[ind]>=DisMin) continue;
        DisMin = Dist[ind];
        KStart = k;
    }

    for(int n=0; n<NVertexBase; n++) Fbot->GetEdge(n)->GetOrg()->SetPoint(PL->GetPoint((n+Imax0)%NVertexBase));  // Set bottom points
    delete PL;

    for(int k=0; k<NSew; k++)
    {
        SewBuf[2*k  ] = (k%2) ? MS->LastQuadEdgeID+k : Ftop->GetEdge((KStart-(1 +  k   /2)+NVertexTop)%NVertexTop)->GetID()/4;
        SewBuf[2*k+1] =                                Ftop->GetEdge((KStart+(1 + (k+1)/2)+NVertexTop)%NVertexTop)->GetID()/4;
    }
    for(int k=0; k<NSew; k++)
    {
        if(MS->AddEdgeSameFace(SewBuf[2*k  ], SewBuf[2*k+1])!=U_OK)
        {
            delete MS; delete[] Dist; delete[] SewBuf;
            CI.AddToLog("ERROR: GetTrangulatedCompletion(). Sewing step %d of %d. \n", k, NVertexTop/2);
            return NULL;
        }
    }
    delete[] SewBuf;

    int    NN     = 0;
    Fbot->GetNeigborVertexIDs(Dist, &NN);
    if(MS->InterpolateVertices(Dist, NN, true, 1, U_PENALTY_NO, 0.)!=U_OK)
    {
        delete MS; delete[] Dist;
        CI.AddToLog("ERROR: GetTrangulatedCompletion(). Interpolating interior.\n");
        return NULL;
    }
    delete[] Dist;
    return MS;
}

UManifold* GetStrip(UEdge* Estart, PMT_CUFACEP* TriArr, int NTri, int* VIDend)
{
    if(Estart==NULL || TriArr==NULL || NTri<=3)
    {
        CI.AddToLog("ERROR: GetStrip(). Invalid (NULL) argument(s). NTri = %d .\n", NTri);
        return NULL;
    }
    for(int n=0; n<NTri; n++)
    {
        if(TriArr[n]->IsTriangle()==true) continue;
        CI.AddToLog("ERROR: GetStrip(). Face  %d not triangular.\n", n);
        return NULL;
    }
    if(TriArr[0]->HasEdge(Estart, true, true)==false)
    {
        CI.AddToLog("ERROR: GetStrip(). Starting edge not adjacent to first triangle .\n");
        return NULL;
    }
    int MaxTriVID = MAX(TriArr[0]->GetEdge()->GetLPrev()->GetOrg()->GetID(), TriArr[0]->GetEdge()->GetOrg()->GetID());
        MaxTriVID = MAX(TriArr[0]->GetEdge()->GetLNext()->GetOrg()->GetID(), MaxTriVID);

    for(int n=1; n<NTri; n++)
    {
        MaxTriVID = MAX(TriArr[n]->GetEdge()->            GetOrg()->GetID(), MaxTriVID);
        MaxTriVID = MAX(TriArr[n]->GetEdge()->GetLNext()->GetOrg()->GetID(), MaxTriVID);
        MaxTriVID = MAX(TriArr[n]->GetEdge()->GetLPrev()->GetOrg()->GetID(), MaxTriVID);

        if(GetConnectingEdgeTri(TriArr[n-1], TriArr[n])) continue;
        CI.AddToLog("ERROR: GetStrip(). Triangle %d not adjacent to %d.\n", n, n-1);
        return NULL;
    }
    UManifold*   MS     = new UManifold();
    UVector3*    p      = new UVector3[NTri+2];
    UVertex**    vbound = new UVertex*[NTri+2];
    int*         newID  = new int[NTri+2];
    if(MS==NULL || MS->GetError()!=U_OK || p==NULL || vbound==NULL || newID==NULL)
    {
        delete[] newID; delete[] vbound; delete[] p; delete MS;
        CI.AddToLog("ERROR: GetStrip(). Creating output object  .\n");
        return NULL;
    }
    for(int n=0; n<NTri+2; n++) vbound[n] = NULL;

    const UVertex* Vold[3] = {TriArr[0]->GetEdge()->GetLPrev()->GetOrg(), TriArr[0]->GetEdge()->GetOrg(), TriArr[0]->GetEdge()->GetLNext()->GetOrg()};
    p[0] = *Vold[0];
    p[1] = *Vold[1];
    p[2] = *Vold[2];
    MS->AddTriangle(0, 1, 2, p);

    vbound[0]   = MS->vertices[0];  newID[0] = Vold[0]->GetID();
    vbound[1]   = MS->vertices[1];  newID[1] = Vold[1]->GetID();
    vbound[2]   = MS->vertices[2];  newID[2] = Vold[2]->GetID();
    int iold[3] = {0,1,2};
    for(int n=1; n<NTri; n++)
    {
        const UVertex* Vnew[3] = {TriArr[n]->GetEdge()->GetLPrev()->GetOrg(), TriArr[n]->GetEdge()->GetOrg(), TriArr[n]->GetEdge()->GetLNext()->GetOrg()};
        int            inew[3] = {-1,-1,-1};

        int knew  = -1;
             if(Vold[0]==Vnew[1]&&Vold[1]==Vnew[0]) {inew[0]=iold[1]; inew[1]=iold[0]; inew[2]=MS->NVertex; knew=2;}
        else if(Vold[0]==Vnew[2]&&Vold[1]==Vnew[1]) {inew[1]=iold[1]; inew[2]=iold[0]; inew[0]=MS->NVertex; knew=0;}
        else if(Vold[0]==Vnew[0]&&Vold[1]==Vnew[2]) {inew[2]=iold[1]; inew[0]=iold[0]; inew[1]=MS->NVertex; knew=1;}

        else if(Vold[1]==Vnew[1]&&Vold[2]==Vnew[0]) {inew[0]=iold[2]; inew[1]=iold[1]; inew[2]=MS->NVertex; knew=2;}
        else if(Vold[1]==Vnew[2]&&Vold[2]==Vnew[1]) {inew[1]=iold[2]; inew[2]=iold[1]; inew[0]=MS->NVertex; knew=0;}
        else if(Vold[1]==Vnew[0]&&Vold[2]==Vnew[2]) {inew[2]=iold[2]; inew[0]=iold[1]; inew[1]=MS->NVertex; knew=1;}

        else if(Vold[2]==Vnew[1]&&Vold[0]==Vnew[0]) {inew[0]=iold[0]; inew[1]=iold[2]; inew[2]=MS->NVertex; knew=2;}
        else if(Vold[2]==Vnew[2]&&Vold[0]==Vnew[1]) {inew[1]=iold[0]; inew[2]=iold[2]; inew[0]=MS->NVertex; knew=0;}
        else if(Vold[2]==Vnew[0]&&Vold[0]==Vnew[2]) {inew[2]=iold[0]; inew[0]=iold[2]; inew[1]=MS->NVertex; knew=1;}
        else
        {
            delete[] newID; delete[] vbound; delete[] p; delete MS;
            CI.AddToLog("ERROR: GetStrip(). Triangles not connected (n=%d) .\n", n);
            return NULL;
        }

        p[inew[knew]] = *Vnew[knew];
        MS->AddTriangle(inew[0], inew[1], inew[2], p);

        UVertex* vbef = MS->vertices[MS->FindVertex(inew[(knew+1)%3])]; // vertex before new one
        for(int nn=n+2; nn>=0; nn--)
        {
            vbound[nn] = vbound[nn-1];
            if(vbound[nn]!=vbef) continue;
            vbound[nn-1] = MS->vertices[MS->FindVertex(inew[knew])];
            break;
        }
        int newVID = Vnew[knew]->GetID();
        if(Estart->GetOrg() ==Vnew[knew]) newVID = MaxTriVID+1;
        if(Estart->GetDest()==Vnew[knew]) newVID = MaxTriVID+2;
        newID[inew[knew]] = newVID;

        Vold[0] = Vnew[0]; Vold[1] = Vnew[1]; Vold[2] = Vnew[2]; 
        iold[0] = inew[0]; iold[1] = inew[1]; iold[2] = inew[2];
    }
    delete[] p;

    UFace* FR = MS->AddNewFace(); // Big bounding face
    for(int n=0; n<NTri+2; n++)
    {
        int n1  = (n+1)%(NTri+2);
        int n2  = (n+2)%(NTri+2);
        int i01 = MS->FindQuadEdge(vbound[n ]->GetID(), vbound[n1]->GetID());
        int i12 = MS->FindQuadEdge(vbound[n1]->GetID(), vbound[n2]->GetID());

        UQuadEdge* QE01 = MS->qedges[i01];
        UQuadEdge* QE12 = MS->qedges[i12];
    
        QE01->GetEdgeSym()->SetONext(QE12->GetEdge()   );
        QE01->GetEdge()   ->SetRightFace (FR);
        QE12->GetEdgeRot()->SetONext(QE01->GetEdgeRot());
    }
    for(int n=0; n<NTri+2; n++) MS->vertices[n]->SetID(newID[n]);
    MS->UpdateLastIDs();

    MS->SortVertices();
    MS->SortFaces();
    MS->SortEdges();

    delete[] newID; delete[] vbound;
    if(VIDend) {VIDend[0] = MaxTriVID+1; VIDend[1] = MaxTriVID+2;}
    return MS;
}

UVector3* GetPointsFromContours(const UPointList** Cont, int NCont, int NPcontInter, int** NPoffset)
{
    if(Cont==NULL || Cont[0]==NULL || NPoffset==NULL)
    {
        CI.AddToLog("ERROR: GetPointsFromContours(). Invalid NULL argument(s).\n");
        return NULL;
    }
    *NPoffset = NULL;
    if(NCont<2 || (NPcontInter>0 && NPcontInter<4))
    {
        CI.AddToLog("ERROR: GetPointsFromContours(). Parameters out of range: NPcontInter=%d, NCont=%d . \n", NPcontInter, NCont);
        return NULL;
    }

    *NPoffset        = new int[NCont+1];
    double*   Offset = new double[NCont];
    if(Offset==NULL || *NPoffset==NULL)
    {
        delete[] Offset; delete[] *NPoffset; *NPoffset = NULL;
        CI.AddToLog("ERROR: GetPointsFromContours(). Memory allocation, NCont = %d. \n", NCont);
        return NULL;
    }
    UVector3 Normal;
    Cont[0]->FitPlane(&Normal);
    int  MainDir   = -1;
    if(fabs(Normal[0])>fabs(Normal[1])+fabs(Normal[2])) MainDir = 0; 
    if(fabs(Normal[1])>fabs(Normal[2])+fabs(Normal[0])) MainDir = 1;
    if(fabs(Normal[2])>fabs(Normal[0])+fabs(Normal[1])) MainDir = 2; 

    int   NP       = 0;
    int   NPmax    = 0;
    for(int ic=0; ic<NCont; ic++)
    {
        if(Cont[ic]==NULL || Cont[ic]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: GetPointsFromContours(). NULL or erroneous drawing ic = %d. \n", ic);
            delete[] Offset; delete[] *NPoffset; *NPoffset = NULL;
            return NULL;
        }
        int NPic  = Cont[ic]->GetNpoints();
        if(NPic<3)
        {
            CI.AddToLog("ERROR: GetPointsFromContours(). Invalid contour, Npoints[%d] = %d (<3). \n", ic, NPic);
            delete[] Offset; delete[] *NPoffset; *NPoffset = NULL;
            return NULL;
        }
        UVector3 NormCont;
        double   OffCont = 0.;
        Cont[ic]->FitPlane(&NormCont, &OffCont);

        if(fabs(Normal&NormCont) < 0.5)
        {
            CI.AddToLog("ERROR: GetPointsFromContours(). First direction is different or invalid for contour %d. \n", ic);
            delete[] Offset; delete[] *NPoffset; *NPoffset = NULL;
            return NULL;
        }
        Offset[ic]        = ((Normal&NormCont) <0) ? -OffCont: OffCont;
        NP               += (NPcontInter<=0 ? NPic : NPcontInter);
        NPmax             = MAX(NPmax, NPic);
    }
    bool      Fabs      = false;
    bool      HighFirst = false;
    int*      Icont     = GetOrderIndexArray(Offset, NCont, Fabs, HighFirst);
    UVector3* Pnts      = new UVector3[NP];
    UVector3* PntBuf    = NPcontInter<=0 ? new UVector3[NPmax] : new UVector3[NPcontInter];

    delete[] Offset; 
    if(Icont== NULL || Pnts==NULL || PntBuf==NULL)
    {
        delete[] Icont; delete[] Pnts; delete[] PntBuf;
        delete[] *NPoffset; *NPoffset = NULL;
        CI.AddToLog("ERROR: GetPointsFromContours(). Sorting contours. \n");
        return NULL;
    }

    UVector3* Pntsic = Pnts;
    (*NPoffset)[0]   = 0;
    for(int ic=0; ic<NCont;ic++)
    {
        int             NPic  = Cont[Icont[ic]]->GetNpoints();
        const UVector3* pic   = Cont[Icont[ic]]->GetPoints();
        bool            Oriic = Cont[Icont[ic]]->GetProjectedArea(MainDir)>0.;
        (*NPoffset)[ic+1]     = (*NPoffset)[ic] + (NPcontInter<=0 ? NPic : NPcontInter);
        if(NPcontInter<=0) 
        {
            if(Oriic) for(int n=0; n<NPic; n++) Pntsic[n] = pic[n       ];
            else      for(int n=0; n<NPic; n++) Pntsic[n] = pic[NPic-1-n];
        }
        else
        {
            UInterpolateCircle IC(pic, NPic, Oriic);
            for(int n=0; n<NPcontInter; n++) Pntsic[n] = IC.GetInterpolVector3(n/(double)NPcontInter);
        }
        UVector3* pnew  = Pntsic;
        int       NPI   = (NPcontInter<=0) ? NPic : NPcontInter;

        Pntsic         += NPI;
        if(ic==0) continue;

        int             NPold  = (NPcontInter<=0) ? Cont[Icont[ic-1]]->GetNpoints() : NPcontInter;
        const UVector3* pold   = pnew-NPold;

        int             Ishift = 0;
        double          MinDis = 0.;
        for(int n=0; n<NPI; n++) MinDis += (pold[int(0.5+n*(NPold-1.)/(NPI-1.))] - pnew[n]).GetNorm();

        for(int ish=1; ish<NPI; ish++)
        {
            double TesDis = 0.;
            for(int n=0; n<NPI; n++) TesDis  += (pold[int(0.5+n*(NPold-1.)/(NPI-1.))] - pnew[(n+ish)%NPI]).GetNorm();
            if(TesDis>=MinDis) continue;

            MinDis = TesDis;
            Ishift = ish;
        }
        if(Ishift>0)
        {
            for(int n=0; n<NPI; n++) PntBuf[n] = pnew[(n+Ishift)%NPI];
            for(int n=0; n<NPI; n++)  pnew [n] = PntBuf[n];
        }
    }
    delete[] Icont; delete[] PntBuf;
    return Pnts;
}

int* MergeIDs(const int* ID1, int NID1, const int* ID2, int NID2, int* NID12)
{
    if( (ID1==NULL && NID1!=0) || NID1<0) {CI.AddToLog("ERROR: MergeIDs(). Invalid param: NID1=%d.\n", NID1);                    return NULL;}
    if( (ID2==NULL && NID2!=0) || NID2<0) {CI.AddToLog("ERROR: MergeIDs(). Invalid param: NID2=%d.\n", NID2);                    return NULL;}
    if(ID1==NULL && ID2==NULL)            {CI.AddToLog("ERROR: MergeIDs(). Invalid NULL parameters.\n");                         return NULL;}
    if(NID12==NULL || NID1+NID2==0      ) {CI.AddToLog("ERROR: MergeIDs(). Invalid parameters: NID1=%d, NID2=%d.\n", NID1,NID2); return NULL;}

    *NID12    = 0;
    int* ID12 = new int[NID1+NID2];
    if(ID12==NULL) 
    {
        CI.AddToLog("ERROR: MergeIDs(). Memory allocation, NID1=%d, NID2=%d.\n", NID1,NID2);
        return NULL;
    }
    for(int k=0; k<NID1; k++) ID12[     k] = ID1[k];
    for(int k=0; k<NID2; k++) ID12[NID1+k] = ID2[k];
    
    SortArray(ID12, NID1+NID2, false, false);
    
    *NID12    = 1;
    int IDold = ID12[0] = ID1 ? ID1[0] : ID2[0];
    for(int k=1; k<NID1+NID2; k++)
    {
        if(ID12[k]==IDold) continue;
        ID12[*NID12] = ID12[k];
        IDold        = (*NID12)++;
    }
    return ID12;
}
