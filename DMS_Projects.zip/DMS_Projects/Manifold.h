#ifndef _MANIFOLD_INCLUDED
#define _MANIFOLD_INCLUDED


#include "VertEdgeFace.h"
#include "Surface.h"
#include "Matrix.h"
#include "LineSearch.h"

class UDrawing;

class UManifoldVertexIterator;
class UManifoldFaceIterator;
class UMatrixSparse;

enum TypePenalty
{
    U_PENALTY_NO,
    U_PENALTY_L1,
    U_PENALTY_L2,
    U_PENALTY_UNKNOWN
};

class DLL_IO UManifold
{
public:
    friend class UManifoldVertexIterator;
    friend class UManifoldFaceIterator;
    friend class UMarchingCubes;
    friend       PMT_UMANIFOLDP DLL_IO GetPyramid(int NVertexBase, const UVector3* BasePoints, int MaxHeight, int* FBasisID, bool FlatManifold);
    friend       PMT_UMANIFOLDP DLL_IO GetCylinder(int NVertexBase, const UVector3* BasePoints, const UVector3* TopPoints, int Height, int* FBasisID, int* FTopID);
    friend       PMT_UMANIFOLDP DLL_IO GetTrangulatedCompletion(UFace* FPolygon, int* FBasisID);
    friend       PMT_UMANIFOLDP DLL_IO GetFrustum(int NVertexBase, const UVector3* BasePoints, int NVertexTop, const UVector3* TopPoints, int Height, int* FBotID, int* FTopID);
    friend       PMT_UMANIFOLDP DLL_IO GetJunction(int NVertexBase, int Height, int NBridge, int NVertexTopLeft, int NVertexTopRight, int* FBotID, int* FTopLID, int* FTopRID);
    friend       PMT_UMANIFOLDP DLL_IO GetStrip(UEdge* Elast, PMT_CUFACEP*, int NTri, int* VIDend);
    enum LaplacianType
    {
        U_LAPLACIAN_UNIFORM,      // "Uniform" Laplacian, diagonal equals -1, neighbors equal 1/NN"
        U_LAPLACIAN_HARMONIC      // Apply cotan formula
    };

    UManifold();
    UManifold(const UManifold &m);
    UManifold(const USurface& S);
    UManifold(const UPointList* Cbot, const UPointList* Ctop, int NPcontInter, int NSublayer, int order, int AddCap);
    UManifold(const UPointList** Cont, int NCont, int NPcontInter, int NSublayer, int order, int AddCap, TypePenalty PT, double Lamda2, int**VertexBoundID=NULL);

    UManifold(const UField* F, int    Level, LevelType LevT);
    UManifold(const UField* F, double Level, LevelType LevT);

    virtual ~UManifold();
    UManifold& operator=(const UManifold &m);

    const UString&      GetProperties(UString Comment) const;
    ErrorType           GetError() const            {if(this) return error;   return U_ERROR;}
    int                 GetNVertex() const          {if(this) return NVertex; return -1;}
    int                 GetNFace() const            {if(this) return NFace;   return -1;}
    int                 GetNEdge() const            {if(this) return NQEdge;  return -1;}
    int                 GetEulerChar() const        {if(this) return NVertex+NFace-NQEdge; return -1;}
    UFace**             GetFaces() const            {if(this) return faces;   return NULL;}
    UVertex**           GetVertices() const         {if(this) return vertices;return NULL;}
    UQuadEdge**         GetQEdges() const           {if(this) return qedges;  return NULL;}
    int*                GetVertexIDs() const;

/* Geometry */
    UVector3            GetCenter() const;
    UVector3            GetCenter(const int* VertID, int NVert) const;
    double              GetTotalArea(void) const;
    ErrorType           ComputeMoments(double* First3, double* Second6, double* Third10) const;
    UEuler              GetXfm2Moments(bool ForceMinRot) const;
    UVector3            GetMomentDir(int dir) const;
    USurface*           GetSurface(const char* Name, bool SkipNonTri) const;
    UPointList*         GetPointList(void) const;
    UPointList*         GetVerticesAsPointList(const int* VertIDarray, int Npoint) const;
    UMatrix             GetCoordMatrix(void) const;
    ErrorType           SetCoordMatrix(const UMatrix& CoordMat);
    bool                IsTriangulation(void) const;
    ErrorType           CompleteTriangulationScratch();
    ErrorType           CompleteTriangulation(bool AddCenters);
    int*                GetNVertexCrossings(const USurface& S) const;
    double*             GetVertexProjections(const USurface& S, int** NCross=NULL) const;
    double*             GetVertexProjections(const UManifold& TSphere, const UManifold& M, const UManifold& MSphere, int** NCross=NULL) const;
    ErrorType           MorfVertices(const double* VertexFunc);
    USurface*           GetMorfedSurface(const double* VertexFunc) const;

/* Vertices */
    UVertex*            GetVertex(int VID);
    int                 GetVertexID(int Vindex) const;
    UVector3            GetVertexNormal(int Vindex) const;
    UVector3            GetVertexCurveVector(int Vindex) const;
    UVector3            GetPoint(int Vindex) const;
    UVector3            GetPointFromID(int ID) const;
    UVector3            GetPointShortestEdge(void) const;
    ErrorType           GetMinMaxBox(UVector3* Min, UVector3* Max) const;
    double              GetMinCoord(int dir) const;
    double              GetMaxCoord(int dir) const;
    int                 GetVertexIDExtremeCoord(int dir, bool Largest) const;
    int                 MarkVertexNeighbours(int Vindex, int MaxNeighDegree, int* Distances) const;
    int                 MarkVertexNeighbours(const int* VindicesForeground, int NForeground, int MaxNeighDegree, int* Distances) const;
    int*                GetVertexNeighbourIDs(int Vindex, int NNeighDegree, int* NNeigh) const;
    int*                GetNVertexNeigbours(int Vindex, int MaxOrder, int*** VertexIDs, int VerboseLevel=0) const;
    int*                GetNVertexNeigbours2(int Vindex, int MaxOrder, int*** VertexIDs) const;

    int                 GetTipVertexID(int dir, bool Largest, double TolAbs);
    int                 GetTipVertexID(int dirpri, int dirsec, bool Largest, bool Top, double TolAbs);
    int*                GetTipVertexIDset(int dir, bool Largest, double TolAbs, int* NID);

    int                 GetIndexClosestPoint(UVector3 C) const;
    int                 GetClosestDirVertexID(const int* VertID, int NVert, UVector3 Dir) const;    
    int                 GetClosestDirVertexID(double Level, int dircross, UVector3 Dir);
    int                 GetClosestDirVertexID(double Level, int dircross, int dir, bool NegDir);
    int*                GetClosestVertextIDs(const UPointList* PL) const;
    UVector3*           GetDensityPoints(int* Npoints) const;
    int*                GetIndexVertexCoordOrder(int coor, bool Fabs, bool HighFirst) const;

    double              GetPathLength(int VIDfrom, int VIDto, int** PathID, int* NVPath) const;

/* Faces */
    UFace*              GetFace(int FID);
    int                 GetTipFaceID(int dir, bool Largest, double TolAbs);
    int                 GetTipFaceID(int dirpri, int dirsec, bool Largest, bool Top, double TolAbs);
    UVector3            GetFaceCenterFromID(int FaceID) const;
    UVector3            GetFacesCenter(const int* FaceIndices, int NIndex) const;
    UVector3*           GetFaceNormals(void);
    int                 GetFaceIDExtremeCoord(int dir, bool Largest) const;
    int                 GetFaceIndexMaxNEdges();
    int                 GetFaceIDShortestEdge(const int* VIDset, int NVID) const;

/* Edges */
    UQuadEdge*          GetQuadEdge(int EID);
    int                 GetVertexIDShortestEdge(const int* VIDset, int NVID) const;
    int*                GetIndexEdgeCoordOrder(int coor, bool Fabs, bool HighFirst) const;
    int*                GetIndexEdgeMinAngle(bool HighFirst=false) const;
    int                 GetQEdgeIDShortestEdge(const int* VIDset, int NVID) const;
    double              GetLengthFromID(int QEID) const;
    ErrorType           SwapEdgeID(int QEID, bool MaximizeAngle);
    ErrorType           RemoveEdges(double LengthThreshold);

/* Transformations */
    ErrorType           Transform(UEuler eul);
    ErrorType           Transform(ULinTran Tra);
    ErrorType           TransformCenter(double Sx, double Sy, double Sz);
    ErrorType           RandomizeVertices(double StDev, int iseed=0);

    ErrorType           InterpolateVertices(const int* FFIDs, int NFF, bool IDsFixed, int order, TypePenalty PT, double Lamda2);
    ErrorType           InterpolateVertices(const int* VertexData, int Thresh, bool FixLower, int order);
    ErrorType           InterpolateVertices(const double* VertexData, double Thresh, bool FixLower, int order);
    ErrorType           InterpolateVertices(const char* VertexDirections, int order);
    ErrorType           ReconstructFromRandomSubset(int Depth, int seed, int order, TypePenalty PT, double Lamda2, UPointList** pPL=NULL, double** ARatio=NULL);

    ErrorType           ExpandSphere(UVector3 Axis);
    ErrorType           ExpandSphereAcos(int IDNPole, int IDSPole, double Lam=1.0);
    ErrorType           ProjectCircle(int ifaceIndex, int CenterVertexID, bool EqualizeBoundary, bool XfmSqrt, bool RepairFailures, bool Harmonic);
    int                 RepairProjectedTriangles(int ifaceIndex) const;
    int                 TestProjectedFaces(int ifaceIndex, int MaxNErrorLog) const;
    int*                GetReverselyProjectedFaceIndices(int ifaceIndex, int* NReversed) const;

    ErrorType           ProjectSphereInit(int dir, double Level, bool CenterDense, bool ApplySqrtXfm, bool RepairFailures, bool Harmonic, bool CompensateCoord);
    ErrorType           ProjectSphere(int dir);
    ErrorType           ProjectSphereExpand(int dir);
    ErrorType           ProjectSphereConformal(int FaceIDSouth, int VertexIDNorth, int IDxaxis, bool MinimizeMedianZ, double* MultPar=NULL, double* BestCost=NULL);
    ErrorType           SmoothSphereHarm(const UManifold* MSphere, int NSphereHarm, double TruncThresh, bool UseL1norm, double* ErrDist, double*ErrMax, double*ErrMed, double** CoefXYZ=NULL);
    ErrorType           RemoveFlatTriangles(double Eps = 1.e-10);

    double*             GetVertexStretchArray(const UManifold& M) const;
    double*             GetVertexThetaArray(void) const;
    double*             GetVertexFiArray(void) const;

    double*             GetVertexAngleDeficit(void) const;
    double*             GetVertexGaussCurvature(void) const;
    double*             GetVertexGaussCurvatureSQR(void) const;
    double*             GetVertexMeanCurvature(void) const;
    double*             GetVertexMeanCurvatureSQR(void) const;
    double*             GetVertexMinCurvature(void) const;
    double*             GetVertexMaxCurvature(void) const;
    double              GetMeanCurvature(void) const;
    double*             GetVertexVoronoiArea(void) const;

    ErrorType           MaximizeMinAngleSwapEdge(int MaxNSwaps, int MaxIDfixed, int iseed, int* NSwap=NULL);
    ErrorType           MaximizeVolumeSwapEdge(int MaxNSwaps, int MaxIDfixed, int iseed, int* NSwap=NULL);
    ErrorType           MinimizeCurvatureSwapEdge(bool GaussCurvature, bool MeanCurvature, int MaxIDfixed, int MaxNSwaps, int iseed, int* NSwap=NULL);
    ErrorType           MinimizeCurvature(bool GaussCurvature, bool MeanCurvature, int MaxIDfixed, double AreaPenalty, int Maxiter, bool SwapEdges);
    ErrorType           SmoothVertices(int NNeighDegree);
    ErrorType           SmoothVertices(double WeigNeig, int Ntimes);

/* Topology */
    int                 GetVertexNeighbors(int VertIndex, int** Neigh) const;
    UMatrixSparse       GetVertexNNeighborsMatrix(bool Invert) const;
    UMatrixSparse       GetMatrixSparseVertexConnectivity(void) const;
    UMatrixSparse       GetMatrixSparseVertexLaplacian(LaplacianType LT, bool GetDiag) const;
    ErrorType           WriteConnectivityText(UFileName F) const;

    int                 GetNComponents(void);
    UManifold**         GetComponents(int* NComp);
    ErrorType           SelectLargestComponent(int* NCompOld=NULL);
    int*                GetVertexComponentMembership(int *Ncomp);

    UManifold*          GetContourCut(const int* ContourID, int NPointsContour, UFace** LRFace, bool KeepOldPointsOnLargestComp);
    UManifold*          GetContourCut(const int* ContourID, int NPointsContour, double SplitFactor, UFace** LRFace, bool KeepOldPointsOnLargestComp);
    UManifold**         GetSplittedManifolds(const int* ContourID, int NPointsContour, UFace** LRFace, bool DupVertexIDs);
    ErrorType           Merge(const UManifold &M);
    ErrorType           MergeFaces(int FaceID, const UManifold &M, int FaceIDM);
    ErrorType           MergeEdgesSameFace(int QEdgeID1, int QEdgeID2);
    ErrorType           AddEdgeSameFace(int QEdgeID1, int QEdgeID2);

    ErrorType           GetLevelContours(const double* VertexData, double Level, LevelType LevTyp, int*** VertIDarray, int** NPointsContour, int* NContour);
    ErrorType           GetLevelContours(const int* VertexData, int Level, LevelType LevTyp, int*** VertIDarray, int** NPointsContour, int* NContour);
    UDrawing*           GetLevelContoursAsDrawing(const double* VertexData, double Level, LevelType LevTyp);
    ErrorType           GetCrossSection(UVector3 Dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour);
    ErrorType           GetCrossSection(int dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour);
    ErrorType           GetCrossSection(int dir, double Level, int*** VertIDarray, int** NPointsContour, int* NContour, double* CoMin, double* CoMax);
    UDrawing*           GetCrossSectionAsDrawing(int dir, double Level, int ICont=-1);
    UDrawing*           GetCrossSectionAsDrawing(UVector3 Dir, double Level, int ICont=-1);
    UDrawing*           GetCrossSectionAsFlatDrawing(int dir, double Level);
    UDrawing*           GetLargestCrossSectionAsDrawing(int dir, double Step);
    UDrawing*           GetDrawing(int* const* VertIDarray, const int* NPointsContour, int NContour, int ICont=-1) const;
    UDrawing*           GetDrawing(PMT_CUVERTEXP* Vert, int NVert) const;

    ErrorType           ForceSphericalTopology(int IfaceStart, int MaxNTheta, int MaxNFi, UEuler* XfmOpt, int* icontOpt);
    ErrorType           RemoveFirstHandle(int MaxOrder, int** HandleVertexIDs, int* NBound, int* NnewVertex);
    ErrorType           RemoveHandles(int MaxOrder, int** HandleInds, int* NHandleInds, UPointList** pDraw);
    ErrorType           RemoveOutliers(int MaxOrder, bool ConstThresh, double ThreshPar, int** NewVertexInds, int* NNewVInds, UPointList** pDraw);

/* Export */
    ErrorType           WriteVTK(UFileName FileName) const;
    ErrorType           WriteVTKVertexData(UFileName FileName, const double** Data, int NDataVec) const;
    ErrorType           WriteMatLab(UFileName FileName) const;
    ErrorType           WriteEvolver(UFileName FileName, int Nfixed=-1) const;

/* Filter distributions */
    double*             GetFaceMedian(const double* FaceData, const int* Skip) const;
    ErrorType           ComputeFaceMedian(double* FaceData, const int* Skip) const;
    ErrorType           RemoveFaceOutliers(double* FaceData, double MinFrac, double MaxFrac) const;

    double*             GetVertexMedian(const double* VertexData, const int* Skip) const;
    ErrorType           ComputeVertexMedian(double* VertexData, const int* Skip) const;
    ErrorType           RemoveVertexOutliers(double* VertexData, double MinFrac, double MaxFrac) const;
    double*             GetSmoothedVertexData(const double* VertDat, int NNeighDegree) const;
    double*             GetSmoothedVertexData(const double* VertDat, double WeigNeig, int Ntimes) const;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

    ErrorType           AddTriangle(int ip0, int ip1, int ip2, const UVector3* p=NULL);
    ErrorType           AddTriangle(UVertex* ver0, UVertex* ver1, UVertex* ver2, int nq10, int nq21, int nq02);

    UVertex*            AddNewVertex();
    UVertex*            AddNewVertex(UVector3 P);
    UFace*              AddNewFace();
    UQuadEdge*          AddNewQuadEdge();
    ErrorType           AddVertex(UVertex* V, int* ind0=NULL, int* ind1=NULL, int* ind2=NULL);
    ErrorType           AddFace  (UFace*   F, int* ind0=NULL, int* ind1=NULL, int* ind2=NULL);
    ErrorType           AddQuadEdge(UQuadEdge* QE);

private:
    static UString      Properties;
    ErrorType           error;
    ErrorType           ReAllocateMemory(void);

    int                 NVertex;
    int                 NVertexAlloc;
    int                 LastVertexID;
    UVertex**           vertices;

    int                 NFace;
    int                 NFaceAlloc;
    int                 LastFaceID;
    UFace**             faces;

    int                 NQEdge;
    int                 NQEdgeAlloc;
    int                 LastQuadEdgeID;
    UQuadEdge**         qedges;

    ErrorType           UpdateLastIDs(void);
    ErrorType           RenumberVerticesFacesEdges(void);
    ErrorType           SortVertices(void);
    ErrorType           SortFaces(void);
    ErrorType           SortEdges(void);
    bool                AreVerticesSorted(void) const;
    bool                AreFacesSorted(void) const;
    bool                AreEdgesSorted(void) const;
    ErrorType           RemoveQEdgeReferences(UQuadEdge* QE1, UQuadEdge* QE2=NULL, UQuadEdge* QE3=NULL);

    ErrorType           OptimizePointOnSphere(const UMatrixSparse* MS, int Ivert);
    ErrorType           SplitContour(int**  pArrayID, int* NPCont, int *NCont, int Istart, int NContAlloc) const;
    ErrorType           SkipShortCuts(int**  pArrayID, int* NPCont, int NCon) const;
    ErrorType           SkipEdgeShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const;
    ErrorType           SkipVertexShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const;
    ErrorType           SkipOneStepShortCuts(UEdge** EArray, int NEdgeIn, int* NEdgeOut) const;
    int                 GetNNeigbours(int VIndex, int* NeigIndArr) const;

    ErrorType           GetMinMaxVertexData(UFace* F, const double* VertData, double* MinDat, double* MaxDat) const;
    double              GetDataOrg(UEdge* E, const double* VertData) const;
    double              GetDataDest(UEdge* E, const double* VertData) const;
public:
    int                 FindFace(int ID) const;
    int                 FindVertex(int ID) const;
    int                 FindQuadEdge(int ID) const;
    int                 FindQuadEdge(int IDorg, int IDdest) const;
    int                 FindQuadEdge(UEdge* Edge) const;

    ErrorType           RemoveEdgeMergeFaces(int QEID);
    ErrorType           RemoveEdgeMergeVertices(int QEID);
    ErrorType           RemoveEdgeMergeFaces(UEdge* Edge);
    ErrorType           RemoveEdgeMergeVertices(UEdge* Edge);
};

class UFitMoeb : public Uminimize
{
public:
    UFitMoeb(const double* Xco, const double* Yco, int NP);
    ~UFitMoeb();
    ErrorType SetShift(double XX, double YY);
    double    ComputeCost(double *par, int iter, int *status)
    {
        return ComputeCost(par, iter, status, NULL, NULL);
    }
    double ComputeCost(double *par, int iter, int *status=NULL, double *grad=NULL, double *gauss=NULL);
private:
    const double*  X;
    const double*  Y;
    int            N;
    bool           FixShift;
    double         FixX;
    double         FixY;
};
class UMinimizeCurve : public ULineSearch
{
public:
    UMinimizeCurve(UVertex** vert, int Nvert, bool GCurve, bool MCurve, int MaxIDF, int MaxIDM, double Lam);
    ~UMinimizeCurve();

    double              ComputeCost(const double* Par=NULL) const;
    ErrorType           MinimizeCurvature(void);

private:
    double              Lamda;     // Area penalty
    bool                GaussCurve;
    bool                MeanCurve;
    int                 NVertex;
    int                 MaxIDfixed;
    int                 MaxIDmoved;
    UVertex**           vertices;
    double*             ParOld;

public:
    double*             GetGradient(const double* Par=NULL) const;
};


PMT_UVECTOR3P    DLL_IO GetPointsFromContours(const UPointList** Cont, int NCont, int NPcontInter, int** NPoffset);
PMT_UMANIFOLDP   DLL_IO GetJunction(int NVertexBase, int Height, int NBridge, int NVertexTopLeft, int NVertexTopRight, int* FBotID, int* FTopLID, int* FTopRID);
PMT_UMANIFOLDP   DLL_IO GetFrustum(int NVertexBase, const UVector3* BasePoints, int NVertexTop, const UVector3* TopPoints, int Height, int* FBotID, int* FTopID);
PMT_UMANIFOLDP   DLL_IO GetCylinder(int NVertexBase, const UVector3* BasePoints, const UVector3* TopPoints, int Height, int* FBotID, int* FTopID);
PMT_UMANIFOLDP   DLL_IO GetPyramid(int NVertexBase, const UVector3* BasePoints, int MaxHeight, int* FBasisID, bool FlatManifold);
PMT_UMANIFOLDP   DLL_IO GetTrangulatedCompletion(UFace* FPolygon, int* FBasisID);
PMT_UMANIFOLDP   DLL_IO GetStrip(UEdge* Estart, PMT_CUFACEP* TriArr, int NTri, int* VIDend);
UEuler           DLL_IO GetMomentMatch(const UManifold* M1, const UManifold* M2);
PMT_IP           DLL_IO MergeIDs(const int* ID1, int NID1, const int* ID2, int NID2, int* NID12);

#endif// _MANIFOLD_INCLUDED
