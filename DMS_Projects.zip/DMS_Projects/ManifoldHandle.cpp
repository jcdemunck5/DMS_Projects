/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for detecting "handles"  of a UManifold object.                    */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/* 
  Update history

  Who    When       What
  JdM    12-09-17   creation
 */


#include "ManifoldHandle.h"
#include "Manifold.h"
#include "Drawing.h"

#include <stack>

ErrorType DeleteBoundElem(BoundElem* BE)
{
    delete BE;
    return U_OK;
}

void UManifoldHandle::SetAllMembersDefault(void)
{
    error       = U_OK;
    TriList     = FaceType();
    Boundary    = BoundType();
}
void UManifoldHandle::DeleteAllMembers(ErrorType E)
{
    for(BoundType::iterator it=Boundary.begin(); it!=Boundary.end(); ++it) DeleteBoundElem(it->second);
    SetAllMembersDefault();
    error = E;
}
UManifoldHandle::UManifoldHandle(UFace* Fstart)
{
    SetAllMembersDefault();
    if(Fstart==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    TriList.insert(FaceType::value_type((const UFace*)Fstart, (const UFace*)NULL));

    UEdge*     E     = Fstart->GetEdge();
    UEdge*     EE[3] = {E->GetLPrev(), E            , E->GetLNext()};
    BoundElem* BE[3] = {new BoundElem, new BoundElem, new BoundElem};

    for(int k=0; k<3; k++)
    {
        BE[k]->Edge = EE[k];
        BE[k]->Next = BE[(k+1)%3];
        BE[k]->Prev = BE[(k+2)%3];
    }
    for(int k=0; k<3; k++) Boundary.insert(BoundType::value_type(EE[k], BE[k]));
}
UManifoldHandle::~UManifoldHandle()
{
    DeleteAllMembers(U_OK);
}
UEdge* UManifoldHandle::AddTriangle(UFace* Fold, UFace* Fnew, int** NonSepVertexID, int* Npoints)
{
    if(Fold==NULL || Fnew==NULL || Fold==Fnew) return NULL;
    if(NonSepVertexID==NULL || Npoints==NULL ) return NULL;

    *NonSepVertexID = NULL;
    *Npoints        = 0;

    FaceType::const_iterator TriOld = TriList.find(Fold);
    if(TriOld==TriList.end())
    {
        CI.AddToLog("ERROR: UManifoldHandle::AddTriangle(). Old triangle (ID=%d) not found. \n", Fold->GetID());
        return NULL;
    }

    UEdge* Eold = GetConnectingEdgeTri(Fold, Fnew);
    if(Eold==NULL)
    {
        CI.AddToLog("ERROR: UManifoldHandle::AddTriangle(). Triangles not connected  (ID=%d, ID=%d). \n", Fold->GetID(), Fnew->GetID());
        return NULL;
    }
    BoundType::const_iterator  BEPairOld = Boundary.find(Eold); // Edge in direction of existing boundary
    if(BEPairOld==Boundary.end())
    {
        CI.AddToLog("ERROR: UManifoldHandle::AddTriangle(). Old edge on triangle (ID=%d) not found. \n", Fold->GetID());
        return NULL;
    }

/*Update triangle map */
    TriList.insert(FaceType::value_type(Fnew, Fold));

    UEdge*    Eprev  = Eold->GetSym()->GetLNext(); // previous edge on new face, in direction of new face
    UEdge*    Enext  = Eold->GetSym()->GetLPrev(); // next     edge on new face, in direction of new face

    BoundType::const_iterator  BEPairEprev = Boundary.find(Eprev->GetSym()); // existing (?) edges, in direction of present boundary
    BoundType::const_iterator  BEPairEnext = Boundary.find(Enext->GetSym());
    if(BEPairEprev!=Boundary.end() && BEPairEnext!=Boundary.end())
    {
        if(BEPairOld->second->Prev==BEPairEprev->second && BEPairOld->second->Next==BEPairEnext->second) // Remove isolated triangle
        {
            ConnectPrevNext(BEPairEprev, BEPairEnext);
            DeleteBoundElem(BEPairOld  ->second); Boundary.erase(BEPairOld  ); 
            DeleteBoundElem(BEPairEprev->second); Boundary.erase(BEPairEprev); 
            DeleteBoundElem(BEPairEnext->second); Boundary.erase(BEPairEnext); 
            return NULL;
        }
    }

/* Glue triangle */
    BoundElem* BENewPrev = new BoundElem;
    BoundElem* BENewNext = new BoundElem;
    BENewPrev->Edge      = Eprev;
    BENewPrev->Prev      = BEPairOld->second->Prev;
    BENewPrev->Next      = BENewNext;
    BENewNext->Edge      = Enext;
    BENewNext->Prev      = BENewPrev;
    BENewNext->Next      = BEPairOld->second->Next;

    IterBoolType IBTprev = Boundary.insert(BoundType::value_type(Eprev, BENewPrev));
    IterBoolType IBTnext = Boundary.insert(BoundType::value_type(Enext, BENewNext));
    Boundary[BEPairOld->second->Prev->Edge]->Next = BENewPrev;
    Boundary[BEPairOld->second->Next->Edge]->Prev = BENewNext;
     
    DeleteBoundElem(BEPairOld->second); Boundary.erase(BEPairOld);      // remove gluing edge

    if(BEPairEprev==Boundary.end() && BEPairEnext==Boundary.end()) return false; // Both edges are new

    BoundType::const_iterator  BEPairEprevNew = IBTprev.first;
    BoundType::const_iterator  BEPairEnextNew = IBTnext.first;

    if(BEPairEprev!=Boundary.end())
    {
        bool CrackRem = (BEPairEprevNew->second->Prev==BEPairEprev->second); // Remove crack
        int  NStep    = GetNStep(BEPairEprev->second, BEPairEprevNew->second);
        if(NStep<0)
        {
            CI.AddToLog("ERROR: UManifoldHandle::AddTriangle(). Testing circuit prev. \n");
            return NULL;
        }
        if(NOT(CrackRem) && NStep==0) *NonSepVertexID = GetVertexCircuit(BEPairEprev->second, BEPairEprevNew->second, Npoints);

        if(NOT(CrackRem)) ConnectPrevNext(BEPairEprevNew, BEPairEprev);
        ConnectPrevNext(BEPairEprev, BEPairEprevNew);
        DeleteBoundElem(BEPairEprev   ->second); Boundary.erase(BEPairEprev   );  
        DeleteBoundElem(BEPairEprevNew->second); Boundary.erase(BEPairEprevNew);  

        if(NOT(CrackRem) && NStep==0) return Eprev; // Contours merged
    }

    if(BEPairEnext!=Boundary.end())
    {
        bool CrackRem = (BEPairEnextNew->second->Next==BEPairEnext->second); // Remove crack
        int  NStep    = GetNStep(BEPairEnext->second, BEPairEnextNew->second->Next);
        if(NStep<0)
        {
            CI.AddToLog("ERROR: UManifoldHandle::AddTriangle(). Testing circuit next. \n");
            return NULL;
        }
        if(NOT(CrackRem) && NStep==0) *NonSepVertexID = GetVertexCircuit(BEPairEnext->second, BEPairEnextNew->second->Next, Npoints);

        if(NOT(CrackRem)) ConnectPrevNext(BEPairEnext, BEPairEnextNew);
        ConnectPrevNext(BEPairEnextNew, BEPairEnext);
        DeleteBoundElem(BEPairEnextNew->second); Boundary.erase(BEPairEnextNew);  
        DeleteBoundElem(BEPairEnext   ->second); Boundary.erase(BEPairEnext   );  

        if(NOT(CrackRem) && NStep==0) return Enext; // Contours merged
    }
    return NULL;
}

PMT_CUVERTEXP* UManifoldHandle::GetVertexCircuit(UEdge* Elast, int* NVert)
{
    if(Elast==NULL || NVert==NULL)
    {
        CI.AddToLog("ERROR. UManifoldHandle::GetVertexCircuit(). Invalid NULL pointer argument(s). \n");
        return NULL;
    }
    *NVert = 0;

    const UVertex* Org = Elast->GetOrg();
    const UVertex* Des = Elast->GetDest();

    BoundType BoundCopy = Boundary;
    size_t MaxStep = BoundCopy.size();
    for(BoundType::iterator it=BoundCopy.begin(); it!=BoundCopy.end(); ++it)
    {
        if(it->second == NULL) continue;

        int   NStep         = 0;    
        bool  DetectOrig    = false;
        bool  DetectDest    = false;
        const BoundElem* BE = it->second;
        while(NOT(DetectOrig && DetectDest) && NStep<=MaxStep)
        {
            const UVertex* Otst = BE->Edge->GetOrg();
            const UVertex* Dtst = BE->Edge->GetDest();
            if(Otst==Org || Dtst==Org) DetectOrig = true;
            if(Otst==Des || Dtst==Des) DetectDest = true;

            NStep++;
            it->second = NULL;
            BE         = BE->Next;
        }
        if(DetectOrig && DetectDest)
        {
            PMT_CUVERTEXP* pVert = new PMT_CUVERTEXP[MaxStep];
            if(pVert)
            {
                pVert[0] = NULL;
                *NVert   = 0;
                for(BE = Boundary[BE->Edge]; BE->Edge->GetOrg()!=pVert[0]; BE=BE->Next) pVert[(*NVert)++] = BE->Edge->GetOrg();
                return pVert;
            }
            break;
        }
    }
    return NULL;
}
UDrawing* UManifoldHandle::GetCircuitsAsDrawing()
{
    UDrawing* Draw = new UDrawing();
    if(Draw==NULL || Draw->GetError()!=U_OK)
    {
        delete Draw;
        return NULL;
    }

    BoundType BoundCopy = Boundary;
    size_t MaxStep = BoundCopy.size();
    for(BoundType::iterator it=BoundCopy.begin(); it!=BoundCopy.end(); ++it)
    {
        if(it->second == NULL) continue;

        int   NStep          = 0;
        const BoundElem* BEs = it->second;
        const BoundElem* BE  = it->second;
        while(NStep<=MaxStep)
        {
            Draw->AddPoint(*BE->Edge->GetOrg(), NStep>0);
            NStep++;
            it->second = NULL;
            BE         = BE->Next;
            if(BE==BEs) break;
        }
        Draw->CloseLastSegment();
    }
    return Draw;
}
ErrorType UManifoldHandle::ComputeNonSeparatingContour(UEdge* Elast, int** VertexIS, int* NVert)
{
    if(Elast==NULL || VertexIS==NULL || NVert==NULL)
    {
        CI.AddToLog("ERROR. UManifoldHandle::ComputeNonSeparatingContour(). Invalid NULL pointer argument(s). \n");
        return U_ERROR;
    }
    *NVert              = 0;
    int          NTri   = 0;
    PMT_CUFACEP* Farray = GetTriCircuit(Elast, &NTri);
    if(Farray==NULL)
    {
        CI.AddToLog("ERROR. UManifoldHandle::ComputeNonSeparatingContour(). Getting triangle cicuit. \n");
        return U_ERROR;
    }
    int        VIDend[2] = {-1, -1};
    UManifold* Mstrip    = GetStrip(Elast, Farray, NTri, VIDend);
    delete[] Farray;
    if(Mstrip==NULL || Mstrip->GetError()!=U_OK)
    {
        delete Mstrip;
        CI.AddToLog("ERROR. UManifoldHandle::ComputeNonSeparatingContour(). Creating manifold strip from triangle cicuit. \n");
        return U_ERROR;
    }
    int    ID[4][2] = {{Elast->GetOrg()->GetID() , VIDend[0]}, {Elast->GetDest()->GetID(), VIDend[0]}, 
                       {Elast->GetOrg()->GetID() , VIDend[1]}, {Elast->GetDest()->GetID(), VIDend[1]}};
    double Dmin     = -1.;
    int    imin     = -1;
    for(int i=0; i<4; i++)
    {
        double Dtest  = Mstrip->GetPathLength(ID[i][0], ID[i][1], NULL, NULL); 
        if(Dtest<=0.)
        {
            delete Mstrip; delete[] Farray;
            CI.AddToLog("ERROR. UManifoldHandle::ComputeNonSeparatingContour(). Getting path length, combi = %d. \n", i);
            return U_ERROR;
        }
        if(NOT(imin<0 || Dtest<Dmin)) continue;
        Dmin = Dtest;
        imin = i;
    }

    Mstrip->GetPathLength(ID[imin][0], ID[imin][1], VertexIS, NVert);
    delete Mstrip;
    if(VertexIS==NULL || NVert<=0)
    {
        delete[] Farray; delete[] VertexIS;
        CI.AddToLog("ERROR. UManifoldHandle::ComputeNonSeparatingContour(). Getting full minimum path. \n");
        return U_ERROR;
    }

    int  kl = -1;
    int* P  = *VertexIS;
    for(int k=0;  k<(*NVert)/2; k++) {int dum = P[k]; P[k] = P[(*NVert)-1-k]; P[(*NVert)-1-k] = dum;}
    for(int k=(*NVert)-1; k>=0; k--)
    {
             if(P[k]==VIDend[0]) {P[k]=Elast->GetOrg() ->GetID(); kl =k;}
        else if(P[k]==VIDend[1]) {P[k]=Elast->GetDest()->GetID(); kl =k;}
    }
    if(P[0]==P[(*NVert)-1]) (*NVert)--;

    return U_OK;
}
PMT_CUFACEP* UManifoldHandle::GetTriCircuit(UEdge* Elast, int* Ntri)
{
    if(Elast==NULL || Ntri==NULL)
    {
        CI.AddToLog("ERROR. UManifoldHandle::GetTriCircuit(). Invalid NULL pointer argument(s). \n");
        return NULL;
    }
    UFace* FL = Elast->GetLeftFace();
    UFace* FR = Elast->GetRightFace();

    size_t Nmax = TriList.size();

    int          NL = 0;
    const UFace* F  = FL;
    for(; NL<Nmax && F; NL++)
    {
        FaceType::const_iterator TriIt = TriList.find(F);
        if(TriIt==TriList.end())
        {
            CI.AddToLog("ERROR: UManifoldHandle::GetTriCircuit(). Left triangle (ID=%d) not found. \n", F->GetID());
            return NULL;
        }
        F = TriIt->second;
    }
    std::stack<const UFace*> Rstack;

    int NR = 0;
    F      = FR;
    for(; NR<Nmax && F; NR++)
    {
        Rstack.push(F);
        FaceType::const_iterator TriIt = TriList.find(F);
        if(TriIt==TriList.end())
        {
            CI.AddToLog("ERROR: UManifoldHandle::GetTriCircuit(). Right triangle (ID=%d) not found. \n", F->GetID());
            return NULL;
        }
        F = TriIt->second;
    }
    PMT_CUFACEP* Farray   = new PMT_CUFACEP[NL+NR];
    if(Farray==NULL)
    {
        CI.AddToLog("ERROR: UManifoldHandle::GetTriCircuit(). Memory allocation, NL+NR = %d. \n", NL+NR);
        return NULL;
    }
    F = FL; 
    for(int n=0 ; n<NL   ; n++, F = TriList.find(F)->second) Farray[n] = F;
    for(int n=NL; n<NL+NR; n++, Rstack.pop()               ) Farray[n] = Rstack.top();

    int Lfirst = NL;
    for(int n=0 ; n<NL; n++)
    {
        if(Farray[n]->HasVertex(Elast->GetOrg()) || Farray[n]->HasVertex(Elast->GetDest())) continue;
        Lfirst = n;
        break;
    }
    int Rlast = NL;
    for(int n=NL+NR-1; n>=NL; n--)
    {
        if(Farray[n]->HasVertex(Elast->GetOrg()) || Farray[n]->HasVertex(Elast->GetDest())) continue;
        Rlast = n;
        break;
    }

    int L =-1;
    int R =-1;
    for(int nl=Lfirst; nl<NL && L<0; nl++)
    {
        for(int nr=Rlast; nr>=NL && R<0; nr--)
        {
            if(GetConnectingEdgeTri(Farray[nl], Farray[nr])==NULL) continue;
            L= nl; R = nr;
        }
    }

    *Ntri = NL+NR;
    if(L>=0 && R>=0) // Shortcut detected
    {
        int Nskip = R-L-1;
        for(int n=L+1; n<NL+NR-Nskip; n++) Farray[n] = Farray[n+Nskip];
        *Ntri -= Nskip;
    }
    return Farray;
}

ErrorType UManifoldHandle::ConnectPrevNext(const BoundType::const_iterator& BE1, const BoundType::const_iterator& BE2)
{
    if(BE1==Boundary.end() || BE2==Boundary.end())
    {
        CI.AddToLog("ERROR: UManifoldHandle::ConnectPrevNext(). E1 or E2 edge not found.\n");
        return U_ERROR;
    }
    BoundType::const_iterator Prev = Boundary.find(BE1->second->Prev->Edge);
    BoundType::const_iterator Next = Boundary.find(BE2->second->Next->Edge);
    if(Prev==Boundary.end() || Next==Boundary.end())
    {
        CI.AddToLog("ERROR: UManifoldHandle::ConnectPrevNext(). Previous or Next edge not found.\n");
        return U_ERROR;
    }
    Prev->second->Next = Next->second;
    Next->second->Prev = Prev->second;
    return U_OK;
}
int UManifoldHandle::GetNStep(const BoundElem* BE1, const BoundElem* BE2) const
{
    if(BE1==NULL || BE2==NULL) return -1;
    if(BE1==BE2)               return  0;

    size_t MaxStep = Boundary.size();
    int    NStep   = 1;
    
    const BoundElem* BE  = BE1->Next;
    while(NStep<=MaxStep)
    {
        if(BE==BE1) return 0;
        if(BE==BE2) return NStep;
        NStep++;
        BE = BE->Next;
    }
    return -1;
}

int* UManifoldHandle::GetVertexCircuit(const BoundElem* BE1, const BoundElem* BE2, int*Npoints) const
{
    if(BE1==NULL || BE2==NULL || Npoints==NULL) return NULL;
    
    int NP1 = 0; double L1 =0.; int* con1 = GetVertexCircuit(BE1, &NP1, &L1);
    int NP2 = 0; double L2 =0.; int* con2 = GetVertexCircuit(BE2, &NP2, &L2);

    if(L1<=0. || NP1==0 || con1==NULL) {delete[] con1; *Npoints= NP2; return con2;}
    if(L2<=0. || NP2==0 || con2==NULL) {delete[] con2; *Npoints= NP1; return con1;}

    if(L1<=L2) 
    {
        delete[] con2; 
        *Npoints= NP1; 
        return con1;
    }
    delete[] con1; 
    *Npoints= NP2;
    return con2;
}

int* UManifoldHandle::GetVertexCircuit(const BoundElem* BE, int*Npoints, double* Length) const
{
    if(BE==NULL || Npoints==NULL || Length==NULL) return NULL;
    *Npoints = 0;
    *Length  = 0.;

    size_t MaxStep = Boundary.size();
    int* Contour = new int[MaxStep];
    if(Contour==NULL) return NULL;

    Contour[0] = BE->Edge->GetOrg()->GetID();
    *Npoints   = 1;
    *Length   += BE->Edge->GetLength();
    const BoundElem* BEN  = BE->Next;
    while(*Npoints<=MaxStep)
    {
        if(*Npoints==MaxStep)
        {
            *Npoints = 0;
            *Length  = 0.;
            delete[] Contour; Contour=NULL;
            CI.AddToLog("ERROR: UManifoldHandle::GetVertexCircuit(). Contour not closed.\n");
            return NULL;
        }

        if(BEN==BE) break;
        Contour[(*Npoints)++] = BEN->Edge->GetOrg()->GetID();
        *Length              += BEN->Edge->GetLength();
        BEN                   = BEN->Next;
    }
    return Contour;
}