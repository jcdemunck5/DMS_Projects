#ifndef _MANIFOLDHANDLE_INCLUDED
#define _MANIFOLDHANDLE_INCLUDED

#include <map>
#include "BasicInclude.h"
#include "VertEdgeFace.h"


struct cmp_Face
{
    bool operator()(PMT_CUFACEP a, PMT_CUFACEP b) const { return a->GetID() < b->GetID(); }
}; 
struct cmp_Edge
{
    bool operator()(PMT_CUEDGEP a, PMT_CUEDGEP b) const { return a->GetID() < b->GetID(); }
}; 
struct BoundElem
{
    UEdge*             Edge;  // GetSym(), GetDest() are not const
    const BoundElem*   Prev;
    const BoundElem*   Next;
};
ErrorType DeleteBoundElem(BoundElem* BE);

typedef std::map<PMT_CUFACEP, PMT_CUFACEP, cmp_Face> FaceType;
typedef std::map<PMT_CUEDGEP, BoundElem* , cmp_Edge> BoundType;

typedef std::pair<BoundType::const_iterator, bool>   IterBoolType;

class UDrawing;
class DLL_IO UManifoldHandle
{
public:

    UManifoldHandle(UFace* Fstart);
    virtual ~UManifoldHandle();
    ErrorType           GetError() const            {if(this) return error;   return U_ERROR;}

    UEdge*              AddTriangle(UFace* Fold, UFace* Fnew, int** NonSepVertexID, int* Npoints);
    ErrorType           ComputeNonSeparatingContour(UEdge* Elast, int** VertexIS, int* Npoints);
    PMT_CUFACEP*        GetTriCircuit(UEdge* Elast, int* Ntri);
    PMT_CUVERTEXP*      GetVertexCircuit(UEdge* Elast, int* NVert);
    UDrawing*           GetCircuitsAsDrawing();

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;
    FaceType            TriList;
    BoundType           Boundary;

    ErrorType           ConnectPrevNext(const BoundType::const_iterator& BE1, const BoundType::const_iterator& BE2);
    int                 GetNStep(const BoundElem* BE1, const BoundElem* BE2) const;
    int*                GetVertexCircuit(const BoundElem* BE, int*Npoints, double* Length) const;
    int*                GetVertexCircuit(const BoundElem* BE1, const BoundElem* BE2, int*Npoints) const;
};

#endif// _MANIFOLDHANDLE_INCLUDED
