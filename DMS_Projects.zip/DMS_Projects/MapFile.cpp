/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for collecting general map data. These data can subsequently       */
/*     be exported to a file, which can be plotted with MATLAB.                  */
/*                                                                               */
/*     Note: all pointers are temporary pointers to data outside the UMapFile    */
/*           object.                                                             */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    20-10-00   creation 
  Jdm    24-10-00   Added more output
  Jdm    25-04-01   Added NORMALS = {}
  Jdm    22-03-02   Added new consrtuctor (from MapFile). Made all pointer non-constant.
                    allocate memory to contain a copy of data arrays and labels, etc.
  JdM    04-04-02   Add compatibility with multiple trials
  JdM    09-04-02   Add trial labels
  JdM    05-06-02   Add default constructor and operator=()
  JdM    11-06-02   Bug fixes in SetMapLabels() and SetTrialLabels() (setting pointers in array to NULL by default)
  JdM    26-07-02   Added GetMinMaxData()
  JdM    04-08-02   Bug fix: GetData(). Range test.
                    Add GetProperties()
  JdM    06-08-02   Unit and MapTitle: ignore spaces
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    30-11-04   Added RemoveChannelsOrigin()
  JdM    06-04-07   Added and used SetAllMembersDefault(), DeleteAllMembers().
                    Used UString for Properties, added nTrialAlloc data member
                    Added MergeTrials
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    13-04-07   Added new SetMapLabels() and SetTrialLabels()
  JdM    21-11-07   WriteFile(). Test NULL pointers of trial data
 JdM/SG  22-01-08   Added RemoveTrial() and GetChannelView().
 JdM/SG  24-01-08   Bug fix. RemoveTrial(). Setting last pointer to NULL
  JdM    09-05-08   Made TrialLabels and MapLabels UString pointers
                    Added PrependTrialLabels()
  JdM    15-08-08   Added new UField** constructor
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    03-09-08   Bug Fix: UField** constructor, testing argument.
  JdM    26-02-09   Bug Fix: UField** constructor, testing argument: veclen must be 1 (not 2)
TW/JdM   16-06-10   Minor edits for Qt3 and g++ compatibility
*/

/*  To be done:

// Date: 23-10-2000

NTRIAL = 2         // Default: 1
UNIT = fT/sqrt(Hz) // Ascii string
SCALE = UNIPOLAR   // UNIPOLAR/BIPOLAR


FIDUCIALS = {
(    5.917,    1.281,    13.82), NAS 
(    5.431,    3.889,    13.58), PAL 
(    4.658,    7.231,     12.1), PAR 
(    2.384,    8.979,    10.91), INI 
(    2.384,    8.979,    10.91), VER
}


 */

#include <string.h>
#include <math.h>

#include "MapFile.h"
#include "Grid.h"
#include "AnalyzeLineExt.h"
#include "Field.h"

/* Inititalize static const parameters. */
UString UMapFile::Properties  = UString();

void UMapFile::SetAllMembersDefault(void)
{
    error       = U_OK;
    Grid        = NULL;      
    MapLabels   = NULL; 
    TrialLabels = NULL;
    Data        = NULL;
    nMaps       = 0; 
    nTrial      = 0;
    nTrialAlloc = 0;
    ChanFast    = false;                 
    MapTitle    = UString("No Map Title");
    Properties  = UString();
    memset(Unit,     0, MAXUNITSTRING);
}
void UMapFile::DeleteAllMembers(ErrorType E)
{
    delete   Grid;      
    delete[] MapLabels;
    delete[] TrialLabels;
    if(Data)
        for(int it=0; it<nTrialAlloc; it++) delete[] Data[it];
    delete[] Data;      

    SetAllMembersDefault();
    error = E;
}

UMapFile::UMapFile()
{
    SetAllMembersDefault();
}
UMapFile::UMapFile(const UMapFile& m)
{
    SetAllMembersDefault();
    *this = m;
}

UMapFile::UMapFile(const char* FileName)
{
    SetAllMembersDefault();

    if(DoesFileExist(FileName)==false)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Files does not exist: %s .",FileName);
        DeleteAllMembers(U_ERROR);
        return;
    }

    char line[200];
    FILE* fp = fopen(FileName,"rb");

    fread(line,1,sizeof(line),fp);
    rewind(fp);
    if(strncmp(line,"MAPFILE",sizeof("MAPFILE")-1))
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). File %s is not a Map file. First characters: %8s\n", FileName, line);
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }

    bool MapLabInFile  = false;
    bool TriLabInFile  = false;
    bool GridInFile    = false;
    bool NormalsInFile = false;
    int Nchan          = -1;
    nMaps              = -1;     
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
        if(AA.IsComment()==true) continue;
        if(AA.IsEmptyLine()==true) continue;
        
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsIdentifierIs("UNIT"))
        {
            const char* Text =  AA.GetPointer();
            for(unsigned int k=0; k<sizeof(Unit)-1; k++)
            {
                if(k>=strlen(Text) || Text[k]=='\n') break;
                Unit[k] = Text[k];
            }
        }
        if(AA.IsIdentifierIs("MAPTITLE"))
        {
            MapTitle = UString(AA.GetPointer());
            MapTitle = MapTitle.GetFirstLine();
        }
        if(AA.IsIdentifierIs("NTRIAL")) 
        {
            nTrial = AA.GetNextInt(-1);
            if(nTrial<=0)
            {
                CI.AddToLog("ERROR: UMapFile::UMapFile(). Number of trials out of range: nTrial = %d\n",nTrial);
                fclose(fp);
                DeleteAllMembers(U_ERROR);
                return;
            }
        }
        if(AA.IsStartList("GRID")==true)        GridInFile    = true;
        if(AA.IsStartList("NORMALS")==true)     NormalsInFile = true;
        if(AA.IsStartList("MAPLABELS")==true)   MapLabInFile  = true;
        if(AA.IsStartList("TRIALLABELS")==true) TriLabInFile  = true;
        if(AA.IsIdentifierIs("NCHANNEL")==true) Nchan = AA.GetNextInt(-1);
        if(AA.IsIdentifierIs("NMAP")==true)     nMaps = AA.GetNextInt(-1);
        if(AA.IsIdentifierIs("DATATYPE")==true)     
        {
            if(strcmp(AA.GetNextString(10,line), "DOUBLE"))
            {
                CI.AddToLog("ERROR: UMapFile::UMapFile(). Data type should be double, not %s  .\n",line);
                fclose(fp);
                DeleteAllMembers(U_ERROR);
                return;
            }
            continue;
        }
    }
    if(Nchan<=0 || nMaps<=0)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Number of channels/ number of maps out of range or not in file. Nchan=%d nMaps=%d .\n",Nchan,nMaps);
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(GridInFile==false)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Sensor grid is not in file. \n");
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }

    rewind(fp);
    Grid = new UGrid(Nchan);
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Creating Grid .\n");
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(MapLabInFile==true)
    {
        MapLabels = new UString[nMaps];
        if(MapLabels==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). creating map labels.\n");
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    if(TriLabInFile==true)
    {
        nTrialAlloc = nTrial;
        TrialLabels = new UString[nTrial];
        if(TrialLabels==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). creating trial labels.\n");
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }

/* Read the sensor information of map file.*/
    while(GetLine(line, sizeof(line), fp)!=NULL)
    {
        UAnalyzeLineExt AA(line);
    
        if(line[0]==12)
        {
            GetLine(line, sizeof(line), fp);
            if(line[0]==12) break;
        }
        if(AA.IsStartList("GRID")==true)
        {
            int is =0;
            while(1)
            {
            {
                GetLine(line, sizeof(line), fp);
                UAnalyzeLineExt AA(line);
                if(AA.IsComment()==true) continue;
                if(AA.IsEmptyLine()==true) continue;
                if(AA.IsEndList())
                {
                    if(is!=Nchan)
                    {
                        CI.AddToLog("ERROR: UMapFile::UMapFile(). Reading all sensor positions (is=%d).\n",is);
                        fclose(fp);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                    break;
                }
                UVector3 x = AA.GetNextVector3();
                Grid->SetPosition(x, is);
                if(NormalsInFile==true)  Grid->SetSensorType(USensor::U_SEN_VECTOR, is);
                else                     Grid->SetSensorType(USensor::U_SEN_POINT , is);
                char Item[20] = "";
                strncpy(Item, AA.GetNextString(sizeof(Item), Item), sizeof(Item)-1);
                Grid->SetName(Item, is);
                is++;
            }
            }
        }
        if(AA.IsStartList("NORMALS")==true)
        {
            int is =0;
            while(1)
            {
            {
                GetLine(line, sizeof(line), fp);
                UAnalyzeLineExt AA(line);
                if(AA.IsComment()==true) continue;
                if(AA.IsEmptyLine()==true) continue;
                if(AA.IsEndList())
                {
                    if(is!=Nchan)
                    {
                        CI.AddToLog("ERROR: UMapFile::UMapFile(). Reading all sensor orientations (is=%d).\n",is);
                        fclose(fp);
                        DeleteAllMembers(U_ERROR);
                        return;
                    }
                    break;
                }
                UVector3 x = AA.GetNextVector3();
                Grid->SetOrientation(x, is);
                is++;
            }
            }
        }
        if(AA.IsStartList("MAPLABELS")==true)
        {
            for(int k=0; k<nMaps; k++)
            {
                GetLine(line, sizeof(line), fp);
                MapLabels[k] = UString(line);
                MapLabels[k] = MapLabels[k].GetFirstLine();
            }
        }
        if(AA.IsStartList("TRIALLABELS")==true)
        {
            for(int k=0; k<nTrial; k++)
            {
                GetLine(line, sizeof(line), fp);
                TrialLabels[k] = UString(line);
                TrialLabels[k] = TrialLabels[k].GetFirstLine();
            }
        }
    }
    if(Grid->TriangulateGrid()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Triangulating grid.\n");
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }

/* Allocate memory for the data*/
    int Ndata = Grid->GetNpoints()*nMaps;

    Data = new double*[nTrial];
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating data for the maps Ndata = %d, nTrial = %d . \n",Ndata,nTrial);
        fclose(fp);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int it = 0; it<nTrial; it++) Data[it] = NULL;
    for(int it = 0; it<nTrial; it++)
    {
        Data[it] = new double[Ndata];
        if(Data[it]==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating data for the maps, trial = %d Ndata = %d, nTrial = %d . \n",it,Ndata,nTrial);
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }

/* read the data*/
    rewind(fp);
    char cp1 = getc(fp);
    char cp2 = getc(fp);
    while(cp1!=12 || cp2!=12)
    {
        cp1 = cp2;
        cp2 = getc(fp);
        if(cp2==EOF)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Unexpected end of file in map-file : %s\n",FileName);
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    for(int it=0; it<nTrial; it++)
        fread(Data[it], sizeof(double), Ndata, fp);
    fclose(fp);
    error = U_OK;
}

UMapFile::UMapFile(const UGrid* Grd, const UField* const* FArr, const char* UnitHor, const char* UnitVer, const char* Title)
{
    SetAllMembersDefault();

    if(Grd==NULL || Grd->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Invalid NULL UGrd argument or invalid UGrd. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    Grid = new UGrid(*Grd);
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Copying grid. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Title) MapTitle = UString(Title);

    if(FArr==NULL || FArr[0]==NULL || FArr[0]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Invalid NULL UField* array, or first UField invalid. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(FArr[0]->Getndim()!=2 || FArr[0]->GetVeclen()!=1 || FArr[0]->GetDType()!=UField::U_DOUBLE)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). First UField elem. of wrong type (%s).\n", (const char*)FArr[0]->GetProperties(""));
        DeleteAllMembers(U_ERROR);
        return;
    }

    int Nkan = Grd->GetNpoints();
    for(int i=0; i<Nkan; i++)
    {
        if(FArr[i]==NULL || FArr[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Erroneously NULL argument (UField -object %d). \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
        if(FArr[i]->Getndim()!=2 || FArr[i]->GetVeclen()!=1 || FArr[i]->GetDType()!=UField::U_DOUBLE)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). FArr[i] of wrong type (%s).\n", (const char*)FArr[1]->GetProperties(""));
            DeleteAllMembers(U_ERROR);
            return;
        }        
        if(FArr[i]->IsGeometryCompatible(FArr[0])==false)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Geometry of element %d not compatible with first one. \n", i);
            DeleteAllMembers(U_ERROR);
            return;
        }
    }
    nMaps      = FArr[0]->GetDimensions(1); 
    nTrial     = FArr[0]->GetDimensions(0);    

/* Set Map Labels */
    MapLabels = new UString[nMaps];
    if(MapLabels==NULL)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating pointers, nMaps = %d. \n",nMaps);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int k=0; k<nMaps; k++)
    {
        double    Y   = FArr[0]->GetPoint(0,k).Gety();
        MapLabels[k] = UString(Y, "%6.2f ") + UString(UnitVer);
    }

/* Set Trial Labels */
    TrialLabels = new UString[nTrial];
    Data        = new double*[nTrial]; 
    if(TrialLabels==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating pointers, nTrial = %d. \n",nTrial);
        DeleteAllMembers(U_ERROR);
        return;
    }
    nTrialAlloc = nTrial;

/* Set Trial Data */
    for(int it=0; it<nTrial; it++)  Data[it] = NULL;
    for(int it=0; it<nTrial; it++)
    {        
        Data[it] = new double[Nkan*nMaps];
        if(Data[it]==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating pointers, nTrial = %d. \n",nTrial);
            DeleteAllMembers(U_ERROR);
            return;
        }
        for(int i=0; i<Nkan; i++)
            for(int k=0; k<nMaps; k++)
                Data[it][i*nMaps+k]  = FArr[i]->GetDdata()[k*nTrial+it];

        double    X     = FArr[0]->GetPoint(it,0).Getx()-FArr[0]->GetPoint(0,0).Getx();
        TrialLabels[it] = UString(X, "%6.2f ") + UString(UnitHor);
    }
}

UMapFile::UMapFile(const UGrid* Grd, int nMap, int NTrial, const char* Title)
{
    SetAllMembersDefault();

    if(Grd)
    {
        Grid = new UGrid(*Grd);
        if(Grid==NULL || Grid->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Copying grid. \n");
            DeleteAllMembers(U_ERROR);
            return;
        }
    }    
    if(Title) MapTitle = UString(Title);
    if(nMap>0)
    {
        MapLabels = new UString[nMap];
        if(MapLabels==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating pointers, nMaps = %d. \n",nMaps);
            DeleteAllMembers(U_ERROR);
            return;
        }
        nMaps = nMap;
    }
    if(NTrial>0)
    {
        TrialLabels = new UString[NTrial];
        Data        = new double*[NTrial]; 
        if(TrialLabels==NULL || Data==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile(). Allocating pointers, NTrial = %d. \n",NTrial);
            DeleteAllMembers(U_ERROR);
            return;
        }
        nTrialAlloc = NTrial;
        nTrial      = NTrial;
        for(int it=0; it<nTrial; it++)  Data[it] = NULL;
    }
}

UMapFile::UMapFile(const UGrid* Grd, int nMap, const char* Title)
{
    SetAllMembersDefault();

    *this = UMapFile(Grd, nMap, 1, Title);
}

UMapFile::~UMapFile()
{
    DeleteAllMembers(U_OK);
}

UMapFile& UMapFile::operator=(const UMapFile& m)
{
    if(this==NULL)
    {
        static UMapFile M; M.error = U_ERROR;
        return M;
    }
    if(&m==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&m) return *this;

    DeleteAllMembers(U_OK);
    if(m.Grid)
    {
        Grid = new UGrid(*m.Grid);
        if(Grid==NULL || Grid->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile::operator=(). Copying UGrid(). \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }

    nMaps = m.nMaps;
    if(m.MapLabels && m.nMaps>0)
    {
        if(SetMapLabels(m.MapLabels)!=U_OK)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile::operator=(). Copying MapLabels(). \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
        
    nTrial = m.nTrial;
    if(m.TrialLabels && m.nTrial>0)
    {
        if(SetTrialLabels(m.TrialLabels)!=U_OK)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile::operator=(). Copying TrialLabels. \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }

    ChanFast = m.ChanFast;                 

    if(m.Data && m.Grid)
    {
        Data   = new double*[nTrial];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::UMapFile::operator=(). Allocating memory for data pointers. \n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }

        for(int it=0; it<m.nTrial; it++) Data[it] = NULL;
        for(int it=0; it<m.nTrial; it++)
        {
            if(SetData(m.Data[it], it, m.ChanFast)!=U_OK)
            {
                CI.AddToLog("ERROR: UMapFile::UMapFile::operator=(). Copying data of trial %d. \n", it);
                DeleteAllMembers(U_ERROR);
                return *this;
            }
        }
    }
    nTrialAlloc = nTrial;
    MapTitle    = m.MapTitle;

    memcpy(Unit, m.Unit, MAXUNITSTRING);
    return *this;
}

ErrorType UMapFile::RemoveChannelsOrigin(void)
{
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::RemoveChannelsOrigin(). Grid not (properly) set. \n");
        return U_ERROR;
    }
    if(this==NULL || error!=U_OK || Data==NULL || ChanFast==true || nMaps==0)
    {
        CI.AddToLog("ERROR: UMapFile::RemoveChannelsOrigin(). Data not (properly) set. \n");
        return U_ERROR;
    }
    int Nrem = 0;
    for(int i=0; i<Grid->GetNpoints(); i++)
        if(Grid->GetPosition(i) == UVector3()) Nrem++;
    
    if(Nrem<=0) return U_OK;

    int* Irem = new int[Nrem];
    if(Irem==NULL)
    {
        CI.AddToLog("ERROR: UMapFile::RemoveChannelsOrigin(). Memory allocation. \n");
        return U_ERROR;
    }

    int NoldChan = Grid->GetNpoints();
    for(int i=0, n=0; i<NoldChan; i++)
    {
        if(Grid->GetPosition(i-n) == UVector3()) 
        {
            Grid->RemoveSensor(i-n);
            Irem[n++] = i;
        }
    }

    for(int k=0; k<nTrial; k++)
    {
        for(int i=0, n=0; i<NoldChan; i++) // Skip all data channel corresponding to Irem[]
        {
            if(i==Irem[n]) 
            {
                n++;
                continue;
            }
            memcpy(Data[k]+(i-n)*nMaps, Data[k]+i*nMaps, sizeof(double)*nMaps);
        }
                
        double* DatNew = new double[(NoldChan-Nrem)*nMaps];
        if(DatNew==NULL)
        {
            CI.AddToLog("WARNING: UMapFile::RemoveChannelsOrigin(). Memory allocation. \n");
            continue;
        }
        memcpy(DatNew, Data[k], sizeof(double)*(NoldChan-Nrem)*nMaps);

        delete[] Data[k];
        Data[k] = DatNew;
    }
    delete[] Irem;
    return U_OK;
}


ErrorType UMapFile::GetMinMaxData(double* Dmin, double* Dmax, int itrial) const
{
    if(Dmin==NULL && Dmax==NULL) return U_OK;

    if(Data==NULL)
    {
        CI.AddToLog("UMapFile::GetMinMaxData(). Data==NULL  .\n");
        return U_ERROR;
    }
    if(itrial>=nTrial)
    {
        CI.AddToLog("UMapFile::GetMinMaxData(). Trial number out of range. itrial = %d .\n", itrial);
        return U_ERROR;
    }

    int trmin = itrial;
    int trmax = itrial;
    if(itrial<0)
    {
        trmin = 0;
        trmax = nTrial-1;
    }
    if(Data[trmin]==NULL)
    {
        CI.AddToLog("UMapFile::GetMinMaxData(). Data[%d]==NULL  .\n",trmin);
        return U_ERROR;
    }
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("UMapFile::GetMinMaxData(). Invalid Grid.\n");
        return U_ERROR;
    }

    int Ndata  = nMaps*(Grid->GetNpoints());    
    double Zmi = Data[trmin][0];
    double Zma = Data[trmin][0];

    for(int it=trmin; it<=trmax; it++)
    {
        if(Data[it]==NULL)
        {
            CI.AddToLog("UMapFile::GetMinMaxData(). Data[%d]==NULL  .\n",it);
            return U_ERROR;
        }
        for(int k=0; k<Ndata; k++)
        {
            double Dat = Data[it][k];
            if(Zmi>Dat) Zmi = Dat;
            if(Zma<Dat) Zma = Dat;
        }
    }
    if(Dmin) *Dmin = Zmi;
    if(Dmax) *Dmax = Zma;
    return U_OK;
}

const double* UMapFile::GetData(void) const 
{
    return GetData(0);
}

const double* UMapFile::GetData(int itrial) const 
{
    if(itrial<0 || itrial>=nTrial)
    {
        CI.AddToLog("ERROR: UMapFile::GetData(). Argument out of range. itrial = %d .\n", itrial);
        return NULL;
    }
    if(Data) return Data[itrial];
    return NULL;
}


ErrorType UMapFile::SetData(const double *Dat, bool CHANFAST)
{
    return SetData(Dat, 0, CHANFAST);
}

ErrorType  UMapFile::SetData(const double *Dat, int itrial, bool CHANFAST)
{
    if(CHANFAST!=false)
    {
        CI.AddToLog("ERROR: UMapFile::SetData(). Fast channel index not yet supported. \n");
        return U_ERROR;
    }
    if(itrial<0 || itrial>=nTrial)
    {
        CI.AddToLog("ERROR: UMapFile::SetData(). Trial out of range. itrial=%d, nTrial=%d  . \n",itrial, nTrial);
        return U_ERROR;
    }
    if(Dat)
    {
        if(Grid==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::SetData(). Grid not (properly) set). \n");
            return U_ERROR;
        }

        int Ndata    = nMaps*(Grid->GetNpoints());
        delete[]       Data[itrial];
        Data[itrial] = new double[Ndata];
        if(Data[itrial]==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::SetData(). Memory allocation. Ndata=%d .\n",Ndata);
            return U_ERROR;
        }
        for(int ij=0; ij<Ndata; ij++) Data[itrial][ij] = Dat[ij];
    }
    else
    {
        delete[] Data[itrial];
        Data[itrial] = NULL;
    }
    ChanFast = CHANFAST;
    return U_OK;
}

ErrorType UMapFile::SetMapLabels(const UString* Labels)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;
    if(Labels==NULL || nMaps<=0   ) return U_ERROR;

    if(MapLabels==NULL) MapLabels = new UString[nMaps];
    if(MapLabels==NULL) return U_ERROR;

    for(int k=0; k<nMaps; k++)
        MapLabels[k]  = Labels[k].GetFirstLine();

    return U_OK;
}
ErrorType UMapFile::SetMapLabels(const char* const* Labels)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;
    if(Labels==NULL || nMaps<=0   ) return U_ERROR;

    if(MapLabels==NULL) MapLabels = new UString[nMaps];
    if(MapLabels==NULL) return U_ERROR;

    for(int k=0; k<nMaps; k++)
        MapLabels[k]  = UString(Labels[k]);

    return U_OK;
}

ErrorType UMapFile::PrependTrialLabels(UString Text)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;
    
    if(nTrialAlloc<nTrial) 
    {
        if(Data)
        {
            CI.AddToLog("ERROR: UMapFile::PrependTrialLabels(). Invalid nTrialAlloc = %d (nTrial=%d). \n", nTrialAlloc, nTrial);
            return U_ERROR;
        }
        nTrialAlloc=nTrial;
    }
    if(TrialLabels==NULL)  TrialLabels = new UString[nTrialAlloc];
    if(TrialLabels==NULL)  return U_ERROR;

    for(int k=0; k<nTrial; k++)
    {
        UString       S = Text + TrialLabels[k];
        TrialLabels[k]  = S.GetFirstLine();
    }
    return U_OK;
}

ErrorType UMapFile::SetTrialLabels(const UString* Labels)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;
    if(Labels==NULL || nTrial<=0  ) return U_ERROR;

    if(nTrialAlloc<nTrial) 
    {
        if(Data)
        {
            CI.AddToLog("ERROR: UMapFile::SetTrialLabels(). Invalid nTrialAlloc = %d (nTrial=%d). \n", nTrialAlloc, nTrial);
            return U_ERROR;
        }
        nTrialAlloc=nTrial;
    }
    if(TrialLabels==NULL)  TrialLabels = new UString[nTrialAlloc];
    if(TrialLabels==NULL)  return U_ERROR;
    
    for(int k=0; k<nTrial; k++)
        TrialLabels[k]  = Labels[k].GetFirstLine();

    return U_OK;
}
ErrorType UMapFile::SetTrialLabels(const char* const* Labels)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;
    if(Labels==NULL || nTrial<=0  ) return U_ERROR;

    if(nTrialAlloc<nTrial) 
    {
        if(Data)
        {
            CI.AddToLog("ERROR: UMapFile::SetTrialLabels(). Invalid nTrialAlloc = %d (nTrial=%d). \n", nTrialAlloc, nTrial);
            return U_ERROR;
        }
        nTrialAlloc=nTrial;
    }
    if(TrialLabels==NULL)  TrialLabels = new UString[nTrialAlloc];
    if(TrialLabels==NULL)  return U_ERROR;
    
    for(int k=0; k<nTrial; k++)
        TrialLabels[k]  = UString(Labels[k]);

    return U_OK;
}

ErrorType UMapFile::WriteFile(const char* FileName, const char* Unt) const
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::WriteFile(). Grid not properly set.\n");
        return U_ERROR;
    }
    if(nMaps<=0)
    {
        CI.AddToLog("ERROR: UMapFile::WriteFile(). Illegal number of maps (=%d).\n",nMaps);
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMapFile::WriteFile(). Data Array not set.\n");
        return U_ERROR;
    }
    for(int k=0; k<nTrial; k++)
        if(Data[k]==NULL)
        {
            CI.AddToLog("ERROR: UMapFile::WriteFile(). Data of trial %d not set.\n", k);
            return U_ERROR;
        }

    FILE* fp = NULL;
    if(FileName)  fp = fopen(FileName,"wb");
    if(fp==NULL) 
    {
        CI.AddToLog("ERROR: UMapFile::WriteFile(). Cannot write map-file: %s \n", FileName);
        return U_ERROR;
    }

    fprintf(fp,"MAPFILE1.0 \n");
    fprintf(fp,"// %s \n",GetTime());
    fprintf(fp,"// File created by UMapFile::WriteFile() \n");
    fprintf(fp,"%s",CI.GetProperties("// "));
    fprintf(fp,"// \n");
    fprintf(fp,"NTRIAL = %d\n",nTrial);
    
    if(Unt)       fprintf(fp,"UNIT = %s\n",Unt);
    else if(Unit) fprintf(fp,"UNIT = %s\n",Unit);

    fprintf(fp,"MAPTITLE = %s \n", (const char*)MapTitle);
    
    int nKan = Grid->GetNpoints();
    fprintf(fp, "NCHANNEL = %d \n",nKan);
    fprintf(fp, "NMAP = %d \n",nMaps);
    fprintf(fp, "GRID = { \n");
    for(int i=0; i<nKan; i++)
        fprintf(fp,"%s, %s \n",Grid->GetPosition(i).GetProperties(), Grid->GetName(i));
    fprintf(fp, "}\n");
    fprintf(fp, "NORMALS = { \n");
    for(int i=0 ; i<nKan; i++)
        fprintf(fp,"%s \n",Grid->GetOrientation(i).GetProperties());
    fprintf(fp, "}\n");
    
    if(MapLabels)
    {
        fprintf(fp, "MAPLABELS = { \n");
        for(int i=0; i<nMaps; i++)
            fprintf(fp,"%s\n",(const char*)MapLabels[i]);            
        fprintf(fp, "}\n");
    }
    if(TrialLabels)
    {
        fprintf(fp, "TRIALLABELS = { \n");
        for(int i=0; i<nTrial; i++)
            fprintf(fp,"%s\n",(const char*)TrialLabels[i]);
        fprintf(fp, "}\n");
    }
    fprintf(fp,"DATATYPE = DOUBLE\n");
    fprintf(fp,"// data ordered map by map\n");

    fprintf(fp,"%c%c",12,12);
    for(int it=0; it<nTrial; it++)
    {
        if(ChanFast==false)
        {
            fwrite(Data[it],sizeof(Data[0][0]),nMaps*nKan,fp);
        }
        else
        {
            for(int j=0; j<nMaps; j++)
                for(int i=0; i<nKan; i++) 
                    fwrite(Data[it]+nMaps*i+j,sizeof(Data[0][0]),1,fp);
        }
    }
    fclose(fp);

    return U_OK;
}

const UString& UMapFile::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMapFile-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(MapTitle         , " MapTitle      = %s     \n") +
                  UString(Unit             , " DataUnit      = %s     \n") +
                  UString(nMaps            , " Nmaps         = %d     \n") +
                  UString(nTrial           , " Ntrial        = %d     \n");
    

    if(Grid)      UString(Grid->GetNpoints(), " Nsensors      = %d     \n");
    else          UString(0                 , " Nsensors      = %d  (No Grid)   \n");

    
    if(Comment.IsNULL() || Comment.IsEmpty())   Properties.ReplaceAll('\n', ';');  
    else                                        Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UMapFile::MergeTrials(const UMapFile& m)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::MergeTrials(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(&m==NULL || m.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::MergeTrials(). Argument NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Grid==NULL && Data==NULL)
    {
        DeleteAllMembers(U_OK);
        *this = m;
        return error;
    }
    if(Grid==NULL || Grid->GetNpoints()!=m.Grid->GetNpoints() ||
       nMaps != m.nMaps)
    {
        CI.AddToLog("ERROR: UMapFile::MergeTrials(). Argument cannot be merged because data members are not consisent. \n");
        return U_ERROR;
    }
    
    int      NewAlloc  = nTrial+m.nTrial;
    double** NewData   = new double*[NewAlloc]; 
    UString* NewTrLabs = new UString[NewAlloc]; 
    if(NewData==NULL || NewTrLabs==NULL)
    {
        delete[] NewData;
        delete[] NewTrLabs;
        CI.AddToLog("ERROR: UMapFile::MergeTrials(). Memory allocation (NewAlloc=%d). \n", NewAlloc);
        return U_ERROR;
    }
    for(int it=0; it<NewAlloc; it++)   NewData[it]   = NULL;
    for(int it=0; it<nTrial  ; it++)
    {
        NewData[it] = Data[it];
        if(TrialLabels) NewTrLabs[it] = TrialLabels[it];
    }
    int Ndata = Grid->GetNpoints() * nMaps;
    for(int it=0; it<m.nTrial; it++)
    {
        NewData[nTrial+it] = new double[Ndata];
        if(NewData[nTrial+it]==NULL || m.Data[it]==NULL)
        {
            for(int it2=0; it2<it; it2++) delete[] NewData[nTrial+it];
            delete[] NewData;
            delete[] NewTrLabs;
            CI.AddToLog("ERROR: UMapFile::MergeTrials(). Memory allocation (itrial = %d, Ndata=%d). \n", it, Ndata);
            return U_ERROR;
        }
        for(int ij=0; ij<Ndata; ij++) NewData[nTrial+it][ij] = m.Data[it][ij];

        if(TrialLabels && m.TrialLabels) 
            NewTrLabs[nTrial+it] = m.TrialLabels[it];
    }
    
    delete[] Data;        Data        = NewData;
    delete[] TrialLabels; TrialLabels = NewTrLabs;
    nTrial      = NewAlloc;
    nTrialAlloc = NewAlloc;

    return U_OK;
}

ErrorType UMapFile::RemoveTrial(int itrial)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::RemoveTrial(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL || Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::RemoveTrial(). Data NULL or not (properly) set. \n");
        return U_ERROR;
    }

    if(itrial<0) itrial += nTrial;
    if(itrial<0 || itrial>=nTrial)
    {
        CI.AddToLog("ERROR: UMapFile::GetChannelView(). itrial argument out of range (itrial=%d). \n", itrial);
        return U_ERROR;
    }

    delete[] Data[itrial];
    for(int it = itrial; it<nTrial-1; it++)  Data[it] = Data[it+1];
    Data[nTrial-1] = NULL;

    if(TrialLabels)
    {
        for(int it = itrial; it<nTrial-1; it++) TrialLabels[it] = TrialLabels[it+1];
        TrialLabels[nTrial-1] = UString();
    }
    nTrial--;

    return U_OK;
}

UField* UMapFile::GetChannelView(int ichan, bool MapsFast, double TrialStep, double MapStep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::GetChannelView(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Data==NULL || Grid==NULL || Grid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMapFile::GetChannelView(). Data NULL or not (properly) set. \n");
        return NULL;
    }

    int Nchan = Grid->GetNpoints();
    if(ichan<0 || ichan>=Nchan)
    {
        CI.AddToLog("ERROR: UMapFile::GetChannelView(). ichan argument out of range (ichan=%d). \n", ichan);
        return NULL;
    }
    if(TrialStep==0.) TrialStep = 1.;
    if(MapStep==0.  ) MapStep   = 1.;


    UVector2 Min( 0.              ,  0.                 );
    UVector2 Max((nMaps-1)*MapStep, (nTrial-1)*TrialStep);
    int Dims[2] = {nMaps, nTrial};

    UField* Chan = new UField(Min, Max, Dims, UField::U_DOUBLE, 1);
    if(Chan==NULL || Chan->GetError()!=U_OK || Chan->GetDdata()==NULL)
    {
        delete Chan;
        CI.AddToLog("ERROR: UMapFile::GetChannelView(). Creating UField-object. \n");
        return NULL;
    }

    double* D = Chan->GetDdata();
    for(int it=0; it<nTrial; it++)
    {
        if(Data[it]==NULL)
        {
            delete Chan;
            CI.AddToLog("ERROR: UMapFile::GetChannelView(). Data[%d] == NULL. \n", it);
            return NULL;
        }
        memcpy(D+it*nMaps, Data[it]+ichan*nMaps, nMaps*sizeof(double));
    }

    if(MapsFast==false) Chan->SwapDirections();

    return Chan;
}
