#ifndef _UMAPFILE_INCLUDED
#define _UMAPFILE_INCLUDED

#include "String.h"

#define MAXUNITSTRING  20

class UGrid;
class UField;

class DLL_IO UMapFile
{
public:
    UMapFile();
    UMapFile(const UMapFile& m);
    UMapFile(const char* FileName);
    UMapFile(const UGrid* Grd, const UField* const* FArr, const char* UnitHor, const char* UnitVer, const char* Title=NULL);
    UMapFile(const UGrid* Grd, int nMap, const char* Title=NULL);
    UMapFile(const UGrid* Grd, int nMap, int NTrial, const char* Title=NULL);
    ~UMapFile();

    UMapFile&       operator=(const UMapFile& m);

    ErrorType       GetError(void) const {return error;}
    const UString&  GetProperties(UString Comment) const;

    ErrorType       SetData(const double *Dat, bool CHANFAST=false);
    ErrorType       SetData(const double *Dat, int itrial, bool CHANFAST=false);
    ErrorType       SetMapLabels(const char* const* Labels);
    ErrorType       SetMapLabels(const UString* Labels);
    ErrorType       SetTrialLabels(const char* const* Labels);
    ErrorType       SetTrialLabels(const UString* Labels);
    ErrorType       PrependTrialLabels(UString Text);
    ErrorType       RemoveChannelsOrigin(void);
    ErrorType       WriteFile(const char* FileName, const char* Unt) const;

    ErrorType       GetMinMaxData(double* Dmin, double* Dmax, int itrial) const;
    int             GetnMaps(void) const {return nMaps;}
    int             GetnTrial(void) const {return nTrial;}
    const UGrid*    GetGrid(void) const {return Grid;}
    const double*   GetData(void) const;
    const double*   GetData(int itrial) const;
    const UString*  GetMapLabels(void) const {return MapLabels;}
    const UString*  GetTrialLabels(void) const {return TrialLabels;}
    UString         GetMapTitle(void) const {return MapTitle;}

    ErrorType       MergeTrials(const UMapFile& m);
    ErrorType       ReAllocateMemory(void);
    ErrorType       RemoveTrial(int itrial);

    UField*         GetChannelView(int ichan, bool MapsFast, double TrialStep, double MapStep) const;

protected:
    UGrid*          Grid;        // Sensor Grid
    double**        Data;        // Data Array
    int             nMaps;       // Number of Maps    (usually number of time samples)
    int             nTrial;      // Number of trials
    int             nTrialAlloc; // Number of trials allocated
    void            SetAllMembersDefault(void);
    void            DeleteAllMembers(ErrorType E);

private:
    ErrorType       error;       // General error flag
    static UString  Properties;

    UString         MapTitle;    // Title of the map
    char            Unit[MAXUNITSTRING];
    UString*        MapLabels;   // Strings explaining the meaning of each map
    UString*        TrialLabels; // Strings explaining the meaning of each trial
    bool            ChanFast;    // if(ChanFast==TRUE) the data are ordered channel after channel 
                                 // else               map after map.
};

#endif //_UMAPFILE_INCLUDED
