#ifndef _MARCHINGCUBES_INCLUDED
#define _MARCHINGCUBES_INCLUDED


#include "MatVec.h"
#include "String.h"
#include "Surface.h"

class UManifold;
class UField;
class DLL_IO UMarchingCubes
{
public:
    UMarchingCubes();
    UMarchingCubes(const UField* F, int    Lev );
    UMarchingCubes(const UField* F, double DLev);
    UMarchingCubes(const UField* F, int    Lev , LevelType LevType, bool Manifold);
    UMarchingCubes(const UField* F, double DLev, LevelType LevType, bool Manifold);

    ~UMarchingCubes();
    UMarchingCubes& operator=(const UMarchingCubes &mc);

    const UString&      GetProperties(UString Comment) const;
    ErrorType           GetError() const            {if(this) return error; return U_ERROR;}

    ErrorType           SetComputeEdgeOrientations(bool set);
    ErrorType           NextSlice();
    ErrorType           AddDiamond(int xcoor, int ycoor, const int* Dat);
    ErrorType           AddDiamond(int xcoor, int ycoor, const double* Dat);
    ErrorType           AddCube(int xcoor, int ycoor, const int* CubeData);
    ErrorType           AddCube(int xcoor, int ycoor, const double* CubeData);
    const USurface*     GetSurface();
    const char*         GetOrientations() const;
    const UManifold*    GetManifold();

    static USurface     GetSurfaceCase(int TriCase);

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:    
    static UString      Properties;
    static const short  TriCaseTable[256][16];  // Edge indices
    int                 EdgeTab[144];           // "Internal QuadEdges, from one rib to another: 12 x 12"

    int                 dimx;
    int                 dimy;
    int                 dimz;
    double*             Xcoords; 
    double*             XcoordsH;
    double*             Ycoords; 
    double*             YcoordsH;
    double*             Zcoords; 
    double*             ZcoordsH;
    int                 zcoor;

    double              DLevel; //  Level for float and double data
    int                 ILevel; //  Level for char, short and int data
    LevelType           LevT;
    bool                CreateManifold;

    int**               RibX[2];
    int**               RibY[2];
    int**               RibZ[1];

    int**               EdgeX[1][6];
    int**               EdgeY[1][6];
    int**               EdgeZ[2][6];

    USurface*           Surf;
    UManifold*          Mani;
    bool                CompEdgeOri;
    int                 NOriAlloc;
    int                 NOri;
    char*               EdgeOrient; // edge orientations of each point added to Surf (0, 1 or 2)

    ErrorType           error;      // General error flag
    ErrorType           ReAllocateMemory(void);
    ErrorType           AddCubeCaseSurf(int xcoor, int ycoor, int CaseIndex);
    ErrorType           AddCubeCaseMani(int xcoor, int ycoor, int CaseIndex);
    ErrorType           AddOrientation(int ori);
};

#endif// _MARCHINGCUBES_INCLUDED
