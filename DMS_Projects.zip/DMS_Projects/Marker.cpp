/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*   Module to create and change a marker, which is a list "marked" samples      */
/*   (UEvent-objects) carrying the same name.                                    */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    26-11-98   Creation, from spitting ReadMarkers.cpp smaller parts
  Jdm    03-01-99   Added more comments.
  AdJ    16-02-99   Added more private variables
                    UMarker-objects contains all the variables of the markerfile
  AdJ    22-02-99   Added initialization for itrial[] and in isamp[] in the constructor
  JdM    03-03-99   delete a few pointers on error
  JdM    05-03-99   Use UEvent-object (defined in Event.h) instead of itrial[] and isamp[] arrays
  JdM    29-03-99   Minor bug fix in UMarker::operator=()
  JdM    04-04-99   Added the function GetEvent()
  JdM    08-08-99   Use CI-object to write errors to .log-file
  JdM    18-12-00   Derive UMarker-object from UEventArray()
  SG     17-03-03   Add SetName() function
  JdM    11-01-04   Remove MarkerName[] (use base class UEventArray::EventName[] and UEventArray::functions())
  JdM    08-02-04   Allow NULL pointer for markercomment in constructor
  JdM    01-05-05   Added operator==()
  JdM    11-10-06   Added GetBeginDeviatingIntervals() and UEventArray-constructor
  JdM    21-01-07   Added Thickness and ShowMarker data members
  JdM    27-01-07   Added SetAllMembersDefault() and DeleteAllMembers(), use UString for Properties;
  JdM    25-11-12   Added CopyAppearence()
  JdM    17-07-13   Added another GetProperties()
  JdM    21-02-15   Added SplitEvents()
  JdM    12-11-15   Added SplitMarker()
  */


#include <string.h>     

#include "Marker.h"
#include "MarkerArray.h"


#define TWO8        256
#define TWO16     65536
#define TWO24  16777216

UString      UMarker::Properties = UString();

void UMarker::SetAllMembersDefault(void)
{
    error            = U_OK;
    MarkerColor      = 255*TWO16;
    Thickness        = 2;
    ShowMarker       = true;
    MarkerGroupID    = 0;
    MarkerComment[0] = 0;
    Editable         = true;
    Properties       = UString();
}

void UMarker::DeleteAllMembers(ErrorType E)
{                           // Nothing to delete
    SetAllMembersDefault();
    error = E;
}
ErrorType UMarker::GetError(void) const
{
    if(this==NULL ) return U_ERROR;
    if(error!=U_OK) return U_ERROR;
    return UEventArray::GetError();
}

UMarker::UMarker() : UEventArray()
{
    SetAllMembersDefault();
}

UMarker::UMarker(const char *name, int nsamp, int NsampPTrial, int color, const char* comment, int groupid, bool editable) :
    UEventArray(name, nsamp, NsampPTrial)
/* 
     Allocate memory for a marker consisting of nsamp samples, having the name name[].
 */
{
    SetAllMembersDefault();
    if(UEventArray::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarker::UMarker(). Creating base class.\n");
        return;
    }

    MarkerColor     = color; 
    Thickness       = 2;
    ShowMarker      = true;
    Editable        = editable;
    MarkerGroupID   = groupid;

    if(comment==NULL)  strncpy(MarkerComment, "No Comment", MAXMARKER_COMMENT);
    else               strncpy(MarkerComment, comment, MAXMARKER_COMMENT);
}

UMarker::UMarker(const UMarker &m) : UEventArray(m)
/*
    Copy constructor.
 */
{
    SetAllMembersDefault();
    if(UEventArray::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarker::UMarker(). Creating base class.\n");
        return;
    }
    *this = m;
}

UMarker::UMarker(const UEventArray &E) : UEventArray(E)
/*
    Copy constructor.
 */
{
    SetAllMembersDefault();
    if(UEventArray::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarker::UMarker(). Creating base class.\n");
        return;
    }
}


UMarker& UMarker::operator=(const UMarker &m)
/*
   Assignment operator
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMarker::operator=(). this==NULL  . \n");
        static UMarker Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&m==NULL)
    {
        CI.AddToLog("ERROR: UMarker::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&m) return *this;

    DeleteAllMembers(U_OK);

    UEventArray::operator=((UEventArray)m);
    if(UEventArray::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarker::operator=(). Copying base class.\n");
        return *this;
    }

    MarkerColor   = m.MarkerColor;
    Thickness     = m.Thickness;
    ShowMarker    = m.ShowMarker;
    MarkerGroupID = m.MarkerGroupID;
    Editable      = m.Editable;

    memcpy(MarkerComment, m.MarkerComment, MAXMARKER_COMMENT);   

    return *this;
}

bool UMarker::operator==(const UMarker &m) const
{
    if(this==NULL && &m==NULL) return true;
    if(this==&m)               return true;
    if(this==NULL || &m==NULL) return false;

    return UEventArray::operator==((UEventArray)m);
}

ErrorType UMarker::SetColor(int color)
{
    MarkerColor = color;
    return U_OK;
}

UColor UMarker::GetColor() const
{
    int Ired = (MarkerColor%TWO24) /TWO16;
    int Igre = (MarkerColor%TWO16) /TWO8 ;
    int Iblu = (MarkerColor%TWO8 )       ;
    return UColor(Ired,Igre,Iblu);
}
ErrorType UMarker::SetColorAsInt(unsigned int Col)
{
    if(this==NULL || GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMarker::SetColorAsInt(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    MarkerColor = Col;
    return U_OK;
}
ErrorType UMarker::SetColor(UColor Col)
{
    if(this==NULL || GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMarker::SetColor(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    MarkerColor = TWO16*Col.GetR() + TWO8*Col.GetG() + Col.GetB();
    return U_OK;
}
ErrorType UMarker::SetThickness(int Thick)
{
    if(this==NULL || GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMarker::SetThickness(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Thick<=0 || Thick>=100)
    {
        CI.AddToLog("ERROR: UMarker::SetThickness(). Argument out of range (Thick=%d).\n", Thick);
        return U_ERROR;
    }
    Thickness = Thick;
    return U_OK;
}
ErrorType UMarker::SetShowMarker(bool Show)
{
    if(this==NULL || GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMarker::SetShowMarker(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    ShowMarker = Show;
    return U_OK;
}
ErrorType UMarker::CopyAppearence(const UMarker* pMark)
{
    if(this==NULL || GetError()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMarker::CopyAppearence(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMark==NULL || pMark->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::CopyAppearence(). NULL or erroneous argument.\n");
        return U_ERROR;
    }
    ShowMarker  = pMark->GetShowMarker();
    MarkerColor = pMark->GetColorAsInt();
    Thickness   = pMark->GetThickness();

    return U_OK;
}


const UString& UMarker::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMarker-object\n");
        return Properties;
    }

    Properties = UString();

    Properties += UString(GetMarkerName(), " MarkerName    = %s \n");
    Properties += UString((int)MarkerColor," Color         = %d \n");
    Properties += UString(Thickness       ," Thickness     = %d \n");
    Properties += UString(UString(BoolAsText(ShowMarker))," ShowMarker    = %s \n");        
    Properties += UString(MarkerComment,   " MarkerComment = %s \n");
    Properties += UString(MarkerGroupID,   " MarkerGroupID = %d \n");

    UString    PropBase;
    if(Comment.IsNULL() || Comment.IsEmpty())
    {
        PropBase = UEventArray::GetProperties("\n");
    }
    else
    {
        Properties += Comment + UString("\n");
        PropBase    = UEventArray::GetProperties("   ");
        PropBase.InsertAtEachLine(Comment);
    }
    Properties += PropBase;

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');  
    else                                      Properties.InsertAtEachLine(Comment);
    return Properties;
}

const UString& UMarker::GetProperties(UString Comment, double Tacq) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMarker-object\n");
        return Properties;
    }
    if(Tacq<=0)
    {
        CI.AddToLog("ERROR: UMarker::GetProperties(), Tacq invalid (%f) .\n", Tacq);
        return GetProperties("Comment");
    }

    Properties = UString();

    Properties += UString(GetMarkerName(), " MarkerName          = %s \n");
    Properties += UString((int)MarkerColor," Color               = %d \n");
    Properties += UString(Thickness       ," Thickness           = %d \n");
    Properties += UString(UString(BoolAsText(ShowMarker))," ShowMarker          = %s \n");        
    Properties += UString(MarkerComment,   " MarkerComment       = %s \n");
    Properties += UString(MarkerGroupID,   " MarkerGroupID       = %d \n");

    UString    PropBase;
    if(Comment.IsNULL() || Comment.IsEmpty())
    {
        PropBase = UEventArray::GetProperties("\n");
    }
    else
    {
        Properties += Comment + UString("\n");
        PropBase    = UEventArray::GetProperties("   ");
        PropBase.InsertAtEachLine(Comment);
    }
    Properties += PropBase + UString("\n");;
    Properties += UString(UEventArray::GetMinInterval()   *Tacq    , " MinTimeInterval     =     %9.3f \n");
    Properties += UString(UEventArray::GetMedianInterval()*Tacq    , " MedTimeInterval     =     %9.3f \n");
    Properties += UString(UEventArray::GetMaxInterval()   *Tacq    , " MaxTimeInterval     =     %9.3f \n");
    Properties += UString(UEventArray::GetAverageTimeInterval(Tacq), " AverageTimeInterval =     %9.3f \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');  
    else                                      Properties.InsertAtEachLine(Comment);
    return Properties;
}

UMarker* UMarker::GetBeginDeviatingIntervals(int Threshold, bool ShortIntervals, bool LongIntervals) const
{
    if(this==NULL || GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::GetBeginDeviatingIntervals(). NULL or erroneous object. \n");
        return NULL;
    }

    UEventArray* Evar = GetBeginDeviatingIntervals(Threshold, ShortIntervals, LongIntervals);
    if(Evar==NULL || Evar->GetError()!=U_OK)
    {
        delete Evar;
        CI.AddToLog("ERROR: UMarker::GetBeginDeviatingIntervals(). Getting events from base class. \n");
        return NULL;
    }
    UMarker* M = new UMarker(*Evar);
    delete Evar;
    if(M==NULL || M->GetError()!=U_OK)
    {
        delete M;
        CI.AddToLog("ERROR: UMarker::GetBeginDeviatingIntervals(). Converting base class to UMarker-object. \n");
        return NULL;
    }
    return M;
}
UMarkerArray* UMarker::SplitMarker(int GroupSize, int NPres, double fsamp) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::SplitMarker(). NULL or erroneous object. \n");
        return NULL;
    }
    if(GroupSize<=0)
    {
        CI.AddToLog("ERROR: UMarker::SplitMarker(). Invalid group size (%d). \n", GroupSize);
        return NULL;
    }
    if(fsamp<=0.)
    {
        CI.AddToLog("ERROR: UMarker::SplitMarker(). Invalid fsamp argument (fsamp = %f). \n", fsamp);
        return NULL;
    }

    UMarkerArray* Mar = new UMarkerArray(0, GetnSampTrial(), NPres, fsamp);
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        delete Mar;
        CI.AddToLog("ERROR: UMarker::SplitMarker(). Creating (empty) UMarkerArray object. \n");
        return NULL;
    }
    int NGroup = (GetnEvents()+GroupSize-1)/GroupSize;

    for(int k=0; k<NGroup; k++)
    {
        int     ievB  =  k   *GroupSize;
        int     ievE  = (k+1)*GroupSize;
        UMarker M     = *this;
        if(k!=NGroup-1) M.DeleteEvents(ievE,     -1);
        if(k!=0       ) M.DeleteEvents(0   , ievB-1);
        if(M.GetnEvents()<=0) continue;

        UString Name = UString(this->GetName()) + "_sub_" + UString(k, "%d");
        M.SetName((const char*)Name);
        Mar->AddMarker(&M);
    }
    return Mar;
}

UMarkerArray* UMarker::SplitEvents(const UMarker* MSplit, int NPres, double fsamp) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::SplitEvents(). NULL or erroneous object. \n");
        return NULL;
    }
    if(MSplit==NULL || MSplit->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::SplitEvents(). NULL or erroneous UMarker argument. \n");
        return NULL;
    }
    if(MSplit->GetnEvents()<2)
    {
        CI.AddToLog("ERROR: UMarker::SplitEvents(). MSplit marker has less than 2 events. \n");
        return NULL;
    }
    if(fsamp<=0.)
    {
        CI.AddToLog("ERROR: UMarker::SplitEvents(). Invalid fsamp argument (fsamp = %f). \n", fsamp);
        return NULL;
    }
    UMarker MSort = *MSplit;
    if(MSort.GetError()!=U_OK || MSort.SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarker::SplitEvents(). Copying or sorting events from  MSplit. \n");
        return NULL;
    }
    UMarkerArray* Mar = new UMarkerArray(0, GetnSampTrial(), NPres, fsamp);
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        delete Mar;
        CI.AddToLog("ERROR: UMarker::SplitEvents(). Creating (empty) UMarkerArray object. \n");
        return NULL;
    }

    int NSplit = MSort.GetnEvents();
    for(int k=0, icomp=0; k<NSplit; k++)
    {
        int     SampB = k<0       ? -1  : MSort.GetAbsSample(k  );
        int     SampE = k==NSplit ? -1  : MSort.GetAbsSample(k+1);
        UMarker M     = *this;
        M.SelectEventsAbsSamp(SampB, SampE-1);
        if(M.GetnEvents()<=0) continue;

        UString Name = UString(this->GetName()) + "_" + UString(icomp++, "%d");
        M.SetName((const char*)Name);
        Mar->AddMarker(&M);
    }
    return Mar;
}

