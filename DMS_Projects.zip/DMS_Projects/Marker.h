#ifndef _MARKERS_INCLUDED
#define _MARKERS_INCLUDED

#define MAXMARKER_COMMENT     64


#include "EventArray.h"
#include "Color.h"

class UMarkerArray;
class DLL_IO UMarker : public UEventArray
{
public:
    UMarker();
    UMarker(const char *name, int nsamp, int NsampTrial, int color, const char* comment, int groupid, bool editable);
    UMarker(const UEventArray &E);
    UMarker(const UMarker &m);

    UMarker&                operator=(const UMarker &m);
    bool                    operator==(const UMarker &m) const;
    bool                    operator!=(const UMarker &m) const {return NOT(operator==(m));}
    ErrorType               GetError(void)      const;
    const UString&          GetProperties(UString Comment) const;
    const UString&          GetProperties(UString Comment, double Tacq) const;

    unsigned int            GetColorAsInt()  const {return MarkerColor;} 
    UColor                  GetColor()       const; 
    int                     GetThickness()   const {return Thickness;}
    bool                    GetShowMarker()  const {return ShowMarker;}
    ErrorType               SetColorAsInt(unsigned int Col);
    ErrorType               SetColor(UColor Col);
    ErrorType               SetThickness(int Thick);
    ErrorType               SetShowMarker(bool Show);
    ErrorType               CopyAppearence(const UMarker* pMark);

    const char*             GetMarkerName(void) const    {return GetEventName();}
    int                     GetnSamples(void)   const    {return GetnEvents();}
    int                     GetTrial(int im)    const    {return GetEvent(im).trial;}
    int                     GetSamp (int im)    const    {return GetEvent(im).sample;}
    int                     GetMarkerGroupID(void) const {return MarkerGroupID;}
    const char*             GetComment(void) const       {return MarkerComment;}
    bool                    GetEditable(void) const      {return Editable;}

    ErrorType               SetColor(int color);
    UMarker*                GetBeginDeviatingIntervals(int Threshold, bool ShortIntervals, bool LongIntervals) const;
    UMarkerArray*           SplitEvents(const UMarker* MSplit, int NPres, double fsamp) const;
    UMarkerArray*           SplitMarker(int GroupSize, int NPres, double fsamp) const;

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;            // General error flag
    static UString          Properties;
    unsigned int            MarkerColor;
    int                     Thickness;
    bool                    ShowMarker;
    char                    MarkerComment[MAXMARKER_COMMENT];
    int                     MarkerGroupID;
    bool                    Editable;
};


#endif //_MARKERS_INCLUDED
