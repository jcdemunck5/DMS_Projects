/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*   Module to manage an array of event arrays (contents of a CTF marker file).  */
/*                                                                               */
/*                                                                               */
/*   Jan de Munck                                                                */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    18-12-00   Creation, derived from CTFDataMarker() object (which is now obsolete).
  Jdm    17-05-01   Bug fix in exporting markerfile
  Jdm    10-10-01   Added mechanism to skip Gost Events
Jdm/FB   11-10-01   Bug fixed option of 10-10-01, set TimeGhost = 0.0224 ms (instead 0f .020)
  Jdm    20-03-02   Added new constructor (creating array of empty markers)
                    Added SetMarker()
  JdM    27-03-02   IsNameEquivalent(): Allow wild cards
  JdM    01-04-02   WriteMarkersCTF() Two minor bug fixes in output format (to allow CTF software to read it)
  JdM    14-06-02   WriteMarkersCTF(). Numbering CLASSID
  JdM    29-08-02   Made returned pointers const
  JdM    26-02-03   Add AddMarker() and new GetMarker()
                    Bug fix MarkerFile constructor. Set data to defaults first.
SG/JdM   04-03-03   Added function GetMarkerIndex()
SG/JdM   04-03-03   Added function EqualizeEvents()
SG/JdM   17-03-03   Bug fix: SetMarker(). Delete old marker before setting new one
JV/JdM   18-03-03   "Bug Fix" WriteMarkersCTF(). Use 6 instead of 4 digits to export time information (important for hight sample frequencies)
  JdM    16-11-03   Added RedistributeTrials(). 
                    In various functions: Test whether nSampTrial is constant over markers
  JdM    20-11-03   Added parameter to one of the constructors
  JdM    05-12-03   Added new RedistributeTrials()
  JdM    10-01-04   Added RemoveMarker() and SetName()
  JdM    16-01-04   Add AddEvent() and SortEvents() and DeleteEvent() and SetEvent()
  JdM    17-01-04   Add AddEquiDistantEvents()
SG/JdM   20-01-04   Add new AddEquiDistantEvents()
SG/JdM   20-01-04   Copied change from 20-11-03, from version SG:    Added function AddEvent()
SG/JdM   20-01-04   Copied change from 20-11-03, from version SG:    Added InsertEvents()
  JdM    12-02-04   Bug Fix: RedistributeTrials(). Testing whether all epochs are equal (true instead of U_OK)
  JdM    21-02-04   Added DeleteEvents() and DeleteMiddleEvents() and CopyMarker()
  JdM    24-06-04   MergeMarkerArray()
  JdM    04-07-04   Added RemoveEmptyMarkers()
  JdM    08-07-04   Added GetEventIndex()
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    01-11-04   Bug fix: CopyMarker(). Testing CopyName==NULL
  JdM    03-11-04   Added GetIntervalsText().
  JdM    06-11-04   Added: GetIntervalsSinCos()
  JdM    20-11-04   Added: GetMinInterval()
  JdM    21-11-04   Added: GetMarkerName(), GetAverageTimeInterval()
  JdM    29-01-04   Added: CopyToAllEpochs()
  JdM    01-05-05   Added: RemoveDoubleNames() and IsSubSet()
                    GetMarkerIndex(). Remove WARNING
  JdM    03-05-05   Replaced obsolete MAXMARKER_NAME by MAXEVENT_NAME
  JdM    18-09-05   Added MakeNamesUnique();
  JdM    09-10-04   Added: GetMaxInterval()
  JdM    10-11-05   Made EventName a UString-object
  JdM    01-12-05   Added another GetIntervalsSinCos()
  JdM    27-01-06   Initialize properties string
  JdM    16-02-06   "scratch"-constructor: allow Nmarkers=0, test other input parameters
  JdM    04-04-06   Added GetIntervalsEpoch()
  JdM    26-11-06   GetIntervalsSinCos() and GetIntervalsEpoch() return UFieldGraph* (i.s.o. UField*)
                    GetIntervalsEpoch(): two parameters added
  JdM    05-01-07   Changed constructor argument from UCTFData into UMEEGDataBase
  JdM    21-01-07   Added function to edit (new) viewing members of UMarker
  JdM    26-01-07   ReadMarkers(): avoid endless loops
  JdM    27-01-07   Added SetAllMembersDefault() and DeleteAllMembers(), use UString for Properties;
  JdM    18-02-07   Added CopyAllEventsToAllEpochs()
  JdM    08-09-07   Added GetTimesFirstInEpoch()
  JdM    05-10-07   GetIntervalsEpoch(): added parameter
  JdM    30-11-07   file name constructor: made UMEEGDataBase*  argument const UMEEGDataBase* 
  JdM    05-04-08   bug fix: ReadMarkers(). Reading marker names with spaces.
  JdM    23-04-08   bug fix: ReadMarkers(). Set markername and markercomment to 0 with memset (to avoid strange ending characters).
  JdM    23-05-08   GetIntervalsSinCos() added NSegment parameter
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    03-01-09   Added ResampleData()
  JdM    29-08-09   Added another (FieldGraph selective) GetAverageTimeInterval()
  JdM    12-02-10   MergeMarkerArray(), AddMarker(), AddNewMarker() added Prepend parameter
  JdM    15-03-12   Systematically test this==NULL and error==U_OK
  JdM    18-03-12   ReadMarkers(). Added four arguments
  JdM    28-03-12   IsNameEquivalent() and GetMarkerIndex(). Added bool CaseSense-argument (default=false)
  JdM    27-04-12   Added RedistributeTrials().
  JdM    07-08-12   BUG FIX RedistributeTrials() dd 27-04-12. Now use newly implemented RedistributeTrials() of UEventArray
  JdM    25-11-12   SetMarker(). Added Keep Appearence parameter
                    Added SetAppearence()
  JdM    08-11-13   Added PrependName()
                    Bug Fix: RedistributeTrials(). Update SRate with new sample frequency.
  JdM    17-11-13   Renamed WriteMarkerFile() as WriteMarkersCTF()
                    Added WriteMarkersTXT() and ReadMarkersTXT()
                    Added new filename constructor (calling ReadMarkersTXT())
  JdM    18-11-13   Added RemoveDoubleMarkers()
                    Bug fix RedistributeTrials(const UEpochs* , NewSampFreq). Setting nSampTrial. Remove obsolete final parameter: NewSamplesTrial.
  JdM    08-12-13   Added ReadMarkersEVL() and applied it in constructors.
  JdM    29-01-14   Bug Fix. RemoveDoubleMarkers(). Only one double marker was removed, not all.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    14-01-15   Added ReadMarkersTRG()
  JdM    27-03-15   Added GetCrossingBlockMatrix(), AreEventsSorted(). Added UMarker constructor
                    Removed (obsolete) SortMarkers()
                    Added single UMarker constructor
  JdM    29-09-15   CopyMarker(). Compare sample frequencies more liberally
  JdM    28-03-16   Added AddEquiWidthEvents()
  JdM    13-05-17   Added ReplaceMarkers()
 */

#include <string.h>
#include <math.h>

#define TRG_CODE_LENGTH 8
typedef struct 
{
    double     sample;
    char       code[TRG_CODE_LENGTH + 2]; /* waste one byte to avoid odd length */
} ANTtexttrig;


#include "MarkerArray.h"
#include "Epochs.h"
#include "AnalyzeLine.h"
#include "MEEGDataBase.h"
#include "MatrixSparse.h"

/* Inititalize static const parameters. */
const double UMarkerArray::TimeGhost  = 0.0224;
UString      UMarkerArray::Properties = UString();

#define MARKERTEXTID "BiapMarkers1.0"
void UMarkerArray::SetAllMembersDefault(void)
{
    error        = U_OK; 
    nMarkers     = 0;       
    pMarkers     = NULL;    
    nSampTrial   = 1;   
    PreStimPts   = 0;
    SRate        = 1;    
    RemGhostMark = false;
    NGostRemoved = 0;
    Properties   = UString();
}

void UMarkerArray::DeleteAllMembers(ErrorType E)
{
    if(pMarkers)
        for(int im=0; im<nMarkers; im++)
            delete pMarkers[im];

    delete[] pMarkers;
    SetAllMembersDefault();
    error = E;
}
UMarkerArray::UMarkerArray() 
{
    SetAllMembersDefault();
}
UMarkerArray::UMarkerArray(const char* MarkerFile)
{
    SetAllMembersDefault();
    error = ReadMarkersTXT(MarkerFile);
}
UMarkerArray::UMarkerArray(const char* MarkerFile, const UMEEGDataBase* Data, bool RemoveGhostMarkers)
{
    SetAllMembersDefault();

    FILE* fpMark = NULL;
    if(MarkerFile)  fpMark = fopen(MarkerFile,"rb");
    if(fpMark==NULL)
    {
        CI.AddToLog( "ERROR UMarkerArray::UMarkerArray(): cannot open %s \n",MarkerFile);
        DeleteAllMembers(U_ERROR);
        return;
    }
    char line[400];
    GetLine(line,sizeof(line),fpMark);
    fclose(fpMark);
    if(!strncmp(line, MARKERTEXTID, sizeof(MARKERTEXTID)-1))
    {
        *this = UMarkerArray(MarkerFile);
        return;
    }

    if(Data==NULL || Data->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Data argument is NULL orr erroneous.\n");
        return;
    }

    bool CaseSensitive = false;
    UFileName FM(MarkerFile);
    if(FM.HasExtension("evl", CaseSensitive)==true)
    {
        error = ReadMarkersEVL(MarkerFile, Data->GetNsampTrial(), Data->GetPreNTriggerPnts(), Data->GetSampleRate());
    }
    else if(FM.HasExtension("trg", CaseSensitive)==true)
    {
        error = ReadMarkersTRG(MarkerFile, Data->GetNsampTrial(), Data->GetPreNTriggerPnts(), Data->GetSampleRate());
    }
    else
    {
        error = ReadMarkersCTF(MarkerFile, Data->GetNsampTrial(), Data->GetPreNTriggerPnts(), Data->GetSampleRate(), RemoveGhostMarkers);
    }
}

UMarkerArray::UMarkerArray(const char* MarkerFile, int NsampTrial, int prestimPts, double srate, bool RemoveGhostMarkers)
{
    SetAllMembersDefault();

    if(MarkerFile==NULL || NsampTrial<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Arguments invalid. \n");
        return;
    }

    bool CaseSensitive = false;
    UFileName FM(MarkerFile);
    if(FM.HasExtension("evl", CaseSensitive)==true)
    {
        if(ReadMarkersEVL(MarkerFile, NsampTrial, prestimPts, srate)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Reading markers from EVL-file (%s). \n", MarkerFile);
        }
    }
    else if(FM.HasExtension("trg", CaseSensitive)==true)
    {
        if(ReadMarkersTRG(MarkerFile, NsampTrial, prestimPts, srate)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Reading markers from TRG-file (%s). \n", MarkerFile);
        }
    }
    else
    {
        if(ReadMarkersCTF(MarkerFile, NsampTrial, prestimPts, srate, RemoveGhostMarkers)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Reading markers from CTF-file (%s). \n", MarkerFile);
        }
    }
}

UMarkerArray::UMarkerArray(int Nmarkers, int NsampTrial, int prestimPts, double srate)
/*
    Create an empty array of Nmarkers default markers, that can be edited and
    exported afterwards.
 */
{
    SetAllMembersDefault();

    if(Nmarkers<0 || NsampTrial<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Invalid arguments: Nmarkers=%d, NsampTrial=%d, srate=%f   \n", Nmarkers, NsampTrial, srate);
        return;
    }

    pMarkers     = new UMarker*[MAX(1,Nmarkers)];
    if(pMarkers==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Memory allocation error.\n");
        return;
    }
    pMarkers[0]  = NULL;

    nSampTrial   = NsampTrial;
    PreStimPts   = prestimPts;
    SRate        = srate;
    NGostRemoved = 0;  
    RemGhostMark = false;

    error        = U_OK;
    nMarkers     = Nmarkers;
    for(int n=0; n<Nmarkers; n++) pMarkers[n] = new UMarker("NoName", 0, nSampTrial, n, "No Comment", 2, true);
}

UMarkerArray::UMarkerArray(const UMarker* M, int prestimPts, double srate)
{
    SetAllMembersDefault();

    if(M==NULL || M->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Invalid or NULL UMarker argument   \n");
        return;
    }
    if(M->GetnSampTrial()<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::UMarkerArray(). Invalid arguments: NsampTrial=%d, srate=%f   \n", M->GetnSampTrial(), srate);
        return;
    }

    nSampTrial   = M->GetnSampTrial();
    PreStimPts   = prestimPts;
    SRate        = srate;
    NGostRemoved = 0;  
    RemGhostMark = false;

    error        = AddMarker(M);
}

UMarkerArray::UMarkerArray(const UMarkerArray& Mar)
{
    SetAllMembersDefault();
    *this = Mar;
}

UMarkerArray::~UMarkerArray()
{
    DeleteAllMembers(U_OK);
}

UMarkerArray& UMarkerArray::operator=(const UMarkerArray &Mar)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::operator=(). this==NULL  . \n");
        static UMarkerArray Default;
        Default.error = U_ERROR;
        return Default;
    }
    if(&Mar==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&Mar) return *this;

    DeleteAllMembers(U_OK);

    if(Mar.pMarkers)
    {
        pMarkers = new UMarker*[Mar.nMarkers];
        if(pMarkers == NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMarkerArray::operator=(). Memory allocation error.\n");
            return *this;
        }
        for(int n=0; n<Mar.nMarkers; n++) pMarkers[n] = NULL;
        for(int n=0; n<Mar.nMarkers; n++)
        {
            pMarkers[n] = new UMarker(*Mar.pMarkers[n]);
            if(pMarkers[n]==NULL || pMarkers[n]->GetError()!=U_OK)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMarkerArray::operator=(). Memory allocation error in marker %d.\n",n);
                return *this;
            }
        }
    }
    nMarkers     = Mar.nMarkers;
    nSampTrial   = Mar.nSampTrial;
    PreStimPts   = Mar.PreStimPts;
    SRate        = Mar.SRate;
    NGostRemoved = Mar.NGostRemoved;  
    RemGhostMark = Mar.RemGhostMark;

    error        = Mar.error;
    return *this;
}

bool UMarkerArray::IsSubSet(const UMarkerArray* Mar) const
{
    if(this==NULL || error!=U_OK || pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::IsSubSet(). MarkerArrar NULL or not properly set. \n");
        return false;
    }
    if(Mar==NULL) return true;
    if(Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::IsSubSet(). Argument not properly set. \n");
        return false;
    }
    for(int im1=0; im1<Mar->GetnMarkers(); im1++)
    {
        bool found = false;
        for(int im2=0; im2<GetnMarkers(); im2++)
        {
            if(*(Mar->pMarkers[im1]) == *(pMarkers[im2]) ) 
            {
                found = true;
                break;
            }
        }
        if(found=false) return false;
    }
    return true;
}

double UMarkerArray::GetAverageTimeInterval(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Markers not set. \n");
        return 0.;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Argument out of range (iMarker=%d). \n", iMarker);
        return 0.;
    }
    return pMarkers[iMarker]->GetAverageTimeInterval(GetSTime());
}
double UMarkerArray::GetAverageTimeInterval(int iMarker, const UFieldGraph* FG, int Level) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Markers not set. \n");
        return 0.;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetAverageTimeInterval(). Argument out of range (iMarker=%d). \n", iMarker);
        return 0.;
    }
    return pMarkers[iMarker]->GetAverageTimeInterval(FG, Level, GetSTime());
}

int UMarkerArray::GetMinInterval(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMinInterval(). Object NULL or erroneous.\n");
        return 0;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMinInterval(). Markers not set. \n");
        return 0;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMinInterval(). Argument out of range (iMarker=%d). \n", iMarker);
        return 0;
    }
    return pMarkers[iMarker]->GetMinInterval();
}
int UMarkerArray::GetMaxInterval(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMaxInterval(). Object NULL or erroneous.\n");
        return 0;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMaxInterval(). Markers not set. \n");
        return 0;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMaxInterval(). Argument out of range (iMarker=%d). \n", iMarker);
        return 0;
    }
    return pMarkers[iMarker]->GetMaxInterval();
}

UFieldGraph* UMarkerArray::GetIntervalsSinCos(int iMarker, double Shift, double DownSample, int Harm, bool Sin) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Markers not set. \n");
        return NULL;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Argument out of range (iMarker=%d). \n", iMarker);
        return NULL;
    }
    return pMarkers[iMarker]->GetIntervalsSinCos(GetSTime(), Shift, DownSample, Harm, Sin);
}

UFieldGraph* UMarkerArray::GetIntervalsSinCos(int iMarker, const UEpochs* Epo, int Harm, bool Sin, int NSegment) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Markers not set. \n");
        return NULL;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsSinCos(). Argument out of range (iMarker=%d). \n", iMarker);
        return NULL;
    }
    return pMarkers[iMarker]->GetIntervalsSinCos(Epo, GetSTime(), Harm, Sin, NSegment);
}

UFieldGraph* UMarkerArray::GetIntervalsEpoch(int iMarker, const UEpochs* Epo, int NSegment, double DeadTimeBeg_s, double DeadTimeEnd_s, double IntervalWindow_s, bool ComputeSD) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsEpoch(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsEpoch(). Markers not set. \n");
        return NULL;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsEpoch(). Argument out of range (iMarker=%d). \n", iMarker);
        return NULL;
    }
    return pMarkers[iMarker]->GetIntervalsEpoch(Epo, GetSTime(), NSegment, DeadTimeBeg_s, DeadTimeEnd_s, IntervalWindow_s, ComputeSD);
}

UFieldGraph* UMarkerArray::GetTimesFirstInEpoch(int iMarker, const UEpochs* Epo) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetTimesFirstInEpoch(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetTimesFirstInEpoch(). Markers not set. \n");
        return NULL;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetTimesFirstInEpoch(). Argument out of range (iMarker=%d). \n", iMarker);
        return NULL;
    }
    return pMarkers[iMarker]->GetTimesFirstInEpoch(Epo, GetSTime());
}

UMatrixSparse* UMarkerArray::GetCrossingBlockMatrix(int NLeft, int NRight, int Ntrial) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). Markers not set. \n");
        return NULL;
    }

    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL || pMarkers[im]->GetError()!=U_OK || pMarkers[im]->GetnEvents()<=0)
        {
            CI.AddToLog("ERROR: GetCrossingBlockMatrix(). UMarker [%d] NULL, erroneous or empty. \n", im);
            return NULL;
        }
        if(pMarkers[im]->GetnSampTrial()!=nSampTrial)
        {
            CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). UMarker [%d] has inconsisten number of samples per trial (should be %d). \n", im, nSampTrial);
            return NULL;
        }
    }
    if(AreEventsSorted()==false)
    {
        UMarkerArray MCopy(*this);
        if(MCopy.GetError()!=U_OK || MCopy.SortEvents()!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). Copying or sorting unsorted events. \n");
            return NULL;
        }
        return MCopy.GetCrossingBlockMatrix(NLeft, NRight, Ntrial);
    }

    int NWindow = NRight+NLeft+1;
    int ArrDim  = nMarkers*nMarkers*2*NWindow;
    if(ArrDim<=0)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). Invalid arguments (NLeft=%d, NRight=%d).\n", NLeft, NRight);
        return NULL;
    }

    double* ColRowArray = new double[ArrDim];
    if(ColRowArray==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockArray(). Memory allocation (NLeft=%d, NRight=%d, ArrDim=%d).\n", NLeft, NRight, ArrDim);
        return NULL;
    }
    for(int kk=0; kk<ArrDim; kk++) ColRowArray[kk] = 0.;

    int MaxSamp = Ntrial*nSampTrial;

    for(int im1=0; im1<nMarkers; im1++)
    {
        for(int iev1=0; iev1<pMarkers[im1]->GetnEvents(); iev1++)
        {
            int isamp1 = pMarkers[im1]->GetAbsSample(iev1);
            int b1     = isamp1-NLeft;
            int e1     = isamp1+NRight;
            if(b1>=MaxSamp || e1<0) continue;

            for(int im2=0; im2<nMarkers; im2++)
            {
                for(int iev2=0; iev2<pMarkers[im2]->GetnEvents(); iev2++)
                {
                    int isamp2 = pMarkers[im2]->GetAbsSample(iev2);
                    int b2     = isamp2-NLeft;
                    if(b2>=MaxSamp || e1<0) continue;

                    int     diff   = isamp2-isamp1;
                    if(abs(diff)>=NWindow) continue;

                    double* ColRow = ColRowArray+(im1*nMarkers+im2)*2*NWindow;
                    if(diff>=0) ColRow[        diff] += 1;   // First collumn
                    if(diff<=0) ColRow[NWindow-diff] += 1;   // First row
                }
            }
        }

    }

    UMatrixSparse* pMS = new UMatrixSparse();
    if(pMS==NULL || pMS->GetError()!=U_OK || pMS->SetBlockToeplitz(ColRowArray, nMarkers, NWindow)!=U_OK)
    {
        delete pMS;
        CI.AddToLog("ERROR: UMarkerArray::GetCrossingBlockMatrix(). Creating UMatrixSparse, or setting block Toeplitz matrix.\n");
        return NULL;
    }
    return pMS;
}

UString UMarkerArray::GetIntervalsText(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsText(). Object NULL or erroneous.\n");
        return UString();
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsText(). Markers not set. \n");
        return UString();
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetIntervalsText(). Argument out of range (iMarker=%d). \n", iMarker);
        return UString();
    }
    return pMarkers[iMarker]->GetIntervalsText(GetSTime());
}

ErrorType UMarkerArray::AddEvent(int iMarker, UEvent ev)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->AddEvent(ev);
}

ErrorType UMarkerArray::AddEquiDistantEvents(const char* MkName, int IndexBegin, int IndexEnd, int NEv) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiDistantEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). pMarkers array not set. \n");
        return U_ERROR;
    }
    if(MkName==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEqualizedEvents(). Marker name is NULL .\n");
        return U_ERROR;
    }
    int iMarker = GetMarkerIndex(MkName);
    if(iMarker<0)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEqualizedEvents(). Name not present: %s .\n", MkName);
        return U_ERROR;
    }
    return AddEquiDistantEvents(iMarker, IndexBegin, IndexEnd, NEv);
}

ErrorType UMarkerArray::AddEquiDistantEvents(int iMarker, int ievFrom, int ievTo, int nevAdd)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiDistantEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiDistantEvents(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiDistantEvents(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->AddEquiDistantEvents(ievFrom, ievTo, nevAdd);
}
ErrorType UMarkerArray::AddEquiWidthEvents(int iMarker, int ievFrom, int ievTo, int Width)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiWidthEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiWidthEvents(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEquiWidthEvents(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->AddEquiWidthEvents(ievFrom, ievTo, Width);
}

ErrorType UMarkerArray::DeleteEvent(int iMarker, int iev)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvent(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvent(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvent(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->DeleteEvent(iev);
}

ErrorType UMarkerArray::DeleteEvents(int iMarker, int ievFrom, int ievTo)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvents(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteEvents(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->DeleteEvents(ievFrom, ievTo);
}

ErrorType UMarkerArray::DeleteMiddleEvents(int iMarker)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteMiddleEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteMiddleEvents(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::DeleteMiddleEvents(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->DeleteMiddleEvents();
}

ErrorType UMarkerArray::SetEvent(int iMarker, int iev, UEvent ev)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetEvent(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetEvent(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetEvent(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->SetEvent(iev, ev);
}

bool UMarkerArray::AreEventsSorted(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AreEventsSorted(). Object NULL or erroneous.\n");
        return false;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AreEventsSorted(). Markers not set. \n");
        return false;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AreEventsSorted(). Argument out of range (iMarker=%d). \n", iMarker);
        return false;
    }
    return pMarkers[iMarker]->AreEventsSortedIncr();
}
bool UMarkerArray::AreEventsSorted() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AreEventsSorted(). Object NULL or erroneous.\n");
        return false;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AreEventsSorted(). Markers not set. \n");
        return false;
    }
    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]       ==NULL ) return false;
        if(AreEventsSorted(im)==false) return false;
    }
    return true;
}

ErrorType UMarkerArray::SortEvents(int iMarker)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SortEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SortEvents(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SortEvents(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->SortEvents();
}

ErrorType UMarkerArray::SortEvents(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SortEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SortEvents(). Markers not set. \n");
        return U_ERROR;
    }
    ErrorType E=U_OK;
    for(int im=0; im<nMarkers; im++)
        if(E==U_OK) pMarkers[im]->SortEvents();

    return E;
}
ErrorType UMarkerArray::ReplaceMarkers(const UMarkerArray* Mar, bool Prepend)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReplaceMarkers(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReplaceMarkers(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReplaceMarkers(). Erroneous or NULL argument. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL || nMarkers<=0)
    {
        DeleteAllMembers(U_OK);
        *this = *Mar;
        return error;
    }
    if(nSampTrial != Mar->nSampTrial ||
       fabs(SRate - Mar->SRate)>0.1  ||
       PreStimPts != Mar->PreStimPts)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReplaceMarkers(). Due to different timing parameters, UMarkerArrays cannot be merged. \n");
        return U_ERROR;
    }
    if(SRate != Mar->SRate)
        CI.AddToLog("WARNING: UMarkerArray::ReplaceMarkers(). Sample frequencies of copied marker different. \n");

    ErrorType E = U_OK;
    for(int im=0; im<Mar->GetnMarkers() && E==U_OK; im++)
    {
        int iReplace = -1;
        for(int m=0; m<nMarkers; m++)
            if(IsNameEquivalent(m, Mar->GetMarkerName(im))==true) {iReplace = m; break;}
        
        if(iReplace>=0) E = SetMarker(*Mar->GetMarker(im), iReplace, true);
        else            E = AddMarker( Mar->GetMarker(im), Prepend);
    }
    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReplaceMarkers(). Adding one of the markers. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMarkerArray::MergeMarkerArray(const UMarkerArray* Mar, bool Prepend)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::MergeMarkerArray(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::MergeMarkerArray(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Mar==NULL || Mar->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::MergeMarkerArray(). Erroneous or NULL argument. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL || nMarkers<=0)
    {
        DeleteAllMembers(U_OK);
        *this = *Mar;
        return error;
    }
    if(nSampTrial != Mar->nSampTrial ||
       fabs(SRate - Mar->SRate)>0.1  ||
       PreStimPts != Mar->PreStimPts)
    {
        CI.AddToLog("ERROR: UMarkerArray::MergeMarkerArray(). Due to different timing parameters, UMarkerArrays cannot be merged. \n");
        return U_ERROR;
    }
    if(SRate != Mar->SRate)
        CI.AddToLog("WARNING: UMarkerArray::MergeMarkerArray(). Sample frequencies of copied marker different. \n");

    ErrorType E = U_OK;
    for(int im=0; im<Mar->GetnMarkers() && E==U_OK; im++)  E = AddMarker(Mar->GetMarker(im), Prepend);

    if(E!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::MergeMarkerArray(). Adding one of the markers. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMarkerArray::CopyMarker(int iMarker, const char* CopyName)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyMarker(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyMarker(). Markers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyMarker(). Argument out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    if(CopyName==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyMarker(). Invalid NULL pointer for new marker name. \n");
        return U_ERROR;
    }

    UMarker M(*pMarkers[iMarker]);
    M.SetName(CopyName);

    return  AddMarker(&M);
}

ErrorType UMarkerArray::SetMarker(const UMarker& Mark, int im, bool KeepAppearence)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetMarker(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Mark==NULL) 
    {
        CI.AddToLog("ERROR: UMarkerArray::SetMarker(). NULL pointer. \n");
        return U_ERROR;
    }
    if(im<0 || im>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetMarker(). Argument out of range (im=%d). \n", im);
        return U_ERROR;
    }
    
    if(Mark.GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetMarker(). Number of samples per trial in argument (%d) is not equal to number of sampls of trial of *this (=%d)  .\n",Mark.GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }

    UMarker* pMOld = pMarkers[im];
    pMarkers[im]   = new UMarker(Mark);
    if(pMarkers[im]==NULL || pMarkers[im]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetMarker(). Copying marker (im=%d). \n", im);
        return U_ERROR;
    }
    if(KeepAppearence && pMOld) pMarkers[im]->CopyAppearence(pMOld);
    delete pMOld;
    return U_OK;
}

int UMarkerArray::GetEventIndex(int iMarker, UEvent E) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetEventIndex(). Object NULL or erroneous.\n");
        return -1;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: GetEventIndex(). Markers not set.\n");
        return -1;
    }
    if(iMarker<0 || iMarker>=nMarkers)
    {
        CI.AddToLog("ERROR: GetEventIndex(). Marker index out of range: iMarker = %d \n", iMarker);
        return -1;
    }
    if(pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: GetEventIndex(). Marker not set: iMarker = %d \n", iMarker);
        return -1;
    }
    return pMarkers[iMarker]->GetIndex(E);
}

int UMarkerArray::GetMarkerIndex(const char* Name, bool CaseSense) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarkerIndex(). Object NULL or erroneous.\n");
        return -1;
    }
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarkerIndex(). Object NULL or erroneous.\n");
        return -1;
    }
    bool IsLabel = false;
    for(int m=0; m<nMarkers; m++)
    {
        IsLabel = IsNameEquivalent(m, Name, CaseSense);
        if(IsLabel==true) return m;
    }
    return -1;
}


ErrorType UMarkerArray::EqualizeEvents(const char* Name, int IndexBegin, int IndexEnd) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). pMarkers not set. \n");
        return U_ERROR;
    }
    int im = GetMarkerIndex(Name);
    if(im<0)
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). Name not present: %s .\n", Name);
        return U_ERROR;
    }
    if(pMarkers[im]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). pMarkers[%d] not set. \n",im);
        return U_ERROR;
    }
    if(IndexBegin<0 || IndexBegin>=pMarkers[im]->GetnSamples())
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). Begin index out of range: IndexBegin = %d .\n", IndexBegin);
        return U_ERROR;
    }
    if(IndexEnd<0) IndexEnd = IndexBegin>=pMarkers[im]->GetnSamples()-1;
    if(IndexEnd>=pMarkers[im]->GetnSamples())
    {
        CI.AddToLog("ERROR: UMarkerArray::EqualizeEvents(). End index out of range: IndexEnd = %d .\n", IndexEnd);
        return U_ERROR;
    }


    UEvent        BegFirstVol    = pMarkers[im]->GetEvent(IndexBegin);
    UEvent        BegLastVol     = pMarkers[im]->GetEvent(IndexEnd);
   
    int           SampleFirstVol = BegFirstVol.GetAbsSample(nSampTrial);
    int           SampleLastVol  = BegLastVol.GetAbsSample(nSampTrial);

    int           NumEv          = pMarkers[im]->GetnSamples();

    double interval = (SampleLastVol - SampleFirstVol)/(NumEv - 1.);
 
    for(int k=1; k<NumEv - 1; k++)
    {
        int absampk = int( SampleFirstVol + k*interval + .5 );
        UEvent E(absampk/nSampTrial, absampk%nSampTrial);
        pMarkers[im]->SetEvent(k, E);
    }   
    return U_OK;
}

ErrorType UMarkerArray::LogProperties(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::LogProperties(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL) return U_ERROR;

    for(int im=0; im<nMarkers; im++)
        pMarkers[im]->LogProperties();
    
    return U_OK;
}

const UString& UMarkerArray::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMarkerArray-object\n");
        return Properties;
    }
    Properties =  UString();

    Properties += UString(nMarkers                ,"Nmarkers            = %d \n"); 
    Properties += UString(nSampTrial              ,"nSampTrial          = %d \n"); 
    Properties += UString(PreStimPts              ,"NPreStimPoints      = %d \n"); 
    Properties += UString(SRate                   ,"SampleRate          = %f \n"); 
    Properties += UString(BoolAsText(RemGhostMark),"GohstEventsRemoved  = %s \n"); 
    if(RemGhostMark)
        Properties += UString(NGostRemoved            ,"NGohstRemoved       = %d \n"); 

    for(int im=0; im<nMarkers; im++)
    {
        UString PropMarker = pMarkers[im]->GetProperties(Comment);
        if(Comment.IsNULL() || Comment.IsEmpty()) PropMarker.ReplaceAll('\n', ';');  
        else                                      PropMarker.InsertAtEachLine(UString("  "));

        Properties += UString("\n");
        Properties += PropMarker;
    }
    if(Comment.IsNULL() || Comment.IsEmpty())  Properties.ReplaceAll('\n', ';');  
    else                                       Properties.InsertAtEachLine(Comment);
    return Properties;
}

ErrorType  UMarkerArray::WriteMarkersCTF(const char *MarkerFileName) const
/*
    Write the Markers in the UMarker[]-array in the markerfile called MarkerFileName[].

    Note: 
    The Markers written are corrected for the number of pre-trigger points. They
    refer to time relative to the pre-trigger time.. 
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::WriteMarkersCTF(). Object NULL or erroneous.\n");
        return U_ERROR;
    }

    FILE* fpwrite = NULL;
    if(MarkerFileName) fpwrite = fopen(MarkerFileName,"wb"); // "wb" write binary
    if(fpwrite==NULL)
    {
        CI.AddToLog("ERROR UCTFDataMarker::WriteMarkersCTF() : Cannot open %s. \n",MarkerFileName);
        return U_ERROR;
    }

    fprintf(fpwrite,"PATH OF DATASET:\n");
    fprintf(fpwrite,"/test.ds");   // Might better be altered?
    fprintf(fpwrite,"\n\n\nNUMBER OF MARKERS:\n");
    fprintf(fpwrite,"%d\n\n\n",nMarkers);
    for(int i=0;i< nMarkers;i++)
    {
        fprintf(fpwrite,"CLASSGROUPID:\n");
        if(i==0) fprintf(fpwrite,"3\n"); 
        else     fprintf(fpwrite,"+3\n"); 
        fprintf(fpwrite,"NAME:\n");
        fprintf(fpwrite,"%s\n",pMarkers[i]->GetMarkerName());
        fprintf(fpwrite,"COMMENT:\n");
        fprintf(fpwrite,"%s\n",pMarkers[i]->GetComment());  
        fprintf(fpwrite,"COLOR:\n");
        fprintf(fpwrite,"%x\n",pMarkers[i]->GetColorAsInt());
        fprintf(fpwrite,"EDITABLE:\n");
        fprintf(fpwrite,"Yes\n");  
        
        fprintf(fpwrite,"CLASSID:\n");
        fprintf(fpwrite,"+%d\n",i+1);
        fprintf(fpwrite,"NUMBER OF SAMPLES:\n");
        fprintf(fpwrite,"%d\n",pMarkers[i]->GetnSamples());
        fprintf(fpwrite,"LIST OF SAMPLES:\n");
        fprintf(fpwrite,"TRIAL NUMBER		TIME FROM SYNC POINT (in seconds)\n");
        for(int j=0;j<pMarkers[i]->GetnSamples();j++)
        {
            int    itrial =  pMarkers[i]->GetTrial(j);
            double tsamp  = (pMarkers[i]->GetSamp(j) - PreStimPts)/SRate;
            if(tsamp >= 0.) fprintf(fpwrite,"+%d				+%.6f\n", itrial, tsamp);
            if(tsamp < 0.)  fprintf(fpwrite,"+%d				%.6f\n", itrial, tsamp);
        }
        fprintf(fpwrite,"\n\n");
    }
    fclose(fpwrite);
    return U_OK;
}
ErrorType  UMarkerArray::WriteMarkersTXT(const char *MarkerFileName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::WriteMarkersTXT(). Object NULL or erroneous.\n");
        return U_ERROR;
    }

    FILE* fpwrite = NULL;
    if(MarkerFileName) fpwrite = fopen(MarkerFileName,"wt");
    if(fpwrite==NULL)
    {
        CI.AddToLog("ERROR UCTFDataMarker::WriteMarkersTXT() : Cannot open %s. \n",MarkerFileName);
        return U_ERROR;
    }

    fprintf(fpwrite,"%s\n", MARKERTEXTID);
    fprintf(fpwrite,"%s", CI.GetProperties("// "));
    fprintf(fpwrite,"NMarkers    = %d  // Number of markers \n", nMarkers);
    fprintf(fpwrite,"NSampTrial  = %d  // Number of samples per trial in associated data file\n", nSampTrial);
    fprintf(fpwrite,"NPreStimPts = %d  // Number of samples before trigger. This is used to set zero point for time axis \n", PreStimPts);
    fprintf(fpwrite,"SampleRate  = %f  // [Hz] \n", SRate);

    if(nMarkers>0 && pMarkers==NULL)
    {
        fclose(fpwrite);
        CI.AddToLog("ERROR UCTFDataMarker::WriteMarkersTXT() : Marker array not properly set. \n");
        return U_ERROR;
    }

    for(int i=0;i< nMarkers;i++)
    {
        fprintf(fpwrite,"\n\n");
        if(pMarkers[i]==NULL || pMarkers[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR UCTFDataMarker::WriteMarkersTXT() : Marker %d not properly set. \n", i);
            continue;
        }
        UString Comment(pMarkers[i]->GetComment());
        Comment.InsertAtEachLine("// ");
        fprintf(fpwrite, "%s\n", (const char*)Comment);
        fprintf(fpwrite,"Name           = %s \n", pMarkers[i]->GetMarkerName());
        fprintf(fpwrite,"Visible        = %s \n", BoolAsText(pMarkers[i]->GetShowMarker()));
        fprintf(fpwrite,"Color          = %d \n", pMarkers[i]->GetColorAsInt());
        fprintf(fpwrite,"Thickness      = %d \n", pMarkers[i]->GetThickness());
        fprintf(fpwrite,"Nsamp          = %d \n", pMarkers[i]->GetnSamples());
        fprintf(fpwrite,"Samples        = {    // Absolute sample numbers        \n");

        int Nsamp = pMarkers[i]->GetnSamples();
        for(int j=0;j<Nsamp;j++)
        {
             fprintf(fpwrite, "%d ", pMarkers[i]->GetAbsSample(j));
            if(j<Nsamp-1 && ((j+1)%20) ) fprintf(fpwrite, "\t");
            else                         fprintf(fpwrite, "\n");
        }
        fprintf(fpwrite,"} \n");
    }
    fclose(fpwrite);
    return U_OK;
}

int UMarkerArray::GetnTotalSamples(const char* MarkerName) const
/*
    Get the total number of samples who's name is equivalent to MarkerName[].
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetnTotalSamples(). Object NULL or erroneous.\n");
        return 0;
    }
    int nTotalSamp = 0;
    for(int n=0; n<nMarkers; n++) 
        if(IsNameEquivalent(n, MarkerName)==true) 
        {
            if(pMarkers==NULL || pMarkers[n]==NULL) return 0;
            nTotalSamp += pMarkers[n]->GetnSamples();
        }
    return nTotalSamp;
}

const char* UMarkerArray::GetMarkerName(int im) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarkerName(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(im<0 || im>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarkerName(). Argument out of range: %d.\n",im);
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarkerName(). pMarkers==NULL.\n");
        return NULL;
    }
    return pMarkers[im]->GetMarkerName();
}

const UMarker* UMarkerArray::GetMarker(int im) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarker(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(im<0 || im>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarker(). Argument out of range: %d.\n",im);
        return NULL;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarker(). pMarkers==NULL.\n");
        return NULL;
    }
    return pMarkers[im];
}

const UMarker* UMarkerArray::GetMarker(const char* MarkerName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetMarker(). Object NULL or erroneous.\n");
        return NULL;
    }

    for(int m=0; m<nMarkers; m++)
        if(IsNameEquivalent(m, MarkerName)==true) return  pMarkers[m];

    CI.AddToLog("ERROR: UMarkerArray::GetMarker(). No marker found of the name %s. \n",MarkerName);
    return NULL;
}

const UMarker* UMarkerArray::GetBeginMarker(const char* MarkerName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetBeginMarker(). Object NULL or erroneous.\n");
        return NULL;
    }

    for(int m=0; m<nMarkers; m++)
        if(IsBeginMarker(m, MarkerName)==true) return  pMarkers[m];

    CI.AddToLog("ERROR: UMarkerArray::GetBeginMarker(). No Begin marker found of the name %s. \n",MarkerName);
    return NULL;
}

const UMarker* UMarkerArray::GetEndMarker(const char* MarkerName) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetEndMarker(). Object NULL or erroneous.\n");
        return NULL;
    }
    for(int m=0; m<nMarkers; m++)
        if(IsEndMarker(m, MarkerName)==true) return  pMarkers[m];

    CI.AddToLog("ERROR: UMarkerArray::GetEndMarker(). No End marker found of the name %s. \n",MarkerName);
    return NULL;
}

ErrorType UMarkerArray::MakeNamesUnique(bool Test)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::MakeNamesUnique(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(pMarkers==NULL && nMarkers==0) return U_OK;
    else if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::MakeNamesUnique(). Object not properly set. \n");
        return U_ERROR;
    }

    bool NamesChanged = false;
    for(int im1=0; im1<nMarkers; im1++)
    {
        const char* Name1 = pMarkers[im1]->GetMarkerName();
        if(Name1==NULL)
        {
            CI.AddToLog("ERROR: UMarkerArray::MakeNamesUnique(). NULL name for marker %d    . \n", im1);
            return U_ERROR;
        }
        for(int im2=im1+1; im2<nMarkers; im2++)
        {
            const char* Name2 = pMarkers[im2]->GetMarkerName();
            if(Name2==NULL)
            {
                CI.AddToLog("ERROR: UMarkerArray::MakeNamesUnique(). NULL name for marker %d    . \n", im2);
                return U_ERROR;
            }
            if(Name1==Name2)
            {
                UString NewName = Name2;
                if(NewName.IncreaseEndingNumber()!=U_OK) NewName+=UString("_1");
                pMarkers[im2]->SetName(NewName);
                NamesChanged = true;
            }
        }
    }
    if(NamesChanged==true)
    {
        if(Test==false) 
            return MakeNamesUnique(true);
        else
        {
            CI.AddToLog("ERROR: UMarkerArray::MakeNamesUnique(). Did not manage to to make unique names in two rounds. \n");
            return U_ERROR;
        }
    }
    return U_OK;
}

ErrorType UMarkerArray::SetName(int iMarker, const char* Name)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetName(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetName(). Argument out of range: iMarker = %d .\n", iMarker);
        return U_ERROR;
    }
    if(Name==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetName(). Invalid NULL Name argument. \n");
        return U_ERROR;
    }
    if(pMarkers[iMarker]->SetName(Name)!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetName(). Renaming marker (Name=%s). \n", Name);
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMarkerArray::PrependName(int iMarker, const char* Prep)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::PrependName(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(iMarker>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::PrependName(). Argument out of range: iMarker = %d .\n", iMarker);
        return U_ERROR;
    }
    if(Prep==NULL || Prep[0]==0) return U_OK;

    if(iMarker>=0)
    {
        if(pMarkers[iMarker]->PrependName(Prep)!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::PrependName(). Prepending string to marker marker name (prep=%s). \n", Prep);
            return U_ERROR;
        }
    }
    else
    {
        for(int im=0; im<nMarkers; im++)
            if(pMarkers[im]->PrependName(Prep)!=U_OK)
            {
                CI.AddToLog("ERROR: UMarkerArray::PrependName(). Prepending string to marker marker %d. \n", im);
                return U_ERROR;
            }
    }
    return U_OK;
}

ErrorType UMarkerArray::RemoveMarker(int iMarker)
{
    if(this==NULL || error!=U_OK || pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RemoveMarker(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers)
    {
        CI.AddToLog("ERROR: UMarkerArray::RemoveMarker(). Argument out of range: iMarker = %d .\n", iMarker);
        return U_ERROR;
    }
    
    delete pMarkers[iMarker];
    for(int im=iMarker; im<nMarkers-1; im++)
        pMarkers[im] = pMarkers[im+1];

    nMarkers--;
    return U_OK;
}

ErrorType UMarkerArray::RemoveEmptyMarkers(void)
{
    if(this==NULL || error!=U_OK || pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RemoveEmptyMarkers(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL || pMarkers[im]->GetnEvents()<=0)
        {
            RemoveMarker(im);
            im--;
        }
    }
    return U_OK;
}

int UMarkerArray::RemoveDoubleMarkers(void)
{
    if(this==NULL || error!=U_OK || pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RemoveDoubleMarkers(). Object NULL, erroneous or not properly set. \n");
        return 0;
    }
    int NRem = 0;
    for(int im1=0; im1<nMarkers; im1++)
    {
        UMarker M1(*(pMarkers[im1]));
        if(M1.GetError()!=U_OK || M1.GetName()==NULL)
        {
            RemoveMarker(im1);
            NRem++;
            im1--;
            continue;
        }

        for(int im2=im1+1; im2<nMarkers; im2++)
        {
            UMarker M2(*(pMarkers[im2]));
            if(M2.GetError()!=U_OK || M1==M2)
            {
                RemoveMarker(im2);
                NRem++;
                im2--;
            }
        }
    }
    return NRem;
}
int UMarkerArray::RemoveDoubleNames(void)
{
    if(this==NULL || error!=U_OK || pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RemoveDoubleNames(). Object NULL, erroneous or not properly set. \n");
        return 0;
    }
    int NRem = 0;
    for(int im1=0; im1<nMarkers; im1++)
    {
        const char* Name1 = GetMarkerName(im1);
        if(Name1==NULL)
        {
            RemoveMarker(im1);
            NRem++;
            im1--;
            continue;
        }
        for(int im2=im1+1; im2<nMarkers; im2++)
        {
            const char* Name2 = GetMarkerName(im2);
            if(Name2==NULL) continue;
            if(strcmp(Name1, Name2)) continue;

            RemoveMarker(im1);
            NRem++;
            im1--;
            break;
        }
    }
    return NRem;
}

ErrorType UMarkerArray::AddMarker(const UMarker *Marker, bool Prepend)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddMarker(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    return AddNewMarkers(1, Marker, Prepend);
}

ErrorType UMarkerArray::AddNewMarkers(int Nnew, const UMarker *NewMarkers, bool Prepend)
/*
    Replace the array of UMarkers (pMarkers[]) by a new new array, which
    is a merged version of the old array and Nnew new markers Newmarkers[].
    If(Newmarkers != NULL) copy the new markers into the new list,
    else simply add Nnew empty markers to markers[].
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). this==NULL or erroneous. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL && nMarkers>0)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Markers erroneously set. \n");
        return U_ERROR;
    }
    if(Nnew==0) return U_OK;
    if(Nnew<0 || NewMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Invalid argument(s): Nnew = %d .\n", Nnew);
        return U_ERROR;
    }
    
    int nSTR = NewMarkers[0].GetnSampTrial();
    for(int n=1; n<Nnew; n++)
    {
        if(NewMarkers[n].GetnSampTrial()!=nSTR)
        {
            CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Number of samples per trial in argument is not constant over markers .\n");
            return U_ERROR;
        }
    }
    if(nSTR!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Number of samples per trial in argument (%d) is not equal to number of sampls of trial of *this (=%d)  .\n", nSTR, nSampTrial);
        return U_ERROR;
    }
        
    UMarker** Temp = new UMarker*[nMarkers+Nnew];
    if(Temp==NULL) 
    {
        CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Memory allocation. Nnew=%d\n",Nnew);
        return U_ERROR;
    }

/* Copy old markers to new array.*/
    if(Prepend) for(int im=0; im<nMarkers; im++) Temp[Nnew+im] = pMarkers[im];
    else        for(int im=0; im<nMarkers; im++) Temp[     im] = pMarkers[im];

/* Copy new markers to new array.*/
    if(Prepend)
    {
        for(int im=0; im<Nnew; im++)
        {
            Temp[im] = new UMarker(NewMarkers[im]);
            if(Temp[im]==NULL || Temp[im]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Copying marker %d \n",im);
                delete[] Temp;
                return U_ERROR;
            }
        }
    }
    else
    {
        for(int im=0; im<Nnew; im++)
        {
            Temp[nMarkers+im] = new UMarker(NewMarkers[im]);
            if(Temp[nMarkers+im]==NULL || Temp[nMarkers+im]->GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UMarkerArray::AddNewMarkers(). Copying marker %d \n",im);
                delete[] Temp;
                return U_ERROR;
            }
        }
    }

/* Replace old pointers and number of markers*/
    delete[] pMarkers;   pMarkers  = Temp;
    nMarkers += Nnew;
    
    return U_OK;
}

bool UMarkerArray::IsNameEquivalent(int iMarker, const char* Name, bool CaseSense) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::IsNameEquivalent(). Object NULL, erroneous or not properly set. \n");
        return false;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers==NULL) return false;

    const char* MarkerName = pMarkers[iMarker]->GetMarkerName();
    if(DoesStringContainWildCard(Name))
        return ::IsStringCompatible(MarkerName, Name, CaseSense);

    if(Name==NULL || Name[0]==0) return true;


    UString pNam(pMarkers[iMarker]->GetMarkerName()); pNam.ToUpper();
    UString  Nam(Name);                                Nam.ToUpper();
    if(NOT(CaseSense))
    {
        pNam.ToUpper();
        Nam.ToUpper();
    }
    return (pNam==Nam);
}

bool UMarkerArray::IsBeginMarker(int iMarker, const char* Name) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::IsBeginMarker(). Object NULL, erroneous or not properly set. \n");
        return false;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers==NULL) return false;

    if(strnicmp("BEGIN",pMarkers[iMarker]->GetMarkerName(),5)) return false;

    if(Name==NULL||Name[0]==0) return true;

    if(stricmp(pMarkers[iMarker]->GetMarkerName()+5,Name)) return false;

    return true;
}

bool UMarkerArray::IsEndMarker(int iMarker, const char* Name) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::IsEndMarker(). Object NULL, erroneous or not properly set. \n");
        return false;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers==NULL) return false;

    if(strnicmp("END" ,pMarkers[iMarker]->GetMarkerName(),3) && 
       strnicmp("EIND",pMarkers[iMarker]->GetMarkerName(),4)) return false;

    if(Name==NULL||Name[0]==0) return true;

    int nb = 0;
    if(!strnicmp("END" ,pMarkers[iMarker]->GetMarkerName(),3)) nb =3;
    if(!strnicmp("EIND",pMarkers[iMarker]->GetMarkerName(),4)) nb =4;

    if(stricmp(pMarkers[iMarker]->GetMarkerName()+nb,Name)) return false;
    return true;
}

ErrorType UMarkerArray::ReadMarkersEVL(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersEVL(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(NsampTrial<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersEVL(). Invalid argument(s): NsampTrial=%d , srate=%f \n", NsampTrial, srate);
        return U_ERROR;
    }
    
    DeleteAllMembers(U_OK);
    nSampTrial   = NsampTrial;
    PreStimPts   = preStimPnts;
    SRate        = srate;
    
    FILE* fpMark = NULL;
    if(MarkerFileName)  fpMark = fopen(MarkerFileName,"rb");
    if(fpMark==NULL)
    {
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersEVL(): cannot open %s \n",MarkerFileName);
        return U_ERROR;
    }  

    UMarker M1("EventBegin", 0, nSampTrial, (1<<8)-1, "Evl-event onset", 0, true);
    UMarker M2("EventEnd", 0, nSampTrial, (1<<16)-1, "Evl-event stop", 0, true);

    char line[400];
    while(GetLine(line,sizeof(line),fpMark))
    {
        UAnalyzeLine AA(line);  
        if(AA.IsEmptyLine()  ==true) continue;
        if(AA.IsCommentLine()==true) continue;
        if(AA.IsIdentifierInLine("((:time", true)==true) 
        {
            double Time = AA.GetNextDouble(-1.);
            if(Time>0)
            {
                M1.AddEvent(int(floor(0.5+Time*srate)));
                if(AA.IsIdentifierInLine("(:length", true)==true) 
                {
                    double DeltaTime = AA.GetNextDouble(-1.);
                    if(DeltaTime>0)
                    {
                        M2.AddEvent(int(floor(0.5+(Time+DeltaTime)*srate)));
                    }
                }
            }
        }
    }
    if(AddMarker(&M1)==U_OK && AddMarker(&M2)==U_OK) return U_OK;
    return U_ERROR;
}

static int SortTrig(const void *elem1, const void *elem2)
{    
    const ANTtexttrig* T1 = (ANTtexttrig*)elem1;
    const ANTtexttrig* T2 = (ANTtexttrig*)elem2;

    if(T1==NULL || T2==NULL) return 1;
    int test = stricmp(T1->code, T2->code);
    if(test) return test;
    if(T1->sample < T2->sample) return -1;
    if(T1->sample > T2->sample) return  1;
    return 0;
}
ErrorType UMarkerArray::ReadMarkersTRG(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersTRG(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(NsampTrial<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersTRG(). Invalid argument(s): NsampTrial=%d , srate=%f \n", NsampTrial, srate);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);
    nSampTrial   = NsampTrial;
    PreStimPts   = preStimPnts;
    SRate        = srate;

    FILE* fpMark = NULL;
    if(MarkerFileName)  fpMark = fopen(MarkerFileName,"rt");
    if(fpMark==NULL)
    {
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTRG(): cannot open %s \n",MarkerFileName);
        return U_ERROR;
    }  
    int NevMax = GetNLines(fpMark);
    if(NevMax<=0)
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTRG(): No triggers (Nev =%d) \n",NevMax);
        return U_ERROR;
    }
    ANTtexttrig* trg = new ANTtexttrig[NevMax];
    if(trg==NULL)
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTRG(): Memory allocation, (Nev =%d) \n",NevMax);
        return U_ERROR;
    }
    int  Nev = 0;
    char line[200];
    for(int j=0; j<NevMax; j++)
    {
        if(!GetLine(line, sizeof(line), fpMark)) break;
        UAnalyzeLine AA(line);
        if(AA.GetNCollumn()!=3) continue;
        double tt = AA.GetNextDouble(-1.);
        int    ss = AA.GetNextInt(-1);
        const char* Label = AA.GetNextString(sizeof(trg[0].code), NULL);
        if(tt<0. || Label==NULL) continue;

        trg[Nev].sample = tt;
        memset(trg[Nev].code, 0, sizeof(trg[0].code));
        strncpy(trg[Nev].code, Label, sizeof(trg[0].code)-1);
        Nev++;
    }
    fclose(fpMark);

    qsort(trg, Nev, sizeof(ANTtexttrig), SortTrig);

    const char* Name = trg[0].code;
    UMarker M(Name, 0, nSampTrial, 100, "External ANT trigger", 0, true);
    for(int j=0; j<Nev; j++)
    {
        const char* NameTest = trg[j].code;
        if(stricmp(Name, NameTest)) // new marker
        {
            AddMarker(&M);
            Name = NameTest;
            M    = UMarker(Name, 0, nSampTrial, 100, "External ANT trigger", 0, true);
        }
        uint64_t samp = uint64_t(trg[j].sample*SRate + 0.5);
        M.AddEvent(UEvent(int(samp/nSampTrial), int(samp%nSampTrial)));
    }
    AddMarker(&M);
    delete[] trg;
    return U_OK;
}

ErrorType  UMarkerArray::ReadMarkersCTF(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate, bool RemoveGhostMarkers) 
/*
    Read the markerfile MarkerFileName[] corresponding to the res4 and meg4-files
    and store these Markers in a UMarker[]-array.

    Note: 
    The Markers stored are corrected for the number of pre-trigger points. They
    refer to ABSOLUTE sample numbers. 
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersCTF(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(NsampTrial<=0 || srate<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersCTF(). Invalid argument(s): NsampTrial=%d , srate=%f \n", NsampTrial, srate);
        return U_ERROR;
    }
    
    DeleteAllMembers(U_OK);
    nSampTrial   = NsampTrial;
    PreStimPts   = preStimPnts;
    SRate        = srate;
    RemGhostMark = RemoveGhostMarkers;
    
    FILE* fpMark = NULL;
    if(MarkerFileName)  fpMark = fopen(MarkerFileName,"rb");
    if(fpMark==NULL)
    {
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersCTF(): cannot open %s \n",MarkerFileName);
        return U_ERROR;
    }  

    char line[400];
    while(GetLine(line,sizeof(line),fpMark))
    {
        UAnalyzeLine AA(line);  
        if(AA.IsEmptyLine()  ==true) continue;
        if(AA.IsCommentLine()==true) continue;
        if(AA.IsIdentifierInLine("MARKERS", true)==true) 
        {
            GetLine(line,sizeof(line),fpMark);
            UAnalyzeLine AA(line);  
            nMarkers = AA.GetNextInt(-1);
            break;
        }
    }
    if(nMarkers<=0)
    {
        fclose(fpMark);
        nMarkers = 0;
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersCTF(): No markers in file %s \n",MarkerFileName);
        return U_OK;
    }
    pMarkers = new UMarker*[nMarkers];
    if(pMarkers==NULL)
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersCTF(): Memory allocation error. nMarkers=%d \n",nMarkers);
        return U_ERROR;
    }
    for(int im=0;im<nMarkers;im++)   pMarkers[im] = NULL;

    NGostRemoved = 0;
    for(int im=0;im<nMarkers;im++)   // Fill in the marker objects
    {
/* Read marker header */

        int          markergroupid   = 0;
        char         markername[32];  
        char         markercomment[MAXMARKER_COMMENT] = "";
        unsigned int markercolor     = 0;
        bool         editable        = true;
        int          nsamp           = -1;

        memset(markername   , 0, sizeof(markername));
        memset(markercomment, 0, sizeof(markercomment));
        while(GetLine(line,sizeof(line),fpMark))
        {
            UAnalyzeLine AA(line);  
            if(AA.IsEmptyLine()  ==true) continue;
            if(AA.IsCommentLine()==true) continue;
            if(AA.IsIdentifierInLine("CLASSGROUPID", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                UAnalyzeLine AA(line);  
                markergroupid = AA.GetNextInt(-1);
                continue;
            }
            if(AA.IsIdentifierInLine("NAME", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                size_t  nb   =  -1 + MIN(sizeof(line),strlen(line));
                if(line[nb] == '\n') line[nb] = 0;
                strncpy(markername, line, sizeof(markername)-1);
                continue;
            }
            if(AA.IsIdentifierInLine("COMMENT", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                size_t  nb   =  -1 + MIN(sizeof(line),strlen(line));
                if(line[nb] == '\n') line[nb] = 0;
                strncpy(markercomment, line, sizeof(markercomment)-1);
                continue;
            }
            if(AA.IsIdentifierInLine("COLOR", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                UAnalyzeLine AA(line);  
                sscanf(AA.GetPointer(),"%x",&markercolor);
                continue;
            }
            if(AA.IsIdentifierInLine("EDITABLE", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                UAnalyzeLine AA(line);  
                char editablestring[32];
                const char* Str = AA.GetNextString(sizeof(editablestring), NULL);
                if(Str) strncpy(editablestring, Str, sizeof(editablestring)-1);
                editable = IsStringCompatible(editablestring, "Yes", false);
                continue;
            }
            if(AA.IsIdentifierInLine("SAMPLES", true)==true) 
            {
                GetLine(line,sizeof(line),fpMark);
                UAnalyzeLine AA(line);  
                nsamp = AA.GetNextInt(-1);
                break;
            }
        }
        if(nsamp<0)
        {
            fclose(fpMark);
            CI.AddToLog( "ERROR UMarkerArray::ReadMarkersCTF(): Cannot read number of samples in marker %d .\n", im);
            return U_ERROR;
        }

/* Make the Markers object */
        pMarkers[im] = new UMarker(markername, nsamp, nSampTrial, im, markercomment, markergroupid, editable);
        if(pMarkers[im]==NULL || pMarkers[im]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::ReadMarkersCTF(). Creating UMarker object number %d .\n", im);
            fclose(fpMark);
            return U_ERROR;
        }
        pMarkers[im]->SetColorAsInt(markercolor);

/* Read samples */
        int NlineTested = 0;
        while(GetLine(line,sizeof(line),fpMark))
        {
            UAnalyzeLine AA(line);  
            if(AA.IsEmptyLine()  ==true) continue;
            if(AA.IsCommentLine()==true) continue;
            if(NlineTested==0 && AA.IsIdentifierInLine("LIST OF SAMPLES", true)==true) {NlineTested++; continue;}
            if(AA.IsIdentifierInLine("TRIAL NUMBER", true)==true) NlineTested++; 
            if(NlineTested==2) break;

            fclose(fpMark);
            CI.AddToLog( "ERROR UMarkerArray::ReadMarkersCTF(): Invalid header in marker %d .\n", im);
            return U_ERROR;
        }
        if(RemGhostMark==false)
        {
            for(int j=0;j<nsamp;j++)
            {
                int    Trial;
                float  tsamp;
                fscanf(fpMark,"%d",&Trial); 
                fscanf(fpMark,"%f",&tsamp);                   

                int Sample = PreStimPts + (int)floor(.5+SRate*tsamp);
                pMarkers[im]->SetEvent(j,UEvent(Trial, Sample));
            }
        }
        else
        {
            double TimeTrial = nSampTrial/SRate;
            int    nsampSkip = 0;
            double TimeOld   = 0.;
            int    TrialOld  = -3;
            int    j         = 0;
            while(j<nsamp)
            {
                int    Trial;
                float  tsamp;
                fscanf(fpMark,"%d",&Trial); 
                fscanf(fpMark,"%f",&tsamp);                   
                
                if(tsamp==0. && j>0 && TrialOld==Trial-1 && TimeTrial-TimeOld<TimeGhost)
                {
                    nsampSkip++;
                    NGostRemoved++;
                    CI.AddToLog("Note: UMarkerArray::ReadMarkersCTF(). Skipping Ghost Marker %s ", markername);
                    CI.AddToLog("trial = %d time = %14.9f \n",Trial, tsamp);
                }
                else
                {
                    int Sample = PreStimPts + (int)floor(.5+SRate*tsamp);
                    pMarkers[im]->SetEvent(j,UEvent(Trial, Sample));
                    j++;
                }
                TimeOld  = tsamp;
                TrialOld = Trial;
            }
            pMarkers[im]->SetnEvents(nsamp-nsampSkip);
        }
    }
    fclose(fpMark);

    return U_OK;
}
ErrorType  UMarkerArray::ReadMarkersTXT(const char *MarkerFileName) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReadMarkersTXT(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    
    DeleteAllMembers(U_OK);
    
    FILE* fpMark = NULL;
    if(MarkerFileName)  fpMark = fopen(MarkerFileName,"rt");
    if(fpMark==NULL)
    {
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(): cannot open %s \n",MarkerFileName);
        return U_ERROR;
    }
    char line[400];
    GetLine(line,sizeof(line),fpMark);
    if(strncmp(line, MARKERTEXTID, sizeof(MARKERTEXTID)-1))
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Wrong ID (%d) \n",line);
        return U_ERROR;
    }

    bool BoolNMark      = false;
    bool BoolNSampTrial = false;
    bool BoolSampleRate = false;

    while(GetLine(line,sizeof(line),fpMark))
    {
        UAnalyzeLine AA(line);  
        if(AA.IsEmptyLine()  ==true) continue;
        if(AA.IsCommentLine()==true) continue;

        if(AA.IsIdentifierIsInLine("NMarkers", true)==true) 
        {
            nMarkers  = AA.GetNextInt(-1);
            BoolNMark = true;
        }
        else if(AA.IsIdentifierIsInLine("NSampTrial", true)==true) 
        {
            nSampTrial     = AA.GetNextInt(-1);
            BoolNSampTrial = true;
        }
        else if(AA.IsIdentifierIsInLine("NPreStimPts", true)==true) 
        {
            PreStimPts     = AA.GetNextInt(-1);
        }
        else if(AA.IsIdentifierIsInLine("SampleRate", true)==true) 
        {
            SRate          = AA.GetNextDouble(0.);
            BoolSampleRate = true;
        }
        if(BoolNMark && BoolNSampTrial && BoolSampleRate) break;
    }
    if(BoolNMark==false || BoolNSampTrial==false || BoolSampleRate==false ||
       nMarkers < 0     || nSampTrial    <= 0    || SRate         <=0.)
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Essential parameters erroneous or out of range (nMarkers = %d, PreStimPts = %d, SRate = %f) \n",nMarkers, PreStimPts, SRate);
        return U_ERROR;
    }
    pMarkers = new UMarker* [nMarkers+1];
    if(pMarkers==NULL)
    {
        fclose(fpMark);
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Memory allocation (nMarkers = %d) \n",nMarkers);
        return U_ERROR;
    }
    for(int im=0; im<nMarkers; im++) pMarkers[im] = NULL;

    int NMarkOK = 0;
    for(int k=0; k<nMarkers; k++)
    {
        UMarker     M;
        const char* DefNam    =  "DefNam";
        UString     Name      =  UString(DefNam);
        bool        Visib     =  true;
        int         Color     =  255;
        int         LineThick =  2;
        int         Nsamp     = -1;
        while(GetLine(line,sizeof(line),fpMark))
        {
            UAnalyzeLine AA(line);  
            if(AA.IsEmptyLine()  ==true) continue;
            if(AA.IsCommentLine()==true) continue;

            if(AA.IsIdentifierIsInLine("Name", true)==true) 
            {
                Name   = UString(AA.GetNextString(sizeof(line), DefNam));
            }
            else if(AA.IsIdentifierIsInLine("Visible", true)==true)
            {
                Visib  = AA.GetNextBool(true);
            }
            else if(AA.IsIdentifierIsInLine("Color", true)==true)
            {
                Color  = AA.GetNextInt(255);
            }
            else if(AA.IsIdentifierIsInLine("Thickness", true)==true)
            {
                LineThick  = AA.GetNextInt(2);
                LineThick  = MIN(MAX(LineThick, 1), 9);
            }
            else if(AA.IsIdentifierIsInLine("Nsamp", true)==true)
            {
                Nsamp      = AA.GetNextInt(-1);
            }
            else if(AA.IsStartList("Samples", true)==true)
            {
                M = UMarker((const char*)Name, 0, nSampTrial, Color, NULL, -1, true);
                M.SetThickness(LineThick);
                M.SetShowMarker(Visib);
                break;
            }
        }
        if(M.GetError()!=U_OK)
        {
            fclose(fpMark);
            CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Reading marker %d .\n", k);
            return U_ERROR;
        }
        int NeventRead = 0;
        while(GetLine(line,sizeof(line),fpMark))
        {
            UAnalyzeLine AA(line);  
            if(AA.IsEmptyLine()  ==true) continue;
            if(AA.IsCommentLine()==true) continue;
            if(AA.IsEndList()==true)
            {
                if(NeventRead!=Nsamp)
                {
                    fclose(fpMark);
                    CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Reading marker %d (NevenRead = %d, Nevent=%d) .\n", k, NeventRead, Nsamp);
                    return U_ERROR;
                }
                if(SetMarker(M, NMarkOK, true) !=U_OK)
                {
                    fclose(fpMark);
                    CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Adding marker %d .\n", k);
                    return U_ERROR;
                }
                NMarkOK++;
                break;
            }
            int NCol = AA.GetNCollumn();
            for(int j=0; j<NCol; j++)
            {
                int iev = AA.GetNextInt(-1);
                UEvent E(iev/nSampTrial, iev%nSampTrial);
                M.AddEvent(E);
                NeventRead++;
            }
        }
    }
    fclose(fpMark);

    if(NMarkOK!=nMarkers)
    {
        CI.AddToLog( "ERROR UMarkerArray::ReadMarkersTXT(). Only %d  of %d markers read succesfully.\n", NMarkOK, nMarkers);
        return U_ERROR;
    }

    return U_OK;
}

ErrorType  UMarkerArray::ReadMarkersPersyst(const char *MarkerFileName)
/*
    Read markerfile created by Persyst spike detector v2000.01.27.

    Note: 
    The Markers stored are corrected for the number of pre-trigger points. They
    refer to ABSOLUTE sample numbers. 
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ReadPersystMarkers(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    char   line[256]; 
    int _npoints=0;

    FILE*   fpMark = NULL;
    if(MarkerFileName) fpMark = fopen(MarkerFileName,"rb");

    if(fpMark==NULL)
    {
        CI.AddToLog("ERROR UCTFDataMarker::ReadPersystMarkers(): cannot open %s \n",MarkerFileName);
        return U_ERROR;
    }  

/*determine the number of lines*/ 
    while(GetLine(line, sizeof(line), fpMark))
    {
        UAnalyzeLine AA(line, sizeof(line));
        if(AA.IsComment()==false) _npoints++;
    }
    _npoints-=1;

/* Read the file.*/
    double* tim = new double [_npoints];
    int*    grp = new int [_npoints];
    if(tim==NULL || grp==NULL)
    {
        delete[] tim;
        delete[] grp;
        fclose(fpMark);
        CI.AddToLog("ERROR UCTFDataMarker::ReadPersystMarkers(): Memory allocation.\n");
        return U_ERROR;
    }
    int     cnt = 0;
    
    rewind(fpMark);
    GetLine(line, sizeof(line), fpMark);// skip first comment line
    while(GetLine(line, sizeof(line), fpMark))                                    
    {                                                                          
        UAnalyzeLine AA(line, sizeof(line));                                  
        if(AA.IsComment() == false)                                           
        {                                                                     
            tim[cnt] = AA.GetNextDouble(); 
            grp[cnt] = AA.GetNextInt(); 
            if(AA.GetError()!=U_OK)                                           
            {                                                                 
                delete[] tim;
                delete[] grp;
                fclose(fpMark);
                CI.AddToLog("ERROR:UMarkerArray::ReadPersystMarkers(). Reading file: MarkerFileName %s.\n",MarkerFileName);
                return U_ERROR;
            }
            cnt++;
        }                                                                     
        memset(line, 0, sizeof(line));
    }
/* determine number of Markers */
    nMarkers=0;
    int i = 0;
    for(     ;i<_npoints;i++)
    {
        if(grp[i]>nMarkers) nMarkers=grp[i];
    }

/* determine number of samples for each marker */
    int* nSamples= new int [nMarkers];
    i = 0;
    for( ;i<nMarkers;i++)nSamples[i]=0;

    i = 0;
    for( ;i<_npoints;i++)nSamples[grp[i]-1]++;
        
// Create marker objects

    pMarkers = new UMarker*[nMarkers];
    if(!pMarkers)
    {
        delete[] tim;
        delete[] grp;
        fclose(fpMark);
        CI.AddToLog("ERROR:UMarkerArray::ReadPersystMarkers(). Memory allocation: nMarkers = %d .\n",nMarkers);
        return U_ERROR;
    }

    for(int im=0;im<nMarkers;im++)   // Fill in the marker objects
    {

/* ClassgroupID of the marker -> 1 is hardware Markers, 3 is software Markers*/
        int markergroupid=3;
                
/* Markername */
        char markername[32];
        sprintf(markername,"spike cluster %i",im+1);

/* Define Commentstring and set to 0 */
        char markercomment[MAXMARKER_COMMENT];
        markercomment[0] = 0;

/* Reading of the Marker color is not yet supported */
/* The color is set to the im-counter value */

/* Are the Markers editable */
        bool editable = true;

/* Number of samples */
        int nsamp=nSamples[im];

/* Make the Markers object */
        pMarkers[im] = new UMarker(markername, nsamp, nSampTrial, im, markercomment, markergroupid, editable);
        if(pMarkers[im]==NULL || pMarkers[im]->GetError() == U_ERROR)
        {
            fclose(fpMark);
            CI.AddToLog("ERROR:UMarkerArray::ReadPersystMarkers(). Creating marker %s.\n",markername);
            return U_ERROR;
        }

/* Find trial and sample numbers*/
        cnt = 0;
        for(int j=0;j<_npoints;j++)
        {
            if(grp[j]-1==im)
            {
                int SampAbs = (int) floor(.5+tim[j]*SRate);
                int Trial   = SampAbs/nSampTrial;
                int Samp    = SampAbs%nSampTrial;
                pMarkers[im]->SetEvent(cnt, UEvent(Trial, Samp));
                cnt++;
            }
        }
    }    
    delete[] tim;
    delete[] grp;
    fclose(fpMark);

    return U_OK;
}

ErrorType UMarkerArray::ResampleData(int NewNSampTrial)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::ResampleData(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::ResampleData(). pMarkers not set. \n");
        return U_ERROR;
    }
    if(NewNSampTrial==nSampTrial) return U_OK;

    if(NewNSampTrial<=0 || nSampTrial<=0)
    {
        CI.AddToLog("ERROR: UEventArray::ResampleData(). Invalid argument (NewNSampTrial=%d, nSampTrial=%d).\n", NewNSampTrial, nSampTrial);
        return U_ERROR;
    }

    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL) continue;
        pMarkers[im]->ResampleData(NewNSampTrial);
    }
    PreStimPts   *= (int)(NewNSampTrial/double(nSampTrial));
    SRate        *=      (NewNSampTrial/double(nSampTrial));    
    nSampTrial    =       NewNSampTrial;   
    return U_OK;
}

ErrorType UMarkerArray::RedistributeTrials(int SkipSamples, int NewSamplesTrial)
/*
    Redistribute all the markers by redistributing the trials over the raw data set.
    This is done by skipping the first SkipSamples in the file, and then making trials
    of NewSamplesTrial samples each.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(NewSamplesTrial<=0)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). NewSamplesTrial (=%d) out pf range. \n", NewSamplesTrial);
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers not set. \n");
        return U_ERROR;
    }

    ErrorType E = U_OK;
    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers[%d] not set. \n",im);
            return U_ERROR;
        }
        if(E==U_OK)
            E = pMarkers[im]->RedistributeTrials(SkipSamples, NewSamplesTrial);
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Redistributing events of marker %s  .\n", pMarkers[im]->GetMarkerName());
            return U_ERROR;
        }
    }
    nSampTrial = NewSamplesTrial;

    return U_OK;
}

ErrorType UMarkerArray::RedistributeTrials(const UEpochs* NewEpochs)
/*
    Redistribute all the events of all UMarkers by redistributing the trials over the 
    raw data set. This is done by determining in wich epoch(s) of NewEpochs each
    event is residing, and setting the trial number equal to that (those) epochs. The
    new sample number will be set equal to the sample of the fitting epoch.
    If an event fits in multiple epochs, that event is copied, with different
    sample and trial numbers.

    Remove events with that are outside all of the epochs in NewEpochs.
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers not set. \n");
        return U_ERROR;
    }

    if(NewEpochs==NULL || NewEpochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(NewEpochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Epoch times are not equal. \n");
        return U_ERROR;
    }
    if(NewEpochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", NewEpochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }

    ErrorType E = U_OK;
    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers[%d] not set. \n",im);
            return U_ERROR;
        }
        if(E==U_OK)
            E = pMarkers[im]->RedistributeTrials(NewEpochs);
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Redistributing events of marker %s  .\n", pMarkers[im]->GetMarkerName());
            return U_ERROR;
        }
    }
    nSampTrial = NewEpochs->GetNsamp(0);
    return U_OK;
}
ErrorType UMarkerArray::RedistributeTrials(const UEpochs* NewEpochs, double NewSampFreq)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers not set. \n");
        return U_ERROR;
    }
    if(SRate<=0)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Invalid sample frequency (SRate=%f). \n", SRate);
        return U_ERROR;
    }
    if(NewSampFreq==SRate || NewSampFreq==0.)    return RedistributeTrials(NewEpochs);

    if(NewEpochs==NULL || NewEpochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(NewEpochs->AreEpochTimesEqual()!=true)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Epoch times are not equal. \n");
        return U_ERROR;
    }
    if(NewEpochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", NewEpochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(NewSampFreq<=0.)
    {
        CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). NewSampFreq (=%f) out of range. \n", NewSampFreq);
        return U_ERROR;
    }

    ErrorType E = U_OK;
    for(int im=0; im<nMarkers; im++)
    {
        if(pMarkers[im]==NULL)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). pMarkers[%d] not set. \n",im);
            return U_ERROR;
        }
        if(E==U_OK)
            E = pMarkers[im]->RedistributeTrials(NewEpochs, SRate, NewSampFreq);
        if(E!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::RedistributeTrials(). Redistributing events of marker %s  .\n", pMarkers[im]->GetMarkerName());
            return U_ERROR;
        }
    }
    nSampTrial = int( NewEpochs->GetNsamp(0) * (NewSampFreq/SRate) );
    SRate      = NewSampFreq;
    return U_OK;
}

ErrorType UMarkerArray::CopyToAllEpochs(int iMarker, int iev, const UEpochs* Epochs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). pMarkers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers  || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). Marker index out of range: iMarker = %d. \n", iMarker);
        return U_ERROR;
    }
    if(iev<0 || iev>=pMarkers[iMarker]->GetnEvents())
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). Event index out of range: iev = %d. \n", iev);
        return U_ERROR;
    }

    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(Epochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyToAllEpochs(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", Epochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    return pMarkers[iMarker]->CopyToAllEpochs(iev, Epochs);
}

ErrorType UMarkerArray::CopyAllEventsToAllEpochs(int iMarker, int iep, const UEpochs* Epochs)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(pMarkers==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). pMarkers not set. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). Marker index out of range: iMarker = %d. \n", iMarker);
        return U_ERROR;
    }
    if(Epochs==NULL || Epochs->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). NULL or erroneous UEpochs() argument. \n");
        return U_ERROR;
    }
    if(Epochs->GetnSampTrial()!=nSampTrial)
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). Nsamples per trial of epochs (%d) not equal to Nsamples per trial of *this. \n", Epochs->GetnSampTrial(), nSampTrial);
        return U_ERROR;
    }
    if(iep<0 || iep>=Epochs->GetnEpochs())
    {
        CI.AddToLog("ERROR: UMarkerArray::CopyAllEventsToAllEpochs(). Epoch index out of range: iep = %d. \n", iep);
        return U_ERROR;
    }
    return pMarkers[iMarker]->CopyAllEventsToAllEpochs(iep, Epochs);
}


ErrorType UMarkerArray::InsertEvents(const char* MkName, int* MkOffset, int NEv) const
/*
   Inserts NEv events for marker MkName. The the new events' positions with repect to the very first
   is given, in terms of absolute samples, by the integer array MkOffset.
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(MkName==NULL || MkOffset==NULL || NEv<=0)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). Invalid input arguments.\n");
        return U_ERROR;
    }
    int im = GetMarkerIndex(MkName);
    if(im<0)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). Name not present: %s .\n", MkName);
        return U_ERROR;
    }
    if(pMarkers[im]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). pMarker[%i] not set.\n", im);
        return U_ERROR;
    }
    int errors = 0;
    for(int ev=0; ev<NEv; ev++)
    {
        if(AddEvent(MkName, MkOffset[ev])!=U_OK)
        {
            CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). Error inserting event %i.\n", ev);
            errors++;
            continue;
        }
    }
    if(errors==NEv)
    {
        CI.AddToLog("ERROR: UMarkerArray::InsertEvents(). Error inserting all events.\n");
        return U_ERROR;
    }
    CI.AddToLog("Note: UMarkerArray::InsertEvents(). %i out of %i events inserted successfully.\n", NEv-errors, NEv);
    return U_OK;
}


ErrorType UMarkerArray::AddEvent(const char* MkName, int offset) const
/*
   Inserts a new event which, in terms of absolute samples, is offset samples away from the very first
   event of MkName.
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Object NULL, erroneous or not properly set. \n");
        return U_ERROR;
    }
    if(MkName==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Marker name is NULL.\n");
        return U_ERROR;
    }
    if(offset<=0)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Non-valid offset value(%i).\n", offset);
        return U_ERROR;
    }
    int im = GetMarkerIndex(MkName);
    if(im<0)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). Name not present: %s .\n", MkName);
        return U_ERROR;
    }
    if(pMarkers[im]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). pMarker[%i] not set.\n", im);
        return U_ERROR;
    }
        
    UEvent  FirstEv     = pMarkers[im]->GetEvent(0);
    int     GetAbsSample   = FirstEv.GetAbsSample(nSampTrial) + offset;
    UEvent  NewEvent(GetAbsSample/nSampTrial, GetAbsSample%nSampTrial);

    for(int m=0; m<pMarkers[im]->GetnSamples(); m++)
    {
        UEvent Event = pMarkers[im]->GetEvent(m);
        if(NewEvent==Event)
        {
            CI.AddToLog("Warning: UMarkerArray::AddEvent(). New Event already present. Not added.\n");
            return U_OK;
        }
    }
    if(pMarkers[im]->AddEvent(NewEvent)!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). UEventArray::AddEvent() returned U_ERROR.\n");
        return U_ERROR;
    }
    if(pMarkers[im]->SortEvents()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::AddEvent(). UEventArray::AddEvent() returned U_ERROR.\n");
        return U_ERROR;
    }
    return U_OK;
}

UColor UMarkerArray::GetColor(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetColor(). Object NULL or erroneous. \n");
        return UColor(0,0,0);
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetColor(). argment out of range (iMarker=%d). \n", iMarker);
        return UColor(0,0,0);
    }
    return pMarkers[iMarker]->GetColor();
}
int UMarkerArray::GetThickness(int iMarker) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetThickness(). Object NULL or erroneous. \n");
        return 1;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetThickness(). argment out of range (iMarker=%d). \n", iMarker);
        return 1;
    }
    return pMarkers[iMarker]->GetThickness();
}
bool UMarkerArray::GetShowMarker(int iMarker)  const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetShowMarker(). Object NULL or erroneous. \n");
        return false;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::GetShowMarker(). argment out of range (iMarker=%d). \n", iMarker);
        return false;
    }
    return pMarkers[iMarker]->GetShowMarker();
}
ErrorType UMarkerArray::SetColor(int iMarker, UColor Col)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetColor(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetColor(). argment out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->SetColor(Col);
}
ErrorType UMarkerArray::SetThickness(int iMarker, int Thick)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetThickness(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetThickness(). argment out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->SetThickness(Thick);
}
ErrorType UMarkerArray::SetShowMarker(int iMarker, bool Show)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetShowMarker(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetShowMarker(). argment out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    return pMarkers[iMarker]->SetShowMarker(Show);
}
ErrorType UMarkerArray::SetAppearence(int iMarker, const UMarker* pMark)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetAppearence(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(iMarker<0 || iMarker>=nMarkers || pMarkers[iMarker]==NULL)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetAppearence(). argment out of range (iMarker=%d). \n", iMarker);
        return U_ERROR;
    }
    if(pMark==NULL || pMark->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMarkerArray::SetAppearence(). Argument NULL or erroneous. \n");
        return U_ERROR;
    }
    return pMarkers[iMarker]->CopyAppearence(pMark);
}

