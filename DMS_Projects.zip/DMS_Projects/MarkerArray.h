#ifndef _MARKERARRAY_INCLUDED
#define _MARKERARRAY_INCLUDED

#include "Marker.h"
#include "String.h"

class UMEEGDataBase;
class UMatrixSparse;

class DLL_IO UMarkerArray 
{
public:
    UMarkerArray();
    UMarkerArray(const UMarkerArray& Mar);
    UMarkerArray(const char* MarkerFile);
    UMarkerArray(const char* MarkerFile, const UMEEGDataBase* Data, bool RemoveGhostMarkers);
    UMarkerArray(const char* MarkerFile, int NsampTrial, int preStimPnts, double srate, bool RemoveGhostMarkers=false);
    UMarkerArray(int Nmarkers, int NsampTrial, int prestimPts, double srate);
    UMarkerArray(const UMarker* M, int prestimPts, double srate);
    virtual ~UMarkerArray();

    UMarkerArray&           operator=(const UMarkerArray &Mar);

    ErrorType               GetError(void)         const {if(this) return error; return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
    int                     GetnMarkers(void)      const {if(this) return nMarkers; return 0;} 
    ErrorType               LogProperties(void)    const;
    int                     GetnPreTrigPnts(void)  const {if(this) return PreStimPts; return 0;}
    int                     GetnSampTrial(void)    const {if(this) return nSampTrial; return 0;}
    double                  GetSampleRate(void)    const {if(this) return SRate;      return 0;}
    double                  GetSTime(void) const {if(this && SRate>0.) return 1./SRate; return 0.;}
    double                  GetAverageTimeInterval(int iMarker) const;
    double                  GetAverageTimeInterval(int iMarker, const UFieldGraph* FG, int Level) const;
   
    int                     GetMinInterval(int iMarker) const;
    int                     GetMaxInterval(int iMarker) const;
    UString                 GetIntervalsText(int iMarker) const;
    UFieldGraph*            GetIntervalsSinCos(int iMarker, double Shift, double DownSample, int Harm, bool Sin) const;
    UFieldGraph*            GetIntervalsSinCos(int iMarker, const UEpochs* Epo, int Harm, bool Sin, int NSegment) const;
    UFieldGraph*            GetIntervalsEpoch(int iMarker, const UEpochs* Epo, int NSegment, double DeadTimeBeg_s, double DeadTimeEnd_s, double IntervalWindow_s, bool ComputeSD) const;
    UFieldGraph*            GetTimesFirstInEpoch(int iMarker, const UEpochs* Epo) const;

    UMatrixSparse*          GetCrossingBlockMatrix(int NLeft, int NRight, int Ntrial) const;

    int                     GetMarkerIndex(const char* Name, bool CaseSense=false) const;
    int                     GetEventIndex(int iMarker, UEvent E) const;
    ErrorType               EqualizeEvents(const char* Name, int IndexBegin, int IndexEnd) const;

    ErrorType               WriteMarkersCTF(const char *MarkerFileName) const;
    ErrorType               WriteMarkersTXT(const char *MarkerFileName) const;

    int                     GetnTotalSamples(const char* MarkerName) const;
    const char*             GetMarkerName(int im) const;
    const UMarker*          GetMarker(int im) const;
    const UMarker*          GetMarker(const char* MarkerName) const;
    const UMarker*          GetBeginMarker(const char* MarkerName) const;
    const UMarker*          GetEndMarker(const char* MarkerName) const;
    bool                    IsSubSet(const UMarkerArray* Mar) const;

/* Visulalisation */
    UColor                  GetColor(int iMarker)       const; 
    int                     GetThickness(int iMarker)   const;
    bool                    GetShowMarker(int iMarker)  const;
    ErrorType               SetColor(int iMarker, UColor Col);
    ErrorType               SetThickness(int iMarker, int Thick);
    ErrorType               SetShowMarker(int iMarker, bool Show);
    ErrorType               SetAppearence(int iMarker, const UMarker* pMark);

/* Eiting markers */
    ErrorType               MergeMarkerArray(const UMarkerArray* Mar, bool Prepend=false);
    ErrorType               ReplaceMarkers(const UMarkerArray* Mar, bool Prepend=false);
    ErrorType               SetMarker(const UMarker& Mark, int im, bool KeepAppearance=false);
    ErrorType               SetName(int iMarker, const char* Name);
    ErrorType               PrependName(int iMarker, const char* Prep);
    ErrorType               MakeNamesUnique(bool Test=false);
    ErrorType               RemoveMarker(int iMarker);
    ErrorType               RemoveEmptyMarkers(void);
    int                     RemoveDoubleMarkers(void);
    int                     RemoveDoubleNames(void);
    ErrorType               CopyMarker(int iMarker, const char* CopyName);
    ErrorType               AddMarker(const UMarker *Marker, bool Prepend=false);
    ErrorType               AddNewMarkers(int Nnew, const UMarker *Newmarkers, bool Prepend=false);    

/* Editing events */
    ErrorType               AddEvent(int iMarker, UEvent ev);
    ErrorType               AddEquiDistantEvents(int iMarker, int ievFrom, int ievTo, int nevAdd);
    ErrorType               AddEquiDistantEvents(const char* MkName, int ievFrom, int ievTo, int nevAdd);
    ErrorType               AddEquiWidthEvents(int iMarker, int ievFrom, int ievTo, int Width);
    ErrorType               DeleteEvent(int iMarker, int iev);
    ErrorType               DeleteEvents(int iMarker, int ievFrom, int ievTo);
    ErrorType               DeleteMiddleEvents(int iMarker);
    ErrorType               SetEvent(int iMarker, int iev, UEvent ev);
    bool                    AreEventsSorted(int iMarker) const;
    bool                    AreEventsSorted() const;
    ErrorType               SortEvents(int iMarker);
    ErrorType               SortEvents();
    ErrorType               InsertEvents(const char* MkName, int* MkOffset, int NEv) const;
    ErrorType               AddEvent(const char* MkName, int offset) const;

    ErrorType               ResampleData(int NewNSampTrial);
    ErrorType               RedistributeTrials(int SkipSamples, int NewSamplesTrial);
    ErrorType               RedistributeTrials(const UEpochs* NewEpochs);
    ErrorType               RedistributeTrials(const UEpochs* NewEpochs, double NewSampFreq);
    ErrorType               CopyToAllEpochs(int iMarker, int iev, const UEpochs* Epochs);
    ErrorType               CopyAllEventsToAllEpochs(int iMarker, int iep, const UEpochs* Epochs);

    bool                    IsNameEquivalent(int iMarker, const char* Name, bool CaseSense=false) const;
    bool                    IsBeginMarker(int iMarker, const char* Name) const;
    bool                    IsEndMarker(int iMarker, const char* Name) const;

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    ErrorType               error;            // General error flag
    static UString          Properties;
    static const double     TimeGhost;        // Time constant to remove Ghost Markers [s]

    int                     nMarkers;         // Number of markers
    UMarker                 **pMarkers;       // The Array of Marker Pointers 

/*Parameters to compute (absolute) samples into time and vice verse*/
    int                     nSampTrial;       // The number of samples per trial           
    int                     PreStimPts;       // Number of samples before stimulus
    double                  SRate;            // Sample rate (Hz)
    int                     NGostRemoved;     // Number of Ghost Markers that are removed 
    bool                    RemGhostMark;     // true iff Ghost markers are to be removed

/* Functions */
    ErrorType               ReadMarkersTXT(const char *MarkerFileName);
    ErrorType               ReadMarkersEVL(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate);
    ErrorType               ReadMarkersTRG(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate);
    ErrorType               ReadMarkersCTF(const char *MarkerFileName, int NsampTrial, int preStimPnts, double srate, bool RemoveGhostMarkers);
    ErrorType               ReadMarkersPersyst(const char *MarkerFileName);
};

#endif //_MARKERARRAY_INCLUDED
