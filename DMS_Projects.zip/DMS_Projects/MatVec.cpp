/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/**********************************************************************************/
/*                                                                                */
/*     Module for matrix and vector manipulations.                                */
/*     Two objects are implemented UVector3 and UMatrix9.                         */
/*                                                                                */
/*     UVector3 is a "normal" 3D vector, for which inner and outer products, sums */
/*     differences, etc can be computed. The UVector3 is a member of many other   */
/*     U-Objects,                                                                 */
/*                                                                                */
/*     UMatrix9, is a 3x3 symmetric matrix.                                       */
/*                                                                                */
/*                                                                                */
/*     NOTE                                                                       */
/*     The UVector3-object contains a static member, char *Properties. This member*/
/*     is used to stored the properties of the object in ASCII-format. Since this */
/*     member is a static one, it used by all UVector3-objects simultaneously.    */
/*                                                                                */
/*     AUTHOR                                                                     */
/*     Jan C. de Munck                                                            */
/*                                                                                */
/**********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    26-02-98   creation
  Jdm    08-10-98   reorganized include-files
  JdM    08-10-98   separated include-files
  JdM    24-10-98   added static Properties string onto the UVector3-object
  JdM    16-11-98   added operator==() on UVector3()
  JdM    03-01-99   added more comments.
  JdM    11-03-99   added functions Min(), Max(), ceil() and floor() on UVector3()
  JdM    05-05-99   removed static key word from a few UVector3() and UMatrix9() operators
  JdM    14-08-99   added the UVector2() object
  JdM    30-08-99   Added the functions GetURad(), GetUThe(), GetUFi() to get unit vectors in spherical coordinates
  JdM    28-09-99   Added Angle()
  JdM    10-09-99   Added IsInBox()
  JdM    16-05-00   Added Determinant()
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    19-09-00   Added operator!=()
  JdM    19-02-02   Added a new Mirror() function
  JdM    27-08-02   Added R180() and R270()
  JdM    08-03-03   Added GetMercator()
  JdM    16-06-04   Added SwapDirections()
  JdM    08-07-04   Added Determinant() for UVector2
  JdM    24-09-04   Added SwapDirections(bool)
  JdM    22-11-04   BUG FIX: operator!=(). Old version ALLWAYS returned false
  JdM    27-05-06   Added CosAngle()
  JdM    26-10-07   Added WriteBinary() and FILE* constructor to UVector2 and UVector3
  JdM    09-05-08   Added Project()
  JdM    12-07-08   Added GetCylinder()
  JdM    28-07-08   Added IsInTriangle()
  JdM    29-07-08   Added new Min() and Max() functions
  JdM    21-04-10   Added Intersect()
  JdM    09-05-10   Added operator[]
  JdM    23-07-10   Added GetRot90()
  JdM    05-10-11   Added operator const double*()
  JdM    23-10-11   changed operator dd 05-10-11 into  operator double*() (so leaving out const-keyword)
  JdM    08-12-13   Added fabs()
  JdM    18-04-14   Added GetMinCoord() and GetMaxCoord()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    28-10-14   Added IsInView()
  JdM    22-02-15   Added GetArea(), renamed Determinant() to GetDeterminant(). Use const references as arguments
  JdM    10-04-16   Added UVector2::operator*=() and UVector3::operator*=()
  JdM    18-09-16   Added CycleCoords(). Renamed (two of) the functions Mirror() as MirrorY(). Tested for this==NULL. Some functions return ErrorType instead of UVector2() or UVector3()
*/

#include <string.h>
#include <math.h>
#include "MatVec.h"

/* Inititalize static const parameters. */
char UVector2::Properties[MAXVECTORSTRING]  =  "";
char UVector3::Properties[MAXVECTORSTRING]  =  "";

const char*  UVector2::HEADERBEGIN = "Vect2_1.0";
const char*  UVector2::HEADEREND   = "Vect2_End";
const char*  UVector3::HEADERBEGIN = "Vect3_1.0";
const char*  UVector3::HEADEREND   = "Vect3_End";


UVector2::UVector2(FILE* fpIn)
{
    _x = _y = 0.;
    if(fpIn==NULL) return;

    unsigned int ioff   = ftell(fpIn);
    size_t       NHead  = strlen(HEADERBEGIN);
    char         Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        fseek(fpIn, ioff, SEEK_SET);
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UVector2::UVector2(). Wrong header (%s). \n", Buffer);
        return;
    }

    _x = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    _y = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    fread(Buffer,1,strlen(HEADEREND),fpIn);
}
ErrorType UVector2::WriteBinary(FILE* fpOut) const
{
    if(this==NULL)  return U_ERROR;
    if(fpOut==NULL) return U_ERROR;

    size_t NHead  = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(_x, DefaultIntelData, fpOut);
    ::WriteBinary(_y, DefaultIntelData, fpOut);
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

char* UVector2::GetProperties(void) const
/*
     return an ASCII string with the current contents of the object.
     Since this string is a static member variable, the calling function should use or
     copy its contens, before a next call to GetProperties() is made.
 */
{
    memset(Properties, 0, MAXVECTORSTRING);
    sprintf(Properties,"(%9.4g,%9.4g)",_x,_y);
    return Properties;
}

bool UVector2::operator==(const UVector2& v) const
{
    if(_x==v._x && _y==v._y) return true;
    return false;
}

bool UVector2::operator!=(const UVector2& v) const
{
    if((*this==v)==true) return false;
    return false;
}

ErrorType UVector2::Mirror(bool X, bool Y)
{
    if(this==NULL) return U_ERROR;
    if(X==true) _x = -_x;
    if(Y==true) _y = -_y;
    return U_OK;
}

UVector2 Min(UVector2 a, UVector2 b)
{
    UVector2 MinVec = a;
    if(b.Getx()<MinVec.Getx()) MinVec.Setx(b.Getx());
    if(b.Gety()<MinVec.Gety()) MinVec.Sety(b.Gety());

    return MinVec;
}
UVector2 Max(UVector2 a, UVector2 b)
{
    UVector2 MaxVec = a;
    if(b.Getx()>MaxVec.Getx()) MaxVec.Setx(b.Getx());
    if(b.Gety()>MaxVec.Gety()) MaxVec.Sety(b.Gety());

    return MaxVec;
}
UVector2 Min(UVector2 a, UVector2 b, UVector2 c)
{
    UVector2 MinVec = a;
    if(b.Getx()<MinVec.Getx()) MinVec.Setx(b.Getx());
    if(c.Getx()<MinVec.Getx()) MinVec.Setx(c.Getx());

    if(b.Gety()<MinVec.Gety()) MinVec.Sety(b.Gety());
    if(c.Gety()<MinVec.Gety()) MinVec.Sety(c.Gety());

    return MinVec;
}
UVector2 Max(UVector2 a, UVector2 b, UVector2 c)
{
    UVector2 MaxVec = a;
    if(b.Getx()>MaxVec.Getx()) MaxVec.Setx(b.Getx());
    if(c.Getx()>MaxVec.Getx()) MaxVec.Setx(c.Getx());

    if(b.Gety()>MaxVec.Gety()) MaxVec.Sety(b.Gety());
    if(c.Gety()>MaxVec.Gety()) MaxVec.Sety(c.Gety());

    return MaxVec;
}

UVector2 ceil(UVector2 a)
{
    return UVector2(ceil(a.Getx()),ceil(a.Gety()) );
}
UVector2 floor(UVector2 a)
{
    return UVector2(floor(a.Getx()),floor(a.Gety()) );
}
UVector2 fabs(UVector2 a)
{
    return UVector2(fabs(a.Getx()),fabs(a.Gety()) );
}

UVector2 operator*(double f, UVector2 v)
{
    return UVector2(v.Getx()*f,v.Gety()*f);
}

UVector2 operator/(double f, UVector2 v)
{
    return UVector2(v.Getx()/f,v.Gety()/f);
}

double   Angle(UVector2 a, UVector2 b)
/* Return the angle between a and b in radians */
{
    double norma = a.GetNorm();
    double normb = b.GetNorm();
    if(norma<=1.E-20 || normb<=1.E-20) return 0;

    double Cos = (a&b)/(norma*normb);
    Cos = MIN(1.,MAX(-1.,Cos));
    return acos(Cos);
}

bool IsInBox(UVector2 BoxMin, UVector2 BoxMax, UVector2 v)
{
    if(     v.Getx()< BoxMin.Getx() ) return false;
    if(BoxMax.Getx()<      v.Getx() ) return false;
    if(     v.Gety()< BoxMin.Gety() ) return false;
    if(BoxMax.Gety()<      v.Gety() ) return false;
    return true;
}
bool IsInTriangle(UVector2 v, UVector2 v0, UVector2 v1, UVector2 v2)
{
    double Det0 = GetDeterminant(v, v1, v2);
    double Det1 = GetDeterminant(v, v2, v0);
    if(Det0>0 && Det1<0) return false;
    if(Det1>0 && Det0<0) return false;
    double Det2 = GetDeterminant(v, v0, v1);
    if(Det1>0 && Det2<0) return false;
    if(Det2>0 && Det1<0) return false;
    if(Det2>0 && Det0<0) return false;
    if(Det0>0 && Det2<0) return false;
    return true;
}
bool Intersect(UVector2 v0, UVector2 v1, UVector2 v2, UVector2 v3)
/*
    Test whether (v0,v1) intersects (v2,v3)
 */
{
    if(GetDeterminant(v0-v2, v1-v2) * GetDeterminant(v0-v3, v1-v3) < 0.  &&
       GetDeterminant(v2-v0, v3-v0) * GetDeterminant(v2-v1, v3-v1) < 0.) return true;
    return false;
}

double GetDeterminant(const UVector2& v0, const UVector2& v1)
{
    return v0.Getx()*v1.Gety() - v0.Gety()*v1.Getx();
}
double GetDeterminant(const UVector2& v0, const UVector2& v1, const UVector2& v2)
{
    return GetDeterminant(v0-v2, v1-v2);
}

UVector3::UVector3(FILE* fpIn)
{
    _x = _y = _z = 0.;
    if(fpIn==NULL)
    {
        CI.AddToLog("ERROR: UVector3::UVector3(). Invalid NULL pointer. \n");
        return;
    }
    unsigned int ioff   = ftell(fpIn);
    size_t       NHead  = strlen(HEADERBEGIN);
    char         Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UVector3::UVector3(). Reading first item from file pointer. \n");
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UVector3::UVector3(). Wrong header (%s). \n", Buffer);
        return;
    }

    _x = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    _y = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    _z = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    fread(Buffer,1,strlen(HEADEREND),fpIn);
}
ErrorType UVector3::WriteBinary(FILE* fpOut) const
{
    if(this==NULL)  return U_ERROR;
    if(fpOut==NULL) return U_ERROR;

    size_t  NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(_x, DefaultIntelData, fpOut);
    ::WriteBinary(_y, DefaultIntelData, fpOut);
    ::WriteBinary(_z, DefaultIntelData, fpOut);
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);
    return U_OK;
}

char* UVector3::GetProperties(void) const
/*
     return an ASCII string with the current contents of the object.
     Since this string is a static member variable, the calling function should use or
     copy its contens, before a next call to GetProperties() is made.
 */
{
    memset(Properties, 0, MAXVECTORSTRING);
    sprintf(Properties,"(%9.4g,%9.4g,%9.4g)",_x,_y,_z);
    return Properties;
}

bool UVector3::operator==(const UVector3& v) const
{
    if(_x==v._x && _y==v._y && _z==v._z) return true;
    return false;
}

bool UVector3::operator!=(const UVector3& v) const
{
    if((*this==v)==true) return false;
    return true;
}

UVector2 UVector3::Project(int iplane) const
{
    if(this==NULL) return UVector2();
    switch(iplane)
    {
    case 0: return Px();
    case 1: return Py();
    case 2: return Pz();
    }
    return UVector2();
}

UVector3 Min(const UVector3& a, const UVector3& b)
{
    UVector3 MinVec = a;
    if(b.Getx()<a.Getx()) MinVec.Setx(b.Getx());
    if(b.Gety()<a.Gety()) MinVec.Sety(b.Gety());
    if(b.Getz()<a.Getz()) MinVec.Setz(b.Getz());

    return MinVec;
}
UVector3 Max(const UVector3& a, const UVector3& b)
{
    UVector3 MaxVec = a;
    if(b.Getx()>a.Getx()) MaxVec.Setx(b.Getx());
    if(b.Gety()>a.Gety()) MaxVec.Sety(b.Gety());
    if(b.Getz()>a.Getz()) MaxVec.Setz(b.Getz());

    return MaxVec;
}
UVector3 Min(const UVector3& a, const UVector3& b, const UVector3& c)
{
    UVector3 MinVec = a;
    if(b.Getx()<MinVec.Getx()) MinVec.Setx(b.Getx());
    if(c.Getx()<MinVec.Getx()) MinVec.Setx(c.Getx());

    if(b.Gety()<MinVec.Gety()) MinVec.Sety(b.Gety());
    if(c.Gety()<MinVec.Gety()) MinVec.Sety(c.Gety());

    if(b.Getz()<MinVec.Getz()) MinVec.Setz(b.Getz());
    if(c.Getz()<MinVec.Getz()) MinVec.Setz(c.Getz());

    return MinVec;
}
UVector3 Max(const UVector3& a, const UVector3& b, const UVector3& c)
{
    UVector3 MaxVec = a;
    if(b.Getx()>MaxVec.Getx()) MaxVec.Setx(b.Getx());
    if(c.Getx()>MaxVec.Getx()) MaxVec.Setx(c.Getx());

    if(b.Gety()>MaxVec.Gety()) MaxVec.Sety(b.Gety());
    if(c.Gety()>MaxVec.Gety()) MaxVec.Sety(c.Gety());

    if(b.Getz()>MaxVec.Getz()) MaxVec.Setz(b.Getz());
    if(c.Getz()>MaxVec.Getz()) MaxVec.Setz(c.Getz());

    return MaxVec;
}

UVector3 ceil(const UVector3& a)
{
    return UVector3(ceil(a.Getx()),ceil(a.Gety()), ceil(a.Getz()) );
}
UVector3 floor(const UVector3& a)
{
    return UVector3(floor(a.Getx()),floor(a.Gety()), floor(a.Getz()) );
}
UVector3 fabs(const UVector3& a)
{
    return UVector3(fabs(a.Getx()),fabs(a.Gety()), fabs(a.Getz()) );
}

UVector3 operator*(double f, const UVector3& v)
{
    return UVector3(v.Getx()*f,v.Gety()*f,v.Getz()*f);
}

UVector3 operator/(double f, const UVector3& v)
{
    return UVector3(v.Getx()/f,v.Gety()/f,v.Getz()/f);
}

UVector2 UVector3::GetMercator(double RadView) const
/*
   Return the Mercator projection of *this, scaled to a maximum radius of RadView
 */
{
    double rho2 = _x*_x + _y*_y;
    if(rho2<=1.e-8) return UVector2();

    double r   = RadView*GetTheta()/(sqrt(rho2)*PI);
    return UVector2(r*_x, r*_y);
}
UVector2 UVector3::GetCylinder(double RadView) const
{
    double r   = RadView*atan2(_y,_z)/PI2;
    return UVector2(_x, r);
}

UVector3 UVector3::GetURad(void) const
/*
     Get the unit vector in the radial direction
 */
{
    UVector3 Rad = *this;
    Rad.Normalize();
    return Rad;
}

UVector3 UVector3::GetUThe(void) const
/*
     Get the unit vector in the increasing theta-direction
 */
{
    double Th0 = GetTheta();
    double Fi0 = GetFi();
    double ct  = cos(Th0);
    double st  = sin(Th0);
    double cf  = cos(Fi0);
    double sf  = sin(Fi0);
    return UVector3(ct*cf,ct*sf,-st);
}

UVector3 UVector3::GetUFi(void) const
/*
     Get the unit vector in the increasing fi-direction
 */
{
    double Fi0 = GetFi();
    return UVector3(-sin(Fi0), cos(Fi0), 0.);
}

ErrorType UVector3::CycleCoords(int dir)
{
    if(this==NULL) return U_ERROR;

    dir = dir>=0 ? (dir%3) : (-dir+1)%3;
    switch(dir)
    {
    case 0: *this = UVector3(_x,_y,_z); break;
    case 1: *this = UVector3(_z,_x,_y); break;
    case 2: *this = UVector3(_y,_z,_x); break;
    }
    return U_OK;
}
ErrorType UVector3::Mirror(bool X, bool Y, bool Z)
{
    if(this==NULL) return U_ERROR;
    if(X==true) _x = -_x;
    if(Y==true) _y = -_y;
    if(Z==true) _z = -_z;
    return U_OK;
}

ErrorType UVector3::SwapDirections(int dir1, int dir2)
{
    if(this==NULL) return U_ERROR;

    if(dir1==dir2) return U_OK;

    if( (dir1==0&&dir2==1) || (dir1==1&&dir2==0) )
    {
        double dum = _x;
        _x         = _y;
        _y         = dum;
        return U_OK;
    }
    if( (dir1==1&&dir2==2) || (dir1==2&&dir2==1) )
    {
        double dum = _y;
        _y         = _z;
        _z         = dum;
        return U_OK;
    }
    if( (dir1==2&&dir2==0) || (dir1==0&&dir2==2) )
    {
        double dum = _z;
        _z         = _x;
        _x         = dum;
        return U_OK;
    }
    return U_ERROR;
}

ErrorType UVector3::SwapDirections(bool Forward)
{
    if(Forward==true)
    {
        double dum = _z;
        _z         = _y;
        _y         = _x;
        _x         = dum;
    }
    else
    {
        double dum = _x;
        _x         = _y;
        _y         = _z;
        _z         = dum;
    }
    return U_OK;
}

double CosAngle(const UVector3& a, const UVector3& b)
{
    double norma = a.GetNorm();
    double normb = b.GetNorm();
    if(norma<=1.E-20 || normb<=1.E-20) return 0;

    return (a&b)/(norma*normb);
}
double   Angle(const UVector3& a, const UVector3& b)
/* Return the angle between a and b in radians*/
{
    double norma = a.GetNorm();
    double normb = b.GetNorm();
    if(norma<=1.E-20 || normb<=1.E-20) return 0;

    double Cos = (a&b)/(norma*normb);
    Cos = MIN(1.,MAX(-1.,Cos));
    return acos(Cos);
}

bool IsInBox(const UVector3& BoxMin, const UVector3& BoxMax, const UVector3& v)
{
    if(     v.Getx()< BoxMin.Getx() ) return false;
    if(BoxMax.Getx()<      v.Getx() ) return false;
    if(     v.Gety()< BoxMin.Gety() ) return false;
    if(BoxMax.Gety()<      v.Gety() ) return false;
    if(     v.Getz()< BoxMin.Getz() ) return false;
    if(BoxMax.Getz()<      v.Getz() ) return false;
    return true;
}
bool IsInView(const UVector3& v0, const UVector3& v1, const UVector3& v2, const UVector3& v)
{
    double D2 = GetDeterminant(v0, v1, v);
    double D0 = GetDeterminant(v1, v2, v);
    double D1 = GetDeterminant(v2, v0, v);

    if(D0>0 && D1>0 && D2>0) return true;
////    if(D0<0 && D1<0 && D2<0) return true;
    return false;
}

double GetDeterminant(const UVector3& v0, const UVector3& v1, const UVector3& v2)
{
    return (v0^v1)&v2;
}
double GetArea(const UVector3& v0, const UVector3& v1, const UVector3& v2)
{
    UVector3 N = (v1-v0) ^ (v2-v0);
    return N.GetNorm()/2.;
}


UMatrix9::UMatrix9(const UMatrix9 &m )
{
    mat0 = m.mat0;
    mat4 = m.mat4;
    mat8 = m.mat8;
    mat1 = m.mat1;
    mat2 = m.mat2;
    mat5 = m.mat5;
}

UMatrix9::UMatrix9(double m00, double m01, double m02, double m11, double m12, double m22)
{
    mat0 = m00;
    mat4 = m11;
    mat8 = m22;
    mat1 = m01;
    mat2 = m02;
    mat5 = m12;
}

UMatrix9::UMatrix9(const UVector3 &v)
{
    mat0 = v.Getx() * v.Getx();
    mat4 = v.Gety() * v.Gety();
    mat8 = v.Getz() * v.Getz();
    mat1 = v.Getx() * v.Gety();
    mat2 = v.Getx() * v.Getz();
    mat5 = v.Gety() * v.Getz();
}

UMatrix9::UMatrix9(const UVector3 &v1, const UVector3 &v2)
{
    mat0 = 2*v1.Getx() * v2.Getx();
    mat4 = 2*v1.Gety() * v2.Gety();
    mat8 = 2*v1.Getz() * v2.Getz();
    mat1 = v1.Getx() * v2.Gety() + v1.Gety() * v2.Getx();
    mat2 = v1.Getx() * v2.Getz() + v1.Getz() * v2.Getx();
    mat5 = v1.Gety() * v2.Getz() + v1.Getz() * v2.Gety();
}

/* Combinations with scalars*/
UMatrix9& UMatrix9::operator*(double f)
{
    mat0 *= f;
    mat4 *= f;
    mat8 *= f;
    mat1 *= f;
    mat2 *= f;
    mat5 *= f;
    return *this;
}
UMatrix9& UMatrix9::operator/(double f)
{
    mat0 /= f;
    mat4 /= f;
    mat8 /= f;
    mat1 /= f;
    mat2 /= f;
    mat5 /= f;
    return *this;
}
/* Combinations with other matrices */
UMatrix9 UMatrix9::operator-(void)
{
    UMatrix9 result(*this);
    result.mat0 = -result.mat0;
    result.mat4 = -result.mat4;
    result.mat8 = -result.mat8;
    result.mat1 = -result.mat1;
    result.mat2 = -result.mat2;
    result.mat5 = -result.mat5;
    return result;
}
UMatrix9 UMatrix9::operator+=(const UMatrix9 &m)
{
    mat0 += m.mat0;
    mat4 += m.mat4;
    mat8 += m.mat8;
    mat1 += m.mat1;
    mat2 += m.mat2;
    mat5 += m.mat5;
    return *this;
}
UMatrix9 UMatrix9::operator-=(const UMatrix9 &m)
{
    mat0 -= m.mat0;
    mat4 -= m.mat4;
    mat8 -= m.mat8;
    mat1 -= m.mat1;
    mat2 -= m.mat2;
    mat5 -= m.mat5;
    return *this;
}
UMatrix9 UMatrix9::operator+(const UMatrix9 &m)
{
    UMatrix9 result(*this);
    result.mat0 += m.mat0;
    result.mat4 += m.mat4;
    result.mat8 += m.mat8;
    result.mat1 += m.mat1;
    result.mat2 += m.mat2;
    result.mat5 += m.mat5;

    return result;
}
UMatrix9 UMatrix9::operator-(const UMatrix9 &m)
{
    UMatrix9 result(*this);
    result.mat0 -= m.mat0;
    result.mat4 -= m.mat4;
    result.mat8 -= m.mat8;
    result.mat1 -= m.mat1;
    result.mat2 -= m.mat2;
    result.mat5 -= m.mat5;

    return result;
}

/* Various*/
void UMatrix9::GetMatrix(double *array)
{
    array[0] = mat0;
    array[1] = mat1;
    array[2] = mat2;
    array[3] = mat1;
    array[4] = mat4;
    array[5] = mat5;
    array[6] = mat2;
    array[7] = mat5;
    array[8] = mat8;
}

void UMatrix9::AddMatrix(double *array)
{
    array[0] += mat0;
    array[1] += mat1;
    array[2] += mat2;
    array[3] += mat1;
    array[4] += mat4;
    array[5] += mat5;
    array[6] += mat2;
    array[7] += mat5;
    array[8] += mat8;
}

UMatrix9 operator*(double f, UMatrix9 m)
{
    double h[9];
    m.GetMatrix(h);
    return UMatrix9(h[0]*f,h[1]*f,h[2]*f,h[4]*f,h[5]*f,h[8]*f);
}

UMatrix9 operator/(double f, UMatrix9 m)
{
    double h[9];
    m.GetMatrix(h);
    return UMatrix9(h[0]/f,h[1]/f,h[2]/f,h[4]/f,h[5]/f,h[8]/f);
}
