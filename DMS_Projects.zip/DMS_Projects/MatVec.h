#ifndef _MATVEC_INCLUDED
#define _MATVEC_INCLUDED

#include <math.h>
#include "BasicInclude.h"

#define MAXVECTORSTRING 64

class DLL_IO UVector2
{
public:
    UVector2() { _x=_y=0;}
    UVector2(float  xx, float  yy)            { _x=xx; _y=yy;}
    UVector2(double xx, double yy)            { _x=xx; _y=yy;}
    UVector2(const float *xx)                 { _x=xx[0]; _y=xx[1];}
    UVector2(const double *xx)                { _x=xx[0]; _y=xx[1];}
    UVector2(double Fi)                       {_x=cos(Fi); _y=sin(Fi);}
    UVector2(const UVector2 &v)               {_x=v._x; _y=v._y;}
    UVector2(FILE* fpIn);

/* Conversion */
    double   operator[](int ic) const {ic=ic%2; if(ic==0) return _x; return _y;}
    operator double*()                        {return &_x;}

/* Combinations with scalars*/
    UVector2 operator*(double f) const        {return UVector2(_x*f,_y*f);}
    UVector2 operator/(double f) const        {return UVector2(_x/f,_y/f);}
    UVector2 operator*=(double f)             {_x*=f; _y*=f; return *this;}

/* Combinations with other vectors */    
    UVector2 operator-(void)  const         {return UVector2(-_x,-_y);}
    UVector2 operator+=(const UVector2& v)  {_x+=v._x; _y+=v._y; return *this;}
    UVector2 operator-=(const UVector2& v)  {_x-=v._x; _y-=v._y; return *this;}
    UVector2 operator+(const UVector2& v) const  {return UVector2(_x+v._x,_y+v._y);}
    UVector2 operator-(const UVector2& v) const  {return UVector2(_x-v._x,_y-v._y);}

/* Cross product*/    
    double operator^(const UVector2& v) const    {return _x*v._y-_y*v._x;}

/* Inner product*/
    double operator&(const UVector2& v) const    {return v._x*_x + v._y*_y;}

/* Conversion*/
    double   GetFi() const           {if(_x==0.&&_y==0.) return 0.; else return atan2(_y,_x);}  

/* Various*/
    bool  operator==(const UVector2& v) const;
    bool  operator!=(const UVector2& v) const;

    double             GetMinCoord() const       {if( this) return MIN(_x, _y);      return 0.;}
    double             GetMaxCoord() const       {if( this) return MAX(_x, _y);      return 0.;}
    double             GetNorm2()const           {if( this) return _x*_x + _y*_y;    return 0.;}
    double             GetNorm()const            {if( this) return sqrt(GetNorm2()); return 0.;}
    double             Normalize()               {double n=GetNorm(); if(n>0.) {_x/=n;_y/=n;} return n;}
    double             Getx()const               {if( this) return _x;               return 0.;}
    double             Gety()const               {if( this) return _y;               return 0.;}
    ErrorType          Setx(double x)            {if(!this) return U_ERROR; _x=x; return U_OK;}
    ErrorType          Sety(double y)            {if(!this) return U_ERROR; _y=y; return U_OK;}

    UVector2           GetRot90(void) const      {if( this) return UVector2(-_y,_x); return UVector2();}
    ErrorType          Rot90(void)               {if(!this) return U_ERROR; double d=_x; _x=-_y; _y= d; return U_OK;}
    ErrorType          Rot180(void)              {if(!this) return U_ERROR; double d=_x; _x=-_y; _y=-d; return U_OK;}
    ErrorType          Rot270(void)              {if(!this) return U_ERROR; double d=_x; _x= _y; _y=-d; return U_OK;}
    ErrorType          SwapXY(void)              {if(!this) return U_ERROR; double d=_x; _x= _y; _y= d; return U_OK;}
    ErrorType          Mirror(bool X, bool Y);

    char*              GetProperties(void) const;
    ErrorType          WriteBinary(FILE* fpOut) const;

private:
    static char        Properties[MAXVECTORSTRING];
    static const char* HEADERBEGIN;
    static const char* HEADEREND;

    double             _x;
    double             _y;
};


UVector2 DLL_IO operator*(double f, UVector2 v);
UVector2 DLL_IO operator/(double f, UVector2 v);

UVector2 DLL_IO Min(UVector2 a, UVector2 b);
UVector2 DLL_IO Max(UVector2 a, UVector2 b);
UVector2 DLL_IO Min(UVector2 a, UVector2 b, UVector2 c);
UVector2 DLL_IO Max(UVector2 a, UVector2 b, UVector2 c);
UVector2 DLL_IO ceil(UVector2 a);
UVector2 DLL_IO floor(UVector2 a);
UVector2 DLL_IO fabs(UVector2 a);


double   DLL_IO Angle(UVector2 a, UVector2 b);
bool     DLL_IO IsInBox(UVector2 BoxMin, UVector2 BoxMax, UVector2 v);
bool     DLL_IO IsInTriangle(UVector2 v, UVector2 v0, UVector2 v1, UVector2 v2);
bool     DLL_IO Intersect(UVector2 v0, UVector2 v1, UVector2 v2, UVector2 v3);
double   DLL_IO GetDeterminant(const UVector2& v0, const UVector2& v1);
double   DLL_IO GetDeterminant(const UVector2& v0, const UVector2& v1, const UVector2& v2);

class DLL_IO UVector3
{
public:
    UVector3() { _x=_y=_z=0;}
    UVector3(float  xx, float  yy, float  zz) { _x=xx; _y=yy; _z=zz;}
    UVector3(double xx, double yy, double zz) { _x=xx; _y=yy; _z=zz;}
    UVector3(const float  *xx)                { _x=xx[0]; _y=xx[1]; _z=xx[2];}
    UVector3(const double *xx)                { _x=xx[0]; _y=xx[1]; _z=xx[2];}
    UVector3(double Th, double Fi)            {double sTh=sin(Th); double cTh=cos(Th);
                                               double sFi=sin(Fi); double cFi=cos(Fi);
                                               _x=sTh*cFi; _y=sTh*sFi; _z=cTh;}
    UVector3(const UVector3 &v)               {_x=v._x; _y=v._y;_z=v._z;}
    UVector3(FILE* fpIn);

/* Conversion */
    double             operator[](int ic) const {ic=ic%3; if(ic==0) return _x; if(ic==1) return _y; return _z;}
    operator           double*() {return &_x;}

/* Combinations with scalars*/
    UVector3           operator*(double f) const        {return UVector3(_x*f,_y*f,_z*f);}
    UVector3           operator/(double f) const        {return UVector3(_x/f,_y/f,_z/f);}
    UVector3           operator*=(double f)             {_x*=f; _y*=f; _z*=f; return *this;}

/* Combinations with other vectors */    
    UVector3           operator-(void)  const         {return UVector3(-_x,-_y,-_z);}
    UVector3           operator+=(const UVector3& v)  {_x+=v._x; _y+=v._y; _z+=v._z; return *this;}
    UVector3           operator-=(const UVector3& v)  {_x-=v._x; _y-=v._y; _z-=v._z; return *this;}
    UVector3           operator+(const UVector3& v) const  {return UVector3(_x+v._x,_y+v._y,_z+v._z);}
    UVector3           operator-(const UVector3& v) const  {return UVector3(_x-v._x,_y-v._y,_z-v._z);}

/* Cross product*/       
    UVector3           operator^(const UVector3& v) const {return UVector3(_y*v._z-_z*v._y,_z*v._x-_x*v._z,_x*v._y-_y*v._x);}

/* Inner product*/
    double             operator&(const UVector3& v) const {return v._x*_x + v._y*_y + v._z*_z;}

/* Conversion*/
    double             GetMinCoord() const       {if(this) return MIN(MIN(_x, _y),_z);      return 0.;}
    double             GetMaxCoord() const       {if(this) return MAX(MAX(_x, _y),_z);      return 0.;}
    double             GetTheta() const          {if(GetNorm2()==0.) return 0.; else return atan2(sqrt(_x*_x+_y*_y),_z);}
    double             GetFi() const             {if(_x==0.&&_y==0.) return 0.; else return atan2(_y,_x);}
    UVector2           Px()    const             {return UVector2(_y, _z);}
    UVector2           Py()    const             {return UVector2(_z, _x);}
    UVector2           Pz()    const             {return UVector2(_x, _y);}
    UVector2           Project(int iplane) const;
    UVector2           GetMercator(double RadView) const;
    UVector2           GetCylinder(double RadView) const;

/* Various*/
    bool               operator==(const UVector3& v) const;
    bool               operator!=(const UVector3& v) const;

    double             GetNorm2()const           {if( this) return _x*_x + _y*_y + _z*_z; return 0.;}
    double             GetNorm()const            {return sqrt(GetNorm2());}
    double             Normalize()               {double n=GetNorm(); if(n>0) {_x/=n;_y/=n;_z/=n;} return n;}
    double             Getx()const               {if( this) return _x; return 0.;}
    double             Gety()const               {if( this) return _y; return 0.;}
    double             Getz()const               {if( this) return _z; return 0.;}
    ErrorType          Setx(double x)            {if(!this) return U_ERROR; _x=x; return U_OK;}
    ErrorType          Sety(double y)            {if(!this) return U_ERROR; _y=y; return U_OK;}
    ErrorType          Setz(double z)            {if(!this) return U_ERROR; _z=z; return U_OK;}

    double             GetVolume() const         {if(this) return _x*_y*_z; return 0.;}

    UVector3           GetURad(void) const;
    UVector3           GetUThe(void) const;
    UVector3           GetUFi(void) const;

    ErrorType          Mirror(bool X, bool Y, bool Z);
    ErrorType          MirrorY()                    {if(!this) return U_ERROR; _y=-_y;              return U_OK;}
    ErrorType          MirrorY(UVector3 s)          {if(!this) return U_ERROR; _y=-_y + 2*s.Gety(); return U_OK;}
    UVector3           GetMirrorY(void) const       {if(!this) return UVector3(); UVector3 M(*this); M.MirrorY();  return M;}
    UVector3           GetMirrorY(UVector3 s) const {if(!this) return UVector3(); UVector3 M(*this); M.MirrorY(s); return M;}
    ErrorType          CycleCoords(int dir);
    ErrorType          SwapDirections(int dir1, int dir2);
    ErrorType          SwapDirections(bool Forward);

    char*              GetProperties(void) const;
    ErrorType          WriteBinary(FILE* fpOut) const;

private:
    static char        Properties[MAXVECTORSTRING];
    static const char* HEADERBEGIN;
    static const char* HEADEREND;

    double             _x;
    double             _y;
    double             _z;
};

UVector3 DLL_IO operator*(double f, const UVector3& v);
UVector3 DLL_IO operator/(double f, const UVector3& v);

UVector3 DLL_IO Min(const UVector3& a, const UVector3& b);
UVector3 DLL_IO Max(const UVector3& a, const UVector3& b);
UVector3 DLL_IO Min(const UVector3& a, const UVector3& b, const UVector3& c);
UVector3 DLL_IO Max(const UVector3& a, const UVector3& b, const UVector3& c);
UVector3 DLL_IO ceil(const UVector3& a);
UVector3 DLL_IO floor(const UVector3& a);
UVector3 DLL_IO fabs(const UVector3& a);

double   DLL_IO CosAngle(const UVector3& a, const UVector3& b);
double   DLL_IO Angle(const UVector3& a, const UVector3& b);
bool     DLL_IO IsInBox(const UVector3& BoxMin, const UVector3& BoxMax, const UVector3& v);
bool     DLL_IO IsInView(const UVector3& v0, const UVector3& v1, const UVector3& v2, const UVector3& v);
double   DLL_IO GetDeterminant(const UVector3& v0, const UVector3& v1, const UVector3& v2);
double   DLL_IO GetArea(const UVector3& v0, const UVector3& v1, const UVector3& v2);


class DLL_IO UMatrix9
{
private:
    double mat0, mat1, mat2, mat4, mat5, mat8;

public:
    UMatrix9() {mat0=mat4=mat8=1.; mat1=mat2=mat5=0.;}; 
    UMatrix9(double d) {mat0=mat4=mat8=d; mat1=mat2=mat5=0.;}; 
    UMatrix9(double m00, double m01, double m02, double m11, double m12, double m22);
    UMatrix9(const UMatrix9 &m ); 
    UMatrix9(const UVector3 &v);
    UMatrix9(const UVector3 &v1, const UVector3 &v2);

/* Combinations with scalars*/
    UMatrix9& operator*(double f);
    UMatrix9& operator/(double f);
/* Combinations with other matrices */    
    UMatrix9 operator-(void);        
    UMatrix9 operator+=(const UMatrix9 &m);  
    UMatrix9 operator-=(const UMatrix9 &m);  
    UMatrix9 operator+(const UMatrix9 &m);   
    UMatrix9 operator-(const UMatrix9 &m);   

/* Various*/
    void GetMatrix(double *mat);
    void AddMatrix(double *mat);
};   

UMatrix9 DLL_IO operator*(double f, UMatrix9 m);
UMatrix9 DLL_IO operator/(double f, UMatrix9 m);

#endif// _MATVEC_INCLUDED
