/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck (adapted from the AVL/NKI AVS-modules)                      */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who      When       What
  JdM    17-04-00   creation
  JdM    24-04-00   Two improvements: find the optimal transform in Match() w.r.t.
                    the initial guess, and give large penalty to points outside MR grid
  JdM    27-04-00   Added parameter to Match() in order to store intermediate results
                    Apply smoothing of MR-image before thresholding
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    30-12-06   Adapted include file to new directory structure
*/


#include<stdlib.h>
#include<string.h>

#include"MatchChamfer.h"
#include"PatTree.h"


UMatchChamfer::UMatchChamfer(int IntP, CostType D3Cost, const UCostminimize& CMpar) :
    Uminimize(CMpar)
{
    InterT = IntP;
    CostT  = D3Cost;
    Dist   = NULL;
    Dots   = NULL;
}

UMatchChamfer::~UMatchChamfer()
{
    delete Dist;
    delete Dots;
}


#define MIN_THRESHOLD     35.
#define MAX_THRESHOLD    500.
#define DIS2ANG             .1
#define OUTSIDE          255

ErrorType UMatchChamfer::Match(const UField* InRef, const UField* InDots, UEuler* Xfm, UPatTree* InterResults) 
/*
    Find the optimal match between the reference UField *InRef and the point list UField
    *InDots usinf Chamfer matching. The intitial guess is provided by *Xfm, and the
    same pointer is used to store the optimal match.

    if(InterResults) store intermediate results (line detection of head) in sibling directory of *InterResults

    Notes:
    The distance transform on *InRef is done by assuming:
    -It is a T1 MR image
    -The outside of the head is detected
    -It is assumed that all points of *Inref lay within the grid of *Inref (large penalties
     are give to points outside this grid (OUTSIDE).
 */
{
    delete Dist;
    delete Dots;

    Dist = new UField(*InRef);
    Dots = new UField(*InDots);
    if(Dist==NULL || Dist->GetError()!=U_OK ||
       Dots==NULL || Dots->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot create internal fields.\n");
        return U_ERROR;
    }

/* Smooth the MR*/
    if(Dist->Smooth(4)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot compute smoothing.\n");
        return U_ERROR;
    }
    if(InterResults)
    {
        UPatTree Inter = InterResults->Sibling("Smooth",UPatTree::U_SCAN);
        Inter.SetScan(Dist);
        Inter.SetScanToWld(InterResults->GetToWld());
    }

/* Apply segmentation thresholds based on pixel histogram*/
    if(Dist->ThresholdRelative(MIN_THRESHOLD, MAX_THRESHOLD, 255)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot compute threshold.\n");
        return U_ERROR;
    }

/* Perform an edge detection*/
    if(Dist->EdgeDetect(true)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot compute EdgeDetect.\n");
        return U_ERROR;
    }

/* Extend the field 1 cm in all directions */
    Dist->ForceUniform(1.e-3);
    if(Dist->Crop(Dist->GetMinx()-UVector3(1.,1.,1.),Dist->GetMaxx()+UVector3(1.,1.,1.),true)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot crop/extend the edge detect.\n");
        return U_ERROR;
    }
    if(InterResults)
    {
        UPatTree Inter = InterResults->Sibling("HeadLine",UPatTree::U_SCAN);
        Inter.SetScan(Dist);
        Inter.SetScanToWld(InterResults->GetToWld());
    }

/* And a distance transform*/
    if(Dist->DistanceXFM(true, true, 1, -1)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot compute distance transform.\n");
        return U_ERROR;
    }
    if(InterResults)
    {
        UPatTree Inter = InterResults->Sibling("Distance",UPatTree::U_SCAN);
        Inter.SetScan(Dist);
        Inter.SetScanToWld(InterResults->GetToWld());
    }

/* Do the iterative search of the transformation w.r.t. the initial guess*/
    if(Dots->xfm(*Xfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchChamfer::Match(). Cannot Transform points.\n");
        return U_ERROR;
    }

    double par[6] = {0.,0.,0.,0.,0.,0.};

    ErrorType error   = Iterate(par,6,2.);
    double    FinCost = ComputeCost(par, -1, NULL);

    par[3] *= DIS2ANG;
    par[4] *= DIS2ANG;
    par[5] *= DIS2ANG;

    *Xfm = UEuler(par[0], par[1], par[2], par[3], par[4], par[5]) * *Xfm;

    CI.AddToLog("Note: UMatchChamfer::Match() \n");
    CI.AddToLog("Note: Final cost = %f \n", FinCost);
    CI.AddToLog("Note: N iterations = %d \n", GetNoIterations());
    CI.AddToLog("Note: N points  = %d \n", Dots->GetNpoints());
    CI.AddToLog("Note: Translations:  (%f, %f, %f) \n",     par[0]   ,     par[1],        par[2]   );
    CI.AddToLog("Note: Rotations:     (%f, %f, %f) \n",180.*par[3]/PI,180.*par[4]/PI,180.*par[5]/PI);
    return error;   
}

double UMatchChamfer::ComputeCost(double *par, int iter, int *status)
{
    UEuler XFM = UEuler(par[0], par[1], par[2], DIS2ANG*par[3], DIS2ANG*par[4], DIS2ANG*par[5]);
    
    UField* CostField = Dist->ResampleField(XFM, Dots, InterT, OUTSIDE, false);
    if(CostField==NULL || CostField->GetError()!=U_OK)
    {
        delete CostField;
        return 1000;
    }
    
    unsigned char* Data = CostField->GetBdata();

/* Add distances*/
    double Cost = 0;
    switch(CostT)
    {
    case U_ABS:
        {
            for(int k=0; k<CostField->GetNpoints(); k++) Cost += abs(Data[k]);
        }
        Cost /= CostField->GetNpoints();
        break;

    case U_SQUARE:
        {
            for(int k=0; k<CostField->GetNpoints(); k++) Cost += Data[k]*Data[k];
        }    
        Cost /= CostField->GetNpoints();
        break;

    case U_MAX:
        {
            Cost = Data[0];
            for(int k=0; k<CostField->GetNpoints(); k++) Cost = MAX(Cost, Data[k]);
        }
        break;
    }
    
    delete CostField;

    return Cost;
}
