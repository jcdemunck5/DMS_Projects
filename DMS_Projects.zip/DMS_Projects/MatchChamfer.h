#ifndef _MATCHCHAMFER_INCLUDED
#define _MATCHCHAMFER_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include"Minimize.h"

class UPatTree;
class UField;
class UEuler;

class DLL_IO UMatchChamfer : public Uminimize
{
public:
    enum CostType {U_ABS,           // Average distances
                   U_SQUARE,        // Average squared distances
                   U_MAX};          // Max distance

    UMatchChamfer(int IntP, CostType D3Cost, const UCostminimize& CMpar = UCostminimize());
    ~UMatchChamfer();

    ErrorType Match(const UField* InRef, const UField* InDots, UEuler* Xfm, UPatTree* InterResults=NULL);

private:
    int       InterT;
    CostType  CostT;
    UField*   Dist;
    UField*   Dots;

    double ComputeCost(double *par, int iter, int *status);
};
#endif// _MATCHCHAMFER_INCLUDED
