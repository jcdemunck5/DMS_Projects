/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck (adapted from the AVL/NKI module Avs_mat3.cpp)              */
/*                                                                               */
/*********************************************************************************/
/*
  Update history 
  
  Who    When       What
  JdM    20-08-99   creation
  JdM    02-09-99   compatibilty for SUN UNIX compiler
  JdM    07-10-99   removed (now) obsolete arguments grad[] and gauss[] from ComputeCost()
  JdM    12-04-00   removed some obsolete parameters and defines
  JdM    23-11-00   Bug Fix in comp_ami(). Prevent overflow errors using double i.s.o. int for temp2
  JdM    30-11-00   Add best cost to standard log file
  JdM    27-03-01   Bug fix in comp_ami(), RMS error in combination with LogBinSize!=0
                    Add PrintCostToScreen()
  JdM    02-02-02   Added new constructor, made some members protected, added GetProperties()
  JdM    04-02-02   New MatchCompute(). Made field parameters const.
  JdM    27-06-02   Added MatchComputeSingleEuler()
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    25-11-02   Added and used ParToXFM()
  JdM    07-10-03   Added SetLimitRise()
  JdM    07-10-04   Bug fix: MatchCompute(). Memory leakage, delete Fout, before making new one
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    04-09-08   Added MatchComputeGlobalShift()
  JdM    16-09-08   Bug fix: MatchComputeGlobalShift(). Initializing pars[]
  JdM    20-09-08   MatchComputeGlobalShift(). Added Range parameter.
  JdM    20-11-08   MatchCompute(). Added ULinTran version
  JdM    01-11-10   Use UString for Properties;
                    Eliminate some warnings by explicit type conversions
  JdM    11-01-12   Detect whether images are 2D (set Fit2D)
  JdM    25-09-13   Added MatchComputeGlobalRot()
                    BUG FIX ComputeCost(). Wrong index was used for rotation in case of Fit2D
  JdM    21-10-13   Bug Fix: MatchComputeGlobalRot(). Use matrix based rotations to address all 24 possible rotations
  JdM    07-04-18   Added MatchComputeScale()
  JdM    08-04-18   MAJOR update. Use (new) URestrictTransform object to manage free parameters
*/
  
#include<stdlib.h>
#include<string.h>

#include"MatchVol.h"
#include"Field.h"


#define OK     1

UString UMatchVol::Properties = UString();

UMatchVol::UMatchVol() :
    Uminimize(UCostminimize())
{
    UCostminimize::SetOptMethod(UCostminimize::U_SIMPLEX_BOOST); 
    UCostminimize::SetMaxiter(500);
    UCostminimize::SetNormalize(false);
    UCostminimize::SetTolerance(-1.e-4);
    UCostminimize::SetStartOffset(5.);
    UCostminimize::SetLogFile();
    error = SetDefaults();
}

UMatchVol::UMatchVol(InterType IntP, CostType D3Cost, int logbin, const UCostminimize& CMpar) :
    Uminimize(CMpar)
{
    error = SetDefaults();
    if(error==U_OK) error = SetCostType(D3Cost);
    if(error==U_OK) error = SetInterType(IntP);
    if(error==U_OK) error = SetLogBinSize(logbin);
    if(error==U_OK)
    {
        UCostminimize::SetStartOffset(5.);
    }
}

UMatchVol::~UMatchVol()
{
    delete   Fout;
    delete[] his1;          
    delete[] his2;          
    delete[] his12;         
    delete[] total_his12;   
    delete[] lut;           
}


ErrorType UMatchVol::SetCostType(CostType D3Cost)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(D3Cost!=U_MUTIN &&
       D3Cost!=U_MUTIN2 &&
       D3Cost!=U_RMSADJ &&
       D3Cost!=U_RMS) 
    {
        CI.AddToLog("ERROR: UMatchVol::SetCostType(). Parameter out of range D3Cost=%d \n",D3Cost);
       return U_ERROR;
    }
    CT  = D3Cost;
    return U_OK;
}

ErrorType UMatchVol::SetInterType(InterType IntP)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(IntP!=U_NOINTER &&
       IntP!=U_TRILIN &&
       IntP!=U_SLICE) 
    {
        CI.AddToLog("ERROR: UMatchVol::SetInterType(). Parameter out of range IntP=%d \n",IntP);
        return U_ERROR;
    }
    IT = IntP;   
    return U_OK;
}

ErrorType UMatchVol::SetLogBinSize(int logbin)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(logbin<0 || logbin >=6)
    {
        CI.AddToLog("ERROR UMatchVol::UMatchVol(). 2Log(Binsize)  =%d  out of range \n", logbin);
        return U_ERROR;
    }
    LogBinSize = logbin;
    LogNbin    = 8-LogBinSize;
    BinSize    = 1; for(int k=0;k<LogBinSize;k++) BinSize+=BinSize;
    Nbin       = 256/BinSize;
    return U_OK;
}


ErrorType UMatchVol::SetRange(double TransLim, double RotLim, double ScaleLim)
/*
     TransLim in [cm]
     RotLim   in [degree]
 */
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(RTF.SetRange(TransLim,RotLim, ScaleLim)!=U_OK)
    {
        CI.AddToLog("ERROR UMatchVol::SetRange(). Setting parameters ranges.\n");
        return U_ERROR;
    }
    if(RTF.GetNparFree()<=0)
    {
        CI.AddToLog("ERROR UMatchVol::SetRange(). No free parameters remaining.\n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMatchVol::SetLimitRise(double LimitRise)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(LimitRise<=0)
    {
        CI.AddToLog("ERROR: UMatchVol::SetLimitRise(). Parameter out of range: LimitRise = %f \n", LimitRise);
        LimitRise = -LimitRise;
    }
    return RTF.SetLimitRise(LimitRise);
}

UEuler UMatchVol::GetBestEuler(void)
{
    if(this==NULL || error!=U_OK) return UEuler();
    return RTF.GetEuler(GetBestPar()) * XFMinit * UEuler(-CenterFin2);
}
ErrorType UMatchVol::MatchComputeGlobalRot(const UField* InRef, const UField* InXfm, UEuler* Xfm)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalRot(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Xfm==NULL)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalRot(). NULL Transformation.\n");
        return U_ERROR;
    }
    if(TestFields(InRef, InXfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalRot(). Invalid UField-arguments.\n");
        return U_ERROR;
    }
    URestrictTransform RTFold = RTF;
    RTF.SetRange(0., 10000., 1.);
    RTF.SetFreePar(false, true, false, false);

    if(InitCoorTables(InRef, InXfm)!=U_OK)
    {
        RTF = RTFold;
        CI.AddToLog("ERROR UMatchVol::MatchComputeGlobalRot(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }

    int MaxI = Uminimize::GetMaxiter();
    Uminimize::SetMaxiter(-1);    
    InitBestCost();

    Uminimize::SetNParameters(RTF.GetNparFree());
    Uminimize::ResetIterations();

    XFMinit          = (*Xfm) * UEuler(CenterFin2);
    
    double pars[MAXFREELINPAR];
    for(int i=0;i<MAXFREELINPAR;i++) pars[i]=0.;

    if(RTF.GetRestrict2D()==true)
    {
        UEuler XFM;
        for(int rot=0; rot<4; rot++)
        {
            switch(RTF.GetFixedDir()) 
            { 
            case 0: XFM = XFM*UEuler(0.,0.,0.,rot*PI/2,0.,0.); break;
            case 1: XFM = XFM*UEuler(0.,0.,0.,0.,rot*PI/2,0.); break;
            case 2: XFM = XFM*UEuler(0.,0.,0.,0.,0.,rot*PI/2); break;
            }
            RTF.ComputeEulerPars(XFM, pars);
            Uminimize::Cost(pars,0,NULL);
        }
    }
    else
    {
        double rotmat[9]; 
        for(int xr=0; xr<6; xr++)
        {
            rotmat[0]=0; rotmat[1]=0; rotmat[2]=0;

            int xr2     = xr/2;
            rotmat[xr2] = (xr%2) ?  -1. : 1;
            for(int yr=0; yr<4; yr++)
            {
                rotmat[3]=0; rotmat[4]=0; rotmat[5]=0;

                int yr2       = (xr2+1+yr/2) % 3;
                rotmat[3+yr2] = (yr%2) ?  -1. : 1;
                for(int zr=0; zr<2; zr++)
                {
                    rotmat[6]=0; rotmat[7]=0; rotmat[8]=0;

                    int zr2       = (xr2+1) % 3; if(zr2==yr2) zr2 = (xr2+2) % 3;
                    rotmat[6+zr2] = (zr%2) ?  -1. : 1;

                    double det = rotmat[0]*rotmat[4]*rotmat[8] + rotmat[1]*rotmat[5]*rotmat[6] + rotmat[2]*rotmat[3]*rotmat[7]
                               - rotmat[0]*rotmat[5]*rotmat[7] - rotmat[1]*rotmat[3]*rotmat[8] - rotmat[2]*rotmat[4]*rotmat[6];
                    if(det<0) continue;

                    UEuler XFM; XFM.SetRotMatrix(rotmat);
                    RTF.ComputeEulerPars(XFM, pars);
                    Uminimize::Cost(pars,0,NULL);
                }
            }
        }
    }
    Uminimize::SetMaxiter(MaxI);
    DeleteCoorTables();

    *Xfm = RTF.GetEuler(GetBestPar()) * XFMinit * UEuler(-CenterFin2);
    RTF  = RTFold;
    return U_OK;
}
ErrorType UMatchVol::MatchComputeGlobalShift(const UField* InRef, const UField* InXfm, UEuler* Xfm, double Step, double Range)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalShift(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Xfm==NULL)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalShift(). NULL Transformation.\n");
        return U_ERROR;
    }
    if(TestFields(InRef, InXfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeGlobalShift(). Invalid UField-arguments.\n");
        return U_ERROR;
    }

    URestrictTransform RTFold = RTF;
    RTF.SetRange(100000., 0., 1.);
    RTF.SetFreePar(true, false, false, false);

    if(InitCoorTables(InRef, InXfm)!=U_OK)
    {
        RTF = RTFold;
        CI.AddToLog("ERROR UMatchVol::MatchComputeGlobalShift(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }

    if(Step <=0   ) Step  = 1.;
    if(Range<=Step) Range = 1.1*Step;

    int MaxI = Uminimize::GetMaxiter();
    Uminimize::SetMaxiter(-1);    
    InitBestCost();

    Uminimize::SetNParameters(RTF.GetNparFree());
    Uminimize::ResetIterations();

    XFMinit          = (*Xfm) * UEuler(CenterFin2);
    
    double pars[MAXFREELINPAR];
    for(int i=0;i<MAXFREELINPAR;i++) pars[i]=0.;

    if(RTF.GetRestrict2D()==true)
    {
        UEuler XFM;
        for(double s=-Range; s<=Range; s+=Step)
        {
            switch(RTF.GetFixedDir()) 
            { 
            case 0: XFM = UEuler(s ,0.,0.,0.,0.,0.); break;
            case 1: XFM = UEuler(0.,s ,0.,0.,0.,0.); break;
            case 2: XFM = UEuler(0.,0.,s ,0.,0.,0.); break;
            }
            RTF.ComputeEulerPars(XFM, pars);
            Uminimize::Cost(pars,0,NULL);
        }
    }
    else
    {
        for(double z=-Range; z<=Range; z+=Step)
            for(double y=-Range; y<=Range; y+=Step)
                for(double x=-Range; x<=Range; x+=Step)
                {
                    UEuler XFM(x,y,z,0.,0.,0.);
                    RTF.ComputeEulerPars(XFM, pars);
                    Uminimize::Cost(pars,0,NULL);
                }
    }
    Uminimize::SetMaxiter(MaxI);
    DeleteCoorTables();

    *Xfm = RTF.GetEuler(GetBestPar()) * XFMinit * UEuler(-CenterFin2);
    RTF  = RTFold;
    return U_OK;
}

ErrorType UMatchVol::MatchComputeSingleEuler(const UField* InRef, const UField* InXfm, UEuler* Xfm)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeSingleEuler(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Xfm==NULL)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeSingleEuler(). NULL Transformation.\n");
        return U_ERROR;
    }
    if(TestFields(InRef, InXfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeSingleEuler(). Invalid UField-arguments.\n");
        return U_ERROR;
    }

    URestrictTransform RTFold = RTF;
    RTF.SetRange(100000., 100000., 1.);
    RTF.SetFreePar(true, true, false, false);

    if(InitCoorTables(InRef, InXfm)!=U_OK)
    {
        RTF = RTFold;
        CI.AddToLog("ERROR UMatchVol::MatchComputeSingleEuler(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }

    int MaxI = Uminimize::GetMaxiter();
    Uminimize::SetMaxiter(-1);
    ErrorType Result = MatchCompute(InRef, InXfm, Xfm);
    Uminimize::SetMaxiter(MaxI);

    RTF = RTFold;
    return Result;
}
ErrorType UMatchVol::MatchCompute(const UField* InRef, const UField* InXfm, UEuler* Xfm)
{
    if(this==NULL||error!=U_OK)
    {
        CI.AddToLog("ERROR UMatchVol::MatchCompute(). Object not properly initialized.\n");
        return U_ERROR;
    }
    if(Xfm==NULL)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchCompute(). NULL Transformation.\n");
        return U_ERROR;
    }
    if(TestFields(InRef, InXfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchCompute(). Invalid UField-arguments.\n");
        return U_ERROR;
    }
    URestrictTransform RTFold = RTF;

    RTF.SetFreePar(true, true, false, false);

/* Make Look Up tables for coordinates */
    if(InitCoorTables(InRef, InXfm)!=U_OK)
    {
        RTF = RTFold;
        CI.AddToLog("ERROR UMatchVol::MatchCompute(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }
    InitBestCost();

/* adjust translation according to formula (1), add Ac */
    XFMinit = (*Xfm) * UEuler(CenterFin2);
    double pars[MAXFREELINPAR];
    for(int i=0;i<MAXFREELINPAR;i++) pars[i]=0.;

/* Start fitting */
    if(Maxiter>0)  Uminimize::Iterate(pars, RTF.GetNparFree());
    else           Uminimize::Cost(pars,0,NULL);

    DeleteCoorTables();

/* Compensate for the shifted origin*/
/* set the output transform as initial * optimized - BAc (see eq. 2) */

    *Xfm = RTF.GetEuler(pars) * XFMinit * UEuler(-CenterFin2);
    RTF  = RTFold;

    CI.AddToLog("Note: UMatchVol::MatchCompute(). BestCost = %f \n",GetBestCost());
    return U_OK;
}

ErrorType UMatchVol::MatchComputeScale(const UField* InRef, const UField* InXfm, ULinTran* Xfm, bool Iso, int DirFixed)
{
    if(this==NULL||error!=U_OK)
    {
        CI.AddToLog("ERROR UMatchVol::MatchComputeScale(). Object not properly initialized.\n");
        return U_ERROR;
    }
    if(Xfm==NULL)
    {
        CI.AddToLog("ERROR UMatchVol::MatchComputeScale(). No initial transform present.\n");
        return U_ERROR;
    }

/* Test arguments and update Fit2D */
    if(TestFields(InRef, InXfm)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::MatchComputeScale(). Invalid UField-arguments.\n");
        return U_ERROR;
    }

    URestrictTransform RTFold = RTF;
    RTF.SetRange(0., 0., 2.);
    RTF.SetFreePar(false, false, true, Iso);
    RTF.SetFixedDir(DirFixed);

/* Make Look Up tables for coordinates */
    if(InitCoorTables(InRef, InXfm)!=U_OK)
    {
        RTF = RTFold;
        CI.AddToLog("ERROR UMatchVol::MatchComputeScale(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }
    InitBestCost();

/* adjust translation according to formula (1), add Ac */
    XFMinit = (*Xfm);//// * UEuler(CenterFin2);

    double pars[MAXFREELINPAR];
    for(int i=0;i<MAXFREELINPAR;i++) pars[i]=0.;

/* Start fitting */
    if(Maxiter>0)  Uminimize::Iterate(pars, RTF.GetNparFree());
    else           Uminimize::Cost(pars,0,NULL);
    DeleteCoorTables();

/* Compensate for the shifted origin*/
/* set the output transform as initial * optimized - BAc (see eq. 2) */

    *Xfm = RTF.GetLinTran(pars) * XFMinit;//// * UEuler(-CenterFin2);
    RTF  = RTFold;

    CI.AddToLog("Note: UMatchVol::MatchComputeScale(). BestCost = %f \n",GetBestCost());
    return U_OK;
}

ErrorType UMatchVol::MatchCompute(const UField* InRef, const UField* InXfm, UEuler* Xfm, double TransLim, double RotLim, double Limr)
/*
     TransLim in [cm]
     RotLim   in [degree]
 */
{
    RTF.SetFreePar(true, true, false, false);
    RTF.SetRange(TransLim, RotLim, 1.);
    RTF.SetLimitRise(Limr);
    return MatchCompute(InRef, InXfm, Xfm);
}
ErrorType UMatchVol::TestFields(const UField* InRef, const UField* InXfm)
{
    if(InRef==NULL || InRef->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::TestFields(). Invalid or NULL Reference scan.\n");
        return U_ERROR;
    }
    if(InXfm==NULL || InXfm->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatchVol::TestFields(). Invalid or NULL Transformed scan.\n");
        return U_ERROR;
    }
    if(InRef->Getndim()!=InXfm->Getndim())
    {  
        CI.AddToLog("ERROR UMatchVol::TestFields(). Incompatible image dimensions.\n");
        return U_ERROR;
    }
    if(InRef->Getndim() !=3 )
    {  
        CI.AddToLog("ERROR UMatchVol::TestFields(). Both input images should be 3-dimensional.\n");
        return U_ERROR;
    }        
    if(InRef->GetDType() != UField::U_BYTE || InXfm->GetDType() != UField::U_BYTE)
    {
        CI.AddToLog("ERROR UMatchVol::TestFields(). Both input images should be of type byte.\n");
        return U_ERROR;
    }

    if(InRef->GetDimensions(0)<=2 && InXfm->GetDimensions(0)<=2) RTF.SetFixedDir( 0);
    if(InRef->GetDimensions(1)<=2 && InXfm->GetDimensions(1)<=2) RTF.SetFixedDir( 1);
    if(InRef->GetDimensions(2)<=2 && InXfm->GetDimensions(2)<=2) RTF.SetFixedDir( 2);
    else                                                         RTF.SetFixedDir(-1);
    return U_OK;
}

double UMatchVol::ComputeCost(double *vector, int iter, int *CostEr)
{ 
    ULinTran xfm = RTF.GetLinTran(vector) * XFMinit;

    if(Fxfm_compute(xfm) != OK) 
        CI.AddToLog("ERROR UMatchVol::ComputeCost() Error in Field transform \n");

/* calc muin cost */
    double f = 0.;
    if(comp_ami(Npixel, Fin1->GetBdata(), Fout->GetBdata(), &f) != OK)
        CI.AddToLog("ERROR UMatchVol::ComputeCost(). Error in comp_ami (memory allocation) \n");
    f += RTF.GetOutOfRangeCost(vector);

    if(PrintCostToScreen==true) 
        CI.AddToLog("Iter = %d  Cost = %f \n", iter, f);
    return f;
}

#define SCALE  1000.

int UMatchVol::comp_ami(int npixel, unsigned char *p1, unsigned char *p2, double *ami)
{
    int           n,n1,n2,i1,i2,m1,m2;
    double        cost1,cost2,corr;

    *ami   = 0.;
    if(!npixel) return OK;

    memset(his12, 0, sizeof(his12[0])*Nbin*Nbin);
    memset(his1, 0, sizeof(his1[0])*Nbin);            /* row */
    memset(his2, 0, sizeof(his2[0])*Nbin);            /* col */
    memset(total_his12, 0, sizeof(total_his12[0])*256*256);

/* fill hist */
    n = npixel;
    do{ total_his12[*p1++ * 256 + *p2++]++;
    } while (--n);

/* if wanted, delete values=0 */
    for(n=0; n<256; n++)
        total_his12[n<<8]=total_his12[n]=0;

/* compress to crosshist */
    for(n1=0; n1<Nbin; n1++)
        for(n2=0; n2<Nbin; n2++)
        { 
            unsigned int temp = 0;
            for(i2=0; i2<BinSize; i2++)
                for(i1=0; i1<BinSize; i1++)
                    temp += total_his12[256*(n1*BinSize+i1)+n2*BinSize+i2];
            his12[n1*Nbin+n2]=temp;
        }

/* make n1 and col hist */
    for(n1=0; n1<Nbin; n1++)
    {  
        unsigned int temp=0;
        for(n2=0; n2<Nbin; n2++) 
            temp += his12[n1*Nbin+n2];
        his1[n1]=temp;
    }

    unsigned int np = 0;
    for(n2=0; n2<Nbin; n2++)
    {  
        unsigned int temp = 0;
        for(n1=0; n1<Nbin; n1++) 
            temp += his12[n1*Nbin+n2];
        his2[n2] =temp;
        np      +=temp;
    }

/* calc cost */
    switch(CT)
    {
    case 0:
        cost2 = 0;
        for(n1=0; n1<Nbin; n1++)
            for(n2=0; n2<Nbin; n2++)
            {
                double temp = his12[(n1<<LogNbin)+n2];
                if(temp>0) 
                    cost2 += temp*log((double)his1[n1]*(double)his2[n2]/temp);
            }

        if(np) *ami   = cost2/np - log((double)np);
        break;

    case 1:
        cost1 = 0;
        corr  = 0;
        for(n1=0; n1<Nbin; n1++)
            for(n2=0; n2<Nbin; n2++)
            {  
                double temp = his12[(n1<<LogNbin)+n2];
                if(temp>0)
                {
                    double temp2  = temp*temp;
                    cost1 += temp2*log((double)his1[n1]*(double)his2[n2]/temp);
                    corr  += temp2;
                }
            }

        if(np) *ami   = (cost1 - corr*log((double)np))/ np;
        break;

    case 2:
        memset(lut,0,256);
        for(n1=0; n1<Nbin; n1++)
        {
            m1 = n1<<LogNbin;
            m2 = 0;
            n2 = 0;
            for(n=0; n<Nbin; n++)
            {
                m2 += n*his12[m1+n];
                n2 +=   his12[m1+n];
            }
            corr = 0;
            if(n2) corr = m2/n2;

            m1  =   n1<<LogBinSize;
            m2  = int(corr*BinSize);
            for(n=0; n<BinSize; n++) 
                lut[m1+n] = (unsigned char) m2+n;
        }

        *ami = 0.;
        for(n1=0;n1<256;n1++)
        {
            int temp = lut[n1];
            m1       = n1<<8;
            for(n2=0;n2<256;n2++) 
                *ami += total_his12[m1+n2]*(temp-n2)*(temp-n2);
        }
        if(np) *ami = sqrt(*ami/np);
        break;

    case 3:
        cost2 = 0;
        for(n1=0; n1<Nbin; n1++)
            for(n2=0; n2<Nbin; n2++)
            {
                double temp = his12[(n1<<LogNbin)+n2];
                if(temp>0) cost2 += temp*(n1-n2)*(n1-n2);
            }

        if(np) *ami   = cost2/np;
        break;
    }
    return OK;
}


#define MAXINDEX    8192                   /* number of subdivisions of input2         */
#define LOGMAXINDEX   13                   /* 2log( MAXINDEX )                         */
#define MATSCALE_X    64                   /* number of subdivisions used for coordinate fractions in x direction*/
#define MATSCALE_Y   512                   /* number of subdivisions used for coordinate fractions in y direction*/
#define MATSCALE_Z    64                   /* number of subdivisions used for coordinate fractions in z direction*/
#define MS2_Y        256                   /* MATSCALE_Y / 2                            */
#define MS32     1048576                   /* MATSCALE_X*MATSCALE_Y*MATSCALE_Z/2        */
#define LOGMATSCALE_X  6                   /* 2 log( MATSCALE_X )                       */
#define LOGMATSCALE_Y  9                   /* 2 log( MATSCALE_Y )                       */
#define LOGMATSCALE_Z  6                   /* 2 log( MATSCALE_Z )                       */
#define LOGMATSCALE3  21                   /* LOGMATSCALE_X*+OGMATSCALE_Y+LOGMATSCALE_Z */

/************************************************************************/
/*                             MODULE FUNCTIONS                         */
/************************************************************************/

/* This code serves to prepare lookup tables for tracing in a non-uniform
   field or tracing a uniform field with arbitrary step size.
*/

void UMatchVol::fill_ntables(float minx, float maxx, float miny, float maxy,
             float minz, float maxz, int dimx, int dimxy, int inter)

{
/* allocate MAXINDEX+1 entries to allow for full coordinate range */

    xtab = (NTABLE *) malloc((MAXINDEX+2) * sizeof(NTABLE));
    ytab = (NTABLE *) malloc((MAXINDEX+2) * sizeof(NTABLE));
    ztab = (NTABLE *) malloc((MAXINDEX+2) * sizeof(NTABLE));

    xtab++;
    ytab++;
    ztab++;

/* fill tables with index and fraction of coordinates */
    for(int i=0; i<MAXINDEX; i++)
    { 
        float f = float( (i+0.5) / MAXINDEX);

        xtab[i].index    = coord_to_index_x(minx + f*(maxx-minx), rt2);
        xtab[i].fraction = int(frac_x(rt2) * MATSCALE_X);

        ytab[i].index    = coord_to_index_y(miny + f*(maxy-miny), rt2) * dimx;
        ytab[i].fraction = int(frac_y(rt2) * MATSCALE_Y);

        ztab[i].index    = coord_to_index_z(minz + f*(maxz-minz), rt2) * dimxy;
        ztab[i].fraction = int(frac_z(rt2) * MATSCALE_Z);
    }

  /* the following is required to guarantee that the full pixel range, e.g.,
     [xmin..xmax] is valid and that small roundoff errors do not cause
     invalid array references
  */

  xtab[-1].index    = xtab[0].index;
  xtab[-1].fraction = xtab[0].fraction;
  ytab[-1].index    = ytab[0].index;
  ytab[-1].fraction = ytab[0].fraction;
  ztab[-1].index    = ztab[0].index;
  ztab[-1].fraction = ztab[0].fraction;

  xtab[MAXINDEX].index    = xtab[MAXINDEX-1].index;
  xtab[MAXINDEX].fraction = xtab[MAXINDEX-1].fraction;
  ytab[MAXINDEX].index    = ytab[MAXINDEX-1].index;
  ytab[MAXINDEX].fraction = ytab[MAXINDEX-1].fraction;
  ztab[MAXINDEX].index    = ztab[MAXINDEX-1].index;
  ztab[MAXINDEX].fraction = ztab[MAXINDEX-1].fraction;

  /* When not-interpolating, the index points to the nearest pixel */

    if(inter == 0 || inter == 2)
    { 
        for(int i=-1; i<=MAXINDEX; i++)
        { 
            if(xtab[i].fraction >= MATSCALE_X/2) xtab[i].index ++;
            if(ztab[i].fraction >= MATSCALE_X/2) ztab[i].index += dimxy;
        }
    }

  /* Interpolate mode 2 interpolates along y axis only */

    if(inter == 0)
    { 
        for(int i=-1; i<=MAXINDEX; i++)
            if (ytab[i].fraction >= MATSCALE_X/2) ytab[i].index += dimx;
    }
}

/* Use this routine to free the non-uniform image lookup tables */
void UMatchVol::free_ntables(void)
{ 
    xtab--; free(xtab); xtab = NULL;
    ytab--; free(ytab); ytab = NULL;
    ztab--; free(ztab); ztab = NULL;
}


/* Table driven tracer/resampler for byte fields.

   The global tables xtab, ytab and ztab contain MAXINDEX+1 entries across the
   whole image and should be prepared prior to this loop using the routine
   fill_ntables. For non-interpolating modes, the table should already contain
   the required half pixel shift.

   arguments:
   count        = number of steps to trace. NO OVERFLOW CHECKING PERFORMED
   (dx, dy, dz) = ray step size and direction in same units as (x, y, z).
   (x, y, z)    = ray start point in units of MAXINDEX^2 times whole image
   dimx, dimxy  = dimensions of image (dimz is not needed)
   bp           = pointer to data of input field [0,0,0]
   inter        = interpolation on/off/half
   out          = pointer to output array (must store count elements)
*/

void UMatchVol::btrace(int count, int dx, int dy, int dz, int x, int y, int z,
        int dimx, int dimxy,
        unsigned char *in, int inter, unsigned char *out, unsigned char *in1)


{ 
    int xf, yf, zf, indx;
    int i;
    int i000,i001,i010,i011,i100,i101,i110,i111;
    int z00,z01,z10,z11,y0,y1,x0;

    out--;
    x -= dx;
    y -= dy;
    z -= dz;
    switch (inter)
    { 
    case 0: /* Non-interpolated */
        for(i=0; i<count; i++)
        {
            x += dx;
            y += dy;
            z += dz;
            out++;
            if (!in1[i]) continue;

            p = &xtab[(x >> LOGMAXINDEX)];
            q = &ytab[(y >> LOGMAXINDEX)];
            r = &ztab[(z >> LOGMAXINDEX)];

            indx = p->index + q->index + r->index;
            *out  = in[indx];
        }
        break;

    case 1: /* do full interpolation */
        for(i=0; i<count; i++)
        {
            x += dx;
            y += dy;
            z += dz;
            out++;
            if(!in1[i]) continue;

            p = &xtab[(x >> LOGMAXINDEX)];
            q = &ytab[(y >> LOGMAXINDEX)];
            r = &ztab[(z >> LOGMAXINDEX)];

            indx = p->index + q->index + r->index;

            i000  = in[indx];
            i001  = in[indx+1];
            i010  = in[indx+dimx];
            i011  = in[indx+dimx+1];
            i100  = in[indx+dimxy];
            i101  = in[indx+dimxy+1];
            i110  = in[indx+dimx+dimxy];
            i111  = in[indx+dimxy+dimx+1];

            if(i000||i001||i010||i011||i100||i101||i110||i111)
            {
                xf  = p->fraction;
                yf  = q->fraction;
                zf  = r->fraction;

                z00 = (i000<<LOGMATSCALE_Z) + zf*(i100-i000);
                z01 = (i001<<LOGMATSCALE_Z) + zf*(i101-i001);
                z10 = (i010<<LOGMATSCALE_Z) + zf*(i110-i010);
                z11 = (i011<<LOGMATSCALE_Z) + zf*(i111-i011);

                y0  = (z00<<LOGMATSCALE_Y)  + yf*(z10-z00);
                y1  = (z01<<LOGMATSCALE_Y)  + yf*(z11-z01);

                x0  =((y0<<LOGMATSCALE_X)   + xf*(y1-y0)  + MS32 )>> LOGMATSCALE3;

                if (x0 > 0) *out = x0;
            }
        }
        break;

    case 2:  /* interpolate in Y direction only */
        for(i=0; i<count; i++)
        {
            x += dx;
            y += dy;
            z += dz;
            out++;
            if (!in1[i]) continue;

            p = &xtab[(x >> LOGMAXINDEX)];
            q = &ytab[(y >> LOGMAXINDEX)];
            r = &ztab[(z >> LOGMAXINDEX)];

            indx = p->index + q->index + r->index;
            i000  = in[indx];
            i010  = in[indx+dimx];

            if(i000||i010)
            {
                yf    = q->fraction;
                x0    = ((i000 << LOGMATSCALE_Y) + yf*(i010-i000) + MS2_Y) >> LOGMATSCALE_Y;

                if (x0 > 0) *out = x0;
            }
        }
        break;

    default: break;
    }
}


/* Compute function that forms outer wrapper for tracing resampler */

int UMatchVol::Fxfm_compute(UEuler xfm)
{
    return Fxfm_compute(ULinTran(xfm));
}
int UMatchVol::Fxfm_compute(ULinTran xfm)
{ 
    double ax, bx, ay, by, az, bz;
    double dxp, dyp, dzp;
    double p, q;

    int   x1, y1, z1, x2, y2, z2;
    int   idx, idy, idz;
    int   first;

    int   count2;

    xfm.Invert();

    int xend  = Fin1->GetDimensions(0);
    int yend  = Fin1->GetDimensions(1);
    int zend  = Fin1->GetDimensions(2);

    int dimx  = Fin2->GetDimensions(0);           /* dimensions for input field */
    int dimy  = Fin2->GetDimensions(1);
    int dimz  = Fin2->GetDimensions(2);

/* calculate limits of input2 volume */
    double xlow  = index_to_coord_x(0, rt2);
    double ylow  = index_to_coord_y(0, rt2);
    double zlow  = index_to_coord_z(0, rt2);

    double xhigh = index_to_coord_x(dimx-1, rt2);
    double yhigh = index_to_coord_y(dimy-1, rt2);
    double zhigh = index_to_coord_z(dimz-1, rt2);

/* Compute pixel size in cm per step in xtab, ytab and ztab */
    double xpixel = (xhigh - xlow) / MAXINDEX;
    double ypixel = (yhigh - ylow) / MAXINDEX;
    double zpixel = (zhigh - zlow) / MAXINDEX;

/* determine which coordinates to loop and which line is traced */
    unsigned char* out  =  Fout->GetBdata()  - xend;
    unsigned char* in1  =  Fin1->GetBdata()  - xend;

/* calculate tranformed direction of ray in input coordinates (is constant) */
    UVector3 t(index_to_coord_x(xend-1, rt1) - index_to_coord_x(0, rt1), float(0.),float(0.));
    t        =  xfm.xfm(t, true);
    

    double dx = t.Getx();
    double dy = t.Gety();
    double dz = t.Getz();

/* loop lines in output field */
    int   x, y, z;

    for(z=0; z<zend; z++)
        for(y=0; y<yend; y++)
        {

/* pre-clear the output row because not all pixels might be reached */
            out += xend;
            memset(out, 0, xend);

/* get first point of line in output coordinates           */
/* JDM: Skip zero line in x-direction in input1            */
            in1 += xend;
            for(x=0;x<xend;x++) if(in1[x]) break;
            if(x==xend) continue;               /* All points are zero: nothing to do */

            x  = 0;
            UVector3 org(index_to_coord_x(x, rt1), index_to_coord_y(y, rt1), index_to_coord_z(z, rt1)); 

/* transform first point to input coordinates */
            org   = xfm.xfm(org);

/* intersect ray with calculation volume; WATCH OUT for 0 dx etc */
            if(fabs(dx) > 0.00001)
            {  
                ax = (xhigh - org.Getx()) / dx;
                bx = (xlow  - org.Getx()) / dx;
            }
            else
            {  
                ax = (xhigh - org.Getx()) * 100000;
                bx = (xlow  - org.Getx()) * 100000;
            }
            if(ax > bx) { double t=ax; ax=bx; bx=t; }

            if(fabs(dy) > 0.00001)
            {  
                ay = (yhigh - org.Gety()) / dy;
                by = (ylow  - org.Gety()) / dy;
            }
            else
            {  
                ay = (yhigh - org.Gety()) * 100000;
                by = (ylow  - org.Gety()) * 100000;
            }
            if(ay > by) { double t=ay; ay=by; by=t; }

            if(fabs(dz) > 0.00001)
            {  
                az = (zhigh - org.Getz()) / dz;
                bz = (zlow  - org.Getz()) / dz;
            }
            else
            {  
                az = (zhigh - org.Getz()) * 100000;
                bz = (zlow  - org.Getz()) * 100000;
            }
            if(az > bz) { double t=az; az=bz; bz=t; }

/* find first position within cube */
            p = ax;
            if(ay > p) p = ay;
            if(az > p) p = az;

/* find last position within cube */
            q = bx;
            if(by < q) q = by;
            if(bz < q) q = bz;

/* test if line does not intersect volume */
            if (p >= 1.0 || q <= 0.0) continue;

/* test if ray needs to be clipped to stay in output field */
/* Note: p/q correspond to start/end points, e.g., 0/xend-1 in the output row */

            if(p <= 0.000001)                   /* left of output row is starting pount */
            {  
                first = 0;
                p     = 0.0;
            }
            else                                /* intersection with input volume is start point */
            { 
                first = int(p * (xend-1) + 1);    /* start point rounded up                        */
                p     = (double)first/(xend-1);   /* adjust p to correspond to exact start point   */
            }

            if(q > 0.999999)                    /* right of output row is starting point */
            {  
                count2 = xend - first;
                q      = 1.0;
            }
            else                                          /* intersection with input volume is end point */
            {  
                count2 = int((q - p) * (xend-1) + 1);       /* rounded down but + 1 to get xend            */
                q      = p + (double) (count2-1)/(xend-1);  /* adjust q to exact end point                 */
            }
            if(count2< 1) continue;           /* nothing to do */

/* calculate first and last point in volume in 2log(MAXINDEX) units */

            x1 = int(MAXINDEX * (org.Getx() + p * dx - xlow) / xpixel + 0.5);
            y1 = int(MAXINDEX * (org.Gety() + p * dy - ylow) / ypixel + 0.5);
            z1 = int(MAXINDEX * (org.Getz() + p * dz - zlow) / zpixel + 0.5);

            x2 = int(MAXINDEX * (org.Getx() + q * dx - xlow) / xpixel + 0.5);
            y2 = int(MAXINDEX * (org.Gety() + q * dy - ylow) / ypixel + 0.5);
            z2 = int(MAXINDEX * (org.Getz() + q * dz - zlow) / zpixel + 0.5);

/* get stepsize in integer for further use */
            if(count2 > 1)
            {  
                dxp = (double)(x2 - x1) / (count2-1);
                dyp = (double)(y2 - y1) / (count2-1);
                dzp = (double)(z2 - z1) / (count2-1);
            }
            else
                dxp = dyp = dzp = 0;

            idx = dxp > 0 ? int(dxp+0.5) : int(dxp-0.5);
            idy = dyp > 0 ? int(dyp+0.5) : int(dyp-0.5);
            idz = dzp > 0 ? int(dzp+0.5) : int(dzp-0.5);


/* JDM: Skip zero pixels */
            for(x=0;x<count2;x++) if(in1[first+x]) break;
            if(!x)
            {  
                x1     += x*idx;
                y1     += x*idy;
                z1     += x*idz;
                count2 -= x;
                first  += x;
            }
            if(count2< 1) continue;

            for(x=xend-1;x>=0;x--) if(in1[x]) break;
            x++;
            if(x<first+count2) count2= x-first;
            if(count2<1) continue;

            btrace(count2, idx, idy, idz, x1, y1, z1, dimx, dimx*dimy, Fin2->GetBdata(), IT, out+first, in1+first);
        }
    return 1;
}

ErrorType UMatchVol::SetDefaults(void)
{
    p = q = r = xtab = ytab = ztab = NULL;

    Fin1   = Fin2   = Fout   = NULL;

    RTF = URestrictTransform();
    RTF.SetRange(10.,20.,1.);
    SetCostType(U_MUTIN2);
    SetInterType(U_TRILIN);
    SetLogBinSize(2);

    PrintCostToScreen = false;
    Npixel            = 0;

/* Allocate arrays for comp_ami */
    his1        = new unsigned int[256];
    his2        = new unsigned int[256];
    his12       = new unsigned int[256*256];
    total_his12 = new unsigned int[256*256];
    lut         = new unsigned char[256];
    if(his1==NULL||his2==NULL||his12==NULL||total_his12==NULL||lut==NULL)
    {
        CI.AddToLog("ERROR UMatchVol::SetDefaults(). Unable to allocate memory for histograms. \n");
        delete[] his1;          his1        = NULL;
        delete[] his2;          his2        = NULL;
        delete[] his12;         his12       = NULL;
        delete[] total_his12;   total_his12 = NULL;
        delete[] lut;           lut         = NULL;
        return U_ERROR;
    }
    return U_OK;
}

const UString& UMatchVol::GetProperties(UString Comment) const
{    
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMatchVol-object\n");
        return Properties;
    }
    Properties  =  UString();
    
    switch(CT)
    {
    case U_MUTIN : Properties += UString("COST      = MutualInformation\n");           break;
    case U_MUTIN2: Properties += UString("COST      = AlternateMutualInformation \n"); break;
    case U_RMSADJ: Properties += UString("COST      = AdjustedRMS \n");                break;
    case U_RMS:    Properties += UString("COST      = RMS \n");                        break;
    }
    switch(IT)
    {
    case U_NOINTER: Properties += UString("INTERPOLATION = NoInterploation \n"); break;
    case U_TRILIN : Properties += UString("INTERPOLATION = TriLinear \n");       break;
    case U_SLICE  : Properties += UString("INTERPOLATION = SliceDirection \n");  break;
    }
    Properties += UString(LogBinSize,"LOGBINSIZE = %d \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');  
    else                                      Properties.InsertAtEachLine(Comment);

    Properties += RTF.GetProperties(Comment + "   ");
    return Properties;
}

ErrorType UMatchVol::InitCoorTables(const UField* InRef, const UField* InXfm)
{
    Fin1     = InRef; 
    Fin2     = InXfm;
    delete Fout; Fout = new UField(*Fin1);
    if(Fout==NULL || Fout->GetError()!=U_OK)
    {
        delete Fout; Fout = NULL;
        CI.AddToLog("ERROR UMatchVol::InitCoorTables(). Cannot allocate memory for intermediate field.\n");
        return U_ERROR;
    }    
    Npixel  = Fin1->GetNpoints();

    /* Make Look Up tables for coordinates */
    AVSfield AVSin1 = InRef->GetAVSfield();
    if(!make_rtables(&AVSin1, &rt1, 1))
    {
        CI.AddToLog("ERROR UMatchVol::InitCoorTables(). Unable to make coordinate look up tables 1. \n");
        return U_ERROR;
    }
    if(!rt1.ux) CI.AddToLog("WARNING UMatchVol::InitCoorTables(). Output X coordinate forced to uniform.\n");

    
/* Shift the coordinates of the transformed field */
    CenterFin2      = InXfm->GetCenter(true);
    UField*  Fin2a  = new UField(*InXfm, true);
    if(InXfm==NULL || InXfm->GetError()!=U_OK)
    {
        delete InXfm;
        CI.AddToLog("ERROR UMatchVol::InitCoorTables(). Unable to create intermediate UField()-object. \n");
        return U_ERROR;
    }
    Fin2a->ShiftCoords(-CenterFin2);

    AVSfield AVSin2a = Fin2a->GetAVSfield();
    if(!make_rtables(&AVSin2a, &rt2, 1))     /* lookup tables for input field */
    {
        delete Fin2a;
        CI.AddToLog("ERROR UMatchVol::InitCoorTables(). Unable to make coordinate look up tables 2");
        return U_ERROR;
    }
    delete Fin2a;

/* create lookup tables for coordinates in input field */
    fill_ntables(index_to_coord_x(0,rt2), index_to_coord_x(Fin2->GetDimensions(0)-1,rt2),
                 index_to_coord_y(0,rt2), index_to_coord_y(Fin2->GetDimensions(1)-1,rt2),
                 index_to_coord_z(0,rt2), index_to_coord_z(Fin2->GetDimensions(2)-1,rt2),
                 InXfm->GetDimensions(0), InXfm->GetDimensions(0)*InXfm->GetDimensions(1), IT);                    
    return U_OK;
}
ErrorType UMatchVol::DeleteCoorTables(void)
{
    free_rtables(&rt2); 
    free_rtables(&rt1);
    free_ntables();
    return U_OK;
}
