#ifndef _MATCHVOL_INCLUDED
#define _MATCHVOL_INCLUDED

/*
  Update history
  
  Who    When       What
  JdM    30-12-06   Adapted include file to new directory structure
*/

#include"Minimize.h"
#include"RestrictTransform.h"
#include"String.h"

#include"avscoor_AVL.h"


class UField;

class DLL_IO UMatchVol : public Uminimize
{
public:
    enum InterType{U_NOINTER,       // No interpolation
                   U_TRILIN,        // Three lineair interpolation
                   U_SLICE};        // Interpolate in slice direction

    enum CostType {U_MUTIN,         // Mutual Information, true
                   U_MUTIN2,        // Mutual Information, erroneous formulas
                   U_RMSADJ,        // RMS-error with adjusted look up table
                   U_RMS};          // Normal RMS error

    UMatchVol();
    UMatchVol(InterType IntP, CostType D3Cost, int logbin, const UCostminimize& CMpar);
    ~UMatchVol();

    ErrorType            GetError(void) const {return error;}

    ErrorType            MatchComputeSingleEuler(const UField* InRef, const UField* InXfm, UEuler* Xfm);
    ErrorType            MatchComputeGlobalShift(const UField* InRef, const UField* InXfm, UEuler* Xfm, double Step, double Range);
    ErrorType            MatchComputeGlobalRot(const UField* InRef, const UField* InXfm, UEuler* Xfm);
    ErrorType            MatchCompute(const UField* InRef, const UField* InXfm, UEuler* Xfm);
    ErrorType            MatchCompute(const UField* InRef, const UField* InXfm, UEuler* Xfm, double TransLim, double RotLim, double Limr);
    ErrorType            MatchComputeScale(const UField* InRef, const UField* InXfm, ULinTran* Xfm, bool Iso, int DirFixed);
   
    void                 SetPrintCostToScreen(bool PCTS) {PrintCostToScreen = PCTS;}
    const UString&       GetProperties(UString Comment) const;

    CostType             GetCostType(void) const      {return CT;};
    InterType            GetInterType(void) const     {return IT;};
    int                  GetLogBinSize(void) const    {return LogBinSize;}

    int                  GetNbin(void) const          {return Nbin;}
    const unsigned int*  GetCrossHistgram(void) const {return his12;}
    
    ErrorType            SetCostType(CostType D3Cost);
    ErrorType            SetInterType(InterType IntP);
    ErrorType            SetLogBinSize(int logbin);
    ErrorType            SetRange(double TransLim, double RotLim, double ScaleLim);
    ErrorType            SetLimitRise(double LimitRise);

    double               GetMaxTra(void) const {return RTF.GetMaxTra();}
    double               GetMaxRot(void) const {return RTF.GetMaxRot();}
    UEuler               GetBestEuler(void);

private:
    ErrorType            error;
    static UString       Properties;

    CostType             CT;          // (global_3D_cost)
    InterType            IT;          // (global_interpolate)
    int                  LogBinSize;  // (global_logbins)
    URestrictTransform   RTF;         // Object to convert free parameters into transformations

    UEuler               XFMinit;     // initial transform

    struct RTABLES       rt2;
    struct RTABLES       rt1;

    typedef struct 
    { 
        int index;
        int fraction;
    }   NTABLE;
    NTABLE *p, *q, *r, *xtab, *ytab, *ztab;

    bool                 PrintCostToScreen;
    const UField*        Fin1;        // Input image, used as reference
    const UField*        Fin2;        // Input image which is transformed, in order to compare it to Fin1
    UField*              Fout;        // Last transformed Fin2
    UVector3             CenterFin2;  // "Gravity point" of the transformed image

    int                  LogNbin;     // (global_lognbin)
    int                  BinSize;     // (global_bsize)
    int                  Nbin;        // (global_nbin)
    int                  Npixel;      // (global_npixel)
    
/* Histograms used by comp_ami */
    unsigned int         *his1;        // Histogram of input1
    unsigned int         *his2;        // Histogram of input2
    unsigned int         *his12;       // Cross histogram of input1 and input2
    unsigned int         *total_his12; // Cross histogram of input1 and input2
    unsigned char        *lut;         // Look up-table

    int                  comp_ami(int npixel, unsigned char *p1, unsigned char *p2, double *ami);
    void                 btrace(int count, int dx, int dy, int dz, int x, int y, int z, int dimx, int dimxy,
                                unsigned char* in, int inter, unsigned char* out, unsigned char* in1);
    int                  Fxfm_compute(ULinTran xfm);
    int                  Fxfm_compute(UEuler xfm);

    ErrorType            SetDefaults(void);

    ErrorType            InitCoorTables(const UField* InRef, const UField* InXfm);
    ErrorType            DeleteCoorTables(void);
    void                 fill_ntables(float minx, float maxx, float miny, float maxy,
                                      float minz, float maxz, int dimx, int dimxy, int inter);
    void                 free_ntables(void);

    ErrorType            TestFields(const UField* InRef, const UField* InXfm);
    double               ComputeCost(double *par, int iter, int *CostEr);
};

#endif// _MATCHVOL_INCLUDED
