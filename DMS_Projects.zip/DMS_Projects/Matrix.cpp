/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  FB     26-11-03   creation
  FB     14-01-04   Added: GetSingValues(), GetPseudoInverse and Augment() and some bug fixes
  FB     27-02-04   Bug fix: GetPseudoInverse(nEigen): no more than nEigen eigenvalues taken into account 
  FB     22-03-05   Disable language extensions (for-loops) for compatability with Linux C++
  FB     08-04-05   Added operator* and operator*=
  FB     19-04-05   Added GetSingValue(int)
  FB     27-01-06   Bug Fix: Delete thisM in operator *=.
  JdM    20-11-07   Changed order of include files for OpenWatcom compatibility (system includes first)
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
                    Remove (obsolete) DeleteMembers()
  JdM    29-12-13   Completely updated interface to UMatrix-object
  JdM    03-01-14   Many combinations tested with TestMatrix.cpp 
  JdM    01-02-14   Added SetData()
  JdM    24-02-14   Added and tested GetMTAT(). Added GetDiagonal()
  JdM    02-03-14   Removed GetInverse()
  JdM    04-03-14   Added GetMatMul(), Removed obsolete functions like GetAM(), GetMA(), GetAMT(), GetMTA(), GetMTAT(), GetMTAT()
  JdM    09-03-14   Added InvertSqrt()
  JdM    23-03-14   Added GetL2NormSolution()
  JdM    09-05-14   Added (virtual) SetDataRandom()
  JdM    10-05-14   Made SetDataRandom() and SetData() virtual
  JdM    11-05-14   Matrix constructor. Set MT=U_MAT_SYMMETRIC when Matrix==NULL
  JdM    15-05-14   Added GetRowProduct()
  JdM    31-05-14   Bug Fix: GetSelection(), UMatrix::operator*=(). Set proper MatrixType
                    Bug Fix: dd 11-05-14. UMatrix(double*, int, int). Set MT U_MAT_SQUARE  or U_MAT_GENERAL. Let user determine whether U_MAT_SYMMETRIC is possible
  JdM    20-06-14   Added GetFrobNorm2Col(), GetFrobNormCol(), GetColSum() and GetColSum()
                    Added DeMeanRows(), NormalizeCols(), DeMeanCols()
                    Added GetColMax() and GetRowMax()
                    Added New GetMatMul(), with term selection.
  JdM    22-06-14   Added Select constructor
                    Added InsertZeroRows()
  JdM    05-07-14   Added GetColProduct()
                    Bug Fix: GetFrobNormCol().
  JdM    09-07-14   Added UFileName() constructor
                    BUG FIX DeMeanRows().
  JdM    12-07-14   Added GetAbsNorm()
  JdM    19-07-14   Added GetTraceM1M2T()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    26-08-14   Added SetElement(), GetSIGN()
  JdM    28-08-14   Added operator-()
  JdM    08-11-14   Added GetBitMap() and GetMaxElem(), GetMinElem()
  JdM    24-12-14   GetMMT(), GetMTM. Added column, row selection parameter
  JdM    29-12-14   Added operator^() and operator^=()  (Hadamard products)
  JdM    30-12-14   Added MaximizeElements(), GetSubThresholdElements() and new GetColProduct() (with row selection)
  JdM    31-12-14   Added SetRangeElements(), and GetInRangeElements()
  JdM    02-01-15   bug fix GetColProduct(). Testing NULL-ness of M2.Data member was not done
                    Added SetDataGaussian().
  JdM    18-01-15   Added SelectRowCol() and double* based selection constructors
  JdM    19-01-15   Added general const float* constructors
  JdM    25-01-15   Renamed GetConcatCollumns() as GetConcatRows() (Rows of both matrices are concatenated)
                    Added new GetConcatCollumns() and concatenation constructor
                    Added GetRow() and GetCollumn() and GetFrobNormRowDiag()
  JdM    28-01-15   Added generalized GetMatMul()
                    Added UField constructor
  JdM    30-01-15   Added UVector3 constructors
 JD/JdM  10-03-15   Bug Fix: GetRow(). Validity output matrix object creation was not properly tested (it always gave error condition).
  JdM    21-03-15   Added WindowType diagonal matrix constructor
                    Added MergeRows() and MergeCols()
  JdM    04-04-15   Added AreElementsNonNegative()
                    Added operator+=(double) and operator-=(double) and operator+(double)
  JdM    05-04-15   Added GetNNonZeroElements()
  JdM    07-04-15   BUG FIX: ApplyFunction(). In case of MT==U_MAT_SYMMETRIC the function was applied twice.
  JdM    18-04-15   Added GetNSubThreshholElements()
  JdM    15-08-15   Renamed U_MAT_EMPTY to U_MAT_NULL, added U_MAT_UNKOWN, added IsEmpty()
                    Added FILE* constructor and WriteBinary()
  JdM    29-08-15   DeMeanCols() and DeMeanRows(). Added parameters indicating to skip ans set zerospecific rows/collumns.
                                                   return U_ERROR for diagonal matrices.
  JdM    29-08-15   Added SetRow() and SetCol(). Reimplement ForceGeneralType()
                    Added GetRowSelection(), ReshapeCols() and SetData()
                    MergeRows(), MergeCols(). Made exceptions for Empty matrices
  JdM    05-09-15   Added GetDiagonalAsColVec()
  JdM    16-09-15   Added another, UMatrix based, SetRow() and SetCol()
  JdM    17-09-15   GetRowSelection(). Made first argument const.
  JdM    21-09-15   Bug Fix: DeMeanRows(), DeMeanCols(). Some bugs were introduced on 29-08-15
  JdM    10-10-15   Added sparse matrix constructor
  JdM    13-10-15   Added UMatrix::operator/(const double)
  JdM    23-12-15   Added another WriteBinary() and double** constructor
                    Bug Fix. UMatrix(FILE* fpIn). Testing matrix dimensions (used = instead of ==)
                    Bug Fix. NormalizeRows(). Function always returned U_ERROR.
  JdM    15-03-16   Added a few diagonal constructors.
                    Added SetUnitVector(), SetUnitVectors() and SetPolynomials()
  JdM    20-03-16   Added GetBlock() and SetBlock(), removed GetSelection()
  JdM    27-03-16   BUG FIX: UMatrix::operator*=(). Matrix multiplication was skipped in case MT==U_MAT_IDENTCONST
  JdM    15-04-16   BUG FIX: UMatrix::operator*=(). Same as 27-03-16. Matrix multiplication was skipped in case MT==U_MAT_IDENTCONST
                    BUG FIX: SetBlock(), in case argument was U_MAT_DIAGONAL only first element was copied
                    BUG FIX: ForceGeneralType(). In case of DiagonalType()==true, wrong elements were addressed
  JdM    16-04-16   SetBlock(). Test for NULL data pointer of argument.
  JdM    16-04-16   BUG FIX: UMatrix::operator*=(). Same as 27-03-16. Wrong multiplication in case MT==U_MAT_IDENTCONST
  JdM    26-04-16   Added ReverseRows() and ReverseCols()
  JdM    11-05-16   Added GetElasticNetSolution() and GetLassoNetSolution()
  JdM    21-05-16   Added PrintToLog()
  JdM    06-06-16   Added Shrink()
  JdM    19-06-16   SetElement(). Reimplemented Diagonal case
  JdM    22-06-16   Added AddElement()
  JdM    25-06-16   Added GetVTMV()
  JdM    26-06-16   BUG FIX Shrink()
  JdM    21-07-16   Added operator*(double f, const UMatrix& M)
  JdM    24-07-16   Added MergeCols(const double*, const double*, const double*, int)
  JdM    25-07-16   Added GetMixedRowNorm() and ShrinkRows()
  JdM    11-09-16   Added CopyCol()
  JdM    28-12-16   BUG FIX: DeMeanCols() and DeMeanRows(). Used if(Nskip=0) instead of if(Nskip==0)
  JdM    01-01-17   Added GetRDM() and GetADM()
  JdM    30-01-17   Added AddBlock() and SubtractBlock()
                    BUG fixed SetBlock(), case of two diagonal matrices was not working in case of col==row
  JdM    31-01-17   Added SwapCols() and SwapRows()
  JdM    03-02-17   Added AdaptDiagonalToConstantEigenvector()
  JdM    05-02-17   Added GetVarianceDifMat()
  JdM    12-02-17   Added WriteTxt()
  JdM    08-07-17   Added GetDistMatMMT()
  JdM    09-07-17   Added GetNColSubThreshold()
  JdM    30-08-17   Added ApplySquareRoot(), ApplyAbs() and ApplyInverse()
  JdM    15-02-18   BUG FIX: GetMMT(). Completing symmetric part: A[i1*Nrow+i2] = A[i2*Nrow+i1]; (it was A[i1*Nrow+i2] = A[i2*Ncol+i1];) Before 12-02-17 this BUG was absent.
  JdM    29-03-18   Added new (constant) constructor
  JdM    19-04-18   Added GetRelErrorMat()
  JdM    22-04-18   Added AddTransposed(), GetSum() and MinimizeElements()
  JdM    06-05-18   Added GetNormalizedDistanceMatrix()
  JdM    24-05-18   Added GetNormalizedDistanceMatrix() (float version)
  JdM    25-05-18   GetNormalizedDistanceMatrix(). Use uint64_t to avoid integer overflow
  JdM    27-05-18   Added GetColMeadian(), GetRowMedian()
  JdM    04-06-18   Added GetColMin() and GetRowMin()
  JdM    07-07-18   Added SubstractCol() and SubstractRow()
                    NormalizeRows() and NormalizeCols(): added default parameters.
*/

#include <string.h>

#include "Matrix.h"
#include "MatrixSymmetric.h"
#include "MatrixSparse.h"
#include "Field.h"
#include "FileName.h"
#include "Random.h"
#include "SortSemiSort.h"
#include "AnalyzeLine.h"
#include "ElasticNet.h"


const char*  UMatrix::HEADERBEGIN = "Matrix1.0";
const char*  UMatrix::HEADEREND   = "MatrixEnd";
UString      UMatrix::Properties  = UString();

const char* GetMatrixTypeText(MatrixType MT)
{
    switch(MT)
    {
    case U_MAT_NULL      : return "EmptyMatrix";
    case U_MAT_IDENTITY  : return "IdentityMatrix";
    case U_MAT_IDENTCONST: return "ConstantIdentityMatrix";
    case U_MAT_DIAGONAL  : return "DiagonalMatrix";
    case U_MAT_SYMMETRIC : return "SymmetricMatrix";
    case U_MAT_SQUARE    : return "SquareMatrix";
    case U_MAT_GENERAL   : return "GeneralMatrix";
    case U_MAT_UNKNOWN   : return "UnknownMatrixType";
    }
    return "UnknownMatrixType";
};

MatrixType GetMatrixType(int itype)
{
    switch(itype)
    {
    case 0: return U_MAT_NULL;
    case 1: return U_MAT_IDENTITY;
    case 2: return U_MAT_IDENTCONST;
    case 3: return U_MAT_DIAGONAL;
    case 4: return U_MAT_SYMMETRIC;
    case 5: return U_MAT_SQUARE;
    case 6: return U_MAT_GENERAL;
    case 7: return U_MAT_UNKNOWN;   
    }
    CI.AddToLog("ERROR: GetMatrixType(). Invalid argument (%d)\n", itype);
    return U_MAT_UNKNOWN;
}

void UMatrix::SetAllMembersDefault(void)
{
    Data       = NULL;
    MT         = U_MAT_NULL;
    Nrow       = 0;
    Ncol       = 0;
    error      = U_OK;
    Properties = UString();
}
void UMatrix::DeleteAllMembers(ErrorType E)
{
    delete[] Data;
    SetAllMembersDefault();
    error = E;
}

UMatrix::UMatrix()
{
    SetAllMembersDefault();
}
UMatrix::UMatrix(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UMatrix::UMatrix(const UMatrix& Matrix)
{   
    SetAllMembersDefault();
    *this = Matrix;
}
UMatrix::UMatrix(const UMatrixSparse& MS)
{   
    SetAllMembersDefault();
    if(&MS==NULL || MS.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). NULL or erroneous sparse matrix argument.\n");
        return;
    }
    Nrow = MS.GetNrow();
    Ncol = MS.GetNcol();
    if(Nrow==0 && Ncol==0) return;
    if(Nrow<=0 || Ncol<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Sparse matrix has wrong Nrow (%d) or Ncol (%d).\n", Nrow, Ncol);
        return;
    }
    Data = MS.GetMatrixFull();
    if(Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Getting full matrix from argument, Nrow = %d, Ncol = %d.\n", Nrow, Ncol);
        return;
    }
    if(MS.IsSymmetric()==true) MT = U_MAT_SYMMETRIC;
    else                       MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
}
UMatrix::UMatrix(int nDim)
/* 
   Identity constructor
 */
{
    SetAllMembersDefault();
    if(nDim<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(int). Invalid Argument.\n");
        return;        
    }

    if(nDim==0) return;

    MT         = U_MAT_IDENTITY;
    Nrow       = nDim;
    Ncol       = nDim;
    Data       = new double[1];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    Data[0]    = 1.;
}
UMatrix::UMatrix(double Elem, int nR, int nC)
{
    SetAllMembersDefault();
    if(nR<=0 || nC<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, int). Invalid Argument(s), nR=%d, nC=%d.\n", nR, nC);
        return;
    }
    Nrow = nR;
    Ncol = nC;
    if(Elem==0.)
    {
        MT = U_MAT_NULL;
        return;
    }
    Data = new double[Nrow*Ncol];
    if(Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, int). Memory allocation, nR=%d, nC=%d.\n", nR, nC);
        return;
    }
    for(int k=0; k<Nrow*Ncol; k++) Data[k] = Elem;
    MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
}
UMatrix::UMatrix(double Diag, int nDim)
{
    SetAllMembersDefault();
    if(nDim<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int). Invalid Argument.\n");
        return;        
    }

    if(nDim==0) return;
    if(Diag==0.)
    {
        Nrow = Ncol = nDim;
        MT   = U_MAT_NULL;
        return;
    }
    MT         = Diag==1. ? U_MAT_IDENTITY : U_MAT_IDENTCONST;
    Nrow       = nDim;
    Ncol       = nDim;
    Data       = new double[1];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    Data[0]    = Diag;
}
UMatrix::UMatrix(double Diag0, int ndim0, double Diag1, int ndim1)
{
    SetAllMembersDefault();
    if(ndim0<0 || ndim1<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, double, int). Invalid Argument(s).\n");
        return;        
    }

    if(ndim0==0) 
    {
        *this = UMatrix(Diag1, ndim1);
        return;
    }
    if(ndim1==0) 
    {
        *this = UMatrix(Diag0, ndim0);
        return;
    }
    if(Diag0==Diag1)
    {
        *this = UMatrix(Diag0, ndim0+ndim1);
        return;
    }
    Nrow    = ndim0+ndim1;
    Ncol    = ndim0+ndim1;
    MT      = U_MAT_DIAGONAL;
    Data    = new double[Nrow];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, double, int). Memory allocation.\n");
        return;
    }

    for(int j=0    ;j<ndim0      ;j++) Data[j] = Diag0;
    for(int j=ndim0;j<ndim0+ndim1;j++) Data[j] = Diag1;
}
UMatrix::UMatrix(double Diag0, int ndim0, double Diag1, int ndim1, double Diag2, int ndim2)
{
    SetAllMembersDefault();
    if(ndim0<0 || ndim1<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, double, int, double, int). Invalid Argument(s).\n");
        return;        
    }

    if(ndim0==0)  {*this = UMatrix(Diag1, ndim1, Diag2, ndim2); return;}
    if(ndim1==0)  {*this = UMatrix(Diag0, ndim0, Diag2, ndim2); return;}
    if(ndim2==0)  {*this = UMatrix(Diag0, ndim0, Diag1, ndim1); return;}

    if(Diag0==Diag1) {*this = UMatrix(Diag0, ndim0+ndim1, Diag2, ndim2      ); return;}
    if(Diag1==Diag2) {*this = UMatrix(Diag0, ndim0      , Diag1, ndim1+ndim2); return;}

    Nrow    = ndim0+ndim1+ndim2;
    Ncol    = ndim0+ndim1+ndim2;
    MT      = U_MAT_DIAGONAL;
    Data    = new double[Nrow];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double, int, double, int, double, int). Memory allocation.\n");
        return;
    }

    for(int j=0          ;j<ndim0            ;j++) Data[j] = Diag0;
    for(int j=ndim0      ;j<ndim0+ndim1      ;j++) Data[j] = Diag1;
    for(int j=ndim0+ndim1;j<ndim0+ndim1+ndim2;j++) Data[j] = Diag2;
}
UMatrix::UMatrix(const double* Diag, int nDim)
{
    SetAllMembersDefault();

    if(nDim==0) return;
    if(nDim<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double*, int). Invalid Argument(s) (nDim=%d).\n", nDim);
        return;        
    }

    Nrow    = nDim;
    Ncol    = nDim;
    MT      = U_MAT_DIAGONAL;
    Data    = new double[Nrow];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double*, int). Memory allocation.\n");
        return;
    }

    if(Diag) for(int j=0;j<nDim;j++) Data[j] = Diag[j];
    else     for(int j=0;j<nDim;j++) Data[j] = 1.;
}
UMatrix::UMatrix(WindowType Win, int nDim)
{
    SetAllMembersDefault();

    if(nDim==0) return;
    if(nDim<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(WindowType, int). Invalid Argument(s) (nDim=%d).\n", nDim);
        return;        
    }
    double* Window = ::GetWindowProfile(Win, nDim, -1.);
    if(Window==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(WindowType, int). Computing window.\n");
        return;        
    }
    *this = UMatrix(Window, nDim);
    delete[] Window;
}

UMatrix::UMatrix(const double* const* Matrix, int nR, int nC)
{
    SetAllMembersDefault();

    if(nR==0 && nC==0) return;
    if(nR<=0 || nC<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double**, int, int). Invalid Argument(s) (nR=%d nC=%d).\n", nR, nC);
        return;
    }
    if(Matrix==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double**, int, int). Invalid NULL pointer.\n");
        return;
    }
    for(int i=0; i<nR;i++)
    {
        if(Matrix[i]) continue;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double**, int, int). Invalid NULL pointer in row %d.\n", i);
        return;
    }

    Nrow    = nR;
    Ncol    = nC;
    MT      = (nC==nR) ?  U_MAT_SQUARE : U_MAT_GENERAL; // Let use determine whether U_MAT_SYMMETRIC is possible
    Data    = new double[Nrow*Ncol];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double*, int, int). Memory allocation.\n");
        return;
    }
    for(int i=0, ij=0; i<Nrow; i++)
        for(int j=0; j<Ncol; j++, ij++) Data[ij] = Matrix[i][j];
}
UMatrix::UMatrix(const double* Matrix, int nR, int nC)
{
    SetAllMembersDefault();

    if(nR==0 && nC==0) return;
    if(nR<=0 || nC<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double*, int, int). Invalid Argument(s) (nR=%d nC=%d).\n", nR, nC);
        return;        
    }

    Nrow    = nR;
    Ncol    = nC;
    MT      = (nC==nR) ?  U_MAT_SQUARE : U_MAT_GENERAL; // Let use determine whether U_MAT_SYMMETRIC is possible
    Data    = new double[Nrow*Ncol];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(double*, int, int). Memory allocation.\n");
        return;
    }

    int Nelem = Nrow*Ncol;

    if(Matrix) for(int j=0;j<Nelem;j++) Data[j] = Matrix[j];
    else       for(int j=0;j<Nelem;j++) Data[j] = 0.;
}    
UMatrix::UMatrix(const float* Matrix, int nR, int nC)
{
    SetAllMembersDefault();

    if(nR==0 && nC==0) return;
    if(nR<=0 || nC<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(float*, int, int). Invalid Argument(s) (nR=%d nC=%d).\n", nR, nC);
        return;        
    }

    Nrow    = nR;
    Ncol    = nC;
    MT      = (nC==nR) ?  U_MAT_SQUARE : U_MAT_GENERAL; // Let use determine whether U_MAT_SYMMETRIC is possible
    Data    = new double[Nrow*Ncol];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(float*, int, int). Memory allocation.\n");
        return;
    }

    int Nelem = Nrow*Ncol;

    if(Matrix) for(int j=0;j<Nelem;j++) Data[j] = Matrix[j];
    else       for(int j=0;j<Nelem;j++) Data[j] = 0.;
}    
UMatrix::UMatrix(const double* Matrix, int nR, int nC, const bool* SelectRowCol)
{
    SetAllMembersDefault();
    
    if(nR!=nC)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Matrix argument not square: (nR, nC) = (%d,%d).\n", nR, nC);
        return;
    }
    if(SelectRowCol==NULL)
    {
        *this = UMatrix(Matrix, nR,nC);
        return;
    }
    Nrow = Ncol = GetNSelect(SelectRowCol, nR);
    if(Nrow==0) return;
    if(Nrow<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    if(Matrix==NULL) return;

    int* Irc = GetSelection(SelectRowCol, nR);
    if(Irc==NULL)
    {
        delete[] Irc;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Getting selection,  nR = %d .\n", nR);
        return;
    }

    Data = new double[Nrow*Ncol];
    if(Data==NULL)
    {
        delete[] Irc;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation Nrow=Ncol = %d. \n", Nrow);
        return;
    }
    double* pData = Data;
    for(int i=0; i<Nrow; i++)
    {
        double* pMatRow = Data+Irc[i]*nC;
        for(int j=0; j<Ncol; j++) *pData++ = pMatRow[Irc[j]];
    }
    delete[] Irc;

    MT   = U_MAT_SQUARE;
}
UMatrix::UMatrix(const UMatrix& Matrix, const bool* SelectRowCol)
{
    SetAllMembersDefault();
    if(SelectRowCol==NULL)
    {
        *this = Matrix;
        return;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). NULL or erroneous UMatrix argument.\n");
        return;
    }
    if(Matrix.Nrow!=Matrix.Ncol)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Matrix argument not square: (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    Nrow = Ncol = GetNSelect(SelectRowCol, Matrix.Nrow);
    if(Nrow==0) return;

    if(Nrow<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    if(Matrix.MT==U_MAT_NULL) return;
    if(Matrix.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Matrix.Data not set.\n", Nrow, Ncol);
        return;
    }

    int* Irc = GetSelection(SelectRowCol, Matrix.Nrow);
    if(Irc==NULL)
    {
        delete[] Irc;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Getting selection,  Nrow = %d .\n", Nrow);
        return;
    }

    MT   = Matrix.MT;
    if(Matrix.IsDiagonalType())
    {
        Data = new double[Matrix.GetNelem()];
        if(Data==NULL)
        {
            delete[] Irc;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation, Nrow=%d .\n", Nrow);
            return;
        }
        Data[0] = Matrix.Data[0];
        if(Matrix.MT!=U_MAT_IDENTITY&&Matrix.MT!=U_MAT_IDENTCONST)
            for(int k=0; k<Nrow; k++) Data[k] = Matrix.Data[Irc[k]];
    }
    else
    {
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            delete[] Irc;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation Nrow=Ncol = %d. \n", Nrow);
            return;
        }
        double* pData = Data;
        for(int i=0; i<Nrow; i++)
        {
            double* pMatRow = Matrix.Data+Irc[i]*Matrix.Ncol;
            for(int j=0; j<Ncol; j++) *pData++ = pMatRow[Irc[j]];
        }
    }
    delete[] Irc;
}
UMatrix::UMatrix(const double* Matrix, int nR, int nC, const bool* SelectRow, const bool* SelectCol)
{   
    SetAllMembersDefault();
    if(SelectRow==NULL && SelectCol==NULL)
    {
        *this = UMatrix(Matrix, nR, nC);
        return;
    }

    Nrow = (SelectRow==NULL) ? nR : GetNSelect(SelectRow, nR);
    Ncol = (SelectCol==NULL) ? nC : GetNSelect(SelectCol, nC);
    if(Nrow==0 && Ncol==0) return;
    
    if(Nrow<=0 || Ncol<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    if(Matrix==NULL) return;

    int* Ir = GetSelection(SelectRow, nR);
    int* Ic = GetSelection(SelectCol, nC);
    if(Ir==NULL || Ic==NULL)
    {
        delete[] Ir; delete[] Ic;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Getting selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    Data = new double[Nrow*Ncol];
    if(Data==NULL)
    {
        delete[] Ir; delete[] Ic;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    double* pData = Data;
    for(int i=0; i<Nrow; i++)
    {
        double* pMatRow = Data+Ir[i]*nC;
        for(int j=0; j<Ncol; j++) *pData++ = pMatRow[Ic[j]];
    }
    delete[] Ir; delete[] Ic;

    MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
}
UMatrix::UMatrix(const UMatrix& Matrix, const bool* SelectRow, const bool* SelectCol)
{   
    SetAllMembersDefault();
    if(SelectRow==NULL && SelectCol==NULL)
    {
        *this = Matrix;
        return;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). NULL or erroneous UMatrix argument.\n");
        return;
    }
    Nrow = (SelectRow==NULL) ? Matrix.Nrow : GetNSelect(SelectRow, Matrix.Nrow);
    Ncol = (SelectCol==NULL) ? Matrix.Ncol : GetNSelect(SelectCol, Matrix.Ncol);
    if(Nrow==0 && Ncol==0) return;
    
    if(Nrow<=0 || Ncol<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    if(Matrix.MT==U_MAT_NULL) return;
    if(Matrix.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Matrix.Data not set.\n", Nrow, Ncol);
        return;
    }

    int* Ir = GetSelection(SelectRow, Matrix.Nrow);
    int* Ic = GetSelection(SelectCol, Matrix.Ncol);
    if(Ir==NULL || Ic==NULL)
    {
        delete[] Ir; delete[] Ic;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Getting selection (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
        return;
    }
    bool EqualSel = (Nrow==Ncol) && (Matrix.Nrow==Matrix.Ncol);
    if(EqualSel) for(int k=0; k<Nrow; k++) if(EqualSel) EqualSel = (Ir[k]==Ic[k]); else break;
    if(Matrix.IsDiagonalType() && EqualSel)
    {
        MT   = Matrix.MT;
        Data = new double[Matrix.GetNelem()];
        if(Data==NULL)
        {
            delete[] Ir; delete[] Ic;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
            return;
        }
        Data[0] = Matrix.Data[0];
        if(Matrix.MT!=U_MAT_IDENTITY&&Matrix.MT!=U_MAT_IDENTCONST)
            for(int k=0; k<Nrow; k++) Data[k] = Matrix.Data[Ir[k]];
    }
    else
    {
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            delete[] Ir; delete[] Ic;
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation (Nrow, Ncol) = (%d,%d).\n", Nrow, Ncol);
            return;
        }
        double* pData = Data;
        if(Matrix.IsDiagonalType())
        {
            MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<Ncol; j++) *pData++ = Matrix.GetElement(Ir[i], Ic[j]);
        }
        else
        {
            MT   = (Nrow==Ncol) ? ((EqualSel&&Matrix.MT==U_MAT_SYMMETRIC)?U_MAT_SYMMETRIC:U_MAT_SQUARE) : U_MAT_GENERAL;
            for(int i=0; i<Nrow; i++)
            {
                double* pMatRow = Matrix.Data+Ir[i]*Matrix.Ncol;
                for(int j=0; j<Ncol; j++) *pData++ = pMatRow[Ic[j]];
            }
        }
    }
    delete[] Ir; delete[] Ic;
}

UMatrix::UMatrix(const double* Mat1, const double* Mat2, int nR1, int nC1, int nR2, int nC2, bool ConcatCols)
{
    SetAllMembersDefault();
    if(Mat1==NULL || Mat2==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: Invalid NULL pointer argument(s).\n");
        return;
    }
    if(nR1<0 || nR2<0 || nC1<0 || nC2<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid argument(s) (nR1,nR2)=(%d, %d) and (nC1,nC2)=(%d, %d) .\n", nR1, nR2, nC1, nC2);
        return;
    }
    if(nR1!=nR2 && nC1!=nC2)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Either number of collums or number of rows should be equal (nR1,nR2)=(%d, %d) and (nC1,nC2)=(%d, %d) .\n", nR1, nR2, nC1, nC2);
        return;
    }
    if(nR1*nC1 + nR2*nC2<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid argument(s) (nR1,nR2)=(%d, %d) and (nC1,nC2)=(%d, %d) .\n", nR1, nR2, nC1, nC2);
        return;
    }

    Data = new double[nR1*nC1 + nR2*nC2];
    if(Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation: (nR1,nR2)=(%d, %d) and (nC1,nC2)=(%d, %d) .\n", nR1, nR2, nC1, nC2);
        return;
    }

    double*       pD  = Data;
    const double* pM1 = Mat1;
    const double* pM2 = Mat2;
    if( nR1==nR2 && (nC1!=nC2 || (nC1==nC2 && ConcatCols==false))) // Concatenate rows of Mat1 and Mat2
    {
        Nrow   = nR1;
        Ncol   = nC1+nC2;
        for(int i=0; i<Nrow; i++)
        {
            for(int j=0; j<nC1; j++) *pD++ = *pM1++;
            for(int j=0; j<nC2; j++) *pD++ = *pM2++;
        }
    }
    else
    {
        Nrow   = nR1+nR2;
        Ncol   = nC1;
        for(int ij=0; ij<nR1*Ncol; ij++) *pD++ = *pM1++;
        for(int ij=0; ij<nR2*Ncol; ij++) *pD++ = *pM2++;
    }
    MT = Nrow==Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
}

UMatrix::UMatrix(const UMatrix& AMat, const UMatrix& BMat)
/* 
    Kronecker Product constructor
 */
{
    SetAllMembersDefault();

    Nrow    = AMat.Nrow* BMat.Nrow;
    Ncol    = AMat.Ncol* BMat.Ncol;
    if((AMat.MT==U_MAT_NULL)||(BMat.MT==U_MAT_NULL)) return;

    if(AMat.Data==NULL || BMat.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(AMat.IsDiagonalType()==true && BMat.IsDiagonalType()==true)
    {
        if(AMat.MT==U_MAT_DIAGONAL || BMat.MT==U_MAT_DIAGONAL)
        {
            Data = new double[Nrow];
            if(Data==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::UMatrix(UMatrix, UMatrix). Memory allocation (diagonal case).\n");
                return;
            }
            for(int i=0;i<AMat.Nrow;i++)
            {
                double DiagA = (AMat.MT==U_MAT_DIAGONAL) ? AMat.Data[i] : AMat.Data[0];
                for(int ii=0;ii<BMat.Nrow;ii++)
                {
                    double DiagB = (BMat.MT==U_MAT_DIAGONAL) ? BMat.Data[ii] : BMat.Data[0];
                    Data[(i*BMat.Nrow+ii)] = DiagA*DiagB;
                }
            }
            MT = U_MAT_DIAGONAL;
        }
        else
        {
            Data    = new double[1];
            Data[0] = AMat.Data[0]*BMat.Data[0];
            if(AMat.MT==U_MAT_IDENTITY && BMat.MT==U_MAT_IDENTITY) MT = U_MAT_IDENTITY;
            else                                                   MT = U_MAT_IDENTCONST;
        }
    }
    else
    {
             if(AMat.MT==U_MAT_GENERAL       || BMat.MT==U_MAT_GENERAL      ) MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
        else if(AMat.IsSymmetricType()==true && BMat.IsSymmetricType()==true) MT = U_MAT_SYMMETRIC;
        else                                                                  MT = U_MAT_SQUARE;

        Data    = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(UMatrix, UMatrix). Memory allocation.\n");
            return;
        }
        for(int i=0;i<AMat.Nrow;i++)
            for(int ii=0;ii<BMat.Nrow;ii++)
                for(int j=0;j<AMat.Ncol;j++)
                    for(int jj=0;jj<BMat.Ncol;jj++)
                        Data[(i*BMat.Nrow+ii)*Ncol+(j*BMat.Ncol+jj)] = AMat.GetElement(i,j)*BMat.GetElement(ii,jj);
    }
}
UMatrix::UMatrix(const UFileName& F)
{
    SetAllMembersDefault();
    if(&F==NULL || F.GetFullFileName()==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid NULL pointer argument.\n");
        return;
    }
    if(F.DoesFileExist()!=true)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). File does not exist: %s \n", (const char*)F);
        return;
    }
    FILE* fp = fopen(F, "rb", false);
    if(fp==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Opening file: %s \n", (const char*)F);
        return;
    }
    
    char line[2000];
    int     NL   = GetNLines(fp);
    int     NC   = -1;
    double* pDat = NULL;
    while(GetLine(line, sizeof(line), fp))
    {
        UAnalyzeLine AA(line);
        if(AA.IsEmptyLine() || AA.IsCommentLine()) continue;
        if(NC<0)
        {
            NC = AA.GetNCollumn();
        }
        else
        {
            int N = AA.GetNCollumn();
            if(N!=NC) NC = -1;
        }
        if(NC<=0)
        {
            fclose(fp);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid number of collumns or number of collumns not constant. File: %s \n", (const char*)F);
            return;
        }
        if(Data==NULL)
        {
            Data = new double[NL*NC];
            if(Data==NULL)
            {
                fclose(fp);
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation. (NL,NC) = (%d,%d)  \n", NL, NC);
                return;
            }
            pDat = Data;
        }
        for(int ic=0; ic<NC; ic++) *pDat++ = AA.GetNextDouble(0.);
        Nrow++;
    }
    fclose(fp);

    Ncol = NC;
    MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
}
UMatrix::UMatrix(const UField* const* const Farray, int Nfield, bool Collumns, const bool* Select)
{
    SetAllMembersDefault();
    if(Farray==NULL && Nfield==0) return;
   
    if(Farray==NULL || Nfield<0 || (Farray==NULL && Nfield>0))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid argument(s), Nfield = %d) . \n", Nfield);
        return;
    }

    int NpointsF = -1;
    int NdimF    = -1;
    for(int n=0; n<Nfield; n++)
    {
        if(Farray[n] == NULL || Farray[n]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid or NULL UField element, n=%d . \n", n);
            return;
        }
        if(Farray[n]->GetVeclen()!=1)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid UField element, n=%d , veclen = %d. \n", n, Farray[n]->GetVeclen());
            return;
        }
        if(n==0) 
        {
            NpointsF = Farray[0]->GetNpoints();
            NdimF    = Farray[0]->Getndim();
        }
        if(Farray[n]->Getndim()!=NdimF)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid UField element, Ndim not constant over UField-array. \n");
            return;
        }
        if(NpointsF!=Farray[n]->GetNpoints())
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Number of points not constant over UField-array (Npoints_0=%d, Npoints=%d) \n", NpointsF, Farray[n]->GetNpoints());
            return;
        }
    }
    int NpointsSel = GetNSelect(Select, NpointsF);
    if(NpointsSel<=0) return;

    Nrow = Collumns   ? NpointsSel : Nfield    ;
    Ncol = Collumns   ? Nfield     : NpointsSel;
    MT   = Nrow==Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
    Data = new double[Nrow*Ncol];
    if(Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation: Nfield = %d, NpointsSel = %d. \n", Nfield, NpointsSel);
        return;
    }
    for(int n=0; n<Nfield; n++)
    {
        for(int j=0, jsel=0; j<NpointsF; j++)
        {
            if(Select && Select[j]==false) continue;
            int nj = Collumns ? jsel*Ncol+n : n*Ncol+jsel;
            switch(Farray[n]->GetDType())
            {
            case UField::U_BYTE   : Data[nj] = Farray[n]->GetBdata()[j]; break;
            case UField::U_SHORT  : Data[nj] = Farray[n]->GetSdata()[j]; break;
            case UField::U_INTEGER: Data[nj] = Farray[n]->GetIdata()[j]; break;
            case UField::U_FLOAT  : Data[nj] = Farray[n]->GetFdata()[j]; break;
            case UField::U_DOUBLE : Data[nj] = Farray[n]->GetDdata()[j]; break;
            default:
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid data type (%d) in element %d. \n",Farray[n]->GetDType(),n);
                return;
            }
            jsel++;
        }
    }
}
UMatrix::UMatrix(const UVector3& V)
{
    SetAllMembersDefault();
    *this = UMatrix((const double*)&V, 3, 1);
}
UMatrix::UMatrix(const UVector3& V1, const UVector3& V2)
{
    SetAllMembersDefault();
    *this = UMatrix((const double*)&V1, (const double*)&V2, 3, 1, 3, 1, true);
}

UMatrix::UMatrix(FILE* fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid NULL pointer. \n");
        return;
    }

    unsigned int ioff   = ftell(fpIn);
    size_t       NHead  = strlen(HEADERBEGIN);
    char     Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Reading first item from file pointer. \n");
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Wrong header (%s). \n", Buffer);
        return;
    }
    MT      = ::GetMatrixType(::ReadBinaryInt(DefaultIntelData, fpIn));
    Nrow    = ::ReadBinaryInt(DefaultIntelData, fpIn);
    Ncol    = ::ReadBinaryInt(DefaultIntelData, fpIn);
    if(MT==U_MAT_UNKNOWN || Nrow<0 || Ncol<0 || (Nrow==0 && Ncol!=0) || (Nrow!=0 && Ncol==0))
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Invalid type, Nrow or Ncol, (%d, %d, %d). \n", int(MT), Nrow, Ncol);
        return;
    }

    int Nelem = GetNelem();
    if(Nelem>0)
    {
        Data = new double[Nelem];
        if(Data==NULL)
        {
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioff, SEEK_SET);
            CI.AddToLog("ERROR: UMatrix::UMatrix(). Memory allocation, Nelem =%d. \n", Nelem);
            return;
        }
        ::ReadBinaryDoubleArray(Data, Nelem, DefaultIntelData, fpIn);
    }
    memset(Buffer, 0, sizeof(Buffer));
    fread(Buffer,1,strlen(HEADEREND),fpIn);
    NHead  = strlen(HEADEREND);
    if(strncmp(HEADEREND, Buffer, NHead))
    {
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UMatrix::UMatrix(). Wrong END header (%s). \n", Buffer);
        return;
    }
}
ErrorType UMatrix::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary().  Ncol (=%d) or Nrow (%d) invalid \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary().  Invalid NULL data pointer. MT = %d \n", MT);
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(MT  , DefaultIntelData, fpOut);
    ::WriteBinary(Nrow, DefaultIntelData, fpOut);
    ::WriteBinary(Ncol, DefaultIntelData, fpOut);

    int Nelem = GetNelem();
    if(Data) ::WriteBinary(Data, Nelem, DefaultIntelData, fpOut);
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);

    return U_OK;
}
ErrorType UMatrix::WriteBinary(UFileName F) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary().  Ncol (=%d) or Nrow (%d) invalid \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary().  Invalid NULL data pointer. MT = %d \n", MT);
        return U_ERROR;
    }
    FILE* fp = fopen(F, "wb");
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteBinary(). Cannot open or create file: %s \n", (const char*)F);
        return U_ERROR;
    }
    if(WriteBinary(fp)!=U_OK)
    {
        fclose(fp);
        CI.AddToLog("ERROR: UMatrix::WriteBinary(). Writing to file: %s \n", (const char*)F);
        return U_ERROR;
    }
    fclose(fp);
    return U_OK;
}
ErrorType UMatrix::WriteTxt(UFileName F, bool Header) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::WriteTxt(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMatrix::WriteTxt().  Ncol (=%d) or Nrow (%d) invalid \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteTxt().  Invalid NULL data pointer. MT = %d \n", MT);
        return U_ERROR;
    }
    FILE* fp = fopen(F, "wt", false);
    if(fp==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::WriteTxt(). Cannot create/open file (%s) \n", (const char*)F);
        return U_ERROR;
    }
    if(Header) fprintf(fp, "%s", (const char*)GetProperties("// "));

    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<Ncol-1; j++) fprintf(fp, "%f \t", GetElement(i,j));
        fprintf(fp, "%f \n", GetElement(i,Ncol-1));
    }
    fclose(fp);

    return U_OK;
}

ErrorType UMatrix::PrintToLog(const char* Name, int irow, int NrowPrint, int icol, int NcolPrint) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::PrintToLog(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMatrix::PrintToLog().  Ncol (=%d) or Nrow (%d) invalid \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::PrintToLog().  Invalid NULL data pointer. MT = %d \n", MT);
        return U_ERROR;
    }
    if(NrowPrint<0) NrowPrint = Nrow;
    if(NcolPrint<0) NcolPrint = Ncol;

    irow = MIN(MAX(0,irow), Nrow-1); NrowPrint = MIN(MAX(1, NrowPrint), Nrow-irow);
    icol = MIN(MAX(0,icol), Ncol-1); NcolPrint = MIN(MAX(1, NcolPrint), Ncol-icol);

    if(Name) CI.AddToLog("%s:\n", Name);
    CI.AddToLog("Row %d - Row %d \n", irow, irow+NrowPrint-1);
    CI.AddToLog("Col %d - Col %d \n", icol, icol+NcolPrint-1);

    for(int i=irow; i<irow+NrowPrint; i++)
    {
        for(int j=icol; j<icol+NcolPrint; j++) CI.AddToLog("%f \t", GetElement(i,j));
        CI.AddToLog("\n");
    }
    return U_OK;
}

UMatrix::~UMatrix()
{
    DeleteAllMembers(U_OK);
}

UMatrix& UMatrix::operator=(const UMatrix& Matrix)
{
    if(this==NULL)
    {
        static UMatrix M(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Object NULL.\n");
        return M;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(Matrix.MT!=U_MAT_NULL && Matrix.Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Argument data matrix NULL.\n");
        return *this;
    }
    if(Matrix.MT!=U_MAT_NULL && (Matrix.Nrow<=0 || Matrix.Ncol<=0))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Argument Matrix.Nrow=%d, Matrix.Ncol=%d.\n",  Matrix.Nrow,  Matrix.Ncol);
        return *this;
    }
    if(Matrix.IsSquareType()==true && Matrix.Nrow!=Matrix.Ncol)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrix::operator=(). Argument Matrix.Nrow=%d, Matrix.Ncol=%d not consistent with type.\n",  Matrix.Nrow,  Matrix.Ncol);
        return *this;
    }

    if(this==&Matrix) return *this;

    DeleteAllMembers(U_OK);

    MT   = Matrix.MT;
    Nrow = MAX(0, Matrix.Nrow);
    Ncol = MAX(0, Matrix.Ncol);

    if(Matrix.Data)
    {
        int Nelem  = GetNelem();
        Data       = new double[Nelem];
        if(!Data)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrix::operator=(). Memory allocation: Nrow=%d, Ncol=%d\n",Matrix.Nrow, Matrix.Ncol);
            return *this;
        }
        for(int k=0; k<Nelem; k++) Data[k] = Matrix.Data[k];
    }
    return *this;
}

UMatrix UMatrix::operator-(const UMatrix& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL)
    {
        if(Matrix.MT==U_MAT_NULL) return *this;
        if(Matrix.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator-().  Data matrix NULL.\n");
            return UMatrix(U_ERROR);
        }

        UMatrix MinMat(Matrix);
        if(MinMat.GetError()!=U_OK || MinMat.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator-().  Creating output matrix.\n");
            return UMatrix(U_ERROR);
        }
        int Nelem = MinMat.Nrow*MinMat.Ncol;
        for(int k=0; k<Nelem; k++) MinMat.Data[k] = -MinMat.Data[k];
        return MinMat;
    }

    if(Matrix.MT==U_MAT_NULL) return UMatrix(*this);

    if(Matrix.Nrow !=Nrow || Matrix.Ncol!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::operator-().  Dimensions do not match.\n");
        return UMatrix(U_ERROR);
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator-().  Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix(*this)-=Matrix;
}

UMatrix& UMatrix::operator-=(const UMatrix& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(MT==U_MAT_NULL)
    {
        if(Matrix.MT==U_MAT_NULL) return *this;
        if(Matrix.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator-=().  Matrix data is NULL.\n");
            return *this;
        }

        *this = UMatrix(Matrix);
        if(this->GetError()!=U_OK || this->Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator-=().  Creating output matrix.\n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        int Nelem = GetNelem();
        for(int k=0; k<Nelem; k++) Data[k] = -Matrix.Data[k];
        return *this;
    }

    if(Matrix.MT==U_MAT_NULL) return *this;

    if(Matrix.Nrow !=Nrow || Matrix.Ncol!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=().  Dimensions do not match.\n");
        return *this;
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=().  Matrix data is NULL.\n");
        return *this;
    }
    if((*this).IsDiagonalType()==true)
    {
        if(Matrix.IsDiagonalType()==true)
        {
            if((*this).MT==U_MAT_DIAGONAL || Matrix.MT==U_MAT_DIAGONAL)
            {
                double* NewData = new double[Nrow];
                if(NewData==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UMatrix::operator-=(). Memory allocation (diagonal case).\n");
                    return *this;
                }
                for(int i=0;i<Nrow;i++)
                {
                    double Diag  = (       MT==U_MAT_DIAGONAL) ?        Data[i] :        Data[0];
                    double DiagM = (Matrix.MT==U_MAT_DIAGONAL) ? Matrix.Data[i] : Matrix.Data[0];
                    NewData[i]   = Diag-DiagM;
                }
                delete[] Data; Data = NewData;
                MT = U_MAT_DIAGONAL;
            }
            else
            {
                Data[0] -= Matrix.Data[0];
                if(Data[0]==1.) MT = U_MAT_IDENTITY;
                else            MT = U_MAT_IDENTCONST;
            }
        }
        else
        {
            double* NewData = new double[Nrow*Ncol];
            if(NewData==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::operator-=(). Memory allocation. Switching from diagonal case.\n");
                return *this;
            }
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<Ncol; j++)
                    NewData[i*Ncol+j] = this->GetElement(i,j)-Matrix.GetElement(i,j);

            delete[] Data; Data = NewData;
            MT = Matrix.MT;
        }
    }
    else // *this non-diagonal
    {
        if(Matrix.IsDiagonalType()==true)
        {
            for(int i=0; i<Nrow; i++)
                Data[i*Ncol+i] -= Matrix.GetElement(i,i);
        }
        else
        {
            int           Nelem = Nrow*Ncol;
                  double* pMat  = Data;
            const double* pM    = Matrix.Data;
            for(int k=0;k<Nelem;k++) *pMat++ -= *pM++;

            if(MT==U_MAT_SYMMETRIC && Matrix.MT!=U_MAT_SYMMETRIC) MT = Matrix.MT;
        }
    }
    return *this;
}

UMatrix UMatrix::operator+(const UMatrix& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL)
    {
        if(Matrix.MT==U_MAT_NULL) return *this;
        if(Matrix.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator+().  Data matrix NULL.\n");
            return UMatrix(U_ERROR);
        }
        return UMatrix(Matrix);
    }

    if(Matrix.MT==U_MAT_NULL) return UMatrix(*this);

    if(Matrix.Nrow !=Nrow || Matrix.Ncol!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::operator+().  Dimensions do not match: (%d,%d) and (%d,%d).\n", Matrix.Nrow, Nrow, Matrix.Ncol, Ncol);
        return UMatrix(U_ERROR);
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator+().  Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix(*this)+=Matrix;
}

UMatrix& UMatrix::operator+=(const UMatrix& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(MT==U_MAT_NULL)
    {
        if(Matrix.MT==U_MAT_NULL) return *this;
        if(Matrix.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator+=().  Matrix data is NULL.\n");
            return *this;
        }

        *this = UMatrix(Matrix);
        if(this->GetError()!=U_OK || this->Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator+=().  Creating output matrix.\n");
            DeleteAllMembers(U_ERROR);
            return *this;
        }
        return *this;
    }

    if(Matrix.MT==U_MAT_NULL) return *this;

    if(Matrix.Nrow !=Nrow || Matrix.Ncol!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=().  Dimensions do not match.\n");
        return *this;
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=().  Matrix data is NULL.\n");
        return *this;
    }
    if((*this).IsDiagonalType()==true)
    {
        if(Matrix.IsDiagonalType()==true)
        {
            if((*this).MT==U_MAT_DIAGONAL || Matrix.MT==U_MAT_DIAGONAL)
            {
                double* NewData = new double[Nrow];
                if(NewData==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UMatrix::operator+=(). Memory allocation (diagonal case).\n");
                    return *this;
                }
                for(int i=0;i<Nrow;i++)
                {
                    double Diag  = (       MT==U_MAT_DIAGONAL) ?        Data[i] :        Data[0];
                    double DiagM = (Matrix.MT==U_MAT_DIAGONAL) ? Matrix.Data[i] : Matrix.Data[0];
                    NewData[i]   = Diag+DiagM;
                }
                delete[] Data; Data = NewData;
                MT = U_MAT_DIAGONAL;
            }
            else
            {
                Data[0] += Matrix.Data[0];
                if(Data[0]==1.) MT = U_MAT_IDENTITY;
                else            MT = U_MAT_IDENTCONST;
            }
        }
        else
        {
            double* NewData = new double[Nrow*Ncol];
            if(NewData==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::operator+=(). Memory allocation. Switching from diagonal case.\n");
                return *this;
            }
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<Ncol; j++)
                    NewData[i*Ncol+j] = this->GetElement(i,j)+Matrix.GetElement(i,j);

            delete[] Data; Data = NewData;
            MT = Matrix.MT;
        }
    }
    else // *this non-diagonal
    {
        if(Matrix.IsDiagonalType()==true)
        {
            for(int i=0; i<Nrow; i++)
                Data[i*Ncol+i] += Matrix.GetElement(i,i);
        }
        else
        {
            int           Nelem = Nrow*Ncol;
                  double* pMat  = Data;
            const double* pM    = Matrix.Data;
            for(int k=0;k<Nelem;k++) *pMat++ += *pM++;

            if(MT==U_MAT_SYMMETRIC && Matrix.MT!=U_MAT_SYMMETRIC) MT = Matrix.MT;
        }
    }
    return *this;
}

UMatrix UMatrix::operator*(double a) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*(double). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;
    
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator*(double). Matrix data is NULL.\n");    
        return UMatrix(U_ERROR);
    }

    UMatrix Matrix(*this);
    Matrix *= a;
    return Matrix;
}
UMatrix& UMatrix::operator*=(double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==1.   || MT==U_MAT_NULL) return *this;
    if(Nrow==0 || Ncol==0)        return *this;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=(double). Matrix data is NULL.\n");
        return *this;
    }
    if(a==0.)
    {
        delete[] Data; Data = NULL;
        MT = U_MAT_NULL;
        return *this;
    }

    int     Nelem = GetNelem();
    double* pData = Data;
    for(int k=0; k<Nelem; k++) *pData++ *= a;

    return *this;
}

UMatrix UMatrix::operator/(double a) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator/(const double). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(a==0.)
    {
        CI.AddToLog("ERROR: UMatrix::operator/(const double). Erroneous 0. argument.\n");
        return UMatrix(U_ERROR);
    }
    return operator*(1./a);
}
UMatrix& UMatrix::operator/=(double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator/=(const double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==0.)
    {
        CI.AddToLog("ERROR: UMatrix::operator/=(const double). Erroneous argument: a=%20.15e.  \n", a);
        return *this;
    }
    if(MT==U_MAT_NULL) return *this;
    
    return (*this *= 1./a);
}

UMatrix UMatrix::operator*(const UMatrix& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }

    if(       MT==U_MAT_NULL) return UMatrix();
    if(Matrix.MT==U_MAT_NULL) return UMatrix();

    if(Ncol != Matrix.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::operator*(). Matrix dimensions do not match: Ncol=%d, M.Nrow=%d .\n", Ncol, Matrix.Nrow);
        return UMatrix(U_ERROR);
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator*().  Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix(*this)*=Matrix;
}
UMatrix UMatrix::operator^(const UMatrix& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator^(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator^(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }

    if(       MT==U_MAT_NULL) return UMatrix();
    if(Matrix.MT==U_MAT_NULL) return UMatrix();

    if(Ncol != Matrix.Ncol || Nrow != Matrix.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::operator^(). Matrix dimensions do not match: Ncol=%d, M.Ncol=%d, Nrow=%d, M.Nrow=%d .\n", Ncol, Matrix.Ncol, Nrow, Matrix.Nrow);
        return UMatrix(U_ERROR);
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator^().  Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix(*this)^=Matrix;
}
UMatrix& UMatrix::operator*=(const UMatrix& Matrix)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(MT==U_MAT_NULL || Matrix.MT==U_MAT_NULL)
    {
        *this = UMatrix();
        return *this;
    }
    if(Ncol != Matrix.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=(). Matrix dimensions do not match: Ncol=%d, M.Nrow=%d .\n", Ncol, Matrix.Nrow);
        return *this;
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator*=().  Matrix data is NULL.\n");
        return *this;
    }

    if((*this).IsDiagonalType()==true)
    {
        if(Matrix.IsDiagonalType()==true)
        {
            if((*this).MT==U_MAT_DIAGONAL || Matrix.MT==U_MAT_DIAGONAL)
            {
                double* NewData = new double[Nrow];
                if(NewData==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UMatrix::operator*=(). Memory allocation (diagonal case).\n");
                    return *this;
                }
                for(int i=0;i<Nrow;i++)
                {
                    double Diag  = (       MT==U_MAT_DIAGONAL) ?        Data[i] :        Data[0];
                    double DiagM = (Matrix.MT==U_MAT_DIAGONAL) ? Matrix.Data[i] : Matrix.Data[0];
                    NewData[i]   = Diag*DiagM;
                }
                delete[] Data; Data = NewData;
                MT = U_MAT_DIAGONAL;
            }
            else
            {
                Data[0] *= Matrix.Data[0];
                if(Data[0]==1.) MT = U_MAT_IDENTITY;
                else            MT = U_MAT_IDENTCONST;
            }
        }
        else
        {
            if(MT==U_MAT_IDENTITY || MT==U_MAT_IDENTCONST)
            {
                double Factor = Data[0];
                *this = Matrix;
                return operator*=(Factor);
            }
            double* NewData = new double[Matrix.Nrow*Matrix.Ncol];
            if(NewData==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::operator*=(). Creating output matrix. Switching from diagonal case.\n");
                return *this;
            }
                  double* pNewData = NewData;
            const double* pM       = Matrix.Data;
            for(int i=0; i<Matrix.Nrow; i++)  // compute t_ii * M_ij
            {
                double Diag = Data[i];
                for(int j=0; j<Matrix.Ncol; j++) (*pNewData++) = Diag * (*pM++);
            }
            delete[] Data; Data = NewData;
            Nrow = Matrix.Nrow;
            Ncol = Matrix.Ncol;
            MT   = (Matrix.MT==U_MAT_SYMMETRIC) ? U_MAT_SQUARE : Matrix.MT;
        }
    }
    else // *this non-diagonal
    {
        if(Matrix.IsDiagonalType()==true)
        {
            if(Matrix.MT==U_MAT_IDENTITY  ) return *this;
            else if(Matrix.MT==U_MAT_IDENTCONST)
            {
                if(Matrix.MT==U_MAT_IDENTCONST)  *this *= Matrix.Data[0];
                return *this;
            }
            else
            {
                double* pMat = Data;
                for(int i=0; i<Nrow; i++)  // compute t_ij * M_jj
                {
                    double* pDiag = Matrix.Data;
                    for(int j=0; j<Ncol; j++, pMat++, pDiag++) *pMat *= *pDiag;
                }
                if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
            }
        }
        else // both non-diagonal
        {
            double* NewData = new double[Nrow*Matrix.Ncol];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::operator*=(). Memory allocation. Nrow=%d, M.Ncol=%d\n", Nrow, Matrix.Ncol);
                return *this;
            }

            double* pNewData = NewData;
            for(int j=0; j<Nrow; j++)
            {
                for(int i=0; i<Matrix.Ncol; i++)
                {
                    double  rw    = 0;
                    double *pMat  = Data       +j*Ncol;
                    double *pM    = Matrix.Data+i;
                    for(int k=0; k<Ncol; k++,pM+=Matrix.Ncol) rw += *pMat++ * *pM;
                    *pNewData++ = rw;
                }
            }
            Ncol = Matrix.Ncol;
            delete[] Data; Data = NewData;

            MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
        }
    }
    return *this;
}
UMatrix& UMatrix::operator^=(const UMatrix& Matrix)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator^=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator^=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(Ncol != Matrix.Ncol || Nrow != Matrix.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::operator^=(). Matrix dimensions do not match: Ncol=%d, M.Ncol=%d, Nrow=%d, M.Nrow=%d .\n", Ncol, Matrix.Ncol, Nrow, Matrix.Nrow);
        return *this;
    }
    if(MT==U_MAT_NULL || Matrix.MT==U_MAT_NULL)
    {
        *this = UMatrix();
        return *this;
    }
    if(Data==NULL || Matrix.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator^=().  Matrix data is NULL.\n");
        return *this;
    }

    if((*this).IsDiagonalType()==true)
    {
        if(Matrix.IsDiagonalType()==true)
        {
            operator*=(Matrix);
            return *this;
        }
        else
        {
            if(MT==U_MAT_IDENTITY || MT==U_MAT_IDENTCONST)
            {
                double* NewData = new double[Ncol];
                if(NewData==NULL)
                {
                    DeleteAllMembers(U_ERROR);
                    CI.AddToLog("ERROR: UMatrix::operator^=(). Creating output matrix. Memory allocation, Ncol = %d.\n", Ncol);
                    return *this;
                }
                for(int ic=0; ic<Ncol; ic++) NewData[ic] = Data[0] * Matrix.Data[ic*(Ncol+1)];
                delete[] Data; Data = NewData;
                MT = U_MAT_DIAGONAL;
            }
            else
            {
                for(int ic=0; ic<Ncol; ic++) Data[ic] *= Matrix.Data[ic];
            }
            return *this;
        }
    }
    else // *this non-diagonal
    {
        if(Matrix.IsDiagonalType()==true)
        {
            double* NewData = new double[Ncol];
            if(NewData==NULL)
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrix::operator^=(). Creating output diagonal matrix. Memory allocation, Ncol = %d.\n", Ncol);
                return *this;
            }

            if(Matrix.MT==U_MAT_IDENTITY || Matrix.MT==U_MAT_IDENTCONST)
                for(int ic=0; ic<Ncol; ic++) NewData[ic] = Matrix.Data[0 ] * Data[ic*(Ncol+1)];
            else
                for(int ic=0; ic<Ncol; ic++) NewData[ic] = Matrix.Data[ic] * Data[ic*(Ncol+1)];

            MT=U_MAT_DIAGONAL;
            delete[] Data; Data = NewData;
            return *this;
        }
        else // both non-diagonal
        {
            double* pData  = Data;
            double* pMData = Matrix.Data;
            int     N      = Nrow*Ncol;
            for(int ij=0; ij<N; ij++) *pData++ *= *pMData++;

            MT = (MT==U_MAT_SYMMETRIC && Matrix.MT==U_MAT_SYMMETRIC) ? U_MAT_SYMMETRIC : (Ncol==Nrow ? U_MAT_SQUARE : U_MAT_GENERAL);
        }
    }
    return *this;
}
UMatrix UMatrix::operator-(void)  const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;

    UMatrix M(*this);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator-(). Copying *this.\n");
        return UMatrix(U_ERROR);
    }
    
    int N       = M.GetNelem();
    double* pD  = Data;
    double* pMD = M.Data;
    for(int n=0; n<N; n++) *pMD++ = -(*pD++);

    if(M.MT==U_MAT_IDENTITY) M.MT = U_MAT_IDENTCONST;
    return M;
}
UMatrix& UMatrix::operator+=(double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==0.)              return *this;
    if(Nrow==0 || Ncol==0) return *this;

    if(MT!=U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator+=(double). Matrix data is NULL.\n");
        return *this;
    }

    if(MT==U_MAT_NULL || IsDiagonalType()==true) 
    {
        double* NewData = new double[Nrow*Ncol];
        if(NewData==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::operator+=(double). Memory allocation (Nrow=%d, Ncol=%d).\n", Nrow, Ncol);
            return *this;
        }
        double* pNew = NewData;
        if(MT==U_MAT_NULL)  for(int k=0; k<Nrow*Ncol; k++) *pNew++ = a;
        else                for(int k=0; k<Nrow*Ncol; k++) *pNew++ = a + GetElement(k);
        delete[] Data; Data = NewData;
        
        MT = Nrow==Ncol? U_MAT_SYMMETRIC : U_MAT_GENERAL;
        return *this;
    }
    double* pData = Data;
    for(int k=0; k<Nrow*Ncol; k++) *pData++ += a;

    return *this;
}
UMatrix UMatrix::operator+(double a) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator+(const double). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }

    if(MT!=U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator+(const double). Matrix data is NULL.\n");    
        return UMatrix(U_ERROR);
    }

    UMatrix Matrix(*this);
    Matrix += a;
    return Matrix;
}

UMatrix& UMatrix::operator-=(double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==0.)              return *this;
    if(Nrow==0 || Ncol==0) return *this;

    if(MT!=U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::operator-=(double). Matrix data is NULL.\n");
        return *this;
    }
    this->operator+=(-a);
    return *this;
}

const UString& UMatrix::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMatrix() object.");
        return Properties;
    }
    Properties = UString();

    Properties += UString(Nrow , "Nrow          = %d \n");
    Properties += UString(Ncol , "Ncol          = %d \n");
    Properties += UString(       "MatrixType    = ") + GetMatrixTypeText(MT) + " \n";

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}
UBitMap UMatrix::GetBitMap(bool ScaleSymmetric) const
{
    UBitMap ERROR(U_ERROR);
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetBitMap(). Object NULL or erroeneous.\n");
        return ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetBitMap(). Data matrix not set.\n");
        return ERROR;
    }
    if(Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMatrix::GetBitMap(). Number of rows (%d) or collumns (%d) out of range.\n", Nrow, Ncol);
        return ERROR;
    }
    double MaxDat = GetMaxElem(ScaleSymmetric);
    double MinDat = ScaleSymmetric ? -MaxDat  : GetMinElem(false);

    unsigned char* bdat = new unsigned char[Nrow*Ncol];
    if(bdat==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetBitMap(). Memory allocation, Nrow = %d, Ncol = %d .\n", Nrow, Ncol);
        return ERROR;
    }

    if(MaxDat==MinDat) 
    {
        for(int k=0; k<Nrow*Ncol; k++) bdat[k] = 0;
        CI.AddToLog("WARNING: UMatrix::GetBitMap(). MinDat = MaxDat = %f \n", MaxDat);
    }
    else
    {
        unsigned char null = (unsigned char) (255.5 * (0.-MinDat)/(MaxDat-MinDat)); 
        for(int k=0; k<Nrow*Ncol; k++) bdat[k] = null;

        switch(MT)
        {
        case U_MAT_NULL:       break;
        case U_MAT_IDENTITY:    for(int k=0,kk=Ncol-1; k<Nrow; k++, kk+=Nrow-k-1) bdat[kk] = 255; break;
        case U_MAT_IDENTCONST:  for(int k=0,kk=Ncol-1; k<Nrow; k++, kk+=Nrow-k-1) bdat[kk] = 255; break;
        case U_MAT_DIAGONAL:    
            {
                for(int k=0,kk=Ncol-1; k<Nrow; k++, kk+=Nrow-k-1) 
                    bdat[kk] = (unsigned char) (255.5 * (Data[k]-MinDat)/(MaxDat-MinDat)); 
                break;
            }
        case U_MAT_SYMMETRIC:   
        case U_MAT_SQUARE:      
        case U_MAT_GENERAL:
            {
                for(int i=0;i<Nrow;i++)
                {
                    unsigned char* pb = bdat + Ncol*(Nrow-i-1);
                    double*        pM = Data + Ncol*i;
                    for(int j=0;j<Ncol;j++, pb++, pM++) *pb = (unsigned char) (255.5 * (*pM-MinDat)/(MaxDat-MinDat)); 
                }
                break;
            }
        }
    }
    UBitMap BM(Ncol, Nrow, bdat);
    delete[] bdat;
    BM.SetPallette(U_PALETTE_JET);
    return BM;
}
ErrorType UMatrix::Print(bool PrintToLog)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::Print(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }

    if(PrintToLog)
    {
        for(int i=0; i<Nrow; i++)
        {
            for(int j=0; j<Ncol-1; j++) CI.AddToLog("%14.10f \t", GetElement(i, j));
            CI.AddToLog("%14.10f\n", GetElement(i, Ncol-1));
        }
    }
    else
    {
        for(int i=0; i<Nrow; i++)
        {
            for(int j=0; j<Ncol-1; j++) fprintf(stderr, "%14.10f \t", GetElement(i, j));
            fprintf(stderr, "%14.10f\n", GetElement(i, Ncol-1));
        }
    }
    return U_OK;
}

ErrorType UMatrix::MergeRows(const UMatrix& M)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). Data not properly set.\n");
        return U_ERROR;
    }

    if(&M==NULL || M.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). NULL or erroeneous argument.\n");
        return U_ERROR;
    }
    if(M.Data==NULL && M.MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). M.Data not properly set.\n");
        return U_ERROR;
    }
    if(M.IsEmpty()) return U_OK;
    if(this->IsEmpty())
    {
        *this = M;
        return U_OK;
    }
    if(Ncol!=M.Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). Number of collums do not fit (Ncol=%d, M.Ncol=%d) .\n", Ncol, M.Ncol);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL && M.MT==U_MAT_NULL)
    {
        Nrow += M.Nrow;
        return U_OK;
    }
    int     NewNrow = Nrow + M.Nrow;
    double* NewDat  = new double[NewNrow*Ncol];
    if(NewDat==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeRows(). Memory allocation, NewNrow=%d, Ncol=%d .\n", NewNrow, Ncol);
        return U_ERROR;
    }
    for(int ij=0; ij<NewNrow*Ncol; ij++) NewDat[ij] = 0.;
    
    if(IsDiagonalType()==true)
    {
        for(int j=0; j<Ncol; j++) NewDat[j*(Ncol+1)] = GetElement(j,j);
    }
    else
    {
        double* pDat = Data;
        double* pNew = NewDat;
        int     Nrc  = Nrow*Ncol;
        for(int ij=0; ij<Nrc; ij++) *pNew++ = *pDat++;
    }

    double* pNew = NewDat+Nrow*Ncol;
    if(M.IsDiagonalType()==true)
    {
        for(int j=0; j<Ncol; j++) pNew[j*(Ncol+1)] = M.GetElement(j,j);
    }
    else
    {
        double* pDat = M.Data;
        int     Nrc  = M.Nrow*Ncol;
        for(int ij=0; ij<Nrc; ij++) *pNew++ = *pDat++;
    }
    Nrow = NewNrow;
    delete[] Data; Data = NewDat;
    MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    return U_OK;
}
ErrorType UMatrix::MergeCols(const UMatrix& M)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Data not properly set.\n");
        return U_ERROR;
    }

    if(&M==NULL || M.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). NULL or erroeneous argument.\n");
        return U_ERROR;
    }
    if(M.Data==NULL && M.MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). M.Data not properly set.\n");
        return U_ERROR;
    }
    if(M.IsEmpty()) return U_OK;
    if(this->IsEmpty())
    {
        *this = M;
        return U_OK;
    }
    if(Nrow!=M.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Number of rows do not fit (Nrow=%d, M.Nrow=%d) .\n", Nrow, M.Nrow);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL && M.MT==U_MAT_NULL)
    {
        Ncol += M.Ncol;
        return U_OK;
    }
    int     NewNcol = Ncol + M.Ncol;
    double* NewDat  = new double[Nrow*NewNcol];
    if(NewDat==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Memory allocation, Nrow=%d, NewNcol=%d .\n", Nrow, NewNcol);
        return U_ERROR;
    }
    for(int ij=0; ij<Nrow*NewNcol; ij++) NewDat[ij] = 0.;
    
    for(int i=0; i<Nrow; i++)
    {
        double* pNew = NewDat + i*NewNcol;
        double* pDat = Data   + i*Ncol;
        if(IsDiagonalType()==true    ) pNew[i] = GetElement(i,i);
        else for(int j=0; j<Ncol; j++) *pNew++ = *pDat++;

        pNew = NewDat  + i*NewNcol + Ncol;
        pDat = M.Data  + i*M.Ncol;
        if(M.IsDiagonalType()==true    ) pNew[i] = M.GetElement(i,i);
        else for(int j=0; j<M.Ncol; j++) *pNew++ = *pDat++;
    }
    
    Ncol = NewNcol;
    delete[] Data; Data = NewDat;
    MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    return U_OK;
}
ErrorType UMatrix::MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Data not properly set.\n");
        return U_ERROR;
    }
    if(Nrow!=Nr)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Number of rows (%d) do not match argument (Nr=%d).\n", Nrow, Nr);
        return U_ERROR;
    }
    int NcolAdd = 0;
    if(Col0) NcolAdd++;
    if(Col1) NcolAdd++;
    if(Col2) NcolAdd++;
    if(NcolAdd==0) return U_OK;

    int     NewNcol = Ncol+NcolAdd;
    double* NewData = new double[Nrow*NewNcol];
    if(NewData==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MergeCols(). Memory alocation, Nrow=%d, NewNcol=%d.\n", Nrow, NewNcol);
        return U_ERROR;
    }
    for(int ij=0; ij<Nrow*NewNcol; ij++) NewData[ij] = 0.;
    if(IsDiagonalType()==true)
    {
        for(int ir=0; ir<Nrow; ir++)
        {
            double* pRow = NewData + ir*NewNcol;
            pRow[ir] = GetElement(ir, ir);
            int ic = Ncol;
            if(Col0) pRow[ic++] = Col0[ir];
            if(Col1) pRow[ic++] = Col1[ir];
            if(Col2) pRow[ic++] = Col2[ir];
        }
    }
    else
    {
        if(MT!=U_MAT_NULL)
        {
            double* pData = Data;
            for(int ir=0; ir<Nrow; ir++)
            {
                double* pRow = NewData + ir*NewNcol;
                for(int ic=0; ic<Ncol; ic++) *pRow++ = *pData++;
            }
        }
        double* pData = Data;
        for(int ir=0; ir<Nrow; ir++)
        {
            double* pRow = NewData + ir*NewNcol;
            int     ic   = Ncol;
            if(Col0) pRow[ic++] = Col0[ir];
            if(Col1) pRow[ic++] = Col1[ir];
            if(Col2) pRow[ic++] = Col2[ir];
        }
    }
    delete[] Data; Data = NewData;
    Ncol = NewNcol;
    MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::AdaptDiagonalToConstantEigenvector(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::AdaptDiagonalToConstantEigenvector(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(Ncol!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::AdaptDiagonalToConstantEigenvector(). Number of rows (%d) not equal to number of collumns (%d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL) return U_OK;
    if(IsDiagonalType()==true) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::AdaptDiagonalToConstantEigenvector(). Data not properly set.\n");
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
    {
        double* pD   = Data +Nrow*i;
        *(pD + i)    = 0.;
        double  sum  = 0.;
        for(int j=0; j<Ncol; j++) sum += *pD++;
        *(pD-Ncol+i) = -sum;
    }
    return U_OK;
}

ErrorType UMatrix::ReshapeCols(int NewNcols)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ReshapeCols(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(NewNcols== Ncol) return U_OK;

    if(NewNcols<=0 || (Nrow*Ncol)%NewNcols)
    {
        CI.AddToLog("ERROR: UMatrix::ReshapeCols(). Invalid argument: NewNcols=%d,   Nrow*Ncol=%d.\n", NewNcols, Nrow*Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ReshapeCols(). Data not properly set.\n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true && ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ReshapeCols(). Forcing from diagonal to general type.\n");
        return U_ERROR;
    }

    Nrow = (Nrow*Ncol)/NewNcols;
    Ncol = NewNcols;

    MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    return U_OK;
}

ErrorType UMatrix::InvertSqrt()
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::InvertSqrt(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrix::InvertSqrt(). Function only implemented for positive diagonal matrices.\n");
        return U_ERROR;
    }
    switch(MT)
    {
    case U_MAT_NULL:       return U_ERROR;
    case U_MAT_IDENTITY:    return U_OK;
    case U_MAT_IDENTCONST:  
        if(Data==NULL || Data[0]<=0.)
        {
            CI.AddToLog("ERROR: UMatrix::InvertSqrt(). Data not set or negative.\n");
            return U_ERROR;
        }
        Data[0] =  1./sqrt( Data[0]);
        return U_OK;
    case U_MAT_DIAGONAL:  
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::InvertSqrt(). Data not set.\n");
            return U_ERROR;
        }
        for(int k=0; k<Ncol; k++) 
        {
            if(Data[k]>0) continue;
            CI.AddToLog("ERROR: UMatrix::InvertSqrt(). Diagonal matrix elemen %d non-positive (%f).\n", k, Data[k]);
            return U_ERROR;
        }
        for(int k=0; k<Ncol; k++) Data[k] =  1./sqrt( Data[k]);
        return U_OK;
    default: break;
    }
    return U_ERROR;
}

bool UMatrix::AreElementsNonNegative(void) const
{
    if(this==NULL || error!=U_OK) return false;
    if(MT==U_MAT_NULL)           return true;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::AreElementsNonNegative(). Data not properly set.\n");
        return false;
    }
    int           N   = GetNelem();
    const double* pD  = Data; 
    for(int n=0; n<N; n++) if(*pD++ < 0.) return false;
    return true;
}
ErrorType UMatrix::NormalizeCols(int skipcol1, int skipcol2,int skipcol3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("WARNING: UMatrix::NormalizeCols(). Matrix Empty. \n");
        return U_OK;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::NormalizeCols(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()) return NormalizeRows(skipcol1, skipcol2, skipcol3);

    for(int icol=0; icol<Ncol; icol++)
    {
        if(icol==skipcol1 || icol==skipcol2 || icol==skipcol3) continue;
        double Norm = GetFrobNormCol(icol);
        if(Norm<=0.) 
        {
            CI.AddToLog("WARNING: UMatrix::NormalizeCols(). Zero norm at col %d . \n", icol);
            continue;
        }
        double* pMat = Data+icol;
        for(int j=0; j<Nrow; j++,pMat+=Ncol) *pMat /= Norm;
    }
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::NormalizeRows(int skiprow1, int skiprow2, int skiprow3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("WARNING: UMatrix::NormalizeRows(). Matrix Empty. \n");
        return U_OK;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::NormalizeRows(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(skiprow1>=Nrow) skiprow1 =-1;
    if(skiprow2>=Nrow) skiprow2 =-1;
    if(skiprow3>=Nrow) skiprow3 =-1;

    if((MT==U_MAT_IDENTITY||MT==U_MAT_IDENTCONST) &&(skiprow1>=0||skiprow2>=0||skiprow3>=0))
    {
        double* Diag = new double[Nrow];
        if(Diag==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::NormalizeRows(). Memory allocation. \n");
            return U_ERROR;
        }
        for(int i=0; i<Nrow; i++) Diag[i] = (i==skiprow1||i==skiprow2||i==skiprow3)? Data[0] : 1.;
        delete[] Data; Data = Diag;
        MT = U_MAT_DIAGONAL;
        return U_OK;
    }
    if(MT==U_MAT_IDENTITY) return U_OK;

    if(MT==U_MAT_IDENTCONST)
    {
        if(Data[0]==0.) CI.AddToLog("WARNING: UMatrix::NormalizeRows(). Zero diagonal matrix zero. \n");

        MT      = U_MAT_IDENTITY;
        Data[0] = 1.;
        return U_OK;
    }
    if(MT==U_MAT_DIAGONAL)
    {
        if(skiprow1<0&&skiprow2<0&&skiprow3<0)
        {
            for(int irow=0; irow<Nrow; irow++)
            {
                double Norm = GetFrobNormRow(irow);
                if(Norm<=0.) CI.AddToLog("WARNING: UMatrix::NormalizeRows(). Zero diagonal matrix at row %d . \n", irow);
            }
            MT      = U_MAT_IDENTITY;
            Data[0] = 1.;
        }
        else
        {
            for(int i=0; i<Nrow; i++) Data[i] = (i==skiprow1||i==skiprow2||i==skiprow3)? Data[i] : 1.;
        }
        return U_OK;
    }
    for(int irow=0; irow<Nrow; irow++)
    {
        if(irow==skiprow1 || irow==skiprow2 || irow==skiprow3) continue;
        double Norm = GetFrobNormRow(irow);
        if(Norm<=0.) 
        {
            CI.AddToLog("WARNING: UMatrix::NormalizeRows(). Zero norm at row %d . \n", irow);
            continue;
        }
        double* pMat = Data+irow*Ncol;
        for(int j=0; j<Ncol; j++,pMat++) *pMat /= Norm;
    }
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::SubstractCol(int icol, int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractCol(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractCol(). Function not implemented for Diagonal type. \n");
        return U_ERROR;
    }
    if(icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractCol(). Parameter out of range: icol = %d. \n", icol);
        return U_ERROR;
    }

    if(skipcol1>=Ncol) skipcol1 = -1;
    if(skipcol2>=Ncol) skipcol2 = -1;

    for(int i=0; i<Nrow; i++)
    {
        double  Val  = Data[i*Ncol+icol];
        double* pDat = Data+i*Ncol;
        for(int j=0; j<Ncol; j++)
        {
            if(j==skipcol1 || j==skipcol2) continue;
            *pDat -= Val;
        }
    }

    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::DeMeanRows(int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanRows(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanRows(). Function not implemented for Diagonal type. \n");
        return U_ERROR;
    }

    if(skipcol1>=Ncol) skipcol1 = -1;
    if(skipcol2>=Ncol) skipcol2 = -1;
    int Nskip = (skipcol1<0 && skipcol2<0) ? 0 : (skipcol1>=0 && skipcol2>=0) ? 2 : 1;
    if(Ncol-Nskip<=0) 
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanRows(). Too few collums (Ncol=%d, Nskip=%d). \n", Ncol, Nskip);
        return U_ERROR;
    }
    if(Nskip==0)
    {
        for(int irow=0; irow<Nrow; irow++)
        {
            double  Mean = GetRowSum(irow)/Ncol;
            double* pMat = Data+irow*Ncol;
            for(int j=0; j<Ncol; j++,pMat++) *pMat -= Mean;
        }
    }
    else
    {
        for(int irow=0; irow<Nrow; irow++)
        {
            double* pMat = Data+irow*Ncol;
            double  Mean = GetRowSum(irow);
            if(skipcol1>=0) Mean-=pMat[skipcol1];
            if(skipcol2>=0) Mean-=pMat[skipcol2];
            Mean /= (Ncol-Nskip);
            
            for(int j=0; j<Ncol; j++,pMat++) *pMat -= Mean;

            if(skipcol1>=0) pMat[skipcol1-Ncol] = 0.;
            if(skipcol2>=0) pMat[skipcol2-Ncol] = 0.;
        }
    }
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::SubstractRow(int irow, int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractRow(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractRow(). Function not implemented for Diagonal type. \n");
        return U_ERROR;
    }
    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::SubstractRow(). Parameter out of range: irow = %d \n", irow);
        return U_ERROR;
    }

    if(skiprow1>=Nrow) skiprow1 = -1;
    if(skiprow2>=Nrow) skiprow2 = -1;

    for(int j=0; j<Ncol; j++)
    {
        double  Val  = Data[irow*Ncol+j];
        double* pDat = Data+j;
        for(int i=0; i<Nrow; i++, pDat+=Ncol)
        {
            if(i==skiprow1 || i==skiprow2) continue;
            *pDat -= Val;
        }
    }

    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::DeMeanCols(int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanCols(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanCols(). Function not implemented for Diagonal type. \n");
        return U_ERROR;
    }

    if(skiprow1>=Nrow) skiprow1 = -1;
    if(skiprow2>=Nrow) skiprow2 = -1;
    int Nskip = (skiprow1<0 && skiprow2<0) ? 0 : (skiprow1>=0 && skiprow2>=0) ? 2 : 1;
    if(Nrow-Nskip<=0) 
    {
        CI.AddToLog("ERROR: UMatrix::DeMeanCols(). Too few rows (Nrow=%d, Nskip=%d). \n", Nrow, Nskip);
        return U_ERROR;
    }
    if(Nskip==0)
    {
        for(int icol=0; icol<Ncol; icol++)
        {
            double  Mean = GetColSum(icol)/Nrow;
            double* pMat = Data+icol;
            for(int j=0; j<Nrow; j++,pMat+=Ncol) *pMat -= Mean;
        }
    }
    else
    {
        for(int icol=0; icol<Ncol; icol++)
        {
            double* pMat = Data+icol;
            double  Mean = GetColSum(icol);
            if(skiprow1>=0) Mean-=pMat[Ncol*skiprow1];
            if(skiprow2>=0) Mean-=pMat[Ncol*skiprow2];
            Mean /= (Nrow-Nskip);
            
            for(int j=0; j<Nrow; j++,pMat+=Ncol) *pMat -= Mean;

            if(skiprow1>=0) pMat[Ncol*(skiprow1-Nrow)] = 0.;
            if(skiprow2>=0) pMat[Ncol*(skiprow2-Nrow)] = 0.;
        }
    }
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::ReverseCols(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ReverseCols(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true && ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ReverseCols(). Forcing general type. \n");
        return U_ERROR;
    }
    if(Nrow==Ncol) MT = U_MAT_SQUARE;

    for(int irow=0; irow<Nrow; irow++)
    {
        double* pDat = Data + irow*Ncol;
        for(int icol=0; icol<Ncol/2; icol++)
        {
            double dum        = pDat[icol       ];
            pDat[icol       ] = pDat[Ncol-1-icol];
            pDat[Ncol-1-icol] = dum;
        }
    }
    return U_OK;
}
ErrorType UMatrix::ReverseRows(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ReverseRows(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(IsDiagonalType()==true && ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ReverseRows(). Forcing general type. \n");
        return U_ERROR;
    }
    if(Nrow==Ncol) MT = U_MAT_SQUARE;

    for(int icol=0; icol<Ncol; icol++)
    {
        double* pDat = Data + icol;
        for(int irow=0; irow<Nrow/2; irow++)
        {
            double dum               = pDat[irow*Ncol         ];
            pDat[irow*Ncol         ] = pDat[(Nrow-1-irow)*Ncol];
            pDat[(Nrow-1-irow)*Ncol] = dum;
        }
    }
    return U_OK;
}
ErrorType UMatrix::SwapCols(int col1, int col2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SwapCols(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(col1<0 || col1>=Ncol || col2<0 || col2>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SwapCols(). Parameters out of range: col1=%d, col2=%d . \n", col1, col2);
        return U_ERROR;
    }
    if(col1==col2) return U_OK;

    if(IsDiagonalType()==true && ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SwapCols(). Forcing general type. \n");
        return U_ERROR;
    }
    if(Nrow==Ncol) MT = U_MAT_SQUARE;

    double* pDat1 = Data + col1;
    double* pDat2 = Data + col2;
    for(int irow=0; irow<Nrow; irow++, pDat1+=Ncol, pDat2+=Ncol)
    {
        double dum = *pDat1;
        *pDat1     = *pDat2;
        *pDat2     = dum;
    }
    return U_OK;
}
ErrorType UMatrix::SwapRows(int row1, int row2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL) return U_OK;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SwapRows(). Data matrix not set. \n");
        return U_ERROR;
    }
    if(row1<0 || row1>=Nrow || row2<0 || row2>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::SwapRows(). Parameters out of range: row1=%d, row2=%d . \n", row1, row2);
        return U_ERROR;
    }
    if(row1==row2) return U_OK;

    if(IsDiagonalType()==true && ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SwapRows(). Forcing general type. \n");
        return U_ERROR;
    }
    if(Nrow==Ncol) MT = U_MAT_SQUARE;

    double* pDat1 = Data + Ncol*row1;
    double* pDat2 = Data + Ncol*row2;
    for(int icol=0; icol<Ncol; icol++, pDat1++, pDat2++)
    {
        double dum = *pDat1;
        *pDat1     = *pDat2;
        *pDat2     = dum;
    }
    return U_OK;
}

ErrorType UMatrix::InsertZeroRows(const bool* NonZeroRows, int NewNrow)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    int NRowNonZ = UMatrix::GetNSelect(NonZeroRows, NewNrow);

    if(NRowNonZ!=Nrow) 
    {
        CI.AddToLog("ERROR: UMatrix::InsertZeroRows(). Nrow (%d) not equal to NRowNonZ (%d). \n", Nrow, NRowNonZ);
        return U_ERROR;
    }
    if(Nrow >NewNrow)
    {
        CI.AddToLog("ERROR: UMatrix::InsertZeroRows(). Nrow (%d) larger than NewNrow (%d). \n", Nrow, NewNrow);
        return U_ERROR;
    }
    if(Nrow==NewNrow) return U_OK;
    if(MT==U_MAT_NULL) 
    {
        Nrow = NewNrow;
        return U_OK;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::InsertZeroRows(). Data matrix not set. \n");
        return U_ERROR;
    }
    double* NewData = new double[NewNrow*Ncol];
    if(NewData==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::InsertZeroRows(). Memory allocation, (NewNrow, Ncol) = (%d, %d). \n", NewNrow, Ncol);
        return U_ERROR;
    }
    double * pData    = Data;
    double * pNewData = NewData;
    if(IsDiagonalType()==true)
    {
        for(int i=0,isel=0; i<NewNrow; i++)
        {
            if(NonZeroRows[i]==true)   for(int j=0; j<Ncol; j++) *pNewData++ = GetElement(isel, j);
            else                       for(int j=0; j<Ncol; j++) *pNewData++ = 0.;
            if(NonZeroRows[i]==true)   isel++;
        }
    }
    else
    {
        for(int i=0; i<NewNrow; i++)
        {
            if(NonZeroRows[i]==true)   for(int j=0; j<Ncol; j++) *pNewData++ = *pData++;
            else                       for(int j=0; j<Ncol; j++) *pNewData++ = 0.;
        }
    }
    delete[] Data; Data = NewData;
    Nrow = NewNrow;
    MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    return U_OK;
}

UMatrix UMatrix::GetGramSchmidtRows(void) const
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL||MT==U_MAT_IDENTITY||MT==U_MAT_IDENTCONST||MT==U_MAT_DIAGONAL) return *this;

    UMatrix GramS = *this; GramS.MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    for(int row1=1; row1<Nrow; row1++) //loop over all rows (except first, since it has no projections to remove)
    {
        double Amp2 = GetFrobNorm2Row(row1);
        if(Amp2<=0.) continue;

        for(int row2=row1+1; row2<Nrow; row2++) // loop over all following rows
        {
            const double* pDat1 = GramS.Data+row1*Ncol;
                  double* pDat2 = GramS.Data+row2*Ncol;
            double        Imp   = 0;
            for(int col=0; col<Ncol; col++, pDat1++, pDat2++) Imp += *pDat1 * *pDat2;
            
            double fact = Imp/Amp2;
            pDat1       = GramS.Data+row1*Ncol;
            pDat2       = GramS.Data+row2*Ncol; // remove projection from row2
            for(int col=0; col<Ncol; col++) *pDat2++ -= fact* *pDat1++;
        }
    }
    return GramS;
}
UMatrix UMatrix::GetSIGN(void) const
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL) return *this;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSIGN(). Data not set. \n");
        return UMatrix(U_ERROR);
    }

    UMatrix M(*this);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSIGN(). Copying this. \n");
        return UMatrix(U_ERROR);
    }
    int     N   = GetNelem();
    double* pMD = M.Data; 
    for(int k=0; k<N; k++, pMD++) *pMD = SIGN(*pMD);

    return M;
}

ErrorType UMatrix::Shrink(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL)            return U_OK;
    if(Data==NULL)                return U_ERROR;

    if(Nzero) *Nzero=0;
    if(Lamda<=0.)
    {
        CI.AddToLog("ERROR: UMatrix::Shrink(). Parameter out of range: Lamda=%f  .\n"), Lamda;
        return U_ERROR;
    }

    double* pDat  = Data;
    if(MT==U_MAT_SYMMETRIC || MT==U_MAT_SQUARE || MT==U_MAT_GENERAL)
    {
        for(int n=0; n<Nrow*Ncol; n++,pDat++) 
        {
            double Dat = *pDat;
            *pDat = Dat>Lamda ? Dat-Lamda : (Dat<-Lamda ? Dat+Lamda : 0.);
            if(Nzero && *pDat==0.) (*Nzero)++;
        }
    }
    else
    {
        int Nelem = GetNelem();
        for(int k=0; k<Nelem; k++, pDat++) 
        {
            double Dat=*pDat; 
            *pDat = Dat>Lamda ? Dat-Lamda : (Dat<-Lamda ? Dat+Lamda : 0.);
            if(Nzero && *pDat==0.) (*Nzero)++;
        }
    }
    if(MT==U_MAT_IDENTITY) MT=U_MAT_IDENTCONST;
    return U_OK;
}
ErrorType UMatrix::ShrinkRows(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL)            return U_OK;
    if(Data==NULL)                return U_ERROR;

    if(Nzero) *Nzero=0;
    if(Lamda<=0.)
    {
        CI.AddToLog("ERROR: UMatrix::ShrinkRows(). Parameter out of range: Lamda=%f  .\n"), Lamda;
        return U_ERROR;
    }

    double* pDat  = Data;
    if(MT==U_MAT_SYMMETRIC || MT==U_MAT_SQUARE || MT==U_MAT_GENERAL)
    {
        for(int ir=0; ir<Nrow; ir++) 
        {
            double Norm = GetFrobNormRow(ir);
            if(Norm<Lamda)
            {
                for(int ic=0; ic<Ncol; ic++, pDat++) *pDat = 0.;
                if(Nzero) (*Nzero)++;
            }
            else
            {
                for(int ic=0; ic<Ncol; ic++, pDat++) *pDat = (*pDat/Norm)*(Norm-Lamda);
            }
        }
    }
    else
    {
        int Nelem = GetNelem();
        for(int k=0; k<Nelem; k++, pDat++) 
        {
            double Dat=*pDat; 
            *pDat = Dat>Lamda ? Dat-Lamda : (Dat<-Lamda ? Dat+Lamda : 0.);
            if(Nzero && *pDat==0.) (*Nzero)++;
        }
    }
    if(MT==U_MAT_IDENTITY) MT=U_MAT_IDENTCONST;
    return U_OK;
}

ErrorType UMatrix::SetDataRandom(double Amp, int seed)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrix::SetDataRandom(). Matrix is identity.\n");
        return U_ERROR;
    }
    if(Amp==0.)
    {
        delete[] Data; Data=NULL;
        MT = U_MAT_NULL;
        return U_OK;
    }

    if(MT==U_MAT_NULL)
    {
        if(Nrow<=0 || Ncol<=0) return U_OK;

        Data = new double[Nrow*Ncol];
        MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    }
    else if(MT==U_MAT_IDENTCONST)
    {
        delete[] Data;  Data = new double[Ncol];
        MT = U_MAT_DIAGONAL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetDataRandom(). Memory allocation or Data not set (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }

    int SeedPoint = seed;
    if(seed<=0) 
    {
        time_t long_time;
        time( &long_time );
        SeedPoint = int(long_time);
    }
    srand(SeedPoint);

    int N       = GetNelem();
    int MaxRand = Nrow*Ncol;
    Amp         = Amp/MaxRand;
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;

    for(int n=0; n<N; n++) Data[n] = Amp*double(rand() % MaxRand);
    return U_OK;
}
ErrorType UMatrix::SetDataGaussian(double Amp, int seed)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrix::SetDataGaussian(). Matrix is identity.\n");
        return U_ERROR;
    }
    if(Amp<=0.)
    {
        CI.AddToLog("ERROR: UMatrix::SetDataGaussian(). Invalid amplitude parameter (%f).\n", Amp);
        return U_ERROR;
    }

    if(MT==U_MAT_NULL)
    {
        if(Nrow<=0 || Ncol<=0) return U_OK;

        Data = new double[Nrow*Ncol];
        MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    }
    else if(MT==U_MAT_IDENTCONST)
    {
        delete[] Data;  Data = new double[Ncol];
        MT = U_MAT_DIAGONAL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetDataGaussian(). Memory allocation or Data not set (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }

    UGaussian G(Amp, 0., seed);
    int N       = GetNelem();
    if(MT==U_MAT_SYMMETRIC) MT = U_MAT_SQUARE;

    for(int n=0; n<N; n++) Data[n] = G.GetGaussian();
    return U_OK;
}
ErrorType UMatrix::SetData(int irow, int icol, const UMatrix& M)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    
    if(irow<0 || icol<0)
    {
        CI.AddToLog("ERROR: UMatrix::SetData(). Invalid arguments (irow=%d, icol=%d)\n", irow, icol);
        return U_ERROR;
    }
    if(irow+M.Nrow > Nrow || icol+M.Ncol > Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SetData(). Arguments (irow=%d, icol=%d) out of range, M.Nrow=%d, M.Ncol=%d .\n", irow, icol, M.Nrow, M.Ncol);
        return U_ERROR;
    }
    if(M.IsEmpty()) return U_OK;
    if(MT==U_MAT_NULL && M.MT==U_MAT_NULL) return U_OK;

    if(this->IsDiagonalType()==true && this->ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SetData(). Forcing general type.\n");
        return U_ERROR;
    }
    if(Data==NULL) return U_ERROR;

    if(M.IsDiagonalType())
    {
        for(int ir=irow; ir<irow+M.Nrow; ir++)
        {
            double* pD  =  Data +  ir*Ncol + icol;
            for(int ic=icol; ic<icol+M.Ncol; ic++) *pD++ = M.GetElement(ir-irow, ic-icol);
        }
    }
    else
    {
        const double* pMD = M.Data;
        for(int ir=irow; ir<irow+M.Nrow; ir++)
        {
            double* pD  =  Data +  ir*Ncol + icol;
            for(int ic=icol; ic<icol+M.Ncol; ic++) *pD++ = *pMD++;
        }
    }
    return U_OK;
}
ErrorType UMatrix::SetData(double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    switch(MT)
    {
    case U_MAT_NULL     : if(Value==0.) return U_OK; 
                           if(Nrow==0 || Ncol==0) return U_OK;
                           Data = new double[Nrow*Ncol];
                           if(Data==NULL)
                           {
                                CI.AddToLog("ERROR: UMatrix::SetData(). Memory allocation (Nrow=%d, Ncol=%d).\n", Nrow, Ncol);
                                return U_ERROR;
                           }
                           MT = (Nrow==Ncol) ? U_MAT_SYMMETRIC : U_MAT_GENERAL;
                           break;

    case U_MAT_IDENTITY  : if(Value==1.) return U_OK; return U_ERROR;
    default: break;
    }
    if(Value==0.)
    {
        delete[] Data; Data = NULL;
        MT = U_MAT_NULL;
        return U_OK;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetData(). Data not set.\n");
        return U_ERROR;
    }
    int     N  = GetNelem();
    double* pD = Data;
    for(int n=0; n<N; n++,pD++) *pD= Value;
    
    if(MT==U_MAT_DIAGONAL) MT = U_MAT_IDENTCONST;
    if(MT==U_MAT_SQUARE  ) MT = U_MAT_SYMMETRIC;
    return U_OK;
}
ErrorType UMatrix::SetUnitVector(int iunit, int Ndim, bool ColVect)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Ndim<=0)
    {
        CI.AddToLog("ERROR: UMatrix::SetUnitVector(). Argument out of range: Ndim=%d\n", Ndim);
        return U_ERROR;
    }
    if(iunit<0 || Ndim<=iunit)
    {
        CI.AddToLog("ERROR: UMatrix::SetUnitVector(). Argument out of range: iunit=%d\n", iunit);
        return U_ERROR;
    }

    if(GetNelem()!=Ndim || Data==NULL)
    {
        delete[] Data; Data = new double[Ndim];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::SetUnitVector(). Memory allocation, Ndim=%d\n", Ndim);
            return U_ERROR;
        }
    }
    for(int k=0; k<Ndim; k++) Data[k]=0.;
    Data[iunit]=1.;
    MT   = U_MAT_GENERAL;
    Nrow = ColVect ? Ndim : 1   ;
    Ncol = ColVect ? 1    : Ndim;

    return U_OK;
}
ErrorType UMatrix::SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MinUnit<0 || MaxUnit<MinUnit)
    {
        CI.AddToLog("ERROR: UMatrix::SetUnitVectors(). Argument(s) out of range: MinUnit=%d, MaxUnit=%d\n", MinUnit, MaxUnit);
        return U_ERROR;
    }
    int NUnit = MaxUnit-MinUnit+1;
    if(ColVect && (NUnit>Ncol || Nrow<MaxUnit+1))
    {
        CI.AddToLog("ERROR: UMatrix::SetUnitVectors(). Number of collmuns out of range: Ncol = %d, MinUnit=%d, MaxUnit=%d\n", Ncol, MinUnit, MaxUnit);
        return U_ERROR;
    }
    if(NOT(ColVect) && (NUnit>Nrow || Ncol<MaxUnit+1))
    {
        CI.AddToLog("ERROR: UMatrix::SetUnitVectors(). Number of rows out of range: Nrow = %d, MinUnit=%d, MaxUnit=%d\n", Nrow, MinUnit, MaxUnit);
        return U_ERROR;
    }
    if(MinUnit==0 && Nrow==Ncol)
    {
        *this = UMatrix(Ncol);
        return U_OK;
    }

    if(GetNelem()!=Nrow*Ncol || Data==NULL)
    {
        delete[] Data; Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::SetUnitVectors(). Memory allocation, Nrow=%d, Ncol=%d\n", Nrow, Ncol);
            return U_ERROR;
        }
    }
    for(int k=0; k<Nrow*Ncol; k++) Data[k] = 0.;
    if(ColVect)
    {
        for(int j=0; j<NUnit; j++) Data[(MinUnit+j)*Ncol+j] = 1.;
    }
    else
    {
        for(int i=0; i<NUnit; i++) Data[i*Ncol+(MinUnit+i)] = 1.;
    }
    MT = Nrow==Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::SetPolynomials(int MinDeg, int MaxDeg, bool ColVect)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MinDeg<0 || MaxDeg<MinDeg)
    {
        CI.AddToLog("ERROR: UMatrix::SetPolynomials(). Argument(s) out of range: MinDeg=%d, MaxDeg=%d\n", MinDeg, MaxDeg);
        return U_ERROR;
    }
    int Ndeg = MaxDeg-MinDeg+1;
    if(ColVect && Ndeg!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SetPolynomials(). Number of collmuns out of range: Ncol = %d, MinDeg=%d, MaxDeg=%d\n", Ncol, MinDeg, MaxDeg);
        return U_ERROR;
    }
    if(NOT(ColVect) && Ndeg!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::SetPolynomials(). Number of rows out of range: Nrow = %d, MinDeg=%d, MaxDeg=%d\n", Nrow, MinDeg, MaxDeg);
        return U_ERROR;
    }

    if(GetNelem()!=Nrow*Ncol || Data==NULL)
    {
        delete[] Data; Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::SetPolynomials(). Memory allocation, Nrow=%d, Ncol=%d\n", Nrow, Ncol);
            return U_ERROR;
        }
    }
    if(ColVect)
    {
        for(int i=0; i<Nrow; i++)
        {
            double t = i /double(Ncol);
            Data[i*Ncol+0] = pow(t, double(MinDeg));
            for(int j=1; j<Ncol; j++) Data[i*Ncol+1] = t*Data[i*Ncol+j-1];
        }
    }
    else
    {
        for(int j=0; j<Ncol; j++)
        {
            double t = j /double(Nrow);
            Data[0*Ncol+j] = pow(t, double(MinDeg));
            for(int i=1; i<Nrow; i++) Data[i*Ncol+j] = t*Data[(i-1)*Ncol+j];
        }
    }
    MT = Nrow==Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::SetElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(irow<0||irow>=Nrow) 
    {
        CI.AddToLog("ERROR: UMatrix::SetElement(). irow (=%d) out of range, Nrow = %d.\n", irow, Nrow);
        return U_ERROR;
    }
    if(icol<0||icol>=Ncol) 
    {
        CI.AddToLog("ERROR: UMatrix::SetElement(). icol (=%d) out of range, Ncol = %d.\n", icol, Ncol);
        return U_ERROR;
    }

    switch(MT)
    {
    case U_MAT_NULL     : if(Value==0.) return U_OK; 
                           Data = new double[Nrow*Ncol];
                           if(Data==NULL)
                           {
                                CI.AddToLog("ERROR: UMatrix::SetElement(). Memory allocation (Nrow=%d, Ncol=%d).\n", Nrow, Ncol);
                                return U_ERROR;
                           }
                           for(int k=0; k<Nrow*Ncol; k++) Data[k] = 0.;
                           MT = (Nrow==Ncol) ? ( (irow==icol) ? U_MAT_SYMMETRIC : U_MAT_SQUARE ) : U_MAT_GENERAL;
                           break;

    case U_MAT_IDENTITY  : if(Value==1. && irow==icol) return U_OK; 
                           break;
    default:               break;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetElement(). Data not set.\n");
        return U_ERROR;
    }

    if(IsDiagonalType()==true)
    {
        if(Value==0. && irow!=icol) return U_OK;
        if(irow==icol)
        {
            if(MT==U_MAT_DIAGONAL)
            {
                Data[irow] = Value;
                return U_OK;
            }
            double* NewData = new double[Ncol];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::SetElement(). Memory allocation (Ncol=%d).\n", Ncol);
                return U_ERROR;
            }
            for(int k=0; k<Ncol; k++) NewData[k] = Data[0];
            NewData[irow] = Value;
            delete[] Data; Data = NewData;
            MT = U_MAT_DIAGONAL;
            return U_OK;
        }
        if(ForceGeneralType()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrix::SetElement(). Forcing general type.\n");
            return U_ERROR;
        }
    }
    Data[irow*Ncol+icol] = Value;
    
    if(MT==U_MAT_SYMMETRIC && Data[icol*Ncol+irow]!=Value) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::AddElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(irow<0||irow>=Nrow) 
    {
        CI.AddToLog("ERROR: UMatrix::AddElement(). irow (=%d) out of range, Nrow = %d.\n", irow, Nrow);
        return U_ERROR;
    }
    if(icol<0||icol>=Ncol) 
    {
        CI.AddToLog("ERROR: UMatrix::AddElement(). icol (=%d) out of range, Ncol = %d.\n", icol, Ncol);
        return U_ERROR;
    }
    if(Value==0.) return U_OK; 

    if(MT==U_MAT_NULL)
    {
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
             CI.AddToLog("ERROR: UMatrix::AddElement(). Memory allocation (Nrow=%d, Ncol=%d).\n", Nrow, Ncol);
             return U_ERROR;
        }
        for(int k=0; k<Nrow*Ncol; k++) Data[k] = 0.;
        MT = (Nrow==Ncol) ? ( (irow==icol) ? U_MAT_SYMMETRIC : U_MAT_SQUARE ) : U_MAT_GENERAL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::AddElement(). Data not set.\n");
        return U_ERROR;
    }

    if(IsDiagonalType()==true)
    {
        if(irow==icol)
        {
            if(MT==U_MAT_DIAGONAL)
            {
                Data[irow] += Value;
                return U_OK;
            }
            double* NewData = new double[Ncol];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::AddElement(). Memory allocation (Ncol=%d).\n", Ncol);
                return U_ERROR;
            }
            for(int k=0; k<Ncol; k++) NewData[k] = Data[0];
            NewData[irow] += Value;
            delete[] Data; Data = NewData;
            MT = U_MAT_DIAGONAL;
            return U_OK;
        }
        if(ForceGeneralType()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrix::AddElement(). Forcing general type.\n");
            return U_ERROR;
        }
    }
    Data[irow*Ncol+icol] += Value;
    
    if(Nrow==Ncol) MT = U_MAT_SQUARE;
    return U_OK;
}
ErrorType UMatrix::SetRow(int irow, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(irow<0||irow>=Nrow) 
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). irow (=%d) out of range, Nrow = %d.\n", irow, Nrow);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL)
    {
        if(Value==0.) return U_OK; 
        if(Nrow==0 || Ncol==0) return U_OK;
    }
    if(ForceGeneralType()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). Forcing general type.\n");
        return U_ERROR;
    }

    double* pRow = Data + irow*Ncol;
    for(int ic=0; ic<Ncol; ic++) *pRow++  = Value;
    
    return U_OK;
}
ErrorType UMatrix::SetRow(int irow, const UMatrix& Row)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(irow<0||irow>=Nrow) 
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). irow (=%d) out of range, Nrow = %d.\n", irow, Nrow);
        return U_ERROR;
    }
    if(&Row==NULL || Row.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). Matrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Row.GetNcol()!=Ncol || Row.GetNrow()!=1)
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). Matrix argument dimensions do not fit (%d, %d).\n", Row.GetNrow(), Row.GetNcol());
        return U_ERROR;
    }
    if(MT==U_MAT_NULL && Row.MT==U_MAT_NULL) return U_OK; 
    if(ForceGeneralType()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetRow(). Forcing general type.\n");
        return U_ERROR;
    }

    double*       pRow = Data + irow*Ncol;
    const double* pR   = Row.Data;
    for(int ic=0; ic<Ncol; ic++) *pRow++  = *pR++;

    return U_OK;
}

ErrorType UMatrix::SetCol(int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(icol<0||icol>=Ncol) 
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). icol (=%d) out of range, Ncol = %d.\n", icol, Ncol);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL)
    {
        if(Value==0.) return U_OK; 
        if(Nrow==0 || Ncol==0) return U_OK;
    }
    if(ForceGeneralType()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). Forcing general type.\n");
        return U_ERROR;
    }

    double* pCol = Data + icol;
    for(int ir=0; ir<Nrow; ir++, pCol+=Ncol) *pCol  = Value;
    
    return U_OK;
}
ErrorType UMatrix::SetCol(int icol, const UMatrix& Col)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(icol<0||icol>=Ncol) 
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). icol (=%d) out of range, Ncol = %d.\n", icol, Ncol);
        return U_ERROR;
    }
    if(&Col==NULL || Col.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). Matrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Col.GetNrow()!=Nrow || Col.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). Matrix argument dimensions do not fit (%d, %d).\n", Col.GetNrow(), Col.GetNcol());
        return U_ERROR;
    }
    if(MT==U_MAT_NULL && Col.MT==U_MAT_NULL) return U_OK; 
    if(ForceGeneralType()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetCol(). Forcing general type.\n");
        return U_ERROR;
    }

    double*       pCol = Data + icol;
    const double* pC   = Col.Data;
    for(int ir=0; ir<Nrow; ir++, pCol+=Ncol) *pCol  = *pC++;
    return U_OK;
}
ErrorType UMatrix::CopyCol(int icol, int DestBegin, int DestEnd)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(icol     <0) icol      += Ncol; // -1 indicates last col
    if(DestBegin<0) DestBegin += Ncol; // -1 indicates last col
    if(DestEnd  <0) DestEnd   += Ncol; // -1 indicates last col
    if(icol<0||icol>=Ncol) 
    {
        CI.AddToLog("ERROR: UMatrix::CopyCol(). icol (=%d) out of range, Ncol = %d.\n", icol, Ncol);
        return U_ERROR;
    }
    if(DestBegin<0 || DestEnd<DestBegin || Ncol<=DestEnd)
    {
        CI.AddToLog("ERROR: UMatrix::CopyCol(). Destination collums out of range: DestBegin = %d, DestEnd = %d, Ncol = %d.\n", DestBegin, DestEnd, Ncol);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL) return U_OK; 
    if(ForceGeneralType()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::CopyCol(). Forcing general type.\n");
        return U_ERROR;
    }
    MT = Ncol==Nrow ? U_MAT_SQUARE : U_MAT_GENERAL;

    for(int i=0; i<Nrow; i++)
    {
        double* pRow = Data + i*Ncol;
        for(int j=DestBegin; j<=DestEnd; j++) pRow[j] = pRow[icol];
    }
    return U_OK;
}

ErrorType UMatrix::ApplyFunction(double (f) (double))
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL)
    {
        if(Nrow<=0 || Ncol<=0) return U_OK;
        if(f(0.)==0.)          return U_OK;

        Data = new double[Nrow*Ncol];
        MT   = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    }
    else if(MT==U_MAT_IDENTCONST)
    {
        delete[] Data;  Data = new double[Ncol];
        MT = U_MAT_DIAGONAL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ApplyFunction(). Memory allocation or Data not set (%d, %d).\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(MT==U_MAT_NULL)
    {
        return SetData(f(0));
    }
    if(MT==U_MAT_IDENTITY)
    { 
        Data[0] = f(1.);
        if(Data[0]!=1.) MT=U_MAT_IDENTCONST;
        return U_OK;
    }

    if(MT==U_MAT_SYMMETRIC)
    {
        for(int i=0; i<Nrow; i++)
            for(int j=0; j<Ncol; j++)
                if(j>=i)  Data[i*Ncol+j] = f(Data[i*Ncol+j]);
                else      Data[i*Ncol+j] =   Data[j*Ncol+i];
    }
    else
    {
        int N  = GetNelem();
        for(int n=0; n<N; n++) Data[n] = f(Data[n]);
    }
    return U_OK;
}
ErrorType UMatrix::ApplySquareRoot()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL    ) return U_OK;
    if(MT==U_MAT_IDENTITY) return U_OK;
    if(Nrow==0 || Ncol==0) return U_OK;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ApplySquareRoot(). Data NULL.\n");
        return U_ERROR;
    }
    if(MT==U_MAT_IDENTCONST)
    { 
        if(Data[0]<0)
        {
            CI.AddToLog("ERROR: UMatrix::ApplySquareRoot(). Data[0] negative. \n");
            return U_ERROR;
        }
        Data[0] = sqrt(Data[0]);
        return U_OK;
    }

    if(MT==U_MAT_SYMMETRIC)
    {
        for(int i=0; i<Nrow; i++)
            for(int j=0; j<Ncol; j++)
                if(j>=i)  
                {
                    if(Data[i*Ncol+j]<0.)
                    {
                        CI.AddToLog("ERROR: UMatrix::ApplySquareRoot(). Data[%d,%d] negative. \n", i,j);
                        return U_ERROR;
                    }
                    Data[i*Ncol+j] = sqrt(Data[i*Ncol+j]);
                }
                else Data[i*Ncol+j] =   Data[j*Ncol+i];
    }
    else
    {
        int N  = GetNelem();
        for(int n=0; n<N; n++) 
        {
            if(Data[n]<0.)
            {
                CI.AddToLog("ERROR: UMatrix::ApplySquareRoot(). Data[%d] negative. \n", n);
                return U_ERROR;
            }
            Data[n] = sqrt(Data[n]);
        }
    }
    return U_OK;
}
ErrorType UMatrix::ApplyInverse()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL || MT==U_MAT_IDENTITY || MT==U_MAT_IDENTCONST) 
    {
        CI.AddToLog("ERROR: UMatrix::ApplyInverse(). Matrix of wrong type (%d).\n", int(MT));
        return U_ERROR;
    }
    if(Nrow==0 || Ncol==0) return U_OK;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ApplyInverse(). Data NULL.\n");
        return U_ERROR;
    }

    if(MT==U_MAT_SYMMETRIC)
    {
        for(int i=0; i<Nrow; i++)
            for(int j=0; j<Ncol; j++)
                if(j>=i)  
                {
                    if(Data[i*Ncol+j]==0.)
                    {
                        CI.AddToLog("ERROR: UMatrix::ApplyInverse(). Data[%d,%d] is 0. \n", i,j);
                        return U_ERROR;
                    }
                    Data[i*Ncol+j] = 1./(Data[i*Ncol+j]);
                }
                else Data[i*Ncol+j] =   Data[j*Ncol+i];
    }
    else
    {
        int N  = GetNelem();
        for(int n=0; n<N; n++) 
        {
            if(Data[n]==0.)
            {
                CI.AddToLog("ERROR: UMatrix::ApplyInverse(). Data[%d] is 0.. \n", n);
                return U_ERROR;
            }
            Data[n] = 1./Data[n];
        }
    }
    return U_OK;
}
ErrorType UMatrix::ApplyAbs()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_NULL    ) return U_OK;
    if(MT==U_MAT_IDENTITY) return U_OK;
    if(Nrow==0 || Ncol==0) return U_OK;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ApplyAbs(). Data NULL.\n");
        return U_ERROR;
    }
    if(MT==U_MAT_IDENTCONST)
    { 
        Data[0] = fabs(Data[0]);
        return U_OK;
    }

    int N  = GetNelem();
    for(int n=0; n<N; n++) Data[n] = fabs(Data[n]);
    return U_OK;
}

ErrorType UMatrix::MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Thresh<0. && Fabs)
    {
        CI.AddToLog("ERROR: UMatrix::MinimizeElements(). Invalid threshold: %f \n", Thresh);
        return U_ERROR;
    }
    if(IsDiagonalType()==true || MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MinimizeElements(). Function not implemented for empty or diagonal matrices. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MinimizeElements(). Data not set. \n");
        return U_ERROR;
    }
    if(pSuperThreshold)
    {
        *pSuperThreshold = new bool[Nrow*Ncol];
        if(*pSuperThreshold==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::MinimizeElements(). Memory allocation (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
            return U_ERROR;
        }
    }

    if(Thresh==0. && Fabs)
    {
        if(pSuperThreshold) for(int n=0; n<Nrow*Ncol; n++) (*pSuperThreshold)[n] = Data[n]>0.;
        delete[] Data; Data = NULL;
        MT=U_MAT_NULL;
        return U_OK;
    }

    double* pDat  = Data;
    int     Nelem = GetNelem();

    if(pSuperThreshold) // True iff no change occurs after thresholding operator
    {
        if(Fabs) for(int n=0; n<Nelem; n++, pDat++) (*pSuperThreshold)[n] = (-Thresh > *pDat) || (*pDat > Thresh);
        else     for(int n=0; n<Nelem; n++, pDat++) (*pSuperThreshold)[n] =                      (*pDat > Thresh);
    }

    pDat  = Data;
    if(Fabs)     for(int n=0; n<Nelem; n++, pDat++) *pDat = (*pDat>= Thresh ? *pDat : ((*pDat<= -Thresh)? *pDat : Thresh));
    else         for(int n=0; n<Nelem; n++, pDat++) *pDat = (*pDat>= Thresh ? *pDat : Thresh);

    return U_OK;
}
ErrorType UMatrix::MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Thresh<0. && Fabs)
    {
        CI.AddToLog("ERROR: UMatrix::MaximizeElements(). Invalid threshold: %f \n", Thresh);
        return U_ERROR;
    }
    if(IsDiagonalType()==true || MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MaximizeElements(). Function not implemented for empty or diagonal matrices. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::MaximizeElements(). Data not set. \n");
        return U_ERROR;
    }
    if(pSubThreshold)
    {
        *pSubThreshold = new bool[Nrow*Ncol];
        if(*pSubThreshold==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::MaximizeElements(). Memory allocation (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
            return U_ERROR;
        }
    }

    if(Thresh==0. && Fabs)
    {
        if(pSubThreshold) for(int n=0; n<Nrow*Ncol; n++) (*pSubThreshold)[n] = false;
        delete[] Data; Data = NULL;
        MT=U_MAT_NULL;
        return U_OK;
    }

    double* pDat  = Data;
    int     Nelem = GetNelem();

    if(pSubThreshold) // True iff no change occurs after thresholding operator
    {
        if(Fabs) for(int n=0; n<Nelem; n++, pDat++) (*pSubThreshold)[n] = (-Thresh <= *pDat) && (*pDat <=Thresh);
        else     for(int n=0; n<Nelem; n++, pDat++) (*pSubThreshold)[n] =                       (*pDat <=Thresh);
    }

    pDat  = Data;
    if(Fabs)     for(int n=0; n<Nelem; n++, pDat++) *pDat = *pDat<-Thresh ? -Thresh : (*pDat<=Thresh ? *pDat : Thresh);
    else         for(int n=0; n<Nelem; n++, pDat++) *pDat =                           (*pDat< Thresh ? *pDat : Thresh);

    return U_OK;
}
ErrorType UMatrix::SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(IsDiagonalType()==true || MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetRangeElements(). Function not implemented for empty or diagonal matrices. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetRangeElements(). Data not set. \n");
        return U_ERROR;
    }
    if(pSubThreshold)
    {
        *pSubThreshold = new bool[Nrow*Ncol];
        if(*pSubThreshold==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::SetRangeElements(). Memory allocation (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
            return U_ERROR;
        }
    }
    if(Tmax<=Tmin)
    {
        if(pSubThreshold) for(int n=0; n<Nrow*Ncol; n++) (*pSubThreshold)[n] = false;
        delete[] Data; Data = NULL;
        MT=U_MAT_NULL;
        return U_OK;
    }
    double* pDat  = Data;
    int     Nelem = GetNelem();

    if(pSubThreshold) 
        for(int n=0; n<Nelem; n++, pDat++) (*pSubThreshold)[n] = (Tmin <= *pDat) && (*pDat <=Tmax); // True iff no change occurs after thresholding operator

    pDat  = Data;
    for(int n=0; n<Nelem; n++, pDat++)     *pDat = *pDat<Tmin ? Tmin : (*pDat<=Tmax ? *pDat : Tmax);
    
    return U_OK;
}

UMatrix UMatrix::GetTranspose(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetTranspose(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix();
    
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetTranspose(). Matrix data not set. \n");
        return UMatrix(U_ERROR);
    }
    if(IsSymmetricType()==true) return UMatrix(*this);

    UMatrix Transpose(DNULL, Ncol, Nrow);
    if(Transpose.GetError()!=U_OK || Transpose.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetTranspose(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }

    const double* pMat = Data;
    double*       M    = Transpose.Data;
    
    for(int i=0;i<Nrow;i++)
    {
        double* pM = M+i;
        for(int j=0;j<Ncol;j++, pM+=Nrow) *pM = *pMat++;
    }
    return Transpose;
}
ErrorType UMatrix::Transpose(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::Transpose(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(MT==U_MAT_NULL) return U_OK;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::Transpose(). Matrix data not set. \n");
        return U_ERROR;
    }
    if(IsSymmetricType()==true) return U_OK;

    double* Buffer = new double[Nrow*Ncol];
    if(Buffer==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::Transpose(). Memory allocation: Nrow=%d, Ncol=%d. \n", Nrow, Ncol);
        return U_ERROR;
    }

    const double* pMat = Data;
    double*       M    = Buffer;
    
    for(int i=0;i<Nrow;i++)
    {
        double* pM = M+i;
        for(int j=0;j<Ncol;j++, pM+=Nrow) *pM = *pMat++;
    }

    delete[] Data; Data = Buffer;
    int dum = Nrow; Nrow=Ncol; Ncol=dum;

    return U_OK;
}

ErrorType UMatrix::ForceGeneralType(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ForceGeneralType(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMatrix::ForceGeneralType(). Invalid Nrow (=%d) or Ncol (=%d). \n", Nrow, Ncol);
        return U_ERROR;
    }

    if(MT==U_MAT_SYMMETRIC || MT==U_MAT_SQUARE || MT==U_MAT_GENERAL)
    {
        MT = U_MAT_GENERAL;
        return U_OK;
    }
    double* NewData = new double[Ncol*Nrow];
    if(NewData==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::ForceGeneralType(). Memory allocation. Nrow (=%d), Ncol (=%d). \n", Nrow, Ncol);
        return U_ERROR;
    }

    double* pNewd = NewData;
    for(int ij=0; ij<Nrow*Ncol; ij++, pNewd++) *pNewd = 0.;

    pNewd = NewData;
    double* pDat = Data;
    switch(MT)
    {
    case U_MAT_IDENTITY  : for(int i=0; i<Ncol; i++, pNewd+=Ncol+1) *pNewd = 1.;       break;
    case U_MAT_IDENTCONST: for(int i=0; i<Ncol; i++, pNewd+=Ncol+1) *pNewd = Data[0];  break;
    case U_MAT_DIAGONAL:   for(int i=0; i<Ncol; i++, pNewd+=Ncol+1) *pNewd = *pDat++;  break;
    }
    
    delete[] Data; Data = NewData;
    MT = U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::ForceSymmetricType(double RelRowError)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::ForceSymmetricType(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(MT==U_MAT_NULL) return U_ERROR;

    if(Nrow<=0 || Ncol<=0 || Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::ForceSymmetricType(). Invalid Nrow (=%d) or Ncol (=%d). \n", Nrow, Ncol);
        return U_ERROR;
    }

    if(IsSymmetricType()==true) return U_OK;

    for(int i=0; i<Nrow; i++)
    {
        double RowSum = 0;
        for(int j=0  ; j<Ncol; j++) RowSum += fabs(Data[i*Ncol+j]);
        for(int j=i+1; j<Ncol; j++)
        {
            if(RelRowError>=0. && fabs(Data[i*Ncol+j]-Data[j*Ncol+i])*RowSum>RelRowError)
            {
                double Diff = fabs(Data[i*Ncol+j]-Data[j*Ncol+i]);
                if(RowSum!=0.) Diff /= RelRowError;
                CI.AddToLog("Note: UMatrix::ForceSymmetric(). Data[%d,%d] asymmetry larger than tolerance (Diff = %20.15e). \n", i,j, Diff);
                return U_ERROR;
            }
            double Aver = 0.5*(Data[i*Ncol+j]+Data[j*Ncol+i]);
            Data[i*Ncol+j] = Data[j*Ncol+i] = Aver;
        }
    }
    MT = U_MAT_SYMMETRIC;
    return U_OK;
}

UMatrix UMatrix::GetDiagonal(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonal(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(Ncol!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonal(). Matrix not square. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix();
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonal(). Matrix not not properly set. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true) return *this;

    UMatrix M;
    M.Ncol = M.Nrow = Ncol;
    M.MT   = U_MAT_DIAGONAL;
    M.Data = new double[Ncol];
    if(M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonal(). Matrix not square. \n");
        return UMatrix(U_ERROR);
    }
    for(int k=0; k<Ncol; k++) M.Data[k] = GetElement(k,k);

    return M;
}
UMatrix UMatrix::GetDiagonalAsColVec(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonalAsColVec(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(Ncol!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonalAsColVec(). Matrix not square. \n");
        return UMatrix(U_ERROR);
    }

    UMatrix M;
    M.Ncol = 1;
    M.Nrow = Nrow;
    M.MT   = U_MAT_GENERAL;
    if(MT==U_MAT_NULL) return M;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonalAsColVec(). Matrix not not properly set. \n");
        return UMatrix(U_ERROR);
    }
    M.Data = new double[Nrow];
    if(M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDiagonalAsColVec(). Memory allocation. \n");
        return UMatrix(U_ERROR);
    }

    if(IsDiagonalType()==true) 
    {
        for(int i=0; i<Nrow; i++) M.Data[i] = GetElement(i,i);
        return M;
    }

    for(int i=0; i<Nrow; i++) M.Data[i] = Data[(Nrow+1)*i];
    return M;
}

UMatrix UMatrix::GetVec(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetVec(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) 
    {
        UMatrix V; V.Ncol = 1; V.Nrow = Nrow*Ncol;
        return V;
    }
    UMatrix V = *this;
    if(V.ForceGeneralType()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetVec(). Forcing matrix as general type. \n");
        return UMatrix(U_ERROR);
    }
    if(V.Transpose()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetVec(). Computing transposed of output matrix. \n");
        return UMatrix(U_ERROR);
    }
    V.Nrow = Nrow*Ncol;
    V.Ncol = 1;
    V.MT   = V.Nrow==1 ? U_MAT_SQUARE : U_MAT_GENERAL;
    return V;
}

UMatrix UMatrix::GetRow(int irow) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetRow(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetRow(). Argument out of range: irow=%d, Nrow=%d. \n", irow, Nrow);
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) 
    {
        UMatrix V; V.Nrow = 1; V.Ncol = Ncol;
        return V;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetRow(). Data not properly set. \n");
        return UMatrix(U_ERROR);
    }
    UMatrix M(DNULL, 1, Ncol);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetRow(). Setting output row. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        M.Data[irow] = (MT==U_MAT_IDENTITY||MT==U_MAT_IDENTCONST) ? Data[0] : Data[irow];
    }
    else
    {
        const double* pD = Data   + irow*Ncol;
        double*       pM = M.Data;
        for(int j=0; j<Ncol; j++) *pM++ = *pD++; 
    }
    return M;
}
UMatrix UMatrix::GetCollumn(int icol) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetCollumn(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetCollumn(). Argument out of range: icol=%d, Ncol=%d. \n", icol, Ncol);
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) 
    {
        UMatrix V; V.Nrow = Nrow; V.Ncol = 1;
        return V;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetCollumn(). Data not properly set. \n");
        return UMatrix(U_ERROR);
    }
    UMatrix M(DNULL, Nrow, 1);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetCollumn(). Setting output row. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        M.Data[icol] = (MT==U_MAT_IDENTITY||MT==U_MAT_IDENTCONST) ? Data[0] : Data[icol];
    }
    else
    {
        const double* pD = Data   + icol;
        double*       pM = M.Data;
        for(int i=0; i<Nrow; i++, pD+=Ncol) *pM++ = *pD; 
    }
    return M;
}

double UMatrix::GetElement(int ij) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(MT==U_MAT_NULL) return 0.;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Matrix data is NULL. \n");
        return 0.;
    }
    if(Ncol<=0) 
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Ncol (%d) invalid. \n", Ncol);
        return 0.;
    }
    return GetElement(ij/Ncol, ij%Ncol);
}

double UMatrix::GetElement(int row, int col) const 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(MT==U_MAT_NULL) return 0.;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Matrix data is NULL. \n");
        return 0.;
    }
    if(row<0 || row>Nrow-1 || col<0 || col>Ncol-1)
    {
        CI.AddToLog("ERROR: UMatrix::GetElement(). Invalid Argument(s). row=%d, col=%d\n", row, col);
        return 0.;
    }
    switch(MT)
    {
    case U_MAT_IDENTITY:    return (row==col) ? 1.        : 0.;
    case U_MAT_IDENTCONST:  return (row==col) ? Data[0]   : 0.;
    case U_MAT_DIAGONAL:    return (row==col) ? Data[col] : 0.;
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:     return Data[row*Ncol+col];
    }
    CI.AddToLog("ERROR: UMatrix::GetElement(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}

double UMatrix::GetTrace(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetTrace(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(MT==U_MAT_NULL) return 0.;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetTrace(). Matrix data is NULL. \n");
        return 0.;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetTrace(). Matrix is not square.");
        return 0.;
    }

    double trace=0.;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return double(Nrow);
    case U_MAT_IDENTCONST:  return Data[0]*Nrow;
    case U_MAT_DIAGONAL:    {for(int i=0;i<Nrow;i++) trace += Data[i]; return trace;}
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:     {for(int i=0;i<Nrow;i++) trace += Data[i*(Ncol+1)]; return trace;}
    }
    CI.AddToLog("ERROR: UMatrix::GetTrace(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}

double UMatrix::GetFrobNorm2(void) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    double  Norm2 = 0.;
    double* pMat  = Data;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return double(Nrow);
    case U_MAT_IDENTCONST:  return Data[0]*Data[0]*Nrow;
    case U_MAT_DIAGONAL:    {for(int k=0; k<Nrow     ; k++, pMat++) Norm2 += SQR(*pMat); return Norm2;}
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:     {for(int k=0; k<Nrow*Ncol; k++, pMat++) Norm2 += SQR(*pMat); return Norm2;}
    }
    CI.AddToLog("ERROR: UMatrix::GetFrobNorm2(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetFrobNorm(void) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL     ) return 0.;

    return sqrt(fabs(GetFrobNorm2()));
}
double UMatrix::GetAbsNorm(void) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL     ) return 0.;

    double  Norm1 = 0.;
    double* pMat  = Data;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return double(Nrow);
    case U_MAT_IDENTCONST:  return fabs(Data[0]*Nrow);
    case U_MAT_DIAGONAL:    {for(int k=0; k<Nrow     ; k++, pMat++) Norm1 += fabs(*pMat); return Norm1;}
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:     {for(int k=0; k<Nrow*Ncol; k++, pMat++) Norm1 += fabs(*pMat); return Norm1;}
    }
    CI.AddToLog("ERROR: UMatrix::GetAbsNorm(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetMixedRowNorm(void) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL     ) return 0.;

    double  Norm12 = 0.;
    double* pMat  = Data;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return double(Nrow);
    case U_MAT_IDENTCONST:  return fabs(Data[0]*Nrow);
    case U_MAT_DIAGONAL:    {for(int k=0; k<Nrow; k++, pMat++) Norm12 += fabs(*pMat); return Norm12;}
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:     {for(int k=0; k<Nrow; k++        ) Norm12 += GetFrobNormRow(k); return Norm12;}
    }
    CI.AddToLog("ERROR: UMatrix::GetMixedRowNorm(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}

double UMatrix::GetFrobNorm2Row(int irow) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNorm2Row(). Argument out of range: irow=%d \n",irow);
        return 0.;
    }

    double  Norm2 = 0.;
    double* pMat  = Data+irow*Ncol;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return 1.;
    case U_MAT_IDENTCONST:  return SQR(Data[0]);
    case U_MAT_DIAGONAL:    return SQR(Data[irow]);
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:    {for(int k=0; k<Ncol; k++, pMat++) Norm2 += SQR(*pMat); return Norm2;}
    }
    CI.AddToLog("ERROR: UMatrix::GetFrobNorm2Row(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetFrobNormRow(int irow) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormRow(). Argument out of range: irow=%d \n",irow);
        return 0.;
    }
    return sqrt(fabs(GetFrobNorm2Row(irow)));
}
UMatrixSymmetric UMatrix::GetVarianceDifMat(void) const
{
    if(this==NULL      || error!=U_OK) return UMatrixSymmetric(U_ERROR);
    if(MT==U_MAT_NULL)  return UMatrixSymmetric(UMatrix(0.,Nrow));
    if(Data==NULL)      return UMatrixSymmetric(U_ERROR);

    UMatrixSymmetric VarMat(DNULL, Nrow, Nrow, false);
    if(VarMat.GetError()!=U_OK || VarMat.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetVarianceDifMat(). Creating output matrix. \n");
        return UMatrixSymmetric(U_ERROR);
    }
    double* pVar = VarMat.Data;
    if(IsDiagonalType()==true)
    {
        for(int i=0; i<Nrow; i++)
            for(int j=i+1; j<Nrow; j++) pVar[i*Nrow+j] = pVar[j*Nrow+i] = SQR(GetElement(i)) + SQR(GetElement(j));
    }
    else
    {
        for(int i=0; i<Nrow; i++)
            for(int j=i+1; j<Nrow; j++)
            {
                double* pMat1 = Data+i*Ncol;
                double* pMat2 = Data+j*Ncol;
                double  V     = 0.;
                for(int k=0; k<Ncol; k++, pMat1++, pMat2++) V += SQR(*pMat1 - *pMat2);
            
                pVar[i*Nrow+j] = pVar[j*Nrow+i] = V;
            }
    }
    return VarMat;
}

double UMatrix::GetSum(bool Fabs) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    double  Sum   = 0;
    double* pMat  = Data;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return double(Ncol);
    case U_MAT_IDENTCONST:  return Fabs ? fabs(Data[0])*Ncol : Data[0]*Ncol;
    case U_MAT_DIAGONAL:
        if(Fabs) for(int k=0; k<Ncol; k++) Sum += fabs(*pMat++);
        else     for(int k=0; k<Ncol; k++) Sum +=      *pMat++;
        return Sum;
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:    
        if(Fabs) for(int k=0; k<Nrow*Ncol; k++) Sum += fabs(*pMat++);
        else     for(int k=0; k<Nrow*Ncol; k++) Sum +=      *pMat++;
        return Sum;
    }
    CI.AddToLog("ERROR: UMatrix::GetSum(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetRowSum(int irow) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetRowSum(). Argument out of range: irow=%d \n",irow);
        return 0.;
    }

    double  Sum   = 0.;
    double* pMat  = Data+irow*Ncol;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return 1.;
    case U_MAT_IDENTCONST:  return Data[0];
    case U_MAT_DIAGONAL:    return Data[irow];
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:    {for(int k=0; k<Ncol; k++, pMat++) Sum += *pMat; return Sum;}
    }
    CI.AddToLog("ERROR: UMatrix::GetRowSum(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
UMatrix UMatrix::GetRowSum(void) const
{
    if(this==NULL      || error!=U_OK) return UMatrix(U_ERROR);
    
    UMatrix Col;
    Col.Ncol  = 1;
    Col.Nrow  = Nrow;
    if(MT ==U_MAT_NULL) return Col;
    if(Data==NULL      ) return UMatrix(U_ERROR);

    Col.MT   = U_MAT_GENERAL;
    Col.Data = new double[Nrow];
    if(Col.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetRowSum(). Memory allocation: Nrow=%d \n",Nrow);
        return UMatrix(U_ERROR);
    }

    for(int irow=0; irow<Nrow; irow++) Col.Data[irow] = GetRowSum(irow);
    return Col;
}
double UMatrix::GetFrobNorm2Col(int icol) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNorm2Col(). Argument out of range: icol=%d \n",icol);
        return 0.;
    }

    double  Norm2 = 0.;
    double* pMat  = Data+icol;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return 1.;
    case U_MAT_IDENTCONST:  return SQR(Data[0]);
    case U_MAT_DIAGONAL:    return SQR(Data[icol]);
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:    {for(int k=0; k<Nrow; k++, pMat+=Ncol) Norm2 += SQR(*pMat); return Norm2;}
    }
    CI.AddToLog("ERROR: UMatrix::GetFrobNorm2Col(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetFrobNormCol(int icol) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormCol(). Argument out of range: icol=%d \n",icol);
        return 0.;
    }
    return sqrt(fabs(GetFrobNorm2Col(icol)));
}
UMatrix UMatrix::GetFrobNormRowDiag(void) const
{
    if(this==NULL      || error!=U_OK) return UMatrix(U_ERROR);
    if(MT ==U_MAT_NULL) 
    {
        UMatrix D = *this;
        D.Ncol = D.Nrow = Nrow;
        return D;
    }
    if(Data==NULL      ) return UMatrix(U_ERROR);

    double* Norm = new double[Nrow];
    if(Norm==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormRowDiag(). Memory allocation, Ncol=%d \n", Ncol);
        return UMatrix(U_ERROR);
    }
    for(int i=0; i<Nrow; i++) Norm[i] = this->GetFrobNormRow(i);
    UMatrix D(Norm, Nrow);
    delete[] Norm;

    return D;
}
UMatrix UMatrix::GetFrobNormColDiag(void) const
{
    if(this==NULL      || error!=U_OK) return UMatrix(U_ERROR);
    if(MT ==U_MAT_NULL) 
    {
        UMatrix D = *this;
        D.Ncol = D.Nrow = Ncol;
        return D;
    }
    if(Data==NULL      ) return UMatrix(U_ERROR);

    double* Norm = new double[Ncol];
    if(Norm==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormColDiag(). Memory allocation, Ncol=%d \n", Ncol);
        return UMatrix(U_ERROR);
    }
    for(int j=0; j<Ncol; j++)  Norm[j] = this->GetFrobNormCol(j);
    UMatrix D(Norm, Ncol);
    delete[] Norm;

    return D;
}
double UMatrix::GetColSum(int icol) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetColSum(). Argument out of range: icol=%d \n",icol);
        return 0.;
    }

    double  Sum   = 0.;
    double* pMat  = Data+icol;
    switch(MT)
    {
    case U_MAT_IDENTITY:    return 1.;
    case U_MAT_IDENTCONST:  return Data[0];
    case U_MAT_DIAGONAL:    return Data[icol];
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:    {for(int k=0; k<Nrow; k++, pMat+=Ncol) Sum += *pMat; return Sum;}
    }
    CI.AddToLog("ERROR: UMatrix::GetColSum(). Matrix of unkown type (%d). \n", int(MT));
    return 0.;
}
double UMatrix::GetColMedian(int icol) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetColMedian(). Argument out of range: icol=%d \n",icol);
        return 0.;
    }
    if(IsDiagonalType()) return 0.;

    double* ColDat = new double[Nrow];
    if(ColDat==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetColMedian(). Memory allocation, Nroe=%d \n",Nrow);
        return 0.;
    }
    double*       pCol  = ColDat;
    const double* pMat  = Data+icol;
    for(int n=0; n<Nrow; n++, pCol++, pMat+=Ncol) *pCol = *pMat;
    double Med = GetMedian(ColDat, Nrow);
    delete[] ColDat;
    return Med;
}
double UMatrix::GetRowMedian(int irow) const
{
    if(this==NULL      || error!=U_OK) return 0.;
    if(MT  ==U_MAT_NULL) return 0.; // OK
    if(Data==NULL      ) return 0.;

    if(irow<0||irow>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetRowMedian(). Argument out of range: icol=%d \n",irow);
        return 0.;
    }
    if(IsDiagonalType()) return 0.;

    return GetMedian(Data+irow*Ncol, Ncol);
}
double UMatrix::GetMaxElem(bool Fabs) const
{
    if(this==NULL      || error!=U_OK) return 0.;

    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMaxElem(). Data not properly set. \n");
        return 0.;
    }
    switch(MT)
    {
    case U_MAT_NULL:       return 0.;
    case U_MAT_IDENTITY:    return 1.;
    case U_MAT_IDENTCONST:  {if(Fabs) return fabs(Data[0]); else return MAX(0.,Data[0]);}
    case U_MAT_DIAGONAL:    
        {
            double MaxEl = Fabs ? fabs(Data[0]) : Data[0];
            for(int k=0; k<Nrow; k++) 
            {
                double Test = Fabs ? fabs(Data[k]) : Data[k];
                if(Test>MaxEl) MaxEl = Test;
            }
            return MAX(0., MaxEl);
        }
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:
        {
            double        MaxEl = Fabs ? fabs(Data[0]) : Data[0];
            const double* pDat  = Data;
            if(Fabs)
            {
                for(int k=0; k<Nrow*Ncol; k++,pDat++) 
                {
                    double Test = fabs(*pDat);
                    if(Test>MaxEl) MaxEl = Test;
                }
            }
            else
            {
                for(int k=0; k<Nrow*Ncol; k++, pDat++) MaxEl = MAX(MaxEl, *pDat);
            }
            return MaxEl;
        }
    }
    return 0;
}
bool* UMatrix::GetSubThresholdElements(double Thresh, bool Fabs) const
{
    if(this==NULL || error!=U_OK       ) return NULL;
    if(Data==NULL && MT   !=U_MAT_NULL) return NULL;
    
    if(Thresh<0 && Fabs)
    {
        CI.AddToLog("ERROR: UMatrix::GetSubThresholdElements(). Invalid threshold: %f \n", Thresh);
        return NULL;
    }
    if(Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMatrix::GetSubThresholdElements(). Invalid Nrow (%d) or Ncol (%d).\n", Nrow, Ncol);
        return NULL;
    }
    if(IsDiagonalType()==true || MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSubThresholdElements(). Function not implemented for Diagonal type of empty matrices.\n");
        return NULL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSubThresholdElements(). Data array is NULL.\n");
        return NULL;
    }


    int   Nelem  = GetNelem();
    bool* SubT   = new bool[Nelem];
    if(SubT==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSubThresholdElements(). Memory allocation: (Nrow=%d and Ncol=%d).\n", Nrow, Ncol);
        return NULL;
    }

    const double* pDat = Data;
    if(Fabs) for(int n=0; n<Nelem; n++, pDat++) SubT[n] = -Thresh<= *pDat && *pDat <=Thresh;
    else     for(int n=0; n<Nelem; n++, pDat++) SubT[n] =                    *pDat <=Thresh;

    return SubT;
}
bool* UMatrix::GetInRangeElements(double Tmin, double Tmax) const
{
    if(this==NULL || error!=U_OK       ) return NULL;
    if(Data==NULL && MT   !=U_MAT_NULL) return NULL;
    
    if(Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMatrix::GetInRangeElements(). Invalid Nrow (%d) or Ncol (%d).\n", Nrow, Ncol);
        return NULL;
    }
    if(IsDiagonalType()==true || MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetInRangeElements(). Function not implemented for Diagonal type of empty matrices.\n");
        return NULL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetInRangeElements(). Data array is NULL.\n");
        return NULL;
    }

    int   Nelem   = GetNelem();
    bool* InRange = new bool[Nelem];
    if(InRange==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetInRangeElements(). Memory allocation: (Nrow=%d and Ncol=%d).\n", Nrow, Ncol);
        return NULL;
    }
    if(Tmax<Tmin) 
    {
        for(int n=0; n<Nelem; n++) InRange[n] = false;
        return InRange;
    }
    const double* pDat = Data;
    for(int n=0; n<Nelem; n++, pDat++) InRange[n] = (Tmin<= *pDat) && (*pDat <=Tmax);

    return InRange;
}
int UMatrix::GetNNonZeroElements(void) const
{
    if(this==NULL || error!=U_OK       ) return 0;
    if(Data==NULL && MT   !=U_MAT_NULL) return 0;

    switch(MT)
    {
    case U_MAT_NULL     : return 0;
    case U_MAT_IDENTITY  : return Nrow;
    case U_MAT_IDENTCONST: if(Data[0]==0.) return 0; return Nrow;
    case U_MAT_DIAGONAL  :
        {
            int NNonZ = 0;
            for(int k=0; k<Nrow; k++) if(Data[k]!=0.) NNonZ++;
            return NNonZ;
        }
    case U_MAT_SYMMETRIC :
    case U_MAT_SQUARE    :
    case U_MAT_GENERAL   :
        {
            int NNonZ = 0;
            int Nelem = Nrow*Ncol;
            for(int k=0; k<Nelem; k++) if(Data[k]!=0.) NNonZ++;
            return NNonZ;
        }
    }
    return 0;
}
int UMatrix::GetNSubThreshholElements(double Thresh, bool Fabs) const
{
    if(this==NULL || error!=U_OK       ) return 0;
    if(Data==NULL && MT   !=U_MAT_NULL) return 0;

    switch(MT)
    {
    case U_MAT_NULL     : return (0<Thresh) ? Nrow*Ncol                                 : 0;
    case U_MAT_IDENTITY  : return (0<Thresh) ? ((1<Thresh) ? Nrow*Ncol : Nrow*Ncol-Nrow) : 0;
    case U_MAT_IDENTCONST: 
        {
            int    Noff = (0<Thresh) ? Nrow*Ncol-Nrow : 0      ;
            double DD   = Fabs       ? fabs(Data[0])  : Data[0];
            return (DD<Thresh)       ? Noff+Nrow      : Noff   ;
        }
    case U_MAT_DIAGONAL  :
        {
            int NSubT = (0<Thresh) ? Nrow*Ncol-Nrow : 0;
            if(Fabs)   for(int k=0; k<Nrow; k++) if(fabs(Data[k])<Thresh) NSubT++;
            else       for(int k=0; k<Nrow; k++) if(     Data[k] <Thresh) NSubT++;
            return NSubT;
        }
    case U_MAT_SYMMETRIC :
    case U_MAT_SQUARE    :
    case U_MAT_GENERAL   :
        {
            int NSubT = 0;
            int Nelem = Nrow*Ncol;
            if(Fabs)   for(int k=0; k<Nelem; k++) if(fabs(Data[k])<Thresh) NSubT++;
            else       for(int k=0; k<Nelem; k++) if(     Data[k] <Thresh) NSubT++;
            return NSubT;
        }
    }
    return 0;
}

double UMatrix::GetMinElem(bool Fabs) const
{
    if(this==NULL      || error!=U_OK) return 0.;

    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMinElem(). Data not properly set. \n");
        return 0.;
    }
    switch(MT)
    {
    case U_MAT_NULL:       return 0.;
    case U_MAT_IDENTITY:    return 0.;
    case U_MAT_IDENTCONST:  {if(Fabs) return MIN(0.,fabs(Data[0])); else return MIN(0.,Data[0]);}
    case U_MAT_DIAGONAL:    
        {
            double MinEl = Fabs ? fabs(Data[0]) : Data[0];
            for(int k=0; k<Nrow; k++) 
            {
                double Test = Fabs ? fabs(Data[k]) : Data[k];
                if(Test<MinEl) MinEl = Test;
            }
            return MIN(0., MinEl);
        }
    case U_MAT_SYMMETRIC:   
    case U_MAT_SQUARE:      
    case U_MAT_GENERAL:
        {
            double        MinEl = Fabs ? fabs(Data[0]) : Data[0];
            const double* pDat  = Data;
            if(Fabs)
            {
                for(int k=0; k<Nrow*Ncol; k++,pDat++) 
                {
                    double Test = fabs(*pDat);
                    if(Test<MinEl) MinEl = Test;
                }
            }
            else
            {
                for(int k=0; k<Nrow*Ncol; k++, pDat++) MinEl = MIN(MinEl, *pDat);
            }
            return MinEl;
        }
    }
    return 0;
}

UMatrix UMatrix::GetColSum(void) const
{
    if(this==NULL      || error!=U_OK) return UMatrix(U_ERROR);
    
    UMatrix Row;
    Row.Ncol  = Ncol;
    Row.Nrow  = 1;
    if(MT ==U_MAT_NULL) return Row;
    if(Data==NULL      ) return UMatrix(U_ERROR);

    Row.MT   = U_MAT_GENERAL;
    Row.Data = new double[Ncol];
    if(Row.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetColSum(). Memory allocation: Nrow=%d \n",Ncol);
        return UMatrix(U_ERROR);
    }

    for(int icol=0; icol<Ncol; icol++) Row.Data[icol] = GetColSum(icol);
    return Row;
}
double UMatrix::GetColMin(int icol, bool Fabs, const bool* SelectRow, int* irow) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(MT!=U_MAT_SYMMETRIC && MT!=U_MAT_SQUARE && MT!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: GetColMin(). Function not implemented for this matrix type: MT = %d .\n", int(MT));
        if(irow) *irow = -1;
        return 0.;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: GetColMin(). Data not properly set.\n");
        if(irow) *irow = -1;
        return 0.;
    }
    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: GetColMin(). icol (= %d) out of range.\n", icol);
        if(irow) *irow = -1;
        return 0.;
    }
    int First = GetFirstSelect(SelectRow, Nrow);
    if(First<0)
    {
        CI.AddToLog("ERROR: GetColMin(). All rows unselected.\n");
        if(irow) *irow = -1;
        return 0.;
    }

    double* pData = Data+First*Ncol+icol;
    double  DMin  = Fabs ? fabs(*pData) : *pData;
    int     ir    = First;
    for(int k=First; k<Nrow; k++, pData+=Ncol)
    {
        if(SelectRow && SelectRow[k]==false) continue;

        double  Test  = Fabs ? fabs(*pData) : *pData;
        if(Test>=DMin)                       continue;

        DMin = Test;
        ir   = k;
    }
    if(irow) *irow = ir;
    return DMin;
}
double UMatrix::GetColMax(int icol, bool Fabs, const bool* SelectRow, int* irow) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(MT!=U_MAT_SYMMETRIC && MT!=U_MAT_SQUARE && MT!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: GetColMax(). Function not implemented for this matrix type: MT = %d .\n", int(MT));
        if(irow) *irow = -1;
        return 0.;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: GetColMax(). Data not properly set.\n");
        if(irow) *irow = -1;
        return 0.;
    }
    if(icol<0||icol>=Ncol)
    {
        CI.AddToLog("ERROR: GetColMax(). icol (= %d) out of range.\n", icol);
        if(irow) *irow = -1;
        return 0.;
    }
    int First = GetFirstSelect(SelectRow, Nrow);
    if(First<0)
    {
        CI.AddToLog("ERROR: GetColMax(). All rows unselected.\n");
        if(irow) *irow = -1;
        return 0.;
    }

    double* pData = Data+First*Ncol+icol;
    double  DMax  = Fabs ? fabs(*pData) : *pData;
    int     ir    = First;
    for(int k=First; k<Nrow; k++, pData+=Ncol)
    {
        if(SelectRow && SelectRow[k]==false) continue;

        double  Test  = Fabs ? fabs(*pData) : *pData;
        if(Test<=DMax)                       continue;

        DMax = Test;
        ir   = k;
    }
    if(irow) *irow = ir;
    return DMax;
}
double UMatrix::GetRowMin(int irow, bool Fabs, const bool* SelectCol, int* icol) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(MT!=U_MAT_SYMMETRIC && MT!=U_MAT_SQUARE && MT!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: GetRowMin(). Function not implemented for this matrix type: MT = %d .\n", int(MT));
        if(icol) *icol = -1;
        return 0.;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: GetRowMin(). Data not properly set.\n");
        if(icol) *icol = -1;
        return 0.;
    }
    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: GetRowMin(). irow (= %d) out of range.\n", irow);
        if(icol) *icol = -1;
        return 0.;
    }
    int First = GetFirstSelect(SelectCol, Ncol);
    if(First<0)
    {
        CI.AddToLog("ERROR: GetRowMin(). All rows unselected.\n");
        if(icol) *icol = -1;
        return 0.;
    }

    double* pData = Data+irow*Ncol+First;
    double  DMin  = Fabs ? fabs(*pData) : *pData;
    int     ic    = First;
    for(int k=First; k<Ncol; k++, pData++)
    {
        if(SelectCol && SelectCol[k]==false) continue;

        double  Test  = Fabs ? fabs(*pData) : *pData;
        if(Test>=DMin)                       continue;

        DMin = Test;
        ic   = k;
    }
    if(icol) *icol = ic;
    return DMin;
}
double UMatrix::GetRowMax(int irow, bool Fabs, const bool* SelectCol, int* icol) const
{
    if(this==NULL || error!=U_OK) return 0.;

    if(MT!=U_MAT_SYMMETRIC && MT!=U_MAT_SQUARE && MT!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: GetRowMax(). Function not implemented for this matrix type: MT = %d .\n", int(MT));
        if(icol) *icol = -1;
        return 0.;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: GetRowMax(). Data not properly set.\n");
        if(icol) *icol = -1;
        return 0.;
    }
    if(irow<0||irow>=Nrow)
    {
        CI.AddToLog("ERROR: GetRowMax(). irow (= %d) out of range.\n", irow);
        if(icol) *icol = -1;
        return 0.;
    }
    int First = GetFirstSelect(SelectCol, Ncol);
    if(First<0)
    {
        CI.AddToLog("ERROR: GetRowMax(). All rows unselected.\n");
        if(icol) *icol = -1;
        return 0.;
    }

    double* pData = Data+irow*Ncol+First;
    double  DMax  = Fabs ? fabs(*pData) : *pData;
    int     ic    = First;
    for(int k=First; k<Ncol; k++, pData++)
    {
        if(SelectCol && SelectCol[k]==false) continue;

        double  Test  = Fabs ? fabs(*pData) : *pData;
        if(Test<=DMax)                       continue;

        DMax = Test;
        ic   = k;
    }
    if(icol) *icol = ic;
    return DMax;
}
double* UMatrix::GetNColSubThreshold(double Threshold) const
{
    if(this==NULL || error!=U_OK) return NULL;

    if(MT!=U_MAT_SYMMETRIC && MT!=U_MAT_SQUARE && MT!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: GetNColSubThreshold(). Function not implemented for this matrix type: MT = %d .\n", int(MT));
        return NULL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: GetNColSubThreshold(). Data not properly set.\n");
        return NULL;
    }
    double* NcolSub = new double[Nrow];
    if(NcolSub==NULL)
    {
        CI.AddToLog("ERROR: GetNColSubThreshold(). Memory allocation, Nrow = %d.\n", Nrow);
        return NULL;
    }
    for(int i=0,ij=0; i<Nrow; i++)
    {
        NcolSub[i] = 0.;
        for(int j=0; j<Ncol; j++, ij++) if(Data[ij]<Threshold) NcolSub[i]+=1.;
    }
    return NcolSub;
}

double UMatrix::GetFrobNormDifference2(const UMatrix& M) const
{
    if(this==NULL        || error !=U_OK) return -1.;
    if(MT   ==U_MAT_NULL) return M.GetFrobNorm2();
    if(Data ==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormDifference2(). Matrix data is NULL. \n");
        return -1.;
    }

    if(&M  ==NULL        || error !=U_OK) return -1.;
    if(M.MT   ==U_MAT_NULL) return GetFrobNorm2();
    if(M.Data ==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormDifference2(). Argument Matrix data is NULL. \n");
        return -1.;
    }

    if(Ncol!=M.Ncol || Nrow!=M.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetFrobNormDifference2(). Dimensions do not match. \n");
        return -1.;
    }

    double  Norm2  =  0.;
    double* pMat   =   Data;
    double* pMat2  = M.Data;
    if((*this).IsDiagonalType()==true)
    {
        if(M.IsDiagonalType()==true)
        {
            if((*this).MT==U_MAT_DIAGONAL || M.MT==U_MAT_DIAGONAL)
            {
                for(int i=0;i<Nrow;i++)
                {
                    double Diag  = (  MT==U_MAT_DIAGONAL) ?   Data[i] :   Data[0];
                    double DiagM = (M.MT==U_MAT_DIAGONAL) ? M.Data[i] : M.Data[0];
                    Norm2   += SQR(Diag-DiagM);
                }
            }
            else
            {
                Norm2 = Nrow * (Data[0] - M.Data[0]);
            }
        }
        else
        {
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<Ncol; j++, pMat2++)
                    if(i==j)  Norm2 +=  SQR(this->GetElement(i,j)-(*pMat2));
                    else      Norm2 +=  SQR(                      (*pMat2));
        }
    }
    else // *this non-diagonal
    {
        if(M.IsDiagonalType()==true)
        {
            for(int i=0; i<Nrow; i++)
                for(int j=0; j<Ncol; j++, pMat++)
                    if(i==j)  Norm2 +=  SQR((*pMat) - M.GetElement(i,j));
                    else      Norm2 +=  SQR((*pMat)                    );
        }
        else
        {
            int     Nelem  = Nrow*Ncol;
            for(int k=0; k<Nelem; k++, pMat++, pMat2++)  Norm2 += SQR((*pMat) - (*pMat2));
        }
    }
    return Norm2;
}
double UMatrix::GetFrobNormDifference(const UMatrix& M) const
{
    if(this==NULL || error !=U_OK) return -1.;
    if(&M  ==NULL || error !=U_OK) return -1.;

    double Norm2 = GetFrobNormDifference2(M);
    if(Norm2<=0.) return Norm2;
    return sqrt(Norm2);
}
ErrorType UMatrix::AddTransposed(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::AddTransposed(). Obect NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::AddTransposed(). Nrow (%d) !=  Nol (%d). \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(IsSymmetricType()==true) 
    {
        *this *= 2.;
        return U_OK;
    }
    for(int n=0, nN=0; n<Ncol; n++, nN+=Ncol) 
    {
        for(int m=n+1, mN=(n+1)*Ncol; m<Ncol; m++, mN+=Ncol) 
        {
            Data[nN + m] += Data[mN + n];
            Data[mN + n]  = Data[nN + m];
        }
        Data[nN + n] *= 2.;
    }
    return U_OK;
}

UMatrix UMatrix::GetConcatCollumns(const UMatrix& BMat) const
/* 
    This routine computes and returns the augmented matrix (*this T, BMat T)T
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Obect NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(&BMat==NULL || BMat.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Argument NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix(BMat);

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }   
    if(BMat.MT==U_MAT_NULL) return UMatrix(*this);
        
    if(BMat.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Matrix argument matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }   
    if(Ncol != BMat.Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Numbers of collumns do not match (%d and %d)\n", Ncol, BMat.Ncol);
        return UMatrix(U_ERROR);
    } 
    if(IsDiagonalType()==true || BMat.IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatCollumns(). Function not (yet) implemented for diagonal type(s). \n");
        return UMatrix(U_ERROR);
    }

    UMatrix MConcat(DNULL, Nrow+BMat.Nrow, Ncol);
    if(MConcat.Data==NULL || MConcat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }

    const double* pD  = Data;
    const double* pB  = BMat.Data;
    double*       pMB = MConcat.Data;

    for(int ij=0;ij<Nrow     *Ncol;ij++) *pMB++ = *pD++;
    for(int ij=0;ij<BMat.Nrow*Ncol;ij++) *pMB++ = *pB++;
    
    MConcat.MT = MConcat.Nrow==MConcat.Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
    return MConcat;
}

UMatrix UMatrix::GetConcatRows(const UMatrix& BMat) const
/* 
    This routine computes and returns the augmented matrix (*this, BMat) 
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Obect NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(&BMat==NULL || BMat.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Argument NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix(BMat);

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }   
    if(BMat.MT==U_MAT_NULL) return UMatrix(*this);
        
    if(BMat.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Matrix argument matrix data is NULL.\n");
        return UMatrix(U_ERROR);
    }   
    if(Nrow != BMat.Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Numbers of rows do not match (%d and %d)\n", Nrow, BMat.Nrow);
        return UMatrix(U_ERROR);
    } 
    if(IsDiagonalType()==true || BMat.IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Function not (yet) implemented for diagonal type(s). \n");
        return UMatrix(U_ERROR);
    }

    UMatrix MConcat(DNULL, Nrow, Ncol+BMat.Ncol);
    if(MConcat.Data==NULL || MConcat.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetConcatRows(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    const double* pD  = Data;
    const double* pB  = BMat.Data;
    double*       pMB = MConcat.Data;

    for(int i=0;i<Nrow;i++)
    {
        for(int j=0; j<Ncol     ;j++)  *pMB++ = *pD++;
        for(int j=0; j<BMat.Ncol;j++)  *pMB++ = *pB++;
    }

    MConcat.MT = MConcat.Nrow==MConcat.Ncol ? U_MAT_SQUARE : U_MAT_GENERAL;
    return MConcat;
}
UMatrix UMatrix::GetBlock(int row, int col, int NrowBlock, int NcolBlock) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetBlock(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(row<0 || NrowBlock<=0 || row+NrowBlock>Nrow ||
       col<0 || NcolBlock<=0 || col+NcolBlock>Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetBlock(). Selection parameter(s) out of range. \n");
        return UMatrix(U_ERROR);
    }

    if(MT==U_MAT_NULL)
    {
        UMatrix Block;
        Block.Nrow = NrowBlock;
        Block.Ncol = NcolBlock;
        Block.MT   = U_MAT_NULL;
        return Block;
    }

    UMatrix Block(DNULL, NrowBlock, NcolBlock);
    if(Block.GetError()!=U_OK || Block.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetBlock(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    Block.MT = (NrowBlock==NcolBlock) ? U_MAT_SQUARE : U_MAT_GENERAL;
    if(MT==U_MAT_SYMMETRIC && row==col && NrowBlock==NcolBlock) Block.MT = U_MAT_SYMMETRIC;

    double* DataB = Block.Data;
    if(IsDiagonalType()==true)
    {
        for(int i=0;i<NrowBlock;i++)
            for(int j=0;j<NcolBlock;j++)
                DataB[i*NcolBlock+j]=GetElement(row+i, col+j);
    }
    else
    {
        for(int i=0;i<NrowBlock;i++)
        {
            const double* pData  = Data  + (row+i)*Ncol+col;
            double*       pDataB = DataB + i*NcolBlock;
            for(int j=0;j<NcolBlock;j++) *pDataB++ = *pData++;
        }
    }
    return Block;
}
ErrorType UMatrix::SetBlock(int row, int col, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SetBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SetBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Block.Data==NULL && Block.MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SetBlock(). Invalid Data NULL pointer of Block matrix argument.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SetBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(this->IsDiagonalType())
    {
        if(Block.IsDiagonalType() && row==col)
        {
            double* NewData = new double[Nrow];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::SetBlock(). Memory allocation, Nrow = %d . \n", Nrow);
                return U_ERROR;
            }
            for(int k=0; k<Nrow; k++) 
                if(k<row || k>=row+Block.Nrow) NewData[k] = GetElement(k,k);
                else                           NewData[k] = Block.GetElement(k-row,k-col);
            delete[] Data; Data = NewData;
            MT = U_MAT_DIAGONAL;
            return U_OK;
        }
        if(ForceGeneralType()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrix::SetBlock(). Forcing general matrix type . \n");
            return U_ERROR;
        }
        if(Block.MT==U_MAT_SYMMETRIC && row==col) MT = U_MAT_SYMMETRIC;
    }
    if(Block.IsDiagonalType())
    {
        double*       pData  = Data+row*Ncol+col;
        for(int k=0; k<Block.Nrow; k++, pData+=Ncol+1) *pData = Block.GetElement(k,k);
    }
    else
    {
        if(Block.MT==U_MAT_NULL)
        {
            for(int i=0; i<Block.Nrow; i++)
            {
                double* pData  = Data +(i+row)*Ncol+col;
                for(int j=0; j<Block.Ncol; j++) *pData++ = 0.;
            }
        }
        else
        {
            for(int i=0; i<Block.Nrow; i++)
            {
                double*       pData  = Data       +(i+row)*Ncol+col;
                const double* pBlock = Block.Data + i     *Block.Ncol;
                for(int j=0; j<Block.Ncol; j++) *pData++ = *pBlock++;
            }
        }
    }
    if(MT==U_MAT_SYMMETRIC && Block.IsSymmetricType() && row==col) MT=U_MAT_SYMMETRIC;
    else if(Nrow==Ncol)                                            MT=U_MAT_SQUARE;
    else                                                           MT=U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::AddBlock(int row, int col, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::AddBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::AddBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Block.Data==NULL && Block.MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::AddBlock(). Invalid Data NULL pointer of Block matrix argument.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::AddBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(Block.MT==U_MAT_NULL) return U_OK;

    if(this->IsDiagonalType())
    {
        if(Block.IsDiagonalType() && row==col)
        {
            double* NewData = new double[Nrow];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::AddBlock(). Memory allocation, Nrow = %d . \n", Nrow);
                return U_ERROR;
            }
            for(int k=0; k<Nrow; k++) 
                if(k<row || k>=row+Block.Nrow) NewData[k] = GetElement(k,k);
                else                           NewData[k] = GetElement(k,k) + Block.GetElement(k-row,k-col);
            delete[] Data; Data = NewData;
            MT = U_MAT_DIAGONAL;
            return U_OK;
        }
        if(ForceGeneralType()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrix::AddBlock(). Forcing general matrix type . \n");
            return U_ERROR;
        }
        if(Block.MT==U_MAT_SYMMETRIC && row==col) MT = U_MAT_SYMMETRIC;
    }
    if(Block.IsDiagonalType())
    {
        double*       pData  = Data+row*Ncol+col;
        for(int k=0; k<Block.Nrow; k++, pData+=Ncol+1) *pData += Block.GetElement(k,k);
    }
    else
    {
        for(int i=0; i<Block.Nrow; i++)
        {
            double*       pData  = Data       +(i+row)*Ncol+col;
            const double* pBlock = Block.Data + i     *Block.Ncol;
            for(int j=0; j<Block.Ncol; j++) *pData++ += *pBlock++;
        }
    }
    if(MT==U_MAT_SYMMETRIC && Block.IsSymmetricType() && row==col) MT=U_MAT_SYMMETRIC;
    else if(Nrow==Ncol)                                            MT=U_MAT_SQUARE;
    else                                                           MT=U_MAT_GENERAL;
    return U_OK;
}
ErrorType UMatrix::SubtractBlock(int row, int col, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SubtractBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::SubtractBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Block.Data==NULL && Block.MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::SubtractBlock(). Invalid Data NULL pointer of Block matrix argument.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::SubtractBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(Block.MT==U_MAT_NULL) return U_OK;

    if(this->IsDiagonalType())
    {
        if(Block.IsDiagonalType() && row==col)
        {
            double* NewData = new double[Nrow];
            if(NewData==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::SubtractBlock(). Memory allocation, Nrow = %d . \n", Nrow);
                return U_ERROR;
            }
            for(int k=0; k<Nrow; k++) 
                if(k<row || k>=row+Block.Nrow) NewData[k] = GetElement(k,k);
                else                           NewData[k] = GetElement(k,k) - Block.GetElement(k-row,k-col);
            delete[] Data; Data = NewData;
            MT = U_MAT_DIAGONAL;
            return U_OK;
        }
        if(ForceGeneralType()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrix::SubtractBlock(). Forcing general matrix type . \n");
            return U_ERROR;
        }
        if(Block.MT==U_MAT_SYMMETRIC && row==col) MT = U_MAT_SYMMETRIC;
    }
    if(Block.IsDiagonalType())
    {
        double*       pData  = Data+row*Ncol+col;
        for(int k=0; k<Block.Nrow; k++, pData+=Ncol+1) *pData -= Block.GetElement(k,k);
    }
    else
    {
        for(int i=0; i<Block.Nrow; i++)
        {
            double*       pData  = Data       +(i+row)*Ncol+col;
            const double* pBlock = Block.Data + i     *Block.Ncol;
            for(int j=0; j<Block.Ncol; j++) *pData++ -= *pBlock++;
        }
    }
    if(MT==U_MAT_SYMMETRIC && Block.IsSymmetricType() && row==col) MT=U_MAT_SYMMETRIC;
    else if(Nrow==Ncol)                                            MT=U_MAT_SQUARE;
    else                                                           MT=U_MAT_GENERAL;
    return U_OK;
}
UMatrix UMatrix::GetRowSelection(const int* IndexR, int Nsel) const
/*
    Return UMatrix by taking a set of Nsel rows from *this, wherein IndexR[k], k=0,..,Nsel-1 refer to the rows that
    are stored on the out put matrix. The order of rows is determined by the indices IndexR[], duplicates are allowed.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetRowSelection(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(IndexR==NULL || Nsel<0)
    {
        if(Nsel==0)  return UMatrix();
        CI.AddToLog("ERROR: UMatrix::GetRowSelection(). Invalid NULL pointer argument or invalid Nsel (=%d).\n", Nsel);
        return UMatrix(U_ERROR);
    }
    for(int k=0; k<Nsel;k++)
    {
        if(IndexR[k]>=0 && IndexR[k]<Nrow) continue;
        CI.AddToLog("ERROR: UMatrix::GetRowSelection(). Invalid selection: IndexR[%d]=%d.\n", k, IndexR[k]);
        return UMatrix(U_ERROR);
    }

    if(MT==U_MAT_NULL)
    {
        UMatrix SelectMat;
        SelectMat.Nrow = Nsel;
        SelectMat.Ncol = Ncol;
        SelectMat.MT   = U_MAT_NULL;
        return SelectMat;
    }

    UMatrix SelectMat(DNULL, Nsel, Ncol);
    if(SelectMat.GetError()!=U_OK || SelectMat.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetRowSelection(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    SelectMat.MT = (Nsel==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    double* Select = SelectMat.Data;
    if(IsDiagonalType()==true)
    {
        for(int i=0;i<Nsel;i++)
        {
            int isel = IndexR[i];
            Select[i*Ncol+isel] = GetElement(isel, isel);
        }
    }
    else
    {
        for(int i=0;i<Nsel;i++)
        {
            double* pDat = Data + IndexR[i]*Ncol;
            for(int j=0;j<Ncol;j++) *Select++ = *pDat++;
        }
    }
    return SelectMat;
}

ErrorType UMatrix::SelectRowCol(const bool* SelectRow, const bool* SelectCol)
{
    if(this==NULL || error!=U_OK       ) 
    {
        CI.AddToLog("ERROR: UMatrix::SelectRowCol(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL &&    MT!=U_MAT_NULL) 
    {
        CI.AddToLog("ERROR: UMatrix::SelectRowCol(). Data not set.\n");
        return U_ERROR;
    }
    if(SelectRow==NULL &&SelectCol==NULL) return U_OK;

    int NRsel = 0;  for(int k=0; k<Nrow; k++) if(SelectRow[k]) NRsel++;
    int NCsel = 0;  for(int k=0; k<Ncol; k++) if(SelectCol[k]) NCsel++;

    if(NRsel==Nrow && NCsel==Ncol) return U_OK;
    if(NRsel==0    && NCsel==0   )
    {
        delete[] Data; Data = NULL;
        MT = U_MAT_NULL;
        return U_OK;
    }

    if(IsSymmetricType()==true && SelectRow!=SelectCol)
    {
        for(int k=0; k<Nrow; k++) 
        {
            if(SelectRow[k]==SelectCol[k]) continue;
            CI.AddToLog("ERROR: UMatrix::SelectRowCol(). Row/collumn selection different for rows and collums (k=%d).\n", k);
            return U_ERROR;
        }
    }

    if(MT==U_MAT_NULL || MT==U_MAT_IDENTITY || MT==U_MAT_IDENTCONST)
    {
        Nrow=Ncol=NRsel; 
        return U_OK;
    }
    else if(MT==U_MAT_DIAGONAL)
    {
        for(int k=0, ksel=0; k<Nrow; k++) if(SelectRow[k]) Data[ksel++] = Data[k];
        Nrow=Ncol=NRsel; 
        return U_OK;
    }

    for(int i=0, k=0, ksel=0; i<Nrow; i++) 
    {
        if(NOT(SelectRow[i]))
        {
            k+=Ncol;
            continue;
        }
        for(int j=0; j<Ncol; j++, k++) if(SelectCol[j]) Data[ksel++] = Data[k];
    }
    double* NewData = new double[NRsel*NCsel];
    if(NewData==NULL)
    {
        CI.AddToLog("WARNING: UMatrixSymmetric::SelectRowCol(). Memory allocation, NRsel=%d, NCsel=%d .\n", NRsel, NCsel);
        return U_OK;
    }
    else
    {
        for(int kk=0; kk<NRsel*NCsel; kk++) NewData[kk] = Data[kk];
        delete[] Data; Data = NewData;
    }
    Nrow = NRsel;
    Ncol = NCsel;
    if(IsSymmetricType()==false)  MT = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;

    return U_OK;
}

UMatrix UMatrix::GetL1NormSolution(const UMatrix& BVec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL1NormSolution(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&BVec==NULL || BVec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL1NormSolution().Erroneous UMatrix argument.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=BVec.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrix::GetL1NormSolution(). Matrix dimensions do not fit.\n");
        return UMatrix(U_ERROR);
    }
    if(BVec.GetNcol()>1)
    {
        CI.AddToLog("ERROR: UMatrix::GetL1NormSolution(). Function not yet implemented for multiple collumns of BVec.\n");
        return UMatrix(U_ERROR);
    }
    UMatrix X(DNULL, Ncol, BVec.Ncol);
    if(SolveL1Norm(Data, X.Data, BVec.Data,  Nrow, Ncol)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL1NormSolution(). Finding L1 solution for col = %d .\n", 0);
        return UMatrix(U_ERROR);
    }
    return X;
}
UMatrix UMatrix::GetL2NormSolution(const UMatrix& BVec, double RelAverAbsEigenThresh) const
/*
    return (Mt M)inv Mt(Bvec)
    Here the inverse of (Mt M) is reguralized using RelAverAbsEigenThresh to set the 
            number of eigenvectors that are included (the remainders are set to zero).

    The returned value is the minimum L2 norm solution of M X = BVec + noise.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL2NormSolution(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&BVec==NULL || BVec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL2NormSolution().Erroneous UMatrix argument.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=BVec.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrix::GetL2NormSolution(). Matrix dimensions do not fit.\n");
        return UMatrix(U_ERROR);
    }
    if(RelAverAbsEigenThresh<0)
    {
        CI.AddToLog("WARNING: UMatrix::GetL2NormSolution(). Threshold parameter out of range (set to 0.).\n");
        RelAverAbsEigenThresh = 0.;
    }
    UMatrix          MTB = GetMatMul(*this, true, BVec, false);
    UMatrixSymmetric MTM = GetMTM();
    if(MTB.GetError()!=U_OK || MTM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetL2NormSolution(). Computing matrix multiplications MTB and/or MTM.\n");
        return UMatrix(U_ERROR);
    }
    int NPos = MTM.GetNPosEig(RelAverAbsEigenThresh);
    return MTM.GetAxIsB(MTB, NPos);
}
UMatrix UMatrix::GetElasticNetSolution(const UMatrix& BVec, double Lam1, double Lam2) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetElasticNetSolution(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&BVec==NULL || BVec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetElasticNetSolution().Erroneous UMatrix argument.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=BVec.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrix::GetElasticNetSolution(). Matrix dimensions do not fit.\n");
        return UMatrix(U_ERROR);
    }
    if(Lam1<0. || Lam2<0.)
    {
        CI.AddToLog("ERROR: UMatrix::GetElasticNetSolution(). Parameter out of range: Lam1 = %f, Lam2 = %f   .\n", Lam1, Lam2);
        return UMatrix(U_ERROR);
    }
    UElasticNet EN(*this, BVec, Lam2);
    if(EN.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetElasticNetSolution(). Creating EN object .\n");
        return UMatrix(U_ERROR);
    }
    return EN.GetBetaMin(Lam1);
}
UMatrix UMatrix::GetLassoSolution(const UMatrix& BVec, double Lam1) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetLassoSolution(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&BVec==NULL || BVec.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetLassoSolution().Erroneous UMatrix argument.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=BVec.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrix::GetLassoSolution(). Matrix dimensions do not fit.\n");
        return UMatrix(U_ERROR);
    }
    if(Lam1<0.)
    {
        CI.AddToLog("ERROR: UMatrix::GetLassoSolution(). Parameter out of range: Lam1 = %f   .\n", Lam1);
        return UMatrix(U_ERROR);
    }
    return GetElasticNetSolution(BVec, Lam1, 0.);
}


UMatrix UMatrix::GetPseudoInverse(int nEigen) const
/* 
    This routine computes and returns the pseudo inverse of Data using nEigen eigen values.
    If nEigen==0, the number of nonzero eigenvalues is determined and
    the Moore-Penrose inverse is returned in Inv.
*/
{        
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Matrix not square.\n");
        return UMatrix(U_ERROR);
    }
    if(nEigen==0) return UMatrix();
    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Matrix is empty.\n");
        return UMatrix(U_ERROR);
    }
    if(nEigen<0)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Invalid Argument. nEigen = %d \n", nEigen);
        return UMatrix(U_ERROR);
    }    
    if(IsDiagonalType()==true)
    {
        UMatrix Minv(*this);
        if(Minv.error!=U_OK || Minv.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Creating output matrix \n");
            return UMatrix(U_ERROR);
        }
        if(Minv.MT==U_MAT_IDENTITY) 
        {
            if(nEigen!=Nrow) CI.AddToLog("WARNING: UMatrix::GetPseudoInverse(Inv, nEigen). Identity matrix. nEigen = %d \n", nEigen);
            return Minv;
        }
        if(Minv.MT==U_MAT_IDENTCONST)
        {
            if(Minv.Data[0]==0.) 
            {
                CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Matrix has zero diagonal\n");
                return UMatrix(U_ERROR);
            }
            Minv.Data[0] = 1./Minv.Data[0];
            if(nEigen!=Nrow) CI.AddToLog("WARNING: UMatrix::GetPseudoInverse(Inv, nEigen). Constant diagonal. nEigen = %d \n", nEigen);
            return Minv;
        }
        bool Fabs      = false;
        bool HFirst    = true;
        int* DiagIndex = GetOrderIndexArray(Data, Nrow, Fabs, HFirst);
        if(DiagIndex==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Ordering diagonal elements \n");
            return UMatrix(U_ERROR);
        }
        for(int i=0; i<Nrow; i++) 
        {
            if(i<nEigen)
            {
                double DD = Minv.Data[DiagIndex[i]] = Data[i];
                if(DD==0.)
                {
                    CI.AddToLog("WARNING: UMatrix::GetPseudoInverse(Inv, nEigen). Diagonal element zero (i=%d) \n", i);
                    Minv.Data[DiagIndex[i]] = 0;
                }
                else
                    Minv.Data[DiagIndex[i]] = 1./DD;
            }
            else
            {
                Minv.Data[DiagIndex[i]] = 0;
            }
        }
        delete[] DiagIndex;
        return Minv;
    }

    UMatrix Minv(DNULL, Ncol, Nrow);
    double* U       = new double[Nrow*Nrow];
    double* Lamda   = new double[Nrow];
    double* V       = new double[Nrow*Nrow];
    if(!Minv.Data || !Lamda || !V || !U)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Memory Allocation, Nrow = %d.\n", Nrow);
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }
    for(int k=0;k<Nrow*Nrow;k++) U[k]=Data[k];

    if (svdcmp_d(U, Nrow, Nrow, Lamda, V)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Error in SVD decomposition.\n");
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }
  
    int k = 0;
    for(k=0;k<nEigen;k++) if (Lamda[k]<1e-10) break;
    
    if(nEigen>0 && k<nEigen)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Number of nonzero eigen values, %d, smaller than %d.\n",k,nEigen);
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }

    double* Inverse = Minv.Data;
    if(MT==U_MAT_SYMMETRIC)
    {
        for(int i=0;i<Ncol;i++)
        {
            for(int j=0;j<Ncol;j++)
            {
                if(j>=i)
                {
                    const double* pV  = V+i*Ncol;
                    const double* pU  = V+j*Ncol;  // *U = * V
                    const double* pL  = Lamda;
                    double        Inv = 0.;
                    for(int k=0;k<nEigen;k++) Inv += (*pV++) * (*pU++) / (*pL++);
                    Inverse[i*Ncol+j] = Inv;
                }
                else
                    Inverse[i*Ncol+j] = Inverse[j*Ncol+i];
            }
        }
        Minv.MT = U_MAT_SYMMETRIC;
    }
    else
    {
        for(int i=0;i<Ncol;i++)
            for(int j=0;j<Ncol;j++)
            {
                const double* pV  = V+i*Ncol;
                const double* pU  = U+j*Ncol;
                const double* pL  = Lamda;
                double        Inv = 0.;
                for(int k=0;k<nEigen;k++) Inv += (*pV++) * (*pU++) / (*pL++);
                Inverse[i*Ncol+j] = Inv;
            }
    }
    delete[] Lamda; delete[] V; delete[] U;
    return Minv;
}

UMatrix UMatrix::GetPseudoInverse(double Tresh) const
/* 
    This routine computes the pseudo inverse of Data using k eigenvalues 
    such that sum(l=1...k) (lamda_l)^2 >= (1-Tresh)*power of Data, given
    0<Tresh<1. The pseudo inverse is returned in Inv.
*/
{        
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Matrix not square.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Matrix is empty.\n");
        return UMatrix(U_ERROR);
    }
    if(Tresh<=0 || Tresh>=1)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Invalid Thres (=%f) parameter.\n", Tresh);
        return UMatrix(U_ERROR);
    }    
    if(IsDiagonalType()==true)
    {
        UMatrix Minv(*this);
        if(Minv.error!=U_OK || Minv.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Creating output matrix \n");
            return UMatrix(U_ERROR);
        }
        if(Minv.MT==U_MAT_IDENTITY) return Minv;
        if(Minv.MT==U_MAT_IDENTCONST)
        {
            if(Minv.Data[0]!=0.) Minv.Data[0] = 1./Minv.Data[0];
            return Minv;
        }

        int* index = GetOrderIndexArray(Data, Nrow, true, true);
        if(index==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(). Ordering diagonal elements \n");
            return UMatrix(U_ERROR);
        }
        double pow  = GetFrobNorm2();
        double err  = 0.;
        for(int k=Nrow-1; k>= 0; k--)
        {   
            int i = index[k];
            Minv.Data[i] = 0.;
            err  += Data[i]*Data[i];
            if(err > Tresh*pow) Minv.Data[i] = 1./Data[i];
        }
        delete[] index;
        return Minv;
    }

    UMatrix Minv(DNULL, Ncol, Nrow);
    double* U       = new double[Nrow*Nrow];
    double* Lamda   = new double[Nrow];
    double* V       = new double[Nrow*Nrow];
    if(!Minv.Data || !Lamda || !V || !U)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Memory Allocation, Nrow = %d.\n", Nrow);
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }
    for(int k=0;k<Nrow*Nrow;k++) U[k]=Data[k];

    if (svdcmp_d(U, Nrow, Nrow, Lamda, V)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, nEigen). Error in SVD decomposition.\n");
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }
    
    int    nEigen = 0;
    double pow    = 0.;   
    for(int k=0;k<Nrow;k++)  pow += Lamda[k]*Lamda[k];
    if(pow==0) 
    {
        CI.AddToLog("ERROR: UMatrix::GetPseudoInverse(Inv, Tresh). Power of matrix is zero.\n");
        delete[] Lamda; delete[] V; delete[] U;
        return UMatrix(U_ERROR);
    }
    
    double err  = 0.;
    int    k    = 0 ;
    for(k=Nrow-1;k>=0;k--)
    {        
        err+= Lamda[k]*Lamda[k];
        if((err/pow) > Tresh)  break;
    }
    nEigen = k+1;
    if(nEigen==0) nEigen =1;
   
    double* Inverse = Minv.Data;
    if(MT==U_MAT_SYMMETRIC)
    {
        for(int i=0;i<Ncol;i++)
        {
            for(int j=0;j<Ncol;j++)
            {
                if(j>=i)
                {
                    const double* pV  = V+i*Ncol;
                    const double* pU  = V+j*Ncol;  // *U = * V
                    const double* pL  = Lamda;
                    double        Inv = 0.;
                    for(int k=0;k<nEigen;k++) Inv += (*pV++) * (*pU++) / (*pL++);
                    Inverse[i*Ncol+j] = Inv;
                }
                else
                    Inverse[i*Ncol+j] = Inverse[j*Ncol+i];
            }
        }
        Minv.MT = U_MAT_SYMMETRIC;
    }
    else
    {
        for(int i=0;i<Ncol;i++)
            for(int j=0;j<Ncol;j++)
            {
                const double* pV  = V+i*Ncol;
                const double* pU  = U+j*Ncol;
                const double* pL  = Lamda;
                double        Inv = 0.;
                for(int k=0;k<nEigen;k++) Inv += (*pV++) * (*pU++) / (*pL++);
                Inverse[i*Ncol+j] = Inv;
            }
    }
    delete[] Lamda; delete[] V; delete[] U;
    return Minv;
}

double* UMatrix::GetSingValuesArray(int* NSingVal) const
/* 
    This routine computes and returns the singular values of Data using
    the Singular Value Decomposition. 
*/   
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValuesArray(). Object NULL or erroneous .\n");
        return NULL;
    }
    if(MT==U_MAT_NULL) 
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValuesArray(). Matrix is empty.\n");
        return NULL;
    }
    if(NSingVal) *NSingVal = 0;

    if(IsDiagonalType()==true)
    {
        double* Lamda = new double[Nrow];
        if(Lamda==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetSingValues(). Memory Allocation, Nrow=%d.\n", Nrow);
            return NULL;
        }
        for(int k=0; k<Nrow; k++) Lamda[k] = GetElement(k,k);
        SortArray(Lamda, Nrow, false, true);
        if(NSingVal) *NSingVal = Nrow;
        return Lamda;
    }

    int     N       = MAX(Ncol, Nrow);
    double* U       = new double[Nrow*Ncol];
    double* Lamda   = new double[N        ];
    double* V       = new double[Ncol*Ncol];
    if(!Lamda || !V || !U)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValues(). Memory Allocation, Ncol=%d, Nrow=%d.\n", Ncol, Nrow);
        delete[] U;  delete[] V; delete[] Lamda;
        return NULL;
    }
    for(int k=0; k<N        ; k++) Lamda[k] = 0.;
    for(int k=0; k<Nrow*Ncol; k++) U[k]     = Data[k];

    if(svdcmp_d(U, Nrow, Ncol, Lamda, V)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValues()). Error in SVD decomposition.\n");       
        delete[] U;  delete[] V; delete[] Lamda;
        return NULL;
    }
    delete[] U;  delete[] V;;

    if(NSingVal) *NSingVal = N;
    return Lamda;
}
double UMatrix::GetSingValue(int n) const
/* 
   This routine computes the n-th singular values of Data 
   the GetSingValues(double*) routine.
*/   
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValue(). Object NULL or erroneous .\n");
        return 0.;
    }
    if(MT==U_MAT_NULL) 
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValue(). Matrix is empty.\n");
        return 0.;
    }

    if (n<0 || n>MAX(Ncol,Nrow)-1)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValue(). Invalid Argument (n=%d).\n", n);       
        return 0.;        
    }
   
    int     NSing = 0;
    double* Eigen = GetSingValuesArray(&NSing);
    if(Eigen==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetSingValue(). Error in computing singular values.\n");
        return 0.;
    }
    
    double value = (n>NSing-1) ? 0. : Eigen[n];
    delete[] Eigen;
    return value;
}

UMatrix UMatrix::GetOrthogonalBasis(void) const
/* 
   This routine computes an orthogonal basis 
   The complement of row space of M (dimension Ncol)
*/ 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: GetOrthogonalBasis(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis() Matrix is empty.\n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        UMatrix Basis(Nrow);
        if(Basis.error!=U_OK || Basis.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis() Creating output matrix.\n");
            return UMatrix(U_ERROR);
        }
        return Basis;
    }
    double* U     = new double[Nrow*Ncol];
    double* Lamda = new double[Ncol     ];
    double* V     = new double[Ncol*Ncol];
    if(!Lamda || !V || !U)
    {
        CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis(). Memory Allocation.\n");        
        delete[] U; delete[] V; delete[] Lamda;
        return UMatrix(U_ERROR);
    }

    for(int k=0; k<Nrow*Ncol;k++) U[k] = Data[k];

    if(svdcmp_d(U, Nrow, Ncol, Lamda, V)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis(). SVD decomposition.\n");
        delete[] U; delete[] V; delete[] Lamda;
        return UMatrix(U_ERROR);
    }

    int k =0; while(k<Ncol && (fabs(Lamda[k])>1e-10) ) k++;
    int rank = k;
    if(rank==0)
    {
        CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis(). Matrix has zero rank!.\n");
        delete[] U; delete[] V; delete[] Lamda;
        return UMatrix(U_ERROR);
    }
    delete[] U; delete[] Lamda;

    if(Ncol==rank)
    {
        delete[] V;
        return UMatrix();
    } 

    UMatrix Basis(DNULL, Ncol, Ncol-rank);
    if(Basis.GetError()!=U_OK || Basis.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetOrthogonalBasis(). Creating output matrix.\n");
        delete[] V;
        return UMatrix(U_ERROR);
    }

    double* Bas = Basis.Data;
    for(int r=0; r<Ncol-rank; r++)
        for(int j=0; j<Ncol; j++)
            Bas[j*(Ncol-rank)+r] = V[j*Ncol+r+rank];

    delete[] V;

    return Basis;
}

UMatrix UMatrix::GetProjection(bool complement) const 
/* 
    if(complement) return Id(Nrow) - M inv(M^tM) M^t
    else           return            M inv(M^tM) M^t
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetProjection(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetProjection(). Matrix is empty.\n");
        return UMatrix(U_ERROR);
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetProjection(). Data matrix NULL.\n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        if(complement) return UMatrix();
        else           return UMatrix(Nrow);
    }

    UMatrixSymmetric MTM    = GetMTM();
    UMatrix Proj = MTM.GetAMAT(*this, true, Nrow); // now MTMinv = M inv(M^tM)M^t
    if(Proj.GetError() != U_OK) 
    {
        CI.AddToLog("ERROR: UMatrix::GetProjection(). Computing matrix multiplication: M (MtM)inv Mt.\n");
        return UMatrix(U_ERROR);
    }
    if(complement) return UMatrix(Nrow)-Proj;

    return Proj;
}

UMatrix UMatrix::GetMTM(const bool* SelectRow) const
/* 
    This routine computes and return the UMatrix product Data^t.Data
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetMTM(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix();

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMTM().  Matrix data is NULL. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType() ==true) 
    {
        if(SelectRow==NULL)  return (*this) * (*this);
        else                 return GetMMT(SelectRow);
    }
    if(IsSymmetricType()==true) return GetMMT(SelectRow);

    UMatrix MTM(DNULL, Ncol, Ncol);
    if(MTM.GetError()!=U_OK || MTM.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMTM(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    MTM.MT    = U_MAT_SYMMETRIC;
    double* A = MTM.Data;
    
    for(int j1=0;j1<Ncol;j1++)
        for(int j2=0;j2<Ncol;j2++)
        {
            if(j1<=j2)
            {
                double* pMat1 = Data+j1;
                double* pMat2 = Data+j2;
                double  prod  = 0.;
                if(SelectRow==NULL) for(int i=0;i<Nrow;i++, pMat1+=Ncol, pMat2+=Ncol)  prod += (*pMat1) * (*pMat2);
                else                for(int i=0;i<Nrow;i++, pMat1+=Ncol, pMat2+=Ncol)  if(SelectRow[i]) prod += (*pMat1) * (*pMat2);
                A[j1*Ncol+j2] = prod;
            }
            else
                A[j1*Ncol+j2]=A[j2*Ncol+j1];
        }

    return MTM;
}

UMatrix UMatrix::GetMMT(const bool* SelectCol) const
/* 
   This routine computes and returns the UMatrix product Data.Data^t 
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetMMT(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) return UMatrix();
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMMT(). Matrix data is NULL. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType() ==true) 
    {
        if(SelectCol==NULL) return (*this) * (*this);

        UMatrix MMT(DNULL, Nrow);
        if(MMT.GetError()!=U_OK || MMT.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrix::GetMMT(). Creating diagonal output matrix. \n");
            return UMatrix(U_ERROR);
        }
        for(int j=0; j<Nrow; j++)
        {
            switch(MT)
            {
            case U_MAT_IDENTITY   : MMT.Data[j] = SelectCol[j] ? 1.              : 0.; break;
            case U_MAT_IDENTCONST : MMT.Data[j] = SelectCol[j] ? Data[0]*Data[0] : 0.; break;
            case U_MAT_DIAGONAL   : MMT.Data[j] = SelectCol[j] ? Data[j]*Data[j] : 0.; break;
            default: return UMatrix(U_ERROR);
            }
        }
        return MMT;
    }
    UMatrix MMT(DNULL, Nrow, Nrow);
    if(MMT.GetError()!=U_OK || MMT.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetMMT(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    MMT.MT    = U_MAT_SYMMETRIC;
    double* A = MMT.Data;

    for(int i1=0;i1<Nrow;i1++)
        for(int i2=0;i2<Nrow;i2++)
        {
            if(i1<=i2)
            {
                double* pMat1 = Data+i1*Ncol;
                double* pMat2 = Data+i2*Ncol;
                double  prod  = 0.;
                if(SelectCol==NULL) for(int j=0;j<Ncol;j++)                                    prod += (*pMat1++) * (*pMat2++);
                else                for(int j=0;j<Ncol;j++, pMat1++, pMat2++) if(SelectCol[j]) prod += (*pMat1) * (*pMat2);
                A[i1*Nrow+i2] = prod;
            }
            else
                A[i1*Nrow+i2] = A[i2*Nrow+i1];
        }

    return MMT;
}
UMatrix UMatrix::GetDistMatMMT() const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetDistMatMMT(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL) 
    {
        UMatrix DistMMT;
        DistMMT.Nrow = DistMMT.Ncol = Nrow;
        return DistMMT;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDistMatMMT(). Matrix data is NULL. \n");
        return UMatrix(U_ERROR);
    }
    UMatrix DistMMT(DNULL, Nrow, Nrow);
    if(DistMMT.GetError()!=U_OK || DistMMT.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetDistMatMMT(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    DistMMT.MT    = U_MAT_SYMMETRIC;
    double*  pDis = DistMMT.Data;
    if(IsDiagonalType()==true)
    {
        for(int i1=0; i1<Nrow; i1++)
            for(int i2=0; i2<Ncol; i2++, pDis++)
            {
                if(i1<i2)       *pDis = SQR(GetElement(i1,i1))+SQR(GetElement(i2,i2));
                else if(i1==i2) *pDis = 0.;
                else            *pDis = DistMMT.Data[Ncol*i2+i1];
            }
    }
    else
    {
        for(int i1=0;i1<Nrow;i1++)
            for(int i2=0;i2<Nrow;i2++)
                if(i1<i2)
                {
                    double* pMat1 = Data+i1*Ncol;
                    double* pMat2 = Data+i2*Ncol;
                    double  dis   = 0.;
                    for(int j=0;j<Ncol;j++, pMat1++, pMat2++) dis += SQR(*pMat1-*pMat2);
                    pDis[i1*Nrow+i2] = dis;
                }
                else if(i1==i2)
                {
                    pDis[i1*Nrow+i2] = 0.;
                }
                else
                    pDis[i1*Nrow+i2] = pDis[i2*Nrow+i1];
    }
    return DistMMT;
}

UMatrix UMatrix::GetAMAT(const UMatrix& A) const
// 
//   This routine computes and returns the UMatrix product A.M.A^t
//
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetAMAT(). Object NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(&A==NULL || A.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetAMAT(). Argument NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }

    if(MT==U_MAT_NULL || A.MT==U_MAT_NULL) return UMatrix();
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetAMAT(). Matrix data is NULL. \n");
        return UMatrix(U_ERROR);
    }
    if(A.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetAMAT(). Matrix argument data is NULL.\n");
        return UMatrix(U_ERROR);
    }   
    if(Nrow!=A.Ncol || Ncol!=A.Ncol)
    {
        CI.AddToLog("ERROR: UMatrix::MultiplyAMAT(). Matrix dimensions do not match. \n");
        return UMatrix(U_ERROR);
    }

    UMatrix Help = GetMatMul(A, false, *this, false);                    // Help = AM
    UMatrix AMAT = GetMatMul(Help, false, A, true);                      // AMAT = Help.AT = AMAT.
    if(A.IsSymmetricType()==true) 
        AMAT.ForceSymmetricType(1.e-8);
    return AMAT;
}
double UMatrix::GetVTMV(const UMatrix& Vec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(&Vec==NULL || Vec.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Argument NULL or erroneous. \n");
        return 0.;
    }
    if(Ncol!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Matrix not square. \n");
        return 0.;
    }
    if(Vec.GetNrow()!=Ncol || Vec.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Argument nor a column vector, or number of rows do not match (Vec.Nrow=%d, Vec.Ncol=%d). \n",Vec.Nrow, Vec.Ncol);
        return 0.;
    }

    if(MT==U_MAT_NULL || Vec.MT==U_MAT_NULL) return 0.;
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Matrix data is NULL. \n");
        return 0.;
    }
    if(Vec.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Matrix argument data is NULL.\n");
        return 0.;
    }   

    double Sum = 0;
    if(IsDiagonalType()==true)
    {
        for(int k=0; k<Ncol; k++) Sum += GetElement(k,k)*SQR(Vec.Data[k]);
    }
    else
    {
        double* pData = Data;
        for(int i=0; i<Nrow; i++)
        {
            double SumR = 0.;
            for(int j=0; j<Ncol; j++, pData++) SumR += *pData * Vec.Data[j];
            Sum += Vec.Data[i]*SumR;
        }
    }
    return Sum;
}

int UMatrix::GetNelem(void) const
{
    if(this==NULL) return -1;

    switch(MT)
    {
    case U_MAT_NULL      : return 0;
    case U_MAT_IDENTITY  : return 1;
    case U_MAT_IDENTCONST: return 1;
    case U_MAT_DIAGONAL  : return Nrow;
    case U_MAT_SYMMETRIC : 
    case U_MAT_SQUARE    : 
    case U_MAT_GENERAL   : return Nrow*Ncol;
    }
    CI.AddToLog("ERROR: UMatrix::GetNelem(). Invalid matrix type %d .\n", MT);
    return -1;
}
bool UMatrix::IsDiagonalType(void) const
{
    if(this==NULL) return false;
    return (MT==U_MAT_IDENTITY) || (MT==U_MAT_IDENTCONST) || (MT==U_MAT_DIAGONAL);
}
bool UMatrix::IsSymmetricType(void) const
{
    if(this==NULL) return false;
    return IsDiagonalType()==true || (MT==U_MAT_SYMMETRIC);
}
bool UMatrix::IsSquareType(void) const
{
    if(this==NULL) return false;
    return IsSymmetricType()==true || (MT==U_MAT_SQUARE);
}
int UMatrix::GetFirstSelect(const bool* Sel, int N)
{
    if(Sel==NULL) return  0;
    if(N<=0)      return -1;

    for(int k=0; k<N; k++) if(Sel[k]) return k;
    return -1;
}
int UMatrix::GetNSelect(const bool* Sel, int N)
{
    if(Sel==NULL) return  N;
    if(N<0)       return -1;

    int Nsel = 0;
    for(int k=0; k<N; k++) if(Sel[k]) Nsel++;
    return Nsel;
}
int* UMatrix::GetSelection(const bool* Sel, int N)
{
    if(N<=0) return NULL;
    
    int* Selection = new int[N];
    if(Selection==NULL) return NULL;
    for(int n=0; n<N; n++) Selection[n] = -1;

    if(Sel==NULL)   for(int n=0      ; n<N; n++) Selection[n] = n;
    else            for(int n=0, is=0; n<N; n++) if(Sel[n]) Selection[is++] = n;

    return Selection;
}

UMatrix DLL_IO operator*(double f, const UMatrix& M)
{
    if(&M==NULL || M.GetError()!=U_OK) return UMatrix(U_ERROR);

    UMatrix Prod;
    if(f==0.) 
    {
        Prod.Ncol = M.Ncol;
        Prod.Nrow = M.Nrow;
        Prod.MT   = U_MAT_NULL;
    }
    else
    {
        Prod  = M;
        Prod *= f;
    }
    return Prod;
}

double  GetFrobNormDifference2(const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError()!=U_OK ||
       &M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetFrobNormDifference2(). NULL or erroneous argument(s). \n");
        return -1.;
    }
    if(M1.GetNcol()!=M2.GetNcol() || M1.GetNrow()!=M2.GetNrow())
    {
        CI.AddToLog("ERROR: GetFrobNormDifference2(). Numbers or rows and/or collumns do not match. \n");
        return -1.;
    }
    return M1.GetFrobNormDifference2(M2);
}
double  GetFrobNormDifference (const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError()!=U_OK ||
       &M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetFrobNormDifference(). NULL or erroneous argument(s). \n");
        return -1.;
    }
    if(M1.GetNcol()!=M2.GetNcol() || M1.GetNrow()!=M2.GetNrow())
    {
        CI.AddToLog("ERROR: GetFrobNormDifference(). Numbers or rows and/or collumns do not match. \n");
        return -1.;
    }
    return M1.GetFrobNormDifference (M2);
}

UMatrix GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2)
{
    if(&M1==NULL || M1.GetError()!=U_OK ||
       &M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetMatMul(). NULL or erroneous argument(s). \n");
        return UMatrix(U_ERROR);
    }
    if(M1.MT==U_MAT_NULL) return UMatrix();
    if(M2.MT==U_MAT_NULL) return UMatrix();
    
    const double* pM1 = M1.Data;
    const double* pM2 = M2.Data;
    if(pM1==NULL || pM2==NULL)
    {
        CI.AddToLog("ERROR: GetMatMul(). Data M1 or M2 not properly set. \n");
        return UMatrix(U_ERROR);
    }

    if(Transp1)
    {
        if(Transp2)
        {
            if(M1.Nrow != M2.Ncol)
            {
                CI.AddToLog("ERROR: GetMatMul(). Incompatible M1.Nrow=%d and M2.Nrow=%d .\n", M1.Nrow, M2.Nrow);
                return UMatrix(U_ERROR);
            }

            if(M1.IsDiagonalType()==true            ) return M1 * M2.GetTranspose();
            if(M2.MT              ==U_MAT_IDENTITY  ) return M1.GetTranspose();
            if(M2.MT              ==U_MAT_IDENTCONST) return M1.GetTranspose()*M2.Data[0];

            UMatrix M1TM2T = UMatrix(DNULL, M1.Ncol, M2.Nrow);
            if(M1TM2T.GetError()!=U_OK || M1TM2T.Data==NULL)
            {
                CI.AddToLog("ERROR: GetMatMul(). Creating output matrix M1TM2T.\n");
                return UMatrix(U_ERROR);
            }
            M1TM2T.MT = (M1TM2T.Nrow==M1TM2T.Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
            double* pM1TM2T = M1TM2T.Data;

            if(M2.IsDiagonalType()==true)   // compute M1_ji * M2_ii
            {
                for(int i=0; i<M1.Ncol; i++)
                {   
                    const double* pMat  = pM1  + i;
                    const double* pDiag = pM2;
                    for(int j=0; j<M2.Nrow; j++, pMat+=M1.Ncol) *pM1TM2T++ =(*pMat) * (*pDiag++);
                }
            }
            else
            {
                for(int i=0; i<M1.Ncol; i++)
                {   
                    for(int j=0; j<M2.Nrow; j++)
                    {
                        double        rw   = 0;
                        const double* pMat = pM1  + i;
                        const double* pA   = pM2  + j*M2.Ncol;
                        for(int k=0; k<M1.Nrow; k++, pMat+=M1.Ncol) rw += (*pMat) *  (*pA++);
                        *pM1TM2T++ = rw;            
                    }
                }
            }
            return M1TM2T;
        }
        else
        {
            if(M1.Nrow != M2.Nrow)
            {
                CI.AddToLog("ERROR: GetMatMul(). Incompatible M1.Nrow=%d and M2.Nrow=%d .\n", M1.Nrow, M2.Nrow);
                return UMatrix(U_ERROR);
            }
            if(M1.IsDiagonalType()==true            ) return M1 * M2;
            if(M2.MT              ==U_MAT_IDENTITY  ) return M1.GetTranspose();
            if(M2.MT              ==U_MAT_IDENTCONST) return M1.GetTranspose()*M2.Data[0];

            UMatrix M1TM2 = UMatrix(DNULL, M1.Ncol, M2.Ncol);
            if(M1TM2.GetError()!=U_OK || M1TM2.Data==NULL)
            {
                CI.AddToLog("ERROR: GetMatMul(). Creating output matrix M1TM2.\n");
                return UMatrix(U_ERROR);
            }
            double* pM1TM2 = M1TM2.Data;
            
            if(M2.IsDiagonalType()==true)   // compute M1_ji * M2_ii
            {
                for(int i=0; i<M1.Ncol; i++)
                {   
                    const double* pMat  = pM1  + i;
                    const double* pDiag = pM2;
                    for(int j=0; j<M2.Ncol; j++, pMat+=M1.Ncol) *pM1TM2++ =(*pMat) * (*pDiag++);
                }
            }
            else
            {
                for(int i=0; i<M1.Ncol; i++)
                {   
                    for(int j=0; j<M2.Ncol; j++)
                    {
                        double        rw   = 0;
                        const double* pMat = pM1  + i;
                        const double* pA   = pM2  + j;
                        for(int k=0; k<M1.Nrow; k++, pMat+=M1.Ncol, pA+=M2.Ncol) rw += (*pMat) *  (*pA);
                        *pM1TM2++ = rw;
                    }
                }
            }
            return M1TM2;
        }
    }
    else
    {
        if(Transp2)
        {
            if(M1.Ncol != M2.Ncol)
            {
                CI.AddToLog("ERROR: GetMatMul(). Incompatible M1.Ncol=%d and M2.Ncol=%d .\n", M1.Ncol, M2.Ncol);
                return UMatrix(U_ERROR);
            }
            if(M2.IsDiagonalType()==true            ) return M1 * M2;
            if(M1.MT              ==U_MAT_IDENTITY  ) return M2.GetTranspose();
            if(M1.MT              ==U_MAT_IDENTCONST) return M2.GetTranspose()*M1.Data[0];

            UMatrix M1M2T = UMatrix(DNULL, M1.Nrow, M2.Nrow);
            if(M1M2T.GetError()!=U_OK || M1M2T.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::GetMatMul(). Creating output matrix M1M2T.\n");
                return UMatrix(U_ERROR);
            }
            double* pM1M2T = M1M2T.Data;

            if(M1.IsDiagonalType()==true)   // compute A_jj * M_ji
            {
                for(int j=0; j<M1.Nrow; j++)
                {
                    double         Diag =  pM1[j];
                    const double* pMat  =  pM2+j;
                    for(int i=0; i<M2.Nrow; i++,pMat+=M2.Ncol) *pM1M2T++ = Diag * (*pMat);
                }
            }
            else
            {
                for(int j=0; j<M1.Nrow; j++)
                {
                    for(int i=0; i<M2.Nrow; i++)
                    {   
                        double        rw   = 0;
                        const double* pA   = pM1  + j*M1.Ncol;
                        const double* pMat = pM2  + i*M2.Ncol;
                        for(int k=0; k<M2.Ncol; k++) rw += (*pA++) * (*pMat++);
                        *pM1M2T++ = rw;            
                    }
                }
            }
            return M1M2T;
        }
        else
        {
            if(M1.Ncol != M2.Nrow)
            {
                CI.AddToLog("ERROR: GetMatMul(). Incompatible M1.Ncol=%d and M2.Nrow=%d .\n", M1.Ncol, M2.Nrow);
                return UMatrix(U_ERROR);
            }
            return M1 * M2;
        }
    }
    return UMatrix(U_ERROR);
}

UMatrix GetMatMul(const UMatrix& M1, const UMatrix& M2, const bool* SelectTerms)
{
    if(&M1==NULL || M1.GetError()!=U_OK ||
       &M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). NULL or erroneous argument(s). \n");
        return UMatrix(U_ERROR);
    }
    if(M1.MT==U_MAT_NULL) return UMatrix();
    if(M2.MT==U_MAT_NULL) return UMatrix();
    
    const double* pM1 = M1.Data;
    const double* pM2 = M2.Data;
    if(pM1==NULL || pM2==NULL)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Data M1 or M2 not properly set. \n");
        return UMatrix(U_ERROR);
    }
    if(M1.Ncol != M2.Nrow)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Incompatible M1.Ncol=%d and M2.Nrow=%d .\n", M1.Ncol, M2.Nrow);
        return UMatrix(U_ERROR);
    }

    if(SelectTerms==NULL) return M1*M2;
    int First = UMatrix::GetFirstSelect(SelectTerms, M1.Ncol);
    if(First<0)  return UMatrix(); // Empty matrix

    UMatrix M1M2;
    if(M1.IsDiagonalType()==true)
    {
        if(M2.IsDiagonalType()==true)
        {
            M1M2 = UMatrix(DNULL, M1.Ncol);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL) 
            {
                CI.AddToLog("ERROR: GetMatMul(Select). Creating output matrix for diagonal case. \n");
                return UMatrix(U_ERROR);
            }
            for(int k=0; k<M1.Ncol; k++)
            {
                if(SelectTerms[k]==false)  M1M2.Data[k] = 0.;
                else                       M1M2.Data[k] = M1.GetElement(k,k)*M2.GetElement(k,k);
            }
        }
        else
        {
            M1M2 = M2;
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL) 
            {
                CI.AddToLog("ERROR: GetMatMul(Select). Creating output matrix for M1 diagonal. \n");
                return UMatrix(U_ERROR);
            }
            double* pData = M1M2.Data;
            for(int j=0; j<M1M2.Nrow; j++)
            {
                if(SelectTerms[j]==false) 
                {
                    for(int i=0; i<M1M2.Ncol; i++) *pData++ = 0.;
                }
                else
                {
                    double Fact = M1.GetElement(j,j);
                    for(int i=0; i<M1M2.Ncol; i++) *pData++ *= Fact;
                }
            }
            M1M2.MT = (M1M2.Ncol==M1M2.Nrow) ? U_MAT_SQUARE : U_MAT_GENERAL;
        }
    }
    else // M1 non-diagonal
    {
        if(M2.IsDiagonalType()==true)
        {
            M1M2 = M1;
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL) 
            {
                CI.AddToLog("ERROR: GetMatMul(Select). Creating output matrix for M2 diagonal. \n");
                return UMatrix(U_ERROR);
            }
            double* pData = M1M2.Data;
            for(int i=0; i<M1M2.Nrow; i++)  // compute t_ij * M_jj
            {
                double* pDiag = M2.Data;
                for(int j=0; j<M1M2.Ncol; j++, pData++, pDiag++) 
                    if(SelectTerms[j]==false) *pData  = 0.;
                    else                      *pData *= *pDiag;
            }
            M1M2.MT = (M1M2.Ncol==M1M2.Nrow) ? U_MAT_SQUARE : U_MAT_GENERAL;
        }
        else // both non-diagonal
        {
            M1M2 = UMatrix(DNULL, M1.Nrow, M2.Ncol);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL) 
            {
                CI.AddToLog("ERROR: GetMatMul(Select). Creating output matrix for general case. \n");
                return UMatrix(U_ERROR);
            }

            double* pData = M1M2.Data;
            for(int j=0; j<M1M2.Nrow; j++)
            {
                for(int i=0; i<M1M2.Ncol; i++)
                {
                    double  rw    = 0;
                    double *pMat  = M1.Data       +j*M1.Ncol;
                    double *pM    = M2.Data+i;
                    for(int k=0; k<M1.Ncol; k++,pM+=M2.Ncol,pMat++) 
                        if(SelectTerms[k]==true) rw += *pMat * *pM;
                    *pData++ = rw;
                }
            }
            M1M2.MT = (M1M2.Ncol==M1M2.Nrow) ? U_MAT_SQUARE : U_MAT_GENERAL;
        }
    }
    return M1M2;
}
UMatrix GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2, const bool* SelectTerms)
{
    if(&M1==NULL || M1.GetError()!=U_OK ||
       &M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). NULL or erroneous argument(s). \n");
        return UMatrix(U_ERROR);
    }
    if(M1.MT==U_MAT_NULL) return UMatrix();
    if(M2.MT==U_MAT_NULL) return UMatrix();
    
    const double* pM1 = M1.Data;
    const double* pM2 = M2.Data;
    if(pM1==NULL || pM2==NULL)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Data M1 or M2 not properly set. \n");
        return UMatrix(U_ERROR);
    }
    if(Transp1==false && Transp2==false) return GetMatMul(M1, M2, SelectTerms);

    if(Transp1==false && Transp2==true && M1.Ncol!=M2.Ncol)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Incompatible M1.Ncol=%d and M2.Ncol=%d .\n", M1.Ncol, M2.Ncol);
        return UMatrix(U_ERROR);
    }
    if(Transp1==true  && Transp2==false && M1.Nrow != M2.Nrow)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Incompatible M1.Nrow=%d and M2.Nrow=%d .\n", M1.Nrow, M2.Nrow);
        return UMatrix(U_ERROR);
    }
    if(Transp1==true  && Transp2==true && M1.Nrow != M2.Ncol)
    {
        CI.AddToLog("ERROR: GetMatMul(Select). Incompatible M1.Nrow=%d and M2.Ncol=%d .\n", M1.Nrow, M2.Ncol);
        return UMatrix(U_ERROR);
    }

    if(SelectTerms==NULL) return GetMatMul(M1, Transp1, M2, Transp2);
    int First = UMatrix::GetFirstSelect(SelectTerms, M1.Ncol);
    if(First<0)  return UMatrix(); // Empty matrix

    UMatrix M1M2;
    if(M1.IsDiagonalType()==true)
    {
        if(Transp2==false || M2.IsDiagonalType()==true)
        {
            return GetMatMul(M1, M2, SelectTerms);
        }
        else
        {
            M1M2 = UMatrix(DNULL, M1.Nrow, M2.Nrow);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL) 
            {
                CI.AddToLog("ERROR: GetMatMul(Select). Creating output matrix for M1 diagonal. \n");
                return UMatrix(U_ERROR);
            }
            double* pData = M1M2.Data;
            for(int j=0; j<M1.Nrow; j++)
            {
                if(NOT(SelectTerms[j])) {pData +=M2.Nrow; continue;}
                double        Diag  =  M1.GetElement(j,j);
                const double* pMat  =  pM2+j;
                for(int i=0; i<M2.Nrow; i++,pMat+=M2.Ncol) *pData++ = Diag * (*pMat);
            }
        }
    }
    else // M1 non-diagonal
    {
        if(Transp1==false || M2.IsDiagonalType()==true)
        {
            return GetMatMul(M1, M2, SelectTerms);
        }
        else if(Transp1==true && Transp2==true)  // No diagonal cases anymore
        {
            M1M2 = UMatrix(DNULL, M1.Ncol, M2.Nrow);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL)
            {
                CI.AddToLog("ERROR: GetMatMul(). Creating output matrix M1M2.\n");
                return UMatrix(U_ERROR);
            }
            double* pM1M2 = M1M2.Data;
            for(int i=0; i<M1.Ncol; i++)
            {   
                for(int j=0; j<M2.Nrow; j++)
                {
                    double        rw   = 0;
                    const double* pMat = pM1  + i;
                    const double* pA   = pM2  + j*M2.Ncol;
                    for(int k=0; k<M1.Nrow; k++, pMat+=M1.Ncol, pA++) if(SelectTerms[k]) rw += (*pMat) *  (*pA);
                    *pM1M2++ = rw;            
                }
            }
        }
        else if(Transp1==true && Transp2==false) 
        {
            M1M2 = UMatrix(DNULL, M1.Ncol, M2.Ncol);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL)
            {
                CI.AddToLog("ERROR: GetMatMul(). Creating output matrix M1TM2.\n");
                return UMatrix(U_ERROR);
            }
            double* pM1M2 = M1M2.Data;
            for(int i=0; i<M1.Ncol; i++)
            {   
                for(int j=0; j<M2.Ncol; j++)
                {
                    double        rw   = 0;
                    const double* pMat = pM1  + i;
                    const double* pA   = pM2  + j;
                    for(int k=0; k<M1.Nrow; k++, pMat+=M1.Ncol, pA+=M2.Ncol) if(SelectTerms[k]) rw += (*pMat) *  (*pA);
                    *pM1M2++ = rw;
                }
            }
        }
        else if(Transp1==false && Transp2==true)
        {
            M1M2 = UMatrix(DNULL, M1.Nrow, M2.Nrow);
            if(M1M2.GetError()!=U_OK || M1M2.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrix::GetMatMul(). Creating output matrix M1M2.\n");
                return UMatrix(U_ERROR);
            }
            double* pM1M2 = M1M2.Data;
            for(int j=0; j<M1.Nrow; j++)
            {
                for(int i=0; i<M2.Nrow; i++)
                {   
                    double        rw   = 0;
                    const double* pA   = pM1  + j*M1.Ncol;
                    const double* pMat = pM2  + i*M2.Ncol;
                    for(int k=0; k<M2.Ncol; k++, pA++, pMat++) if(SelectTerms[k]) rw += (*pA) * (*pMat);
                    *pM1M2++ = rw;            
                }
            }
        }
    }
    M1M2.MT = (M1M2.Ncol==M1M2.Nrow) ? U_MAT_SQUARE : U_MAT_GENERAL;
    return M1M2;
}

double  GetRowProduct(const UMatrix& M1, int row1, const UMatrix& M2, int row2)
{
    if(&M1==NULL || M1.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetRowProduct(). M1 argument NULL or erroneous.\n");
        return 0.;
    }
    if(row1<0||row1>=M1.Nrow)
    {
        CI.AddToLog("ERROR: GetRowProduct(). Argument out ofrange: row1=%d, M1.Nrow=%d .\n", row1, M1.Nrow);
        return 0.;
    }
    if(&M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetRowProduct(). M2 argument NULL or erroneous.\n");
        return 0.;
    }
    if(row2<0||row2>=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetRowProduct(). Argument out ofrange: row2=%d, M2.Nrow=%d .\n", row2, M2.Nrow);
        return 0.;
    }
    if(M1.Ncol!=M2.Ncol)
    {
        CI.AddToLog("ERROR: GetRowProduct(). Argument out ofrange: M1.Ncol=%d, M2.Ncol=%d .\n", M1.Ncol, M2.Ncol);
        return 0.;
    }
    if(M1.IsDiagonalType()==true || M2.IsDiagonalType()==true)
        return M1.GetElement(row1,row1) * M2.GetElement(row2,row2);

    const double* p1=M1.Data;
    const double* p2=M2.Data;
    if(p1==NULL || p2==NULL)
    {
        if(M1.MT!=U_MAT_NULL && M1.MT!=U_MAT_NULL) 
            CI.AddToLog("ERROR: GetRowProduct(). Data array of one of matrices is NULL.\n");
        return 0.;
    }
    double sum  = 0.;
    int    Ncol = M1.Ncol;
    p1         += Ncol*row1;
    p2         += Ncol*row2;
    for(int k=0; k<Ncol; k++) sum += *p1++ * *p2++;
    return sum;
}
double  GetColProduct(const UMatrix& M1, int col1, const UMatrix& M2, int col2)
{
    if(&M1==NULL || M1.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetColProduct(). M1 argument NULL or erroneous.\n");
        return 0.;
    }
    if(col1<0||col1>=M1.Ncol)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: col1=%d, M1.Ncol=%d .\n", col1, M1.Ncol);
        return 0.;
    }
    if(&M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetColProduct(). M2 argument NULL or erroneous.\n");
        return 0.;
    }
    if(col2<0||col2>=M2.Ncol)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: col2=%d, M2.Ncol=%d .\n", col2, M2.Ncol);
        return 0.;
    }
    if(M1.Nrow!=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: M1.Nrow=%d, M2.Nrow=%d .\n", M1.Nrow, M2.Nrow);
        return 0.;
    }
    if(M1.IsDiagonalType()==true) return M1.GetElement(col1,col1) * M2.GetElement(col1,col2);
    if(M2.IsDiagonalType()==true) return M1.GetElement(col2,col1) * M2.GetElement(col2,col2);

    const double* p1=M1.Data;
    const double* p2=M2.Data;
    if(p1==NULL || p2==NULL)
    {
        if(M1.MT!=U_MAT_NULL && M2.MT!=U_MAT_NULL) 
            CI.AddToLog("ERROR: GetColProduct(). Data array of one of matrices is NULL.\n");
        return 0.;
    }
    double sum   = 0.;
    int    Ncol1 = M1.Ncol;
    int    Ncol2 = M2.Ncol;
    p1          += col1;
    p2          += col2;
    for(int k=0; k<M1.Nrow; k++, p1+=Ncol1, p2+=Ncol2) sum += *p1 * *p2;
    return sum;
}
double GetColProduct(const UMatrix& M1, int col1, const bool* SelectRow, const UMatrix& M2, int col2)
{
    if(&M1==NULL || M1.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetColProduct(). M1 argument NULL or erroneous.\n");
        return 0.;
    }
    if(col1<0||col1>=M1.Ncol)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: col1=%d, M1.Ncol=%d .\n", col1, M1.Ncol);
        return 0.;
    }
    if(&M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetColProduct(). M2 argument NULL or erroneous.\n");
        return 0.;
    }
    if(col2<0||col2>=M2.Ncol)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: col2=%d, M2.Ncol=%d .\n", col2, M2.Ncol);
        return 0.;
    }
    if(M1.Nrow!=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetColProduct(). Argument out ofrange: M1.Nrow=%d, M2.Nrow=%d .\n", M1.Nrow, M2.Nrow);
        return 0.;
    }
    if(SelectRow==NULL) return GetColProduct(M1, col1, M2, col2);

    if(M1.IsDiagonalType()==true) return SelectRow[col1]==false ? 0.: M1.GetElement(col1,col1) * M2.GetElement(col1,col2);
    if(M2.IsDiagonalType()==true) return SelectRow[col2]==false ? 0.: M1.GetElement(col2,col1) * M2.GetElement(col2,col2);

    const double* p1=M1.Data;
    const double* p2=M2.Data;
    if(p1==NULL || p2==NULL)
    {
        if(M1.MT!=U_MAT_NULL && M2.MT!=U_MAT_NULL) 
            CI.AddToLog("ERROR: GetColProduct(). Data array of one of matrices is NULL.\n");
        return 0.;
    }
    double sum   = 0.;
    int    Ncol1 = M1.Ncol;
    int    Ncol2 = M2.Ncol;
    p1          += col1;
    p2          += col2;
    for(int k=0; k<M1.Nrow; k++, p1+=Ncol1, p2+=Ncol2) if(SelectRow[k]) sum += *p1 * *p2;
    return sum;
}

double GetTraceM1M2T(const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetTraceM1M2T(). M1 argument NULL or erroneous.\n");
        return 0.;
    }
    if(&M2==NULL || M2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetTraceM1M2T(). M2 argument NULL or erroneous.\n");
        return 0.;
    }
    if(M1.Nrow!=M2.Nrow || M1.Ncol!=M2.Ncol)
    {
        CI.AddToLog("ERROR: GetTraceM1M2T(). Matrix sizes don`t match M1.Nrow=%d, M2.Nrow=%d, M1.Ncol=%d, M2.Ncol=%d .\n", M1.Nrow, M2.Nrow, M1.Ncol, M2.Ncol);
        return 0.;
    }

    double Trace = 0;
    if(M1.IsDiagonalType()==true || M2.IsDiagonalType()==true)
    {
        for(int ir=0; ir<M1.Nrow; ir++) Trace += GetRowProduct(M1, ir, M2, ir);
    }
    else
    {
        const double* p1=M1.Data;
        const double* p2=M2.Data;
        if(p1==NULL || p2==NULL)
        {
            if(M1.MT!=U_MAT_NULL && M1.MT!=U_MAT_NULL) 
                CI.AddToLog("ERROR: GetTraceM1M2T(). Data array of one of matrices is NULL.\n");
            return 0.;
        }
        int NRC = M1.Nrow * M1.Ncol;
        for(int irc=0; irc<NRC; irc++) Trace += *p1++ * *p2++;
    }
    return Trace;
}

double GetRDM(const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError() || M1.Data==NULL || M1.IsDiagonalType() ||
       &M2==NULL || M2.GetError() || M2.Data==NULL || M2.IsDiagonalType())
    {
        CI.AddToLog("ERROR: GetRDM(). One or both arguments NULL or erroneous, or DiagonalType. \n");
        return -1.;
    }
    if( M1.Ncol != M2.Ncol || M1.Nrow!=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetRDM(). Matrices have different sizes (%d,%d) and (%d,%d). \n", M1.Nrow,M1.Ncol,M2.Nrow,M2.Ncol);
        return -1.;
    }
    int NPoints = M1.Nrow*M1.Ncol;

    double D1 = 0;  for(int i=0; i<NPoints; i++) D1 += M1.Data[i]*M1.Data[i]; 
    double D2 = 0;  for(int i=0; i<NPoints; i++) D2 += M2.Data[i]*M2.Data[i]; 

    if(D1<=0 || D2<=0)
    {
        CI.AddToLog("ERROR: GetRDM(). Zero amplitude(s). \n");
        return -1.;
    }

    D1 = sqrt(D1);
    D2 = sqrt(D2);
    double D = 0;
    for(int i=0; i<NPoints; i++) 
    {
        double T = M1.Data[i]/D1 - M2.Data[i]/D2;
        D += T*T;
    }
    return sqrt(D);
}
double GetADM(const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError() || M1.Data==NULL || M1.IsDiagonalType() ||
       &M2==NULL || M2.GetError() || M2.Data==NULL || M2.IsDiagonalType())
    {
        CI.AddToLog("ERROR: GetADM(). One or both arguments NULL or erroneous, or DiagonalType. \n");
        return -1.;
    }
    if( M1.Ncol != M2.Ncol || M1.Nrow!=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetADM(). Matrices have different sizes (%d,%d) and (%d,%d). \n", M1.Nrow,M1.Ncol,M2.Nrow,M2.Ncol);
        return -1.;
    }
    int NPoints = M1.Nrow*M1.Ncol;

    double D = 0;
    for(int i=0; i<NPoints; i++) D += SQR(M1.Data[i]-M2.Data[i]);
    return NPoints>0 ? sqrt(D/NPoints) : -1.;
}
UMatrix GetRelErrorMat(const UMatrix& M1, const UMatrix& M2)
{
    if(&M1==NULL || M1.GetError() || M1.Data==NULL || M1.IsDiagonalType() ||
       &M2==NULL || M2.GetError() || M2.Data==NULL || M2.IsDiagonalType())
    {
        CI.AddToLog("ERROR: GetRelErrorMat(). One or both arguments NULL or erroneous, or DiagonalType. \n");
        return UMatrix(U_ERROR);
    }
    if( M1.Ncol != M2.Ncol || M1.Nrow!=M2.Nrow)
    {
        CI.AddToLog("ERROR: GetRelErrorMat(). Matrices have different sizes (%d,%d) and (%d,%d). \n", M1.Nrow,M1.Ncol,M2.Nrow,M2.Ncol);
        return UMatrix(U_ERROR);
    }

    UMatrix RelMat  = M1;
    int     NPoints = M1.Nrow*M1.Ncol;
    if(RelMat.GetError()!=U_OK||RelMat.Data==NULL||NPoints<=0)
    {
        CI.AddToLog("ERROR: GetRelErrorMat(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }

    for(int i=0; i<NPoints; i++)
        RelMat.Data[i] = (M2.Data[i]==0.) ? 0. : 1. -M1.Data[i]/M2.Data[i];

    return RelMat;
}

UMatrix GetNormalizedDistanceMatrix(const double* Xmat, int NrowX, int NcolX)
{
    if(Xmat==NULL)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Erroneous (NULL?) input parameter. \n");
        return UMatrix(U_ERROR);
    }
    if(NrowX<=0||NcolX<=0)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Erroneous input parameter(s): NrowX = %d, NcolX = %d \n", NrowX, NcolX);
        return UMatrix(U_ERROR);
    }
    UMatrix   DMat(DNULL, NrowX, NrowX);
    if(DMat.GetError() || DMat.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Creating D-matrix. \n");
        return UMatrix(U_ERROR);
    }
    double MaxE = 0;
    for(uint64_t k=0; k<NrowX*NcolX; k++) MaxE = MAX(MaxE, fabs(Xmat[k]));
    if(MaxE<=0.)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Max Elem is zero. \n");
        return UMatrix(U_ERROR);
    }

    for(uint64_t i=0; i<NrowX; i++)
        for(uint64_t j=i+1; j<NrowX; j++)
        {
            const double* pMat1 = Xmat+i*NcolX;
            const double* pMat2 = Xmat+j*NcolX;
            double        V     = 0.;
            for(int k=0; k<NcolX; k++, pMat1++, pMat2++) V += SQR(*pMat1 - *pMat2);

            DMat.Data[i*NrowX+j] = DMat.Data[j*NrowX+i] = V;
        }

    DMat   /= (MaxE*MaxE);
    DMat.MT = U_MAT_SYMMETRIC;
    return DMat;
}
UMatrix GetNormalizedDistanceMatrix(const float* Xmat, int NrowX, int NcolX)
{
    if(Xmat==NULL)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Erroneous (NULL?) input parameter. \n");
        return UMatrix(U_ERROR);
    }
    if(NrowX<=0||NcolX<=0)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Erroneous input parameter(s): NrowX = %d, NcolX = %d \n", NrowX, NcolX);
        return UMatrix(U_ERROR);
    }
    UMatrix   DMat(DNULL, NrowX, NrowX);
    if(DMat.GetError() || DMat.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Creating D-matrix. \n");
        return UMatrix(U_ERROR);
    }
    double MaxE = 0;
    for(uint64_t k=0; k<NrowX*NcolX; k++) MaxE = MAX(MaxE, fabs(Xmat[k]));
    if(MaxE<=0.)
    {
        CI.AddToLog("ERROR: GetNormalizedDistanceMatrix(). Max Elem is zero. \n");
        return UMatrix(U_ERROR);
    }

    for(uint64_t i=0; i<NrowX; i++)
        for(uint64_t j=i+1; j<NrowX; j++)
        {
            const float* pMat1 = Xmat+i*NcolX;
            const float* pMat2 = Xmat+j*NcolX;
            double       V     = 0.;
            for(int k=0; k<NcolX; k++, pMat1++, pMat2++) V += SQR(*pMat1 - *pMat2);

            DMat.Data[i*NrowX+j] = DMat.Data[j*NrowX+i] = V;
        }

    DMat   /= (MaxE*MaxE);
    DMat.MT = U_MAT_SYMMETRIC;
    return DMat;
}

