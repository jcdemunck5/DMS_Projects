#ifndef _MATRIX_INCLUDED
#define _MATRIX_INCLUDED

#include "String.h"
#include "BitMap.h"

enum MatrixType {U_MAT_NULL,      
                 U_MAT_IDENTITY,   
                 U_MAT_IDENTCONST, 
                 U_MAT_DIAGONAL,   
                 U_MAT_SYMMETRIC,  
                 U_MAT_SQUARE,     
                 U_MAT_GENERAL,
                 U_MAT_UNKNOWN};   

PMT_CCP DLL_IO GetMatrixTypeText(MatrixType MT);
MatrixType GetMatrixType(int itype);


class UFileName;
class UField;
class UMatrixSparse;
class DLL_IO UMatrix 
{
    friend class   UMatrixSquare;
    friend class   UMatrixSymmetric;
    friend class   UMultiDimScale;
    friend class   UMatrixTwoKP;
    friend class   UMatrixSparse;
    friend class   UMultiChan;
    friend class   UCovariance;
    friend class   ULUdecompose;
    friend class   UPreConBiConGrad;
    friend class   UInterpolateCircle;

    friend class   USurface;
    friend class   UManifold;
    friend class   UEMfield;
    friend class   UBemField;
    friend class   UBemMatrix3;
    friend class   UProjector;
    friend class   UEventArray;

    friend class   UTSNE;

    friend UMatrix DLL_IO operator*(double f, const UMatrix& M);
    friend UMatrix DLL_IO GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2);
    friend UMatrix DLL_IO GetMatMul(const UMatrix& M1, const UMatrix& M2, const bool* SelectTerms);
    friend UMatrix DLL_IO GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2, const bool* SelectTerms);
    friend double  DLL_IO GetRowProduct(const UMatrix& M1, int row1, const UMatrix& M2, int row2);
    friend double  DLL_IO GetColProduct(const UMatrix& M1, int col1, const UMatrix& M2, int col2);
    friend double  DLL_IO GetColProduct(const UMatrix& M1, int col1, const bool* SelectRow, const UMatrix& M2, int col2);
    friend double  DLL_IO GetTraceM1M2T(const UMatrix& M1, const UMatrix& M2);
    friend double  DLL_IO GetRDM(const UMatrix& M1, const UMatrix& M2);
    friend double  DLL_IO GetADM(const UMatrix& M1, const UMatrix& M2);
    friend UMatrix DLL_IO GetRelErrorMat(const UMatrix& M1, const UMatrix& M2);
    friend UMatrix DLL_IO GetNormalizedDistanceMatrix(const double* Xmat, int NrowX, int NcolX);
    friend UMatrix DLL_IO GetNormalizedDistanceMatrix(const float* Xmat, int NrowX, int NcolX);

public:
    UMatrix();                                                                                  // default constructor -> empty matrix
    UMatrix(ErrorType E);                                                                       // constructor used to return an empty, Erroneous matrix
    UMatrix(FILE* fpIn);                                                                        // read from opened binary stream
    UMatrix(const UMatrix& A);                                                                  // Copy constructor 
    UMatrix(const UMatrix& A, const bool* SelectRowCol);                                        // Selection constructor (square matrices)
    UMatrix(const double* Matrix, int nR, int nC, const bool* SelectRowCol);                    // Selection constructor (square matrices)
    UMatrix(const UMatrix& A, const bool* SelectRow, const bool* SelectCol);                    // Selection constructor 
    UMatrix(const double* Matrix, int nR, int nC, const bool* SelectRow, const bool* SelectCol);// Selection constructor 
    UMatrix(double Elem, int nR, int nC);                                                       // Constant matrix with all elements equal to Elem
    UMatrix(int nDim);                                                                          // identity constructor
    UMatrix(double Diag, int nDim);                                                             // constant diagonal constructor
    UMatrix(double Diag0, int ndim0, double Diag1, int ndim1);                                  // Diagonal constructor with two vaules
    UMatrix(double Diag0, int ndim0, double Diag1, int ndim1, double Diag2, int ndim2);         // Diagonal constructor with three vaules
    UMatrix(const double* Diag, int nDim);                                                      // general diagonal matrix constructor
    UMatrix(WindowType Win, int nDim);                                                          // WindowType diagonal matrix constructor
    UMatrix(const float* Matrix, int nR, int nC);                                               // general constructor
    UMatrix(const double* Matrix, int nR, int nC);                                              // general constructor
    UMatrix(const double* const* Matrix, int nR, int nC);                                       // general constructor
    UMatrix(const double* Mat1, const double* Mat2, int nR1, int nC1, int nR2, int nC2, bool ConcatCols=false); // constructor merging rows or collums of Mat1 and Mat2 
    UMatrix(const UMatrix& A, const UMatrix& B);                                                // Kronecker Product constructor
    UMatrix(const UFileName& F);                                                                // Text file constructor
    UMatrix(const UField* const* const Farray, int Nfield, bool Collumns, const bool* Select);  // row or collums take from 1D UField objects
    UMatrix(const UVector3& V);                                                                 // 3 x 1 collumn vector
    UMatrix(const UVector3& V1, const UVector3& V2);                                            // 6 x 1 collumn vector
    UMatrix(const UMatrixSparse& M);                                                            // sparse matrix

    virtual ~UMatrix();

    UMatrix& operator= (const UMatrix& M);
    UMatrix  operator- (const UMatrix& M) const; 
    UMatrix& operator-=(const UMatrix& M); 
    UMatrix  operator+ (const UMatrix& M) const; 
    UMatrix& operator+=(const UMatrix& M); 
    UMatrix  operator* (const UMatrix& M) const; 
    UMatrix  operator^ (const UMatrix& M) const; // Hadamard product
    UMatrix& operator*=(const UMatrix& M); 
    UMatrix& operator^=(const UMatrix& M);       // Hadamard product
    UMatrix  operator* (double a) const;
    UMatrix  operator/ (double a) const;
    UMatrix& operator+=(double a);
    UMatrix& operator-=(double a);
    UMatrix& operator*=(double a);
    UMatrix& operator/=(double a);
    UMatrix  operator+ (double a) const;
    UMatrix  operator-(void)  const;
    operator           const double*()          const {if(this) return Data;  return NULL;}

    ErrorType          GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&     GetProperties(UString Comment) const;
    UBitMap            GetBitMap(bool ScaleSymmetric) const;
    ErrorType          Print(bool PrintToLog);
    virtual ErrorType  InvertSqrt();

    bool               IsEmpty(void)            const {if(this) return (Ncol<=0 || Nrow<=0); return true;}
    MatrixType         GetMatrixType(void)      const {if(this) return MT;    return U_MAT_NULL;}
    int                GetNrow(void)            const {if(this) return Nrow;  return 0;}
    int                GetNcol(void)            const {if(this) return Ncol;  return 0;}
    const double*      GetMatrixArray(void)     const {if(this) return Data;  return NULL;}

    virtual ErrorType  SetData(double Value);
    virtual ErrorType  SetData(int irow, int icol, const UMatrix& M);
    virtual ErrorType  Shrink(double Lamda, int* Nzero=NULL);
    virtual ErrorType  ShrinkRows(double Lamda, int* Nzero=NULL);
    virtual ErrorType  SetUnitVector(int iunit, int Ndim, bool ColVect);
    virtual ErrorType  SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect);
    virtual ErrorType  SetPolynomials(int MinDeg, int MaxDeg, bool ColVect);
    virtual ErrorType  SetElement(int irow, int icol, double Value);
    virtual ErrorType  AddElement(int irow, int icol, double Value);
    virtual ErrorType  SetRow(int irow, double Value);
    virtual ErrorType  SetRow(int irow, const UMatrix& Row);
    virtual ErrorType  SetCol(int icol, double Value);
    virtual ErrorType  SetCol(int icol, const UMatrix& Col);
    virtual ErrorType  CopyCol(int icol, int DestBegin, int DestEnd);
    virtual ErrorType  SetDataRandom(double Amp=1., int seed=0);
    virtual ErrorType  SetDataGaussian(double Amp=1., int seed=0);
    virtual ErrorType  ApplyFunction(double (f) (double));
    virtual ErrorType  ApplySquareRoot();
    virtual ErrorType  ApplyInverse();
    virtual ErrorType  ApplyAbs();
    virtual ErrorType  MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold=NULL);
    virtual ErrorType  MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold=NULL);
    virtual ErrorType  SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold=NULL);
    virtual ErrorType  NormalizeRows(int skiprow1=-1, int skiprow2=-1, int skiprow3=-1);
    virtual ErrorType  NormalizeCols(int skipcol1=-1, int skipcol2=-1,int skipcol3=-1);
    virtual ErrorType  DeMeanRows(int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType  DeMeanCols(int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType  SubstractCol(int icol, int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType  SubstractRow(int irow, int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType  ReverseCols(void);
    virtual ErrorType  ReverseRows(void);
    virtual ErrorType  SwapCols(int col1, int col2);
    virtual ErrorType  SwapRows(int row1, int row2);
    virtual ErrorType  InsertZeroRows(const bool* NonZeroRows, int NewNrow);
    virtual ErrorType  MergeRows(const UMatrix& M);
    virtual ErrorType  MergeCols(const UMatrix& M);
    virtual ErrorType  MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr);
    virtual ErrorType  ReshapeCols(int NewNcols);
    ErrorType          AdaptDiagonalToConstantEigenvector(void);

    UMatrix            GetTranspose(void)       const;
    virtual ErrorType  Transpose(void);
    virtual ErrorType  ForceGeneralType(void);
    virtual ErrorType  ForceSymmetricType(double RelRowError);
    double             GetElement(int i, int j) const;
    double             GetElement(int ij)       const;
    double             GetTrace(void)           const;
    double             GetFrobNorm2(void)       const;
    double             GetFrobNorm(void)        const;
    double             GetAbsNorm(void)         const;
    double             GetMixedRowNorm(void)    const;
    double             GetFrobNormDifference2(const UMatrix& M) const;
    double             GetFrobNormDifference(const UMatrix& M) const;

    double             GetSum(bool Fabs) const;
    double             GetFrobNorm2Row(int irow) const;
    double             GetFrobNormRow(int irow) const;
    double             GetRowSum(int irow) const;
    UMatrix            GetRowSum(void)     const;
    double             GetFrobNorm2Col(int icol) const;
    double             GetFrobNormCol(int icol) const;
    UMatrix            GetFrobNormRowDiag(void) const;
    UMatrix            GetFrobNormColDiag(void) const;
    UMatrixSymmetric   GetVarianceDifMat(void) const;

    double             GetColSum(int icol) const;
    UMatrix            GetColSum(void)     const;
    double             GetColMedian(int icol) const;
    double             GetRowMedian(int irow) const;
    bool               AreElementsNonNegative(void) const;

    bool*              GetSubThresholdElements(double Thresh, bool Fabs) const;
    int                GetNSubThreshholElements(double Thresh, bool Fabs) const;
    bool*              GetInRangeElements(double Tmin, double Tmax) const;
    int                GetNNonZeroElements(void) const;
    double             GetMinElem(bool Fabs) const;
    double             GetMaxElem(bool Fabs) const;
    double             GetColMin(int icol, bool Fabs, const bool* SelectRow, int* irow) const;
    double             GetRowMin(int irow, bool Fabs, const bool* SelectCol, int* icol) const;
    double             GetColMax(int icol, bool Fabs, const bool* SelectRow, int* irow) const;
    double             GetRowMax(int irow, bool Fabs, const bool* SelectCol, int* icol) const;
    double*            GetNColSubThreshold(double Threshold) const;

    UMatrix            GetVec(void) const;
    UMatrix            GetRow(int irow) const;
    UMatrix            GetCollumn(int icol) const;
    UMatrix            GetDiagonal(void) const;
    UMatrix            GetDiagonalAsColVec(void) const;
    UMatrix            GetGramSchmidtRows(void) const;
    UMatrix            GetSIGN(void) const;

    ErrorType          AddTransposed(void);
    UMatrix            GetConcatCollumns(const UMatrix& BMat) const;
    UMatrix            GetConcatRows(const UMatrix& BMat) const;
    UMatrix            GetBlock(int row, int col, int NrowBlock, int NcolBlock) const; 
    virtual ErrorType  SetBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType  AddBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType  SubtractBlock(int row, int col, const UMatrix& Block);
    UMatrix            GetRowSelection(const int* IndexR, int Nsel) const;
    ErrorType          SelectRowCol(const bool* SelectRow, const bool* SelectCol);

    UMatrix            GetL2NormSolution(const UMatrix& BVec, double RelAverAbsEigenThresh=0.) const;
    UMatrix            GetL1NormSolution(const UMatrix& Bvec) const;
    UMatrix            GetElasticNetSolution(const UMatrix& BVec, double Lam1, double Lam2) const;
    UMatrix            GetLassoSolution(const UMatrix& BVec, double Lam1) const;

    UMatrix            GetPseudoInverse(int nEigen) const;
    UMatrix            GetPseudoInverse(double Tresh) const;
    double*            GetSingValuesArray(int* NSingVal=NULL) const;
    double             GetSingValue(int n) const;

    UMatrix            GetMTM(const bool* SelectRow=NULL) const;
    UMatrix            GetMMT(const bool* SelectCol=NULL) const;
    UMatrix            GetDistMatMMT() const;
    UMatrix            GetAMAT(const UMatrix& A) const;
    double             GetVTMV(const UMatrix& Vec) const;

    UMatrix            GetOrthogonalBasis(void) const;
    UMatrix            GetProjection(bool complement) const;

    bool               IsDiagonalType(void) const;
    bool               IsSymmetricType(void) const;
    bool               IsSquareType(void) const;

    ErrorType          PrintToLog(const char* Name, int irow, int NrowPrint, int icol, int NcolPrint) const;
    ErrorType          WriteTxt(UFileName F, bool Header) const;
    ErrorType          WriteBinary(UFileName F) const;
    ErrorType          WriteBinary(FILE* fpOut) const;
protected:   
    void               SetAllMembersDefault(void);
    void               DeleteAllMembers(ErrorType E);

    double*            Data;
    int                Nrow;
    int                Ncol;
    MatrixType         MT;

private:
    static const char* HEADERBEGIN;
    static const char* HEADEREND;
    static UString     Properties;    // General property string.
    ErrorType          error;         // General error flag

    int                GetNelem(void) const;

public:
    static int         GetFirstSelect(const bool* Sel, int N);
    static int         GetNSelect(const bool* Sel, int N);
    static int*        GetSelection(const bool* Sel, int N);
};

UMatrix DLL_IO operator*(double f, const UMatrix& M);

double  DLL_IO GetFrobNormDifference2(const UMatrix& M1, const UMatrix& M2);
double  DLL_IO GetFrobNormDifference (const UMatrix& M1, const UMatrix& M2);
UMatrix DLL_IO GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2);
UMatrix DLL_IO GetMatMul(const UMatrix& M1, const UMatrix& M2, const bool* SelectTerms);
UMatrix DLL_IO GetMatMul(const UMatrix& M1, bool Transp1, const UMatrix& M2, bool Transp2, const bool* SelectTerms);
double  DLL_IO GetRowProduct(const UMatrix& M1, int row1, const UMatrix& M2, int row2);
double  DLL_IO GetColProduct(const UMatrix& M1, int col1, const UMatrix& M2, int col2);
double  DLL_IO GetColProduct(const UMatrix& M1, int col1, const bool* SelectRow, const UMatrix& M2, int col2);
double  DLL_IO GetTraceM1M2T(const UMatrix& M1, const UMatrix& M2);
double  DLL_IO GetRDM(const UMatrix& M1, const UMatrix& M2);
double  DLL_IO GetADM(const UMatrix& M1, const UMatrix& M2);
UMatrix DLL_IO GetNormalizedDistanceMatrix(const double* Xmat, int NrowX, int NcolX);
UMatrix DLL_IO GetNormalizedDistanceMatrix(const float* Xmat, int NrowX, int NcolX);

#endif //_MATRIX_INCLUDED
