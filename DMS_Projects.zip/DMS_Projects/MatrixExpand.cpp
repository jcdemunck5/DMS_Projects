/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*     Expand the matrix A of the derived class as follows:                         */
/*                                                                                  */
/*      DiagMid inv * ((DiagMid*(A + At))**matpower) + DiagOffset + MatOffset       */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    20-03-17   creation
  JdM    24-05-17   Defined default virtual functions in .cpp file to avoid many repetitive error messages.
  JdM    31-08-17   Added selection parameters to SetDiagonalOffset()
 */

#include "MatrixExpand.h"

/* Inititalize static (const) parameters. */
UString UMatrixExpand::Properties = UString();

// Some virtual functions with defaults:
double*     UMatrixExpand::GetDiagonal(int matpow, const double* DiagMid) const {return NULL;}
ErrorType   UMatrixExpand::MatVec(const double* Vec, int Nr, double* Result) const {return U_ERROR;}
ErrorType   UMatrixExpand::MatTVec(const double* Vec, int Nr, double* Result) const {return U_ERROR;}
int         UMatrixExpand::GetNrow(void) const {return 0;}
int         UMatrixExpand::GetNcol(void) const {return 0;}
bool        UMatrixExpand::IsSymmetric(double Tol) const {return false;}

void UMatrixExpand::SetAllMembersDefault(void)
{
    AddTransposed = false;
    matpower      = 1;
    MatOffset     = 0.;
    DiagOffset    = NULL;
    DiagMid       = NULL;
    DiagExpand    = NULL;
    error         = U_OK;
    Properties    = UString();
}
void UMatrixExpand::DeleteAllMembers(ErrorType E)
{
    delete[] DiagOffset;
    delete[] DiagMid;
    delete[] DiagExpand;
    SetAllMembersDefault();
    error = E;
}
UMatrixExpand::UMatrixExpand()
{
    SetAllMembersDefault();
}
UMatrixExpand::UMatrixExpand(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMatrixExpand::~UMatrixExpand()
{
    DeleteAllMembers(U_OK);
}

UMatrixExpand& UMatrixExpand::operator= (const UMatrixExpand& ME)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::operator=(). this==NULL.\n");
        static UMatrixExpand Def(U_ERROR);
        return Def;
    }
    if(&ME==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::operator=(). Invalid NULL argument.\n");
        UPreConBiConGrad::DeleteAllMembers(U_ERROR);
        UDavidson::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&ME) return *this;

    UPreConBiConGrad::operator=(ME);
    UDavidson       ::operator=(ME);

    DeleteAllMembers(U_OK);

    AddTransposed = ME.AddTransposed;
    matpower      = ME.matpower;
    MatOffset     = ME.MatOffset;
    
    int Ndim = ME.GetNrow();
    if(ME.DiagOffset && Ndim>0)
    {
        DiagOffset = new double[Ndim];
        if(DiagOffset) 
        {
            for(int n=0; n<Ndim; n++) DiagOffset[n] = ME.DiagOffset[n];
        }
        else
        {
            CI.AddToLog("ERROR: UMatrixExpand::operator=(). Memory allocation for DiagOffset, (Ndim=%d).\n", Ndim);
            UPreConBiConGrad::DeleteAllMembers(U_ERROR);
            UDavidson::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    if(ME.DiagMid && Ndim>0)
    {
        DiagMid = new double[Ndim];
        if(DiagMid) 
        {
            for(int n=0; n<Ndim; n++) DiagMid[n] = ME.DiagMid[n];
        }
        else
        {
            CI.AddToLog("ERROR: UMatrixExpand::operator=(). Memory allocation for DiagMid, (Ndim=%d).\n", Ndim);
            UPreConBiConGrad::DeleteAllMembers(U_ERROR);
            UDavidson::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    if(ME.DiagExpand && Ndim>0)
    {
        DiagExpand = new double[Ndim];
        if(DiagExpand) 
        {
            for(int n=0; n<Ndim; n++) DiagExpand[n] = ME.DiagExpand[n];
        }
        else
        {
            CI.AddToLog("ERROR: UMatrixExpand::operator=(). Memory allocation for DiagExpand, (Ndim=%d).\n", Ndim);
            UPreConBiConGrad::DeleteAllMembers(U_ERROR);
            UDavidson::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            return *this;
        }
    }
    return *this;
}
ErrorType UMatrixExpand::SetMinus(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetMinus(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    
    MatOffset     = -MatOffset;

    int Ndim = GetNrow();
    if(Ndim<=0)  return U_OK;

    if(!(matpower%2)) // matpower is even: use Mid diagonal to force negative power
    {
        if(DiagMid) for(int n=0; n<Ndim; n++) DiagMid[n] = -DiagMid[n];
        else
        {
            DiagMid = new double[Ndim];
            if(DiagMid) for(int n=0; n<Ndim; n++) DiagMid[n] = -1.;
            else
            {
                CI.AddToLog("ERROR: UMatrixExpand::SetMinus(). Memory allocation, Ndim =%d .\n", Ndim);
                return U_ERROR;
            }
        }
    }
    if(DiagOffset) for(int n=0; n<Ndim; n++) DiagOffset[n] = -DiagOffset[n];
    if(DiagExpand) for(int n=0; n<Ndim; n++) DiagExpand[n] = -DiagExpand[n];

    return U_OK;
}

const UString& UMatrixExpand::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMatrixExpand-object");
        return Properties;
    }

    Properties  = UString();
    Properties += UString(BoolAsText(AddTransposed)   , " AddTransposed = %s  \n") +
                  UString(matpower                    , " matpower      = %d  \n") +
                  UString(MatOffset                   , " MatOffset     = %f  \n") +
                  UString(BoolAsText(DiagOffset!=NULL), " DiagOffset    = %s  \n") +
                  UString(BoolAsText(DiagMid   !=NULL), " DiagMid       = %s  \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

ErrorType UMatrixExpand::SetAddTransposed(bool set)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(set && IsSquare()==false)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetAddTransposed(). Matrix not square (Nrow=%d, Ncol=%d)\n", GetNrow(), GetNcol());
        return U_ERROR;
    }
    if(set && matpower!=1)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetAddTransposed(). Cannot combine AddTransposed with matpower = %d .\n", matpower);
        return U_ERROR;
    }
    if(AddTransposed!=set) { delete[] DiagExpand; DiagExpand = NULL;}

    AddTransposed = set; 
    return U_OK;
}
ErrorType UMatrixExpand::SetPower(int ipow)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(ipow!=1 && IsSquare()==false)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetPower(). Matrix not square (Nrow=%d, Ncol=%d)\n", GetNrow(), GetNcol());
        return U_ERROR;
    }
    if(ipow<1)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetPower(). Argument out of range: ipow=%d \n", ipow);
        return U_ERROR;
    }
    if(ipow!=1 && AddTransposed)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetPower(). Cannot combine AddTransposed with matpower = %d .\n", ipow);
        return U_ERROR;
    }
    if(matpower!=ipow) { delete[] DiagExpand; DiagExpand = NULL;}
    matpower = ipow;
    return U_OK;
}
ErrorType UMatrixExpand::SetMatOffset(double Off)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MatOffset!=Off) { delete[] DiagExpand; DiagExpand = NULL;}

    MatOffset = Off;
    return U_OK;
}
ErrorType UMatrixExpand::SetDiagonalOffset(double DOff, const int* SelectedRC, int NSelect)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(IsSquare()==false)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetDiagonalOffset(). Matrix not square (Nrow=%d, Ncol=%d)\n", GetNrow(), GetNcol());
        return U_ERROR;
    }
    delete[] DiagExpand; DiagExpand = NULL;
    delete[] DiagOffset; DiagOffset = NULL;
    if(DOff==0.)        return U_OK;

    int   Ndim = GetNrow();
    DiagOffset = (Ndim<=0) ? NULL : new double[Ndim];
    if(DiagOffset==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetDiagonalOffset(). Memory allocation, Ndim = %d .\n", Ndim);
        return U_ERROR;
    }
    if(SelectedRC)
    {
        for(int n=0; n<Ndim; n++) DiagOffset[n] = 0.;
        for(int k=0; k<NSelect; k++)
        {
            int n = SelectedRC[k];
            if(n<0 || n>=Ndim)
            {
                CI.AddToLog("ERROR: UMatrixExpand::SetDiagonalOffset(). SelectedRC[%d] = %d : out of range .\n", k, n);
                delete[] DiagOffset; DiagOffset = NULL;
                return U_ERROR;
            }
            DiagOffset[n] = DOff;
        }
    }
    else
        for(int n=0; n<Ndim; n++) DiagOffset[n] = DOff;
    return U_OK;
}
ErrorType UMatrixExpand::SetDiagonalOffset(const double* DOff)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(IsSquare()==false)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetDiagonalOffset(). Matrix not square (Nrow=%d, Ncol=%d)\n", GetNrow(), GetNcol());
        return U_ERROR;
    }

    delete[] DiagExpand; DiagExpand = NULL;
    delete[] DiagOffset; DiagOffset = NULL;
    if(DOff==NULL)       return U_OK;

    int   Ndim = GetNrow();
    DiagOffset = (Ndim<=0) ? NULL : new double[Ndim];
    if(DiagOffset==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetDiagonalOffset(). Memory allocation: Ndim = %d .\n", Ndim);
        return U_ERROR;
    }
    for(int n=0; n<Ndim; n++) DiagOffset[n] = DOff[n];
    return U_OK;
}
ErrorType UMatrixExpand::SetMidDiagonal(const double* MidD)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    delete[] DiagExpand; DiagExpand = NULL;
    delete[] DiagMid;    DiagMid    = NULL;
    if(MidD==NULL)    return U_OK;

    int Nrow = GetNrow();
    DiagMid  = (Nrow<=0) ? NULL : new double[Nrow];
    if(DiagMid==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::SetMidDiagonal(). Memory allocation: Nrow = %d .\n", Nrow);
        return U_ERROR;
    }
    for(int n=0; n<Nrow; n++) DiagMid[n] = MidD[n];
    return U_OK;
}
double* UMatrixExpand::GetDiagonal(void) const
{
    if(this==NULL || error!=U_OK) return NULL;
    if(IsSquare()!=true)
    {
        CI.AddToLog("ERROR: UMatrixExpand::GetDiagonal(). Matrix not square (Nrow=%d, Ncol=%d)\n", GetNrow(), GetNcol());
        return NULL;
    }

    int     Ndim     = GetNrow();
    double* DiagCopy = (Ndim<=0) ? NULL : new double[Ndim];
    if(DiagCopy==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::GetDiagonal(). Memory allocation: Ndim = %d .\n", Ndim);
        return NULL;
    }
    if(DiagExpand) for(int n=0; n<Ndim; n++) DiagCopy[n] = DiagExpand[n];
    else           for(int n=0; n<Ndim; n++) DiagCopy[n] = 0.;

    return DiagCopy;
}
ErrorType UMatrixExpand::ComputeProduct(double* AB, const double* B, int NrowB) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ComputeProduct(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(AB==NULL || B==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ComputeProduct(). Invalid NULL argument(s).\n");
        return U_ERROR;
    }
    int Nrow = GetNrow();
    for(int ic=0; ic<NrowB; ic++)
        if(ATimes(B+ic*Nrow, AB+ic*Nrow,false)!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixExpand::ComputeProduct(). Matrix vector multiplication, ic = %d  .\n", ic);
            return U_ERROR;
        }

    return U_OK;
}
ErrorType UMatrixExpand::ApplySettings(void)
/*      PreDiag ((A + At)**matpower) + DiagOffset + MatOffset                                 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ApplySettings(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(matpower<1 || (matpower!=1 && (AddTransposed||IsSquare()==false)))
    {
        CI.AddToLog("ERROR: UMatrixExpand::ApplySettings(). Invalid configuration. \n");
        return U_ERROR;
    }

    int Nrow = GetNrow();
    delete[] DiagExpand; DiagExpand = GetDiagonal(matpower, DiagMid);
    if(DiagExpand==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ApplySettings(). Creating Diagonal, Nrow = %d  .\n", Nrow);
        return U_ERROR;
    }
    if(AddTransposed) for(int n=0; n<Nrow; n++) DiagExpand[n] *= 2;
    if(DiagOffset   ) for(int n=0; n<Nrow; n++) DiagExpand[n] += DiagOffset[n];
    if(MatOffset!=0.) for(int n=0; n<Nrow; n++) DiagExpand[n] += MatOffset;
    return U_OK;
}

ErrorType UMatrixExpand::APredSolve(const double* Bvec, double* Xvec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixExpand::APredSolve(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Bvec==NULL || Xvec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::APredSolve(). Invalid NULL pointer argument(s).\n");
        return U_ERROR;
    }
    int Nrow = GetNrow();
    if(DiagExpand==NULL || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixExpand::APredSolve(). Object not properly initialized (DiagExpand==NULL or Nrow=%d out of range).\n", Nrow);
        return U_ERROR;
    }
    for(int n=0; n<Nrow; n++) Xvec[n] = (DiagExpand[n]==0.) ? Bvec[n] : Bvec[n] / DiagExpand[n];
    return U_OK;
}
ErrorType UMatrixExpand::ATimes(const double* Bvec, double* Xvec, bool TransMat) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(matpower<1 || (matpower!=1 && (AddTransposed||IsSquare()==false)))
    {
        CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Invalid configuration. \n");
        return U_ERROR;
    }
    if(Bvec==NULL || Xvec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Invalid NULL pointer argument(s).\n");
        return U_ERROR;
    }

    int          Nrow = GetNrow();
    int          Ncol = GetNcol();
    ErrorType    E    = U_ERROR;
    if(TransMat) E    = MatTVec(Bvec, Nrow, Xvec);
    else         E    = MatVec (Bvec, Nrow, Xvec);

    if(E!=U_OK) {CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Compting MatVec().\n"); return U_ERROR;}

    if(matpower==1 && AddTransposed==false)
    {
        if(DiagOffset   ) for(int n=0; n<Nrow; n++) Xvec[n] += DiagOffset[n]*Bvec[n];
        if(MatOffset!=0.)
        {
            double  Sum = 0.; for(int n=0; n<Nrow; n++) Sum+=Bvec[n];
            Sum *= MatOffset; for(int n=0; n<Ncol; n++) Xvec[n]+=Sum;
        }
        return U_OK;
    }

    double* Buffer = new double[Nrow];
    if(Buffer==NULL)
    {
        CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Memory allocation, Nrow = %d .\n", Nrow);
        return U_ERROR;
    }

    if(AddTransposed==true)
    {
        if(NOT(TransMat)) E    = MatTVec(Bvec, Nrow, Buffer);
        else              E    = MatVec (Bvec, Nrow, Buffer);
        if(E!=U_OK) {CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Compting MatVec(), 2-nd time.\n"); delete[] Buffer; return U_ERROR;}
        for(int n=0; n<Nrow; n++) Xvec[n] += Buffer[n];
        delete[] Buffer;

        if(DiagOffset   ) for(int n=0; n<Nrow; n++) Xvec[n] += DiagOffset[n]*Bvec[n];
        if(MatOffset!=0.)
        {
            double  Sum = 0.; for(int n=0; n<Nrow; n++) Sum+=Bvec[n];
            Sum *= MatOffset; for(int n=0; n<Ncol; n++) Xvec[n]+=Sum;
        }
        return U_OK;
    }
    for(int ip=1; ip<matpower&&E==U_OK; ip++)
    {
        if(DiagMid) for(int n=0; n<Nrow; n++) Buffer[n] = DiagMid[n]*Xvec[n];
        else        for(int n=0; n<Nrow; n++) Buffer[n] =            Xvec[n];
        if(TransMat) E    = MatTVec(Buffer, Nrow, Xvec);
        else         E    = MatVec (Buffer, Nrow, Xvec);
    }
    delete[] Buffer;
    if(E!=U_OK) {CI.AddToLog("ERROR: UMatrixExpand::ATimes(). Compting MatVec(), raising to power.\n"); return U_ERROR;}

    if(DiagOffset   ) for(int n=0; n<Nrow; n++) Xvec[n] += DiagOffset[n]*Bvec[n];
    if(MatOffset!=0.)
    {
        double  Sum = 0.; for(int n=0; n<Nrow; n++) Sum+=Bvec[n];
        Sum *= MatOffset; for(int n=0; n<Ncol; n++) Xvec[n]+=Sum;
    }
    return U_OK;
}
bool UMatrixExpand::IsSquare(void) const
{
    if(this==NULL)           return false;
    if(GetNrow()!=GetNcol()) return false;
    return true;
}
