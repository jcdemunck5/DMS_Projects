#ifndef _MATRIXEXPAND_INCLUDED
#define _MATRIXEXPAND_INCLUDED

#include "PreConBiConGrad.h"
#include "Davidson.h"

class DLL_IO UMatrixExpand : public UPreConBiConGrad, public UDavidson
{

public:
    UMatrixExpand();
    UMatrixExpand(ErrorType E);
    virtual ~UMatrixExpand();

    UMatrixExpand&      operator= (const UMatrixExpand& ME);

    ErrorType           GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&      GetProperties(UString Comment) const;

    ErrorType           SetAddTransposed(bool set);
    ErrorType           SetMatOffset(double Off);
    ErrorType           SetPower(int ipow);
    ErrorType           SetDiagonalOffset(double DOff, const int* SelectedRC, int NSelect);
    ErrorType           SetDiagonalOffset(const double* DOff);
    ErrorType           SetMidDiagonal(const double* MidD);
    ErrorType           ApplySettings(void);                  // Call this function after all settings are done, in order to set the diagonal of the expanded matrix

    double*             GetExpandedDiagonal(void) const { return GetDiagonal();}
protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

    bool                GetAddTransposed(void) const {if(this) return AddTransposed; return false;}

// general virtual functions
    virtual double*     GetDiagonal(int matpow, const double* DiagMid) const;
    virtual ErrorType   MatVec(const double* Vec, int Nr, double* Result) const;
    virtual ErrorType   MatTVec(const double* Vec, int Nr, double* Result) const;
    virtual int         GetNrow(void) const;
    virtual int         GetNcol(void) const;

// virtual functions for UPreConBiConGrad and UDavidson
////    virtual ErrorType   InitMat(void);

// virtual functions for UPreConBiConGrad
    virtual ErrorType   APredSolve(const double* Bvec, double* Xvec) const;
    virtual ErrorType   ATimes(const double* Bvec, double* Xvec, bool TransMat) const;

// virtual funnctions for UDavidson
    virtual ErrorType   ComputeProduct(double* AB, const double* B, int NrowB) const;
    virtual bool        IsSymmetric(double Tol) const;

    virtual double*     GetDiagonal(void) const;       // return deep copy Diag[]
    ErrorType           SetMinus(void);
private:
    static UString      Properties;    // General property string.
    ErrorType           error;         // General error flag
    bool                AddTransposed; // if true, all operations are performed after first adding transposed version
    int                 matpower;      // Matrix raised by this power
    double              MatOffset;     // Number added to all matrix elements
    double*             DiagOffset;    // Diagonal added to "powered" matrix
    double*             DiagMid;       // Diagonal pre-multiplied to Matrix before raised to matpower
    double*             DiagExpand;    // Diagonal of expanded matrix

    bool                IsSquare(void) const;
};
#endif //_MATRIXEXPAND_INCLUDED
