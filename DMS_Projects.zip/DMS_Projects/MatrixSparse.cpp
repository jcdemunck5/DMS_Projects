/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for performing sparse matrix computations.                         */
/*     Matrix is stored in compressed collumn storage format.                    */
/*     See Numerical Recipes in C++, Third Edition, p 84.                        */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    07-12-08   Creation
  JdM    26-12-08   Added SetBlockSymmetricToeplitz()
  JdM    01-01-09   Added SetBlockToeplitz(), bug fixes SetBlockSymmetricToeplitz()
  JdM    20-01-09   Added WriteXDR()
  JdM    15-04-10   Added SetNrow() and AddCollumn() and operator=()
  JdM    16-04-10   WriteXDR(). ReverseData()
                    Added GetMatrixFull(), GetCollumnFull() and GetRowFull(), RemoveCollumn() and RemoveRow()
  JdM    17-04-10   Added matrix offset parameter to APredSolve() and ATimes()
  JdM    22-05-10   Renamed GetMatrixFull(), GetCollumnFull() and GetRowFull()
                    Added GetCollumnSparse(), GetRowSparse(), GetRowTSparse() and GetNonZeroRowIndex()
                    Bug Fix: operator[]. switching row and collumn
  JdM    31-05-10   Added ComputeProduct(), GetDiagonal() and IsSymmetric()
                    Derived UMatrixSparse from UDavidson
                    Added AddTransposed member element.
  JdM    21-11-10   Added GetSelectedRowsSparse(), RemoveSelectedCollumns() and RemoveSelectedRows()
  JdM    14-12-11   Bug fix. GetProperties(). Avoid overflow in computation of FillIn
  JdM    04-04-15   Added SetElement() and GetElement()
  JdM    17-09-15   Added another AddCollumn() and int, int constructor
  JdM    10-10-15   Added operator*()
  JdM    21-05-16   Added GetRowTimesColIgnoreOffsetPow()
                    Bug Fix: UMatrix Constructor. Last element of ColPtr was wrongly set
  JdM    21-05-16   Added matpower and MatOffset data members
  JdM    23-05-16   Added GetSparseSQR() and operator*=()
  JdM    04-06-16   Added AddElement() and GetTrace()
  JdM    06-06-16   Added UMatrix based MatVec()
  JdM    15-06-16   Added operator*=(double)
  JdM    16-06-16   GetAxIsB(). Added TranMat parameter
  JdM    28-06-16   Added GetVTMV() and GetMTM()
                    GetSparseSQR() return UMatrixSparse (instead of UMatrixSparse*) to be consistent with UMatrix object
  JdM    18-06-16   Added PrintToLog()
  JdM    28-07-16   Always return UMatrixSparse, instead of UMatrixSparse*
  JdM    16-03-16   Added GetSelectedCollumnsSparse()
  JdM    17-03-17   Added operator*() (int old version UMatrixSparse was converted back and forth to UMatrix)
  JdM    18-03-17   IsSymmetric(). Added tolerance parameter
                    Added operator-(void)
  JdM    21-03-17   Moved AddTransposed, matpower, MatOffset and associated member functions to new base class UMatrixExpand
  JdM    06-04-17   Before calling base class Solve() or SolveT(), first call UMatrixExpand::ApplySettings() to compute effects of matrix expansion on diagonal
  JdM    27-08-17   RemoveSelectedRows(). Remove rows directly, instead of calling RemoveRow() many times.
  JdM    28-08-17   Bug Fix. GetDiagonal(). Preset diagonal to zero. 
  JdM    29-08-17   Added GetRowIndex() and GetSparseMTM()
  JdM    30-08-17   Added SandwichDiagonal(), PreMultiplyDiagonal() and GetSparseATB()
  JdM    01-09-19   operator[], use GetRowIndex(), dd 29-08-17
                    Added GetDiagonalAB() and GetDiagonalATB() and used them in much more efficient GetDiagonal() (case matpow>1)
*/

#include "MatrixSparse.h"
#include "Field.h"
#include "SortSemiSort.h"

UString UMatrixSparse::Properties = UString();

void UMatrixSparse::SetAllMembersDefault(void)
{
    error         = U_OK;
    Nrow          = 0;
    Ncol          = 0;
    Nval          = 0;
    NcolAlloc     = 0;
    NvalAlloc     = 0;
    Value         = NULL;
    ColPtr        = NULL;
    RowIndex      = NULL;
    Properties    = UString();
}
void UMatrixSparse::DeleteAllMembers(ErrorType E)
{
    delete[] Value;
    delete[] ColPtr;
    delete[] RowIndex;

    SetAllMembersDefault();
    error = E;
}

UMatrixSparse::UMatrixSparse()
{
    SetAllMembersDefault();
}
UMatrixSparse::UMatrixSparse(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UMatrixSparse::UMatrixSparse(int Nr, int Nc)
{
    SetAllMembersDefault();
    if(Nr<0 || Nc<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::UMatrixSparse(). Argument(s) out of range (Nr=%d, Nc=%d).\n", Nr, Nc);
        return;
    }
    Nrow = Nr;
    Ncol = Nc;
}

UMatrixSparse::UMatrixSparse(const UMatrixSparse& ms)
{
    SetAllMembersDefault();
    *this = ms;
}
UMatrixSparse::UMatrixSparse(const UMatrix& M)
{
    SetAllMembersDefault();
    if(&M==NULL || M.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::UMatrixSparse(). Argument NULL or erroneous.\n");
        return;
    }
    Nrow = M.Nrow;
    Ncol = M.Ncol;
    switch(M.MT)
    {
    case U_MAT_NULL:       return;
    case U_MAT_IDENTITY  :
    case U_MAT_IDENTCONST:
    case U_MAT_DIAGONAL  :
        NcolAlloc = Ncol;
        NvalAlloc = Nval = Ncol;
        Value     = new double[NvalAlloc];  
        ColPtr    = new int[NcolAlloc+1];   
        RowIndex  = new int[NvalAlloc];     

        if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSparse::UMatrixSparse(). Memory allocation, Nrow = %d.\n", Nrow);
            return;
        }
        for(int j=0; j<Ncol; j++)
        {
            ColPtr[j]   = j;
            Value[j]    = (M.MT==U_MAT_DIAGONAL) ? M.Data[j] : M.Data[0];
            RowIndex[j] = j;
        }
        ColPtr[Ncol] = Ncol;
        return;

    case U_MAT_SYMMETRIC:
    case U_MAT_SQUARE   :
    case U_MAT_GENERAL  :
        NvalAlloc = Nval = M.GetNNonZeroElements();
        if(NvalAlloc<=0) return;
        NcolAlloc = Ncol;

        Value     = new double[NvalAlloc];  
        ColPtr    = new int[NcolAlloc+1];   
        RowIndex  = new int[NvalAlloc];     

        if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSparse::UMatrixSparse(). Memory allocation, NvalAlloc = %d.\n", NvalAlloc);
            return;
        }
        ColPtr[0] = 0;
        for(int j=0, knon=0; j<Ncol; j++)
        {
            for(int i=0; i<Nrow; i++)
            {
                double Dat     = M.Data[i*Ncol+j];
                if(Dat==0.) continue;
                Value[knon]    = Dat;
                RowIndex[knon] = i;
                knon++;
            }
            ColPtr[j+1] = knon;
        }
        return;
    }
    DeleteAllMembers(U_ERROR);
    CI.AddToLog("ERROR: UMatrixSparse::UMatrixSparse(). Invalid UMatrix type: %d.\n", int(M.MT));
}

UMatrixSparse::~UMatrixSparse()
{
    DeleteAllMembers(U_OK);
}

UMatrixSparse& UMatrixSparse::operator=(const UMatrixSparse& ms)
{
    if(this==NULL)
    {
        static UMatrixSparse Def; Def.error = U_ERROR;
        return Def;
    }
    if(&ms==NULL)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&ms) return *this;

    DeleteAllMembers(U_OK);

    UMatrixExpand::operator=(ms);
    if(UMatrixExpand::GetError() != U_OK)
    {
        UMatrixExpand::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::operator=(). Copying base class. \n");
        return *this;
    }
    Nrow          = ms.Nrow;
    Ncol          = ms.Ncol;
    Nval          = ms.Nval;
    NcolAlloc     = ms.Ncol+1;
    NvalAlloc     = ms.Nval;
    if(ms.Value)
    {
        Value = new double[ms.Nval];
        if(Value==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSparse::operator=(). Memory allocation (Nval=%d)  .\n", ms.Nval);
            return *this;
        }
        for(int n=0; n<ms.Nval; n++) Value[n] = ms.Value[n];
    }
    if(ms.RowIndex)
    {
        RowIndex = new int[ms.Nval];
        if(RowIndex==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSparse::operator=(). Memory allocation for RowIndex, (Nval=%d).\n", ms.Nval);
            return *this;
        }
        for(int n=0; n<ms.Nval; n++) RowIndex[n] = ms.RowIndex[n];
    }
    if(ms.ColPtr)
    {
        ColPtr = new int[ms.Ncol+1];
        if(ColPtr==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSparse::operator=(). Memory allocation for ColPtr, (Ncol=%d).\n", ms.Ncol);
            return *this;
        }
        for(int n=0; n<ms.Ncol+1; n++) ColPtr[n] = ms.ColPtr[n];
    }
    return *this;
}
double UMatrixSparse::operator[] (int index) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator[]. Object NULL or erroneous. \n");
        return 0.;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator[]. Object not properly set. \n");
        return 0.;
    }

    if(index<0 || index>=Ncol*Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator[]. index argumen (%d) out of range (Nrow=%d, Ncol=%d). \n", index, Nrow, Ncol);
        return 0.;
    }

    int   ic = index%Ncol;
    int   ir = index/Ncol;

    int    ind = GetRowIndex(ir, ic);
    return ind <0 ? 0. : Value[ind];
}
UMatrixSparse UMatrixSparse::operator*(const UMatrixSparse& MS) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if(&MS==NULL || MS.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Argument NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if(Ncol != MS.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Matrix dimensions do not match: Ncol=%d, MS.Nrow=%d .\n", Ncol, MS.Nrow);
        return UMatrixSparse(U_ERROR);
    }
    return UMatrixSparse(*this)*=MS;
}
UMatrixSparse UMatrixSparse::operator*(const double* PostDiag) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(const double*). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if(PostDiag==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(const double*). Argument NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    UMatrixSparse MD(*this);
    if(MD.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(const double*). Copying *this.\n");
        return UMatrixSparse(U_ERROR);
    }
    for(int j=0,iv=0; j<Ncol; j++)
        for(int i=ColPtr[j]; i<ColPtr[j+1]; i++,iv++)
            MD.Value[iv] *= PostDiag[j];
    return MD;
}
UMatrix UMatrixSparse::operator*(const UMatrix& M) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Object not properly set. \n");
        return UMatrix(U_ERROR);
    }

    if(&M==NULL || M.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Ncol!=M.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Collums and rows do not match: Ncol = %d, M.Nrow=%d .\n", Ncol, M.Nrow);
        return UMatrix(U_ERROR);
    }
    if(M.MT==U_MAT_NULL)     return UMatrix();
    if(M.MT==U_MAT_IDENTITY) return M;
    if(M.IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Function not yet implemented for diagonal matrices .\n");
        return UMatrix(U_ERROR);
    }

    UMatrix AM(DNULL, Nrow, M.Ncol);
    if(AM.Data==NULL || AM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*(). Creating output matrix.\n");
        return UMatrix(U_ERROR);
    }

    for(int ic=0; ic<M.Ncol; ic++)
    {
        for(int j=0; j<Ncol; j++)
            for(int i=ColPtr[j]; i<ColPtr[j+1]; i++)
                AM.Data[RowIndex[i]*M.Ncol+ic] += Value[i]*M.Data[j*M.Ncol+ic];
    }

    return AM;
}
UMatrixSparse& UMatrixSparse::operator*=(const UMatrixSparse& ms)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Object not properly set  .\n");
        return *this;
    }

    if(&ms==NULL || ms.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(ms.Value==NULL || ms.ColPtr==NULL || ms.RowIndex==NULL || ms.Ncol<=0 || ms.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Object argument not properly set  .\n");
        return *this;
    }

    if(Ncol != ms.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Matrix dimensions do not match: Ncol=%d, M.Nrow=%d .\n", Ncol, ms.Nrow);
        return *this;
    }

    UMatrixSparse* MSprod = new UMatrixSparse();
    double*        Col    = new double[ms.Nrow];
    if(MSprod==NULL || MSprod->GetError()!=U_OK || Col==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Memory allocation error, ms.Nrow = %d  .\n", ms.Nrow);
        delete[] Col;  delete MSprod;
        return *this;
    }
    MSprod->Nrow      = Nrow;
    MSprod->Ncol      = 0;
    MSprod->NcolAlloc = ms.Ncol;
    MSprod->NvalAlloc = 10*ms.Ncol;
    MSprod->RowIndex  = new int   [MSprod->NvalAlloc  ];
    MSprod->ColPtr    = new int   [MSprod->NcolAlloc+1];
    MSprod->Value     = new double[MSprod->NvalAlloc  ];
    if(MSprod->RowIndex==NULL || MSprod->ColPtr==NULL || MSprod->Value==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Memory allocation error, MSprod->NvalAlloc = %d  .\n", MSprod->NvalAlloc);
        delete[] Col;  delete MSprod;
        return *this;
    }

    for(int icol=0; icol<ms.Ncol; icol++)
    {
        for(int k=0; k<ms.Nrow; k++) Col[k] = 0.;
    
        for(int j=0; j<Ncol; j++)
        {
            for(int ij=ColPtr[j]; ij<ColPtr[j+1]; ij++)
            {
                int i = RowIndex[ij];
                for(int jicol=ms.ColPtr[icol]; jicol<ms.ColPtr[icol+1]; jicol++)
                    if(j==ms.RowIndex[jicol]) Col[i] += Value[ij] * ms.Value[jicol];
            }
        }
        if(MSprod->AddCollumn(Col, Nrow)!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Adding collumn %d  .\n", icol);
            delete[] Col;  delete MSprod;
            return *this;
        }
    }
    delete[] Col;
    *this = *MSprod;
    delete MSprod;
    return *this;
}
UMatrixSparse& UMatrixSparse::operator*=(double Factor)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator*=(). Object not properly set  .\n");
        return *this;
    }
    if(Factor==0.)
    {
        Nval = 0;
        for(int j=0; j<=Ncol; j++) ColPtr[j] = 0;
    }
    else
    {
        for(int ij=0; ij<Nval; ij++) Value[ij] *= Factor;
    }
    return *this;
}
UMatrixSparse UMatrixSparse::operator-(void)  const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator-(). Object NULL or erroneous.\n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator-(). Object not properly set  .\n");
        return *this;
    }
    UMatrixSparse MS(*this);
    if(MS.GetError()!=U_OK || MS.Value==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::operator-(). Copying *this.\n");
        return UMatrixSparse(U_ERROR);
    }
    MS.SetMinus();

    const double* pV   = Value;
    double*       pMV  = MS.Value;
    for(int n=0; n<Nval; n++) *pMV++ = -(*pV++);

    return MS;
}

UMatrixSparse UMatrixSparse::GetSparseSQR(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseSQR(). Object NULL or erroneous  .\n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseSQR(). Object not properly set (Nrow=%d, Ncol=%d)  .\n", Nrow, Ncol);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse  MS2;
    double*        Col = new double[Nrow];
    if(Col==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseSQR(). Memory allocation error, Nrow = %d  .\n", Nrow);
        delete[] Col;
        return UMatrixSparse(U_ERROR);
    }
    MS2.Nrow      = Nrow;
    MS2.Ncol      = 0;
    MS2.NcolAlloc = Ncol;
    MS2.NvalAlloc = 10*Ncol;
    MS2.RowIndex  = new int   [MS2.NvalAlloc  ];
    MS2.ColPtr    = new int   [MS2.NcolAlloc+1];
    MS2.Value     = new double[MS2.NvalAlloc  ];
    if(MS2.RowIndex==NULL || MS2.ColPtr==NULL || MS2.Value==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseSQR(). Memory allocation error, MS2.NvalAlloc = %d  .\n", MS2.NvalAlloc);
        delete[] Col;
        return UMatrixSparse(U_ERROR);
    }

    for(int icol=0; icol<Ncol; icol++)
    {
        for(int k=0; k<Nrow; k++) Col[k] = 0.;
    
        for(int j=0; j<Ncol; j++)
        {
            for(int ij=ColPtr[j]; ij<ColPtr[j+1]; ij++)
            {
                int i = RowIndex[ij];
                for(int jicol=ColPtr[icol]; jicol<ColPtr[icol+1]; jicol++)
                    if(j==RowIndex[jicol]) Col[i] += Value[ij] * Value[jicol];
            }
        }
        if(MS2.AddCollumn(Col, Nrow)!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixSparse::GetSparseSQR(). Adding collumn %d  .\n", icol);
            delete[] Col;
            return UMatrixSparse(U_ERROR);
        }
    }
    return MS2;
}
UMatrixSparse UMatrixSparse::GetSparseMTM(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseMTM(). Object NULL or erroneous  .\n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseMTM(). Object not properly set (Nrow=%d, Ncol=%d)  .\n", Nrow, Ncol);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse  MMT = GetSparseATB(*this, *this);
    if(MMT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseMTM(). Creating output matrix.\n");
        return UMatrixSparse(U_ERROR);
    }
    return MMT;
}
double UMatrixSparse::GetVTMV(const UMatrix& Vec) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetVTMV(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(&Vec==NULL || Vec.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetVTMV(). Argument NULL or erroneous. \n");
        return 0.;
    }
    if(Ncol!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetVTMV(). Matrix not square. \n");
        return 0.;
    }
    if(Vec.GetNrow()!=Ncol || Vec.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetVTMV(). Argument nor a column vector, or number of rows do not match (Vec.Nrow=%d, Vec.Ncol=%d). \n",Vec.Nrow, Vec.Ncol);
        return 0.;
    }

    if(Vec.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrix::GetVTMV(). Matrix argument data is NULL.\n");
        return 0.;
    }   

    double Sum = 0;
    for(int ic=0; ic<Ncol; ic++)
    {
        double SumC = 0;
        for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++) SumC += Value[j]*Vec.Data[RowIndex[j]];
        if(ColPtr[ic]<ColPtr[ic+1]) Sum += SumC*Vec.Data[ic];
    }
    return Sum;
}

double UMatrixSparse::GetElement(int ir, int ic) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetElement(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetElement(). Object not properly set. \n");
        return 0.;
    }
    if(ir<0 || ir>=Nrow || ic<0 || ic>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetElement(). Indices out of range (%d,%d), but Nrow(=%d) != Ncol (=%d)   .\n", ir, ic, Nrow, Ncol);
        return 0.;
    }

    for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++) if(RowIndex[j]==ir) return Value[j];

    return 0.;
}
ErrorType UMatrixSparse::SetElement(int ir, int ic, double Val)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetElement(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetElement(). Object not properly set. \n");
        return U_ERROR;
    }
    if(ir<0 || ir>=Nrow || ic<0 || ic>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetElement(). Indices out of range (%d,%d), but Nrow(=%d) != Ncol (=%d)   .\n", ir, ic, Nrow, Ncol);
        return U_ERROR;
    }

    int jIndex = -1;
    for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++) if(RowIndex[j]==ir) {jIndex =j; break;}
    if(jIndex<0)
    {
        if(Val==0.) return U_OK;
        CI.AddToLog("ERROR: UMatrixSparse::SetElement(). Original matrix element (%d, %d) is zero. Function is not implemented for this case .\n", ir, ic);
        return U_ERROR;
    }
    Value[jIndex] = Val;
    return U_OK;
}
ErrorType UMatrixSparse::AddElement(int ir, int ic, double Val)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddElement(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddElement(). Object not properly set. \n");
        return U_ERROR;
    }
    if(ir<0 || ir>=Nrow || ic<0 || ic>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddElement(). Indices out of range (%d,%d), but Nrow(=%d) != Ncol (=%d)   .\n", ir, ic, Nrow, Ncol);
        return U_ERROR;
    }
    if(Val==0.) return U_OK;

    int jIndex = -1;
    for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++) if(RowIndex[j]==ir) {jIndex =j; break;}
    if(jIndex<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddElement(). Original matrix element (%d, %d) is zero. Function is not implemented for this case .\n", ir, ic);
        return U_ERROR;
    }
    Value[jIndex] += Val;
    return U_OK;
}

int UMatrixSparse::GetNonZeroRowIndex(int icol, int iNZval) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetNonZeroRowIndex(). Object NULL or erroneous. \n");
        return -1;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetNonZeroRowIndex(). Object not properly set. \n");
        return -1;
    }

    if(icol<0 || icol>=Ncol || iNZval<0 || ColPtr[icol]+iNZval>=ColPtr[icol+1])
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetNonZeroRowIndex(). icol (=%d) or iNZval (=%d) out of range. \n", icol, iNZval);
        return -1;
    }
    return RowIndex[ColPtr[icol]+iNZval];
}

const UString& UMatrixSparse::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMatrixSparse-object");
        return Properties;
    }
    double FillIn = 0;
    if(Ncol>0 && Nrow>0) FillIn = double(Nval)/(double(Ncol)*double(Nrow));

    Properties  = UString();
    Properties += UString(Ncol    , " Ncol          = %d     \n") +
                  UString(Nrow    , " Nrow          = %d     \n") +
                  UString(Nval    , " Nval          = %d     \n") +
                  UString(Nval    , " FillIn        = %f     \n") +
                  UString(" MatrixExpand:   \n") +
                  UMatrixExpand::GetProperties("   ");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

double UMatrixSparse::GetTrace(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetTrace(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetTrace(). Nrow(=%d) != Ncol (=%d)   .\n", Nrow, Ncol);
        return 0.;
    }
    
    double Trace = 0.;
    for(int ic=0; ic<Ncol; ic++)
        for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++)
        {
            if(RowIndex[j]<ic) continue;
            Trace += Value[j];
            break;
        }

    return Trace;
}

UMatrix UMatrixSparse::GetDiagonalAsMatrix(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalAsMatrix(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalAsMatrix(). Number of rows (%d) and collumns (%d) not identical .\n", Nrow, Ncol);
        return UMatrix(U_ERROR);
    }

    UMatrix M;
    M.error = U_OK;
    M.Nrow  = Nrow;
    M.Ncol  = Ncol;
    M.MT    = U_MAT_DIAGONAL;
    M.Data  = GetDiagonal(1,NULL);
    if(M.Data==NULL) return UMatrix(U_ERROR);

    return M;
}
double* UMatrixSparse::GetDiagonal(int matpow, const double* DiagMid) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonal(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(matpow<1)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonal(). Parameter out of range, matpow = %d  . \n", matpow);
        return NULL;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonal(). Number of rows (%d) and collumns (%d) not identical .\n", Nrow, Ncol);
        return NULL;
    }
    double* Diag = NULL;
    if(matpow==1)
    {
        Diag = new double[Nrow];
        if(Diag)
        {
            for(int k=0; k<Nrow; k++) Diag[k] = 0.;
            for(int ic=0; ic<Ncol; ic++)
            {
                int ind = GetRowIndex(ic, ic);
                if(ind>=0) Diag[ic] = Value[ind];
            }
        }
    }
    else
    {
        UMatrixSparse Mpow;
        if(DiagMid)
        {
            UMatrixSparse MD   = *this * DiagMid;
            Mpow = MD* *this;
            for(int ip=2; ip<matpow && Mpow.GetError()==U_OK; ip++) Mpow = MD * Mpow;

            if(Mpow.GetError()!=U_OK)
            {
                CI.AddToLog("ERROR: UMatrixSparse::GetDiagonal(). Raising matrix to power %d .\n", matpow);
                return NULL;
            }
            Diag = Mpow.GetDiagonal(1, NULL);
        }
        else
        {
            if(IsSymmetric())
            {
                Mpow = *this;
                for(int ip=2; ip<matpow && Mpow.GetError()==U_OK; ip++) Mpow = GetSparseATB(Mpow, *this);
                Diag = GetDiagonalATB(Mpow, *this);
            }
            else
            {
                Mpow = *this;
                for(int ip=2; ip<matpow && Mpow.GetError()==U_OK; ip++) Mpow *= *this;
                Diag = GetDiagonalAB(Mpow, *this);
            }
        }
    }
    if(Diag==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonal(). Memory allocation (Nrow=%d) .\n", Nrow);
        return NULL;
    }
    return Diag;
}
ErrorType UMatrixSparse::SandwichDiagonal(const UMatrix& Diag)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Number of rows (%d) and collumns (%d) not identical .\n", Nrow, Ncol);
        return U_ERROR;
    }
    if(&Diag==NULL || Diag.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Argument erroneous. \n");
        return U_ERROR;
    }
    if(Diag.IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Argument not of diagonal type. \n");
        return U_ERROR;
    }
    if(Diag.GetNrow()!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Number of Diag.rows (%d) and collumns (%d) not identical .\n", Diag.GetNrow(), Ncol);
        return U_ERROR;
    }
    switch(Diag.MT)
    {
    case U_MAT_NULL:
        *this = UMatrixSparse();
        Nrow = Ncol = Diag.Nrow;
        return U_OK;
    case U_MAT_IDENTITY:
        return U_OK;
    case U_MAT_IDENTCONST:
        {
            double sqr = SQR(Diag.Data[0]);
            for(int n=0; n<Nval; n++) Value[n] *= sqr;
        }
        return U_OK;
    case U_MAT_DIAGONAL:
        {
            const double* pDiag = Diag.Data;
            for(int j=0,n=0; j<Ncol; j++)
                for(int ir=ColPtr[j]; ir<ColPtr[j+1]; ir++,n++)
                    Value[n] *= pDiag[j]*pDiag[RowIndex[ir]];
        }
        return U_OK;
    }
    CI.AddToLog("ERROR: UMatrixSparse::SandwichDiagonal(). Diag.MT (%d) ofwrong type .\n", int(Diag.MT));
    return U_ERROR;
}
ErrorType UMatrixSparse::PreMultiplyDiagonal(const UMatrix& Diag)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PreMultiplyDiagonal(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Diag==NULL || Diag.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PreMultiplyDiagonal(). Argument erroneous. \n");
        return U_ERROR;
    }
    if(Diag.IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PreMultiplyDiagonal(). Argument not of diagonal type. \n");
        return U_ERROR;
    }
    if(Diag.GetNrow()!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PreMultiplyDiagonal(). Number of Diag.rows (%d) and collumns (%d) not identical .\n", Diag.GetNrow(), Ncol);
        return U_ERROR;
    }
    switch(Diag.MT)
    {
    case U_MAT_NULL:
        {
            int Nc = Ncol; 
            int Nr = Nrow;
            *this  = UMatrixSparse();
            Ncol   = Nc;
            Nrow   = Nr;
        }
        return U_OK;
    case U_MAT_IDENTITY:
        return U_OK;
    case U_MAT_IDENTCONST:
        {
            for(int n=0; n<Nval; n++) Value[n] *= Diag.Data[0];
        }
        return U_OK;
    case U_MAT_DIAGONAL:
        {
            const double* pDiag = Diag.Data;
            for(int j=0,n=0; j<Ncol; j++)
                for(int ir=ColPtr[j]; ir<ColPtr[j+1]; ir++,n++)
                    Value[n] *= pDiag[RowIndex[ir]];
        }
        return U_OK;
    }
    CI.AddToLog("ERROR: UMatrixSparse::PreMultiplyDiagonal(). Diag.MT (%d) ofwrong type .\n", int(Diag.MT));
    return U_ERROR;
}

bool UMatrixSparse::IsSymmetric(double Tol) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::IsSymmetric(). Object NULL or erroneous.\n");
        return false;
    }
    if(Nrow!=Ncol ) return false;
    if(UMatrixExpand::GetAddTransposed()) return true;

    if(Tol<0.) Tol = 0.;
    for(int ic=0; ic<Ncol; ic++)
        for(int j=ColPtr[ic]; j<ColPtr[ic+1]; j++)
        {
            int ir = RowIndex[j];
            if(fabs(Value[j]-(*this)[ic*Ncol+ir])>Tol)
                return false;
        }
    return true;
}

ErrorType UMatrixSparse::SetNrow(int Nr)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetNrow(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nr<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetNrow(). Argument out of range (Nr=%d). \n", Nr);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    Nrow = Nr;

    return U_OK;
}
ErrorType UMatrixSparse::AddCollumn(const int* NZindex, const double* Values, int NNZ)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NZindex==NULL || NNZ<0 || NNZ>Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Argument out of range (NNZ=%d, Nrow=%d). \n", NNZ, Nrow);
        return U_ERROR;
    }

    if(Nval+NNZ>=NvalAlloc || Ncol+2>=NcolAlloc)
    {
        if(Nval+NNZ>=NvalAlloc)
        {
            int     NewAlloc    = Nval+NNZ+10+Nrow;
            double* NewValue    = new double[NewAlloc];
            int*    NewRowIndex = new int[NewAlloc];
            if(NewValue==NULL || NewRowIndex==NULL)
            {
                delete[] NewValue; delete[] NewRowIndex;
                CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Memory allocation  (NewAlloc=%d). \n", NewAlloc);
                return U_ERROR;
            }
            for(int n=0; n<Nval;n++)
            {
                NewValue[n]    = Value[n];
                NewRowIndex[n] = RowIndex[n];
            }
            delete[] Value;    Value    = NewValue;
            delete[] RowIndex; RowIndex = NewRowIndex;
            NvalAlloc = NewAlloc;
        }
        if(Ncol+2>=NcolAlloc)
        {
            int     NewAlloc    = 2*(Ncol+10);
            int*    NewColPtr   = new int[NewAlloc];
            if(NewColPtr==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Memory allocation  (NewAlloc=%d). (collumns)\n", NewAlloc);
                return U_ERROR;
            }
            for(int n=0; n<Ncol;n++) NewColPtr[n] = ColPtr[n];
            delete[] ColPtr;    ColPtr    = NewColPtr;
            NcolAlloc = NewAlloc;
        }
    }

    int* Index = NULL;
    if(NNZ>0)
    {
        bool Abs   = false;
        bool HiFi  = false; // High values first
        Index      = GetOrderIndexArray(NZindex, NNZ, Abs, HiFi);
        if(Index==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Ordering NonZero indices. \n");
            return U_ERROR;
        }
    }
    ColPtr[Ncol  ] = Nval;
    ColPtr[Ncol+1] = Nval+NNZ;
    for(int ind=Nval,j=0; ind<Nval+NNZ; ind++,j++)
    {
        Value[ind]    = Values[Index[j]];
        RowIndex[ind] = NZindex[Index[j]];
    }
    delete[] Index;

    Ncol++;
    Nval+=NNZ;
    return U_OK;
}
ErrorType UMatrixSparse::AddCollumn(const int* NZindex, double Val, int NNZ)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(NZindex==NULL || NNZ<0 || NNZ>Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Argument out of range (NNZ=%d, Nrow=%d). \n", NNZ, Nrow);
        return U_ERROR;
    }

    double* Values = new double[NNZ+1]; // +1 to allow mem alloc in case of empty collumn
    if(Values==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Memory allocation, NNZ = %d .\n", NNZ);
        return U_ERROR;
    }
    for(int k=0; k<NNZ; k++) Values[k] = Val;

    ErrorType E = AddCollumn(NZindex, Values, NNZ);
    delete[] Values;
    return E;
}
ErrorType UMatrixSparse::AddCollumn(const double* Col, int NrowAdded)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Col==NULL || NrowAdded!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). NULL argument or argument out of range (NrowAdded=%d, Nrow=%d). \n", NrowAdded, Nrow);
        return U_ERROR;
    }
    double* Values  = new double[Nrow];
    int*    NZindex = new int[Nrow];
    if(Values==NULL || NZindex==NULL)
    {
        delete[] Values;
        delete[] NZindex;
        CI.AddToLog("ERROR: UMatrixSparse::AddCollumn(). Memory allocation, Nrow = %d .\n", Nrow);
        return U_ERROR;
    }
    int NNZ = 0;
    for(int k=0; k<NrowAdded; k++) 
    {
        if(Col[k]==0.) continue;
        Values [NNZ] = Col[k];
        NZindex[NNZ] = k;
        NNZ++;
    }
    ErrorType E = AddCollumn(NZindex, Values, NNZ);
    delete[] Values;
    delete[] NZindex;
    return E;
}

ErrorType UMatrixSparse::MatVec(const UMatrix& Vec, UMatrix& Result) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Object not properly set. \n");
        return U_ERROR;
    }
    if(&Vec==NULL || Vec.GetError()!=U_OK || &Result==NULL || Result.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Argument(s) NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Vec.Nrow!=Ncol || Vec.Ncol!=1 || Result.Nrow!=Ncol || Result.Ncol!=1)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Argument(s) Not well dimensioned Vec: (%d,%d) and Result: (%d,%d). \n", Vec.Nrow, Vec.Ncol, Result.Nrow, Result.Ncol);
        return U_ERROR;
    }
    if(Vec.GetMatrixType()!=U_MAT_GENERAL || Result.GetMatrixType()!=U_MAT_GENERAL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Argument(s) Not have wrong type Vec: (%d) and Result: (%d). \n", int(Vec.MT), int(Result.MT));
        return U_ERROR;
    }
    return MatVec(Vec.Data, Vec.Nrow, Result.Data);
}

ErrorType UMatrixSparse::MatVec(const double* Vec, int Nr, double* Result) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Object not properly set. \n");
        return U_ERROR;
    }
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(Nr!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Matrix collums (%d) not equal to Vector rows (%d). \n", Ncol, Nr);
        return U_ERROR;
    }
    if(Result==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatVec(). Result vector NULL. \n");
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++) Result[i] = 0.;

    for(int j=0; j<Ncol; j++)
        for(int i=ColPtr[j]; i<ColPtr[j+1]; i++)
            Result[RowIndex[i]] += Value[i]*Vec[j];

    return U_OK;
}
ErrorType UMatrixSparse::MatTVec(const double* Vec, int Nr, double* Result) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatTVec(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatTVec(). Object not properly set. \n");
        return U_ERROR;
    }
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatTVec(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(Nr!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatTVec(). Matrix rows (%d) not equal to Vecor rows (%d). \n", Nrow, Nr);
        return U_ERROR;
    }
    if(Result==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::MatTVec(). Result vector NULL. \n", Ncol);
        return U_ERROR;
    }

    for(int i=0; i<Ncol; i++) Result[i] = 0.;
    for(int i=0; i<Ncol; i++)
    {
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
            Result[i] += Value[j]*Vec[RowIndex[j]];
    }
    return U_OK;
}

double* UMatrixSparse::GetMatVec(const double* Vec, int Nr, int* Nrowout) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Object not properly set. \n");
        return NULL;
    }
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Invalid NULL argument. \n");
        return NULL;
    }
    if(Nr!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Matrix collums (%d) not equal to Vecor rows (%d). \n", Ncol, Nr);
        return NULL;
    }
    double* Pr = new double[Nrow];
    if(Pr==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Memory allocation (Nrow=%d). \n", Nrow);
        return NULL;
    }
    if(MatVec(Vec, Nr, Pr)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatVec(). Computing matrix vector multiplication. \n");
        delete[] Pr;
        return NULL;
    }
    if(Nrowout) *Nrowout = Nrow;
    return Pr;
}

double* UMatrixSparse::GetMatTVec(const double* Vec, int Nr, int* Nrowout) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Object not properly set. \n");
        return NULL;
    }
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Invalid NULL argument. \n");
        return NULL;
    }
    if(Nr!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Matrix rows (%d) not equal to Vecor rows (%d). \n", Nrow, Nr);
        return NULL;
    }
    double* Pr = new double[Ncol];
    if(Pr==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Memory allocation (Ncol=%d). \n", Ncol);
        return NULL;
    }
    if(MatTVec(Vec, Nr, Pr)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatTVec(). Computing matrix vector multiplication. \n");
        delete[] Pr;
        return NULL;
    }
    if(Nrowout) *Nrowout = Ncol;
    return Pr;
}

ErrorType UMatrixSparse::SetSymmetricToeplitz(const double* Row, int N)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetSymmetricToeplitz(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Row==NULL || N<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetSymmetricToeplitz(). Invalid NULL argument or invalid N (= %d). \n", N);
        return U_ERROR;
    }
    DeleteAllMembers(U_OK);

    Ncol = Nrow = N;
    Nval = N*N;

    if(Row[0]==0.) Nval-=N;
    for(int n=1; n<N; n++)
        if(Row[n]==0.) Nval -= 2*(N-n);

    Value       = new double[Nval];
    ColPtr      = new int[N+1];
    RowIndex    = new int[Nval];
    NcolAlloc   = Ncol+1;
    NvalAlloc   = Nval;

    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::SetSymmetricToeplitz(). Memory allocation  N=%d, Nval=%d. .\n", N, Nval);
        return U_ERROR;
    }

/* First collumn */
    ColPtr[0] = 0;
    int ind   = 0;
    for(int i=0; i<N; i++)
    {
        if(Row[i]==0.) continue;
        Value   [ind] = Row[i];
        RowIndex[ind] = i;
        ind++;
    }
    ColPtr[1] = ind;

/* Collumn 1 to N-1 */
    for(int j=1; j<N; j++)
    {
        int S = ColPtr[1]-1;
        while(RowIndex[S]>j && S>=0) S--;

        for(int s=S; s>=0; s--)
        {
            Value   [ind] = Value[s];
            RowIndex[ind] = j-RowIndex[s];
            ind++;
        }
        for(int s=1; s <ColPtr[1]; s++)
        {
            if(j+RowIndex[s]>=N) break;
            Value   [ind] = Value[s];
            RowIndex[ind] = j+RowIndex[s];
            ind++;
        }
        ColPtr[j+1] = ind;
    }
    if(ind!=Nval)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetSymmetricToeplitz(). Fatal error, Nval (=%d) != ind(=%d) .\n", Nval, ind);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMatrixSparse::SetBlockSymmetricToeplitz(const double* Rows, int NBlock, int NColBlock)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockSymmetricToeplitz(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Rows==NULL || NBlock<=0 || NColBlock<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockSymmetricToeplitz(). Invalid NULL argument or invalid NBlock (= %d) or NColBlock (=%d). \n", NBlock, NColBlock);
        return U_ERROR;
    }

    int* FirstNZ = new int[NBlock];
    int* LastNZ  = new int[NBlock];
    if(FirstNZ==NULL || LastNZ==NULL)
    {
        delete[] FirstNZ;
        delete[] LastNZ;
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockSymmetricToeplitz(). Memory allocation (NBlock=%d) \n", NBlock);
        return U_ERROR;
    }

    DeleteAllMembers(U_OK);

    Ncol = Nrow = NBlock*NColBlock;
    Nval = Nrow*Ncol;

    for(int k1=0; k1<NBlock; k1++)
    {
        for(int k2=0; k2<NBlock; k2++)
        {
            int           k12 = k1*NBlock+k2;
            const double* Row = Rows + k12*NColBlock;
            if(Rows[k12*NColBlock+0]==0.) Nval -= NColBlock;
            for(int n=1; n<NColBlock; n++)
                if(Row[n]==0.)            Nval -= 2*(NColBlock-n);
        }
    }

    Value       = new double[Nval];
    ColPtr      = new int[Ncol+1];
    RowIndex    = new int[Nval];
    NcolAlloc   = Ncol+1;
    NvalAlloc   = Nval;

    if(Value==NULL || ColPtr==NULL || RowIndex==NULL)
    {
        delete[] FirstNZ;
        delete[] LastNZ;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockSymmetricToeplitz(). Memory allocation  Ncol=%d, Nval=%d. .\n", Ncol, Nval);
        return U_ERROR;
    }

    ColPtr[0] = 0;
    int ind   = 0;
    for(int k2=0; k2<NBlock; k2++)
    {
        for(int k1=0; k1<NBlock; k1++)                     // First collumn of new blocks
        {
            FirstNZ[k1]       = -1;
            LastNZ[k1]        = -1;
            int           k21 = k2   + k1 *NBlock;
            const double* Row = Rows + k21*NColBlock;
            for(int i=0; i<NColBlock; i++)
            {
                if(Row[i]==0.) continue;
                Value   [ind] = Row[i];
                RowIndex[ind] = k1*NColBlock+i;
                if(FirstNZ[k1]==-1) FirstNZ[k1] = ind;
                LastNZ[k1]    = ind;
                ind++;
            }
        }
        ColPtr[k2*NColBlock+1] = ind;

        for(int j=1; j<NColBlock; j++) // Collumn 1 to NColBlock-1
        {
            for(int k1=0; k1<NBlock; k1++)
            {
                if(FirstNZ[k1]<0) continue;
                int sm = FirstNZ[k1];
                int SM = LastNZ[k1];

                for(int s=SM; s>=sm; s--)
                {
                    if(  k1*NColBlock-RowIndex[s]==0) continue;
                    if(j+k1*NColBlock-RowIndex[s] <0) continue;
                    Value   [ind] = Value[s];
                    RowIndex[ind] = j+2*k1*NColBlock-RowIndex[s];
                    ind++;
                }
                for(int s=sm; s <=SM; s++)
                {
                    if(j+RowIndex[s]>=(k1+1)*NColBlock) break;
                    Value   [ind] = Value[s];
                    RowIndex[ind] = j+RowIndex[s];
                    ind++;
                }
            }
            ColPtr[k2*NColBlock+j+1] = ind;
        }
    }
    delete[] FirstNZ;
    delete[] LastNZ;
    if(ind!=Nval)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockSymmetricToeplitz(). Fatal error, Nval (=%d) != ind(=%d) .\n", Nval, ind);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMatrixSparse::SetBlockToeplitz(const double* ColRows, int NBlock, int NColBlock)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockToeplitz(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(ColRows==NULL || NBlock<=0 || NColBlock<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockToeplitz(). Invalid NULL argument or invalid NBlock (= %d) or NColBlock (=%d). \n", NBlock, NColBlock);
        return U_ERROR;
    }

    DeleteAllMembers(U_OK);

    Ncol = Nrow = NBlock*NColBlock;
    Nval = Nrow*Ncol;

    for(int k1=0; k1<NBlock; k1++)
    {
        for(int k2=0; k2<NBlock; k2++)
        {
            int           k12 = k1*NBlock+k2;
            const double* Col = ColRows + k12*2*NColBlock;
            const double* Row = Col     +       NColBlock;
            for(int n=0; n<NColBlock; n++)  if(Col[n]==0.) Nval -= (NColBlock-n);
            for(int n=1; n<NColBlock; n++)  if(Row[n]==0.) Nval -= (NColBlock-n);

            if(Col[0]!=Row[0])
            {
                DeleteAllMembers(U_ERROR);
                CI.AddToLog("ERROR: UMatrixSparse::SetBlockToeplitz(). First row and collumn element of block (%d, %d) are different .\n", k1, k2);
                return U_ERROR;
            }
        }
    }

    int* FirstNZ  = new int[2*NBlock];
    int* LastNZ   = new int[2*NBlock];
    double* CpRow = new double[Nrow];
    int* ColIndex = new int[Nrow];
    Value         = new double[Nval];
    ColPtr        = new int[Ncol+1];
    RowIndex      = new int[Nval];
    NcolAlloc     = Ncol+1;
    NvalAlloc     = Nval;

    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || FirstNZ==NULL || LastNZ==NULL || CpRow==NULL || ColIndex==NULL)
    {
        delete[] FirstNZ;
        delete[] LastNZ;
        delete[] CpRow;
        delete[] ColIndex;
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockToeplitz(). Memory allocation  Ncol=%d, Nval=%d  .\n", Ncol, Nval);
        return U_ERROR;
    }

    ColPtr[0] = 0;
    int ind   = 0;
    for(int k2=0; k2<NBlock; k2++)
    {
        int indrow = 0;
        for(int k1=0; k1<NBlock; k1++)                     // First collumn of new blocks
        {
            FirstNZ[k1]       = -1;
            LastNZ[k1]        = -1;
            int           k12 = k2      + k1   *NBlock;
            const double* Col = ColRows + k12*2*NColBlock;
            const double* Row = Col     +       NColBlock;
            for(int i=0; i<NColBlock; i++)
            {
                if(Col[i]==0.) continue;
                Value   [ind] = Col[i];
                RowIndex[ind] = k1*NColBlock+i;
                if(FirstNZ[k1]==-1) FirstNZ[k1] = ind;
                LastNZ[k1]    = ind;
                ind++;
            }

            int* FirstRow = FirstNZ+NBlock;  FirstRow[k1] = -1;
            int* LastRow  = LastNZ +NBlock;  LastRow[k1]  = -1;
            for(int i=0; i<NColBlock; i++)
            {
                if(Row[i]==0.) continue;
                CpRow   [indrow] = Row[i];
                ColIndex[indrow] = k1*NColBlock+i;
                if(FirstRow[k1]==-1) FirstRow[k1] = indrow;
                LastRow[k1]      = indrow;
                indrow++;
            }
        }
        ColPtr[k2*NColBlock+1] = ind;

        for(int j=1; j<NColBlock; j++) // Collumn 1 to NColBlock-1
        {
            for(int k1=0; k1<NBlock; k1++)
            {
                int sm = FirstNZ[NBlock+k1];
                int SM = LastNZ [NBlock+k1];
                if(sm>=0)
                {
                    for(int s=SM; s>=sm; s--)
                    {
                        if(  k1*NColBlock-ColIndex[s]==0) continue;
                        if(j+k1*NColBlock-ColIndex[s] <0) continue;
                        Value   [ind] = CpRow[s];
                        RowIndex[ind] = j+2*k1*NColBlock-ColIndex[s];
                        ind++;
                    }
                }
                sm = FirstNZ[k1];
                SM = LastNZ[k1];
                if(sm>=0)
                {
                    for(int s=sm; s <=SM; s++)
                    {
                        if(j+RowIndex[s]>=(k1+1)*NColBlock) break;
                        Value   [ind] = Value[s];
                        RowIndex[ind] = j+RowIndex[s];
                        ind++;
                    }
                }
            }
            ColPtr[k2*NColBlock+j+1] = ind;
        }
    }
    delete[] FirstNZ;
    delete[] LastNZ;
    delete[] CpRow;
    delete[] ColIndex;
    if(ind!=Nval)
    {
        CI.AddToLog("ERROR: UMatrixSparse::SetBlockToeplitz(). Fatal error, Nval (=%d) != ind(=%d) .\n", Nval, ind);
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMatrixSparse::PrintToLog(const char* Name, int irow, int NrowPrint, int icol, int NcolPrint) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PrintToLog(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PrintToLog().  Ncol (=%d) or Nrow (%d) invalid \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::PrintToLog(). Object not properly set. \n");
        return U_ERROR;
    }
    if(NrowPrint<0) NrowPrint = Nrow;
    if(NcolPrint<0) NcolPrint = Ncol;

    irow = MIN(MAX(0,irow), Nrow-1); NrowPrint = MIN(MAX(1, NrowPrint), Nrow-irow);
    icol = MIN(MAX(0,icol), Ncol-1); NcolPrint = MIN(MAX(1, NcolPrint), Ncol-icol);

    if(Name) CI.AddToLog("%s:\n", Name);
    CI.AddToLog("Row %d - Row %d \n", irow, irow+NrowPrint-1);
    CI.AddToLog("Col %d - Col %d \n", icol, icol+NcolPrint-1);

    for(int i=irow; i<irow+NrowPrint; i++)
    {
        for(int j=icol; j<icol+NcolPrint; j++) CI.AddToLog("%f \t", GetElement(i,j));
        CI.AddToLog("\n");
    }
    return U_OK;
}

ErrorType UMatrixSparse::WriteXDR(UFileName Fout, bool ConvLog) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::WriteXDR(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::WriteXDR(). Object not properly set. \n");
        return U_ERROR;
    }

    UVector2 Min(double(     0), double(     0));
    UVector2 Max(double(Ncol-1), double(Nrow-1));
    int dims[2] = {Ncol, Nrow};

    UField FLD(Min, Max, dims, UField::U_BYTE, 1);
    if(FLD.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::WriteXDR(). Creating UField object.  \n");
        return U_ERROR;
    }

    FLD.SetDataByte(0);
    unsigned char* Dat = FLD.GetBdata();

    for(int i=0; i<Ncol; i++)
    {
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
        {
            double V = Value[j];
            if(V==0.) continue;
            if(ConvLog) V = log(fabs(V));

            Dat[RowIndex[j]*Ncol+i] += (unsigned char) int(V);
        }
    }

    FLD.ReverseData(1,false);
    return FLD.WriteXDR(Fout, GetProperties(" "));
}

double* UMatrixSparse::GetMatrixFull(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatrixFull(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatrixFull(). Object not properly set. \n");
        return NULL;
    }

    double* Mat = new double[Nrow*Ncol];
    if(Mat==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetMatrixFull(). Memory allocation (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
        return NULL;
    }
    for(int k=0; k<Nrow*Ncol; k++) Mat[k] = 0.;
    for(int i=0; i<Ncol; i++)
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
        {
            Mat[RowIndex[j]*Ncol+i] += Value[j];
        }
    return Mat;
}

double* UMatrixSparse::GetCollumnFull(int icol) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnFull(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnFull(). Object not properly set. \n");
        return NULL;
    }

    if(icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnFull(). Parameter out of range (icol=%d). \n", icol);
        return NULL;
    }
    double* Vec = new double[Nrow];
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnFull(). Memory allocation (Nrow=%d). \n", Nrow);
        return NULL;
    }
    for(int k=0; k<Nrow; k++) Vec[k] = 0.;
        for(int j=ColPtr[icol]; j<ColPtr[icol+1]; j++)
            Vec[RowIndex[j]] = Value[j];

    return Vec;
}
UMatrixSparse UMatrixSparse::GetCollumnSparse(int icol) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnSparse(). Object NULL or erroneous. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnSparse(). Object not properly set. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnSparse(). Parameter out of range (icol=%d). \n", icol);
        return UMatrixSparse(U_ERROR);
    }
    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnSparse(). Creating output UMatrixSparse()-object. \n");
        return UMatrixSparse(U_ERROR);
    }
    MS.Ncol       = 1;
    MS.Nrow       = Nrow;
    MS.Nval       = ColPtr[icol+1]-ColPtr[icol];
    MS.NcolAlloc  = 2;
    MS.NvalAlloc  = ColPtr[icol+1]-ColPtr[icol];
    MS.ColPtr     = new int[2];
    if(MS.Nval>0)
    {
        MS.Value    = new double[MS.Nval];
        MS.RowIndex = new int   [MS.Nval];
    }
    if(MS.NcolAlloc==NULL || (MS.Nval>0 && (MS.Value==NULL || MS.RowIndex==NULL)))
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetCollumnSparse(). Memory allocation.\n");
        return UMatrixSparse(U_ERROR);
    }
    MS.ColPtr[0] = 0;
    MS.ColPtr[1] = MS.Nval;

    for(int j=ColPtr[icol],jj=0; j<ColPtr[icol+1]; j++,jj++)
    {
        MS.Value   [jj] = Value[j];
        MS.RowIndex[jj] = RowIndex[j];
    }
    return MS;
}
UMatrixSparse UMatrixSparse::GetSelectedCollumnsSparse(const int* icols, int NrSel) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Object NULL or erroneous. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Object not properly set. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(icols==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Invalid NULL argument (irows) .\n");
        return UMatrixSparse(U_ERROR);
    }
    if(NrSel<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Parameter out of range (NrSel=%d). \n", NrSel);
        return UMatrixSparse(U_ERROR);
    }
    int NvalSel = 0;
    for(int i=0; i<NrSel; i++)
    {
        if(icols[i]>=0 && icols[i]<Nrow) 
        {
            NvalSel += ColPtr[icols[i]+1]-ColPtr[icols[i]];
            continue;
        }
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Selected row out of range (icols[%d] = %d ).\n", i, icols[i]);
        return UMatrixSparse(U_ERROR);
    }
    int* Index = GetOrderIndexArray(icols, NrSel, false, false);
    if(Index==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Getting collumn order.\n");
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Creating output UMatrixSparse()-object. \n");
        return UMatrixSparse(U_ERROR);
    }
    MS.Ncol       = NrSel;
    MS.Nrow       = Nrow;
    MS.Nval       = NvalSel;
    MS.NcolAlloc  = NrSel;
    MS.NvalAlloc  = NvalSel;
    MS.ColPtr     = new int[NrSel+1];
    if(MS.Nval>0)
    {
        MS.Value    = new double[MS.Nval];
        MS.RowIndex = new int   [MS.Nval];
    }
    if(MS.NcolAlloc==NULL || (MS.Nval>0 && (MS.Value==NULL || MS.RowIndex==NULL)))
    {
        delete[] Index;
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedCollumnsSparse(). Memory allocation.\n");
        return UMatrixSparse(U_ERROR);
    }
    MS.ColPtr[0    ] = 0;
    MS.ColPtr[NrSel] = MS.Nval;

    for(int icol=0,jj=0; icol<NrSel; icol++)
    {
        MS.ColPtr[icol+1] = MS.ColPtr[icol] + ColPtr[icols[Index[icol]]+1]-ColPtr[icols[Index[icol]]];

        for(int j=ColPtr[icols[Index[icol]]]; j<ColPtr[icols[Index[icol]]+1]; j++,jj++)
        {
            MS.Value   [jj] = Value[j];
            MS.RowIndex[jj] = RowIndex[j];
        }
    }
    delete[] Index;
    return MS;
}

ErrorType UMatrixSparse::RemoveCollumn(int icol)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveCollumn(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveCollumn(). Object not properly set. \n");
        return U_ERROR;
    }
    if(icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveCollumn(). Parameter out of range (icol=%d). \n", icol);
        return U_ERROR;
    }

    int NValRem = ColPtr[icol+1]-ColPtr[icol];
    if(NValRem)
    {
        for(int j=ColPtr[icol]; j<Nval-NValRem; j++)
        {
            Value   [j] = Value   [j+NValRem];
            RowIndex[j] = RowIndex[j+NValRem];
        }
    }
    for(int ic = icol; ic<Ncol; ic++) ColPtr[ic] = ColPtr[ic+1]-NValRem;
    Ncol-=1;
    Nval-=NValRem;
    return U_OK;
}
ErrorType UMatrixSparse::RemoveSelectedCollumns(const int* icols, int NcSel)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Object not properly set. \n");
        return U_ERROR;
    }
    if(NcSel<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Invalid argument, NcSel=%d .\n",NcSel);
        return U_ERROR;
    }
    if(NcSel==0   ) return U_OK;
    if(icols==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Ivalid NULL pointer argument. \n");
        return U_ERROR;
    }

    bool Fabs  = false;
    bool HiFi  = true;
    int* Order = GetOrderIndexArray(icols, NcSel, Fabs, HiFi);
    if(Order==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Getting ordered collumns. \n");
        return U_ERROR;
    }
    for(int k=0; k<NcSel; k++)
    {
        if(icols[k]<0 || icols[k]>=Ncol)
        {
            delete[] Order;
            CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Collumn index out of range icols[%d] = %d .\n", k, icols[k]);
            return U_ERROR;
        }
        if(k>0 && Order[k-1]==Order[k])
        {
            delete[] Order;
            CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Collumn index duplicated. \n");
            return U_ERROR;
        }
    }
    for(int k=0; k<NcSel; k++)
    {
        if(RemoveCollumn(icols[Order[k]])==U_OK) continue;

        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedCollumns(). Removing collumn %d. \n", icols[Order[k]]);
        delete[] Order;
        return U_ERROR;
    }
    delete[] Order;
    return U_OK;
}
ErrorType UMatrixSparse::RemoveSelectedRows(const int* irows, int NrSel)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Object not properly set. \n");
        return U_ERROR;
    }
    if(NrSel<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Invalid argument, NrSel=%d .\n",NrSel);
        return U_ERROR;
    }
    if(NrSel==0   ) return U_OK;
    if(irows==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Ivalid NULL pointer argument. \n");
        return U_ERROR;
    }

    bool Fabs      = false;
    bool HiFi      = false;
    int* Order     = GetOrderIndexArray(irows, NrSel, Fabs, HiFi);
    int* NewColPtr = new int[Ncol+1];
    if(Order==NULL || NewColPtr==NULL)
    {
        delete[] Order; delete[] NewColPtr;
        CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Getting ordered rows. \n");
        return U_ERROR;
    }
    for(int k=0; k<=Ncol; k++) NewColPtr[k] = ColPtr[k];
    for(int k=0; k<NrSel; k++)
    {
        if(irows[k]<0 || irows[k]>=Nrow)
        {
            delete[] Order; delete[] NewColPtr;
            CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Row index out of range irows[%d] = %d .\n", k, irows[k]);
            return U_ERROR;
        }
        if(k>0 && Order[k-1]==Order[k])
        {
            delete[] Order; delete[] NewColPtr;
            CI.AddToLog("ERROR: UMatrixSparse::RemoveSelectedRows(). Row index duplicated. \n");
            return U_ERROR;
        }
    }

    int  NValRem = 0;
    for(int j=0,k=0; j<Ncol; j++)
    {
        int krem  = 0;
        int irrem = irows[Order[krem]];

        for(int i=ColPtr[j]; i<ColPtr[j+1]; i++)
        {
            for(  ; krem+1<NrSel && irows[Order[krem+1 ]]<=RowIndex[i]; krem++) irrem = irows[Order[krem +1]];
            if(                     irows[Order[NrSel-1]]<=RowIndex[i])        {irrem = irows[Order[NrSel-1]]; krem = NrSel-1;}

            if(RowIndex[i]==irrem)
            {
                NValRem++;
            }
            else
            {
                Value   [k] = Value   [k+NValRem];
                RowIndex[k] = RowIndex[k+NValRem];
                if(RowIndex[k]>irrem) RowIndex[k]-=krem+1;
                k++;
            }
        }
        NewColPtr[j+1] -=NValRem;
    }
    delete[] Order;

    Nrow  -=NrSel;
    Nval  -=NValRem;
    delete[] ColPtr; ColPtr = NewColPtr; 
    return U_OK;
}

ErrorType UMatrixSparse::RemoveRow(int irow)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveRow(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveRow(). Object not properly set. \n");
        return U_ERROR;
    }

    if(irow<0 || irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::RemoveRow(). Parameter out of range (irow=%d). \n", irow);
        return U_ERROR;
    }

    int  NValRem = 0;
    int  icMin   = 0;
    for(int j=0,k=0; j<Ncol; j++)
    {
        int icMax = abs(ColPtr[j+1]);
        for(int i=icMin; i<icMax; i++)
        {
            if(RowIndex[i]==irow)
            {
                NValRem++;
                ColPtr[j+1] =-ColPtr[j+1];
            }
            else
            {
                Value   [k] = Value   [k+NValRem];
                RowIndex[k] = RowIndex[k+NValRem];
                if(RowIndex[k]>irow) RowIndex[k]--;
                k++;
            }
        }
        icMin = icMax;
    }
    int irem = 0;
    for(int j=0; j<=Ncol; j++)
    {
        if(ColPtr[j]<0) irem++;
        ColPtr[j] = abs(ColPtr[j]) - irem;
    }
    Nrow-=1;
    Nval-=NValRem;
    return U_OK;
}

double* UMatrixSparse::GetRowFull(int irow) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowFull(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowFull(). Object not properly set. \n");
        return NULL;
    }
    if(irow<0 || irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowFull(). Parameter out of range (irow=%d). \n", irow);
        return NULL;
    }
    double* Vec = new double[Ncol];
    if(Vec==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowFull(). Memory allocation (Ncol=%d). \n", Ncol);
        return NULL;
    }
    for(int k=0; k<Ncol; k++) Vec[k] = 0.;
    for(int i=0; i<Ncol; i++)
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
        {
            if(RowIndex[j]!=irow) continue;
            Vec[i] += Value[j];
        }

    return Vec;
}
UMatrixSparse UMatrixSparse::GetRowSparse(int irow) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparse(). Object NULL or erroneous. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparse(). Object not properly set. \n");
        return UMatrixSparse(U_ERROR);
    }

    if(irow<0 || irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparse(). Parameter out of range (irow=%d). \n", irow);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparse(). Creating output UMatrixSparse()-object. \n");
        return UMatrixSparse(U_ERROR);
    }

    int NVrow = 0;
    for(int i=0; i<Ncol; i++)
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++) if(RowIndex[j]==irow) {NVrow++; break;}

    MS.Ncol       = Ncol;
    MS.Nrow       = 1;
    MS.Nval       = NVrow;
    MS.NcolAlloc  = Ncol+1;
    MS.NvalAlloc  = NVrow;
    MS.ColPtr     = new int[Ncol+1];
    if(MS.Nval>0)
    {
        MS.Value    = new double[MS.Nval];
        MS.RowIndex = new int   [MS.Nval];
    }
    if(MS.NcolAlloc==NULL || (MS.Nval>0 && (MS.Value==NULL || MS.RowIndex==NULL)))
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparse(). Memory allocation.\n");
        return UMatrixSparse(U_ERROR);
    }

    MS.ColPtr[0] = 0;
    int     icol = 0;
    for(int i=0; i<Ncol; i++)
    {
        MS.ColPtr[i+1] = MS.ColPtr[i];
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
        {
            if(RowIndex[j]!=irow) continue;
            MS.RowIndex[icol] = 0;
            MS.Value   [icol] = Value[j];
            MS.ColPtr[i+1]++;
            icol++;
            break;
        }
    }
    return MS;
}
UMatrixSparse UMatrixSparse::GetSelectedRowsSparse(const int* irows, int NrSel) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Object NULL or erroneous. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Object not properly set. \n");
        return UMatrixSparse(U_ERROR);
    }

    if(irows==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Invalid NULL argument (irows) .\n");
        return UMatrixSparse(U_ERROR);
    }
    if(NrSel<0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Parameter out of range (NrSel=%d). \n", NrSel);
        return UMatrixSparse(U_ERROR);
    }
    for(int i=0; i<NrSel; i++)
    {
        if(irows[i]>=0 && irows[i]<Nrow) continue;
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Selected row out of range (irows[%d] = %d ).\n", i, irows[i]);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Creating output UMatrixSparse()-object. \n");
        return UMatrixSparse(U_ERROR);
    }
    int NVrow = 0;
    for(int i=0; i<Ncol; i++)
        for(int jsel=0; jsel<NrSel; jsel++)
            for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
                if(RowIndex[j]==irows[jsel]) {NVrow++; break;}

    MS.Ncol       = 0;
    MS.Nrow       = NrSel;
    MS.Nval       = 0;
    MS.NcolAlloc  = Ncol+1;
    MS.NvalAlloc  = NVrow;
    MS.ColPtr     = new int[Ncol+1];
    if(NVrow>0)
    {
        MS.Value    = new double[NVrow];
        MS.RowIndex = new int   [NVrow];
    }
    if(MS.NcolAlloc==NULL || (NVrow>0 && (MS.Value==NULL || MS.RowIndex==NULL)))
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Memory allocation.\n");
        return UMatrixSparse(U_ERROR);
    }

    double* NZValue = new double[NrSel];
    int*    NZindex = new int   [NrSel];
    if(NZValue==NULL || NZindex==NULL)
    {
        delete[] NZValue; delete[] NZindex;
        CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Memory allocation, NrSel = %d  . \n", NrSel);
        return UMatrixSparse(U_ERROR);
    }

    for(int i=0; i<Ncol; i++)
    {
        int NNZ = 0;
        for(int jsel=0; jsel<NrSel; jsel++)
        {
            for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
            {
                if(RowIndex[j]!=irows[jsel]) continue;
                NZindex[NNZ] = jsel;
                NZValue[NNZ] = Value[j];
                NNZ++;
            }
        }
        if(MS.AddCollumn(NZindex, NZValue, NNZ)!=U_OK)
        {
            delete[] NZValue; delete[] NZindex;
            CI.AddToLog("ERROR: UMatrixSparse::GetSelectedRowsSparse(). Adding collumn %d .\n", i);
            return UMatrixSparse(U_ERROR);
        }
    }
    delete[] NZValue; delete[] NZindex;

    return MS;
}

UMatrixSparse UMatrixSparse::GetRowTSparse(int irow) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparseT(). Object NULL or erroneous. \n");
        return UMatrixSparse(U_ERROR);
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparseT(). Object not properly set. \n");
        return UMatrixSparse(U_ERROR);
    }

    if(irow<0 || irow>=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparseT(). Parameter out of range (irow=%d). \n", irow);
        return UMatrixSparse(U_ERROR);
    }

    UMatrixSparse MS;
    if(MS.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparseT(). Creating output UMatrixSparse()-object. \n");
        return UMatrixSparse(U_ERROR);
    }
    int NVrow = 0;
    for(int i=0; i<Ncol; i++)
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++) if(RowIndex[j]==irow) {NVrow++; break;}

    MS.Ncol       = 1;
    MS.Nrow       = Ncol;
    MS.Nval       = NVrow;
    MS.NcolAlloc  = 2;
    MS.NvalAlloc  = NVrow;
    MS.ColPtr     = new int[2];
    if(MS.Nval>0)
    {
        MS.Value    = new double[MS.Nval];
        MS.RowIndex = new int   [MS.Nval];
    }
    if(MS.NcolAlloc==NULL || (MS.Nval>0 && (MS.Value==NULL || MS.RowIndex==NULL)))
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowSparseT(). Memory allocation.\n");
        return UMatrixSparse(U_ERROR);
    }
    MS.ColPtr[0] = 0;
    MS.ColPtr[1] = MS.Nval;

    int      icol = 0;
    for(int i=0; i<Ncol; i++)
    {
        for(int j=ColPtr[i]; j<ColPtr[i+1]; j++)
        {
            if(RowIndex[j]!=irow) continue;
            MS.RowIndex[icol] = i;
            MS.Value   [icol] = Value[j];
            icol++;
            break;
        }
    }
    return MS;
}

UMatrix UMatrixSparse::GetAxIsB(const UMatrix& B, bool TransMat)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetAxIsB(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&B==NULL || B.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetAxIsB(). Erroneous argument.\n");
        return UMatrix(U_ERROR);
    }
    if(B.GetNrow() != Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetAxIsB(). Number of rows and collmns do not match, B.Nrow=%d, Ncol=%d .\n", B.GetNrow(), Ncol);
        return UMatrix(U_ERROR);
    }
    if(B.IsEmpty()) return B;

    return UPreConBiConGrad::GetAxIsB(B, TransMat);
}


ErrorType UMatrixSparse::TestSetValueIndexPlus1(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSparse::TestSetValueIndexPlus1(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::TestSetValueIndexPlus1(). Object not properly set. \n");
        return U_ERROR;
    }
    for(int k=0; k<Nval; k++) Value[k] = k+1.;
    return U_OK;
}
int UMatrixSparse::GetRowIndex(int irow, int icol) const
{
    if(this==NULL     || error!=U_OK ) return -1;
    if(RowIndex==NULL || ColPtr==NULL) return -1;

    if(irow<0 || irow>=Nrow) return -1;
    if(icol<0 || icol>=Ncol) return -1;

    int ind = SearchIndex(irow, RowIndex+ColPtr[icol], ColPtr[icol+1]-ColPtr[icol]);
    if(RowIndex[ColPtr[icol]+ind]==irow) return ColPtr[icol]+ind;
    return -1;
}

UMatrixSparse GetSparseATB(const UMatrixSparse& A, const UMatrixSparse& B)
{
    if(&A==NULL || A.GetError()!=U_OK || &B==NULL || B.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetSparseATB(). NULL or erroneous argument(s).\n");
        return UMatrixSparse(U_ERROR);
    }
    if(A.Value==NULL || A.ColPtr==NULL || A.RowIndex==NULL || A.Ncol<=0 || A.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseATB(). Object A not properly set (A.Nrow=%d, A.Ncol=%d)  .\n", A.Nrow, A.Ncol);
        return UMatrixSparse(U_ERROR);
    }
    if(B.Value==NULL || B.ColPtr==NULL || B.RowIndex==NULL || B.Ncol<=0 || B.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetSparseATB(). Object B not properly set (B.Nrow=%d, B.Ncol=%d)  .\n", B.Nrow, B.Ncol);
        return UMatrixSparse(U_ERROR);
    }

    if(A.GetNrow()!=B.GetNrow())
    {
        CI.AddToLog("ERROR: GetSparseATB(). Matrix dimensions do not match (A.Nrow=%d, B.Nrow=%d).\n",A.GetNrow(), B.GetNrow());
        return UMatrixSparse(U_ERROR);
    }
    UMatrixSparse  ATB;
    double*        Col = new double[A.Ncol];
    if(Col==NULL)
    {
        CI.AddToLog("ERROR: GetSparseATB(). Memory allocation error, A.Ncol = %d  .\n", A.Ncol);
        return UMatrixSparse(U_ERROR);
    }
    ATB.Nrow      = A.Ncol;
    ATB.Ncol      = 0;
    ATB.NcolAlloc = B.Ncol;
    ATB.NvalAlloc = 10*ATB.NcolAlloc;
    ATB.RowIndex  = new int   [ATB.NvalAlloc  ];
    ATB.ColPtr    = new int   [ATB.NcolAlloc+1];
    ATB.Value     = new double[ATB.NvalAlloc  ];
    if(ATB.RowIndex==NULL || ATB.ColPtr==NULL || ATB.Value==NULL)
    {
        CI.AddToLog("ERROR: GetSparseATB(). Memory allocation error, ATB.NvalAlloc = %d  .\n", ATB.NvalAlloc);
        delete[] Col;
        return UMatrixSparse(U_ERROR);
    }

    for(int icol2=0; icol2<B.Ncol; icol2++)
    {
        for(int icol1=0; icol1<A.Ncol; icol1++) Col[icol1] = 0.;
        for(int icol1=0; icol1<A.Ncol; icol1++)
        {
            int ind1  = A.ColPtr[icol1];
            int ind2  = B.ColPtr[icol2];
            while(ind1<A.ColPtr[icol1+1] && ind2<B.ColPtr[icol2+1])
            {
                if(A.RowIndex[ind1]==B.RowIndex[ind2])
                {
                    Col[icol1] += A.Value[ind1]*B.Value[ind2];
                    ind1++; ind2++;
                }
                else if(A.RowIndex[ind1]<B.RowIndex[ind2]) ind1++;
                else                                       ind2++;
            }
        }
        if(ATB.AddCollumn(Col, A.Ncol)!=U_OK)
        {
            CI.AddToLog("ERROR: UGetSparseATB(). Adding collumn %d  .\n", icol2);
            delete[] Col;
            return UMatrixSparse(U_ERROR);
        }
    }
    return ATB;
}
double* GetDiagonalATB(const UMatrixSparse& A, const UMatrixSparse& B)
{
    if(&A==NULL || A.GetError()!=U_OK || &B==NULL || B.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetDiagonalATB(). NULL or erroneous argument(s).\n");
        return NULL;
    }
    if(A.Value==NULL || A.ColPtr==NULL || A.RowIndex==NULL || A.Ncol<=0 || A.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalATB(). Object A not properly set (A.Nrow=%d, A.Ncol=%d)  .\n", A.Nrow, A.Ncol);
        return NULL;
    }
    if(B.Value==NULL || B.ColPtr==NULL || B.RowIndex==NULL || B.Ncol<=0 || B.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalATB(). Object B not properly set (B.Nrow=%d, B.Ncol=%d)  .\n", B.Nrow, B.Ncol);
        return NULL;
    }

    if(A.GetNrow()!=B.GetNrow() || A.GetNcol()!=B.GetNcol())
    {
        CI.AddToLog("ERROR: GetDiagonalATB(). Matrix dimensions do not match (A.Nrow=%d, B.Nrow=%d), (A.Ncol=%d, B.Ncol=%d).\n",A.GetNrow(), B.GetNrow(),A.GetNcol(), B.GetNcol());
        return NULL;
    }
    double* Diag = new double[A.Ncol];
    if(Diag==NULL)
    {
        CI.AddToLog("ERROR: GetDiagonalATB(). Memory allocation error, A.Ncol = %d  .\n", A.Ncol);
        return NULL;
    }

    for(int icol=0; icol<A.Ncol; icol++) Diag[icol] = 0.;

    for(int icol=0; icol<A.Ncol; icol++)
    {
        int ind1  = A.ColPtr[icol];
        int ind2  = B.ColPtr[icol];
        while(ind1<A.ColPtr[icol+1] && ind2<B.ColPtr[icol+1])
        {
            if(A.RowIndex[ind1]==B.RowIndex[ind2])
            {
                Diag[icol] += A.Value[ind1]*B.Value[ind2];
                ind1++; ind2++;
            }
            else if(A.RowIndex[ind1]<B.RowIndex[ind2]) ind1++;
            else                                       ind2++;
        }
    }
    return Diag;
}
double* GetDiagonalAB(const UMatrixSparse& A, const UMatrixSparse& B)
{
    if(&A==NULL || A.GetError()!=U_OK || &B==NULL || B.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetDiagonalAB(). NULL or erroneous argument(s).\n");
        return NULL;
    }
    if(A.Value==NULL || A.ColPtr==NULL || A.RowIndex==NULL || A.Ncol<=0 || A.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalAB(). Object A not properly set (A.Nrow=%d, A.Ncol=%d)  .\n", A.Nrow, A.Ncol);
        return NULL;
    }
    if(B.Value==NULL || B.ColPtr==NULL || B.RowIndex==NULL || B.Ncol<=0 || B.Nrow<=0)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetDiagonalAB(). Object B not properly set (B.Nrow=%d, B.Ncol=%d)  .\n", B.Nrow, B.Ncol);
        return NULL;
    }

    if(A.GetNrow()!=B.GetNcol() || A.GetNcol()!=B.GetNrow())
    {
        CI.AddToLog("ERROR: GetDiagonalAB(). Matrix dimensions do not match (A.Nrow=%d, B.Ncol=%d), (A.Ncol=%d, B.Nrow=%d).\n",A.GetNrow(), B.GetNcol(),A.GetNcol(), B.GetNrow());
        return NULL;
    }
    double* Diag = new double[A.Nrow];
    if(Diag==NULL)
    {
        CI.AddToLog("ERROR: GetDiagonalAB(). Memory allocation error, A.Nrow = %d  .\n", A.Nrow);
        return NULL;
    }

    for(int irow1=0; irow1<A.Nrow; irow1++) Diag[irow1] = 0.;

    for(int irow1=0; irow1<A.Nrow; irow1++)
    {
        for(int j=B.ColPtr[irow1]; j<B.ColPtr[irow1+1]; j++)
        {
            int ind1 = A.GetRowIndex(irow1, B.RowIndex[j]);
            if(ind1<0) continue;
            Diag[irow1] += A.Value[ind1] * B.Value[j];
        }
    }
    return Diag;
}


/***** OBSOLETE ????
double UMatrixSparse::GetRowTimesColIgnoreOffsetPow(int irow, int icol) const
{
    if(this==NULL || error!=U_OK)
    {
        return 0.;
    }
    if(Value==NULL || ColPtr==NULL || RowIndex==NULL || Ncol<=0 || Nrow!=Ncol)
    {
        return 0.;
    }
    if(AddTransposed && Nrow!=Ncol)
    {
        return 0.;
    }
    if(irow<0 || irow>=Nrow || icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSparse::GetRowTimesColIgnoreOffsetPow(). Arguments(s) out of range, icol=%d, irow=%d\n", icol, irow);
        return 0.;
    }

    double Prod = 0.;
    for(int j=ColPtr[icol]; j<ColPtr[icol+1]; j++)   // V * V
    {
        int ic = RowIndex[j];
        for(int k=ColPtr[ic]; k<ColPtr[ic+1]; k++)
        {
            if(RowIndex[k]==irow) {Prod += Value[k]*Value[j]; break;}
        }
    }
    if(AddTransposed)
    {
        for(int j=ColPtr[irow]; j<ColPtr[irow+1]; j++) // Vt * Vt
        {
            int ic = RowIndex[j];
            for(int k=ColPtr[ic]; k<ColPtr[ic+1]; k++)
            {
                if(RowIndex[k]==icol) {Prod += Value[k]*Value[j]; break;}
            }
        }
        for(int j=ColPtr[icol]; j<ColPtr[icol+1]; j++) // Vt * V
        {
            int ir = RowIndex[j];
            for(int k=ColPtr[irow]; k<ColPtr[irow+1]; k++)
            {
                if(RowIndex[k]==ir) {Prod += Value[k]*Value[j]; break;}
            }
        }
        int minrc = MIN(irow, icol);
        int maxrc = MAX(irow, icol);
        for(int m=0; m<Ncol; m++)                   // V  * Vt
        {
            int k1=-1;
            for(int k=ColPtr[m]; k<ColPtr[m+1]; k++)
            {
                if(RowIndex[k]==minrc)  k1 = k;
                if(RowIndex[k]==maxrc) {if(k1>=0) Prod += Value[k1]*Value[k]; break;}
            }
        }
    }
    return Prod;
}
******/
