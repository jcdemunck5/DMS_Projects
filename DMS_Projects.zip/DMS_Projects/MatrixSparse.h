#ifndef _MATRIXSPARSE_INCLUDED
#define _MATRIXSPARSE_INCLUDED


#include "Matrix.h"
#include "MatrixExpand.h"
#include "String.h"
#include "FileName.h"

class DLL_IO UMatrixSparse : public UMatrixExpand
{
    friend UMatrixSparse DLL_IO GetSparseATB(const UMatrixSparse& A, const UMatrixSparse& B);
    friend PMT_DP        DLL_IO GetDiagonalATB(const UMatrixSparse& A, const UMatrixSparse& B);
    friend PMT_DP        DLL_IO GetDiagonalAB(const UMatrixSparse& A, const UMatrixSparse& B);

public:
    UMatrixSparse(); 
    UMatrixSparse(ErrorType E); 
    UMatrixSparse(const UMatrixSparse& MS); 
    UMatrixSparse(const UMatrix& M);
    UMatrixSparse(int Nr, int Nc);
    ~UMatrixSparse();

    UMatrixSparse&      operator=(const UMatrixSparse& MS);
    UMatrixSparse       operator*(const UMatrixSparse& MS) const; 
    UMatrixSparse       operator*(const double* PostDiag) const; 

    UMatrixSparse&      operator*=(const UMatrixSparse& MS); 
    UMatrixSparse&      operator*=(double Factor); 
    UMatrixSparse       operator-(void)  const;

    double              operator[] (int index) const;

    ErrorType           GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&      GetProperties(UString Comment) const;
    int                 GetNrow(void)            const {if(this) return Nrow; return 0;}
    int                 GetNcol(void)            const {if(this) return Ncol; return 0;}
    int                 GetNvalue(void)          const {if(this) return Nval; return 0;}
    int                 GetNonZeroRowIndex(int icol, int iNZval) const;

    UMatrix             operator*(const UMatrix& M) const;
    ErrorType           MatVec(const UMatrix& Vec, UMatrix& Result) const;
    virtual ErrorType   MatVec(const double* Vec, int Nr, double* Result) const;
    virtual ErrorType   MatTVec(const double* Vec, int Nr, double* Result) const;
    double*             GetMatVec(const double* Vec, int Nr, int* Nrowout=NULL) const;
    double*             GetMatTVec(const double* Vec, int Nr, int* Nrowout=NULL) const;

    UMatrixSparse       GetSparseSQR(void) const;
    UMatrixSparse       GetSparseMTM(void) const;
    double              GetVTMV(const UMatrix& Vec) const;

    double              GetTrace(void) const;
    virtual double*     GetDiagonal(int matpow, const double* DiagMid) const;
    UMatrix             GetDiagonalAsMatrix(void) const;
    ErrorType           SandwichDiagonal(const UMatrix& Diag);
    ErrorType           PreMultiplyDiagonal(const UMatrix& Diag);
    bool                IsSymmetric(double Tol=1.e-13) const;

    ErrorType           SetNrow(int Nr);
    ErrorType           AddCollumn(const int* NZindex, double Val, int NNZ);
    ErrorType           AddCollumn(const int* NZindex, const double* Values, int NNZ);
    ErrorType           AddCollumn(const double* Col, int NrowAdded);
    ErrorType           RemoveCollumn(int icol);
    ErrorType           RemoveRow(int irow);
    ErrorType           RemoveSelectedCollumns(const int* icols, int NcSel);
    ErrorType           RemoveSelectedRows(const int* irows, int NrSel);

    ErrorType           SetSymmetricToeplitz(const double* Row, int N);
    ErrorType           SetBlockSymmetricToeplitz(const double* Rows, int NBlock, int NColBlock);
    ErrorType           SetBlockToeplitz(const double* ColRows, int NBlock, int NColBlock);
    ErrorType           PrintToLog(const char* Name, int irow, int NrowPrint, int icol, int NcolPrint) const;
    ErrorType           WriteXDR(UFileName Fout, bool ConvLog) const;
    
    ErrorType           SetElement(int i, int j, double Val);
    ErrorType           AddElement(int i, int j, double Val);
    double              GetElement(int i, int j) const;
    double*             GetMatrixFull(void) const;
    double*             GetCollumnFull(int icol) const;
    double*             GetRowFull(int irow) const;

    UMatrixSparse       GetCollumnSparse(int icol) const;
    UMatrixSparse       GetSelectedCollumnsSparse(const int* icols, int NrSel) const;
    UMatrixSparse       GetRowSparse(int irow) const;
    UMatrixSparse       GetSelectedRowsSparse(const int* irows, int NrSel) const;
    UMatrixSparse       GetRowTSparse(int irow) const;
    
    ErrorType           TestSetValueIndexPlus1(void);
    
    UMatrix             GetAxIsB(const UMatrix& B, bool TransMat=false);

protected:   
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;
    ErrorType           error;

    int                 Nrow;
    int                 Ncol;
    int                 Nval;
    int                 NcolAlloc;
    int                 NvalAlloc;
    double*             Value;         // Used: Nval
    int*                ColPtr;        // Used: Ncol+1
    int*                RowIndex;      // Used: Nval

    int                 GetRowIndex(int irow, int icol) const;
};

UMatrixSparse DLL_IO GetSparseATB(const UMatrixSparse& A, const UMatrixSparse& B);
PMT_DP        DLL_IO GetDiagonalATB(const UMatrixSparse& A, const UMatrixSparse& B);
PMT_DP        DLL_IO GetDiagonalAB(const UMatrixSparse& A, const UMatrixSparse& B);

#endif //_MATRIXSPARSE_INCLUDED
