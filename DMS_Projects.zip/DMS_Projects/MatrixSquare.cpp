/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    08-01-14   creation
  JdM    13-01-14   Many combinations tested with TestMatrix.cpp 
  JdM    10-05-14   Added NormalizeRows(), SetDataRandom(), SetData() and ApplyFunction()
  JdM    20-06-14   Added DeMeanRows(), NormalizeCols(), DeMeanCols()
  JdM    22-06-14   Removed (default) Decomp parameter from one of the constructors.
                    Added Select constructor
  JdM    05-07-14   Bug Fix. GetAxIsB(). Moment at which the Singular is tested.
  JdM    30-12-14   Added MaximizeElements()
  JdM    31-12-14   Added SetRangeElements()
  JdM    02-01-15   Added SetDataGaussian().
  JdM    18-01-15   Added SelectRowCol()
  JdM    22-03-15   Added MergeRows() and MergeCols()
  JdM    15-03-16   Added SetUnitVector(), SetUnitVectors() and SetPolynomials()
  JdM    20-03-16   Added SetBlock()
  JdM    26-04-16   Added ReverseRows() and ReverseCols()
  JdM    06-06-16   Added Shrink();
  JdM    22-06-16   Added AddElement()
  JdM    22-07-16   Added operator-()
                    Added operator* ( const UMatrix& Matrix)
  JdM    24-07-16   Added MergeCols(const double*, const double*, const double*, int)
  JdM    25-07-16   Added ShrinkRows()
  JdM    11-09-16   Added CopyCol()
  JdM    30-01-17   Added AddBlock() and SubtractBlock()
  JdM    02-02-17   Added ComputeSVD()
  JdM    15-03-17   Bug Fix: GetATxIsB(). Decompose matrix when not yet done so.
  JdM    30-08-17   Added ApplySquareRoot(), ApplyAbs() and ApplyInverse()
  JdM    22-04-18   Added MinimizeElements()
  JdM    07-07-18   Added SubstractCol() and SubstractRow(). Added parameters to DeMeanRows() and DeMeanCols()
                    NormalizeRows() and NormalizeCols(): added default parameters.
  */

#include "MatrixSquare.h"

UString UMatrixSquare::Properties = UString();

void UMatrixSquare::SetAllMembersDefault(void)
{
    error           = U_OK;
    Properties      = UString();

    Decomposed      = false;
    Singular        = true;
    NonNegDefinite  = false;
    LogAbsDet       = 0.;
    SignDetPos      = true;
    CholMat         = UMatrix();
    LUMat           = UMatrix();
    LUIndex         = NULL;
}
void UMatrixSquare::DeleteAllMembers(ErrorType E)
{
    delete[] LUIndex;
    SetAllMembersDefault();
    error = E;
}

UMatrixSquare::UMatrixSquare()
{
    SetAllMembersDefault();
}
UMatrixSquare::UMatrixSquare(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UMatrixSquare::UMatrixSquare(const UMatrix& Matrix)
{   
    SetAllMembersDefault();
    if(Matrix.Nrow != Matrix.Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::UMatrixSquare(). Argument UMatrix not square (Nrow, Ncol) = (%d,%d) .\n", Matrix.Nrow, Matrix.Ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    *this = Matrix;
}
UMatrixSquare::UMatrixSquare(const UMatrixSquare& Matrix)
{   
    SetAllMembersDefault();
    if(Matrix.Nrow != Matrix.Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::UMatrixSquare(). Argument UMatrixSquare not square (Nrow, Ncol) = (%d,%d) .\n", Matrix.Nrow, Matrix.Ncol);
        DeleteAllMembers(U_ERROR);
        return;
    }
    *this = Matrix;
}

UMatrixSquare::UMatrixSquare(const UMatrixSquare& Matrix, const bool* SelectRowCol) : UMatrix(Matrix, SelectRowCol)
{
    SetAllMembersDefault();
    if(UMatrix::GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::UMatrixSquare(). Setting base class with row/col selector .\n");
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(SelectRowCol==NULL) // Copy decomposition
    {
        Decomposed      = Matrix.Decomposed;
        Singular        = Matrix.Singular;
        NonNegDefinite  = Matrix.NonNegDefinite;
        LogAbsDet       = Matrix.LogAbsDet;
        SignDetPos      = Matrix.SignDetPos;
        CholMat         = Matrix.CholMat;
        LUMat           = Matrix.LUMat;
        if(Matrix.LUIndex)
        {
            LUIndex = new unsigned int[Matrix.Nrow];
            if(LUIndex)
            {
                for(int k=0; k<Nrow; k++) LUIndex[k] = Matrix.LUIndex[k];
            }
            else
            {
                CI.AddToLog("ERROR: UMatrixSquare::UMatrixSquare(). Memory allocation, Nrow = %d  . \n", Nrow);
                UMatrix::DeleteAllMembers(U_ERROR);
                DeleteAllMembers(U_ERROR);
            }
        }
    }
}

UMatrixSquare::~UMatrixSquare()
{
    DeleteAllMembers(U_OK);
}

UMatrixSquare& UMatrixSquare::operator=(const UMatrix& Matrix)
{
    if(this==NULL)
    {
        static UMatrixSquare M(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Object NULL.\n");
        return M;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if((Matrix.IsSquareType()!=true && Matrix.MT!=U_MAT_GENERAL)|| Matrix.Ncol!=Matrix.Nrow)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Argument matrix object not square.\n");
        return *this;
    }
    UMatrix::operator=(Matrix);
    if(UMatrix::GetError() != U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Copying base class. \n");
        return *this;
    }
    if(MT==U_MAT_GENERAL) MT = U_MAT_SQUARE;
    DeleteAllMembers(U_OK);
    return *this;
}

UMatrixSquare& UMatrixSquare::operator=(const UMatrixSquare& Matrix)
{
    if(this==NULL)
    {
        static UMatrixSquare M(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Object NULL.\n");
        return M;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(this==&Matrix) return *this;

    UMatrix::operator=(Matrix);
    if(UMatrix::GetError() != U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSquare::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    Decomposed      = Matrix.Decomposed;
    Singular        = Matrix.Singular;
    NonNegDefinite  = Matrix.NonNegDefinite;
    LogAbsDet       = Matrix.LogAbsDet;
    SignDetPos      = Matrix.SignDetPos;
    CholMat         = Matrix.CholMat;
    LUMat           = Matrix.LUMat;
    if(Matrix.LUIndex)
    {
        LUIndex = new unsigned int[Matrix.Nrow];
        if(LUIndex)
        {
            for(int k=0; k<Nrow; k++) LUIndex[k] = Matrix.LUIndex[k];
        }
        else
        {
            CI.AddToLog("ERROR: UMatrixSquare::operator=(). Memory allocation, Nrow = %d . \n", Nrow);
            UMatrix::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
        }
    }
    return *this;
}

UMatrixSquare UMatrixSquare::operator-(const UMatrixSquare& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-(). Object NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-(). Argument NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    return UMatrixSquare(UMatrix(*this) -((const UMatrix&)Matrix));
}

UMatrixSquare& UMatrixSquare::operator-=(const UMatrixSquare& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    UMatrix::operator-=((const UMatrix&)Matrix);
    DeleteAllMembers(UMatrix::GetError()); // Invalidate decomposition
    return *this;
}

UMatrixSquare UMatrixSquare::operator+(const UMatrixSquare& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator+(). Object NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator+(). Argument NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    return UMatrixSquare(UMatrix(*this) +((const UMatrix&)Matrix));
}

UMatrixSquare& UMatrixSquare::operator+=(const UMatrixSquare& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator+=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator+=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    UMatrix::operator+=((const UMatrix&)Matrix);
    DeleteAllMembers(UMatrix::GetError()); // Invalidate decomposition
    return *this;
}

UMatrixSquare UMatrixSquare::operator*(const double a) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(double). Object NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(double). Matrix data is NULL.\n");    
        return UMatrixSquare(U_ERROR);
    }

    UMatrixSquare Matrix(*this);
    Matrix *= a;

    return Matrix;
}
UMatrixSquare& UMatrixSquare::operator*=(const double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(MT==U_MAT_NULL) return *this;
    
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*=(double). Matrix data is NULL.\n");
        return *this;
    }

    UMatrix::operator*=(a);
    if(UMatrix::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(a==0.)
    {
        DeleteAllMembers(U_OK);
    }
    else
    {
        if(Singular==true)
        {
            DeleteAllMembers(U_OK);
        }
        else if(Decomposed==true)
        {
            if(NonNegDefinite)
            {
                if(a<0.)
                {
                    Decomposed = false;
                    LUMat      = UMatrix();
                    CholMat    = UMatrix();
                }
                else
                {
                    CholMat   *=(a);
                    LogAbsDet += Nrow * log(fabs(a));
                }
            }
            else
            {
                if(a<0. && Nrow%2) SignDetPos = NOT(SignDetPos);
                LogAbsDet += Nrow * log(fabs(a));
                LUMat     *= a;  //// ????
                CholMat    = UMatrix();
            }
        }
    }
    return *this;
}

UMatrixSquare& UMatrixSquare::operator/=(const double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator/=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==0.)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator/=(double). Erroneous argument: a=%20.15e.  \n", a);
        return *this;
    }
    if(MT==U_MAT_NULL) return *this;
    
    return (*this *= 1./a);
}

UMatrixSquare UMatrixSquare::operator*(const UMatrixSquare& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(). Object NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(). Argument NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    return UMatrixSquare(UMatrix(*this) * ((const UMatrix&)Matrix));
}
UMatrix UMatrixSquare::operator* ( const UMatrix& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*(). Argument NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix(*this) * ((const UMatrix&)Matrix);
}

UMatrixSquare& UMatrixSquare::operator*=(const UMatrixSquare& Matrix)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(Matrix.GetNcol()!=Matrix.GetNrow() || Ncol!=Matrix.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator*=(). Argument not a square matrix, or Nrow/Ncol do not match.\n");
        return *this;
    }
    UMatrix::operator*=((const UMatrix&)Matrix);
    DeleteAllMembers(U_OK);

    return *this;
}
UMatrixSquare UMatrixSquare::operator-(void)  const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-(). Object NULL or erroneous.\n");
        return UMatrixSquare(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;

    UMatrixSquare M(*this);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::operator-(). Copying *this.\n");
        return UMatrixSquare(U_ERROR);
    }
    
    int N       = M.GetNelem();
    double* pD  = Data;
    double* pMD = M.Data;
    for(int n=0; n<N; n++) *pMD++ = -(*pD++);

    if(M.MT==U_MAT_IDENTITY) M.MT = U_MAT_IDENTCONST;
    M.Decomposed = false;
    return M;
}
ErrorType UMatrixSquare::ForceGeneralType(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ForceGeneralType(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(MT==U_MAT_GENERAL) 
    {
        if(Nrow==Ncol) MT = U_MAT_SQUARE;
        return U_OK;
    }
    if(UMatrix::ForceGeneralType()!=U_OK) return U_ERROR;

    if(Nrow==Ncol) MT = U_MAT_SQUARE;
    Decomposed = false;
    return U_OK;
}
ErrorType UMatrixSquare::ForceSymmetricType(double RelRowError)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ForceSymmetricType(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(MT==U_MAT_SYMMETRIC) return U_OK;
    if(UMatrix::ForceSymmetricType(RelRowError)!=U_OK) return U_ERROR;

    Decomposed = false;
    return U_OK;
}

const UString& UMatrixSquare::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMatrixSquare() object.");
        return Properties;
    }
    Properties  = UString();

    Properties += UString(          "DECOMPOSED    = ") + BoolAsText(Decomposed) + " \n";
    Properties += UString(          "SINGULAR      = ") + BoolAsText(Singular)   + " \n";
    Properties += UString(LogAbsDet,"LOGABSDET     = %20.5e \n");
    if(SignDetPos) Properties += UString(          "SIGN_DET     = POSITIVE \n");
    else           Properties += UString(          "SIGN_DET     = NEGATIVE \n");
    Properties += UString(          "NONNEGATIVE   = ") + BoolAsText(NonNegDefinite)   + " \n";

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties += UMatrix::GetProperties(Comment);
    else                                      Properties += UMatrix::GetProperties(Comment+UString("   "));

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}
ErrorType UMatrixSquare::Shrink(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::Shrink(Lamda, Nzero);
}
ErrorType UMatrixSquare::ShrinkRows(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ShrinkRows(Lamda, Nzero);
}
ErrorType UMatrixSquare::SetData(double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetData(Value);
}
ErrorType UMatrixSquare::CopyCol(int icol, int DestBegin, int DestEnd)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::CopyCol(icol, DestBegin, DestEnd);
}

ErrorType UMatrixSquare::SetBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SetBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SetBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SetBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::SetBlock(row, col, Block);
}
ErrorType UMatrixSquare::AddBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::AddBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::AddBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::AddBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::AddBlock(row, col, Block);
}
ErrorType UMatrixSquare::SubtractBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SubtractBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SubtractBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }
    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SubtractBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::SubtractBlock(row, col, Block);
}
ErrorType UMatrixSquare::SetUnitVector(int iunit, int Ndim, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    CI.AddToLog("ERROR: UMatrixSquare::SetUnitVector(). Function cannot be used on derived class.\n");
    Decomposed = false;
    return U_ERROR;
}
ErrorType UMatrixSquare::SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SetUnitVectors(). Function cannot be used on derived class.\n");
        return U_ERROR;
    }
    Decomposed = false;
    return UMatrix::SetUnitVectors(MinUnit, MaxUnit, ColVect);
}
ErrorType UMatrixSquare::SetPolynomials(int MinDeg, int MaxDeg, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::SetPolynomials(). Function cannot be used on derived class.\n");
        return U_ERROR;
    }
    Decomposed = false;
    return UMatrix::SetPolynomials(MinDeg, MaxDeg, ColVect);
}

ErrorType UMatrixSquare::SetElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetElement(irow, icol, Value);
}
ErrorType UMatrixSquare::AddElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::AddElement(irow, icol, Value);
}
ErrorType UMatrixSquare::SetRow(int irow, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetRow(irow, Value);
}
ErrorType UMatrixSquare::SetCol(int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetRow(icol, Value);
}
ErrorType UMatrixSquare::SetDataRandom(double Amp, int seed)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSquare::SetDataRandom(). Matrix is identity.\n");
        return U_ERROR;
    }
    Decomposed = false;
    return UMatrix::SetDataRandom(Amp, seed);
}
ErrorType UMatrixSquare::SetDataGaussian(double Amp, int seed)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSquare::SetDataGaussian(). Matrix is identity.\n");
        return U_ERROR;
    }
    Decomposed = false;
    return UMatrix::SetDataGaussian(Amp, seed);
}
ErrorType UMatrixSquare::ApplyFunction(double (f) (double))
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyFunction(f);
}
ErrorType UMatrixSquare::ApplySquareRoot()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplySquareRoot();
}
ErrorType UMatrixSquare::ApplyAbs()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyAbs();
}
ErrorType UMatrixSquare::ApplyInverse()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyInverse();
}
ErrorType UMatrixSquare::MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::MinimizeElements(Thresh, Fabs, pSuperThreshold);
}
ErrorType UMatrixSquare::MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::MaximizeElements(Thresh, Fabs, pSubThreshold);
}
ErrorType UMatrixSquare::SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetRangeElements(Tmin, Tmax, pSubThreshold);
}
ErrorType UMatrixSquare::NormalizeRows(int skiprow1, int skiprow2, int skiprow3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::NormalizeRows(skiprow1, skiprow2, skiprow3);
}
ErrorType UMatrixSquare::NormalizeCols(int skipcol1, int skipcol2,int skipcol3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::NormalizeCols(skipcol1, skipcol2, skipcol3);
}
ErrorType UMatrixSquare::SubstractCol(int icol, int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::SubstractCol(icol, skipcol1, skipcol2);
}
ErrorType UMatrixSquare::SubstractRow(int irow, int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::SubstractRow(irow, skiprow1, skiprow2);
}
ErrorType UMatrixSquare::DeMeanRows(int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::DeMeanRows(skipcol1, skipcol2);
}
ErrorType UMatrixSquare::DeMeanCols(int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::DeMeanCols(skiprow1, skiprow2);
}
ErrorType UMatrixSquare::ReverseCols(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::ReverseCols();
}
ErrorType UMatrixSquare::ReverseRows(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::ReverseRows();
}
ErrorType UMatrixSquare::SelectRowCol(const bool* SelectRowCol)
{
    if(this==NULL || error!=U_OK       ) return U_ERROR;
    if(Data==NULL &&    MT!=U_MAT_NULL) return U_ERROR;

    if(SelectRowCol==NULL) return U_OK;

    Decomposed = false;
    return UMatrix::SelectRowCol(SelectRowCol, SelectRowCol);
}
ErrorType UMatrixSquare::MergeRows(const UMatrix& M)
{
    CI.AddToLog("ERROR: UMatrixSquare::MergeRows(). Merging rows not possible for UMatrixSquare. \n");
    return U_ERROR;
}
ErrorType UMatrixSquare::MergeCols(const UMatrix& M)
{
    CI.AddToLog("ERROR: UMatrixSquare::MergeCols(). Merging collumns not possible for UMatrixSquare. \n");
    return U_ERROR;
}
ErrorType UMatrixSquare::MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr)
{
    CI.AddToLog("ERROR: UMatrixSquare::MergeCols(). Merging collumns not possible for UMatrixSymmetric. \n");
    return U_ERROR;
}
ErrorType UMatrixSquare::ComputeSVD(UMatrixSquare& UU, UMatrixSquare& Lam, UMatrixSquare& VV) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ComputeSVD(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ComputeSVD(). Matrix not square (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
        return U_ERROR;
    }
    if(Data==NULL && MT!=U_MAT_NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ComputeSVD(). Data not set. \n");
        return U_ERROR;
    }

    UU  = UMatrixSquare();
    Lam = UMatrixSquare();
    VV  = UMatrixSquare();
    if(MT==U_MAT_NULL) return U_OK;

    UU  = *this;
    Lam = UMatrix(DNULL, Nrow);
    VV  = *this;
    if(UU.Data==NULL || UU.GetError()!=U_OK || Lam.Data==NULL || Lam.GetError()!=U_OK || VV.Data==NULL || VV.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ComputeSVD(). Creating output matrices (Nrow=%d, Ncol=%d). \n", Nrow, Ncol);
        return U_ERROR;
    }
    if (svdcmp_d(UU.Data, Nrow, Nrow, Lam.Data, VV.Data)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSquare::ComputeSVD(). Error in SVD decomposition.\n");
        UU  = UMatrixSquare(); Lam = UMatrixSquare(); VV  = UMatrixSquare();
        return U_ERROR;
    }
    return U_OK;
}

ErrorType UMatrixSquare::Decompose()
{
    if(Decomposed) return U_OK;

    if(UMatrix::MT!=U_MAT_NULL && Data==NULL) return U_ERROR;

    NonNegDefinite = false;
    ErrorType    E = U_OK;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :   Singular   = true;                   break;
    case U_MAT_IDENTITY  :   LogAbsDet  = 0.; 
                             SignDetPos = true; 
                             Singular   = false;                  break;
    case U_MAT_IDENTCONST:   LogAbsDet  = (Data[0]==0.) ? 0. : Nrow*log(fabs(Data[0])); 
                             SignDetPos = Data[0]>0.;          
                             Singular   = Data[0]==0.;            break;
    case U_MAT_DIAGONAL  :  {
                                LogAbsDet  = 0.;
                                SignDetPos = true;
                                Singular   = false;
                                for(int k=0; k<Nrow; k++)
                                {
                                    double Diag = Data[k];
                                    if(Diag==0)      {Singular   = true; LogAbsDet=0.; SignDetPos=false; break;}
                                    else if(Diag>0.) {LogAbsDet += log( Diag); }
                                    else             {LogAbsDet += log(-Diag); SignDetPos = NOT(SignDetPos);}
                                }
                                break;
                            }
    case U_MAT_SYMMETRIC :   E = Cholesky();
                             if(E!=U_OK && NOT(Singular)) E = LUDecompose(); break;
    case U_MAT_SQUARE    :   E = LUDecompose();                              break;
    default:
        CI.AddToLog("ERROR: UMatrixSquare::Decompose(). Matrix of wrong type (MT=%d) \n", int(MT));
        return U_ERROR;
    }
    Decomposed = true;
    if(E!=U_OK) 
    {
        Singular   = true;
        CI.AddToLog("ERROR: UMatrixSquare::Decompose(). Decomposition error. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMatrixSquare::Cholesky()
{
    if(UMatrix::MT!=U_MAT_SYMMETRIC)
    {
        Singular = false;
        CI.AddToLog("ERROR: UMatrixSquare::Cholesky(). Matrix of wrong type (MT = %d). \n", int(MT));
        return U_ERROR;
    }
    CholMat   = UMatrix(*this);
    if(CholMat.GetError()!=U_OK||CholMat.Data==NULL) 
    {
        Singular = true;
        CI.AddToLog("ERROR: UMatrixSquare::Cholesky(). Memory allocation, Nrow = %d. \n", Nrow);
        return U_ERROR;
    }

    LogAbsDet = 0.;
    for(int i=0; i<Nrow; i++)
    {  
        double SQ = 0.;
        for(int j=i; j<Nrow; j++)
        {  
            double        sum = CholMat.Data[j*Nrow+i];
            const double* pCi = CholMat.Data + i*Nrow;
            const double* pCj = CholMat.Data + j*Nrow;
            for(int k=0; k<i; k++) sum -= (*pCi++) * (*pCj++);

            if(i==j) 
            {  
                if(sum<=0.) 
                {
                    CholMat        = UMatrix();
                    Singular       = false;
                    LogAbsDet      = 0.;
                    NonNegDefinite = false;
                    CI.AddToLog("WARNING: UMatrixSquare::Cholesky(). Matrix not non-neg def, Nrow = %d, i = %d .\n", Nrow, i);
                    return U_ERROR;
                } 
                SQ                      = sqrt(sum);
                CholMat.Data[i*Nrow+i]  = SQ;
                LogAbsDet              += log(SQ);
            } 
            else
                CholMat.Data[j*Nrow+i]  = sum/SQ; 
        }
    }
    for(int i=1;i<Nrow;i++)
        for(int j=0;j<i;j++) CholMat.Data[j*Nrow+i] = CholMat.Data[i*Nrow+j];

    CholMat.MT     = U_MAT_SYMMETRIC;
    LogAbsDet     *= 2.;
    SignDetPos     = true; 
    Singular       = false;
    NonNegDefinite = true;
    return U_OK;
}
 
ErrorType UMatrixSquare::LUDecompose()
{
    const double TINY = 1.0e-20;
    if(Nrow!=Ncol || GetNelem()!=Nrow*Ncol)
    {
        Singular = false;
        CI.AddToLog("ERROR: UMatrixSquare::LUDecompose(). Matrix not square (MT = %d). \n", int(MT));
        return U_ERROR;
    }
    delete[] LUIndex; 
    LUIndex = new unsigned int[Nrow];
    LUMat   = *this;
    if(LUIndex==NULL || LUMat.GetError()!=U_OK || LUMat.Data==NULL) 
    {
        delete[] LUIndex; LUIndex=NULL;
        Singular = true;
        CI.AddToLog("ERROR: UMatrixSquare::LUDecompose(). Memory allocation, Nrow = %d. \n", Nrow);
        return U_ERROR;
    }

    double* vv = new double[Nrow];
    if(!vv) 
    {
        CI.AddToLog("ERROR: UMatrixSquare::LUDecompose(). Memory allocation. Nrow=%d\n", Nrow);
        return U_ERROR;
    }

    SignDetPos     = true; 
    for(int i=0; i<Nrow; i++) 
    {
        double big  = 0.0;
        double temp = 0.0;
        for(int j=0; j<Nrow; j++) if((temp=fabs(LUMat.Data[i*Nrow+j]))>big) big = temp;

        if(big == 0.0)  //Singular matrix in routine ludcmp
        {
            delete[] vv; 
            LUMat          = UMatrix();
            Singular       = true;
            LogAbsDet      = 0.;
            NonNegDefinite = false;
            CI.AddToLog("ERROR: UMatrixSquare::LUDecompose(). Matrix is singular. i=%d\n",i);
            return U_ERROR;
        }
        vv[i] = 1.0/big;
    }
    int imax = -1;
    for(int j=0; j<Nrow; j++) 
    {
        for(int i=0; i<j; i++) 
        {
            double sum = LUMat.Data[i*Nrow+j];
            for(int k=0; k<i; k++) sum -= LUMat.Data[i*Nrow+k]*LUMat.Data[k*Nrow+j];
            LUMat.Data[i*Nrow+j] = sum;
        }
        double big=0.0;
        
        for(int i=j; i<Nrow; i++) 
        {
            double sum = LUMat.Data[i*Nrow+j];
            double dum = 0;
            for(int k=0;k<j;k++) sum -= LUMat.Data[i*Nrow+k]*LUMat.Data[k*Nrow+j];
            LUMat.Data[i*Nrow+j] = sum;
            if( (dum=vv[i]*fabs(sum)) >= big) 
            {
                big  = dum;
                imax = i;
            }
        }
        if(j != imax) 
        {
            for(int k=0;k<Nrow;k++) 
            {
                double dum              = LUMat.Data[imax*Nrow+k];
                LUMat.Data[imax*Nrow+k] = LUMat.Data[j   *Nrow+k];
                LUMat.Data[j   *Nrow+k] = dum;
            }
            SignDetPos = NOT(SignDetPos);
            vv[imax]=vv[j];
        }
        LUIndex[j]=imax;
        if(LUMat.Data[j*Nrow+j] == 0.0) LUMat.Data[j*Nrow+j]=TINY;
        if(j != Nrow) 
        {
            double dum=1.0/(LUMat.Data[j*Nrow+j]);
            for(int i=j+1;i<Nrow;i++) LUMat.Data[i*Nrow+j] *= dum;
        }
    }
    delete[] vv;

    LogAbsDet = 0.;
    for(int i=0; i<Nrow; i++) LogAbsDet += log(fabs(LUMat.Data[i*Nrow+i]));
    
    LUMat.MT       = U_MAT_SQUARE;
    Singular       = false;
    NonNegDefinite = false;
    return U_OK;
}

double UMatrixSquare::GetSignDet()
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetSignDet(). Performing matrix decomposition. \n");
        return 0.;
    }
    if(Singular  ==true)          return 0.;

    return SignDetPos ? 1. : -1.;
}

double UMatrixSquare::GetLogAbsDet()
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Decomposed==false)
    {
        if(Decompose()!=U_OK) 
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetLogAbsDet(). Performing matrix decomposition. \n");
            return 0.;
        }
    }
    if(Singular  ==true)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetLogAbsDet(). Matrix is singular. \n");
        return 0.;
    }
    return LogAbsDet;
}
UMatrixSquare UMatrixSquare::GetInverse()
{
    if(this==NULL || error!=U_OK) return UMatrixSquare(U_ERROR);
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetInverse(). Performing matrix decomposition. \n");
        return UMatrixSquare(U_ERROR);
    }
    if(Singular  ==true)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetInverse(). Matrix is singular. \n");
        return UMatrixSquare(U_ERROR);
    }
    if(Data==NULL) UMatrixSquare(U_ERROR);

    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :  return UMatrixSquare(U_ERROR);
    case U_MAT_IDENTITY  :  return UMatrixSquare(UMatrix(Nrow));
    case U_MAT_IDENTCONST:  {
                                if(Data[0]==0.) UMatrixSquare(U_ERROR);
                                UMatrixSquare Min  = *this;
                                Min               /= (Data[0]*Data[0]);
                                Min.LogAbsDet      = -LogAbsDet;
                                return Min;
                            }
    case U_MAT_DIAGONAL  :  {
                                UMatrixSquare Min = *this;
                                for(int k=0; k<Nrow; k++)
                                {
                                    double Diag = Data[k];
                                    if(Diag==0)  return UMatrixSquare(U_ERROR);
                                    Min.Data[k] /= (Diag*Diag);
                                }
                                return Min;
                            }
    case U_MAT_SYMMETRIC :  if(NonNegDefinite)
                            {
                                UMatrixSquare Min = *this;
                                UMatrix       H((double*)NULL, Nrow, 1);
                                if(Min.GetError()!=U_OK|| H.GetError()!=U_OK)
                                {
                                    CI.AddToLog("ERROR: UMatrixSquare::GetInverse(). Constructing output matrix. \n");
                                    return UMatrixSquare(U_ERROR);
                                }
                                double* h   = H.Data;
                                for(int i=0; i<Nrow; i++)
                                {
                                    for(int k=0; k<Nrow; k++) h[k] = 0.;  // Solve: [L] hi=ei
                                    for(int k=i; k<Nrow; k++) 
                                    {  
                                        if(k==i) h[k] = 1.;
                                        for(int j=0;j<k;j++) h[k] -= CholMat.Data[j*Nrow+k]*h[j];
                                        h[k] /= CholMat.Data[k*Nrow+k];
                                    }   

                                    for(int k=i; k<Nrow; k++) Min.Data[k*Nrow+i]=h[k];     // Solve: [L]T xi = hi
                                    for(int j=Nrow-1;j>=i;j--)
                                    {
                                        double        sum = Min.Data[j*Nrow+i];
                                        const double* pCj = CholMat.Data+ j   *Nrow+j+1;
                                        const double* pM  =     Min.Data+(j+1)*Nrow+i  ;
                                        for(int k=j+1; k<Nrow; k++,pM+=Nrow) sum -= (*pCj++) * (*pM);
                                        Min.Data[j*Nrow+i] = sum/CholMat.Data[j*Nrow+j];
                                    }
                                }
                                for(int i=0;i<Nrow;i++) // Copy upper to lower part 
                                    for(int j=0;j<i;j++) Min.Data[j*Nrow+i] = Min.Data[i*Nrow+j];

                                Min.Decomposed = false;
                                return Min;
                            }
    case U_MAT_SQUARE    :  {
                                UMatrixSquare Min(Nrow);
                                if(Min.GetError()!=U_OK|| Min.ForceGeneralType()!=U_OK)
                                {
                                    CI.AddToLog("ERROR: UMatrixSquare::GetInverse(). Constructing output matrix. \n");
                                    return UMatrixSquare(U_ERROR);
                                }
                                Min.MT = U_MAT_SQUARE;
                                for(int i=0; i<Nrow; i++)
                                {
                                    int ii = -1;
                                    for(int j=0; j<Nrow; j++)
                                    {
                                        int ip               = LUIndex[j];
                                        double sum           = Min.Data[Nrow*ip+i];
                                        Min.Data[Nrow*ip+i]  = Min.Data[Nrow*j +i];
                                        const double* pLU    = LUMat.Data + j*Nrow+ii;
                                        const double* pX     = Min.Data   +ii*Nrow+i;
                                        if(ii!=-1)
                                            for(int k=ii;k<=j-1;k++,pX+=Nrow) sum -= (*pLU++) * (*pX);
                                        else 
                                            if(sum) ii=j;
                                        Min.Data[Nrow*j +i]  = sum;
                                    }
        
                                    for(int j=Nrow-1;j>=0;j--) 
                                    {
                                        double        sum  = Min.Data[Nrow*j +i];
                                        const double* pLU  = LUMat.Data + j   *Nrow+ j+1;
                                        const double* pX   = Min.Data   +(j+1)*Nrow+i  ;
                                        for(int k=j+1;k<Nrow;k++,pX+=Nrow) sum -= (*pLU++) * (*pX);

                                        Min.Data[Nrow*j +i] = sum/LUMat.Data[j*Nrow+j];
                                    }
                                }
                                Min.Decomposed    = false;
                                return Min;
                            }
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSquare::GetInverse(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrixSquare(U_ERROR);
}

UMatrix UMatrixSquare::GetATxIsB(const UMatrix& B)
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);
    if(&B  ==NULL || B.GetError()!=U_OK) return UMatrix(U_ERROR);

    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetATxIsB(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL || Data==NULL || Singular==true)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetATxIsB(). Matrix empty or singular.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=B.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetATxIsB(). Numbers of rows do not fit (Nrow=%d) and (B.Nrow=%d)\n", Nrow, B.Nrow);
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false)
    {
        if(Decompose()!=U_OK) 
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetATxIsB(). Performing matrix decomposition. \n");
            return UMatrix(U_ERROR);
        }
    }
    if(IsSymmetricType()==true) return GetAxIsB(B);

    UMatrix X = B;
    if(X.GetError()!=U_OK || X.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetATxIsB(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }

    int ii   = -1;
    int Nvec = B.Ncol;

    for(int ic=0; ic<Nvec; ic++)
    {
        for(int i=0;i<Nrow;i++) 
        {
            double sum   = X.Data[i*Nvec+ic];
            if(ii!=-1)
                for(int j=ii;j<=i-1;j++) sum -= LUMat.Data[j*Nrow+i]*X.Data[j*Nvec+ic];
            else 
                if(sum) ii=i;
            X.Data[i*Nvec+ic]  = sum/LUMat.Data[i*Nrow+i];
        }

        for(int i=Nrow-1;i>=0;i--) 
        {
            double sum = X.Data[i*Nvec+ic];
            for(int j=i+1;j<Nrow;j++) sum -= LUMat.Data[j*Nrow+i]*X.Data[j*Nvec+ic];

            X.Data[i*Nvec+ic] = sum;
        }

    /* Tested re-ordering of matrix elemeents on 01-09-99 */
        for(int i=0; i<Nrow; i++)
        {
            double  dum                = X.Data[        i *Nvec+ic];
            X.Data[        i *Nvec+ic] = X.Data[LUIndex[i]*Nvec+ic];
            X.Data[LUIndex[i]*Nvec+ic] = dum;
        }
    }
    return X;
}

UMatrix UMatrixSquare::GetAxIsB(const UMatrix& B, const bool* SelectRowCol)
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);
    if(&B  ==NULL || B.GetError()!=U_OK) return UMatrix(U_ERROR);

    if(Nrow!=B.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Numbers of rows do not fit (Nrow=%d) and (B.Nrow=%d)\n", Nrow, B.Nrow);
        return UMatrix(U_ERROR);
    }
    if(MT==U_MAT_NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Matrix empty or singular.\n");
        return UMatrix(U_ERROR);
    }
    if(SelectRowCol)
    {
        UMatrixSquare MS(*this, SelectRowCol);
        UMatrix       BS(B, SelectRowCol, NULL);
        if(MS.GetError()!=U_OK || BS.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Creating UMatrixSquare or UMatrix with selected rows/collumns. \n");
            return UMatrix(U_ERROR);
        }
        UMatrix XS = MS.GetAxIsB(BS, NULL);
        if(XS.GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Solving system on selected rows/collumns. \n");
            return UMatrix(U_ERROR);
        }
        if(XS.InsertZeroRows(SelectRowCol, Nrow)!=U_OK)
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Inserting zeroes at unselected rows. \n");
            return UMatrix(U_ERROR);
        }
        return XS;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(Singular==true)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Matrix singular.\n");
        return UMatrix(U_ERROR);
    }

    if(IsDiagonalType()==true || B.Ncol>=Nrow)
    {
        UMatrix Min = GetInverse();
        UMatrix X   = Min*B;

        if(X.GetError()!=U_OK || X.ForceGeneralType()!=U_OK || X.Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Inverting matrix or multipying inverse to input B. \n");
            return UMatrix(U_ERROR);
        }
        return X;
    }

    UMatrix X = B;
    if(X.GetError()!=U_OK || X.ForceGeneralType()!=U_OK || X.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSquare::GetAxIsB(). Creating output matrix. \n");
        return UMatrix(U_ERROR);
    }
    if(X.Nrow==X.Ncol) X.MT = U_MAT_SQUARE;
    int Nvec = B.Ncol;

    if(NonNegDefinite)
    {
        UMatrix H((double*)NULL, Nrow, 1);
        double* h = H.Data;
        for(int ic=0; ic<Nvec; ic++)
        {
            for(int k=0; k<Nrow; k++) h[k] = B.Data[k*Nvec+ic];  // Solve: Lh=b
            for(int k=0; k<Nrow; k++) 
            {  
                for(int j=0;j<k;j++) h[k] -= CholMat.Data[j*Nrow+k]*h[j];
                h[k] /= CholMat.Data[k*Nrow+k];
            }   

            for(int k=0; k<Nrow; k++) X.Data[k*Nvec+ic]=h[k];     // Solve: [L]Tx=h
            for(int j=Nrow-1;j>=0;j--)
            {
                for(int k=j+1; k<Nrow; k++) X.Data[j*Nvec+ic] -= CholMat.Data[j*Nrow+k]*X.Data[k*Nvec+ic];
                X.Data[j*Nvec+ic] /= CholMat.Data[j*Nrow+j];
            }
        }
        return X;
    }
    
    for(int ic=0; ic<Nvec; ic++)
    {
        int ii = -1;
        for(int j=0;j<Nrow;j++) 
        {
            int ip             = LUIndex[j];
            double sum         = X.Data[Nvec*ip+ic];
            X.Data[Nvec*ip+ic] = X.Data[Nvec*j +ic];
            const double* pLU  = LUMat.Data + j*Nrow+ii;
            const double* pX   = X.Data     +ii*Nvec+ic;
            if(ii!=-1)
                for(int k=ii;k<=j-1;k++,pX+=Nvec) sum -= (*pLU++) * (*pX);
            else 
                if(sum) ii=j;
            X.Data[Nvec*j +ic]  = sum;
        }
        
        for(int j=Nrow-1;j>=0;j--) 
        {
            double        sum  = X.Data[Nvec*j +ic];
            const double* pLU  = LUMat.Data + j   *Nrow+ j+1;
            const double* pX   = X.Data     +(j+1)*Nvec+ic  ;
            for(int k=j+1;k<Nrow;k++,pX+=Nvec) sum -= (*pLU++) * (*pX);

            X.Data[Nvec*j +ic] = sum/LUMat.Data[j*Nrow+j];
        }
    }
    return X;
}
