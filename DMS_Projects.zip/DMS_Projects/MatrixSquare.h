#ifndef _MATRIXSQUARE_INCLUDED
#define _MATRIXSQUARE_INCLUDED

#include "Matrix.h"

class DLL_IO UMatrixSquare : public UMatrix
{
public:
    UMatrixSquare();                                                    // default constructor -> empty matrix
    UMatrixSquare(ErrorType E);                                         // constructor used to return an empty, Erroneous matrix
    UMatrixSquare(const UMatrix& A);                                    // Copy constructor 
    UMatrixSquare(const UMatrixSquare& A);                              // Copy constructor 
    UMatrixSquare(const UMatrixSquare& A, const bool* SelectRowCol);    // Copy constructor with selector
    
    virtual ~UMatrixSquare();

    UMatrixSquare& operator= ( const UMatrix& M);
    UMatrixSquare& operator= ( const UMatrixSquare& M);
    UMatrixSquare  operator- ( const UMatrixSquare& M) const; 
    UMatrixSquare& operator-=( const UMatrixSquare& M); 
    UMatrixSquare  operator+ ( const UMatrixSquare& M) const; 
    UMatrixSquare& operator+=( const UMatrixSquare& M); 
    UMatrixSquare  operator* ( const UMatrixSquare& M) const; 
    UMatrix        operator* ( const UMatrix& M) const; 
    UMatrixSquare& operator*=( const UMatrixSquare& M); 
    UMatrixSquare  operator* ( const double a) const;
    UMatrixSquare& operator*=( const double a);
    UMatrixSquare& operator/=( const double a);
    UMatrixSquare operator-(void)  const;

    ErrorType               GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
   
    virtual ErrorType       SetData(double Value);
    virtual ErrorType       Shrink(double Lamda, int* Nzero=NULL);
    virtual ErrorType       ShrinkRows(double Lamda, int* Nzero=NULL);
    virtual ErrorType       SetBlock(int icol, int irow, const UMatrix& Block);
    virtual ErrorType       AddBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType       SubtractBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType       SetUnitVector(int iunit, int Ndim, bool ColVect);
    virtual ErrorType       SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect);
    virtual ErrorType       SetPolynomials(int MinDeg, int MaxDeg, bool ColVect);
    virtual ErrorType       SetElement(int irow, int icol, double Value);
    virtual ErrorType       AddElement(int irow, int icol, double Value);
    virtual ErrorType       SetRow(int irow, double Value);
    virtual ErrorType       SetCol(int icol, double Value);
    virtual ErrorType       CopyCol(int icol, int DestBegin, int DestEnd);
    virtual ErrorType       SetDataRandom(double Amp=1., int seed=0);
    virtual ErrorType       SetDataGaussian(double Amp=1., int seed=0);
    virtual ErrorType       ApplyFunction(double (f) (double));
    virtual ErrorType       ApplySquareRoot();
    virtual ErrorType       ApplyInverse();
    virtual ErrorType       ApplyAbs();
    virtual ErrorType       MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold=NULL);
    virtual ErrorType       MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold=NULL);
    virtual ErrorType       SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold=NULL);
    virtual ErrorType       NormalizeRows(int skiprow1=-1, int skiprow2=-1, int skiprow3=-1);
    virtual ErrorType       NormalizeCols(int skipcol1=-1, int skipcol2=-1, int skipcol3=-1);
    virtual ErrorType       DeMeanRows(int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType       DeMeanCols(int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType       SubstractCol(int icol, int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType       SubstractRow(int irow, int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType       ReverseCols(void);
    virtual ErrorType       ReverseRows(void);
    virtual ErrorType       SelectRowCol(const bool* SelectRowCol);
    virtual ErrorType       MergeRows(const UMatrix& M);
    virtual ErrorType       MergeCols(const UMatrix& M);
    virtual ErrorType       MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr);

    ErrorType               ComputeSVD(UMatrixSquare& UU, UMatrixSquare& Lam, UMatrixSquare& VV) const;

    UMatrixSquare           GetInverse(void);                       // These functions call Decompose()
    double                  GetSignDet(void);
    double                  GetLogAbsDet(void);
    UMatrix                 GetAxIsB(const UMatrix& B, const bool* SelectRowCol=NULL);
    UMatrix                 GetATxIsB(const UMatrix& B);
    virtual ErrorType       ForceGeneralType(void);
    virtual ErrorType       ForceSymmetricType(double RelRowError);

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    static UString          Properties;       // General property string.
    ErrorType               error;            // General error flag

    bool                    Decomposed;
    bool                    Singular;
    bool                    NonNegDefinite;
    double                  LogAbsDet;
    bool                    SignDetPos;
    UMatrix                 CholMat;
    UMatrix                 LUMat;
    unsigned int*           LUIndex;

    ErrorType               Decompose(void);  // Decompose in LU or Cholesky, when not yet done.
    ErrorType               Cholesky(void);
    ErrorType               LUDecompose(void);
};

#endif //_MATRIXSQUARE_INCLUDED
