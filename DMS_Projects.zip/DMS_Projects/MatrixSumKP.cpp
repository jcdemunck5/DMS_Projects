/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     Module for solving systems Ax=b, where A is the sum of Kronecker products */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    06-08-12   creation
  JdM    21-05-16   Remove MatOffset argument from virtual functions APredSolve() and ATimes()
  JdM    20-03-16   APredSolve(): remove obsolete TransA parameter
*/ 


#include "MatrixSumKP.h"

#include "Jacobi.h"
#include "FileName.h"


UString UMatrixSumKP::Properties       = UString();

void UMatrixSumKP::SetAllMembersDefault()
{
    error   = U_OK;
    NKP     = 0;
    MatPre     = NULL;
    MatPost    = NULL;
}
void UMatrixSumKP::DeleteAllMembers(ErrorType E)
{
    for(int n=0; n<NKP; n++)
    {
        if(MatPre ) delete MatPre [n];
        if(MatPost) delete MatPost[n];
    }
    delete[] MatPre ;
    delete[] MatPost;
    SetAllMembersDefault();
    error = E;
}
UMatrixSumKP::UMatrixSumKP()
{
    SetAllMembersDefault();
}
UMatrixSumKP::UMatrixSumKP(const UMatrixSumKP& MSKP)
{
    SetAllMembersDefault();
    *this = MSKP;
}
UMatrixSumKP::UMatrixSumKP(int dimX, const double* XX, int dimT, const double* TT)
{
    SetAllMembersDefault();
    if(dimX<=0 || XX==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Ivalid (NULL) argument(s), dimX=%d .\n", dimX);
        return;
    }
    if(dimT<=0 || TT==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Ivalid (NULL) argument(s), dimT=%d .\n", dimX);
        return;
    }
    NKP  = 1;
    MatPre  = new UJacobi*[1]; if(MatPre ) MatPre [0] = NULL;
    MatPost = new UJacobi*[1]; if(MatPost) MatPost[0] = NULL;
    if(MatPre ==NULL || MatPost==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Memory allocation, NKP=%d .\n", NKP);
        return;
    }
    MatPre [0] = new UJacobi(XX, dimX, false, false);    
    if(MatPre [0]==NULL || MatPre [0]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Creating UJacobi object1, dimX= .\n", dimX);
        return;
    }
    MatPost[0] = new UJacobi(TT, dimT, false, false);    
    if(MatPost[0]==NULL || MatPost[0]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Creating UJacobi object1, dimT= .\n", dimT);
        return;
    }
}
UMatrixSumKP::UMatrixSumKP(int dimX, const double* XX1, const double* XX2, int dimT, const double* TT1, const double* TT2)
{
    SetAllMembersDefault();
    if(dimX<=0 || XX1==NULL || XX2==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Ivalid (NULL) argument(s), dimX=%d .\n", dimX);
        return;
    }
    if(dimT<=0 || TT1==NULL || TT2==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Ivalid (NULL) argument(s), dimT=%d .\n", dimX);
        return;
    }
    NKP  = 2;
    MatPre  = new UJacobi*[2]; if(MatPre ) {MatPre [0] = MatPre [1] = NULL;}
    MatPost = new UJacobi*[2]; if(MatPost) {MatPost[0] = MatPost[1] = NULL;}
    if(MatPre ==NULL || MatPost==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Memory allocation, NKP=%d .\n", NKP);
        return;
    }
    MatPre [0] = new UJacobi(XX1, dimX, false, false);    
    MatPre [1] = new UJacobi(XX2, dimX, false, false);    
    if(MatPre [0]==NULL || MatPre [0]->GetError()!=U_OK ||
       MatPre [1]==NULL || MatPre [1]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Creating UJacobi object1 or 2, dimX= .\n", dimX);
        return;
    }
    MatPost[0] = new UJacobi(TT1, dimT, false, false);    
    MatPost[1] = new UJacobi(TT2, dimT, false, false);    
    if(MatPost[0]==NULL || MatPost[0]->GetError()!=U_OK ||
       MatPost[1]==NULL || MatPost[1]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::UMatrixSumKP(). Creating UJacobi object1 or 2, dimT= .\n", dimT);
        return;
    }
}
UMatrixSumKP::~UMatrixSumKP()
{
    DeleteAllMembers(U_OK);
}

UMatrixSumKP& UMatrixSumKP::operator=(const UMatrixSumKP& MSKP)
{
    if(this==NULL)
    {
        static UMatrixSumKP Def; Def.error = U_ERROR;
        CI.AddToLog("ERROR: UMatrixSumKP::operator=(). this==NULL. \n");
        return Def;
    }
    if(&MSKP==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::operator=(). Argument has NULL address. \n");
        return *this;
    }
    if(this==&MSKP) return *this;

    if(MSKP.NKP<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::operator=(). Argument has invalid number of objecs: MSKP.NKP=%d    . \n", MSKP.NKP);
        return *this;
    }
    DeleteAllMembers(U_OK);
    
    NKP  = MSKP.NKP;
    MatPre  = new UJacobi*[NKP]; if(MatPre ) for(int n=0; n<NKP; n++) MatPre [n]=NULL;
    MatPost = new UJacobi*[NKP]; if(MatPost) for(int n=0; n<NKP; n++) MatPost[n]=NULL;
    if(MatPre ==NULL || MatPost==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSumKP::operator=(). Memory allocation: MSKP.NKP=%d    . \n", MSKP.NKP);
        return *this;
    }

    for(int n=0; n<NKP; n++)
    {
        MatPre [n] = new UJacobi(*(MSKP.MatPre [n])); 
        MatPost[n] = new UJacobi(*(MSKP.MatPost[n])); 
        if(MatPre [n]==NULL || MatPre [n]->GetError()!=U_OK  ||
           MatPost[n]==NULL || MatPost[n]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSumKP::operator=(). Copying UJacobi object, n=%d \n", n);
            return *this;
        }
    }
    return *this;
}
const UString& UMatrixSumKP::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMatrixSumKP-object\n");
        return Properties;
    }
    Properties  =  UString();
    Properties +=  UString(NKP,"NKP          = %d \n");
    if(MatPre [0])   Properties +=  UString(MatPre [0]->GetNdim(),"DimPre       = %d \n");
    if(MatPost[0])   Properties +=  UString(MatPost[0]->GetNdim(),"DimPost      = %d \n");

    return Properties;
}
int UMatrixSumKP::GetNdimPre(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::GetNdimPre(). Object NULL or erroneous.\n");
        return 0;
    }
    if(MatPre ==NULL || MatPre [0]==NULL || MatPre [0]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::GetNdimPre(). Object not properly set.\n");
        return 0;
    }
    return MatPre [0]->GetNdim();
}
int UMatrixSumKP::GetNdimPost(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::GetNdimPost(). Object NULL or erroneous.\n");
        return 0;
    }
    if(MatPost ==NULL || MatPost [0]==NULL || MatPost [0]->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::GetNdimPost(). Object not properly set.\n");
        return 0;
    }
    return MatPost [0]->GetNdim();
}
    

ErrorType UMatrixSumKP::APredSolve(const double* Bvec, double* Xvec) const
{
    if(this==NULL || error!=U_OK)
    {
        return U_ERROR;
    }
    if(NKP<=0 || MatPre ==NULL || MatPost==NULL || MatPre [0]==NULL || MatPost[0]==NULL)
    {
        return U_ERROR;
    }
    if(Bvec==NULL || Xvec==NULL) return U_ERROR;

    int NDim1 = MatPre [0]->GetNdim();
    int NDim2 = MatPost[0]->GetNdim();

    for(int i=0, k=0; i<NDim1; i++)
    {
        for(int j=0; j<NDim2; j++, k++)
        {
            double Diag = 0;
            for(int n=0; n<NKP; n++) Diag += MatPre [n]->GetDiagElem(i)*MatPost[n]->GetDiagElem(j);

            if(Diag==0.) Xvec[k] = Bvec[k];
            else         Xvec[k] = Bvec[k]/Diag;
       }
    }
    return U_OK;
}
ErrorType UMatrixSumKP::ATimes(const double* Bvec, double* Xvec, bool Trans) const
{
    if(this==NULL || error!=U_OK)
    {
        return U_ERROR;
    }
    if(NKP<=0 || MatPre ==NULL || MatPost==NULL || MatPre [0]==NULL || MatPost[0]==NULL)
    {
        return U_ERROR;
    }
    if(Bvec==NULL || Xvec==NULL) return U_ERROR;


    int NDim1 = MatPre [0]->GetNdim();
    int NDim2 = MatPost[0]->GetNdim();
    int NDim  = NDim1*NDim2;
    
    double* Term = new double[NDim];
    if(Term==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSumKP::ATimes(). Memory allocation, NDim = %d.\n", NDim);
        return U_ERROR;
    }
    for(int k=0; k<NDim; k++) Xvec[k] = 0.;

    ErrorType E = U_OK;
    for(int n=0; n<NKP; n++)
    {
        for(int k=0; k<NDim; k++) Term[k] = Bvec[k];

        if(E==U_OK) E = MatPre [n]->MultiplyJA(Term, NDim2);
        if(E==U_OK) E = MatPost[n]->MultiplyAJ(Term, NDim1);

        if(E!=U_OK)
        {
            delete[] Term;
            CI.AddToLog("ERROR: UMatrixSumKP::ATimes(). Matrix multiplication, n = %d.\n", n);
            return U_ERROR;
        }
        for(int k=0; k<NDim; k++) Xvec[k] +=Term[k];       
    }
    delete[] Term;

    return U_OK;
}

