#ifndef _MATRIX_SUMKP_INCLUDED
#define _MATRIX_SUMKP_INCLUDED


#include "PreConBiConGrad.h"
#include "String.h"

class UJacobi;
class DLL_IO UMatrixSumKP : public UPreConBiConGrad
{
public:
    UMatrixSumKP(); 
    UMatrixSumKP(const UMatrixSumKP& MSKP); 
    UMatrixSumKP(int dimX, const double* XX, int dimT, const double* TT); 
    UMatrixSumKP(int dimX, const double* XX1, const double* XX2, int dimT, const double* TT1, const double* TT2); 
    ~UMatrixSumKP();

    UMatrixSumKP&       operator=(const UMatrixSumKP& MSKP);

    ErrorType           GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&      GetProperties(UString Comment) const;
    int                 GetNdimPre(void) const;
    int                 GetNdimPost(void) const;

protected:   
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;
    ErrorType           error;
    int                 NKP;
    UJacobi**           MatPre;  // Array of NKP square matrices representing first KP factors
    UJacobi**           MatPost; // Array of NKP square matrices representing second KP factors

    virtual ErrorType   APredSolve(const double* Bvec, double* Xvec) const;
    virtual ErrorType   ATimes(const double* Bvec, double* Xvec, bool Transx) const;
    virtual ErrorType   InitMat(void) {return U_OK;}
};

#endif//_MATRIX_SUMKP_INCLUDED
