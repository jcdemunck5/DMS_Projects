/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************************/
/*                                                                                  */
/*     GENERAL:                                                                     */
/*                                                                                  */
/*     This module contains a derivative of the UMatrix object, which is such that  */
/*     the matrix is symmetric (or diagonal, or identity, etc). Moreover, when      */
/*     the matrix is represented with M, it is decomposed as                        */
/*     if(MT==U_MAT_SYMMETRIC)                                                      */
/*          M = UMat Lamda UMat^t                                                   */
/*          if(InvWmat)    Minv = WMat SIGN(Lamda) WMat^t                           */
/*          else           M    = WMat SIGN(Lamda) WMat^t                           */
/*          Here Lamda contains ordered eigenvalues and UMat eigenvectors           */
/*                                                                                  */
/*     if(MT==U_MAT_DIAGONAL)                                                       */
/*          DiagIndex[] contains indices or diagonal ordering from large to small   */
/*                                                                                  */
/*      NNeigPos = Number of positive eigenvalues                                   */
/*      NNeigNeg = Number of negative eigenvalues                                   */
/*                                                                                  */
/*      NNeigPos+NNeigNeg <= Ncol (=Nrow)                                           */
/*                                                                                  */
/************************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    23-02-14   creation
  JdM    24-02-14   Tested and bug fixed GetAMAT() and GetATMA() for symmetric and diagonal case, BUT not for NNeg>0
  JdM    27-02-14   Added ComputeJointDiagonalize()
  JdM    01-03-14   Added Invert()
  JdM    10-05-14   Added NormalizeRows(), SetDataRandom(), SetData() and ApplyFunction()
  JdM    11-05-14   Bug Fix (?) GetInverse(). Diagonal case. Treatment of NPos and NNeg (was ignored?)
                    Added GetInvertSqrt() and InvertSqrt()
  JdM    31-05-14   UMatrixSymmetric(double*, int, int, bool). Allow NULL pointer and set MT U_MAT_SYMMETRIC in that case.
  JdM    02-06-14   Added Sqrt() and GetSqrt()
  JdM    17-06-14   UMatrixSymmetric::operator=(). Enforce symmetry with REL_SYMMETRY_ERROR if argument is not
  JdM    20-06-14   Added DeMeanRows(), NormalizeCols(), DeMeanCols()
                    Decompose(). Try ForceSymmetric() if *this is of wrong type
  JdM    02-11-14   Bug fix: GetAxIsB(). Test for singularity after decomposition is done.
  JdM    21-12-14   Added SetElement(). SeDataRandom(): test various conditions more precisely in order to keep symmetric matrix elements
                    Added identity constructor
  JdM    31-12-14   Added SetRangeElements()
  JdM    02-01-15   Added SetDataGaussian().
  JdM    13-01-15   Bug Fix. GetAxIsB(). Testing Decomposed && DeCompose()!=U_OK (in old code || was used instead of &&)
  JdM    17-01-15   Added GetEigenVector()
  JdM    18-01-15   Added SelectRowCol()
  JdM    20-01-15   BUG Fix GetAxIsB(). It was omitted to add arguments NPos and NNeg in computation of LamdaInv.Invert() and LamdaInv.GetAMAT()
  JdM    26-01-15   Added GetVTMV(), GetA1TMA2() and GetV1TMV2()
  JdM    22-03-15   Added MergeRows() and MergeCols()
  JdM    04-04-15   BUG FIX: GetEigenVector(). In case of U_MAT_SYMMETRIC, a row of UMat was returned, instead of a collumn
  JdM    06-04-15   UMatrix constructor: apply several tests and force symmetric type
  JdM    11-04-15   Added GetClusteringCoefficients()
  JdM    18-04-15   Added GetPathLenghtMatrix()
  JdM    10-10-15   Added sparse matrix constructor
  JdM    15-03-16   Added SetUnitVector(), SetUnitVectors() and SetPolynomials()
  JdM    20-03-16   Added SetBlock()
  JdM    26-04-16   Added ReverseRows() and ReverseCols()
  JdM    06-06-16   Added Shrink();
  JdM    22-06-16   Aded AddElement()
  JdM    22-07-16   Aded operator-()
  JdM    24-07-16   Added MergeCols(const double*, const double*, const double*, int)
  JdM    25-07-16   Added ShrinkRows()
  JdM    11-09-16   Added CopyCol()
  JdM    15-09-16   Added GetNormalizedEigen()
  JdM    01-10-16   BUG FIX: SetBlock(). Added first line: if(this==NULL || error!=U_OK)
  JdM    25-01-17   Added ResetDecomp()
  JdM    26-01-17   When argument NNeg==-1, set NNeg=NNeigNeg to include all negative eigenvalues in inverse ot matrix products.
                    Applied to: Invert(), GetInverse(), GetAxIsB(), GetAMAT(), GetATMA(), GetVTMV(), GetA1TMA2() and GetV1TMV2()
  JdM    30-01-17   Added AddBlock() and SubtractBlock()
  JdM    31-01-17   Added SwapCols() and SwapRows()
  JdM    05-02-17   Added GetEigenVectors()
  JdM    30-08-17   Added ApplySquareRoot(), ApplyAbs() and ApplyInverse()
  JdM    22-04-18   Added MinimizeElements()
  JdM    07-07-18   Added SubstractCol() and SubstractRow(). Added parameters to DeMeanRows() and DeMeanCols()
                    NormalizeRows() and NormalizeCols(): added default parameters.
  */

#include "MatrixSymmetric.h"
#include "MatrixSparse.h"
#include "DecompHermitian.h"
#include "Random.h"
#include "SortSemiSort.h"

static const double REL_SYMMETRY_ERROR      = 1.e-8;
UString UMatrixSymmetric::Properties        = UString();

static double ThirdPow(double x)
{
    if(x==0.) return 0.;
    if(x< 0.) return -ThirdPow(-x);
    return pow(x, 1./3.);
}

void UMatrixSymmetric::SetAllMembersDefault(void)
{
    error           = U_OK;
    Properties      = UString();

    Decomposed      = false;
    Singular        = true;
    LogAbsDet       = 0.;
    SignDetPos      = true;
    NNeigPos        = 0;
    NNeigNeg        = 0;
    Lamda           = UMatrix();
    UMat            = UMatrix();
    InvWmat         = false;
    WMat            = UMatrix();
    DiagIndex       = NULL;
}
void UMatrixSymmetric::DeleteAllMembers(ErrorType E)
{
    delete[] DiagIndex;
    SetAllMembersDefault();
    error = E;
}

UMatrixSymmetric::UMatrixSymmetric()
{
    SetAllMembersDefault();
}
UMatrixSymmetric::UMatrixSymmetric(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UMatrixSymmetric::UMatrixSymmetric(int nDim) : UMatrix(nDim)
{
    SetAllMembersDefault();
    error = UMatrix::GetError();
}

UMatrixSymmetric::UMatrixSymmetric(const double*Matrix, int nR, int nC, bool Decomp)
{
    SetAllMembersDefault();
    if(nR<=0 || nC<=0 || nR!=nC)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(double*, int, int). Invalid Argument(s) (nR=%d nC=%d) Matrix shouble be symmetric.\n", nR, nC);
        return;        
    }
    Nrow    = nR;
    Ncol    = nC;
    MT      = U_MAT_SQUARE;
    Data    = new double[Nrow*Ncol];
    if(!Data)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(double*, int, int). Memory allocation.\n");
        return;
    }
    if(Matrix)
    {
        for(int j=0;j<Nrow*Ncol;j++) Data[j] = Matrix[j];
        if(ForceSymmetricType(REL_SYMMETRY_ERROR)!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(double*, int, int). Data argument does represent symmetric matrix.\n");
            return;
        }
    }
    else
    {
        for(int j=0;j<Nrow*Ncol;j++) Data[j] = 0.;
        MT = U_MAT_SYMMETRIC;
    }
    if(Decomp) error = Decompose();
}
UMatrixSymmetric::UMatrixSymmetric(const UMatrixSparse& MS, bool Decomp)
{   
    SetAllMembersDefault();
    if(&MS==NULL || MS.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). NULL or erroneous sparse matrix argument.\n");
        return;
    }
    if(MS.IsSymmetric()==false)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). Argument sparse matrix is not symmetric.\n");
        return;
    }
    MT = U_MAT_SYMMETRIC;

    Nrow = MS.GetNrow();
    Ncol = MS.GetNcol();
    if(Nrow==0 && Ncol==0) return;
    if(Nrow<=0 || Ncol<=0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). Sparse matrix has wrong Nrow (%d) or Ncol (%d).\n", Nrow, Ncol);
        return;
    }
    Data = MS.GetMatrixFull();
    if(Data==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). Getting full matrix from argument, Nrow = %d, Ncol = %d.\n", Nrow, Ncol);
        return;
    }

    if(Decomp) error = Decompose();
}
UMatrixSymmetric::UMatrixSymmetric(const UMatrix& Matrix, bool Decomp)
{   
    SetAllMembersDefault();
    if(Matrix.Nrow!=Matrix.Ncol)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). Matrix argument not square (Nrow=%d, Ncol=%d).\n", Matrix.Nrow, Matrix.Ncol);
        return;
    }
    *this = Matrix;
    if(MT!=U_MAT_SYMMETRIC && ForceSymmetricType(1.e-9)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::UMatrixSymmetric(). Matrix is not symmetric and cannot be forced so.\n");
        return;
    }
    if(Decomp) error = Decompose();
}
UMatrixSymmetric::UMatrixSymmetric(const UMatrixSymmetric& Matrix)
{   
    SetAllMembersDefault();
    *this = Matrix;
}
UMatrixSymmetric::~UMatrixSymmetric()
{
    DeleteAllMembers(U_OK);
}

UMatrixSymmetric& UMatrixSymmetric::operator=(const UMatrix& Matrix)
{
    if(this==NULL)
    {
        static UMatrixSymmetric M(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Object NULL.\n");
        return M;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(Matrix.IsSymmetricType()!=true && Nrow!=Ncol)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Argument matrix object not symmetric.\n");
        return *this;
    }
    UMatrix::operator=(Matrix);
    if(UMatrix::GetError() != U_OK || UMatrix::ForceSymmetricType(REL_SYMMETRY_ERROR)!=U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Copying base class or forcing symmetry. \n");
        return *this;
    }
    DeleteAllMembers(U_OK);
    return *this;
}

UMatrixSymmetric& UMatrixSymmetric::operator=(const UMatrixSymmetric& Matrix)
{
    if(this==NULL)
    {
        static UMatrixSymmetric M(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Object NULL.\n");
        return M;
    }
    if(&Matrix==NULL || Matrix.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Argument NULL or erroneous.\n");
        return *this;
    }
    if(this==&Matrix) return *this;

    UMatrix::operator=(Matrix);
    if(UMatrix::GetError() != U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);
    Decomposed      = Matrix.Decomposed;
    Singular        = Matrix.Singular;
    LogAbsDet       = Matrix.LogAbsDet;
    SignDetPos      = Matrix.SignDetPos;
    NNeigPos        = Matrix.NNeigPos;
    NNeigNeg        = Matrix.NNeigNeg;
    Lamda           = Matrix.Lamda;
    UMat            = Matrix.UMat;
    InvWmat         = Matrix.InvWmat;
    WMat            = Matrix.WMat;
    if(Matrix.DiagIndex)
    {
        DiagIndex = new int[Matrix.Nrow];
        if(DiagIndex)
        {
            for(int k=0; k<Nrow; k++) DiagIndex[k] = Matrix.DiagIndex[k];
        }
        else
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::operator=(). Memory allocation, Nrow = %d . \n", Nrow);
            UMatrix::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
        }
    }
    return *this;
}

UMatrixSymmetric UMatrixSymmetric::operator-(const UMatrixSymmetric& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-(). Object NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-(). Argument NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    return UMatrixSymmetric(UMatrix(*this) -((const UMatrix&)Matrix));
}

UMatrixSymmetric& UMatrixSymmetric::operator-=(const UMatrixSymmetric& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    UMatrix::operator-=((const UMatrix&)Matrix);
    DeleteAllMembers(UMatrix::GetError()); // Invalidate decomposition
    return *this;
}

UMatrixSymmetric UMatrixSymmetric::operator+(const UMatrixSymmetric& Matrix) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator+(). Object NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator+(). Argument NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    return UMatrixSymmetric(UMatrix(*this) +((const UMatrix&)Matrix));
}

UMatrixSymmetric& UMatrixSymmetric::operator+=(const UMatrixSymmetric& Matrix) 
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator+=(). Object NULL or erroneous.\n");
        return *this;
    }
    if(&Matrix==NULL || Matrix.error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator+=(). Argument NULL or erroneous.\n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    UMatrix::operator+=((const UMatrix&)Matrix);
    DeleteAllMembers(UMatrix::GetError()); // Invalidate decomposition
    return *this;
}
UMatrix UMatrixSymmetric::operator*( const UMatrix& M) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator*(UMatrix&). Object NULL or erroneous.\n");
        return UMatrix(U_ERROR);
    }
    return UMatrix::operator*(M);
}

UMatrixSymmetric UMatrixSymmetric::operator*(const double a) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator*(double). Object NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;

    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator*(double). Matrix data is NULL.\n");    
        return UMatrixSymmetric(U_ERROR);
    }

    UMatrixSymmetric Matrix(*this);
    Matrix *= a;

    return Matrix;
}
UMatrixSymmetric& UMatrixSymmetric::operator*=(const double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator*=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(MT==U_MAT_NULL) return *this;
    
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator*=(double). Matrix data is NULL.\n");
        return *this;
    }

    UMatrix::operator*=(a);
    if(UMatrix::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    DeleteAllMembers(U_OK);
    return *this;
}

UMatrixSymmetric& UMatrixSymmetric::operator/=(const double a)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator/=(double). Object NULL or erroneous.\n");
        return *this;
    }
    if(a==0.)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator/=(double). Erroneous argument: a=%20.15e.  \n", a);
        return *this;
    }
    if(MT==U_MAT_NULL) return *this;
    
    return (*this *= 1./a);
}
UMatrixSymmetric UMatrixSymmetric::operator-(void)  const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-(). Object NULL or erroneous.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(MT==U_MAT_NULL) return *this;

    UMatrixSymmetric M(*this);
    if(M.GetError()!=U_OK || M.Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::operator-(). Copying *this.\n");
        return UMatrixSymmetric(U_ERROR);
    }
    
    int N       = M.GetNelem();
    double* pD  = Data;
    double* pMD = M.Data;
    for(int n=0; n<N; n++) *pMD++ = -(*pD++);

    if(M.MT==U_MAT_IDENTITY) M.MT = U_MAT_IDENTCONST;
    M.Decomposed = false;
    return M;
}

ErrorType UMatrixSymmetric::Shrink(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::Shrink(Lamda, Nzero);
}
ErrorType UMatrixSymmetric::ShrinkRows(double Lamda, int* Nzero)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    CI.AddToLog("ERROR: UMatrixSymmetric::ShrinkRows(). This function makes matrix asymmetric. \n");
    return U_ERROR;
}
ErrorType UMatrixSymmetric::CopyCol(int icol, int DestBegin, int DestEnd)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    CI.AddToLog("ERROR: UMatrixSymmetric::CopyCol(). This function makes matrix asymmetric. \n");
    return U_ERROR;
}
ErrorType UMatrixSymmetric::SetData(double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetData(Value);
}
ErrorType UMatrixSymmetric::SetDataRandom(double Amp, int seed)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    if(Data==NULL &&    MT!=U_MAT_NULL) return U_ERROR;

    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataRandom(). Matrix not square.\n");
        return U_ERROR;
    }
    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataRandom(). Matrix is identity.\n");
        return U_ERROR;
    }
    Decomposed = false;

    if(MT==U_MAT_NULL)
    {
        delete[] Data;
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::SetDataRandom(). Memory allocation. Nrow = %d, Ncol =%d.\n", Nrow, Ncol);
            return U_ERROR;
        }
        for(int ij=0; ij<Nrow*Ncol; ij++) Data[ij] = 0.;
        MT = U_MAT_SYMMETRIC;
    }
    else if(IsDiagonalType()==true) return UMatrix::SetDataRandom(Amp, seed);
    
    if(MT!=U_MAT_SYMMETRIC)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataRandom(). Matrix is not symmetric.\n");
        return U_ERROR;
    }

    int SeedPoint;
    if(seed<=0) 
    {
        time_t long_time;
        time( &long_time );
        SeedPoint = int(long_time);
    }
    else 
        SeedPoint = seed;
    srand(SeedPoint);

    int MaxRand = Nrow*Ncol;
    Amp         = Amp/MaxRand;
    for(int i=0; i<Nrow; i++)
        for(int j=i; j<Ncol; j++) Data[i*Ncol+j] = Data[j*Ncol+i] = Amp*double(rand() % MaxRand);
    return U_OK;
}
ErrorType UMatrixSymmetric::SetDataGaussian(double Amp, int seed)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(Data==NULL &&    MT!=U_MAT_NULL) return U_ERROR;

    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataGaussian(). Matrix not square.\n");
        return U_ERROR;
    }

    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataGaussian(). Matrix is identity.\n");
        return U_ERROR;
    }
    if(Amp<=0.)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataGaussian(). Invalid amplitude parameter (%f).\n", Amp);
        return U_ERROR;
    }

    Decomposed = false;
    if(MT==U_MAT_NULL)
    {
        delete[] Data;
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::SetDataGaussian(). Memory allocation. Nrow = %d, Ncol =%d.\n", Nrow, Ncol);
            return U_ERROR;
        }
        for(int ij=0; ij<Nrow*Ncol; ij++) Data[ij] = 0.;
        MT = U_MAT_SYMMETRIC;
    }
    else if(IsDiagonalType()==true) return UMatrix::SetDataGaussian(Amp, seed);
    
    if(MT!=U_MAT_SYMMETRIC)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetDataGaussian(). Matrix is not of U_MAT_SYMMETRIC type.\n");
        return U_ERROR;
    }

    UGaussian G(Amp, 0., seed);
    for(int i=0; i<Nrow; i++)
        for(int j=i; j<Ncol; j++) Data[i*Ncol+j] = Data[j*Ncol+i] = G.GetGaussian();
    return U_OK;
}
ErrorType UMatrixSymmetric::SetUnitVector(int iunit, int Ndim, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    CI.AddToLog("ERROR: UMatrixSymmetric::SetUnitVector(). Function cannot be used on derived class.\n");
    Decomposed = false;
    return U_ERROR;
}
ErrorType UMatrixSymmetric::SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    CI.AddToLog("ERROR: UMatrixSymmetric::SetUnitVectors(). Function cannot be used on derived class.\n");
    Decomposed = false;
    return U_ERROR;
}
ErrorType UMatrixSymmetric::SetPolynomials(int MinDeg, int MaxDeg, bool ColVect)
{
    if(this==NULL || error!=U_OK)        return U_ERROR;
    CI.AddToLog("ERROR: UMatrixSymmetric::SetPolynomials(). Function cannot be used on derived class.\n");
    Decomposed = false;
    return U_ERROR;
}

ErrorType UMatrixSymmetric::SetElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetElement(). Matrix not square.\n");
        return U_ERROR;
    }
    if(irow<0 || irow>=Nrow || icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetElement(). irow (=%d) or icol (=%d) out of range.\n", irow, icol);
        return U_ERROR;
    }
    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSymmetric::SetElement(). Matrix is identity.\n");
        return U_ERROR;
    }
    Decomposed = false;

    if(MT==U_MAT_NULL)
    {
        delete[] Data;
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::SetElement(). Memory allocation. Nrow = %d, Ncol =%d.\n", Nrow, Ncol);
            return U_ERROR;
        }
        for(int ij=0; ij<Nrow*Ncol; ij++) Data[ij] = 0.;
        MT = U_MAT_SYMMETRIC;
    }
    else if(IsDiagonalType()==true && irow==icol) return UMatrix::SetElement(irow, icol, Value);
    
    if(MT!=U_MAT_SYMMETRIC)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetElement(). Matrix is not symmetric.\n");
        return U_ERROR;
    }

    Data[irow*Ncol+icol] = Data[icol*Ncol+irow] = Value;
    return U_OK;
}
ErrorType UMatrixSymmetric::AddElement(int irow, int icol, double Value)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddElement(). Matrix not square.\n");
        return U_ERROR;
    }
    if(irow<0 || irow>=Nrow || icol<0 || icol>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddElement(). irow (=%d) or icol (=%d) out of range.\n", irow, icol);
        return U_ERROR;
    }
    if(Value==0.) return U_OK;
    if(MT==U_MAT_IDENTITY)
    { 
        CI.AddToLog("ERROR: UMatrixSymmetric::AddElement(). Matrix is identity.\n");
        return U_ERROR;
    }
    Decomposed = false;

    if(MT==U_MAT_NULL)
    {
        delete[] Data;
        Data = new double[Nrow*Ncol];
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::AddElement(). Memory allocation. Nrow = %d, Ncol =%d.\n", Nrow, Ncol);
            return U_ERROR;
        }
        for(int ij=0; ij<Nrow*Ncol; ij++) Data[ij] = 0.;
        MT = U_MAT_SYMMETRIC;
    }
    else if(IsDiagonalType()==true && irow==icol) return UMatrix::AddElement(irow, icol, Value);
    
    if(MT!=U_MAT_SYMMETRIC)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddElement(). Matrix is not symmetric.\n");
        return U_ERROR;
    }

    Data[irow*Ncol+icol] += Value;
    Data[icol*Ncol+irow]  = Data[irow*Ncol+icol];
    return U_OK;
}
ErrorType UMatrixSymmetric::SetBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(col!=row || Block.IsSymmetricType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SetBlock(). Symmetry of result not warranted (row, col) = (%d, %d), Block.MT=%d. \n", row, col, Block.MT);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::SetBlock(row, col, Block);
}
ErrorType UMatrixSymmetric::AddBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(col!=row || Block.IsSymmetricType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::AddBlock(). Symmetry of result not warranted (row, col) = (%d, %d), Block.MT=%d. \n", row, col, Block.MT);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::AddBlock(row, col, Block);
}
ErrorType UMatrixSymmetric::SubtractBlock(int col, int row, const UMatrix& Block)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SubtractBlock(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&Block==NULL || Block.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SubtractBlock(). UMatrix argument NULL or erroneous.\n");
        return U_ERROR;
    }

    if(row<0 || row+Block.Nrow>Nrow ||
       col<0 || col+Block.Ncol>Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SubtractBlock(). Parameter(s) out of range (row, col) = (%d, %d). \n", row, col);
        return U_ERROR;
    }
    if(col!=row || Block.IsSymmetricType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::SubtractBlock(). Symmetry of result not warranted (row, col) = (%d, %d), Block.MT=%d. \n", row, col, Block.MT);
        return U_ERROR;
    }

    Decomposed = false;
    return UMatrix::SubtractBlock(row, col, Block);
}

ErrorType UMatrixSymmetric::ApplyFunction(double (f) (double))
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyFunction(f);
}
ErrorType UMatrixSymmetric::ApplySquareRoot()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplySquareRoot();
}
ErrorType UMatrixSymmetric::ApplyAbs()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyAbs();
}
ErrorType UMatrixSymmetric::ApplyInverse()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::ApplyInverse();
}
ErrorType UMatrixSymmetric::MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::MinimizeElements(Thresh, Fabs, pSuperThreshold);
}
ErrorType UMatrixSymmetric::NormalizeRows(int skiprow1, int skiprow2, int skiprow3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::NormalizeRows(skiprow1, skiprow2, skiprow3);
}
ErrorType UMatrixSymmetric::NormalizeCols(int skipcol1, int skipcol2,int skipcol3)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::NormalizeCols(skipcol1, skipcol2, skipcol3);
}
ErrorType UMatrixSymmetric::MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::MaximizeElements(Thresh, Fabs, pSubThreshold);
}
ErrorType UMatrixSymmetric::SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return UMatrix::SetRangeElements(Tmin, Tmax, pSubThreshold);
}
ErrorType UMatrixSymmetric::SubstractCol(int icol, int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::SubstractCol(icol, skipcol1, skipcol2);
}
ErrorType UMatrixSymmetric::SubstractRow(int irow, int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::SubstractRow(irow, skiprow1, skiprow2);
}
ErrorType UMatrixSymmetric::DeMeanRows(int skipcol1, int skipcol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::DeMeanRows(skipcol1, skipcol2);
}
ErrorType UMatrixSymmetric::DeMeanCols(int skiprow1, int skiprow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    Decomposed = false;
    return UMatrix::DeMeanCols(skiprow1, skiprow2);
}
ErrorType UMatrixSymmetric::ReverseCols(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL) return U_OK;

    CI.AddToLog("WARNING: UMatrixSymmetric::ReverseCols(). Matrix no longer guarateed symmetric.\n");
    Decomposed = false;
    return UMatrix::ReverseCols();
}
ErrorType UMatrixSymmetric::ReverseRows(void)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL) return U_OK;
    
    CI.AddToLog("WARNING: UMatrixSymmetric::ReverseRows(). Matrix no longer guarateed symmetric.\n");
    Decomposed = false;
    return UMatrix::ReverseRows();
}
ErrorType UMatrixSymmetric::SwapCols(int icol1, int icol2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL) return U_OK;
    if(icol1==icol2)   return U_OK;

    CI.AddToLog("WARNING: UMatrixSymmetric::SwapCols(). Matrix no longer guarateed symmetric.\n");
    Decomposed = false;
    return UMatrix::SwapCols(icol1, icol2);
}
ErrorType UMatrixSymmetric::SwapRows(int irow1, int irow2)
{
    if(this==NULL || error!=U_OK) return U_ERROR;
    if(MT==U_MAT_NULL) return U_OK;
    if(irow1==irow2)   return U_OK;

    CI.AddToLog("WARNING: UMatrixSymmetric::SwapRows(). Matrix no longer guarateed symmetric.\n");
    Decomposed = false;
    return UMatrix::SwapRows(irow1, irow2);
}

ErrorType UMatrixSymmetric::SelectRowCol(const bool* SelectRowCol)
{
    if(this==NULL || error!=U_OK       ) return U_ERROR;
    if(Data==NULL &&    MT!=U_MAT_NULL) return U_ERROR;

    if(SelectRowCol==NULL) return U_OK;

    Decomposed = false;
    return UMatrix::SelectRowCol(SelectRowCol, SelectRowCol);
}
ErrorType UMatrixSymmetric::MergeRows(const UMatrix& M)
{
    CI.AddToLog("ERROR: UMatrixSymmetric::MergeRows(). Merging rows not possible for UMatrixSymmetric. \n");
    return U_ERROR;
}
ErrorType UMatrixSymmetric::MergeCols(const UMatrix& M)
{
    CI.AddToLog("ERROR: UMatrixSymmetric::MergeCols(). Merging collumns not possible for UMatrixSymmetric. \n");
    return U_ERROR;
}
ErrorType UMatrixSymmetric::MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr)
{
    CI.AddToLog("ERROR: UMatrixSymmetric::MergeCols(). Merging collumns not possible for UMatrixSymmetric. \n");
    return U_ERROR;
}

const UString& UMatrixSymmetric::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMatrixSymmetric() object.");
        return Properties;
    }
    Properties  = UString();

    Properties += UString(          "DECOMPOSED    = ") + BoolAsText(Decomposed) + " \n";
    Properties += UString(          "SINGULAR      = ") + BoolAsText(Singular)   + " \n";
    Properties += UString(LogAbsDet,"LOGABSDET     = %20.5e \n");
    Properties += UString(NNeigPos ,"NPosEigenVal  = %d  \n");
    Properties += UString(NNeigNeg ,"NNegEigenVal  = %d  \n");
    if(SignDetPos) Properties += UString(          "SIGN_DET     = POSITIVE \n");
    else           Properties += UString(          "SIGN_DET     = NEGATIVE \n");

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties += UMatrix::GetProperties(Comment);
    else                                      Properties += UMatrix::GetProperties(Comment+UString("   "));

    if(Comment.IsNULL() || Comment.IsEmpty()) Properties.ReplaceAll('\n', ';');
    else                                      Properties.InsertAtEachLine(Comment);

    return Properties;
}

int UMatrixSymmetric::GetNPosEig(double RelAverAbsEigenThresh)
{
    if(this==NULL || error!=U_OK) return -1;
    
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: GetNPosEig(). Data not properly set. \n");
        return -1;
    }
    if(RelAverAbsEigenThresh<0.)
    {
        CI.AddToLog("ERROR: GetNPosEig(). Threshold parameter out of range (%f). \n", RelAverAbsEigenThresh);
        return -1;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNPosEig(). Performing matrix decomposition. \n");
        return -1;
    }

    int NPos = 0;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :                  NPos = 0; break;
    case U_MAT_IDENTITY  :                  NPos = 1<RelAverAbsEigenThresh ? 0 : Ncol; break;
    case U_MAT_IDENTCONST:
        if(Data[0]<RelAverAbsEigenThresh)   NPos = 0; 
        else                                NPos = Ncol; 
        break;
    case U_MAT_DIAGONAL  :  
        {
            if(Ncol<=0) return -1;
            double Aver = 0;
            for(int k=0; k<Ncol; k++) Aver += fabs(Data[k]);
            if(Aver==0.) return 0;
            Aver /= Ncol;
            NPos  = GetNLarger(Data, Ncol, Aver*RelAverAbsEigenThresh);
        }
        break;
    case U_MAT_SYMMETRIC :  
        {
            if(Ncol<=0) return -1;
            double Aver = 0;
            for(int k=0; k<Ncol; k++) Aver += fabs(Lamda.Data[k]);
            if(Aver==0.) return 0;
            Aver /= Ncol;
            NPos  = GetNLarger(Lamda.Data, Ncol, Aver*RelAverAbsEigenThresh);
        }
        break;
    default:
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNPosEig(). Matrix of wrong type (MT=%d) \n", int(MT));
        return -1;
    }
    if(NPos>NNeigPos)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNPosEig(). NPos (%d) out of range (NNeigPos=%d) \n", NPos, NNeigPos);
        return -1;
    }
    return NPos;
}
int UMatrixSymmetric::GetNNegEig(double RelAverAbsEigenThresh)
{
    if(this==NULL || error!=U_OK) return -1;
    
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: GetNNegEig(). Data not properly set. \n");
        return -1;
    }
    if(RelAverAbsEigenThresh<0.)
    {
        CI.AddToLog("ERROR: GetNNegEig(). Threshold parameter out of range (%f). \n", RelAverAbsEigenThresh);
        return -1;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNNegEig(). Performing matrix decomposition. \n");
        return -1;
    }

    int NNeg = 0;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL      :                  NNeg = 0; break;
    case U_MAT_IDENTITY  :                  NNeg = 0; break;
    case U_MAT_IDENTCONST:
        if(Data[0]<-RelAverAbsEigenThresh)  NNeg = Ncol;
        else                                NNeg = 0;
        break;
    case U_MAT_DIAGONAL  :  
        {
            if(Ncol<=0) return -1;
            double Aver = 0;
            for(int k=0; k<Ncol; k++) Aver += fabs(Data[k]);
            if(Aver==0.) return 0;
            Aver /= Ncol;
            NNeg  = GetNSmaller(Data, Ncol, -Aver*RelAverAbsEigenThresh);
        }
        break;
    case U_MAT_SYMMETRIC :  
        {
            if(Ncol<=0) return -1;
            double Aver = 0;
            for(int k=0; k<Ncol; k++) Aver += fabs(Lamda.Data[k]);
            if(Aver==0.) return 0;
            Aver /= Ncol;
            NNeg  = GetNSmaller(Lamda.Data, Ncol, -Aver*RelAverAbsEigenThresh);
        }
        break;
    default:
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNNegEig(). Matrix of wrong type (MT=%d) \n", int(MT));
        return -1;
    }
    if(NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNNegEig(). NNeg (%d) out of range (NNeigNeg=%d) \n", NNeg, NNeigNeg);
        return -1;
    }
    return NNeg;
}

UMatrix UMatrixSymmetric::GetAMAT(const UMatrix& A, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(A.GetNcol()!=Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Number of A.Ncol (%d) does not match Nrow (%d)\n", A.GetNcol(), Nrow);
        return UMatrix(U_ERROR);
    }
    if(UpdateWmat(InvertM)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Updating Wmat.\n");
        return UMatrix(U_ERROR);
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;
    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
        return UMatrix(U_ERROR);
    }
    if(A.IsDiagonalType()) return GetADiagMADiag(A, InvertM, NPos, NNeg);

    UMatrix AMAT;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :   return AMAT;
    case U_MAT_IDENTITY  :   
        AMAT = A.GetMMT();
        break;
    case U_MAT_IDENTCONST:   
        AMAT = A.GetMMT();
        if(    NOT(InvertM)) AMAT*= Data[0];
        else if(Data[0]==0.) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Matrix singular.\n");
            return UMatrix(U_ERROR);
        }
        else                 AMAT/= Data[0];
        break;
    case U_MAT_DIAGONAL  :  
        {
            AMAT = UMatrix((double*)NULL, A.Nrow, A.Nrow);
            if(AMAT.GetError()!=U_OK || AMAT.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Creating output matrix, diagonal case.\n");
                return UMatrix(U_ERROR);
            }
            for(int i1=0; i1<A.Nrow; i1++)
            {
                for(int i2=0; i2<A.Nrow; i2++)
                {
                    if(i2>=i1)
                    {
                        double  Imp   = 0.;
                        const double* M1 = A.Data+i1*A.Ncol;
                        const double* M2 = A.Data+i2*A.Ncol;

                        if(InvertM)
                        {
                            for(int k=0; k<Nrow; k++) 
                            {
                                if(Data[DiagIndex[k]]==0.) continue;
                                if(k<NPos || k>=Nrow-NNeg) Imp += (M1[DiagIndex[k]] * M2[DiagIndex[k]]) / Data[DiagIndex[k]];
                            }
                        }
                        else
                        {
                            for(int k=0; k<Nrow; k++) 
                                if(k<NPos || k>=Nrow-NNeg) Imp += (M1[DiagIndex[k]] * M2[DiagIndex[k]]) * Data[DiagIndex[k]];
                        }
                        AMAT.Data[i1*A.Nrow+i2] = Imp;
                    }
                    else
                    {
                        AMAT.Data[i1*A.Nrow+i2]  = AMAT.Data[i2*A.Nrow+i1];
                    }
                }
            }
        }
        break;
    case U_MAT_SYMMETRIC :  
        {
            AMAT = UMatrix((double*)NULL, A.Nrow, A.Nrow);
            if(AMAT.GetError()!=U_OK || AMAT.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Creating output matrix, symmetric case.\n");
                return UMatrix(U_ERROR);
            }
            UMatrix WmatTAT = GetMatMul(WMat, true, A, true);
            if(WmatTAT.GetError()!=U_OK || WmatTAT.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Computing WmatTAT.\n");
                return UMatrix(U_ERROR);
            }

            const double* pWmatTAT = WmatTAT.Data;
            for(int i1=0; i1<A.Nrow; i1++)
            {
                for(int i2=0; i2<A.Nrow; i2++)
                {
                    if(i2>=i1)
                    {
                        double        Imp  = 0.;
                        const double* pW1  = pWmatTAT+i1;
                        const double* pW2  = pWmatTAT+i2;
                        for(int k=0; k<NPos; k++, pW1+=A.Nrow, pW2+=A.Nrow) Imp += *pW1 * *pW2;

                        pW1  = pWmatTAT+i1+A.Nrow*(Ncol-1);
                        pW2  = pWmatTAT+i2+A.Nrow*(Ncol-1);
                        for(int k=0; k<NNeg; k++, pW1-=A.Nrow, pW2-=A.Nrow) Imp -= *pW1 * *pW2;
                        AMAT.Data[i1*A.Nrow+i2] = Imp;
                    }
                    else
                    {
                        AMAT.Data[i1*A.Nrow+i2]  = AMAT.Data[i2*A.Nrow+i1];
                    }
                }
            }
        }
        break;
    default:
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAMAT(). Matrix of wrong type (MT=%d) \n", int(MT));
        return UMatrix(U_ERROR);
    }
    AMAT.MT  = U_MAT_SYMMETRIC;
    return AMAT;
}
UMatrix UMatrixSymmetric::GetA1TMA2(const UMatrix& A1, const UMatrix& A2, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(Ncol!=A1.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Number of Ncol (%d) does not match A1.Ncol (%d)\n", Ncol, A1.GetNcol());
        return UMatrix(U_ERROR);
    }
    if(Ncol!=A2.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Number of Ncol (%d) does not match A2.Nrow (%d)\n", Nrow, A2.GetNrow());
        return UMatrix(U_ERROR);
    }
    if(UpdateWmat(InvertM)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Updating Wmat.\n");
        return UMatrix(U_ERROR);
    }
    UMatrix X;
    if(InvertM)
    {
        if(NPos==-1) NPos=NNeigPos;
        if(NNeg==-1) NNeg=NNeigNeg;
        if(NPos<0 || NPos>NNeigPos || 
           NNeg<0 || NNeg>NNeigNeg)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
            return UMatrix(U_ERROR);
        }

        X = GetAxIsB(A2, NPos, NNeg);
    }
    else
    {
        X = *this * A2;
    }
    if(X.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetA1TMA2(). Computing *this * A2, or (*this)inverse * A2 . \n");
        return UMatrix(U_ERROR);
    }
    return GetMatMul(A1, true, X, false);
}
double UMatrixSymmetric::GetVTMV(const UMatrix& V, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) 0.;
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetVTMV(). Data not properly set. \n");
        return  0.;
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetVTMV(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return 0.;
    }
    if(Ncol!=V.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetVTMV(). Number of Ncol (%d) does not match A.Nrow (%d)\n", Ncol, V.GetNrow());
        return 0.;
    }
    if(V.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetVTMV(). Matrix argument has multiple collumns (%d).\n", V.GetNcol());
        return 0.;
    }
    UMatrix S = GetATMA(V, InvertM, NPos, NNeg);
    if(S.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetVTMV(). Computing VTMV.\n");
        return 0.;
    }
    return S.Data[0];
}
double UMatrixSymmetric::GetV1TMV2(const UMatrix& V1, const UMatrix& V2, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) 0.;
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetV1TMV2(). Data not properly set. \n");
        return  0.;
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetV1TMV2(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return 0.;
    }
    if(Ncol!=V1.GetNrow() || Ncol!=V2.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetV1TMV2(). Number of Ncol (%d) does not match V1.Nrow (%d) or V2.Nrow (%d) .\n", Ncol, V1.GetNrow(), V2.GetNrow());
        return 0.;
    }
    if(V1.GetNcol()!=1 || V2.GetNcol()!=1)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetV1TMV2(). Matrix argument has multiple collumns (V1.Ncol=%d, V2.Ncol=%d).\n", V1.GetNcol(), V2.GetNcol());
        return 0.;
    }
    UMatrix S = GetA1TMA2(V1, V2, InvertM, NPos, NNeg);
    if(S.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetV1TMV2(). Computing V1TMV2.\n");
        return 0.;
    }
    return S.Data[0];
}

UMatrix UMatrixSymmetric::GetATMA(const UMatrix& A, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(IsSymmetricType()!=true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Matrix is not diagonal nor symmetric (MT=%d)\n", int(UMatrix::MT));
        return UMatrix(U_ERROR);
    }

    if(Ncol!=A.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Number of Ncol (%d) does not match A.Nrow (%d)\n", Ncol, A.GetNrow());
        return UMatrix(U_ERROR);
    }
    if(UpdateWmat(InvertM)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Updating Wmat.\n");
        return UMatrix(U_ERROR);
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;
    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
        return UMatrix(U_ERROR);
    }
    if(A.IsDiagonalType()) return GetADiagMADiag(A, InvertM, NPos, NNeg);

    UMatrix ATMA;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :   return ATMA;
    case U_MAT_IDENTITY  :   
        ATMA = A.GetMTM();
        break;
    case U_MAT_IDENTCONST:   
        ATMA = A.GetMTM();
        if(    NOT(InvertM)) ATMA*= Data[0];
        else if(Data[0]==0.) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Matrix singular.\n");
            return UMatrix(U_ERROR);
        }
        else                 ATMA/= Data[0];
        break;
    case U_MAT_DIAGONAL  :  
        {
            ATMA = UMatrix((double*)NULL, A.Ncol, A.Ncol);
            if(ATMA.GetError()!=U_OK || ATMA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Creating output matrix, diagonal case.\n");
                return UMatrix(U_ERROR);
            }
            for(int j1=0; j1<A.Ncol; j1++)
            {
                for(int j2=0; j2<A.Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double  Imp   = 0.;
                        const double* M1 = A.Data+j1;
                        const double* M2 = A.Data+j2;

                        if(InvertM)
                        {
                            for(int k=0; k<Nrow; k++) 
                            {
                                if(Data[DiagIndex[k]]==0.) continue;
                                int NcolK = A.Ncol*DiagIndex[k];
                                if(k<NPos || k>=Nrow-NNeg) Imp += (M1[NcolK] * M2[NcolK]) / Data[DiagIndex[k]];
                            }
                        }
                        else
                        {
                            for(int k=0; k<Nrow; k++) 
                            {
                                int NcolK = A.Ncol*DiagIndex[k];
                                if(k<NPos || k>=Nrow-NNeg) Imp += (M1[NcolK] * M2[NcolK]) * Data[DiagIndex[k]];
                            }
                        }
                        ATMA.Data[j1*A.Ncol+j2] = Imp;
                    }
                    else
                    {
                        ATMA.Data[j1*A.Ncol+j2]  = ATMA.Data[j2*A.Ncol+j1];
                    }
                }
            }
        }
        break;
    case U_MAT_SYMMETRIC :  
        {
            ATMA = UMatrix((double*)NULL, A.Ncol, A.Ncol);
            if(ATMA.GetError()!=U_OK || ATMA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Creating output matrix, symmetric case.\n");
                return UMatrix(U_ERROR);
            }
            UMatrix WmatTA = GetMatMul(WMat, true, A, false);
            if(WmatTA.GetError()!=U_OK || WmatTA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Computing WmatTAT.\n");
                return UMatrix(U_ERROR);
            }

            const double* pWmatTA = WmatTA.Data;
            for(int j1=0; j1<A.Ncol; j1++)
            {
                for(int j2=0; j2<A.Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double        Imp  = 0.;
                        const double* pW1  = pWmatTA+j1;
                        const double* pW2  = pWmatTA+j2;
                        for(int k=0; k<NPos; k++, pW1+=A.Ncol, pW2+=A.Ncol) Imp += *pW1 * *pW2;

                        pW1  = pWmatTA+j1+A.Ncol*(Nrow-1);
                        pW2  = pWmatTA+j2+A.Ncol*(Nrow-1);
                        for(int k=0; k<NNeg; k++, pW1-=A.Ncol, pW2-=A.Ncol) Imp -= *pW1 * *pW2;
                        ATMA.Data[j1*A.Ncol+j2] = Imp;
                    }
                    else
                    {
                        ATMA.Data[j1*A.Ncol+j2]  = ATMA.Data[j2*A.Ncol+j1];
                    }
                }
            }
        }
        break;
    default:
        CI.AddToLog("ERROR: UMatrixSymmetric::GetATMA(). Matrix of wrong type (MT=%d) \n", int(MT));
        return UMatrix(U_ERROR);
    }
    ATMA.MT  = U_MAT_SYMMETRIC;
    return ATMA;
}
UMatrix UMatrixSymmetric::GetADiagMADiag(const UMatrix& A, bool InvertM, int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(UMatrix::MT != U_MAT_NULL && Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Data not properly set. \n");
        return  UMatrix(U_ERROR);
    }
    if(Ncol!=A.GetNrow())
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Number of Ncol (%d) does not match A.Nrow (%d)\n", Ncol!=A.GetNrow());
        return UMatrix(U_ERROR);
    }
    if(UpdateWmat(InvertM)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Updating Wmat.\n");
        return UMatrix(U_ERROR);
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;
    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Number of positive (%d) or negative (%d) eigenvalues out of range \n", NPos, NNeg);
        return UMatrix(U_ERROR);
    }
    if(A.GetMatrixType()==U_MAT_NULL) return UMatrix();
    if(A.IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Matrix argument should be diagonal matrix \n");
        return UMatrix(U_ERROR);
    }

    UMatrix AMA;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :   return AMA; // valid for any A
    case U_MAT_IDENTITY  :               // Ignore NPos, NNeig
        AMA = A*A;
        break;
    case U_MAT_IDENTCONST:    
        AMA = A*A;
        if(    NOT(InvertM)) AMA*= Data[0];
        else if(Data[0]==0.) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Matrix singular.\n");
            return UMatrix(U_ERROR);
        }
        else                 AMA/= Data[0];
        break;
    case U_MAT_DIAGONAL  :  
        {
            AMA = UMatrix(DNULL, A.Ncol); // Diagonal matrix
            if(AMA.GetError()!=U_OK || AMA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Creating output matrix, diagonal case.\n");
                return UMatrix(U_ERROR);
            }
            for(int k=0; k<A.Ncol; k++)
            {
                if(InvertM)
                {
                    if(Data[DiagIndex[k]]==0.) continue;
                    if(k<NPos || k>=Nrow-NNeg) AMA.Data[k] =  1. / Data[DiagIndex[k]];
                    else                       AMA.Data[k] =  0.;
                }
                else
                {
                    if(k<NPos || k>=Nrow-NNeg) AMA.Data[k] =       Data[DiagIndex[k]];
                    else                       AMA.Data[k] =  0.;
                }
            }
            if(A.MT== U_MAT_IDENTCONST)     for(int k=0; k<A.Ncol; k++) AMA.Data[k] *= SQR( A.Data[0] );
            else if(A.MT== U_MAT_DIAGONAL)  for(int k=0; k<A.Ncol; k++) AMA.Data[k] *= SQR( A.Data[k] );
        }
        break;
    case U_MAT_SYMMETRIC :  
        {
            AMA = UMatrix((double*)NULL, A.Ncol, A.Ncol);
            if(AMA.GetError()!=U_OK || AMA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Creating output matrix, symmetric case.\n");
                return UMatrix(U_ERROR);
            }
            UMatrix WmatTA = GetMatMul(WMat, true, A, false);
            if(WmatTA.GetError()!=U_OK || WmatTA.Data==NULL)
            {
                CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Computing WmatTAT.\n");
                return UMatrix(U_ERROR);
            }

            const double* pWmatTA = WmatTA.Data;
            for(int j1=0; j1<A.Ncol; j1++)
            {
                for(int j2=0; j2<A.Ncol; j2++)
                {
                    if(j2>=j1)
                    {
                        double        Imp  = 0.;
                        const double* pW1  = pWmatTA+j1;
                        const double* pW2  = pWmatTA+j2;
                        for(int k=0; k<NPos; k++, pW1+=A.Ncol, pW2+=A.Ncol) Imp += *pW1 * *pW2;

                        pW1  = pWmatTA+j1+A.Ncol*(Nrow-1);
                        pW2  = pWmatTA+j2+A.Ncol*(Nrow-1);
                        for(int k=0; k<NNeg; k++, pW1-=A.Ncol, pW2-=A.Ncol) Imp -= *pW1 * *pW2;
                        AMA.Data[j1*A.Ncol+j2] = Imp;
                    }
                    else
                    {
                        AMA.Data[j1*A.Ncol+j2]  = AMA.Data[j2*A.Ncol+j1];
                    }
                }
            }
        }
        break;
    default:
        CI.AddToLog("ERROR: UMatrixSymmetric::GetADiagMADiag(). Matrix of wrong type (MT=%d) \n", int(MT));
        return UMatrix(U_ERROR);
    }
    AMA.MT  = U_MAT_SYMMETRIC;
    return AMA;
}

ErrorType UMatrixSymmetric::ResetDecomp()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    return U_OK;
}

ErrorType UMatrixSymmetric::Decompose()
{
    if(Decomposed) return U_OK;

    if(UMatrix::MT!=U_MAT_NULL && Data==NULL) return U_ERROR;

    DeleteAllMembers(U_OK);
    ErrorType    E = U_OK;
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :   Singular   = true;                   break;
    case U_MAT_IDENTITY  :   NNeigPos   = Ncol;
                             NNeigNeg   = 0;
                             LogAbsDet  = 0.; 
                             SignDetPos = true; 
                             Singular   = false;                  break;
    case U_MAT_IDENTCONST:   NNeigPos   = (Data[0]> 0.) ? Ncol : 0;
                             NNeigNeg   = (Data[0]< 0.) ? Ncol : 0;
                             LogAbsDet  = (Data[0]==0.) ? 0.   : Nrow*log(fabs(Data[0])); 
                             SignDetPos = Data[0]>0.;          
                             Singular   = Data[0]==0.;            break;
    case U_MAT_DIAGONAL  :  {
                                LogAbsDet  = 0.;
                                SignDetPos = true;
                                Singular   = false;
                                for(int k=0; k<Nrow; k++)
                                {
                                    double Diag = Data[k];
                                    if(Diag==0)      {Singular   = true; LogAbsDet=0.; SignDetPos=false;}
                                    else if(Diag>0.) {NNeigPos++; if(Singular==false)  LogAbsDet += log( Diag); }
                                    else             {NNeigNeg++; if(Singular==false) {LogAbsDet += log(-Diag); SignDetPos = NOT(SignDetPos);}}
                                }
                                bool Fabs   = false;
                                bool HFirst = true;
                                delete[] DiagIndex; DiagIndex = GetOrderIndexArray(Data, Nrow, Fabs, HFirst);
                                if(DiagIndex==NULL)
                                {
                                    CI.AddToLog("ERROR: UMatrixSymmetric::Decompose(). Getting ordering of diagonal values.\n");
                                    E = U_ERROR;
                                }
                            }
                            break;
    case U_MAT_SYMMETRIC :  {
                                UDecompHermitian DH;
                                Lamda           = UMatrix((double*)NULL, Nrow);
                                UMat            = UMatrix((double*)NULL, Nrow, Ncol);
                                if(Lamda.GetError()!=U_OK || Lamda.Data==NULL ||
                                    UMat.GetError()!=U_OK ||  UMat.Data==NULL)
                                {
                                    CI.AddToLog("ERROR: UMatrixSymmetric::Decompose(). Creating matrices for eigenvalues/eigenvectors.\n");
                                    E = U_ERROR;
                                    break;
                                }
                                int Nrot = 0;
                                int ierr = jacobi_d(Data, Nrow, Lamda.Data, UMat.Data, &Nrot);
                                if(ierr<0)
                                {
                                    CI.AddToLog("ERROR: UMatrixSymmetric::Decompose(). Computing eigenvalues/eigenvectors.\n");
                                    E = U_ERROR;
                                    break;
                                }
                                UMat.MT    = U_MAT_SQUARE;
                                LogAbsDet  = 0.;
                                SignDetPos = true;
                                Singular   = false;
                                for(int k=0; k<Nrow; k++)
                                {
                                    double Diag = Lamda.GetElement(k,k);
                                    if(Diag==0)      {Singular   = true; LogAbsDet=0.; SignDetPos=false;}
                                    else if(Diag>0.) {NNeigPos++; if(Singular==false)  LogAbsDet += log( Diag); }
                                    else             {NNeigNeg++; if(Singular==false) {LogAbsDet += log(-Diag); SignDetPos = NOT(SignDetPos);}}
                                }
                            }
                            Decomposed = true; // Enforce update of Wmat, with InvWmat = false
                            InvWmat    = true;
                            E          = UpdateWmat(false);
                            break;
    default:
        if(Ncol==Nrow)
        {
            if(ForceSymmetricType(REL_SYMMETRY_ERROR)==U_OK && IsSymmetricType()==true) return Decompose();
        }
        CI.AddToLog("ERROR: UMatrixSymmetric::Decompose(). Matrix of wrong type (MT=%d) \n", int(MT));
        return U_ERROR;
    }
    Decomposed = true;
    if(E!=U_OK) 
    {
        Singular   = true;
        CI.AddToLog("ERROR: UMatrixSymmetric::Decompose(). Decomposition error. \n");
        return U_ERROR;
    }
    return U_OK;
}
ErrorType UMatrixSymmetric::UpdateWmat(bool SetInv)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    bool ForceUpdate = NOT(Decomposed);
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::UpdateWmat(). Performing matrix decomposition. \n");
        return U_ERROR;
    }
    if(SetInv==InvWmat && NOT(ForceUpdate)) return U_OK;

    InvWmat = SetInv;
    if(MT==U_MAT_SYMMETRIC)
    {
        WMat = UMat;
        for(int k=0; k<Ncol;k++)
        {
            double SqEig = sqrt(fabs(Lamda.Data[k]));

            if(InvWmat== true)
            {
                if(SqEig>0)  for(int i=0;i<Nrow;i++) WMat.Data[i*Ncol+k] /= SqEig;
                else         for(int i=0;i<Nrow;i++) WMat.Data[i*Ncol+k] = 0;
            }
            else
                for(int i=0;i<Nrow;i++) WMat.Data[i*Ncol+k] *= SqEig;
        }
    }
    return U_OK;
}
double UMatrixSymmetric::GetSignDet()
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Decomposed==false)
    {
        if(Decompose()!=U_OK) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetSignDet(). Performing matrix decomposition. \n");
            return 0.;
        }
    }
    if(Singular  ==true)          return 0.;

    return SignDetPos ? 1. : -1.;
}
double UMatrixSymmetric::GetSmallestEigen(void)
{
    if(this==NULL || error!=U_OK) return 0.;
    return GetEigen(Ncol-1);
}
double UMatrixSymmetric::GetSmallestNonZeroEigen(void)
{
    if(this==NULL || error!=U_OK) return 0.;
    for(int n=Ncol-1; n>=0.; n--)
    {
        double Eig = GetEigen(n);
        if(Eig==0.) continue;
        return Eig;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetSmallestNonZeroEigen(). All eigenvalues are zero.\n");
    return 0.;
}
double UMatrixSymmetric::GetLargestEigen(void)
{
    if(this==NULL || error!=U_OK) return 0.;
    return GetEigen(0);
}
double UMatrixSymmetric::GetEigen(int i)
{
    if(this==NULL || error!=U_OK) return 0.;
    if(i<0 || i>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigen(). Invalid index (i=%d). \n", i);
        return 0.;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigen(). Performing matrix decomposition. \n");
        return 0.;
    }
    if(Data==NULL) return 0.;

    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :  return 0.;
    case U_MAT_IDENTITY  :  return 1.;
    case U_MAT_IDENTCONST:  return Data[0];
    case U_MAT_DIAGONAL  :  return Data[DiagIndex[i]];
    case U_MAT_SYMMETRIC :  return Lamda.Data[i];
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetEigen(). Matrix of wrong type (MT=%d) \n", int(MT));
    return 0.;
}
double* UMatrixSymmetric::GetNormalizedEigen(bool Percentage)
{
    if(this==NULL || error!=U_OK) return NULL;
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNormalizedEigen(). Performing matrix decomposition. \n");
        return NULL;
    }
    double* NormEig = new double[Nrow];
    if(NormEig==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetNormalizedEigen(). Memory allocation. \n");
        return NULL;
    }
    for(int k=0; k<Nrow; k++) NormEig[k] = 0.;
    if(Data==NULL) return NormEig;

    double Sum = 0.;
    for(int k=0; k<Nrow; k++) {NormEig[k] = GetEigen(k), Sum+=NormEig[k];};
    if(Sum>0.    ) for(int k=0; k<Nrow; k++) NormEig[k] /=Sum;
    if(Percentage) for(int k=0; k<Nrow; k++) NormEig[k] *=100.;
    return NormEig;
}

UMatrix UMatrixSymmetric::GetEigenVector(int i)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(i<0 || i>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVector(). Invalid index (i=%d). \n", i);
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVector(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(Data==NULL) return UMatrix(U_ERROR);

    UMatrix EV(DNULL, Nrow, 1);
    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :  return EV;
    case U_MAT_IDENTITY  :  
    case U_MAT_IDENTCONST:  
    case U_MAT_DIAGONAL  :  EV.SetElement(i, 0, 1.); return EV; // Reordering required in case U_MAT_DIAGONAL????
    case U_MAT_SYMMETRIC :  for(int k=0; k<Nrow; k++) EV.SetElement(k, 0, UMat.GetElement(k,i)); return EV;
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVector(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrix(U_ERROR);
}
UMatrix UMatrixSymmetric::GetEigenVectors(int i1, int i2)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(i1<0 || i1>i2 || i2>=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVectors(). Invalid indeces (i1=%d,i2=%d). \n", i1, i2);
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVectors(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(Data==NULL) return UMatrix(U_ERROR);

    UMatrix EV(DNULL, Nrow, i2-i1+1);
    switch(UMatrix::MT)
    {
    case U_MAT_NULL      :  return EV;
    case U_MAT_IDENTITY  :  
    case U_MAT_IDENTCONST:  
    case U_MAT_DIAGONAL  :  for(int i=i1; i<=i2; i++) EV.SetElement(i, i-i1, 1.); return EV; // Reordering required in case U_MAT_DIAGONAL????
    case U_MAT_SYMMETRIC :  for(int i=i1; i<=i2; i++) EV.SetCol(i-i1, UMat.GetCollumn(i)); return EV;
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetEigenVector(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrix(U_ERROR);
}

UMatrix UMatrixSymmetric::GetUMat()
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetUMat(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }

    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :  return UMatrix();
    case U_MAT_IDENTITY  :  return UMatrix(GetNcol());
    case U_MAT_IDENTCONST:  return UMatrix(GetNcol());
    case U_MAT_DIAGONAL  :  return UMatrix(GetNcol()); // Reordering required????
    case U_MAT_SYMMETRIC :  return UMat;
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetUMat(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrix(U_ERROR);
}
UMatrix UMatrixSymmetric::GetLamda()
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetLamda(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }

    switch(UMatrix::MT)
    {
    case U_MAT_NULL     :  return UMatrix();
    case U_MAT_IDENTITY  :  return UMatrix(GetNcol());
    case U_MAT_IDENTCONST:  return UMatrix(GetNcol())*Data[0];
    case U_MAT_DIAGONAL  :  return *this; // Reordering required????
    case U_MAT_SYMMETRIC :  return Lamda;
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetLamda(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrix(U_ERROR);
}

double UMatrixSymmetric::GetLogAbsDet()
{
    if(this==NULL || error!=U_OK) return 0.;
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetLogAbsDet(). Performing matrix decomposition. \n");
        return 0.;
    }
    if(Singular  ==true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetLogAbsDet(). Matrix is singular. \n");
        return 0.;
    }
    return LogAbsDet;
}
ErrorType UMatrixSymmetric::Invert(int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Invert(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(Data==NULL || Nrow!=Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Invert(). Matrix not square or data not set.\n");
        return U_ERROR;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Invert(). Performing matrix decomposition. \n");
        return U_ERROR;
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;

    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Invert(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
        return U_ERROR;
    }

    *this = GetInverse(NPos, NNeg);
    return error;
}
UMatrixSymmetric UMatrixSymmetric::GetInverse(int NPos, int NNeg)
{
    if(this==NULL || error!=U_OK) return UMatrixSymmetric(U_ERROR);
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Performing matrix decomposition. \n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(Singular  ==true && NPos+NNeg==Ncol)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Matrix is singular. \n");
        return UMatrixSymmetric(U_ERROR);
    }
    if(Data==NULL) return UMatrixSymmetric(U_ERROR);

    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;
    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
        return UMatrixSymmetric(U_ERROR);
    }

    switch(UMatrix::MT)
    {
    case U_MAT_NULL      :  return UMatrixSymmetric(U_ERROR);         // Ignore NNeg and NPos
    case U_MAT_IDENTITY  :  return UMatrixSymmetric(UMatrix(Nrow));
    case U_MAT_IDENTCONST:  {
                                if(Data[0]==0.) return UMatrixSymmetric(U_ERROR);
                                UMatrixSymmetric Min  = *this;
                                Min               /= (Data[0]*Data[0]);
                                Min.LogAbsDet      = -LogAbsDet;
                                return Min;
                            }
    case U_MAT_DIAGONAL  :  {
                                UMatrixSymmetric Min = *this;
                                if(Min.error!=U_OK) return UMatrixSymmetric(U_ERROR);

                                for(int k=0; k<Ncol; k++)
                                {
                                    int kInd = DiagIndex[k];
                                    Min.Data[kInd] = 0.;
                                    if(kInd>=NPos && kInd<Nrow-NNeg)  continue;
                                    if(Data[kInd]==0.)  continue; // This should never happen
                                    Min.Data[kInd] = 1./Data[kInd];
                                }
                                bool Fabs   = false;
                                bool HFirst = true;
                                delete[] Min.DiagIndex; Min.DiagIndex = GetOrderIndexArray(Min.Data, Nrow, Fabs, HFirst);
                                if(Min.DiagIndex==NULL)
                                {
                                    CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Getting ordering of diagonal values.\n");
                                    return UMatrixSymmetric(U_ERROR);
                                }
                                return Min;
                            }
    case U_MAT_SYMMETRIC :  {
                                UMatrixSymmetric LamdaInv = Lamda;
                                if(LamdaInv.GetError()!=U_OK || LamdaInv.Invert()!=U_OK)
                                {
                                    CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Computing inverse of eigenvalues. \n");
                                    return UMatrixSymmetric(U_ERROR);
                                }
                                UMatrixSymmetric MinSym= LamdaInv.GetAMAT(UMat, false, NPos, NNeg);
                                MinSym.Decomposed      =  true;
                                MinSym.Singular        =  false;
                                MinSym.LogAbsDet       = -LogAbsDet;
                                MinSym.SignDetPos      =  SignDetPos;
                                MinSym.NNeigPos        =  NPos;
                                MinSym.NNeigNeg        =  NNeg;
                                MinSym.Lamda           =  Lamda;  // Set memory, reorder next
                                MinSym.UMat            =  UMat;   //
                                for(int j=0; j<Ncol; j++)
                                {
                                    MinSym.Lamda.Data[j] =  LamdaInv.Data[LamdaInv.DiagIndex[j]];
                                    for(int i=0; i<Nrow; i++)
                                        MinSym.UMat.Data[i*Ncol+j]  =  UMat.Data[i*Ncol+LamdaInv.DiagIndex[j]];
                                }
                                MinSym.InvWmat         =  NOT(InvWmat);
                                MinSym.UpdateWmat(InvWmat);
                                return MinSym;
                            }
    default: break;
    }
    CI.AddToLog("ERROR: UMatrixSymmetric::GetInverse(). Matrix of wrong type (MT=%d) \n", int(MT));
    return UMatrixSymmetric(U_ERROR);
}
ErrorType UMatrixSymmetric::Sqrt(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Sqrt(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::Sqrt(). Function only implemented for positive diagonal matrices.\n");
        return U_ERROR;
    }

    Decomposed = false; // Compute square root
    switch(MT)
    {
    case U_MAT_NULL:       return U_OK;
    case U_MAT_IDENTITY:    return U_OK;
    case U_MAT_IDENTCONST:  
        if(Data==NULL || Data[0]<0.)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::Sqrt(). Data not set or negative.\n");
            return U_ERROR;
        }
        Data[0] =  sqrt( Data[0]);
        return U_OK;
    case U_MAT_DIAGONAL:  
        if(Data==NULL)
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::Sqrt(). Data not set.\n");
            return U_ERROR;
        }
        for(int k=0; k<Ncol; k++) 
        {
            if(Data[k]>=0) continue;
            CI.AddToLog("ERROR: UMatrixSymmetric::Sqrt(). Diagonal matrix elemen %d non-positive (%f).\n", k, Data[k]);
            return U_ERROR;
        }
        for(int k=0; k<Ncol; k++) Data[k] = sqrt( Data[k]);
        return U_OK;
    default: break;
    }
    return U_ERROR;
}
ErrorType UMatrixSymmetric::InvertSqrt(int NPos)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Object NULL or erroeneous.\n");
        return U_ERROR;
    }
    if(IsDiagonalType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Function only implemented for positive diagonal matrices.\n");
        return U_ERROR;
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Performing matrix decomposition. \n");
        return U_ERROR;
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NPos<0 || NPos>NNeigPos)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Number of positive (%d) eigenvalues out of range (NNeigPos = %d)\n", NPos, NNeigPos);
        return U_ERROR;
    }
    if(Invert(NPos,0)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Inverting matrix.\n");
        return U_ERROR;
    }
    if(Sqrt()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::InvertSqrt(). Computing square root.\n");
        return U_ERROR;
    }
    return U_OK;
}
UMatrix UMatrixSymmetric::GetSqrt(void)
// Compute and return R such that (*this) = R*Rt
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetSqrt(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(IsSymmetricType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetSqrt(). Function only implemented for positive diagonal matrices.\n");
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetSqrt(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        UMatrixSymmetric Sq = (*this);
        if(Sq.Sqrt()!=U_OK) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetSqrt(). Computing square root.\n");
            return UMatrix(U_ERROR);
        }
        return UMatrix(Sq);
    }
    UMatrixSymmetric Sq = Lamda;
    if(Sq.Sqrt()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetSqrt(). Computing square root of Lamda.\n");
        return UMatrix(U_ERROR);
    }
    return UMat*Sq;
}
UMatrix UMatrixSymmetric::GetInvertSqrt(int NPos)
// Compute and return R such that (*this) inverse = R*Rt
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Object NULL or erroeneous.\n");
        return UMatrix(U_ERROR);
    }
    if(IsSymmetricType()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Function only implemented for symmetric matrices.\n");
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(NPos==-1) NPos=NNeigPos;
    if(NPos<0 || NPos>NNeigPos)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Number of positive (%d) eigenvalues out of range (NNeigPos = %d).\n", NPos, NNeigPos);
        return UMatrix(U_ERROR);
    }
    if(IsDiagonalType()==true)
    {
        UMatrixSymmetric InvSq = (*this);
        if(InvSq.InvertSqrt(NPos)!=U_OK) 
        {
            CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Computing inverse square root.\n");
            return UMatrix(U_ERROR);
        }
        return UMatrix(InvSq);
    }
    UMatrixSymmetric InvSq = Lamda;
    if(InvSq.InvertSqrt(NPos)!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetInvertSqrt(). Computing inverse square root of Lamda.\n");
        return UMatrix(U_ERROR);
    }
    return UMat*InvSq;
}

UMatrix UMatrixSymmetric::GetAxIsB(const UMatrix& B, int NPos, int NNeg)
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);
    if(&B  ==NULL || B.GetError()!=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Matrix empty.\n");
        return UMatrix(U_ERROR);
    }
    if(Nrow!=B.Nrow)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Numbers of rows do not fit (Nrow=%d) and (B.Nrow=%d)\n", Nrow, B.Nrow);
        return UMatrix(U_ERROR);
    }
    if(Decomposed==false && Decompose()!=U_OK) 
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Performing matrix decomposition. \n");
        return UMatrix(U_ERROR);
    }
    if(Singular==true)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Matrix singular.\n");
        return UMatrix(U_ERROR);
    }

    if(NPos==-1) NPos=NNeigPos;
    if(NNeg==-1) NNeg=NNeigNeg;
    if(NPos<0 || NPos>NNeigPos || 
       NNeg<0 || NNeg>NNeigNeg)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Number of positive (%d) or negative (%d) eigenvalues out of range (NNeigPos,NNeigNeg) =(%d,%d)\n", NPos, NNeg, NNeigPos, NNeigNeg);
        return UMatrix(U_ERROR);
    }

    if(MT==U_MAT_IDENTITY) return B;
    if(IsDiagonalType()==true || B.Ncol>=Nrow)
    {
        UMatrix Min = GetInverse(NPos, NNeg);
        return Min*B;
    }
    UMatrixSymmetric LamdaInv = Lamda;
    if(LamdaInv.GetError()!=U_OK || LamdaInv.Invert(NPos, NNeg)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetAxIsB(). Computing inverse of eigenvalues. \n");
        return UMatrix(U_ERROR);
    }
    return LamdaInv.GetAMAT(UMat,false, NPos, NNeg)*B;
}

UMatrix UMatrixSymmetric::GetClusteringCoefficients(void) const
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetClusteringCoefficients(). Matrix empty.\n");
        return UMatrix(U_ERROR);
    }
    if(AreElementsNonNegative()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetClusteringCoefficients(). There are negative matrix elements. Clustering coefficient not defined.\n");
        return UMatrix(U_ERROR);
    }
    UMatrix H(*this);
    if(H.ApplyFunction(ThirdPow)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetClusteringCoefficients(). Raising *this to thirdth power.\n");
        return UMatrix(U_ERROR);
    }
    H = H*H*H;
    UMatrix Tri = H.GetDiagonal();
    UMatrix Deg = GetColSum();
    if(Tri.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetClusteringCoefficients(). Raising *this to third power, getting diagonal or computing col sum.\n");
        return UMatrix(U_ERROR);
    }
    UMatrix Cluster(DNULL,Nrow, 1);

    for(int k=0; k<Nrow; k++) 
    {
        double T = Tri.Data[k];
        double D = Deg.Data[k];
        if(T<=0. || D<=0.) continue;
        Cluster.Data[k] = T / (D*(D-1));
    }
    return Cluster;
}

UMatrix UMatrixSymmetric::GetPathLenghtMatrix(double WeightInfiniteDist) const
{
    if(this==NULL || error       !=U_OK) return UMatrix(U_ERROR);

    if(MT==U_MAT_NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetPathLenghtMatrix(). Matrix empty.\n");
        return UMatrix(U_ERROR);
    }
    if(AreElementsNonNegative()==false)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetPathLenghtMatrix(). There are negative matrix elements. Clustering coefficient not defined.\n");
        return UMatrix(U_ERROR);
    }

    if(WeightInfiniteDist==0.) WeightInfiniteDist = -1;
    int NSubT = (WeightInfiniteDist<0.) ? Nrow*Ncol : GetNSubThreshholElements(WeightInfiniteDist, false);
    if(NSubT<=0)
    {
        CI.AddToLog("ERROR: UMatrixSymmetric::GetPathLenghtMatrix(). There are no connections (NSubT=%d, WeightInfiniteDist=%f).\n", NSubT, WeightInfiniteDist);
        return UMatrix(U_ERROR);
    }
    UMatrix Path(DNULL, Nrow, Ncol);
    int*    Prev = new int[Nrow]; // Used to store sequence of nodes, starting from source, and running in increasing distance
    int*    Q    = new int[Nrow];
    if(Path.GetError()!=U_OK || Prev==NULL || Q==NULL)
    {
        delete[] Prev; delete[] Q;
        CI.AddToLog("ERROR: UMatrixSymmetric::GetPathLenghts(). Memory allocation, or creating output matrix (Nrow=%d) .\n", Nrow);
        return UMatrix(U_ERROR);
    }
    for(int k=0; k<Nrow;k++) Prev[k] = Q[k] = 0;

    for(int source = 0; source<Nrow; source++)
    {
        double* Dist = Path.Data + source*Ncol;
        Dist[source] =  0.;
        Prev[source] = -1;

        for(int v=0; v<Nrow; v++) Q[v] = Q[v] = (v+1)%Nrow;
        for(int v=0; v<Nrow; v++)
        {
            if(v==source) continue;
            Dist[v] = -1.;
            Prev[v] = -1;
        }
        int NQ     = Nrow;
        int qstart = 0;
        while(NQ>0)
        {
            int    uprev = qstart;
            int    u     = Q[qstart];
            double Dmin  = Dist[u];
            for(int k=0, q=Q[qstart], qp=qstart; k<NQ; k++, q=Q[q], qp =Q[qp])  
                if(Dist[q]>=0. && (Dist[q]<Dmin||Dmin<0.)) 
                { 
                    u      = q;  
                    Dmin   = Dist[q]; 
                    uprev  = qp;
                    qstart = uprev;
                }
            Q[uprev] = Q[u]; //Remove u from list
            NQ--;

            for(int v=0; v<Nrow; v++) 
            {
                double Distuv = Data[u*Ncol+v];
                if(WeightInfiniteDist>0 && WeightInfiniteDist<=Distuv) continue;  // Loop over neighbors of u: skip vertices at "infinite" distance

                double DistAlt = Dist[u] + Distuv;
                if(DistAlt<Dist[v] || Dist[v]<0)
                {
                    Dist[v] = DistAlt;
                    Prev[v] = u;
                }
            }
        }
    }
    delete[] Prev; delete[] Q;

    return Path;
}
ErrorType ComputeJointDiagonalize(UMatrixSymmetric& A, UMatrixSymmetric& B, double MaxEigenOffset, UMatrix& Z, UMatrix& DiagA, UMatrix& DiagB)
/*
    Compute Z such that Z * A *ZT = DiagA and Z * B * ZT = DiagB, and both DiagA and DiagB are diagonal matrices.
 */
{
    if(&A==NULL || A.GetError()!=U_OK || &B==NULL || B.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ComputeJointDiagonalize(). NULL or erroneous matrix input argument(s).\n");
        return U_ERROR;
    }
    if(A.GetNcol()!=B.GetNcol())
    {
        CI.AddToLog("ERROR: ComputeJointDiagonalize(). A and B matrices not equally sized (A.Ncol=%d, B.Ncol=%d).\n",A.GetNcol(), B.GetNcol());
        return U_ERROR;
    }
    if(&Z==NULL || &DiagA==NULL || &DiagB==NULL)
    {
        CI.AddToLog("ERROR: ComputeJointDiagonalize(). NULL matrix output argument(s).\n");
        return U_ERROR;
    }
    int    N      = A.GetNcol();
    if(A.IsDiagonalType()==true && B.IsDiagonalType()==true)
    {
        DiagA = A; DiagB = B; Z = UMatrix(N);
        return U_OK;
    }

    double ASmall = -1.;
    double BSmall = -1.;
    if((ASmall=A.GetSmallestEigen())>0)
    {
        UMatrixSymmetric LamA   = A.GetLamda();
        LamA.InvertSqrt();
        UMatrix          ZAL    = A.GetUMat() * LamA;
        UMatrixSymmetric C      = B.GetATMA(ZAL, false);
        Z = GetMatMul(C.GetUMat(), true, ZAL, true);
        DiagB = C.GetLamda();
        DiagA = UMatrix(B.GetNcol());
        return U_OK;
    }
    else if((BSmall=B.GetSmallestEigen())>0.)
    {
        UMatrixSymmetric LamB   = B.GetLamda();
        LamB.InvertSqrt();
        UMatrix          ZBL    = B.GetUMat() * LamB;
        UMatrixSymmetric C      = A.GetATMA(ZBL, false);
        Z = GetMatMul(C.GetUMat(), true, ZBL, true);
        DiagA = C.GetLamda();
        DiagB = UMatrix(A.GetNcol());
        return U_OK;
    }
    else if(MaxEigenOffset>0)
    {
        if(fabs(ASmall)<fabs(BSmall))
        {
            double Offset = fabs(MaxEigenOffset*A.GetSmallestNonZeroEigen());
            UMatrixSymmetric LamA   = A.GetLamda() + UMatrix(N)*Offset;
            LamA.InvertSqrt();
            UMatrix          ZAL    = A.GetUMat() * LamA;
            UMatrixSymmetric C      = B.GetATMA(ZAL, false);
            Z = GetMatMul(C.GetUMat(), true, ZAL, true);
            DiagB = C.GetLamda();
            DiagA = UMatrix(B.GetNcol());
            CI.AddToLog("Note: ComputeJointDiagonalize(). Added Offset to A = %20.9f \n", Offset);
            return U_OK;
        }
        else
        {
            double Offset = fabs(MaxEigenOffset*B.GetSmallestNonZeroEigen());
            UMatrixSymmetric LamB   = B.GetLamda() + UMatrix(N)*Offset;
            LamB.InvertSqrt();
            UMatrix          ZBL    = B.GetUMat() * LamB;
            UMatrixSymmetric C      = A.GetATMA(ZBL, false);
            Z = GetMatMul(C.GetUMat(), true, ZBL, true);
            DiagA = C.GetLamda();
            DiagB = UMatrix(A.GetNcol());
            CI.AddToLog("Note: ComputeJointDiagonalize(). Added Offset to B = %20.9f \n", Offset);
            return U_OK;
        }
    }
    CI.AddToLog("ERROR: ComputeJointDiagonalize(). Neither of input matrices is positive definite.\n");
    return U_ERROR;
}
