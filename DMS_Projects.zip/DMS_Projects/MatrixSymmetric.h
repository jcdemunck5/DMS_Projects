#ifndef _MATRIXSYMMETRIC_INCLUDED
#define _MATRIXSYMMETRIC_INCLUDED

#include "Matrix.h"

class DLL_IO UMatrixSymmetric : public UMatrix
{
public:
    UMatrixSymmetric();                                                             // default constructor -> empty matrix
    UMatrixSymmetric(ErrorType E);                                                  // constructor used to return an empty, Erroneous matrix
    UMatrixSymmetric(int nDim);                                                     // identity constructor
    UMatrixSymmetric(const double*Matrix, int Nrow, int Ncol, bool Decomp=false);   // Scratch constructor 
    UMatrixSymmetric(const UMatrixSparse& MS, bool Decomp=false);                   // Sparse matrix constructor
    UMatrixSymmetric(const UMatrix& A, bool Decomp=false);                          // Copy constructor 
    UMatrixSymmetric(const UMatrixSymmetric& A);                                    // Copy constructor 
    
    virtual ~UMatrixSymmetric();

    UMatrixSymmetric&       operator= ( const UMatrix& M);
    UMatrixSymmetric&       operator= ( const UMatrixSymmetric& M);
    UMatrixSymmetric        operator- ( const UMatrixSymmetric& M) const; 
    UMatrixSymmetric&       operator-=( const UMatrixSymmetric& M); 
    UMatrixSymmetric        operator+ ( const UMatrixSymmetric& M) const; 
    UMatrixSymmetric&       operator+=( const UMatrixSymmetric& M); 
    UMatrix                 operator* ( const UMatrix& M) const;
    UMatrixSymmetric        operator* ( const double a) const;
    UMatrixSymmetric&       operator*=( const double a);
    UMatrixSymmetric&       operator/=( const double a);
    UMatrixSymmetric        operator-(void)  const;

    ErrorType               GetError(void)           const {if(this) return error; return U_ERROR;}
    const UString&          GetProperties(UString Comment) const;
    virtual ErrorType       SetData(double Value);
    virtual ErrorType       CopyCol(int icol, int DestBegin, int DestEnd);
    virtual ErrorType       Shrink(double Lamda, int* Nzero=NULL);
    virtual ErrorType       ShrinkRows(double Lamda, int* Nzero=NULL);
    virtual ErrorType       SetUnitVector(int iunit, int Ndim, bool ColVect);
    virtual ErrorType       SetUnitVectors(int MinUnit, int MaxUnit, bool ColVect);
    virtual ErrorType       SetPolynomials(int MinDeg, int MaxDeg, bool ColVect);
    virtual ErrorType       SetDataRandom(double Amp=1., int seed=0);
    virtual ErrorType       SetDataGaussian(double Amp=1., int seed=0);
    virtual ErrorType       SetElement(int irow, int icol, double Value);
    virtual ErrorType       AddElement(int irow, int icol, double Value);
    virtual ErrorType       SetBlock(int icol, int irow, const UMatrix& Block);
    virtual ErrorType       AddBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType       SubtractBlock(int row, int col, const UMatrix& Block);
    virtual ErrorType       ApplyFunction(double (f)(double));
    virtual ErrorType       ApplySquareRoot();
    virtual ErrorType       ApplyInverse();
    virtual ErrorType       ApplyAbs();
    virtual ErrorType       MinimizeElements(double Thresh, bool Fabs, bool** pSuperThreshold=NULL);
    virtual ErrorType       MaximizeElements(double Thresh, bool Fabs, bool** pSubThreshold=NULL);
    virtual ErrorType       SetRangeElements(double Tmin, double Tmax, bool** pSubThreshold=NULL);
    virtual ErrorType       NormalizeRows(int skiprow1=-1, int skiprow2=-1, int skiprow3=-1);
    virtual ErrorType       NormalizeCols(int skipcol1=-1, int skipcol2=-1, int skipcol3=-1);
    virtual ErrorType       DeMeanRows(int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType       DeMeanCols(int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType       SubstractCol(int icol, int skipcol1=-1, int skipcol2=-1);
    virtual ErrorType       SubstractRow(int irow, int skiprow1=-1, int skiprow2=-1);
    virtual ErrorType       ReverseCols(void);
    virtual ErrorType       ReverseRows(void);
    virtual ErrorType       SwapCols(int col1, int col2);
    virtual ErrorType       SwapRows(int row1, int row2);
    virtual ErrorType       SelectRowCol(const bool* SelectRowCol);
    virtual ErrorType       MergeRows(const UMatrix& M);
    virtual ErrorType       MergeCols(const UMatrix& M);
    virtual ErrorType       MergeCols(const double* Col0, const double* Col1, const double* Col2, int Nr);

    virtual ErrorType       InvertSqrt(int NPos=-1);                // These functions call Decompose()
    virtual ErrorType       Sqrt(void);
    UMatrix                 GetInvertSqrt(int NPos=-1);
    UMatrix                 GetSqrt(void);
    ErrorType               Invert(int NPos=-1, int NNeg=0);
    UMatrixSymmetric        GetInverse(int NPos=-1, int NNeg=0);
    double                  GetSignDet(void);
    double                  GetLogAbsDet(void);
    UMatrix                 GetAxIsB(const UMatrix& B, int NPos=-1, int NNeg=0);
    double                  GetSmallestEigen(void);
    double                  GetSmallestNonZeroEigen(void);
    double                  GetLargestEigen(void);
    double                  GetEigen(int i);
    double*                 GetNormalizedEigen(bool Percentage);
    UMatrix                 GetEigenVector(int i);
    UMatrix                 GetEigenVectors(int i1, int i2);
    UMatrix                 GetUMat();                              // Matrix with eigenvectors (MT=U_MAT_SYMMETRIC)
    UMatrix                 GetLamda();                             // Diagonal matrix with sorted eigen values

    int                     GetNPosEig(double RelAverAbsEigenThresh);
    int                     GetNNegEig(double RelAverAbsEigenThresh);
    UMatrix                 GetAMAT(const UMatrix& A, bool InvertM, int NPos=-1, int NNeg=0); // Allow update of decomposition and WMat
    UMatrix                 GetATMA(const UMatrix& A, bool InvertM, int NPos=-1, int NNeg=0);
    double                  GetVTMV(const UMatrix& A, bool InvertM, int NPos=-1, int NNeg=0);
    UMatrix                 GetA1TMA2(const UMatrix& A1, const UMatrix& A2, bool InvertM, int NPos=-1, int NNeg=0);
    double                  GetV1TMV2(const UMatrix& V1, const UMatrix& V2, bool InvertM, int NPos=-1, int NNeg=0);

    UMatrix                 GetClusteringCoefficients(void) const;
    UMatrix                 GetPathLenghtMatrix(double WeightInfiniteDist=-1.) const;
    ErrorType               ResetDecomp();

protected:
    void                    SetAllMembersDefault(void);
    void                    DeleteAllMembers(ErrorType E);

private:
    static UString          Properties;         // General property string.
    ErrorType               error;              // General error flag

    bool                    Decomposed;
    bool                    Singular;
    double                  LogAbsDet;
    bool                    SignDetPos;
    int                     NNeigPos;
    int                     NNeigNeg;
    UMatrix                 Lamda;              // UMatrix(*this) = UMat * Lamda * UMatT
    UMatrix                 UMat;
    int*                    DiagIndex;          // Used to sort diagonal elements in case of MT==U_MAT_DIAGONAL
                                                // The following members are only set if(MT==U_MAT_SYMMETRIC) and are only use in
                                                // GetAMAT() and GetAMAT() (and GetADiagMADiag())
    bool                    InvWmat;            // If(InvWmat)   UMatrix(*this) =  WMat * WMatT
    UMatrix                 WMat;               // Else          UMatrix(*this) = (WMat * WMatT)Inv

protected:
    virtual ErrorType       Decompose(void);    // Decompose in eigenvalues/eigenvectors

private:
    ErrorType               UpdateWmat(bool SetInv);
    UMatrix                 GetADiagMADiag(const UMatrix& A, bool InvertM, int NPos, int NNeg);
};
ErrorType                   ComputeJointDiagonalize(UMatrixSymmetric& A, UMatrixSymmetric& B, double MaxEigenOffset, UMatrix& Z, UMatrix& DiagA, UMatrix& DiagB);

#endif //_MATRIXSYMMETRIC_INCLUDED

