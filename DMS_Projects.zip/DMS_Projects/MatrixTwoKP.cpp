/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     Module for keeping track of a matrix structure consting of a sum of two   */
/*     Kronecker products.                                                       */
/*     Mat = XX1 * TT1 + XX2 * TT2                                               */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    25-12-13   creation
  JdM    06-03-14   Changed interface. Use UMatrixSymmetric i.s.o. UCovariance
  JdM    18-07-14   Added GetFrobNorm2(), GetFrobNorm(), and tested version of GetLogAbsDet()
  JdM    19-07-14   GetFrobNormDifference2(). Removed constrained of non-diagonallity
                    Only call Decompose() when function requires it (not in constructor)
*/

#include "MatrixTwoKP.h"
#include "Matrix.h"
#include "MatrixSquare.h"
#include "Covariance.h"
#include "DecompHermitian.h"

static UMatrixTwoKP MERROR(U_ERROR);

void UMatrixTwoKP::SetAllMembersDefault(void)
{
    error       = U_OK;
    XX1         = UMatrixSymmetric();
    XX2         = UMatrixSymmetric();
    TT1         = UMatrixSymmetric();
    TT2         = UMatrixSymmetric();

    Decomposed  = false;
    NX          = 0;
    NT          = 0;

    LambXX1     = UMatrix();
    LambXX2     = UMatrix();
    ZmatXX      = UMatrix();
    LambTT1     = UMatrix();
    LambTT2     = UMatrix();
    ZmatTT      = UMatrix();
}
void UMatrixTwoKP::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error   = E;
}

UMatrixTwoKP::UMatrixTwoKP()
{
    SetAllMembersDefault();
}
UMatrixTwoKP::UMatrixTwoKP(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}
UMatrixTwoKP::UMatrixTwoKP(const UMatrixTwoKP& TKP)
{
    SetAllMembersDefault();
    *this = TKP;
}
UMatrixTwoKP::UMatrixTwoKP(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2)
{
    SetAllMembersDefault();
    if(SetComponents(X1, X2, T1, T2)!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::UMatrixTwoKP(). Setting components. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
}
UMatrixTwoKP::~UMatrixTwoKP()
{
    DeleteAllMembers(U_OK);
}
UMatrixTwoKP& UMatrixTwoKP::operator=(const UMatrixTwoKP& TKP)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::operator=(). this==NULL. \n");
        return MERROR;
    }
    if(&TKP==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::operator=(). Argument has invalid NULL address. \n");
        return *this;
    }
    if(this==&TKP) return *this;

    DeleteAllMembers(U_OK);

    XX1 = TKP.XX1;
    XX2 = TKP.XX2;
    TT1 = TKP.TT1;
    TT2 = TKP.TT2;

    if( XX1.GetError()!=U_OK || XX2.GetError() || TT1.GetError()!=U_OK || TT2.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixTwoKP::operator=(). Copying (covariance) matrices. \n");
        return *this;
    }

    NX      = TKP.NX;
    NT      = TKP.NT;

    Decomposed  = TKP.Decomposed;
    LambXX1     = TKP.LambXX1;
    LambXX2     = TKP.LambXX2;
    ZmatXX      = TKP.ZmatXX ;
    LambTT1     = TKP.LambTT1;
    LambTT2     = TKP.LambTT2;
    ZmatTT      = TKP.ZmatTT ;
    if( LambXX1.GetError()!=U_OK || LambXX2.GetError()!=U_OK || ZmatXX.GetError()!=U_OK ||
        LambTT1.GetError()!=U_OK || LambTT2.GetError()!=U_OK || ZmatTT.GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMatrixTwoKP::operator=(). Copying joint diagonalisation matrices. \n");
        return *this;
    }
    return *this;
}

const UMatrixSymmetric& UMatrixTwoKP::GetCovXX1() const
{
    if(this==NULL   || error!=U_OK) return (const UMatrixSymmetric&)MERROR;
    return XX1;
}
const UMatrixSymmetric& UMatrixTwoKP::GetCovXX2() const
{
    if(this==NULL   || error!=U_OK) return (const UMatrixSymmetric&)MERROR;
    return XX2;
}
const UMatrixSymmetric& UMatrixTwoKP::GetCovTT1() const
{
    if(this==NULL   || error!=U_OK) return (const UMatrixSymmetric&)MERROR;
    return TT1;
}
const UMatrixSymmetric& UMatrixTwoKP::GetCovTT2() const
{
    if(this==NULL   || error!=U_OK) return (const UMatrixSymmetric&)MERROR;
    return TT2;
}
double UMatrixTwoKP::GetLogAbsDet(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetLogAbsDet(). Object NULL or erroneous. \n");
        return 0.;
    }
    if(Decomposed==false && Decompose()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetLogAbsDet(). Decomposing matrices. \n");
        return 0.;
    }
    double Res = NT*XX1.GetLogAbsDet() + NX*TT1.GetLogAbsDet();
    for(int i=0; i<NX; i++)
    {
        double L1X = LambXX1.GetElement(i,i);
        double L2X = LambXX2.GetElement(i,i);
        for(int j=0; j<NT; j++)
        {
            double L1T = LambTT1.GetElement(j,j);
            double L2T = LambTT2.GetElement(j,j);
            if(fabs(L1T)<1.e-100 || fabs(L1X)<1.e-100)
            {
                CI.AddToLog("ERROR: UMatrixTwoKP::GetLogAbsDet(). XX1 or TT1 is singular, L1T=%g, L1X=%g. \n", L1T, L1X);
                return 0.;
            }
            Res += log(fabs(1. + L2T*L2X/(L1T*L1X)));
        }
    }
    return Res;
}
double UMatrixTwoKP::GetLogAbsDetTest(void)
{
    UMatrixSquare M = UMatrix(XX1, TT1) + UMatrix(XX2, TT2);
    return M.GetLogAbsDet();
}

ErrorType UMatrixTwoKP::NormalizeBalanced(bool FromEigen)
{
    if(this==NULL   || error!=U_OK                 ) return U_ERROR;
    if(Decomposed==false && Decompose()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::NormalizeBalanced(). Performing Joint Decompositions.\n");
        return U_ERROR;
    }

    double al = FromEigen ? LambXX1.GetElement(NX-1,NX-1)    : XX1.GetElement(0);
    double be = FromEigen ? LambXX2.GetElement(NX-1,NX-1)    : XX2.GetElement(0);
    double ga = FromEigen ? LambTT1.GetElement(NT-1,NT-1)    : TT1.GetElement(0);
    double de = FromEigen ? LambTT2.GetElement(NT-1,NT-1)    : TT2.GetElement(0);

    const double AA = FromEigen ? sqrt(fabs(al*ga+be*de-1.)) : 1.;
    const double BB = FromEigen ? 1.                         : sqrt(fabs(al*ga+be*de-1.));
    const double CC = FromEigen ? (al*ga+be*de-1.)/AA        : 1.;
    const double DD = FromEigen ? 1.                         : (al*ga+be*de-1.)/BB;
    double     ABCD = AA*CC+BB*DD;

    double a = (be*DD+ga*AA)/ABCD;
    double b = (ga*BB-be*CC)/ABCD;
    double c = (de*AA-al*DD)/ABCD;
    double d = (de*BB+al*CC)/ABCD;

    return Normalize(a, b, c, d);
}

ErrorType UMatrixTwoKP::NormalizeSymmectric(bool FromEigen)
{
    if(this==NULL   || error!=U_OK                 ) return U_ERROR;
    if(Decomposed==false && Decompose()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::NormalizeSymmectric(). Performing Joint Decompositions.\n");
        return U_ERROR;
    }

    double al = FromEigen ? LambXX1.GetElement(NX-1,NX-1)    : XX1.GetElement(0);
    double be = FromEigen ? LambXX2.GetElement(NX-1,NX-1)    : XX2.GetElement(0);
    double ga = FromEigen ? LambTT1.GetElement(NT-1,NT-1)    : TT1.GetElement(0);
    double de = FromEigen ? LambTT2.GetElement(NT-1,NT-1)    : TT2.GetElement(0);

    const double AA = 1.;
    const double BB = (al*ga==1. || be*de==1.) ? ((al*ga==1.)? sqrt(fabs(be*de)) : sqrt(fabs(al*ga))) : sqrt(fabs(al*ga+be*de-1.));
    const double CC = 1.;
    const double DD = (al*ga==1. || be*de==1.) ? ((al*ga==1.)? be*de/BB          : al*ga/BB)          : (al*ga+be*de -1)/BB;
        
    double       Den = be*CC-al*DD;

    double a = ( ga*be - AA*DD)/Den;
    double b = (-al*ga + AA*CC)/Den;
    double c = (-al*ga + AA*CC)/Den;
    double d = (-al*de + BB*CC)/Den;

    return Normalize(a, b, c, d);
}

ErrorType UMatrixTwoKP::Normalize(double a, double b, double c, double d)
{
    if(this==NULL   || error!=U_OK) return U_ERROR;

    if(XX1.GetError()!=U_OK || XX1.GetMatrixArray()==NULL || XX2.GetError()!=U_OK  || XX2.GetMatrixArray()==NULL ||
       TT1.GetError()!=U_OK || TT1.GetMatrixArray()==NULL || TT2.GetError()!=U_OK  || TT2.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Normalize(). One the matrix components NULL or erroneous. \n");
        return U_ERROR;
    }

    double Det = a*d-b*c;
    if(fabs(Det)<1.e-20)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Normalize(). Transformation degenerated, Det = %f. \n", Det);
        return U_ERROR;
    }

    Decomposed           = false;
    UMatrixSymmetric Buf = XX1;
    XX1                  = XX1*a + XX2*c;
    XX2                  = Buf*b + XX2*d;
    if(XX1.GetError()!=U_OK || XX1.GetMatrixArray()==NULL || XX2.GetError()!=U_OK  || XX2.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Normalize(). Updating XX matrices. \n");
        return U_ERROR;
    }
    a /= Det;
    b /= Det;
    c /= Det;
    d /= Det;

    Buf = TT1;
    TT1 = TT1*  d  + TT2*(-b);
    TT2 = Buf*(-c) + TT2*  a ;
    if(TT1.GetError()!=U_OK || TT1.GetMatrixArray()==NULL || TT2.GetError()!=U_OK  || TT2.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Normalize(). Updating TT matrices. \n");
        return U_ERROR;
    }
    return U_OK;
}

UMatrix UMatrixTwoKP::GetAxIsB(const UMatrix& B)
{
    if(this==NULL || error!=U_OK) return UMatrix(U_ERROR);

    if(&B==NULL || B.GetError()!=U_OK || B.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetAxIsB(). UMatrix argument NULL or erroneous. \n");
        return UMatrix(U_ERROR);
    }
    if(NX!=B.GetNrow() || NT!=B.GetNcol())
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetAxIsB(). UMatrix dimensions do not fit: Nrow = %d, Ncol=%d  . \n", B.GetNrow(), B.GetNcol());
        return UMatrix(U_ERROR);
    }

    if(Decomposed==false && Decompose()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetAxIsB(). Performing Joint Decompositions.\n");
        return UMatrix(U_ERROR);
    }

    UMatrix Whulp   = GetMatMul(ZmatXX, false, B     ,false);
    UMatrix WXXTWTT = GetMatMul(Whulp , false, ZmatTT,true );

    if(Whulp.GetError()!=U_OK || WXXTWTT.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetAxIsB(). First pre-whitening. \n");
        return UMatrix(U_ERROR);
    }

// Diagonal KP
    for(int i=0; i<NX; i++)
    {
        double LX1 = LambXX1.GetElement(i,i);
        double LX2 = LambXX2.GetElement(i,i);
        for(int j=0; j<NT; j++)
        {
            double LT1 = LambTT1.GetElement(j,j);
            double LT2 = LambTT2.GetElement(j,j);

            WXXTWTT.Data[i*NT+j] /= (LX1*LT1 + LX2*LT2);
        }
    }

    Whulp     = GetMatMul(ZmatXX, true , WXXTWTT, false);
    UMatrix X = GetMatMul(Whulp , false, ZmatTT , false);

    if(Whulp.GetError()!=U_OK || X.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetAxIsB(). Solving system. \n");
        return UMatrix(U_ERROR);
    }
    return X;
}

double UMatrixTwoKP::GetFrobNormDifference(const UMatrixTwoKP& TKP) const
{
    if(this==NULL || error!=U_OK)          return -1.;
    if(&TKP==NULL || TKP.GetError()!=U_OK) return -1.;

    return sqrt(fabs(GetFrobNormDifference2(TKP.XX1, TKP.XX2, TKP.TT1, TKP.TT2)));
}
double UMatrixTwoKP::GetFrobNormDifference(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2) const
{
    if(this==NULL || error!=U_OK)                                                                return -1.;
    if(X1.GetError()!=U_OK || X2.GetError()!=U_OK || T1.GetError()!=U_OK || X2.GetError()!=U_OK) return -1.;

    return sqrt(fabs(GetFrobNormDifference2(X1, X2, T1, T2)));
}
double UMatrixTwoKP::GetFrobNormDifference2(const UMatrixTwoKP& TKP) const
{
    if(this==NULL || error!=U_OK)          return -1.;
    if(&TKP==NULL || TKP.GetError()!=U_OK) return -1.;

    return GetFrobNormDifference2(TKP.XX1, TKP.XX2, TKP.TT1, TKP.TT2);
}
double UMatrixTwoKP::GetFrobNormDifference2(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2) const
{
    if(this==NULL || error!=U_OK) return -1.;

    if(X1.GetError()!=U_OK || X2.GetError()!=U_OK || T1.GetError()!=U_OK || X2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetFrobNormDifference2(). One the matrix components NULL or erroneous. \n");
        return -1.;
    }
    if(X1.GetNcol()!=NX || X1.GetNcol()!=X2.GetNcol()  ||  
       T1.GetNcol()!=NT || T1.GetNcol()!=T2.GetNcol())
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetFrobNormDifference2(). Arguments not compatible dimensioned. \n");
        return -1.;
    }
    const UMatrix* pMatXX[4] = {&XX1, &XX2, &X1, &X2};
    const UMatrix* pMatTT[4] = {&TT1, &TT2, &T1, &T2};
    double Prod[16];
    for(int k1=0; k1<4; k1++)
        for(int k2=0; k2<4; k2++)
        {
            if(k2>=k1)
            {
                Prod[k1*4+k2] = GetTraceM1M2T(*(pMatXX[k1]), *(pMatXX[k2])) * GetTraceM1M2T(*(pMatTT[k1]), *(pMatTT[k2]));
            }
            else
            {
                Prod[k1*4+k2] = Prod[k2*4+k1];
            }
        }

    double SumDif = 0;
    for(int k1=0; k1<4; k1++)
        for(int k2=0; k2<4; k2++)
            if((k1<2 && k2<2) || (k1>=2 && k2>=2))
            {
                SumDif += Prod[k1*4+k2];
            }
            else
            {
                SumDif -= Prod[k1*4+k2];
            }

    return SumDif;
}

double UMatrixTwoKP::GetFrobNorm() const
{
    if(this==NULL || error!=U_OK) return -1;
    return sqrt(fabs(GetFrobNorm2()));
}
double UMatrixTwoKP::GetFrobNorm2() const
{
    if(this==NULL || error!=U_OK) return -1;

    if(XX1.IsDiagonalType()==true || XX2.IsDiagonalType()==true || TT1.IsDiagonalType()==true || TT2.IsDiagonalType()==true)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::GetFrobNorm2(). Function not (yet) implemented for diagonal matrices. \n");
        return -1.;
    }

    const double* pMatXX[2] = {XX1.GetMatrixArray(), XX2.GetMatrixArray()};
    const double* pMatTT[2] = {TT1.GetMatrixArray(), TT2.GetMatrixArray()};
    
    return GetImprod(pMatXX[0], pMatXX[0], NX*NX) * GetImprod(pMatTT[0], pMatTT[0], NT*NT) +
           GetImprod(pMatXX[1], pMatXX[1], NX*NX) * GetImprod(pMatTT[1], pMatTT[1], NT*NT) +
         2*GetImprod(pMatXX[0], pMatXX[1], NX*NX) * GetImprod(pMatTT[0], pMatTT[1], NT*NT);
}

ErrorType UMatrixTwoKP::SetComponents(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2)
{
    if(this==NULL) return U_ERROR;

    DeleteAllMembers(U_OK);

    if(&X1==NULL || X1.GetError()!=U_OK || &X2==NULL || X2.GetError()!=U_OK ||
       &T1==NULL || T1.GetError()!=U_OK || &T2==NULL || T2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::SetComponents(). One the matrix components NULL or erroneous. \n");
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    if(X1.GetNcol()<=0 || X1.GetNcol()!=X2.GetNcol()  ||  
       T1.GetNcol()<=0 || T1.GetNcol()!=T2.GetNcol())
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::SetComponents(). Arguments not compatible dimensioned. \n");
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    Decomposed = false;

    XX1 = X1;    XX2 = X2;
    TT1 = T1;    TT2 = T2;
    if(XX1.GetError()!=U_OK || XX2.GetError()!=U_OK ||
       TT1.GetError()!=U_OK || TT2.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::SetComponents(). Copying one of the components. \n");
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    NX = XX1.GetNcol();
    NT = TT1.GetNcol();

    return U_OK;
}
ErrorType UMatrixTwoKP::Decompose()
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    Decomposed = false;
    if(XX1.GetError()!=U_OK || XX1.GetMatrixArray()==NULL || XX2.GetError()!=U_OK  || XX2.GetMatrixArray()==NULL ||
       TT1.GetError()!=U_OK || TT1.GetMatrixArray()==NULL || TT2.GetError()!=U_OK  || TT2.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Decompose(). One the matrix components NULL or erroneous. \n");
        return U_ERROR;
    }

    if(XX1.GetNcol()<=0 || XX1.GetNcol()!=XX2.GetNcol() || XX1.GetNcol()!=NX ||
       TT1.GetNcol()<=0 || TT1.GetNcol()!=TT2.GetNcol() || TT1.GetNcol()!=NT)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Decompose(). Covariances not compatible dimensioned. \n");
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }

    ErrorType    EX = ComputeJointDiagonalize(XX1, XX2, 1.5, ZmatXX, LambXX1, LambXX2);
    ErrorType    ET = ComputeJointDiagonalize(TT1, TT2, 1.5, ZmatTT, LambTT1, LambTT2);
    if(EX!=U_OK || ET!=U_OK)
    {
        CI.AddToLog("ERROR: UMatrixTwoKP::Decompose(). Jointly diagonalizing covariance components . \n");
        DeleteAllMembers(U_ERROR);
        return U_ERROR;
    }
    Decomposed = true;
    return U_OK;
}

