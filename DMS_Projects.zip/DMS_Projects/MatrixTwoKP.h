#ifndef _MATRIXTWOKP_INCLUDED
#define _MATRIXTWOKP_INCLUDED

#include "MatrixSymmetric.h"

class DLL_IO UMatrixTwoKP
{
public:
    UMatrixTwoKP();
    UMatrixTwoKP(ErrorType E);
    UMatrixTwoKP(const UMatrixTwoKP& TKP);
    UMatrixTwoKP(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2);

    virtual ~UMatrixTwoKP();
    UMatrixTwoKP&       operator= (const UMatrixTwoKP& TKP);

    ErrorType           GetError() const {if(this) return error; return U_ERROR;}
    const UMatrixSymmetric&  GetCovXX1() const;
    const UMatrixSymmetric&  GetCovXX2() const;
    const UMatrixSymmetric&  GetCovTT1() const;
    const UMatrixSymmetric&  GetCovTT2() const;

    UMatrix             GetAxIsB(const UMatrix& B);
    double              GetFrobNormDifference(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2) const;
    double              GetFrobNormDifference(const UMatrixTwoKP& TKP) const;
    double              GetFrobNormDifference2(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2) const;
    double              GetFrobNormDifference2(const UMatrixTwoKP& TKP) const;
    double              GetFrobNorm() const;
    double              GetFrobNorm2() const;
    ErrorType           SetComponents(const UMatrixSymmetric& X1, const UMatrixSymmetric& X2, const UMatrixSymmetric& T1, const UMatrixSymmetric& T2);

    double              GetLogAbsDet(void);
    double              GetLogAbsDetTest(void);

    ErrorType           Normalize(double a, double b, double c, double d);
    ErrorType           NormalizeSymmectric(bool FromEigen);
    ErrorType           NormalizeBalanced(bool FromEigen);

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    ErrorType           error;
    UMatrixSymmetric    XX1;
    UMatrixSymmetric    XX2;
    UMatrixSymmetric    TT1;
    UMatrixSymmetric    TT2;

    int                 NX;      // Same as XX1.GetNcol(), XX1.GetNrow(), XX2.GetNcol(), etc
    int                 NT;      // Same as TT1.GetNcol(), TT1.GetNrow(), TT2.GetNcol(), etc

    UMatrix             LambXX1; // Joint diagonalisation of XX:
    UMatrix             LambXX2; // ZmatXX * XX1 * ZmatXX^t = LambXX1 and ZmatXX * XX2 * ZmatXX^t = LambXX2 
    UMatrix             ZmatXX;  // such that LambXX1 and LambXX2 are diagonal matrices
    UMatrix             LambTT1; // Simimilar for TT:
    UMatrix             LambTT2; // ZmatTT * TT1 * ZmatTT^t = LambTT1 and ZmatTT * TT2 * ZmatTT^t = LambTT2 
    UMatrix             ZmatTT;  //

    bool                Decomposed;
    ErrorType           Decompose(); // Compute Joint diagonilizations
};

#endif // _MATRIXTWOKP_INCLUDED