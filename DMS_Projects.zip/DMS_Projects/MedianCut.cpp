/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*     Mechanism for median-cut color quantization.                              */
/*                                                                               */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    12-10-11   Creation
  JdM    30-11-11   Added double version of GetMedianCut()
  JdM    15-01-12   Added ResetTuples()
                    Added pointer constructors
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    23-04-15   Renamed GetKDTree() as CreateKDTree()
  JdM    25-04-15   UBlockDouble(): added (optional) TupleIndex containing original index as data member, such that UpdateDistanceClosestPoint()
                    and GetDistanceClosestPoint() are able to compute the original point index.
  JdM    27-04-15   Added UBlock::GetEnclosingObjects() and UBlockDouble::GetEnclosingObjects()
  JdM    05-05-15   Added class UListNodeInt and external functions
  JdM    16-05-15   Added UListNodeRange* object and mechanism to remove disjunct ranges RemoveDisjunctRanges()
  JdM    19-05-15   Added GetInRangeObjects()
  JdM    18-09-15   Bug fix: GetInRangeObjects(). if(Left==NULL && Right==NULL) also look in *this for objects.
  JdM    10-12-16   Use DeleteList() to delete a linked list in order to avoid large recursions.
  JdM    05-03-17   Added GetRandomIndices() and AddBlocksDepth()
*/

#include "MedianCut.h"
#include "MatVec.h"
#include "SortSemiSort.h"
#include "Random.h"

UListNodeRange::UListNodeRange() : UListNodeInt()
{
    MinR = MaxR = 0.;
}
UListNodeRange::UListNodeRange(int v, double minR, double maxR) : UListNodeInt(v)
{
    MinR = minR;
    MaxR = maxR;
}
UListNodeRange* Merge(UListNodeRange* L1, UListNodeRange* L2) 
{
    if(L1==NULL && L2==NULL) return NULL;

    if(L1==NULL) return L2;
    if(L2==NULL) return L1;

    if(L1->MinR <= L2->MinR) 
    {
        L1->Next = Merge((UListNodeRange*)L1->Next, L2);
        return L1;
    }
    else
    {
        L2->Next = Merge(L1, (UListNodeRange*)L2->Next);
        return L2;
    }
}
UListNodeRange* MergeSort(UListNodeRange* LNR, int n) 
{
    if(n<=1) return LNR;

    int m = n / 2;
    
    UListNodeInt*   R   = Split((UListNodeInt*)LNR, m);
   
    UListNodeRange* L1  = MergeSort(LNR, m);
    UListNodeRange* L2  = MergeSort((UListNodeRange*)R  , n - m);
   
    return Merge(L1, L2);
}
UListNodeRange* RemoveDisjunctRanges(UListNodeRange* LNR)
{
    if(LNR==NULL) return NULL;

    int           Nelem = LNR->GetListLength();
    if(Nelem<=1) return LNR;

    UListNodeRange* Lsort = MergeSort(LNR, Nelem);
    UListNodeRange* Lold  = Lsort;
    UListNode*      Next  = Lsort->GetNext();
    while(Next)
    {
        if(Lsort->MaxR < ((UListNodeRange*) Next)->MinR)
        {
            Lold->SetNext(Next->GetNext());
            Next->SetNext(NULL); // Prevent deletion of whole chain
            delete Next; Next = Lold->GetNext();
        }
        else
        {
            Lold = (UListNodeRange*)Next;
            Next = Next->GetNext();
        }
    }
    return Lsort;
}


UListNodeInt* Merge(UListNodeInt* L1, UListNodeInt* L2) 
{
    if(L1==NULL && L2==NULL) return NULL;

    if(L1==NULL) return L2;
    if(L2==NULL) return L1;

    if(L1->value <= L2->value) 
    {
        L1->Next = Merge((UListNodeInt*)L1->Next, L2);
        return L1;
    }
    else
    {
        L2->Next = Merge(L1, (UListNodeInt*)L2->Next);
        return L2;
    }
}
UListNodeInt* Split(UListNodeInt* L1, int m)
{
    if(L1==NULL) return NULL;

    UListNodeInt* p = L1;
    for(int k=1; k<m; k++)
    {
        p = (UListNodeInt*)p ->Next;
        if(p==NULL) return NULL;
    }
    UListNodeInt* L2 = (UListNodeInt*)p->Next;
    p->Next = NULL;
    
    return L2;
}
UListNodeInt* MergeSort(UListNodeInt* LNI, int n) 
{
    if(n<=1) return LNI;

    int m = n / 2;
    
    UListNodeInt* R   = Split(LNI, m);
   
    UListNodeInt* L1  = MergeSort(LNI, m);
    UListNodeInt* L2  = MergeSort(R  , n - m);
   
    return Merge(L1, L2);
}
UListNodeInt* RemoveDoubleValues(UListNodeInt* LNI)
{
    if(LNI==NULL) return NULL;

    int           Nelem = LNI->GetListLength();
    if(Nelem<=1) return LNI;

    UListNodeInt* Lsort = MergeSort(LNI, Nelem);
    UListNodeInt* Lold  = Lsort;
    UListNode*    Next  = Lsort->GetNext();
    while(Next)
    {
        if(Lold->value == ((UListNodeInt*) Next)->value)
        {
            Lold->SetNext(Next->GetNext());
            Next->SetNext(NULL); // Prevent deletion of whole chain
            delete Next; Next = Lold->GetNext();
        }
        else
        {
            Lold = (UListNodeInt*)Next;
            Next = Next->GetNext();
        }
    }
    return Lsort;
}

int SetMaxMinTupKD(int N) {int old = MINTUPLES_KDTREE; MINTUPLES_KDTREE = N; return old;}

void UBlock::SetAllMembersDefault(void)
{
    NTuples   =   0;
    Veclen    =   0;
    SplitComp =  -1;
}
void UBlock::DeleteAllMembers(ErrorType E)
{
}

UBlock::UBlock()
{
    SetAllMembersDefault();
}
UBlock::UBlock(const UBlock* pBL) 
{
    SetAllMembersDefault();
    if(pBL==NULL) return;

    if(pBL->Left )  Left  = new UTreeNodeBin(pBL->Left ); 
    if(pBL->Right)  Right = new UTreeNodeBin(pBL->Right); 

    SetBlockParameters(pBL);
}
UBlock::~UBlock() // virtual
{
    DeleteAllMembers(U_OK);
    SetAllMembersDefault();
}

/* virtual functions: */
int           UBlock::FindIndex(const unsigned char* Tuple) const                                        {return 0;}
int           UBlock::FindIndex(const double* Tuple) const                                               {return 0;}
ErrorType     UBlock::SetMean(unsigned char* Tab)                                                        {return U_OK;}
ErrorType     UBlock::ResetTuples(void)                                                                  {return U_OK;}
double        UBlock::GetDistanceClosestPoint(const double* Tuple, int* Index) const                     {return 0.;}
UListNodeInt* UBlock::GetEnclosingObjects(double ObjectRadius, const double* Tuple, int dir) const       {return NULL;}
UListNodeInt* UBlock::GetEnclosingObjects(const double* ObjectWidth, const double* Tuple, int dir) const {return NULL;}
UListNodeInt* UBlock::GetInRangeObjects(double ObjectRadius, const double* Tuple, double Distance) const {return NULL;}
UListNodeInt* UBlock::GetClosestObjects(double ObjectRadius, const double* Tuple) const                  {return NULL;}
UListNodeInt* UBlock::GetClosestObjects(const double* ObjectWidth, const double* Tuple) const            {return NULL;}
ErrorType     UBlock::WriteTxt(FILE* fp, int Depth) const                                                {return U_OK;}

ErrorType UBlock::SetBlockParameters(const UBlock* pBL)
{
    if(this==NULL) return U_ERROR;
    if(pBL ==NULL) return U_ERROR;

    UTreeNodeBin::SetNodeIndex(pBL->GetNodeIndex());

    NTuples   =  pBL->NTuples;
    Veclen    =  pBL->Veclen;
    SplitComp =  pBL->SplitComp;
    return U_OK;
}

UBlock* UBlock::GetLargestNTuplesLeave(void)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UBlock::GetLargestNTuplesLeave(). Object NULL. \n");
        return NULL;
    }
    UBlock* B  = (UBlock*)(this->GetLefMostLeave());
    if(B==NULL)
    {
        CI.AddToLog("ERROR: UBlock::GetLargestNTuplesLeave(). Getting left most leave. \n");
        return NULL;
    }

    int Size = B->NTuples;
    ComputeLargestNTuple(&B, &Size);
    return B;
}
void UBlock::ComputeLargestNTuple(UBlock** B, int* Size)
{
    UBlock* BlockLeft  = (UBlock*) Left;
    UBlock* BlockRight = (UBlock*) Right;
    if(BlockLeft ) 
    {
        BlockLeft ->ComputeLargestNTuple(B, Size);
        BlockRight->ComputeLargestNTuple(B, Size);
    }
    else
    {
        if(NTuples>*Size) 
        {
            *Size = NTuples;
            *B    = this;
        }
    }
}

void UBlockByte::SetAllMembersDefault(void)
{
    Min          = NULL;
    Max          = NULL;
    Mean         = NULL;
    Tuples       = NULL;
}
void UBlockDouble::SetAllMembersDefault(void)
{
    Min          = NULL;
    Max          = NULL;
    Mean         = NULL;
    Tuples       = NULL;
    TupleIndex   = NULL;
}
void UBlockByte::DeleteAllMembers(ErrorType E)
{
    delete[] Min ;
    delete[] Max ;
    delete[] Mean;
    SetAllMembersDefault();
}
void UBlockDouble::DeleteAllMembers(ErrorType E)
{
    delete[] Min ;
    delete[] Max ;
    delete[] Mean;
    SetAllMembersDefault();
}

UBlockByte::UBlockByte()
{
    SetAllMembersDefault();
}
UBlockDouble::UBlockDouble()
{
    SetAllMembersDefault();
}

UBlockByte::UBlockByte(const UBlockByte* pBLB)
{
    SetAllMembersDefault();
    if(pBLB==NULL) return;

    if(pBLB->Left )  Left  = new UBlockByte((const UBlockByte*)pBLB->Left ); 
    if(pBLB->Right)  Right = new UBlockByte((const UBlockByte*)pBLB->Right); 

    SetBlockParameters(pBLB);

    Min      = new unsigned char[Veclen];
    Max      = new unsigned char[Veclen];
    Mean     = new unsigned char[Veclen];
    if(Min==NULL || Max==NULL || Mean==NULL)
    {
        CI.AddToLog("UBlockByte::UBlockByte(). Memory allocation. Veclen = %d \n", Veclen);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int k=0; k<Veclen; k++)
    {
        Min [k] = pBLB->Min [k];
        Max [k] = pBLB->Max [k];
        Mean[k] = pBLB->Mean[k];
    }
    Tuples     = NULL;
}
UBlockDouble::UBlockDouble(const UBlockDouble* pBLD) 
{
    SetAllMembersDefault();
    if(pBLD==NULL) return;

    if(pBLD->Left )  Left  = new UBlockDouble((const UBlockDouble*)pBLD->Left ); 
    if(pBLD->Right)  Right = new UBlockDouble((const UBlockDouble*)pBLD->Right); 

    SetBlockParameters(pBLD);

    Min      = new double[Veclen];
    Max      = new double[Veclen];
    Mean     = new double[Veclen];
    if(Min==NULL || Max==NULL || Mean==NULL)
    {
        CI.AddToLog("UBlockByte::UBlockDouble(). Memory allocation. Veclen = %d \n", Veclen);
        DeleteAllMembers(U_ERROR);
        return;
    }
    for(int k=0; k<Veclen; k++)
    {
        Min [k] = pBLD->Min [k];
        Max [k] = pBLD->Max [k];
        Mean[k] = pBLD->Mean[k];
    }
    Tuples     = NULL;
    TupleIndex = NULL;
}

UBlockByte::UBlockByte(unsigned char** Tupl, int Vecl, int Ntup, int Scomp)
{
    SetAllMembersDefault();
    if(Tupl==NULL)
    {
        CI.AddToLog("UBlockByte::UBlockByte(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Vecl<=0 || Ntup<=0)
    {
        CI.AddToLog("UBlockByte::UBlockByte(). Invalid argument(s): Vecl = %d, Ntup = %d \n", Vecl, Ntup);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Scomp>=Vecl)
    {
        CI.AddToLog("UBlockByte::UBlockByte(). Scomp-parameter out of range: Scomp = %d; Vecl = %d\n", Scomp, Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Min      = new unsigned char[Vecl];
    Max      = new unsigned char[Vecl];
    Mean     = new unsigned char[Vecl];
    if(Min==NULL || Max==NULL || Mean==NULL)
    {
        CI.AddToLog("UBlockByte::UBlockByte(). Memory allocation. Vecl = %d \n", Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Tuples   = Tupl;
    NTuples  = Ntup;
    Veclen   = Vecl;

    UpdateRange();
    if(Scomp>=0) 
    {
        SplitComp = Scomp;
    }
    else // Compute Component with largest  range 
    {
        int m     = Max[0] - Min[0];
        SplitComp = 0;
        for(int k=1; k<Veclen; k++)
        {
            int diff = Max[k] - Min[k];
            if(diff > m)
            {
                m         = diff;
                SplitComp = k;
            }
        }
    }
}
UBlockDouble::UBlockDouble(double** Tupl, int Vecl, int Ntup, int Scomp, int* TupInd)
{
    SetAllMembersDefault();
    if(Tupl==NULL)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Invalid NULL pointer argument. \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Vecl<=0 || Ntup<=0)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Invalid argument(s): Vecl = %d, Ntup = %d \n", Vecl, Ntup);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Scomp>=Vecl)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Scomp-parameter out of range: Scomp = %d; Vecl = %d\n", Scomp, Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Min      = new double[Vecl];
    Max      = new double[Vecl];
    Mean     = new double[Vecl];
    if(Min==NULL || Max==NULL || Mean==NULL)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Memory allocation. Vecl = %d \n", Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Tuples     = Tupl;
    TupleIndex = TupInd;

    NTuples    = Ntup;
    Veclen     = Vecl;

    UpdateRange();
    if(Scomp>=0) 
    {
        SplitComp = Scomp;
    }
    else // Compute Component with largest  range 
    {
        double m     = Max[0] - Min[0];
        SplitComp = 0;
        for(int k=1; k<Veclen; k++)
        {
            double diff = Max[k] - Min[k];
            if(diff > m)
            {
                m         = diff;
                SplitComp = k;
            }
        }
    }
}
UBlockDouble::UBlockDouble(double** Tupl, int Vecl, int Ntup, int Scomp, double* TupMin, double* TupMax, int* TupInd)
{
    SetAllMembersDefault();
    if(Tupl==NULL || TupMin==NULL || TupMax==NULL)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Invalid NULL pointer argument(s). \n");
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Vecl<=0 || Ntup<=0)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Invalid argument(s): Vecl = %d, Ntup = %d \n", Vecl, Ntup);
        DeleteAllMembers(U_ERROR);
        return;
    }
    if(Scomp>=Vecl)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Scomp-parameter out of range: Scomp = %d; Vecl = %d\n", Scomp, Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Min      = new double[Vecl];
    Max      = new double[Vecl];
    Mean     = new double[Vecl];
    if(Min==NULL || Max==NULL || Mean==NULL)
    {
        CI.AddToLog("UBlockDouble::UBlockDouble(). Memory allocation. Vecl = %d \n", Vecl);
        DeleteAllMembers(U_ERROR);
        return;
    }
    Tuples     = Tupl;
    TupleIndex = TupInd;

    NTuples    = Ntup;
    Veclen     = Vecl;

    for(int k=0; k<Veclen; k++) {Min[k] = TupMin[k]; Max[k] = TupMax[k]; Mean[k]=0.;}
    for(int i=0; i <NTuples; i++)
        for(int k=0; k<Veclen; k++)   Mean[k] += Tuples[i][k];

    if(NTuples) for(int k=0; k<Veclen ; k++) Mean[k] /= NTuples;

    if(Scomp>=0) 
    {
        SplitComp = Scomp;
    }
    else // Compute Component with largest  range 
    {
        double m     = Max[0] - Min[0];
        SplitComp = 0;
        for(int k=1; k<Veclen; k++)
        {
            double diff = Max[k] - Min[k];
            if(diff > m)
            {
                m         = diff;
                SplitComp = k;
            }
        }
    }
}
UBlockByte::~UBlockByte()
{
    DeleteAllMembers(U_OK);
}
UBlockDouble::~UBlockDouble()
{
    DeleteAllMembers(U_OK);
}

ErrorType UBlockByte::UpdateRange()
{
    if(Tuples==NULL) 
    {
        if(Mean&&Max&&Min) 
            for(int k=0; k<Veclen; k++)  Min[k] = Max[k] = Mean[k] = 0;
        return U_OK;
    }

/* Compute Min, Max and Mean */
    unsigned int* IMean = new unsigned int[Veclen];
    if(IMean==NULL)
    {
        CI.AddToLog("ERROR: UBlockByte::UpdateRange(). Memory allocation (Veclen=%d).\n", Veclen);
        return U_ERROR;
    }
    for(int k=0; k<Veclen; k++)
    {
        Min[k]   = Max[k]  = Tuples[0][k];
        IMean[k] = Mean[k] = 0;
    }
    for(int i=0; i <NTuples; i++)
    {
        for(int k=0; k<Veclen; k++)
        {
            Min[k]    = MIN(Min[k], Tuples[i][k]);
            Max[k]    = MAX(Max[k], Tuples[i][k]);
            IMean[k] += Tuples[i][k];
        }
    }
    if(NTuples)
        for(int k=0; k<Veclen ; k++) Mean[k]   = (unsigned char)(IMean[k]/NTuples);

    delete[] IMean;
    return U_OK;
}
ErrorType UBlockDouble::UpdateRange()
{
    if(Tuples==NULL) 
    {
        if(Mean&&Max&&Min) 
            for(int k=0; k<Veclen; k++)  Min[k] = Max[k] = Mean[k] = 0.;
        return U_OK;
    }
/* Compute Min, Max and Mean */
    for(int k=0; k<Veclen; k++)
    {
        Min[k]  = Max[k]  = Tuples[0][k];
        Mean[k] = 0;
    }

    for(int i=0; i <NTuples; i++)
    {
        for(int k=0; k<Veclen; k++)
        {
            Min[k]   = MIN(Min[k], Tuples[i][k]);
            Max[k]   = MAX(Max[k], Tuples[i][k]);
            Mean[k] += Tuples[i][k];
        }
    }
    if(NTuples)
        for(int k=0; k<Veclen ; k++) Mean[k] /= NTuples;

    return U_OK;
}

ErrorType UBlockByte::SplitMedian(void)
{
    if(Left || Right)
    {
        CI.AddToLog("ERROR: UBlockByte::SplitMedian(). Not at bottom of tree. \n");
        return U_ERROR;
    }
    if(SplitComp<0 || SplitComp>=Veclen)
    {
        CI.AddToLog("ERROR: UBlockByte::SplitMedian(). SplitComp (%d) out of range. \n", SplitComp);
        return U_ERROR;
    }
    if(NTuples<2)
    {
        CI.AddToLog("ERROR: UBlockByte::SplitMedian(). NTuples (%d) out of range. \n", NTuples);
        return U_ERROR;
    }

    int NMed = (NTuples+1)/2;
    if(SemiSortArray(Tuples, SplitComp, NMed, NTuples)!=U_OK)
    {
        CI.AddToLog("ERROR: UBlockByte::SplitMedian(). Sorting array around median. \n");
        return U_ERROR;
    }
    UBlockByte* BlockLeft  = new UBlockByte(Tuples       , Veclen, NMed        );
    UBlockByte* BlockRight = new UBlockByte(Tuples + NMed, Veclen, NTuples-NMed);

    if(BlockLeft==NULL || BlockRight==NULL)
    {
        delete BlockLeft ;  
        delete BlockRight;  
        CI.AddToLog("ERROR: UBlockByte::SplitMedian(). Creating Left or right branch. \n");
        return U_ERROR;
    }
    return SetLeftRight(BlockLeft, BlockRight);
}
ErrorType UBlockDouble::SplitMedian(void)
{
    if(Left || Right)
    {
        CI.AddToLog("ERROR: UBlockDouble::SplitMedian(). Not at bottom of tree. \n");
        return U_ERROR;
    }
    if(SplitComp<0 || SplitComp>=Veclen)
    {
        CI.AddToLog("ERROR: UBlockDouble::SplitMedian(). SplitComp (%d) out of range. \n", SplitComp);
        return U_ERROR;
    }
    if(NTuples<2)
    {
        CI.AddToLog("ERROR: UBlockDouble::SplitMedian(). NTuples (%d) out of range. \n", NTuples);
        return U_ERROR;
    }

    int NMed = (NTuples+1)/2;
    if(SemiSortArray(Tuples, SplitComp, NMed, NTuples, TupleIndex)!=U_OK)
    {
        CI.AddToLog("ERROR: UBlockDouble::SplitMedian(). Sorting array around median. \n");
        return U_ERROR;
    }
    UBlockDouble* BlockLeft  = new UBlockDouble(Tuples       , Veclen, NMed        , -1, TupleIndex);
    UBlockDouble* BlockRight = new UBlockDouble(Tuples + NMed, Veclen, NTuples-NMed, -1, TupleIndex==NULL?NULL:TupleIndex+NMed);

    if(BlockLeft==NULL || BlockRight==NULL)
    {
        delete BlockLeft ;  
        delete BlockRight;  
        CI.AddToLog("ERROR: UBlockDouble::SplitMedian(). Creating Left or right branch. \n");
        return U_ERROR;
    }
    return SetLeftRight(BlockLeft, BlockRight);
}

ErrorType UBlockDouble::AddPointsLeave(UVector3* Points, int* Tril, int* Npoints, UVector3 View, UVector3 Width, int projdir) const
{
    if(this==NULL                         ) return U_ERROR;
    if(Veclen!=3 || Min==NULL || Max==NULL) return U_ERROR;
    if(Points==NULL                       ) return U_ERROR;
    if(Npoints==NULL || *Npoints<0        ) return U_ERROR;

    if(Left  && ((UBlockDouble*) Left )->AddPointsLeave(Points, Tril, Npoints, View, Width, projdir) !=U_OK) return U_ERROR;
    if(Right && ((UBlockDouble*) Right)->AddPointsLeave(Points, Tril, Npoints, View, Width, projdir) !=U_OK) return U_ERROR;

    if(Left==NULL && Right==NULL)
    {
        for(int k=0; k<Veclen; k++)
        {
            if(k==projdir) continue;
            if(Width[k]+Max[k] < View[k]) return U_OK;
            if(View[k]         < Min[k] ) return U_OK;
        }

        for(int i=0; i<NTuples; i++)
        {
            Points[*Npoints] = UVector3(Tuples[i]);
            Tril[*Npoints]   = TupleIndex[i];
            (*Npoints)++;
        }
    }
    return U_OK;
}

ErrorType UBlockDouble::AddBlockLeaveRanges(UVector3* MinArr, UVector3* MaxArr, int* Iblock, UVector3 View, UVector3 Width, int projdir) const
{
    if(this==NULL                         ) return U_ERROR;
    if(Veclen!=3 || Min==NULL || Max==NULL) return U_ERROR;
    if(MinArr==NULL || MaxArr==NULL       ) return U_ERROR;
    if(Iblock==NULL || *Iblock<0          ) return U_ERROR;

    if(Left  && ((UBlockDouble*) Left )->AddBlockLeaveRanges(MinArr, MaxArr, Iblock, View, Width, projdir) !=U_OK) return U_ERROR;
    if(Right && ((UBlockDouble*) Right)->AddBlockLeaveRanges(MinArr, MaxArr, Iblock, View, Width, projdir) !=U_OK) return U_ERROR;

    if(Left==NULL && Right==NULL)
    {
        for(int k=0; k<Veclen; k++)
        {
            if(k==projdir) continue;
            if(Width[k]+Max[k] < View[k]) return U_OK;
            if(View[k]         < Min[k] ) return U_OK;
        }

        MinArr[*Iblock] = UVector3(Min);
        MaxArr[*Iblock] = UVector3(Max);
        (*Iblock) +=1;
    }
    return U_OK;
}
ErrorType UBlockDouble::AddBlockLeaveRanges(UVector3* MinArr, UVector3* MaxArr, int* Iblock) const
{
    if(this==NULL                         ) return U_ERROR;
    if(Veclen!=3 || Min==NULL || Max==NULL) return U_ERROR;
    if(MinArr==NULL || MaxArr==NULL       ) return U_ERROR;
    if(Iblock==NULL || *Iblock<0          ) return U_ERROR;

    if(Left  && ((UBlockDouble*) Left )->AddBlockLeaveRanges(MinArr, MaxArr, Iblock) !=U_OK) return U_ERROR;
    if(Right && ((UBlockDouble*) Right)->AddBlockLeaveRanges(MinArr, MaxArr, Iblock) !=U_OK) return U_ERROR;

    if(Left==NULL && Right==NULL)
    {
        MinArr[*Iblock] = UVector3(Min);
        MaxArr[*Iblock] = UVector3(Max);
        (*Iblock) +=1;
    }
    return U_OK;
}
ErrorType UBlockDouble::WriteTxt(FILE* fp, int Depth) const
{
    if(this==NULL) return U_ERROR;
    if(fp  ==NULL) return U_ERROR;

    if(Depth<=0) return U_OK;

    fprintf(fp, "NTuples   = %d \n",NTuples);
    fprintf(fp, "Veclen    = %d \n",Veclen);
    fprintf(fp, "NodeIndex = %d \n",GetNodeIndex());
    fprintf(fp, "Depth     = %d \n",Depth );
    fprintf(fp, "Min       = ");
    for(int k=0; k<Veclen; k++) fprintf(fp, "\t %f", Min[k]); 
    fprintf(fp, "\n");
    fprintf(fp, "Max       = ");
    for(int k=0; k<Veclen; k++) fprintf(fp, "\t %f", Max[k]); 
    fprintf(fp, "\n");

    fprintf(fp, "\n");
    ErrorType E = U_OK;
    if(Left  && E==U_OK) {fprintf(fp,"LEFT: \n"); E = ((UBlockDouble*)Left )->WriteTxt(fp, Depth-1);}
    if(Right && E==U_OK) {fprintf(fp,"RIGHT:\n"); E = ((UBlockDouble*)Right)->WriteTxt(fp, Depth-1);}

    return E;
}
int* UBlockDouble::GetRandomIndices(int Depth, int seed, int* NIndex) const
{
    if(this==NULL) return NULL;
    if(seed<=0 || NIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetRandomIndices(). Invalid (NULL) argument(s). \n");
        return NULL;
    }
    int DepthMax = GetMaxDepth(this);
    if(Depth<0 || Depth>DepthMax) Depth = DepthMax;
    if(Depth<0)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetRandomIndices(). Invalid Depth (%d). \n", Depth);
        return NULL;
    }
    int            NIndexAlloc = 1<<Depth;
    UBlockDouble** Blocks      = new UBlockDouble*[NIndexAlloc];
    int*           Index       = new int[NIndexAlloc];
    if(Blocks==NULL || Index==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetRandomIndices(). Memory allocation, NIndexAlloc = %d. \n", NIndexAlloc);
        delete[] Blocks; delete[] Index;
        return NULL;
    }
    int NBlock = 0;
    if(AddBlocksDepth(Blocks, &NBlock, 1, Depth)!=U_OK || NBlock>NIndexAlloc)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetRandomIndices(). Block sampling, NBlock=%d, NIndexAlloc = %d. \n", NBlock, NIndexAlloc);
        delete[] Blocks; delete[] Index;
        return NULL;
    }
    *NIndex = NBlock;

    URandom R(seed);
    for(int k=0; k<NBlock; k++)
    {
        UBlockDouble* B = Blocks[k];
        while(B->Left && B->Right) B = (R.GetRandInt(2)) ? (UBlockDouble*) (B->Left) : (UBlockDouble*) (B->Right);

        Index[k] = TupleIndex[rand()%NTuples];
    }
    delete[] Blocks;
    return Index;
}
ErrorType UBlockDouble::AddBlocksDepth(UBlockDouble** Blocks, int* NBlock, int DepthActual, int DepthRequested) const
{
    if(Blocks==NULL || NBlock==NULL) return U_ERROR;

    if(DepthActual>DepthRequested) return U_ERROR;
    if(DepthActual<DepthRequested) 
    {
        if(Left)  if(((UBlockDouble*)Left )->AddBlocksDepth(Blocks, NBlock, DepthActual+1, DepthRequested)!=U_OK) return U_ERROR;
        if(Right) if(((UBlockDouble*)Right)->AddBlocksDepth(Blocks, NBlock, DepthActual+1, DepthRequested)!=U_OK) return U_ERROR;
    }
    else if(DepthActual==DepthRequested)
    {
        Blocks[(*NBlock)++] = (UBlockDouble*) this;
    }
    return U_OK;
}


UListNodeInt* UBlockDouble::GetEnclosingObjects(double ObjectRadius, const double* Tuple, int projdir) const
{
    if(this==NULL || Tuples==NULL || TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Object NULL or erroneously set (Tuples or TupleIndex). \n");
        return NULL;
    }
    if(Tuple==NULL || ObjectRadius<=0.)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Invalid NULL pointer argument (ObjectRadius = %f). \n", ObjectRadius);
        return NULL;
    }

    UListNodeInt* LNIhead = new UListNodeInt(-1);
    if(LNIhead==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Creating head of UListNodeInt*. \n");
        return NULL;
    }
    UListNodeInt* LNItail = LNIhead;

/* Check other blocks */    
    if(Left ) LNItail = ((UBlockDouble*)Left )->UpdateEnclosingObjects(ObjectRadius*ObjectRadius, Tuple, LNItail, projdir);
    if(Right) LNItail = ((UBlockDouble*)Right)->UpdateEnclosingObjects(ObjectRadius*ObjectRadius, Tuple, LNItail, projdir);

    if(LNItail==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Creating tail of UListNodeInt*. \n");
        DeleteList(LNIhead);
        return NULL;
    }
    return RemoveDoubleValues(LNIhead);
}
UListNodeInt* UBlockDouble::UpdateEnclosingObjects(double ObjectRadius2, const double* Tuple, UListNodeInt* Tail, int projdir) const
{
    if(this     ==NULL)                                         return NULL;
    if(Tuples   ==NULL || Tuples[0] ==NULL || TupleIndex==NULL) return NULL;
    if(Tuple    ==NULL ||                     Tail      ==NULL) return NULL;

    if(GetDistance2(Tuple, projdir)>ObjectRadius2) return Tail;

    if(Left ) Tail = ((UBlockDouble*)Left )->UpdateEnclosingObjects(ObjectRadius2, Tuple, Tail, projdir);
    if(Right) Tail = ((UBlockDouble*)Right)->UpdateEnclosingObjects(ObjectRadius2, Tuple, Tail, projdir);

    if(Left==NULL && Right==NULL)
    {
        UListNodeInt* LNItail = Tail;
        for(int i=0; i<NTuples; i++)
        {
            double Dis2 = 0.;
            for(int k=0; k<Veclen; k++)
            {
                if(k==projdir) continue;
                Dis2 += SQR(Tuples[i][k]-Tuple[k]);
            }
            if(Dis2>ObjectRadius2) continue;

            LNItail->value = TupleIndex[i];
            LNItail->Next  = new UListNodeInt(-1);
            LNItail        = (UListNodeInt*)LNItail->Next;
        }
        Tail = LNItail;
    }
    return Tail;
}

UListNodeInt* UBlockDouble::GetEnclosingObjects(const double* ObjectWidth, const double* Tuple, int projdir) const
{
    if(this==NULL || Tuples==NULL || TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Object NULL or erroneously set (Tuples or TupleIndex). \n");
        return NULL;
    }
    if(ObjectWidth==NULL || Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Invalid NULL pointer argument. \n");
        return NULL;
    }

    UListNodeInt* LNIhead = new UListNodeInt(-1);
    if(LNIhead==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Creating head of UListNodeInt*. \n");
        return NULL;
    }
    UListNodeInt* LNItail = LNIhead;

/* Check other blocks */    
    if(Left ) LNItail = ((UBlockDouble*)Left )->UpdateEnclosingObjects(ObjectWidth, Tuple, LNItail, projdir);
    if(Right) LNItail = ((UBlockDouble*)Right)->UpdateEnclosingObjects(ObjectWidth, Tuple, LNItail, projdir);

    if(LNItail==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetEnclosingObjects(). Creating tail of UListNodeInt*. \n");
        DeleteList(LNIhead);
        return NULL;
    }
    return RemoveDoubleValues(LNIhead);
}
UListNodeInt* UBlockDouble::UpdateEnclosingObjects(const double* ObjectWidth, const double* Tuple, UListNodeInt* Tail, int projdir) const
{
    if(this    ==NULL)                                          return NULL;
    if(Tuples  ==NULL || Tuples[0]  ==NULL || TupleIndex==NULL) return NULL;
    if(Tuple   ==NULL || ObjectWidth==NULL || Tail      ==NULL) return NULL;

    if(SplitComp!=projdir)
    {
        if(Tuple[SplitComp]                      < Min[SplitComp]  ) return Tail;
        if(Max[SplitComp]+ObjectWidth[SplitComp] < Tuple[SplitComp]) return Tail;
    }

    if(Left ) Tail = ((UBlockDouble*)Left )->UpdateEnclosingObjects(ObjectWidth, Tuple, Tail, projdir);
    if(Right) Tail = ((UBlockDouble*)Right)->UpdateEnclosingObjects(ObjectWidth, Tuple, Tail, projdir);

    if(Left==NULL && Right==NULL)
    {
        UListNodeInt* LNItail = Tail;
        for(int i=0; i<NTuples; i++)
        {
            bool Enclosed = true;
            for(int k=0; k<Veclen; k++)
            {
                if(k==projdir) continue;
                if(Tuples[i][k]+ObjectWidth[k] < Tuple[k]  || Tuple[k] < Tuples[i][k]) 
                {
                    Enclosed = false; 
                    break;
                }
            }
            if(Enclosed==false) continue;

            LNItail->value = TupleIndex[i];
            LNItail->Next  = new UListNodeInt(-1);
            LNItail        = (UListNodeInt*)LNItail->Next;
        }
        Tail = LNItail;
    }
    return Tail;
}

UListNodeInt* UBlockDouble::GetInRangeObjects(double ObjectRadius, const double* Tuple, double Distance) const
{
    if(this==NULL || Tuples==NULL || TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetInRangeObjects(). Object NULL or erroneously set (Tuples or TupleIndex). \n");
        return NULL;
    }
    if(Tuple==NULL || ObjectRadius<0. || Distance<0.)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetInRangeObjects(). Invalid (NULL) pointer argument(s). ObjectRadius=%f, Distance=%f .\n", ObjectRadius, Distance);
        return NULL;
    }

    UListNodeInt* LNIhead = NULL;
    UListNodeInt* LNItail = NULL;

/* Check other blocks */    
    if(Left ) LNItail = ((UBlockDouble*)Left )->UpdateInRangeObjects(ObjectRadius, Tuple, LNItail, &LNIhead, Distance);
    if(Right) LNItail = ((UBlockDouble*)Right)->UpdateInRangeObjects(ObjectRadius, Tuple, LNItail, &LNIhead, Distance);

    if(Left==NULL && Right==NULL)
    {
        for(int i=0; i<NTuples; i++)
        {
            double TestMin = 0.;
            double TestMax = 0.;
            ComputeDistanceRange(ObjectRadius, i, Tuple, &TestMin, &TestMax);

            if(TestMin>Distance) continue;
            if(LNIhead==NULL)
            {
                LNIhead = LNItail = new UListNodeInt(TupleIndex[i]);
            }
            else
            {
                LNItail->Next  = new UListNodeInt(TupleIndex[i]);
                LNItail        = (UListNodeInt*)LNItail->Next;
            }
        }
    }
    return RemoveDoubleValues(LNIhead);
}
UListNodeInt* UBlockDouble::UpdateInRangeObjects(double ObjectRadius, const double* Tuple, UListNodeInt* Tail, UListNodeInt** Head, double Distance) const
{
    if(this     ==NULL)                                         return NULL;
    if(Tuples   ==NULL || Tuples[0] ==NULL || TupleIndex==NULL) return NULL;
    if(Min      ==NULL || Max       ==NULL                    ) return NULL;
    if(Tuple    ==NULL || Head      ==NULL                    ) return NULL;

    double TestMin  = 0.;
    ComputeDistanceRange(ObjectRadius, -1, Tuple, &TestMin, NULL);
    if(TestMin>Distance) return Tail;

    if(Left ) Tail = ((UBlockDouble*)Left )->UpdateInRangeObjects(ObjectRadius, Tuple, Tail, Head, Distance);
    if(Right) Tail = ((UBlockDouble*)Right)->UpdateInRangeObjects(ObjectRadius, Tuple, Tail, Head, Distance);

    UListNodeInt* LNItail = Tail;
    if(Left==NULL && Right==NULL)
    {
        for(int i=0; i<NTuples; i++)
        {
            double TestMin = 0.;
            double TestMax = 0.;
            ComputeDistanceRange(ObjectRadius, i, Tuple, &TestMin, &TestMax);

            if(TestMin>Distance) continue;
            if(*Head==NULL)
            {
                *Head = LNItail = new UListNodeInt(TupleIndex[i]);
            }
            else
            {
                LNItail->Next  = new UListNodeInt(TupleIndex[i]);
                LNItail        = (UListNodeInt*)LNItail->Next;
            }
        }
    }
    return LNItail;
}

UListNodeInt* UBlockDouble::GetClosestObjects(double ObjectRadius, const double* Tuple) const
{
    if(this==NULL || Tuples==NULL || TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Object NULL or erroneously set (Tuples or TupleIndex). \n");
        return NULL;
    }
    if(Tuple==NULL || ObjectRadius<=0.)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Invalid NULL pointer argument(s). ObjectRadius=%f .\n", ObjectRadius);
        return NULL;
    }

/* Find distance to closest point in enclosing block */
    UBlockDouble* B = (UBlockDouble*) FindBlockLeave(Tuple);
    if(B==NULL || B->Tuples==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Block not found or erroneous. \n");
        return NULL;
    }
    if(B->Tuples[0]==NULL || B->TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). (First) tuple not set: Tuples[0]==NULL. \n");
        return NULL;
    }
    double DisMin = 0.;
    double DisMax = 0.;
    B->ComputeDistanceRange(ObjectRadius, 0, Tuple, &DisMin, &DisMax);

    UListNodeRange* LNIhead = new UListNodeRange(B->TupleIndex[0], DisMin, DisMax);
    if(LNIhead==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Creating head of UListNodeRange*. \n");
        return NULL;
    }
    UListNodeRange* LNItail = LNIhead;

    for(int i=1; i<B->NTuples; i++)
    {
        double TestMin = 0.;
        double TestMax = 0.;
        B->ComputeDistanceRange(ObjectRadius, i, Tuple, &TestMin, &TestMax);

        if(TestMin>DisMax) continue;
        if(TestMax<DisMin)
        {
            DeleteList(LNIhead);
            LNItail = LNIhead = new UListNodeRange(B->TupleIndex[i], TestMin, TestMax);
            DisMin  = TestMin;
            DisMax  = TestMax;
        }
        else
        {
            LNItail->Next  = new UListNodeRange(B->TupleIndex[i], TestMin, TestMax);
            LNItail        = (UListNodeRange*)LNItail->Next;
            DisMin         = MIN(DisMin, TestMin);
            DisMax         = MIN(DisMax, TestMax);
        }
    }

/* Check other blocks */    
    if(Left ) LNItail = ((UBlockDouble*)Left )->UpdateClosestObjects(ObjectRadius, Tuple, LNItail, &DisMin, &DisMax);
    if(Right) LNItail = ((UBlockDouble*)Right)->UpdateClosestObjects(ObjectRadius, Tuple, LNItail, &DisMin, &DisMax);

    if(LNItail==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Creating tail of UListNodeInt*. \n");
        DeleteList(LNIhead);
        return NULL;
    }
    
////
    int Len1 = LNIhead->GetListLength();
    LNIhead  = (UListNodeRange*) RemoveDoubleValues(LNIhead);
    int Len2 = LNIhead->GetListLength();
    LNIhead  = (UListNodeRange*) RemoveDisjunctRanges(LNIhead);
    int Len3 = LNIhead->GetListLength();

    return LNIhead;
////
    
////    return RemoveDoubleValues(LNIhead);
}
UListNodeRange* UBlockDouble::UpdateClosestObjects(double ObjectRadius, const double* Tuple, UListNodeRange* Tail, double* DisMin, double* DisMax) const
{
    if(this     ==NULL)                                         return NULL;
    if(Tuples   ==NULL || Tuples[0] ==NULL || TupleIndex==NULL) return NULL;
    if(Min      ==NULL || Max       ==NULL                    ) return NULL;
    if(Tuple    ==NULL ||                     Tail      ==NULL) return NULL;
    if(DisMin   ==NULL || DisMax    ==NULL                    ) return NULL;

    double TestMin  = 0.;
    ComputeDistanceRange(ObjectRadius, -1, Tuple, &TestMin, NULL);
    if(TestMin>*DisMax) return Tail;

    if(Left ) Tail = ((UBlockDouble*)Left )->UpdateClosestObjects(ObjectRadius, Tuple, Tail, DisMin, DisMax);
    if(Right) Tail = ((UBlockDouble*)Right)->UpdateClosestObjects(ObjectRadius, Tuple, Tail, DisMin, DisMax);

    if(Left==NULL && Right==NULL)
    {
        UListNodeRange* LNItail = Tail;
        for(int i=0; i<NTuples; i++)
        {
            double TestMin = 0.;
            double TestMax = 0.;
            ComputeDistanceRange(ObjectRadius, i, Tuple, &TestMin, &TestMax);

            if(TestMin<*DisMax)
            {
                LNItail->Next  = new UListNodeRange(TupleIndex[i], TestMin, TestMax);
                LNItail        = (UListNodeRange*)LNItail->Next;
                *DisMin        = MIN(*DisMin, TestMin);
                *DisMax        = MIN(*DisMax, TestMax);
            }
        }
        Tail = LNItail;
    }
    return Tail;
}

UListNodeInt* UBlockDouble::GetClosestObjects(const double* ObjectWidth, const double* Tuple) const
{
    if(this==NULL || Tuples==NULL || TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Object NULL or erroneously set (Tuples or TupleIndex). \n");
        return NULL;
    }
    if(ObjectWidth==NULL || Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Invalid NULL pointer argument(s). \n");
        return NULL;
    }
    for(int k=0; k<Veclen; k++)
        if(ObjectWidth[k]<=0.)
        {
            CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Invalid range (ObjectWidth[%d] = %f) . \n", k, ObjectWidth[k]);
            return NULL;
        }

/* Find distance to closest point in enclosing block */
    double* Mid = new double[Veclen];
    if(Mid) for(int k=0; k<Veclen; k++) Mid[k] = Tuple[k] + 0.5*ObjectWidth[k];
    UBlockDouble* B = Mid? (UBlockDouble*) FindBlockLeave(Mid) : NULL;
    delete[] Mid;
    if(B==NULL || B->Tuples==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Block not found or erroneous. \n");
        return NULL;
    }
    if(B->Tuples[0]==NULL || B->TupleIndex==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). (First) tuple not set: Tuples[0]==NULL. \n");
        return NULL;
    }

    double DisMin2 = 0.;
    double DisMax2 = 0.;
    B->ComputeDistance2Range(ObjectWidth, 0, Tuple, &DisMin2, &DisMax2);
    UListNodeRange* LNIhead = new UListNodeRange(B->TupleIndex[0], DisMin2, DisMax2);
    if(LNIhead==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Creating head of UListNodeInt*. \n");
        return NULL;
    }
    UListNodeRange* LNItail = LNIhead;

    for(int i=1; i<B->NTuples; i++)
    {
        double TestMin2 = 0.;
        double TestMax2 = 0.;
        B->ComputeDistance2Range(ObjectWidth, i, Tuple, &TestMin2, &TestMax2);

        if(TestMin2>DisMax2) continue;
        if(TestMax2<DisMin2)
        {
            DeleteList(LNIhead);
            LNItail = LNIhead = new UListNodeRange(B->TupleIndex[i], TestMin2, TestMax2);
            DisMin2 = TestMin2;
            DisMax2 = TestMax2;
        }
        else
        {
            LNItail->Next  = new UListNodeRange(B->TupleIndex[i], TestMin2, TestMax2);
            LNItail        = (UListNodeRange*)LNItail->Next;
            DisMin2        = MIN(DisMin2, TestMin2);
            DisMax2        = MIN(DisMax2, TestMax2);
        }
    }

/* Check other blocks */    
    if(Left ) LNItail = ((UBlockDouble*)Left )->UpdateClosestObjects( ObjectWidth, Tuple, LNItail, &DisMin2, &DisMax2);
    if(Right) LNItail = ((UBlockDouble*)Right)->UpdateClosestObjects( ObjectWidth, Tuple, LNItail, &DisMin2, &DisMax2);

    if(LNItail==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetClosestObjects(). Creating tail of UListNodeInt*. \n");
        DeleteList(LNIhead);
        return NULL;
    }
    return RemoveDoubleValues(LNIhead);
}
UListNodeRange* UBlockDouble::UpdateClosestObjects(const double* ObjectWidth, const double* Tuple, UListNodeRange* Tail, double* DisMin2, double* DisMax2) const
{
    if(this    ==NULL)                                          return NULL;
    if(Tuples  ==NULL || Tuples[0]  ==NULL || TupleIndex==NULL) return NULL;
    if(Min     ==NULL || Max        ==NULL                    ) return NULL;
    if(Tuple   ==NULL || ObjectWidth==NULL || Tail      ==NULL) return NULL;
    if(DisMin2 ==NULL || DisMax2    ==NULL                    ) return NULL;

    double TestMin2 = 0.;
    ComputeDistance2Range(ObjectWidth, -1, Tuple, &TestMin2, NULL);
    if(TestMin2>*DisMax2) return Tail;

    if(Left ) Tail = ((UBlockDouble*)Left )->UpdateClosestObjects(ObjectWidth, Tuple, Tail, DisMin2, DisMax2);
    if(Right) Tail = ((UBlockDouble*)Right)->UpdateClosestObjects(ObjectWidth, Tuple, Tail, DisMin2, DisMax2);

    if(Left==NULL && Right==NULL)
    {
        UListNodeRange* LNItail = Tail;
        for(int i=0; i<NTuples; i++)
        {
            double TestMin2 = 0.;
            double TestMax2 = 0.;
            ComputeDistance2Range(ObjectWidth, i, Tuple, &TestMin2, &TestMax2);

            if(TestMin2<*DisMax2)
            {
                LNItail->Next  = new UListNodeRange(TupleIndex[i], TestMin2, TestMax2);
                LNItail        = (UListNodeRange*)LNItail->Next;
                *DisMin2       = MIN(*DisMin2, TestMin2);
                *DisMax2       = MIN(*DisMax2, TestMax2);
            }
        }
        Tail = LNItail;
    }
    return Tail;
}

double UBlockDouble::GetDistanceClosestPoint(const double* Tuple, int* Index) const
{
    if(this==NULL || Tuples==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistanceClosestPoint(). Object NULL or erroneously set. \n");
        return 0;
    }
    if(Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistanceClosestPoint(). Invalid NULL pointer argument. \n");
        return 0;
    }

/* Find distance to closest point in enclosing block */
    UBlockDouble* B = (UBlockDouble*) FindBlockLeave(Tuple);
    if(B==NULL || B->Tuples==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistanceClosestPoint(). Block not found or erroneous. \n");
        return 0.;
    }
    if(B->Tuples[0]==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistanceClosestPoint(). (First) tuple not set: Tuples[0]==NULL. \n");
        return 0.;
    }
    if(Index)
    {
        if(B->TupleIndex==NULL)
        {
            *Index = -1; Index = NULL;
            CI.AddToLog("WARNING: UBlockDouble::GetDistanceClosestPoint(). TupleIndex array not set, requested original index set to -1. \n");
        }
        else
        {
            *Index = B->TupleIndex[0];
        }
    }

    double Dis2 = 0;
    for(int k=0; k<Veclen; k++) Dis2 += SQR(Tuple[k]-B->Tuples[0][k]);
    for(int i=1; i<B->NTuples; i++)
    {
        double Test2 = 0;
        for(int k=0; k<Veclen; k++) Test2 += SQR(Tuple[k]-B->Tuples[i][k]);
        if(Test2>=Dis2) continue;
        
        if(Index) *Index = B->TupleIndex[i];
        Dis2 = Test2;
    }

/* Check other blocks */    
    if(Left ) ((UBlockDouble*)Left )->UpdateDistanceClosestPoint(Tuple, &Dis2, Index);
    if(Right) ((UBlockDouble*)Right)->UpdateDistanceClosestPoint(Tuple, &Dis2, Index);
    return sqrt(Dis2);
}
ErrorType UBlockDouble::UpdateDistanceClosestPoint(const double* Tuple, double* DisMin2, int* Index) const
{
    if(this ==NULL                 ) return U_ERROR;
    if(Tuple==NULL || DisMin2==NULL) return U_ERROR;

    if(this->GetDistance2(Tuple) > *DisMin2) return U_OK;

    if(Left ) ((UBlockDouble*)Left )->UpdateDistanceClosestPoint(Tuple, DisMin2, Index);
    if(Right) ((UBlockDouble*)Right)->UpdateDistanceClosestPoint(Tuple, DisMin2, Index);

    if(Left==NULL && Right==NULL)
    {
        if(Tuples[0]==NULL) return U_ERROR;

        if(Index && TupleIndex==NULL) Index = NULL;
        for(int i=0; i<NTuples; i++)
        {
            double Test2 = 0;
            for(int k=0; k<Veclen; k++) Test2 += SQR(Tuple[k]-Tuples[i][k]);
            if(Test2>=*DisMin2) continue;
            
            if(Index) *Index = TupleIndex[i];
            *DisMin2 = Test2;
        }
    }
    return U_OK;
}
ErrorType UBlockDouble::ComputeDistance2Range(const double* ObjectWidth, int itup, const double* Tuple, double* DisMin2, double* DisMax2) const
{
    if(this==NULL || Tuples==NULL || Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistance2Range(). Object NULL or erroneously set. \n");
        return U_ERROR;
    }
    if(ObjectWidth==NULL || Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistance2Range(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(itup>=NTuples)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistance2Range(). itup (=%d) out of range. \n", itup);
        return U_ERROR;
    }

    double TestMin = 0.;
    double TestMax = 0.;
    for(int k=0; k<Veclen; k++)
    {
        const double* T = (itup>=0) ? Tuples[itup]   : Min;
        const double  W = (itup>=0) ? ObjectWidth[k] : Max[k]-Min[k]+ObjectWidth[k];
        if(     Tuple[k]<T[k] )
        {
            TestMin += SQR(T[k]     - Tuple[k]);
            TestMax += SQR(T[k] + W - Tuple[k]);
        }
        else if(Tuple[k]>T[k]+W) 
        {
            TestMin += SQR(T[k] + W - Tuple[k]);
            TestMax += SQR(T[k]     - Tuple[k]);
        }
        else
        {
            TestMax += SQR(W);
        }
    }
    if(DisMin2) *DisMin2 = TestMin;
    if(DisMax2) *DisMax2 = TestMax;
    return U_OK;
}

ErrorType UBlockDouble::ComputeDistanceRange(double ObjectRadius, int itup, const double* Tuple, double* DisMin, double* DisMax) const
{
    if(this==NULL || Tuples==NULL || Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistanceRange(). Object NULL or erroneously set. \n");
        return U_ERROR;
    }
    if(Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistanceRange(). Invalid NULL argument(s). \n");
        return U_ERROR;
    }
    if(itup>=NTuples)
    {
        CI.AddToLog("ERROR: UBlockDouble::ComputeDistanceRange(). itup (=%d) out of range. \n", itup);
        return U_ERROR;
    }
    
    double     TestMin = (itup>=0) ? sqrt(::GetDistance2(Tuples[itup], Tuple, Veclen))-ObjectRadius : 
                                     sqrt(  GetDistance2(Tuple                      ))-ObjectRadius;
    double     TestMax = TestMin + 2*ObjectRadius;
    if(DisMin) *DisMin = MAX(0., TestMin);
    if(DisMax) *DisMax = TestMax;
    return U_OK;
}
double UBlockDouble::GetDistance2(const double* Point, int projdir) const
{
    if(this==NULL || Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistance2(). Object NULL or erroneously set. \n");
        return 0;
    }
    if(Point==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistance2(). Invalid NULL pointer argument. \n");
        return 0;
    }
    double Dis2 = 0;
    for(int k=0; k<Veclen; k++)
    {
        if(k==projdir) continue;
        if(     Point[k]<Min[k]) Dis2 += SQR(Min[k]-Point[k]);
        else if(Point[k]>Max[k]) Dis2 += SQR(Max[k]-Point[k]);
    }
    return Dis2;
}
double UBlockDouble::GetDistance2(const double* Point) const
{
    if(this==NULL || Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistance2(). Object NULL or erroneously set. \n");
        return 0;
    }
    if(Point==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistance2(). Invalid NULL pointer argument. \n");
        return 0;
    }
    double Dis2 = 0;
    for(int k=0; k<Veclen; k++)
    {
        if(     Point[k]<Min[k]) Dis2 += SQR(Min[k]-Point[k]);
        else if(Point[k]>Max[k]) Dis2 += SQR(Max[k]-Point[k]);
    }
    return Dis2;
}
double GetDistance2(const double* Tuple, const double* TupCent, int Veclen)
{
    if(Tuple==NULL || TupCent==NULL || Veclen<=0)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetDistance2(). Invalid NULL pointer argument(s). \n");
        return 0;
    }

    double Dis2 = 0;
    for(int k=0; k<Veclen; k++) Dis2 += SQR(Tuple[k]-TupCent[k]);
    return Dis2;
}


const UBlockDouble* UBlockDouble::FindBlockLeave(const double* Tuple) const
{
    if(this==NULL || Min==NULL || Max==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::FindBlockLeave(). Object NULL or erroneously set. \n");
        return NULL;
    }
    if(Tuple==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::FindBlockLeave(). Invalid NULL pointer argument. \n");
        return NULL;
    }
    UBlockDouble* BlockLeft  = (UBlockDouble*) Left;
    UBlockDouble* BlockRight = (UBlockDouble*) Right;
    
    if(BlockLeft && BlockRight)
    {
        if(Tuple[SplitComp]<=BlockLeft->Max[SplitComp]) return BlockLeft ->FindBlockLeave(Tuple);
        else                                            return BlockRight->FindBlockLeave(Tuple);
    }
    return this;
}

ErrorType UBlockDouble::MakeKDTree(bool AutoRange)
{
    if(Left ) delete Left;  Left  = NULL;
    if(Right) delete Right; Right = NULL;

    if(SplitComp<0 || SplitComp>=Veclen)
    {
        CI.AddToLog("ERROR: UBlockDouble::MakeKDTree(). SplitComp (%d) out of range. \n", SplitComp);
        return U_ERROR;
    }
    if(NTuples<MINTUPLES_KDTREE) return U_OK;

    int NMed = (NTuples+1)/2;
    if(SemiSortArray(Tuples, SplitComp, NMed, NTuples, TupleIndex)!=U_OK)
    {
        CI.AddToLog("ERROR: UBlockDouble::MakeKDTree(). Re-arranging coords.\n");
        return U_ERROR;
    }
    int NewComp = (SplitComp+1)%Veclen;
    
    UBlockDouble* BlockLeft  = NULL;
    UBlockDouble* BlockRight = NULL;
    if(AutoRange)
    {
        BlockLeft  = new UBlockDouble(Tuples     , Veclen, NMed        , NewComp, TupleIndex);
        BlockRight = new UBlockDouble(Tuples+NMed, Veclen, NTuples-NMed, NewComp, TupleIndex==NULL?NULL:TupleIndex+NMed);
    }
    else
    {
        if(Min==NULL || Max==NULL)
        {
            CI.AddToLog("ERROR: UBlockDouble::MakeKDTree(). Min[] or Max[] not set.\n");
            return U_ERROR;
        }
        double Bound     = Tuples[NMed-1][SplitComp];
        double Dum       = Max[SplitComp]; 
        Max[SplitComp]   = Bound;
        BlockLeft        = new UBlockDouble(Tuples     , Veclen, NMed        , NewComp, Min, Max, TupleIndex);
        Max[SplitComp]   = Dum;

        Dum              = Min[SplitComp];
        Min[SplitComp]   = Bound;
        BlockRight       = new UBlockDouble(Tuples+NMed, Veclen, NTuples-NMed, NewComp, Min, Max, TupleIndex==NULL?NULL:TupleIndex+NMed);
        Min[SplitComp]   = Dum;
    }

    if(BlockLeft==NULL || BlockRight==NULL)
    {
        delete BlockLeft ;  
        delete BlockRight;  
        CI.AddToLog("ERROR: UBlockDouble::MakeKDTree(). Creating Left or right branch. \n");
        return U_ERROR;
    }
    SetLeftRight(BlockLeft, BlockRight);

    if(BlockLeft ->MakeKDTree(AutoRange)!=U_OK) return U_ERROR;
    if(BlockRight->MakeKDTree(AutoRange)!=U_OK) return U_ERROR;

    return U_OK;
}

int UBlockByte::FindIndex(const unsigned char* Tuple) const
{
    UBlockByte* BlockLeft  = (UBlockByte*) Left;
    UBlockByte* BlockRight = (UBlockByte*) Right;
    if(BlockLeft ) // Choose BlockLeft or BlockRight
    {
        if(Tuple[SplitComp]<BlockLeft->Max[SplitComp]) return BlockLeft ->FindIndex(Tuple);
        else                                           return BlockRight->FindIndex(Tuple);
    }
    return GetNodeIndex();
}
int UBlockDouble::FindIndex(const double* Tuple) const
{
    UBlockDouble* BlockLeft  = (UBlockDouble*) Left;
    UBlockDouble* BlockRight = (UBlockDouble*) Right;
    if(BlockLeft ) // Choose BlockLeft or BlockRight
    {
        if(Tuple[SplitComp]<BlockLeft->Max[SplitComp]) return BlockLeft ->FindIndex(Tuple);
        else                                           return BlockRight->FindIndex(Tuple);
    }
    return GetNodeIndex();
}

UBlockByte* UBlockByte::GetLongestSideLengthLeave(void)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UBlockByte::GetLongestSideLengthLeave(). Object NULL. \n");
        return NULL;
    }
    if(SplitComp<0 || SplitComp>=Veclen)
    {
        CI.AddToLog("ERROR: UBlockByte::GetLongestSideLengthLeave(). SplitComp-parameter out of range: SplitComp = %d; Veclen = %d\n", SplitComp, Veclen);
        return NULL;
    }

/* Initializa size with side length of one of the leaves */
    UBlockByte* B  = (UBlockByte*)(this->GetLefMostLeave());
    if(B==NULL)
    {
        CI.AddToLog("ERROR: UBlockByte::GetLongestSideLengthLeave(). Getting left most leave. \n");
        return NULL;
    }
    int Size = B->Max[B->SplitComp] - B->Min[B->SplitComp];
    
    ComputeLongestSideLength(&B, &Size);
    return B;
}
UBlockDouble* UBlockDouble::GetLongestSideLengthLeave(void)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetLongestSideLengthLeave(). Object NULL. \n");
        return NULL;
    }
    if(SplitComp<0 || SplitComp>=Veclen)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetLongestSideLengthLeave(). SplitComp-parameter out of range: SplitComp = %d; Veclen = %d\n", SplitComp, Veclen);
        return NULL;
    }

/* Initializa size with side length of one of the leaves */
    UBlockDouble* B  = (UBlockDouble*)(this->GetLefMostLeave());
    if(B==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::GetLongestSideLengthLeave(). Getting left most leave. \n");
        return NULL;
    }
    double Size = B->Max[B->SplitComp] - B->Min[B->SplitComp];
    
    ComputeLongestSideLength(&B, &Size);
    return B;
}

void UBlockByte::ComputeLongestSideLength(UBlockByte** B, int* Size)
{
    UBlockByte* BlockLeft  = (UBlockByte*) Left;
    UBlockByte* BlockRight = (UBlockByte*) Right;
    if(BlockLeft ) 
    {
        BlockLeft ->ComputeLongestSideLength(B, Size);
        BlockRight->ComputeLongestSideLength(B, Size);
    }
    else
    {
        int Test = Max[SplitComp] - Min[SplitComp];
        if(Test>*Size) 
        {
            *Size = Test;
            *B    = this;
        }
    }
}
void UBlockDouble::ComputeLongestSideLength(UBlockDouble** B, double* Size)
{
    UBlockDouble* BlockLeft  = (UBlockDouble*) Left;
    UBlockDouble* BlockRight = (UBlockDouble*) Right;
    if(BlockLeft ) 
    {
        BlockLeft ->ComputeLongestSideLength(B, Size);
        BlockRight->ComputeLongestSideLength(B, Size);
    }
    else
    {
        double Test = Max[SplitComp] - Min[SplitComp];
        if(Test>*Size) 
        {
            *Size = Test;
            *B    = this;
        }
    }
}

ErrorType UBlockByte::SetMean(unsigned char* Tab)
{
    if(Tab==NULL)
    {
        CI.AddToLog("ERROR: UBlockByte::SetMean(). Ivalid NULL argument. \n");
        return U_ERROR;
    }
    UBlockByte* BlockLeft  = (UBlockByte*) Left;
    UBlockByte* BlockRight = (UBlockByte*) Right;

    if(BlockLeft ) 
    {
        if(BlockLeft ->SetMean(Tab)!=U_OK) return U_ERROR;
        if(BlockRight->SetMean(Tab)!=U_OK) return U_ERROR;
    }
    else
    {
        int BlockIndex = GetNodeIndex();
        if(BlockIndex<0)
        {
            CI.AddToLog("ERROR: UBlockByte::SetMean(). BlockIndex (=%d) out of range. \n", BlockIndex);
            return U_ERROR;
        }
        for(int k=0; k<Veclen; k++)
            Tab[BlockIndex*Veclen+k] = Mean[k];
    }
    return U_OK;
}
ErrorType UBlockDouble::SetMean(double* Tab)
{
    if(Tab==NULL)
    {
        CI.AddToLog("ERROR: UBlockDouble::SetMean(). Ivalid NULL argument. \n");
        return U_ERROR;
    }
    UBlockDouble* BlockLeft  = (UBlockDouble*) Left;
    UBlockDouble* BlockRight = (UBlockDouble*) Right;

    if(BlockLeft ) 
    {
        if(BlockLeft ->SetMean(Tab)!=U_OK) return U_ERROR;
        if(BlockRight->SetMean(Tab)!=U_OK) return U_ERROR;
    }
    else
    {
        int BlockIndex = GetNodeIndex();
        if(BlockIndex<0)
        {
            CI.AddToLog("ERROR: UBlockDouble::SetMean(). BlockIndex (=%d) out of range. \n", BlockIndex);
            return U_ERROR;
        }
        for(int k=0; k<Veclen; k++)
            Tab[BlockIndex*Veclen+k] = Mean[k];
    }
    return U_OK;
}
ErrorType UBlockByte::ResetTuples(void)
{
    UBlockByte* BlockLeft  = (UBlockByte*) Left;
    UBlockByte* BlockRight = (UBlockByte*) Right;

    if(BlockLeft ) 
    {
        if(BlockLeft ->ResetTuples()!=U_OK) return U_ERROR;
        if(BlockRight->ResetTuples()!=U_OK) return U_ERROR;
    }
    else
    {
        Tuples = NULL;
    }
    return U_OK;
}
ErrorType UBlockDouble::ResetTuples(void)
{
    UBlockDouble* BlockLeft  = (UBlockDouble*) Left;
    UBlockDouble* BlockRight = (UBlockDouble*) Right;

    if(BlockLeft ) 
    {
        if(BlockLeft ->ResetTuples()!=U_OK) return U_ERROR;
        if(BlockRight->ResetTuples()!=U_OK) return U_ERROR;
    }
    else
    {
        Tuples     = NULL;
        TupleIndex = NULL;
    }
    return U_OK;
}

UBlockByte* GetMedianCut(unsigned char* image, int Veclen, int NPoints, int DesiredSize, unsigned char** TabMean)
{
    if(image==NULL)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Invalid NULL image pointer. \n");
        return NULL;
    }
    if(Veclen<=0 || NPoints<=0 || DesiredSize<=0 || DesiredSize>256)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Invalid input parameter(s): Veclen=%d, NPoints=%d, DesiredSize=%d. \n", Veclen, NPoints, DesiredSize);
        return NULL;
    }

    unsigned char** pimage = new unsigned char*[NPoints];    
    if(pimage==NULL)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Memory allocation: Veclen=%d, NPoints=%d, DesiredSize=%d. \n", Veclen, NPoints, DesiredSize);
        return NULL;
    }
    for(int i=0; i<NPoints; i++) pimage[i] = image+i*Veclen; 
    
    int         NBlock = 1;
    UBlockByte* Root   = new UBlockByte(pimage, Veclen, NPoints);
    UBlockByte* CBlock = Root; // Current block
    if(Root==NULL)
    {
        delete   Root;
        delete[] pimage;
        CI.AddToLog("ERROR: GetMedianCut(). Creating root-node. \n");
        return NULL;
    }
    while(CBlock && NBlock < DesiredSize && CBlock->GetNTuples() > 1)
    {
        if(CBlock->SplitMedian()!=U_OK)
        {
            delete   Root;
            delete[] pimage;
            CI.AddToLog("ERROR: GetMedianCut(). Splitting UBlockByte, level = %d. \n", NBlock);
            return NULL;
        }
        CBlock = Root->GetLongestSideLengthLeave();
        NBlock++;
    }
    InitNodeIndices(Root, U_TREEORD_IN);

    Root->ResetTuples(); // Keep Mean/Min/Max -information per node
    delete[] pimage;

    if(TabMean)
    {
        (*TabMean)         = new unsigned char[DesiredSize*Veclen];
        if((*TabMean)==NULL)
        {
            delete     Root;
            CI.AddToLog("ERROR: GetMedianCut(). Memory allocation for TabMean (DesiredSize=%d).\n", DesiredSize);
            return NULL;
        }
        for(int ki=0; ki<DesiredSize*Veclen; ki++) (*TabMean)[ki] = 0;
        if(Root->SetMean(*TabMean)!=U_OK)
        {
            delete[] (*TabMean); (*TabMean) = NULL;
            delete   Root;
            CI.AddToLog("ERROR: GetMedianCut(). Setting table entries.\n");
            return NULL;
        }
    }
    return Root;
}

UBlockDouble* GetMedianCut(double* image, int Veclen, int NPoints, int DesiredSize, double** TabMean)
{
    if(image==NULL)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Invalid NULL image pointer. \n");
        return NULL;
    }
    if(Veclen<=0 || NPoints<=0 || DesiredSize<=0 || DesiredSize>256)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Invalid input parameter(s): Veclen=%d, NPoints=%d, DesiredSize=%d. \n", Veclen, NPoints, DesiredSize);
        return NULL;
    }

    double** pimage = new double*[NPoints];    
    if(pimage==NULL)
    {
        CI.AddToLog("ERROR: GetMedianCut(). Memory allocation: Veclen=%d, NPoints=%d, DesiredSize=%d. \n", Veclen, NPoints, DesiredSize);
        return NULL;
    }
    for(int i=0; i<NPoints; i++) pimage[i] = image+i*Veclen; 
    
    int           NBlock    = 1;
    UBlockDouble* Root      = new UBlockDouble(pimage, Veclen, NPoints, -1);
    UBlockDouble* CBlock    = Root; // Current block
    if(Root==NULL)
    {
        delete   Root;
        delete[] pimage;
        CI.AddToLog("ERROR: GetMedianCut(). Creating root-node. \n");
        return NULL;
    }
    while(CBlock && NBlock < DesiredSize && CBlock->GetNTuples() > 1)
    {
        if(CBlock->SplitMedian()!=U_OK)
        {
            delete   Root;
            delete[] pimage;
            CI.AddToLog("ERROR: GetMedianCut(). Splitting UBlockByte, level = %d. \n", NBlock);
            return NULL;
        }
        CBlock = Root->GetLongestSideLengthLeave();
        NBlock++;
    }
    InitNodeIndices(Root, U_TREEORD_IN);

    Root->ResetTuples(); // Keep Mean/Min/Max -information per node
    delete[] pimage;

    if(TabMean)
    {
        (*TabMean)         = new double[DesiredSize*Veclen];
        if((*TabMean)==NULL)
        {
            delete     Root;
            CI.AddToLog("ERROR: GetMedianCut(). Memory allocation for TabMean (DesiredSize=%d).\n", DesiredSize);
            return NULL;
        }
        for(int ki=0; ki<DesiredSize*Veclen; ki++) (*TabMean)[ki] = 0;
        if(Root->SetMean(*TabMean)!=U_OK)
        {
            delete[] (*TabMean); (*TabMean) = NULL;
            delete   Root;
            CI.AddToLog("ERROR: GetMedianCut(). Setting table entries.\n");
            return NULL;
        }
    }
    return Root;
}

UBlockDouble* CreateKDTree(double** pPoints, int Veclen, int NPoints, bool AutoRange)
{
    if(pPoints==NULL)
    {
        CI.AddToLog("ERROR: CreateKDTree(). Invalid NULL points pointer. \n");
        return NULL;
    }
    if(Veclen<=0 || NPoints<=0)
    {
        CI.AddToLog("ERROR: CreateKDTree(). Invalid input parameter(s): Veclen = %d, NPoints=%d. \n", Veclen, NPoints);
        return NULL;
    }
    return CreateKDTree(pPoints, Veclen, NPoints, AutoRange, NULL);
}
UBlockDouble* CreateKDTree(double** pPoints, int Veclen, int NPoints, bool AutoRange, int* OrigIndex)
{
    if(pPoints==NULL)
    {
        CI.AddToLog("ERROR: CreateKDTree(). Invalid NULL points pointer. \n");
        return NULL;
    }
    if(Veclen<=0 || NPoints<=0)
    {
        CI.AddToLog("ERROR: CreateKDTree(). Invalid input parameter(s): Veclen = %d, NPoints=%d. \n", Veclen, NPoints);
        return NULL;
    }

    int           idim = 0;
    UBlockDouble* Root = new UBlockDouble(pPoints, Veclen, NPoints, idim, OrigIndex); // First one applies autorange
    if(Root==NULL)
    {
        delete   Root;
        CI.AddToLog("ERROR: CreateKDTree(). Creating root-node. \n");
        return NULL;
    }
    if(Root->MakeKDTree(AutoRange)!=U_OK)
    {
        delete   Root;
        CI.AddToLog("ERROR: CreateKDTree(). Creating KDTree.... \n");
        return NULL;
    }
    InitAllNodeIndices(Root, U_TREEORD_IN);

    return Root;
}
