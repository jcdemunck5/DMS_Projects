#ifndef MEDIAN_CUT_H_
#define MEDIAN_CUT_H_

#include "TreeNode.h"

static int MINTUPLES_KDTREE = 40;
extern int SetMaxMinTupKD(int N);

class UVector3;

class DLL_IO UListNodeInt : public UListNode
{
    friend PMT_LISTNODEINT DLL_IO Merge(UListNodeInt*, UListNodeInt*);
    friend PMT_LISTNODEINT DLL_IO Split(UListNodeInt*, int m);

public:
    UListNodeInt()      {value=0;}
    UListNodeInt(int v) {value=v;}

    int value;
};

PMT_LISTNODEINT DLL_IO Merge(UListNodeInt* L1, UListNodeInt* L2);  // Here "<" is used
PMT_LISTNODEINT DLL_IO MergeSort(UListNodeInt* L, int n);
PMT_LISTNODEINT DLL_IO RemoveDoubleValues(UListNodeInt* L);

class DLL_IO UListNodeRange : public UListNodeInt
{
public:
    UListNodeRange();
    UListNodeRange(int v, double minR, double maxR);

    double MinR;
    double MaxR;
};

UListNodeRange* Merge(UListNodeRange* L1, UListNodeRange* L2);
UListNodeRange* Split(UListNodeRange* L1, int m);
UListNodeRange* MergeSort(UListNodeRange* L, int n);
UListNodeRange* RemoveDisjunctRanges(UListNodeRange* L);


class DLL_IO UBlock : public UTreeNodeBin
{
public:
    UBlock();
    UBlock(const UBlock* pBL);
    virtual ~UBlock();

    int                    GetVeclen(void) const {if(this) return Veclen; return 0;}
    int                    GetNTuples(void) const {if(this) return NTuples; return 0;}
    virtual int            FindIndex(const unsigned char* Tuple) const;
    virtual int            FindIndex(const double* Tuple) const;
    virtual ErrorType      SetMean(unsigned char* Tab);
    virtual ErrorType      ResetTuples(void);    
    UBlock*                GetLargestNTuplesLeave(void);
    virtual double         GetDistanceClosestPoint(const double* Tuple, int* Index=NULL) const;
    virtual UListNodeInt*  GetEnclosingObjects(double ObjectRadius, const double* Tuple, int projdir=-1) const;
    virtual UListNodeInt*  GetEnclosingObjects(const double* ObjectWidth, const double* TupleMin, int projdir=-1) const;
    virtual UListNodeInt*  GetInRangeObjects(double ObjectRadius, const double* Tuple, double Distance) const;
    virtual UListNodeInt*  GetClosestObjects(double ObjectRadius, const double* Tuple) const;
    virtual UListNodeInt*  GetClosestObjects(const double* ObjectWidth, const double* Tuple) const;

    virtual ErrorType      WriteTxt(FILE* fp, int Depth) const;
protected:
    void                   SetAllMembersDefault(void);
    void                   DeleteAllMembers(ErrorType E);

    ErrorType              SetBlockParameters(const UBlock* pBL);
    int                    NTuples;
    int                    Veclen;
    int                    SplitComp;

private:
    void                   ComputeLargestNTuple(UBlock** BLong, int* Size);
};

class DLL_IO UBlockByte : public UBlock
{
    friend PMT_BLOCKBYTE DLL_IO GetMedianCut(unsigned char*, int, int, int, unsigned char**);

public:
    ~UBlockByte();
    UBlockByte(const UBlockByte* pBLB);

    int                 FindIndex(const unsigned char* Tuple) const;
    ErrorType           SetMean(unsigned char* Tab);
    ErrorType           ResetTuples(void);    
    int                 GetNTuples(void) const {if(this) return NTuples; return 0;}
    
protected:
    UBlockByte();
    UBlockByte(unsigned char** Tuple, int Vecl, int Ntup, int Scomp=-1);

    ErrorType           SplitMedian(void);
    UBlockByte*         GetLongestSideLengthLeave(void);

    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    unsigned char*      Min;
    unsigned char*      Max;
    unsigned char*      Mean;
    unsigned char**     Tuples;

    ErrorType           UpdateRange();
    void                ComputeLongestSideLength(UBlockByte** BLong, int* Size);
};

class DLL_IO UBlockDouble : public UBlock
{
    friend PMT_BLOCKDOUBLE  DLL_IO CreateKDTree(double**, int, int, bool);
    friend PMT_BLOCKDOUBLE  DLL_IO CreateKDTree(double**, int, int, bool, int*);
    friend PMT_BLOCKDOUBLE  DLL_IO GetMedianCut(double*, int, int, int, double**);

///
    friend class USurface;
    friend class UPointsTable;
///
public:
    ~UBlockDouble();
    UBlockDouble(const UBlockDouble* pBLD);

    int                 FindIndex(const double* Tuple) const;
    
    ErrorType           SetMean(double* Tab);
    ErrorType           ResetTuples(void);    
    int                 GetNTuples(void) const {if(this) return NTuples; return 0;}
    const double*       GetMin(void)     const {if(this) return Min; return NULL;}
    const double*       GetMax(void)     const {if(this) return Max; return NULL;}

    int*                GetRandomIndices(int Depth, int seed, int* NIndex) const;
    ErrorType           AddBlocksDepth(UBlockDouble** Blocks, int* NBlock, int DepthActual, int DepthRequested) const;

//// Temp debugging functions
    ErrorType           AddBlockLeaveRanges(UVector3* MinArr, UVector3* MaxArr, int* Iblock) const;
    ErrorType           AddBlockLeaveRanges(UVector3* MinArr, UVector3* MaxArr, int* Iblock, UVector3 View, UVector3 Width, int projdir=-1) const;
    ErrorType           AddPointsLeave(UVector3* Points, int* TriL, int* Npoints, UVector3 View, UVector3 Width, int projdir=-1) const;
////
protected:
    UBlockDouble();
    UBlockDouble(double** Tuple, int Vecl, int Ntup, int Scomp, int* TupInd=NULL);
    UBlockDouble(double** Tuple, int Vecl, int Ntup, int Scomp, double*TupMin, double*TupMax, int* TupInd=NULL);

    ErrorType           MakeKDTree(bool AutoRange);
    UBlockDouble*       GetLongestSideLengthLeave(void);
    UBlockDouble*       GetLargestNTuplesLeave(void);

    ErrorType           SplitMedian(void);
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

    UListNodeInt*       GetEnclosingObjects(double ObjectRadius, const double* Tuple, int projdir=-1) const;
    UListNodeInt*       UpdateEnclosingObjects(double ObjectRadius2, const double* Tuple, UListNodeInt* Tail, int projdir) const;

    UListNodeInt*       GetEnclosingObjects(const double* ObjectWidth, const double* Tuple, int projdir=-1) const;
    UListNodeInt*       UpdateEnclosingObjects(const double* ObjectWidth, const double* Tuple, UListNodeInt* Tail, int projdir) const;

    UListNodeInt*       GetInRangeObjects(double ObjectRadius, const double* Tuple, double Distance) const;
    UListNodeInt*       UpdateInRangeObjects(double ObjectRadius, const double* Tuple, UListNodeInt* Tail, UListNodeInt** Head, double Distance) const;

    UListNodeInt*       GetClosestObjects(double ObjectRadius, const double* Tuple) const;
    UListNodeRange*     UpdateClosestObjects(double ObjectRadius, const double* Tuple, UListNodeRange* Tail, double* DisMin, double* DisMax) const;

    UListNodeInt*       GetClosestObjects(const double* ObjectWidth, const double* Tuple) const;
    UListNodeRange*     UpdateClosestObjects(const double* ObjectWidth, const double* Tuple, UListNodeRange* Tail, double* DisMin, double* DisMax) const;

    double              GetDistanceClosestPoint(const double* Tuple, int* Index) const;
    ErrorType           UpdateDistanceClosestPoint(const double* Tuple, double* Dis2, int* Index) const;
    
    double              GetDistance2(const double* Tuple) const;
    double              GetDistance2(const double* Tuple, int projdir) const;
    ErrorType           ComputeDistanceRange(double ObjectRadius, int itup, const double* Tuple, double* DisMin, double* DisMax) const;
    ErrorType           ComputeDistance2Range(const double* ObjectWidth, int itup, const double* Tuple, double* DisMin2, double* DisMax2) const;

    const UBlockDouble* FindBlockLeave(const double* Tuple) const;
    ErrorType           WriteTxt(FILE* fp, int Depth) const;
private:
    double*             Min;
    double*             Max;
    double*             Mean;
    double**            Tuples;
    int*                TupleIndex;

    ErrorType           UpdateRange();
    void                ComputeLongestSideLength(UBlockDouble** BLong, double* Size);
};
double GetDistance2(const double* Tuple, const double* TupCent, int Veclen);


PMT_BLOCKBYTE   DLL_IO GetMedianCut(unsigned char* image, int Veclen, int numPoints, int desiredSize, unsigned char** TabMean);
PMT_BLOCKDOUBLE DLL_IO GetMedianCut(double* image, int Veclen, int numPoints, int desiredSize, double** TabMean);
PMT_BLOCKDOUBLE DLL_IO CreateKDTree(double** pPoints, int Veclen, int NPoints, bool AutoRange);
PMT_BLOCKDOUBLE DLL_IO CreateKDTree(double** pPoints, int Veclen, int NPoints, bool AutoRange, int* OrgIndex);
#endif // #ifndef MEDIAN_CUT_H_ 

