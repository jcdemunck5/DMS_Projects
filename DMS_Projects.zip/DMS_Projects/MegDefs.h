/*********************************************************************************/
/*                                                                               */
/*     Megdefs.h                                                                 */
/*     Include file for CTF data format                                          */ 
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*********************************************************************************/
/*
  Update history
  
  Who    When           What
  Jdm    13-11-1996     creation, retyped by from CTF manual
  Jdm    05-01-1998     added some comments
  Jdm    06-03-1998     replace makeResources() by readResources()
  JdM    12-11-1998     Compatibility with UNIX
  JdM    25-08-1999     Compatibility with UNIX, defining some external "C" function as static
  JdM    16-08-2001     Added enum{TAB_G1BR, TAB_G2BR, TAB_G3BR, TAB_G2OI, TAB_G3OI};
  JdM    11-06-2002     Added SENTYPE_ADC2
JdM/GdV  06-10-2004     Un-Compatibility with MS Language extensions: remove #define true, #define false
  JdM    07-07-2005     Remove MAXSENRES
  JdM    12-02-2010     added #define SENTYPE_MEGMA, renamed SENTYPE_MEG into SENTYPE_MEGGR
  JdM    05-08-2014     Bug Fix. Use int instead of long in typedefs (long is 8 bytes in LINUX 64 bits)
*/

#ifndef _H_MegDefs
#define _H_MegDefs

#define MAX_COILS        8
#define MAX_BALANCING    50
#define SENSOR_LABEL     31
#define MAX_AVERAGE_BINS 8

#define NOGRAD  0x00000000
#define G1BR    0x47314252
#define G2BR    0x47324252
#define G3BR    0x47334252
#define G2OI    0x47324f49
#define G3OI    0x47334f49

enum{TAB_G1BR, TAB_G2BR, TAB_G3BR, TAB_G2OI, TAB_G3OI};                  

/* The following typedefs are added by JCM */

#define SENTYPE_MAGR  0   /* Magnetometer reference     */
#define SENTYPE_GRAR  1   /* Gradiometer reference      */
#define SENTYPE_MEGMA 4   /* MEG signal (magnetometer)  */
#define SENTYPE_MEGGR 5   /* MEG signal (gradiometer)   */
#define SENTYPE_EEG   9   /* EEG channel                */
#define SENTYPE_ADC  10   /* Additional Analogue signal */
#define SENTYPE_ADC2 18   /* Additional Analogue signal */
#define SENTYPE_STIM 11   /* Simulus related signal     */
/***
typedef enum 
            {eMEGReference, // magnetomer reference     
             eMEGReference1,    // first gradiometer reference
             eMEGReference2,    // second gradiometer reference
             eMEGReference3,    // third gradiometer reference
             eMEGSensor,    // magnetometer sensor
             eMEGSensor1,   // fisrt gradiometer sensor
             eMEGSensor2,   // second gradiometer sensor
             eMEGSensor3,   // third gradiometer sensor
             eEEGRef,       // EEG reference electrode
             eEEGSensor,    // EEG sensor electrode
             eADCRef,       // ADC Channel
             eStimRef,      // Stimulus channel
             eTimeRef,      // Not used.
             ePositionRef,  // Not used
             eDACRef,       // Not used
             eOtherRef,     // Other undefined types
             eInvalidType   // end of list.
        } SensorType;
****/

typedef char          Char;
typedef unsigned char UChar;
typedef Char          Str32[32];
typedef Char          Str60[60];
typedef Char          Str255[255];
typedef Char          Str256[256];

typedef int           Int32;
typedef short         Int16;

typedef double        SDouble;
typedef unsigned int  Bit32;

#ifdef WIN32
typedef enum {False, True} CTFBoolean;
#else
typedef enum {False, True} CTFBoolean;
#endif

typedef struct
{
    Int32      no_samples;
    Int16      no_channels;  
    SDouble    sample_rate;
    SDouble    epoch_time;
    Int16      no_trials;
    Int32      preTrigPts;
    Int16      no_trials_done;
    Int16      no_trials_display;
    CTFBoolean save_trials;
    UChar      primaryTrigger;
    UChar      secondaryTrigger[MAX_AVERAGE_BINS];
    UChar      triggerPolarityMask;
    Int16      trigger_mode;
    CTFBoolean accept_reject_Flag;
    Int16      run_time_display;
    CTFBoolean zero_Head_flag;
    CTFBoolean artifact_mode;
} new_general_setup_rec_ext;

typedef struct
{
    Str32      nf_run_name;
    Str256     nf_run_title;
    Str32      nf_instruments;
    Str32      nf_collect_descriptor;
    Str32      nf_subject_id;
    Str32      nf_operator;
    Str60      nf_sensorFileName;
} meg4FileSetup;

typedef struct
{
    Str256                    appName;
    Str256                    dataOrigin;
    Str256                    dataDescription;
    Int16                     no_trials_avgd;
    Str255                    data_time;
    Str255                    data_date;
    new_general_setup_rec_ext gSetUp;
    meg4FileSetup             nfSetUp;
    Int32                     rdlen;
} meg4GeneralResRec;

typedef enum {CLASSERROR, BUTTERWORTH } classType;
typedef enum {TYPERROR, LOWPASS, HIGHPASS, NOTCH} filtType;

typedef struct
{
    SDouble    freq;
    classType  fClass;
    filtType   fType;
    Int16      numParam;
    SDouble*   params;
} filter;

typedef struct 
{
    SDouble x, y, z, junk;
} d3_point_ext;

typedef struct 
{
    d3_point_ext  position;
    d3_point_ext  orient;
    Int16         numturns;
    SDouble       area;
} CoilRec_ext;

typedef enum {CIRCULAR, SQUARE} CoilType;

typedef struct
{
    Int16       sensorTypeIndex;
    Int16       originalRunNum;
    CoilType    coilShape;
    SDouble     properGain;
    SDouble     qGain;
    SDouble     ioGain;
    SDouble     ioOffset;
    Int16       numCoils;
    Int16       grad_order_no;
    CoilRec_ext coilTbl[MAX_COILS];
    CoilRec_ext HdcoilTbl[MAX_COILS];
} NewSensorResRec;


typedef struct
{
    Int16        num_of_coefs;
    Char         sensor_list[MAX_BALANCING][SENSOR_LABEL];        
    SDouble      coefs_list[MAX_BALANCING];
} CoefResRec;

typedef struct
{
    Str32        sensorName;
    Bit32        coefType;
    CoefResRec   coefRec;
} SensorCoefResRec;


/* The following parts are moved from the example program towards this header file*/
typedef struct
{
    meg4GeneralResRec    genres;
    Char*                run_description;
    Int16                num_filters;
    filter*              filters;
    Str32*               chanNames;
    NewSensorResRec*     senres;
    Int16                numcoef;
    SensorCoefResRec*    scrr;
}  resource;


#ifdef __cplusplus
extern "C" {
#endif
           int            readResources(const char *filename, resource* rez);
           int            Readgenres(char *filename, meg4GeneralResRec* genres);
           void           deleteResources(resource *rez);
           int            CopyResources(resource *rez1, const resource *rez2);
           int            CopySenResRec(NewSensorResRec* SenTo, NewSensorResRec* SenFrom, int Nsens);
           int            swapint(const int    *n);
#ifdef __cplusplus
} // extern "C" {
#endif


#endif /* _H_MegDefs */
    




