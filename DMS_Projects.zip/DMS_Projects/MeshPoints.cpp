/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL                                                                   */
/*     Module for maintaining a grid with test points. These points may be       */
/*     distributed inside a sphere, half-sphere, cube, etc.                      */
/*     The advantage of using this object is that the grid points for a certain  */
/*     grid are computed any time in exactly the same way and order.             */
/*                                                                               */
/*     USAGE                                                                     */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    21-06-15   creation, split off from UStartDip
  JdM    22-06-15   USurface constructor: shrink surface by factor of 0.95
 */

#include "MeshPoints.h"
#include "Surface.h"

#define DEF_POINTS_CURRENT             600
#define DEF_POINTS_MAGNETIC            1200
#define DEF_LARGE_SEARCH_RADIUS_COIL     25.  // Default parameters for global search 
#define DEF_SMALL_SEARCH_RADIUS_COIL     10.  
#define DEF_RADIUS_3S                     5.  
#define BLOCK_VOLUME                    715.

/* Inititalize static const parameters. */
UString      UMeshPoints::Properties = UString();


void UMeshPoints::SetAllMembersDefault(void)
{
    error       = U_OK;

    Size        = 0.;
    MeshSize    = 0.;
    RType       = U_SPHERE;

    Ndippoints  = 0;
    NGlobGrid   = 0;
    for(int k=0; k<MAXNGRID  ;k++) GlobGrid[k] = NULL;
    for(int k=0; k<MAXNGRID+1;k++) Ncum[k]     = 0;

    GridIndex   = NULL;
}
void UMeshPoints::DeleteAllMembers(ErrorType E)
{
    for(int ig=0; ig<MAXNGRID; ig++) delete GlobGrid[ig];
    delete[] GridIndex;

    SetAllMembersDefault();
    error = E;
}

UMeshPoints::UMeshPoints(const USurface* Surf, int npts)
/*
    The Mesh constructor for current dipole in a realistic model with inner surface *Brain.
    npts is the approximate number of points.
 */
{
    SetAllMembersDefault();

    if(Surf==NULL || Surf->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). NULL or Erroneous surface paramater. \n");
        return;
    }
    USurface SurfCopy(*Surf);
    if(SurfCopy.GetError()!= U_OK || SurfCopy.TransformCenter(0.95, 0.95, 0.95)!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Copying or shrinking surface argument. \n");
        return;
    }

/* The true values*/
    if(npts<=0) npts  = DEF_POINTS_CURRENT;

    UVector3 Minx, Maxx;
    SurfCopy.ComputeMinMax(&Minx, &Maxx);
    Size        = pow(fabs((Maxx-Minx).Getx()*(Maxx-Minx).Gety()*(Maxx-Minx).Getz()),1./3.);
    MeshSize    = Size*pow(.5/npts,1./3.);

    NGlobGrid   = 1;
    RType       = U_REALISTIC;
    GlobGrid[0] = new UField(MeshSize, Minx-UVector3(1.,1.,1.), Maxx+UVector3(1.,1.,1.), UField::U_BYTE);
        
    if(GlobGrid[0]==NULL || GlobGrid[0]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Memory allocation error.\n");
        return;
    }

/* Determine the cumulative number of grid points*/
    Ncum[0] = 0;
    for(int k=0; k<MAXNGRID; k++) Ncum[k+1] = GlobGrid[0]->GetNpoints();

    GlobGrid[0]->SetDataByte((unsigned char)1);
    GlobGrid[0]->IsInSurface(&SurfCopy);

/////
/////    GlobGrid[0]->WriteXDR("C:/Users/ibm/Desktop/TestGlob.xdr", "Modality = MEG ");  // MEG: avoid centralizing in Biap4D
/////

    Ndippoints = GlobGrid[0]->GetNonZeroes();
    if(Ndippoints<=0)
        CI.AddToLog("WARNING: UMeshPoints::UMeshPoints(). Ndippoints = %d.\n",Ndippoints);

    if(InitTabIndex()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Initializing index table.\n");
    }
}

UMeshPoints::UMeshPoints(double Radius, UVector3 centre, int npts, UDipole::DipoleType DT)
/*
    The Mesh constructor for current dipole in the spherical symmetric head model,
    with radius Radius and center centre.

    npts is the approximate number of points.
 */
{
    SetAllMembersDefault();

    Size        = Radius;

    switch(DT)
    {
    case UDipole::Symmetric:
    case UDipole::SymmetricPos:
        NGlobGrid   = 1;
        RType       = U_HALFSPHERE;
        if(npts<=0) npts  = DEF_POINTS_CURRENT;
        npts        = npts*2;
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,0,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;

    case UDipole::Current:
        NGlobGrid   = 1;
        RType       = U_SPHERE;
        if(npts<=0) npts  = DEF_POINTS_CURRENT;
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,Size,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;

    case UDipole::Magnetic:
        NGlobGrid   = 1;
        RType       = U_SPHERE;
        if(npts<=0) npts  = DEF_POINTS_MAGNETIC;
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,Size,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;
    }
        
    if(GlobGrid[0]==NULL || GlobGrid[0]->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Memory allocation error.\n");
        return;
    }

/* Determine the cumulative number of grid points*/
    for(int k=0; k<MAXNGRID; k++) Ncum[k+1] = GlobGrid[0]->GetNpoints();
    GlobGrid[0]->SetDataByte((unsigned char)1);
    GlobGrid[0]->IsInSphere(centre, Size);

    Ndippoints = GlobGrid[0]->GetNonZeroes();
    if(Ndippoints<=0)
        CI.AddToLog("WARNING: UMeshPoints::UMeshPoints(). Ndippoints = %d.\n",Ndippoints);

    if(InitTabIndex()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Initializing index table.\n");
    }
}

UMeshPoints::UMeshPoints(UVector3 centre, RegionType RT, int npts)
/*
    The Mesh constructor for the magnetic dipole type.

    npts is the approximate number of points.
 */
{
    SetAllMembersDefault();

    if(npts<0)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). UInvalid argument: npts = %d \n");
        return;
    }

    RType       = RT;

    switch(RType)
    {
    case U_SPHERE: 
        NGlobGrid   = 1;
        Size        = DEF_SMALL_SEARCH_RADIUS_COIL; 
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,Size,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;
    
    case U_LARGESPHERE:  
        NGlobGrid   = 1;
        Size        = DEF_LARGE_SEARCH_RADIUS_COIL; 
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,Size,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;
    
    case U_HALFSPHERE:    
        NGlobGrid   = 1;
        Size        = DEF_SMALL_SEARCH_RADIUS_COIL; 
        MeshSize    = Size*pow(1.3333*PI/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,0,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;

    case U_CUBE:
        NGlobGrid   = 1;
        Size        = DEF_SMALL_SEARCH_RADIUS_COIL; 
        MeshSize    = 2*Size*pow(1./npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, centre-UVector3(Size,Size,Size), centre+UVector3(Size,Size,Size), UField::U_BYTE);
        break;

    case U_THREESPHERES: 
        NGlobGrid   = 3;
        Size        = DEF_SMALL_SEARCH_RADIUS_COIL; 
        MeshSize    = DEF_RADIUS_3S*pow(PI2/npts,1./3.);
        {
            UVector3 Centres[3];
            Centres[0]  = centre + UVector3(Size*1.2, 0.  ,0.);
            Centres[1]  = centre + UVector3(0.      , Size,0.);
            Centres[2]  = centre + UVector3(0.      ,-Size,0.);

            GlobGrid[0] = new UField(MeshSize, Centres[0]-UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), 
                                               Centres[0]+UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), UField::U_BYTE);
            GlobGrid[1] = new UField(MeshSize, Centres[1]-UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), 
                                               Centres[1]+UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), UField::U_BYTE);
            GlobGrid[2] = new UField(MeshSize, Centres[2]-UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), 
                                               Centres[2]+UVector3(DEF_RADIUS_3S,DEF_RADIUS_3S,DEF_RADIUS_3S), UField::U_BYTE);
        }
        break;

    case U_THREEBLOCKS:
        NGlobGrid   = 3;
        MeshSize    = pow(BLOCK_VOLUME/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, UVector3( 5.5,-2.5,-3.5), UVector3(11.5, 2.0,6.5), UField::U_BYTE);
        GlobGrid[1] = new UField(MeshSize, UVector3(-2.5, 5.0,-5.5), UVector3( 3.0, 8.5,4.0), UField::U_BYTE);
        GlobGrid[2] = new UField(MeshSize, UVector3(-3.0,-8.5,-6.0), UVector3( 2.5,-5.0,4.5), UField::U_BYTE);
        break;

    case U_THREELARGEBLOCKS:
        NGlobGrid   = 3;
        MeshSize    = pow(BLOCK_VOLUME/npts,1./3.);
        GlobGrid[0] = new UField(MeshSize, UVector3(-2.0, -5.0, -6.0)+centre, UVector3(14.0,  5.0, 8.0)+centre, UField::U_BYTE);
        GlobGrid[1] = new UField(MeshSize, UVector3(-4.0,  4.0, -6.0)+centre, UVector3( 4.0, 12.0, 6.0)+centre, UField::U_BYTE);
        GlobGrid[2] = new UField(MeshSize, UVector3(-4.0,-12.0, -6.0)+centre, UVector3( 4.0, -4.0, 6.0)+centre, UField::U_BYTE);
        break;

    case U_FOURSMALLSPHERES: 
        NGlobGrid   = 4;
        Size        = 2; 
        MeshSize    = Size*pow(PI2/npts,1./3.);
        {
            UVector3 Centres[4];
            Centres[0]  = UVector3( 25.7323, 0., 6.);
            Centres[1]  = UVector3( 0., 25.7323, 6.);
            Centres[2]  = UVector3(-25.7323, 0., 6.);
            Centres[3]  = UVector3( 0.,-25.7323, 6.);

            GlobGrid[0] = new UField(MeshSize, Centres[0]-UVector3(Size,Size,Size), 
                                               Centres[0]+UVector3(Size,Size,Size), UField::U_BYTE);
            GlobGrid[1] = new UField(MeshSize, Centres[1]-UVector3(Size,Size,Size), 
                                               Centres[1]+UVector3(Size,Size,Size), UField::U_BYTE);
            GlobGrid[2] = new UField(MeshSize, Centres[2]-UVector3(Size,Size,Size), 
                                               Centres[2]+UVector3(Size,Size,Size), UField::U_BYTE);
            GlobGrid[3] = new UField(MeshSize, Centres[3]-UVector3(Size,Size,Size), 
                                               Centres[3]+UVector3(Size,Size,Size), UField::U_BYTE);
        }
        break;

    default:
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Unsupprted RegionType: %d \n", RType);
        return;
    }

/* Test each grid and mark each point with 1 */    
    for(int k=0; k<NGlobGrid; k++)
    {
        if(GlobGrid[k]==NULL || GlobGrid[k]->GetError()!=U_OK)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Memory allocation error in Grid %d.\n",k);
        }
        GlobGrid[k]->SetDataByte((unsigned char)1);
    }

/* Determine the cumulative number of grid points*/
    Ncum[0] = 0;
    for(int k=0; k<MAXNGRID;k++) 
    {
        if(GlobGrid[k]==NULL) Ncum[k+1] = Ncum[k];
        else                  Ncum[k+1] = Ncum[k] + GlobGrid[k]->GetNpoints();
    }

    switch(RType)
    {
    case U_SPHERE:
    case U_LARGESPHERE:
    case U_HALFSPHERE:
        GlobGrid[0]->IsInSphere(centre, Size);

    case U_CUBE:
        Ndippoints = GlobGrid[0]->GetNonZeroes();
        break;

    case U_THREESPHERES:
        GlobGrid[0]->IsInSphere(UVector3(2.,0.,0.), Size);
        GlobGrid[1]->IsInSphere(UVector3(), Size);
        GlobGrid[2]->IsInSphere(UVector3(), Size);
        Ndippoints  = GlobGrid[0]->GetNonZeroes();
        Ndippoints += GlobGrid[1]->GetNonZeroes();
        Ndippoints += GlobGrid[2]->GetNonZeroes();
        break;

    case U_THREEBLOCKS:
        GlobGrid[0]->IsInSphere(UVector3(), -5.);
        GlobGrid[0]->IsInSphere(UVector3(), 12.);
        GlobGrid[1]->IsInSphere(UVector3(), -4.);
        GlobGrid[1]->IsInSphere(UVector3(), 10.);
        GlobGrid[2]->IsInSphere(UVector3(), -4.);
        GlobGrid[2]->IsInSphere(UVector3(), 10.);
        Ndippoints  = GlobGrid[0]->GetNonZeroes();
        Ndippoints += GlobGrid[1]->GetNonZeroes();
        Ndippoints += GlobGrid[2]->GetNonZeroes();
        break;

    case U_THREELARGEBLOCKS:
        Ndippoints  = GlobGrid[0]->GetNonZeroes();
        Ndippoints += GlobGrid[1]->GetNonZeroes();
        Ndippoints += GlobGrid[2]->GetNonZeroes();
        break;

    case U_FOURSMALLSPHERES: 
        GlobGrid[0]->IsInSphere(UVector3( 25.7323, 0., 6.), Size);
        GlobGrid[1]->IsInSphere(UVector3( 0., 25.7323, 6.), Size);
        GlobGrid[2]->IsInSphere(UVector3(-25.7323, 0., 6.), Size);
        GlobGrid[3]->IsInSphere(UVector3( 0.,-25.7323, 6.), Size);
        Ndippoints  = GlobGrid[0]->GetNonZeroes();
        Ndippoints += GlobGrid[1]->GetNonZeroes();
        Ndippoints += GlobGrid[2]->GetNonZeroes();
        Ndippoints += GlobGrid[3]->GetNonZeroes();
        break;
    
    default:
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Unsupprted RegionType: %d \n", RType);
        return;
    }

    if(Ndippoints<=0)
        CI.AddToLog("WARNING: UMeshPoints::UMeshPoints(). Ndippoints = %d.\n",Ndippoints);

    if(InitTabIndex()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMeshPoints::UMeshPoints(). Initializing index table.\n");
    }
}

UMeshPoints::~UMeshPoints()
{
    DeleteAllMembers(U_OK);
}

ErrorType UMeshPoints::InitTabIndex(void)
/*
     Initialize the data of the global search tables such that each point (that
     is not skipped) equals the 'point order' +1. The other points (that are
     skipped) will remain zero.
     In this way, it is very easy to find the table index for a given mesh point.
     This is used when the optimal global search error is interpolated to refine
     the global search estimate, in UStartDipole::ComputeGlobalInterpolate().

     InitTabIndex() should be called at the end of each constructor.
 */
{
    for(int ig=0; ig<NGlobGrid; ig++)
    {
        if(GlobGrid[ig]==NULL || GlobGrid[ig]->GetError()!=U_OK || GlobGrid[ig]->GetBdata()==NULL)
        {
            CI.AddToLog("ERROR: UMeshPoints::InitTabIndex(). Grids not properly set.\n");
            return U_ERROR;
        }
    }
    delete[] GridIndex; GridIndex = new int[Ndippoints];
    if(GridIndex==NULL)
    {
        CI.AddToLog("ERROR: UMeshPoints::InitTabIndex(). Memory allocation, Ndippoints = %d.\n", Ndippoints);
        return U_ERROR;
    }
    for(int ip=0; ip<Ndippoints; ip++) GridIndex[ip] = 0;

    for(int ig=0, ip=0; ig<NGlobGrid; ig++)
    {
        unsigned char* Bdata = GlobGrid[ig]->GetBdata();
        int  NP              = GlobGrid[ig]->GetNpoints();
        for(int n=0; n<NP; n++) if(Bdata[n]) GridIndex[ip++] = Ncum[ig]+n;
    }
    return U_OK;
}

UVector3 UMeshPoints::GetPoint(int ipt) const
{
    if(ipt<0 || ipt>=Ndippoints)
    {
        CI.AddToLog("ERROR: UMeshPoints::GetPoint(). Index out of range (%d)\n", ipt);
        return UVector3();
    }

    int N = GridIndex[ipt];
    for(int k=0; k<=NGlobGrid; k++)
        if(N<Ncum[k])  return GlobGrid[k-1]->GetPoint(N-Ncum[k-1]);

    return UVector3();
}

int UMeshPoints::GetIgrid(int ipt) const
{
    for(int k=0; k<=NGlobGrid; k++) if(ipt<Ncum[k]) return k-1;
    return 0;
}

const UString& UMeshPoints::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UMeshPoints-object");
        return Properties;
    }
    Properties   = UString();

    switch(RType)
    {
    case U_SPHERE:
    case U_LARGESPHERE :     Properties += UString(Size,"MESH =     SPHERE(%7.2f)      \n");             break;
    case U_HALFSPHERE  :     Properties += UString(Size,"MESH =     HALF_SPHERE(%7.2f) \n");             break;
    case U_CUBE        :     Properties += UString(Size,"MESH =     CUBE(%7.2f) \n");                    break;
    case U_THREESPHERES:     Properties += UString(DEF_RADIUS_3S,"MESH =     THREE_SPHERES(%7.2f") + UString(Size,"%7.2f) \n");   break;
    case U_THREEBLOCKS :     Properties += UString("MESH =     THREE_BLOCKS() \n");                      break;
    case U_THREELARGEBLOCKS: Properties += UString("MESH =     THREE_LARGEBLOCKS \n");                   break;
    case U_FOURSMALLSPHERES: Properties += UString("MESH =     FOUR_SMALL_SPHERES \n");                  break;
    case U_REALISTIC   :     Properties += UString("MESH =     REALISTIC \n");                           break;
    }

    //if(Comment.IsNULL() || Comment.IsEmpty())     Properties.ReplaceAll('\n', ';');  
    //else                                          Properties.InsertAtEachLine(Comment);

    return Properties;
}


/****
T.o.v. het default hoofdpos coord.stelsel [cm]

afgerond:

minimum
nas: 5.5	-2.5	-3.5
pal: -2.50	5.0	-5.5
par: -3.0	-8.5	-6.0

max
nas: 11.5	2.0	6.5
pal: 3.0	8.5	4.0
par: 2.5	-5.0	4.5


max radii
nas: 12
pal: 10
par: 10


min radii
nas: 5
pal: 4
par: 4
***/