#ifndef _MESHPOINTS_INCLUDED
#define _MESHPOINTS_INCLUDED

#include "String.h"
#include "MatVec.h"
#include "Dipole.h"

#define MAXNGRID   4


class USurface;
class UField;

class DLL_IO UMeshPoints
{
public:
    enum RegionType  {U_SPHERE,
                      U_LARGESPHERE,
                      U_HALFSPHERE,
                      U_CUBE,
                      U_THREESPHERES,
                      U_THREEBLOCKS,
                      U_THREELARGEBLOCKS,
                      U_FOURSMALLSPHERES,
                      U_REALISTIC};

    UMeshPoints(UVector3 centre, RegionType RT, int npts);
    UMeshPoints(double Radius, UVector3 centre, int npts, UDipole::DipoleType DT);
    UMeshPoints(const USurface* Surf, int npts);
    ~UMeshPoints();

    ErrorType        GetError(void) const       {return error;}
    const UString&   GetProperties(UString Comment) const;

    int              GetNpoints(void) const     {return Ndippoints;}
    UVector3         GetPoint(int ipt) const;
    double           GetMeshSize(void) const    {return MeshSize;}
    int              GetIgrid(int ipt) const;

protected:
    void             SetAllMembersDefault(void);
    void             DeleteAllMembers(ErrorType E);

private:
    static UString   Properties;
    ErrorType        error;

    double           Size;                  // Outer dimension of the grid.
    double           MeshSize;              // Mesh or step size
    RegionType       RType;                 // The type of the grid

    int              NGlobGrid;             // Number of grids (1 or 3 (NLR-coil case))
    UField*          GlobGrid[MAXNGRID];    // List of all grid points (non-zero points of the uniform field)
    int              Ncum[MAXNGRID+1];      // The cumulative number of (total) points in all grids (including zeroes)
    int              Ndippoints;            // Total number of points used in global search alg. (this is the number of non-zero points in all grids)
    int*             GridIndex;             // GridIndex[idippoint] refers to nonzero points on GlobGrid[]
        
    ErrorType        InitTabIndex(void);
};

#endif // _MESHPOINTS_INCLUDED
