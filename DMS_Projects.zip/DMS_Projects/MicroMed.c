/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Micromed native file                                                      */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  JdM    21-04-05   re-shaped comments (for g++-compatibility)
  JdM    28-06-08   Bug fixed Read_Header_3(), added Direct_Read_Electrode3()
*/

#include"MicroMed.h"

/*******************************************************************/
/************** SET DESCRIPTORS FOR HEADER OF TYPE "4" *************/
/*******************************************************************/

void Set_Descriptors(Micromed_Header_Type_4* Head)
{
    
    Head->Code_Area.Name[0]='O';
    Head->Code_Area.Name[1]='R';
    Head->Code_Area.Name[2]='D';
    Head->Code_Area.Name[3]='E';
    Head->Code_Area.Name[4]='R';
    Head->Code_Area.Name[5]=' ';
    Head->Code_Area.Name[6]=' ';
    Head->Code_Area.Name[7]=' ';
    Head->Code_Area.Start_Offset=sizeof(Micromed_Header_Type_4);
    Head->Code_Area.Length=(unsigned long int)MAX_CAN*sizeof(Micromed_New_Code);

    Head->Electrode_Area.Name[0]='L';
    Head->Electrode_Area.Name[1]='A';
    Head->Electrode_Area.Name[2]='B';
    Head->Electrode_Area.Name[3]='C';
    Head->Electrode_Area.Name[4]='O';
    Head->Electrode_Area.Name[5]='D';
    Head->Electrode_Area.Name[6]=' ';
    Head->Electrode_Area.Name[7]=' ';
    Head->Electrode_Area.Start_Offset=Head->Code_Area.Start_Offset+Head->Code_Area.Length;
    Head->Electrode_Area.Length=(unsigned long int)MAX_LAB*sizeof(Micromed_New_Electrode);

    Head->Note_Area.Name[0]='N';
    Head->Note_Area.Name[1]='O';
    Head->Note_Area.Name[2]='T';
    Head->Note_Area.Name[3]='E';
    Head->Note_Area.Name[4]=' ';
    Head->Note_Area.Name[5]=' ';
    Head->Note_Area.Name[6]=' ';
    Head->Note_Area.Name[7]=' ';
    Head->Note_Area.Start_Offset=Head->Electrode_Area.Start_Offset+Head->Electrode_Area.Length;
    Head->Note_Area.Length=(unsigned long int)MAX_NOTE*sizeof(Micromed_New_Annotation);

    Head->Flag_Area.Name[0]='F';
    Head->Flag_Area.Name[1]='L';
    Head->Flag_Area.Name[2]='A';
    Head->Flag_Area.Name[3]='G';
    Head->Flag_Area.Name[4]='S';
    Head->Flag_Area.Name[5]=' ';
    Head->Flag_Area.Name[6]=' ';
    Head->Flag_Area.Name[7]=' ';
    Head->Flag_Area.Start_Offset=Head->Note_Area.Start_Offset+Head->Note_Area.Length;
    Head->Flag_Area.Length=(unsigned long int)MAX_FLAG*sizeof(Micromed_New_Marker_Pair);

    Head->Segment_Area.Name[0]='T';
    Head->Segment_Area.Name[1]='R';
    Head->Segment_Area.Name[2]='O';
    Head->Segment_Area.Name[3]='N';
    Head->Segment_Area.Name[4]='C';
    Head->Segment_Area.Name[5]='A';
    Head->Segment_Area.Name[6]=' ';
    Head->Segment_Area.Name[7]=' ';
    Head->Segment_Area.Start_Offset=Head->Flag_Area.Start_Offset+Head->Flag_Area.Length;
    Head->Segment_Area.Length=(unsigned long int)MAX_SEGM*sizeof(Micromed_New_Segment);
    
    Head->B_Impedance_Area.Name[0]='I';
    Head->B_Impedance_Area.Name[1]='M';
    Head->B_Impedance_Area.Name[2]='P';
    Head->B_Impedance_Area.Name[3]='E';
    Head->B_Impedance_Area.Name[4]='D';
    Head->B_Impedance_Area.Name[5]='_';
    Head->B_Impedance_Area.Name[6]='B';
    Head->B_Impedance_Area.Name[7]=' ';
    Head->B_Impedance_Area.Start_Offset=Head->Segment_Area.Start_Offset+Head->Segment_Area.Length;
    Head->B_Impedance_Area.Length=(unsigned long int)MAX_CAN*sizeof(Micromed_New_Impedance);
    
    Head->E_Impedance_Area.Name[0]='I';
    Head->E_Impedance_Area.Name[1]='M';
    Head->E_Impedance_Area.Name[2]='P';
    Head->E_Impedance_Area.Name[3]='E';
    Head->E_Impedance_Area.Name[4]='D';
    Head->E_Impedance_Area.Name[5]='_';
    Head->E_Impedance_Area.Name[6]='E';
    Head->E_Impedance_Area.Name[7]=' ';
    Head->E_Impedance_Area.Start_Offset=Head->B_Impedance_Area.Start_Offset+Head->B_Impedance_Area.Length;
    Head->E_Impedance_Area.Length=(unsigned long int)MAX_CAN*sizeof(Micromed_New_Impedance);

    Head->Montage_Area.Name[0]='M';
    Head->Montage_Area.Name[1]='O';
    Head->Montage_Area.Name[2]='N';
    Head->Montage_Area.Name[3]='T';
    Head->Montage_Area.Name[4]='A';
    Head->Montage_Area.Name[5]='G';
    Head->Montage_Area.Name[6]='E';
    Head->Montage_Area.Name[7]=' ';
    Head->Montage_Area.Start_Offset=Head->E_Impedance_Area.Start_Offset+Head->E_Impedance_Area.Length;
    Head->Montage_Area.Length=(unsigned long int)MAX_MONT*sizeof(Micromed_New_Montage);

    Head->Compression_Area.Name[0]='C';
    Head->Compression_Area.Name[1]='O';
    Head->Compression_Area.Name[2]='M';
    Head->Compression_Area.Name[3]='P';
    Head->Compression_Area.Name[4]='R';
    Head->Compression_Area.Name[5]='E';
    Head->Compression_Area.Name[6]='S';
    Head->Compression_Area.Name[7]='S';
    Head->Compression_Area.Start_Offset=Head->Montage_Area.Start_Offset+Head->Montage_Area.Length;
    Head->Compression_Area.Length=(unsigned long int)sizeof(Micromed_New_Compression);
    
    Head->Average_Area.Name[0]='A';
    Head->Average_Area.Name[1]='V';
    Head->Average_Area.Name[2]='E';
    Head->Average_Area.Name[3]='R';
    Head->Average_Area.Name[4]='A';
    Head->Average_Area.Name[5]='G';
    Head->Average_Area.Name[6]='E';
    Head->Average_Area.Name[7]=' ';
    Head->Average_Area.Start_Offset=Head->Compression_Area.Start_Offset+Head->Compression_Area.Length;
    Head->Average_Area.Length=sizeof(Micromed_New_Average);

    Head->History_Area.Name[0]='H';
    Head->History_Area.Name[1]='I';
    Head->History_Area.Name[2]='S';
    Head->History_Area.Name[3]='T';
    Head->History_Area.Name[4]='O';
    Head->History_Area.Name[5]='R';
    Head->History_Area.Name[6]='Y';
    Head->History_Area.Name[7]=' ';
    Head->History_Area.Start_Offset=Head->Average_Area.Start_Offset+Head->Average_Area.Length;
    Head->History_Area.Length=(unsigned long int)MAX_SAMPLE*sizeof(Micromed_New_Sample)+(unsigned long int)MAX_HISTORY*sizeof(Micromed_New_Montage);

    Head->Digital_Video_Area.Name[0]='D';
    Head->Digital_Video_Area.Name[1]='V';
    Head->Digital_Video_Area.Name[2]='I';
    Head->Digital_Video_Area.Name[3]='D';
    Head->Digital_Video_Area.Name[4]='E';
    Head->Digital_Video_Area.Name[5]='O';
    Head->Digital_Video_Area.Name[6]=' ';
    Head->Digital_Video_Area.Name[7]=' ';
    Head->Digital_Video_Area.Start_Offset=Head->History_Area.Start_Offset+Head->History_Area.Length;
    Head->Digital_Video_Area.Length=(unsigned long int)MAX_VIDEO_FILE*sizeof(Micromed_New_Sample);

    Head->EventA_Area.Name[0]='E';
    Head->EventA_Area.Name[1]='V';
    Head->EventA_Area.Name[2]='E';
    Head->EventA_Area.Name[3]='N';
    Head->EventA_Area.Name[4]='T';
    Head->EventA_Area.Name[5]=' ';
    Head->EventA_Area.Name[6]='A';
    Head->EventA_Area.Name[7]=' ';
    Head->EventA_Area.Start_Offset=Head->Digital_Video_Area.Start_Offset+Head->Digital_Video_Area.Length;
    Head->EventA_Area.Length=(unsigned long int)sizeof(Micromed_New_Event);

    Head->EventB_Area.Name[0]='E';
    Head->EventB_Area.Name[1]='V';
    Head->EventB_Area.Name[2]='E';
    Head->EventB_Area.Name[3]='N';
    Head->EventB_Area.Name[4]='T';
    Head->EventB_Area.Name[5]=' ';
    Head->EventB_Area.Name[6]='B';
    Head->EventB_Area.Name[7]=' ';
    Head->EventB_Area.Start_Offset=Head->EventA_Area.Start_Offset+Head->EventA_Area.Length;
    Head->EventB_Area.Length=(unsigned long int)sizeof(Micromed_New_Event);
    
    Head->Trigger_Area.Name[0]='T';
    Head->Trigger_Area.Name[1]='R';
    Head->Trigger_Area.Name[2]='I';
    Head->Trigger_Area.Name[3]='G';
    Head->Trigger_Area.Name[4]='G';
    Head->Trigger_Area.Name[5]='E';
    Head->Trigger_Area.Name[6]='R';
    Head->Trigger_Area.Name[7]=' ';
    Head->Trigger_Area.Start_Offset=Head->EventB_Area.Start_Offset+Head->EventB_Area.Length;
    Head->Trigger_Area.Length=(unsigned long int)MAX_TRIGGER*sizeof(Micromed_New_Trigger);
    
    return;
}



/************************************************************************/
/************* VERIFY IF THE DESCRIPTOR IS DEFINED OR NOT ***************/
/************************************************************************/
int defined(char* Match, char* Found)
{
    unsigned short int i;
    int DescExists = 1;

    for (i=0; i<8; i++)                                                 
        if (Match[i]!=Found[i]) DescExists=0;   

    return(DescExists);
}



/************************************************************************/
/******************** READS HEADER OF TYPE "0" **************************/
/************************************************************************/

void Read_Header_0(FILE* f,     
            Micromed_Header_Type_4*     Head,   
            Micromed_Header_Type_1*     Head_Old,
            Micromed_New_Code           Code[],     
            Micromed_New_Electrode      Electrode[],    
            Micromed_New_Annotation     Note[],     
            Micromed_New_Marker_Pair    Flag[],     
            Micromed_New_Segment        Segment[],      
            Micromed_New_Impedance      B_Impedance[],  
            Micromed_New_Impedance      E_Impedance[],  
            Micromed_New_Montage        Montage[],      
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])

{
    unsigned char code_std[]={174,1,2,5,3,7,4,6,16,8,10,9,17,18,11,13,12,19,14,15,171,160,167,164}; 

    int conv_label[]={0,1,2,3,4,5,6,7,8,9,10,11,12 \
              ,13,14,15,16,17,18,19,28,29,30,31,27,27 \
              ,27,27,27,27,27,27                 \
              ,27,27,27,27,27,27,27,27,27,27,27,27,27 \
              ,27,27,27,27,27,27,27,27,27,27,27,27,27 \
              ,27,27,27,27,27,27                 \
              ,32,34,36,38,40,42,44,46,48,50,52,54,62 \
              ,62,60,62,62,62,62,62,62,62,62,62,62,62 \
              ,62};

   int conv_Code[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 \
           ,16,17,18,19,171,160,167,164,169,174,255,255,20,21,22,23 \
           ,160,160,161,161,162,162,163,163,164,164,165,165,166,166,167,167 \
           ,168,168,169,169,170,170,171,171,255,255,255,255,174,174,255,255 \
           ,63,32,34,36,38,35,39,37,41,43,42,46,48,47,50,52 \
           ,40,44,45,49,62,61,60,59,58,57,56,55,33,51,54,53 \
           ,176,176,177,177,178,178,179,179,180,180,181,181,255,255,182,182 \
           ,183,183,184,184,185,185,255,255,255,255,255,255,186,186,255,255};

   Micromed_Electrode Fix_Labels[]={{{'G','2',' ',' ',' '},0,800} \
                   ,{{'F','p','1',' ',' '},0,800} \
                   ,{{'F','p','2',' ',' '},0,800} \
                   ,{{'F','3',' ',' ',' '},0,800} \
                   ,{{'F','4',' ',' ',' '},0,800} \
                   ,{{'F','7',' ',' ',' '},0,800} \
                   ,{{'F','8',' ',' ',' '},0,800} \
                   ,{{'F','z',' ',' ',' '},0,800} \
                   ,{{'C','3',' ',' ',' '},0,800} \
                   ,{{'C','4',' ',' ',' '},0,800} \
                   ,{{'C','z',' ',' ',' '},0,800} \
                   ,{{'P','3',' ',' ',' '},0,800} \
                   ,{{'P','4',' ',' ',' '},0,800} \
                   ,{{'P','z',' ',' ',' '},0,800} \
                   ,{{'O','1',' ',' ',' '},0,800} \
                   ,{{'O','2',' ',' ',' '},0,800} \
                   ,{{'T','3',' ',' ',' '},0,800} \
                   ,{{'T','4',' ',' ',' '},0,800} \
                   ,{{'T','5',' ',' ',' '},0,800} \
                   ,{{'T','6',' ',' ',' '},0,800} \
                   ,{{'E','O','G',' ',' '},0,800} \
                   ,{{'E','M','G',' ',' '},0,800} \
                   ,{{'E','C','G',' ',' '},0,6400} \
                   ,{{'P','N','G',' ',' '},0,800} \
                   ,{{'A','U','X',' ',' '},0,4000+16384} \
                   ,{{'M','K','R',' ',' '},0,800} \
                   ,{{'G','N','D',' ',' '},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'F','p','z',' ',' '},0,800} \
                   ,{{'O','z',' ',' ',' '},0,800} \
                   ,{{'A','2',' ',' ',' '},0,800} \
                   ,{{'A','1',' ',' ',' '},0,800} \
                   ,{{'E','M','G','1','+'},0,800} \
                   ,{{'E','M','G','1','-'},0,800} \
                   ,{{'E','M','G','2','+'},0,800} \
                   ,{{'E','M','G','2','-'},0,800} \
                   ,{{'E','M','G','3','+'},0,800} \
                   ,{{'E','M','G','3','-'},0,800} \
                   ,{{'E','M','G','4','+'},0,800} \
                   ,{{'E','M','G','4','-'},0,800} \
                   ,{{'P','N','G','1','+'},0,800} \
                   ,{{'P','N','G','1','-'},0,800} \
                   ,{{'P','N','G','2','+'},0,800} \
                   ,{{'P','N','G','2','-'},0,800} \
                   ,{{'P','N','G','3','+'},0,800} \
                   ,{{'P','N','G','3','-'},0,800} \
                   ,{{'E','C','G','1','+'},0,6400} \
                   ,{{'E','C','G','1','-'},0,6400} \
                   ,{{'E','C','G','2','+'},0,6400} \
                   ,{{'E','C','G','2','-'},0,6400} \
                   ,{{'D','C','1','+',' '},0,4000+16384} \
                   ,{{'D','C','1','+',' '},0,4000+16384} \
                   ,{{'D','C','2','+',' '},0,4000+16384} \
                   ,{{'D','C','2','+',' '},0,4000+16384} \
                   ,{{'E','O','G','1','+'},0,800} \
                   ,{{'E','O','G','1','-'},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'M','K','R','+',' '},0,800} \
                   ,{{'M','K','R','-',' '},0,800} \
                   ,{{'.','.','.','.','.'},0,800} \
                   ,{{'.','.','.','.','.'},0,800}};

    int i,j;

/************** Set "Head" Structure ******************************************************/
    fseek(f,0,SEEK_SET);                    
    i=fread(Head_Old,6144,1,f);                 

    for (i=0; i<31; i++) Head->Title[i]=' '; Head->Title[31]=0;

    for (i=0; i<31; i++) Head->Laboratory[i]=' '; Head->Laboratory[31]=0;

    for (i=0; i<22; i++) Head->Patient_Data.Surname[i]=Head_Old->Patient_Data.Surname[i];
    for (i=0; i<20; i++) Head->Patient_Data.Name[i]=Head_Old->Patient_Data.Name[i];
    Head->Patient_Data.Day=Head_Old->Patient_Data.Day;
    Head->Patient_Data.Month=Head_Old->Patient_Data.Month;
    Head->Patient_Data.Year=Head_Old->Patient_Data.Year;

    Head->Date.Day=Head_Old->Date.Day;
    Head->Date.Month=Head_Old->Date.Month;
    Head->Date.Year=Head_Old->Date.Year;
    Head->Time.Hour=Head_Old->Time.Hour;
    Head->Time.Min=Head_Old->Time.Min;
    Head->Time.Sec=Head_Old->Time.Sec;

    Head->Acquisition_Unit=(unsigned short int)Head_Old->Acquisition_Unit;

    Head->Filetype=Head_Old->Filetype;

    Head->Data_Start_Offset=(unsigned long int)Head_Old->Data_Start_Offset;

    Head->Num_Chan=Head_Old->Num_Chan;

    Head->Multiplexer=Head_Old->Num_Chan;

    Head->Rate_Min=Head_Old->Rate_Min;

    Head->Bytes=1;

    Head->Compression=0;

    Head->Montages=0;

    Head->Header_Type=Head_Old->Header_Type;

    Set_Descriptors(Head);


/************** Set "Electrode" Structure *************************************************/
    for (i=0; i<64; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]=Fix_Labels[conv_label[i]].Name[0];
        Electrode[i].Positive_Input_Label[1]=Fix_Labels[conv_label[i]].Name[1];
        Electrode[i].Positive_Input_Label[2]=Fix_Labels[conv_label[i]].Name[2];
        Electrode[i].Positive_Input_Label[3]=Fix_Labels[conv_label[i]].Name[3];
        Electrode[i].Positive_Input_Label[4]=Fix_Labels[conv_label[i]].Name[4];
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='G';
        Electrode[i].Negative_Input_Label[1]='2';
        Electrode[i].Negative_Input_Label[2]=' ';
        Electrode[i].Negative_Input_Label[3]=' ';
        Electrode[i].Negative_Input_Label[4]=' ';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=(-1)*(long)(Fix_Labels[conv_label[i]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Physic_Maximum=(long)(Fix_Labels[conv_label[i]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Measurement_Unit=(unsigned short int)Fix_Labels[conv_label[i]].Signal_Max>>14;
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }

    for (i=64; i<160; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=-400;
        Electrode[i].Physic_Maximum=400;
        Electrode[i].Measurement_Unit=0; 
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }   

    for (i=160; i<187; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=1;
        Electrode[i].Positive_Input_Label[0]=Fix_Labels[conv_label[i-96]].Name[0];
        Electrode[i].Positive_Input_Label[1]=Fix_Labels[conv_label[i-96]].Name[1];
        Electrode[i].Positive_Input_Label[2]=Fix_Labels[conv_label[i-96]].Name[2];
        Electrode[i].Positive_Input_Label[3]=Fix_Labels[conv_label[i-96]].Name[3];
        Electrode[i].Positive_Input_Label[4]=Fix_Labels[conv_label[i-96]].Name[4];
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]=Fix_Labels[conv_label[i-96]+1].Name[0];
        Electrode[i].Negative_Input_Label[1]=Fix_Labels[conv_label[i-96]+1].Name[1];
        Electrode[i].Negative_Input_Label[2]=Fix_Labels[conv_label[i-96]+1].Name[2];
        Electrode[i].Negative_Input_Label[3]=Fix_Labels[conv_label[i-96]+1].Name[3];
        Electrode[i].Negative_Input_Label[4]=Fix_Labels[conv_label[i-96]+1].Name[4];
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=(-1)*(long)(Fix_Labels[conv_label[i-96]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Physic_Maximum=(long)(Fix_Labels[conv_label[i-96]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Measurement_Unit=(unsigned short int)Fix_Labels[conv_label[i-96]].Signal_Max>>14;
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }

    for (i=187; i<640; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=1;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=-400;
        Electrode[i].Physic_Maximum=400;
        Electrode[i].Measurement_Unit=0; 
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }


/************** Set "Code" Structure *****************************************************/
    for (i=0; i<MAX_CAN; i++) Code[i]=0;
    if (Head->Filetype==64)
    {
        for (i=0; i<Head->Num_Chan; i++) Code[i]=code_std[i];
    }
    else
    {
        for (i=0; i<Head->Num_Chan; i++)
        {
            if (((Head_Old->Electrode_Code[i]>>8)==0) || ((Head_Old->Electrode_Code[i]>>8)==26))
                Code[i]=conv_Code[(Head_Old->Electrode_Code[i] & 255)];
            else
            {
                if ((Head_Old->Electrode_Code[i]>>8)<32)
                    Code[i]=conv_Code[(Head_Old->Electrode_Code[i]>>8)];
                else
                    Code[i]=conv_Code[(Head_Old->Electrode_Code[i] & 254)];
            }
        }
    }


/************** Set "Note" Structure *****************************************************/
    for (i=0; i<80; i++)
    {
        Note[i].Sample=Head_Old->Note[i].Time * Head_Old->Rate_Min;
        for (j=0; j<20; j++) Note[i].Comment[j]=Head_Old->Note[i].Comment[j];
        for (j=20; j<40; j++) Note[i].Comment[j]=' ';
    }   
    for (i=80; i<MAX_NOTE; i++)
    {
        Note[i].Sample=0;
        for (j=0; j<40; j++) Note[i].Comment[j]=' ';
    }

    
/************** Set "Flag" Structure *****************************************************/
    for (i=0; i<15; i++)
    {
        Flag[i].Begin=Head_Old->Flag[i].Begin;
        Flag[i].End=Head_Old->Flag[i].End;
    }
    for (i=15; i<MAX_FLAG; i++)
    {
        Flag[i].Begin=0;
        Flag[i].End=0;
    }

    
/************** Set "Segment" Structure ***************************************************/
    for (i=0; i<15; i++)
    {
        Segment[i].Time=Head_Old->Segment[i].Time;
        Segment[i].Sample=Head_Old->Segment[i].Sample;
    }
    for (i=15; i<MAX_SEGM; i++)
    {
        Segment[i].Time=0;
        Segment[i].Sample=0;
    }


/************** Set "B_Impedance" and "E_Impedance" Structure *****************************/
    for (i=0; i<MAX_CAN; i++)                                                   //      
    {                                                                           //
        B_Impedance[i].Positive=255;                                            //  reset
        E_Impedance[i].Positive=255;                                            //  B_Impedance
        B_Impedance[i].Negative=255;                                            //  E_Impedance
        E_Impedance[i].Negative=255;                                            //
    }                                                                           //


/************** Set "Montage" Structure ***************************************************/
    for (i=0; i<MAX_MONT; i++)                                                  //  reset
        Montage[i].Lines=0;                                                     //  Montages


/************** Set "Compression" Structure ***********************************************/
    Compression->Undefined[0]=0;                                                //  reset Compression


/************** Set "Average" Structure ***************************************************/
    Average->Mean_File=0;                                                       //
    Average->Mean_Trace=0;                                                      //  reset 
    Average->Mean_Prestim=0;                                                    //  Average
    Average->Mean_PostStim=0;                                                   //
    Average->Mean_Type=0;                                                       //
    for (i=0; i<AVERAGE_FREE; i++) Average->Free[i]=0;                          //


/************** Set "History" Structure ***************************************************/
    for (i=0; i<MAX_SAMPLE; i++) History_Sample[i]=-1;                          //  reset History_Sample


/************** Set "Digital_Video" Structure *********************************************/
    for (i=0; i<MAX_VIDEO_FILE; i++) Digital_Video[i]=0;                        //  reset Digital_Video


/************** Set "EventA" and "EventB" Structure ***************************************/
    EventA->Description[0]=0;                                                   //
    EventB->Description[0]=0;                                                   //
    for (i=0; i<MAX_EVENT; i++)                                                 //
    {                                                                           //  reset 
        EventA->Selection[i].Begin=0;                                           //  EventA
        EventB->Selection[i].Begin=0;                                           //  EventB
        EventA->Selection[i].End=0;                                             //
        EventB->Selection[i].End=0;                                             //
    }                                                                           //


/************** Set "Trigger" Structure ***************************************************/
    for (i=0; i<MAX_TRIGGER; i++)                                               //
    {                                                                           //  reset 
        Trigger[i].Sample=-1;                                                   //  Trigger
        Trigger[i].Type=-1;                                                     //
    }       
    
    return;
}




/************************************************************************/
/******************** READS HEADER OF TYPE "1" **************************/
/************************************************************************/

void Read_Header_1(FILE* f,
            Micromed_Header_Type_4*     Head, 
            Micromed_Header_Type_1*     Head_Old,
            Micromed_New_Code           Code[], 
            Micromed_New_Electrode      Electrode[], 
            Micromed_New_Annotation     Note[], 
            Micromed_New_Marker_Pair    Flag[], 
            Micromed_New_Segment        Segment[], 
            Micromed_New_Impedance      B_Impedance[], 
            Micromed_New_Impedance      E_Impedance[], 
            Micromed_New_Montage        Montage[], 
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    
   int conv_label[]={0,1,2,3,4,5,6,7,8,9,10,11,12 \
              ,13,14,15,16,17,18,19,28,29,30,31,27,27 \
              ,27,27,27,27,27,27                 \
              ,65,92,66,69,67,71,68,70,80,72,74,73,81 \
              ,82,75,77,76,83,78,93,79,95,94,91,90,89 \
              ,88,87,86,85,84,64                 \
              ,32,34,36,38,40,42,44,46,48,50,52,54,62 \
              ,62,60,62,96,98,100,102,104,106,110,112,114,116 \
              ,124};

    int conv_Code[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 \
           ,16,17,18,19,171,160,167,164,169,174,255,255,20,21,22,23 \
           ,160,160,161,161,162,162,163,163,164,164,165,165,166,166,167,167 \
           ,168,168,169,169,170,170,171,171,255,255,255,255,174,174,255,255 \
           ,63,32,34,36,38,35,39,37,41,43,42,46,48,47,50,52 \
           ,40,44,45,49,62,61,60,59,58,57,56,55,33,51,54,53 \
           ,176,176,177,177,178,178,179,179,180,180,181,181,255,255,182,182 \
           ,183,183,184,184,185,185,255,255,255,255,255,255,186,186,255,255};

    int i,j;

/************** Set "Head" Structure ******************************************************/
    fseek(f,0,SEEK_SET);                    // reads
    fread(Head_Old,6144,1,f);                   // Head_Old

    for (i=0; i<31; i++) Head->Title[i]=' '; Head->Title[31]=0;

    for (i=0; i<31; i++) Head->Laboratory[i]=' '; Head->Laboratory[31]=0;

    for (i=0; i<22; i++) Head->Patient_Data.Surname[i]=Head_Old->Patient_Data.Surname[i];
    for (i=0; i<20; i++) Head->Patient_Data.Name[i]=Head_Old->Patient_Data.Name[i];
    Head->Patient_Data.Day=Head_Old->Patient_Data.Day;
    Head->Patient_Data.Month=Head_Old->Patient_Data.Month;
    Head->Patient_Data.Year=Head_Old->Patient_Data.Year;

    Head->Date.Day=Head_Old->Date.Day;
    Head->Date.Month=Head_Old->Date.Month;
    Head->Date.Year=Head_Old->Date.Year;
    Head->Time.Hour=Head_Old->Time.Hour;
    Head->Time.Min=Head_Old->Time.Min;
    Head->Time.Sec=Head_Old->Time.Sec;

    Head->Acquisition_Unit=(unsigned short int)Head_Old->Acquisition_Unit;

    Head->Filetype=Head_Old->Filetype;

    Head->Data_Start_Offset=(unsigned long int)Head_Old->Data_Start_Offset;

    Head->Num_Chan=Head_Old->Num_Chan;

    Head->Multiplexer=Head_Old->Num_Chan;

    Head->Rate_Min=Head_Old->Rate_Min;

    Head->Bytes=1;

    Head->Compression=0;

    Head->Montages=0;

    Head->Header_Type=Head_Old->Header_Type;

    Set_Descriptors(Head);


/************** Set "Electrode" Structure *************************************************/
    for (i=0; i<64; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]=Head_Old->Labels[conv_label[i]].Name[0];
        Electrode[i].Positive_Input_Label[1]=Head_Old->Labels[conv_label[i]].Name[1];
        Electrode[i].Positive_Input_Label[2]=Head_Old->Labels[conv_label[i]].Name[2];
        Electrode[i].Positive_Input_Label[3]=Head_Old->Labels[conv_label[i]].Name[3];
        Electrode[i].Positive_Input_Label[4]=Head_Old->Labels[conv_label[i]].Name[4];
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='G';
        Electrode[i].Negative_Input_Label[1]='2';
        Electrode[i].Negative_Input_Label[2]=' ';
        Electrode[i].Negative_Input_Label[3]=' ';
        Electrode[i].Negative_Input_Label[4]=' ';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=(-1)*(long)(Head_Old->Labels[conv_label[i]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Physic_Maximum=(long)(Head_Old->Labels[conv_label[i]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Measurement_Unit=(unsigned short int)Head_Old->Labels[conv_label[i]].Signal_Max>>14;
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }

    for (i=64; i<160; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=-400;
        Electrode[i].Physic_Maximum=400;
        Electrode[i].Measurement_Unit=0; 
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }

    for (i=160; i<187; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=1;
        Electrode[i].Positive_Input_Label[0]=Head_Old->Labels[conv_label[i-96]].Name[0];
        Electrode[i].Positive_Input_Label[1]=Head_Old->Labels[conv_label[i-96]].Name[1];
        Electrode[i].Positive_Input_Label[2]=Head_Old->Labels[conv_label[i-96]].Name[2];
        Electrode[i].Positive_Input_Label[3]=Head_Old->Labels[conv_label[i-96]].Name[3];
        Electrode[i].Positive_Input_Label[4]=Head_Old->Labels[conv_label[i-96]].Name[4];
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]=Head_Old->Labels[conv_label[i-96]+1].Name[0];
        Electrode[i].Negative_Input_Label[1]=Head_Old->Labels[conv_label[i-96]+1].Name[1];
        Electrode[i].Negative_Input_Label[2]=Head_Old->Labels[conv_label[i-96]+1].Name[2];
        Electrode[i].Negative_Input_Label[3]=Head_Old->Labels[conv_label[i-96]+1].Name[3];
        Electrode[i].Negative_Input_Label[4]=Head_Old->Labels[conv_label[i-96]+1].Name[4];
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=(-1)*(long)(Head_Old->Labels[conv_label[i-96]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Physic_Maximum=(long)(Head_Old->Labels[conv_label[i-96]].Signal_Max & 16383)/(2*(800/Head_Old->Signal));
        Electrode[i].Measurement_Unit=(unsigned short int)Head_Old->Labels[conv_label[i-96]].Signal_Max>>14;
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }

    for (i=187; i<640; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=1;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)0;
        Electrode[i].Logic_Maximum=(unsigned long)255;
        Electrode[i].Logic_Ground=(unsigned long)128;
        Electrode[i].Physic_Minimum=-400;
        Electrode[i].Physic_Maximum=400;
        Electrode[i].Measurement_Unit=0; 
        Electrode[i].Prefiltering_HiPass_Limit=333;
        Electrode[i].Prefiltering_HiPass_Type=1;
        Electrode[i].Prefiltering_LowPass_Limit=Head_Old->Rate_Min/2;
        Electrode[i].Prefiltering_LowPass_Type=2;
        Electrode[i].Rate_Coefficient=1;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<31; j++) Electrode[i].Description[j]=' ';
        Electrode[i].Description[31]=0;
    }


/************** Set "Code" Structure ******************************************************/   
    for (i=0; i<MAX_CAN; i++) Code[i]=0;
    for (i=0; i<Head->Num_Chan; i++)
    {
        if ((Head_Old->Electrode_Code[i]>>8)==0)
            Code[i]=conv_Code[(Head_Old->Electrode_Code[i] & 255)];
        else
        {
            if ((Head_Old->Electrode_Code[i]>>8)<32)
                Code[i]=conv_Code[(Head_Old->Electrode_Code[i]>>8)];
            else
                Code[i]=conv_Code[(Head_Old->Electrode_Code[i] & 254)];
        }
    }


/************** Set "Note" Structure ******************************************************/    
   for (i=0; i<80; i++)
     {
       Note[i].Sample=Head_Old->Note[i].Time * Head_Old->Rate_Min;
       for (j=0; j<20; j++) Note[i].Comment[j]=Head_Old->Note[i].Comment[j];
       for (j=20; j<40; j++) Note[i].Comment[j]=' ';
     }
   for (i=80; i<MAX_NOTE; i++)
     {
       Note[i].Sample=0;
       for (j=0; j<40; j++) Note[i].Comment[j]=' ';
     }


/************** Set "Flag" Structure ******************************************************/    
    for (i=0; i<15; i++)
    {
        Flag[i].Begin=Head_Old->Flag[i].Begin;
        Flag[i].End=Head_Old->Flag[i].End;
    }
    for (i=15; i<MAX_FLAG; i++)
    {
        Flag[i].Begin=0;
        Flag[i].End=0;
    }


/************** Set "Segment" Structure ***************************************************/    
    for (i=0; i<15; i++)
    {
        Segment[i].Time=Head_Old->Segment[i].Time;
        Segment[i].Sample=Head_Old->Segment[i].Sample;
    }
    for (i=15; i<MAX_SEGM; i++)
    {
        Segment[i].Time=0;
        Segment[i].Sample=0;
    }


/************** Set "B_Impedance" and "E_Impedance" Structure *****************************/
    for (i=0; i<MAX_CAN; i++)
    {
        B_Impedance[i].Positive=255;
        E_Impedance[i].Positive=255;
        B_Impedance[i].Negative=255;
        E_Impedance[i].Negative=255;
    }


/************** Set "Montage" Structure ***************************************************/
   for (i=0; i<MAX_MONT; i++)
       Montage[i].Lines=0;


/************** Set "Compression" Structure ***********************************************/
    Compression->Undefined[0]=0;


/************** Set "Average" Structure ***************************************************/
    Average->Mean_File=0;                                                       //
    Average->Mean_Trace=0;                                                      //  reset 
    Average->Mean_Prestim=0;                                                    //  Average
    Average->Mean_PostStim=0;                                                   //
    Average->Mean_Type=0;                                                       //
    for (i=0; i<AVERAGE_FREE; i++) Average->Free[i]=0;                          //


/************** Set "History" Structure ***************************************************/
    for (i=0; i<MAX_SAMPLE; i++) History_Sample[i]=-1;                          //  reset History_Sample


/************** Set "Digital_Video" Structure *********************************************/
    for (i=0; i<MAX_VIDEO_FILE; i++) Digital_Video[i]=0;                        //  reset Digital_Video


/************** Set "EventA" and "EventB" Structure ***************************************/
    EventA->Description[0]=0;                                                   //
    EventB->Description[0]=0;                                                   //
    for (i=0; i<MAX_EVENT; i++)                                                 //
    {                                                                           //  reset 
        EventA->Selection[i].Begin=0;                                           //  EventA 
        EventB->Selection[i].Begin=0;                                           //  EventB
        EventA->Selection[i].End=0;                                             //
        EventB->Selection[i].End=0;                                             //
    }                                                                           //


/************** Set "Trigger" Structure ***************************************************/
    for (i=0; i<MAX_TRIGGER; i++)                                               //
    {                                                                           //  reset 
        Trigger[i].Sample=-1;                                                   //  Trigger
        Trigger[i].Type=-1;                                                     //
    }       

    return;
}




/************************************************************************/
/******************** READS HEADER OF TYPE "2" **************************/
/************************************************************************/

void Read_Header_2(FILE* f,
            Micromed_Header_Type_4*     Head, 
            Micromed_New_Code           Code[],
            Micromed_New_Electrode      Electrode[], 
            Micromed_New_Annotation     Note[], 
            Micromed_New_Marker_Pair    Flag[], 
            Micromed_New_Segment        Segment[], 
            Micromed_New_Impedance      B_Impedance[], 
            Micromed_New_Impedance      E_Impedance[], 
            Micromed_New_Montage        Montage[], 
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    short i,j,m;
    unsigned short int Conv_Time[]={1,2,4,8,16};
    double Conv_PA[]={0.00,0.20,0.30,0.40,0.50,0.53,0.60,0.70,0.80,1.00,1.20,1.40,1.60,1.80,2.00,2.50,3.00,3.50,4.00,4.50,5.00,5.30,5.50,6.00,7.00,8.00,10.00,20.00,30.00,40.00,50.00,53.00};
    double Conv_PB[]={10.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0,110.0,120.0,130.0,140.0,150.0,175.0,200.0,225.0,250.0,300.0,350.0,400.0,450.0,500.0,550.0,600.0,700.0,800.0,1.0,2.0,4.0,5.0};
    Micromed_Code_3         Code_3[MAX_CAN];
    Micromed_Electrode_3    Electrode_3[MAX_LAB_3]; 
    Micromed_Montage_2      Montage_2[MAX_MONT];


/************** Set "Head" Structure *****************************************************/
    fseek(f,0,SEEK_SET);                                                        //  reads 
////   fread(Head,sizeof(Micromed_Header_Type_4),1,f);                             //  Head
    Direct_Read_Header4(f, Head);

/************** Set "Code" Structure *****************************************************/
    fseek(f,Head->Code_Area.Start_Offset,SEEK_SET);                             //  reads
    fread(Code_3,(unsigned short)Head->Code_Area.Length,1,f);                   //  Code_3
        
    for (i=0; i<Head->Num_Chan; i++) Code[i]=(unsigned short int)Code_3[i];
    for (i=Head->Num_Chan; i<MAX_CAN; i++) Code[i]=0;                           


/************** Set "Electrode" Structure ************************************************/
    fseek(f,Head->Electrode_Area.Start_Offset,SEEK_SET);                        //  reads
    fread(Electrode_3,(unsigned short)Head->Electrode_Area.Length,1,f);         //  Electrode_3
    
    for (i=0; i<240; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=(unsigned char)Electrode_3[i].Type;
        Electrode[i].Positive_Input_Label[0]=Electrode_3[i].Positive_Input_Label[0];
        Electrode[i].Positive_Input_Label[1]=Electrode_3[i].Positive_Input_Label[1];
        Electrode[i].Positive_Input_Label[2]=Electrode_3[i].Positive_Input_Label[2];
        Electrode[i].Positive_Input_Label[3]=Electrode_3[i].Positive_Input_Label[3];
        Electrode[i].Positive_Input_Label[4]=Electrode_3[i].Positive_Input_Label[4];
        Electrode[i].Positive_Input_Label[5]=Electrode_3[i].Positive_Input_Label[5];
        Electrode[i].Negative_Input_Label[0]=Electrode_3[i].Negative_Input_Label[0];
        Electrode[i].Negative_Input_Label[1]=Electrode_3[i].Negative_Input_Label[1];
        Electrode[i].Negative_Input_Label[2]=Electrode_3[i].Negative_Input_Label[2];
        Electrode[i].Negative_Input_Label[3]=Electrode_3[i].Negative_Input_Label[3];
        Electrode[i].Negative_Input_Label[4]=Electrode_3[i].Negative_Input_Label[4];
        Electrode[i].Negative_Input_Label[5]=Electrode_3[i].Negative_Input_Label[5];
        Electrode[i].Logic_Minimum=(unsigned long)Electrode_3[i].Logic_Minimum;
        Electrode[i].Logic_Maximum=(unsigned long)Electrode_3[i].Logic_Maximum;
        Electrode[i].Logic_Ground=(unsigned long)Electrode_3[i].Logic_Ground;
        Electrode[i].Physic_Minimum=Electrode_3[i].Physic_Minimum;
        Electrode[i].Physic_Maximum=Electrode_3[i].Physic_Maximum;
        Electrode[i].Measurement_Unit=Electrode_3[i].Measurement_Unit;
        Electrode[i].Prefiltering_HiPass_Limit=Electrode_3[i].Prefiltering_HiPass_Limit;
        Electrode[i].Prefiltering_HiPass_Type=Electrode_3[i].Prefiltering_HiPass_Type;
        Electrode[i].Prefiltering_LowPass_Limit=Electrode_3[i].Prefiltering_LowPass_Limit;
        Electrode[i].Prefiltering_LowPass_Type=Electrode_3[i].Prefiltering_LowPass_Type;
        Electrode[i].Rate_Coefficient=Electrode_3[i].Rate_Coefficient;
        Electrode[i].Latitude=Electrode_3[i].Latitude;
        Electrode[i].Longitude=Electrode_3[i].Longitude;
        Electrode[i].Maps=Electrode_3[i].Maps;
        Electrode[i].Average_Ref=Electrode_3[i].Average_Ref;
        for (j=0; j<32; j++) Electrode[i].Description[j]=Electrode_3[i].Description[j];
    }

    for (i=240; i<640; i++)
    {
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)Electrode_3[1].Logic_Minimum;
        Electrode[i].Logic_Maximum=(unsigned long)Electrode_3[1].Logic_Maximum;
        Electrode[i].Logic_Ground=(unsigned long)Electrode_3[1].Logic_Ground;
        Electrode[i].Physic_Minimum=Electrode_3[1].Physic_Minimum;
        Electrode[i].Physic_Maximum=Electrode_3[1].Physic_Maximum;
        Electrode[i].Measurement_Unit=Electrode_3[1].Measurement_Unit;
        Electrode[i].Prefiltering_HiPass_Limit=Electrode_3[1].Prefiltering_HiPass_Limit;
        Electrode[i].Prefiltering_HiPass_Type=Electrode_3[1].Prefiltering_HiPass_Type;
        Electrode[i].Prefiltering_LowPass_Limit=Electrode_3[1].Prefiltering_LowPass_Limit;
        Electrode[i].Prefiltering_LowPass_Type=Electrode_3[1].Prefiltering_LowPass_Type;
        Electrode[i].Rate_Coefficient=Electrode_3[1].Rate_Coefficient;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<32; j++) Electrode[i].Description[j]=Electrode_3[i].Description[j];
    }


/************** Convert "Note" Structure ***********************************************/
    fseek(f,Head->Note_Area.Start_Offset,SEEK_SET);                             //  reads 
    fread(Note,(unsigned short)Head->Note_Area.Length,1,f);                     //  Note
    
    for (i=0; i<MAX_NOTE_2; i++)    Note[i].Sample*=Head->Rate_Min;             //
    for (i=MAX_NOTE_2; i<MAX_NOTE; i++)                                         //
    {                                                                           //  converts 
       Note[i].Sample=0;                                                        //  Format
       for (j=0; j<40; j++) Note[i].Comment[j]=' ';                             //
    }                                                                           //


/************** Set "Flag" Structure ******************************************************/
    fseek(f,Head->Flag_Area.Start_Offset,SEEK_SET);                             //  reads 
    fread(Flag,(int)Head->Flag_Area.Length,1,f);                                //  Flag


/************** Set "Segment" Structure ***************************************************/
    fseek(f,Head->Segment_Area.Start_Offset,SEEK_SET);                          //  reads 
    fread(Segment,(int)Head->Segment_Area.Length,1,f);                          //  Segment


/************** Set "B_Impedance" Structure ***********************************************/
    fseek(f,Head->B_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads 
    fread(B_Impedance,(int)Head->B_Impedance_Area.Length,1,f);                  //  B_Impedance
    
    for (i=Head->Num_Chan; i<MAX_CAN; i++)                                      //  
    {                                                                           //
        B_Impedance[i].Positive=0;                                              //
        B_Impedance[i].Negative=0;                                              //
    }                                                                           //


/************** Set "E_Impedance" Structure ***********************************************/
    fseek(f,Head->E_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads 
    fread(E_Impedance,(int)Head->E_Impedance_Area.Length,1,f);                  //  E_Impedance
    
    for (i=Head->Num_Chan; i<MAX_CAN; i++)                                      //  
    {                                                                           //
        E_Impedance[i].Positive=0;                                              //
        E_Impedance[i].Negative=0;                                              //
    }                                                                           //


/************** Set "Montage" Structure ***************************************************/
    fseek(f,Head->Montage_Area.Start_Offset,SEEK_SET);                          //  reads 
    fread(Montage_2,(int)Head->Montage_Area.Length,1,f);                        //  Montages
    
    for (m=0; m<Head->Montages; m++)    
    {
        if (Montage_2[m].Lines<=96) Montage[m].Lines=Montage_2[m].Lines;
        else Montage[m].Lines=1;

        Montage[m].Sectors=1;

        if (Montage_2[m].Base_Time<=4) Montage[m].Base_Time=Conv_Time[Montage_2[m].Base_Time];
        else Montage[m].Base_Time=10;

        if (Montage_2[m].Notch<=2) Montage[m].Notch=(unsigned char)Montage_2[m].Notch;
        else Montage[m].Notch=0;

        Montage[m].ViewReference=0;

        for (i=0; i<MAX_DERIV; i++)
        {
            Montage[m].Colour[i]=0;
            Montage[m].Selection[i]=Montage_2[m].Selection[i]&1;
            Montage[m].Inputs[i].NonInv=Montage_2[m].Derivation[i].NonInv;
            Montage[m].Inputs[i].Inv=Montage_2[m].Derivation[i].Inv;
            Montage[m].HiPass_Filter[i]=(unsigned long int)(1000.0*Conv_PA[(Montage_2[m].L_Filter[i]/20)&31]);
            Montage[m].LowPass_Filter[i]=(unsigned long int)(100.0*Conv_PB[(Montage_2[m].H_Filter[i]/10-1)&31]);
            Montage[m].Reference[i]=200;
        }   

        for (i=0; i<64; i++) Montage[m].Description[i]=Montage_2[m].Description[i];
    }


/************** Set "Compression" Structure ***********************************************/
    fseek(f,Head->Compression_Area.Start_Offset,SEEK_SET);                      //  reset 
    fread(Compression,(int)Head->Compression_Area.Length,1,f);                  //  Compression


/************** Set "Average" Structure ***************************************************/
    Average->Mean_File=0;                                                       //
    Average->Mean_Trace=0;                                                      //  reset
    Average->Mean_Prestim=0;                                                    //  Average 
    Average->Mean_PostStim=0;                                                   //
    Average->Mean_Type=0;                                                       //  
    for (i=0; i<AVERAGE_FREE; i++) Average->Free[i]=0;                          //


/************** Set "History" Structure ***************************************************/
    for (i=0; i<MAX_SAMPLE; i++) History_Sample[i]=-1;                          //  reset History_Sample


/************** Set "Digital_Video" Structure *********************************************/
    for (i=0; i<MAX_VIDEO_FILE; i++) Digital_Video[i]=0;                        //  reset Digital_Video


/************** Set "EventA" and "EventB" Structure ***************************************/
    EventA->Description[0]=0;                                                   //
    EventB->Description[0]=0;                                                   //
    for (i=0; i<MAX_EVENT; i++)                                                 //
    {                                                                           //  reset 
        EventA->Selection[i].Begin=0;                                           //  EventA
        EventB->Selection[i].Begin=0;                                           //  EventB
        EventA->Selection[i].End=0;                                             //
        EventB->Selection[i].End=0;                                             //
    }                                                                           //


/************** Set "Trigger" Structure ***************************************************/
    for (i=0; i<MAX_TRIGGER; i++)                                               //
    {                                                                           //  reset 
        Trigger[i].Sample=-1;                                                   //  Trigger
        Trigger[i].Type=-1;                                                     //
    }                                                                           //
    

/************** Set "Descriptor" Structure ************************************************/
    Set_Descriptors(Head);

    return;
}



/************************************************************************/
/******************** READS HEADER OF TYPE "3" **************************/
/************************************************************************/

void Read_Header_3(FILE* f,
            Micromed_Header_Type_4*     Head, 
            Micromed_New_Code           Code[], 
            Micromed_New_Electrode      Electrode[], 
            Micromed_New_Annotation     Note[], 
            Micromed_New_Marker_Pair    Flag[], 
            Micromed_New_Segment        Segment[], 
            Micromed_New_Impedance      B_Impedance[], 
            Micromed_New_Impedance      E_Impedance[], 
            Micromed_New_Montage        Montage[], 
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    unsigned short int  i,j,m;
    char NameDesc[11]="xxxxxxxx";
    void* Address;
    Micromed_Code_3         Code_3[MAX_CAN];
    Micromed_Electrode_3    Electrode_3[MAX_LAB_3]; 
    Micromed_Montage_3      Montage_3[MAX_MONT]; // Must be greater between MAX_MONT and MAX_HISTORY

/************** Set "Header" Structure ***************************************************/
    fseek(f,0,SEEK_SET);                                                        //  reads
////    i=fread(Head,1,sizeof(Micromed_Header_Type_4),f);                           //  Head
    Direct_Read_Header4(f, Head);


/************** Set "Code" Structure *****************************************************/
    fseek(f,Head->Code_Area.Start_Offset,SEEK_SET);                             //  reads
    fread(Code_3,1,Head->Code_Area.Length,f);                                   //  Code_3
    
    for (i=0; i<Head->Num_Chan; i++) Code[i]=(unsigned short int)Code_3[i];     //  Convert Code_3
    for (i=Head->Num_Chan; i<MAX_CAN; i++) Code[i]=0;                           //  into Code


/************** Set "Electrode" Structure ************************************************/
    fseek(f,Head->Electrode_Area.Start_Offset,SEEK_SET);                        //  reads
////    fread(Electrode_3,1,Head->Electrode_Area.Length,f);                         //  Electrode_3
    i = (unsigned short int)(Head->Electrode_Area.Length/128);
    Direct_Read_Electrode3(f, Electrode_3, 256);

    for (i=0; i<240; i++)                                                       //  convert Electrode_3
    {                                                                           //  into Electrode
        Electrode[i].Status=0;
        Electrode[i].Type=(unsigned char)Electrode_3[i].Type;
        Electrode[i].Positive_Input_Label[0]=Electrode_3[i].Positive_Input_Label[0];
        Electrode[i].Positive_Input_Label[1]=Electrode_3[i].Positive_Input_Label[1];
        Electrode[i].Positive_Input_Label[2]=Electrode_3[i].Positive_Input_Label[2];
        Electrode[i].Positive_Input_Label[3]=Electrode_3[i].Positive_Input_Label[3];
        Electrode[i].Positive_Input_Label[4]=Electrode_3[i].Positive_Input_Label[4];
        Electrode[i].Positive_Input_Label[5]=Electrode_3[i].Positive_Input_Label[5];
        Electrode[i].Negative_Input_Label[0]=Electrode_3[i].Negative_Input_Label[0];
        Electrode[i].Negative_Input_Label[1]=Electrode_3[i].Negative_Input_Label[1];
        Electrode[i].Negative_Input_Label[2]=Electrode_3[i].Negative_Input_Label[2];
        Electrode[i].Negative_Input_Label[3]=Electrode_3[i].Negative_Input_Label[3];
        Electrode[i].Negative_Input_Label[4]=Electrode_3[i].Negative_Input_Label[4];
        Electrode[i].Negative_Input_Label[5]=Electrode_3[i].Negative_Input_Label[5];
        Electrode[i].Logic_Minimum=(unsigned long)Electrode_3[i].Logic_Minimum;
        Electrode[i].Logic_Maximum=(unsigned long)Electrode_3[i].Logic_Maximum;
        Electrode[i].Logic_Ground=(unsigned long)Electrode_3[i].Logic_Ground;
        Electrode[i].Physic_Minimum=Electrode_3[i].Physic_Minimum;
        Electrode[i].Physic_Maximum=Electrode_3[i].Physic_Maximum;
        Electrode[i].Measurement_Unit=Electrode_3[i].Measurement_Unit;
        Electrode[i].Prefiltering_HiPass_Limit=Electrode_3[i].Prefiltering_HiPass_Limit;
        Electrode[i].Prefiltering_HiPass_Type=Electrode_3[i].Prefiltering_HiPass_Type;
        Electrode[i].Prefiltering_LowPass_Limit=Electrode_3[i].Prefiltering_LowPass_Limit;
        Electrode[i].Prefiltering_LowPass_Type=Electrode_3[i].Prefiltering_LowPass_Type;
        Electrode[i].Rate_Coefficient=Electrode_3[i].Rate_Coefficient;
        Electrode[i].Latitude=Electrode_3[i].Latitude;
        Electrode[i].Longitude=Electrode_3[i].Longitude;
        Electrode[i].Maps=Electrode_3[i].Maps;
        Electrode[i].Average_Ref=Electrode_3[i].Average_Ref;
        for (j=0; j<32; j++) Electrode[i].Description[j]=Electrode_3[i].Description[j];
    }
    for (i=0; i<Head->Num_Chan; i++) Electrode[Code[i]].Status=1;               //  Set Active Electrodes


    for (i=240; i<MAX_LAB; i++)                                                 // Set Rest of Electrode_3
    {                                                                           // at values of Fp1=ELectrode_3[1]
        Electrode[i].Status=0;
        Electrode[i].Type=0;
        Electrode[i].Positive_Input_Label[0]='.';
        Electrode[i].Positive_Input_Label[1]='.';
        Electrode[i].Positive_Input_Label[2]='.';
        Electrode[i].Positive_Input_Label[3]='.';
        Electrode[i].Positive_Input_Label[4]='.';
        Electrode[i].Positive_Input_Label[5]=0;
        Electrode[i].Negative_Input_Label[0]='.';
        Electrode[i].Negative_Input_Label[1]='.';
        Electrode[i].Negative_Input_Label[2]='.';
        Electrode[i].Negative_Input_Label[3]='.';
        Electrode[i].Negative_Input_Label[4]='.';
        Electrode[i].Negative_Input_Label[5]=0;
        Electrode[i].Logic_Minimum=(unsigned long)Electrode_3[1].Logic_Minimum;
        Electrode[i].Logic_Maximum=(unsigned long)Electrode_3[1].Logic_Maximum;
        Electrode[i].Logic_Ground=(unsigned long)Electrode_3[1].Logic_Ground;
        Electrode[i].Physic_Minimum=Electrode_3[1].Physic_Minimum;
        Electrode[i].Physic_Maximum=Electrode_3[1].Physic_Maximum;
        Electrode[i].Measurement_Unit=Electrode_3[1].Measurement_Unit;
        Electrode[i].Prefiltering_HiPass_Limit=Electrode_3[1].Prefiltering_HiPass_Limit;
        Electrode[i].Prefiltering_HiPass_Type=Electrode_3[1].Prefiltering_HiPass_Type;
        Electrode[i].Prefiltering_LowPass_Limit=Electrode_3[1].Prefiltering_LowPass_Limit;
        Electrode[i].Prefiltering_LowPass_Type=Electrode_3[1].Prefiltering_LowPass_Type;
        Electrode[i].Rate_Coefficient=Electrode_3[1].Rate_Coefficient;
        Electrode[i].Latitude=0.0;
        Electrode[i].Longitude=0.0;
        Electrode[i].Maps=0;
        Electrode[i].Average_Ref=0;
        for (j=0; j<32; j++) Electrode[i].Description[j]=Electrode_3[1].Description[j];
    }


/************** Set "Note" Structure ******************************************************/
    fseek(f,Head->Note_Area.Start_Offset,SEEK_SET);                             // 
    fread(Note,1,Head->Note_Area.Length,f);                                     //  reads Note


/************** Set "Flag" Structure ******************************************************/
    fseek(f,Head->Flag_Area.Start_Offset,SEEK_SET);                             // 
    fread(Flag,1,Head->Flag_Area.Length,f);                                     //  reads Flag


/************** Set "Segment" Structure ***************************************************/
    fseek(f,Head->Segment_Area.Start_Offset,SEEK_SET);                          // 
    fread(Segment,1,Head->Segment_Area.Length,f);                               //  reads Segment


/************** Set "B_Impedance" Structure ***********************************************/
    fseek(f,Head->B_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads
    fread(B_Impedance,1,Head->B_Impedance_Area.Length,f);                       //  B_Impedance
    
    for (i=Head->Num_Chan; i<MAX_CAN; i++)                                      //  
    {                                                                           //
        B_Impedance[i].Positive=0;                                              //
        B_Impedance[i].Negative=0;                                              //
    }                                                                           //

    
/************** Set "E_Impedance" Structure **********************************************/
    fseek(f,Head->E_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads
    fread(E_Impedance,1,Head->E_Impedance_Area.Length,f);                       //  E_Impedance
    
    for (i=Head->Num_Chan; i<MAX_CAN; i++)                                      //  
    {                                                                           //
        E_Impedance[i].Positive=0;                                              //
        E_Impedance[i].Negative=0;                                              //
    }                                                                           //


/************** Set "Montage" Structure ***************************************************/
                                                    
    fseek(f,Head->Montage_Area.Start_Offset,SEEK_SET);  

    for (m=0; m<Head->Montages; m++)                                //  reads
    {                                                               //  Montage_3
        Address = &(Montage_3[m]);
        fread(Address,1,sizeof(Micromed_Montage_3),f);

        if (Montage_3[m].Lines<=96) Montage[m].Lines=Montage_3[m].Lines;
        else Montage[m].Lines=1;

        Montage[m].Sectors=Montage_3[m].Sectors;                    //  Convert Montage_3[]
        Montage[m].Base_Time=Montage_3[m].Base_Time;                //  into Montage[]
        Montage[m].Notch=(unsigned char)Montage_3[m].Notch;
        Montage[m].ViewReference=Montage_3[m].ViewReference;

        for (i=0; i<MAX_DERIV; i++)
        {
            Montage[m].Colour[i]=Montage_3[m].Colour[i];
            Montage[m].Selection[i]=Montage_3[m].Selection[i];
            Montage[m].Inputs[i].NonInv=(unsigned short)Montage_3[m].Inputs[i].NonInv;
            Montage[m].Inputs[i].Inv=(unsigned short)Montage_3[m].Inputs[i].Inv;
            Montage[m].HiPass_Filter[i]=Montage_3[m].HiPass_Filter[i];
            Montage[m].LowPass_Filter[i]=Montage_3[m].LowPass_Filter[i];
            Montage[m].Reference[i]=Montage_3[m].Reference[i];
        }   

        for (i=0; i<64; i++) Montage[m].Description[i]=Montage_3[m].Description[i];
    }


/************** Set "Compression" Structure ***********************************************/
    fseek(f,Head->Compression_Area.Start_Offset,SEEK_SET);                      //  reads
    fread(Compression,1,Head->Compression_Area.Length,f);                       //  Compression


/************** Set "Average" Structure ***************************************************/
    sprintf(NameDesc,"AVERAGE ");                                               
    if (defined(NameDesc, Head->Average_Area.Name))                             
    {                                                                           
        fseek(f,Head->Average_Area.Start_Offset,SEEK_SET);      //  if defined
        fread(Average,1,Head->Average_Area.Length,f);           //  reads 
    }                                                           //  Average
    else                                                                        
    {                                                                           
        Average->Mean_File=0;                                                   
        Average->Mean_Trace=0;                                  //  otherwise
        Average->Mean_Prestim=0;                                //  reset 
        Average->Mean_PostStim=0;                               //  Average
        Average->Mean_Type=0;                                                       
        Average->Corr_Max_Time=0.0;                                                     
        Average->Corr_Mean_Time=0.0;
        Average->Corr_Min_Time=0.0;
        Average->Corr_Ratio=0.0;
        Average->Corr_SD=0.0;
        Average->Correct_Answers=0;
        Average->No_Answers=0;
        Average->Wrong_Answers=0;
        for (i=0; i<AVERAGE_FREE; i++) Average->Free[i]=0;      
    }


/************** Set "History" Structure ***************************************************/
    sprintf(NameDesc,"HISTORY ");                   
    if (defined(NameDesc, Head->History_Area.Name))                         
    {                                                                           //  if defined
        fseek(f,Head->History_Area.Start_Offset,SEEK_SET);                      //  reads 
        fread(History_Sample,1,MAX_SAMPLE*sizeof(Micromed_New_Sample),f);       //  History_Sample 
                                                                        
        for (m=0; History_Sample[m]!=-1; m++)
        {
            Address = &(Montage_3[m]);                                          //  reads Montage_3
            fread(Address,1,sizeof(Micromed_Montage_3),f);                      //
        }
    }                                                                           
    else                                                                        
    {                                                                           //  otherwise
        for (i=0; i<MAX_SAMPLE; i++) History_Sample[i]=-1;                      //  reset 
    }                                                                           //  History_Sample

    for (m=0; History_Sample[m]!=-1; m++)   
    {
        if (Montage_3[m].Lines<=96) History[m].Lines=Montage_3[m].Lines;
        else History[m].Lines=1;

        History[m].Sectors=Montage_3[m].Sectors;
        History[m].Base_Time=Montage_3[m].Base_Time;
        History[m].Notch=(unsigned char)Montage_3[m].Notch;
        History[m].ViewReference=Montage_3[m].ViewReference;

        for (i=0; i<MAX_DERIV; i++)
        {
            History[m].Colour[i]=Montage_3[m].Colour[i];
            History[m].Selection[i]=Montage_3[m].Selection[i];
            History[m].Inputs[i].NonInv=(unsigned short)Montage_3[m].Inputs[i].NonInv;
            History[m].Inputs[i].Inv=(unsigned short)Montage_3[m].Inputs[i].Inv;
            History[m].HiPass_Filter[i]=Montage_3[m].HiPass_Filter[i];
            History[m].LowPass_Filter[i]=Montage_3[m].LowPass_Filter[i];
            History[m].Reference[i]=Montage_3[m].Reference[i];
        }   

        for (i=0; i<64; i++) History[m].Description[i]=Montage_3[m].Description[i];
    }

/************** Set "Digital_Video" Structure *********************************************/
    for (i=0; i<MAX_VIDEO_FILE; i++) Digital_Video[i]=0;                        //  reset Digital_Video

    
/************** Set "Event A" Structure ***************************************************/
    sprintf(NameDesc,"EVENT A ");                                               //
    if (defined(NameDesc, Head->EventA_Area.Name))                              //
    {                                                                           //
        fseek(f,Head->EventA_Area.Start_Offset,SEEK_SET);                       //  if defined
        fread(EventA,1,Head->EventA_Area.Length,f);                             //  reads 
    }                                                                           //  EventA
    else                                                                        //
    {                                                                           //
        EventA->Description[0]=0;                                               //
        for (i=0; i<MAX_EVENT; i++)                                             //  
        {                                                                       //  otherwise
            EventA->Selection[i].Begin=0;                                       //  reset
            EventA->Selection[i].End=0;                                         //  EventA
        }                                                                       //
    }


/************** Set "Event B" Structure ***************************************************/
    sprintf(NameDesc,"EVENT B ");                                               //
    if (defined(NameDesc, Head->EventB_Area.Name))                              //
    {                                                                           //
        fseek(f,Head->EventB_Area.Start_Offset,SEEK_SET);                       //  if defined
        fread(EventB,1,Head->EventB_Area.Length,f);                             //  reads 
    }                                                                           //  EventB
    else                                                                        //
    {                                                                           //
        EventB->Description[0]=0;                                               //
        for (i=0; i<MAX_EVENT; i++)                                             //
        {                                                                       //  otherwise
            EventB->Selection[i].Begin=0;                                       //  reset
            EventB->Selection[i].End=0;                                         //  EventB
        }                                                                       //
    }

    
/************** Set "Trigger" Structure ***************************************************/
    for (i=0; i<MAX_TRIGGER; i++)                                               //
    {                                                                           //  reset
        Trigger[i].Sample=-1;                                                   //  Trigger
        Trigger[i].Type=-1;                                                     //
    }                                                                           //


/************** Set "Descriptor" Structure ************************************************/
    Set_Descriptors(Head);

    return;
}



/************************************************************************/
/******************** READS HEADER OF TYPE "4" **************************/
/************************************************************************/

void Read_Header_4(FILE* f,
            Micromed_Header_Type_4*     Head, 
            Micromed_New_Code           Code[], 
            Micromed_New_Electrode      Electrode[], 
            Micromed_New_Annotation     Note[], 
            Micromed_New_Marker_Pair    Flag[], 
            Micromed_New_Segment        Segment[], 
            Micromed_New_Impedance      B_Impedance[], 
            Micromed_New_Impedance      E_Impedance[], 
            Micromed_New_Montage        Montage[], 
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[],
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    unsigned short int  Amount,m;
    void* Address;

/************** Set "Head" Structure ******************************************************/
    fseek(f,0,SEEK_SET);                                                        //  reads
////    fread(Head,sizeof(Micromed_Header_Type_4),1,f);                             //  Head
    Direct_Read_Header4(f, Head);

/************** Set "Code" Structure ******************************************************/
    fseek(f,Head->Code_Area.Start_Offset,SEEK_SET);                             //  reads
    fread(Code,(unsigned short)Head->Code_Area.Length,1,f);                     //  Code


/************** Set "Electrode" Structure *************************************************/
    Amount=(unsigned short int)(Head->Electrode_Area.Length/(unsigned long)2);  //
    Address = &(Electrode[0]);                                                  //
    fseek(f,Head->Electrode_Area.Start_Offset,SEEK_SET);                        //  reads 
////    fread(Address,Amount,1,f);                                                  //  Electrode
////    Address = &(Electrode[MAX_LAB/2]);                                          //
////    fread(Address,Amount,1,f);                                                  //
    Direct_Read_New_Electrode(f, Electrode, MAX_LAB);

/************** Set "Note" Structure ******************************************************/
    fseek(f,Head->Note_Area.Start_Offset,SEEK_SET);                             //  reads 
    fread(Note,(unsigned short)Head->Note_Area.Length,1,f);                     //  Note

    
/************** Set "Flag" Structure ******************************************************/
    fseek(f,Head->Flag_Area.Start_Offset,SEEK_SET);                             //  reads 
    fread(Flag,(unsigned short)Head->Flag_Area.Length,1,f);                     //  Flag


/************** Set "Segment" Structure ***************************************************/    
    fseek(f,Head->Segment_Area.Start_Offset,SEEK_SET);                          //  reads 
    fread(Segment,(unsigned short)Head->Segment_Area.Length,1,f);               //  Segment


/************** Set "B_Impedance" Structure ***********************************************/
    fseek(f,Head->B_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads 
    fread(B_Impedance,(unsigned short)Head->B_Impedance_Area.Length,1,f);       //  B_Impedance


/************** Set "E_Impedance" Structure ***********************************************/    
    fseek(f,Head->E_Impedance_Area.Start_Offset,SEEK_SET);                      //  reads 
    fread(E_Impedance,(unsigned short)Head->E_Impedance_Area.Length,1,f);       //  E_Impedance


/************** Set "Montage" Structure ***************************************************/
    fseek(f,Head->Montage_Area.Start_Offset,SEEK_SET);                          //
    for (m=0; m<Head->Montages; m++)                                            //  reads
    {                                                                           //  Montage
        Address = &(Montage[m]);                                                //
        Amount=(unsigned short int)sizeof(Micromed_New_Montage);                //
        fread(Address,Amount,1,f);                                              //
    }                                                                           //


/************** Set "Compression" Structure ***********************************************/
    fseek(f,Head->Compression_Area.Start_Offset,SEEK_SET);                      //  reads 
    fread(Compression,(unsigned short)Head->Compression_Area.Length,1,f);       //  Compression


/************** Set "Average" Structure ***************************************************/
    fseek(f,Head->Average_Area.Start_Offset,SEEK_SET);                          //  reads 
    fread(Average,(unsigned short)Head->Average_Area.Length,1,f);               //  Average


/************** Set "History" Structure ***************************************************/
    fseek(f,Head->History_Area.Start_Offset,SEEK_SET);                          //  reads
    fread(History_Sample,MAX_SAMPLE*sizeof(Micromed_New_Sample),1,f);           //  History_Sample 

    Amount = (unsigned short int)sizeof(Micromed_New_Montage);                  //
    for (m=0; History_Sample[m]!=-1; m++)                                       //  reads
    {                                                                           //  History
        Address = &(History[m]);                                                //
        fread(Address,Amount,1,f);                                              //
    }                                                                           //

/************** Set "Digital_Video" Structure *********************************************/   
    fseek(f,Head->Digital_Video_Area.Start_Offset,SEEK_SET);                    //  reads 
    fread(Digital_Video,(unsigned short)Head->Digital_Video_Area.Length,1,f);   //  Digital_Video


/************** Set "Event_A" Structure ***************************************************/    
    fseek(f,Head->EventA_Area.Start_Offset,SEEK_SET);                           //  reads 
    fread(EventA,(unsigned short)Head->EventA_Area.Length,1,f);                 //  EventA


/************** Set "Event_B" Structure ***************************************************/    
    fseek(f,Head->EventB_Area.Start_Offset,SEEK_SET);                           //  reads 
    fread(EventB,(unsigned short)Head->EventB_Area.Length,1,f);                 //  EventB


/************** Set "Trigger" Structure ***************************************************/    
    fseek(f,Head->Trigger_Area.Start_Offset,SEEK_SET);                          //  reads 
    fread(Trigger,(unsigned short)Head->Trigger_Area.Length,1,f);               //  Trigger

    return;
}

/************************************************************************/
/******************** UPDATE A COMPLETE HEADER OF TYPE "4" **************/
/****** It works only if the header is complete of all descriptors ******/
/************************************************************************/

void Update_EEG_Header(FILE*            d,
            Micromed_Header_Type_4*     Head,
            Micromed_New_Code           Code[],
            Micromed_New_Electrode      Electrode[],
            Micromed_New_Annotation     Note[],
            Micromed_New_Marker_Pair    Flag[],
            Micromed_New_Segment        Segment[],
            Micromed_New_Impedance      B_Impedance[],
            Micromed_New_Impedance      E_Impedance[],
            Micromed_New_Montage        Montage[],
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    rewind(d);                                                                  //  writes 
    fwrite(Head,1,sizeof(Micromed_Header_Type_4),d);                            //  write Head              
        
    fseek(d,Head->Code_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Code,1,(unsigned short)Head->Code_Area.Length,d);                    //  Code

    fseek(d,Head->Electrode_Area.Start_Offset,SEEK_SET);                        //  writes 
    fwrite(Electrode,1,Head->Electrode_Area.Length,d);                          //  Electrode

    fseek(d,Head->Note_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Note,1,Head->Note_Area.Length,d);                                    //  Note

    fseek(d,Head->Flag_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Flag,1,Head->Flag_Area.Length,d);                                    //  Flag

    fseek(d,Head->Segment_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Segment,1,Head->Segment_Area.Length,d);                              //  Segment

    fseek(d,Head->B_Impedance_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(B_Impedance,1,Head->B_Impedance_Area.Length,d);                      //  B_Impedance

    fseek(d,Head->E_Impedance_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(E_Impedance,1,Head->E_Impedance_Area.Length,d);                      //  E_Impedance

    fseek(d,Head->Montage_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Montage,1,Head->Montage_Area.Length,d);                              //  Montages

    fseek(d,Head->Compression_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(Compression,1,Head->Compression_Area.Length,d);                      //  Compression

    fseek(d,Head->Average_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Average,1,Head->Average_Area.Length,d);                              //  Average

    fseek(d,Head->History_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(History_Sample,1,MAX_SAMPLE*sizeof(Micromed_New_Sample),d);          //  History_Sample
    fwrite(History,1,(unsigned long)MAX_HISTORY*(unsigned long)sizeof(Micromed_New_Montage),d);
    
    fseek(d,Head->Digital_Video_Area.Start_Offset,SEEK_SET);                    //  writes 
    fwrite(Digital_Video,1,Head->Digital_Video_Area.Length,d);                  //  Digital_Video

    fseek(d,Head->EventA_Area.Start_Offset,SEEK_SET);                           //  writes 
    fwrite(EventA,1,Head->EventA_Area.Length,d);                                //  EventA

    fseek(d,Head->EventB_Area.Start_Offset,SEEK_SET);                           //  writes 
    fwrite(EventB,1,Head->EventB_Area.Length,d);                                //  EventB

    fseek(d,Head->Trigger_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Trigger,1,Head->Trigger_Area.Length,d);                              //  Trigger

    rewind(d);
    return;
}



/************************************************************************/
/******************** CREATE A COMPLETE HEADER OF TYPE "4" **************/
/************************************************************************/

FILE* Create_EEG_Header(char*           filename,
            Micromed_Header_Type_4*     Head,
            Micromed_New_Code           Code[],
            Micromed_New_Electrode      Electrode[],
            Micromed_New_Annotation     Note[],
            Micromed_New_Marker_Pair    Flag[],
            Micromed_New_Segment        Segment[],
            Micromed_New_Impedance      B_Impedance[],
            Micromed_New_Impedance      E_Impedance[],
            Micromed_New_Montage        Montage[],
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[], 
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])
{
    long    New_Offset,New_Position,i;
    unsigned char   buffer[32*256];
    FILE* d;

    if ((d=fopen(filename,"wb")) == NULL) return(d);
    rewind(d);

    Head->Header_Type=4;
    Set_Descriptors(Head);

    New_Position=Head->Trigger_Area.Start_Offset+Head->Trigger_Area.Length;
    if (New_Position%(long)Head->Multiplexer!=0) 
        New_Offset=((New_Position/(long)Head->Multiplexer)+1)*((long)Head->Multiplexer);
    else 
        New_Offset=New_Position;
    Head->Data_Start_Offset=New_Offset;
        
    fwrite(Head,1,sizeof(Micromed_Header_Type_4),d);                            //  write Head              
        
    fseek(d,Head->Code_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Code,1,(unsigned short)Head->Code_Area.Length,d);                    //  Code

    fseek(d,Head->Electrode_Area.Start_Offset,SEEK_SET);                        //  writes 
    fwrite(Electrode,1,Head->Electrode_Area.Length,d);                          //  Electrode

    fseek(d,Head->Note_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Note,1,Head->Note_Area.Length,d);                                    //  Note

    fseek(d,Head->Flag_Area.Start_Offset,SEEK_SET);                             //  writes 
    fwrite(Flag,1,Head->Flag_Area.Length,d);                                    //  Flag

    fseek(d,Head->Segment_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Segment,1,Head->Segment_Area.Length,d);                              //  Segment

    fseek(d,Head->B_Impedance_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(B_Impedance,1,Head->B_Impedance_Area.Length,d);                      //  B_Impedance

    fseek(d,Head->E_Impedance_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(E_Impedance,1,Head->E_Impedance_Area.Length,d);                      //  E_Impedance

    fseek(d,Head->Montage_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Montage,1,Head->Montage_Area.Length,d);                              //  Montages

    fseek(d,Head->Compression_Area.Start_Offset,SEEK_SET);                      //  writes 
    fwrite(Compression,1,Head->Compression_Area.Length,d);                      //  Compression

    fseek(d,Head->Average_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Average,1,Head->Average_Area.Length,d);                              //  Average

    fseek(d,Head->History_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(History_Sample,1,MAX_SAMPLE*sizeof(Micromed_New_Sample),d);          //  History_Sample
    fwrite(History,1,(unsigned long)MAX_HISTORY*(unsigned long)sizeof(Micromed_New_Montage),d);
    
    fseek(d,Head->Digital_Video_Area.Start_Offset,SEEK_SET);                    //  writes 
    fwrite(Digital_Video,1,Head->Digital_Video_Area.Length,d);                  //  Digital_Video

    fseek(d,Head->EventA_Area.Start_Offset,SEEK_SET);                           //  writes 
    fwrite(EventA,1,Head->EventA_Area.Length,d);                                //  EventA

    fseek(d,Head->EventB_Area.Start_Offset,SEEK_SET);                           //  writes 
    fwrite(EventB,1,Head->EventB_Area.Length,d);                                //  EventB

    fseek(d,Head->Trigger_Area.Start_Offset,SEEK_SET);                          //  writes 
    fwrite(Trigger,1,Head->Trigger_Area.Length,d);                              //  Trigger

    for (i=0; i<(32*256); i++) buffer[i]=0;                                     //
    New_Offset-=New_Position;                                                   //
    if (New_Offset>0)                                                           //  writes empty
        fwrite(buffer,1,(unsigned int)New_Offset,d);                            //  space
    fseek(d,Head->Data_Start_Offset,SEEK_SET);                                  //

    return(d);
}


/************************************************************************/
/**************** READ A GENERIC MICROMED EEG FILE HEADER ***************/
/************************************************************************/

FILE* Read_EEG_Header(const char*       filename,
            const char*                 Read_Option,
            Micromed_Header_Type_4*     Head, 
            Micromed_New_Code           Code[], 
            Micromed_New_Electrode      Electrode[], 
            Micromed_New_Annotation     Note[], 
            Micromed_New_Marker_Pair    Flag[], 
            Micromed_New_Segment        Segment[], 
            Micromed_New_Impedance      B_Impedance[], 
            Micromed_New_Impedance      E_Impedance[], 
            Micromed_New_Montage        Montage[], 
            Micromed_New_Compression*   Compression,
            Micromed_New_Average*       Average,
            Micromed_New_Sample         History_Sample[], 
            Micromed_New_Montage        History[],
            Micromed_New_Sample         Digital_Video[],
            Micromed_New_Event*         EventA, 
            Micromed_New_Event*         EventB,
            Micromed_New_Trigger        Trigger[])

{
    FILE* f;
    unsigned char discriminant;
    Micromed_Header_Type_1 Head_Old;

    if ((f=fopen(filename,Read_Option)) == NULL)
    {
      return(f);
    }

    fseek(f,175,SEEK_SET);                      //  reads byte 175
    fread(&discriminant,1,1,f);                 //  which contains Header Type

    switch (discriminant)
    {
        case 0:
            Read_Header_0(f,Head,&Head_Old,Code,Electrode,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,Compression,Average,History_Sample,History,Digital_Video,EventA,EventB,Trigger);
        break;

        case 1:
            Read_Header_1(f,Head,&Head_Old,Code,Electrode,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,Compression,Average,History_Sample,History,Digital_Video,EventA,EventB,Trigger);
        break;

        case 2:
            Read_Header_2(f,Head,Code,Electrode,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,Compression,Average,History_Sample,History,Digital_Video,EventA,EventB,Trigger);
        break;
     
        case 3:
            Read_Header_3(f,Head,Code,Electrode,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,Compression,Average,History_Sample,History,Digital_Video,EventA,EventB,Trigger);
        break;

        case 4:
            Read_Header_4(f,Head,Code,Electrode,Note,Flag,Segment,B_Impedance,E_Impedance,Montage,Compression,Average,History_Sample,History,Digital_Video,EventA,EventB,Trigger);
        break;
    }

    return(f);
}

void   Direct_Read_Header4(FILE* fp, Micromed_Header_Type_4*    Head)
{
    fread( Head->Title,        32,  1,  fp);
    fread( Head->Laboratory,   32,  1,  fp);
    Direct_Read_New_Patient_Data(fp, &Head->Patient_Data);
    Direct_Read_New_Date        (fp, &Head->Date);
    Direct_Read_New_Time        (fp, &Head->Time);
    fread(&Head->Acquisition_Unit, 2,  1,  fp);
    fread(&Head->Filetype,         2,  1,  fp);
    fread(&Head->Data_Start_Offset,4,  1,  fp);
    fread(&Head->Num_Chan,         2,  1,  fp);
    fread(&Head->Multiplexer,      2,  1,  fp);
    fread(&Head->Rate_Min,         2,  1,  fp);
    fread(&Head->Bytes,            2,  1,  fp);
    fread(&Head->Compression,      2,  1,  fp);
    fread(&Head->Montages,         2,  1,  fp);
    fread(&Head->Dvideo_Begin,     4,  1,  fp);
    fread(&Head->MPEG_Difference,  2,  1,  fp);
    fread( Head->Reserved_1,      15,  1,  fp);
    fread(&Head->Header_Type,      1,  1,  fp);

    Direct_Read_New_Descriptor(fp, &Head->Code_Area);
    Direct_Read_New_Descriptor(fp, &Head->Electrode_Area);
    Direct_Read_New_Descriptor(fp, &Head->Note_Area);
    Direct_Read_New_Descriptor(fp, &Head->Flag_Area);
    Direct_Read_New_Descriptor(fp, &Head->Segment_Area);
    Direct_Read_New_Descriptor(fp, &Head->B_Impedance_Area);
    Direct_Read_New_Descriptor(fp, &Head->E_Impedance_Area);
    Direct_Read_New_Descriptor(fp, &Head->Montage_Area);
    Direct_Read_New_Descriptor(fp, &Head->Compression_Area);
    Direct_Read_New_Descriptor(fp, &Head->Average_Area);
    Direct_Read_New_Descriptor(fp, &Head->History_Area);
    Direct_Read_New_Descriptor(fp, &Head->Digital_Video_Area);
    Direct_Read_New_Descriptor(fp, &Head->EventA_Area);
    Direct_Read_New_Descriptor(fp, &Head->EventB_Area);
    Direct_Read_New_Descriptor(fp, &Head->Trigger_Area);

    fread(Head->Reserved_2,      224,  1,  fp);
}


void   Direct_Read_New_Patient_Data(FILE* fp, Micromed_New_Patient_Data* Patient_Data)
{
    fread( Patient_Data->Surname,     22,  1,  fp);
    fread( Patient_Data->Name,        20,  1,  fp);
    fread(&Patient_Data->Month,        1,  1,  fp);
    fread(&Patient_Data->Day,          1,  1,  fp);
    fread(&Patient_Data->Year,         1,  1,  fp);
    fread( Patient_Data->Reserved,    19,  1,  fp);
}

void   Direct_Read_New_Date(FILE* fp, Micromed_New_Date_Type*    Date)
{
    fread(&Date->Day,   1,  1,  fp);
    fread(&Date->Month, 1,  1,  fp);
    fread(&Date->Year,  1,  1,  fp);
}

void   Direct_Read_New_Time(FILE* fp, Micromed_New_Time_Type*    Time)
{
    fread(&Time->Hour, 1,  1,  fp);
    fread(&Time->Min,  1,  1,  fp);
    fread(&Time->Sec,  1,  1,  fp);
}



void   Direct_Read_New_Descriptor(FILE* fp, Micromed_New_Descriptor* Area)
{
    fread( Area->Name,          8,  1,  fp);
    fread(&Area->Start_Offset,  4,  1,  fp);
    fread(&Area->Length,        4,  1,  fp);
}

void   Direct_Read_New_Electrode   (FILE* fp, Micromed_New_Electrode*    Elec, int Nelec)
{
    int i=0;
    for(i=0; i<Nelec; i++)
    {
        fread(&Elec[i].Status,                    1,  1,  fp);
        fread(&Elec[i].Type,                      1,  1,  fp);
        fread( Elec[i].Positive_Input_Label,      6,  1,  fp);
        fread( Elec[i].Negative_Input_Label,      6,  1,  fp);
        fread(&Elec[i].Logic_Minimum,             4,  1,  fp);
        fread(&Elec[i].Logic_Maximum,             4,  1,  fp);
        fread(&Elec[i].Logic_Ground,              4,  1,  fp);
        fread(&Elec[i].Physic_Minimum,            4,  1,  fp);
        fread(&Elec[i].Physic_Maximum,            4,  1,  fp);

        fread(&Elec[i].Measurement_Unit,          2,  1,  fp);
        fread(&Elec[i].Prefiltering_HiPass_Limit, 2,  1,  fp);
        fread(&Elec[i].Prefiltering_HiPass_Type,  2,  1,  fp);
        fread(&Elec[i].Prefiltering_LowPass_Limit,2,  1,  fp);
        fread(&Elec[i].Prefiltering_LowPass_Type, 2,  1,  fp);
        fread(&Elec[i].Rate_Coefficient,          2,  1,  fp);
        fread(&Elec[i].Position,                  2,  1,  fp);

        fread(&Elec[i].Latitude,                  4,  1,  fp);
        fread(&Elec[i].Longitude,                 4,  1,  fp);
        fread(&Elec[i].Maps,                      1,  1,  fp);
        fread(&Elec[i].Average_Ref,               1,  1,  fp);

        fread( Elec[i].Description,              32,  1,  fp);
        fread( Elec[i].Reserved_2,               38,  1,  fp);
    }
}

void   Direct_Read_Electrode3   (FILE* fp, Micromed_Electrode_3*    Elec, int Nelec)
{
    int i=0;
    for(i=0; i<Nelec; i++)
    {
        fread(&Elec[i].Type,                      2,  1,  fp);
        fread( Elec[i].Positive_Input_Label,      6,  1,  fp);
        fread( Elec[i].Negative_Input_Label,      6,  1,  fp);
        fread(&Elec[i].Logic_Minimum,             2,  1,  fp);
        fread(&Elec[i].Logic_Maximum,             2,  1,  fp);
        fread(&Elec[i].Logic_Ground,              2,  1,  fp);
        fread(&Elec[i].Physic_Minimum,            4,  1,  fp);
        fread(&Elec[i].Physic_Maximum,            4,  1,  fp);

        fread(&Elec[i].Measurement_Unit,          2,  1,  fp);
        fread(&Elec[i].Prefiltering_HiPass_Limit, 2,  1,  fp);
        fread(&Elec[i].Prefiltering_HiPass_Type,  2,  1,  fp);
        fread(&Elec[i].Prefiltering_LowPass_Limit,2,  1,  fp);
        fread(&Elec[i].Prefiltering_LowPass_Type, 2,  1,  fp);
        fread(&Elec[i].Rate_Coefficient,          2,  1,  fp);
        fread(&Elec[i].Position,                  2,  1,  fp);

        fread( Elec[i].Reserved_1,               12,  1,  fp);
        fread(&Elec[i].Latitude,                  4,  1,  fp);
        fread(&Elec[i].Longitude,                 4,  1,  fp);
        fread(&Elec[i].Maps,                      1,  1,  fp);
        fread(&Elec[i].Average_Ref,               1,  1,  fp);

        fread( Elec[i].Description,              32,  1,  fp);
        fread( Elec[i].Reserved_2,               32,  1,  fp);
    }
}
