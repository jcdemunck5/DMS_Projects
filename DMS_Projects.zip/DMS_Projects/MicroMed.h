#ifndef _MICROMEDEEGSTRUCTURE_INCLUDED
#define _MICROMEDEEGSTRUCTURE_INCLUDED

/********************************************************************
****    This software is freely distributed by Micromed s.r.l.   ****
****   to help the user have an easy interpretation of Micromed  ****
**** EEG data. Micromed cannot be held responsible for any error ****
****                  contained in this software.                ****
*********************************************************************
**** Version: 4.02                                               ****
**** Author: Cristiano Rizzo - Project Development Manager       **** 
**** Last modification: 18/06/2003                               ****
*********************************************************************
****     Any correction, appreciation or comment is welcome!     ****
****     For further informations or in case of need contact:    ****
****                                                             ****
****         Cristiano Rizzo - Micromed s.r.l.                   ****
****         I-31021 Mogliano Veneto (Treviso) - ITALY           ****
****         tel. +39.041.5937000 (district of Venice)           ****
****         fax. +39.041.5937011                                ****
****         e-mail: cristiano.rizzo@micromed-it.com             ****
********************************************************************/

#include <stdio.h>

/*******************************************************************
******************** CONSTANTS FOR ARRAY DIMENSION *****************
*******************************************************************/

#define MAX_LAB_3           256

#define LEN_MONTAGE_3       3072

#define MAX_NOTE_2          100
#define LEN_MONTAGE_2       1600


#define MAX_CAN             256     //  Maximum Number of Channels to be Acquired
#define MAX_DERIV           128     //  Maximum Number of Derivations to be Displayed
#define MAX_NOTE            200
#define MAX_SAMPLE          128
#define MAX_HISTORY         30
#define MAX_LAB             640     //  Maximum Number of Labels
#define MAX_MONT            30
#define MAX_FLAG            100
#define MAX_SEGM            100
#define LEN_MONTAGE         4096
#define MAX_SEC             40
#define MAX_EVENT           100
#define MAX_VIDEO_FILE      1024
#define MAX_TRIGGER         8192


typedef struct
{
    unsigned char       NonInv;     //  This is for montages of Type 3
    unsigned char       Inv;
}
Micromed_Double_Byte;


typedef struct
{
    unsigned short int  NonInv;     //  This is for montages of Type 4
    unsigned short int  Inv;
}
Micromed_Double_Word;

/*******************************************************************
******* STRUCTURE NECESSARY FOR COMPATIBILITY WITH TYPE 0,1,2 ******
*******************************************************************/

typedef struct
{
    char            Surname[22];
    char            Name[20];
    unsigned char   Month;
    unsigned char   Day;
    unsigned char   Year;
    unsigned char   Reserved[3];
}
Micromed_PatientData;



typedef struct
{
    unsigned char   Month;
    unsigned char   Day;
    unsigned char   Year;
}
Micromed_Date_Type;



typedef struct
{
    char                Name[5];
    unsigned char       Reserved;
    unsigned short int  Signal_Max;
}
Micromed_Electrode;



typedef struct
{
    unsigned long int   Time;           
    char                Comment[40];    
}
Micromed_Old_Annotation;



typedef struct
{
    unsigned long int   Time;        
    char                Comment[20]; 

}
Micromed_Annotation;






/*******************************************************************
******************* STRUCTURE NECESSARY FOR TYPE 3 *****************
*******************************************************************/

typedef struct
{
    char            Surname[22];
    char            Name[20];
    unsigned char   Month;
    unsigned char   Day;
    unsigned char   Year;
    unsigned char   Reserved[19];
}
Micromed_New_Patient_Data;



typedef struct 
{
    unsigned char   Day;
    unsigned char   Month;
    unsigned char   Year;
}
Micromed_New_Date_Type;



typedef struct
{
    unsigned char   Hour;
    unsigned char   Min;
    unsigned char   Sec;
}
Micromed_New_Time_Type;



#define BQ124_INT       0
#define MS40            1
#define BQ132S_INT      2
#define BQ124_BQCARD    6
#define SAM32_BQCARD    7
#define SAM25_BQCARD    8
#define BQ132SR_INT     9
#define SAM32R_BQCARD   10
#define SAM25R_BQCARD   11
#define SAM32_INT       12
#define SAM25_INT       13
#define SAM32R_INT      14
#define SAM25R_INT      15



#define C128    40
#define C84P    42
#define C84     44
#define C96     46
#define C63P    48
#define C63     50
#define C64     52
#define C42P    54
#define C42     56
#define C32     58
#define C21P    60
#define C21     62
#define C19P    64
#define C19     66
#define C12     68
#define C8P     70
#define C8      72
#define CFRE    74



typedef struct
{
    char                Name[8];
    unsigned long int   Start_Offset;
    unsigned long int   Length;
}
Micromed_New_Descriptor;



typedef unsigned char Micromed_Code_3;

typedef unsigned short int Micromed_New_Code;


typedef struct
{
    unsigned short int  Type;
    char                Positive_Input_Label[6];
    char                Negative_Input_Label[6];         
    unsigned short int  Logic_Minimum;
    unsigned short int  Logic_Maximum;
    unsigned short int  Logic_Ground;                    
    long int            Physic_Minimum;
    long int            Physic_Maximum;                  
    unsigned short int  Measurement_Unit;
    unsigned short int  Prefiltering_HiPass_Limit;
    unsigned short int  Prefiltering_HiPass_Type;
    unsigned short int  Prefiltering_LowPass_Limit;
    unsigned short int  Prefiltering_LowPass_Type;
    unsigned short int  Rate_Coefficient;
    unsigned short int  Position;                        
    unsigned char       Reserved_1[12];                  
    float               Latitude;
    float               Longitude;                       
    unsigned char       Maps;
    unsigned char       Average_Ref;                     
    char                Description[32];
    unsigned char       Reserved_2[32];                  
}
Micromed_Electrode_3;



typedef struct
{
    unsigned char       Status;
    unsigned char       Type;
    char                Positive_Input_Label[6];
    char                Negative_Input_Label[6];
    unsigned long int   Logic_Minimum;
    unsigned long int   Logic_Maximum;
    unsigned long int   Logic_Ground;
    long int            Physic_Minimum;
    long int            Physic_Maximum;
    unsigned short int  Measurement_Unit;
    unsigned short int  Prefiltering_HiPass_Limit;
    unsigned short int  Prefiltering_HiPass_Type;
    unsigned short int  Prefiltering_LowPass_Limit;
    unsigned short int  Prefiltering_LowPass_Type;
    unsigned short int  Rate_Coefficient;
    unsigned short int  Position;
    float               Latitude;
    float               Longitude;
    unsigned char       Maps;
    unsigned char       Average_Ref;
    char                Description[32];
    unsigned char       Reserved_2[38];
}
Micromed_New_Electrode;



typedef struct
{
    unsigned long int   Sample;         
    char                Comment[40];    
}
Micromed_New_Annotation;



typedef struct
{
    unsigned long int   Begin;
    unsigned long int   End;
}
Micromed_New_Marker_Pair;



typedef struct
{
    unsigned long int   Time;            
    unsigned long int   Sample;          
}
Micromed_New_Segment;




typedef struct
{
    unsigned char   Positive;
    unsigned char   Negative;
}
Micromed_New_Impedance;




typedef struct
{
    unsigned short int      Lines;
    unsigned short int      Sectors;
    unsigned short int      Base_Time;
    unsigned short int      Common_Gain;
    unsigned short int      Notch;

    unsigned char           free[502];

    unsigned char           Selection[MAX_DERIV];
    char                    Description[64];
    Micromed_Double_Byte    Derivation[MAX_DERIV];
    unsigned short int      L_Filter[MAX_DERIV];
    unsigned short int      H_Filter[MAX_DERIV];
    unsigned char           Reference[MAX_DERIV];
}
Micromed_Montage_2;




typedef struct
{
    unsigned short int      Lines;
    unsigned short int      Sectors;
    unsigned short int      Base_Time;
    unsigned short int      Notch;
    unsigned char           Colour[MAX_DERIV];
    unsigned char           Selection[MAX_DERIV];
    char                    Description[64];
    Micromed_Double_Byte    Inputs[MAX_DERIV];
    unsigned long int       HiPass_Filter[MAX_DERIV];
    unsigned long int       LowPass_Filter[MAX_DERIV];
    unsigned long int       Reference[MAX_DERIV];
    unsigned char           ViewReference;
    unsigned char           Free[951];
}
Micromed_Montage_3; 




typedef struct
{
    unsigned short int      Lines;
    unsigned short int      Sectors;
    unsigned short int      Base_Time;
    unsigned char           Notch;
    unsigned char           ViewReference;
    unsigned char           Colour[MAX_DERIV];
    unsigned char           Selection[MAX_DERIV];
    char                    Description[64];
    Micromed_Double_Word    Inputs[MAX_DERIV];
    unsigned long int       HiPass_Filter[MAX_DERIV];
    unsigned long int       LowPass_Filter[MAX_DERIV];
    unsigned long int       Reference[MAX_DERIV];

    unsigned char           Free[1720];
}
Micromed_New_Montage;




typedef struct
{
    unsigned char   Undefined[10];  
}
Micromed_New_Compression;



#define AVERAGE_FREE    82
typedef struct
{
    unsigned long int       Mean_Trace;                 //  Number of Averaged Traces (Triggers)
    unsigned long int       Mean_File;                  //  Number of Averaged Files
    unsigned long int       Mean_Prestim;               //  Pre Stim (msec.)
    unsigned long int       Mean_PostStim;              //  Post Stim (msec.)
    unsigned long int       Mean_Type;                  //  0 = Not Weighted, 1 = Weighted
    unsigned short int      Correct_Answers;            //  Number of Sweep with Correct Answers
    unsigned short int      Wrong_Answers;              //  Number of Sweep with Wrong Answers
    unsigned short int      No_Answers;                 //  Number of Sweep with No Answer
    float                   Corr_Mean_Time;             //
    float                   Corr_SD;                    //  
    float                   Corr_Max_Time;              //
    float                   Corr_Min_Time;              //
    float                   Corr_Ratio;                 //
    unsigned char           Free[AVERAGE_FREE];         //
}
Micromed_New_Average;



typedef struct
{
    unsigned char   Undefined[10];          
}
Micromed_New_Free;



typedef unsigned long int Micromed_New_Sample;



typedef struct
{
    char                        Description[64];
    Micromed_New_Marker_Pair    Selection[MAX_EVENT];
}
Micromed_New_Event;


typedef struct
{
    long int                    Sample;
    short int                   Type;
}
Micromed_New_Trigger;


/*******************************************************************
*************** STRUCTURE OF TYPE "0" and "1" FILES ****************
*******************************************************************/

typedef struct
{
    unsigned short int          reserved1[4];
    unsigned short int          Rate_Min;
    unsigned short int          reserved2;
    unsigned short int          Signal;
    unsigned short int          Electrode_Code[32];
    unsigned short int          Filter[32];
    unsigned char               reserved3[32];
    unsigned char               Acquisition_Unit;
    unsigned char               Header_Type;
    unsigned short int          Filetype;
    unsigned short int          LowFilterMultiplier;
    unsigned short int          HighFilterMultiplier;
    unsigned short int          Data_Start_Offset;
    unsigned short int          Num_Chan;
    Micromed_Date_Type          Date;
    Micromed_New_Time_Type      Time;
    Micromed_PatientData        Patient_Data;
    Micromed_New_Marker_Pair    Flag[15];
    Micromed_New_Segment        Segment[15];
    Micromed_Annotation         Note[80];

    unsigned char               free_at_all[2600];
    unsigned char               reserved4[40];
    unsigned short int          Fre_Punt;
    unsigned short int          Fre_Len;
    unsigned short int          Evo_Punt;
    unsigned short int          Evo_Len;
    unsigned short int          Com_Punt;
    unsigned short int          Com_Len;
    unsigned short int          FFT_Punt;
    unsigned short int          FFT_Len;
    Micromed_Electrode          Labels[128];
    unsigned short int          Impedance[32];
    unsigned char               Max_Length[32];
}
Micromed_Header_Type_1;


/*******************************************************************
******************* STRUCTURE OF TYPE "2" FILES ********************
*******************************************************************/

typedef struct
{
    char                        Title[32];
    char                        Laboratory[32];
    Micromed_New_Patient_Data   Patient_Data;
    Micromed_New_Date_Type      Date;
    Micromed_New_Time_Type      Time;
    unsigned short int          Acquisition_Unit;
    unsigned short int          Filetype;
    unsigned long int           Data_Start_Offset;
    unsigned short int          Num_Chan;
    unsigned short int          Multiplexer;
    unsigned short int          Rate_Min;
    unsigned short int          Bytes;
    unsigned short int          Compression;
    unsigned short int          Montages;
    unsigned char               Reserved_1[21];

    unsigned char               Header_Type;

    Micromed_New_Descriptor     Code_Area;
    Micromed_New_Descriptor     Electrode_Area;
    Micromed_New_Descriptor     Note_Area;
    Micromed_New_Descriptor     Flag_Area;
    Micromed_New_Descriptor     Segment_Area;
    Micromed_New_Descriptor     B_Impedance_Area;
    Micromed_New_Descriptor     E_Impedance_Area;
    Micromed_New_Descriptor     Montage_Area;
    Micromed_New_Descriptor     Compression_Area;

    unsigned char               Reserved_2[320];
}
Micromed_Header_Type_2;


/*******************************************************************
******************* STRUCTURE OF TYPE "3" FILES ********************
*******************************************************************/

typedef struct
{
    char                        Title[32];
    char                        Laboratory[32];
    Micromed_New_Patient_Data   Patient_Data;
    Micromed_New_Date_Type      Date;
    Micromed_New_Time_Type      Time;
    unsigned short int          Acquisition_Unit;
    unsigned short int          Filetype;
    unsigned long int           Data_Start_Offset;
    unsigned short int          Num_Chan;
    unsigned short int          Multiplexer;
    unsigned short int          Rate_Min;
    unsigned short int          Bytes;
    unsigned short int          Compression;
    unsigned short int          Montages;
    unsigned long int           Dvideo_Begin;
    unsigned char               Reserved_1[17];

    unsigned char               Header_Type;

    Micromed_New_Descriptor     Code_Area;
    Micromed_New_Descriptor     Electrode_Area;
    Micromed_New_Descriptor     Note_Area;
    Micromed_New_Descriptor     Flag_Area;
    Micromed_New_Descriptor     Segment_Area;
    Micromed_New_Descriptor     B_Impedance_Area;
    Micromed_New_Descriptor     E_Impedance_Area;
    Micromed_New_Descriptor     Montage_Area;
    Micromed_New_Descriptor     Compression_Area;
    Micromed_New_Descriptor     Average_Area;           
    Micromed_New_Descriptor     History_Area;
    Micromed_New_Descriptor     Reserved2;
    Micromed_New_Descriptor     EventA_Area;
    Micromed_New_Descriptor     EventB_Area;

    unsigned char               Reserved3[240];
}
Micromed_Header_Type_3;


/*******************************************************************
******************* STRUCTURE OF TYPE "4" FILES ********************
*******************************************************************/

typedef struct
{
    char                        Title[32];
    char                        Laboratory[32];
    Micromed_New_Patient_Data   Patient_Data;
    Micromed_New_Date_Type      Date;
    Micromed_New_Time_Type      Time;
    unsigned short int          Acquisition_Unit;
    unsigned short int          Filetype;
    unsigned long int           Data_Start_Offset;
    unsigned short int          Num_Chan;
    unsigned short int          Multiplexer;
    unsigned short int          Rate_Min;
    unsigned short int          Bytes;
    unsigned short int          Compression;
    unsigned short int          Montages;
    unsigned long int           Dvideo_Begin;
    unsigned short int          MPEG_Difference;
    unsigned char               Reserved_1[15];

    unsigned char               Header_Type;

    Micromed_New_Descriptor     Code_Area;
    Micromed_New_Descriptor     Electrode_Area;
    Micromed_New_Descriptor     Note_Area;
    Micromed_New_Descriptor     Flag_Area;
    Micromed_New_Descriptor     Segment_Area;
    Micromed_New_Descriptor     B_Impedance_Area;
    Micromed_New_Descriptor     E_Impedance_Area;
    Micromed_New_Descriptor     Montage_Area;
    Micromed_New_Descriptor     Compression_Area;
    Micromed_New_Descriptor     Average_Area;           
    Micromed_New_Descriptor     History_Area;
    Micromed_New_Descriptor     Digital_Video_Area;
    Micromed_New_Descriptor     EventA_Area;
    Micromed_New_Descriptor     EventB_Area;
    Micromed_New_Descriptor     Trigger_Area;

    unsigned char               Reserved_2[224];
}
Micromed_Header_Type_4;



/*******************************************************************
*********** STRUCTURE NECESSARY FOR OTHER MICROMED FILES ***********
*******************************************************************/

typedef struct
{
    unsigned short int      FileType;
    unsigned char           Header_Type;
    unsigned char           Bytes;
    unsigned char           Number_TRC;
    unsigned char           free1;
    unsigned short int      Rate_Min;
    unsigned short int      Signal;
    Micromed_New_Date_Type  Date;
    Micromed_New_Time_Type  Time;
    unsigned char           Segments;
    unsigned long int       Duration;
    unsigned short int      Analyse;
    unsigned short int      Optical_Disk;
}
Micromed_Pazrec;

#ifdef __cplusplus
extern "C" {
#endif
    void Set_Descriptors(Micromed_Header_Type_4* Head);
    int  defined(char* Match, char* Found);
    void Read_Header_0(FILE* f,     
                Micromed_Header_Type_4*     Head,   
                Micromed_Header_Type_1*     Head_Old,
                Micromed_New_Code           Code[],     
                Micromed_New_Electrode      Electrode[],    
                Micromed_New_Annotation     Note[],     
                Micromed_New_Marker_Pair    Flag[],     
                Micromed_New_Segment        Segment[],      
                Micromed_New_Impedance      B_Impedance[],  
                Micromed_New_Impedance      E_Impedance[],  
                Micromed_New_Montage        Montage[],      
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    void Read_Header_1(FILE* f,
                Micromed_Header_Type_4*     Head, 
                Micromed_Header_Type_1*     Head_Old,
                Micromed_New_Code           Code[], 
                Micromed_New_Electrode      Electrode[], 
                Micromed_New_Annotation     Note[], 
                Micromed_New_Marker_Pair    Flag[], 
                Micromed_New_Segment        Segment[], 
                Micromed_New_Impedance      B_Impedance[], 
                Micromed_New_Impedance      E_Impedance[], 
                Micromed_New_Montage        Montage[], 
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    void Read_Header_2(FILE* f,
                Micromed_Header_Type_4*     Head, 
                Micromed_New_Code           Code[],
                Micromed_New_Electrode      Electrode[], 
                Micromed_New_Annotation     Note[], 
                Micromed_New_Marker_Pair    Flag[], 
                Micromed_New_Segment        Segment[], 
                Micromed_New_Impedance      B_Impedance[], 
                Micromed_New_Impedance      E_Impedance[], 
                Micromed_New_Montage        Montage[], 
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    void Read_Header_3(FILE* f,
                Micromed_Header_Type_4*     Head, 
                Micromed_New_Code           Code[], 
                Micromed_New_Electrode      Electrode[], 
                Micromed_New_Annotation     Note[], 
                Micromed_New_Marker_Pair    Flag[], 
                Micromed_New_Segment        Segment[], 
                Micromed_New_Impedance      B_Impedance[], 
                Micromed_New_Impedance      E_Impedance[], 
                Micromed_New_Montage        Montage[], 
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    void Read_Header_4(FILE* f,
                Micromed_Header_Type_4*     Head, 
                Micromed_New_Code           Code[], 
                Micromed_New_Electrode      Electrode[], 
                Micromed_New_Annotation     Note[], 
                Micromed_New_Marker_Pair    Flag[], 
                Micromed_New_Segment        Segment[], 
                Micromed_New_Impedance      B_Impedance[], 
                Micromed_New_Impedance      E_Impedance[], 
                Micromed_New_Montage        Montage[], 
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[],
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    void Update_EEG_Header(FILE*            d,
                Micromed_Header_Type_4*     Head,
                Micromed_New_Code           Code[],
                Micromed_New_Electrode      Electrode[],
                Micromed_New_Annotation     Note[],
                Micromed_New_Marker_Pair    Flag[],
                Micromed_New_Segment        Segment[],
                Micromed_New_Impedance      B_Impedance[],
                Micromed_New_Impedance      E_Impedance[],
                Micromed_New_Montage        Montage[],
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);
    FILE* Create_EEG_Header(char*           filename,
                Micromed_Header_Type_4*     Head,
                Micromed_New_Code           Code[],
                Micromed_New_Electrode      Electrode[],
                Micromed_New_Annotation     Note[],
                Micromed_New_Marker_Pair    Flag[],
                Micromed_New_Segment        Segment[],
                Micromed_New_Impedance      B_Impedance[],
                Micromed_New_Impedance      E_Impedance[],
                Micromed_New_Montage        Montage[],
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[], 
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);

    FILE* Read_EEG_Header(const char*       filename,
                const char*                 Read_Option,
                Micromed_Header_Type_4*     Head, 
                Micromed_New_Code           Code[], 
                Micromed_New_Electrode      Electrode[], 
                Micromed_New_Annotation     Note[], 
                Micromed_New_Marker_Pair    Flag[], 
                Micromed_New_Segment        Segment[], 
                Micromed_New_Impedance      B_Impedance[], 
                Micromed_New_Impedance      E_Impedance[], 
                Micromed_New_Montage        Montage[], 
                Micromed_New_Compression*   Compression,
                Micromed_New_Average*       Average,
                Micromed_New_Sample         History_Sample[], 
                Micromed_New_Montage        History[],
                Micromed_New_Sample         Digital_Video[],
                Micromed_New_Event*         EventA, 
                Micromed_New_Event*         EventB,
                Micromed_New_Trigger        Trigger[]);

    void   Direct_Read_Header4         (FILE* fp, Micromed_Header_Type_4*    Head);
    void   Direct_Read_New_Patient_Data(FILE* fp, Micromed_New_Patient_Data* Patient_Data);
    void   Direct_Read_New_Date        (FILE* fp, Micromed_New_Date_Type*    Date);
    void   Direct_Read_New_Time        (FILE* fp, Micromed_New_Time_Type*    Time);
    void   Direct_Read_New_Descriptor  (FILE* fp, Micromed_New_Descriptor*   Area);
    void   Direct_Read_New_Electrode   (FILE* fp, Micromed_New_Electrode*    Elec, int Nelec);
    void   Direct_Read_Electrode3      (FILE* fp, Micromed_Electrode_3*      Elec, int Nelec);

#ifdef __cplusplus
} // extern "C" {
#endif

#endif// _MICROMEDEEGSTRUCTURE_INCLUDED

