/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL                                                                   */
/*     Module for minimizing a cost function, C++ version.                       */
/*                                                                               */
/*     USAGE                                                                     */
/*     The function minimization methods, implemented here can be used by using  */
/*     the Uminimize-object as a base class. The derived object (see e.g.        */
/*     UFitGrid or ULocMovDip) must contain a function with the following name   */
/*     and prototype:                                                            */
/*                                                                               */
/*     double ComputeCost(double *par, int iter, int *status=NULL,               */
/*                        double *grad=NULL, double *gauss=NULL);                */
/*                                                                               */
/*     This function, being a member of the derived class, has acces, to the     */
/*     data needed to minimize the function (e.g. measurements, model parameters,*/
/*     the number of parameters to be minimized, etc.) ComputeCost() must be     */
/*     devised such that it returns the cost, for a given parameter vector       */
/*     present in par[]. In case that methods with derivatives are used, like    */
/*     UCostMinimize::U_MARQUARDT and UCostMinimize::U_MARQUARDT2, ComputeCost() */
/*     should also compute the derivatives when the minimization algorithm       */
/*     required that. ComputeCost() is notified that these derivatives are       */
/*     required by calls with non-zero grad and gauss pointers. With methods     */
/*     that do not used derivatives, like UCostMinimize::U_SIMPLEX, ComputeCost()*/
/*     will always be called with grad==NULL and gauss==NULL.                    */
/*     The parameter iter gives the present iteration. This parameter is not     */
/*     very important to the implementation of ComputeCost(), it might be        */
/*     usefull to print it in the log-file, when UCostMinimize::AddToLog==true.  */
/*     The when status is non-zero, it must be set to 0 in the case that all     */
/*     parameters are in range (have a valid value), and to -1 when at least     */
/*     one of the parameters is out of range (e.g. when it represents a negative */
/*     conductivity). In this way, the minimization algorithm knows that it      */
/*     should take a smaller step size. When status==NULL, it must be ignored.   */
/*                                                                               */
/*     Important inhereted parameters:                                           */
/*        BOOL      Normalize;  // Apply some normalization in the definition of */
/*                                 the cost function                             */
/*        BOOL      Penalty;    // If true, add penalty parameters that are too  */
/*                                 close to their out of range value             */
/*     The proper treatment of these parameters is not at all crucial for the    */
/*     functioning of this module, it should only be dealt with to remain        */
/*     consistency with the output of UCostminimize::GetParameterString().       */
/*                                                                               */
/*     Once ComputeCost() is implemented with the above specications, the cost   */
/*     minimization procedure can be started with a call to Iterate().           */
/*                                                                               */
/*     NOTE(S)                                                                   */
/*     It might be neccesary to scale the minimization parameters, e.g, to       */
/*     minimize the logarithm of a parameter that must stay positive. One could  */
/*     also think of a special object that mananages the conversions that        */
/*     determines whether parameters are out-of-range.                           */
/*     If(UCostMinimize::AddToLog==true), a log-file is opened at the start of   */
/*     the itrations, and it is closed at the end. Each time before ComputeCost()*/
/*     is called, some default information is written to the log-file. The file  */
/*     remains open, and the file pointer (UMinimize::fpLog) is available in     */
/*     ComputeCost() to store more detailed information (e.g. unscaled           */
/*     parameters).                                                              */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    26-02-97   creation
  Jdm    20-02-98   changed name of parameters, changed use of off-set parameter
  Jdm    23-03-98   changes in UCostminize()
  JdM    08-10-98   separated include-files
  JdM    12-11-98   reduce some compiler warnings for UNIX CPP compiler
  JdM    14-12-98   Split Minimize.cpp into Minimize.cpp and CostMinimize.cpp, with one object each
  Jdm    04-01-99   Added more detailed comments.
  JdM    20-08-99   SIMPLEX, SIMPLEX_BOOST and POWELS: negative Tolerance implies relative tolerance
  JdM    31-08-99   Made all arrays static, eliminate the use of malloc() and free() 
  JdM    07-10-99   Added (virtual) functions to compute derivatives of Cost.
  JdM    08-10-99   Compute BestCost and BestPar[]
  JdM    11-10-99   Iterate(): return immediately when the maximum number of iterations is zero.
  JdM    19-01-00   The numerical version of the gradient should return MINUS the gradient.
  JdM    20-01-00   Added InitBestCost parameter.
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    30-11-00   Added GetBestCost()
  JdM    03-02-02   Added mechanism to stop iterationes externally
  JdM    25-11-02   Added NewBestCost() and GetBestPar(), to be used to show improvements
  GdV    13-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    04-09-08   Added InitBestCost(). Use UString for IterationString[]
  JdM    08-09-08   Added SetNParameters()
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    26-08-14   Changed SIGN() into FSIGN() to avoid conflicts with newly added SIGN() macro in BasicInclude.h
*/


#include <string.h>
#include <math.h>
#include <stdio.h>

#include "Minimize.h"
/* Inititalize static const parameters. */

/* Simplex constants:*/
#define ALPHA   1.0         // first extrapolation 
#define BETA    0.5         // contraction factor  
#define GAMMA   2.0         // extra extrapolation 
#define FTOL    0.0002      // relative tolerance  (should be no less than square root of machine precision)


/* Powell's constants:*/
#define GOLD   1.618034
#define GLIMIT 100.0
#define TINY   1.0e-10
#ifndef MAX
#  define MAX(i1,i2) i1>i2?i1:i2
#endif
#define FSIGN(a,b)            ((b) > 0.0 ? fabs(a) : -fabs(a))
#define SHFT(a,b,c,d)        (a)=(b);(b)=(c);(c)=(d);

#define ITMAX 100
#define CGOLD 0.3819660
#define ZEPS  1.0e-10

/* General constants:*/
#define SHRINK    .9        // shrink factor to be used when cost function yields input parameter error (should be <1.)
#define MAXSHRINK 25        // the maximum number of times a parameter is shrinked

Uminimize::Uminimize(const UCostminimize& cost)  :  UCostminimize(cost)
{
    IterationString = UString();
    fpLog           = NULL;

    StopIterations  = false;
    iterations      = 0; 
    CostError       = 0;
    ndim            = 0;
    BestCost        = 0.;
    BestInit        = true;
    for(int k=0; k<MAXPAR; k++) BestPar[k] = 0.;
}
Uminimize::~Uminimize()    
{
}

void Uminimize::SetCostMinimize(const UCostminimize& cost)
{
    UCostminimize::operator=(cost);
    InitBestCost();
}
ErrorType Uminimize::InitBestCost(void)
{
    BestCost    = -1.E200;
    BestInit    = true;
    for(int k=0; k<MAXPAR; k++) BestPar[k] = 0.;
    return U_OK;
}

ErrorType Uminimize::SetNParameters(int npar)
{
    if(npar<=0 || npar>=MAXPAR)
    {
        CI.AddToLog("ERROR: Uminimize::SetNParameters(). Argument out of range: npar = %d   .\n", npar);
        return U_ERROR;
    }
    ndim = npar;
    return U_OK;
}
double Uminimize::Cost(double *par, double *grad, double *gauss)
{
    if(AddToLog==true && fpLog)  fprintf(fpLog,"%s\n",(const char*)IterationString);

    double cost = ComputeCost(par, iterations++, &CostError, grad, gauss);
    ShowStatus(iterations, cost, par);
    if(BestInit==true || cost<BestCost)
    {
        BestInit = false;
        BestCost = cost;
        for(int k=0; k<ndim; k++) BestPar[k] = par[k];
        NewBestCost();
    }
    return cost;
} 

ErrorType Uminimize::Iterate(double *start, int nvar, double offset)
/*
    Start the minimization procedure, using the parameters set in the base
    class UCostMinize.
    start[] is an array of (scaled) starting values
    nvar    is the number of parameters to be minimized (should not be much 
            larger than say, 10)
    offset  (scaled) initial step size. If this parameter is omitted,
            the stepsize of the base class is used (UCostMinimize::StartOffset).
 */
{
    StopIterations = false;

    if(nvar<0 || nvar>MAXPAR)
    {
        CI.AddToLog("ERROR : Uminimize::Iterate() : too many parameters %d. The Maximum = %d\n",nvar,MAXPAR);
        return U_ERROR;
    }
    if(Maxiter<=0) return U_OK; // Nothing to do!

    int     i, j, status;
    
    if(offset!=0.) StartOffset = offset;

    double values[MAXPAR+1];
    double array[(MAXPAR+1)*MAXPAR];
        
    if(Optimization==UCostminimize::U_SIMPLEX ||
       Optimization==UCostminimize::U_SIMPLEX_BOOST ||
       Optimization==UCostminimize::U_POWELL)
    {

/* set starting values for the simplex */
        for(i=0; i<nvar+1; i++)  memcpy(array+i*MAXPAR, start, nvar*sizeof(double));

    }
    ndim         = nvar;
    iterations   = 0;
    BestInit     = true;

/* Open File, if required*/
    if(AddToLog==true)
    {
        fpLog = fopen(LogFile,"at");
        if(!fpLog) 
        {
            CI.AddToLog("ERROR : Uminimize::Iterate() : cannot open log-file %s \n",LogFile);
            return U_ERROR;
        }
    }
    else
        fpLog = NULL;

    switch(Optimization)
    {
    case UCostminimize::U_NOMETHOD:
        CI.AddToLog("ERROR : Uminimize::Iterate() : No minimization method set \n");
        return U_ERROR;
        
    case UCostminimize::U_SIMPLEX:
    case UCostminimize::U_SIMPLEX_BOOST:
        IterationString = UString("Simplex: Compute initial Simplex");
        values[0] = Cost(array);
        for (i=1; i<ndim+1; i++)  
        {
            double fac = 1.;
            do
            {
                array[i*MAXPAR+i-1]  = array[i-1] + fac*StartOffset;
                values[i]            = Cost(array+i*MAXPAR);
                fac                 *= SHRINK;
            }
            while(CostError);
        }
        status = Amoeba(array, values);

/* restart for boost,  by newly offsetting startpoint and calculating func values */           
        if(Optimization==UCostminimize::U_SIMPLEX_BOOST && !status)
        {
            IterationString = UString("Simplex BOOST: Compute initial Simplex");
            values[0] = Cost(array);
            for (i=1; i<ndim+1; i++)  
            {
                double fac = 1.;
                do
                {
                    array[i*MAXPAR+i-1]  = array[i-1] + fac*StartOffset;
                    values[i]            = Cost(array+i*MAXPAR);
                    fac                 *= SHRINK;
                }
                while(CostError);
            }
            status = Amoeba(array, values);
        }
        break;

    case UCostminimize::U_POWELL:
        for(i=0; i<ndim; i++)               /* preset unity directions */
            for(j=0; j<ndim; j++)
            {
                if (i==j) array[i*MAXPAR+j] = StartOffset;
                else      array[i*MAXPAR+j] = 0.0;
            }

        status = Powell(start,array);
        break;

#ifndef PUBLIC_SOURCES
    case UCostminimize::U_MARQUARDT:
        status = Marquardt(start);
        break;

    case UCostminimize::U_MARQUARDT2:
        status = Marquardt2(start);
        break;
#endif
    }

/* Return best point over all iterations*/
    for(int k=0; k<ndim; k++) start[k] = BestPar[k];

/* Close Log-file*/
    if(fpLog) fclose(fpLog);

    return U_OK;
}

int Uminimize::Amoeba(double *p, double *y)
/*
   amoeba: routine from ch 10.5 of numerical recipes.

            double p[ndim+1][ndim] = starting vectors for the simplex
            double y[ndim+1]       = function values at starting vectors
            int   ndim             = number of dimensions to optimize
            int   Maxiter          = maximum number of iterations
*/
{ 
    int     i,j,ilo,ihi,inhi,mpts=ndim+1;
    double  ytry,ysave,sum,rtol;
    double  alfa,beta,gamma;

    double ptry[MAXPAR];
    double psum[MAXPAR];

    for(j=0;j<ndim;j++) ptry[j]=psum[j]=0.;

/* set new vector psum to sum of parameters over simplex points */

    for(j=0; j<ndim; j++)
    {  
        for(i=0, sum=0.0; i<mpts; i++)  sum += p[i*MAXPAR+j];
        psum[j] = sum;
    }

/* find point with highest and lowest function value */
    while(StopIterations==false)
    { 
        ilo = 1;
        ihi = y[1]>y[2] ? (inhi=2,1) : (inhi=1,2);
        for(i=0; i<mpts; i++)
        { 
            if(y[i] < y[ilo]) ilo = i;
            if(y[i] > y[ihi])
            { 
                inhi = ihi;
                ihi  = i;
            }
            else 
                if (y[i] > y[inhi])
            
            if(i != ihi) inhi = i;
        }

/* check end criterium (mvh, avoid divide by zero) */
        if(Tolerance < 0)                     /* apply relative tolerance */
        {
            rtol = fabs(y[ihi]) + fabs(y[ilo]);
            if(rtol < FTOL) rtol = FTOL;
            rtol = 2.0 * fabs(y[ihi]-y[ilo])/rtol;
            if(rtol < -Tolerance) break;
        }
        else                                /* apply absolute tolerace */
            if(fabs(y[ihi] - y[ilo]) < Tolerance) break;

/* check number of iterations */
        if(iterations >= Maxiter)
        { 
            IterationString = UString("Amoeba: Too many iterations");
            return -1;
        }

/* try reflection from high point */
        IterationString = UString("Amoeba: Reflection from highest point");
        alfa = -ALPHA;
        do
        {
            ytry  = Amotry(p, y, psum, ihi, alfa, ptry);
            alfa *= SHRINK;
        }
        while(CostError);

/* if reflection works, try a larger step */
        if(ytry <= y[ilo]) 
        {
            IterationString = UString("Amoeba: Reflection OK, try larger step");
            gamma = GAMMA;
            do
            {
                ytry   = Amotry(p, y, psum, ihi, gamma, ptry);
                gamma *= SHRINK;
            }
            while(CostError);
        }
/* reflection did not work out, try contraction */
        else if (ytry >= y[inhi])
        { 
            ysave = y[ihi];
            IterationString = UString("Amoeba: Reflection Not OK, try contraction in 1D");
            beta  = BETA;
            do
            {
                ytry  = Amotry(p, y, psum, ihi, beta, ptry);
                beta *= SHRINK;
            }
            while(CostError);

            if(ytry >= ysave)
            { 
                for(i=0; i<mpts; i++)
                { 
                    if(i != ilo)
                    { 
                        for(j=0; j<ndim; j++)
                        { 
                            psum[j]       = 0.5 * (p[i*MAXPAR+j]+p[ilo*MAXPAR+j]);
                            p[i*MAXPAR+j] = psum[j];
                        }
                        IterationString = UString("Amoeba: Reflection Not OK, try contraction about the lowest point");
                        y[i] = Cost(psum);
                    }
                }
                for(j=0; j<ndim; j++)
                { 
                    for (i=0,sum=0.0; i<mpts; i++) sum += p[i*MAXPAR+j]; 
                    psum[j] = sum;
                }
            }
        }
    }
    return 0;
}

/* help routine for amoeba()
   args: p    = vectors of simplex
     y    = functions values at simplex points
     psum = sum of coordinates over simplex points
     ndim = number of dimensions
     ihi  = coordinate to work with
     fac  = factor to extrapolate, etc.
     ptry = workspace / vector to try
*/
double Uminimize::Amotry(double *p, double *y, double *psum, int ihi, double fac, double *ptry)
{ 
    int j;
    double fac1, fac2, ytry;

    fac1 = (1.0-fac) / ndim;
    fac2 = fac1 - fac;

    for(j=0; j<ndim; j++)
        ptry[j] = psum[j] * fac1 - p[ihi*MAXPAR+j] * fac2;

    ytry = Cost(ptry);

    if(ytry < y[ihi])
    { 
        y[ihi] = ytry;
        for(j=0; j<ndim; j++)
        { 
            psum[j]         += ptry[j] - p[ihi*MAXPAR+j];
            p[ihi*MAXPAR+j]  = ptry[j];
        }
    }
    return ytry;
}

/* Powell optimization code from numerical recipes ch10.5 */
int Uminimize::Powell(double *p, double *xi)
{ 
    int     i,ibig,j,flag;
    double  t,fptt,fp,del,fret;

    double  pt[MAXPAR];
    double ptt[MAXPAR];
    double xit[MAXPAR];

    for(j=0;j<ndim;j++) pt[j]=ptt[j]=xit[j]=0.;


    IterationString = UString("Powell: Cost at start");
    fret = Cost(p);
    for(j=0; j<ndim; j++) pt[j]=p[j];

    while(StopIterations==false)
    { 
        fp   = fret;
        ibig = 0;
        del  = 0.0;
        for(i=0; i<ndim; i++)
        { 
            for(j=0; j<ndim; j++) xit[j] = xi[i*MAXPAR+j];
            fptt = fret;
            Linmin(p, xit, &fret);
            if(fabs(fptt-fret) > del)
            { 
                del  = fabs(fptt-fret);
                ibig = i;
            }
        }

        if(Tolerance <= 0)
            flag = (2.0*fabs(fp-fret) <= -Tolerance*(fabs(fp)+fabs(fret)));
        else
            flag = (fabs(fp-fret) < Tolerance);

        if(flag) return 0;

        if(iterations >= Maxiter)
        { 
            IterationString = UString("Powell: Too many iterations");
            return -1;
        }
        
        double step = 1.;
        for(            ;step>0.;step-=.1)
        {
            for(j=0; j<ndim; j++) ptt[j] = p[j] + step*( p[j]-pt[j] );
            IterationString = UString(step, "Powell: Cost at test point, step = %f");
            fptt = Cost(ptt);
            if(!CostError) break;
        }
        for(j=0; j<ndim; j++)
        { 
            xit[j] = step*( p[j]-pt[j] );
            pt[j]  = p[j];
        }

        if(fptt < fp)
        { 
            t = 2.0*(fp-2.0*fret+fptt)*(fp-fret-del)*(fp-fret-del)-del*(fp-fptt)*(fp-fptt);
            if(t < 0.0)
            { 
                Linmin(p, xit, &fret);
                for(j=0; j<ndim; j++) xi[ibig*MAXPAR+j]=xit[j];
            }
        }
    }
    return 0;
}

void Uminimize::Linmin(double *p, double *xi, double *fret)
{ 
    int     j;
    double  xx,xmin,fx,fb,fa,bx,ax;

    for(j=0; j<ndim; j++)  { pcom[j]  = p[j]; xicom[j] = xi[j]; }

    ax = 0;
    if(Mnbrak(&ax, &xx, &bx, &fa, &fx, &fb))  
    {
        xmin = 0;
        if(fa<fx && fa<fb) xmin = ax;
        if(fx<fb && fx<fa) xmin = xx;
        if(fb<fa && fb<fx) xmin = bx;
    }
    else
        *fret = Brent(ax, xx, bx, FTOL, &xmin);
    
    for(j=0; j<ndim; j++)
    { 
        xi[j] *= xmin;
        p[j]  += xi[j];
    }
}

double Uminimize::f1dim(double x)
{ 
    int j;

    for (j=0; j<ndim; j++)
    xtcom[j] = pcom[j] + x*xicom[j];

    return Cost(xtcom);
}

int Uminimize::CostStep_c(double a, double b, double *c, double *step, double *Cost_c, int part, double *umin, double *umax)
/*
    Compute the largest number *step (smaller or equal to the initial value of *step)
    such that the function evaluation at *c = b + *step * (b-a) does not produce
    a domain error.

    Update the range (umin, umax) assuming *step>0;

    Return 
    0   iff no domain errors occur at the initial value of step.
    1   iff no domain errors occur after more than 1 and less than MAXSHRINK trials
   -1   iff domain errors occur on all MAXSHRINK trials
 */
{
    for(int n=0; n<MAXSHRINK; n++)
    {
        *c      = b + *step * (b-a);
        if(part==1)
            IterationString = UString(a, "MnBrak: Part I . Find c; Try a=%f,") + UString(b, "b=%f and ") + UString(*c,"c=%f");
        else
            IterationString = UString(a, "MnBrak: Part II. Find u; Try a=%f,") + UString(b, "b=%f and ") + UString(*c,"u=%f");
        
        *Cost_c = f1dim(*c);
        if(!CostError && !n) return 0;
        if(!CostError &&  n) 
        {
            if(umin && umax)
            {
                if(b>a) *umax = MIN(*c,*umax);
                else    *umin = MAX(*c,*umin);
            }
            return 1;
        }
        *step  *= SHRINK;
    }
    if(umin && umax)
    {
        if(b>a) *umax = MIN(b,*umax);
        else    *umin = MAX(b,*umin);
    }
    return -1;
}

int Uminimize::CostStep_b(double a, double *b, double *step, double *Cost_b, int part, double *umin, double *umax)
/*
    Compute the largest number *step (smaller or equal to the initial value of *step)
    such that the function evaluation at *b = a + *step  does not produce a domain error.

    Return 
    0   iff no domain errors occur at the initial value of step.
    1   iff no domain errors occur after more than 1 and less than MAXSHRINK trials
   -1   iff domain errors occur on all MAXSHRINK trials
 */
{
    for(int n=0; n<MAXSHRINK; n++)
    {
        *b = a + *step;
        if(part==1)
            IterationString = UString(*b, "MnBrak: Part I . Find b; Try b=%f");
        else
            IterationString = UString(*b, "MnBrak: Part II. Find u; Try u=%f");

        *Cost_b = f1dim(*b);
        if(!CostError && !n) return 0;
        if(!CostError &&  n) 
        {
            if(umin && umax)
            {
                if(*step>0) *umax = MIN(*b,*umax);
                else        *umin = MAX(*b,*umin);
            }
            return 1;
        }
        *step   *= SHRINK;
    }
   
    if(umin && umax)
    {
        if(*step>0) *umax = MIN(a,*umax);
        else        *umin = MAX(a,*umin);
    }   
    return -1;
}

int Uminimize::Mnbrak(double *ax, double *bx, double *cx, double *fa, double *fb, double *fc)
{ 
    double umin, umax, u, r, q, fu, step, dum;
/*
     Part I
     Determine *ax, *bx, *cx such that:
     1.) *ax > *bx > *cx   or *ax < *bx < *cx
     2.) (*ax-*bx) / (*ax-*cx) ~~ 1 / GOLD  (as good as possible)
     3.) *fa, *fb and *fc  produce no domain errors
     4.) *fb < *fa
     5.) Determine umin and umax such that no domain errors occur in f1dim(u) for u E (umin, umax)

     Part II
     Determine *cx such that
     1.) *cx = *bx + u * (*bx-*ax),   u>0 and u<ulim (larger steps will cause an error)
     2.) *fc does not produce a domain error
     3.) *fb < *fc

     return 0 iff both parts were succesful
     return 1 iff either part was not succesful

 */
/* Part I:                                                    */
/* It is assumed that the point ax does not cause an error. */
    umin  = -GLIMIT;       
    umax  =  GLIMIT;    
    IterationString = UString(*ax, "MnBrak: Part I. Compute f at a=%f");
    *fa   = f1dim(*ax);  

    *bx   = *ax+1.;
    IterationString = UString(*bx, "MnBrak: Part I. Compute f at b=%f");
    *fb   = f1dim(*bx);
    if(CostError)
    {
        *bx   = *ax+2.;
        IterationString = UString(*ax, "MnBrak: Part I. Compute f at a=%f");
        *fb   = f1dim(*bx);
        if(!CostError && *fb < *fa)
        {
            *ax = *bx;
            *fa = *fb;
        }

/* The default choice is bx=1 */
        step  = 1.0;   
        if(CostStep_b(*ax, bx, &step, fb, 1, &umin, &umax)<0)  
        {
            *bx    = *ax-1;
            IterationString = UString(*bx, "MnBrak: Part I. Compute f at b=%f");
            *fb   = f1dim(*bx);
            if(CostError)
            {
                *bx   = *ax-2.;
                *fb   = f1dim(*bx);
                if(!CostError && *fb < *fa)
                {
                    *ax = *bx;
                    *fa = *fb;
                }
            }
            step   = -1.0;         // try opposite direction
            if(CostStep_b(*ax, bx, &step, fb, 1, &umin, &umax)<0)  
            {
                *cx = *bx = *ax;
                *fc = *fb = *fa;
                IterationString = UString("MnBrak: Part I. ERROR No b was found");
                return 1;
            }
        }
    }
/* Now we have:
   umin <= *ax < *bx <= umax      or
   umin <= *bx < *ax <= umax     
*/
    if(*fb>*fa)
    {
        SHFT(dum, *ax, *bx, dum)
        SHFT(dum, *fa, *fb, dum)
    }
    if(*bx>*ax)
        step = MIN(GOLD, (umax-*bx)/(*bx-*ax) );
    else
        step = MIN(GOLD, (umin-*bx)/(*bx-*ax) );

    if(CostStep_c(*ax, *bx, cx, &step, fc, 1, &umin, &umax)<0) 
    {
        *cx  = *bx;                 // try a point in between a and b
        *bx  = *ax + (*cx-*ax)/GOLD;
        IterationString = UString(*bx, "MnBrak: Part I . Try intermediate point, b=%f");
        *fb  = f1dim(*bx); 
        if(CostError) 
        {
            *cx = *ax;
            *fc = *fa;
            IterationString = UString("MnBrak: Part I . ERROR No c was found at intermediate point");
            return 1;
        }
        
        if(*fb>*fa) // reverse direction
        {
            SHFT(dum, *ax, *bx, dum)
            SHFT(dum, *fa, *fb, dum)
            if(*bx>*ax)
                step = MIN(GOLD, (umax-*bx)/(*bx-*ax) );
            else
                step = MIN(GOLD, (umin-*bx)/(*bx-*ax) );
            
            if(CostStep_c(*ax, *bx, cx, &step, fc, 1, &umin, &umax)<0) 
            {
                *cx = *ax;
                *fc = *fa;
                IterationString = UString("MnBrak: Part I . ERROR No c was found in reverse direction");
                return 1;
            }                
        }        
    }

/* Part II: */
    while(*fb > *fc)
    { 
        if(umin>umax) return 1;

/* Find parabolic minimum. */
        r = (*bx-*ax)*(*fb-*fc);
        q = (*bx-*cx)*(*fb-*fa);
        u = (*bx)-((*bx-*cx)*q-(*bx-*ax)*r)/(2.0*FSIGN(MAX(fabs(q-r), TINY), q-r));
        
        if((*bx-u) * (u-*cx) > 0.0)
        { 
            IterationString = UString("MnBrak: Part II. Find Parabolic Minimum between bx and cx");
            fu = f1dim(u);
            if(fu < *fc)
            { 
                *ax = *bx;
                *bx = u;
                *fa = *fb;
                *fb = fu;
                return 0;
            } 
            else if(fu > *fb)
            { 
                *cx = u;
                *fc = fu;
                return 0;
            }

/* Parabolic minimum is of no use. Expand until no errors occur.*/
            if(*bx>*ax)
                step = MIN(GOLD*(1+GOLD), (umax - *bx)/(*bx-*ax) );
            else
                step = MIN(GOLD*(1+GOLD), (umin - *bx)/(*bx-*ax) );
            
            if(CostStep_c(*ax, *bx, &u, &step, &fu, 2, &umin, &umax)<0)  
            {
                IterationString = UString("MnBrak: Part II. ERROR No c was found on expansion of parabolic minimum");
                return 1;
            }                
        }

/* Parabolic minimum is located before umin or umax.*/        
        else if(  (*bx<*cx && *cx<u && u<umax) 
                ||(*bx>*cx && *cx>u && u>umin)  )
        { 
            step = u-*cx;
            if(CostStep_b(*cx, &u, &step, &fu, 2, &umin, &umax)<0)  
            {
                IterationString = UString("MnBrak: Part II. ERROR No c was found on expansion of u");
                return 1;
            }                

            if(fu < *fc)
            { 
                if(*ax<*bx)
                    step = MIN((umax-*bx)/(*bx-*ax), GOLD*(1+GOLD));
                else
                    step = MIN((umin-*bx)/(*bx-*ax), GOLD*(1+GOLD));

                SHFT(*bx, *cx, u, *bx + step*(*bx-*ax))
                SHFT(*fb, *fc, fu, f1dim(u))
            }
        } 
        else if(  (*bx<*cx && umax<u) 
                ||(*bx>*cx && umin>u) )
        { 
            if(*bx<*cx)
                step = umax-*cx;
            else
                step = umin-*cx;

            if(CostStep_b(*cx, &u, &step, &fu, 2, &umin, &umax)<0)  
            {
                IterationString = UString("MnBrak: Part II. ERROR No c was found on expansion of umin/umax");
                return 1;
            }                

        } 
        else
        { 
            if(*bx>*ax)
                step = MIN(GOLD*(1+GOLD), (umax-*bx)/(*bx-*ax) );
            else
                step = MIN(GOLD*(1+GOLD), (umin-*bx)/(*bx-*ax) );

            if(CostStep_c(*ax, *bx, &u, &step, &fu, 2, &umin, &umax)<0) 
            {
                IterationString = UString("MnBrak: Part II. ERROR No c was found on default expansion");
                return 1;
            }                

        }
        SHFT(*ax, *bx, *cx, u)
        SHFT(*fa, *fb, *fc, fu)
    }
    return 0;
}

double Uminimize::Brent(double ax, double bx, double cx, double tol, double *xmin)
{ 
    int     iter;
    double  a,b,d=0.0,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm;
    double  e=0.0;

    a=((ax < cx) ? ax : cx);
    b=((ax > cx) ? ax : cx);
    x=w=v=bx;
    fw=fv=fx=f1dim(x);
    for(iter=1;iter<=ITMAX;iter++)
    { 
        IterationString = UString(iter,"Brent: Iteration %5d");
        xm=0.5*(a+b);
        tol2=2.0*(tol1=tol*fabs(x)+ZEPS+fabs(Tolerance));
        if(fabs(x-xm) <= (tol2-0.5*(b-a)))
        { 
            *xmin=x;
            return fx;
        }

        if(fabs(e) > tol1)
        { 
            r=(x-w)*(fx-fv);
            q=(x-v)*(fx-fw);
            p=(x-v)*q-(x-w)*r;
            q=2.0*(q-r);
            if(q > 0.0) p = -p;
            q=fabs(q);
            etemp=e;
            e=d;
            if(fabs(p) >= fabs(0.5*q*etemp) || p <= q*(a-x) || p >= q*(b-x)) 
                d=CGOLD*(e=(x >= xm ? a-x : b-x));
            else
            { 
                d=p/q;
                u=x+d;
                if(u-a < tol2 || b-u < tol2)  d=FSIGN(tol1,xm-x);
            }
        } 
        else
        { 
            d=CGOLD*(e=(x >= xm ? a-x : b-x));
        }

        u =(fabs(d) >= tol1 ? x+d : x+FSIGN(tol1,d));
        fu=f1dim(u);
        
        if(fu <= fx)
        { 
            if(u >= x) a=x; else b=x;
            SHFT(v,w,x,u)
            SHFT(fv,fw,fx,fu)
        }
        else
        { 
            if(u < x) a=u; else b=u;
            if(fu <= fw || w == x)
            { 
                v =w;
                w =u;
                fv=fw;
                fw=fu;
            } 
            else if(fu <= fv || v == x || v == w)
            { 
                v =u;
                fv=fu;
            }
        }
    }
    IterationString = UString("Brent: Too many iterations");
    *xmin=x;
    return fx;
}

double Uminimize::ComputeCost(double *par, int iter, int *CostEr, double *grad)
/* 
    Numerical differentiation to compute the MINUS gradient grad[] for the case that the  
    analytical derivative is not defined in derived class.
*/
{
    if(grad==NULL) return ComputeCost(par, iter, CostEr);

    if(CostEr) *CostEr = 0;
    double        cost = Cost(par);


    for(int j=0; j<ndim; j++)
    {
        par[j] +=Hdif;
        grad[j] = -(Cost(par)-cost)/Hdif;
        par[j] -=Hdif;
    }                    
    return cost;
}

double Uminimize::ComputeCost(double *par, int iter, int *CostEr, double *grad, double *gauss)
/* 
    Numerical differentiation to compute gauss matrix gauss[] for the case that the  
    analytical derivative is not defined in derived class.
*/
{
    if(grad ==NULL) return ComputeCost(par, iter, CostEr);
    if(gauss==NULL) return ComputeCost(par, iter, CostEr, grad);

    if(CostEr) *CostEr = 0;
    double        cost = ComputeCost(par, iter, CostEr, grad);
    
    double dgrad[MAXPAR];
    for(int j=0; j<ndim; j++)
    {
        par[j] +=Hdif;
        Cost(par, dgrad);
        par[j] -=Hdif;
        for(int i=0; i<ndim; i++) gauss[ndim*j+i] = (grad[i]-dgrad[i])/Hdif;
    }                    
    return cost;
}