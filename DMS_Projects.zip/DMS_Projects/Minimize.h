#ifndef _MINIMIZE_INCLUDED
#define _MINIMIZE_INCLUDED

#include "CostMinimize.h"
#include "String.h"

#define MAXPAR 50           // the maximum number of non-linear parameters that can be minimized

class DLL_IO Uminimize   : public UCostminimize
{
public:
    Uminimize(const UCostminimize& cost); 
    virtual         ~Uminimize();

    void            SetCostMinimize(const UCostminimize& cost);
    ErrorType       Iterate(double *start, int nvar, double offset=0.); 

    ErrorType       InitBestCost(void);
    double          GetBestCost(void) const {return BestCost;}
    const double*   GetBestPar(void) const  {return BestPar;}

    void            StopComputations(void)         {StopIterations = true;}
    const char*     GetIterationString(void) const {return IterationString;}
    int             GetNParameters(void)     const {return ndim;}
    int             GetNoIterations(void)    const {return iterations; }

    virtual void    ShowStatus(int iter, double cost, double* par)  {if(iter<0 || cost<0. || par==NULL) return;}

protected:
    UString         IterationString; // Current "condition" of the minimization algorithm
    FILE            *fpLog;          // File pointer to log-file (if required). This file is opened 
                                     // and closed at the beginning and end of Iterate() with "at"

    ErrorType       ResetIterations(void)           {iterations=0; return U_OK;}
    ErrorType       SetNParameters(int npar);

/* The following two member functions compute the derivatives of the cost w.r.t par[] numerically,
   when analytical methods are not provided by the derived class.
 */
    virtual double  ComputeCost(double *par, int iter, int *CostEr, double *grad);
    virtual double  ComputeCost(double *par, int iter, int *CostEr, double *grad, double *gauss);
    virtual void    NewBestCost(void) {return;} // Called whenever the best cost is improved
    double          Cost(double *par, double *grad=NULL, double *gauss=NULL);

private:
    bool            StopIterations;  // Stop iterations (set exernally using (StopComputations())
    int             iterations;      // Total number of iterations, for each call of Iterate()
    int             CostError;       // Flag to test for invalid parameters, set in Cost(). 0=No parameter error, 1=parameter error
    int             ndim;            // Number of parameters
    double          pcom[MAXPAR];           
    double          xicom[MAXPAR];
    double          xtcom[MAXPAR];
    double          BestPar[MAXPAR]; // Best parameters (acoording to BestCost), over all iterations,
    double          BestCost;        // lowest cost, computed over all iterations
    bool            BestInit;        // Flag to denote that the BestCost has to be initialized

/* Simplex*/
    int             Amoeba(double *p, double *y);
    double          Amotry(double *p, double *y, double *psum, int ihi, double fac, double *ptry);

/* Powell*/
    int             Powell(double *p, double *xi);
    void            Linmin(double *p, double *xi, double *fret);
    double          f1dim(double x);
    int             CostStep_b(double a, double *b, double *step, double *Cost_b, int part, double *umin=NULL, double *umax=NULL);
    int             CostStep_c(double a, double b, double *c, double *step, double *Cost_c, int part, double *umin=NULL, double *umax=NULL);
    int             Mnbrak(double *ax, double *bx, double *cx, double *fa, double *fb, double *fc);
    double          Brent(double ax, double bx, double cx, double tol, double *xmin);

/* Marquardt*/
#ifndef PUBLIC_SOURCES
    int             Marquardt(double *par);
    int             Marquardt2(double *par);
    int             lnsrch(double* par, double res, double *grad, double *dir, double *pnew, double *resnew, double maxstep);
#endif
/* General:*/
    virtual double  ComputeCost(double *par, int iter, int *CostEr) = 0;
/* Given the parameters par[], compute and return the cost,
   determine the domain error *CostEr (if present).
   if(grad!=NULL) compute gradient of error.
   if(gauss!=NULL compute gaussian of error. */ 
};

#endif// _MINIMIZE_INCLUDED
