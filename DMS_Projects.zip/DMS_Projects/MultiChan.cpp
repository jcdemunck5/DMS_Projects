/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     Module for keeping track of epochs of multi-channel MEG/EEG/fMRI data.    */
/*     Channels can be added, data can be filtered in several ways, or new       */
/*     UMultiChan objects can be created from existing ones.                     */
/*                                                                               */
/*     NOTE:                                                                     */
/*     A history in text format is kept track of at each operation. This history */
/*     can be extracted with GetHistory().                                       */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
 JdM/SG  12-06-03   creation
  JdM    17-06-03   Added more functions.
  JdM    29-06-03   Added cut-copy constructor
  JdM    20-07-03   Made UGrid*  in one of the constructors const
                    Bug Fix: operator=()
                    Added  GetCorrelation() and MaxCorrelatedSubShift()
  JdM    21-07-03   Added GetShiftedCorrelation() and GetMaxCorrelatedShift()
  SG     07-08-03   Added Interpolate_DataSegment()
  SG     08-08-03   Added CompOffsetIntermediate(), CompOffsetSlices(), CompOffsetSilentBegin(), CompOffsetSilentEnd(),
                    RemoveJump() and overloaded forms of LevelOffset()
  SG     12-08-03   Added CopyFirstPoint() and CopyLastPoint()
  SG     15-08-03   Added GetSampTime(), GetNChan(), GetNtime() and GetSensorGrid()
  SG     20-08-03   Added Copy()
  SG     21-08-03   Bug Fix: Constructor UMultiChan(const UMultiChan& MC, int SkipSamples, int NewWidth):
                    set SampTime=MC.SampTime
  SG     21-08-03   Minor Bug Fix Copy(): Increse the increment bytes of FilterHistory from 300 to 500
  SG     21-08-03   Minor Bug Fix RepeatValue(): function applied to samples between BegSamp and EndSamp,
                    INCLUDING BegSamp but EXCLUDING EndSamp
  SG     26-08-03   Added CorrectSliceTime()
  JdM    04-11-03   Added GetFFTPowerChan() and GetAverFFTPower()
  JdM    23-11-03   Added Distance2()
  JdM    14-12-03   Added GetSpectrogram()
  JdM    17-12-03   Added operator-=()
  JdM    14-12-03   Renamed old GetSpectrogram() as GetSpectrogramArray() and added GetSpectrogram()  (for single channels)
  JdM    20-12-03   Added GetMinMax()
SG/JdM   20-01-04   Added DownSampleData() (based on earlier version of SG of 27-11-03)
  JdM    30-01-04   GetSpectrogram(): Use center frequency of a frequency bin as UField coordinate, insted of first frequency of a bin.
  JdM    03-02-04   Added GetNormalizedCovariance().
  JdM    19-02-04   Added Window parameter onto GetAverFFTPower(), GetFFTPowerChan(), GetSpectrogram() and GetSpectrogramArray()
  JdM    22-02-04   Bug fix: GetNormalizedCovariance(). Computing residual error
  SG     31-03-04   Bug Fix: RepeatValue(). Writing properties string. Add missing HistEnd to second sprintf line.
  JdM    06-04-04   Added ShiftSubstract()
  SG     23-04-04   Added RemoveLinearTrend()
  SG     23-04-04   Bug Fix: ShiftSubtract(). New computation of Length when OffsetMC=0 and Offset+MC.Ncol exceeds *this.Ncol.
  JdM    20-07-04   Added SelectChannels()
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    19-11-04   Bug Fix: ShiftSubstract(). Determining ofsets end Length
  JdM    20-11-04   Added GetPointMax4(), GetDataPower()
  JdM    27-11-04   Use UString for History and Properties, added SetAllMembersDefault() and DeleteAllMembers()
  JdM    02-12-04   Added GetPropertiesString() and made several UMultiChan arguments const (again)
  JdM    28-12-04   Add RegressChan() and RegressAllChan()
  JdM    30-12-04   Add MergeChannels() and GetFrequency()
  JdM    31-12-04   Add GetRMS()
  JdM    14-01-05   Add GetSVD() and PreWhiten()
  JdM    18-01-05   ShiftData(): Added interpolation parameter TimeShiftType
  JdM    19-01-05   ShiftData(): case U_TIMESHIFT_FFT: use (new function) ::ShiftDataFFT()
  JdM    22-02-05   GetProperties() : use static Properties to keep this function const. Remove GetPropertiesString()
  JdM    11-03-05   Bug fix GetNormalizedCovariance() : SampleTime = (MaxShift-MinShift)/NShift (not MaxShift/NShift)
  JdM    10-03-05   RepeatValue(). Skip logfile message when function is not applied
  JdM    28-01-06   GetSpectrogram() and GetSpectrogramArray(): allow WinSize==Ncol (single time window)
  JdM    30-01-06   NOTE: ApplyWindow(), GetAverFFTPower(), GetFFTPowerChan() and GetSpectrogram():
                    Skipped (implicit) trend-removal, that was present in ULinearFilter::ApplyWindow(). added parameter
  JdM    12-03-06   Renamed DownSampleData() as GetDownSampledData()
                    Added GetResampledData()
  JdM    11-05-06   Added GetTimeMaxRMS(), GetTimeMaxValue() and GetTimeMinValue()
  JdM    01-06-06   Added GetLRSymmetryAsTime()
  JdM    08-06-06   Added IsAnySampleSuperThreshold()
  JdM    26-06-06   Bug fix: IsAnySampleSuperThreshold(). Setting brackets {}!
  JdM    15-03-07   Added GetSpectrogramArray2() and GetSpectrogram2()
  JdM    10-04-07   Update according UGrid changes. UGrid::GetSensors() -> UGrid::GetSensor()
  JdM    15-04-07   Added GetSynLikeMatrix()
  JdM    04-06-05   BUG FIX SelectChannels(). SensorGrid->GetName(inew). This bug was accompanied with index overflow messages from UGrid
  JdM    09-07-07   Added two parameters to GetSynLikeMatrix()
  JdM    23-08-07   Added SetData()
  JdM    14-11-07   Added GetAmplitudeFactor()
DP/JdM   22-11-07   Added GetMorletWaveletTransform()
DP/JdM   23-11-07   Added Another version of GetMorletWaveletTransform()
  JdM    28-11-07   Added GetMorletWaveletTransformArray()
  JdM    15-05-08   Added GetTimeShiftText()
  JdM    02-07-08   GetDownSampledData(). Changed meaning og phase parameter (negative means averaging)
  JdM    06-07-08   GetMinMax(). Added channel selection parameter
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    27-11-08   Added PostMultiply()
  JdM    28-11-08   double data constructor: admit NULL pointer.
                    Added GetChannelData() and SetChannelData()
  JdM    05-01-09   Added ResampleData()
  JdM    12-01-09   Added GetMaxOutlier() and GetRMStime()
  JdM    12-09-09   Added GetResampledData() using linear interpolation
  JdM    10-01-10   Added DownSampledData()
  JdM    10-06-10   Added GetMaxDatChan() and GetMinDatChan()
  JdM    16-10-10   Added GetMinData() and GetMaxData()
  JdM    07-11-10   Added ApplyHilbertTransform()
  JdM    17-11-11   Added InterpolateOutliers()
  JdM    19-11-11   Bug Fixed and Renamed Interpolate_DataSegment() as InterpolateDataSegment()
                    Removed RemoveJump(), added GetMedianAbs()
                    Added (preprocessing window) parameter to ApplyLinearFilter()
                    Renamed Copy() to CopyData(). Changed names of arguments
  JdM    15-12-11   Added GetEnvelopAsFieldGraph()
  JdM    11-01-12   Added InvertData()
  JdM    07-08-12   Added SolveSumKP
                    Added PreMultiply(). Both PreMultiply() and PostMultiply() are based on newly implemented UJacobi-functions
  JdM    10-08-12   Added GetLFPowerAsFieldGraph()
  JdM    21-12-12   Added GetSpatialCovariance() and GetTemporalCovariance()
  JdM    04-01-14   Derive UMultiChan fom UMatrix object.
  JdM    30-07-14   Changed min() into MIN and max() into MAX() for g++ compatibility
  JdM    21-12-14   Base PostMultiply() and PreMultiply() on UMatrixSymmetric object instead of UJacobi
  JdM    18-01-15   GetSpatialCovariance() and GetTemporalCovariance(): use UMatrixSymmetric instead of UJacobi
                    Added operator=(const UMatrix&)
  JdM    28-01-15   PreWhiten(). Use new UCovariance::GetPreWhiten() and UCovariance::GetPostWhiten() functions.
  JdM    09-03-15   Added GetMapsAsField()
  JdM    10-03-15   Added GetMapsAsBitmap()
  JdM    22-03-15   Added ShiftProject() and GetCut()
  JdM    02-10-15   Added ReorderChannelNames()
  JdM    15-10-15   operator+=() and operator-=(): launch WARNING instead of ERROR when sensor grids of operands are not equal.
  JdM    09-09-16   Separately test for this==NULL in some functions to avoid crashing when FilterHistory is addressed.
  JdM    11-09-16   Removed obsolete CopyFirstPoint(), CopyLastPoint(), RepeatValue(), CorrectSliceTime(),
                    CompOffsetIntermediate(), CompOffsetSlices(), CompOffsetSilentBegin(), CompOffsetSilentEnd() and LevelOffset()
  JdM    14-09-16   Added ComputeGroupReference() and RemoveReferenceComponents()
                    ReorderChannelNames(): added argument
 */

#include <math.h>
#include <string.h>

#include "MultiChan.h"
#include "Projector.h"
#include "GridFit.h"
#include "Field.h"
#include "FieldGraph.h"
#include "Covariance.h"
#include "SortSemiSort.h"
#include "MatrixSumKP.h"
#include "Interpolate.h"
#include "WaveletTransform.h"



ErrorType UMultiChan::CopyFirstPoint()
/*
   Sets the first point of the data series equal to the second.
 */
{
    if(!Data)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyFirstPoint(). Data Array is NULL.\n");
        return U_ERROR;
    }
    if(Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyFirstPoint(). Invalid number of channels (%i).\n",Nrow);
        return U_ERROR;
    }
    if(Ncol<=1)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyFirstPoint(). Invalid number of samples per slice (%i).\n",Ncol);
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
    {
        Data[i * Ncol + 0] = Data[i * Ncol + 1];
    }

/*Update filter history */
    FilterHistory += UString("UMultiChan::CopyFirstPoint() \n");
    return U_OK;
}

ErrorType UMultiChan::CopyLastPoint()
/*
   Sets the last point of the data series equal to the previous one.
 */
{
    if(!Data)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyLastPoint(). Data Array is NULL.\n");
        return U_ERROR;
    }
    if(Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyLastPoint(). Invalid number of channels (%i).\n",Nrow);
        return U_ERROR;
    }
    if(Ncol<=1)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyLastPoint(). Invalid number of samples in the data series (%i).\n",Ncol);
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
    {
        Data[i * Ncol + Ncol - 1] = Data[i * Ncol + Ncol - 2];
    }

/*Update filter history */
    FilterHistory += UString("UMultiChan::CopyLastPoint() \n");

    return U_OK;
}
ErrorType  UMultiChan::RepeatValue(int BegSamp, int EndSamp)
/*
    Set a range (starting in BegSamp and ending in EndSamp and excluding EndSamp)
    of the time functions equal to a constant value.
    This value is that corresponding to the sample immediately before sample BegSamp.

    -Update History.
 */
{
    if(BegSamp<=0 || EndSamp<0 || BegSamp>=Ncol || EndSamp>=Ncol || BegSamp>EndSamp)
    {
        CI.AddToLog("ERROR: UMultiChan::RepeatValue(). Arguments out of range: BegSamp=%d, EndSamp=%d, Ncol=%d  . \n",BegSamp, EndSamp, Ncol);
        return U_ERROR;
    }
    if(BegSamp==EndSamp) return U_OK;

    for(int i=0; i<Nrow; i++)
    {
        double* pData     =   Data + i*Ncol + BegSamp;
        double  LastPoint = *(Data + i*Ncol + BegSamp - 1);
        for(int j=BegSamp;j<EndSamp;j++)
        {
            *pData++ = LastPoint;
        }
    }

/*Update filter history */
    FilterHistory  +=  UString(BegSamp, "UMultiChan::RepeatValue(BegSamp=%d")
                    +  UString(EndSamp, ", EndSamp=%d) \n");

    return U_OK;
}

UString UMultiChan::Properties = UString();

const char* GetTimeShiftText(TimeShiftType TST)
{
    switch(TST)
    {
    case U_TIMESHIFT_SAMPLE: return "Nearest Sample";
    case U_TIMESHIFT_LINEAR: return "Linear";
    case U_TIMESHIFT_FFT   : return "DFT";
    default: break;
    }
    return "Unknown Time Interploaltion Type";
}

void UMultiChan::SetAllMembersDefault(void)
{
    error          = U_OK;
    FilterHistory  = UString();

    SensorGrid     = NULL;
    SampTime       = 0.;
}

void UMultiChan::DeleteAllMembers(ErrorType E)
{
    delete   SensorGrid;
    SetAllMembersDefault();
    error = E;
}

UMultiChan::UMultiChan() : UMatrix()
{
    SetAllMembersDefault();
    FilterHistory  = UString("UMultiChan::UMultiChan() \n");
}
UMultiChan::UMultiChan(ErrorType E) : UMatrix(E)
{
    SetAllMembersDefault();
    error = E;
}

UMultiChan::UMultiChan(const UMultiChan& MC) : UMatrix((UMatrix)MC)
{
    SetAllMembersDefault();
    if(&MC==NULL)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Argument has invalid NULL address. \n");
        return;
    }

    FilterHistory  = UString("UMultiChan::UMultiChan() \n");
    *this = MC;
}

UMultiChan::UMultiChan(const UMultiChan& MC, int SkipSamples, int NewWidth) : UMatrix()
/*
    Create new object by copying MC, and select time samples by skipping the first
    SkipSamples and taking the following NewWidth samples (see Cut())
 */
{
    SetAllMembersDefault();
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Argument has invalid NULL address or argument is erroneous. \n");
        return;
    }

    if(SkipSamples<0 || NewWidth<=0 || SkipSamples+NewWidth>MC.Ncol)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Arguments out of range: SkipSamples=%d, NewWidth=%d and MC.Ncol=%d . \n",SkipSamples, NewWidth, MC.Ncol);
        return;
    }

    if(MC.SensorGrid)
    {
        SensorGrid = new UGrid(*MC.SensorGrid);
        if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
        {
            UMatrix::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Copying sensor grid. \n");
            return;
        }
    }

    SampTime = MC.SampTime;
    Nrow     = MC.Nrow;
    Ncol     = NewWidth;
    MT       = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    Data     = new double[Nrow*Ncol];
    if(Data==NULL)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Memory allocation:  Ncol = %d . \n", Ncol);
        return;
    }

/* Copy selected samples */
    double* pMCData = MC.Data+SkipSamples;
    double* pData   = Data;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<Ncol; j++)   *pData++ = *pMCData++;
        pMCData += (MC.Ncol-Ncol);
    }

/*Update filter history */
    FilterHistory  = UString("UMultiChan::UMultiChan(MC=")
                   + MC.GetProperties((const char*)NULL)
                   + UString(SkipSamples, ", SkipSamples=%d")
                   + UString(NewWidth   , ", NewWidth=%d) \n");

    error = U_OK;
}

UMultiChan::UMultiChan(const UGrid* Grid, int ntime, double samptime) : UMatrix()
{
    SetAllMembersDefault();
    if(Grid==NULL || Grid->GetError()!=U_OK || Grid->GetNpoints()<=0 || ntime<=0 || samptime<=0.)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Erronous argument(s): Grid==NULL (?) ntime = %d, samptime = %f.\n", ntime, samptime);
        return;
    }
    *this = UMultiChan(NULL, Grid, ntime, samptime);
}
UMultiChan::UMultiChan(const double* data, const UGrid* Grid, int ntime, double samptime) : UMatrix()
{
    SetAllMembersDefault();
    if(Grid==NULL || Grid->GetError()!=U_OK || Grid->GetNpoints()<=0 || ntime<=0 || samptime<=0.)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Erronous argument(s): Grid==NULL (?) ntime = %d, samptime = %f.\n", ntime, samptime);
        return;
    }
    Nrow       = Grid->GetNpoints();
    Ncol       = ntime;
    MT         = (Nrow==Ncol) ? U_MAT_SQUARE : U_MAT_GENERAL;
    Data       = new double[Nrow*Ncol];
    SensorGrid = new UGrid(*Grid);
    if(Data==NULL || SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::UMultiChan(). Memory Allocation, ntime=%d. Npoints = %d  .\n", Ncol, Nrow);
        return;
    }
    SampTime  = samptime;
    int NCNt  = Nrow*Ncol;
    if(data) for(int ij=0; ij<NCNt; ij++) Data[ij] = data[ij];
    else     for(int ij=0; ij<NCNt; ij++) Data[ij] = 0.;

/*Update filter history */
    FilterHistory  = UString("UMultiChan::UMultiChan(");
    FilterHistory += UString(Nrow     , ", Nrow=%d");
    FilterHistory += UString(Ncol     , ", Ncol=%d");
    FilterHistory += UString(SampTime  , ", SampTime=%f) \n");
}

UMultiChan::~UMultiChan()
{
    DeleteAllMembers(U_OK);
}
UMultiChan& UMultiChan::operator= (const UMatrix& M)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(&M==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator=(). Argument has invalid NULL address. \n");
        return *this;
    }
    if(this==&M) return *this;

    UMatrix::operator=(M);
    if(UMatrix::GetError() != U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::operator=(). Copying base class. \n");
        return *this;
    }
    return *this;
}

UMultiChan& UMultiChan::operator=(const UMultiChan& MC)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(&MC==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator=(). Argument has invalid NULL address. \n");
        return *this;
    }
    if(this==&MC) return *this;

    UMatrix::operator=(MC);
    if(UMatrix::GetError() != U_OK)
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiChan::operator=(). Copying base class. \n");
        return *this;
    }

    DeleteAllMembers(U_OK);

    FilterHistory   += MC.FilterHistory;
    if(MC.SensorGrid)
    {
        SensorGrid = new UGrid(*MC.SensorGrid);
        if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
        {
            delete SensorGrid; SensorGrid = NULL;
        }
    }

    if(!SensorGrid        && MC.SensorGrid   )
    {
        UMatrix::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_OK);
        CI.AddToLog("ERROR: UMultiChan::operator=(). Copying data from argument. Memory allocation. \n");
        return *this;
    }

    error          = MC.error;
    SampTime       = MC.SampTime;

/*Update filter history */
    FilterHistory   += UString("UMultiChan::operator=(Data");
    FilterHistory   += UString(Nrow   , ", MC.Nrow = %d");
    FilterHistory   += UString(Ncol   , ", MC.Ncol = %d");
    FilterHistory   += UString(SampTime, ", MC.SampTime = %f) \n");

    return *this;
}

UMultiChan& UMultiChan::operator+=(const UMultiChan& MC)
/*
   Add the data arrays of MC to those of *this, sample by sample, channel by channel.
   if(*this is empty (created by default constructor)) apply operator=(MC)
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). Object not properly set. History = %s .\n", FilterHistory);
        return *this;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). Invalid UMultiChannel argument. \n");
        return *this;
    }
    if(MC.Data==NULL) return *this;
    if(Data==NULL)
    {
        return *this = MC;
    }
    if(SensorGrid && MC.SensorGrid && *SensorGrid != *MC.SensorGrid)
        CI.AddToLog("WARNING: UMultiChan::operator+=(). Sensorgrid is not identical to argument. \n");
    if(Nrow != MC.Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). Number of channels are different: (%d and %d) . \n",Nrow,MC.Nrow);
        return *this;
    }
    if(Ncol != MC.Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). Number of time samples are different: (%d and %d) . \n",Ncol, MC.Ncol);
        return *this;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::operator+=(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return *this;
    }

    double* pData    = Data;
    double* pMCData  = MC.Data;
    for(int i=0; i<Nrow; i++)
        for(int j=0; j<Ncol; j++)
            *pData++ += *pMCData++;


/*Update filter history */
    FilterHistory   += UString("UMultiChan::operator+=() \n");
    return *this;
}

UMultiChan& UMultiChan::operator-=(const UMultiChan& MC)
/*
   Substract the data arrays of MC from those of *this, sample by sample, channel by channel.
   if(*this is empty (created by default constructor)) apply operator=(MC)
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). Object not properly set. History = %s .\n", FilterHistory);
        return *this;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). Invalid UMultiChannel argument. \n");
        return *this;
    }
    if(MC.Data==NULL) return *this;
    if(Data==NULL)
    {
        return *this = MC;
    }
    if(SensorGrid && MC.SensorGrid && *SensorGrid != *MC.SensorGrid)
        CI.AddToLog("WARNING: UMultiChan::operator-(). Sensorgrid is not identical to argument. \n");

    if(Nrow != MC.Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). Number of channels are different: (%d and %d) . \n",Nrow,MC.Nrow);
        return *this;
    }
    if(Ncol != MC.Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). Number of time samples are different: (%d and %d) . \n",Ncol, MC.Ncol);
        return *this;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::operator-=(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return *this;
    }

    double* pData    = Data;
    double* pMCData  = MC.Data;
    for(int i=0; i<Nrow; i++)
        for(int j=0; j<Ncol; j++)
            *pData++ -= *pMCData++;


/*Update filter history */
    FilterHistory   += UString("UMultiChan::operator-=() \n");
    return *this;
}

UMultiChan& UMultiChan::operator*=(double f)
/*
   Multiply the data arrays with the factor f.
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator*=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(Data==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::operator*=(). Object not properly set. History = %s \n", FilterHistory);
        return *this;
    }
    if(f==1.) return *this;

    int     Nelem = Nrow*Ncol;
    double* pData = Data;
    for(int ij=0; ij<Nelem; ij++) (*pData++) *= f;

/*Update filter history */
    FilterHistory   += UString(f, "UMultiChan::operator*=(%f) \n");

    return *this;
}

UMultiChan& UMultiChan::operator/=(double f)
/*
   Divide the data arrays with the factor f.
 */
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::operator/=(). this==NULL. \n");
        static UMultiChan M(U_ERROR);
        return M;
    }
    if(Data==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::operator/=(). Object not properly set. History = %s \n", FilterHistory);
        return *this;
    }
    if(f==0.)
    {
        CI.AddToLog("ERROR: UMultiChan::operator/=(). Cannot divide by 0. \n");
        return *this;
    }
    *this *= (1./f);

/*Update filter history */
    FilterHistory   += UString(f, "UMultiChan::operator/=(%f) \n");
    return *this;
}

ErrorType UMultiChan::InvertData(void) 
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<0 || Ncol<0)
    {
        CI.AddToLog("ERROR: UMultiChan::InvertData(). Object NULL or not properly set.\n");
        return U_ERROR;
    }
    int     Nelem = Nrow*Ncol;
    for(int ij=0; ij<Nelem; ij++) Data[ij] = -Data[ij];
    return U_OK;
}

ErrorType UMultiChan::SetData(double Dat)
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::SetData(). Object NULL or not properly set.\n");
        return U_ERROR;
    }
    int     Nelem = Nrow*Ncol;
    double* pData = Data;
    for(int ij=0; ij<Nelem; ij++) (*pData++) = Dat;
    return U_OK;
}

const double* UMultiChan::GetChannelData(int ichan) const
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetChannelIData(). Object NULL. \n");
        return NULL;
    }
    if(Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetChannelData(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetChannelData(). ichan (=%d) out of range; Nchan = %d .\n", ichan, Nrow);
        return NULL;
    }
    return Data + ichan*Ncol;
}
ErrorType UMultiChan::SetChannelData(const double* data, int ichan)
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::SetChannelData(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::SetChannelData(). Invalid NULL argument. \n");
        return U_ERROR;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::SetChannelData(). ichan (=%d) out of range; Nchan = %d .\n", ichan, Nrow);
        return U_ERROR;
    }
    for(int j=0; j<Ncol; j++)  Data[ichan*Ncol +j] = data[j];

    return U_OK;
}

double UMultiChan::GetMaxData(bool Fabs) const
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxData(). Object not properly set. History = %s \n", FilterHistory);
        return 0.;
    }
    double DMin = 0;
    double DMax = 0;
    if(GetMinMax(&DMin, &DMax, -1))
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxData(). Getting min and max .\n");
        return 0.;
    }
    if(NOT(Fabs)) return DMax;

    DMin = fabs(DMin);
    DMax = fabs(DMax);
    return MAX(DMin, DMax);
}
double UMultiChan::GetMinData() const
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinData(). Object not properly set. History = %s \n", FilterHistory);
        return 0.;
    }
    double DMin = 0;
    double DMax = 0;
    if(GetMinMax(&DMin, &DMax, -1))
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinData(). Getting min and max .\n");
        return 0.;
    }
    return DMin;
}
UCovariance* UMultiChan::GetSpatialCovariance(DataType DType) const
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0 || SensorGrid==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpatialCovariance(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(DType!=U_DAT_MEG && DType!=U_DAT_EEG)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpatialCovariance(). Data should be of type MEG or EEG (DType = %d) \n", DType);
        return NULL;
    }

    UMatrixSymmetric MMT = GetMMT();
    if(MMT.GetError()!= U_OK || MMT.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpatialCovariance(). Memory allocation, Nrow = %d .\n", Nrow);
        return NULL;
    }
    UCovariance*         Cov = NULL;
    if(DType==U_DAT_MEG) Cov = new UCovariance(MMT, SensorGrid, NULL);
    else                 Cov = new UCovariance(MMT, NULL, SensorGrid);

    if(Cov==NULL || Cov->GetError()!=U_OK)
    {
        delete Cov;
        CI.AddToLog("ERROR: UMultiChan::GetSpatialCovariance(). Creating UCovariance object.\n");
        return NULL;
    }
    return Cov;
}
UCovariance* UMultiChan::GetTemporalCovariance(void) const
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0 || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTemporalCovariance(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }

    UMatrixSymmetric MTM = GetMTM();
    if(MTM.GetError()!= U_OK || MTM.GetMatrixArray()==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTemporalCovariance(). Memory allocation, Ncol = %d .\n", Ncol);
        return NULL;
    }
    UCovariance* Cov = new UCovariance(MTM, SampTime*1000.);

    if(Cov==NULL || Cov->GetError()!=U_OK)
    {
        delete Cov;
        CI.AddToLog("ERROR: UMultiChan::GetTemporalCovariance(). Creating UCovariance object.\n");
        return NULL;
    }
    return Cov;
}

ErrorType UMultiChan::GetMinMax(double* DatMin, double* DatMax, int ichan) const
/*
    Compute the minimum and maximum value of the Data[] array.
 */
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinMax(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }

    if(DatMin==NULL && DatMax==NULL) return U_OK;
    if(ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinMax(). Channel parameter out of range (ichan=%d). \n", ichan);
        return U_ERROR;
    }
    int    ijstart = 0;
    int    Nij     = Nrow*Ncol;
    if(ichan>=0)
    {
        ijstart    = ichan*Ncol;
        Nij        = Ncol;
    }

    double Dmin  = Data[ijstart];
    double Dmax  = Data[ijstart];
    double *pDat = Data+ijstart;
    for(int ij=0; ij<Nij; ij++, pDat++)
    {
        if(Dmin>*pDat) Dmin = *pDat;
        if(Dmax<*pDat) Dmax = *pDat;
    }
    if(DatMin) *DatMin = Dmin;
    if(DatMax) *DatMax = Dmax;

    return U_OK;
}
double UMultiChan::GetMedianAbs(void) const
{
    if(this==NULL||Data==NULL || error !=U_OK || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMedianAbs(). Object not properly set. History = %s \n", FilterHistory);
        return 0;
    }
    return ::GetMedianAbs(Data, Nrow*Ncol);
}

ErrorType UMultiChan::ShiftData(double Shift, TimeShiftType TST)
/*
    Shift the data array Data[] over a time distance of Shift seconds

    switch(TST)
        U_TIMESHIFT_SAMPLE -> Round off to whole sample
        U_TIMESHIFT_FFT    -> Interpolate with FFT
        U_TIMESHIFT_LINEAR -> Interpolate linearly

    Update History.
 */
{
    if(this==NULL || Data==NULL || error !=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftData(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    if(Shift==0.)           return U_OK;
    if(Ncol ==0 || Nrow==0) return U_OK;

    switch(TST)
    {
    case U_TIMESHIFT_SAMPLE:
        {
            int ShiftSamp = (int)floor( 0.5 + Shift/SampTime);
            if(ShiftSamp==0) return U_OK;

            for(int i=0; i<Nrow; i++)
            {
                double* pData = Data+i*Ncol;
                if(ShiftSamp<0)
                {
                    for(int j=Ncol-1; j>=-ShiftSamp; j--) pData[j] = pData[j+ShiftSamp];
                    for(int j=0;      j <-ShiftSamp; j++) pData[j] = pData[0];
                }
                else
                {
                    for(int j=0;              j<Ncol-ShiftSamp; j++) pData[j] = pData[j+ShiftSamp];
                    for(int j=Ncol-ShiftSamp; j<Ncol;           j++) pData[j] = pData[Ncol-1];
                }
            }
            break;
        }
    case U_TIMESHIFT_FFT:
        {
            double* Buffer = new double[Ncol];
            if(Buffer==NULL)
            {
                CI.AddToLog("ERROR: UMultiChan::ShiftData(). Memory allocation if Buffer. Ncol = %d .\n", Ncol);
                return U_ERROR;
            }
            for(int i=0; i<Nrow; i++)
                ::ShiftDataFFT(Data+i*Ncol, Buffer, SampTime, Ncol, Shift);
            delete[] Buffer;
            break;
        }
    case U_TIMESHIFT_LINEAR:
        {
    /* Shift a whole number of samples */
            double    ShiftSamp = floor( 0.5 + Shift/SampTime) * SampTime;
            ShiftData(ShiftSamp, U_TIMESHIFT_SAMPLE);

    /* Shift a fraction, using interpolation*/
            double ShiftFrac = (Shift - ShiftSamp)/SampTime; // This must be in (-0.5, +0.5)
            if(ShiftFrac==0.) return U_OK;

            double W0 = ShiftFrac;
            if(ShiftFrac<0.) W0 = 1+ShiftFrac;
            else             W0 = 1-ShiftFrac;
            double W1 = 1.-W0;
            for(int i=0; i<Nrow; i++)
            {
                double* pData = Data+i*Ncol;
                if(ShiftFrac<0.)
                    for(int j=Ncol-1; j>=1     ; j--) pData[j] = W0*pData[j-1] + W1*pData[j  ];
                else
                    for(int j=0      ; j<Ncol-1; j++) pData[j] = W0*pData[j  ] + W1*pData[j+1];
            }
            break;
        }

        break;
    default:
        CI.AddToLog("ERROR: UMultiChan::ShiftData(). Invalid TimeShiftType: TST = %d. \n", TST);
        return U_ERROR;
    }


/*Update filter history */
    FilterHistory   += UString(Shift, "UMultiChan::ShiftData(Shift=%f")
                     + UString(TST  , ", TST=%d) \n");
    return U_OK;
}

UMultiChan* UMultiChan::GetResampledData(int NewNtime) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: GetResampledData(). this = NULL or erroneous   .\n");
        return NULL;
    }
    if(NewNtime<=0)
    {
        CI.AddToLog("ERROR: GetResampledData(). Invalid new samples (NewNtime = %d ) .\n", NewNtime);
        return NULL;
    }
    double* DSdata = new double[Nrow*NewNtime];
    if(DSdata==NULL)
    {
        delete[] DSdata;
        CI.AddToLog("ERROR: GetResampledData(). Memory allocation error. NewNsamp = %d   .\n", NewNtime);
        return NULL;
    }

    double NewSampTime = SampTime*Ncol/NewNtime;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<NewNtime; j++)
        {
            double* pOut  = DSdata + i*NewNtime;
            double  Xout  = j*NewSampTime;
            for(int jj=0; jj<Ncol; jj++)
            {
                if(jj==Ncol-1)
                {
                    double Xin0 = jj*SampTime;
                    if(Xin0==Xout) pOut[j] = Data[i*Ncol + jj];
                    continue;
                }
                double Xin0 =  jj   *SampTime;
                double Xin1 = (jj+1)*SampTime;
                if( (Xin0<=Xout && Xout<=Xin1) ||
                    (Xin0>=Xout && Xout>=Xin1))
                {
                    double D0 = Data[i*Ncol + jj  ];
                    double D1 = Data[i*Ncol + jj+1];

                    pOut[j] = ((Xin0-Xout)*D1 + (Xout-Xin1)*D0) / (Xin0-Xin1);
                    break;
                }
            }
        }
    }

    UMultiChan* MC = new UMultiChan(DSdata, SensorGrid, NewNtime, NewSampTime);
    delete[] DSdata;
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: GetResampledData(). Converting down sampled data to UMultiChan object. \n");
        return NULL;
    }
    return MC;
}

UMultiChan* UMultiChan::GetResampledData(const UInterpolate* Inter) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: GetResampledData(). this = NULL or erroneous   .\n");
        return NULL;
    }
    if(Inter==NULL || Inter->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: GetResampledData(). Erroneous or NULL Interpolate argument. \n");
        return NULL;
    }
    if(Inter->GetNsampInput()!=Ncol)
    {
        CI.AddToLog("ERROR: GetResampledData(). Number of input samples of UInterpolate argument (=%d) does not match Ncol (=%d). \n",Inter->GetNsampInput(), Ncol);
        return NULL;
    }
    int NewNsamp = Inter->GetNsampOutput();
    if(NewNsamp<=0)
    {
        CI.AddToLog("ERROR: GetResampledData(). Number of output samples of UInterpolate argument (=%d) out of range. \n",Inter->GetNsampOutput());
        return NULL;
    }

    double* DSdata = new double[Nrow*NewNsamp];
    if(DSdata==NULL)
    {
        delete[] DSdata;
        CI.AddToLog("ERROR: GetResampledData(). Memory allocation error. NewNsamp = %d   .\n", NewNsamp);
        return NULL;
    }
    for(int i=0; i<Nrow; i++)
        if(Inter->Resample(Data+i*Ncol, DSdata+i*NewNsamp)!=U_OK)
        {
            delete[] DSdata;
            CI.AddToLog("ERROR: GetResampledData(). Interpolation error. \n");
            return NULL;
        }

    UMultiChan* MC = new UMultiChan(DSdata, SensorGrid, NewNsamp, SampTime*Ncol/NewNsamp);
    delete[] DSdata;
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: GetResampledData(). Converting down sampled data to UMultiChan object. \n");
        return NULL;
    }
    return MC;
}
ErrorType UMultiChan::ResampleData(const UInterpolate* Inter)
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: ResampleData(). this = NULL or erroneous   .\n");
        return U_ERROR;
    }
    if(Inter==NULL || Inter->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: ResampleData(). Erroneous or NULL Interpolate argument. \n");
        return U_ERROR;
    }
    if(Inter->GetNsampInput()!=Ncol)
    {
        CI.AddToLog("ERROR: ResampleData(). Number of input samples of UInterpolate argument (=%d) does not match Ncol (=%d). \n",Inter->GetNsampInput(), Ncol);
        return U_ERROR;
    }
    int NewNsamp = Inter->GetNsampOutput();
    if(NewNsamp<=0)
    {
        CI.AddToLog("ERROR: ResampleData(). Number of output samples of UInterpolate argument (=%d) out of range. \n",Inter->GetNsampOutput());
        return U_ERROR;
    }
    double* DSdata = new double[Nrow*NewNsamp];
    if(DSdata==NULL)
    {
        CI.AddToLog("ERROR: ResampleData(). Memory allocation error. NewNsamp = %d   .\n", NewNsamp);
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
        if(Inter->Resample(Data+i*Ncol, DSdata+i*NewNsamp)!=U_OK)
        {
            delete[] DSdata;
            CI.AddToLog("ERROR: ResampleData(). Interpolation error. \n");
            return U_ERROR;
        }
    delete[] Data; Data = DSdata;
    SampTime *= (Ncol/double(NewNsamp));
    Ncol     = NewNsamp;

    return U_OK;
}

double UMultiChan::GetDataPower(void) const
/*
   Return the sum of squares of the data-array.
 */
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetDataPower(). Object not properly set. History = %s \n", FilterHistory);
        return 0.;
    }
    return UMatrix::GetFrobNorm2();
}

int UMultiChan::GetMaxOutlier(int offset, int NWindow, double Thresh) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxOutlier(). Object not properly set. History = %s \n", FilterHistory);
        return -1;
    }
    if(offset<0 || Thresh<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxOutlier(). Invalid parameters: offset = %d, Thresh = %f \n", offset, Thresh);
        return -1;
    }
    if(NWindow<=0)
    {
        NWindow = Ncol;
        offset  = 0;
    }

    int    jmax = offset;
    double Dmax = GetRMStime(jmax);
    for(int j=offset; j<offset+NWindow; j++)
    {
        if(j>=Ncol) break;
        double D = GetRMStime(j);
        if(D<=Dmax) continue;

        jmax = j;
        Dmax = D;
    }

    if(Dmax<Thresh) return -1;
    return jmax;
}

int UMultiChan::GetPointMax4(void) const
/*
   Return the sample number for which the sum over channels of the fourth
   power of the data is maximum.
 */
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetPointMax4(). Object not properly set. History = %s \n", FilterHistory);
        return 0;
    }
    double T4 = 0.;
    int    jm = 0;
    for(int j=0; j<Ncol; j++)
    {
        double test4 = 0;
        for(int i=0; i<Nrow; i++)
        {
            double D = Data[i*Ncol+j];
            test4   += D*D*D*D;
        }
        if(test4>T4)
        {
            T4 = test4;
            jm = j;
        }
    }
    return jm;
}

ErrorType UMultiChan::UpSampleData(int UpSampleFactor)
/*
    Shift the data array Data[] over a new sample rate covering the same time interval, but
    Ncol*UpSampleFactor samples.

    -delete Data[] and replace it by a new array of  nChan * Ncol*UpSampleFactor samples.
    -Update History.
 */
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::UpSampleData(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    if(UpSampleFactor<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::UpSampleData(). Invalid argument: UpSampleFactor = %d.\n", UpSampleFactor);
        return U_ERROR;
    }
    if(UpSampleFactor==1) return U_OK;

    int     NewNtime = Ncol*UpSampleFactor;
    double* NewData  = new double[Nrow*NewNtime];
    double* Himp     = new double[2*UpSampleFactor+1];
    if(NewData==NULL || Himp==NULL)
    {
        delete[] NewData;
        delete[] Himp;
        CI.AddToLog("ERROR: UMultiChan::UpSampleData(). Memory allocation if Buffer. Ncol = %d, UpSampleFactor = %d .\n", Ncol, UpSampleFactor);
        return U_ERROR;
    }
    for(int k=0; k<2*UpSampleFactor+1; k++)
    {
        if(k<=UpSampleFactor) Himp[k] = k/(double)UpSampleFactor;
        else                  Himp[k] = Himp[2*UpSampleFactor-k];
    }

    UConvolve Con(Himp, 2*UpSampleFactor+1);
    Con.SetManyFFT(false);

    double* pNewData = NewData;
    double* pOldData = Data;
    for(int i=0; i<Nrow; i++)
    {
        for(int jn=0; jn<NewNtime; jn++)
        {
            if(jn%UpSampleFactor) *pNewData++ = 0;
            else                  *pNewData++ = *pOldData++;
        }
        if(Con.ComputeConv(NewData+i*NewNtime, NewNtime)!=U_OK)
        {
            delete[] NewData;
            delete[] Himp;
            CI.AddToLog("ERROR: UMultiChan::UpSampleData(). Computing convolution in channel = %d .\n", i);
            return U_ERROR;
        }
    }

    delete[] Himp;
    delete[] Data;  Data = NewData;
    Ncol     = NewNtime;
    SampTime /= UpSampleFactor;


/*Update filter history */
    FilterHistory   += UString(UpSampleFactor, "UMultiChan::UpSampleData(UpSampleFactor=%d) \n");

    return U_OK;
}

ErrorType UMultiChan::InterpolateOutliers(double ThreshNormal, double ThreshOutlier, int MaxWin, int**SampOutlier, int* NOutlier)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::InterpolateOutliers(). Object NULL. \n");
        return U_ERROR;
    }
    if(Data==NULL && Nrow==0 && Ncol==0) return U_OK;
    if(Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::InterpolateOutliers(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    if(ThreshNormal <=0 || ThreshOutlier<ThreshNormal)
    {
        CI.AddToLog("ERROR: UMultiChan::InterpolateOutliers(). Invalid argument(s): ThreshOutlier = %d, ThreshNormal = %f .\n", ThreshOutlier, ThreshNormal);
        return U_ERROR;
    }
    if(MaxWin<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::InterpolateOutliers(). Invaid argument: MaxWin = %d  .\n", MaxWin);
        return U_ERROR;
    }
    int* isampout = new int[Ncol];
    if(isampout==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::InterpolateOutliers(). Memory allocation: Ncol = %d  .\n", Ncol);
        return U_ERROR;
    }
    for(int j=0; j<Ncol; j++) isampout[j] = 0;

    for(int ichan=0; ichan<Nrow; ichan++)
    {
        double* Dati  = Data + ichan*Ncol;
        int     jgood = -1;
        int     jbad  = -1;
        for(int j=0; j<Ncol; j++)
        {
            if(fabs(Dati[j])<ThreshNormal ) 
            {
                if(jbad>=0)
                {                    
                    if(jbad-MAX(0,jgood) > MaxWin)
                        CI.AddToLog("WARNING: UMultiChan::InterpolateOutliers(). BAD epoch larger than %d samples. \n", MaxWin);

                    InterpolateDataSegment(jgood, j, ichan); 
                    isampout[jbad] =  1;
                    jbad           = -1;
                }
                jgood = j; 
            }
            else if(fabs(Dati[j])>=ThreshOutlier) 
            {
                jbad  = j;
            }
        }
        if(jgood<0)
        {          
            CI.AddToLog("WARNING: UMultiChan::InterpolateOutliers(). All %d samples BAD . \n", Ncol);
            InterpolateDataSegment(-1, Ncol, ichan); 
        }
        else if(jbad>=0)
        {
            InterpolateDataSegment(jgood, Ncol, ichan); 
        }
    }
    
    int Nout = 0;
    for(int j=0; j<Ncol; j++) if(isampout[j]) Nout++; 

    if(NOutlier) *NOutlier = Nout;

    if(SampOutlier)
    {
        for(int j=0, k=0; j<Ncol; j++) if(isampout[j]) isampout[k++]=j; 
        *SampOutlier = isampout;
    }
    else
    {
        delete[] isampout;
    }

    return U_OK;
}
ErrorType UMultiChan::ComputeGroupReference(void) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::ComputeGroupReference(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ComputeGroupReference(). SensorGrid NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Nrow!=SensorGrid->GetNpoints() || SensorGrid->GetGroup()==NULL || SensorGrid->GetGroup()->GetNGroup()<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::ComputeGroupReference(). Inconsistent sensor grid, or grouping not properly set. \n");
        return U_ERROR;
    }

/* Initialize static (group) parameters */
    int     NG    = SensorGrid->GetGroup()->GetNGroup();
    int*    index = SensorGrid->GetGroupNameOrder(true);
    if(index==NULL)
    {
        delete[] index;
        CI.AddToLog("ERROR: UMultiChan::ComputeGroupReference(). Getting group name ordering  .\n");
        return U_ERROR;
    }
    for(int is=0; is<Nrow; is++) index[is] *= Ncol;

/* Compute group averages */
    for(int j=0; j<Ncol; j++)
    {
        for(int ig=0,is=0; ig<NG; ig++)
        {
            int    Nel  = SensorGrid->GetGroup()->GetNElem(ig);
            if(Nel<=0) continue;
            double Aver = 0.;
            for(int ie=0; ie<Nel; ie++,is++) Aver += Data[index[is]+j];
            Aver /= Nel;

            is -= Nel;
            for(int ie=0; ie<Nel; ie++,is++) Data[index[is]+j] -= Aver;
        }
    }
    delete[] index;
    return U_OK;
}

ErrorType UMultiChan::ApplyLinearFilter(ULinearFilter& Filt, const UMultiChan* MCpre)
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(&Filt==NULL || Filt.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Invalid or NULL Filt argument.\n");
        return U_ERROR;
    }

    if(MCpre)
    {
        if(MCpre->GetError()!=U_OK || MCpre->Data==NULL)
        {
            CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Pre-processing window NULL or erroneoes.\n");
            return U_ERROR;
        }
        if(MCpre->GetNChan()!=Nrow)
        {
            CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Pre-processing window has deviation number of channels (%d), Nrow=%d.\n", MCpre->GetNChan(), Nrow);
            return U_ERROR;
        }
        if(Filt.ComputeFilter(MCpre->Data, MCpre->Ncol, Data, Ncol, Nrow)!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Applying the ComputeFilter() function of Filt.\n");
            return U_ERROR;
        }
    }
    else
    {
        if(Filt.ComputeFilter(NULL, 0, Data, Ncol, Nrow)!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::ApplyLinearFilter(). Applying the ComputeFilter() function of Filt.\n");
            return U_ERROR;
        }
    }

/*Update filter history */
    FilterHistory   += UString(Filt.GetProperties((const char*)NULL), "UMultiChan::ApplyLinearFilter(Filt=%s) \n");
    return U_OK;
}

ErrorType  UMultiChan::Merge(const UMultiChan& MC)
/*
    Merge the time functions of MC to the existing ones, channel by channel.
    First test wheather such merging is possible.

    -Update History.
 */
{
    if(this==NULL || error !=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(MC.Data==NULL) return U_OK;
    if(Data==NULL)
    {
        *this = MC;
        return error;
    }
    if(SensorGrid && MC.SensorGrid && *SensorGrid != *MC.SensorGrid)
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). Sensorgrid is not identical to argument. \n");
        return U_ERROR;
    }
    if(Nrow != MC.Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). Number of channels are different: (%d and %d) . \n",Nrow,MC.Nrow);
        return U_ERROR;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return U_ERROR;
    }

    int     NewNtime = Ncol + MC.Ncol;
    double* NewData  = new double[Nrow*NewNtime];
    if(NewData==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::Merge(). Memory allocation: NewNtime = %d . \n", NewNtime);
        return U_ERROR;
    }

    double* pData    = Data;
    double* pMCData  = MC.Data;
    double* pNewData = NewData;
    for(int i=0; i<Nrow; i++)
        for(int j=0; j<NewNtime; j++)
        {
            if(j<Ncol) *pNewData++ = *pData++;
            else       *pNewData++ = *pMCData++;
        }

    delete[] Data; Data = NewData;
    Ncol = NewNtime;

/*Update filter history */
    FilterHistory   += UString("UMultiChan::Merge(MC=")        +
                       MC.GetProperties((const char*)NULL)     +
                       UString(") \n");

    return U_OK;
}

UMultiChan* UMultiChan::GetCut(int SkipSamples, int NewWidth) const
{
    if(this==NULL || error !=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCut(). Object NULL or erroneous .\n");
        return NULL;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCut(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }

    if(SkipSamples<0 || NewWidth<=0 || SkipSamples+NewWidth>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCut(). Arguments out of range: SkipSamples=%d, NewWidth=%d and Ncol=%d . \n",SkipSamples, NewWidth, Ncol);
        return NULL;
    }

    UMultiChan* MC = new UMultiChan();
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMultiChan::GetCut(). Creating output object. \n");
        return NULL;
    }
    MC->SampTime = SampTime;
    if(SensorGrid) 
    {
        MC->SensorGrid = new UGrid(*SensorGrid);
        if(MC->SensorGrid==NULL || MC->SensorGrid->GetError()!=U_OK)
        {
            delete MC;
            CI.AddToLog("ERROR: UMultiChan::GetCut(). Copying sensor grid. \n");
            return NULL;
        }
    }
    MC->MT   = MT;
    MC->Nrow = Nrow;
    MC->Ncol = NewWidth;
    MC->Data  = new double[Nrow*NewWidth];
    if(MC->Data==NULL)
    {
        delete MC;
        CI.AddToLog("ERROR: UMultiChan::GetCut(). Memory allocation: NewNtime = %d . \n", NewWidth);
        return NULL;
    }
    double* pData    = Data+SkipSamples;
    double* pNewData = MC->Data;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<NewWidth; j++) *pNewData++ = *pData++;
        pData += (Ncol-NewWidth);
    }

/*Update filter history */
    MC->FilterHistory  = FilterHistory + UString(SkipSamples, "UMultiChan::GetCut(SkipSamples=%d")
                                       + UString(NewWidth   , ", NewWidth=%d) \n");
    return MC;
}

ErrorType  UMultiChan::Cut(int SkipSamples, int NewWidth)
/*
    Cut from the existind time functions a window of width NewWidth, thereby sipping the first SkipSamples samples.
 */
{
    if(this==NULL || error !=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::Cut(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::Cut(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }

    if(SkipSamples<0 || NewWidth<=0 || SkipSamples+NewWidth>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::Cut(). Arguments out of range: SkipSamples=%d, NewWidth=%d and Ncol=%d . \n",SkipSamples, NewWidth, Ncol);
        return U_ERROR;
    }

    double* NewData  = new double[Nrow*NewWidth];
    if(NewData==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::Cut(). Memory allocation: NewWidth = %d . \n", NewWidth);
        return U_ERROR;
    }

    double* pData    = Data+SkipSamples;
    double* pNewData = NewData;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<NewWidth; j++) *pNewData++ = *pData++;
        pData += (Ncol-NewWidth);
    }

    delete[] Data; Data = NewData;
    Ncol = NewWidth;

/*Update filter history */
    FilterHistory   += UString(SkipSamples, "UMultiChan::Cut(SkipSamples=%d")
                     + UString(NewWidth   , ", NewWidth=%d) \n");

    return U_OK;
}

ErrorType  UMultiChan::MergeCut(const UMultiChan& MC, int SkipSamples, int NewWidth)
/*
    First Merge *this with MC, then apply Cut with SkipSamples and NewWidth
 */
{
    if(this==NULL) return U_ERROR;
    if(this->Merge(MC)!=U_OK)
    {
        CI.AddToLog("ERROR: MergeCut(). Applying Merge() function. \n");
        return U_ERROR;
    }
    if(this->Cut(SkipSamples, NewWidth)!=U_OK)
    {
        CI.AddToLog("ERROR: MergeCut(). Applying Cut() function. \n");
        return U_ERROR;
    }
    return U_OK;
}

ErrorType  UMultiChan::CopyData(const UMultiChan& MC, int OffsetFrom, int NCopy, int OffsetTo)
/*
    Copy part of the time functions in MC to a certain part of the time functions
    in *this.

    OffsetFrom - number of skipped samples in the time series of MC.
    NCopy      - number of copied samples
    OffsetTo   - time series' sample where the new copied samples will be inserted in *this.

    -Update History.
 */
{
    if(this==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Object NULL or not properly set.\n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Invalid data in *this object. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(MC.Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Invalid data in input UMultiChan object. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(OffsetFrom<0 || NCopy<=0 || OffsetTo<0 || OffsetFrom+NCopy>MC.Ncol || OffsetTo+NCopy>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Arguments out of range: OffsetFrom=%d, NCopy=%d, OffsetTo=%d, Ncol=%d and MC.Ncol=%d  . \n",OffsetFrom, NCopy, OffsetTo, Ncol, MC.Ncol);
        return U_ERROR;
    }
    if(SensorGrid && MC.SensorGrid && *SensorGrid != *MC.SensorGrid)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Sensorgrid is not identical to argument. \n");
        return U_ERROR;
    }
    if(Nrow != MC.Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). Number of channels are different: (%d and %d) . \n",Nrow,MC.Nrow);
        return U_ERROR;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::CopyData(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return U_ERROR;
    }

    for(int i=0; i<Nrow; i++)
    {
        double* pData   =    Data + i*   Ncol + OffsetTo;
        double* pMCData = MC.Data + i*MC.Ncol + OffsetFrom;
        for(int j=0;j<NCopy;j++)
            *pData++ = *pMCData++;
    }

/*Update filter history */
    FilterHistory  +=  UString("UMultiChan::CopyData(MC=")
                    +  MC.GetProperties((const char*)NULL)
                    +  UString(OffsetFrom, ", OffsetFrom = %d")
                    +  UString(NCopy     , ", NCopy      = %d")
                    +  UString(OffsetTo  , ", OffsetTo   = %d \n");

    return U_OK;
}

ErrorType UMultiChan::MergeChannels(const UMultiChan& MC)
/*
    Merge the channels of MC to the existing ones.
    First test wheather such merging is possible.

    -Update History.
 */
{
    if(error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::MergeChannels(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::MergeChannels(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(MC.Data==NULL) return U_OK;
    if(Data==NULL)
    {
        *this = MC;
        return error;
    }
    if(Ncol != MC.Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::MergeChannels(). Number of time samples are different: (%d and %d) . \n",Ncol, MC.Ncol);
        return U_ERROR;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::MergeChannels(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return U_ERROR;
    }

    UGrid*  NewGrid  = NULL;
    if(SensorGrid && MC.SensorGrid)
    {
        NewGrid = new UGrid(*SensorGrid);
        if(NewGrid==NULL ||
           NewGrid->GetError()!=U_OK ||
           NewGrid->AddGrid(MC.SensorGrid)!=U_OK)
        {
            delete NewGrid;
            CI.AddToLog("ERROR: UMultiChan::MergeChannels(). Merging sensor grids. \n");
            return U_ERROR;
        }
    }
    int     NewNChan = Nrow + MC.Nrow;
    double* NewData  = new double[NewNChan*Ncol];
    if(NewData==NULL)
    {
        delete NewGrid;
        CI.AddToLog("ERROR: UMultiChan::MergeChannels(). Memory allocation: NewNChan = %d . \n", NewNChan);
        return U_ERROR;
    }

    double* pData    = Data;
    double* pMCData  = MC.Data;
    double* pNewData = NewData;
    for(int ij=0; ij<   Nrow*Ncol; ij++) *pNewData++ = *pData++;
    for(int ij=0; ij<MC.Nrow*Ncol; ij++) *pNewData++ = *pMCData++;
    delete[] Data;       Data       = NewData;
    delete   SensorGrid; SensorGrid = NewGrid;
    Nrow = NewNChan;

/*Update filter history */
    FilterHistory   += UString("UMultiChan::MergeChannels(MC=") +
                       MC.GetProperties((const char*)NULL)      +
                       UString(") \n");

    return U_OK;
}

ErrorType UMultiChan::SelectChannels(const UGrid* GSelect)
/*
    Remove all channels whose names are not compatible with at least one
    of the sensors of *GSelect.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::SelectChannels(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(GSelect==NULL || GSelect->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::SelectChannels(). NULL or erroneous UGrid argument. \n");
        return U_ERROR;
    }
    if(SensorGrid==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::SelectChannels(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    int Nrem = 0;
    for(int i=0; i<Nrow; i++)
    {
        int         inew   = i-Nrem;
        const char* LabSen = SensorGrid->GetName(inew); // 04-06-07 do not use i!
        bool        Remove = true;
        for(int is=0; is<GSelect->GetNpoints(); is++)
        {
            const char* LabSel = GSelect->GetName(is);
            if(IsStringCompatible(LabSen, LabSel, false)==true)
            {
                Remove = false;
                break;
            }
        }
        if(Remove==true)
        {
            SensorGrid->RemoveSensor(inew);
            for(int ic=inew; ic<Nrow-1; ic++)
                memcpy(Data+ic*Ncol, Data+(ic+1)*Ncol, sizeof(Data[0])*Ncol);
            Nrem++;
        }
    }
    Nrow -= Nrem;

/*Update filter history */
    FilterHistory  +=  UString("UMultiChan::SelectChannels(");
    for(int is=0; is<GSelect->GetNpoints(); is++)
        FilterHistory  +=  UString(GSelect->GetName(is),"%s ,");
    FilterHistory  +=  UString(") \n");

    return U_OK;
}
ErrorType UMultiChan::ReorderChannelNames(bool HighFirst, bool GroupMemberShip)
/*
    Reorder all channels by alphabetic channel names.
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ReorderChannelNames(). NULL or erroneous object. \n");
        return U_ERROR;
    }
    if(SensorGrid==NULL || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::ReorderChannelNames(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }

    double* DataBuf = new double[Nrow];
    int* Index      = GroupMemberShip ? SensorGrid->GetGroupNameOrder(HighFirst) : SensorGrid->GetSensorNameOrder(HighFirst);
    if(Index==NULL || DataBuf==NULL)
    {
        delete[] Index; delete[] DataBuf;
        CI.AddToLog("ERROR: UMultiChan::ReorderChannelNames(). Getting sensor order or creating data buffer.\n");
        return U_ERROR;
    }
    if(SensorGrid->ReorderSensors(Index, Nrow)!=U_OK)
    {
        delete[] Index; delete[] DataBuf;
        CI.AddToLog("ERROR: UMultiChan::ReorderChannelNames().Reordering labels.\n");
        return U_ERROR;
    }
    for(int j=0; j<Ncol; j++)
    {
        for(int i=0; i<Nrow; i++) DataBuf[i]       = Data[Index[i]*Ncol+j];
        for(int i=0; i<Nrow; i++) Data  [i*Ncol+j] = DataBuf[i];
    }
    delete[] Index; delete[] DataBuf;
    return U_OK;
}


ErrorType UMultiChan::ShiftSubstract(const UMultiChan& MC, int ShiftSamples)
/*
    Shift MC over ShiftSamples samples, and substract the overlapping part (if there is)
    from this.

    -Update History.
 */
{
    if(this==NULL ||error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(&MC==NULL || MC.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }

/* Test for overlap */
    if(ShiftSamples+MC.Ncol<=0 || Ncol<=ShiftSamples) return U_OK;

/* Test object*/
    if(MC.Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Invalid data in input UMultiChan object. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Invalid data in *this object. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(SensorGrid && MC.SensorGrid && *SensorGrid != *MC.SensorGrid)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Sensorgrid is not identical to argument. \n");
        return U_ERROR;
    }
    if(Nrow != MC.Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). Number of channels are different: (%d and %d) . \n",Nrow,MC.Nrow);
        return U_ERROR;
    }
    if(fabs(SampTime-MC.SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftSubstract(). SampleTime (%f) not identical to argument (%f). \n", SampTime, MC.SampTime);
        return U_ERROR;
    }

/* Substract overlapping part */
////    int Offset   = MAX(0, ShiftSamples);
////    int OffsetMC = MAX(0,-ShiftSamples);
////    int Length   = MC.Ncol-OffsetMC;
////    if(OffsetMC==0 && Offset+Length>Ncol) Length = Ncol - Offset;

    int Offset   = 0;
    int OffsetMC = 0;
    int Length   = 0;
    if(ShiftSamples>=0)
    {
        Offset   = ShiftSamples;
        OffsetMC = 0;
        Length   = MIN(MC.Ncol, Ncol-ShiftSamples) -1;
    }
    else
    {
        Offset   = 0;
        OffsetMC = -ShiftSamples;
        Length   = MIN(Ncol, MC.Ncol+ShiftSamples) -1;
    }

    for(int i=0; i<Nrow; i++)
    {
        double* pData   =    Data + i*   Ncol + Offset  ;
        double* pMCData = MC.Data + i*MC.Ncol + OffsetMC;
        for(int j=0;j<Length;j++)
            *pData++ -= *pMCData++;
    }

/*Update filter history */
    FilterHistory  +=  UString("UMultiChan::ShiftSubstract(MC=")
                    +  MC.GetProperties((const char*)NULL)
                    +  UString(ShiftSamples          , ", ShiftSamples=%d) \n");
    return U_OK;
}
ErrorType UMultiChan::ShiftProject(const UProjector& P, int ShiftSamples)
/*
   Apply the projector P on a shifted segment of the data. Overlap may not be partial.
 */
{
    if(this==NULL ||error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). Invalid data in *this object. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(&P==NULL || P.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). Invalid UProjector argument. \n");
        return U_ERROR;
    }

/* Test for overlap */
    if(ShiftSamples+P.GetNdim()<=0 || Ncol<=ShiftSamples) return U_OK; // Not any overlap
    if( (ShiftSamples<0    && 0   <=ShiftSamples+P.GetNdim()) || 
        (ShiftSamples<Ncol && Ncol<=ShiftSamples+P.GetNdim()))
    {
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). UProjector only partly overlaps with UMultiChan. Ncol=%d, ShiftSamples=%d and P.GetNdim()=%d .\n", Ncol, ShiftSamples, P.GetNdim());
        return U_ERROR;
    }

    UMultiChan* MCut = GetCut(ShiftSamples, P.GetNdim());
    if(MCut==NULL || MCut->GetError()!=U_OK)
    {
        delete MCut;
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). Cutting data segment.\n");
        return U_ERROR;
    }
    if(P.ProjectRows(MCut)!=U_OK)
    {
        delete MCut;
        CI.AddToLog("ERROR: UMultiChan::ShiftProject(). Applying projector.\n");
        return U_ERROR;
    }

/* Replace projected segment */
    double* pData    = Data+ShiftSamples;
    double* pCutData = MCut->Data;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<MCut->Ncol; j++) *pData++ =*pCutData++;
        pData += (Ncol-MCut->Ncol);
    }
    delete MCut;

/*Update filter history */
    FilterHistory  +=  UString("UMultiChan::ShiftProject(P=")
                    +  P.GetProperties((const char*)NULL)
                    +  UString(ShiftSamples          , ", ShiftSamples=%d) \n");
    return U_OK;
}

const UString& UMultiChan::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString("ERROR in parameters of UMultiChan() object.");
        return Properties;
    }
    Properties = UString();
    UString     End(";");
    UString     Beg(" ");
    if(Comment.IsEmpty()==false && Comment.IsNULL()==false)
    {
        Beg = UString(Comment);
        End = UString("\n");
    }

    Properties += Beg + UString(SampTime, "SampleTime = %f ") + End;
    Properties += Beg + UString(Nrow   , "Nrow = %d ")      + End;
    Properties += Beg + UString(Ncol   , "Ncol = %d ")      + End;

    if(SensorGrid) Properties += Beg + UString("SensorGridSet = TRUE  ") + End;
    else           Properties += Beg + UString("SensorGridSet = FALSE ") + End;

    return Properties;
}

UMultiChan* Merge(const UMultiChan& MC1, const UMultiChan& MC2)
{
    if(&MC1==NULL || &MC2==NULL)
    {
        CI.AddToLog("ERROR: Merge(). Invalid NULL addreses of at least one of the arguments. \n");
        return NULL;
    }
    UMultiChan* MC = new UMultiChan(MC1);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: Merge(). Creating copy of MC1. \n");
        return NULL;
    }
    if(MC->Merge(MC2)!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: Merge(). Merging MC2. \n");
        return NULL;
    }
    return MC;
}

UMultiChan* MergeCut(const UMultiChan& MC1, const UMultiChan& MC2, int SkipSamples, int NewWidth)
{
    UMultiChan* MC = Merge(MC1, MC2);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: MergeCut(). Merging arguments MC1 and MC2. \n");
        return NULL;
    }
    if(MC->Cut(SkipSamples, NewWidth)!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: MergeCut(). Cutting samples from merged MC1 and MC2. \n");
        return NULL;
    }
    return MC;
}

double UMultiChan::GetShiftedCorrelation(const UMultiChan* Templ, int Shift, int Skip) const
/*
    return the correlation co-efficient between *this andthe template *Templ, where *this
    is shifted over Shift samples. In computing the correlation co-efficient, the first and
    last Skip samples are skipped.

    On error, return 0.
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetShiftedCorrelation(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetShiftedCorrelation(). Invalid UMultiChannel argument. \n");
        return 0.;
    }
    if(Nrow != Templ->Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::GetShiftedCorrelation(). Number of channels are different: (%d and %d) . \n",Nrow,Templ->Nrow);
        return 0.;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::GetShiftedCorrelation(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return 0.;
    }
    if(Skip<0 ||  abs(Shift)>Skip || 2*Skip>=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). Shift (%d) or Shift (%d) out of range. (Ncol= %d), \n", Shift, Skip, Ncol);
        return 0.;
    }

    double* SData = Data+Shift;
    double* TData = Templ->Data;
    double F11 = 0;
    double F12 = 0;
    double F22 = 0;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=Skip; j<Ncol-Skip; j++)
        {
            F11 += SData[i*Ncol+j]*SData[i*Ncol+j];
            F12 += SData[i*Ncol+j]*TData[i*Ncol+j];
            F22 += TData[i*Ncol+j]*TData[i*Ncol+j];
        }
    }
    double Cor = F12*F12;
    if(F11>0. && F22>0.) Cor = Cor /(F11*F22);
    return Cor;
}

int UMultiChan::GetMaxCorrelatedShift(const UMultiChan* Templ, int MaxShift, double* BestCor) const
/*
    Compute (and return) the best shift , between -MaxShift and +MaxShift,
    that maximizes the correlation between *this and *Templ.

    DO NOT apply this optimal shift to *this (as opposed to MaxCorrelatedSubShift())

    if(BestCor  ) *BestCor will contain the best correlation

    on ERROR, return 0
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxCorrelatedShift(). Object not properly set. History = %s .\n", FilterHistory);
        return 0;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxCorrelatedShift(). Invalid UMultiChannel argument. \n");
        return 0;
    }
    if(Nrow != Templ->Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxCorrelatedShift(). Number of channels are different: (%d and %d) . \n",Nrow,Templ->Nrow);
        return 0;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxCorrelatedShift(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return 0;
    }
    if(SensorGrid && Templ->SensorGrid && *SensorGrid != *(Templ->SensorGrid))
    {
        CI.AddToLog("WARNING: UMultiChan::GetMaxCorrelatedShift(). Sensorgrid is not identical to argument. \n");
    }
    if(MaxShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxCorrelatedShift(). MaxShift parameter out of range: MaxShift = %d \n", MaxShift);
        return 0;
    }

    double Cor   = 0.;
    int    kmin  = 0;

    for(int k=-MaxShift; k<=MaxShift; k++)
    {
        double Cortest = GetShiftedCorrelation(Templ, k, MaxShift);
        if(Cortest>Cor)
        {
            Cor   = Cortest;
            kmin  = k;
        }
    }
    if(BestCor  ) *BestCor   = Cor;

    return kmin;
}

UMultiChan* UMultiChan::GetNormalizedCovariance(const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double* ResErr, TimeShiftType TST) const
/*
    Compute the normalized and shifted cross-covariance between each channel of *this and
    the time function in *Templ. Time shifts are obtained by shifting *Templ between MinShift and MaxShift [s] over
    NShift pieces.

    Notes:
    -Assume (and test) that *Templ is single channel template
    -Assume (and test) that the number of time samples and sampling rate of *this and *Templ are equal.
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Object not properly set. History = %s .\n", FilterHistory);
        return NULL;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Invalid UMultiChannel argument. \n");
        return NULL;
    }
    if(Templ->Nrow!=1)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Number of channels in *Templ should be 1, not %d  .\n", Templ->Nrow);
        return NULL;
    }
    if(Ncol != Templ->Ncol) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Number of time samples are different: (%d and %d) . \n",Ncol,Templ->Ncol);
        return NULL;
    }
    if(MinShift>=MaxShift || NShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Shift parameters out of range: MinShift=%f, MaxShift=%f and NShift=%d   .\n", MinShift, MaxShift, NShift);
        return NULL;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return NULL;
    }

    double* ShiftCov = new double[Nrow*NShift];
    if(ShiftCov==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Memory allocation, Nrow = %d, NShift = %d. \n", Nrow, NShift);
        return NULL;
    }
    for(int ij=0; ij<Nrow*NShift; ij++) ShiftCov[ij] = 0.;
    int jmin = 0; if(MinShift<0) jmin = -(int)floor(MinShift/SampTime);
    int jmax = 0; if(MaxShift>0) jmax =  (int)floor(MaxShift/SampTime);

    for(int j=0; j<NShift; j++)
    {
        double Shift = MinShift + j*(MaxShift-MinShift)/NShift;
        UMultiChan MC(*Templ);
        MC.ShiftData(Shift, TST);

        double Norm  = 0.;
        double Norm2 = 0.;
        for(int jj=jmin; jj<Ncol-jmax; jj++) Norm2 += MC.Data[jj]*MC.Data[jj];
        if(Norm2<=0.) continue;
        Norm = sqrt(Norm2);

        double Hres    = 0.; // residual error
        double DatNorm = 0.; // data norm
        for(int i=0; i<Nrow; i++)
        {
            double Cov  = 0;
            int jj = jmin;
            for(         ; jj<Ncol-jmax; jj++) Cov += Data[i*Ncol+jj] * MC.Data[jj];

            ShiftCov[i*NShift+j] = Cov/Norm;
            double CovNorm2      = Cov/Norm2;
            jj = jmin;
            for(     ; jj<Ncol-jmax; jj++)
            {
                double term  = (Data[i*Ncol+jj] - CovNorm2*MC.Data[jj]);
                Hres        += term*term;
                DatNorm     += Data[i*Ncol+jj]*Data[i*Ncol+jj];
            }
        }
        if(ResErr) ResErr[j] = Hres/DatNorm;
    }

    UMultiChan* Output = new UMultiChan(ShiftCov, SensorGrid, NShift, (MaxShift-MinShift)/NShift);
    delete[] ShiftCov;
    if(Output==NULL || Output->GetError()!=U_OK)
    {
        delete Output;
        CI.AddToLog("ERROR: UMultiChan::GetNormalizedCovariance(). Creating MultiChan-object. \n");
        return NULL;
    }
    return Output;
}


double UMultiChan::GetCorrelation(const UMultiChan* Templ, int skipbegin, int skipend) const
/*
    return the correlation co-efficient between *this andthe template *Templ.
    In this computation, skip the first skipbegin samples from the beginning of each timeseries,
    and skipend from the and.

    On error, return 0.
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). Invalid UMultiChannel argument. \n");
        return 0.;
    }
    if(Nrow != Templ->Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). Number of channels are different: (%d and %d) . \n",Nrow,Templ->Nrow);
        return 0.;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return 0.;
    }
    if(skipbegin<0 || skipend<0 || skipbegin+skipend>=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetCorrelation(). skipbegin (%d) and or skipend (%d) out of range. (Ncol= %d), \n",skipbegin, skipend, Ncol);
        return 0.;
    }

    double* TData = Templ->Data;
    double F11 = 0;
    double F12 = 0;
    double F22 = 0;
    for(int i=0; i<Nrow; i++)
    {
        for(int j=skipbegin; j<Ncol-skipend; j++)
        {
            F11 += Data [i*Ncol+j]* Data[i*Ncol+j];
            F12 += Data [i*Ncol+j]*TData[i*Ncol+j];
            F22 += TData[i*Ncol+j]*TData[i*Ncol+j];
        }
    }
    double Cor = F12*F12;
    if(F11>0. && F22>0.) Cor = Cor /(F11*F22);
    return Cor;
}

ErrorType UMultiChan::MaxCorrelatedSubShift(const UMultiChan* Templ, int SampleSub, double* BestShift, double* BestCor, int* BestIndex, TimeShiftType TST)
{
    return MaxCorrelatedSubShift(Templ, 1, SampleSub, BestShift, BestCor, BestIndex, TST);
}

ErrorType UMultiChan::MaxCorrelatedSubShift(const UMultiChan* Templ, int MaxShift, int SampleSub, double* BestShift, double* BestCor, int* BestIndex, TimeShiftType TST)
/*
    Shift *this MultiChan-object in time, in such a way that it is maximally correlated with the
    template *Templ. Compute this optimum by shifting MaxShift samples to the left to MaxShift samples
    to the right, in steps of SampTime/SampleSub.

    if(BestShift) *BestShift will contain the best shift in s.
    if(BestCor  ) *BestCor will contain the best correlation
    if(BestIndex) *BestIndex will contain the best shift, in terms of multiple of SampTime/SampleSub
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(Nrow != Templ->Nrow) // could happen if grids are not set.
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). Number of channels are different: (%d and %d) . \n",Nrow,Templ->Nrow);
        return U_ERROR;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return U_ERROR;
    }
    if(SensorGrid && Templ->SensorGrid && *SensorGrid != *(Templ->SensorGrid))
    {
        CI.AddToLog("WARNING: UMultiChan::MaxCorrelatedSubShift(). Sensorgrid is not identical to argument. \n");
    }
    if(MaxShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). MaxShift parameter out of range: MaxShift = %d \n", MaxShift);
        return U_ERROR;
    }
    if(SampleSub<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::MaxCorrelatedSubShift(). Sample subdivision parameter out of range: SampleSub = %d \n", SampleSub);
        return U_ERROR;
    }

    double Cor   = 0.;
    int    kmin  = 0;
    UMultiChan MC(*this);
    MC.ShiftData(-SampTime*MaxShift, TST);

    for(int k=-SampleSub*MaxShift; k<=SampleSub*MaxShift; k++)
    {
        double Cortest = MC.GetCorrelation(Templ, MaxShift, MaxShift);
        if(Cortest>Cor)
        {
            Cor   = Cortest;
            kmin  = k;
        }
        MC.ShiftData(SampTime/SampleSub, TST);
    }
    double Shift = kmin*SampTime/SampleSub;
    ShiftData(Shift, TST);
    if(BestShift) *BestShift = Shift;
    if(BestCor  ) *BestCor   = Cor;
    if(BestIndex) *BestIndex = kmin;

/*Update filter history */
    FilterHistory += UString("UMultiChan::MaxCorrelatedSubShift(*Templ=")
                   + Templ->GetProperties((const char*)NULL)
                   + UString(MaxShift  , ", MaxShift = %d")
                   + UString(SampleSub , ", SampleSub = %d")
                   + UString(Shift     , ", *BestShift = %f")
                   + UString(Cor       , ", *BestCor = %f")
                   + UString(kmin      , ", *BestIndex = %d) \n");
    return U_OK;
}

double* UMultiChan::GetMinDatChan(bool Fabs) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinDatChan(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinDatChan(). SensorGrid==NULL or Dat==NULL. \n");
        return NULL;
    }
    double* MinDat = new double[Nrow];
    if(MinDat==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMinDatChan(). Allocating memory for output array. \n");
        return NULL;
    }

/* Compute minimum per channel*/
    for(int i=0; i<Nrow; i++)
    {
        MinDat[i] = Data[i*Ncol];         if(Fabs) MinDat[i] = fabs(MinDat[i]);

        for(int j=0; j<Ncol; j++)
        {
            double Test = Data[i*Ncol+j]; if(Fabs) Test      = fabs(Test);
            MinDat[i]   = MIN(Test, MinDat[i]);
        }
    }
    return MinDat;
}
double* UMultiChan::GetMaxDatChan(bool Fabs) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxDatChan(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxDatChan(). SensorGrid==NULL or Dat==NULL. \n");
        return NULL;
    }
    double* MaxDat = new double[Nrow];
    if(MaxDat==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMaxnDatChan(). Allocating memory for output array. \n");
        return NULL;
    }

/* Compute maximum per channel*/
    for(int i=0; i<Nrow; i++)
    {
        MaxDat[i] = Data[i*Ncol];         if(Fabs) MaxDat[i] = fabs(MaxDat[i]);

        for(int j=0; j<Ncol; j++)
        {
            double Test = Data[i*Ncol+j]; if(Fabs) Test      = fabs(Test);
            MaxDat[i]   = MAX(Test, MaxDat[i]);
        }
    }
    return MaxDat;
}

double* UMultiChan::GetLRSymmetryAsTime(void) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetLRSymmetryAsTime(). Object NULL or erroneous. \n");
        return NULL;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetLRSymmetryAsTime(). SensorGrid==NULL or Dat==NULL. \n");
        return NULL;
    }
    double* LRCorPat = new double[Ncol];
    if(LRCorPat==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetLRSymmetryAsTime(). Allocating memory for output array. \n");
        return NULL;
    }
    for(int j=0; j<Ncol; j++) LRCorPat[j] = 0.;

    for(int j=0; j<Ncol; j++)
    {
        int    Npair    = 0;
        double AverR    = 0.;
        double AverL    = 0.;
        double AverR2   = 0.;
        double AverL2   = 0.;
        double AverLR   = 0.;

        for(int i1=0; i1<Nrow; i1++)
        {
            int i2 = SensorGrid->GetLeftHomologueIndex(i1);
            if(i2<0 || i1==i2) continue;

            Npair++;
            AverR  += Data[i1*Ncol + j];
            AverL  += Data[i2*Ncol + j];
            AverR2 += Data[i1*Ncol + j]*Data[i1*Ncol + j];
            AverL2 += Data[i2*Ncol + j]*Data[i2*Ncol + j];
            AverLR += Data[i2*Ncol + j]*Data[i1*Ncol + j];
        }
        if(Npair>0)
        {
            AverR  /= Npair;
            AverL  /= Npair;
            AverR2 -= Npair * AverR * AverR;
            AverL2 -= Npair * AverL * AverL;
            AverLR -= Npair * AverL * AverR;
            LRCorPat[j] = 0.;
            if(AverR2>0. && AverL2>0.) LRCorPat[j] = AverLR/sqrt(AverR2*AverL2);
        }
        else
        {
            CI.AddToLog("WARNING: UMultiChan::GetLRSymmetryAsTime(). No symmetric counterparts detected. \n");
            return LRCorPat;
        }
    }
    return LRCorPat;
}

ErrorType UMultiChan::RegressAllChan(const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double** Coeff, double** Shift, TimeShiftType TST) const
/*
    Compute the regression between all channels of *this and the signals in *Templ. Do so, by shifting Templ
    in NShift steps from MinShift to MaxShift.
    if(Coeff) *Coeff will contain a new pointer with the regression Templ->Nchan coefficients of all Nrow channels.
    if(Shift) *Shift will contain a new pointer with all shifts in s.

    Time shifts are obtained by shifting *Templ between MinShift and MaxShift [s] over NShift pieces.

    Note:
    -Assume (and test) that the number of time samples and sampling rate of *this and *Templ are equal.
 */
{
    if(Coeff) *Coeff = NULL;
    if(Shift) *Shift = NULL;

    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL || Templ->Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(Ncol != Templ->Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Number of time samples are different: (%d and %d) . \n",Ncol,Templ->Ncol);
        return U_ERROR;
    }
    if(MinShift>=MaxShift || NShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Shift parameters out of range: MinShift=%f, MaxShift=%f and NShift=%d   .\n", MinShift, MaxShift, NShift);
        return U_ERROR;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return U_ERROR;
    }

    double* Co = new double[Nrow*Templ->Nrow];
    double* Sh = new double[Nrow];
    if(Co==NULL || Sh==NULL)
    {
        delete[] Co;
        delete[] Sh;
        CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Memory allocation, Nrow = %d, Templ->Nrow = %d. \n", Nrow, Templ->Nrow);
        return U_ERROR;
    }

    for(int i=0; i<Nrow; i++)
    {
        double* pCoef     = NULL;
        double  BestShift = 0;
        if(RegressChan(i, Templ, MinShift,MaxShift, NShift, &pCoef, &BestShift, TST)!=U_OK)
        {
            delete[] Co;
            delete[] Sh;
            CI.AddToLog("ERROR: UMultiChan::RegressAllChan(). Computing regression in channel %d \n", i);
            return U_ERROR;
        }

        for(int k=0; k<Templ->Nrow; k++) Co[i*Templ->Nrow + k] = pCoef[k];
        delete[] pCoef;
        Sh[i] = BestShift;
    }
    if(Coeff) *Coeff = Co; else delete[] Co;
    if(Shift) *Shift = Sh; else delete[] Sh;

    return U_OK;
}

ErrorType UMultiChan::RegressChan(int ichan, const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double** Coeff, double* BestShift, TimeShiftType TST) const
/*
    Compute the regression between channel ichan of *this and the signals in *Templ. Do so, by shifting Templ
    in NShift steps from MinShift to MaxShift.
    if(Coeff    ) *Coeff     will contain a new pointer with the regression Templ->Nchan coefficients of all Nrow channels.
    if(BestShift) *BestShift will contain the best shift in s.

    Time shifts are obtained by shifting *Templ between MinShift and MaxShift [s] over NShift pieces.

    Note:
    -Assume (and test) that the number of time samples and sampling rate of *this and *Templ are equal.
 */
{
    if(Coeff)     *Coeff     = NULL;
    if(BestShift) *BestShift = 0.;

    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Object not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return U_ERROR;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL || Templ->Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Invalid UMultiChannel argument. \n");
        return U_ERROR;
    }
    if(Ncol != Templ->Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Number of time samples are different: (%d and %d) . \n",Ncol,Templ->Ncol);
        return U_ERROR;
    }
    if(MinShift>=MaxShift || NShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Shift parameters out of range: MinShift=%f, MaxShift=%f and NShift=%d   .\n", MinShift, MaxShift, NShift);
        return U_ERROR;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return U_ERROR;
    }

    double* Co = new double[Templ->Nrow];
    double  Sh = 0.;

    if(Co==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Memory alocation. \n");
        return U_ERROR;
    }

    int    jmin   = -(int)floor(MinShift/SampTime);
    int    jmax   =  (int)floor(MaxShift/SampTime);
    int    jShift = MAX(jmax, -jmin);

    double Res  = 0.;
    for(int j=0; j<NShift; j++)
    {
        double  Shift = MinShift + j*(MaxShift-MinShift)/NShift;
        UMultiChan MC(*Templ);
        MC.ShiftData(Shift, TST);

        double* pCoef = NULL;
        if(j==0)
        {
            Res = RegressChan(ichan, &MC, &pCoef, jShift, jShift);
            if(pCoef==NULL)
            {
                delete[] Co;
                CI.AddToLog("ERROR: UMultiChan::RegressChan(). Computing regression of shifted template on channel %d, shift = %d .\n", ichan, j);
                return U_ERROR;
            }
            for(int k=0; k<MC.Nrow; k++) Co[k] = pCoef[k];
            delete[] pCoef;
            continue;
        }

        double Test = RegressChan(ichan, &MC, &pCoef, jShift, jShift);
        if(pCoef==NULL)
        {
            delete[] Co;
            CI.AddToLog("ERROR: UMultiChan::RegressChan(). Computing regression of shifted template on channel %d, shift = %d .\n", ichan, j);
            return U_ERROR;
        }
        if(Test<Res)
        {
            Res = Test;
            Sh  = Shift;
            for(int k=0; k<MC.Nrow; k++) Co[k] = pCoef[k];
        }
        delete[] pCoef;
    }
    if(Coeff    ) *Coeff     = Co; else delete[] Co;
    if(BestShift) *BestShift = Sh;

    return U_OK;
}

double UMultiChan::RegressChan(int ichan, const UMultiChan* Templ, double** Coeff, int SkipFirst, int SkipLast) const
/*
    Compute the regression between channel ichan of *this and the signals in *Templ.
    Return the residual error of this regression.
    Compute the regression over the interval (MAX(0, SkipFirst), Ncol-MAX(0, SkipLast))

    On error, return 100.

    if(Coeff    ) *Coeff     will contain a new pointer with the regression Templ->Nchan coefficients of all Nrow channels.

    Note:
    -Assume (and test) that the number of time samples and sampling rate of *this and *Templ are equal.
 */
{
    const double ResERROR = 100.;

    if(Coeff) *Coeff = NULL;

    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Object not properly set. History = %s .\n", FilterHistory);
        return ResERROR;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return ResERROR;
    }
    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL || Templ->Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Invalid UMultiChannel argument. \n");
        return ResERROR;
    }
    if(Ncol != Templ->Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Number of time samples are different: (%d and %d) . \n",Ncol,Templ->Ncol);
        return ResERROR;
    }
    if(fabs(SampTime-Templ->SampTime)>1.e-5)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). SampleTime (%f) not identical to argument (%f). \n", SampTime, Templ->SampTime);
        return ResERROR;
    }
    if(SkipFirst<0) SkipFirst = 0;
    if(SkipLast <0) SkipLast  = 0;
    if(SkipFirst>=Ncol-SkipLast)
    {
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Too many samples skipped: SkipFirst = %d, SkipLast = %d .\n", SkipFirst, SkipLast);
        return ResERROR;
    }

    int     Nfunc  = Templ->GetNChan();
    double* Matrix = new double[Nfunc*Nfunc];
    double* Norm   = new double[Nfunc];
    double* pCoef  = new double[Nfunc];
    double* RHS    = new double[Nfunc];
    if(Matrix==NULL || Norm==NULL || pCoef==NULL || RHS==NULL)
    {
        delete[] Matrix;
        delete[] Norm;
        delete[] pCoef;
        delete[] RHS;
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). Memory allocation, Nfunc = %d  .\n", Nfunc);
        return ResERROR;
    }
    for(int k=0; k<Nfunc; k++)
    {
        Norm[k] = 0.;
        for(int j=SkipFirst; j<Ncol-SkipLast-1; j++)
            Norm[k]    += Templ->Data[k*Ncol+j]*Templ->Data[k*Ncol+j];

        if(Norm[k]>0.)
            Norm[k] = sqrt( Norm[k] );
        else
        {
            delete[] Matrix;
            delete[] pCoef;
            delete[] Norm;
            delete[] RHS;
            CI.AddToLog("ERROR: UMultiChan::RegressChan(). Template function %d identically zero.  \n", k);
            return ResERROR;
        }

        RHS[k]  = 0.;
        for(int j=SkipFirst; j<Ncol-SkipLast-1; j++)
            RHS[k]    += Data[ichan*Ncol+j]    *Templ->Data[k*Ncol+j];
        RHS[k] /= Norm[k];
    }
    for(int k1=0; k1<Nfunc; k1++)
    {
        for(int k2=0; k2<Nfunc; k2++)
        {
            if(k2>=k1)
            {
                Matrix[k1*Nfunc+k2] = 0.;
                for(int j=SkipFirst; j<Ncol-SkipLast-1; j++)
                    Matrix[k1*Nfunc+k2] += Templ->Data[k1*Ncol+j] * Templ->Data[k2*Ncol+j];

                Matrix[k1*Nfunc+k2] /= Norm[k1]*Norm[k2];
            }
            else
            {
                Matrix[k1*Nfunc+k2] = Matrix[k2*Nfunc+k1];
            }
        }
    }

    double det = 0;
    if(daxisb_c(Matrix, pCoef, RHS, Nfunc, Nfunc, &det))
    {
        delete[] Matrix;
        delete[] Norm;
        delete[] pCoef;
        delete[] RHS;
        CI.AddToLog("ERROR: UMultiChan::RegressChan(). System matrix not positive. \n");
        return ResERROR;
    }
    for(int k=0; k<Nfunc; k++) pCoef[k] /= Norm[k];

    double Res = 0.;
    double No  = 0.;
    for(int j=SkipFirst; j<Ncol-SkipLast-1; j++)
    {
        double Term = Data[ichan*Ncol+j];
        No  += Term*Term;

        for(int k=0; k<Nfunc; k++) Term -= pCoef[k] * Templ->Data[k*Ncol+j];

        Res += Term * Term;
    }
    if(No>0) Res /= No;
    else     CI.AddToLog("WARNING: UMultiChan::RegressChan(). Channel %d identically zero. \n", ichan);

    if(Coeff) *Coeff = pCoef; else delete[] pCoef;

    return Res;
}

double UMultiChan::GetFrequency(int ichan, double* ResError) const
/*
    Return the best fitting frequency of channel ichan in Hz
    if(ResError) *ResError will contain the residual error
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFrequency(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFrequency(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return 0.;
    }

    double* data = new double[2*Ncol];
    if(data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFrequency(). Memory allocation, Ncol = %d .\n", Ncol);
        return 0.;
    }
    UGrid   G(2);
    UMultiChan Templ(data, &G, Ncol, SampTime);
    delete[] data;
    if(Templ.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFrequency(). Setting template. \n");
        return 0.;
    }

    double Freq   = 0;
    double ResMin = 100.;
    for(int k=1; k<Ncol/2; k++)
    {
        double Omk = k*PI2/(double)(Ncol);
        for(int j=0; j<Ncol; j++) Templ.Data[      j] = cos(j*Omk);
        for(int j=0; j<Ncol; j++) Templ.Data[Ncol+j] = sin(j*Omk);
        double Test = RegressChan(ichan, &Templ, NULL, 0, 0);
        if(Test<ResMin)
        {
            ResMin = Test;
            Freq   = Omk/(PI2*SampTime);
        }
    }
    if(ResError) *ResError = ResMin;
    return Freq;
}

double UMultiChan::GetAmplitudeFactor(const UMultiChan* Templ, double ChanOutlierMedianFactor) const
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }

    if(Templ==NULL || Templ->GetError()!=U_OK || Templ->Data==NULL || Templ->Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Invalid UMultiChannel argument. \n");
        return 0.;
    }
    if(Ncol != Templ->Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Number of time samples are different: (%d and %d) . \n",Ncol,Templ->Ncol);
        return 0.;
    }
    if(Nrow != Templ->Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Number of time channels are different: (%d and %d) . \n",Nrow,Templ->Nrow);
        return 0.;
    }

    double* RMSArray     = NULL;
    double  RMSThreshold = 0;
    if(ChanOutlierMedianFactor>0)
    {
        RMSArray = new double[Nrow];
        if(RMSArray==NULL)
        {
            CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Memory allocation. \n");
            return 0.;
        }
        for(int i=0; i<Nrow; i++) RMSArray[i] = GetRMS(i);

        RMSThreshold = ChanOutlierMedianFactor*GetMedian(RMSArray, Nrow);
    }

    double ThisTemp = 0;
    double TempTemp = 0;

    int NBAD = 0;
    for(int i=0; i<Nrow; i++)
    {
        if(RMSArray && RMSArray[i]>RMSThreshold)
        {
            NBAD++;
            continue;
        }
        for(int j=0; j<Ncol; j++)
        {
            ThisTemp +=        Data[i*Ncol+j] * Templ->Data[i*Ncol+j];
            TempTemp += Templ->Data[i*Ncol+j] * Templ->Data[i*Ncol+j];
        }
    }
    delete[] RMSArray;

    if(TempTemp<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAmplitudeFactor(). Too many bad channels? NBAD = %d. \n", NBAD);
        return 0;
    }
    return ThisTemp/TempTemp;
}

double UMultiChan::GetRMS(int ichan) const
/*
    Return the RMS of channel ichan
 */
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetRMS(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetRMS(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return 0.;
    }
    if(Ncol<=0) return 0.;

    double RMS = 0.;
    for(int j=0; j<Ncol; j++)
    {
        double Term = Data[ichan*Ncol+j];
        RMS += Term*Term;
    }
    RMS /= Ncol;
    return sqrt(fabs(RMS));
}

double UMultiChan::GetRMStime(int jsamp) const
{
    if(error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetRMStime(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(jsamp<0 || jsamp>=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetRMStime(). Erroneous sample number, jsamp = %d, Ncol = %d.\n", jsamp, Ncol);
        return 0.;
    }
    if(Nrow<=0) return 0.;

    double RMS = 0.;
    for(int i=0; i<Nrow; i++)
    {
        double Term = Data[i*Ncol+jsamp];
        RMS += Term*Term;
    }
    RMS /= Nrow;
    return sqrt(fabs(RMS));
}

bool UMultiChan::IsAnySampleSuperThreshold(double Thresh) const
{
    if(this == NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::IsAnySampleSuperThreshold(). This == NULL .\n");
        return false;
    }
    if(error !=U_OK || Data==NULL || SampTime==0)
    {
        CI.AddToLog("ERROR: UMultiChan::IsAnySampleSuperThreshold(). Object not properly set. History = %s .\n", FilterHistory);
        return false;
    }
    if(Thresh==0.) return true;

    if(Thresh<0)
    {
        for(int ij=0; ij<Ncol*Nrow; ij++) if(Data[ij]<Thresh) return true;
    }
    else
    {
        for(int ij=0; ij<Ncol*Nrow; ij++) if(Data[ij]>Thresh) return true;
    }
    return false;
}


double UMultiChan::GetTimeMaxRMS(double Tmin, double Tmax, int ichan, double* RMS) const
/*
    Return the time at which the RMS of channel ichan is maximum.
    if ichan<0 compute RMS over all channels

    On error return 0;
 */
{
    if(this == NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxRMS(). This == NULL .\n");
        return 0.;
    }
    if(error !=U_OK || Data==NULL || SampTime==0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxRMS(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxRMS(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return 0.;
    }
    if(Tmin>Tmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxRMS(). Erroneous Tmin, Tmax (%f,%f)  \n", Tmin, Tmax);
        return 0.;
    }
    if(Ncol==0)
    {
        if(RMS) *RMS = 0.;
        return 0.;
    }
    int jmin = (int)floor(Tmin/SampTime);
    if(jmin<0 || jmin>= Ncol)
    {
        jmin = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMaxRMS(). Tmin, out of range  \n", Tmin);
    }
    int jmax = 1+(int)floor(Tmax/SampTime);
    if(jmax<0 || jmax>= Ncol)
    {
        jmax = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMaxRMS(). Tmax, out of range  \n", Tmax);
    }
    int icmin = ichan;
    int icmax = ichan+1;
    if(ichan<0)
    {
        icmin = 0;
        icmax = Nrow;
    }

    int    jbest   = jmin;
    double RMSbest = 0.;
    for(int j=jmin; j<jmax; j++)
    {
        double Test = 0;
        for(int i=icmin; i<icmax; i++)
        {
            double Term = Data[i*Ncol+j];
            Test += Term*Term;
        }
        if(Test>RMSbest)
        {
            RMSbest = Test;
            jbest   = j;
        }
    }
    RMSbest /= Nrow;

    if(RMS) *RMS = sqrt(RMSbest);
    return jbest*SampTime;
}

double UMultiChan::GetTimeMaxValue(double Tmin, double Tmax, int ichan, double* Value) const
/*
    Return the time at which the Valus of channel ichan is maximum.
    if ichan<0 compute the time on which the maximum over all channels is maximum

    On error return 0;
 */
{
    if(this == NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxValue(). This == NULL .\n");
        return 0.;
    }
    if(error !=U_OK || Data==NULL || SampTime==0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxValue(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxValue(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return 0.;
    }
    if(Tmin>Tmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMaxValue(). Erroneous Tmin, Tmax (%f,%f)  \n", Tmin, Tmax);
        return 0.;
    }
    if(Ncol==0)
    {
        if(Value) *Value = 0.;
        return 0.;
    }
    int jmin =   (int)floor(Tmin/SampTime);
    if(jmin<0 || jmin>= Ncol)
    {
        jmin = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMaxValue(). Tmin, out of range  \n", Tmin);
    }
    int jmax = 1+(int)floor(Tmax/SampTime);
    if(jmax<0 || jmax>= Ncol)
    {
        jmax = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMaxValue(). Tmax, out of range  \n", Tmax);
    }
    int icmin = ichan;
    int icmax = ichan+1;
    if(ichan<0)
    {
        icmin = 0;
        icmax = Nrow;
    }

    int    jbest     = jmin;
    double Valuebest = Data[icmin*Ncol+jmin];
    for(int j=jmin; j<jmax; j++)
    {
        double Test = Data[icmin*Ncol+j];
        for(int i=icmin; i<icmax; i++)
        {
            double Term = Data[i*Ncol+j];
            Test = MAX(Term, Test);
        }
        if(Test>Valuebest)
        {
            Valuebest = Test;
            jbest     = j;
        }
    }

    if(Value) *Value = Valuebest;
    return jbest*SampTime;
}

double UMultiChan::GetTimeMinValue(double Tmin, double Tmax, int ichan, double* Value) const
/*
    Return the time at which the Valus of channel ichan is minimum.
    if ichan<0 compute the time on which the minimum over all channels is minimum

    On error return 0;
 */
{
    if(this == NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMinValue(). This == NULL .\n");
        return 0.;
    }
    if(error !=U_OK || Data==NULL || SampTime==0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMinValue(). Object not properly set. History = %s .\n", FilterHistory);
        return 0.;
    }
    if(ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMinValue(). Erroneous channel number, ichan = %d, Nrow = %d.\n", ichan, Nrow);
        return 0.;
    }
    if(Tmin>Tmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetTimeMinValue(). Erroneous Tmin, Tmax (%f,%f)  \n", Tmin, Tmax);
        return 0.;
    }
    if(Ncol==0)
    {
        if(Value) *Value = 0.;
        return 0.;
    }
    int jmin =   (int)floor(Tmin/SampTime);
    if(jmin<0 || jmin>= Ncol)
    {
        jmin = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMinValue(). Tmin, out of range  \n", Tmin);
    }
    int jmax = 1+(int)floor(Tmax/SampTime);
    if(jmax<0 || jmax>= Ncol)
    {
        jmax = MAX(0, MIN(Ncol, jmin));
        CI.AddToLog("WARNING: UMultiChan::GetTimeMinValue(). Tmax, out of range  \n", Tmax);
    }
    int icmin = ichan;
    int icmax = ichan+1;
    if(ichan<0)
    {
        icmin = 0;
        icmax = Nrow;
    }

    int    jbest     = jmin;
    double Valuebest = Data[icmin*Ncol+jmin];
    for(int j=jmin; j<jmax; j++)
    {
        double Test = Data[icmin*Ncol+j];
        for(int i=icmin; i<icmax; i++)
        {
            double Term = Data[i*Ncol+j];
            Test = MIN(Term, Test);
        }
        if(Test<Valuebest)
        {
            Valuebest = Test;
            jbest     = j;
        }
    }

    if(Value) *Value = Valuebest;
    return jbest*SampTime;
}

ErrorType UMultiChan::RemoveReferenceComponents(int NSVDcomp, double BandRefLayerLow, double BandRefLayerHigh)
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Object NULL or not properly set.\n");
        return U_ERROR;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). SensorGrid NULL or not properly set.\n");
        return U_ERROR;
    }
    if(NSVDcomp==0) return U_OK;
    if(NSVDcomp<0)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Parameter out of range: NSVDcomp =%d.\n", NSVDcomp);
        return U_ERROR;
    }
    if(ComputeGroupReference()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Computing rereference.\n");
        return U_ERROR;
    }
    if(BandRefLayerLow>=0. && BandRefLayerHigh>0. && BandRefLayerHigh>BandRefLayerLow)
    {
        double Fsamp = SampTime >0. ? 1./SampTime : 0.;
        ULinearFilter Filt(Fsamp);
        Filt.SetFilter(BandRefLayerLow, BandRefLayerHigh, U_PREP_OFFSET,U_POWERLINE_NO, 0., 1.);
        if(ApplyLinearFilter(Filt)!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Applying bandpass filter.\n");
            return U_ERROR;
        }
    }
    bool* Iref = new bool[Nrow];
    if(Iref==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Memory allocation, Nrow =%d .\n", Nrow);
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++) Iref[i] = false;
    int NRef = 0;
    for(int i=0; i<Nrow; i++)
    {
        if(UGrid::IsStandardREFLabelRefLay(SensorGrid->GetName(i))==false) continue;
        Iref[i] = true;
        NRef++;
    }
    if(NRef<NSVDcomp||Ncol<=NRef)
    {
        delete[] Iref;
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Number of reference channels out of range: NRef=%d, NSVDcomp=%d, Ncol=%d .\n", NRef, NSVDcomp, Ncol);
        return U_ERROR;
    }
    UMatrix Um(*this, Iref, NULL);
    bool CollumnSpace = false;
    UProjector P(Um, CollumnSpace, NSVDcomp, "SVD");
    P.SetComplement(true);

/////
    UMatrixSymmetric UUT = Um.GetMMT();
    double* Eig = UUT.GetNormalizedEigen(true);
    if(Eig) for(int k=0; k<MIN(10, NRef); k++) CI.AddToLog("%6.1f \t", Eig[k]);
    CI.AddToLog("\n");
/////

    for(int i=0; i<Nrow; i++) Iref[i] = NOT(Iref[i]);
    if(P.ProjectRows(this, Iref)!=U_OK)
    {
        delete[] Iref;
        CI.AddToLog("ERROR: UMultiChan::RemoveReferenceComponents(). Applying projector .\n");
        return U_ERROR;
    }
    delete[] Iref;
    return U_OK;
}

ErrorType UMultiChan::GetSVD(double** UMat, double** Lamda, double** VMat, double** SVproc) const
/*
    Compute the singular value decomposition of Data[] = *UMat[] * *Lamda[] * *VMat[]
 */
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSVD(). Object NULL or not properly set.\n");
        return U_ERROR;
    }

    double* Um = new double[Nrow*Ncol];
    double* La = new double[MAX(Nrow,Ncol)];
    double* Vm = new double[Ncol*Ncol];
    double* SV = new double[MAX(Nrow,Ncol)];

    if(Um==NULL || La==NULL || Vm==NULL || SV==NULL)
    {
        delete[] Um; delete[] La; delete[] Vm; delete[] SV;
        CI.AddToLog("ERROR: UMultiChan::GetSVD(). Memory allocation. Nrow = %d, Ncol = %d .\n", Nrow, Ncol);
        return U_ERROR;
    }
    for(int ij=0; ij<    Nrow*Ncol ; ij++) Um[ij] = Data[ij];
    for(int  k=0;  k<MAX(Nrow,Ncol);  k++) SV[ k] = 0.;

    if(svdcmp_d(Um, Nrow, Ncol, La, Vm)!=0)
    {
        delete[] Um; delete[] La; delete[] Vm; delete[] SV;
        CI.AddToLog("ERROR: UMultiChan::GetSVD(). Performing SVD algorithm .\n");
        return U_ERROR;
    }

    double DataNorm = 0.;
    for(int k=0; k<MIN(Ncol,Nrow); k++) DataNorm += La[k]*La[k];
    if(DataNorm<1.e-10)
        CI.AddToLog("WARNING: UMultiChan::GetSVD(). Sum of (weighed) squares of data matrix almost vanishes. DataNorm = %e\n",DataNorm);
    else
        for(int k=0; k<MIN(Ncol,Nrow); k++) SV[k] = 100.*La[k]*La[k]/DataNorm;

    if(UMat  ) *UMat   = Um; else delete[] Um;
    if(Lamda ) *Lamda  = La; else delete[] La;
    if(VMat  ) *VMat   = Vm; else delete[] Vm;
    if(SVproc) *SVproc = SV; else delete[] SV;
    return U_OK;
}

ErrorType UMultiChan::PreWhiten(UCovariance* XX, UCovariance* TT)
/*
    Prewhiten the Data matrix with the Kronker product of the spatial covariance XX and the
    temporal covariance TT.
    if(XX==NULL) ignore XX,
    if(TT==NULL) ignore TT
 */
{
    if(XX==NULL && TT==NULL) return U_OK;

    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::PreWhiten(). Object NULL or not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }

/* Spatial covariance*/
    if(XX)
    {
        if(XX->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::PreWhiten(). Spatial covariance not properly set. \n");
            return U_ERROR;
        }
        if(XX->GetNdim()!=Nrow)
        {
            CI.AddToLog("ERROR: UMultiChan::PreWhiten(). Spatial covariance has different dimension (Ndim=%d) than the number of channels (Nrow=%d)  . \n", XX->GetNdim(), Nrow);
            return U_ERROR;
        }
        *this               = XX->GetPreWhitened(*this);
        UString Prop        = XX->GetProperties("");
        FilterHistory      += UString((const char*)Prop, "UMultiChan::PreWhiten(XX=%s, ");
    }
    else
        FilterHistory      += UString(                     "UMultiChan::PreWhiten(NULL , ");


/* Temporal covariance*/
    if(TT)
    {
        if(TT->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::PreWhiten(). Temporal covariance not properly set. \n");
            return U_ERROR;
        }
        if(TT->GetNdim()!=Ncol)
        {
            CI.AddToLog("ERROR: UMultiChan::PreWhiten(). Temporal covariance has different dimension (Ndim=%d) than the number of samples (Ncol=%d)  .\n", TT->GetNdim(), Ncol);
            return U_ERROR;
        }
        *this               = TT->GetPostWhitened(*this);
        UString Prop        = TT->GetProperties("");
        FilterHistory      += UString((const char*)Prop, "%s) \n");
    }
    else
        FilterHistory      += UString(                     "NULL) \n");

    return U_OK;
}
ErrorType UMultiChan::SolveSumKP(UMatrixSumKP* SKP)
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Object NULL or not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(SKP==NULL || SKP->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Invalid NULL pointer argument. \n");
        return U_ERROR;
    }
    if(SKP->GetNdimPre()!=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Number of channels (%d) does not match NdimPre (%s) .\n", Nrow, SKP->GetNdimPre());
        return U_ERROR;
    }
    if(SKP->GetNdimPost()!=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Number of time samples (%d) does not match NdimPost (%s) .\n", Nrow, SKP->GetNdimPost());
        return U_ERROR;
    }
    int     Ndim     = Nrow*Ncol;
    double* DataPrew = new double[Ndim];
    if(DataPrew==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Memory allocation, Ndim = %d .\n", Ndim);
        return U_ERROR;
    }
    for(int ij=0; ij<Ndim; ij++) DataPrew[ij] = Data[ij];
    int     itol   = 1;
    double  Tol    = 1.e-10;
    int     itmax  = MIN(10000, 2*Ndim);
    int     Niter  = 0;
    double  Err    = 0;
    if(SKP->Solve(Data, DataPrew, Ndim, itol, Tol, itmax, &Niter, &Err)!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::SolveSumKP(). Solving system of equations.\n");
        delete[] DataPrew;
        return U_ERROR;
    }
    delete[] Data; Data = DataPrew;

    UString Prop   = SKP->GetProperties("");
    FilterHistory += UString("UMultiChan::SolveSumKP(SKP: ") + Prop+" )";
    return U_OK;
}

ErrorType UMultiChan::PostMultiply(const UMatrixSymmetric* pMS)
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::PostMultiply(). Object NULL or not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(pMS==NULL || pMS->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::PostMultiply(). UMatrixSymmetric argument is NULL.\n");
        return U_ERROR;
    }
    if(pMS->GetNrow()!=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::PostMultiply(). Jacobi argument has different dimension (Ndim=%d) than the number of samples (Ncol=%d)  .\n", pMS->GetNrow(), Ncol);
        return U_ERROR;
    }
    UMatrix(*this) = (*this) * (*pMS);
    FilterHistory += UString(pMS->GetProperties(""), "UMultiChan::PostMultiply(pMS=%s)");

    return U_OK;
}
ErrorType UMultiChan::PreMultiply(const UMatrixSymmetric* pMS)
{
    if(this==NULL || error !=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::PreMultiply(). Object NULL or not properly set. History = %s .\n", FilterHistory);
        return U_ERROR;
    }
    if(pMS==NULL || pMS->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::PreMultiply(). UMatrixSymmetric argument is NULL.\n");
        return U_ERROR;
    }
    if(pMS->GetNcol()!=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::PreMultiply(). Jacobi argument has different dimension (Ndim=%d) than the number of samples (Ncol=%d)  .\n", pMS->GetNcol(), Ncol);
        return U_ERROR;
    }
    UMatrix(*this) = (*pMS) * (*this);
    FilterHistory += UString(pMS->GetProperties(""), "UMultiChan::PreMultiply(pMS=%s)");

    return U_OK;
}

ErrorType UMultiChan::InterpolateDataSegment(int isamp, int esamp, int ichan)
/*
    Performs the linear interpolation of the time series (of all channels)
    between samples isamp and esamp
 */
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR UMultiChan::InterpolateDataSegment(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL)
    {
        CI.AddToLog("ERROR UMultiChan::InterpolateDataSegment(). Data array is NULL.\n");
        return U_ERROR;
    }
    if(ichan>=Nrow)
    {
        CI.AddToLog("ERROR UMultiChan::InterpolateDataSegment(). parameter out of range (ichan=%d).\n", ichan);
        return U_ERROR;
    }
    int icB = 0;
    int icE = Nrow-1;
    if(ichan>=0)
    {
        icB = ichan;
        icE = ichan;
    }
    
    if(isamp<0 && isamp>=esamp)
    {
        for(int i=icB; i<=icE; i++)
        {
            double* Dati = Data+ i*Ncol;
            for(int j=0; j<Ncol; j++) Dati[j] = 0.;
        }
    }
    else if(isamp<0)
    {
        for(int i=icB; i<=icE; i++)
        {
            double* Dati = Data+ i*Ncol;
            double  D    = Dati[esamp];
            for(int j=0; j<esamp; j++) Dati[j] = D;
        }
    }
    else if(esamp>=Ncol)
    {
        for(int i=icB; i<=icE; i++)
        {
            double* Dati = Data+ i*Ncol;
            double  D    = Dati[isamp];
            for(int j=isamp; j<Ncol; j++) Dati[j] = D;
        }
    }
    else if(isamp!=esamp)
    {
        for(int i=icB; i<=icE; i++)
        {
            double* Dati = Data+ i*Ncol;
            double  slo  = (Dati[esamp] - Dati[isamp])/(esamp-isamp);
            double  off  =  Dati[isamp];

            for(int j=isamp; j<=esamp; j++) Dati[j] = slo * (j-isamp) + off;
        }
    }
/*Update filter history */
    FilterHistory += UString(isamp, "UMultiChan::InterpolateDataSegment(isamp=%d ")
                   + UString(esamp, ", esamp=%d ) ")
                   + UString(ichan, ", ichan=%d ) \n");
    return U_OK;
}

ErrorType UMultiChan::RemoveLinearTrend()
/*
     Removes the linear trend of the data array stored in Data[]
*/
{
    if(Data==NULL || Nrow<1 || Ncol<1)
    {
        CI.AddToLog("ERROR: UMultiChan::RemoveLinearTrend(). Data or Nrow or Ncol not set. \n");
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
    {
        double m = (Data[i*Ncol+Ncol-1]-Data[i*Ncol+0])/(Ncol-1-0);
        double b =  Data[i*Ncol+0];
        for(int j=0; j<Ncol; j++) Data[i*Ncol+j] -= m*j+b;
    }

/*Update filter history */
    FilterHistory += UString("UMultiChan::RemoveLinearTrend() \n");

    return U_OK;
}

UMultiChan* UMultiChan::GetDownSampledData(int factor, int phase) const
/*
    This function returns a new UMultiChan object, which is a downsampled version of *this.

      factor   = Gives number of samples after which a sample is taken for the output;
      phase    = Gives the sample where the samples to be included in the output start to be counted;

      if(phase<0) start at sample 0, average factor samples
*/
{
    if(this==NULL || error!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetDownSampledData(). Object NULL or eroneous or data not set. \n");
        return NULL;
    }
    if(factor<=0||phase>=factor)
    {
        CI.AddToLog("ERROR: UMultiChan::GetDownSampledData(). Invalid input arguments: factor=%d, phase=%d  .\n", factor, phase);
        return NULL;
    }

    bool   Aver  = false;
    int NewNtime = 0;
    for(int j=phase; j<Ncol; j+=factor)  NewNtime++;
    if(phase<0)
    {
        Aver     = true;
        phase    = 0;
        NewNtime = Ncol/factor;
    }

    if(NewNtime<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetDownSampledData(). Invalid total number of samples for downsampled data.\n");
        return NULL;
    }
    double* DSdata = new double[Nrow*NewNtime];
    if(DSdata==NULL)
    {
        delete[] DSdata;
        CI.AddToLog("ERROR: UMultiChan::GetDownSampledData(). Memory allocation error.\n");
        return NULL;
    }
    for(int i=0; i<Nrow; i++)
    {
        if(Aver==false)
        {
            for(int j=phase, jj=0; j<Ncol; j+=factor)
            {
                DSdata[i*NewNtime + jj] = Data[i*Ncol + j];
                jj++;
                if(jj==NewNtime) break;
            }
        }
        else
        {
            for(int jj=0,j=0; jj<NewNtime; jj++)
            {
                double DatAve = 0;
                for(int k=0; k<factor; k++,j++) DatAve += Data[i*Ncol + j];
                DatAve /= factor;
                DSdata[i*NewNtime + jj] = DatAve;
            }
        }
    }

    UMultiChan* MC = new UMultiChan(DSdata, SensorGrid, NewNtime, SampTime*factor);
    delete[] DSdata;
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMultiChan::GetDownSampledData(). Converting down sampled data to UMultiChan object. \n");
        return NULL;
    }
    return MC;
}
ErrorType UMultiChan::DownSampledData(int factor, int phase)
{
    if(this==NULL || error!=U_OK || Data==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::DownSampledData(). Object NULL or eroneous or data not set. \n");
        return U_ERROR;
    }
    if(factor<=0||phase>=factor)
    {
        CI.AddToLog("ERROR: UMultiChan::DownSampledData(). Invalid input arguments: factor=%d, phase=%d  .\n", factor, phase);
        return U_ERROR;
    }
    UMultiChan* MC = GetDownSampledData(factor, phase);
    if(MC==NULL || MC->GetError()!=U_OK)
    {
        delete MC;
        return U_ERROR;
    }
    *this = *MC;
    if(error!=U_OK)
    {
        delete MC;
        CI.AddToLog("ERROR: UMultiChan::DownSampledData(). Copying down sampled result. \n");
        return U_ERROR;
    }
    delete MC;
    return U_OK;
}

ErrorType UMultiChan::ApplyWindow(const double* Window, int Nsamp, UPreProType Prep)
{
    if(Data==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyWindow(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    if(Window==NULL || Nsamp!=Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyWindow(). Invalid NULL window or invalid number of time samples. Ncol=%d, Nsamp=%d   .\n",Ncol, Nsamp);
        return U_ERROR;
    }
    for(int i=0; i<Nrow; i++)
        ULinearFilter::ApplyWindow(Data+i*Ncol, Window, Ncol, Prep);

    switch(Prep)
    {
    case U_PREP_NO:     FilterHistory += UString("UMultiChan::ApplyWindow(), No pre-processing. \n"); break;
    case U_PREP_OFFSET: FilterHistory += UString("UMultiChan::ApplyWindow(), Offset-removal   . \n"); break;
    case U_PREP_TREND:  FilterHistory += UString("UMultiChan::ApplyWindow(), Trend removal. \n"); break;
    }
    return U_OK;
}

double* UMultiChan::GetAverFFTPower(int BegSamp, int SubWin, int* nPowSub, WindowType WT, UPreProType Prep) const
/*
    Return an array with the channel-averaged power spectrum, of the the sub-window
    starting from BegSamp and a length of SubWin.
    WT determines the window function multiplied to the data of each channel, before computing the spectrum.

    if(BegSamp<0) Start at sample 0
    if(SubWin <0) Include all samples
    if(nPowSub) *nPowSub will contain the number of power spectrum values.
 */
{
    if(Data==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::GetAverFFTPower(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }

    if(BegSamp<0) BegSamp = 0;
    if(SubWin <0) SubWin  = Ncol;

    if(BegSamp+SubWin>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetAverFFTPower(). Arguments out of range: BegSamp=%d, SubWin=%d, Ncol=%d \n", BegSamp, SubWin, Ncol);
        return NULL;
    }

    if(SubWin<10)
        CI.AddToLog("WARNING: UMultiChan::GetAverFFTPower(). Too few samples per sub-epoch.  SubWin=%d .\n",SubWin);

    int Npower = SubWin/2+1;

    double* pAverPowFFT = new double[Npower];
    double* pDataFFT    = new double[SubWin];     // tempory array containing the FFT's
    double* pDataWin    = new double[SubWin];     // Windowed data
    double* Window      = ULinearFilter::GetWindowProfile(WT, SubWin);
    const rfftw_plan pFFTplan = FFTW.GetRealPlan(SubWin, true);

    if(!pAverPowFFT || !pDataFFT || !pDataWin || !Window || !pFFTplan)
    {
        delete[] pAverPowFFT;
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        CI.AddToLog("ERROR: UMultiChan::GetAverFFTPower(). Memory allocation. SubWin=%d, Nrow=%d  .\n", SubWin, Nrow);
        return NULL;
    }
    for(int k=0;k<Npower;k++) pAverPowFFT[k] = 0.;

    for(int i=0;i<Nrow;i++)
    {
        for(int j=0; j<SubWin; j++) pDataWin[j] = Data[i*Ncol+BegSamp+j];
        ULinearFilter::ApplyWindow(pDataWin, Window, SubWin, Prep);
        rfftw_one(pFFTplan, pDataWin, pDataFFT);

        pAverPowFFT[0] += pDataFFT[0]*pDataFFT[0];       // The DC-component
        for(int k=1; k<SubWin/2; k++)
            pAverPowFFT[k] += 2* (pDataFFT[k]*pDataFFT[k] + pDataFFT[SubWin-k]*pDataFFT[SubWin-k]);

        if(SubWin%2==0)
            pAverPowFFT[SubWin/2] += pDataFFT[SubWin/2]*pDataFFT[SubWin/2];
    }
    delete[] pDataFFT;
    delete[] pDataWin;
    delete[] Window;

    if(Nrow)
        for(int k=0;k<Npower;k++) pAverPowFFT[k] /= Nrow;

    if(nPowSub) *nPowSub = Npower;
    return pAverPowFFT;
}

UFieldGraph* UMultiChan::GetLFPowerAsFieldGraph(bool ScaleToMax) const
{
    if(this==NULL || Data==NULL || error !=U_OK || Ncol<2|| Nrow<1 || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetLFPowerAsFieldGraph(). Object NULL or not properly set. \n");
        return NULL;
    }

    UFieldGraph* FG = new UFieldGraph(float(0.), float((Ncol-1)*SampTime), Ncol, UField::U_DOUBLE, 1);
    if(FG==NULL||FG->GetError()!=U_OK||FG->GetDdata()==NULL)
    {
        delete FG;
        CI.AddToLog("ERROR: UMultiChan::GetLFPowerAsFieldGraph(). Creating output object.\n");
        return NULL;
    }
    FG->SetLabel("LFPower");

    double MaxP2 = 0;
    for(int j=0; j<Ncol; j++)
    {
        double P2 = 0.; 
        for(int i=0; i<Nrow; i++) P2 += Data[i*Ncol+j]*Data[i*Ncol+j];
        if(Nrow>0) P2/=Nrow;    
        FG->GetDdata()[j] = P2;
        MaxP2 = MAX(P2, MaxP2);
    }
    if(ScaleToMax && MaxP2>0.)
    {
        double MaxDat  = GetMaxData(true);
        *FG           *= (MaxDat/MaxP2);
    }
    return FG;
}

UFieldGraph* UMultiChan::GetEnvelopAsFieldGraph(void) const
{
    if(this==NULL || Data==NULL || error !=U_OK || Ncol<2|| Nrow<1 || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetEnvelopAsFieldGraph(). Object NULL or not properly set. \n");
        return NULL;
    }

    UFieldGraph* FG = new UFieldGraph(float(0.), float((Ncol-1)*SampTime), Ncol, UField::U_DOUBLE, 1);
    if(FG==NULL||FG->GetError()!=U_OK||FG->GetDdata()==NULL)
    {
        delete FG;
        CI.AddToLog("ERROR: UMultiChan::GetEnvelopAsFieldGraph(). Creating output object.\n");
        return NULL;
    }
    FG->SetLabel("Envelop");

    for(int j=0; j<Ncol; j++)
    {
        double MaxDat = 0.; 
        for(int i=0; i<Nrow; i++) MaxDat = MAX(MaxDat, fabs(Data[i*Ncol+j]));
        FG->GetDdata()[j] = MaxDat;             
    }
    
    double Beg = FG->GetDdata()[      0];
    double End = FG->GetDdata()[Ncol-1];
    for(int j=0; j<Ncol; j++)
        FG->GetDdata()[j] -= ( Beg + j*(End-Beg)/(Ncol-1) ); 

    ULinearFilter Filt(1./SampTime);
    double EpTime = (Ncol-1)*SampTime;
    double Fmin   = 0;
    double Fmax   = 20./EpTime;
    Filt.SetFilter(Fmin, Fmax, U_PREP_NO, U_POWERLINE_NO, 1., MIN(1.,EpTime/4));

    if(Filt.ComputeFilter(NULL, 0, FG->GetDdata(), Ncol, 1)!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetEnvelopAsFieldGraph(). Applying the ComputeFilter() function of Filt.\n");
        return NULL;
    }
    FG->AbsValue();
    return FG;
}

double* UMultiChan::GetFFTPowerChan(int BegSamp, int SubWin, int* nPowSub, int chan, WindowType WT, UPreProType Prep) const
/*
    Return an array with the power spectrum of channel chan, of the the sub-window
    starting from BegSamp and a length of SubWin.
    WT determines the window function multiplied to the data of each channel, before computing the spectrum.

    if(BegSamp<0) Start at sample 0
    if(SubWin <0) Include all samples
    if(nPowSub) *nPowSub will contain the number of power spectrum values.
 */
{
    if(this==NULL || Data==NULL || error !=U_OK )
    {
        CI.AddToLog("ERROR: UMultiChan::GetFFTPowerChan(). Object NULL or not properly set. \n");
        return NULL;
    }
    if(chan<0 || chan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFFTPowerChan(). Channel index out of range. chan = %d \n", chan);
        return NULL;
    }

    if(BegSamp<0) BegSamp = 0;
    if(SubWin <0) SubWin  = Ncol;

    if(BegSamp+SubWin>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetFFTPowerChan(). Arguments out of range: BegSamp=%d, SubWin=%d, Ncol=%d \n", BegSamp, SubWin, Ncol);
        return NULL;
    }

    if(SubWin<10)
        CI.AddToLog("WARNING: UMultiChan::GetFFTPowerChan(). Too few samples per sub-epoch.  SubWin=%d .\n",SubWin);

    int Npower = SubWin/2+1;

    double* pPowFFT  = new double[Npower];
    double* pDataFFT = new double[SubWin];     // tempory array containing the FFT
    double* pDataWin = new double[SubWin];     // Windowed data
    double* Window   = ULinearFilter::GetWindowProfile(WT, SubWin);
    const rfftw_plan pFFTplan = FFTW.GetRealPlan(SubWin, true);

    if(!pPowFFT || !pDataFFT || !pDataWin || !Window || !pFFTplan)
    {
        delete[] pPowFFT;
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        CI.AddToLog("ERROR: UMultiChan::GetFFTPowerChan(). Memory allocation. SubWin=%d, Nrow=%d  .\n", SubWin, Nrow);
        return NULL;
    }

    for(int j=0; j<SubWin; j++) pDataWin[j] = Data[chan*Ncol+BegSamp+j];
    ULinearFilter::ApplyWindow(pDataWin, Window, SubWin, Prep);
    rfftw_one(pFFTplan, pDataWin, pDataFFT);

    pPowFFT[0] = pDataFFT[0]*pDataFFT[0];       // The DC-component
    for(int k=1; k<SubWin/2; k++)
        pPowFFT[k] = 2* (pDataFFT[k]*pDataFFT[k] + pDataFFT[SubWin-k]*pDataFFT[SubWin-k]);

    if(SubWin%2==0)
        pPowFFT[SubWin/2] = pDataFFT[SubWin/2]*pDataFFT[SubWin/2];

    delete[] pDataFFT;
    delete[] pDataWin;
    delete[] Window;


    if(nPowSub) *nPowSub = Npower;
    return pPowFFT;
}

UField** UMultiChan::GetMorletWaveletTransformArray(const UWaveletTransform& W, int SubFactor, int* NChannel) const
{
    if(Data==NULL || error !=U_OK || SampTime<=0. || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(&W==NULL || W.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Wavelet argument not properly set.\n");
        return NULL;
    }
    if(SampTime!=W.GetSampTime() || Ncol!=W.GetNtime() )
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Sampling time or number of sample not compatible with Wavelet object.\n");
        return NULL;
    }
    if(SubFactor<=0 || Ncol/SubFactor<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Invalid sub-sampling (%d) argument. \n", SubFactor);
        return NULL;
    }

/* Determine UField coordinates */
    UField** pFArr    = new UField*[Nrow];
    if(pFArr==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Memory allocation. Nrow=%d  .\n", Nrow);
        return NULL;
    }

    for(int i=0; i<Nrow; i++) pFArr[i] = NULL;
    for(int i=0; i<Nrow; i++)
    {
        pFArr[i] = GetMorletWaveletTransform(i, W, SubFactor);
        if(pFArr[i]==NULL || pFArr[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransformArray(). Getting wavelet transform of channel %d   .\n", i);
            for(int ii=0; ii<Nrow; ii++) delete pFArr[ii];
            delete[] pFArr;
            return NULL;
        }
    }
    if(NChannel) *NChannel = Nrow;
    return pFArr;
}

UField* UMultiChan::GetMorletWaveletTransform(int ichan, const UWaveletTransform& W, int SubFactor) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Object NULL or erroneous.  \n");
        return NULL;
    }
    if(Data==NULL || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). ichan (=%d) out of  range, Nrow=%d  .\n", ichan, Nrow);
        return NULL;
    }
    if(&W==NULL || W.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Wavelet argument not properly set.\n");
        return NULL;
    }
    if(SampTime!=W.GetSampTime() || Ncol!=W.GetNtime() )
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Sampling time or number of sample not compatible with Wavelet object.\n");
        return NULL;
    }
    if(SubFactor<=0 || Ncol/SubFactor<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Invalid sub-sampling (%d) argument. \n", SubFactor);
        return NULL;
    }

    UField* Fwavel = W.GetTransformAbsolute(Data+ichan*Ncol, SubFactor);

    if(Fwavel==NULL || Fwavel->GetError()!=U_OK)
    {
        delete Fwavel;
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Computing wavelet transform. \n");
        return NULL;
    }
    return Fwavel;
}

UField* UMultiChan::GetMorletWaveletTransform(int ichan, double Fmin, double Fdelta, double Fmax, int NShift, WindowType WT, UPreProType Prep) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Object NULL or erroneous.  \n");
        return NULL;
    }
    if(Data==NULL || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). ichan (=%d) out of  range, Nrow=%d  .\n", ichan, Nrow);
        return NULL;
    }
    double Fsamp = 1./SampTime;
    if(Fmin<0 || Fmax<=Fmin || Fsamp<Fmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Invalid frequency range (Fmin=%f Fmax=%f).\n", Fmin, Fmax);
        return NULL;
    }
    if(Fdelta<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Invalid frequency step (Fdelta=%f).\n", Fdelta);
        return NULL;
    }
    if(NShift<=1 || NShift>Ncol)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Invalid number of shifts (NShift=%d).\n", NShift);
        return NULL;
    }

    int     NFreq   = int((Fmax-Fmin)/Fdelta);
    double* Window  = ULinearFilter::GetWindowProfile(WT, Ncol);
    double* Signal  = new double[Ncol];
    double* RealW   = new double[Ncol];
    double* ImagW   = new double[Ncol];
    double* Times   = new double[NShift];
    double* Freqs   = new double[NFreq];
    if(Window==NULL || Signal==NULL || RealW==NULL || ImagW==NULL || Times==NULL || Freqs==NULL)
    {
        delete[] Window;
        delete[] Signal;
        delete[] RealW;
        delete[] ImagW;
        delete[] Times;
        delete[] Freqs;
        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Memory allocation error (NShift=%d, NFreq=%d).\n", NShift, NFreq);
        return NULL;
    }
    for(int j=0; j<Ncol;  j++) Signal[j] = Data[ichan*Ncol+j];
    for(int j=0; j<NShift; j++) Times [j] = j*SampTime*Ncol/NShift;
    for(int k=0; k<NFreq;  k++) Freqs [k] = Fmin + (k+1)*Fdelta;

    ULinearFilter::ApplyWindow(Signal, Window, Ncol, Prep);
    delete[] Window;

    int     Dims[2] = {NShift, NFreq};
    UField*  Fwavel = new UField(Times, Freqs, NULL, Dims, UField::U_DOUBLE, 1);
    delete[] Times;
    delete[] Freqs;

    if(Fwavel==NULL || Fwavel->GetError()!=U_OK || Fwavel->GetData()==NULL)
    {
        delete   Fwavel;
        delete[] Signal;
        delete[] RealW;
        delete[] ImagW;

        CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Creating output UField-object.\n");
        return NULL;
    }

    const int WAVELETORDER = 8;  // and computing the resulting constants for the wavelet:
    double    C_Sig        = ( 1./sqrt(1. + exp(-double(WAVELETORDER*WAVELETORDER)) - 2*exp(-3.*(WAVELETORDER*WAVELETORDER)/4.))  ) / sqrt(sqrt(PI));
    double    K_Sig        = exp(-(WAVELETORDER*WAVELETORDER)/2.);

    double*   Spectogram   = Fwavel->GetDdata();

    for(int k=0; k<NFreq;k++)  // loop for scales
    {
        double sca = Fwavel->GetCoord(1, k)*PI2/WAVELETORDER;
        for(int j=0;j<NShift;j++)  // loop for time positions
        {
            double tau = Fwavel->GetCoord(0, j);
            if(MorletWavelet(RealW, ImagW, sca, tau, WAVELETORDER, C_Sig, K_Sig)!=U_OK)
            {
                delete[] Signal;
                delete[] RealW;
                delete[] ImagW;
                delete   Fwavel;
                CI.AddToLog("ERROR: UMultiChan::GetMorletWaveletTransform(). Computing MorletWavelet.\n");
                return NULL;
            }

            double SumR=0;
            double SumI=0;
            for(int n=0;n<Ncol;n++)// and multiplying it with the signal:
            {
                SumR += Signal[n]*RealW[n];
                SumI += Signal[n]*ImagW[n];
            }
            Spectogram[k*NShift+j]=(SumR*SumR+SumI*SumI) * sca * SampTime; // and that is the element for the power matrix:
        }
    }
    delete[] Signal;
    delete[] RealW;
    delete[] ImagW;
    return Fwavel;
}


ErrorType UMultiChan::MorletWavelet(double* re, double* im, double sca, double tau, int WaveOrder, double C_Sig, double K_Sig) const
/*
 input: - re[] a pointer to the array for the real part of the wavelet,
        - im[] a pointer to the array for the imaginary part of the wavelet,
        - sca  desired scale of the wavelet,
        - tau  desired shift of the wavelet [sec],
        - Sig order parameter of the wavelet,
        - C_Sig 'normalizing' constant for the wavelet,
        - K_Sig 'shifting' constant for the wavelet,
*/
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::MorletWavelet(). Object NULL or erroneous.  \n");
        return U_ERROR;
    }
    if(re==NULL || im==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::MorletWavelet(). Invalid NULL pointer arguments.  \n");
        return U_ERROR;
    }
    if(tau<0 || tau>Ncol*SampTime)
    {
        CI.AddToLog("ERROR: UMultiChan::MorletWavelet(). Shift parameter out of range (tau=%f).  \n", tau);
        return U_ERROR;
    }
    if(sca<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::MorletWavelet(). Scale parameter out of range (sca=%f).  \n", sca);
        return U_ERROR;
    }


    double t      = -tau     *sca; // this will hold the time
    double deltat =  SampTime*sca; // this will hold the time jumps

    for(int j=0;j<Ncol;j++)   // the loop computing the real and imaginary part of the wavelet:
    {
        double Expt2 = C_Sig*exp(-(t*t)/2);

        re[j]        = Expt2*(cos(WaveOrder*t)-K_Sig);
        im[j]        = Expt2*(sin(WaveOrder*t)-K_Sig);
        t           += deltat;
    }
    return U_OK;
}

UField* UMultiChan::GetSpectrogram(int ichan, int WinSize, int WinShift, WindowType WT, UPreProType Prep) const
/*
    Return an UField pointer, refering to the spectrogram of channel ichan.
    The spectrogram is computed by shifting a window of WinSize samples over
    the time axis, in jumps of WinShift samples. For each of these windows, compute
    the powers of the spectra.
    WT determines the window function multiplied to the data of each channel, before computing the spectrum.
 */
{
    if(Data==NULL || error !=U_OK || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram(). ichan (=%d) out of  range, Nrow=%d  .\n", ichan, Nrow);
        return NULL;
    }
    if(WinSize<=10 || WinSize>Ncol || WinShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram(). Input parameters out of range: WinSize=%d, WinShift=%d .\n", WinSize, WinShift);
        return NULL;
    }

    int Npower  = 1 +  WinSize/2;
    int NWindow = 1 + (Ncol-WinSize)/WinShift;

/* Determine UField coordinates */
    const rfftw_plan pFFTplan = FFTW.GetRealPlan(WinSize, true);
    double*  pDataFFT = new double[WinSize];     // tempory array containing the FFT's
    double*  pDataWin = new double[WinSize];     // Windowed data
    double*  Window   = ULinearFilter::GetWindowProfile(WT, WinSize);
    double*  Times    = new double[NWindow];
    double*  Freqs    = new double[Npower];
    int      Dims[2]  = {NWindow, Npower};

    if(pDataFFT==NULL ||pDataWin==NULL || Window==NULL || Times==NULL || Freqs==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram(). Memory allocation. NWindow=%d, Npower=%d.\n", NWindow, Npower);
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        delete[] Times;
        delete[] Freqs;
        return NULL;
    }

    double  SampleRate = 1./SampTime;
    for(int jwin=0; jwin<NWindow; jwin++) Times[jwin] = (WinSize/2 + jwin*WinShift)* SampTime;
    for(int    k=0;    k<Npower;     k++) Freqs[k]    = SampleRate*(k+.5)/(2*Npower);

    UField*  Fspect   = new UField(Times, Freqs, NULL, Dims, UField::U_DOUBLE, 1);
    delete[] Times;
    delete[] Freqs;
    if(Fspect==NULL || Fspect->GetError()!=U_OK)
    {
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        delete   Fspect;
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram(). Creating empty field. \n");
        return NULL;
    }

/* Compute spectrogram */
    double* Spectogram = Fspect->GetDdata();
    for(int jwin=0; jwin<NWindow; jwin++)
    {
        for(int j=0; j<WinSize; j++) pDataWin[j] = Data[ichan*Ncol+jwin*WinShift+j];
        ULinearFilter::ApplyWindow(pDataWin, Window, WinSize, Prep);

        rfftw_one(pFFTplan, pDataWin, pDataFFT);

        Spectogram[0*Dims[0]+jwin] += pDataFFT[0]*pDataFFT[0];       // The DC-component
        for(int k=1; k<Npower; k++)
             Spectogram[k*Dims[0]+jwin]+= 2* (pDataFFT[k]*pDataFFT[k] + pDataFFT[WinSize-k]*pDataFFT[WinSize-k]);

        if(WinSize%2==0)
             Spectogram[(WinSize/2)*Dims[0]+jwin] = pDataFFT[WinSize/2]*pDataFFT[WinSize/2];
    }

    delete[] pDataFFT;
    delete[] pDataWin;
    delete[] Window;
    return Fspect;
}
UField* UMultiChan::GetSpectrogram2(int ichan, int WinSize, int NWindow, WindowType WT, UPreProType Prep) const
/*
    Return an UField pointer, refering to the spectrogram of channel ichan.
    The spectrogram is computed by shifting NWindow windows of WinSize samples
    evenly over the time axis. For each of these windows, compute the powers of the
    spectra.
    WT determines the window function multiplied to the data of each channel,
    before computing the spectrum.
 */
{
    if(Data==NULL || error !=U_OK || SampTime<=0.)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram2(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram2(). ichan (=%d) out of  range, Nrow=%d  .\n", ichan, Nrow);
        return NULL;
    }
    if(WinSize<=10 || WinSize>Ncol || NWindow<=0 || NWindow>=Ncol/2)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram2(). Input parameters out of range: WinSize=%d, NWindow=%d .\n", WinSize, NWindow);
        return NULL;
    }
    int Npower  = 1 +  WinSize/2;

/* Determine UField coordinates */
    const rfftw_plan pFFTplan = FFTW.GetRealPlan(WinSize, true);
    double*  pDataFFT = new double[WinSize];     // tempory array containing the FFT's
    double*  pDataWin = new double[WinSize];     // Windowed data
    double*  Window   = ULinearFilter::GetWindowProfile(WT, WinSize);
    double*  Times    = new double[NWindow];
    double*  Freqs    = new double[Npower];
    int      Dims[2]  = {NWindow, Npower};

    if(pDataFFT==NULL ||pDataWin==NULL || Window==NULL || Times==NULL || Freqs==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram2(). Memory allocation. NWindow=%d, Npower=%d.\n", NWindow, Npower);
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        delete[] Times;
        delete[] Freqs;
        return NULL;
    }

    double  SampleRate = 1./SampTime;
    for(int jwin=0; jwin<NWindow; jwin++) Times[jwin] = (Ncol-WinSize)*SampTime*jwin/NWindow + WinSize*SampTime/2;
    for(int    k=0;    k<Npower;     k++) Freqs[k]    = SampleRate*(k+.5)/(2*Npower);

    UField*  Fspect   = new UField(Times, Freqs, NULL, Dims, UField::U_DOUBLE, 1);
    delete[] Times;
    delete[] Freqs;
    if(Fspect==NULL || Fspect->GetError()!=U_OK)
    {
        delete[] pDataFFT;
        delete[] pDataWin;
        delete[] Window;
        delete   Fspect;
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogram2(). Creating empty field. \n");
        return NULL;
    }

/* Compute spectrogram */
    double* Spectogram = Fspect->GetDdata();
    for(int jwin=0; jwin<NWindow; jwin++)
    {
        int joff = int((Ncol-WinSize)*jwin/(double)NWindow);
        for(int j=0; j<WinSize; j++) pDataWin[j] = Data[ichan*Ncol+joff+j];
        ULinearFilter::ApplyWindow(pDataWin, Window, WinSize, Prep);

        rfftw_one(pFFTplan, pDataWin, pDataFFT);

        Spectogram[0*Dims[0]+jwin] = pDataFFT[0]*pDataFFT[0];       // The DC-component
        for(int k=1; k<Npower; k++)
             Spectogram[k*Dims[0]+jwin] = 2* (pDataFFT[k]*pDataFFT[k] + pDataFFT[WinSize-k]*pDataFFT[WinSize-k]);

        if(WinSize%2==0)
             Spectogram[(WinSize/2)*Dims[0]+jwin] = pDataFFT[WinSize/2]*pDataFFT[WinSize/2];
    }

    delete[] pDataFFT;
    delete[] pDataWin;
    delete[] Window;
    return Fspect;
}

UField** UMultiChan::GetSpectrogramArray(int WinSize, int WinShift, int* NChannel, WindowType WT, UPreProType Prep) const
/*
    Return an array of UField pointers, refering to the spectrograms of each channel.
    These spectrograms are computed by shifting a window of WinSize samples over
    the time axis, in jumps of WinShift samples. For each of these windows, compute
    the powers of the spectra.
    WT determines the window function multiplied to the data of each channel, before computing the spectrum.
 */
{
    if(Data==NULL || error !=U_OK || SampTime<=0. || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(WinSize<=10 || WinSize>Ncol || WinShift<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray(). Input parameters out of range: WinSize=%d, WinShift=%d .\n", WinSize, WinShift);
        return NULL;
    }

    int Npower  = 1 +  WinSize/2;
    int NWindow = 1 + (Ncol-WinSize)/WinShift;

/* Determine UField coordinates */
    UField** pFArr    = new UField*[Nrow];
    if(pFArr==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray(). Memory allocation. NWindow=%d, Npower=%d   .\n", NWindow, Npower);
        delete[] pFArr;
        return NULL;
    }

    for(int i=0; i<Nrow; i++)
    {
        pFArr[i] = GetSpectrogram(i, WinSize, WinShift, WT, Prep);
        if(pFArr[i]==NULL || pFArr[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray(). Getting spectrogram of channel %d   .\n", i);
            for(int ii=0; ii<i; ii++) delete pFArr[ii];
            delete[] pFArr;
            return NULL;
        }
    }
    if(NChannel) *NChannel = Nrow;
    return pFArr;
}
UField** UMultiChan::GetSpectrogramArray2(int WinSize, int NWindow, int* NChannel, WindowType WT, UPreProType Prep) const
/*
    Return an array of UField pointers, refering to the spectrograms of each channel.
    These spectrograms are computed by shifting NWindow windows of WinSize samples
    evenly over the time axis. For each of these windows, compute the powers of the spectra.
    WT determines the window function multiplied to the data of each channel,
    before computing the spectrum.
 */
{
    if(Data==NULL || error !=U_OK || SampTime<=0. || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray2(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(WinSize<=10 || WinSize>Ncol || NWindow<=0 || NWindow>=Ncol/2)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray2(). Input parameters out of range: WinSize=%d, NWindow=%d .\n", WinSize, NWindow);
        return NULL;
    }
    int Npower  = 1 +  WinSize/2;

/* Determine UField coordinates */
    UField** pFArr    = new UField*[Nrow];

    if(pFArr==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray2(). Memory allocation. NWindow=%d, Npower=%d   .\n", NWindow, Npower);
        delete[] pFArr;
        return NULL;
    }

    for(int i=0; i<Nrow; i++)
    {
        pFArr[i] = GetSpectrogram2(i, WinSize, NWindow, WT, Prep);
        if(pFArr[i]==NULL || pFArr[i]->GetError()!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiChan::GetSpectrogramArray2(). Getting spectrogram of channel %d   .\n", i);
            for(int ii=0; ii<i; ii++) delete pFArr[ii];
            delete[] pFArr;
            return NULL;
        }
    }
    if(NChannel) *NChannel = Nrow;
    return pFArr;
}

ErrorType UMultiChan::ApplyHilbertTransform(void)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyHilbertTransform(). Object NULL or erroneous.\n");
        return U_ERROR;
    }
    if(Data==NULL || Ncol<=0 || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyHilbertTransform(). Object not properly set. History = %s \n", FilterHistory);
        return U_ERROR;
    }
    double* AnalImag = new double[Ncol];
    if(AnalImag==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::ApplyHilbertTransform(). Getting data before Hilbert Transform.\n");
        return U_ERROR;
    }

    for(int i=0; i<Nrow; i++)
    {
        double* DatChan = Data + i*Ncol;
        if(HilbertTransform(DatChan, AnalImag, Ncol)!=U_OK)
        {
            delete[] AnalImag;
            CI.AddToLog("ERROR: UMultiChan::ApplyHilbertTransform(). Computing Hilbert transform, i = %d .\n", i);
            return U_ERROR;
        }
        for(int j=0; j<Ncol; j++) DatChan[j] = sqrt(DatChan[j]*DatChan[j]+AnalImag[j]*AnalImag[j]);
    }
    delete[] AnalImag;

    return U_OK;
}

UField* UMultiChan::GetSynLikeMatrix(int NSampSubWindow, double FracOverlap, int SubSamp, int ichan, SimilarityType SimTyp, int* DiagWidth) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Object NULL or erroneous.\n");
        return NULL;
    }
    if(Data==NULL || SampTime<=0. || Nrow<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(NSampSubWindow<=1 || NSampSubWindow>Ncol || SubSamp<=0 || ichan<0 || ichan>=Nrow)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Input parameters out of range: NSampSubWindow=%d, SubSamp=%d, ichan=%d.\n", NSampSubWindow, SubSamp, ichan);
        return NULL;
    }
    if(FracOverlap<0 || 1<=FracOverlap)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Invalid overlap (FracOverlap = %f). \n", FracOverlap);
        return NULL;
    }
    double FracShift = 1-FracOverlap;
    int    NsubWin   = int(floor( 1 + (Ncol-NSampSubWindow) /(FracShift*NSampSubWindow) ));

    int     Dims[2] ={NsubWin, NsubWin};
    UField* Matrix  = new UField(UVector2(),UVector2(1.,1.), Dims, UField::U_DOUBLE, 1);
    if(Matrix==NULL || Matrix->GetError()!=U_OK || Matrix->GetDdata()==NULL)
    {
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Creating output UField object.\n");
        delete Matrix;
        return NULL;
    }
    if(DiagWidth) *DiagWidth = int(ceil(1./FracShift));

    const   double* Ch  = Data+ichan*Ncol;
    double*         Mat = Matrix->GetDdata();

    switch(SimTyp)
    {
    case U_SIMI_FROBNORM:
        {
            for(int n1=0; n1<NsubWin; n1++)
            {
                for(int n2=0; n2<NsubWin; n2++)
                {
                    const double* Ch1  = Ch + int( n1*FracShift*NSampSubWindow );
                    const double* Ch2  = Ch + int( n2*FracShift*NSampSubWindow );
                    Mat[n1*NsubWin+n2] = 0.;
                    if(n2>n1)
                    {
                        double Elem = 0;
                        for(int l=0; l<NSampSubWindow; l+=SubSamp)
                            Elem += (Ch1[l]-Ch2[l])*(Ch1[l]-Ch2[l]);

                        if(Elem>0.&&NSampSubWindow>0)
                            Mat[n1*NsubWin+n2] = sqrt(Elem/NSampSubWindow);
                    }
                    else if(n2<n1)
                    {
                        Mat[n1*NsubWin+n2] = Mat[n2*NsubWin+n1];
                    }
                }
            }
            break;
        }

    case U_SIMI_CORR2:
        {
            for(int n1=0; n1<NsubWin; n1++)
            {
                for(int n2=0; n2<NsubWin; n2++)
                {
                    const double* Ch1  = Ch + int( n1*FracShift*NSampSubWindow );
                    const double* Ch2  = Ch + int( n2*FracShift*NSampSubWindow );
                    Mat[n1*NsubWin+n2] = 1.;
                    if(n2>n1)
                    {
                        double Elem11 = 0;
                        double Elem22 = 0;
                        double Elem12 = 0;
                        for(int l=0; l<NSampSubWindow; l+=SubSamp)
                        {
                            Elem11  += Ch1[l]*Ch1[l];
                            Elem22  += Ch2[l]*Ch2[l];
                            Elem12  += Ch1[l]*Ch2[l];
                        }
                        if(Elem11>0.&&Elem22>0.&&NSampSubWindow>0)
                            Mat[n1*NsubWin+n2] = Elem12*Elem12/(Elem11*Elem22);
                    }
                    else if(n2<n1)
                    {
                        Mat[n1*NsubWin+n2] = Mat[n2*NsubWin+n1];
                    }
                }
            }
            return Matrix;
        }
    default:
        CI.AddToLog("ERROR: UMultiChan::GetSynLikeMatrix(). Invalid similarity type (%d). \n", SimTyp);
        delete Matrix;
        return NULL;
    }
    if(NsubWin<=1) return Matrix;

    double Min = Mat[1];
    double Max = Mat[1];
    for(int n1=0; n1<NsubWin; n1++)
        for(int n2=0; n2<NsubWin; n2++)
        {
            if(n2<=n1) continue;
            if(Min>Mat[n1*NsubWin+n2]) Min = Mat[n1*NsubWin+n2];
            if(Max<Mat[n1*NsubWin+n2]) Max = Mat[n1*NsubWin+n2];
        }
    if(Min>0)
    {
        for(int n1=0; n1<NsubWin; n1++)
            for(int n2=0; n2<NsubWin; n2++)
                Mat[n1*NsubWin+n2] = (Min + Max)/(Min + Mat[n1*NsubWin+n2]);
    }
    return Matrix;
}

UBitMap UMultiChan::GetMapsAsBitmap(const int*dims, double Dmin, double Dmax, int BegSamp, int EndSamp, int Step, PaletteType Pal) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Object not properly set. History = %s \n", FilterHistory);
        return UBitMap(U_ERROR);
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Sensor grid not (properly) set. \n");
        return UBitMap(U_ERROR);
    }
    if(dims==NULL || dims[0]<=2 || dims[1]<=2)
    {
        if(dims==NULL) CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Invalid NULL dims pointer. \n");
        else           CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Invalid dimensions: (%d, %d). \n", dims[0], dims[1]);
        return UBitMap(U_ERROR);
    }
    if(Dmin>=Dmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Invalid data scale: Dmin = %f, Dmax = %f . \n", Dmin, Dmax);
        return UBitMap(U_ERROR);
    }
    if(BegSamp<0 || BegSamp>=Ncol || EndSamp<BegSamp || Step<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Invalid map offsets: BegSamp=%d, EndSamp=%d, Step=%d .\n", BegSamp, EndSamp, Step);
        return UBitMap(U_ERROR);
    }
    UField* Fplot = GetMapsAsField(dims, Dmin, Dmax, BegSamp, EndSamp, Step);
    if(Fplot==NULL || Fplot->GetError()!=U_OK)
    {
        delete Fplot;
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Creating UField object .\n");
        return UBitMap(U_ERROR);
    }
    if(Fplot->ConvertDataToByte(Dmin, Dmax)!=U_OK)
    {
        delete Fplot;
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Converting UField object to bytes.\n");
        return UBitMap(U_ERROR);
    }
    UBitMap BM(dims[0], dims[0], Fplot->GetBdata());
    delete Fplot;
    if(BM.GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsBitmap(). Converting UField object to UBitMap.\n");
        return UBitMap(U_ERROR);
    }
    BM.SetPallette(Pal);
    BM.SetPalletteFirst(255, 255, 255);
    return BM;
}
UField* UMultiChan::GetMapsAsField(const int*dims, double Dmin, double Dmax, int BegSamp, int EndSamp, int Step) const
{
    if(this==NULL || error !=U_OK || Data==NULL || Nrow<=0 || Ncol<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Object not properly set. History = %s \n", FilterHistory);
        return NULL;
    }
    if(SensorGrid==NULL || SensorGrid->GetError()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Sensor grid not (properly) set. \n");
        return NULL;
    }
    if(dims==NULL || dims[0]<=2 || dims[1]<=2)
    {
        if(dims==NULL) CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Invalid NULL dims pointer. \n");
        else           CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Invalid dimensions: (%d, %d). \n", dims[0], dims[1]);
        return NULL;
    }
    if(Dmin>=Dmax)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Invalid data scale: Dmin = %f, Dmax = %f . \n", Dmin, Dmax);
        return NULL;
    }
    if(BegSamp<0 || BegSamp>=Ncol || EndSamp<BegSamp || Step<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Invalid map offsets: BegSamp=%d, EndSamp=%d, Step=%d .\n", BegSamp, EndSamp, Step);
        return NULL;
    }
    UGridFit Gfit(*SensorGrid);
    double    Rad = 11;
    UVector3  Pos;
    if(Gfit.FitSphere(Pos, &Rad)<=0)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Fitting sphere to sensors.\n");
        return NULL;
    }
    if(Gfit.TriangulateGrid()!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Triangulating grid.\n");
        return NULL;
    }

    const double  XVIEWMIN  = -1.2*Rad;
    const double  XVIEWMAX  =  1.2*Rad;
    const double  YVIEWMIN  = -1.2*Rad;
    const double  YVIEWMAX  =  1.2*Rad;
    const double  RADVIEW   =  1.4*Rad;

    UField* Fplot= new UField(UVector2(XVIEWMIN,YVIEWMIN), UVector2(XVIEWMAX,YVIEWMAX), dims, UField::U_DOUBLE, 1);
    if(Fplot==NULL || Fplot->GetError()!=U_OK)
    {
        delete Fplot;
        CI.AddToLog("ERROR: UMultiChan::GetMapsAsField(). Creating UField object. \n");
        return NULL;
    }
    Fplot->SetDataDouble(-1.2*MAX(fabs(Dmin),fabs(Dmax))); 

    UVector3 C = Gfit.GetCenter();
    
    int Nplot = 0;
    for(int j=BegSamp; j<EndSamp; j+=Step) Nplot++;
    int Nplotx = MAX(1, int(sqrt((double)(Nplot*dims[0])/dims[1] + .5)));
    int Nploty = Nplot / Nplotx;
    if(Nplotx*Nploty<Nplot) Nploty += 1;
    if(Nplotx*Nploty<Nplot) Nploty += 1;
    int NviewMax = MAX(Nplotx, Nploty);

    for(int j=BegSamp,ipl=0; j<EndSamp; j+=Step,ipl++)
    {
        int iX =            (ipl%Nplotx);   // rectangle index
        int iY = NviewMax-1-(ipl/Nplotx);

        for(int it=0; it<Gfit.GetNTriangle(); it++) 
        {
            int is[3] = {0,0,0};
            if(Gfit.GetTriangleIndices(it, is, is+1, is+2)!=U_OK) continue;

            double DatVal[3] = {0.,0.,0.};
            UVector2 Pxy[3];
            for(int k=0; k<3; k++)
            {
                DatVal[k]  = Data[is[k]*Ncol +j];
                UVector3 S = Gfit.GetPosition(is[k])-C;
                Pxy[k]     = S.GetMercator(RADVIEW).GetRot90(); 
                Pxy[k].Setx(XVIEWMIN + ((Pxy[k].Getx()-XVIEWMIN)+(XVIEWMAX-XVIEWMIN)*iX)/NviewMax);
                Pxy[k].Sety(YVIEWMIN + ((Pxy[k].Gety()-YVIEWMIN)+(YVIEWMAX-YVIEWMIN)*iY)/NviewMax);
            }
            if(Fplot->PlotTriangle(Pxy[0], Pxy[1], Pxy[2], DatVal, false)!=U_OK) continue;
        }
    }
    return Fplot;
}

double  Distance2(const UMultiChan& MC1, const UMultiChan& MC2)
{
    if(&MC1==NULL || &MC2==NULL)
    {
        CI.AddToLog("ERROR: Distance2(). Invalid NULL addreses of at least one of the MultiChan arguments. \n");
        return 0;
    }
    if(MC1.GetData()==NULL || MC2.GetData()==NULL)
    {
        CI.AddToLog("ERROR: Distance2(). Invalid NULL Data pointer in at least one of the MultiChan arguments. \n");
        return 0;
    }
    if(MC1.GetNChan() != MC2.GetNChan() ||
       MC2.GetNtime() != MC2.GetNtime())
    {
        CI.AddToLog("ERROR: Distance2(). Number of channels, or number of times are unequal. \n");
        return 0;
    }
    double        dist2 = 0;
    const double* pD1   = MC1.GetData();
    const double* pD2   = MC2.GetData();
    for(int ij=0; ij<MC1.GetNChan()*MC1.GetNtime(); ij++)
    {
        double t  = *pD1++ - *pD2++;
        dist2    += t*t;
    }
    return dist2;
}

