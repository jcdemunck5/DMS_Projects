#ifndef _MULTICHAN_INCLUDED
#define _MULTICHAN_INCLUDED

#include "LinearFilter.h"
#include "String.h"
#include "MEEGDataBase.h"
#include "MatrixSymmetric.h"
#include "BitMap.h"

typedef enum
{
    U_TIMESHIFT_SAMPLE,  // Round off to whole sample
    U_TIMESHIFT_LINEAR,  // Interpolate linearly
    U_TIMESHIFT_FFT      // Interpolate with FFT
} TimeShiftType;

PMT_CCP DLL_IO GetTimeShiftText(TimeShiftType TST);

typedef enum
{
    U_SIMI_FROBNORM,     // Frobenius norm
    U_SIMI_CORR2,        // Correlation Squared
} SimilarityType;

class UGrid;
class UField;
class UFieldGraph;
class UCovariance;
class UInterpolate;
class UWaveletTransform;
class UMatrixSumKP;
class UMatrix;

class DLL_IO UMultiChan : public UMatrix
{
public:
    UMultiChan();
    UMultiChan(ErrorType E);
    UMultiChan(const UGrid* Grid, int ntime, double samptime);
    UMultiChan(const double* data, const UGrid* Grid, int ntime, double samptime);
    UMultiChan(const UMultiChan& MC);
    UMultiChan(const UMultiChan& MC, int SkipSamples, int NewWidth);
    virtual ~UMultiChan();

    UMultiChan&         operator= (const UMatrix& M);
    UMultiChan&         operator= (const UMultiChan& MC);
    UMultiChan&         operator+=(const UMultiChan& MC);
    UMultiChan&         operator-=(const UMultiChan& MC);
    UMultiChan&         operator*=(double f);
    UMultiChan&         operator/=(double f);

    ErrorType           GetError() const {return error;}
    double              GetMinData() const;
    double              GetMaxData(bool Fabs) const;
    double              GetMedianAbs(void) const;
    ErrorType           GetMinMax(double* DatMin, double* DatMax, int ichan) const;
    const UString&      GetProperties(UString Comment) const;
    const char*         GetHistory()    const {if(this) return FilterHistory; return NULL;}
    const double*       GetData()       const {if(this) return Data;          return NULL;}
    double              GetSampTime()   const {if(this) return SampTime;      return 0;}
    int                 GetNChan()      const {if(this) return Nrow;          return 0;}
    const UGrid*        GetSensorGrid() const {if(this) return SensorGrid;    return NULL;}
    int                 GetNtime()      const {if(this) return Ncol;          return 0;}

    ErrorType           InvertData(void);
    ErrorType           SetData(double Dat);
    const double*       GetChannelData(int ichan) const;
    ErrorType           SetChannelData(const double* data, int ichan);
    ErrorType           CopyData(const UMultiChan& MC, int OffsetFrom, int NCopy, int OffsetTo);

    ErrorType           CopyFirstPoint();
    ErrorType           CopyLastPoint();
    ErrorType           RepeatValue(int BegSamp, int EndSamp);

    ErrorType           InterpolateDataSegment(int isamp, int esamp, int ichan=-1);
    ErrorType           RemoveLinearTrend(void);

    int                 GetMaxOutlier(int offset, int NWindow, double Thresh) const;
    int                 GetPointMax4(void) const;
    double              GetDataPower(void) const;
    ErrorType           ShiftData(double Shift, TimeShiftType TST);
    ErrorType           UpSampleData(int UpSampleFactor);
    UMultiChan*         GetDownSampledData(int factor, int phase) const;
    ErrorType           DownSampledData(int factor, int phase);
    UMultiChan*         GetResampledData(int NewNtime) const;
    UMultiChan*         GetResampledData(const UInterpolate* Inter) const;
    ErrorType           ResampleData(const UInterpolate* Inter);

    ErrorType           ComputeGroupReference(void) const;
    ErrorType           ApplyLinearFilter(ULinearFilter& Filt, const UMultiChan* MCpre=NULL);
    ErrorType           InterpolateOutliers(double ThreshNormal, double ThreshOutlier, int MaxWin, int**SampOutlier, int* NOutlier);
    ErrorType           ShiftSubstract(const UMultiChan& MC, int ShiftSamples);
    ErrorType           ShiftProject(const UProjector& P, int ShiftSamples);

    ErrorType           Merge(const UMultiChan& MC);
    UMultiChan*         GetCut(int SkipSamples, int NewWidth) const;
    ErrorType           Cut(int SkipSamples, int NewWidth);
    ErrorType           MergeCut(const UMultiChan& MC, int SkipSamples, int NewWidth);
    ErrorType           MergeChannels(const UMultiChan& MC);
    ErrorType           SelectChannels(const UGrid* GSelect);

    ErrorType           ReorderChannelNames(bool HighFirst, bool GroupMemberShip);

    double              GetCorrelation(const UMultiChan* Templ, int skipbegin, int skipend) const;
    ErrorType           MaxCorrelatedSubShift(const UMultiChan* Templ, int SampleSub, double* BestShift, double* BestCor, int* BestIndex, TimeShiftType TST=U_TIMESHIFT_FFT);
    ErrorType           MaxCorrelatedSubShift(const UMultiChan* Templ, int MaxShift, int SampleSub, double* BestShift, double* BestCor, int* BestIndex, TimeShiftType TST=U_TIMESHIFT_FFT);
    double              GetShiftedCorrelation(const UMultiChan* Templ, int Shift, int Skip) const;
    int                 GetMaxCorrelatedShift(const UMultiChan* Templ, int MaxShift, double* BestCor) const;
    UMultiChan*         GetNormalizedCovariance(const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double* ResErr, TimeShiftType TST=U_TIMESHIFT_FFT) const;

    double*             GetMinDatChan(bool Fabs) const;
    double*             GetMaxDatChan(bool Fabs) const;
    double*             GetLRSymmetryAsTime(void) const;

    ErrorType           RegressAllChan(const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double** Coeff, double** Shift, TimeShiftType TST=U_TIMESHIFT_FFT) const;
    ErrorType           RegressChan(int ichan, const UMultiChan* Templ, double MinShift, double MaxShift, int NShift, double** Coeff, double* BestShift, TimeShiftType TST=U_TIMESHIFT_FFT) const;
    double              RegressChan(int ichan, const UMultiChan* Templ, double** Coeff, int SkipFirst, int SkipLast) const;
    double              GetFrequency(int ichan, double* ResError) const;
    double              GetAmplitudeFactor(const UMultiChan* Templ, double ChanOutlierMedianFactor) const;
    double              GetRMS(int ichan) const;
    double              GetRMStime(int isamp) const;
    double              GetTimeMaxRMS(double Tmin, double Tmax, int ichan, double* RMS) const;
    double              GetTimeMaxValue(double Tmin, double Tmax, int ichan, double* MaxValue) const;
    double              GetTimeMinValue(double Tmin, double Tmax, int ichan, double* MinValue) const;
    bool                IsAnySampleSuperThreshold(double Thresh) const;

    UCovariance*        GetSpatialCovariance(DataType DType) const;
    UCovariance*        GetTemporalCovariance(void) const;

    ErrorType           RemoveReferenceComponents(int NSVDcomp, double BandRefLayerLow, double BandRefLayerHigh);
    ErrorType           GetSVD(double** UMat, double** Lamda, double** Vmat, double** SVproc) const;
    ErrorType           PreWhiten(UCovariance* XX, UCovariance* TT); // arguments may be decomposed
    ErrorType           SolveSumKP(UMatrixSumKP* SKP);
    ErrorType           PostMultiply(const UMatrixSymmetric* pMS);
    ErrorType           PreMultiply(const UMatrixSymmetric* pMS);

    UFieldGraph*        GetLFPowerAsFieldGraph(bool ScaleToMax) const;
    UFieldGraph*        GetEnvelopAsFieldGraph(void) const;
    double*             GetAverFFTPower(int BegSamp, int SubWin, int* nPowSub, WindowType WT, UPreProType Prep) const;
    double*             GetFFTPowerChan(int BegSamp, int SubWin, int* nPowSub, int chan, WindowType WT, UPreProType Prep) const;
    UField*             GetMorletWaveletTransform(int ichan, const UWaveletTransform& W, int SubFactor) const;
    UField*             GetMorletWaveletTransform(int ichan, double Fmin, double Fdelta, double Fmax, int NShift, WindowType WT, UPreProType Prep) const;
    UField**            GetMorletWaveletTransformArray(const UWaveletTransform& W, int SubFactorint, int *NChannel) const;
    UField*             GetSpectrogram(int ichan, int WinSize, int WinShift, WindowType WT, UPreProType Prep) const;
    UField*             GetSpectrogram2(int ichan, int WinSize, int NWindow, WindowType WT, UPreProType Prep) const;
    UField**            GetSpectrogramArray(int WinSize, int WinShift, int* NChannel, WindowType WT, UPreProType Prep) const;
    UField**            GetSpectrogramArray2(int WinSize, int NWindow, int* NChannel, WindowType WT, UPreProType Prep) const;
    ErrorType           ApplyWindow(const double* Window, int Nsamp, UPreProType Prep);
    ErrorType           ApplyHilbertTransform(void);

    UField*             GetSynLikeMatrix(int NSampSubWindow, double FracOverlap, int SubSamp, int ichan, SimilarityType SimTyp, int* DiagWidth) const;
    UField*             GetMapsAsField(const int*dims, double Dmin, double Dmax, int BegSamp, int EndSamp, int Step) const;
    UBitMap             GetMapsAsBitmap(const int*dims, double Dmin, double Dmax, int BegSamp, int EndSamp, int Step, PaletteType Pal) const;

    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);
private:
    static UString      Properties;    // General property string.
    ErrorType           error;         // General error flag
    UString             FilterHistory; // Sequence of all filtering operations that have been applied

    UGrid*              SensorGrid;    // Position and names of different time signals
    double              SampTime;      // Sample time [s]
    ErrorType           MorletWavelet(double* re, double* im, double sca, double tau, int WaveOrder, double C_Sig, double K_Sig) const;
};


PMT_UMULTICHANP DLL_IO Merge(const UMultiChan& MC1, const UMultiChan& MC2);
PMT_UMULTICHANP DLL_IO MergeCut(const UMultiChan& MC1, const UMultiChan& MC2, int SkipSamples, int NewWidth);
double          DLL_IO Distance2(const UMultiChan& MC1, const UMultiChan& MC2);

#endif// _MULTICHAN_INCLUDED


