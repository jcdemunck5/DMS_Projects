/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL:                                                                  */
/*                                                                               */
/*     Module to convert a distance matrix to a set of coordinates.              */
/*                                                                               */
/*     NOTE:                                                                     */
/*                                                                               */
/*     AUTHOR:                                                                   */
/*     J.C. de Munck                                                             */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  JdM    05-02-17   creation
 */


#include "MultiDimScale.h"
#include "Projector.h"

UString UMultiDimScale::Properties = UString();

void UMultiDimScale::SetAllMembersDefault(void)
{
    error          = U_OK;
}

void UMultiDimScale::DeleteAllMembers(ErrorType E)
{
    SetAllMembersDefault();
    error = E;
}

UMultiDimScale::UMultiDimScale() : UMatrixSymmetric()
{
    SetAllMembersDefault();
}
UMultiDimScale::UMultiDimScale(const UMatrixSymmetric& DistMat) : UMatrixSymmetric(DistMat)
{
    SetAllMembersDefault();

    double FN = GetFrobNorm();
    if(FN>0.) *this /= FN;
}
UMultiDimScale::~UMultiDimScale()
{
    DeleteAllMembers(U_OK);
}

UMatrix UMultiDimScale::GetCoordinates(int Ncoord, MDSType MDT) const
{
    if(this==NULL || error!=U_OK)
    {
        return UMatrix(U_ERROR);
    }
    if(Ncoord<=0 || Ncoord>=Nrow)
    {
        return UMatrix(U_ERROR);
    }
    if(MDT!=U_MDS_CLASSICAL && MDT!=U_MDS_LEASTSQUARES) 
    {
        return UMatrix(U_ERROR);
    }

    UMatrix E(DNULL, Nrow, 1);
    E.SetData(1.);
    UProjector P(E, true, "Const");
    P.SetComplement(true);
    UMatrixSymmetric Cov = P.GetPAP(-*this)/2;

    UMatrix Coord = Cov.GetEigenVectors(0, Ncoord-1);
    UMatrix Diag(DNULL, Ncoord);
    
    if(Coord.GetError()!=U_OK || Coord.Data==NULL || Diag.GetError()!=U_OK || Diag.Data==NULL)
    {
        return UMatrix(U_ERROR);
    }

    for(int k=0; k<Ncoord; k++) Diag.Data[k] = sqrt(fabs(Cov.GetEigen(k)));
    Coord = Coord*Diag;
    if(MDT==U_MDS_CLASSICAL) return Coord;

    double StressOld = -1.;
    for(int iter= 0; iter<1000; iter++)
    {
        UMatrix VarDif = Coord.GetVarianceDifMat();
        UMatrix B(DNULL, Nrow, Nrow);
        double Stress  = 0;
        for(int i=0; i<Nrow; i++)
        {
            for(int j=i+1; j<Ncol; j++)
            {
                double D1 = sqrt(       Data[i*Ncol+j]);
                double D2 = sqrt(VarDif.Data[i*Ncol+j]);
                Stress    += SQR(D1-D2);
            
                B.Data[i*Ncol+j] = B.Data[j*Ncol+i] = D2>0. ? -D1/D2 : 0.;
            }
            double Diag = B.Data[i*Ncol+i] = 0;
            for(int j=0; j<Ncol; j++) Diag += B.Data[i*Ncol+j];
            B.Data[i*Ncol+i] =  -Diag;
        }
        B    *= (1./Nrow);
        Coord = B*Coord;

        if(iter>0 && fabs(StressOld-Stress)<1.e-6*Stress) break;
        
        StressOld = Stress;
    }
    return Coord;
}

