#ifndef _MULTIDIMSCALE_INCLUDED
#define _MULTIDIMSCALE_INCLUDED

#include "MatrixSymmetric.h"

enum MDSType
{
    U_MDS_CLASSICAL,        // Classical multi dimensuoinal scaling through eigenvector decomposition
    U_MDS_LEASTSQUARES,     // No correlations, all variances not equal
    U_MDS_NUMMDS            // Number of types
};


class DLL_IO UMultiDimScale : public UMatrixSymmetric
{
public:
    UMultiDimScale();
    UMultiDimScale(const UMatrixSymmetric& DistMat);
    ~UMultiDimScale();

    const UString&      GetProperties(UString Comment) const;
    UMatrix             GetCoordinates(int Ncoord, MDSType MDT) const;

protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static UString      Properties;    // General property string.
    ErrorType           error;         // General error flag
};

#endif// _MULTIDIMSCALE_INCLUDED
