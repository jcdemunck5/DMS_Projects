/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL                                                                   */
/*     Module for doing a few (pre-) computations in the multi-Sphere model.     */
/*                                                                               */
/*                                                                               */
/*     NOTES                                                                     */
/*     All coordinates are given in the head coordinate system:                  */
/*     nasion-left-right.                                                        */
/*                                                                               */
/*     USAGE                                                                     */
/*     A UMultiSphereModel-object can be created from a pointer to an UHeadModel */
/*     object. In the UHeadModel-object the data needed for the multi-sphere     */
/*     model are determined (from file or other constructors) and the            */
/*     computations required in the model are done here, in the                  */
/*     UMultiSphereModel -object. In practice, the UHeadModel-pointer is passed  */
/*     to the UEMfield-object, which determines the nature of the model          */
/*     (realistic or multi-sphere) and passes the UHeadModel pointer to here.    */
/*     The UEMfield object calls functions of UMultiSphereModel for the          */
/*     updates of the tables and coefficients when needed in the multi-sphere    */
/*     models.                                                                   */
/*     Realistic model are treated by the other base classe of the UEMfield      */
/*     object (UBemField).                                                       */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    22-05-00   creation, by splitting UHeadModel into two
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    25-10-00   Prevent the launching of error messages caused by inconsistency between Model and HM
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    28-03-05   Added SetAllMembersDefault(), DeleteAllMembers(). Default constructor, copy constructor and operator=(). Use UString for GetProperties()
  JdM    30-10-06   Added GetPotential() and GetLeadField()
  JdM    11-11-06   Safer addressing of arrays
  JdM    13-11-06   Added SetRelativeElectrodeRadius()
  JdM    15-11-06   InitCorfa(). delete arrays before creating new ones.
  JdM    16-11-06   increased MAXTERM from 300 to 3000
  JdM    05-11-07   Constructor : Set error to U_OK in case of non-sphere model
  JdM    20-11-07   Adapted to new implementation of UHeadModel::ModelType
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    13-11-12   BUG FIX: SetAllMembersDefault() and operator=(). Include CondModel, SpherePos and HeadRadius members
  JdM    02-02-14   Added GetPotentialEIT(), added member coefEIT[]. Not yet tested!
  JdM    16-07-14   Bug Fix: GetPotentialEIT(). Multiply end result by HeadRadius, instead of deviding by (HeadRadius*HeadRadius)
  JdM    02-10-14   GetPotentialEIT(). Add test on arguments.
  JD     10-11-14   BUG FIX: GetPotentialEIT(). Apply proper scaling factor.
  JdM    18-11-14   InitCorfa(). More efficient implementation based on new derivation.
  JdM    02-12-16   UpdateRadialCoefficients(). Maximized number of error messages for dipole out of head.
  JdM    18-03-18   Made InjectionSize private member. Added SetInjectionSize(). Added new GetPotentialEIT()
  */

#include <string.h>
#include "MultiSphereModel.h"

/* Inititalize static const parameters. */
/* Inititalize static const parameters. */
const double UMultiSphereModel::ELRADIUS   = 0.5;  // Default electrode radius (measured along the spherical surface) in case of current injection, [cm]
UString      UMultiSphereModel::Properties = UString();
const int    UMultiSphereModel::MAXTERM    =  3000;
const int    UMultiSphereModel::MINTERM    =  10;

void UMultiSphereModel::SetAllMembersDefault(void)
{
    CondModel  = U_CONDMOD_UNKNOWN;
    SpherePos  = UVector3();
    HeadRadius = 10;

    eps = eht = rs = NULL;
    coefEIT    = NULL;
    corfa      = NULL; 
    rn0        = NULL;
    rn1        = NULL;
    rn2        = NULL;
    rn3        = NULL;
    rn4        = NULL;
    uprod      = NULL;

    Ns         =  0;
    jdip       = -1;
    jelec      = -1;
    relec      =  1;

    Nterm      =  0;
    Lam        = .5;
    F0 = F1 = F2 = F3 = F4 = 0.;

    InjectionSize = ELRADIUS;
    error         = U_OK;
}

void UMultiSphereModel::DeleteAllMembers(ErrorType E)
{
    delete[] eps;
    delete[] eht;
    delete[] rs;
    delete[] coefEIT;
    delete[] corfa; 
    delete[] rn0;
    delete[] rn1;
    delete[] rn2;
    delete[] rn3;
    delete[] rn4;
    delete[] uprod;
    SetAllMembersDefault();
    error = E;
}

UMultiSphereModel::UMultiSphereModel()
{    
    SetAllMembersDefault();
}

UMultiSphereModel::UMultiSphereModel(const UHeadModel* HM)
/*   
      Initialize the multi-sphere model for by data collected by *HM.
 */
{    
    SetAllMembersDefault();
    if(HM==NULL) return;

    if(HM->GetError()!=U_OK)  
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel::UMultiSphereModel(). Invalid argument (NULL)\n");
        return;
    }
    CondModel = HM->GetCondModelType();
    switch(CondModel)
    {
    case U_CONDMOD_SPHERE:
    case U_CONDMOD_HOMSPHERE:
    case U_CONDMOD_THREESPHERE:
    case U_CONDMOD_MULTISPHERE:
        break;
    default:
        return;
    }

    Ns  = HM->GetNshell();
    if(Ns<0) Ns = 0;

    if(Ns>0)
    {
        eps = new double[Ns];
        eht = new double[Ns];
        rs  = new double[Ns];
        if(eht==NULL || eps==NULL || rs==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel::UMultiSphereModel(). Memory allocation. Ns=%d\n.",Ns);
            return;
        }
        for(int k=0; k<Ns; k++) 
        {
            eps[k] = HM->GetEps(k);
            eht[k] = HM->GetEht(k);
            rs[k]  = HM->GetRs(k); 
        }
    }
    if(CondModel==U_CONDMOD_MULTISPHERE)    
        relec  = HM->GetRelElecRad();
    
    HeadRadius = HM->GetHeadRadius();
    SpherePos  = HM->GetSpherePos();

    if(InitCorfa()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel::UMultiSphereModel(). Setting co-efficients. \n.");
        return;
    }
}

UMultiSphereModel::UMultiSphereModel(const UMultiSphereModel &MSM)
{
    SetAllMembersDefault();
    *this = MSM;
}

UMultiSphereModel::~UMultiSphereModel()
{
    DeleteAllMembers(U_OK);
}

UMultiSphereModel& UMultiSphereModel::operator=(const UMultiSphereModel &MSM)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::operator=(). this==NULL. \n");
        static UMultiSphereModel M; M.error = U_ERROR;
        return M;
    }
    if(&MSM==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::operator=(). Invalid NULL Address argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&MSM) return *this;

    DeleteAllMembers(U_OK);
    
    error      = MSM.error;
    Ns         = MSM.Ns;
    jdip       = MSM.jdip;
    jelec      = MSM.jelec;
    relec      = MSM.relec;

    Nterm      = MSM.Nterm;
    Lam        = MSM.Lam;
    F0         = MSM.F0;
    F1         = MSM.F1;
    F2         = MSM.F2;
    F3         = MSM.F3;
    F4         = MSM.F4;

    CondModel  = MSM.CondModel;
    SpherePos  = MSM.SpherePos;
    HeadRadius = MSM.HeadRadius;

    if(MSM.eps)
    {
        eps = new double[MSM.Ns];
        if(eps) for(int k=0; k<Ns; k++) eps[k] = MSM.eps[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }
    if(MSM.eht)
    {
        eht = new double[MSM.Ns];
        if(eht) for(int k=0; k<Ns; k++) eht[k] = MSM.eht[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }
    if(MSM.rs )
    {
        rs  = new double[MSM.Ns];
        if(rs ) for(int k=0; k<Ns; k++) rs [k] = MSM.rs [k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }
    if(MSM.uprod)
    {
        uprod = new double[2*MAXTERM];
        if(uprod) for(int k=0; k<2*MAXTERM; k++) uprod[k] = MSM.uprod[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel::operator=(). Copying uprod.  . \n");
            return *this;
        }
    }
    if(MSM.coefEIT) coefEIT = new double[MAXTERM];
    if(MSM.corfa)   corfa   = new double[MAXTERM];
    if(MSM.rn0)     rn0     = new double[MAXTERM];
    if(MSM.rn1)     rn1     = new double[MAXTERM]; 
    if(MSM.rn2)     rn2     = new double[MAXTERM]; 
    if(MSM.rn3)     rn3     = new double[MAXTERM]; 
    if(MSM.rn4)     rn4     = new double[MAXTERM]; 

    if((MSM.coefEIT && !coefEIT) ||
       (MSM.corfa && !corfa) || (MSM.rn0&&!rn0) || (MSM.rn1&&!rn1) ||
       (MSM.rn2&&!rn2)       || (MSM.rn3&&!rn3) || (MSM.rn4&&!rn4))
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel::operator=(). Copying help arrays (MAXTERM=%d) . \n", MAXTERM);
        return *this;
    }
    for(int k=0; k<MAXTERM; k++)
    {
        if(coefEIT) coefEIT[k] = MSM.coefEIT[k];
        if(corfa)   corfa[k]   = MSM.corfa[k];
        if(rn0)     rn0[k]     = MSM.rn0  [k];
        if(rn1)     rn1[k]     = MSM.rn1  [k];
        if(rn2)     rn2[k]     = MSM.rn2  [k];
        if(rn3)     rn3[k]     = MSM.rn3  [k];
        if(rn4)     rn4[k]     = MSM.rn4  [k];
    }
    InjectionSize = MSM.InjectionSize;
    return *this;
}

double UMultiSphereModel::GetInnerRadius(void) const
{
    if(Ns<=0) return HeadRadius;
    return HeadRadius*rs[Ns-1];
}

const UString& UMultiSphereModel::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMultiSphereModel-object");
        return Properties;
    }
    Properties   = UString();
    Properties  += UString(" MultiSphere Model: \n");
    
    switch(CondModel)
    {
    case U_CONDMOD_SPHERE:
        Properties += UString(" MSModel    = Sphere model // (MEG only)  \n");
        break;
    case U_CONDMOD_HOMSPHERE:
        Properties += UString(" MSModel    = Homogeneous sphere \n");
        break;
    case U_CONDMOD_THREESPHERE:
        Properties += UString(" MSModel    = The standard three-sphere model \n");
        break;
    case U_CONDMOD_MULTISPHERE:
        Properties += UString(" MSModel    = The general multi-sphere model \n");
        break;
    default:
        Properties += UString(" MSModel    = ERROR in Head model: Erroneous head model \n");
    }
    Properties += UString(SpherePos.GetProperties(), " SPHERE_POS   = %s \n");
    Properties += UString(HeadRadius               , " HEAD_RADIUS  = %7.2f \n");    

    Properties += UString(" Radii: ");
    if(rs) for(int k=0; k<Ns; k++) Properties += UString(rs[k], " %6.2f,"); 
    Properties += UString("\n");

    Properties += UString(" Eps: ");
    if(eps) for(int k=0; k<Ns; k++) Properties += UString(eps[k], " %10.6f,"); 
    Properties += UString("\n");

    Properties += UString(" Eht: ");
    if(eht) for(int k=0; k<Ns; k++) Properties += UString(eht[k], " %10.6f,"); 
    Properties += UString("\n");

    if(GetAllowEIT()) Properties += UString(InjectionSize, " InjectionSize = %7.4f \n");

    if(Comment.IsNULL() || Comment.IsEmpty())        Properties.ReplaceAll('\n', ';');  
    else                                             Properties.InsertAtEachLine(Comment);

    return Properties;
}


ErrorType UMultiSphereModel::SetRelativeElectrodeRadius(double rel)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(CondModel!=U_CONDMOD_HOMSPHERE && 
       CondModel!=U_CONDMOD_THREESPHERE && 
       CondModel!=U_CONDMOD_MULTISPHERE) return U_ERROR;

    if(rel<=0 || rel>1)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::SetRelativeElectrodeRadius(). rel = %f out of range. \n",rel);
        return U_ERROR;
    }
    relec = rel;
    if(CondModel==U_CONDMOD_HOMSPHERE) return U_OK;
        
    return InitCorfa();
}
ErrorType UMultiSphereModel::SetInjectionSize(double ElSizeCm)
{
    if(this==NULL || error!=U_OK) return U_ERROR;

    if(CondModel!=U_CONDMOD_HOMSPHERE && 
        CondModel!=U_CONDMOD_THREESPHERE && 
        CondModel!=U_CONDMOD_MULTISPHERE) return U_ERROR;

    if(ElSizeCm<=0 || ElSizeCm>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::SetInjectionSize(). SizeCm = %f out of range. \n", ElSizeCm);
        return U_ERROR;
    }
    InjectionSize = ElSizeCm;
    if(CondModel==U_CONDMOD_HOMSPHERE) return U_OK;

    return InitCorfa();
}

ErrorType UMultiSphereModel::SetSigma(const double* Sigma)
/*
     Set the radial and tangential conductivities equal to
     Sigma[0], Sigma[1], etc, for the multi-sphere model. Update
     the correction factors, used for the computation of the potentials.
 */
{
    if(CondModel!=U_CONDMOD_HOMSPHERE && 
       CondModel!=U_CONDMOD_THREESPHERE && 
       CondModel!=U_CONDMOD_MULTISPHERE) return U_ERROR;

    for(int j=0; j<Ns; j++) 
        if(Sigma[j] <=0)
        {
            CI.AddToLog("ERROR: UMultiSphereModel::SetSigma(). Sigma = %f <=0. !!\n",Sigma[j]);
            return U_ERROR;
        }

    for(int j=0; j<Ns; j++) eht[j] = eps[j] = Sigma[j];
    if(CondModel==U_CONDMOD_HOMSPHERE) return U_OK;
        
    return InitCorfa();
}

ErrorType UMultiSphereModel::ProjectElectrode(UVector3* Xelec) const
{
    if( CondModel==U_CONDMOD_HOMSPHERE ||
        CondModel==U_CONDMOD_THREESPHERE )
    {   // Project the electrode onto the outer sphere
        Xelec->Normalize();
        *Xelec = *Xelec * HeadRadius;
    }
    else if(CondModel==U_CONDMOD_MULTISPHERE)
    {   // Project the electrode onto a spherical surface, possibly sub-surface
        Xelec->Normalize();
        *Xelec = *Xelec * (HeadRadius*relec);
    }
    return U_OK;
}

ErrorType UMultiSphereModel::UpdateRadialCoefficients(UVector3 DipolePos) 
/* 
   Update the radial coefficients rn0[], rn1[], rn2[], rn3[] and rn4[]. 
   Also, update the "Renormalisation parameters" and the number of terms, Nterm.

   R_dip is the radial coordinate of the dipole in cm.
*/
{
    if(CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return U_OK; // Nothing to do

    double R_dip = (DipolePos-SpherePos).GetNorm();
    double rdip  = R_dip/HeadRadius;
    if(rdip>=1.) 
    {
        static int NMESS = 0;
        if(NMESS<=20) CI.AddToLog("ERROR: UMultiSphereModel::UpdateRadialCoefficients(). Dipole out of head! rdip=%f .\n",rdip);
        if(NMESS==20) CI.AddToLog("ERROR: UMultiSphereModel::UpdateRadialCoefficients(). Dipole out of head! Last ERROR Message .\n");
        NMESS++;
        return U_ERROR;
    }
    if(CondModel==U_CONDMOD_THREESPHERE)
    {
        double pg = 1;
        for(int n=1; n<=MAXTERM;n++) 
        {
            rn0[n-1] =   corfa[n-1] * pg;
            rn1[n-1] = n*corfa[n-1] * pg;
            rn2[n-1] = n*(n-1)*rn0[n-1]/rdip;
            pg      *= rdip;
        }
    }
    else if(CondModel==U_CONDMOD_MULTISPHERE)
    {
        UpdateUmat(rdip);
      
/*  Update the radial functions */
        double lam0  = rdip/rs[jdip-1];
        double lam   = 1; if(jdip<Ns) lam = rs[jdip]/rdip;
      
        int n,n2;
        for(n=n2=0;n<MAXTERM;n++,n2+=2)
        {  
            double vu  = (-1.+ sqrt(1 + 4.*(n+1.)*(n+2.)*eht[jdip-1]/eps[jdip-1] )  )/2.;
            double vu2 = 2*vu+1;
            double d1  = pow(lam0,vu);
            if(jdip==Ns)
            {  
                double tmp = d1*corfa[n]/(vu2*eps[jdip-1]*rdip);
                rn0[n]     =    uprod[n2+1]*tmp;
                rn1[n]     = vu*uprod[n2+1]*tmp;
            }
            else 
            {  
                double ss11  = vu+1;
                double ss21  = vu*(vu+1)*eps[jdip-1]/rdip;
                double ss12  = rs[jdip]/eps[jdip-1];
                double ss22  = lam*vu;

                double d2    = pow(lam,2*vu);
                double uuj11 = ss11 + d2*ss22;
                       d2    = d2*lam;
                double uuj21 = ss21 - d2*ss21;
                double uuj12 = ss12 - d2*ss12;
                       d2    = d2*lam;       
                double uuj22 = ss22 + d2*ss11;

                double tmp0  = uuj11*uprod[n2] + uuj12*uprod[n2+1];
                double tmp1  = uuj21*uprod[n2] + uuj22*uprod[n2+1];
                double tmp   = d1*corfa[n]/vu2;
                rn0[n] = tmp0*tmp/rdip;
                rn1[n] = tmp1*tmp/eps[jdip-1];
            }
            rn2[n] = (vu*(vu+1)*rn0[n] - 2*rn1[n])/rdip;
        }
    }

/* Compute the differenced series coefficients:*/
    UpdateRenorPar(R_dip);
 
    double PLam = Lam;
    for(int n=0; n<MAXTERM;n++) 
    {  
        rn2[n] = rn2[n] - F2*(n+1)*(n+2)*PLam;
        rn3[n] = rn1[n] - F3*(n+1)      *PLam;
        rn4[n] = rn0[n] - F4            *PLam;
        rn0[n] = rn0[n] - F0            *PLam;
        rn1[n] = rn1[n] - F1*(n+1)      *PLam;
        PLam  *= Lam;        
    }

    
    for(int n=MAXTERM-1; n>=MINTERM; n--) if(fabs(rn2[n]/rn2[0])<1.e-6) Nterm = n;
    return U_OK;
}

void UMultiSphereModel::UpdateUmat(double rdip)
/* Test whether the dipole is still in the right shell. If not, update the 
   coefficients such that the potential can be computed as follows:


 -4*PI*psi = sigma corfa[n]*{ Mr*Rn1'*Yn00  + Mth*(Rn1/r0)*Yn10},
  
  with
  Rn1(r0) = LAM**VUj *{ Uj(1,1)*uprod[0] + Uj(1,2)*uprod[1] }
  Rn1'(r0)= LAM**VUj *{ Uj(2,1)*uprod[0] + Uj(2,2)*uprod[1] }/EPSj


  with  Uj = (R0/Rj+1)**-(VUj+2) * Sj-  + (R0/Rj+1)**VUj * Sj+

                           ( VUj*R0/Rj+1             -R0/EPSj )
  with Sj- = 1/(2VUj +1)  (                                    )
                           ( -VUj*(VUj+1)*EPSj/Rj      VUj+1  ) 

              
                           ( VUj+1                 Rj/EPSj    )
  with Sj+ = 1/(2VUj +1)  (                                    )
                           ( VUj*(VUj+1)*EPSj/R0  VUj*Rj+1/R0 ) 


  with  LAM    = R0/Rj
  and  VUj    = .5*(  -1+SQRT( 1+4*n*(n+1)*EHT(JS)/EPSj )  )

  where j refers to jdip

  Note(s):
  It is assumed that the dipole is closer to the center of the sphere than the dipole.
      
*/
{
    if(CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return; // Nothing to do

    int is = -1;
    for(int j=1;j<=Ns && rdip<=rs[j-1];j++) is=j;
    if(is==jdip) return; //Nothing to do!!

    jdip = is;

    for(int n=1;n<=MAXTERM;n++)
    {  
        double uuj11, uuj21, uuj12, uuj22;
        double prod11 =1.;
        double prod21 =0.;
        double prod12 =0.;
        double prod22 =1.;

        int j = Ns;
        for(      ;j>=jdip+1;j--)
        {  
            double vu  = (-1.+ sqrt(1 + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2. ;
            double vu2 = 2*vu+1;
            if(j==Ns) 
            {  
                uuj11 = 0. ;
                uuj21 = 0. ;
                uuj12 = 1./(eps[j-1]*vu2);
                uuj22 = vu/(rs[j-1]*vu2);
            }
            else
            {  
                double lam   = rs[j]/rs[j-1];
                double ss11  = vu+1;
                double ss21  = vu*(vu+1)*eps[j-1]/rs[j-1];
                double ss12  = rs[j]/eps[j-1];
                double ss22  = lam*vu;
                double p     = pow(lam,2*vu);
                uuj11 = (ss11 + p*ss22)/vu2;
                p     = p*lam;
                uuj21 = (ss21 - p*ss21)/vu2;
                uuj12 = (ss12 - p*ss12)/vu2;
                p     = p*lam;
                uuj22 = (ss22 + p*ss11)/vu2;
            }
            double hulp11 = prod11;
            double hulp21 = prod21;        
            double hulp12 = prod12;        
            double hulp22 = prod22;       
            prod11 = uuj11*hulp11 + uuj12*hulp21;
            prod21 = uuj21*hulp11 + uuj22*hulp21;
            prod12 = uuj11*hulp12 + uuj12*hulp22;
            prod22 = uuj21*hulp12 + uuj22*hulp22;
        }
        double p=1.; 
        j = jelec;
        for(     ;j<=jdip-1;j++)         
        {  
            double lam = rs[j]/rs[j-1];
            double vu  = (-1.+ sqrt(1. + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2. ;
            p   = p*pow(lam,vu);
        }
        double vu  = (-1.+ sqrt(1. + 4.*n*(n+1.)*eht[jelec-1]/eps[jelec-1] )  )/2.;
        double lam = relec/rs[jelec-1];
        p   = p/pow(lam,vu);
      
        uprod[2*n-2] = prod12*p;
        uprod[2*n-1] = prod22*p;
    }
}

ErrorType UMultiSphereModel::InitCorfa()
/* 
     Initialize the coefficients corfa[] for the three-sphere and the multi-sphere model.
     Allocate memory for the dipole dependent arrays rn0[], rn1[], rn2[], rn3[] and rn4[]. 
 */
{
    if(CondModel != U_CONDMOD_THREESPHERE && 
       CondModel != U_CONDMOD_MULTISPHERE) return U_OK;

    jdip  = -1;  // invalidate shell parameters
    jelec = -1;
    delete[] uprod;   uprod   = NULL;
    delete[] coefEIT; coefEIT = NULL;
    delete[] corfa;   corfa   = NULL;
    delete[] rn0;     rn0     = NULL;
    delete[] rn1;     rn1     = NULL;
    delete[] rn2;     rn2     = NULL;
    delete[] rn3;     rn3     = NULL;
    delete[] rn4;     rn4     = NULL;

    if(CondModel!=U_CONDMOD_THREESPHERE) uprod   = new double[2*MAXTERM]; // Coefficients not required for the three-sphere model
    
    bool AllowEIT =GetAllowEIT();
    if(AllowEIT)                         coefEIT = new double[  MAXTERM];

    corfa = new double[MAXTERM];
    rn0   = new double[MAXTERM];
    rn1   = new double[MAXTERM]; 
    rn2   = new double[MAXTERM]; 
    rn3   = new double[MAXTERM]; 
    rn4   = new double[MAXTERM]; 
    if(corfa==NULL || rn0==NULL || rn1==NULL || rn2==NULL || rn3==NULL || rn4==NULL ||
        (CondModel == U_CONDMOD_MULTISPHERE && uprod  ==NULL) ||
        (AllowEIT  == true                  && coefEIT==NULL))
    {
        delete[] uprod;   uprod   = NULL;
        delete[] coefEIT; coefEIT = NULL;
        delete[] corfa;   corfa   = NULL;
        delete[] rn0;     rn0     = NULL;
        delete[] rn1;     rn1     = NULL;
        delete[] rn2;     rn2     = NULL;
        delete[] rn3;     rn3     = NULL;
        delete[] rn4;     rn4     = NULL;

        Ns    = 0;
        for(int k=0; k<MAXSURFACE; k++) rs[k] = eps[k] = eht[k] = 0.;

        CI.AddToLog("ERROR: UMultiSphereModel::InitCorfa(). Memroy Allocation. \n");
        return U_ERROR;
    }

    if(CondModel==U_CONDMOD_THREESPHERE)
    {      
        jelec       = 1;        
        double ksi  = eps[1]/eps[0];
        double g1   = rs[2]/rs[0];
        double g2   = rs[1]/rs[0];
        double g12  = g1/g2;
        double pg1  = g1 *g1 *g1;
        double pg2  = g2 *g2 *g2;
        double pg12 = g12*g12*g12;

        int n,n2;
        for(n=1,n2=3;n<=MAXTERM;n++,n2+=2)
        {
            double teller  = ksi*n2*n2*n2/(PI4*eps[0]*HeadRadius*HeadRadius*n*(n+1));
            double noemer  = ((n+1)*ksi+n)*(1.+n*ksi/(n+1)) + (1.-ksi)*((n+1)*ksi+n)*(pg1-pg2) - n*(1.-ksi)*(1.-ksi)*pg12;

            corfa[n-1] = teller/noemer; 
            pg1  *= g1 *g1;
            pg2  *= g2 *g2;
            pg12 *= g12*g12;
        }
    }

/*  Compute the correction factors corfa[] for the general multi-sphere model. */
    else if(CondModel==U_CONDMOD_MULTISPHERE)
    {
        double R_elec = relec*HeadRadius;
        jelec = 1;
        for(int j=1;j<=Ns;j++) if(relec<rs[j-1]) jelec=j; 
    
        for(int n=1;n<=MAXTERM;n++)  
        {  
            double ss11 ,ss21 ,ss12 ,ss22 ,lam, p;
            double kkj11,kkj21,kkj12,kkj22,k11jel;
            double prod11 = 1.;
            double prod21 = 0.;
            double prod12 = 0.;
            double prod22 = 1.;
       
            for(int j=1;j<=Ns;j++)
            {  
                double vu =(-1.+ sqrt(1 + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2.;
                double vu2=2*vu+1;
                if(j==jelec) 
                {  
                    lam    =  relec/rs[j-1];
                    ss11   =  vu*lam;
                    ss12   = -relec/eps[j-1];
                    ss22   =  vu+1;
                    p      =  pow(lam,vu2);
                    kkj12  =  (ss12 - p*ss12)/vu2;
                    p      =  p*lam;
                    kkj11  =  (ss11 + p*ss22)/vu2;
                    k11jel =  kkj11*prod11 + kkj12*prod21;
                }
                if(j<Ns)
                {  
                    lam  =  rs[j]/rs[j-1];
                    ss11 =  vu*lam;
                    ss21 = -vu*(vu+1)*eps[j-1]/rs[j-1];
                    ss12 = -rs[j]/eps[j-1];
                    ss22 =  vu+1;
                
                    p     = pow(lam,vu+vu);
                    kkj22 = (ss22 + p*ss11)/vu2;
                    p     = p*lam;
                    kkj21 = (ss21 - p*ss21)/vu2;
                    kkj12 = (ss12 - p*ss12)/vu2;
                    p     = p*lam;        
                    kkj11 = (ss11 + p*ss22)/vu2;
                }
                else
                {  
                    kkj11 =  vu/(rs[j-1]*vu2);
                    kkj21 =  0.;
                    kkj12 = -1./(eps[j-1]*vu2);
                    kkj22 =  0.;
                }
                double hulp11 = prod11;         
                double hulp21 = prod21;         
                double hulp12 = prod12;         
                double hulp22 = prod22;         
                prod11 = kkj11*hulp11 + kkj12*hulp21;
                prod21 = kkj21*hulp11 + kkj22*hulp21;
                prod12 = kkj11*hulp12 + kkj12*hulp22;
                prod22 = kkj21*hulp12 + kkj22*hulp22;
            }
            corfa[n-1]= (2*n+1)*k11jel/(prod11*R_elec*R_elec*PI4);       
        }
    }
    
    if(AllowEIT  == true)
    {
        double ThetaElc = atan(InjectionSize/HeadRadius);
        double cosTh    = cos(ThetaElc);

        double Pn_1     = 1.;       // (n-1) th Legendre Polynomial of cos(ThetaElc)
        double Pn       = cosTh;    // n-th     Legendre Polynomial of cos(ThetaElc)
        double Sn_1     =  1;       // (n-1)-th Legendre Polynomial of cos(0)  == 1
        double Sn       =  1;       // n-th     Legendre Polynomial of cos(0)  == 1
    
        coefEIT[0]      = 0;
        for(int n=1; n<MAXTERM; n++)
        {
            double fr    = (2.*n+1.)/(n+1.);

            coefEIT[n]   = fr*(Pn_1-cosTh*Pn -(Sn_1-Sn))/(1+cosTh);

    // Recursions of the Legendre polynomials 
            double Pold  = Pn;
            Pn           = (  (2*n+1.)*cosTh*Pn - n*Pn_1   )/(n+1.);
            Pn_1         = Pold;

            Pold         = Sn;
            Sn           = (  (2*n+1.)*      Sn - n*Sn_1    )/(n+1.);
            Sn_1         = Pold;
        }

    //choosing between the homogeneous sphere model and the 3 layered sphere model

        if( ( eps[0] == eps[1] )&&( eps[1] == eps[2] ) )    //homogeneous
        {
            for(int n=1; n<MAXTERM;n++) coefEIT[n]  *=  rs[0]/( n * eps[0]);
        }
        else                                                //3 layered
        {
            double fn1   = pow(rs[2]/rs[1],3.);
            double fn2   = pow(rs[2]/rs[1],4.);
            double fn3   = pow(rs[1]/rs[0],4.);
            double fn4   = pow(rs[1]/rs[0],3.);
                
            for(int n=1; n<MAXTERM;n++)
            {
                double n1      = n+1;
                double D1      =  (n1*eps[0]+n*eps[1])*(n1*eps[1]+n*eps[2]) + n*(eps[1]-eps[2])*n1*(eps[0]-eps[1])  *fn1;
                double D2      =  n* (eps[0] - eps[1])*(n1*eps[1]+n*eps[2]) + n*(eps[1]-eps[2])*(n*eps[0]+n1*eps[1])*fn1;
                double DDn     = rs[1]*D1/D2;
                double EEn     =  eps[0] * (rs[1]/rs[0]) * DDn - (n1/n) * eps[0] * rs[1] * fn3;
                coefEIT[n]    *=   rs[1] *( DDn + fn4*rs[1])/(n*EEn);

                fn1           *=   rs[2]*rs[2]/(rs[1]*rs[1]);
                fn2           *=   rs[2]*rs[2]/(rs[1]*rs[1]);
                fn3           *=   rs[1]*rs[1]/(rs[0]*rs[0]);
                fn4           *=   rs[1]*rs[1]/(rs[0]*rs[0]);
            }
        }
    }
    return U_OK;
}

void UMultiSphereModel::UpdateRenorPar(double r0)
/*
     Compute the renormalization parameters, Lam, F0, F1, F2, F3 and F4, for the given
     radial dipole coordinate r0 [cm].
 */
{    
    if(CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return; // Nothing to do

/* Determine the dipole shell number */    
    int j0 = -1;
    int j  =  0;
    for(       ;j<Ns; j++) 
        if(r0<=rs[j]*HeadRadius) j0=j;

    Lam      = 1.;
    double A = 1./PI4;
    j = jelec-1;
    for(       ;j<=j0;j++) 
    {  
        double alfa  = sqrt(eht[j]/eps[j]);
        double alfa2 = .5*(alfa-1.);
        if(j==jelec-1)
        {  
            double lam = rs[j]/relec;
            Lam *= pow(lam,alfa);
            A     *= pow(lam,alfa2);
        }
        double lam = rs[j+1]/rs[j];
        if(j==j0) 
            lam = r0/(HeadRadius*rs[j]);
        Lam *= pow(lam,alfa);
        A     *= pow(lam,alfa2);
    }

    double beta = sqrt(eht[jelec-1]*eps[jelec-1]);
    double F    = 1.;
    for(j=jelec-1;j<j0;j++)
    {  
        double beta1 = sqrt(eht[j+1]*eps[j+1]);
        F    *= 2*beta1/(beta+beta1);
        beta  = beta1;
    }
    beta = sqrt(eht[j0]*eps[j0]);
    F0 = A*F/(beta*relec*HeadRadius);
    
    if(relec==1.) F0 *= 2;

    F0 =  F0 / r0;
    F1 =  F0 * beta   / eps[j0];
    F2 = (F0 * eht[j0]/ eps[j0]) * (HeadRadius/r0);
    F3 =  F1;
    F4 =  F0;
}

void UMultiSphereModel::GetSums(double cosom, double *sum0, double* sum1, double* sum2, double* sum3, double* sum4) const
/*
    Compute the sums of Legendre series needed in the computation of the multi-sphere
    potentials, and their derivatives.
    cosom is the cosine of the angle between dipole and electrode.
 */
{
    if(CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return; // Nothing to do

    double Pnm00 = cosom;
    double Pnm01 = 1.;
    double Pnm02 = 0.;
    double Pnm10 = 1.;
    double PnmOld;

    bool sum234 = true;
    if(sum2==NULL || sum3==NULL || sum4==NULL) sum234 = false;

    *sum0 = *sum1 = 0.;
    if(sum234==true) *sum2 = *sum3 = *sum4 = 0.;

    for(int n=0; n<Nterm; n++) 
    {  
        *sum0  +=  rn0[n] * Pnm01;
        *sum1  +=  rn1[n] * Pnm00;
        if(sum234==true)
        {
            *sum2  +=  rn2[n] * Pnm00;
            *sum3  +=  rn1[n] * Pnm01;
            *sum4  +=  rn0[n] * Pnm02;

            Pnm02  =  cosom*Pnm02 +(n+3)*Pnm01; 
        }
        Pnm01  =  cosom*Pnm01 +(n+2)*Pnm00; 
        PnmOld =  Pnm00;
        Pnm00  = ((2*n+3)*cosom*Pnm00 - (n+1)*Pnm10)/(n+2);
        Pnm10  =  PnmOld;
    }

/* Add the asymptotic approximation in closed form*/
    double R2 = 1. - 2*cosom*Lam + Lam*Lam;
    double R3 = R2*sqrt(R2);
    double R5 = R3*R2;
    *sum0 += F0 * Lam               / R3;
    *sum1 += F1 * Lam * (cosom-Lam) / R3;
    if(sum234==true)
    {
        *sum2 += F2 * Lam * ((2*cosom-3*Lam)*R2 +3*Lam*(cosom-Lam)*(cosom-Lam))/R5;
        *sum3 += F3 * Lam * ( 3*Lam*(cosom-Lam) + R2) / R5;
        *sum4 += F4 * Lam * Lam *3                    / R5;
    }
}

double UMultiSphereModel::GetPotentialEIT(double Current, UVector3 Xinject, UVector3 Xextract) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetPotentialEIT(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(coefEIT==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetPotentialEIT(). coefEIT[] coefficients not set.\n");
        return 0.;
    }
    double Ri     = Xinject .GetNorm();
    double Re     = Xextract.GetNorm();
    if(Ri<=0. || Re<=0.)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetPotentialEIT(). Invalid NULL vector argument(s).\n");
        return 0.;
    }
    double cosom  = (Xinject&Xextract) / ( Ri*Re );

    double P1n_1  = 1.;      // (n-1) th Legendre Polynomial of cosom
    double P1n    = cosom;   // n-th     Legendre Polynomial of cosom
    double sum    = 0;

    for(int n=1; n<MAXTERM; n++)
    {
        sum           += coefEIT[n]*P1n;

        double Pold   = P1n;
        P1n           = (  (2*n+1.)*cosom*P1n - n*P1n_1   )/(n+1);
        P1n_1         = Pold;
    }
// Calibration issues:
//return Current*sum*HeadRadius/PI;
// Calibration, corrected implementation
// (excessive division by PI removed;
// division by electrode area (PI2*(1-cos(InjectionSize/HeadRadius))*HeadRadius*HeadRadius) included to convert Current to current density):
    return Current*sum/(PI2*(1-cos(InjectionSize/HeadRadius))*HeadRadius);
}
double UMultiSphereModel::GetPotentialEIT(double Current, double ElSizeCm, UVector3 Xextract)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetPotentialEIT(). Object NULL or erroneous.\n");
        return 0.;
    }
    if(coefEIT==NULL || ElSizeCm!=InjectionSize)
    {
        if(SetInjectionSize(ElSizeCm)!=U_OK)
        {
            CI.AddToLog("ERROR: UMultiSphereModel::GetPotentialEIT(). Setting Electrode size.\n");
            return 0.;
        }
    }

    return GetPotentialEIT(Current, UVector3(0.,0.,HeadRadius), Xextract);
}

double UMultiSphereModel::GetPotential(UDipole Dip, UVector3 Xpos) const
{
    return Dip.Getd() & GetLeadField(Dip, Xpos);
}
UVector3 UMultiSphereModel::GetLeadField(UDipole Dip, UVector3 Xpos) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetLeadField(). Object NULL or erroneous. \n");
        return UVector3();
    }
    if(eps  ==NULL || eht==NULL || rs ==NULL ||
       corfa==NULL || rn0==NULL || rn1==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetLeadField(). Object not properly set. \n");
        return UVector3();
    }
    if(CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) 
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetLeadField(). Wrong CondModel (=%d). \n", CondModel);
        return UVector3();
    }

    UVector3 Xel = Xpos -SpherePos;
    UVector3 Xdi = Dip.Getx()-SpherePos;
    double   re  = Xel.GetNorm(); 
    double   rd  = Xdi.GetNorm(); 
    if(re<=0 || re>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetLeadField(). Elec radius out of range (re=%f, HeadRadius=%f). \n", re, HeadRadius);
        return UVector3();
    }
    if(rd<=0 || rd>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel::GetLeadField(). Dip radius out of range (re=%f, HeadRadius=%f). \n", rd, HeadRadius);
        return UVector3();
    }

    double cosom = (Xel&Xdi)/(re*rd);
    double sum0  = 0;
    double sum1  = 0;
        
    GetSums(cosom, &sum0, &sum1);

    double f_xs  =  sum0/re;
    double f_xd  = (sum1-sum0*cosom)/rd;
    return f_xs*Xel + f_xd*Xdi;
}

bool UMultiSphereModel::GetAllowEIT(void) const
{
    if(this==NULL || error!=U_OK || eps==NULL || eht==NULL) return false;
    return ( Ns == 3 && eps[0] == eht[0] && eps[1] == eht[1] && eps[2] == eht[2]);
}
