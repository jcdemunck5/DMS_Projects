#ifndef _MULTISPHERE_INCLUDED
#define _MULTISPHERE_INCLUDED

#include"HeadModel.h"

/*
  Update history
  
  Who    When       What
  JdM    17-08-01   Made desctructor virtual
*/

class DLL_IO UMultiSphereModel
{
public:
    UMultiSphereModel();
    UMultiSphereModel(const UHeadModel* HM);
    UMultiSphereModel(const UMultiSphereModel &MSM);        
    virtual ~UMultiSphereModel();
    UMultiSphereModel& operator=(const UMultiSphereModel &MSM);

    ErrorType           GetError(void) const     {return error;}
    const UString&      GetProperties(UString Comment) const;
    double              GetInnerRadius(void) const; 

    ErrorType           SetRelativeElectrodeRadius(double rel);
    ErrorType           SetInjectionSize(double ElSizeCm);

    double              GetPotentialEIT(double Current, UVector3 Xinject, UVector3 Xextract) const;
    double              GetPotentialEIT(double Current, double ElSizeCm, UVector3 Xextract);
    double              GetPotential(UDipole Dip, UVector3 Xpos) const;
    UVector3            GetLeadField(UDipole Dip, UVector3 Xpos) const;

    static const double ELRADIUS;
protected:
    double              GetEps(int j=0) const    {if(j<0 || j>=Ns) return -1;
                                                  else             return eps[j];}
    ErrorType           SetSigma(const double* Sigma);
    ErrorType           UpdateRadialCoefficients(UVector3 DipolePos);
    void                GetSums(double cosom, double *sum0, double* sum1, double* sum2=NULL, double* sum3=NULL, double* sum4=NULL) const;
    ErrorType           ProjectElectrode(UVector3* Xelec) const;
    

    CondModelType       CondModel;       // Exact type of multi-sphere model
    UVector3            SpherePos;       // The position of the best fitting sphere of the head w.r.t.NLR
    double              HeadRadius;      // The radius of the best fitting sphere

    int                 Ns;              // number of concentric spheres, compartments, surfaces
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:
    static const int    MAXTERM;         // The maximum number of terms used in the multi-sphere models
    static const int    MINTERM;         // The minimum number of terms used in the multi-sphere models

    static UString      Properties;      // Array to store the current properties of the object.
    ErrorType           error;           // General error flag


// Computations and data for the multi-sphere model.
    ErrorType           InitCorfa(void);         
    void                UpdateUmat(double rdip); 
    void                UpdateRenorPar(double rdip);
    
    int                 jdip;            // integer refering to the dipole shell (only used in UpdateUmat())
    int                 jelec;           // integer refering to the electrode shell (only used in UpdateUmat())
    double              relec;           // relative radial coordinates of the electrodes.

    double*             rs;              // relative sphere radii (fractions of HeadRadius)
    double*             eps;             // radial conductivities
    double*             eht;             // tangential conductivities

    double*             coefEIT;         // Coefficients for the multi-sphere model in case of the EIT problem
    double*             corfa;           // Coefficients to compute the potential. These coefficients  are
    double*             rn0;             // computed and deleted by this object.
    double*             rn1;
    double*             rn2;
    double*             rn3;
    double*             rn4;
    double*             uprod;
    double              Lam, F0, F1, F2, F3, F4; // Renormalisation parameters, used to compute matched series of differences
    int                 Nterm;           // The number of terms that are actually used

    double              InjectionSize;   // electrode radius (measured along the spherical surface) in case of current injection, [cm]
    bool                GetAllowEIT(void) const;
};

#endif // _MULTISPHERE_INCLUDED
