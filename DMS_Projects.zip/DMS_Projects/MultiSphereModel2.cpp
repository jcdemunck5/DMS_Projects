/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*     GENERAL                                                                   */
/*     Module for doing a few (pre-) computations in the multi-Sphere model.     */
/*                                                                               */
/*                                                                               */
/*     NOTES                                                                     */
/*     All coordinates are given in the head coordinate system:                  */
/*     nasion-left-right.                                                        */
/*                                                                               */
/*     USAGE                                                                     */
/*     A UMultiSphereModel2-object can be created from a pointer to an UHeadModel*/
/*     object. In the UHeadModel-object the data needed for the multi-sphere     */
/*     model are determined (from file or other constructors) and the            */
/*     computations required in the model are done here, in the                  */
/*     UMultiSphereModel2 -object. In practice, the UHeadModel-pointer is passed */
/*     to the UEMfield-object, which determines the nature of the model          */
/*     (realistic or multi-sphere) and passes the UHeadModel pointer to here.    */
/*     The UEMfield object calls functions of UMultiSphereModel2 for the         */
/*     updates of the tables and coefficients when needed in the multi-sphere    */
/*     models.                                                                   */
/*     Realistic model are treated by the other base classe of the UEMfield      */
/*     object (UBemField).                                                       */
/*                                                                               */
/*     AUTHOR                                                                    */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history

  Who    When       What
  Jdm    22-05-00   creation, by splitting UHeadModel into two
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    25-10-00   Prevent the launching of error messages caused by inconsistency between Model and HM
  GdV    14-10-04   declared some undeclared identifiers (for g++-compatibility)
  JdM    28-03-05   Added SetAllMembersDefault(), DeleteAllMembers(). Default constructor, copy constructor and operator=(). Use UString for GetProperties()
  JdM    30-10-06   Added GetPotential() and GetLeadField()
  JdM    18-09-09
    JdM    11-11-06   Safer addressing of arrays
    JdM    13-11-06   Added SetRelativeElectrodeRadius()
    JdM    15-11-06   InitCorfa(). delete arrays before creating new ones.
    JdM    16-11-06   increased MAXTERM from 300 to 3000
    JdM    05-11-07   Constructor : Set error to U_OK in case of non-sphere model

  JdM    21-11-07   Adapted to new implementation of UHeadModel::ModelType
  JdM    30-08-08   Added parameter to DeleteAllMembers()
  JdM    18-09-09   (Partly) Integrated UMultiSphereModel2 and UMultiSphereModel.
                    To do: derivatives, special treatment of U_CONDMOD_HOMSPHERE and U_CONDMOD_THREESPHERE models.
*/


#include <string.h>
#include "MultiSphereModel2.h"

/* Inititalize static const parameters. */
/* Inititalize static const parameters. */
UString      UMultiSphereModel2::Properties = UString();
const int    UMultiSphereModel2::MAXTERM    =  3000;
const int    UMultiSphereModel2::MINTERM    =  10;

void UMultiSphereModel2::SetAllMembersDefault(void)
{
    eps  = eht = rs = NULL;
    Numer       = NULL;
    LamPower    = NULL;
    UmatInner12 = NULL;
    UmatInner22 = NULL;
    UmatOuter21 = NULL;
    UmatOuter22 = NULL;

    rn0         = NULL;
    rn1         = NULL;

    Ns          =  0;
    jinner      = -1;
    jouter      = -1;
    rdip = relc = 0.;
    Nterm       =  0;

    Properties  = UString();
    error       = U_OK;
}

void UMultiSphereModel2::DeleteAllMembers(ErrorType E)
{
    delete[] eps;
    delete[] eht;
    delete[] rs;
    delete[] Numer;
    delete[] LamPower;
    delete[] UmatInner12;
    delete[] UmatInner22;
    delete[] UmatOuter21;
    delete[] UmatOuter22;
    delete[] rn0;
    delete[] rn1;
    SetAllMembersDefault();
    error = E;
}

UMultiSphereModel2::UMultiSphereModel2()
{
    SetAllMembersDefault();
}

UMultiSphereModel2::UMultiSphereModel2(const UHeadModel* HM)
/*
      Initialize the multi-sphere model for by data collected by *HM.
 */
{
    SetAllMembersDefault();
    if(HM==NULL) return;

    if(HM->GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel2::UMultiSphereModel2(). Erroneous argument. \n");
        return;
    }
    CondModel = HM->GetCondModelType();
    switch(CondModel)
    {
    case U_CONDMOD_SPHERE:
    case U_CONDMOD_HOMSPHERE:
    case U_CONDMOD_THREESPHERE:
    case U_CONDMOD_MULTISPHERE:
        break;
    default:
        return;
    }

    Ns  = HM->GetNshell();
    if(Ns<0) Ns = 0;

    if(Ns>0)
    {
        eps = new double[Ns];
        eht = new double[Ns];
        rs  = new double[Ns];
        if(eht==NULL || eps==NULL || rs==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel2::UMultiSphereModel2(). Memory allocation. Ns=%d\n.",Ns);
            return;
        }
        for(int k=0; k<Ns; k++)
        {
            eps[k] = HM->GetEps(k);
            eht[k] = HM->GetEht(k);
            rs[k]  = HM->GetRs(k);
        }
    }
    HeadRadius = HM->GetHeadRadius();
    SpherePos  = HM->GetSpherePos();

    if(InitCoefArrays()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel2::UMultiSphereModel2(). Initializig coefficients.\n.");
        return;
    }
}

UMultiSphereModel2::UMultiSphereModel2(const UMultiSphereModel2 &MSM)
{
    SetAllMembersDefault();
    *this = MSM;
}

UMultiSphereModel2::~UMultiSphereModel2()
{
    DeleteAllMembers(U_OK);
}

UMultiSphereModel2& UMultiSphereModel2::operator=(const UMultiSphereModel2 &MSM)
{
    if(this==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). this==NULL . \n");
        static UMultiSphereModel2 M; M.error = U_ERROR;
        return M;
    }
    if(&MSM==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). Invalid NULL Address argument. \n");
        DeleteAllMembers(U_ERROR);
        return *this;
    }
    if(this==&MSM) return *this;

    DeleteAllMembers(U_OK);

    error      = MSM.error;
    Ns         = MSM.Ns;
    jinner     = MSM.jinner;
    jouter     = MSM.jouter;
    rdip       = MSM.rdip;
    relc       = MSM.relc;
    Nterm      = MSM.Nterm;

    if(MSM.eps)
    {
        eps = new double[MSM.Ns];
        if(eps) for(int k=0; k<Ns; k++) eps[k] = MSM.eps[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }
    if(MSM.eht)
    {
        eht = new double[MSM.Ns];
        if(eht) for(int k=0; k<Ns; k++) eht[k] = MSM.eht[k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }
    if(MSM.rs )
    {
        rs  = new double[MSM.Ns];
        if(rs ) for(int k=0; k<Ns; k++) rs [k] = MSM.rs [k];
        else
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). memory allocation, Ns = %d  . \n", MSM.Ns);
            return *this;
        }
    }

    if(MSM.Numer      )   Numer         = new double[MAXTERM];
    if(MSM.LamPower   )   LamPower      = new double[MAXTERM];
    if(MSM.UmatInner12)   UmatInner12   = new double[MAXTERM];
    if(MSM.UmatInner22)   UmatInner22   = new double[MAXTERM];
    if(MSM.UmatOuter21)   UmatOuter21   = new double[MAXTERM];
    if(MSM.UmatOuter22)   UmatOuter22   = new double[MAXTERM];
    if(MSM.rn0        )   rn0           = new double[MAXTERM];
    if(MSM.rn1        )   rn1           = new double[MAXTERM];

    if((MSM.Numer       && !Numer)       ||
       (MSM.LamPower    && !LamPower)    ||
       (MSM.UmatInner12 && !UmatInner12) ||
       (MSM.UmatInner22 && !UmatInner22) ||
       (MSM.UmatOuter21 && !UmatOuter21) ||
       (MSM.UmatOuter22 && !UmatOuter22) ||
       (MSM.rn0         && !rn0)         ||
       (MSM.rn1         && !rn1)        )
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UMultiSphereModel2::operator=(). Copying help arrays (MAXTERM=%d) . \n", MAXTERM);
        return *this;
    }
    for(int k=0; k<MAXTERM; k++)
    {
        if(Numer)        Numer      [k] = MSM.Numer      [k];
        if(LamPower)     LamPower   [k] = MSM.LamPower   [k];
        if(UmatInner12)  UmatInner12[k] = MSM.UmatInner12[k];
        if(UmatInner22)  UmatInner22[k] = MSM.UmatInner22[k];
        if(UmatOuter21)  UmatOuter21[k] = MSM.UmatOuter21[k];
        if(UmatOuter22)  UmatOuter22[k] = MSM.UmatOuter22[k];
        if(rn0        )  rn0        [k] = MSM.rn0        [k];
        if(rn1        )  rn1        [k] = MSM.rn1        [k];
    }
    return *this;
}

const UString& UMultiSphereModel2::GetProperties(UString Comment) const
{
    if(error!=U_OK)
    {
        Properties = UString(" ERROR in UMultiSphereModel2-object");
        return Properties;
    }
    Properties   = UString();
    Properties  += UString(" MultiSphere Model: \n");

    switch(CondModel)
    {
    case U_CONDMOD_SPHERE:
        Properties += UString(" MSModel = Sphere model // (MEG only)  \n");
        break;
    case U_CONDMOD_HOMSPHERE:
        Properties += UString(" MSModel = Homogeneous sphere \n");
        break;
    case U_CONDMOD_THREESPHERE:
        Properties += UString(" MSModel = The standard three-sphere model \n");
        break;
    case U_CONDMOD_MULTISPHERE:
        Properties += UString(" MSModel = The general multi-sphere model \n");
        break;
    default:
        Properties += UString(" MSModel = ERROR in Head model: Erroneous head model \n");
    }
    Properties += UString(SpherePos.GetProperties(), " SPHERE_POS  = %s \n");
    Properties += UString(HeadRadius               , " HEAD_RADIUS = %7.2f \n");

    Properties += UString(" Radii: ");
    if(rs) for(int k=0; k<Ns; k++) Properties += UString(rs[k], " %6.2f,");
    Properties += UString("\n");

    Properties += UString(" Eps: ");
    if(eps) for(int k=0; k<Ns; k++) Properties += UString(eps[k], " %10.6f,");
    Properties += UString("\n");

    Properties += UString(" Eht: ");
    if(eht) for(int k=0; k<Ns; k++) Properties += UString(eht[k], " %10.6f,");
    Properties += UString("\n");

    if(Comment.IsNULL() || Comment.IsEmpty())
        Properties.ReplaceAll('\n', ';');
    else
        Properties.InsertAtEachLine(Comment);

    return Properties;
}
double UMultiSphereModel2::GetEps(int j) const
{
    if(this==NULL || error!=U_OK || eps==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetEps(). Object NULL or erroneous or not correctly set.\n");
        return -1.;
    }
    if(j<0 || j>=Ns)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetEps(). Argument out of range (j=%d, Ns=%d). \n", j, Ns);
        return -1;
    }
    return eps[j];
}

ErrorType UMultiSphereModel2::SetRelativeElectrodeRadius(double rel)
{
    if(CondModel!=U_CONDMOD_HOMSPHERE &&
       CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return U_ERROR;

    if(rel<=0 || rel>1)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::SetRelativeElectrodeRadius(). rel = %f out of range. \n",rel);
        return U_ERROR;
    }
    relc = rel;
    if(CondModel==U_CONDMOD_HOMSPHERE) return U_OK;

    return InitCoefArrays();
}
ErrorType UMultiSphereModel2::SetSigma(const double* Sigma)
/*
     Set the radial and tangential conductivities equal to
     Sigma[0], Sigma[1], etc, for the multi-sphere model. Update
     the correction factors, used for the computation of the potentials.
 */
{
    if(CondModel!=U_CONDMOD_HOMSPHERE &&
       CondModel!=U_CONDMOD_THREESPHERE &&
       CondModel!=U_CONDMOD_MULTISPHERE) return U_ERROR;

    for(int j=0; j<Ns; j++)
        if(Sigma[j] <=0)
        {
            CI.AddToLog("ERROR: UMultiSphereModel2::SetSigma(). Sigma = %f <=0. !!\n",Sigma[j]);
            return U_ERROR;
        }

    for(int j=0; j<Ns; j++) eht[j] = eps[j] = Sigma[j];
    if(CondModel==U_CONDMOD_HOMSPHERE) return U_OK;

    return InitCoefArrays();
}

ErrorType UMultiSphereModel2::ProjectElectrode(UVector3* Xelec) const
{
    if( CondModel==U_CONDMOD_HOMSPHERE ||
        CondModel==U_CONDMOD_THREESPHERE )
    {   // Project the electrode onto the outer sphere
        Xelec->Normalize();
        *Xelec = *Xelec * HeadRadius;
    }
    else if(CondModel==U_CONDMOD_MULTISPHERE)
    {   // Project the electrode onto a spherical surface, possibly sub-surface
        Xelec->Normalize();
        *Xelec = *Xelec * (HeadRadius*relc);
    }
    return U_OK;
}

ErrorType UMultiSphereModel2::InitCoefArrays()
{
    if(CondModel != U_CONDMOD_HOMSPHERE   &&
       CondModel != U_CONDMOD_THREESPHERE &&
       CondModel != U_CONDMOD_MULTISPHERE) return U_OK;

    delete[] Numer;
    delete[] LamPower;
    delete[] UmatInner12;
    delete[] UmatInner22;
    delete[] UmatOuter21;
    delete[] UmatOuter22;
    delete[] rn0;
    delete[] rn1;

    Numer         = new double[MAXTERM];
    LamPower      = new double[MAXTERM];
    UmatInner12   = new double[MAXTERM];
    UmatInner22   = new double[MAXTERM];
    UmatOuter21   = new double[MAXTERM];
    UmatOuter22   = new double[MAXTERM];
    rn0           = new double[MAXTERM];
    rn1           = new double[MAXTERM];


    if(Numer      ==NULL || LamPower   ==NULL ||
       rn0        ==NULL || rn1        ==NULL ||
       UmatInner12==NULL || UmatInner22==NULL ||
       UmatOuter21==NULL || UmatOuter22==NULL)
    {
        delete[] Numer;         Numer       = NULL;
        delete[] LamPower;      LamPower    = NULL;
        delete[] UmatInner12;   UmatInner12 = NULL;
        delete[] UmatInner22;   UmatInner22 = NULL;
        delete[] UmatOuter21;   UmatOuter21 = NULL;
        delete[] UmatOuter22;   UmatOuter22 = NULL;
        delete[] rn0;           rn0         = NULL;
        delete[] rn1;           rn1         = NULL;

        CI.AddToLog("ERROR: UMultiSphereModel2::InitCoefArrays(). Memroy Allocation. \n");
        return U_ERROR;
    }
    for(int k=0; k<MAXTERM; k++)
    {
        Numer      [k] = 0.;
        LamPower   [k] = 0.;
        UmatInner12[k] = 0.;
        UmatInner22[k] = 0.;
        UmatOuter21[k] = 0.;
        UmatOuter22[k] = 0.;
        rn0        [k] = 0.;
        rn1        [k] = 0.;
    }

    for(int n=1;n<=MAXTERM;n++)
    {
        double ss11 ,ss21 ,ss12 ,ss22 ,lam, p;
        double kkj11,kkj21,kkj12,kkj22;
        double prod11 = 1.;
        double prod21 = 0.;
        double prod12 = 0.;
        double prod22 = 1.;

        for(int j=1;j<=Ns;j++)
        {
            double vu =(-1.+ sqrt(1 + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2.;
            double vu2=2*vu+1;
            if(j<Ns)
            {
                lam  =  rs[j]/rs[j-1];
                ss11 =  vu*lam;
                ss21 = -vu*(vu+1)*eps[j-1]/rs[j-1];
                ss12 = -rs[j]/eps[j-1];
                ss22 =  vu+1;

                p     = pow(lam,vu+vu);
                kkj22 = (ss22 + p*ss11)/vu2;
                p     = p*lam;
                kkj21 = (ss21 - p*ss21)/vu2;
                kkj12 = (ss12 - p*ss12)/vu2;
                p     = p*lam;
                kkj11 = (ss11 + p*ss22)/vu2;
            }
            else
            {
                kkj11 =  vu/(rs[j-1]*vu2);
                kkj21 =  0.;
                kkj12 = -1./(eps[j-1]*vu2);
                kkj22 =  0.;
            }
            double hulp11 = prod11;
            double hulp21 = prod21;
            double hulp12 = prod12;
            double hulp22 = prod22;
            prod11 = kkj11*hulp11 + kkj12*hulp21;
            prod21 = kkj21*hulp11 + kkj22*hulp21;
            prod12 = kkj11*hulp12 + kkj12*hulp22;
            prod22 = kkj21*hulp12 + kkj22*hulp22;
        }
        Numer[n-1]= PI4*prod11*HeadRadius*HeadRadius/(2*n+1.);
    }
    return U_OK;
}

ErrorType UMultiSphereModel2::UpdateUmat(double Rdip, double Relec)
{
    if(CondModel != U_CONDMOD_HOMSPHERE   &&
       CondModel != U_CONDMOD_THREESPHERE &&
       CondModel != U_CONDMOD_MULTISPHERE) return U_OK;

    if(Rdip<0   || Rdip>=HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::UpdateUmat(). Dip radius out of range (re=%f, HeadRadius=%f). \n", Rdip, HeadRadius);
        return U_ERROR;
    }
    if(Relec<0 || Relec>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::UpdateUmat(). Elec radius out of range (re=%f, HeadRadius=%f). \n", Relec, HeadRadius);
        return U_ERROR;
    }
    if(Numer      ==NULL || LamPower   ==NULL ||
       rn0        ==NULL || rn1        ==NULL ||
       UmatInner12==NULL || UmatInner22==NULL ||
       UmatOuter21==NULL || UmatOuter22==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::UpdateUmat(). Arrays not set. \n", Relec, HeadRadius);
        return U_ERROR;
    }

    bool UpdateIn = InnerPointChanged(Rdip, Relec);
    bool UpdateOt = OuterPointChanged(Rdip, Relec);

    if(UpdateIn==true)
    {
        for(int n=1;n<=MAXTERM;n++)
        {
            double prod12 = 0.;
            double prod22 = 1.;

            for(int j = Ns;j>=jinner+1;j--)
            {
                double uuj11, uuj21, uuj12, uuj22;

                double vu  = (-1.+ sqrt(1 + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2. ;
                double vu2 = 2*vu+1;
                if(j==Ns)
                {
                    uuj11 = 0. ;
                    uuj21 = 0. ;
                    uuj12 = 1./(eps[j-1]*vu2);
                    uuj22 = vu/( rs[j-1]*vu2);
                }
                else
                {
                    double lam   = rs[j]/rs[j-1];
                    double ss11  = vu+1;
                    double ss21  = vu*(vu+1)*eps[j-1]/rs[j-1];
                    double ss12  = rs[j]/eps[j-1];
                    double ss22  = lam*vu;
                    double p     = pow(lam,2*vu);
                    uuj11 = (ss11 + p*ss22)/vu2;
                    p     = p*lam;
                    uuj21 = (ss21 - p*ss21)/vu2;
                    uuj12 = (ss12 - p*ss12)/vu2;
                    p     = p*lam;
                    uuj22 = (ss22 + p*ss11)/vu2;
                }
                double hulp12 = prod12;
                double hulp22 = prod22;
                prod12 = uuj11*hulp12 + uuj12*hulp22;
                prod22 = uuj21*hulp12 + uuj22*hulp22;
            }
            UmatInner12[n-1] = prod12;
            UmatInner22[n-1] = prod22;
        }
    }
    if(UpdateOt==true)
    {
        for(int n=1;n<=MAXTERM;n++)
        {
            double prod21 = 0.;
            double prod22 = 1.;

            for(int j = 1; j<jouter; j++)
            {
                double uuj11, uuj21, uuj12, uuj22;
                double vu     = (-1.+ sqrt(1 + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2. ;
                double vu2    = 2*vu+1;

                double lam    = rs[j]/rs[j-1];
                double ss11   = vu+1;
                double ss21   = vu*(vu+1)*eps[j-1]/rs[j-1];
                double ss12   = rs[j]/eps[j-1];
                double ss22   = lam*vu;
                double p      = pow(lam,2*vu);
                uuj11         = (ss11 + p*ss22)/vu2;
                p             =  p*lam;
                uuj21         = (ss21 - p*ss21)/vu2;
                uuj12         = (ss12 - p*ss12)/vu2;
                p             =  p*lam;
                uuj22         = (ss22 + p*ss11)/vu2;

                double hulp21 = prod21;
                double hulp22 = prod22;
                prod21 = hulp21*uuj11 + hulp22*uuj21;
                prod22 = hulp21*uuj12 + hulp22*uuj22;
            }
            UmatOuter21[n-1] = prod21;
            UmatOuter22[n-1] = prod22;
        }
    }
    if(UpdateIn==true||UpdateOt==true)
    {
        for(int n=1;n<=MAXTERM;n++)
        {
            double p=1.;
            for(int j=jouter;j<=jinner-1;j++)
            {
                double lam = rs[j]/rs[j-1];
                double vu  = (-1.+ sqrt(1. + 4.*n*(n+1.)*eht[j-1]/eps[j-1] )  )/2. ;
                p   = p*pow(lam,vu);
            }
            LamPower[n-1] = p;
        }
    }

/* Update rno[] and rn1[] */
    double rdip   = Rdip /HeadRadius;
    double rinner = Rdip<Relec? Rdip /HeadRadius : Relec/HeadRadius;
    double router = Rdip<Relec? Relec/HeadRadius : Rdip /HeadRadius;

    double lamin   = 1;  if(jinner< Ns) lamin = rs[jinner  ]/rinner;
    double lamot   = 1;  if(jouter<=Ns) lamot = router/rs[jouter-1];

    for(int n=1;n<=MAXTERM;n++)
    {
        double vu       = (-1.+ sqrt(1 + 4.*n*(n+1.)*eht[jinner-1]/eps[jinner-1] )  )/2. ;
        double vu2      = 2*vu+1;
        double Plamin0  = pow(rinner/rs[jinner-1],vu);
        double prin     = 1;
        double prot     = 1;
        double pder     = 1;
        if(jinner==Ns)
        {
            prin                = 1./(vu2*       eps[jinner-1]);
            if(Rdip<Relec) pder = vu/(vu2*rinner*eps[jinner-1]);
        }
        else
        {
            double ss11  = vu+1;
            double ss21  = vu*(vu+1) *eps[jinner-1]/rinner;
            double ss12  = rs[jinner]/eps[jinner-1];
            double ss22  = lamin*vu;

            double d2    =  pow(lamin,2*vu);
            double uuj11 = (ss11 + d2*ss22)/vu2;
                   d2    =  d2*lamin;
            double uuj21 = (ss21 - d2*ss21)/vu2;
            double uuj12 = (ss12 - d2*ss12)/vu2;
                   d2    =  d2*lamin;
            double uuj22 = (ss22 + d2*ss11)/vu2;

            prin         =  uuj11*UmatInner12[n-1] + uuj12*UmatInner22[n-1];
            if(Rdip<Relec)
                pder     = (uuj21*UmatInner12[n-1] + uuj22*UmatInner22[n-1])/eps[jinner-1];
        }
        vu               = (-1.+ sqrt(1 + 4.*n*(n+1.)*eht[jouter-1]/eps[jouter-1] )  )/2.;
        vu2              = 2*vu+1;
        double Plamot0   = pow(router/rs[jouter-1],vu);

        double ss11      = vu+1;
        double ss21      = vu*(vu+1) *eps[jouter-1]/rs[jouter-1];
        double ss12      = router    /eps[jouter-1];
        double ss22      = lamot*vu;

        double d2        =  pow(lamot,2*vu);
        double uuj11     = (ss11 + d2*ss22)/vu2;
               d2        =  d2*lamot;
        double uuj21     = (ss21 - d2*ss21)/vu2;
        double uuj12     = (ss12 - d2*ss12)/vu2;
               d2        =  d2*lamot;
        double uuj22     = (ss22 + d2*ss11)/vu2;
        prot             =  UmatOuter21[n-1]*uuj12 + UmatOuter22[n-1]*uuj22;
        if(Rdip>=Relec)
            pder         =-(UmatOuter21[n-1]*uuj11 + UmatOuter22[n-1]*uuj21)/eps[jouter-1];

////        double Factor    = LamPower[n-1]*Plamin0/(router*router*Numer[n-1]*Plamot0);
        double Factor    = (fabs(Plamot0)<1.e-100) ? 0. : LamPower[n-1]*Plamin0/(router*router*Numer[n-1]*Plamot0);

        rn0[n-1]         =         Factor*prin*prot/rdip;
        if(Rdip<Relec)  rn1[n-1] = Factor*pder*prot;
        else            rn1[n-1] = Factor*prin*pder;
    }

/* Substract asymptotic expansion */
    double F0  = 0;
    double F1  = 0;
    double Lam = 1;
    GetRenorPar(Rdip, Relec, &Lam, &F0, &F1);

    double PLam = Lam;
    for(int n=0; n<MAXTERM;n++)
    {
        rn0[n] -= F0      *PLam;
        rn1[n] -= F1*(n+1)*PLam;
        PLam   *=          Lam;
    }

    Nterm = MAXTERM;
    for(int n = MAXTERM-1; n>= MINTERM; n--) if(fabs(rn1[n]/rn1[0])<1.e-8) Nterm = n;
    return U_OK;
}


bool UMultiSphereModel2::InnerPointChanged(double Rdip, double Relec)
{
    int j0 = -1;
    if(Rdip<Relec)  {for(int j=1;j<=Ns; j++) if(Rdip <=rs[j-1]*HeadRadius)  j0 = j;}
    else            {for(int j=1;j<=Ns; j++) if(Relec<=rs[j-1]*HeadRadius)  j0 = j;}

    if(jinner==j0) return false;
    jinner = j0;
    return true;
}
bool UMultiSphereModel2::OuterPointChanged(double Rdip, double Relec)
{
    int je = 1;
    if(Rdip<Relec)  {for(int j=1;j<=Ns;j++) if(Relec<rs[j-1]*HeadRadius) je=j;}
    else            {for(int j=1;j<=Ns;j++) if(Rdip <rs[j-1]*HeadRadius) je=j;}

    if(jouter==je) return false;
    jouter=je;
    return true;
}

ErrorType UMultiSphereModel2::GetRenorPar(double Rdip, double Relec, double* Lam, double* F0, double* F1)
/*
     Compute the renormalization parameters, Lam, F0, F1 for the given
     radial dipole coordinate Rdip and radial electrode coordinates [cm].
 */
{
    if(CondModel != U_CONDMOD_HOMSPHERE   &&
       CondModel != U_CONDMOD_THREESPHERE &&
       CondModel != U_CONDMOD_MULTISPHERE) return U_OK;

    if(Lam==NULL || F0==NULL || F1==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetRenorPar(). Invalid NULL pointer argument(s) .\n");
        return U_ERROR;
    }
    if(Rdip<=0)
    {
        *Lam = 0.;
        *F0  = 0.;
        *F1  = 0.;
        return U_OK;
    }

    InnerPointChanged(Rdip, Relec);
    OuterPointChanged(Rdip, Relec);

    double rinner = Rdip /HeadRadius;
    double router = Relec/HeadRadius;
    if(Rdip>=Relec)
    {
        rinner = Relec/HeadRadius;
        router = Rdip /HeadRadius;
    }

    *Lam      = 1.;
    double  A = 1./PI4;
    for(int j = jouter; j<=jinner; j++)
    {
        double alfa  = sqrt(eht[j-1]/eps[j-1]);
        double alfa2 = .5*(alfa-1.);
        double lam   = 1.;
        if(j==jouter)
        {
            lam   = router/rs[j-1];
            *Lam /= pow(lam,alfa );
            A    /= pow(lam,alfa2);
        }
        if(j==jinner) lam = rinner/rs[j-1];
        else          lam = rs[j] /rs[j-1];
        *Lam *= pow(lam,alfa );
        A    *= pow(lam,alfa2);
    }

    double beta = sqrt(eht[jouter-1]*eps[jouter-1]);
    double F    = 1.;
    for(int j=jouter;j<jinner;j++)
    {
        double beta1 = sqrt(eht[j]*eps[j]);
        F    *= 2*beta1/(beta+beta1);
        beta  = beta1;
    }
    beta = sqrt(eht[jinner-1]*eps[jinner-1]);
    *F0  = A*F/(beta*router*HeadRadius);

    if(router==1) *F0 *= 2;

    if(Rdip>=Relec)
    {
        beta = sqrt(eht[jouter-1]*eps[jouter-1]);
        *F0  =  *F0                / (router*HeadRadius);
////        *F1  =  *F0 * eps[jouter-1]/ beta;
        *F1  =  - *F0 * eps[jouter-1]/ beta;    }
    else
    {
        *F0 =  *F0                / (rinner*HeadRadius);
        *F1 =  *F0 * beta         / eps[jinner-1];
    }
    return U_OK;
}

ErrorType UMultiSphereModel2::GetSums(double cosom, double Rdip, double Relec, double *sum0, double* sum1)
/*
    Compute the sums of Legendre series needed in the computation of the multi-sphere
    potentials, and their derivatives.
    cosom is the cosine of the angle between dipole and electrode.
 */
{
    if(CondModel != U_CONDMOD_HOMSPHERE   &&
       CondModel != U_CONDMOD_THREESPHERE &&
       CondModel != U_CONDMOD_MULTISPHERE) return U_OK;

    if(rn0==NULL ||rn1==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetSums(). Help-arrays not set. \n");
        return U_ERROR;
    }
    if(UpdateUmat(Rdip, Relec)!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetSums(). Updating U-matrices \n");
        return U_ERROR;
    }
    double Pnm00 = cosom;
    double Pnm01 = 1.;
    double Pnm02 = 0.;
    double Pnm10 = 1.;
    double PnmOld;

    *sum0 = *sum1 = 0.;

    for(int n=0; n<Nterm; n++)
    {
        *sum0  +=  rn0[n] * Pnm01;
        *sum1  +=  rn1[n] * Pnm00;

        Pnm01  =  cosom*Pnm01 +(n+2)*Pnm00;
        PnmOld =  Pnm00;
        Pnm00  = ((2*n+3)*cosom*Pnm00 - (n+1)*Pnm10)/(n+2);
        Pnm10  =  PnmOld;
    }

/* Add the asymptotic approximation in closed form*/
    double F0  = 0;
    double F1  = 0;
    double Lam = 1;
    GetRenorPar(Rdip, Relec, &Lam, &F0, &F1);

    double R2 = 1. - 2*cosom*Lam + Lam*Lam;
    double R3 = R2*sqrt(R2);
    *sum0    += F0 * Lam               / R3;
    *sum1    += F1 * Lam * (cosom-Lam) / R3;

    return U_OK;
}

double UMultiSphereModel2::GetPotential(UDipole Dip, UVector3 Xpos)
{
    return Dip.Getd() & GetLeadField(Dip, Xpos);
}

UVector3 UMultiSphereModel2::GetLeadField(UDipole Dip, UVector3 Xpos)
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Object NULL or erroneous. \n");
        return UVector3();
    }
    if(eps  ==NULL || eht==NULL || rs ==NULL)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Object not properly set. \n");
        return UVector3();
    }
    if(CondModel != U_CONDMOD_HOMSPHERE   &&
       CondModel != U_CONDMOD_THREESPHERE &&
       CondModel != U_CONDMOD_MULTISPHERE)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Wrong Model (=%d). \n", CondModel);
        return UVector3();
    }

    UVector3 Xel = Xpos      -SpherePos;
    UVector3 Xdi = Dip.Getx()-SpherePos;
    double   re  = Xel.GetNorm();
    double   rd  = Xdi.GetNorm();
    if(fabs(re-HeadRadius)/HeadRadius < 1.e-6) re = HeadRadius;
    if(re<=0 || re>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Elec radius out of range (re=%f, HeadRadius=%f). \n", re, HeadRadius);
        return UVector3();
    }
    if(rd<=0 || rd>HeadRadius)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Dip radius out of range (re=%f, HeadRadius=%f). \n", rd, HeadRadius);
        return UVector3();
    }


    double cosom = (Xel&Xdi)/(re*rd);
    double sum0  = 0;
    double sum1  = 0;

    if(GetSums(cosom, rd, re, &sum0, &sum1)!=U_OK)
    {
        CI.AddToLog("ERROR: UMultiSphereModel2::GetLeadField(). Getting intermediate results. \n");
        return UVector3();
    }

    double f_xs  =  sum0/re;
    double f_xd  = (sum1-sum0*cosom)/rd;
    return f_xs*Xel + f_xd*Xdi;
}
