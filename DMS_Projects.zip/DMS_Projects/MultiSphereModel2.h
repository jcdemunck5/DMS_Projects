#ifndef _MULTISPHERE2_INCLUDED
#define _MULTISPHERE2_INCLUDED

#include"HeadModel.h"


class UMultiSphereModel2
{
public:
    UMultiSphereModel2();
    UMultiSphereModel2(const UHeadModel* HM);
    UMultiSphereModel2(const UMultiSphereModel2 &MSM);        
    virtual ~UMultiSphereModel2();
    UMultiSphereModel2& operator=(const UMultiSphereModel2 &MSM);

    ErrorType         GetError(void) const     {return error;}
    const UString&    GetProperties(UString Comment) const;
    double            GetPotential(UDipole Dip, UVector3 Xpos);
    UVector3          GetLeadField(UDipole Dip, UVector3 Xpos);
    double            GetEps(int j=0) const;
    ErrorType         SetRelativeElectrodeRadius(double rel);

protected:
    ErrorType         SetSigma(const double* Sigma);
    ErrorType         ProjectElectrode(UVector3* Xelec) const;
    ErrorType         GetSums(double cosom, double Rdip, double Relec, double *sum0, double* sum1);
    ErrorType         UpdateUmat(double Rdip, double Relec);

    void              SetAllMembersDefault(void);
    void              DeleteAllMembers(ErrorType E);

private:
    static const int  MAXTERM;         // The maximum number of terms used in the multi-sphere models
    static const int  MINTERM;         // The minimum number of terms used in the multi-sphere models
    CondModelType     CondModel;       // Exact type of multi-sphere model

    static UString    Properties;      // Array to store the current properties of the object.
    ErrorType         error;           // General error flag
   
    double            rdip;            // Actual dipole radial coordinate, (fraction of HeadRadius)
    double            relc;            // Actual electrode radial coordinate, (fraction of HeadRadius)
    int               jinner;          // Actual shell of dipole (if rdip<relc), or electrode (if rdip>=relc)
    int               jouter;          // Actual shell of dipole (if rdip>relc), or electrode (if rdip<=relc)

    UVector3          SpherePos;       // The position of the best fitting sphere of the head w.r.t.NLR
    double            HeadRadius;      // The radius of the best fitting sphere

    int               Ns;              // number of concentric spheres, compartments, surfaces
    double*           rs;              // relative sphere radii (fractions of HeadRadius)
    double*           eps;             // radial conductivities
    double*           eht;             // tangential conductivities

    int               Nterm;           // The number of terms that are actually used
    double*           Numer;           // Coefficients to compute the potential.
    double*           LamPower;
    double*           UmatInner12;
    double*           UmatInner22;
    double*           UmatOuter21;
    double*           UmatOuter22;
    double*           rn0;             
    double*           rn1;

// Computations and data for the multi-sphere model.
    ErrorType         InitCoefArrays(void);

    bool              InnerPointChanged(double Rdip, double Relec);
    bool              OuterPointChanged(double Rdip, double Relec);
    ErrorType         GetRenorPar(double Rdip, double Relec, double*Lam, double* F1, double* F2);
};

#endif // _MULTISPHERE2_INCLUDED
