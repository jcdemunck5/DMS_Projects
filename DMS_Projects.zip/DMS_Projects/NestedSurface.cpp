/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/*********************************************************************************/
/*                                                                               */
/*                                                                               */
/*     Module for maintaining a 3D surface that can be nested, and can have      */
/*     inner and outer conductivities.                                           */
/*                                                                               */
/*                                                                               */
/*     Jan C. de Munck                                                           */
/*                                                                               */
/*********************************************************************************/
/*
  Update history
  
  Who    When       What
  Jdm    22-04-99   creation, derived from splitting Surface.cpp
  JdM    24-04-99   Added GetProperties()
  JdM    06-06-99   Added new constructor, which reads data from .xdr-file (used with ConQuestViewer)
  JdM    09-11-99   Move InSurface() to base class USurface()
  JdM    17-01-00   Error messages in constructor.
  JdM    27-03-00   operator==() : Test whether this==&s
  JdM    28-06-00   Initialize static const parameters here, i.s.o. GlobalInit.h
  JdM    25-10-00   Added copy constructor 
  JdM    12-04-01   Added new operator=()
  JdM    20-04-01   Bug fix: memory leakage in operator=()
  JdM    27-04-03   Added new constructor
  JdM    01-01-07   Use UString for Properties
  JdM    29-08-08   Added DeleteAllMembers() and SetAllMembersDefault()
  JdM    06-10-11   Added UFileName constructor, which also deals with .stl-files. Removed obsolete const char* constructors
  JdM    25-05-15   Added WriteBinary() and FILE* constructor to USurface
*/

#include <string.h>
#include "NestedSurface.h"

/* Inititalize static const parameters. */
UString      UNestedSurface::Properties  = UString();
const char*  UNestedSurface::HEADERBEGIN = "NestedSurface1.0";
const char*  UNestedSurface::HEADEREND   = "NestedSurfaceEnd";


void UNestedSurface::SetAllMembersDefault(void)
{
    error      =  U_OK;
    OuterCond  =  0;
    InnerCond  =  0;
    parent     = -1;
    nchild     = -1;
    child      =  NULL;
}
void UNestedSurface::DeleteAllMembers(ErrorType E)
{
    delete[] child;
    SetAllMembersDefault();
    error = E;
}

UNestedSurface::UNestedSurface() : USurface()
{
    SetAllMembersDefault();
}

UNestedSurface::UNestedSurface(UVector3* plist, int np, int* tril, int ntr, double cond, const char *gname) :
    USurface(plist, np, tril, ntr, gname)
{
    SetAllMembersDefault();

    if(USurface::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class\n");
        return;
    }
    InnerCond = cond;
    return;    
}

UNestedSurface::UNestedSurface(double mesh_size, double x_par, double y_par, double z_par, ShapeGeomType fig, double cond, const char *gname) :
    USurface(mesh_size, x_par, y_par, z_par, fig, gname) 
{
    SetAllMembersDefault();

    if(USurface::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class\n");
        return;
    }
    InnerCond = cond;
}

UNestedSurface::UNestedSurface(UFileName FileName, double cond, const char* Sname) :
    USurface(FileName, Sname) 
{
    SetAllMembersDefault();

    if(USurface::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class\n");
        return;
    }
    InnerCond = cond;
}

UNestedSurface::UNestedSurface(const UNestedSurface &S) : USurface((USurface) S)
{
    SetAllMembersDefault();

    if(USurface::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class\n");
        return;
    }
    
    if(S.nchild>0 && S.child!=NULL)
    {
        child = new int[S.nchild];
        if(child==NULL)
        {
            DeleteAllMembers(U_ERROR);
            CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). nchild = %d\n",S.nchild);
            return;
        }
        for(int k=0; k<S.nchild; k++) child[k] = S.child[k];
    }

    nchild    = S.nchild;
    parent    = S.parent;
    InnerCond = S.InnerCond;
    OuterCond = S.OuterCond;
}

UNestedSurface::UNestedSurface(const USurface &S, double cond) : USurface(S)
{
    SetAllMembersDefault();

    if(USurface::GetError()!=U_OK) 
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class\n");
        return;
    }
    InnerCond = cond;
}
UNestedSurface::UNestedSurface(FILE* fpIn) : USurface(fpIn)
{
    SetAllMembersDefault();

    if(fpIn==NULL)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Invalid NULL pointer. \n");
        return;
    }
    if(USurface::GetError()!=U_OK)
    {
        DeleteAllMembers(U_ERROR);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Creating base class from fpIn. \n");
        return;
    }

    unsigned int ioff   = ftell(fpIn);
    size_t       NHead  = strlen(HEADERBEGIN);
    char     Buffer[100];
    memset(Buffer, 0, sizeof(Buffer));
    if(fread(Buffer,1,NHead,fpIn)<=0)
    {
        UPointList::DeleteAllMembers(U_ERROR);
        USurface::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Reading first item from file pointer. \n");
        return;
    }
    if(strncmp(HEADERBEGIN, Buffer, NHead))
    {
        UPointList::DeleteAllMembers(U_ERROR);
        USurface::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Wrong header (%s). \n", Buffer);
        return;
    }
    InnerCond = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    OuterCond = ::ReadBinaryDouble(DefaultIntelData, fpIn);
    parent    = ::ReadBinaryInt   (DefaultIntelData, fpIn);
    nchild    = ::ReadBinaryInt   (DefaultIntelData, fpIn);
    if(nchild>0)
    {
        child = new int[nchild];
        if(child==NULL)
        {
            UPointList::DeleteAllMembers(U_ERROR);
            USurface::DeleteAllMembers(U_ERROR);
            DeleteAllMembers(U_ERROR);
            fseek(fpIn, ioff, SEEK_SET);
            CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Memory allocation, nchild = %d . \n", nchild);
            return;
        }
        for(int ic=0; ic<nchild; ic++) child[ic] = ::ReadBinaryInt(DefaultIntelData, fpIn);
    }
    memset(Buffer, 0, sizeof(Buffer));
    fread(Buffer,1,strlen(HEADEREND),fpIn);
    NHead  = strlen(HEADEREND);
    if(strncmp(HEADEREND, Buffer, NHead))
    {
        UPointList::DeleteAllMembers(U_ERROR);
        USurface::DeleteAllMembers(U_ERROR);
        DeleteAllMembers(U_ERROR);
        fseek(fpIn, ioff, SEEK_SET);
        CI.AddToLog("ERROR: UNestedSurface::UNestedSurface(). Wrong END header (%s). \n", Buffer);
        return;
    }
}
ErrorType UNestedSurface::WriteBinary(FILE* fpOut) const
{
    if(this==NULL || error!=U_OK)
    {
        CI.AddToLog("ERROR: UNestedSurface::WriteBinary(). Object NULL or erroneous. \n");
        return U_ERROR;
    }
    if(fpOut==NULL)
    {
        CI.AddToLog("ERROR: UNestedSurface::WriteBinary(). NULL argument. \n");
        return U_ERROR;
    }
    if(USurface::WriteBinary(fpOut)!=U_OK)
    {
        CI.AddToLog("ERROR: UNestedSurface::WriteBinary(). Writing base class. \n");
        return U_ERROR;
    }

    size_t NHead     = strlen(HEADERBEGIN);
    if(fwrite(HEADERBEGIN,1,NHead,fpOut)<=0)   return U_ERROR;

    ::WriteBinary(InnerCond, DefaultIntelData, fpOut);
    ::WriteBinary(OuterCond, DefaultIntelData, fpOut);
    ::WriteBinary(parent   , DefaultIntelData, fpOut);
    ::WriteBinary(nchild   , DefaultIntelData, fpOut);
    if(nchild>0)
        for(int ic=0; ic<nchild; ic++) ::WriteBinary(child[ic]   , DefaultIntelData, fpOut);
    fwrite(HEADEREND,1,strlen(HEADEREND),fpOut);

    return U_OK;
}

UNestedSurface::~UNestedSurface()
{    
    DeleteAllMembers(U_OK);
}

UNestedSurface& UNestedSurface::operator=(const UNestedSurface &g)
{
    if(this==&g) return *this;

    USurface::operator=(g);
    if(USurface::GetError() != U_OK) goto error;
    OuterCond = g.OuterCond;
    InnerCond = g.InnerCond;
    parent    = g.parent;
    nchild    = g.nchild;

    delete[] child;
    if(g.child)
    {
        if((child = new int[nchild])==NULL) goto error;
        for(int i=0; i<nchild; i++) child[i] = g.child[i];
    }
    else
        child = NULL;

    error = U_OK;
    return *this;

error:
    delete[] child;         child      = NULL;
    OuterCond = InnerCond =  0;
    parent    = nchild    = -1;
    error     = U_ERROR;
    return *this;
}

UNestedSurface& UNestedSurface::operator=(const USurface &g)
{
    if(this==&g) return *this;

    OuterCond  =  0;  // Inner conductivity stays unchanged, reset relation to other surfaces
    parent     = -1;
    nchild     = -1;
    delete[] child;
    child      =  NULL;

    USurface::operator=(g);
    if(USurface::GetError() != U_OK) 
    {
        CI.AddToLog("ERROR: operator=(). Setting USurface()-base class.\n");
        InnerCond =  0;
        error     = U_ERROR;
        return *this;
    }

    error = U_OK;
    return *this;
}

bool UNestedSurface::operator==(const UNestedSurface &g) 
/*
    Return true iff both surfaces are "equal", i.e. iff
        they do no have children, 
    and they have the same parent,
    and they have they same number of points,
    and they have they same number of triangles,

    Note: Prior to calling this operator, the topology of the Conductor containing
          these surfaces should be set, using ChequeConductor().
 */
{
    if(nchild || g.nchild)  return false;
    if(parent != g.parent)  return false;
    if(Npoints!= g.Npoints) return false;
    if(Ntri   != g.Ntri)    return false;
    
    return true;       
}

ErrorType UNestedSurface::SetNchild(int nc, int *children)
{
    if(nc<0) return U_ERROR;
    delete child;
    child = NULL;

    if(nc==0) 
    {
        nchild = 0;
        child  = NULL;
        return U_OK;
    }
    if( (child=new int[nc])==NULL ) return U_ERROR;

    nchild = nc;
    if(children) for(int i=0;i<nchild;i++) child[i] = children[i];

    return U_OK;
}

int UNestedSurface::GetNextChild(int ichild) const
{
    if(nchild==0) return -1;

    if(ichild<0||ichild>=nchild-1) return child[0];
    else                           return child[ichild+1];
}

const UString&  UNestedSurface::GetProperties(UString Comment) const
{
    if(this==NULL || error!=U_OK)
    {
        Properties = UString(" ERROR in UNestedSurface-object");
        return Properties;
    }
    Properties  = UString();
    Properties += UString(InnerCond , " InnerCond     = %f     \n") 
                + UString(OuterCond , " OuterCond     = %f     \n");
    
    if(Comment.IsNULL() || Comment.IsEmpty())     Properties += USurface::GetProperties(Comment);
    else                                          Properties += USurface::GetProperties(Comment + "   ");

    if(Comment.IsNULL() || Comment.IsEmpty())     Properties.ReplaceAll('\n', ';');  
    else                                          Properties.InsertAtEachLine(Comment);

    return Properties;
}
