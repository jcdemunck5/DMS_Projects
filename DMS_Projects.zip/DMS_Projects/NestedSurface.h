#ifndef _NESTEDSURFACE_INCLUDED
#define _NESTEDSURFACE_INCLUDED

#include "Surface.h"

class DLL_IO UNestedSurface : public USurface
{
public:
    UNestedSurface();
    UNestedSurface(FILE* fpIn);
    UNestedSurface(UVector3* plist, int np, int* tril, int ntr, double cond, const char *gname);
    UNestedSurface(double mesh_size, double x_par, double y_par, double z_par, ShapeGeomType fig, double cond, const char *gname=NULL);
    UNestedSurface(UFileName TriFileName, double cond, const char* Sname=NULL);
    UNestedSurface(const UNestedSurface &S);
    UNestedSurface(const USurface &S, double cond=1.);
    
    virtual ~UNestedSurface();

    UNestedSurface& operator=(const UNestedSurface &g);
    UNestedSurface& operator=(const USurface &g);
    bool operator==(const UNestedSurface &g);
    bool operator!=(const UNestedSurface &g) {if(operator==(g))return false; else return true;}    

    double              GetOuterCond() const            {return OuterCond;}
    double              GetInnerCond() const            {return InnerCond;}
    void                SetOuterCond(double cond)       {OuterCond=cond;}
    void                SetInnerCond(double cond)       {InnerCond=cond;}
    int                 GetParent() const               {return parent;}
    void                SetParent(int par)              {parent = par;}
    ErrorType           SetNchild(int nc, int *children=NULL);          
    int                 GetNchild(void) const           {return nchild;}         
    int                 GetNextChild(int ichild) const;
    ErrorType           GetError() const                {return error;}
    const UString&      GetProperties(UString Comment) const;

    ErrorType           WriteBinary(FILE* fpOut) const;
protected:
    void                SetAllMembersDefault(void);
    void                DeleteAllMembers(ErrorType E);

private:    
    static const char*  HEADERBEGIN;
    static const char*  HEADEREND;
    ErrorType           error;      // General error flag
    static UString      Properties;
    double              InnerCond;  // Inner conductivity of the surface
    double              OuterCond;  // Outer conductivity of the surface (to be computed when all Surfaces are known)
    int                 parent;     // The next surface that encloses this Surface    
    int                 nchild;     // Number of Surfaces directly enclosed by this surface (excluding grand-children)
    int                 *child;     // List of surfaces directly enclosed by this surface           
};

#endif// _NESTEDSURFACE_INCLUDED
