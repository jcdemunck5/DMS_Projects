#ifndef _NEUROSCANH_INCLUDED
#define _NEUROSCANH_INCLUDED

typedef struct
{
    char           rev[20];
    char           type;           //1 (AVG), 0 (EEG)
    char           PatID[20];
    char           Operator[20];
    char           Docter[20];
    char           Referral[20];
    char           Hospital[20];
    char           PatName[20];
    short          Age;
    char           Sex;            //M,F
    char           Hand;           //M,R,L
    char           Medication[20];
    char           Catagory[20];
    char           SubjectState[20];
    char           SessionLabel[20];
    char           Date[10];
    char           Time[12];
    char           Reserved4[115];
    short          CompSweeps;
    short          AcceptedSweeps;
    short          RejectedSweeps;
    short          PointsPerWaveform;
    short          NChan;
    char           Reserved5[3];
    char           VarianceIncluded;
    unsigned short SampleRate;
    double         CalScale;
    char           Reserved6[111];
    float          DisplayMin;
    float          DisplayMax;
    float          EpochStart;      // s
    float          EpochEnd;
    char           Reserved7[351];
    long int       NumSamples;
    char           Reserved8[18];
    long int       EventTableOffseset;
    float          NsecondsPerPage;
    long int       ChannelOffset;
    char           AutoCorrectDCflag;
    char           DCthreshold;
} NeuroScanSetUp;

typedef struct
{
    char           Label[10];
    char           Reserved1[5];
    short          Nobservations;
    char           Reserved2[30];
    short          BaseLineOffset; // Offset in AD units
    char           Reserved3[10];
    float          Sensitivity;
    char           Reserved4[8];
    float          CalibCoef;
} NeuroScanElect;

typedef struct
{
    char      TagType;
    long int  Size;
    long int  Offset;
}
NeuroScanTag;

#define EVENTSIZE1 8
#define EVENTSIZE2 19
#define ELECTRSIZE 75

typedef struct
{
    unsigned short StimType;        /* range 0-65535                           */
    unsigned char  KeyBoard;        /* range 0-11 corresponding to fcn keys +1 */
    char           KeyPad_Accept;   /* 0->3 range 0-15 bit coded response pad  */
    long int       Offset;          /* 4->7 values 0xd=Accept 0xc=Reject       */
} NeuroScanEvent1;                  /* file offset of event                    */

typedef struct
{
    unsigned short StimType;        /* range 0-65535                           */
    unsigned char  KeyBoard;        /* range 0-11 corresponding to fcn keys +1 */
    char           KeyPad_Accept;   /* 0->3 range 0-15 bit coded response pad  */
    long int       Offset;          /* 4->7 values 0xd=Accept 0xc=Reject       */
    short          Type;
    short          Code;
    float          Latency;
    char           EpochEvent;
    char           Accept;
    char           Accuracy;
} NeuroScanEvent2;

#endif// _NEUROSCANH_INCLUDED
