/*********************************************************************************/
/*                                                                               */
/*    BIAP (Brain Image Analysis Programme), a general set of C/C++ software     */
/*	  tools to read, analyse and visualyse brain imaging modalities: EEG, MEG,   */
/*    fMRI, MRI, PET EEG/fMRI                                                    */
/*    Copyright (C) 2018  Dr Jan C de Munck (V-th)                               */
/*                                                                               */
/*    This program is free software: you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by       */
/*    the Free Software Foundation, either version 3 of the License, or          */
/*    (at your option) any later version.                                        */
/*                                                                               */
/*    This program is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/*    GNU General Public License for more details.                               */
/*                                                                               */
/*    You should have received a copy of the GNU General Public License          */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.     */
/*                                                                               */
/*	            Dr Jan C de Munck (V-th), jancdemunck@gmail.com                  */
/*                                                                               */
/*                                                                               */
/*********************************************************************************/
/************************************************************************/
/*                                                                      */
/*      file       : AVSCOOR.C (was: AVS_COOR.C(PP) )                   */
/*                                                                      */
/*      purpose    : AVS rectilinear/uniform coordinates to             */
/*                   index/fraction and vice versa. C code for          */
/*                   init/deinit subroutines.                           */
/*                                                                      */
/*      author     : Marcel van Herk (JCRT / NKI / AVL)                 */
/*                                                                      */
/*      date       : 27 - 04 - 92                                       */
/*                                                                      */
/*      portability: AVS requires sizeof(void *)==sizeof(int)           */
/*                   This module assumes sizeof(int)>=4                 */
/*                                                                      */
/*      notes      : This module has been integrated in QUIRT           */
/*                   Define QUIRT selects other set of include files    */
/*                                                                      */
/************************************************************************/
/* Updates:
    Who  When       What
  mvh    27-04-92   Creation (and several days before as well)
  mvh    28-04-92   Added support for integer based coordinates
  mvh    29-04-92   Fixed it and some rectilinear flaws
  mvh    02-05-92   Made half pixel shift switchable
  mvh    05-05-92   halfpixel=0 and non-interpolated -> half pixel left
  mvh    17-05-92   Changed include name
  mvh    13-07-92   Made minumum and maximum for integer tables one narrower
                    Removed HALFPIXEL junk (should fix inter to TRUE)
  mvh    08-08-92   Adapted for QUIRT system
  mvh    04-11-92   Allow 2-dimensional input fields as well
  mvh    05-11-92   Removed non-interpolated code for clarity
                    Added 'rounding' of maximum when intflag is set
  mvh    02-03-93   Fixed to run on HP
  mvh    16-05-93   Made uniform code more equal to rectilinear code
                    so that it is more accurate when using integers.
  mvh    08-01-94   Standard header, portability notes
  mvh    08-01-94   Stripped some blocked-out code, added uniform flags
  mvh    09-01-94   Added typecasts to avoid compiler warnings
  mvh    10-01-94   Copy uniform flags to IRTABLE
  fcv    29-08-95   Added check on dimensions and coordinates for UNIFORM
  mvh    12-01-96   previous check crashed sometimes, z floats were accessed if !dim3
 nl+mvh  08-03-96   Added test for rectilinear lut generation coords range, added string.h
  mvh    25-09-96   Check that coordinates are monotone
  mvh    28-10-96   If interpolate bit 2 is set, suppress error messages (for use by avs_edis)
  mvh    17-04-97   Some fixes for 2D rectilinear fields (access to non-init floats)
  lsp    27-06-97   Applied casts to satisfy MSVC
  tp     30-06-97   Added Portability key; lf->cr,lf;
 mg/tp   16-10-97   Moved to Common and re-renamed to avscoor.c
  JdM    30-08-02   Remove conditional includes, to allow makefile generation with tmake (Qt)
  JdM    30-12-06   Adapted include file to new directory structure
  JdM    29-01-14   Modified updates lay out to be automatically analyzed
*/

/************************************************************************/
/*                         MODULE DOCUMENTATION                         */
/************************************************************************/
/*
AVS Modules Marcel van Herk                                 AVS_COOR.C
21-09-93

NAME
     AVSCOOR.C - internal routines for managing coordinates of uniform and
     rectilinear fields.

SUMMARY
     Name          none

     Source        AVSCOOR.C

     Type          This file is included or linked with AVS modules

DESCRIPTION
     This module performs conversion between AVS rectilinear/uniform
     coordinates and index/fraction and the other way around.

     The following macro's are supplied:

     coord_to_index_x
     coord_to_index_y
     coord_to_index_z
       Convert coordinate (e.g., in cm) to an index in a uniform or
       rectlinear field. The macros expect the coordinate and a RTABLES
       structure as input. When the coordinate is outside the volume, the
       index returns -1. The last pixel is counted outside the volume,
       because no interpolation is possible for that pixel.

    frac_x
    frac_y
    frac_z
       Give fractional coordinate for last coord_to_index.
       These macros expect the RTABLES structure as input.

    ifrac_x
    ifrac_y
    ifrac_z
       Give integer fractional coordinate.

   index_to_coord_x
   index_to_coord_y
   index_to_coord_z
       Use the tables in the RTABLES structure to translate a pixel index
       into a coordinate.


   make_rtables(field, t, inter)
      construct lookup tables for the field into struct RTABLES* t.
      arguments: field = 3D field (UNIFORM or RECTILINEAR).
		 t     = pointer to table structure.
		 inter = flag, use 1 (bit 2 suppresses error messages)
      returns: 0 for failure (out of memory or other), 1 for success

   make_irtables(field, t, inter, scale)
      construct integer coordinate based lookup tables for the field into t.
      arguments: field = 3D field  (UNIFORM or RECTILINEAR).
		 t     = pointer to IRTABLES structure.
		 inter = flag, use 1 (bit 2 suppresses error messages)
		 scale = scale factor, all input coordinates must be scaled by
			 this factor, and all output fractions and coordinates
			 are scaled by this factor.

   free_rtables(t)
      free the mess we've made
      argument: t = pointer to previously filled lookup table structure.

LIMITATIONS
      For finding the nearest pixel, the index must be incremented when the
      fraction is larger than 0.5. The last pixel cannot be used because it
      is not possible to access the next pixel for interpolation.

PORTABILITY
	AVS, C
	QUIRT, C

Release 1.0                   Marcel van Herk                  AVS_COOR.C
*/

/************************************************************************/
/*                             INCLUDE FILES                            */
/************************************************************************/

////#ifndef QUIRT
////#include <avs/field.h>
////#include <avs/avs.h>
////#include <memory.h>
////#else
////#include <malloc.h>
////#include "mbfield.h"
////#endif

////#include <string.h>
////#include <math.h>
////#include <stdio.h>
////#include "avscoor.h"


#include <string.h>
#include <stdlib.h>
#include "Field.h"
#include "avscoor_AVL.h"


/************************************************************************/
/*                    DEFINES, ENUMERATED TYPES AND CONSTANTS           */
/************************************************************************/

#define INTFLAG 32                           /* if set, use integers    */
#define INF 1e10                             /* 'infinite' coordinate   */
#define rfabs(x) ((x)<0 ? -(x) : (x))        /* floating absolute value */
#define nint(x)  ((x)<0 ? (int)((x)-0.5) : (int)((x)+0.5))

/************************************************************************/
/*                           GLOBAL VARIABLES                           */
/************************************************************************/

/************************************************************************/
/*                              PROTOTYPES                              */
/************************************************************************/
/* no compute function here */

/************************************************************************/
/*                             AVS INTERFACE                            */
/************************************************************************/
/* This module is included into or linked with other AVS modules */

/************************************************************************/
/*                           MODULE FUNCTIONS                           */
/************************************************************************/

/* construct lookup tables for the field into t.
   arguments: field = 3D field for relevant operation (UNIFORM or RECTILINEAR).
	      t     = pointer to table structure.
	      inter = flag, use 1 (bit 2 suppresses error messages)
		      (high bits used internally for integer table generation)

   returns: 0 for failure (out of memory or other), 1 for success

   The interpolation tables are valid from the left of the first pixel to right
   of the one-before-last pixel.

   note : use free_rtables to free the tables when done. The tables can take
   up a significant amount of space (more than 30 kbyte) depending on the
   presence of some pixel cells which are much smaller than the others.
*/

int make_rtables(AVSfield *field, struct RTABLES *t, int inter)
		                             /* inter is NOT used anymore */
{ int   i, j, ic, dim3, errorcode;
  float low, high, c, *coords;
  int intflag;
  float omsx, omsy, omsz; /* original step before rounding for integer */

  dim3 = (field->ndim == 3);

  intflag = inter / INTFLAG;                 /* get integer step flag */
  inter   = inter & (INTFLAG - 1);           /* restore interpolate flag */

  coords  = field->points;                   /* coordinate array */
  t->dimx = field->dimensions[0];            /* pixel counts in x, y, z */
  t->dimy = field->dimensions[1];
  if (dim3) t->dimz = field->dimensions[2];

  t->xl = t->yl = t->zl = NULL;              /* for easy error handling */
  t->xs = t->ys = t->zs = NULL;
  t->xi = t->yi = t->zi = NULL;
  t->xt = t->yt = t->zt = NULL;
  t->xc = t->yc = t->zc = NULL;

					     /* low coordinates */
  t->xl = (float *)malloc(t->dimx * sizeof(float));
  t->yl = (float *)malloc(t->dimy * sizeof(float));
  if (dim3) t->zl = (float *)malloc(t->dimz * sizeof(float));

					     /* coordinate steps */
  t->xs = (float *)malloc(t->dimx * sizeof(float));
  t->ys = (float *)malloc(t->dimy * sizeof(float));
  if (dim3) t->zs = (float *)malloc(t->dimz * sizeof(float));


  if (!t->xl || !t->yl || (!t->zl && dim3))  { free_rtables(t); return 0; }
  if (!t->xs || !t->ys || (!t->zs && dim3))  { free_rtables(t); return 0; }

  if (field->uniform == UNIFORM)             /* handle UNIFORM fields */
  { t->minx = *coords++;                     /* get extents of coordinates */
    t->maxx = *coords++;
    t->miny = *coords++;
    t->maxy = *coords++;
    if (dim3)
    { t->minz = *coords++;
      t->maxz = *coords;
    }

    if (t->dimx<=1 || t->dimy<=1 || t->maxx==t->minx || t->maxy==t->miny)
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). some uniform coordinates identical, cannot make tables. \n");
      free_rtables(t);
      return 0;
    }

    if (dim3)
    { if(t->maxz==t->minz && t->dimz<=1)
      { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). some uniform coordinates identical, cannot make tables. \n");
	free_rtables(t);
	return 0;
      }
    }
					   /* number steps in index arrays */

					    /* get pixel size */
    t->msx  = omsx = (t->maxx - t->minx) / (t->dimx-1);
    t->msy  = omsy = (t->maxy - t->miny) / (t->dimy-1);
    if (dim3) t->msz = omsz = (t->maxz - t->minz) / (t->dimz-1);

    if (intflag)                             /* 'round' step for integer */
    { t->msx = (int)(t->msx * intflag) / (float)intflag;
      t->msy = (int)(t->msy * intflag) / (float)intflag;
      if (dim3) t->msz = (int)(t->msz * intflag) / (float)intflag;
    }

    if (t->minx > t->maxx)                   /* get ascending flags     */
      t->ax  = -1;                           /* .. descending x         */
    else
      t->ax  = 1;                            /* ascending */

    if (t->miny > t->maxy)                   /* idem for y */
      t->ay  = -1;
    else
      t->ay  = 1;

    if (dim3)
    { if (t->minz > t->maxz)                 /* idem for z */
	t->az  = -1;
      else
	t->az  = 1;
    }

    t->nsx = (int)((t->maxx - t->minx + 1.5 * t->msx) / t->msx);
    t->nsy = (int)((t->maxy - t->miny + 1.5 * t->msy) / t->msy);
    if(dim3) t->nsz = (int)((t->maxz - t->minz + 1.5 * t->msz) / t->msz);

					     /* allocate index arrays */
    t->xi = (int *)malloc(t->nsx * sizeof(int));
    t->yi = (int *)malloc(t->nsy * sizeof(int));
    if (dim3) t->zi = (int *)malloc(t->nsz * sizeof(int));

    t->xt = (float *)malloc(t->nsx * sizeof(float));
    t->yt = (float *)malloc(t->nsy * sizeof(float));
    if (dim3) t->zt = (float *)malloc(t->nsz * sizeof(float));

    if (!t->xi || !t->yi || (!t->zi && dim3)) { free_rtables(t); return 0; }
    if (!t->xt || !t->yt || (!t->zt && dim3)) { free_rtables(t); return 0; }

    ic = 1;                                  /* fill the index arrays for x */
    for (i=0; i<t->nsx; i++)
    { high = (i+1) * t->msx;                 /* right coordinate for index */
      c = ic * omsx;                         /* current pixel coordinate */

      if (rfabs(c) >= rfabs(high))           /* still in current pixel */
      { t->xt[i] = (float)-INF;              /* no threshold needed */
	t->xi[i] = ic-1;                     /* copy pixel index */
      }
      else
      { t->xt[i] = c;                        /* pixelthreshold in this index */
	t->xi[i] = ic++;                     /* pixel number if > threshold  */
	if (t->ax < 0) t->xi[i]--;           /* reverse logic for descending */
      }
    }

    ic = 1;                                  /* same procedure for y */
    for (i=0; i<t->nsy; i++)
    { high = (i+1) * t->msy;
      c = ic * omsy;                         /* current pixel coordinate */

      if (rfabs(c) >= rfabs(high))
      { t->yt[i] = (float)-INF;
	t->yi[i] = ic-1;
      }
      else
      { t->yt[i] = c;
	t->yi[i] = ic++;
	if (t->ay < 0) t->yi[i]--;           /* reverse logic for descending */
      }
    }

    if (dim3)
    { ic = 1;                                /* and for z */
      for (i=0; i<t->nsz; i++)
      { high = (i+1) * t->msz;
	c = ic * omsz;                       /* current pixel coordinate */

	if (rfabs(c) >= rfabs(high))
	{ t->zt[i] = (float)-INF;
	  t->zi[i] = ic-1;
	}
	else
	{ t->zt[i] = c;
	  t->zi[i] = ic++;
	  if (t->az < 0) t->zi[i]--;         /* reverse logic for descending */
	}
      }
    }

    for (i=0; i<t->dimx; i++)                /* fill low and step arrays */
    { t->xl[i] = i * omsx;
      t->xs[i] = omsx;
    }

    for (i=0; i<t->dimy; i++)
    { t->yl[i] = i * omsy;
      t->ys[i] = omsy;
    }

    if (dim3)
    { for (i=0; i<t->dimz; i++)
      { t->zl[i] = i * omsz;
	t->zs[i] = omsz;
      }
    }

    t->ux = t->uy = t->uz = 1;               /* set uniform flags */
  }

  else if (field->uniform == RECTILINEAR)    /* rectilinear data */
  { t->minx = coords[0];                     /* coordinate extents */
    t->maxx = coords[t->dimx-1];
    t->miny = coords[t->dimx];
    t->maxy = coords[t->dimx + t->dimy - 1];
    if (dim3)
    { t->minz = coords[t->dimx + t->dimy];
      t->maxz = coords[t->dimx + t->dimy + t->dimz - 1];
    }

    if (t->dimx<2 || t->dimy<2 || (t->dimz<2 && dim3))
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels().  X, Y or Z dimension too small (<2), cannot make rtables. \n");
      free_rtables(t);
      return 0;
    }

    errorcode = 0;

    low = (float)INF; high = -low;                  /* find minimal step size for x */

    for (i = 1; i<t->dimx; i++)
    { c = coords[i]-coords[i-1];
      if (c <  low) low  = c;
      if (c > high) high = c;
    }

    if (low * high < 0) errorcode = 1;
    t->msx = rfabs(low);
    if (rfabs(high) < t->msx) t->msx = rfabs(high);


    low = (float)INF; high = -low;                  /* idem for y */

    for (i = t->dimx + 1; i<t->dimy + t->dimx; i++)
    { c = coords[i]-coords[i-1];
      if (c <  low) low  = c;
      if (c > high) high = c;
    }

    if (low * high < 0) errorcode = 2;
    t->msy = rfabs(low);
    if (rfabs(high) < t->msy) t->msy = rfabs(high);


    if (dim3)
    { low = (float)INF; high = -low;                  /* idem for z */

      for (i = t->dimx + t->dimy + 1; i<t->dimz + t->dimy + t->dimx; i++)
      { c = coords[i]-coords[i-1];
        if (c <  low) low  = c;
        if (c > high) high = c;
      }

      if (low * high < 0) errorcode = 3;
      t->msz = rfabs(low);
      if (rfabs(high) < t->msz) t->msz = rfabs(high);
    }

    if (errorcode)
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). X, Y or Z coordinates not monotone, cannot make rtables. \n");
      free_rtables(t);
      return 0;
    }

    if (intflag)                             /* 'round' step for integer */
    { t->msx = (int)(t->msx * intflag) / (float)intflag;
      t->msy = (int)(t->msy * intflag) / (float)intflag;
      if (dim3) t->msz = (int)(t->msz * intflag) / (float)intflag;
    }

    if (t->minx > t->maxx)
    { t->msx = - t->msx;                     /* step is negative for .. */
      t->ax  = -1;                           /* .. descending x         */
    }
    else
      t->ax  = 1;                            /* ascending */

    if (t->miny > t->maxy)                   /* idem for y */
    { t->msy = - t->msy;
      t->ay  = -1;
    }
    else
      t->ay  = 1;

    if (dim3)
    { if (t->minz > t->maxz)                   /* idem for z */
      { t->msz = - t->msz;
	t->az  = -1;
      }
      else
	t->az  = 1;
    }

    if (t->msx==0 || t->msy==0)
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). some rectilinear coordinates identical, cannot make tables. \n");
      free_rtables(t);
      return 0;
    }

    if (dim3)
      if (t->msz==0)
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). some rectilinear coordinates identical, cannot make tables. \n");
      free_rtables(t);
      return 0;
    }

    if (errorcode)
    { free_rtables(t);
      return 0;
    }
					   /* number steps in index arrays */
    t->nsx = (int)((t->maxx - t->minx + 1.5 * t->msx) / t->msx);
    t->nsy = (int)((t->maxy - t->miny + 1.5 * t->msy) / t->msy);
    if(dim3) t->nsz = (int)((t->maxz - t->minz + 1.5 * t->msz) / t->msz);

    if (t->nsx>2000 || t->nsy>2000 || (t->nsz>2000 && dim3))
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). rectilinear lookup tables too large (more than 2000 elements). \n");
      free_rtables(t);
      return 0;
    }

    if (t->nsx <= 0 || t->nsy <= 0 || (t->nsz <= 0 && dim3))
    { if (!(inter&2)) AVSerror("ERROR: make_rtabels(). rectilinear lookup tables too small. \n");
      free_rtables(t);
      return 0;
    }

					     /* index arrays */
    t->xi = (int *)malloc(t->nsx * sizeof(int));
    t->yi = (int *)malloc(t->nsy * sizeof(int));
    if (dim3) t->zi = (int *)malloc(t->nsz * sizeof(int));

					     /* threshold arrays */
    t->xt = (float *)malloc(t->nsx * sizeof(float));
    t->yt = (float *)malloc(t->nsy * sizeof(float));
    if (dim3) t->zt = (float *)malloc(t->nsz * sizeof(float));

    if (!t->xi || !t->yi || (!t->zi && dim3)) { free_rtables(t); return 0; }
    if (!t->xt || !t->yt || (!t->zt && dim3)) { free_rtables(t); return 0; }

    ic = 1;                                  /* fill the index arrays for x */
    for (i=0; i<t->nsx; i++)
    { high = (i+1) * t->msx;                 /* right coordinate for index */
      j    = ic;

      if (j < t->dimx)
        c = coords[j] - t->minx;             /* current pixel coordinate */

      if (rfabs(c) >= rfabs(high))           /* still in current pixel */
      { t->xt[i] = (float)-INF;                     /* no threshold needed */
	t->xi[i] = ic-1;                     /* copy pixel index */
      }
      else
      { t->xt[i] = c;                        /* pixelthreshold in this index */
	t->xi[i] = ic++;                     /* pixel number if > threshold  */
	if (t->ax < 0) t->xi[i]--;           /* reverse logic for descending */
      }
    }

    ic = 1;                                  /* same procedure for y */
    for (i=0; i<t->nsy; i++)
    { high = (i+1) * t->msy;
      j    = ic + t->dimx;

      if (j < t->dimy + t->dimx)
        c = coords[j] - t->miny;             /* current pixel coordinate */

      if (rfabs(c) >= rfabs(high))
      { t->yt[i] = (float)-INF;
	t->yi[i] = ic-1;
      }
      else
      { t->yt[i] = c;
	t->yi[i] = ic++;
	if (t->ay < 0) t->yi[i]--;           /* reverse logic for descending */
      }
    }

    if (dim3)
    { ic = 1;                                /* and for z */
      for (i=0; i<t->nsz; i++)
      { high = (i+1) * t->msz;
	j    = ic + t->dimx + t->dimy;

        if (j < t->dimz + t->dimy + t->dimx)
	  c = coords[j] - t->minz;           /* current pixel coordinate */

	if (rfabs(c) >= rfabs(high))
	{ t->zt[i] = (float)-INF;
	  t->zi[i] = ic-1;
	}
	else
	{ t->zt[i] = c;
	  t->zi[i] = ic++;
	  if (t->az < 0) t->zi[i]--;         /* reverse logic for descending */
	}
      }
    }

    for (i=0; i<t->dimx; i++)                /* fill x low and step arrays */
    { t->xl[i] = coords[i] - t->minx;
      if (i==t->dimx-1)
	t->xs[i] = t->msx;
      else
	t->xs[i] = coords[i+1] - coords[i];
    }

    ic = t->dimx;                            /* fill y low and step arrays */
    for (i=0; i<t->dimy; i++)
    { t->yl[i] = coords[i + ic] - t->miny;
      if (i==t->dimy-1)
	t->ys[i] = t->msy;
      else
	t->ys[i] = coords[i + 1 + ic] - coords[i + ic];
    }

    if (dim3)
    { ic = t->dimx + t->dimy;                /* fill z low and step arrays */
      for (i=0; i<t->dimz; i++)
      { t->zl[i] = coords[i + ic] - t-> minz;
	if (i==t->dimz-1)
	  t->zs[i] = t->msz;
	else
	  t->zs[i] = coords[i + 1 + ic] - coords[i + ic];
      }
    }

    /* determine whether each axis is uniform (within 0.01 pixel) or not */

    t->ux = t->uy = t->uz = 1;

    if ( fabs( (t->maxx - t->minx)/t->msx - (t->dimx-1) ) > 0.01) t->ux = 0;
    if ( fabs( (t->maxy - t->miny)/t->msy - (t->dimy-1) ) > 0.01) t->uy = 0;
    if (dim3)
      if ( fabs( (t->maxz - t->minz)/t->msz - (t->dimz-1) ) > 0.01) t->uz = 0;
  }

  else
  { if (!(inter&2)) AVSerror("ERROR: make_rtabels().  non-supported data type. \n");
    free_rtables(t);
    return 0;
  }

  t->mx = t->maxx;
  t->my = t->maxy;
  if (dim3) t->mz = t->maxz;

					     /* make center of pixel arrays */
  t->xc = (float *) malloc(t->dimx * sizeof(float));
  t->yc = (float *) malloc(t->dimy * sizeof(float));
  if (dim3) t->zc = (float *) malloc(t->dimz * sizeof(float));
  if (!t->xc || !t->yc || (!t->zc && dim3)) { free_rtables(t); return 0; }

					     /* copy from left */
  memcpy(t->xc, t->xl, t->dimx * sizeof(float));
  memcpy(t->yc, t->yl, t->dimy * sizeof(float));
  if (dim3) memcpy(t->zc, t->zl, t->dimz * sizeof(float));

  for (i=0; i<t->dimx; i++) t->xc[i] += t->minx;
  for (i=0; i<t->dimy; i++) t->yc[i] += t->miny;
  if (dim3) for (i=0; i<t->dimz; i++) t->zc[i] += t->minz;

					     /* invert for fast computation */
  for (i=0; i<t->dimx; i++) t->xs[i] = 1 / t->xs[i];
  for (i=0; i<t->dimy; i++) t->ys[i] = 1 / t->ys[i];
  if (dim3) for (i=0; i<t->dimz; i++) t->zs[i] = 1 / t->zs[i];

  if (t->minx < t->maxx)  t->mix = t->minx;  /* reverse range for ascending */
  else { t->mix = t->mx; t->mx = t->minx; }

  if (t->miny < t->maxy)  t->miy = t->miny;  /* reverse range for ascending */
  else { t->miy = t->my; t->my = t->miny; }

  if (dim3)
  { if (t->minz < t->maxz)  t->miz = t->minz;/* reverse range for ascending */
    else { t->miz = t->mz; t->mz = t->minz; }
  }

  return 1;                                  /* ok */
}

/* make_irtables(field, irt, interpolate, scale) create tables for integer
						 based coordinate systems.
   arguments: AVSfield *field      = field to work on.
	      struct IRTABLES *irt = table structure (from avs_coords.h)
	      inter                = flag, see make_rtables
	      scale                = works with coordinate * scale
   returns:   0 = failure, 1 = success

   Note: with the integer version, ifrac_x etc. must be used instead of
   frac_x. For the rest, all the same macros can be used. Also free_rtables
   must be used to free the integer based tables.
*/

int make_irtables(AVSfield *field, struct IRTABLES *irt, int inter, int scale)
{ struct RTABLES t;
  int i, dim3;

  dim3 = (field->ndim == 3);
  if (!make_rtables(field, &t, inter + INTFLAG * scale)) return 0;

  irt->xl = irt->yl = irt->zl = NULL;    /* for easy error handling */
  irt->xs = irt->ys = irt->zs = NULL;
  irt->xi = irt->yi = irt->zi = NULL;
  irt->xt = irt->yt = irt->zt = NULL;
  irt->xc = irt->yc = irt->zc = NULL;

					 /* allocate all the tables */
  irt->xi = (int *) malloc(t.nsx * sizeof(int));
  irt->yi = (int *) malloc(t.nsy * sizeof(int));
  if (dim3) irt->zi = (int *) malloc(t.nsz * sizeof(int));

  irt->xt = (int *) malloc(t.nsx * sizeof(int));
  irt->yt = (int *) malloc(t.nsy * sizeof(int));
  if (dim3) irt->zt = (int *) malloc(t.nsz * sizeof(int));

  irt->xl = (int *) malloc(t.dimx * sizeof(int));
  irt->yl = (int *) malloc(t.dimy * sizeof(int));
  if (dim3) irt->zl = (int *) malloc(t.dimz * sizeof(int));

  irt->xs = (int *) malloc(t.dimx * sizeof(int));
  irt->ys = (int *) malloc(t.dimy * sizeof(int));
  if (dim3) irt->zs = (int *) malloc(t.dimz * sizeof(int));

  irt->xc = (int *) malloc(t.dimx * sizeof(int));
  irt->yc = (int *) malloc(t.dimy * sizeof(int));
  if (dim3) irt->zc = (int *) malloc(t.dimz * sizeof(int));

					  /* check allocation */
  if (!irt->xi || !irt->yi || (!irt->zi && dim3))
  { free_rtables((struct RTABLES *)irt);
    return 0;
  }
  if (!irt->xt || !irt->yt || (!irt->zt && dim3))
  { free_rtables((struct RTABLES *)irt);
    return 0;
  }
  if (!irt->xl || !irt->yl || (!irt->zl && dim3))
  { free_rtables((struct RTABLES *)irt);
    return 0;
  }
  if (!irt->xs || !irt->ys || (!irt->zs && dim3))
  { free_rtables((struct RTABLES *)irt);
    return 0;
  }
  if (!irt->xc || !irt->yc || (!irt->zc && dim3))
  { free_rtables((struct RTABLES *)irt);
    return 0;
  }

					 /* copy and scale relevant tables */
  for (i=0; i<t.nsx; i++) irt->xi[i] = t.xi[i];
  for (i=0; i<t.nsy; i++) irt->yi[i] = t.yi[i];
  if (dim3) for (i=0; i<t.nsz; i++) irt->zi[i] = t.zi[i];

  for (i=0; i<t.nsx; i++)
    if (t.xt[i] > -INF/2) irt->xt[i] = nint(t.xt[i] * scale);
    else                  irt->xt[i] = (int)-1e9;

  for (i=0; i<t.nsy; i++)
    if (t.yt[i] > -INF/2) irt->yt[i] = nint(t.yt[i] * scale);
    else                  irt->yt[i] = (int)-1e9;

  if (dim3)
  { for (i=0; i<t.nsz; i++)
      if (t.zt[i] > -INF/2) irt->zt[i] = nint(t.zt[i] * scale);
      else                  irt->zt[i] = (int)-1e9;
  }

  for (i=0; i<t.dimx; i++) irt->xl[i] = nint(t.xl[i] * scale);
  for (i=0; i<t.dimy; i++) irt->yl[i] = nint(t.yl[i] * scale);
  if (dim3) for (i=0; i<t.dimz; i++) irt->zl[i] = nint(t.zl[i] * scale);

  for (i=0; i<t.dimx; i++) irt->xs[i] = nint(scale / t.xs[i]);
  for (i=0; i<t.dimy; i++) irt->ys[i] = nint(scale / t.ys[i]);
  if (dim3) for (i=0; i<t.dimz; i++) irt->zs[i] = nint(scale / t.zs[i]);

  for (i=0; i<t.dimx; i++) irt->xc[i] = nint(t.xc[i] * scale);
  for (i=0; i<t.dimy; i++) irt->yc[i] = nint(t.yc[i] * scale);
  if (dim3) for (i=0; i<t.dimz; i++) irt->zc[i] = nint(t.zc[i] * scale);

					  /* copy / scale relevant variables */
  irt->minx = nint(t.minx * scale);
  irt->miny = nint(t.miny * scale);
  if (dim3) irt->minz = nint(t.minz * scale);

  irt->maxx = nint(t.maxx * scale);
  irt->maxy = nint(t.maxy * scale);
  if (dim3) irt->maxz = nint(t.maxz * scale);

  irt->msx = nint(t.msx * scale);
  irt->msy = nint(t.msy * scale);
  if (dim3) irt->msz = nint(t.msz * scale);

  irt->mix = nint(t.mix * scale + 1);
  irt->miy = nint(t.miy * scale + 1);
  if (dim3) irt->miz = nint(t.miz * scale + 1);

  irt->mx = nint(t.mx * scale - 1);
  irt->my = nint(t.my * scale - 1);
  if (dim3) irt->mz = nint(t.mz * scale - 1);

  irt->dimx = t.dimx;
  irt->dimy = t.dimy;
  if (dim3) irt->dimz = t.dimz;

  irt->nsx = t.nsx;
  irt->nsy = t.nsy;
  if (dim3) irt->nsz = t.nsz;

  irt->ax = t.ax;
  irt->ay = t.ay;
  if (dim3) irt->az = t.az;

  irt->ux = t.ux;
  irt->uy = t.uy;
  if (dim3) irt->uz = t.uz;

  irt->scale = scale;

  free_rtables(&t);
  return 1;
}


/* free the mess we've made.
   argument: t = pointer to previously filled lookup table structure.
*/

int free_rtables(struct RTABLES *t)
{ if (t->xi) free(t->xi);
  if (t->yi) free(t->yi);
  if (t->zi) free(t->zi);

  if (t->xt) free(t->xt);
  if (t->yt) free(t->yt);
  if (t->zt) free(t->zt);

  if (t->xl) free(t->xl);
  if (t->yl) free(t->yl);
  if (t->zl) free(t->zl);

  if (t->xs) free(t->xs);
  if (t->ys) free(t->ys);
  if (t->zs) free(t->zs);

  if (t->xc) free(t->xc);
  if (t->yc) free(t->yc);
  if (t->zc) free(t->zc);

  return 1;
}
