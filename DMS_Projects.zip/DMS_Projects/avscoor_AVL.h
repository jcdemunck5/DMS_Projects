/************************************************************************/
/*                                                                      */
/*      file       : AVSCOOR.H (was: AVSCOOR.H)                         */
/*                                                                      */
/*      purpose    : Include file for working with uniform/rectilinear  */
/*                   coordinates. Contains fast conversions of index to */
/*                   coordinates and vice-versa                         */
/*                                                                      */
/*      author     : Marcel van Herk (JCRT / NKI / AVL)                 */
/*                                                                      */
/*      date       : 27 - 4 - 92                                        */
/*                                                                      */
/*      portability: AVS requires sizeof(void *)==sizeof(int)           */
/*                                                                      */
/*      notes      : Use with AVSCOOR.C (was: AVS_COOR.C)               */
/*                                                                      */
/************************************************************************/
/* Updates:
When		Who	What
27-04-92        mvh     Creation (and several days before as well)
28-04-92        mvh     Added support for integer based coordinates
17-05-92        mvh     Changed module name
26-09-93        mvh     Adapted for windows NT
08-01-94        mvh     Standard header, portability notes and documentation
08-01-94        mvh     Added uniform flags ux, uy and uz
14-06-95        fcv     Added brackets in macro and detabbed
22-09-95	fcv	added protypes for make_rtables() and free_rtables()
09-11-95	fcv	added #ifdef c++ extern "C" {} for all lines
19970609	tp+lsp	ANSI function headers (protoize)
19971016	tp	Renamed to avscoor.h

  JdM    30-12-06   Adapted include file to new directory structure

*/

#include"Field.h"


#ifdef __cplusplus
extern "C" {
#endif

/* In the following comments the x coordinate has been used as example.
   The nomenclature is derived from ascending coordinate systems. minx
   should be read as firstx, while maxx should be read as lastx. The only
   exception is mix and mx, which are used for range checking. These are
   reversed for descending coordinate systems.
*/

struct RTABLES
{ int   *xi,  *yi,  *zi;  /* index from coordinate tables (nsx entries) */
  float *xt,  *yt,  *zt;  /* thresholds of coordinates (nsx entries)    */
  float *xl,  *yl,  *zl;  /* left coordinate per pixel (dimx entries)   */
  float *xs,  *ys,  *zs;  /* coordinate step per pixel (dimx entries)   */
  float *xc,  *yc,  *zc;  /* center of pixel (dimx entries)             */

  float minx, miny, minz; /* mimimum coordinate (left of first pixel)   */
  float maxx, maxy, maxz; /* maximum coordinate (left of last pixel)    */
  float msx,  msy,  msz;  /* minimal coordinate step (scale for index)  */
  float mix,  miy,  miz;  /* minimum for range checks                   */
  float mx,   my,   mz;   /* maximum for range checks                   */

  int   ix,   iy,   iz;   /* lookup table index temporaries (0..nsx-1)  */
  int   rx,   ry,   rz;   /* (returned) pixel index value (0..dimx-1)   */
  float vx,   vy,   vz;   /* coordinate temporaries (0..mx - minx)      */

  int   dimx, dimy, dimz; /* pixel counts in field                      */
  int   nsx,  nsy,  nsz;  /* number of entries in lookup tables         */
  int   ax,   ay,   az;   /* rect: 1 when ascending, -1 when descending */
  int   ux,   uy,   uz;   /* uniform flags for the three dimensions     */
};

struct IRTABLES           /* same structure for integer tables          */
{ int   *xi,  *yi,  *zi;  /* index from coordinate tables (nsx entries) */
  int   *xt,  *yt,  *zt;  /* thresholds of coordinates (nsx entries)    */
  int   *xl,  *yl,  *zl;  /* left coordinate per pixel (dimx entries)   */
  int   *xs,  *ys,  *zs;  /* coordinate step per pixel (dimx entries)   */
  int   *xc,  *yc,  *zc;  /* center of pixel (dimx entries)             */

  int   minx, miny, minz; /* mimimum coordinate (left of first pixel)   */
  int   maxx, maxy, maxz; /* maximum coordinate (left of last pixel)    */
  int   msx,  msy,  msz;  /* minimal coordinate step (scale for index)  */
  int   mix,  miy,  miz;  /* minimum for range checks                   */
  int   mx,   my,   mz;   /* maximum for range checks                   */

  int   ix,   iy,   iz;   /* lookup table index temporaries (0..nsx-1)  */
  int   rx,   ry,   rz;   /* (returned) pixel index value (0..dimx-1)   */
  int   vx,   vy,   vz;   /* coordinate temporaries (0..mx - minx)      */

  int   dimx, dimy, dimz; /* pixel counts in field                      */
  int   nsx,  nsy,  nsz;  /* number of entries in lookup tables         */
  int   ax,   ay,   az;   /* rect: 1 when ascending, -1 when descending */
  int   ux,   uy,   uz;   /* uniform flags for the three dimensions     */
  int   scale;            /* scale factor for coordinates               */
};


/* find pixel index from coordinate for x,y,z.
   arguments: x, y, z = input coordinate
              t       = rectilinear lookup table structure

   How it works: 1) returns -1 if coordinate c < minc or > mc, where mc is
                 maxc for interpolation tables, or maxc+msc for pixel
                 selection tables (which allow coordinates in last pixel).

                 2) looks up index from table with msc spacing. If the
                 answer is ambigeous (table cell covers two indices), a
                 comparison with the threshold value of this cell decides
                 which index should be returned (original or one less).
                 In non-ambigeous table cells the threshold is made
                 inactive (set to -INF). For descending fields the logic
                 is reversed, so that the index in incremented as a result
                 of the comparison.

  Note: 1) When ascending, the first comparison should be <, to allow for
           exact first pixel input. The problem is, however, that for
           descending input, the minimum is the last pixel, so that this
           change would allow exact last pixel input, going outside the range.
           The macros cannot process inputs exactly on the image borders.

        2) When descending, the comparison on the 8th line of the macro should
           be <=, because logic is reversed in this case. The problem is that
           some pixels at the exact boundary give back a fraction of 1.0. For
           most interpolation schemes this should be no problem.

  Warning: these macros evaluate (x) multiple times. Do NOT put any auto
  increments or decrements in the expression for (x).

  Because it is impossible to put comments in the macro, it is reproduced here.

1  #define coord_to_index_x(x, t)\               ..name of macro
2  ( (x) <= t.mix || (x) >= t.mx ?\              ..check if coordinate in image
3    ( t.rx = -1\                                .. if not: return -1 for index
4    ) :\                                        ..else
5    ( t.vx = (x) - t.minx,\                     .. value - first
6      t.ix = (int)(t.vx / t.msx),\              .. divide by step to get index
7      t.rx = t.xi[t.ix],\                       .. get index to return
8      t.vx < t.xt[t.ix] ? (t.rx -= t.ax) : t.rx\.. adjust index if needed
9    )\
10 )

*/

#define coord_to_index_x(x, t)\
( (x) <= (t).mix || (x) >= (t).mx ?\
  ( (t).rx = -1\
  ) :\
  ( (t).vx = (x) - (t).minx,\
    (t).ix = (int)((t).vx / (t).msx),\
    (t).rx = (t).xi[(t).ix],\
    (t).vx < (t).xt[(t).ix] ? ((t).rx -= (t).ax) : (t).rx\
  )\
)

#define coord_to_index_y(y, t)\
( (y) <= (t).miy || (y) >= (t).my ?\
  ( (t).ry = -1\
  ) :\
  ( (t).vy = (y) - (t).miny,\
    (t).iy = (int)((t).vy / (t).msy),\
    (t).ry = (t).yi[(t).iy],\
    (t).vy < (t).yt[(t).iy] ? ((t).ry -= (t).ay) : (t).ry\
  )\
)

#define coord_to_index_z(z, t)\
( (z) <= (t).miz || (z) >= (t).mz ?\
  ( (t).rz = -1\
  ) :\
  ( (t).vz = (z) - (t).minz,\
    (t).iz = (int)((t).vz / (t).msz),\
    (t).rz = (t).zi[(t).iz],\
    (t).vz < (t).zt[(t).iz] ? ((t).rz -= (t).az) : (t).rz\
  )\
)



/* find fractional index for previously obtained pixel index.
   argument: t = rectilinear lookup table structure.
   returns fraction (0..1) of cell coordinate for coordinate
   previously processed by coord_to_index macros.

   How it works:
   returns (x value - low x of cell) * (1 / step size of cell).

   Note: use ifrac_x for integer based coordinates.
*/

#define frac_x(t) (((t).vx - (t).xl[(t).rx]) * (t).xs[(t).rx])
#define frac_y(t) (((t).vy - (t).yl[(t).ry]) * (t).ys[(t).ry])
#define frac_z(t) (((t).vz - (t).zl[(t).rz]) * (t).zs[(t).rz])

#define ifrac_x(t) (((t).vx - (t).xl[(t).rx]) * (t).scale / (t).xs[(t).rx])
#define ifrac_y(t) (((t).vy - (t).yl[(t).ry]) * (t).scale / (t).ys[(t).ry])
#define ifrac_z(t) (((t).vz - (t).zl[(t).rz]) * (t).scale / (t).zs[(t).rz])

/* return coordinate for index (allways center of pixel cell) */
#define index_to_coord_x(i,t) ((t).xc[i])
#define index_to_coord_y(i,t) ((t).yc[i])
#define index_to_coord_z(i,t) ((t).zc[i])

int make_rtables(AVSfield *f, struct RTABLES *t, int i);
int free_rtables(struct RTABLES *t);
/*int make_rtables();  inter is NOT used anymore */

/* make_rtables(field, t, inter) construct lookup tables for the field into t.
   arguments: field = 3D field for relevant operation (UNIFORM or RECTILINEAR).
              t     = pointer to table structure.
              inter = flag, must be set when using tables for interpolating
                      must be clear when using tables for nearest pixel.

   returns: 0 for failure (out of memory or other), 1 for success

   The nearest pixel tables are valid from left of first pixel to right
   of last pixel. The interpolation tables are valid from middle of first
   pixel to middle of the one-before-last pixel.

   note : use free_rtables to free the tables when done. The tables can take
   up a significant amount of space (more than 30 kbyte) depending on the
   presence of some pixel cells which are much smaller than the others.
*/

int make_irtables(AVSfield *field, struct IRTABLES *irt, int inter, int scale);
/* make_irtables(field, t, inter, scale) construct integer coordinate based
					 lookup tables for the field into t.
   arguments: field = 3D field for relevant operation (UNIFORM or RECTILINEAR).
	      t     = pointer to IRTABLES structure.
	      inter = flag, must be set when using tables for interpolating
		      must be clear when using tables for nearest pixel.
	      scale = scale factor, all input coordinates must be scaled by
		      this factor, and all output fractions and coordinates
		      are scaled by this factor.

   For the rest, see the description of make_rtables.
*/

/*int free_rtables();*/
/* free_rtables(t)  free the mess we've made
   argument: t = pointer to previously filled lookup table structure.
*/

#ifdef __cplusplus
}
#endif
